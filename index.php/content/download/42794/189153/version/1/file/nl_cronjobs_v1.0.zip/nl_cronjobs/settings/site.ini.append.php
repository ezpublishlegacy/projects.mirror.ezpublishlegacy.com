<?php /*

[RegionalSettings]
TranslationExtensions[]=nl_cronjobs

*/ ?>
