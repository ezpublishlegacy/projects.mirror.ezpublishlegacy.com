<?php /* #?ini charset="utf-8"?

[ProcessSettings]
PhpCliPath=php
SleepTime=2
MaxExecutionTime=3600
OutputFile=var/log/process_output.log
ErrorFile=var/log/process_error.log



*/ ?>
