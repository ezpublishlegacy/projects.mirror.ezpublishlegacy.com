<?php /*

[NavigationPart]
Part[nlcronjobnavigationpart]=NL Cronjobs

[TopAdminMenu]
Tabs[]=nlcronjobs

[Topmenu_nlcronjobs]
NavigationPartIdentifier=nlcronjobnavigationpart
Name=Cronjobs
Tooltip=Cronjobs dashboard
URL[]
URL[default]=cronjobs/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
# We don't show it in browse mode
Shown[browse]=true
PolicyList[]=cronjobs/list
*/ ?>
