<?php /*

[Settings]
# Load the eZ Locale Settings. 
# By default eZDatePicker loads jquery-ui-i18n.js for locales
# but if you want to load the settings in the locale.ini you can enable it
UseLocaleConfig=enabled


*/ ?>