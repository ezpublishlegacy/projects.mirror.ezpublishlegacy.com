<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezdatepicker

*/ ?>