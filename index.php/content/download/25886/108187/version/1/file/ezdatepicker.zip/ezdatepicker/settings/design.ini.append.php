<?php /*

[ExtensionSettings]
DesignExtensions[]=ezdatepicker

[StylesheetSettings]
CSSFileList[]=ezdatepicker.css

[JavaScriptSettings]
JavaScriptList[]=jquery-1.3.2.min.js
JavaScriptList[]=jquery-ui-1.7.2.custom.min.js
JavaScriptList[]=jquery-ui-i18n.js

*/ ?>