<?php

class subtreelocationInfo
{
    static function info()
    {
        $subtreeLocationCopyrightString = 'Copyright (C) 1999-2010 Jonathan Bouzekri';

        return array( 'Name'      => '<a href="http://projects.ez.no/subtreelocation">Subtree Location</a> extension',
                      'Version'   => '0.1',
                      'Copyright' => $subtreeLocationCopyrightString,
                      'License'   => 'GNU General Public License v2.0',),
                    );
    }
}

?>
