<?php /* #?ini charset="utf-8"?

# Action for selecting a node placement for a subtree.
[AddSubtreeAssignment]
StartNode=content
SelectionType=multiple
ReturnType=NodeID
StartNode_classgroup[2]=users

*/
