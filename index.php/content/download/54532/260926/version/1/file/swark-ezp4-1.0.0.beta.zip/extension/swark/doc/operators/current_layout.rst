current_layout
--------------

Summary
~~~~~~~
Returns the name of the current layout (set by, for example, the layout/set function) or false for the standard layout.

Usage
~~~~~
::

    current_layout()

Parameters
~~~~~~~~~~
None.
