<?php /* #?ini charset="utf-8"?
[ModuleSettings]
ExtensionRepositories[]=jvamazonadvertising
ModuleList[]=amazonadvertising
*/
