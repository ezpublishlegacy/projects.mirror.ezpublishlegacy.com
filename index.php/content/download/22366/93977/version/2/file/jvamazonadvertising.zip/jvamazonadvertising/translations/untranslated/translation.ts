<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>design/standard/class/datatype/jvamazonid</name>
    <message>
        <source>Reference field for ASIN search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter attribute identifiers as for object name (ie. &amp;lt;my_attribute_identifier&amp;gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If left empty, will be content object name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically search ASIN on publish if object attribute is left empty (default value)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amazon SearchIndex (category) to search into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a valid search index (product category).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search indexes are listed here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amazon BrowseNode (sub-category) to search into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a valid browse node (product location in Amazon catalog). Leave empty if not applicable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find a browse nodes non-exhaustive list here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype/jvamazonid</name>
    <message>
        <source>Search Amazon ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically search Amazon ID on publish if empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No product has been found in Amazon catalog for the search query &quot;%searchquery&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the right product name to fill the field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/jvamazonadvertising/error</name>
    <message>
        <location filename="jvamazonidtype.php" line="211"/>
        <source>Invalid Amazon product ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
