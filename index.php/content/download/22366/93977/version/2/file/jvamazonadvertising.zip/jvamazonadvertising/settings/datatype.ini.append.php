<?php /* #?ini charset="utf-8"?

[ViewSettings]
GroupedInput[]=jvamazonid

[EditSettings]
GroupedInput[]=jvamazonid

*/
