<?php
include_once('extension/topandroid/classes/simple_html_dom.php');
/*!
  \class   TopAppsOperator topappsoperator.php
  \ingroup eZTemplateOperators
  \brief   List top apps from app store.
  \version 1.0
  \date    Wednesday 28 July 2010 11:37:15 am
  \author  Thiago Campos Viana

*/


class TopAndroidOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TopAndroidOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'topandroid' );
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'topandroid' => array( 'type' => array(	'type' => 'string',
																'required' => false,
																'default'=>'free')));
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {

		$type = $namedParameters['type'];
		
		$html = file_get_html("http://www.android.com/market/".$type.".html");
		//echo "http://www.android.com/market/".$type.".html";
		// get article block
		$output = $html->find('div[id=appPage-1] div'); 
		//echo $output->innertext;
		$operatorValue="<ul class=\"top-".$type."-apps\">";
		$count=1;
		//print_r($output);
		
		foreach($output as $article) {
			// get title
			$operatorValue.="<li class=\"top-".$count."\">";
			$id = str_replace("appThumb-","",$article->id);
			$title = trim($article->find('span',0)->innertext);
			$link="http://www.android.com/market/".$type.".html#app=".$id;

			$img = "<img src=\"http://www.android.com/market/".$article->find('img',0)->src."\" alt=\"".$title."\" />";

			$operatorValue.="<strong>".$count.".</strong>";
			$operatorValue.="<h3><a href=\"".$link."\">".$title."</a></h3>";
			$operatorValue.="<a href=\"".$link."\">".$img."</a>";
			
			$operatorValue.="</li>";
			$count++;		

		}
		
		$operatorValue.="</ul>";
		// clean up memory
		$html->clear();
		unset($html);
		
    }
}

?>