<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/topandroid/classes/topandroidoperator.php',
                                    'class' => 'TopAndroidOperator',
                                    'operator_names' => array( 'topandroid' ) );

?>
