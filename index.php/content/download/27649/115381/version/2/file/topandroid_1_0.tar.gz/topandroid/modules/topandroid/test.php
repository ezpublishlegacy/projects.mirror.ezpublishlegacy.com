<?php

$tpl = eZTemplate::factory();

$Result = array();
$Result['path'] = array( array( 'url' => false,

                'text' => 'TopAndroid' ),

        array( 'url' => false,

                'text' => 'Test' ) );
$Result['content']=$tpl->fetch("design:topandroid/test.tpl");

?>
