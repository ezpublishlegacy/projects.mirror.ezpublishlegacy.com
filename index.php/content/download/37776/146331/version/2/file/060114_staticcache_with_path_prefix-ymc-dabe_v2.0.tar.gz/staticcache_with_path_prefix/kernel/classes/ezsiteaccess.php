<?php
//
// Definition of eZSiteAccess class
//
// Created on: <22-���-2003 16:23:14 sp>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezsiteaccess.php
*/

/*!
  \class eZSiteAccess ezsiteaccess.php
  \brief The class eZSiteAccess does

*/

include_once( 'lib/ezutils/classes/ezsys.php' );

class eZSiteAccess
{
    /*!
     Constructor
    */
    function eZSiteAccess()
    {
    }

    function siteAccessList()
    {
        $ini =& eZINI::instance();
        $siteAccessArray =& $ini->variable( 'SiteAccessSettings', 'AvailableSiteAccessList' );

        $siteAccessList = array();
        reset( $siteAccessArray );
        foreach ( array_keys( $siteAccessArray ) as $key )
        {
            $siteAccessItem = array();
            $siteAccessItem['name'] =& $siteAccessArray[$key];
            $siteAccessItem['id'] = crc32( $siteAccessArray[$key] );
            $siteAccessList[] = $siteAccessItem;
        }
        if ( $serversiteaccess = eZSys::serverVariable( $ini->variable( 'SiteAccessSettings', 'ServerVariableName' ), true ) )
        {
            $siteAccessItem = array();
            $siteAccessItem['name'] =& $serversiteaccess;
            $siteAccessItem['id'] = crc32( $serversiteaccess );
            $siteAccessList[] = $siteAccessItem;
        }
        return $siteAccessList;
    }

    /*!
     This function switches to a different siteaccess.
    */
    function switchSiteaccess( $requested_siteaccess = false )
    {
        $current_siteaccess = $GLOBALS['eZCurrentAccess']['name'];

        if ( $current_siteaccess === null )
            return;

        if (!isset($GLOBALS['eZOriginalAccess']) )
        {
            $GLOBALS['eZOriginalAccess'] = $current_siteaccess;
        }

        if ( !$requested_siteaccess )
        {
            $requested_siteaccess = $GLOBALS['eZOriginalAccess'];
        }

        if (!is_array($GLOBALS['eZSiteaccessSwitchCache']) )
        {
            $GLOBALS['eZSiteaccessSwitchCache'] = array();
        }

        if (!is_array($GLOBALS['eZSiteaccessSwitchCache'][$current_siteaccess]) )
        {
            $GLOBALS['eZSiteaccessSwitchCache'][$current_siteaccess] = $GLOBALS["eZINIOverrideDirList"];
        }

        $GLOBALS["eZINIOverrideDirList"] = $GLOBALS['eZSiteaccessSwitchCache'][$requested_siteaccess];
        $GLOBALS['eZCurrentAccess']['name'] = $requested_siteaccess;

        $notCached = true;
        if (!is_array($GLOBALS["eZINIOverrideDirList"]) )
        {
            $notCached = false;
            $GLOBALS["eZINIOverrideDirList"] = array( 0 => array( 0 => 'override',
                                                                  1 => '',
                                                                  2 => '') );
            $ini =& eZINI::instance();
            $ini->loadCache();

            // Check for extension
            eZExtension::activateExtensions( 'default' );
            // Extension check end
            $settingsDir = array( 0 => 'siteaccess/'.$requested_siteaccess,
                                  1 => '',
                                  2 => 'siteaccess');

            array_unshift( $GLOBALS["eZINIOverrideDirList"], $settingsDir );
            $ini->loadCache();

            // Check for siteaccess extension
            eZExtension::activateExtensions( 'access' );
            // Siteaccess extension check end

            $GLOBALS['eZSiteaccessSwitchCache'][$requested_siteaccess] = $GLOBALS["eZINIOverrideDirList"];
        }

        if ( $notCached )
        {
            $ini =& eZINI::instance();
            $ini->loadCache();
        }

        $rootDir = 'settings';
        $iniFiles = array();
        foreach ( eZDir::recursiveFindRelative( $rootDir, '', '.ini' ) as $iniFile )
        {
            $corrected = strrchr( $iniFile, '/' );
            if ( $corrected )
            {
                $iniFiles[] = $corrected;
            }
        }
        $iniFiles = str_replace('/', '', $iniFiles );
        sort( array_unique($iniFiles) );

        foreach ( $iniFiles as $resetIniFile )
        {
            $ini =& eZINI::instance($resetIniFile);
            $ini->loadCache();
        }
    }
}

?>
