<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=userexp
AvailableDataTypes[]=userexp

*/ ?>
