CREATE TABLE IF NOT EXISTS `userexp` (
  `contentobject_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `experience` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`contentobject_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `userexp_data` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `contentobject_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `experience` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userexp_data_content_id` ( `contentobject_id`, `user_id` )
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


