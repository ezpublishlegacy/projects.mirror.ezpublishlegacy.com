<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=userexp

[ExtensionSettings]
ActiveExtensions[]=userexp

[RegionalSettings]
TranslationExtensions[]=userexp


*/ ?>