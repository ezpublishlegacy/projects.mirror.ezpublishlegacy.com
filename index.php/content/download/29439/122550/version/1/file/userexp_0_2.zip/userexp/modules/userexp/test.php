<?php

$tpl = eZTemplate::factory();


$user = eZUser::currentUser();

$userID = $user->attribute( 'contentobject_id' );
//$contentObject=eZContentObject::fetch($userID);
$contentObject=eZContentObject::fetch($userID);
//var_dump(eZContentObject::fetch($userID));


$attribs = $contentObject->contentObjectAttributes();
        $loopLength = count($attribs);
        
        for ($i = 0; $i < $loopLength; $i++) {
        //echo "<br />".$attribs[$i]->attribute( 'data_type_string' );


            switch ($attribs[$i]->attribute("data_type_string")) {

                case 'userexp':
                //echo "<br />".$attribs[$i]->content();
                echo "<br />".$attribs[$i]->toString($attribs[$i]);
                    $attribs[$i]->fromString("125|2");
                    //$attribs[$i]->setAttribute( 'data_float', 1 );
                    //$attribs[$i]->store();
                    echo $attribs[$i]->toString($attribs[$i]);
                    echo "<br />".var_dump($attribs[$i]->content());
                    $attribs[$i]->fromString("-46|2");
                    echo "<br />".$attribs[$i]->toString($attribs[$i]);
                    
                    $attribs[$i]->fromString("-1|2");
                    echo "<br />".$attribs[$i]->toString($attribs[$i]);
                    
                    $attribs[$i]->fromString("1|2");
                    echo "<br />".$attribs[$i]->toString($attribs[$i]);
                    //$attribs[$i]->store();
                    break;
                    
            }
            
        }


$rateDataObj = UserExpDataObject::create( array( 'id' => 1,
                                                    'text' =>  'eee'
        ));
		$rateDataObj->store();
		
		$rateDataObj = UserExpDataObject::fetch( 2 );
		if($rateDataObj==null)
		var_dump($rateDataObj);
		exit;

$Result = array();
$Result['path'] = array( array( 'url' => false,

                'text' => 'userexp' ),

        array( 'url' => false,

                'text' => 'Test' ) );
$Result['content']=$tpl->fetch("design:userexp/test.tpl");

?>
