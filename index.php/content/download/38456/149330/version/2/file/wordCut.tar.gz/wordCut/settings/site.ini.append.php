<?php

[TemplateSettings]
ExtensionAutoloadPath[]=wordCut

?>
