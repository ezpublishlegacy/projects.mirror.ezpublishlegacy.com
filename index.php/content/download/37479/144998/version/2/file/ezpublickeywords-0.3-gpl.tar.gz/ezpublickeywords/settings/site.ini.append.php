<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezpublickeywords

[RegionalSettings]
TranslationExtensions[]=ezpublickeywords

*/ ?>
