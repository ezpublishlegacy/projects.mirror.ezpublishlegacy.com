<!DOCTYPE TS><TS>
<context>
    <name>extension/ezpublickeywords</name>
    <message>
        <source>Public keywords</source>
        <translation>Publiczne słowa kluczowe</translation>
    </message>
</context>
<context>
    <name>extension/ezpublickeywords/class</name>
    <message>
        <source>Keyword amount range</source>
        <translation>Zakres ilości wyrażeń kluczowych</translation>
    </message>
    <message>
        <source>Single keyword length range</source>
        <translation>Zakres długości pojedynczego wyrażenia</translation>
    </message>
    <message>
        <source>keywords</source>
        <translation>wyrażeń kluczowych</translation>
    </message>
    <message>
        <source>characters</source>
        <translation>znaków</translation>
    </message>
</context>
<context>
    <name>extension/ezpublickeywords/error</name>
    <message>
        <source>You have entered %userAmount keywords. The minimum allowed amount of keywords is %systemAmount.</source>
        <translation>Wpisano %userAmount wyrażeń kluczowych. Minimalna dopuszczalna liczba wyrażeń kluczowych wynosi %systemAmount.</translation>
    </message>
    <message>
        <source>You have entered %userAmount keywords. The maximum allowed amount of keywords is %systemAmount.</source>
        <translation>Wpisano %userAmount wyrażeń kluczowych. Maksymalna dopuszczalna liczba wyrażeń kluczowych wynosi %systemAmount.</translation>
    </message>
    <message>
        <source>One of the keywords you entered is %userLength characters long. The minimum allowed length of single keyword is %systemLength characters.</source>
        <translation>Długość jednego z wpisanych wyrażeń wynosi %userLength znaków. Minimalna dopuszczalna długość pojedynczego wyrażenia kluczowego wynosi %systemLength znaków.</translation>
    </message>
    <message>
        <source>One of the keywords you entered is %userLength characters long. The maximum allowed length of single keyword is %systemLength characters.</source>
        <translation>Długość jednego z wpisanych wyrażeń wynosi %userLength znaków. Maksymalna dopuszczalna długość pojedynczego wyrażenia kluczowego wynosi %systemLength znaków.</translation>
    </message>
    <message>
        <source>One of the keywords you entered uses illegal characters. Allowed characters are: %characters.</source>
        <translation>Jedno z wpisanych wyrażeń zawiera niedopuszczalne znaki. Dozwolone są: %characters.</translation>
    </message> 
</context>
<context>
    <name>extension/ezpublickeywords/range</name>
    <message>
        <source>lowercase</source>
        <translation>mała litera</translation>
    </message>
    <message>
        <source>uppercase</source>
        <translation>wielka litera</translation>
    </message>
    <message>
        <source>digits</source>
        <translation>cyfry</translation>
    </message>
    <message>
        <source>Polish lowercase</source>
        <translation>polskie znaki małą</translation>
    </message>
    <message>
        <source>Polish uppercase</source>
        <translation>polskie znaki wielką</translation>
    </message>
    <message>
        <source>German lowercase</source>
        <translation>niemieckie znaki małą</translation>
    </message>
    <message>
        <source>German uppercase</source>
        <translation>niemieckie znaki wielką</translation>
    </message>
    <message>
        <source>space and hyphen</source>
        <translation>spaca i kreska</translation>
    </message>
</context>
</TS>
