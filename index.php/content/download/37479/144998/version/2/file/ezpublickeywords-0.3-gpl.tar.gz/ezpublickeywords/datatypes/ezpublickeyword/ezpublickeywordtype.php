<?php

/**
 * eZ Public Keywords extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */




class eZPublicKeywordType extends eZKeywordType
{
    const DATA_TYPE_STRING = 'ezpublickeyword';

    const MIN_AMOUNT_FIELD = 'data_int1';
    const MIN_AMOUNT_VARIABLE = '_ezpublickeyword_min_amount_';
    const MAX_AMOUNT_FIELD = 'data_int2';
    const MAX_AMOUNT_VARIABLE = '_ezpublickeyword_max_amount_';
    const MIN_LENGTH_FIELD = 'data_int3';
    const MIN_LENGTH_VARIABLE = '_ezpublickeyword_min_length_';
    const MAX_LENGTH_FIELD = 'data_int4';
    const MAX_LENGTH_VARIABLE = '_ezpublickeyword_max_length_';


    function __construct()
    {
        $this->eZDataType( self::DATA_TYPE_STRING, ezi18n( 'extension/ezpublickeywords', 'Public keywords' ),
        array( 'serialize_supported' => true ) );
    }


    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_ezpublickeyword_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data = $http->postVariable( $base . '_ezpublickeyword_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $classAttribute = $contentObjectAttribute->contentClassAttribute();


            if ( $data == '' )
            {
                if ( !$classAttribute->attribute( 'is_information_collector' ) and
                $contentObjectAttribute->validateIsRequired() )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Input required.' ) );
                    return eZInputValidator::STATE_INVALID;
                }
            }
            else
            {
                $keyword = new eZKeyword();
                $keyword->initializeKeyword( $data );
                $keywordArray = $keyword->keywordArray();
                $keywordArrayCount = count( $keywordArray );

                $minAmount = $classAttribute->attribute( self::MIN_AMOUNT_FIELD );
                if( $keywordArrayCount < $minAmount )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezpublickeywords/error',
                		'You have entered %userAmount keywords. The minimum allowed amount of keywords is %systemAmount.', null, array( '%userAmount' => $keywordArrayCount, '%systemAmount' => $minAmount ) ) );
                    return eZInputValidator::STATE_INVALID;
                }
                $maxAmount = $classAttribute->attribute( self::MAX_AMOUNT_FIELD );
                if( $keywordArrayCount > $maxAmount )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezpublickeywords/error',
                		'You have entered %userAmount keywords. The maximum allowed amount of keywords is %systemAmount.', null, array( '%userAmount' => $keywordArrayCount, '%systemAmount' => $maxAmount ) ) );
                    return eZInputValidator::STATE_INVALID;
                }

                $ini = eZINI::instance( 'publickeywords.ini' );
                $globalRangeINI = $ini->group( 'GlobalRangeSettings' );

                $languageCharsetName = 'Charset_'.$contentObjectAttribute->LanguageCode;
                if( $ini->hasGroup( $languageCharsetName ) )
                {
                    $languageCharsetINI = $ini->group( $languageCharsetName );
                }
                else
                {
                    $languageCharsetINI = $ini->group( 'CharsetDefault' );
                }

                $allowedCharset = '';
                $translationArray = array();
                foreach( $languageCharsetINI['CharsetDefinition'] as $charset )
                {
                    if( in_array( $charset, array_keys( $globalRangeINI['AvailableCharset'] ) ) )
                    {
                        $allowedCharset .= $globalRangeINI['AvailableCharset'][$charset];
                        $translationArray[$charset] = array();
                        if( $globalRangeINI['TranslateSubsets'] == 'true' )
                        {
                            if( in_array( $charset, array_keys( $globalRangeINI['AvailableCharsetNames'] ) ) )
                            {
                                $translationArray[$charset]['translation'] = $globalRangeINI['AvailableCharsetNames'][$charset];
                            }
                        }
                        $translationArray[$charset]['value'] = $globalRangeINI['AvailableCharset'][$charset];
                    }
                }
                $allowedCharsetTranslation = '';
                $allowedCharsetTranslationCount = count( $translationArray );
                $cnt = 0;
                foreach( $translationArray as $translation )
                {
                    if( $cnt > 0 && $cnt < $allowedCharsetTranslationCount )
                    {
                        $allowedCharsetTranslation .= ', ';
                    }
                    if( $globalRangeINI['TranslateSubsets'] == 'true' )
                    {
                        if( isset( $translation['translation'] ) )
                        {
                            $allowedCharsetTranslation .= ezi18n( 'extension/ezpublickeywords/range', $translation['translation'] );
                        }
                        else
                        {
                            $allowedCharsetTranslation .= $translation['value'];
                        }
                    }
                    else
                    {
                        $allowedCharsetTranslation .= $translation['value'];
                    }
                    $cnt++;
                }


                $keywordsTooLong = 0;
                $keywordsTooShort = 0;
                $keywordsInvalidCharset = 0;
                $minLength = $classAttribute->attribute( self::MIN_LENGTH_FIELD );
                $maxLength = $classAttribute->attribute( self::MAX_LENGTH_FIELD );
                $mbEregPattern = "^[".$allowedCharset."]{".$minLength.",".$maxLength."}$";
                foreach( $keywordArray as $keyword )
                {
                    $keywordLength = mb_strlen( $keyword );
                    if( $keywordLength > 0 && $keywordLength < $minLength )
                    {
                        $keywordsTooShort++;
                        break;
                    }
                    else
                    if( $keywordLength > $maxLength )
                    {
                        $keywordsTooLong++;
                        break;
                    }
                    if( !ereg( $mbEregPattern, $keyword ) )
                    {
                        $keywordsInvalidCharset++;
                        break;
                    }
                }

                if( $keywordsTooShort )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezpublickeywords/error',
                		'One of the keywords you entered is %userLength characters long. The minimum allowed length of single keyword is %systemLength characters.', null, array( '%userLength' => $keywordLength, '%systemLength' => $minLength ) ) );
                    return eZInputValidator::STATE_INVALID;
                }

                if( $keywordsTooLong )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezpublickeywords/error',
                		'One of the keywords you entered is %userLength characters long. The maximum allowed length of single keyword is %systemLength characters.', null, array( '%userLength' => $keywordLength, '%systemLength' => $maxLength ) ) );
                    return eZInputValidator::STATE_INVALID;
                }

                if( $keywordsInvalidCharset )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezpublickeywords/error',
                		'One of the keywords you entered uses illegal characters. Allowed characters are: %characters.', null, array( '%characters' => $allowedCharsetTranslation ) ) );
                    return eZInputValidator::STATE_INVALID;
                }

            }
        }
        return eZInputValidator::STATE_ACCEPTED;
    }


    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_ezpublickeyword_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data = $http->postVariable( $base . '_ezpublickeyword_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $keyword = new eZKeyword();
            $keyword->initializeKeyword( $data );
            $contentObjectAttribute->setContent( $keyword );
            return true;
        }
        return false;
    }



    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $ini = eZINI::instance( 'publickeywords.ini' );
        $globalRangeINI = $ini->group( 'GlobalRangeSettings' );

        $minAmountVariable = $globalRangeINI['MinAmount'];
        $minAmountVariableName = $base . self::MIN_AMOUNT_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $minAmountVariableName ) )
        {
            $minAmountVariable = $http->postVariable( $minAmountVariableName );
        }

        $maxAmountVariable = $globalRangeINI['MaxAmount'];
        $maxAmountVariableName = $base . self::MAX_AMOUNT_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $maxAmountVariableName ) )
        {
            $maxAmountVariable = $http->postVariable( $maxAmountVariableName );
        }

        $minLengthVariable = $globalRangeINI['MinLength'];
        $minLengthVariableName = $base . self::MIN_LENGTH_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $minLengthVariableName ) )
        {
            $minLengthVariable = $http->postVariable( $minLengthVariableName );
        }

        $maxLengthVariable = $globalRangeINI['MaxLength'];
        $maxLengthVariableName = $base . self::MAX_LENGTH_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $maxLengthVariableName ) )
        {
            $maxLengthVariable = $http->postVariable( $maxLengthVariableName );
        }

        if( !is_numeric( $minAmountVariable ) || !is_numeric( $maxAmountVariable ) || !is_numeric( $minLengthVariable ) || !is_numeric( $maxLengthVariable ))
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $minAmountVariable > $maxAmountVariable )
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $minLengthVariable > $maxLengthVariable )
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $minAmountVariable < $globalRangeINI['MinAmount'] )
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $maxAmountVariable > $globalRangeINI['MaxAmount'] )
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $minLengthVariable < $globalRangeINI['MinLength'] )
        {
            return eZInputValidator::STATE_INVALID;
        }

        if( $maxLengthVariable > $globalRangeINI['MaxLength'] )
        {
            return eZInputValidator::STATE_INVALID;
        }

        return eZInputValidator::STATE_ACCEPTED;
    }



    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {

        $ini = eZINI::instance( 'publickeywords.ini' );
        $globalRangeINI = $ini->group( 'GlobalRangeSettings' );

        $minAmountVariable = $globalRangeINI['MinAmount'];
        $minAmountVariableName = $base . self::MIN_AMOUNT_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $minAmountVariableName ) )
        {
            $minAmountVariable = $http->postVariable( $minAmountVariableName );
            $classAttribute->setAttribute( self::MIN_AMOUNT_FIELD, $minAmountVariable );
        }

        $maxAmountVariable = $globalRangeINI['MaxAmount'];
        $maxAmountVariableName = $base . self::MAX_AMOUNT_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $maxAmountVariableName ) )
        {
            $maxAmountVariable = $http->postVariable( $maxAmountVariableName );
            $classAttribute->setAttribute( self::MAX_AMOUNT_FIELD, $maxAmountVariable );
        }

        $minLengthVariable = $globalRangeINI['MinLength'];
        $minLengthVariableName = $base . self::MIN_LENGTH_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $minLengthVariableName ) )
        {
            $minLengthVariable = $http->postVariable( $minLengthVariableName );
            $classAttribute->setAttribute( self::MIN_LENGTH_FIELD, $minLengthVariable );
        }

        $maxLengthVariable = $globalRangeINI['MaxLength'];
        $maxLengthVariableName = $base . self::MAX_LENGTH_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $maxLengthVariableName ) )
        {
            $maxLengthVariable = $http->postVariable( $maxLengthVariableName );
            $classAttribute->setAttribute( self::MAX_LENGTH_FIELD, $maxLengthVariable );
        }

    }

    
}

eZDataType::register( eZPublicKeywordType::DATA_TYPE_STRING, 'eZPublicKeywordType' );

?>
