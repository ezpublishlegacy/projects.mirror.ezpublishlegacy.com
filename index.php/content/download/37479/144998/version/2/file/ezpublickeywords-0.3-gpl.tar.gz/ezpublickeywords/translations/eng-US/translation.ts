<!DOCTYPE TS><TS>
<context>
    <name>extension/ezpublickeywords</name>
    <message>
        <source>Public keywords</source>
        <translation>Public keywords</translation>
    </message>
</context>
<context>
    <name>extension/ezpublickeywords/class</name>
    <message>
        <source>Keyword amount range</source>
        <translation>Public keywords</translation>
    </message>
    <message>
        <source>Single keyword length range</source>
        <translation>Public keywords</translation>
    </message>
    <message>
        <source>keywords</source>
        <translation>keywords</translation>
    </message>
    <message>
        <source>characters</source>
        <translation>characters</translation>
    </message>
</context>
<context>
    <name>extension/ezpublickeywords/error</name>
    <message>
        <source>You have entered %userAmount keywords. The minimum allowed amount of keywords is %systemAmount.</source>
        <translation>You have entered %userAmount keywords. The minimum allowed amount of keywords is %systemAmount.</translation>
    </message>
    <message>
        <source>You have entered %userAmount keywords. The maximum allowed amount of keywords is %systemAmount.</source>
        <translation>You have entered %userAmount keywords. The maximum allowed amount of keywords is %systemAmount.</translation>
    </message>
    <message>
        <source>One of the keywords you entered is %userLength characters long. The minimum allowed length of single keyword is %systemLength characters.</source>
        <translation>One of the keywords you entered is %userLength characters long. The minimum allowed length of single keyword is %systemLength characters.</translation>
    </message>
    <message>
        <source>One of the keywords you entered is %userLength characters long. The maximum allowed length of single keyword is %systemLength characters.</source>
        <translation>One of the keywords you entered is %userLength characters long. The maximum allowed length of single keyword is %systemLength characters.</translation>
    </message>
    <message>
        <source>One of the keywords you entered uses illegal characters. Allowed characters are: %characters.</source>
        <translation>One of the keywords you entered uses illegal characters. Allowed characters are: %characters.</translation>
    </message>    
</context>
<context>
    <name>extension/ezpublickeywords/range</name>
    <message>
        <source>lowercase</source>
        <translation>lowercase</translation>
    </message>
    <message>
        <source>uppercase</source>
        <translation>uppercase</translation>
    </message>
    <message>
        <source>digits</source>
        <translation>digits</translation>
    </message>
    <message>
        <source>Polish lowercase</source>
        <translation>Polish lowercase</translation>
    </message>
    <message>
        <source>Polish uppercase</source>
        <translation>Polish uppercase</translation>
    </message>
    <message>
        <source>German lowercase</source>
        <translation>German lowercase</translation>
    </message>
    <message>
        <source>German uppercase</source>
        <translation>German uppercase</translation>
    </message>
    <message>
        <source>space and hyphen</source>
        <translation>space and hyphen</translation>
    </message>
</context>
</TS>
