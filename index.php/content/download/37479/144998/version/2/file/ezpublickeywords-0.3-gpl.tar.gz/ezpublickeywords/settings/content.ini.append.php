<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezpublickeywords
AvailableDataTypes[]=ezpublickeyword

*/ ?>
