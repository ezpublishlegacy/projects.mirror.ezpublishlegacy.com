<?php /* #?ini charset="utf-8"?


# Global range settings for minimum and maximum amounts and lengths that
# define what ranges will be allowed in the class attribute definitions.
# These values cannot be overriden by values smaller than minimums and larger
# than maximums.

[GlobalRangeSettings]

# Minimum and maximum amount range.
MinAmount=0
MaxAmount=30

# Minimum and maximum length of a single keyword (in characters).
MinLength=2
MaxLength=50


# Character sets that will be available for customizing allowed charsets
# per language.
# Note: Space, to be allowed within a keyword, needs to be at least in one 
# of the following. The declarations have to be PHP ereg() function compatible!
# That includes ranges, escape string etc.
AvailableCharset[]
AvailableCharset[standard_lowercase]=a-z
AvailableCharset[standard_uppercase]=A-Z
AvailableCharset[digits]=0-9
AvailableCharset[polish_lowercase]=ąćęłńóśźż
AvailableCharset[polish_uppercase]=ĄĆĘŁŃÓŚŹŻ
AvailableCharset[german_lowercase]=äëöß
AvailableCharset[german_uppercase]=ÄËÖß
AvailableCharset[special]= -

# Whether validation messages should translate subset names (defined below).
# Allowed values: true, false
TranslateSubsets=true

# Translation handles for subsets
AvailableCharsetNames[]
AvailableCharsetNames[standard_lowercase]=lowercase
AvailableCharsetNames[standard_uppercase]=uppercase
AvailableCharsetNames[digits]=digits
AvailableCharsetNames[polish_lowercase]=Polish lowercase
AvailableCharsetNames[polish_uppercase]=Polish uppercase
AvailableCharsetNames[german_lowercase]=German lowercase
AvailableCharsetNames[german_uppercase]=German uppercase
AvailableCharsetNames[special]=space and hyphen


# Default charset definition, it will be used if it is impossible to find 
# a language-based match.
# Note: All the subsets will be put together and the resulting string
# has to be a valid regular expression (range). It's best to put special
# subsets at the end 
[CharsetDefault]
CharsetDefinition[]=standard_lowercase
CharsetDefinition[]=standard_uppercase
CharsetDefinition[]=digits
CharsetDefinition[]=special


# Contant language based charset definitions. For each language it is possible 
# to define a different allowed charset combination.

[Charset_pol-PL]
CharsetDefinition[]
CharsetDefinition[]=standard_lowercase
CharsetDefinition[]=standard_uppercase
CharsetDefinition[]=polish_lowercase
CharsetDefinition[]=polish_uppercase
CharsetDefinition[]=digits
CharsetDefinition[]=special

[Charset_ger-DE]
CharsetDefinition[]
CharsetDefinition[]=standard_lowercase
CharsetDefinition[]=standard_uppercase
CharsetDefinition[]=german_lowercase
CharsetDefinition[]=german_uppercase
CharsetDefinition[]=digits
CharsetDefinition[]=special

*/ ?>
