eZ Public Keywords extension for eZ Publish 4.0
version 0.3 beta

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ryba.eu



About
-----

eZ Public Keywords datatype extends built-in eZ Publish ezkeyword type
by providing it with some additional validation rules.

As useful as ezkeyword datatype is, it has a very limited validation. This
makes it quite risky to let anonymous, or even untrained users fill object
attributes based on this datatype.

eZ Public Keywords datatype provides a set of validation techniques that can
prevent submitting of unwanted or potentially dangerous data. It makes it
possible to define:
- minimum number of comma-separated keywords/phrases (per class attribute)
- maximum number of comma-separated keywords/phrases (per class attribute)
- minimum length of one keyword/phrase (per class attribute)
- maximum length of one keyword/phrase (per class attribute)
- all of the above globally (as a security parameter)
- valid charset (per content object attribute language)
- valid default charset

Additionally, it provides detailed validation messaging for user's easier
problem identification.

I believe this might be a step towards making keywords datatype publicly
available. Hope you find it useful, too.

Internally, this datatype extends original ezkeyword datatype (class), which 
means that it uses exactly the same database keywords engine. All of the 
phrases collected by the attributes of this type should be available for 
standard fetching functions and other standard operations.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------

- eZ Publish 4.0.0+
- eZ Publish Components: Base, File
- eZ Publish Keyword Datatype



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezpublickeywords/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezpublickeywords

3. Regenerate autoload arrays.

4. Clear cache.



Changelog
---------

# PROBLEMS
- Fix bug: No default values are preset when adding an attribute in a class.


# v0.3 beta, local, 2008.01.13
+ Minor fixes.

# v0.2 beta, local, 2008.01.04
+ Fully functional.

# v0.1 alpha, local, 2008.01.03
+ First fully working version.

# v0.0 alpha, local, 2008.01.03
+ Start.


/+/ complete
/-/ plan or in progress
