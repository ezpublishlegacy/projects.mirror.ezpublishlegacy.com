<?php
/**
 * Class used to communicate with jsonrpc servers
 * @deprecated use a plain ggWebservicesClient instead of this
 *
 * @author G. Giunta
 * @version $Id: ggjsonrpcclient.php 210 2010-12-05 20:42:42Z gg $
 * @copyright (C) G. Giunta 2009-2010
 */

class ggJSONRPCClient extends ggWebservicesClient
{
    function __construct( $server, $path = '/', $port = 80, $protocol=null )
    {
        $this->ResponseClass = 'ggJSONRPCResponse';
        $this->UserAgent = 'gg eZ JSONRPC client';
        $this->ContentType = 'application/json';
        parent::__construct( $server, $path, $port, $protocol );
    }
}

?>