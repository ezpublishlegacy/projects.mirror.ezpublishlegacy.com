<?php
//
// Created on: <3-Mar-2009>
//
// SOFTWARE NAME: IB Stock
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
include_once( 'kernel/classes/ezorderitem.php' );
include_once( 'kernel/classes/ezorder.php' );

define( 'EZ_WORKFLOW_TYPE_UPDATESTOCK_ID', 'updatestock' );

class UpdateStockType extends eZWorkflowEventType {
    function UpdateStockType() {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_UPDATESTOCK_ID, 'Update stock count' );
    }
    
    function execute( $process, $event ) {
    	$settings                      = eZINI::instance( 'stock.ini', 'extension/stock/settings' );
    	$stockCountAttributeIdentifier = $settings->variable( 'General', 'StockCountAttributeIdentifier' );
    	
        $parameters = $process->attribute( 'parameter_list' );
        $order      = eZOrder::fetch( $parameters['order_id'] );

        if ( !is_object( $order ) ) {
            eZDebug::writeWarning( 'Can\'t proceed without a Order ID.', 'Update stock' );
            return eZWorkflowType::STATUS_NONE;
        }

		$productCollection = $order->productCollection();
		$orderedItems      = $productCollection->itemList();
		foreach ( $orderedItems as $item ) {
			$contentObject           = $item->contentObject(); 
			$contentObjectAttributes = $contentObject->dataMap();
						
			if( isset( $contentObjectAttributes[ $stockCountAttributeIdentifier ] ) ) {
				$stockAttribute = $contentObjectAttributes[ $stockCountAttributeIdentifier ];
				if( $stockAttribute->DataTypeString == 'ezinteger' ) {
					$stockAttribute->fromString( $stockAttribute->content() - $item->ItemCount );
					$stockAttribute->store();					
				}
			}
		}
        return eZWorkflowType::STATUS_ACCEPTED;
    }    
}

eZWorkflowEventType::registerEventType( EZ_WORKFLOW_TYPE_UPDATESTOCK_ID, 'UpdateStockType' );
?>