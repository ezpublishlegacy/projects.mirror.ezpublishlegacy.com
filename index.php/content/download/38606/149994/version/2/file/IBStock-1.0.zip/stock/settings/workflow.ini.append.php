<?php
[EventSettings]
ExtensionDirectories[]=stock
AvailableEventTypes[]=event_updatestock
?>