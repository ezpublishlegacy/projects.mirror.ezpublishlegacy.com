<?php /* #?ini charset="utf-8"?

[Leftmenu_setup]
Links[rss]=rss2/list
PolicyList_rss[]=rss2/edit

*/ ?>
