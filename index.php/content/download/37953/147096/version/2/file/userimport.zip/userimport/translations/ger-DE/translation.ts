<!DOCTYPE TS><TS>
<context>
    <name>userimport</name>
    <message>
        <source>User Import</source>
        <translation>Benutzer Import Seite</translation>
    </message>
    <message>
        <source>Tab seperated</source>
        <translation>Die einzelnen Felder werden durch Tabulator getrennt!</translation>
    </message>
    <message>
        <source>Test it</source>
        <translation>Testen</translation>
    </message>
    <message>
        <source>Import it</source>
        <translation>Ja, importieren</translation>
    </message>
    <message>
        <source>Import status</source>
        <translation>Import Status</translation>
    </message>    
    <message>
        <source>Already existing</source>
        <translation>Bereits importiert</translation>
    </message>    
</context>
</TS>
