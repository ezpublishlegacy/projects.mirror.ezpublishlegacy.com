<?php

include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'lib/ezlocale/classes/ezdatetime.php' );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
include_once( 'lib/ezutils/classes/ezini.php' );

class eZUserImport extends eZUser
{
    /*!
     Constructor
    */
    
    function eZUserImport()
    {

    }
        
    function &testing( $var_NewImportUser )
    {
    	$arr_NewImportUser = explode ("\n", $var_NewImportUser); 
    	
		$i = 0;
		$temparray = Array();
		foreach ($arr_NewImportUser as $one_NewImportUser) {
			$temparray[$i] = split("\t", $one_NewImportUser );
			$i = $i + 1;
			
		}		
		return $temparray;
    }
    
    function &saving( $var_NewImportUser, $var_ImportGroup )
    {
		// loading field definitions
        $ini =& eZINI::instance();
        $UserImportIni =& eZINI::instance( 'userimport.ini' );
		$def_importUserFields = $UserImportIni->variableArray( 'UserImportSettings', 'ImportUserFields' );
		$def_importUserAttributeFields = $UserImportIni->variableArray( 'UserImportSettings', 'ImportAttributeUserFields' );
		$def_importUserClassID = $UserImportIni->variable( 'UserImportSettings', 'ImportUserClassID' );



    	$arr_NewImportUser = explode ("\n", $var_NewImportUser); 
    	
		$sum_imports = 0;
		$sum_exists = 0;
		//$sum_group_add = 0;
		
		$i = 0;
		foreach ($arr_NewImportUser as $one_NewImportUser) {
			$arr_SingleNewUserLine[$i] = split("\t", $one_NewImportUser );

			$arr_SingleNewUser = Array();
			$j = 0;
			// create associative array
			foreach ($def_importUserFields as $item_field) { 
				$arr_SingleNewUser[$item_field] = $arr_SingleNewUserLine[$i][$j];
				$j = $j + 1;
			}

		// ******************************************************************************
		
			$user_temp_data["login"] = $arr_SingleNewUser["login"];
			$user_temp_data["email"] = $arr_SingleNewUser["email"];
			$user_temp_data["password"] = $arr_SingleNewUser["password"];
			$user_temp_data["first_Name"] = $arr_SingleNewUser["first_Name"];
			$user_temp_data["last_Name"] = $arr_SingleNewUser["last_Name"];
			$user_temp_data["birthday"] = $arr_SingleNewUser["birthday"];
			
			$is_user_valid = false;
			if (($user_temp_data["login"] != "") && ($user_temp_data["email"] != "") && ($user_temp_data["password"] != ""))  $is_user_valid = true;
			

			$defaultUserPlacement = $var_ImportGroup + 0;
			
			$userClassID = $def_importUserClassID;
			$userCreatorID =& eZUser::currentUserID(); // Administrator = 14

			$defaultSectionID = 1;

		// is_user_valid
		if ($is_user_valid) {
		
			

			// check, if object already exist
			$existUserObj =& new eZUser( );
			$existUser =& $existUserObj->fetchByName( $user_temp_data["login"] );
			
			
			// User exist, only add the new Group
			if ($existUser) {
			
				$sum_exists++;

				//--------------------------------------------------------------------------------
					$object =& eZContentObject::fetch( $existUser->ContentObjectID );
					$nodeID = $object->attribute("main_node_id");
					$version =& $object->currentVersion();
					$class =& $object->contentClass();

					$existingNode =& eZContentObjectTreeNode::fetch( $nodeID );

					// VARIABLE defaultUserPlacement
					
					$selectedNodeIDArray = array($defaultUserPlacement);
					$assignedNodes =& $version->nodeAssignments();
					$assignedIDArray = array();
					$setMainNode = false;
					$hasMainNode = false;
					foreach ( $assignedNodes as $assignedNode )
					{
						$assignedNodeID = $assignedNode->attribute( 'parent_node' );
						if ( $assignedNode->attribute( 'is_main' ) )
							$hasMainNode = true;
						$assignedIDArray[] = $assignedNodeID;
					}
					if ( !$hasMainNode )
						$setMainNode = true;

					$mainNodeID = $existingNode->attribute( 'main_node_id' );
					$objectName = $object->attribute( 'name' );
					foreach ( $selectedNodeIDArray as $selectedNodeID )
					{
						if ( !in_array( $selectedNodeID, $assignedIDArray ) )
						{
							$isPermitted = true;
							$parentNode =& eZContentObjectTreeNode::fetch( $selectedNodeID );
							$parentNodeObject =& $parentNode->attribute( 'object' );

							$canCreate = $parentNode->checkAccess( 'create', $class->attribute( 'id' ), $parentNodeObject->attribute( 'contentclass_id' ) ) == 1;
							if ( $isPermitted )
							{
								$isMain = 0;
								if ( $setMainNode )
									$isMain = 1;
								$setMainNode = false;
								$nodeAssignment =& $version->assignToNode( $selectedNodeID, $isMain );
								$newNode =& $parentNode->addChild( $object->attribute( 'id' ), 0, true );
								$newNode->setAttribute( 'sort_field', $nodeAssignment->attribute( 'sort_field' ) );
								$newNode->setAttribute( 'sort_order', $nodeAssignment->attribute( 'sort_order' ) );
								$newNode->setAttribute( 'contentobject_version', $version->attribute( 'version' ) );
								$newNode->setAttribute( 'contentobject_is_published', 1 );
								$newNode->setAttribute( 'main_node_id', $mainNodeID );
								$newNode->setName( $objectName );
								$newNode->updateSubTreePath();
								$newNode->store();
								eZContentObjectTreeNode::updateNodeVisibility( $newNode, $parentNode, false );
							}
						}
					}
					include_once( 'kernel/content/ezcontentoperationcollection.php' );
					eZContentOperationCollection::clearObjectViewCache( $objectID, true );
					eZContentObject::expireTemplateBlockCacheIfNeeded();
				//------------------------------------------------------------------

			} 
			// User does not exist, will be created
			else {	
			
				$sum_imports++;

				$class =& eZContentClass::fetch( $userClassID );
				$contentObject =& $class->instantiate( $userCreatorID, $defaultSectionID );

				$remoteID = "IMPORT_" . $user_temp_data["login"];
				$contentObject->setAttribute( 'remote_id', $remoteID );
				$contentObject->store();


				$contentObjectID = $contentObject->attribute( 'id' );
				$userID = $contentObjectID;


				$nodeAssignment =& eZNodeAssignment::create( array(
														 'contentobject_id' => $contentObjectID,
														 'contentobject_version' => 1,
														 'parent_node' => $defaultUserPlacement,
														 'is_main' => 1
														 )
													 );
				$nodeAssignment->setAttribute( 'parent_remote_id', "VHB_" . $defaultUserPlacement );
				$nodeAssignment->store();        

				$version =& $contentObject->version( 1 );
				$version->setAttribute( 'modified', time() );
				$version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
				$version->store();

				$contentObjectID = $contentObject->attribute( 'id' );
				$contentObjectAttributes =& $version->contentObjectAttributes();

				foreach ($contentObjectAttributes as $attribute)
				{		
					$attribute->setAttribute("data_text",$arr_SingleNewUser[$attribute->attribute("contentclass_attribute_identifier")]);
					$attribute->store();

				}

				$user =& new eZUser( $userID );

				$user->setAttribute('login', $user_temp_data["login"] );
				$user->setAttribute('email', $user_temp_data["email"] );

				$hashType = eZUser::hashType() . "";
				$newHash = $user->createHash( $user_temp_data["login"], $user_temp_data["password"], eZUser::site(), $hashType );

				$user->setAttribute( "password_hash_type", $hashType );
				$user->setAttribute( "password_hash", $newHash );

				$user->store();

				include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
				$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID, 'version' => 1 ) );
			}

		// ******************************************************************************

			$i = $i + 1;
		}  // is_user_valid
		}

		
		$sum = Array();
		$sum["sum_exists"] = $sum_exists;
		$sum["sum_imports"] = $sum_imports;
		
		return $sum;
    }
}

?>