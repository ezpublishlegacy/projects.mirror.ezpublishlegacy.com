<?php

include_once( 'kernel/common/template.php' );
include_once( 'extension/userimport/modules/userimport/classes/ezuserimport.php' );
include_once( 'lib/ezutils/classes/ezini.php' );


$http =& eZHTTPTool::instance();

$Module =& $Params['Module'];

$tpl =& templateInit();

// loading field definitions
$ini =& eZINI::instance();
$UserImportIni =& eZINI::instance( 'userimport.ini' );
$def_importUserFields = $UserImportIni->variableArray( 'UserImportSettings', 'ImportUserFields' );
$def_standardImportGroup = $UserImportIni->variableArray( 'UserImportSettings', 'FallBackGroup' );


$creator_user =& new eZUser( eZUser::currentUserID() );
$groups =& $creator_user->groups();

// filtering standard groups
// condition: the importing user is member of the group, where the users will be imported.
// "12" = Administrator users 	"4" = Users

foreach ($groups as $group_id)
{		
	if ($group_id != 12 && $group_id != 4)  $def_standardImportGroup = $group_id;
}

		//var_dump($def_standardImportGroup); 
		$groupNode =& eZContentObject::fetch( $def_standardImportGroup );
		//var_dump($groupNode);
		$nodeID = $groupNode->attribute( 'main_node_id' );
		//var_dump($nodeID);
		
		$def_standardImportGroup = $nodeID;

$tpl->setVariable( 'txt_importUserFields', $def_importUserFields );

$mytext = "Keine Daten �bermittelt";

if ( $http->hasPostVariable( 'UserImportTestenButton' ) )
{
    $newUserImport = new eZUserImport();
    $mytext = $http->postVariable('NewImportUser');
    $temparray = $newUserImport->testing($http->postVariable('NewImportUser'));
    
	$tpl->setVariable( 'txt_import_status_exist', 0 );
	$tpl->setVariable( 'txt_import_status_new', 0 );
	
    $tpl->setVariable( 'temparray', $temparray );
    
	//$mytext = $http->postVariable('NewImportUser');

    
} elseif ( $http->hasPostVariable( 'UserImportSaveButton' ) )
{

    $newUserImport = new eZUserImport();
    $arr_import_status = $newUserImport->saving($http->postVariable('NewImportUser'), $def_standardImportGroup);
    
    $txt_import_status_exist = $arr_import_status["sum_exists"];
    $txt_import_status_new = $arr_import_status["sum_imports"];
    
	$tpl->setVariable( 'txt_import_status_exist', $txt_import_status_exist );
	$tpl->setVariable( 'txt_import_status_new', $txt_import_status_new );
    $tpl->setVariable( 'temparray', $temparray );
    
    $mytext = $http->postVariable('NewImportUser');
} else {
	$tpl->setVariable( 'temparray', $temparray );
}



$tpl->setVariable( 'mytext', $mytext );

$Result = array();

$Result['content'] =& $tpl->fetch( 'design:userimport/list.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "UserImport") );
?>