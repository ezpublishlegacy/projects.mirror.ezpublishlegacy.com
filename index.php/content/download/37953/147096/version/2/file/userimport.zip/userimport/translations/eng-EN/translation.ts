<!DOCTYPE TS><TS>
<context>
    <name>userimport</name>
    <message>
        <source>User Import</source>
        <translation>User Import Page</translation>
    </message>
    <message>
        <source>Tab seperated</source>
        <translation>Fields have to be Tab separated</translation>
    </message>
    <message>
        <source>Test it</source>
        <translation>Test it</translation>
    </message>
    <message>
        <source>Import it</source>
        <translation>Yes, import it</translation>
    </message>
    <message>
        <source>Import status</source>
        <translation>Import Status</translation>
    </message>    
    <message>
        <source>Already existing</source>
        <translation>Already existing</translation>
    </message>    
</context>
</TS>
