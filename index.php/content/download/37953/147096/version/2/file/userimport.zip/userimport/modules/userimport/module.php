<?php
$Module = array( "name" => "UserImport" );

$ViewList = array();
$ViewList["list"] = array( 
	'script' => 'list.php'
	
	);
?>