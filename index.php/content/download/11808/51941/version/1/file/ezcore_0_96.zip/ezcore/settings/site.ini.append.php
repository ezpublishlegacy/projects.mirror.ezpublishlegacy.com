<?php /* #?ini charset="utf-8"?


[TemplateSettings]
ExtensionAutoloadPath[]=ezcore


#[RoleSettings]


[SSLZoneSettings] 
ModuleViewAccessMode[ezcore/*]=keep




*/ ?>