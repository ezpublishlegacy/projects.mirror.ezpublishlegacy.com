<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezcore
ExtensionAjaxRepositories[]=ezcore
ModuleList[]=ezcore

*/ ?>