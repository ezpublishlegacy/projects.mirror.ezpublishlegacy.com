<?php /* #?ini charset="utf-8"?

#This block follows the format RSSExport_<RSSExport ID>
[RSSExport_1]
#The template paths are relative to design:opsa_rss/attributes
Attributes[]=

*/ ?>