<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=modelviewer

[ExtensionSettings]
ActiveExtensions[]=modelviewer

[RegionalSettings]
TranslationExtensions[]=modelviewer

*/?>