<?php /* #?ini charset="utf-8"?


[full_obj]
Source=node/view/full.tpl
MatchFile=full/obj.tpl
Subdir=templates
Match[class_identifier]=obj

[line_obj]
Source=node/view/line.tpl
MatchFile=line/obj.tpl
Subdir=templates
Match[class_identifier]=obj

[embed_obj]
Source=content/view/embed.tpl
MatchFile=embed/obj.tpl
Subdir=templates
Match[class_identifier]=obj


*/ ?>