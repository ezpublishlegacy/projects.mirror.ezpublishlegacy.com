<?php /* #?ini charset="utf8"?

[StylesheetSettings]
CSSFileList[]=skins/aqua/theme.css
# CSSFileList[]=calendar-blue.css
# CSSFileList[]=calendar-blue2.css
# CSSFileList[]=calendar-brown.css
# CSSFileList[]=calendar-green.css
# CSSFileList[]=calendar-system.css
# CSSFileList[]=calendar-tas.css
# CSSFileList[]=calendar-win2k-1.css
# CSSFileList[]=calendar-win2k-2.css
# CSSFileList[]=calendar-win2k-2-cold-1.css
# CSSFileList[]=calendar-win2k-2-cold-2.css
CSSFileList[]=classesfix.css

[JavaScriptSettings]
JavaScriptList[]=calendar.js
JavaScriptList[]=lang/calendar-en.js
JavaScriptList[]=calendar-setup.js

[ExtensionSettings]
DesignExtensions[]=ezdatetimeselect
*/ ?>