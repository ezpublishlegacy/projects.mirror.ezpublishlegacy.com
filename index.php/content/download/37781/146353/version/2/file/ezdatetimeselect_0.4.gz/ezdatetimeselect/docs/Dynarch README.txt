The DHTML Calendar
-------------------

  Author: Mihai Bazon, <mihai_bazon@yahoo.com>
          http://dynarch.com/mishoo/

  This program is free software published under the
  terms of the GNU Lesser General Public License.

  For the entire license text please refer to
  http://www.gnu.org/licenses/lgpl.html

Contents
---------

  calendar.js     -- the main program file
  lang/*.js       -- internalization files
  *.css           -- color themes
  cal.html        -- example usage file
  doc/            -- documentation, in PDF and HTML
  simple-1.html   -- quick setup examples [popup calendars]
  simple-2.html   -- quick setup example for flat calendar
  calendar.php    -- PHP wrapper
  test.php        -- test file for the PHP wrapper

Homepage
---------

  For details and latest versions please refer to calendar
  homepage, located on my website:

    http://dynarch.com/mishoo/calendar.epl

