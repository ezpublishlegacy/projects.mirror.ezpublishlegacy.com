ezDateTimeSelect Extension
--------------------------

Introduction:

The ezDateTimeSelect extension is created using the Dynarch DHTML Calendar.  It is free software published under the terms of the GNU Lesser General Public License.

  For the entire license text please refer to
  http://www.gnu.org/licenses/lgpl.html


Installation instructions:

- Unzip the downloaded extension to the 'extension' folder in your ezPublish root directory

- Enable the extension in using the Admin interface (setup tab, extensions link)

Options:

The Dynarch DHTML calendar comes with a number of different css files to change the look of the calendar.  You can change which css file is used by editing the design.ini.append.php file in the extension's settings directory. For example:

Before:

[StylesheetSettings]
# CSSFileList[]=skins/aqua/theme.css
CSSFileList[]=calendar-brown.css

After:

[StylesheetSettings]
CSSFileList[]=skins/aqua/theme.css
# CSSFileList[]=calendar-brown.css

Also, if you look at the Dynarch DHTML Calendar reference.pdf document you'll see that there are more fancy things that you can do with the calendar.