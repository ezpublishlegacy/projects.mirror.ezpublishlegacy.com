<!DOCTYPE TS><TS>
<context>
    <name>extension/states_check</name>
    <message>
        <source>%editable editable(s)</source>
        <translation type="unfinished">%editable編集可能</translation>
    </message>
    <message>
        <source>%uneditable uneditable(s)</source>
        <translation type="unfinished">%uneditable編集不可能</translation>
    </message>
    <message>
        <source>States check</source>
        <translation type="unfinished">ステートチェック</translation>
    </message>
    <message>
        <source>States group</source>
        <translation type="unfinished">ステートグループ</translation>
    </message>
    <message>
        <source>There are no objects in a states workflow.</source>
        <translation type="unfinished">ステートワークフローに入ってるオブジェクトはありません。</translation>
    </message>
</context>
</TS>
