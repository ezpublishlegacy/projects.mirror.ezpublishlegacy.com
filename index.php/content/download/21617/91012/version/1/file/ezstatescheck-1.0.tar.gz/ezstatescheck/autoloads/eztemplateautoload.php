<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/states_check/autoloads/check_states_objects.php',
                                    'class' => 'CheckStatesObjectsOperator',
                                    'operator_names' => array( 'check_states_objects' ) );

?>
