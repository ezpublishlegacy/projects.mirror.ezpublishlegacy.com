<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezstatescheck

ModuleList[]=states_check

*/ ?>
