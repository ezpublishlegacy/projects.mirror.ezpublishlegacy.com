<?php
/**
 * File containing the eZ Publish module definition.
 *
 * @copyright Copyright (C) 2005-2009 eZ Systems AS. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 0.9
 * @package states_check
 */

$Module = array( 'name' => 'States Check', 'variable_params' => true );

$ViewList = array();
$ViewList['view'] = array( 'script' => 'view.php',
                           'single_post_actions' => array( 'ViewButton' => 'View' ),
                           'params' => array( 'ParentNodeID' ) );

?>
