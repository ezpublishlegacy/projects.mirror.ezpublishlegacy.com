<!DOCTYPE TS><TS>
<context>
    <name>extension/states_check</name>
    <message>
        <source>States check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>States group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no objects in a states workflow.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
