<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezstatescheck

[RegionalSettings]
TranslationExtensions[]=ezstatescheck

*/ ?>

