<?php /*

[ExtensionSettings]
DesignExtensions[]=ezstatescheck

[StylesheetSettings]
CSSFileList[]=states_check.css
*/ ?>
