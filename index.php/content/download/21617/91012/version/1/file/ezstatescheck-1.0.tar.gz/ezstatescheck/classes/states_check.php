<?php
/**
 * File containing the eZ Publish module definition.
 *
 * @copyright Copyright (C) 2005-2009 eZ Systems AS. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 0.9
 * @package states_check
 */

class StatesCheck
{
    private $group_structure;
    private $in_states_objects_data;
        
    function __construct()
    {
       $this->group_structure = array();
       $this->in_states_objects_data = array();
       $this->load();
    }

    public function load()
    {
        $ignored_ids = array();
        $group_structure = array();
        $groups = eZContentObjectStateGroup::fetchByOffset(99,0);
        $current_user = eZUser::currentUser();
        $editables_states_list = array();
        $is_almighty = false;
        $in_states_objects_data = array();
        $in_states_objects_data["editable"] = array();
        $in_states_objects_data["uneditable"] = array();

        // fetch wich states the current user can edit
        $is_almighty = $current_user->AccessArray["state"]["administrate"]["*"] === "*";
        foreach( $current_user->AccessArray["state"]["assign"] as $policy)
        {
            foreach( $policy as $key => $editables_states )
            {
                if( $key === 'NewState' ){ continue; }
                foreach( $editables_states as $editable_state )
                {
                    $editables_states_list[] = $editable_state;
                }
            }
        }

        // create the base structure and prepare the SQL contition terms (ignored_ids)
        foreach( $groups as $group )
        {
            $group_locale = $group->currentTranslation()->Name;
            $group_structure[$group_locale] = array();
            $group_structure[$group_locale]["states"] = array();
            $group_structure[$group_locale]["states_id"] = array();
            $group_structure[$group_locale]["objects"] = array();
            $states = eZContentObjectState::fetchByGroup($group->ID);
            $states_count = count($states);
            foreach( $states as $i => $state ){
                $locale_state = $state->currentTranslation();
                $group_structure[$group_locale]["states"][] = array( "name" => $locale_state->Name, "id" => $locale_state->ContentObjectStateID  );
                $group_structure[$group_locale]["states_id"][] = $locale_state->ContentObjectStateID;
                if( $i===0 || $i===($states_count-1) )
                {
                    $ignored_ids[] = $state->ID;
                }
            }
        }
        
        // get the objects that are in states groups
        $db = eZDB::instance();
        $db->begin();
        $in_states_objects = $db->arrayQuery( "SELECT * FROM ezcobj_state_link WHERE contentobject_state_id<>'" . implode( "' AND contentobject_state_id<>'", $ignored_ids ) ."'");
        
        // put the objects in the $group_structure
        foreach($in_states_objects as $object){
            foreach($group_structure as $index => $group){
                if( in_array( $object["contentobject_state_id"], $group["states_id"] ))
                {
                    $object["can_change_status"] = in_array( $object["contentobject_state_id"], $editables_states_list ) || $is_almighty;
                    $group_structure[$index]["objects"][] = $object;
                }
            }
        }
        
        // remove the unused or uneditable groups of $group_structure
        foreach($group_structure as $index => $group)
        {
            $can_edit_group = array_intersect($group["states_id"], $editables_states_list);
            if( ( empty( $group["objects"] ) or ( empty($can_edit_group) ) and !$is_almighty ) )
            {
                unset( $group_structure[$index]);
            }
        }

        foreach($group_structure as $index => $group)
        {
            foreach( $group["objects"] as $object )
            {
                if( $object["can_change_status"] )
                {
                    $in_states_objects_data["editable"][] = $object;
                }
                else
                {
                    $in_states_objects_data["uneditable"][] = $object;
                }
            }
        }
        $this->group_structure = $group_structure;
        $this->in_states_objects_data = $in_states_objects_data;
    }
    
    function get_group_structure()
    {
        return $this->group_structure;
    } 

    function get_in_states_objects_data()
    {
        return $this->in_states_objects_data;
    } 
}

?>
