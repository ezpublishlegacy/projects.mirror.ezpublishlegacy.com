<?php

class CheckStatesObjectsOperator
{
    var $operators;
    /*!
      Constructor, does nothing by default.
    */
    function __construct()
    {
        $this->operators = array( 'check_states_objects' );
    }

    /*!
     \return an array with the template operator name.
    */
    function &operatorList()
    {
        return $this->operators;
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return false;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return false;
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {
        switch ( $operatorName )
        {
            case 'check_states_objects':
            {
                $state_check = new StatesCheck();
                $in_states_objects_data = $state_check->get_in_states_objects_data();
                $operatorValue = $in_states_objects_data;
            } break;

        }
    }
}

?>
