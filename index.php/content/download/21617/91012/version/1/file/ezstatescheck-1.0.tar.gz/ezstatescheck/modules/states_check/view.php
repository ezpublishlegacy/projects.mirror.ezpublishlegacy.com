<?php
/**
 * File containing the eZ Publish upload view implementation.
 *
 * @copyright Copyright (C) 2005-2009 eZ Systems AS. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.1
 * @package states_check
 */

include_once( 'kernel/common/template.php' );

$http = eZHTTPTool::instance();
$tpl = templateInit();
$module = $Params['Module'];
$parentNodeID = $Params['ParentNodeID'];
$state_check = new StatesCheck();
$group_structure = $state_check->get_group_structure();

// Pass variables to view.tpl template
$tpl->setVariable( 'group_structure', $group_structure );
$tpl->setVariable( 'in_states_objects', $in_states_objects );
$tpl->setVariable( 'file_types', $availableFileTypesStr );
$tpl->setVariable( 'session_id', session_id() );
$tpl->setVariable( 'session_name', session_name() );
$tpl->setVariable( 'user_session_hash', eZSession::getUserSessionHash() );
$tpl->setVariable( 'parent_node', $parentNode );

// Process template and set path data
$Result = array();
$Result['content'] = $tpl->fetch( 'design:states_check/view.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'extension/states_check', 'States check' ) ) );

?>
