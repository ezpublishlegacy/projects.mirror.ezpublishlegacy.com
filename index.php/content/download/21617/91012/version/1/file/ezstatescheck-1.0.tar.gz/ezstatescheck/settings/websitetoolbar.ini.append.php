<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=states_check

IncludeInView[states_check]=full

*/ ?>
