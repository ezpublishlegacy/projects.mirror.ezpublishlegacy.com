<?php /* #?ini charset="utf-8"?

[DesignSettings]
SiteDesign=ezteamroom
AdditionalSiteDesignList[]
AdditionalSiteDesignList[]=base
AdditionalSiteDesignList[]=ezpersonalfrontpage

[ContentSettings]
CachedViewModes=full;sitemap;pdf;module_widget;module_widget_latest;manage;teamrooms
CachedViewPreferences[]
CachedViewPreferences[full]=teamroom_files_list_limit=10;teamroom_folder_list_limit=10;teamroom_milestone_list_limit=10;teamroom_list_limit=10;teamroom_forum_list_limit=10;personalfrontpage_widgetlist_1441=0;personalfrontpage_displaydescription=1;teamroom_blog_list_limit=10;teamroom_calendar_limit=10;teamroom_documents_list_limit=10;teamroom_tasklist_list_limit=10;teamroom_list_limit;teamroom_member_list_limit=10

[SiteAccessSettings]
PathPrefix=Teamrooms

*/ ?>
