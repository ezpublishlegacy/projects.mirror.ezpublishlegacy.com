<?php /* #?ini charset="utf-8"?

[StylesheetSettings]
SiteCSS=extension/ezteamroom/design/standard/stylesheets/site-colors.css
ClassesCSS=extension/ezteamroom/design/standard/stylesheets/classes-colors.css

[JavaScriptSettings]
JavaScriptList[]=insertmedia.js
JavaScriptList[]=json2.js
JavaScriptList[]=personal_frontpage_helper.js
JavaScriptList[]=drag_drop.js
JavaScriptList[]=boxes.js
JavaScriptList[]=teamroom.js
#JavaScriptList[]=lightbox.js
JavaScriptList[]=ezdatepickerex.js
JavaScriptList[]=yui/build/yahoo-dom-event/yahoo-dom-event.js
JavaScriptList[]=yui/build/calendar/calendar.js

[StylesheetSettings]
#CSSFileList[]=lightbox.css

*/ ?>
