<?php /* #?ini charset="utf-8"?

[BrowseSettings]
AliasList[banners]=59

[AddRelatedBannerImageToDataType]
StartNode=banners
SelectionType=single
ReturnType=ObjectID

[AddBookmark]
StartNode=2
SelectionType=multiple
ReturnType=NodeID

# Action for finding node id for link
[SelectLinkNodeID]
StartNode=2
SelectionType=single
ReturnType=NodeID

# Action for finding object id for link
[SelectLinkObjectID]
StartNode=2
SelectionType=single
ReturnType=ObjectID

# Action for finding related objects
[AddRelatedObjectToOE]
StartNode=2
SelectionType=multiple
ReturnType=ObjectID

*/ ?>
