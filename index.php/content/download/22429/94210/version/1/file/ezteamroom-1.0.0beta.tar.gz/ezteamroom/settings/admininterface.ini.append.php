<?php /* #?ini charset="iso-8859-1"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=popupmenu/teamroomcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=popupmenu/teamroomsubitemscontextmenu.tpl

*/ ?>