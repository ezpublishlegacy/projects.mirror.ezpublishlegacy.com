<?php /* #?ini charset="utf-8"?

[Toolbar_top]
Tool[]
Tool[]=login
Tool[]=searchbox

[Toolbar_right]
Tool[]
Tool[]=node_list

[Toolbar_bottom]
Tool[]

[Tool_right_node_list_1]
parent_node=2
title=Latest
show_subtree=
limit=5
*/ ?>