<?php /* #?ini charset="iso-8859-1"?

[CreateSettings]
UploadHandlerMap[]
MimeClassMap[]
MimeClassMap[image]=image
MimeClassMap[video/quicktime]=quicktime
MimeClassMap[video/x-msvideo]=windows_media
MimeClassMap[video/x-ms-wmv]=windows_media
MimeClassMap[video/vnd.rn-realvideo]=real_video
MimeClassMap[application/vnd.rn-realmedia]=real_video
# Not supported yet
#MimeClassMap[application/x-shockwave-flash]=flash
MimeClassMap[application/vnd.oasis.opendocument.text]=teamroom_file
MimeClassMap[application/msword]=teamroom_file
MimeClassMap[application/rtf]=teamroom_file
DefaultClass=teamroom_file

[teamroom_file_ClassSettings]
FileAttribute=file
NameAttribute=name
NamePattern=<original_filename_base>

*/ ?>
