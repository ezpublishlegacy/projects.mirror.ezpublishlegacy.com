<?php /* #?ini charset="utf-8"?

[rotated]
Family=bluehigb
PointSize=10
XAdjustment=21
YAdjustment=145
WidthAdjustment=12
HeightAdjustment=30
BackgroundColor=#eeeee5
#AbsoluteWidth=200
AbsoluteHeight=150
TextColor=#000000
Angle=90


*/ ?>
