<?php /*

# Does not work!?

[MultiUploadSettings]
AvailableClasses[]=file_folder
AvailableClasses[]=teamroom_file_folder

[FileTypeSettings_file_folder]
FileType[]
FileType[]=*.*

[FileTypeSettings_teamroom_file_folder]
FileType[]
FileType[]=*.*

*/ ?>
