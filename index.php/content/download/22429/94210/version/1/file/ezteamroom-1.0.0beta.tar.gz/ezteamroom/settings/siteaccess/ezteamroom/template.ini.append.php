<?php /* #?ini charset="utf-8"?

[CharsetSettings]
DefaultTemplateCharset=utf-8
*/ ?>