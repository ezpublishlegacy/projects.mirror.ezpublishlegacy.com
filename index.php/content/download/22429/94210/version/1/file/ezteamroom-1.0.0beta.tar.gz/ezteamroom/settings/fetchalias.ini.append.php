<?php /*

[teamroom_comments]
Module=content
FunctionName=list
Constant[sort_by]=published;0
Parameter[parent_node_id]=parent_node_id
Constant[class_filter_type]=include
Constant[class_filter_array]=teamroom_comment

*/ ?>
