URL ALIAS TRANSLITERATION
by gl@ez.no

Transliterates "special characters" in URL's according to the locale setting.
Based on eZ publish 3.3-4. Will be ported to 3.5 at least, and maybe the second
release of 3.4.



INSTALLATION

Replace
kernel/classes/ezurlalias.php
with the file supplied in this package.

Add this to your site.ini(.append)

[URLTranslator]
# Transliterate according to locale settings
LocaleTransliteration=enabled


Add transliteration settings like this to your locale file:
(share/locale/*.ini)

[URLTransliteration]
TransliterateString[�]=ae
TransliterateString[�]=oe
TransliterateString[�]=aa
TransliterateString[�]=AE
TransliterateString[�]=OE
TransliterateString[�]=AA

This example is for nor-NO. It will replace � with ae, � with oe, etc.


Run
php -C update/common/scripts/updateniceurls.php
from your eZ publish directory.



NOTES

This is not very fast. It may slow down heavily loaded sites a bit.
(The modified code is run every time an object is published.)

If you are not using eZ publish 3.3-4, you should merge the changes in kernel/classes/ezurlalias.php
into your own version. The only changes are:
- Added the function convertLocaleChars()
- Added 6 lines to the beginning of the function convertToAlias()
