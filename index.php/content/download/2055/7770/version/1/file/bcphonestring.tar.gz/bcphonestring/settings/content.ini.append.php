<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=bcphonestring
AvailableDataTypes[]=bcphonestring

*/ ?>