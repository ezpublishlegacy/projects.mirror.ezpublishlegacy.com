<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=bccleanuprss

[CronjobPart-cleanuprss]
Scripts[]=cleanuprss.php

# typo friendly
[CronjobPart-rsscleanup]
Scripts[]=cleanuprss.php

*/ ?>