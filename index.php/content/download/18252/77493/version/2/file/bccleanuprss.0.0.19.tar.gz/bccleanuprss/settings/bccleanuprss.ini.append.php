<?php /* #?ini charset="utf-8"?

[CleanupRSSSettings]
# Class IDs of the import items
RSSClasses[]
RSSClasses[]=16
RSSClasses[]=1

# How many RSS import items to leave on the system per import group
RSSLimit=100

# Cleanup RSS Log File
RSSCleanupLogFile=rsscleanup.log

# Administrator Group User With Root Privilages
RSSCleanupUser=admin

*/ ?>