<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ngsuggest

[JavaScriptSettings]
JavaScriptList[]=jquery.jsonSuggest-dev.js
JavaScriptList[]=json2.js
JavaScriptList[]=ngSuggest.js

[StylesheetSettings]
CSSFileList[]=ngsuggest.css
*/ ?>
