<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ngsuggest
ModuleList[]=ngsuggest
*/ ?>
