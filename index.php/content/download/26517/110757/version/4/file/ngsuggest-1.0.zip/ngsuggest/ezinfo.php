<?php

class ngsuggestInfo
{
    static function info()
    {
        return array( 'Name'      => '<a href="http://projects.ez.no/ngsuggest">Netgen Suggest</a> extension',
                      'Version'   => '1.0',
                      'Copyright' => 'Copyright (C) 2011 Netgen d.o.o. Croatia',
                      'License'   => 'GNU General Public License v2.0',
                    );
    }
}

?>
