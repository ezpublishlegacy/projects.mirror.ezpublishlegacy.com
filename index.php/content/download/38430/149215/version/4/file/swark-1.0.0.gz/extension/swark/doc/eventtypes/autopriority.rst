autopriority
------------
Automatically sets the priority of new nodes to the maximum of siblings
prirorities incremented by value of [AutoPriority]/PriorityIncrement set in
swark.ini (default 10).
