<?php /* #?ini charset="iso-8859-1"?

[AutoPriority]
PriorityIncrement=10

*/ ?>
