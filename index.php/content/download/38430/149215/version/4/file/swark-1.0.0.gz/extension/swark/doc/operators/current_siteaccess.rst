current_siteaccess
------------------

Returns the name of the current siteaccess.

Usage
~~~~~
::

    current_siteaccess()

Parameters
~~~~~~~~~~
None.
