<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezsurvey
AvailableDataTypes[]=ezsurvey

[CustomTagSettings]
AvailableCustomTags[]=survey

[VersionManagement]
# IMPORTANT: set the limits on the survey classes
# to a high value, otherwise survey results coupled to older versions may be deleted
#
VersionHistoryClass[survey]=1000
# VersionHistoryClass[myothersurveyclass]=1000
#

*/ ?>
