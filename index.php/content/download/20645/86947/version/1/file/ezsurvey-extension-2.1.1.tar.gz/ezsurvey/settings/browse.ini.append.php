<?php /* #?ini charset="utf-8"?

# Action for finding related objects
[AddRelatedSurveyNode]
StartNode=media
SelectionType=single
ReturnType=NodeID

[AddRelatedSurveyObject]
StartNode=media
SelectionType=single
ReturnType=ObjectID
Class[]=
Class[]=survey_attribute



*/ ?>
