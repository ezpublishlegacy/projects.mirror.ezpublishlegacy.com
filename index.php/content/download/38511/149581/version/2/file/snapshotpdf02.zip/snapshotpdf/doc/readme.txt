SnapshotPDF Operator
------------------------


0. Intro
--------
This is a version of the Snapshot extesion that grabs a page from a pdf and saves it as a jpg at a specified location.

It uses Ghostscript for the conversion. 


1. Installation
---------------

a) Install Ghostscript if not allready installed.


b) Follow these steps to add the SnapshotPDF datatype to your ezp installation:

   1) Extract the archive into the /extension directory
  
   2) Activate in the admin interface

c) Configure the snapshot.ini.append.php file to specify where you want the images to be saved. Don't forget chmod'ing :-)



2. Features
-----------
- grabs a page of a pdf and save it as a jpg
- returns the path of the jpg



3. Usage
--------
ezsnapshotpdf(path_to_pdf_file,page_to_get_grabbed)

This is an example of usage in a template:

<a href="{ezsnapshotpdf($my_fetched_node.data_map.file.content.filepath,2)}">Read PDF</a>


4. ToDo
-------
- add adjustable quality (which at the time of writing is rather poor)


Developed by Felix Laate (felix@enternett.no).