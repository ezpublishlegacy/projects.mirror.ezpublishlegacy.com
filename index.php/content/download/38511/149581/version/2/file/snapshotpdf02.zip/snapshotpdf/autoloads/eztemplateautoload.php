<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/snapshotpdf/autoloads/snapshotpdf.php',
         'class' => 'MySnapshotPdfOperator',
         'operator_names' => array( 'ezsnapshotpdf' ) );

?>