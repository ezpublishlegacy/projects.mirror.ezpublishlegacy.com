<?php

[TemplateSettings]
ExtensionAutoloadPath[]=snapshotpdf

?>