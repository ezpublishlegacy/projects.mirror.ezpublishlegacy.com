<?php

//
// Definition of SnapshotPdf Class
//
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

include_once("resize.inc.php");

class MySnapshotPdfOperator
{
    /*!
     Constructor
    */
    function MySnapshotPdfOperator()
    {
        $this->Operators = array( 'ezsnapshotpdf');
    }

    /*!
     Returns the operators in this class.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     \return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     The first operator has two parameters, the other has none.
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array(                      
                      'ezsnapshotpdf' => array('file' => array( 'type' => 'string',
                                                                     'required' => true,
                                                                     'default' => '' ),
                                                'page' => array( 'type' => 'string',
                                                                     'required' => true,
                                                                     'default' => '' ),
												'width' => array( 'type' => 'string',
                                                                     'required' => false,
                                                                     'default' => '' ),
                                                'height' => array( 'type' => 'string',
                                                                     'required' => false,
                                                                     'default' => '' )
                                            ) );
    }

    /*!
     Executes the needed operator(s).
     Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                     &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'ezsnapshotpdf':
            {
                $operatorValue = $this->ezsnapshotpdf( $namedParameters['file'], 
                                                        $namedParameters['page'], 
														$namedParameters['width'],
                                                        $namedParameters['height']);
            } break;
        }
    }

    function ezsnapshotpdf( $file, $page, $width, $height  )
    { 
        //return str_replace( $search, $replace, $subject  );
		

		$path_array = split('/', $file);
		$newname = end($path_array) . '-' . $page . '.jpg';
		$newname_resized = end($path_array) . '-' . $page . '-' . $width . 'x' . $height . '.jpg';
		
		$ini =& eZINI::instance('snapshot.ini');    
         
        $save_path_root = $ini->variable( 'General', 'SavePathRoot' );		
		$save_file = $save_path_root[0] . $newname;
		
		// Check if allready exists		
		if (file_exists($save_file)) {
   			return '/' . $save_file;
		} 
		else {
			$command = 'gs -dNOPAUSE -dBATCH -dFirstPage=' . $page . ' -dLastPage=' . $page . ' -sDEVICE=jpeg -sOutputFile=' . $save_file . ' -r72 -c --setpdfwrite ' . $file;
			//$command2 = 'convert -resize 50x50 ' . $save_file . ' ' . $save_file;
			//exec("/usr/bin/convert -resize 120x120 $file2 $file2 2>&1"); 
			
			if(!exec($command)) {
				//return $command;
			}
			else {
				//return '/' . $save_file;	
				//return $command;	
			}
			
			if (!$width && !$height) {
				return '/' . $save_file;
			}
			else {
			
				$thumb=new thumbnail($save_file); // prepare to generate "shiegege.jpg" in directory "/www"
				$thumb->size_width($width);		   // set width for thumbnail with 100 pixels
				$thumb->size_height($height);
				//$thumb->show();				   // show my thumbnail
				$thumb->save($save_path_root[0] . $newname_resized);	   // save my  thumbnail to file "huhu.jpg" in directory "/www/thumb
				
				//return $command;		
				return '/' . $save_path_root[0] . $newname_resized; 
			}
			
		} //end filecheck 
		
	//return "test";

    }

    /// \privatesection
    var $Operators;
}

?>