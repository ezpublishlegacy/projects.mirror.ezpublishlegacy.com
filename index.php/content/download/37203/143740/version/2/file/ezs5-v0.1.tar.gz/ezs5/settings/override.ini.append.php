<?php /* #?ini charset="utf-8"?

#[s5_presentation]
#Source=pagelayout.tpl
#MatchFile=full/s5_presentation_layout.tpl
#Subdir=templates
#Match[class_identifier]=s5_presentation

#[full_s5_presentation]
#Source=node/view/full.tpl
#MatchFile=full/s5_presentation.tpl
#Subdir=templates
#Match[class_identifier]=s5_presentation

*/ ?>