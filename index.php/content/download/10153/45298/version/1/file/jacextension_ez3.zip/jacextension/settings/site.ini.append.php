<?php /* #?ini charset="utf-8"?

# Explizit Zugriffsrechte auf Modulviews geben
[RoleSettings] 
PolicyOmitList[]=modul1/list
PolicyOmitList[]=modul1/create


# nach Templateoperatoren in jaceextension suchen
[TemplateSettings]
ExtensionAutoloadPath[]=jacextension

*/ ?>

