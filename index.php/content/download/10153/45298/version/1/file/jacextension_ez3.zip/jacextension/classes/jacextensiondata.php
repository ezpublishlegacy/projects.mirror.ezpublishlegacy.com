<?php
include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );


class JACExtensionData extends eZPersistentObject
{
    /*!
       Konstruktor 
    */
    function JACExtensionData( $row )
    {
        $this->eZPersistentObject( $row );
    }

    /*!
     	Definition des Aufbaus vom Datenobjektes / Datenbanktabellenstruktur
     */
    function definition()
    {
        return array( 'fields' => array( 
        
				            'id' => array( 'name' => 'ID',
							               'datatype' => 'integer',
										   'default' => 0,
										   'required' => true ),
							         
							'user_id' => array( 'name' => 'UserID',
							                    'datatype' => 'integer',
							                    'default' => 0,
							                    'required' => true ),
							                    
							'created' => array( 'name'  => 'Created',
										        'datatype' => 'integer',
										        'default' => 0,
										        'required' => true ),
							         
							'value' => array( 'name' => 'Value',
									          'datatype' => 'string',
									          'default' => '',
									          'required' => true ) 
						    ),
					        
					'keys'=> array( 'id' ),
					'function_attributes' => array( 'user_object' => 'getUserObject' ),
			        'increment_key' => 'id',
			        'class_name' => 'JACExtensionData',
			        'name' => 'jacextension_data' );
    }

    /*!
       Hier erweitern wir attribute() aus eZPersistentObject
     */
    function &attribute( $attr )
    {
        if ( $attr == 'user_object' )
            return $this->getUserObject();
        else
            return eZPersistentObject::attribute( $attr );
    }

    /*!
       Hilfsfunktion wird in Funktion attribute aufgerufen 
     */
    function &getUserObject( $asObject = true )
    {
        $userID = $this->attribute('user_id');
        $user = eZUser::fetch($userID, $asObject);
        return $user;
    }
    

    /*!
     	erzeugt ein neue Objekt vom Typ JACExtensionData
		und gibt dieses zurück
     */
    function create( $user_id, $value )
    {
         
        $row = array( 'id' => null,
                      'user_id' => $user_id,
                      'value' => $value,
                      'created' => time() );
         
        return new JACExtensionData( $row );
    }
    
    /*!
     liefert den datensatz mit gegebener id als JACExtensionData Objekt zurück
     */
    function &fetchByID( $id , $asObject = true)
    {
        $result = eZPersistentObject::fetchObject( 
        
                        JACExtensionData::definition(),
				        null,
				        array( 'id' => $id ),
				        $asObject,
				        null,
				        null );
	    
		if ( is_object($result) )
		    return $result;
        else
            return false;
    }

    /*!
     	liefert alle JACExtensionData Objekte entweder
		als Objekt oder Array zurück
     */
    function &fetchList( $asObject = true )
    {
        $result = eZPersistentObject::fetchObjectList( 
        
                        JACExtensionData::definition(),
						null,null,null,null,
						$asObject,
						false,null );       
        return $result;
    }
    
    /*!
     liefert die Anzahl der Datensätze zurück
     */
    function getListCount()
    {
        $db =& eZDB::instance();
        $query = 'SELECT COUNT(id) AS count FROM jacextension_data';
        $rows = $db->arrayQuery( $query );
        
        return $rows[0]['count'];        
       
    }

    // -- member variables--
    //// \privatesection
    var $ID;
    var $UserID;
    var $Created;
    var $Value;

}
?>