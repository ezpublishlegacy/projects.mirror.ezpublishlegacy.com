<?php

include_once('extension/jacextension/classes/jacextensiondata.php');


class eZModul1FunctionCollection
{
    
    function eZModul1FunctionCollection()
    {
    }
    
    function fetchJacExtensionDataList( $asObject )
	{
	    return array( 'result' => JACExtensionData::fetchList($asObject) );
	}

	function fetchJacExtensionDataListCount( )
	{	   
    	return array( 'result' => JACExtensionData::getListCount() );
	}
  
}

?>
