<?php
/*!
 Operator: jac('list') und jac('count') <br>
 Count: {jac('count')} <br>
 Liste: {jac('list')|attribute(show)}
 */
class JACOperator{
    var $Operators;

    function JACOperator( $name = "jac" ){
		$this->Operators = array( $name );
    }

    /*! 
     Returns the template operators.
    */
    function &operatorList(){
		return $this->Operators;
    }
    
    /*!
     \return true to tell the template engine that the parameter list exists per operator type.
     */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
     */
    function namedParameterList()
    {
        return array( 'jac' => array( 'result_type' => array(  'type' => 'string',
						                                       'required' => true,
						                                       'default' => 'list' )) );
    }

    /*!
      Je nachdem welche Parameter übergeben worden sind JACExtensionData Objekte fetchen {jac('list)}
      oder Datansätze zählen  {jac('count')}  
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters ){
        include_once('extension/jacextension/classes/jacextensiondata.php');

        $result_type = $namedParameters['result_type'];        
        
        if( $result_type == 'list')        
            $operatorValue = JACExtensionData::fetchList(true);
        elseif( $result_type == 'count')       
            $operatorValue = JACExtensionData::getListCount();    
      
    }
};
?>
