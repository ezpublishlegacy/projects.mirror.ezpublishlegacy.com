/* COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
// SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE:
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0  of the GNU General
// Public License as published by the Free Software Foundation.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of version 2.0 of the GNU General
// Public License along with this program; if not, write to the Free
// Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA. */

/* 
This splits long mysqldump files into one record per line Matches on '),.  If no file is given, input is standard in.
compile using gcc -o dbsplit dbsplit.c
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

FILE	*file;
static	char	*cmd;
	static	char	buff[BUFSIZ];
int	buffct=0;
static char *usage[] = {
		" [<filename>]\nSplits long mysqldump files into one record per line Matches on '),'.\nInput is stdin if no filename is given.\n",
		0 };

main(argc, argv)
int	argc;
char	*argv[];
{
	extern int	optind, optopt;
	extern char	*optarg;
	int	c,e;
	int	fileopen=0;

	cmd = argv[0];
	if (argc > 1){
		if (!strcmp(argv[1],"--help")) {
			fprintf(stderr, "%s: %s", cmd, *usage);
			exit(0);
		}
	}
	for(;optind<=argc;optind++){ /* for multiple filenames */
	if (!argv[optind] && optind==argc && fileopen) {
		break; /* hit last null with open file, quit */
		}
	if (optind==argc && !fileopen) {/* hit last null with no file*/
		file = stdin;
	} else {	/* No null, must be file */
		fileopen++;
		if(!strcmp(argv[optind],"-")){
			file = stdin;
		} else { /* set file or error out */
			if((file=fopen(argv[optind],"r"))==NULL) {
				fprintf( stderr, "%s:  cannot open %s\n",
					cmd, argv[optind] );
				continue;
			}
		}
	} /* Got a valid file, so process*/
	while((c=getc(file)) != EOF) {
	switch(c){
	case '\n' : case 13 : 
		putchar(10);
		break;
	case 160:
		putchar(32);
		break;
	case ')':
		/* load buff */
		e = c;
		do buff[buffct] = e;
		while(buffct++ < 2 && (e=getc(file)) !=',' && e != EOF);
		if (e != ',' ) {
			putbuff(0,--buffct);
		} else {
		        putchar(c);
		        putchar(10);
		}
		buffct=0;
		break;
	default:
		putchar(c);
		}  /* end of switch */
	}	/* end of while */
	if(file)
		fclose(file);
} /* end of for */
} /* end of main */
putbuff(begin,finish)
	register int    begin;
	register int    finish;
{
	       for(;begin<=finish;putchar(buff[begin++]));
}
