#!/bin/sh
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.
#############################################################################
# This finds Byte Order Marks (http://en.wikipedia.org/wiki/Byte_Order_Mark)
# which are sometimes injected into files with MS Windows editors and which can
# cause php scripts to exit silently causing confusing errors.
# May return false positives on binary files.
# Will work on file or recursively on a directory.
#############################################################################

file=${1:-.}
doit ()
{
output=`head -1 "$file"|sed -n '/\xef\xbb\xbf/p'`
if [ -n "$output" ]
then
        echo "$file Got BOM"
fi
}
if [ -f "$file" ]
then
	doit $file
elif [ -d "$file" ]
then
	dir=$file
	find $dir -type f -print|
        egrep -v --regexp="/\.svn/|/changelog/|\.png$|\.jpg$|\.gif$|\.ico$|\.sql$|\.pdf$|\.psd$|\.doc$|\.tif$|\.bin$"|while read file
	do
		doit "$file"
	done
else 
	echo "$file not a file or directory ?!"
fi