#!/bin/bash
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.
#############################################################################
#
# Recursive grep to search through files in a directory or directories
# 
#############################################################################
trap 'exit' 0 1 2 3 9 15 19
cmd=`basename $0`
last=${@:$#}
startdir="$PWD"
list=$startdir
igdir="/\.svn/|/changelog/"

default_option=${default_option:-"-i -h -a"} #default options

printerr ()
{
cat <<EOF
Usage: $cmd [OPTION]... PATTERN 

"$igdir" in the filename/path is ignored by default

Options are standard egrep options - and will be passed through -  except
for these changed and additional options:

 -d <dir>           searches from directory <dir>
 -f                 only searches the filenames
 --ignore=<regexp>  directories to ignore, "$igdir" is default
 -CAT               slightly faster but can fail ugly on binary files
                    necessary to look for multi-byte characters

The options $default_option are default and will be turned off if used,
i.e. case-insensitive is default, use -i to make case-sensitive.
EOF
exit 1
}
clropt ()
{
     option=`echo $option|sed -e "s/${1} //g" -e "s/^${1} //g" -e "s/ ${1}$//g"`
}
getfiles ()
{
     egrep -l ${option} -d recurse ${include} ${exclude} --regexp="$last" "$directory"|
     egrep -v --regexp="$igdir"
}
maybecho ()
{
     if [ ! "$suppress" ]
     then
             echo "$*"
     fi
}

########
# MAIN #
########

if [ $# -lt 1 ]
then 
     printerr
else     
     option=$default_option
     for opt               #Can't be a function because of this
     do
     case $opt in
          "--help") printerr;;     #to remove
          "$last")  continue;;     
          '-d'|'-h'|'-a'|'-i'|'-r')     clropt $opt;; #to remove
          "-l")     lopt=lopt;clropt $opt;;
          "-c")     ccount=ccount;clropt $opt;;
          "-f")     filename=filename;;
          "-r")     clropt $opt;;
          "-s")     suppress=supress;option="$option $opt";;
          "-H")     Hopt=1;clropt $opt;;
          "-CAT")
                    strings=cat
                    clropt $opt
                    ;;
          "--exclude="*)
                    exclude=$opt
                    clropt $opt
                    ;;
          "--include="*)
                    include=$opt
                    clropt $opt
                    ;;
          "--ignore=+"*)
                    clropt $opt
                    igdir=${igdir+$igdir|}`echo $opt|sed 's/--ignore=+\(.*\)/\1/'`
                    ;;
          "--ignore="*)
                    clropt $opt
                    igdir=`echo $opt|sed 's/--ignore=\(.*\)/\1/'`
                    ;;
          "-"*)     option="$option $opt";;     #to passthru
          *)        count=$((${count:-0} + 1))
                    eval list[$count]=$opt;; #Must be a directory for -d
     esac
     done
     igdir=${igdir:-"^$"}
fi
for  lcount in `seq 1 $count`     #If not array then default $list is $list[1]
do
     echo ${list[$lcount]}
done|while read directory
do
     if [ ! -d "$directory" ]
     then
          if [ -d "$startdir/$directory" ]
          then 
               directory="$startdir/$directory"
          else
               maybecho "$directory not valid directory.  Ignored."
               continue
          fi
     fi
     
     maybecho "##### "$directory "##############"
     if [ "$filename" ]     #-f search filename
     then
          find "$directory" -print|egrep ${option} --regexp="$last"|
          egrep -v --regexp="$igdir"
     elif [ "$ccount" ]     #-c option gets rid of files with 0
     then
          getfiles|while read file
          do
               outcount=`${strings:-strings} "$file"|egrep -c ${option} --regexp="$last"`
               if [ "$outcount" != 0 ]
               then
                    echo "#### $file: $outcount"
               fi
          done

     elif [ "$lopt" ] #(standard input) comes from pipe error
     then            #on -l (just output filenames
          getfiles
     else               #default
          getfiles|while read file
          do
               maybecho "#### $file :"
               ${strings:-strings} "$file"|
               egrep ${Hopt:+-H --label="${file}"} ${option} --regexp="$last"
          done
     fi
done
