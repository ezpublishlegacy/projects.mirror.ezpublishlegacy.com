#!/bin/sh
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.
#############################################################################
# This outputs a settings files sorted alphabetically by the [head] line.  By
# doing this on two different files, they can be diffed to see any differences.
# WARNING: Not a good idea to REPLACE the settings file with the output however,
# because sometimes order matters - on the match nodes for example
#############################################################################

overfile=${1}
if [ $# -ne 1 ]
then
cat - <<EOF
This outputs a settings files sorted alphabetically by the [head] line.  By
doing this on two different files, they can be diffed to see any differences.
WARNING: Not a good idea to REPLACE the settings file with the output however,
because sometimes order matters - on the match nodes for example
EOF
exit
fi

#put the heads into an array
linenums=(`grep -n "^\[" $overfile|awk 'BEGIN{FS=":"}{print $1}'`)
grep "^\[" $overfile|sort -u|while read head
do
	headline=`grep -n "^\\\\${head}$" $overfile|awk 'BEGIN{FS=":"}{print $1}'`
	headcount=`echo $headline|awk '{print NF}'`
	if [ $headcount -ne 1 ]
	then
		echo $head "IS A DOUBLE!!! BAILING OUT"
		exit
	fi	
	for((i=0;i<=${#linenums[*]};i++)) do
	if [ "$headline" -eq ${linenums[$i]} ]
	then
		nextline=${linenums[(($i + 1))]}
		break
	fi
	done
	if [ -z "$nextline" ]
	then
		nextline=${nextline:-"$"}
	else
		nextline=$(($nextline - 1))
	fi
	eval "sed -n '$headline,$nextline p' $overfile"
done
