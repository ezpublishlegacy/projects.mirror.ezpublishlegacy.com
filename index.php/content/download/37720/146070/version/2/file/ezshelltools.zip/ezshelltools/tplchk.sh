#!/bin/sh
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

#############################################################################
# This does a check for common tags in template files to find mismatched 
# code blocks.  Could return false positives if a tag is closed in a different
# template.
# Can be run on one file or recursively on a directory.
#############################################################################

tplfile=${@:$#} 
cmd=`basename $0`
gettags ()
{
cat - <<EOF |grep -v "^#"
div <div </div>
span <span </span>
li <li[^n] </li>
if {if {/if} {else
switch {switch {/switch}
case {case {[/c][ca][as][se][e/]}
let {let {/let}
default {default {/default}
foreach {foreach {/foreach}
section {section[^-] {/section} {section-
append {append-block {/append-block}
cache {cache-block {/cache-block}
EOF
}
matchtag ()
{
	matchtag=`echo $1|sed 's/\[.*\]$//'` #This is needed to stop the <li
	cat $tplfile|grep "$1"|		     #from matching on link with <li[^n]
	awk -v matchtag=$matchtag -v endtag=$endtag -v elsetag=${elsetag:-"this_is_a_long_dummy_string"} 'BEGIN{FS=endtag}{
                for(i=1;i<=NF;i++) {
                        if ( matchtag != elsetag && $i ~ elsetag ) {
                                continue
                        } else {
                                if ( $i ~ matchtag ) {total = total + 1}
                        }
                }
        } END {
        print total
        }'
}
checktags ()
{
else=0
dirtyflag=0
elsetag=""
gettags|while read label opentag closetag elsetag
do
	endtag=${closetag:$((${#closetag} - 1)):1}
	closetag=${closetag:0:$((${#closetag} - 1))}
	open=`matchtag $opentag|tail -1`
	close=`matchtag $closetag|tail -1`
	if [ -n "$elsetag" ]
	then
        	else=`matchtag $elsetag|tail -1`
		if [ "${opt}" = "-v" ]
		then
			echo $label $opentag ${open:-0} $closetag ${close:-0} ${else:+elsetag $else}
		fi
	else
		if [ "${opt}" = "-v" ]
		then
			echo $label $opentag ${open:-0} $closetag ${close:-0}
		fi
	fi
	if [ "${open:-0}" -ne "${close:-0}" ]
	then 
		if [ "$1" = "verbose" ]
		then
			echo -e "Uneven ${label} tags: ${label}-open: ${open:-0} ${label}-close: ${close:-0}\c"
			if [ -n "$elsetag" -a ${else:-0} -ne 0 ]
			then
				echo -e " ${label}-else: ${else:-0}\c"	
			fi
			echo
		else
			dirtyflag=1
			echo $dirtyflag
		fi
	fi
done
}
########
# MAIN #
########
if [ $# -lt 1 ]
then
	echo -e "Usage:\t $cmd <file|directory>"
	echo -e "\t\t<directory> is recursive"
	echo -e "\t\t-v (verbose) also displays clean files"
	exit
elif [ "$1" != "$tplfile" -a "$1" = "-v" ]
then
	opt="-v"
fi
if [ "$tplfile" = "." ]
then
	tplfile=$PWD
elif [ "$tplfile" = ".." ]
then
	tplfile=`dirname $PWD`
fi
if [ -d "$tplfile" ]
then
	echo "#### Starting from $tplfile ####"
	find $tplfile -name "*.tpl" -print|while read file
	do
		$0 ${opt} ${file}
	done
	exit
fi

dirtyflag=`checktags`
if [ -n "${dirtyflag}" ]
then
	echo "##### "$tplfile" #####"
	checktags verbose
elif [ "${opt}" = "-v" ]
then
	echo "##### "$tplfile" #####"
	echo "`basename $tplfile` appears clean"
fi
