#!/bin/sh
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

#############################################################################
#
# This shell script will split a mysql database dumping each 
# table into a seperate file.  used in conjunction with dbsplit
# - which will split each database entry to a seperate line,
# it is possible to see exactly what has changed in the database
# by running:
#
# diff --recursive --suppress-common-lines --side-by-side <dir1> <dir2>
#
# The only argument is a filename which should be a dbdump file with a 
# .sql extension.  The files will be written to a directory named the 
# same as the file with the .sql stripped off.  If the file does not have
# a .sql extension, then the file will be appended with the process id
# of this shell script.
#
#############################################################################

cmd=`basename $0`
dbfile=${@:$#}

printerr ()
{
cat <<EOF
$*
Usage: $cmd <filename>
<filename> must be a mysql 4.4 dump
EOF
exit 1 
}
if [ $# -lt 1 ]
then 
     printerr "Error: no input file."
elif [ "$dbfile" = "--help" ]
then 
     printerr "Error: no input file."
elif [ ! -f "$dbfile" ]
then
	printerr "$cmd Error: $dbfile not a file"
elif [ ! -r "$dbfile" ]
then
	printerr "$cmd Error: $dbfile not readable"
fi

if [ -n "`type -ap dbsplit`" ]
then
	parsecmd=dbsplit
else
	parsecmd="cat -"
fi
grep -n "CREATE TABLE" $dbfile|cut -d : -f 1|while read num
do
	tablename=`eval "sed -n '$num p' $dbfile"|cut -d " " -f 3|sed 's/\`//g'`
	dir=`echo $(basename $dbfile)|sed 's/.sql$//'`
	echo $dir $num $tablename
	if [ "$dir" = "$dbfile" ]
	then #no .sql in filename gotta do something else
		dir=$dbfile.$$
	fi
	if [ ! -d "$dir" ]
	then
		mkdir $dir
	fi
	eval "sed -n '$num,/^UNLOCK TABLE/p' $dbfile"|
	sed 's/,$//'|$parsecmd > $dir/$tablename
done
