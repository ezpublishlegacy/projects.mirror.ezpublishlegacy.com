#!/bin/sh
# COPYRIGHT NOTICE: Copyright (C) 2007 Contactivity BV
# SOFTWARE LICENSE: GNU General Public License v2.0 NOTICE: >
# This program is free software; you can redistribute it and/or
# modify it under the terms of version 2.0  of the GNU General
# Public License as published by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of version 2.0 of the GNU General
# Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

#############################################################################
# This fixes indentation of html or template files making it easier to spot 
# uneven tags.  This may fail on odd tag stuff or on tags embedded in comments
#############################################################################

eval last='$'\{${#}\}
delimeter="| \c"
opentag="<div"
closetag="</div"
elsecount=0
tabcount=0
prterr ()
{
echo $1
cat <<-EOF
Formats tags
USAGE: $cmd [-s|-l|--tag="<tag>"] <file>
	<tag> should not have close bracket i.e. tag=<li
	-s {section
	-l <li  
default is <div
EOF
exit
}
push_array ()
{
        divarray[${#divarray[*]}]=$*
}
pop_array () #not used
{
        pointer=$((${#divarray[*]} - 1))
        echo ${divarray[${pointer}]}
        unset divarray[${pointer}]
}
matchtag ()
{
      matchtag=`echo $opentag|sed 's/\[.*\]$//'`
      cat $last|grep "$opentag"|awk -v matchtag=$matchtag -v endtag=$endtag -v elsetag=${elsetag:-"this_is_a_long_dummy_string"} 'BEGIN{FS=endtag;print matchtag" MATCHTAG"}{
                for(i=1;i<=NF;i++) {
                        print i" I "$i" DOLLAR I"
                        if ( matchtag != elsetag && $i ~ elsetag ) {
                                print "CONTINUING"
                                continue
                        } else {
                                if ( $i ~ matchtag ) {total = total + 1;
print "MATCHED "total" TOTAL";
                                }
                        }
                }
        } END {
        print total
        }'
}
parse ()
{
while read line
do
	tag=""
        if [ "${tabcountafter:-0}" -eq 1 ]
        then
		if [ "${bothonline:-0}" -eq 1 ]
		then
			tabcount=$(($tabsum + $tabcount))
			bothonline=0
		else
                	tabcount=$(($tabcount + $opencount))
		fi
		if [ "${elsecount:-0}" -ne 0 ]
		then
			tabcount=$(($tabcount + $elsecount))
		fi
                tabcountafter=0
        fi
	#The x always guarantees at least 1 field.  Blank line would be zero, no match would be 1.  Blank lines should maybe be stripped ?!
        opencount=`echo x$line|awk -v opentag=$opentag 'BEGIN{FS=opentag}{print NF}'`
        opencount=$(($opencount - 1))
        if [ "$opencount" -ne 0 ]
        then
		push_array $line
                tabcountafter=1
        fi
        closecount=`echo x$line|awk -v closetag=$closetag 'BEGIN{FS=closetag}{print NF}'`
        closecount=$(($closecount - 1))
	tabsum=$(($opencount - $closecount))
        if [ "$closecount" -ne 0 ]
        then
        	#echo ${divarray[${pointer}]}
		pointer=$((${#divarray[*]} - 1))
		tag={\*`echo ${divarray[${pointer}]}|sed 's/.*class="\(.*\)".*/\1/'`\*}
		tag=`echo $tag|sed 's/.*id="\(.*\)".*/{*\1*}/'`
		for((i=1;i<=$closecount;i++))
		do
			if [ "${pointer}" -gt 1 ]
			then
        			unset divarray[${pointer}]
				pointer=$((${#divarray[*]} - 1))
			fi
		done
		if [ "${tabcountafter:-0}" -eq 1 ]
		then
			tabcount=$(($tabcount + $tabsum))
			bothonline=1
			tag=""
		else
                	tabcount=$(($tabcount - $closecount))
		fi
        fi
	if [ -n "$elsetag" ]
	then
		elsecount=`echo x$line|awk -v elsetag=$elsetag 'BEGIN{FS=elsetag}{print NF}'`
        	elsecount=$(($elsecount - 1))
		if [ "${elsecount:-0}" -ne 0 ]
		then
                	tabcount=$(($tabcount - $elsecount))
			tabcountafter=1
		fi
	fi
	
	if [ "$1" = "-s" -a $opencount -eq 0 -a $closecount -eq 0 -a $elsecount -eq 0  ]
	then
		continue
	else
		for x in `seq 1 $tabcount`
		do
			echo -e $delimeter
		done
		echo $line $tag
	fi
done
}
########
# MAIN #
########
case $1 in
	--help|-h)  prterr;;
	$last)  ;;
        -l)     opentag="<li[^n]"
                closetag="</li"
                ;;
        -s)
                opentag="{section[^-]"
                closetag="{/section"
                elsetag="{section-"
                ;;
        -i)
                opentag="{if"
                closetag="{/if"
                elsetag="{else"
                ;;
	"--tag="*)
                    tag=`echo $1|sed 's/--tag=\(.*\)/\1/'`
                    opentag=$tag
                    closetag=`echo $tag|sed 's/\(.\)\(.*\)/\1\/\2/'`
                    elsetag="${tag}-"
		    echo $opentag $closetag
                ;;
	*)      prterr $1 bad option. ;;
esac
cat -s $last|sed 's/^[[:blank:]]\{1,\}//'|grep -v "^$"|parse
#matchtag $opentag  #for awk debug
opentot=`matchtag $opentag|tail -1`
#matchtag $closetag #for awk debug
closetot=`matchtag $closetag|tail -1`
if [ ${opentot:-0} -ne ${closetot:-0} ]
then
	echo UNEVEN TAGS: OPEN $opentag ${opentot:-ERROR} CLOSE $closetag ${closetot:-ERROR}
fi
