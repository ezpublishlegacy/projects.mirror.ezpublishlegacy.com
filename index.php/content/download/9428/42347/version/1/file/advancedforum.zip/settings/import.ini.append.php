[ImportSettings]
RepositoryDirectories[]=extension/advancedforum/classes
ExtensionDirectories[]=advancedforum
FilterExtensionDirectories[]=advancedforum