[ForumSettings]
# shorten usernames longer as defined amount
UsernameShortening=15
Views=enabled
# Define in which language the posts are created, defaults to locale settings
#CreateLanguage=eng
# View Languages
#ViewLanguages[]
#ViewLanguages[]=ger
#ViewLanguages[]=ger-DE