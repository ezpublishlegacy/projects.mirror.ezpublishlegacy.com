[ModuleSettings]
ExtensionRepositories[]=advancedforum
