[TemplateSettings]
ExtensionAutoloadPath[]=advancedforum

[RegionalSettings]
TranslationExtensions[]=advancedforum

[RoleSettings]
PolicyOmitList[]=view/count