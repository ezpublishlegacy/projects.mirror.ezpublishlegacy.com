<?php /*

[ModuleSettings]
ExtensionRepositories[]=directebankingpaycode

ModuleList[]=directebankingpaycode

*/ ?>
