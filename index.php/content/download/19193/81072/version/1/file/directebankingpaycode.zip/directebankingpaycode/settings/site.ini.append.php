<?php /*

[RegionalSettings]
TranslationExtensions[]=directebankingpaycode

[RoleSettings]
PolicyOmitList[]=directebankingpaycode/notificate
PolicyOmitList[]=directebankingpaycode/success
PolicyOmitList[]=directebankingpaycode/failed

*/ ?>
