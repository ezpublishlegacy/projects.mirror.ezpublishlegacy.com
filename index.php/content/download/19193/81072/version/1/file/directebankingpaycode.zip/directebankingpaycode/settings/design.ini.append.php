<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=directebankingpaycode

[StylesheetSettings]
CSSFileList[]=jscal2.css
CSSFileList[]=border-radius.css
CSSFileList[]=steel.css
*/ ?>
