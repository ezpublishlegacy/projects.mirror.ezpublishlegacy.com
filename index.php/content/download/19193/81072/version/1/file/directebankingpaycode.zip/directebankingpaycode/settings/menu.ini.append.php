<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[directebankingpaycode]=DIRECTebanking.com - paycode

[TopAdminMenu]
Tabs[]=directebankingpaycode

[Topmenu_directebankingpaycode]
NavigationPartIdentifier=directebankingpaycode
Name=DIRECTebanking.com - paycode
Tooltip=Control your DIRECTebanking.com - Paycode Account
URL[]
URL[default]=directebankingpaycode/profile/view
Enabled[]
Enabled[default]=false
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=false
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
