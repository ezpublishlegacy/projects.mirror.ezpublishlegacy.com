<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
	array( 'script' => 'extension/smartshort/autoloads/eztemplatesmartshortoperator.php',
                            'class' => 'SmartShortOperator',
                            'operator_names' => array( 'smartshort' ) );
?>
