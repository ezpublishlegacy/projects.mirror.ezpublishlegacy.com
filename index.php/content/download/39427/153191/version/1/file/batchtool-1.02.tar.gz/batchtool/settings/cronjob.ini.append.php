<?php /* #?ini charset="iso-8859-1"?

[CronjobSettings]
ExtensionDirectories[]=batchtool

[CronjobPart-batchtool]
Scripts[]=batchtool.php

*/ ?>
