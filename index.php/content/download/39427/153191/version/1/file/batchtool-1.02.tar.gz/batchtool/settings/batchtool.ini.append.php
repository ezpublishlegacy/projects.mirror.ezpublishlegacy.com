<?php /* #?ini charset="iso-8859-1"?

[BatchToolSettings]
UserID=14
FilterList[]
FilterList[]=fetchnodelist
OperationList[]
OperationList[]=nodelistname
OperationList[]=nodecopy
OperationList[]=nodemove
OperationList[]=nodesetpriority
OperationList[]=nodedelete
OperationList[]=nodechangeattribute
OperationList[]=nodealwaysavailable

[NodeChangeAttribute]
PHPFunctions[]
PHPFunctions[]=trim
UserFunctions[]
UserFunctions[]=user_trim

*/ ?>
