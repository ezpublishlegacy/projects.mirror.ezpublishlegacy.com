var classggHTTPClient =
[
    [ "__construct", "classggHTTPClient.html#ac000bc3149007ffa19bd171a9007638b", null ],
    [ "call", "classggHTTPClient.html#a9c0b7b7d564d6d069693ac754c2d9149", null ],
    [ "get", "classggHTTPClient.html#a8824af9e3b4cea4e6d99a691e03d9fe1", null ],
    [ "post", "classggHTTPClient.html#a05d9d898f016e213242853b3c86ac191", null ]
];