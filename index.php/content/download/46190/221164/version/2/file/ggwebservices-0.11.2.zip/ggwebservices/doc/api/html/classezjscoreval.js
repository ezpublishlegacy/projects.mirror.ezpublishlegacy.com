var classezjscoreval =
[
    [ "serialize", "classezjscoreval.html#af60803baf17148c4ca549c82bdf37af1", null ]
];