var classggHTTPRequest =
[
    [ "_payload", "classggHTTPRequest.html#af36b0ea34e5bdbfef897a36f8c4c5008", null ],
    [ "decodeStream", "classggHTTPRequest.html#ac44722085465a1d1a4c231d1d8a646f2", null ],
    [ "method", "classggHTTPRequest.html#accc7cc53a05f2491765288e03211679d", null ],
    [ "payload", "classggHTTPRequest.html#aa19547a80dd6fb40a5b8ef9a71435252", null ],
    [ "$ContentType", "classggHTTPRequest.html#a9376f9ec87a259a353930545476bae5b", null ]
];