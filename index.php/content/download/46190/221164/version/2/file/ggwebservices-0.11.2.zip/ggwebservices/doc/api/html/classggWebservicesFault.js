var classggWebservicesFault =
[
    [ "__construct", "classggWebservicesFault.html#a1ea9f4e749e5e7c98127c1f4fdf128d6", null ],
    [ "__tostring", "classggWebservicesFault.html#a6cc08a57d6e599f6637d7477fcd9684d", null ],
    [ "faultCode", "classggWebservicesFault.html#abcc3c17d05766a2ad484650a13175ab0", null ],
    [ "faultString", "classggWebservicesFault.html#acad06290dc9d830b59b0de8f37024524", null ],
    [ "$FaultCode", "classggWebservicesFault.html#a3f1d31d869f968dffc68b6b189e2715d", null ],
    [ "$FaultString", "classggWebservicesFault.html#abb70aef57520b787f7007e5d1bf780e6", null ]
];