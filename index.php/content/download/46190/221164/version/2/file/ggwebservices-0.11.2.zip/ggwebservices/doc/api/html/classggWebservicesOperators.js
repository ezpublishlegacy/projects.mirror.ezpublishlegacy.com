var classggWebservicesOperators =
[
    [ "modify", "classggWebservicesOperators.html#a2b24ba8fa68706152b1f9729ff46d40c", null ],
    [ "namedParameterList", "classggWebservicesOperators.html#a6c327e9ed51ac8f3e6760a5101baf144", null ],
    [ "namedParameterPerOperator", "classggWebservicesOperators.html#acd325744916cbbb19d61a3c2b50f1c5f", null ],
    [ "operatorList", "classggWebservicesOperators.html#a9d48d8012bab93507e1ee08eae7bd0e6", null ],
    [ "$operators", "classggWebservicesOperators.html#a681a0c4acefbd89ce2e33a760a0c96fb", null ]
];