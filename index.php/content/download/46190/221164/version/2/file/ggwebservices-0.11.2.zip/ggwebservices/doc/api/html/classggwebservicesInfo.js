var classggwebservicesInfo =
[
    [ "info", "classggwebservicesInfo.html#a21c95fa870a0d11954118fda286cc2ad", null ]
];