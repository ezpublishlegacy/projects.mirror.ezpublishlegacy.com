var classggPhpSOAPClientTransport =
[
    [ "__construct", "classggPhpSOAPClientTransport.html#ade66628d1e4124cfc12e87ac8fdbf245", null ],
    [ "__doRequest", "classggPhpSOAPClientTransport.html#a5da44e1b912c8c9cfd5674ff36facb16", null ]
];