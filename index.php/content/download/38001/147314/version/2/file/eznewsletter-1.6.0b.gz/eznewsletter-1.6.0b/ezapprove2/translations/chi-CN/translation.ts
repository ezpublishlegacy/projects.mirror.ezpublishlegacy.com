<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name>crm</name>
    <message>
        <location filename="" line="0"/>
        <source>Select minimum number of required approvals.</source>
        <translation type="obsolete">Velg minimum antall påkrevde godkjenninger.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/full/ezapprove</name>
    <message>
        <location filename="" line="0"/>
        <source>Approval</source>
        <translation>审批</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object awaits approval before it can be published.</source>
        <translation>内容对象发布之前需要经过审批。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>如果您愿意，您可以给审批者发送邮件?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>内容对象%1发布之前需要经过您的审批。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Do you approve of the content object being published?</source>
        <translation>您批准发布该内容对象吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have approved the content, and it is waiting for more approvers, or the workflow to continue the processing of the object,</source>
        <translation>您已经批准该内容，现在它需要通过其他审批者的审批，或者继续交由工作流处理，</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>该内容对象%1已获得批准并且将在发布工作流下次执行时被发布。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 [deleted] was approved and will be published once the publishing workflow continues.</source>
        <translation>该内容对象%1 [已删除] 已获得批准并且将在发布工作流下次执行时被发布。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>该内容对象%1未获得批准但可再次作为草稿存在。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 [deleted] was not accepted but is available as a draft again.</source>
        <translation>该内容对象%1 [已删除] 未获得批准但可再次作为草稿存在。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>您可以再次编辑草稿并发布，此时需要再次经过审批。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit the object</source>
        <translation>编辑对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>该内容对象%1未获得批准但可作为作者的一份草稿存在。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The content object %1 [deleted] was not accepted but will be available as a draft for the author.</source>
        <translation>该内容对象%1 [已删除] 未获得批准但可作为作者的一份草稿存在。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>作者可以再次编辑草稿并发布，此时需要再次经过审批。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Comment</source>
        <translation>注释</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add Comment</source>
        <translation>添加注释</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approve</source>
        <translation>Godkjenn</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Deny</source>
        <translation>据否</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add approver</source>
        <translation>添加审批者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Messages</source>
        <translation>消息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Participants</source>
        <translation>参与者</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/line/ezapprove</name>
    <message>
        <location filename="" line="0"/>
        <source>%1 awaits approval by editor</source>
        <translation>%1等待编辑的审批</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%1 was approved for publishing</source>
        <translation>%1已获得发布批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%1 was not approved for publishing</source>
        <translation>%1未获得发布批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%1 awaits your approval</source>
        <translation>%1等待您的审批</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>编辑 &lt;%child_name&gt;。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>您没有权限编辑 &lt;%child_name&gt;。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Any</source>
        <translation>任何</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No users selected.</source>
        <translation>未选择用户。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add users</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approve users</source>
        <translation>审批用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Continue</source>
        <translation>继续</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <location filename="" line="0"/>
        <source>Posted: %1</source>
        <translation>提交: %1</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <location filename="" line="0"/>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] 审批 &quot;%objectname&quot; 等待您的参与</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>这封邮件提醒您&quot;%objectname&quot;正等待您在%sitename的审批。
发布流程已被挂起，您可以决定继续或者终止。
该审批可以在以下URL查看。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot; 等待审批</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>这封邮件提醒您&quot;%objectname&quot;在%sitename等待您的审批。
如果您希望给审批者发送消息或查看状态，访问以下URL。</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <location filename="" line="0"/>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>如果您不希望继续收到这些提醒，
修改您以下的配置:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%sitename notification system</source>
        <translation>%sitename 提醒系统</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
        <location filename="" line="0"/>
        <source>Approver users</source>
        <translation>审批者用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approver groups</source>
        <translation>审批者组</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sections</source>
        <translation>分区</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Any</source>
        <translation>任何</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Users without approval</source>
        <translation>不需要审批的用户</translation>
    </message>
</context>
<context>
    <name>ezapprove2</name>
    <message>
        <location filename="" line="0"/>
        <source>One</source>
        <translation>一</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>All</source>
        <translation>所有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User defined</source>
        <translation>用户自定义的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Predefined</source>
        <translation>预定义的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approve</source>
        <translation>审批</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
        <translation>放弃</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New Draft</source>
        <translation>新建草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select users to do content approval &lt;%object_name&gt;</source>
        <translation>选择用户负责审批 &lt;%object_name&gt;</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select users for content approval &lt;%object_name&gt;</source>
        <translation>选择用户负责审批 &lt;%object_name&gt;</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Elements awaiting approval</source>
        <translation>等待审批的项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Started</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># Approved</source>
        <translation># 已批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># Required</source>
        <translation># 已请求</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select approval for removal. This will will mark the pending version as archived.</source>
        <translation>选择要删除的审批。这会将等待的版本标志为归档。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update list</source>
        <translation>更新列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update approval statuses.</source>
        <translation>更新审批状态。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit Subscription</source>
        <translation>编辑订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You need to select at least %num_users users to approve your content.</source>
        <translation>您需要选择至少%num_users名用户负责审批您的内容。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approve List</source>
        <translation>审批列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select approver</source>
        <translation>选择审批者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>In approval</source>
        <translation>审批中</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approved</source>
        <translation>已批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discarded</source>
        <translation>已放弃</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Finnished</source>
        <translation>已结束</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select minimum number of required approvals.</source>
        <translation>选择最少需要的审批次数。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Object ID</source>
        <translation>对象ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Affected sections</source>
        <translation>影响到的分区</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>All sections</source>
        <translation>所有分区</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Users select approvers themselves</source>
        <translation>用户自行选择审批者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Users select who should approve the content when publishing</source>
        <translation>用户选择谁负责审批内容</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Required number of users to approve content</source>
        <translation>必须的审批者数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Any</source>
        <translation>任何</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select if one or all is enough to approve content.</source>
        <translation>选择一个人还是所有人可以审批内容。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allow approvers to be added while approving content.</source>
        <translation>允许在审批过程中添加审批者。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Pre selected approvers</source>
        <translation>预先选择的审批者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Users who approves content</source>
        <translation>负责审批内容的用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No users selected.</source>
        <translation>未选择用户。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>Fjern valgte删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add users</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Groups who approves content</source>
        <translation>负责审批内容的用户组</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Group</source>
        <translation>用户组</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No groups selected.</source>
        <translation>未选择用户组。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add groups</source>
        <translation>添加用户组</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Excluded user groups ( users in these groups do not need to have their content approved )</source>
        <translation>被排除的用户组(这些组中的用户发布的内容不需要经过审批)</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User and user groups</source>
        <translation>用户与用户组</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <location filename="" line="0"/>
        <source>Approval2</source>
        <translation>审批2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approval v.2</source>
        <translation>审批 v.2</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <location filename="" line="0"/>
        <source>Approve2</source>
        <translation>审批2</translation>
    </message>
</context>
</TS>
