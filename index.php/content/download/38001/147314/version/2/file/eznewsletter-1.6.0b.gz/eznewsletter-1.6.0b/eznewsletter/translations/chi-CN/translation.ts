<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name></name>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>编辑 &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>将内容从 %from_lang翻译至%to_lang</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back to edit</source>
        <translation>返回编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
        <translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>发布当前编辑的草稿。草稿因此将成为该对象的发布版本。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store draft</source>
        <translation>保存草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>保存当前编辑草稿的内容并继续编辑。使用此按钮定期保存您的工作。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard draft</source>
        <translation>放弃草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to discard the draft?</source>
        <translation>您确定希望放弃该草稿吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>放弃当前编辑的草稿。这同时也会删除所有属于该草稿的翻译（如果有）。</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <location filename="" line="0"/>
        <source>Show 10 items per page.</source>
        <translation>每页显示10条记录。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show 50 items per page.</source>
        <translation>每页显示50条记录。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show 25 items per page.</source>
        <translation>每页显示25条记录。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>编辑 &lt;%child_name&gt;。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>您没有权限编辑&lt;%child_name&gt;。</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <location filename="" line="0"/>
        <source>Content structure</source>
        <translation>内容结构</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage the main content structure of the site.</source>
        <translation>管理站点的主内容结构。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Media library</source>
        <translation>媒体库</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage images, files, documents, etc.</source>
        <translation>管理图片，文件，文档等。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User accounts</source>
        <translation>用户帐号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage users, user groups and permission settings.</source>
        <translation>管理用户，用户组以及权限配置。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Webshop</source>
        <translation>网上商店</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
        <translation>管理客户，订单，折扣以及增值税类型；查看销售统计。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Design</source>
        <translation>设计</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage templates, menus, toolbars and other things related to appearence.</source>
        <translation>管理模板，菜单，工具栏以及其他与外观相关的配置。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Setup</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Configure settings and manage advanced functionality.</source>
        <translation>修改配置以及管理高级功能。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My account</source>
        <translation>我的帐号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage items and settings that belong to your account.</source>
        <translation>管理属于您的项目以及配置。</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/content/menu</name>
    <message>
        <location filename="" line="0"/>
        <source>Change the left menu width to small size.</source>
        <translation>将左侧菜单的宽度变为小号。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Small</source>
        <translation>小号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Medium</source>
        <translation>中号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Change the left menu width to large size.</source>
        <translation>将左侧菜单的宽度变为大号。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Large</source>
        <translation>大号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Change the left menu width to medium size.</source>
        <translation>将左侧菜单的宽度变为中号。</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/browse_article_pool</name>
    <message>
        <location filename="" line="0"/>
        <source>Select a source for newsletter articles</source>
        <translation>选择一个新闻邮件的文章源</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Use the radio buttons to choose a source location for articles to be used in the newsletter, then click &quot;OK&quot;.</source>
        <translation>使用勾选单选框选择一个文章源位置，该位置中的文章将会被新闻邮件使用，然后点击&quot;确定&quot;。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>通过顶端的标签，左侧的菜单以及中间的内容列表导航。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/browse_single_user_select</name>
    <message>
        <location filename="" line="0"/>
        <source>Please select an eZ Publish user.</source>
        <translation>请选择一个eZ Publish用户。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_bounce</name>
    <message>
        <location filename="" line="0"/>
        <source>Confirm bounce entry removal</source>
        <translation>确认删除弹回项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the bounce entry?</source>
        <translation>您确认希望删除该弹回项目吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the bounce entries?</source>
        <translation>您确认希望删除这些弹回项目吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following bounce entries will be removed:</source>
        <translation>以下的弹回项目将被删除:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Do not proceeed unless you are sure.</source>
        <translation>除非您确定，否则不要继续。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_newsletter</name>
    <message>
        <location filename="" line="0"/>
        <source>Confirm newsletter removal</source>
        <translation>确定删除新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the newsletter?</source>
        <translation>您确定希望删除该新闻邮件吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following newsletters will be removed:</source>
        <translation>以下的新闻邮件将被删除:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Do not proceed unless you are sure.</source>
        <translation>除非您确定，否则不要继续。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>Confirm newsletter type removal</source>
        <translation>群定删除新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the newsletter type?</source>
        <translation>您确定希望删除该新闻邮件类型吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the newsletter types?</source>
        <translation>您确认希望删除这些新闻邮件类型吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following newsletter types will be removed:</source>
        <translation>以下的新闻邮件类型将被删除:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Do not proceed unless you are sure.</source>
        <translation>除非您确定，否则不要继续。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_onhold</name>
    <message>
        <location filename="" line="0"/>
        <source>Confirm on hold entry removal</source>
        <translation>确定删除保留项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the on hold entry?</source>
        <translation>您确认希望删除该保留项目吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove the on hold entries?</source>
        <translation>您确认希望删除这些保留项目吗?</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following entries on hold will be removed:</source>
        <translation>以下的保留项目将被删除:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Do not proceed unless you are sure.</source>
        <translation>除非您确定，否则不要继续。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/contentstructuremenu</name>
    <message>
        <location filename="" line="0"/>
        <source>Archive</source>
        <translation>归档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Drafts</source>
        <translation>草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Ideas</source>
        <translation>计划</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>In progress</source>
        <translation>处理中</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Recurring</source>
        <translation>重复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Fold/Unfold</source>
        <translation>收起/展开</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter type list</source>
        <translation>新闻列表列表</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_object</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit newsletter</source>
        <translation>编辑新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter send date</source>
        <translation>新闻邮件发送日期</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter category</source>
        <translation>新闻邮件分类</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Pretext</source>
        <translation>前置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Posttext</source>
        <translation>后置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Design to use</source>
        <translation>设计视图</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Output format</source>
        <translation>输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send preview address</source>
        <translation>预览邮件地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send preview mobile number</source>
        <translation>预览移动电话号码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send preview</source>
        <translation>发送预览</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_onhold</name>
    <message>
        <location filename="" line="0"/>
        <source>Message on hold</source>
        <translation>保留的消息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send item data:</source>
        <translation>发送项目数据:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter ID</source>
        <translation>新闻邮件ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter name</source>
        <translation>新闻邮件名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sent to address</source>
        <translation>发送到地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Recipient name</source>
        <translation>收件人名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Set new sendout status</source>
        <translation>设置新发送状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Set</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back to on hold list</source>
        <translation>返回保留列表</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_recurrence</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter recurrence</source>
        <translation>新闻邮件重复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Recurrence type</source>
        <translation>重复类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Daily</source>
        <translation>每天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Weekdays</source>
        <translation>每周的某天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Monday</source>
        <translation>周一</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Tuesday</source>
        <translation>周二</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Wednesday</source>
        <translation>周三</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Thursday</source>
        <translation>周四</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Friday</source>
        <translation>周五</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Saturday</source>
        <translation>周六</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sunday</source>
        <translation>周日</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Weekly</source>
        <translation>每周</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Day of week</source>
        <translation>每周的某天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Monthly</source>
        <translation>每月</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Day of month</source>
        <translation>每月的某天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Deactivated</source>
        <translation>未激活</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit newsletter type</source>
        <translation>编辑新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Description</source>
        <translation>简介</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Use the description field to explaining the purpose of this newslettertype.</source>
        <translation>在简介中说明该新闻邮件类型的用途。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sender address</source>
        <translation>发件人地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date modifier</source>
        <translation>发送日期修改器</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Days</source>
        <translation>日</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hours</source>
        <translation>时</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Minutes</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Default pretext</source>
        <translation>默认前置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Default posttext</source>
        <translation>默认后置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Personalize newsletter</source>
        <translation>个性化的新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Valid content classes</source>
        <translation>合法的内容类</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allowed designs</source>
        <translation>允许的设计视图</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allowed output formats</source>
        <translation>允许的输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription lists</source>
        <translation>订阅列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related objects</source>
        <translation>关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add related object</source>
        <translation>添加关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove object location</source>
        <translation>删除对象位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No object relation selected</source>
        <translation>没有选择对象关联</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter suggestion inbox</source>
        <translation>新闻邮件意见信箱</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Change inbox placement</source>
        <translation>修改收件箱位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Delete inbox placement</source>
        <translation>删除收件箱位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No newsletter placement is specified</source>
        <translation>未指定新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add inbox placement</source>
        <translation>添加收件箱位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter placement</source>
        <translation>新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Change newsletter placement</source>
        <translation>修改新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Delete newsletter placement</source>
        <translation>删除新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add newsletter placement</source>
        <translation>添加新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The validation of your entries failed.</source>
        <translation>您的字段未通过验证。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_relation_newsletter</name>
    <message>
        <location filename="" line="0"/>
        <source>Related objects [%related_objects]</source>
        <translation>关联对象 [%related_objects]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related images [%related_images]</source>
        <translation>关联图片 [%related_images]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have permissions to view this object</source>
        <translation>您没有权限查看该对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>复制这段代码并粘贴至XML字段。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related files [%related_files]</source>
        <translation>关联文件 [%related_files]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>File type</source>
        <translation>文件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>XML code</source>
        <translation>XML代码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>您没有权限查看该对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related content [%related_objects]</source>
        <translation>关联内容 [%related_objects]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>没有对象关联至当前编辑的对象。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove the selected items from the list(s) above. Only the relations that will be removed. The items will not be deleted.</source>
        <translation>从上面的列表中删除所选项。只有对象关联会被删除。项目不会被删除。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add existing</source>
        <translation>添加现存项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add an existing item as a related object.</source>
        <translation>添加一个现存项目为关联对象。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upload new</source>
        <translation>上传新项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upload a file and add it as a related object.</source>
        <translation>上传新文件并添加为关联对象。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name of the subscriber.</source>
        <translation>订阅者名。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
        <translation>姓氏</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name of the subscriber.</source>
        <translation>订阅者姓氏。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email of the subscriber.</source>
        <translation>订阅者邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile number</source>
        <translation>移动电话号码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile number of the subscriber.</source>
        <translation>订阅者移动电话号码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>eZ Publish user</source>
        <translation>eZ Publish用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Apply the changes and return to subscription list view.</source>
        <translation>应用修改并返回订阅列表视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Vip</source>
        <translation>贵宾</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VIP status</source>
        <translation>贵宾状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Output format</source>
        <translation>输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Apply the changes and return subscription list view.</source>
        <translation>应用修改并返回订阅列表视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>取消修改并返回订阅列表视图。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_subscription_list</name>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name of the subscription list.</source>
        <translation>订阅列表名称。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Registration URL</source>
        <translation>注册URL</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>URL to subscription.</source>
        <translation>订阅URL。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Generate hash</source>
        <translation>生成哈希字符串</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Generate hash for URL.</source>
        <translation>生成URL哈希字符串。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related objects</source>
        <translation>关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add related object</source>
        <translation>添加关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove object location</source>
        <translation>删除对象位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No object relation selected</source>
        <translation>未选择对象关联</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Description</source>
        <translation>简介</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Use the description to explain the purpose of this subscription list.</source>
        <translation>在简介中说明该订阅列表的用途。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Login steps</source>
        <translation>登录步骤</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Require password</source>
        <translation>需要密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allow anonymous users</source>
        <translation>允许匿名用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Auto confirm registered users</source>
        <translation>自动确认注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Automatically confirm registered users</source>
        <translation>自动确认注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Automatically approve registered users</source>
        <translation>自动批准注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Apply the changes and return to the subscription list view.</source>
        <translation>应用修改并返回订阅列表视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>取消修改并返回订阅列表视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscriptions</source>
        <translation>订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OutputFormat</source>
        <translation>输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No subscriptions available</source>
        <translation>没有订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update settings.</source>
        <translation>更新配置。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_archive</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter archive</source>
        <translation>新闻邮件归档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send status</source>
        <translation>发送状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># sent</source>
        <translation># 已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># read</source>
        <translation># 已阅读</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview newsletter</source>
        <translation>预览新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date</source>
        <translation>发送日期</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_draft</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter drafts</source>
        <translation>新闻邮件草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send status</source>
        <translation>发送状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># sent</source>
        <translation># 已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># read</source>
        <translation># 已阅读</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date</source>
        <translation>发送日期</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_inprogress</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter in progress</source>
        <translation>新闻邮件正在处理中</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send status</source>
        <translation>发送状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># sent</source>
        <translation># 已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># read</source>
        <translation># 已阅读</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview newsletter</source>
        <translation>预览新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date</source>
        <translation>发送日期</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_bounce</name>
    <message>
        <location filename="" line="0"/>
        <source>Soft bounce</source>
        <translation>弱弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hard bounce</source>
        <translation>强弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter bounces</source>
        <translation>新闻邮件弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter</source>
        <translation>新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sent to address</source>
        <translation>发送到地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce count</source>
        <translation>弹回次数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce type</source>
        <translation>弹回类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce arrived</source>
        <translation>到达的弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No bounces detected</source>
        <translation>未检测到弹回记录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select bounce to clear bounce entry.</source>
        <translation>选择并删除弹回项目。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected bounce entries.</source>
        <translation>删除选中的弹回项目。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_onhold</name>
    <message>
        <location filename="" line="0"/>
        <source>Soft bounce</source>
        <translation>弱弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hard bounce</source>
        <translation>强弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send items on hold</source>
        <translation>发送保留项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter</source>
        <translation>新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sent to address</source>
        <translation>发送到地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Recipient name</source>
        <translation>收件人名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No messages on hold detected</source>
        <translation>未检测到保留消息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select an iten on hold to delete the scheduled sendout.</source>
        <translation>选择一个保留项目并删除发送计划。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected entries on hold.</source>
        <translation>删除选中的保留项目。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_type</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter types</source>
        <translation>新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created by</source>
        <translation>创建者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created on</source>
        <translation>创建于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No newsletters defined</source>
        <translation>没有定义新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select newsletter type for removal.</source>
        <translation>选择并删除新闻邮件类型。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter</source>
        <translation>新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit the &lt;%newsletter_name&gt; newsletter type.</source>
        <translation>编辑&lt;%newsletter_name&gt;新闻邮件类型。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected newsletter types.</source>
        <translation>删除选中的新闻邮件类型。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New newsletter type</source>
        <translation>新建新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create a new newsletter type.</source>
        <translation>创建新的新闻邮件类型。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter placement</source>
        <translation>新闻邮件位置</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_recurring</name>
    <message>
        <location filename="" line="0"/>
        <source>Recurring newsletter</source>
        <translation>重复新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send status</source>
        <translation>发送状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview newsletter</source>
        <translation>预览新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date</source>
        <translation>发送日期</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_subscriptions</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription lists</source>
        <translation>订阅列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscribers</source>
        <translation>订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select subscription list for removal.</source>
        <translation>选择并删除订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected subscription list.</source>
        <translation>删除选中的订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New subscription list</source>
        <translation>新建订阅列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create a new subscription list.</source>
        <translation>创建新的订阅列表。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_preview</name>
    <message>
        <location filename="" line="0"/>
        <source>Back</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Return to last view.</source>
        <translation>返回上一个视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Copy this item to the same location</source>
        <translation>复制该项目至相同位置</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/no_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>You are not subscribed to any newsletter or your profile is invalid.</source>
        <translation>您未订阅任何新闻邮件或您的个人信息不正确。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please check your profile link.</source>
        <translation>请检查您的个人信息链接。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/bounce_menu</name>
    <message>
        <location filename="" line="0"/>
        <source>Bounce management</source>
        <translation>弹回管理</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>On hold</source>
        <translation>保留</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>All</source>
        <translation>所有</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/eznewsletter_menu</name>
    <message>
        <location filename="" line="0"/>
        <source>List management</source>
        <translation>列表管理</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search subscriber</source>
        <translation>搜索订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce management</source>
        <translation>弹回管理</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newslettermenu</source>
        <translation>新闻邮件菜单</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newslettertypes</source>
        <translation>新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/newsletter_menu</name>
    <message>
        <location filename="" line="0"/>
        <source>Newslettertypes</source>
        <translation>新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/robinson_menu</name>
    <message>
        <location filename="" line="0"/>
        <source>List management</source>
        <translation>列表管理</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list</source>
        <translation>Opt-out列表</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/pending</name>
    <message>
        <location filename="" line="0"/>
        <source>Your email address has not been confirmed yet.</source>
        <translation>您的邮件地址还未被确认。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please click on the subscription confirmation link you received by email to validate your account.</source>
        <translation>请点击您邮件中的订阅确认链接并验证您的帐号。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/register_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>Register subscription</source>
        <translation>注册订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name of the subscriber.</source>
        <translation>订阅者名。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
        <translation>姓氏</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name of the subscriber.</source>
        <translation>订阅者姓氏。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile number</source>
        <translation>移动电话号码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile number of the subscriber.</source>
        <translation>订阅者移动电话号码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email of the subscriber.</source>
        <translation>订阅者邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Output format</source>
        <translation>输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscribe</source>
        <translation>订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add to subscription.</source>
        <translation>添加到订阅。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/register_subscription_info</name>
    <message>
        <location filename="" line="0"/>
        <source>Thank you for registering</source>
        <translation>感谢您的注册</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Thank you for subscribing to %name.</source>
        <translation>感谢您订阅%name。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit robinsonlist entry</source>
        <translation>编辑robinsonlist项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>List</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type of data:</source>
        <translation>数据类型:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email address or mobile number</source>
        <translation>邮件地址或移动电话号码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email address or mobile phone number.</source>
        <translation>邮件地址或移动电话号码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Apply the changes and return to opt-out list.</source>
        <translation>应用修改并返回opt-out视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel the changes and return to the opt-out list.</source>
        <translation>取消修改并返回opt-out视图。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_import</name>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list import</source>
        <translation>导入opt-out列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upload file</source>
        <translation>上传文件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First row is label</source>
        <translation>第一行为标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import to list:</source>
        <translation>导入至列表:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type of data:</source>
        <translation>数据类型:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import options:</source>
        <translation>导入选项:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Data to import</source>
        <translation>要导入的数据</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>RowNum</source>
        <translation>行号</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile</source>
        <translation>移动电话</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select row to import</source>
        <translation>选择要导入的行</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel subscription import.</source>
        <translation>取消订阅导入。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import selected</source>
        <translation>导入所选项</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_show</name>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list</source>
        <translation>Opt-out列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Filter list by local/global entries:</source>
        <translation>用局部/全局项目过滤列表:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>List type:</source>
        <translation>列表类型:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show all</source>
        <translation>显示所有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Filter  subscription list.</source>
        <translation>过滤  订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select entry for removal.</source>
        <translation>选择要删除的项目。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit entry.</source>
        <translation>编辑项目。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection.</source>
        <translation>反选。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile</source>
        <translation>移动电话</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select entry for removal</source>
        <translation>选择要删除的项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected entry.</source>
        <translation>删除选中的项目。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New entry</source>
        <translation>新建项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create a new entry.</source>
        <translation>创建新的项目。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import from file</source>
        <translation>自文件导入</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import entries from file.</source>
        <translation>自文件导入项目。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_user</name>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list settings</source>
        <translation>Opt-out列表配置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email address</source>
        <translation>电子邮件地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile phone number</source>
        <translation>移动电话号码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add to list</source>
        <translation>添加至列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Apply the changes and return to the opt-out list.</source>
        <translation>应用修改并返回opt-out视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove from list</source>
        <translation>从列表中删除</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/registration</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter subscription verification</source>
        <translation>新闻邮件订阅验证</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hi %name

Thank you for subscribing to the list %listName. To activate your subscription, visit this link: %link .

To edit your settings, visit : %settingsLink</source>
        <translation>%name，您好

感谢您订阅%listName。请访问这个链接:%link激活您的订阅。

请访问:%settingsLink修改您的配置</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter subscription activation</source>
        <translation>激活新闻邮件订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hello,

Thank you for subscribing to %listName.</source>
        <translation>您好，

感谢您订阅%listName。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/unscubscription</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter subscription deactivation</source>
        <translation>撤销新闻邮件订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hello,

Your subscription to %listName was deactivated.

Thank you for using this service.</source>
        <translation>您好，

您%listName的订阅已经被撤销。

感谢您使用我们的服务。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_activate</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription activated</source>
        <translation>订阅已被激活</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hi %name

Your subscription to %subscriptionName has been activated.</source>
        <translation>%name，您好

您的%subscriptionName订阅已被激活。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_import</name>
    <message>
        <location filename="" line="0"/>
        <source>Import subscribers to subscription list &lt;%subscription_list_name&gt;</source>
        <translation>导入订阅者至订阅列表&lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upload file</source>
        <translation>上传文件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First row is label</source>
        <translation>第一行为标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>CSV field delimiter</source>
        <translation>CSV字段分割符</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import subscriptions</source>
        <translation>导入订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
        <translation>姓氏</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile</source>
        <translation>移动电话</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select row to import</source>
        <translation>选择要导入的行</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel subscription import.</source>
        <translation>取消订阅导入。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import selected</source>
        <translation>导入所选项</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_list</name>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Login steps</source>
        <translation>登录步骤</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Require password</source>
        <translation>需要密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allow anonymous users</source>
        <translation>允许匿名用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Automatically confirm registered users</source>
        <translation>自动确认注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Automatically approve registered users</source>
        <translation>自动批准注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related objects</source>
        <translation>关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No related object specified</source>
        <translation>未指定关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Description</source>
        <translation>简介</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit current subscription list.</source>
        <translation>编辑当前订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status:</source>
        <translation>状态:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show all</source>
        <translation>显示所有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Filter  subscription list.</source>
        <translation>过滤  订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VIP:</source>
        <translation>贵宾:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscriber list</source>
        <translation>订阅者列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
        <translation>姓氏</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VIP</source>
        <translation>贵宾</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirmed</source>
        <translation>已确认</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approved</source>
        <translation>已批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Removed</source>
        <translation>已删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select subscriber for removal</source>
        <translation>选择要删除的订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>n/a</source>
        <translation>不可用</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected subscription.</source>
        <translation>删除选中的订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New subscription</source>
        <translation>新建订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create a new subscription.</source>
        <translation>创建新的订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import CSV</source>
        <translation>导入CSV</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import contact from CSV file.</source>
        <translation>自CSV文件导入联络人。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_search</name>
    <message>
        <location filename="" line="0"/>
        <source>Search result is greater than 50, please check your search text!</source>
        <translation>搜索结果超过50条，请检查您的搜索关键自!</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription search</source>
        <translation>订阅搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Enter name or email address:</source>
        <translation>输入名称或电子邮件地址:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search text.</source>
        <translation>关键字。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search subscription.</source>
        <translation>搜索订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscriber list</source>
        <translation>订阅者列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
        <translation>姓氏</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile</source>
        <translation>移动电话</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirmed</source>
        <translation>已确认</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approved</source>
        <translation>已批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Removed</source>
        <translation>已删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select subscriber for removal</source>
        <translation>选择要删除的订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>n/a</source>
        <translation>不可用</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
        <translation>删除所选项</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected subscription.</source>
        <translation>删除选中的订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New subscription</source>
        <translation>新建订阅</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/unsubscribe</name>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email of the subscriber.</source>
        <translation>订阅者邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unsubscribe</source>
        <translation>退订</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unsubscribe subscription</source>
        <translation>退订订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel and discard.</source>
        <translation>取消并放弃。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_addsubscription</name>
    <message>
        <location filename="" line="0"/>
        <source>Please select a list you want to add:</source>
        <translation>请选择一个要添加的列表:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No subscriptions available</source>
        <translation>没有订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add Subscription</source>
        <translation>添加订阅</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_password</name>
    <message>
        <location filename="" line="0"/>
        <source>Please enter your password</source>
        <translation>请输入您的密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Submit</source>
        <translation>提交</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update settings</source>
        <translation>更新配置</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_profile</name>
    <message>
        <location filename="" line="0"/>
        <source>Your settings</source>
        <translation>您的配置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Firstname</source>
        <translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile</source>
        <translation>移动电话</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update settings.</source>
        <translation>更新配置。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_user</name>
    <message>
        <location filename="" line="0"/>
        <source>Your subscriptions</source>
        <translation>您的订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscribed</source>
        <translation>已订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Output format</source>
        <translation>输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No subscriptions available</source>
        <translation>没有订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update settings.</source>
        <translation>更新配置。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/view_newsletter_bounce</name>
    <message>
        <location filename="" line="0"/>
        <source>Soft bounce</source>
        <translation>弱弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hard bounce</source>
        <translation>强弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter bounces</source>
        <translation>新闻邮件弹回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sent item data:</source>
        <translation>发送项目数据:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sent</source>
        <translation>已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter ID</source>
        <translation>新闻邮件ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription ID</source>
        <translation>订阅ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter name</source>
        <translation>新闻邮件名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscriber data:</source>
        <translation>订阅者数据:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscriber name</source>
        <translation>订阅者名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce details:</source>
        <translation>弹回细节:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce response message:</source>
        <translation>弹回消息:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription data:</source>
        <translation>订阅数据:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription list name</source>
        <translation>订阅列表名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Bounce count</source>
        <translation>弹回次数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Set new subscription status</source>
        <translation>设置新的订阅状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Set</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back to bounce list</source>
        <translation>返回弹回列表</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/view_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter type</source>
        <translation>新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Description</source>
        <translation>简介</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sender address</source>
        <translation>发件人地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send date modifier</source>
        <translation>发送日期修改器</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Days</source>
        <translation>日</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hours</source>
        <translation>时</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Minutes</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Default pretext</source>
        <translation>默认前置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There is no default pretext defined.</source>
        <translation>未定义默认的前置文字。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Default posttext</source>
        <translation>默认后置文字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There is no default posttext defined.</source>
        <translation>未定义默认的后置文字。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Default subscription</source>
        <translation>默认订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription lists</source>
        <translation>订阅列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allowed designs</source>
        <translation>允许的设计视图</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Allowed output formats</source>
        <translation>允许的输出格式</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Related objects</source>
        <translation>关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No related object specified</source>
        <translation>未指定关联对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Suggestion inbox</source>
        <translation>意见信箱</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No inbox set</source>
        <translation>未设置收件箱</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter placement</source>
        <translation>新闻邮件位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No newsletter placement is specified.</source>
        <translation>未指定新闻邮件位置。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit this newsletter type.</source>
        <translation>编辑新闻邮件类型。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create newsletter</source>
        <translation>创建新闻邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter lists</source>
        <translation>新闻邮件列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># sent</source>
        <translation># 已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source># read</source>
        <translation># 已阅读</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <location filename="" line="0"/>
        <source>Year</source>
        <translation>年</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Month</source>
        <translation>月</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Day</source>
        <translation>日</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Hour</source>
        <translation>时</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Minute</source>
        <translation>分</translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit &lt;%subscription_name&gt; [Subscription]</source>
        <translation>编辑 &lt;%subscription_name&gt; [Subscription]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit &lt;%subscription_list_name&gt; [Subscription list]</source>
        <translation>编辑 &lt;%subscription_list_name&gt; [Subscription list]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>URL : %url</source>
        <translation>URL : %url</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit the &lt;%newsletter_name&gt; subscription list.</source>
        <translation>编辑 the &lt;%newsletter_name&gt; subscription list。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out lists ( %number_emails Emails / %number_mobile Mobile numbers )</source>
        <translation>Opt-out列表 ( %number_emails Emails / %number_mobile Mobile numbers )</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subscription list &lt;%subscription_list_name&gt;</source>
        <translation>订阅列表 &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit the &lt;%newsletter_name&gt; subscription.</source>
        <translation>编辑&lt;%newsletter_name&gt;订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newslettertype: %newsletter_type_name [%newsletter_type_id]</source>
        <translation>新闻邮件类型: %newsletter_type_name [%newsletter_type_id]</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No subscription.</source>
        <translation>无订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Activate Subscription</source>
        <translation>激活订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>Email address &quot;%address&quot; did not validate.</source>
        <translation>电子邮件地址&quot;%address&quot;为经过验证。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit newsletter type</source>
        <translation>编辑新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have not defined a name for this newslettertype</source>
        <translation>您未为该新闻邮件类型命名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have to select at least one allowed output format.</source>
        <translation>您必须选择至少一种允许的输出格式。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have to select at least one design.</source>
        <translation>您必须选择至少一种设计视图。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have to select at least one subscription list.</source>
        <translation>您必须选择至少一个订阅列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have to select a valid newsletter placement.</source>
        <translation>您必须选择一个正确的新闻邮件位置。</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>Email address or mobile phone number is in opt-out list!</source>
        <translation>Opt-out列表包含电子邮件地址或移动电话号码!</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email Address or mobile phone number is in Robinsonlist!</source>
        <translation>Robinson列表中包含电子邮件地址或移动电话号码!</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit subscription</source>
        <translation>编辑订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_subscription_list</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription lists</source>
        <translation>订阅列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/eznewslettertype/output_format</name>
    <message>
        <location filename="" line="0"/>
        <source>Plain text</source>
        <translation>纯文本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>HTML w/external images</source>
        <translation>HTML(包含外部图片)</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>SMS</source>
        <translation>短信</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_archive</name>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter type</source>
        <translation>查看新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_draft</name>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter type</source>
        <translation>查看新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_inprogress</name>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter type</source>
        <translation>查看新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_newsletterbounce</name>
    <message>
        <location filename="" line="0"/>
        <source>Messages on hold</source>
        <translation>保留的消息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter items on hold</source>
        <translation>保留的新闻邮件项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter bounce entry</source>
        <translation>查看新闻邮件弹回项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter types</source>
        <translation>新闻邮件类型</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter bounces</source>
        <translation>查看新闻邮件弹回项目</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter types</source>
        <translation>新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_recuring</name>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter type</source>
        <translation>查看新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_subscriptions</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription lists</source>
        <translation>订阅列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/login_steps</name>
    <message>
        <location filename="" line="0"/>
        <source>Confirm user</source>
        <translation>确认用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm and approve user</source>
        <translation>确认并批准用户</translation>
    </message>
</context>
<context>
    <name>eznewsletter/modify_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>The given email address is already in use. Please use another.</source>
        <translation>提供的电子邮件已被使用。请使用其他邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password did not match</source>
        <translation>密码不匹配</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No subscription</source>
        <translation>无订阅</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Activate subscription</source>
        <translation>激活订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/newsletter/edit_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>You must provide a valid email address.</source>
        <translation>您必须提供一个正确的电子邮件地址。</translation>
    </message>
</context>
<context>
    <name>eznewsletter/object_status</name>
    <message>
        <location filename="" line="0"/>
        <source>Draft</source>
        <translation>草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Published</source>
        <translation>发布</translation>
    </message>
</context>
<context>
    <name>eznewsletter/ouput_formats</name>
    <message>
        <location filename="" line="0"/>
        <source>External HTML</source>
        <translation>外部HTML</translation>
    </message>
</context>
<context>
    <name>eznewsletter/output_formats</name>
    <message>
        <location filename="" line="0"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>SMS</source>
        <translation>短信</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>External HTML</source>
        <translation>外部HTML</translation>
    </message>
</context>
<context>
    <name>eznewsletter/recurrencetype</name>
    <message>
        <location filename="" line="0"/>
        <source>Daily</source>
        <translation>每天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Weekly</source>
        <translation>每周</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Monthly</source>
        <translation>每月</translation>
    </message>
</context>
<context>
    <name>eznewsletter/register_subscription</name>
    <message>
        <location filename="" line="0"/>
        <source>You are already a registered subscriber</source>
        <translation>您已经是注册的订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have renewed your subscription.</source>
        <translation>您已经续订了您的订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Passwords did not match.</source>
        <translation>密码不匹配。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You must enter a first name.</source>
        <translation>您必须输入您的名字。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You must enter a last name.</source>
        <translation>您必须输入您的姓氏。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You must provide a valid email address.</source>
        <translation>您必须提供一个正确的电子邮件地址。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You&apos;re already a registered subscriber</source>
        <translation>您已经是注册的订阅者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email address or mobile phone number is in opt-out list. Subscribing is not possible.</source>
        <translation>Opt-out列表包含电子邮件地址或移动电话号码。无法订阅。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Register subscription</source>
        <translation>注册订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Please enter a valid email.</source>
        <translation>请输入一个正确的电子邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please fill in all required fields.</source>
        <translation>请填写所有必填项。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list edit</source>
        <translation>编辑Opt-out列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_import</name>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list</source>
        <translation>Opt-out列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_show</name>
    <message>
        <location filename="" line="0"/>
        <source>Opt-out list</source>
        <translation>Opt-out列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_user</name>
    <message>
        <location filename="" line="0"/>
        <source>Entered email address is already in the list.</source>
        <translation>输入的电子邮件已存在于列表中。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Entered email address is not in the list.</source>
        <translation>输入的电子邮件地址不在列表中。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please enter a valid email.</source>
        <translation>请输入一个正确的电子邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Entered mobile phone number is already in the list.</source>
        <translation>输入的移动电话号码已存在于列表中。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Entered mobile phone number is not in the list.</source>
        <translation>输入的移动电话号码不在列表中。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>An error occured, no updates were made.</source>
        <translation>发生一个错误，更新失败。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Updates complete.</source>
        <translation>更新完成。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You must fill in at least one field.</source>
        <translation>您必须至少填写一个字段。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Robinsonlist settings</source>
        <translation>Robinson列表配置</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_action</name>
    <message>
        <location filename="" line="0"/>
        <source>Synchronize</source>
        <translation>同步</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Only add new</source>
        <translation>只添加新记录</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_entrysource</name>
    <message>
        <location filename="" line="0"/>
        <source>Local</source>
        <translation>局部</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>External data</source>
        <translation>外部数据</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_entrytype</name>
    <message>
        <location filename="" line="0"/>
        <source>Email address</source>
        <translation>电子邮件地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mobile phone number</source>
        <translation>移动电话号码</translation>
    </message>
</context>
<context>
    <name>eznewsletter/send_status</name>
    <message>
        <location filename="" line="0"/>
        <source>Not sent</source>
        <translation>未发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Building sendout list</source>
        <translation>创建发送列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sending</source>
        <translation>发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Finished</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Stopped</source>
        <translation>中断</translation>
    </message>
</context>
<context>
    <name>eznewsletter/senditem_status</name>
    <message>
        <location filename="" line="0"/>
        <source>Send mailing</source>
        <translation>发送邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mark as sent</source>
        <translation>标志为已发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>On hold</source>
        <translation>保留</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_activate</name>
    <message>
        <location filename="" line="0"/>
        <source>Activate subscription</source>
        <translation>激活订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_import</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription list</source>
        <translation>订阅列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_list</name>
    <message>
        <location filename="" line="0"/>
        <source>Subscription list</source>
        <translation>订阅列表</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_search</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit Subscription</source>
        <translation>编辑订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_status</name>
    <message>
        <location filename="" line="0"/>
        <source>Pending</source>
        <translation>等待</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirmed</source>
        <translation>已确认</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Approved</source>
        <translation>已批准</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Removed by self</source>
        <translation>已被自己删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Removed by admin</source>
        <translation>已经被管理员删除</translation>
    </message>
</context>
<context>
    <name>eznewsletter/user_settings</name>
    <message>
        <location filename="" line="0"/>
        <source>The given email address is already in use. Please use another.</source>
        <translation>提供的电子邮件已被使用。请使用其他邮件。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password did not match</source>
        <translation>密码不匹配</translation>
    </message>
</context>
<context>
    <name>eznewsletter/user_settings_password.tpl</name>
    <message>
        <location filename="" line="0"/>
        <source>Activate subscription</source>
        <translation>激活订阅</translation>
    </message>
</context>
<context>
    <name>eznewsletter/view_newslettertype</name>
    <message>
        <location filename="" line="0"/>
        <source>View newsletter type</source>
        <translation>查看新闻邮件类型</translation>
    </message>
</context>
<context>
    <name>eznewsletter/vip_type</name>
    <message>
        <location filename="" line="0"/>
        <source>Not set</source>
        <translation>未设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Silver</source>
        <translation>白银</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Gold</source>
        <translation>黄金</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Platinum</source>
        <translation>铂金</translation>
    </message>
</context>
<context>
    <name>eznewsletter/workflow/event</name>
    <message>
        <location filename="" line="0"/>
        <source>Newsletter read</source>
        <translation>已阅读新闻邮件</translation>
    </message>
</context>
<context>
    <name>eznewslettert</name>
    <message>
        <location filename="" line="0"/>
        <source>Back to subscription list</source>
        <translation>返回订阅列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>RowNum</source>
        <translation>行号</translation>
    </message>
</context>
</TS>
