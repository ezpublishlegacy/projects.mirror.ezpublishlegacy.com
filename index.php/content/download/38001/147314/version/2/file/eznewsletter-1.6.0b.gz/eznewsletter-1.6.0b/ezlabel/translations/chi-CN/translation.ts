<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name>extension/ezlabel</name>
    <message>
        <location filename="" line="0"/>
        <source>Private label</source>
        <translation>私有标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global label</source>
        <translation>全局标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove label</source>
        <translation>删除标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unassign label</source>
        <translation>删除标记指派</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>List all labels</source>
        <translation>列出所有标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Assign</source>
        <translation>指派</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/create</name>
    <message>
        <location filename="" line="0"/>
        <source>Label</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Labels defined</source>
        <translation>已定义的标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global</source>
        <translation>全局</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Private</source>
        <translation>私有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Assign</source>
        <translation>指派</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Label</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Labels defined</source>
        <translation>已定义的标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/list</name>
    <message>
        <location filename="" line="0"/>
        <source>Label</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Labels defined</source>
        <translation>已定义的标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Private label</source>
        <translation>私有标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global label</source>
        <translation>全局标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There are no labels.</source>
        <translation>无标记。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global</source>
        <translation>全局</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Private</source>
        <translation>私有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/toolbar/full</name>
    <message>
        <location filename="" line="0"/>
        <source>Hide label view</source>
        <translation>隐藏标记试图</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Labels</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show label view</source>
        <translation>显示标记视图</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove label</source>
        <translation>删除标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unassign label</source>
        <translation>删除标记指派</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Private label</source>
        <translation>私有标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global label</source>
        <translation>全局标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No Labels assigned.</source>
        <translation>无指派的标记。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>List all labels</source>
        <translation>列出所有标记</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Assign</source>
        <translation>指派</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Global</source>
        <translation>全局</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Private</source>
        <translation>私有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No labels assigned.</source>
        <translation>无指派的标记。</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/view_full</name>
    <message>
        <location filename="" line="0"/>
        <source>Assigned objects</source>
        <translation>指派的对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Objects assigned to label</source>
        <translation>指派到标记的对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There are no objects assigned to this label.</source>
        <translation>无指派到该标记的对象。</translation>
    </message>
</context>
<context>
    <name>extension/label</name>
    <message>
        <location filename="" line="0"/>
        <source>Labels</source>
        <translation>标记</translation>
    </message>
</context>
</TS>
