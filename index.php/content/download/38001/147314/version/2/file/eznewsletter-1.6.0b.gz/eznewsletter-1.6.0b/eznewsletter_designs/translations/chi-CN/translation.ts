<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout</name>
    <message>
        <location filename="" line="0"/>
        <source>Interested? Learn more ...</source>
        <translation>感兴趣吗? 了解更多...</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sorry, article not found!</source>
        <translation>抱歉，未找到文章!</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Topics</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>back</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upcoming Events</source>
        <translation>近期活动</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Legal Information</source>
        <translation>法律信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unsubscribe</source>
        <translation>退订</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upcoming events</source>
        <translation>近期活动</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Legal information</source>
        <translation>法律信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>TOPICS this week</source>
        <translation>本周主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>TOPICS</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>EVENTS THIS MONTH</source>
        <translation>本月活动</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Profil</source>
        <translation>简介</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout/sms</name>
    <message>
        <location filename="" line="0"/>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>您好，新闻内容更新。请访问%url_to_newsletter查看新闻邮件。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite</name>
    <message>
        <location filename="" line="0"/>
        <source>back</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sorry, article not found!</source>
        <translation>抱歉，未找到文章!</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout</name>
    <message>
        <location filename="" line="0"/>
        <source>Read the full story ...</source>
        <translation>阅读全文...</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Frontpage</source>
        <translation>首页</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unsubscribe</source>
        <translation>退订</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Also today</source>
        <translation>也包括今天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Contact us</source>
        <translation>联系我们</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>TOPICS this week</source>
        <translation>本周主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>TOPICS</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Read more</source>
        <translation>了解更多</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Profil</source>
        <translation>简介</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout/sms</name>
    <message>
        <location filename="" line="0"/>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>您好，网站内容更新。访问%url_to_newsletter查看我们的新闻邮件。</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/node/view/newsletter</name>
    <message>
        <location filename="" line="0"/>
        <source>Read the full story ...</source>
        <translation>阅读全文...</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout</name>
    <message>
        <location filename="" line="0"/>
        <source>Read more</source>
        <translation>了解更多</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Only</source>
        <translation>只有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Buy this product now</source>
        <translation>立刻购买该商品</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Contact us</source>
        <translation>联系我们</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unsubscribe</source>
        <translation>退订</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ONLY</source>
        <translation>只有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Profil</source>
        <translation>简介</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout/sms</name>
    <message>
        <location filename="" line="0"/>
        <source>Hello, we have some products available which might interrest you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>您好，我们有您或许感兴趣的商品。访问%url_to_newsletter查看我们的新闻邮件。</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <location filename="" line="0"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Price:</source>
        <translation>价格:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your price:</source>
        <translation>您的价格:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You save:</source>
        <translation>节省:</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Price</source>
        <translation>价格</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User account information</source>
        <translation>用户帐户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User ID</source>
        <translation>用户ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Login</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
</context>
</TS>
