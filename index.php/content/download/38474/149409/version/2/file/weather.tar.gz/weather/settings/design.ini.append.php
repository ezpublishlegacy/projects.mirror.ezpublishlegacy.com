<?php /*

[ExtensionSettings]
DesignExtensions[]=weather

*/ ?>