<?php /*

[ModuleSettings]
ExtensionRepositories[]=weather

*/ ?>