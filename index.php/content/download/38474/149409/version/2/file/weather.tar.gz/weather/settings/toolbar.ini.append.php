<?php /*

[Tool]
AvailableToolArray[]=weather

[Tool_weather]
title=Weather
show_subtree=2
location_code=NOXX0034
unit=c
displaycityname_check=yes
displaydate_check=yes
displayicon_check=yes
displaytemperature_check=yes
caching_duration=600

[Tool_weather_description]
title=Title
show_subtree=Show in subtree
location_code=Location Code (developer.yahoo.com/weather)
unit=Unit (c/f)
displaycityname_check=Show City name
displaydate_check=Show date
displayicon_check=Show weather condition icon
displaytemperature_check=Show temperature
caching_duration=Caching Duration (sec)

*/ ?>