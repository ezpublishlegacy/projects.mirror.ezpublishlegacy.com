<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezxmlinstaller
AvailableDataTypes[]=ezfeatureselect

*/ ?>
