<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=topandroid

*/
?>
