<?php
$Module = array(
        "name" => 'topandroid'
);

$ViewList = array();
$ViewList['test'] = array(
        'functions' => array( 'test' ),
        'script'  => 'test.php'
);

$FunctionList[ 'test' ] = array();

?>
