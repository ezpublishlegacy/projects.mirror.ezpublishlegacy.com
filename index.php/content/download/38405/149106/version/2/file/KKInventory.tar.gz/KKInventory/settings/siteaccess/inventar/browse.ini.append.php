<?php /* #?ini charset="iso-8859-1"?

[AddRelatedObjectToDataType]
StartNode=44
SelectionType=single
ReturnType=ObjectID

[NewObjectAddNodeAssignment]
StartNode=49
SelectionType=single
ReturnType=NodeID
ActionName=SelectParentNode
StartNode_classgroup[2]=users

*/ ?>
