<?php /* #?ini charset="iso-8859-1"?

#[sortlist]
#Source=node/view/full.tpl
#MatchFile=sortlist.tpl
#Subdir=templates
#Match[class]=1

#[view]
#Source=node/view/full.tpl
#MatchFile=view.tpl
#Subdir=templates
#Match[class]=2

[bygning]
Source=node/view/full.tpl
MatchFile=bygning.tpl
Subdir=templates
Match[class]=75

[kommune]
Source=node/view/full.tpl
MatchFile=kommune.tpl
Subdir=templates
Match[class]=81

[rom]
Source=node/view/full.tpl
MatchFile=rom.tpl
Subdir=templates
Match[class]=72

[floy]
Source=node/view/full.tpl
MatchFile=floy.tpl
Subdir=templates
Match[class]=79

[objekt]
Source=node/view/full.tpl
MatchFile=objekt.tpl
Subdir=templates
Match[class]=73

[kunst]
Source=node/view/full.tpl
MatchFile=kunst.tpl
Subdir=templates
Match[class]=76

[privat]
Source=node/view/full.tpl
MatchFile=privat.tpl
Subdir=templates
Match[class]=74

[edit_objekt]
Source=content/edit.tpl
MatchFile=edit_objekt.tpl
Subdir=templates
Match[class]=73

[edit_privat]
Source=content/edit.tpl
MatchFile=edit_privat.tpl
Subdir=templates
Match[class]=74

[edit_rom]
Source=content/edit.tpl
MatchFile=edit_rom.tpl
Subdir=templates
Match[class]=72

[edit_kunst]
Source=content/edit.tpl
MatchFile=edit_kunst.tpl
Subdir=templates
Match[class]=76

*/ ?>
