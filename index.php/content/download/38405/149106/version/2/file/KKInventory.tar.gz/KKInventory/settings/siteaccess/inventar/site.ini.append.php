<?php /* #?ini charset="iso-8859-1"?

[SiteSettings]
#IndexPage=/content/view/full/<start_node>
LoginPage=embedded
SiteName=Inventardatabase
#SiteURL=<www.domain.com>

[SiteAccessSettings]
RequireUserLogin=false

[DesignSettings]
SiteDesign=kk

[ContentSettings]
TranslationList=
EditDirtyObjectAction=usecurrent

[DatabaseSettings]
DatabaseImplementation=ezmysql
Server=localhost
#Database=<db>
#User=<user>
#Password=<password>
Charset=iso-8859-1
Socket=disabled

[RegionalSettings]
Locale=eng-GB
ContentObjectLocale=nor-NO
TextTranslation=enabled

*/ ?>
