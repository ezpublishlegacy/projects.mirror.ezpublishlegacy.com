<?php /*
#
# $Id: workflow.ini.append.php 18 2010-06-11 13:46:53Z nfrp $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.2/extension/autostatus/settings/workflow.ini.append.php $
#

[EventSettings]
ExtensionDirectories[]=autostatus
AvailableEventTypes[]=event_autostatus

*/ ?>