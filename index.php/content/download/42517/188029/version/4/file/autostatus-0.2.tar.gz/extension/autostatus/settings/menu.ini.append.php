<?php /*
#
# $Id: menu.ini.append.php 50 2011-06-29 06:36:24Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.2/extension/autostatus/settings/menu.ini.append.php $
#

[NavigationPart]
Part[autostatus]=Auto status

[TopAdminMenu]
Tabs[]=autostatus

[Topmenu_autostatus]
NavigationPartIdentifier=autostatus
Name=Auto status
Tooltip=Auto status
URL[]
URL[default]=autostatus/log
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[navigation]=true
Shown[default]=true
Shown[browse]=true
PolicyList[]=autostatus/log

*/ ?>
