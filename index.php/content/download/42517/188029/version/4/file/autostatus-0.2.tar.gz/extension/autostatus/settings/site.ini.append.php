<?php /*
#
# $Id: site.ini.append.php 18 2010-06-11 13:46:53Z nfrp $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.2/extension/autostatus/settings/site.ini.append.php $
#

[RegionalSettings]
TranslationExtensions[]=autostatus

*/ ?>