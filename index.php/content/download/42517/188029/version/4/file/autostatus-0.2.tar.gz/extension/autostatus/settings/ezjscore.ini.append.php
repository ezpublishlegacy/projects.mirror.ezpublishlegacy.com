<?php /*
#
# $Id: ezjscore.ini.append.php 43 2011-06-27 20:38:05Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.2/extension/autostatus/settings/ezjscore.ini.append.php $
#

[ezjscServer]
FunctionList[]=autostatus

[ezjscServer_autostatus]
Class=autostatusAjaxFunctions

*/ ?>
