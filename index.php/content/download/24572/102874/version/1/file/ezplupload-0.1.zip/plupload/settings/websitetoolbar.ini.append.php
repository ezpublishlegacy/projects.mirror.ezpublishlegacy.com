<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=plupload
IncludeInView[plupload]=full

*/ ?>
