<?php
/**
 *
 * @author G. Giunta
 * @version $Id: contentstats.php 18 2010-04-17 14:29:21Z gg $
 * @copyright (C) G. Giunta 2008-2010
 * @license Licensed under GNU General Public License v2.0. See file license.txt
 *
 * @todo add more classes of content that have no stats in main admin interface
 * @todo add support for ezsurvey, ezflow, eznewsletter contents
 */

$module = $Params['Module'];

// rely on system policy instead of creating our own, but allow also PolicyOmitList
$ini = eZINI::instance();
if ( !in_array( 'sysinfo/contentstats', $ini->variable( 'RoleSettings', 'PolicyOmitList' ) ) )
{
    $user = eZUser::currentUser();
    if ( !$user->hasAccessTo( 'setup', 'system_info' ) )
    {
        return $Module->handleError( eZError::KERNEL_ACCESS_DENIED, 'kernel' );
    }
}

$contentTypes = array(
    'Objects (including users)' => array( 'table' => 'ezcontentobject' ),
    'Users' => array( 'table' => 'ezuser' ),
    'Content Classes' => array( 'table' => 'ezcontentclass' ),
    'Information Collections' => array( 'table' => 'ezinfocollection' ),
);

$db = eZDB::instance();
$contentList = array();
foreach( $contentTypes as $key => $desc )
{
    $sql = 'SELECT COUNT(*) AS NUM FROM ' .  $desc['table'];
    /*if ( isset($desc['groupby']) )
    {
        $sql. = '';
    }*/
    $count = $db->arrayQuery( $sql );
    $contentList[$key] = $count[0]['NUM'];
}

require_once( "kernel/common/template.php" );
$tpl = templateInit();
$tpl->setVariable( 'title', 'Content stats' );
$tpl->setVariable( 'contentlist', $contentList );

$Result = array();
$Result['content'] = $tpl->fetch( "design:sysinfo/contentstats.tpl" ); //var_dump($cacheFilesList);

$Result['left_menu'] = 'design:parts/sysinfo/menu.tpl';
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'SysInfo', 'Content stats' ) ) );

?>
