﻿<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>System Information</source>
        <comment>Navigation part</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SysInfo</name>
    <message>
        <source>Cache search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
