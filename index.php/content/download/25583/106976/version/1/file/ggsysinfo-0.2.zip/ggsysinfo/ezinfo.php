<?php
class ggsysinfoInfo
{
    static function info()
    {
        return array( 'Name' => "ggsysinfo",
                      'Version' => "0.2",
                      'Copyright' => "Copyright (C) 2008-2010 G. Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>