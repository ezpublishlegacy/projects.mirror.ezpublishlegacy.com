<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ggsysinfo

[RegionalSettings]
TranslationExtensions[]=ggsysinfo

[RoleSettings]
PolicyOmitList[]=sysinfo

*/ ?>