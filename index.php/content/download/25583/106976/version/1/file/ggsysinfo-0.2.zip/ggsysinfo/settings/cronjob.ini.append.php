<?php /*

[CronjobSettings]
ExtensionDirectories[]=ggsysinfo

*/ ?>