<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=enhancedselection2
AvailableDataTypes[]=sckenhancedselection


*/
?>
