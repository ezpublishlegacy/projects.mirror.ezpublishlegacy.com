<?php
/*

[ExtensionSettings]
DesignExtensions[]=enhancedselection2

*/
?>
