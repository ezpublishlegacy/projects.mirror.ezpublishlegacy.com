<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=nxc_cmisclient
ModuleList[]=cmis_client

*/ ?>
