<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=saarchive

[CronjobPart-saarchive]
Scripts[]=saarchive_archive_content.php

*/ ?>

