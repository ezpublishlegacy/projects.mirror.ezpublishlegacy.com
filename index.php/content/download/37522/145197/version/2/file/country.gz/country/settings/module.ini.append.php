<?php
#?ini charset="iso-8859-1"?
# eZ publish configuration file for modules

[ModuleSettings]
ExtensionRepositories[]=country
?>