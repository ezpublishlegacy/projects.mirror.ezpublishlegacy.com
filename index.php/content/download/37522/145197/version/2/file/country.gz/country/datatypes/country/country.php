<?php
//
// Copyright (C) 1999-2006 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//
// Author:       Paul Forsyth
// Version:      $Id$

class Country
{
	// Database id for the country
	var $ID;

	// Country name
	var $Name;

	// Code (ALPHA 2)
	var $Code;

	// Internation Dialling Code
	var $IDC;

    /*!
     Constructor
    */
    function Country($id, $name, $code, $idc=0)
    {
    	$this->ID = $id;
    	$this->Name = $name;
    	$this->Code = $code;
    	$this->IDC = $idc;
    }

    function hasAttribute( $attr )
    {
        return ( $attr == 'id' or
                 $attr == 'name' or
                 $attr == 'code' or
                 $attr == 'idc' );
    }

    function &attribute( $attr )
    {
        switch( $attr )
        {
            case 'id':
            {
            	return $this->ID;
            } break;
            case 'name':
            {
            	return $this->Name;
            } break;
            case 'code':
            {
            	return $this->Code;
            } break;
            case 'idc':
            {
            	return $this->IDC;
            } break;
            default:
                return null;
        }
        return null;
    }

    function attributes()
    {
    	return array( 'id' , 'name', 'code', 'idc' );
    }
}
?>