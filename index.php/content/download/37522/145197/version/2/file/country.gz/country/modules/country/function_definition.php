<?php
//
// Copyright (C) 1999-2006 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//
// Author:       Paul Forsyth
// Version:      $Id$

$FunctionList = array();
$FunctionList['countries'] = array( 'name' => 'countries',
                                       'operation_types' => array( 'read' ),
                                       'call_method' => array( 'include_file' => 'extension/country/modules/country/countryfunctioncollection.php',
                                                               'class' => 'CountryFunctionCollection',
                                                               'method' => 'fetchCountries' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( ) );

$FunctionList['country'] = array( 'name' => 'country',
                                       'operation_types' => array( 'read' ),
                                       'call_method' => array( 'include_file' => 'extension/country/modules/country/countryfunctioncollection.php',
                                                               'class' => 'CountryFunctionCollection',
                                                               'method' => 'fetchCountry' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( array( 'name' => 'code',
                                                                     'type' => 'string',
                                                                     'required' => true ) ) );

?>