<?php
//
// Copyright (C) 1999-2006 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//
// Author:       Paul Forsyth
// Version:      $Id$

include_once( "lib/ezdb/classes/ezdb.php" );
include_once( "extension/country/datatypes/country/country.php" );

class CountryFunctionCollection
{
    /*!
     Constructor
    */
    function CountryFunctionCollection()
    {
    }

    function &instance()
    {
      $instance =& $GLOBALS["CountryFunctionCollection"];

      if ( get_class( $instance ) != "CountryFunctionCollection" )
      {
          $instance = new CountryFunctionCollection();

          $GLOBALS['CountryFunctionCollection'] =& $instance;
      }

      return $instance;
    }

   	function fetchCountries()
    {
    	// Fetch from the db
		$db =& eZDB::instance();

        $query = "SELECT * FROM country ORDER BY country_name";

		$resultArray =& $db->arrayQuery( $query );

		$countries = array();
		foreach ( $resultArray as $resultRow )
		{
			$countries[$resultRow['country_code_alpha_2']] = new Country($resultRow['id'],
																		 $resultRow['country_name'],
																         $resultRow['country_code_alpha_2'],
																         $resultRow['idc']);
		}

		return array( 'result' => $countries);
    }

   	function fetchCountry($code)
    {
    	// Fetch from the db
		$db =& eZDB::instance();

        $query = "SELECT * FROM country WHERE country_code_alpha_2='$code'";

		$resultArray =& $db->arrayQuery( $query );

		if ( count( $resultArray ) == 1 && $resultArray !== false )
        {
			$country = new Country($resultArray[0]['id'],
								   $resultArray[0]['country_name'],
						           $resultArray[0]['country_code_alpha_2'],
						           $resultArray[0]['idc']);

			return array( 'result' => $country);
        }
        else
        {
            eZDebug::writeError( "Unable to find country from code ($code)");
            return null;
        }
    }

	function fetchCountryIDC($code)
    {
		$countryResult = $this->fetchCountry($code);
		$country =& $countryResult['result'];

		return $country->IDC;
   }
}
?>