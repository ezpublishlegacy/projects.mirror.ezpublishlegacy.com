<?php
//
// Copyright (C) 1999-2006 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//
// Author:       Paul Forsyth
// Version:      $Id$

include_once( "kernel/classes/ezdatatype.php" );

define( "EZ_DATATYPESTRING_COUNTRY", "country" );
define( "EZ_DATATYPESTRING_DEFAULT_COUNTRY_FIELD", "data_text1" );
define( "EZ_DATATYPESTRING_MULTI_FIELD", "data_int1" );
define( "EZ_DATATYPESTRING_DEFAULT_COUNTRY_VARIABLE", "_ezstring_default_value_" );

class CountryType extends eZDataType
{
    function CountryType()
    {
        $this->eZDataType( EZ_DATATYPESTRING_COUNTRY, ezi18n( 'extension/datatypes', "Country", 'Datatype name' ),
                                                      array( 'serialize_supported' => true,
                                                             'object_serialize_map' => array( 'data_text' => 'text' )));
    }

    function initializeObjectAttribute( &$contentObjectAttribute, $currentVersion, &$originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
        else
        {
            $contentClassAttribute =& $contentObjectAttribute->contentClassAttribute();
            $default = $contentClassAttribute->attribute( EZ_DATATYPESTRING_DEFAULT_COUNTRY_FIELD );
            if ( $default !== "" )
            {
                $contentObjectAttribute->setAttribute( "data_text", $default );
            }
        }
    }

    function validateObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        return $this->validateAttributeHTTPInput( $http, $base, $contentObjectAttribute, false );
    }

    function validateCollectionAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        return $this->validateAttributeHTTPInput( $http, $base, $contentObjectAttribute, true );
    }

    function validateAttributeHTTPInput( &$http, $base, &$contentObjectAttribute, $isInformationCollector )
    {
        if ( $http->hasPostVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $country =& $http->postVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $classAttribute =& $contentObjectAttribute->contentClassAttribute();

            if ( $isInformationCollector == $classAttribute->attribute( 'is_information_collector' ) )
            {
                if ( $contentObjectAttribute->validateIsRequired() )
                {
                    if( count($country) == 1 && $country[0] == "" )
                    {
                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                             'A valid country is required.',
                                                                             'CountryType' ) );
                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                    }
                }
            }
        }
        return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
    }

    function fetchObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $data =& $http->postVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( "id" ) );

            $countryString = implode( ',', $data );

            $contentObjectAttribute->setAttribute( "data_text", $countryString );

            return true;
        }
        return false;
    }

    function fetchCollectionAttributeHTTPInput( &$collection, &$collectionAttribute, &$http, $base, &$contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $data =& $http->postVariable( $base . '_country_data_text_' . $contentObjectAttribute->attribute( "id" ) );

            $countryString = implode( ',', $data );

            $collectionAttribute->setAttribute( "data_text", $countryString );

            return true;
        }
        return false;
    }

    function fetchClassAttributeHTTPInput( &$http, $base, &$classAttribute )
    {
        $attributeContent =& $this->classAttributeContent( $classAttribute );
        $classAttributeID = $classAttribute->attribute( 'id' );
        $isMultipleSelection = false;

        if ( $http->hasPostVariable( $base . "_country_ismultiple_value_" . $classAttributeID ) )
        {
            $classAttribute->setAttribute( EZ_DATATYPESTRING_MULTI_FIELD, 1 );
        }
        else
        {
            // Test if the class is in a temporary state. If so dont change the current value
            if ($classAttribute->attribute('version')!=EZ_CLASS_VERSION_STATUS_TEMPORARY)
            {
                $classAttribute->setAttribute( EZ_DATATYPESTRING_MULTI_FIELD, 0 );
            }
        }

        if ( $http->hasPostVariable( $base . "_country_default_value_". $classAttributeID ) )
        {
            $defaultValue = $http->postVariable( $base . "_country_default_value_". $classAttributeID );
            $classAttribute->setAttribute( EZ_DATATYPESTRING_DEFAULT_COUNTRY_FIELD, $defaultValue );
        }
    }

    function hasObjectAttributeContent( &$contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( 'data_text' ) ) != '';
    }

    /*!
     Store the content.
    */
    function storeObjectAttribute( &$attribute )
    {
    }

    /*!
     Returns the content.
    */
    function &objectAttributeContent( &$contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /*!
     Returns the text.
    */
    function title( &$contentObjectAttribute )
    {
        return  $contentObjectAttribute->attribute( "data_text" );
    }

    function isIndexable()
    {
        return true;
    }

    function isInformationCollector()
    {
        return true;
    }
}

eZDataType::register( EZ_DATATYPESTRING_COUNTRY, "countrytype" );

?>
