var classezjscoreresp =
[
    [ "serialize", "classezjscoreresp.html#a05bc80f2df211e0a52b69942ed6938f7", null ],
    [ "$content_type", "classezjscoreresp.html#a7ae36febcf3bd79755f068b3f60e37d5", null ]
];