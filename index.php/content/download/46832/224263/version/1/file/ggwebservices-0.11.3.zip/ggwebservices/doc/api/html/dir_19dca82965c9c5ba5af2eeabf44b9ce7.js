var dir_19dca82965c9c5ba5af2eeabf44b9ce7 =
[
    [ "flickr_client", "dir_90a25802419decee920309f55badf34b.html", null ],
    [ "lastfm_client", "dir_729948dcfe1cfa007d9205ad0a990012.html", null ],
    [ "soap_server", "dir_d4661b6121e531d57e5dcf0b5c480566.html", null ],
    [ "solr_client", "dir_e494fd30d2f920a347fdd68d71092ef5.html", null ],
    [ "template_client", "dir_7afdc981a282abab24ae71da50dd9d5e.html", null ],
    [ "twitter_client", "dir_db8e087aa979cd34572d3ac1faabb1b4.html", null ],
    [ "yql_client", "dir_69386a251b57ae46b34d4bc300096fa8.html", null ]
];