var dirs =
[
    [ "autoloads", "dir_22bd9d4158161524a23f6402b9cb9b00.html", null ],
    [ "classes", "dir_23db2c463a132e304a4430dcfd4112d6.html", null ],
    [ "cronjobs", "dir_9ee0ad1d1aea91fcb0a8cc8a6996cce1.html", null ],
    [ "doc", "dir_542bb5e14fd2e80108d1aee3aecfed78.html", "dir_542bb5e14fd2e80108d1aee3aecfed78" ],
    [ "jsonrpc", "dir_151ce68e35872c6df6f941c25cfd31ca.html", null ],
    [ "lib", "dir_158c7e96626dfd75d6dc11bffd20aa60.html", "dir_158c7e96626dfd75d6dc11bffd20aa60" ],
    [ "modules", "dir_ee00da5067ab36244598e5d5c24fe011.html", "dir_ee00da5067ab36244598e5d5c24fe011" ],
    [ "rest", "dir_bb5f101a5d0bc249a2e5ccc122faee9c.html", null ],
    [ "tests", "dir_134a9445943d87eb4a349adab21e263d.html", null ],
    [ "xmlrpc", "dir_4ddeb94280a391cd3b01174cffea2f0b.html", null ]
];