var execute_8php =
[
    [ "$module", "execute_8php.html#ac531301c55a8d8b6c7613597218ff482", null ],
    [ "$protocol", "execute_8php.html#ac01bf1cf041487498864d054b991f570", null ],
    [ "$wsclass", "execute_8php.html#a47590aba854d7817d72fcfea28b66474", null ],
    [ "$wsINI", "execute_8php.html#a8b92f2c6fbdb05abdfa3368ecbabb4a7", null ]
];