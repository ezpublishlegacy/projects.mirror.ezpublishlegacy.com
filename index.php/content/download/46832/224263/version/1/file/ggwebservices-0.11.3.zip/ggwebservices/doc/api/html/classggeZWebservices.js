var classggeZWebservices =
[
    [ "appendLogEntry", "classggeZWebservices.html#ab46f40192200ab8de5940088efba59d3", null ],
    [ "checkAccess", "classggeZWebservices.html#a90739e7f5e8ef9e817aeb695dea32b69", null ],
    [ "checkAccessToServer", "classggeZWebservices.html#a776a5ad0bc0b31ce99510c1fbb605be1", null ],
    [ "classInspect", "classggeZWebservices.html#aa838b5f8816547760cbf2446698d67ad", null ],
    [ "configFileByProtocol", "classggeZWebservices.html#a876d4752d55ec2e60a2eb13b512712d2", null ],
    [ "getMethodsList", "classggeZWebservices.html#a1d45309221be62392766e0ef40648783", null ],
    [ "getServersList", "classggeZWebservices.html#abc5a5cc1b3b86a7f195ddf913d870f0d", null ],
    [ "isLoggingEnabled", "classggeZWebservices.html#a3062bdecc399eb673c26a94a2f995701", null ],
    [ "isRegisterAllProtocolsFunctionsEnabled", "classggeZWebservices.html#a50dc74af2bb4ed54def0d020efc2b87b", null ],
    [ "methodsWSDL", "classggeZWebservices.html#af429d6d6f8d7a6282cfe545c680d7426", null ],
    [ "methodsXSD", "classggeZWebservices.html#ae49540c23935c52c9aa6d27ba3ab1bc3", null ],
    [ "registerAvailableMethods", "classggeZWebservices.html#a871f1f60b275fc7d796e89cf1c82a012", null ],
    [ "typeFromDocComment", "classggeZWebservices.html#a1fa6ac240608d440617119f31ebd66bf", null ],
    [ "$debuglevel", "classggeZWebservices.html#a9027b2c5bfaca6e95a0d97897fbeb0d6", null ],
    [ "$errorlevels", "classggeZWebservices.html#a2f48ef73cc6500d8d0ea3e4e4099c246", null ],
    [ "$protocolconfigs", "classggeZWebservices.html#a82a80dd5bb6279cd0175971e7ebdad2f", null ],
    [ "$serverprotocols", "classggeZWebservices.html#afe45e2599bb2d048b1f2a39d31024469", null ]
];