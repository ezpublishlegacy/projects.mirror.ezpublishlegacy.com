var proxy_8php =
[
    [ "$access", "proxy_8php.html#ad7fd03ae69de40b00cc4758c23a4404e", null ],
    [ "$module", "proxy_8php.html#ac531301c55a8d8b6c7613597218ff482", null ],
    [ "$namespaceURI", "proxy_8php.html#a61b7c378ddf6dbafcc1068ffe0d65695", null ],
    [ "$protocol", "proxy_8php.html#ac01bf1cf041487498864d054b991f570", null ],
    [ "$remoteserver", "proxy_8php.html#a51c6d7d4662dd3257ef2d2213bd0cd78", null ],
    [ "$request", "proxy_8php.html#abb35c8495a232b510389fa6d7b15d38a", null ],
    [ "$response", "proxy_8php.html#af4b6fb1bbc77ccc05f10da3b16935b99", null ],
    [ "$server", "proxy_8php.html#ad135cc8a47e55f0829949cf62214170f", null ],
    [ "$serverClass", "proxy_8php.html#a6d8046a1467cd1dd3c9c18c8e1db26a2", null ],
    [ "$user", "proxy_8php.html#a787c4c5d23bd2422a90e1705bc16165b", null ]
];