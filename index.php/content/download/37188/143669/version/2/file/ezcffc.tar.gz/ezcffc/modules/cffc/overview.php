<?php

include_once( 'kernel/common/template.php' );

$tpl = templateInit();

if( $Params["GroupClassID"] )
	$GroupClassID = $Params["GroupClassID"];
else
	$GroupClassID = 1;

$list_group = eZContentClassGroup::fetchList( false, $asObject );	
	
$list = eZContentClassClassGroup::fetchClassList( 0, $GroupClassID, $asObject = true );

$tpl->setVariable( "groupclasses", $list );
$tpl->setVariable( "groups", $list_group );

$Result = array();
$Result['content'] = $tpl->fetch( 'design:cffc/overview.tpl' );
$Result['left_menu'] = 'design:cffc/cffc_menu.tpl';
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'extension/cffc', 'Generate form from class to template *.tpl' ) ) );
?>