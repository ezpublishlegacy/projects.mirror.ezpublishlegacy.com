<?php

include_once( 'kernel/common/template.php' );

// get attributes class
$ClassID = $Params["ClassID"];
$class = eZContentClass::fetch( $ClassID, true, eZContentClass::VERSION_STATUS_DEFINED );
$attributes = $class->fetchAttributes();

// file name get from url
$filename = strtolower( $Params['CLASSNAME'] ) . '.tpl';

$tpl = templateInit();

$tpl->setVariable( "attributes", $attributes );

$content = $tpl->fetch( 'design:cffc/generate_template.tpl' );

$contentLength = strlen( $content );
//$mimeType = 'application/octet-stream';
$mimeType = 'application/xhtml+xml';
$charSet = 'utf-8';

$version = eZPublishSDK::version();

header( "Pragma: " );
header( "Cache-Control: " );
header( "Content-Length: $contentLength" );
header("Content-type:$mimeType; charset=$charSet");
header( "X-Powered-By: eZ Publish $version" );
header( "Content-Disposition: attachment; filename=$filename" );
header( "Content-Transfer-Encoding: binary" );
ob_end_clean();
print( $content );
fflush();
eZExecution::cleanExit();

?>