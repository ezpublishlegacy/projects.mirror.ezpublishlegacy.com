<?php
//
// Creation Date : 13-06-2009
// Author : Lukasz Klejnberg
// www.idealsolutions.pl
//
// This module allows for easy generate form from class and save to *.tpl which can be used in override/templates/full/*
//

$Module = array( 'name' => 'cffc', 'variable_params' => true );

$ViewList = array();
$ViewList['overview'] = array(
    'script' => 'overview.php',
    'default_navigation_part' => 'ezcffc',
    'ui_context' => 'view',
	'unordered_params' => array( 'groupclassid' => 'GroupClassID' ) );

$ViewList['generate_template'] = array(
    'script' => 'generate_template.php',
    'default_navigation_part' => 'ezcffc',
    'ui_context' => 'view',
    'unordered_params' => array( 'classid' => 'ClassID', 'classname' => 'CLASSNAME' ) );

?>
