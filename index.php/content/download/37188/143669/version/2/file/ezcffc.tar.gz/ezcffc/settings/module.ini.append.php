[ModuleSettings]
ExtensionRepositories[]=ezcffc
ModuleList[]=ezcffc