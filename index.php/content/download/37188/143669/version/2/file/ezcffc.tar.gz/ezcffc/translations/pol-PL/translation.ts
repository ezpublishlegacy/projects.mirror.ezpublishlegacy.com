<!DOCTYPE TS><TS>
<context>
    <name>extension/cffc</name>
    <message>
        <source>Edit the &amp;lt;%class_name&amp;gt; class.</source>
        <translation>Edytuj klasę &amp;lt;%class_name&amp;gt;.</translation>
    </message>
    <message>
        <source>List class</source>
        <translation>Lista klas</translation>
    </message>
    <message>
        <source>Generate form from class to template *.tpl</source>
        <translation>Generowanie formularza z klasy do szablonu *.tpl</translation>
    </message>
    <message>
        <source>edit</source>
        <translation>edytuj</translation>
    </message>
    <message>
        <source>Generate form from class to template</source>
        <translation>Generuj formularz z klasy do szablonu</translation>
    </message>
    <message>
        <source>generate</source>
        <translation>generuj</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Generate form from class to template *.tpl</source>
        <translation>Generowanie formularza z klasy do szablonu *.tpl</translation>
    </message>
    <message>
        <source>Template form</source>
        <translation>Szablon formularza</translation>
    </message>
</context>
</TS>
