[NavigationPart]
Part[ezcffc]=CFFC - TPL form

[TopAdminMenu]
Tabs[]=ezcffc

[Topmenu_ezcffc]
NavigationPartIdentifier=ezcffc
Name=CFFC - TPL form
URL[]
URL[default]=cffc/overview
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true