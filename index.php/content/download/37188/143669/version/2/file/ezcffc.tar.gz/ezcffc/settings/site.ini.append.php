[RegionalSettings]
TranslationExtensions[]=ezcffc

[RoleSettings]
PolicyOmitList[]=cffc/overview
PolicyOmitList[]=cffc/generate_template