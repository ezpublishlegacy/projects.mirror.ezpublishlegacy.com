<?php /* #?ini charset="utf-8"? 
# tell ez publish to grant this access to everybody 

[RoleSettings] 
PolicyOmitList[]=ezpdfviewer/do

[TemplateSettings]
ExtensionAutoloadPath[]=ezpdfviewer
*/ ?>




