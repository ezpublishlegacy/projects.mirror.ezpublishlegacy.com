<?php /* #?ini charset="utf-8"? 
# transmit to eZ, to search for designs in ezorder
[ExtensionSettings] 
DesignExtensions[]=ezpdfviewer
*/ ?>
