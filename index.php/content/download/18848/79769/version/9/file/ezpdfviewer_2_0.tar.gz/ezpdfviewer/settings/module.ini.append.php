<?php /* #?ini charset="utf-8"? 
# tell ez publish to search after modules in the extension ezorder
[ModuleSettings]
ExtensionRepositories[]=ezpdfviewer
*/ ?>


