<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=personlist
AvailableDataTypes[]=sckpersonlist

*/
?>
