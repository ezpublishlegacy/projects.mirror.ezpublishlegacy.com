<?php
/*

[ExtensionSettings]
DesignExtensions[]=personlist

*/
?>
