<?php
/*

[SelectUserNode]
StartNode=users
SelectionType=single
ReturnType=NodeID

*/
?>