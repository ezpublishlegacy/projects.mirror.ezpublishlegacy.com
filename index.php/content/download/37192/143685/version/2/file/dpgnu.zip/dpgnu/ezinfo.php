<?php

class dpgnuInfo
{
    function info()
    {
        return array( 'Name' => 'dP Google News URL extension',
                      'Version' => '1.0.0',
                      'Copyright' => 'Copyright (C) 2007 Damien Pitard',
                      'License' => 'GNU General Public License v2.0'
                    );
    }
}
?>