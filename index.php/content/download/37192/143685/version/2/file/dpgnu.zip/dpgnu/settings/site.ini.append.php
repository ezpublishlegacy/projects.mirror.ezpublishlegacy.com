<?php /* #?ini charset="iso-8859-1"?

[URLTranslator]

# A list of extension which have url filter support.
Extensions[]=dpgnu

# List of active filters, each entry must contain the name of the class
# which implements the filtering. The name of the file is a lowercase
# variant of the classname.
# e.g. the class MyFilter would have the filename myfilter.php
# Note: All filters are placed in the subdirectory urlfilters in extension directory.
Filters[]=dpgnu

*/ ?>