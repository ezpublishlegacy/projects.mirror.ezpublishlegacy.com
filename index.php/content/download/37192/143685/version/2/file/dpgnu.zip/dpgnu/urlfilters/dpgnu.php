<?php

include_once( 'kernel/classes/ezurlaliasfilter.php' );

class dPGNU extends eZURLAliasFilter
{
	function dPGNU()
	{		
	}
	
    function process( $text, &$languageObject, &$caller )
    {
        if ( get_class ( $caller ) == 'ezcontentobjecttreenode' )
        {
			$ini =& eZINI::instance( 'dpgnu.ini' );
			$classes = $ini->variable( 'GNUSettings', 'Classes' );
			if ( in_array( $caller->attribute( 'class_identifier' ), $classes ) )
			{
				include_once( 'lib/ezi18n/classes/ezchartransform.php' );
				$sep  = eZCharTransform::wordSeparator();
        		$text .= $sep.$caller->attribute( 'node_id' );
			}
        }
        return $text;
    }
}

?>