<?php /*

[ExtensionSettings]
DesignExtensions[]=ggsysinfo

*/?>