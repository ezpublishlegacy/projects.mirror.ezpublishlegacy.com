#?ini charset="iso-8859-1"?

[googlesitemap]
PageLayout=googlesitemap_pagelayout.tpl