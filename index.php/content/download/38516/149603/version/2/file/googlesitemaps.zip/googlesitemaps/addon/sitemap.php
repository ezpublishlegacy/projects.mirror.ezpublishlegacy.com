<?php

  // upload this script to your web server as http://<SiteURL>/sitemap.php

  header("Content-Type: text/xml");
  $url = urldecode($_GET['url']);

  $fp = fopen($url,"r");

  while(!feof($fp))
  {
    echo( fread($fp,1024) );
  }

  fclose($fp);

  exit();

?>

