#?ini charset="iso-8859-1"?
[ContentSettings]
CachedViewModes=full;sitemap;pdf;googlesitemap
ComplexDisplayViewModes=sitemap;googlesitemap

[TemplateSettings]
ExtensionAutoloadPath[]=googlesitemaps
