GoogleSiteMaps Extension Read Me

What is the GoogleSiteMaps extension?
================================================
GoogleSiteMaps Extension produce a sitemap xml for Google.
https://www.google.com/webmasters/sitemaps/docs/en/protocol.html

Name   : GoogleSiteMaps Extension
Version: 0.1
Author : Sergey A. Shishkin
Date   : 20.01.2006
URL    : http://www.competent.name/proekty/ez_publish/googlesitemaps_extension
e-mail : classic.ru@gmail.com
ICQ    : #28582606

Installation and Configuration
================================================
Please read the INSTALL.TXT file for installation and configuration instructions.


Content
================================================
Files in this extension :

  /settings/design.ini.append.php                          
  /settings/fetchalias.ini.append.php
  /settings/googlesitemaps.ini.append.php
  /settings/layout.ini.append.php
  /settings/site.ini.append.php

  /design/standard/templates/googlesitemap_pagelayout.tpl
  /design/standard/templates/node/view/googlesitemaps.tpl

  /autoloads/ezextlinkfixoperator.php
  /autoloads/eztemplateautoload.php

  /addon/sitemap.php (it is addon, not a part of extension)

USING Google SiteMaps
================================================
Type this url in your browser
   http://<SiteURL>(/index.php)(/<siteacceess>)/layout/set/googlesitemap/content/view/googlesitemaps/2
You will see full sitemap of your site, beginnig on node:2 (root)
If you want build sitemap of subtree - use another node_id
http://<SiteURL>(/index.php)(/<siteacceess>)/layout/set/googlesitemap/content/view/googlesitemaps/<node_id>

Example: http://www.competent.name/layout/set/googlesitemap/content/view/googlesitemaps/2

1. Register account and login into Google Sitemaps
   https://www.google.com/webmasters/sitemaps/
2. Add your site to Google Sitemaps
3. Append sitemap of your site

ps. Some tunings
================================================
If you will append to Gooogle Sitemaps link to your sitemap like
http://<SiteURL>(/index.php)(/<siteacceess>)/layout/set/googlesitemap/content/view/googlesitemaps/<node_id>
...
It will look like not good in Google Sitemaps interface.
Google will show FULL URL to your sitemap as SiteURL.
Then you may do following steps
1. Copy file sitemap.php from addon folder to <root_of_ezpublish>
2. Edit .htaccess file (if you using it)

RewriteRule !\.(gif|jpe?g|png|css|js|htm|html|swf)|var(.+)storage.pdf(.+)\.pdf$ index.php
Change to
RewriteRule !sitemap\.php|\.(gif|jpe?g|png|css|js|htm|html|swf)|var(.+)storage.pdf(.+)\.pdf$ index.php

Now you can use link http://<SiteURL>/sitemap.php?url=http://<SiteURL>(/index.php)(/<siteacceess>)/layout/set/googlesitemap/content/view/googlesitemaps/<node_id>

Example: http://www.competent.name/sitemap.php?url=http://www.competent.name/layout/set/googlesitemap/content/view/googlesitemaps/2/