<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/googlesitemaps/autoloads/ezextlinkfixoperator.php',
                                    'class' => 'eZExtLinkFixOperator',
                                    'operator_names' => array( 'extlinkfix' ) );
?>