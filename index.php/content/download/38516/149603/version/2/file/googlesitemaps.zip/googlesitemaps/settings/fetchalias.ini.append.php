[googlesitemaps]
Module=content
FunctionName=list
Parameter[sort_by]=sort_by
Parameter[parent_node_id]=parent_node_id
Parameter[class_filter_type]=class_filter_type
Parameter[class_filter_array]=class_filter_array
Parameter[main_node_only]=main_node_only