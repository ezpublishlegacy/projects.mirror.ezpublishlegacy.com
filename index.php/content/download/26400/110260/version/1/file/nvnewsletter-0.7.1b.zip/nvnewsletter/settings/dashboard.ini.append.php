<?php /*

[DashboardSettings]
DashboardBlocks[]=nvnewsletter

[DashboardBlock_nvnewsletter]
Priority=60
NumberOfItems=10
PolicyList[]=nvnewsletter/read

*/ ?> 