ALTER TABLE `nvnewsletter_receiverfields`  ENGINE = InnoDB;
ALTER TABLE `nvnewsletter_receivers_has_fields`  ENGINE = InnoDB;
ALTER TABLE `nvnewsletter_receivers_has_groups`  ENGINE = InnoDB;
ALTER TABLE `nvnewsletter_receivers_has_groups_unsub`  ENGINE = InnoDB;
