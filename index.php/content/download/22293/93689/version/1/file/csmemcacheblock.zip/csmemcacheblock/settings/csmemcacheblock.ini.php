<?php /*

[CSMemCacheBlock]
# Caching engine
# memcache, or apc possible
CachingEngine=apc

[CachingOptions_memcache]
path=memcache
options[]
options[host]=localhost
options[port]=11211
class=ezcCacheStorageMemcachePlain

[CachingOptions_apc]
path=apc
options[]
class=ezcCacheStorageApcPlain


*/ ?>