<?php
//
// Definition of CSMemcacheBlockFunction class
//
// Created on: <24-Dec-2009 15:06:33 jr>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 4.x.x
// COPYRIGHT NOTICE: Copyright (C) 1999-2009 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

class CSMemcacheBlockFunction
{
    public function CSMemcacheBlockFunction( $functionName = 'memcache-block' )
    {
        $this->FunctionName = $functionName;  
              
        $INI   = eZINI::instance( 'csmemcacheblock.ini' );	
                    
		$CacheEngine = $INI->variable('CSMemCacheBlock','CachingEngine');
        $Options = $INI->variable('CachingOptions_'.$CacheEngine,'options');
        // String parameters cannot be passed to ezcomponents, nonsense to convert to integer here....
        foreach ($Options as $key => $option)
        {
            if (in_array($key,array('port')))
            {
                $Options[$key] = (int)$option;
            }
        }
        
        $this->cacheEnginePath = $INI->variable('CachingOptions_'.$CacheEngine,'path');
        $this->cacheEngineClass = $INI->variable('CachingOptions_'.$CacheEngine,'class');
        
        $this->cacheEngineOptions = $Options;
        $this->cacheEngineInstances = array();    
     
    }

    public function functionList()
    {
        return array( $this->FunctionName );
    }

    public function functionTemplateHints()
    {
        return array( $this->FunctionName => array( 'parameters'           => true,
                                                    'static'               => false,
                                                    'transform-children'   => true,
                                                    'tree-transformation'  => false,
                                                    'transform-parameters' => true ) );
    }

    public function process( $tpl, &$textElements, $functionName, $functionChildren, $functionParameters, $functionPlacement, $rootNamespace, $currentNamespace )
    {
        switch ( $functionName )
        {
            case $this->FunctionName:
            {
                $regenerationIsForced = false;
               
                if( $this->keyIsValid( $tpl,
                                       $rootNamespace,
                                       $currentNamespace,
                                       $functionParameters,
                                       $functionPlacement )
                    and
                    $this->ttlIsValid( $tpl,
                                       $rootNamespace,
                                       $currentNamespace,
                                       $functionParameters,
                                       $functionPlacement ) )
                {
                    $blockKeyString = $this->generateBlockKeyString( $tpl, $rootNamespace, $currentNamespace, $functionParameters, $functionPlacement );

                    eZDebug::writeNotice( $blockKeyString, 'CSMemcacheBlockFunction::process' );
                    
                    $cacheDir = $this->cacheBaseSubdir();
                    $fileName = $this->generateUniqueFilename( $blockKeyString );                                          
                    
                    if (!key_exists('csmemcache_ttl_'.$this->TTLInSeconds(),$this->cacheEngineInstances))
                    {    
                        ezcCacheManager::createCache( 'csmemcache_ttl_'.$this->TTLInSeconds(),  $this->cacheEnginePath.'_'.$this->TTLInSeconds(), $this->cacheEngineClass, array_merge($this->cacheEngineOptions,array('ttl' => $this->TTLInSeconds())));                        
                        $this->cacheEngineInstances['csmemcache_ttl_'.$this->TTLInSeconds()] = ezcCacheManager::getCache( 'csmemcache_ttl_'.$this->TTLInSeconds() );
                        
                    }
                    
                    $this->cacheEngine =  $this->cacheEngineInstances['csmemcache_ttl_'.$this->TTLInSeconds()];                                          
                                     
                    // file exists ?
                    if( ($htmlContents = $this->cacheEngine->restore( $fileName )) === false )
                    {                        
                        eZDebug::writeNotice( 'file does not exists : ' . $blockKeyString, 'CSMemcacheBlockFunction::process' );
                        $htmlContents = $this->processChildren( $tpl, $functionChildren, $rootNamespace, $currentNamespace );
                        $this->cacheEngine->store( $fileName, $htmlContents );
                        
                        $textElements[] = $htmlContents;
                    }
                    else
                    {
                        // expired ?
                        if( $regenerationIsForced )
                        {
                            eZDebug::writeNotice( 'file expired : ' . $blockKeyString, 'CSMemcacheBlockFunction::process' );
                            $htmlContents = $this->processChildren( $tpl, $functionChildren, $rootNamespace, $currentNamespace );                            
                            $this->cacheEngine->store( $fileName, $htmlContents );
                            $textElements[] = $htmlContents;   
                        }
                        else
                        {                    
                            eZDebug::writeNotice( 'file valid : ' . $blockKeyString, 'CSMemcacheBlockFunction::process' );
                            $textElements[] = $htmlContents;  
                        }
                       
                    }                    
                    
                }
                
            } break;
        }
    }
    
    
    private function generateUniqueFilename( $SIBlockKey )
    {
        $uniqueFilename = md5( $SIBlockKey  );

        eZDebug::writeNotice( $uniqueFilename, 'CSMemcacheBlockFunction::generateUniqueFilename' );

        return $uniqueFilename;
    }
    
    public function keyIsValid( $tpl, $rootNamespace, $currentNamespace, $functionParameters, $functionPlacement )
    {
        $keyString = $tpl->elementValue( $functionParameters['key'], $rootNamespace, $currentNamespace, $functionPlacement );

        if( !$keyString )
        {
            return false;
        }

        return true; 
    }
    
    
    public function ttlIsValid( $tpl, $rootNamespace, $currentNamespace, $functionParameters, $functionPlacement )
    {
        $ttlString = $tpl->elementValue( $functionParameters['ttl'], $rootNamespace, $currentNamespace, $functionPlacement );

            
        $this->setTTL( $ttlString );

        if( !$this->validateTTL() )
        {
            $tpl->error( $this->FunctionName, 'memcache-block : The TTL is not valid', $functionPlacement );

            return false;
        }

        return true;
    }
    
    public function setTTL( $ttlString )
    {
        $this->TTL = $ttlString;
    }

    public function setKey( $keyString )
    {
        $this->Key = $keyString;
    }

    public function setSrc( $filePath )
    {
        $this->Src = $filePath;
    }

    public function validateKey()
    {
        if( !$this->Key )
        {
            return false;
        }

        return true;
    }

    public function TTLInSeconds()
    {
        $ttlInfos = $this->parseTTL();

        switch( $ttlInfos['ttl_unit'] )
        {
            case 'h' : $ttlInSeconds = $ttlInfos['ttl_value'] * 3600      ; break;
            case 'm' : $ttlInSeconds = $ttlInfos['ttl_value'] * 60        ; break;
            case 's' : $ttlInSeconds = $ttlInfos['ttl_value']             ; break;
            default  : $ttlInSeconds = $ttlInfos['ttl_value'] * 3600 * 24 ; break;
        }

        return $ttlInSeconds;
    }

    public function fileIsExpired( $mtime )
    {
        $TTLValue = $this->TTLInSeconds();
        return ( time() - $mtime ) >= $TTLValue;
    }

    public function parseTTL()
    {
        $ttlUnit  = substr( $this->TTL, -1);
        $ttlValue = (int)$this->TTL;

        return array( 'ttl_unit'  => $ttlUnit,
                      'ttl_value' => $ttlValue );
    }

    public function validateTTL()
    {
        // available time units are :
        // h : hours
        // m : minutes
        // s : seconds
        // d : days
        // units can not be combined

        $possibleUnits = array( 'h', 'm', 's', 'd' );

        $ttlInfos = $this->parseTTL();

        if( !in_array( $ttlInfos['ttl_unit'], $possibleUnits ) )
        {
            return false;
        }

        if( !$ttlInfos['ttl_value'] )
        {
            return false;
        }

        return true;
    }
    
    private function generateBlockKeyString( $tpl, $rootNamespace, $currentNamespace, $functionParameters, $functionPlacement )
    {
        $viewParametersString = $this->generateViewParametersString( '', '_' );

        $elementValue = $tpl->elementValue( $functionParameters['key'], $rootNamespace, $currentNamespace, $functionPlacement );

        if( is_array( $elementValue ) )
        {
            $elementValue = join( '_', $elementValue );
        }

        // values of the "key" attribute
        // converted into a string
        $blockKeyArray[] = $elementValue;

        // line number of the {si-block call}
        $blockKeyArray[] = $functionPlacement[0][0];

        $blockKeyArray[] = $functionPlacement[1][0];

        // template's filepath
        $blockKeyArray[] = $functionPlacement[2];

        // view_parameters
        $blockKeyArray[] = $viewParametersString;

        // fetching the current siteaccess
        $accessName = $GLOBALS['eZCurrentAccess']['name'];

        $blockKeyArray[] = $accessName;

        $blockKeyString = join( '_', $blockKeyArray );

        return $blockKeyString;
    }

    public function processChildren( $tpl, $functionChildren, $rootNamespace, $currentNamespace )
    {
        // generating HTML
        $childTextElements = array();
        foreach ( array_keys( $functionChildren ) as $childKey )
        {
            $child = $functionChildren[ $childKey ] ;
            $tpl->processNode( $child, $childTextElements, $rootNamespace, $currentNamespace );
        }
        $text = join( '', $childTextElements );

        eZDebug::writeNotice( $text, 'CSMemcacheBlockFunction::process' );
        return $text;
    }

    public function hasChildren()
    {
        return true;
    }

    public function cacheBaseSubdir()
    {
        return 'memcache-block';
    }

    private function generateViewParametersString( $preSeparator = '', $postSeparator = '' )
    {
        // taking view parameters and generate a string with them
        $eZURI = eZURI::instance( eZSys::requestURI() );
        $viewParametersString = '';

        foreach( $eZURI->UserArray as $paramName => $paramValue )
        {
            $viewParametersString .= $preSeparator . $paramName . $postSeparator . $paramValue;
        }

        return $viewParametersString;
    }


    // Name of the function
    private $FunctionName;
 
    public $TTL = '';
    public $Key = '';
    public $Src = '';
    
    private $cacheEngine;
    private $cacheEngineClass;
    private $cacheEnginePath;
    private $cacheEngineOptions;
    private $cacheEngineInstances;
}

?>