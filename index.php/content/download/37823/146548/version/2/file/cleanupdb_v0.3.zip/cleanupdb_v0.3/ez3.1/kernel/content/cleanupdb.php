<?php
//
//
// Created on: <08-Aug-2003 23:44:12 wy>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file cleanupdb.php
*/
/*
YMC (Young Media Concepts GmbH) NOTES:
==========
-this file will remove old (archived) versions of objects
-stops after 100 removed versions - because of possible php-limits (search for $maxLoop to change this)
*/

//by ymc-dabe //created the complete file...

include_once( "kernel/classes/ezcontentobject.php" );
include_once( "kernel/classes/ezcontentobjecttreenode.php" );
include_once( "kernel/classes/ezcontentcache.php" );

include_once( "lib/ezutils/classes/ezhttptool.php" );

include_once( "kernel/common/template.php" );
include_once( 'kernel/common/i18n.php' );

$Module =& $Params["Module"];

$http =& eZHTTPTool::instance();

$tpl =& templateInit();

$viewMode = $http->sessionVariable( "CurrentViewMode" );
$contentObjectID = $http->sessionVariable( 'ContentObjectID' );
$contentNodeID = $http->sessionVariable( 'ContentNodeID' );

if ( $http->hasPostVariable( "ConfirmButton" ) )
{

$db =& eZDB::instance();
$del_id = 3;

        $delete_array =& eZPersistentObject::fetchObjectList( eZContentObjectVersion::definition(),
             null, array( "status" => $del_id
             ),
			 array( 'contentobject_id' => 'desc' ),
			 null,
             true );

$maxLoop = 100;
$countLoop = count( $delete_array );
if ( $maxLoop > $countLoop)
{
$tpl->setVariable( "success", "1" );
$loop = $countLoop;
}
else
{
$tpl->setVariable( "success", "2" );
$loop = $maxLoop;
}
$i=0;
foreach ( $delete_array as $delete_object)
{
if ( $i < $loop)
{
$i++;

$objectID = $delete_object->attribute( 'contentobject_id' );
$version = $delete_object->attribute( 'version' );

$delete_object_attribute_array =& eZPersistentObject::fetchObjectList( eZContentObjectAttribute::definition(),
             null, array( "contentobject_id" => $objectID
             ),
			 array( 'version' => 'desc' ),
			 null,
             true );

foreach ($delete_object_attribute_array as $delete_object_attribute_object)
{
   if ( $delete_object_attribute_object->attribute( 'version' ) == $version )
   {
      $objectAttributeID = $delete_object_attribute_object->attribute( 'id' );

      $db->query( "DELETE FROM ezimage
                         WHERE contentobject_attribute_id=$objectAttributeID AND version=$version" );	  

      $db->query( "DELETE FROM ezimagevariation
                         WHERE contentobject_attribute_id=$objectAttributeID AND version=$version" );	  

      $db->query( "DELETE FROM ezbinaryfile
                         WHERE contentobject_attribute_id=$objectAttributeID AND version=$version" );	  

      $db->query( "DELETE FROM ezenumvalue
                         WHERE contentobject_attribute_id=$objectAttributeID AND contentobject_attribute_version=$version" );	  

      $db->query( "DELETE FROM ezenumobjectvalue
                         WHERE contentobject_attribute_id=$objectAttributeID AND contentobject_attribute_version=$version" );	  

      $db->query( "DELETE FROM ezmedia
                         WHERE contentobject_attribute_id=$objectAttributeID AND version=$version" );	  

   }
}

        $db->query( "DELETE FROM ezcontentobject_version
                         WHERE contentobject_id=$objectID AND version=$version" );

        $db->query( "DELETE FROM ezcontentobject_name
                         WHERE contentobject_id=$objectID AND content_version=$version" );

        $db->query( "DELETE FROM ezcontentobject_attribute
                         WHERE contentobject_id=$objectID AND version=$version" );
					
        $db->query( "DELETE FROM ezcontentobject_attribute
                         WHERE contentobject_id=$objectID AND version=$version" );

        $db->query( "DELETE FROM eznode_assignment
                         WHERE contentobject_id=$objectID AND contentobject_version=$version" );


}
}

$tpl->setVariable( "count", $i );

}


if ( $http->hasPostVariable( "CancelButton" ) )
{
    $Module->redirectTo( '/class/grouplist/'  );
}
$Module->setTitle( ezi18n( 'kernel/content', 'CleanUpDatabase' ) . ' ' . $NodeName );


$tpl->setVariable( "module", $Module );
$tpl->setVariable( "ChildObjectsCount", $ChildObjectsCount );
$tpl->setVariable( "DeleteResult",  $deleteResult );
$Result = array();
$Result['content'] =& $tpl->fetch( "design:node/cleanupdb.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'kernel/content', 'Remove object' ) ) );
?>
