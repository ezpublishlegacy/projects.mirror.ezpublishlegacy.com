<?php /* #?ini charset="iso-8859-1"?

[UpdateCacheAddNode]
StartNode=content
SelectionType=single
ReturnType=NodeID

*/ ?>