<?php

include_once ('lib/ezutils/classes/ezfunctionhandler.php');


define( "REQUEST_LIMIT", 5 );
define( "REQUEST_DEBUG", false );
class Requester
{
    function requestPage( &$parameters )
    {
        if (!isset( $parameters[ 'total_count' ] ))
        {
            $parameters['start_time'] = time();

            $count = eZFunctionHandler::execute( 'content','tree_count', 
                    array( 'parent_node_id' => $parameters[ 'node' ] ) );

            $parameters['total_count'] = $count;
            $parameters['created_count'] = 0;

            if ( REQUEST_DEBUG )
                Requester::file_put_contents( '/tmp/loadlog.html', 'Starting '.time()."\n", 'w' );
        }

        $fetchParameters = array( 'AsObject' => false, 
                                  'Limit' => REQUEST_LIMIT,
                                  'Offset' => $parameters[ 'created_count' ] );
        $nodes = eZContentObjectTreeNode::subTree( $fetchParameters , $parameters[ 'node' ] );

        $total=0;
        $success=0;
        foreach ( $nodes as $node )
        {
            $url = $parameters['base_url'] . "/content/view/full/" . $node[ 'node_id' ];
            $res = Requester::doRequest( $url );
            $total++;
            if ( $res )
                $success++;
        }
        $parameters['created_count']=$parameters['created_count']+$total;
    }

    function doRequest( $url )
    {

        if ( extension_loaded( 'curl' ) )
        {
            $ch = curl_init( $url );
            curl_setopt( $ch, CURLOPT_HEADER, 0 );
            curl_setopt( $ch, CURLOPT_FAILONERROR, 1 );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );

            $ini =& eZINI::instance();
            $proxy = $ini->hasVariable( 'ProxySettings', 'ProxyServer' ) ? $ini->variable( 'ProxySettings', 'ProxyServer' ) : false;
            if ( $proxy )
            {
                curl_setopt ( $ch, CURLOPT_PROXY , $proxy );
                $userName = $ini->hasVariable( 'ProxySettings', 'User' ) ? $ini->variable( 'ProxySettings', 'User' ) : false;
                $password = $ini->hasVariable( 'ProxySettings', 'Password' ) ? $ini->variable( 'ProxySettings', 'Password' ) : false;
                if ( $userName )
                {
                    curl_setopt ( $ch, CURLOPT_PROXYUSERPWD, "$userName:$password" );
                }
            }
            $result = curl_exec( $ch );
            if ( REQUEST_DEBUG )
                Requester::file_put_contents( '/tmp/loadlog.html', "\n$url\n" . $result, 'a' );
            if ( !$result )
            {
                return false;
            }
            curl_close( $ch );
            return true;
        }
        else 
        {
            $res = file_get_contents( $url );
            if ( REQUEST_DEBUG )
                Requester::file_put_contents( '/tmp/loadlog.html',  "\n$url\n" . $result, 'a' );
            if ( $res )
                return true;
        }
        return false;
    }


    function file_put_contents( $filename, $contents, $mode = 'w' )
    {
        $fp = fopen( $filename, $mode );
        fwrite( $fp, $contents );
        fclose( $fp );
    }
}

?>