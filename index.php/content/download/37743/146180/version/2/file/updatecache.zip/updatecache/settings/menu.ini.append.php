<?php /* #?ini charset="iso-8859-1"?

[NavigationPart]
Part[ezupdatecachepart]=Update Cache

[TopAdminMenu]
Tabs[]=update_cache

[Topmenu_update_cache]
NavigationPartIdentifier=ezupdatecachepart
Name=Update Cache
Tooltip=Regenerate cache for nodes
URL[]
URL[default]=update/cache
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>