<?php

include_once( 'kernel/common/template.php' );

$Module =& $Params['Module'];
$http =& eZHTTPTool::instance();
$tpl =& templateInit();

$ini = eZINI::instance();
$siteURL = 'http://' . $ini->variable( 'SiteSettings', 'SiteURL' );

$parameters = array( 'node' => 2,
                     'base_url' => $siteURL );

if ( $http->hasPostVariable( 'Parameters' ) )
{
    $parameters = $http->postVariable( 'Parameters' );
}

if ( $http->hasPostVariable( 'ParametersSerialized' ) )
{
    $parameters = unserialize( $http->postVariable( 'ParametersSerialized' ) );
}

if ( $http->hasPostVariable( 'GenerateButton' ) )
{
    include_once( dirname( __FILE__ ) . '/../../classes/requester.php' );
    Requester::requestPage( $parameters );

    if ( $parameters['created_count'] < $parameters['total_count'] )
    {
        $tpl->setVariable( 'parameters_serialized', serialize( $parameters ) );
        $parameters['time'] = time();
        $tpl->setVariable( 'parameters', $parameters );

        $Result['content'] = $tpl->fetch( 'design:update/progress.tpl' );
        $Result['pagelayout'] = 'update/progress_pagelayout.tpl';
        return;
    }
}

if ( $http->hasPostVariable( 'BrowseButton' ) )
{
    include_once( 'kernel/classes/ezcontentbrowse.php' );
    return eZContentBrowse::browse( array( 'action_name' => 'UpdateCacheAddNode',
                                           'from_page' => '/update/cache',
                                           'persistent_data' => array( 'ParametersSerialized' => serialize( $parameters ) ) ), $Module );
}

if ( $http->hasPostVariable( 'SelectedNodeIDArray' ) &&
     !$http->hasPostVariable( 'BrowseCancelButton' ) )
{
    $selectedNodeIDArray = $http->postVariable( 'SelectedNodeIDArray' );
    $parameters['node'] = $selectedNodeIDArray[0];
}


$tpl->setVariable( 'parameters', $parameters );

$Result['content'] =& $tpl->fetch( 'design:update/main.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Update Cache' ) );

?>