-----------------------
  Cache updater for
     eZ publish
------------------------

Installing
----------

Unpack to extensions directory. Activate extension. Clear template and content caches. 
The "Update cache" should now show up as a top menu tab in the administration interface.

Requrements
-----------

Extension has been tested with eZ publish 3.8, but should work with earlier releases.
CURL extension to PHP is recommended.

About
-----

This extension is created as an automated way to regenerate caches after you
have cleared all cache. The extension performes multiple GET requests to 
all pages in a subtree specified when starting the module. This means you do 
not need to manually click though all the pages to generate caches for them.

This extension is based heavy on the "Lorem Ipsum" extension created by Jan
Kudlicka. ( http://svn.ez.no/svn/extensions/contentgenerate/ )

 - Kristian Hole

Changelog
---------

v1.0 ( 2006-11-29 )
- Initial release
