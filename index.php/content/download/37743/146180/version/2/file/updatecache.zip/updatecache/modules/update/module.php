<?php

$Module = array( 'name' => 'Update Cache for eZ publish' );

$ViewList = array();
$ViewList['cache'] = array(
    'script' => 'cache.php',
    'default_navigation_part' => 'ezupdatecachepart',
    'params' => array() );


?>
