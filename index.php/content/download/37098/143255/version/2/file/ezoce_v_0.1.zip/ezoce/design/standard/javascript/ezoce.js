	function getText()
	{
		document.TemplateEditForm.TemplateContent.value = document.OCEApplet.getDocumentText();

	}

	function setText()
	{
		document.OCEApplet.setDocumentText(document.TemplateEditForm.TemplateContent.value );

	}


	