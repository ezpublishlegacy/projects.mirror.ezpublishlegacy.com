<?php /*

[ExtensionSettings]
DesignExtensions[]=ezoce

*/ ?>