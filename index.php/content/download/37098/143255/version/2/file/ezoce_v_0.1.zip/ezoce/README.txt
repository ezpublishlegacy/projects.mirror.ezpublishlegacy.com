/*
    eZOCE for eZ publish
    Copyright (C) 2006  JAC Systeme GmbH, Stralsund Germany
*/

Developed by
Felix Woldt   ( felix@jac-systeme.de )


Online Code Editor (OCE) = Java Applet 
======================================
This extenstion plugs in a JavaApplet into the 
TemplateEdit View of the admin interface of 
eZ publish.


V 0.1
=====

Features:
- syntaxhighlighting 
- light search engine
- you can detach the applet from the browser
	=> so you can edit the template in fullview
	
Known Bugs:
- syntaxhighlignting have some mistakes	



Install ezoce extention
=======================

1. Download the OE package.

2. Copy the downloaded package into the 'extension' directory of your
   eZ publish installation.

3. Unpack the files in the distribution.

4. Enable the OCE extension in eZ publish.

   To enable OCE for all of your siteaccesses, log in to your eZ publish
   administration interface, click on the 'Setup' tab, and then click
   'Extensions' on the left. You will see the list of available extensions.
   Select the 'ezdhtml' item and click the 'Apply changes' button.
   Aternatively, you can also edit the file 'site.ini.append.php' located
   in the 'settings/override' directory. Add the following line under
   the [ExtensionSettings] section:

   ActiveExtensions[]=ezoce

   Create the file and/or the section if they do not exist.

   To enable OE for only a single siteaccess, open the 'site.ini.append.php'
   file located in the 'settings/siteaccess/your_siteaccess' directory.
   Add the following line under the [ExtensionSettings] section:

   ActiveAccessExtensions[]=ezoce

   Create the file and/or the section if they do not exist.

6. Clear all the eZ publish caches.

   Log in to your eZ publish administration interface, select the 'Setup' tab,
   and then click the 'Clear all caches' button. If you use eZ publish 3.6
   or higher, you can also use the developer toolbar (if enabled) located
   in the right hand side. Simply select 'All caches' from the drop-down list
   and click the 'Clear' button.

   The other way to clear all caches is to remove the contents of 'var/cache/'
   and/or 'var/your_siteaccess/cache/' directory. This can either be done
   manually or by making use of a script.

   Linux users may launch the following script:

   $ ./bin/shell/clearcache.sh --clear-all

   If you have PHP CLI installed, you can also do the following (this script
   should also work on Windows):

   $ ./bin/php/ezcache.php --clear-all

7. Clear the browser caches

   Browsers usually cache visited pages in a folder somewhere. The next time
   the same pages are visited, they are loaded faster because some of the
   information already exists on the local storage device. If you already have
   OCE installed and you're upgrading it then you will have to clear the
   browser's cache.

