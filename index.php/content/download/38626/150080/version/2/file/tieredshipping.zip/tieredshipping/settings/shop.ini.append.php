#?ini charset="iso-8859-1"?
# eZ publish configuration file.

[ShippingSettings]
Handler=tiered
ExtensionDirectories[]=tieredshipping
