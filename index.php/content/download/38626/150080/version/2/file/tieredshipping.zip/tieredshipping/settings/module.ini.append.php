<? /*

[ModuleSettings]
ExtensionRepositories[]=tieredshipping

*/ ?>