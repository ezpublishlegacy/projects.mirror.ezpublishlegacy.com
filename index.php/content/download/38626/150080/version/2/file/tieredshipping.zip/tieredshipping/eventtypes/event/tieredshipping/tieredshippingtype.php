<?php
//
// Definition of TieredShippingType class
//
// SOFTWARE NAME: Tiered Shipping Type Class
// SOFTWARE RELEASE: 0.3
// COPYRIGHT NOTICE: Copyright (C) 2006 Blend Interactive
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


include_once( 'kernel/classes/ezorder.php' );

define( 'EZ_WORKFLOW_TYPE_TIEREDSHIPPING_ID', 'tieredshipping' );

class TieredShippingType extends eZWorkflowEventType
{
    /*!
     Constructor
    */
    function TieredShippingType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_TIEREDSHIPPING_ID, 'Tiered Shipping' );
        $this->setTriggerTypes( array( 'shop' => array( 'confirmorder' => array ( 'before' ) ) ) );
    }

    function execute( &$process, &$event )
    {
        $ini =& eZINI::instance( 'workflow.ini' );
        
        $tiers = $ini->variable( "TieredShippingWorkflow", "Tiers");
        $costs = $ini->variable( "TieredShippingWorkflow", "Costs");

        $description = $ini->variable( "TieredShippingWorkflow", "ShippingDescription" );

        $parameters = $process->attribute( 'parameter_list' );
        $orderID = $parameters['order_id'];

        $order = eZOrder::fetch( $orderID );
        $orderItems = $order->attribute( 'order_items' );
        
        $price = $order->attribute('total_ex_vat');
        
        //

        $addShipping = true;
        foreach ( array_keys( $orderItems ) as $key )
        {
            $orderItem =& $orderItems[$key];
            if ( $orderItem->attribute( 'type' ) == 'tieredshipping' )
            {
                $addShipping = false;
                break;
            }
        }
        if ( $addShipping )
        {
            //Walk up shipping tiers to determine cost.
            for($tierIndex = 0; $tierIndex < count($tiers); $tierIndex++)
            {
              //Is the price between this tier and the next?
              if($tierIndex == count($tiers) || ($price >= $tiers[$tierIndex] && $price < $tiers[$tierIndex + 1]))
              {
                break;
              } 
            }
            $cost = $costs[$tierIndex];
        
            $productCollection =& $order->attribute( 'productcollection' );
            $orderCurrency =& $productCollection->attribute( 'currency_code' );

            include_once( 'kernel/shop/classes/ezshopfunctions.php' );
            $cost = eZShopFunctions::convertAdditionalPrice( $orderCurrency, $cost );

            $orderItem = new eZOrderItem( array( 'order_id' => $orderID,
                                                 'description' => $description,
                                                 'price' => $cost,
                                                 'type' => 'tieredshipping' )
                                          );
            $orderItem->store();
        }
        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_TIEREDSHIPPING_ID, "tieredshippingtype" );

?>
