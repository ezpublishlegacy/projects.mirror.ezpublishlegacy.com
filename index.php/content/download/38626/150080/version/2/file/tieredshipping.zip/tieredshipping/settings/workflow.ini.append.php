[EventSettings]
ExtensionDirectories[]=tieredshipping
AvailableEventTypes[]=event_tieredshipping

[TieredShippingWorkflow]

ShippingDescription=Shipping

Tiers[]
Tiers[]=0
Tiers[]=50
Tiers[]=100
Tiers[]=200
Tiers[]=350
Tiers[]=500

Costs[]
Costs[]=8
Costs[]=10
Costs[]=12
Costs[]=15
Costs[]=18
Costs[]=21

