Tiered Shipping Extension
Version 0.3
Developed by Blend Interactive
http://www.blendinteractive.com
----------------------
The TieredShipping Extension allows you to set tiered shipping costs based on 
the price of the order. 

For example, with this extension you can create a shipping rule that sets 
orders under $50 to ship for $10, orders between $50 and $100 to ship for $20, 
and free shipping for orders over $100.

Installation
---------------

1.) Unzip the extension in your eZ Publish extension directory.

2.) Activate the extension in the 'extensions' page of the admin system's 
'Setup' tab.

3.) Create a workflow (let's call it "Shipping") and add the Tiered Shipping 
Event.

4.) Assign the new "Shipping" workflow to the 'shop/confirmorder/before' 
trigger.

5.) Edit Workflow.ini to set the desired shipping tiers (examples are 
included in the extension's settings)
