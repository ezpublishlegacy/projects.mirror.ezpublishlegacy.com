<?php /* #?ini charset="utf8"?

[ModuleSettings]
ExtensionRepositories[]=workflowboard
ModuleList[]=workflowboard

*/ ?>
