<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=workflowboard

[RegionalSettings]
TranslationExtensions[]=workflowboard

*/ ?>
