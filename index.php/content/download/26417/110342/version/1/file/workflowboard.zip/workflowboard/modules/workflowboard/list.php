<?php

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation()
{
	$db=eZDb::instance();
	$query="SELECT wp.id as wp_id, w.id as wf_id " .
			"FROM ezworkflow_process wp, ezworkflow w " .
			"WHERE wp.workflow_id = w.id " .
			" AND  w.version = 0 " .
			"ORDER BY wp.created DESC";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else 
	{
		return false;
	}
}
/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
require_once 'kernel/common/template.php';
$tpl = templateInit();
$wi =getWorkflowsInformation();
$result=array();
if ($wi !== false)
{
	foreach ($wi as $w)
	{
		$real_workflow_process = eZWorkflowProcess::fetch($w['wp_id']);
		$real_workflow = eZWorkflow::fetch($w['wf_id']);
		$result[]=array("process"=>$real_workflow_process, "workflow"=>$real_workflow);
	}
}
$view_parameters=array('workflows'=>$result);
$tpl->setVariable('view_parameters', $view_parameters);

$Result = array();
$Result['content'] = $tpl->fetch( 'design:workflowboard/list.tpl' );
$Result['path'] = array( array( 'url' => false,
								'text' => ezi18n('workflowboard/translations','Workflow Board')),
						 array( 'url' => false,
                                'text' => ezi18n('workflowboard/translations','Current workflow list') ) 
                       );
?>
