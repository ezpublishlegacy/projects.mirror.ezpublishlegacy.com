<?php
//
// Copyright (C) 2005 Smile. All rights reserved.
// Copyright (c) 2009 Open Net. All rights reserved
//
// Authors:
//  Maxime THOMAS <maxime.thomas@smile.fr>
//  Yvon-Philippe CRITTIN <cyp@open-net.ch>
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation($id)
{
	$db=eZDb::instance();
	$query="SELECT wp.id as wp_id, w.id as wf_id " .
			"FROM ezworkflow_process wp, ezworkflow w " .
			"WHERE wp.workflow_id = w.id " .
			"AND wp.id=$id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else 
	{
		return false;
	}
}
/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
$Module = $Params["Module"];
$http = eZHTTPTool::instance();
require_once 'kernel/common/template.php';
$tpl = templateInit();

$action = $Params['action'];

switch ( $action ) 
{	
	case "list":
		return $Module->redirectToView( 'list' );
	break;
	
	case "view":
		$param = $Params['param'];
		if ( !is_numeric( $param ) )
		{	
			
			return $Module->redirectToView( 'message', array('error','null') );
		}
		$p = getWorkflowsInformation($param);
		if (!$p)
		{
			return $Module->redirectToView( 'message', array('error','null') );
		}
		return $Module->redirectToView( 'view', array($param) );
	break;
	
	case "accept" :
		$param = $Params['param'];
		$accept = $http->postVariable( 'AcceptButton' );
		$list = $http->postVariable( 'DenyButton' );
		if ($accept != null)
		{
			return $Module->redirectToView( 'remove', array($param, 1) );
		}
		elseif ($list != null)
		{
			return $Module->redirectToView( 'list', array( ) );
		}
		else
		{
			return $Module->redirectToView( 'view', array($param) );
		}
		
	break;
	case "remove" :
		$param = $Params['param'];
		
		$list = $http->postVariable( 'BackButton' );
		if ($list != null)
		{
			return $Module->redirectToView( 'list' );
		}
		else
		{
			if ( !is_numeric( $param ) )
			{	
				return $Module->redirectToView( 'message', array('error','null') );
			}
			$p = getWorkflowsInformation($param);
			if (!$p)
			{
				return $Module->redirectToView( 'message', array('error','null') );
			}
			else
			{
				return $Module->redirectToView( 'remove', array($param) );
			}
		}
	break;
	
	case "message" :
		$param = $Params['param'];
		$string= $Parmas['string'];
		return $Module->redirectToView( 'message', array($param, $string) );
	break;
	
}

?>
