<?php /* #?ini charset="utf-8"?
[NavigationPart]
Part[healthchecknavigationpart]=Custom navigation

[TopAdminMenu]
Tabs[]=healthcheck

[Topmenu_healthcheck]
NavigationPartIdentifier=healthchecknavigationpart
Name=System Health Check
Tooltip=Checks the system is set up correctly and warns of potential problems.
URL[]
URL[default]=/healthcheck/overview
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true
 */ ?>
