eZ publish security fix #1

This is security fix for the user edit exploit found in eZ publish at
19.May.2003.

The exploit allowed anyone to edit the text of a users profile.
This caused the user object to be set as a draft thus disabling login for the
specific user.

The fixes makes sure that only users who have content/edit permissions
can edit setting and profiles for users.
Password change can now only be the user itself.

The following versions are affected:
2.9-3, 2.9-4, 2.9-5, 2.9-6, 2.9-7, 3.0-1 and 3.0-2

The supplied patches are for 3.0-1 and 3.0-2. In addition the fixed files for
the 3.0-2 version is added incase patching is not possible.

Installing the fix:
Patch the files with
patch -p0 < patches/user-fix-3.0-1.patch
for a 3.0-1 site or
patch -p0 < patches/user-fix-3.0-2.patch
for a 3.0-2 site

If you do not have the possiblity to patch the files you can copy the files
in 3.0-2-files to your eZ publish installation.

Alternative fix:
It's possible to turn off the user module by adding this to site.ini
[SiteAccessRules]
Rules[]
Rules[]=Access;enable
Rules[]=ModuleAll;true
Rules[]=Access;disable
Rules[]=Module;user
 
However this also turns of the login and should only be used until the fix is
installed.

Cleanups:
For those of you who have users which were affected by this exploit you
will have to edit the user objects and republish them to make them active
again.
