<?php

include_once( 'extension/ezwebservicesapi/xmlrpc/common.php' );

?>
