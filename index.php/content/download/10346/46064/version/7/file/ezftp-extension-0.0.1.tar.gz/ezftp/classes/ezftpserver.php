<?php

include_once( 'extension/ezftp/classes/ezftpclient.php' );

class eZFTPServer
{
    private $settings;
    private $socket;
    private $clients;
    
    public function eZFTPServer()
    {
        $ini =& eZINI::instance( 'ezftp.ini' );
        $this->settings = $ini->group( 'eZFTPSettings' );   
        $this->socket = false;
        $this->clients = array();
    }
  
    public function run()
    {
    	// assign listening socket 
        if ( !( $this->socket = @socket_create( AF_INET, SOCK_STREAM, 0 ) ) )
        {
            $this->socketError();
            return false;
        }

        // reuse listening socket address 
        if ( !@socket_setopt( $this->socket, SOL_SOCKET, SO_REUSEADDR, 1 ) )
        {
            $this->socketError();
            return false;
        }

        // set socket to non-blocking 
        if ( !@socket_set_nonblock( $this->socket ) )
        {
            $this->socketError();
            return false;
        }

        // bind listening socket to specific address/port 
        if ( $this->settings['DynamicIP'] == 'enabled' )
        {
            $IPAddress = $this->getIPAddress();
            if ( !$IPAddress )
                return false;
                
            if ( !@socket_bind( $this->socket, $IPAddress, $this->settings['ListenPort'] ) )
            {
                $this->socketError();
                return false;
            }
        }
        else
        {
            if ( !@socket_bind( $this->socket, $this->settings['ListenAddress'], $this->settings['ListenPort'] ) )
            {
                $this->socketError();
                return false;
            }
        }

        // listen on listening socket
        if ( !socket_listen( $this->socket ) )
        {
            $this->socketError();
            return false;
        }

        // set initial vars and loop until $abort is set to true
        $abort = false;
        
        while ( !$abort )
        {
            // sockets we want to pay attention to
            $setArray = array_merge( array( "server" => $this->socket ), $this->getClientConnections() );
            
            $set = $setArray;
            
            // loop through sockets and check for data transfers
            foreach( $set as $sockKey => $sock )
            {
                $clientID = array_search( $sock, $setArray );
                if ( !$clientID || $clientID == "server")
                    continue;
                
                if ( $this->clients[$clientID]->dataTransfer !== false )
                {
                    $dataTransfer = &$this->clients[$clientID]->dataTransfer;
                    if ( $dataTransfer->done )
                    {
                        $this->clients[$clientID]->dataFinish();
                    }
                    else
                    {
                        // do data transfer, and remove client from socket list for listening on the control connection
                        $dataTransfer->interact();
                        unset( $set[$sockKey] );
                    }
                }
            }
            
            reset($set);
            
            if ( socket_select($set, $setW = NULL, $setE = NULL, 0) > 0)
            {
                // loop through sockets
                foreach( $set as $sock )
                {
                    $name = array_search ( $sock, $setArray );

                    if (! $name)
                    {
                        continue;
                    }
                    elseif ( $name == "server" )
                    {
                        if ( !( $conn = socket_accept( $this->socket ) ) )
                        {
                            $this->socketError();
                            return false;
                        }
                        else
                        {
                            // add socket to client list and announce connection
                            $clientID = uniqid("client_");
                            
                            $this->clients[$clientID] = new eZFTPClient( $conn, $clientID );
                            
                            // if MaxConnexion exceeded disconnect client
                            if ( count( $this->clients ) > $this->settings['MaxConnexion'] )
                            {
                                $this->clients[$clientID]->send( '421 Maximum user count reached.' );
                                $this->removeClient( $clientID );
                                continue;
                            }
                            
                            // get a list of how many connections each IP has
                            $ipPool = array();
                            foreach( $this->clients as $client )
                            {
                                $key = $client->addr;
                                $ipPool[$key] = ( array_key_exists( $key, $ipPool ) ) ? $ipPool[$key] + 1 : 1;
                            }
                            
                            // disconnect when MaxConnexionPerIP is exceeded for this client
                            if ($ipPool[$key] > $this->settings['MaxConnexionPerIP'])
                            {
                                $this->clients[$clientID]->send( '421 Too many connections from this IP.' );
                                $this->removeClient($clientID);
                                continue;
                            }
                            
                            // everything is ok, run client
                            if ( !$this->clients[$clientID]->run() )
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        $clientID = $name;
                        if ($this->clients[$clientID]->dataTransfer === false) {
                            
                            // client socket has incoming data
                            if ( ( $read = @socket_read( $sock, 1024 ) ) === false || $read == '' )
                            {
                                if ($read != '')
                                {
                                    $this->socketError();
                                    return false;
                                }
    
                                // remove client from array
                                $this->removeClient( $clientID );
    
                            }
                            else
                            {
                                // only want data with a newline
                                if ( strchr( strrev($read), "\n" ) === false )
                                {
                                    $this->clients[$clientID]->buffer .= $read;
                                }
                                else
                                {
                                    $this->clients[$clientID]->buffer .= str_replace( "\n", "", $read );
                                    
                                    // interact with client
                                    if ( !$this->clients[$clientID]->interact() )
                                    {
                                        $this->removeClient($clientID);
                                    }
                                    else
                                    {
                                        $this->clients[$clientID]->buffer = "";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
    
    private function socketError()
    {
        eZDebug::writeError( socket_strerror( socket_last_error( $this->socket) ) , 'eZFTPServer::socketError' );
        if ( is_resource( $this->socket) )
            @socket_close( $this->socket );
    }
    
    private function getIPAddress()
    {
        exec("ifconfig | grep -1 ".$this->settings['DynamicIPInterface']." | cut -s -d ' ' -f12 | grep addr | cut -d ':' -f2", $output, $return);
        if ($return != "0")
        {
        	eZDebug::writeError( "Couldn't get ip address... maybe you should turn off the dynamic ip detection feature..." , 'eZFTPServer::getIPAddress' );
            return false;
        }
        return rtrim( $output[0] );
    }
    
    private function getClientConnections()
    {
        $connections = array();

        foreach( $this->clients as $clientID => $client )
        {
            $connections[$clientID] = $client->conn;
        }

        return $connections;
    }
    
    private function removeClient( $clientID )
    {
        unset( $this->clients[$clientID] );
    }

    public function currentSiteFromPath( $path )
    {
        $indexDir = eZSys::indexDir();

        // Remove indexDir if used in non-virtualhost mode.
        if ( preg_match( "#^" . preg_quote( $indexDir ) . "(.+)$#", $path, $matches ) )
        {
            $path = $matches[1];
        }
        
        // Get the list of available sites.
        $sites = $this->availableSites();

        foreach ( $sites as $site )
        {
            // Check if given path starts with this site-name, if so: return it.
            if ( preg_match( "#^/" . preg_quote( $site ) . "(.*)$#", $path, $matches ) )
            {
                return $site ;
            }
        }

        return false ;
    }
    
    /*!
      Gets and returns a list of the available sites (from site.ini).
    */
    private function availableSites()
    {
        // The site list is an array of strings.
        $siteList = array();

        // Grab the sitelist from the ini file.
        $ini = eZINI::instance();
        $siteList = $ini->variable( 'SiteSettings', 'SiteList' );

        // Return the site list.
        return $siteList ;
    }
    
   /*!
      Sets/changes the current site(access) to a \a $site.
    */
    static function setCurrentSite( $site )
    {
        $access = array( 'name' => $site,
                         'type' => EZ_ACCESS_TYPE_STATIC );

        $access = changeAccess( $access );

        // Clear/flush global database instance.
        $nullVar = null;
        eZDB::setInstance( $nullVar );
    }
    
}
?>