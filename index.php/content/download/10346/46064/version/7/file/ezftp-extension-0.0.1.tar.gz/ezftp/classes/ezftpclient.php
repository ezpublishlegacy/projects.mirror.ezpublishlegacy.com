<?php

include_once( 'extension/ezftp/classes/ezftpinout.php' );

class eZFTPClient
{
    private $settings;
    private $user;

    var $id;
    var $conn;
    var $buffer;
    var $transferType;
    var $loggedIn;
    var $login;
    var $userUid;
    var $userGid;
    var $userHomeDir;
    var $addr;
    var $port;
    var $pasv;
    var $dataTransfer;
    var $dataAddr;
    var $dataPort;
    // passive ftp data socket and connection
    var $dataSocket;
    var $dataConn;
    // active ftp data socket pointer
    var $dataFsp;
    var $command;
    var $parameter;
    var $io;
    var $auth;
    var $cwd;
    
    public function eZFTPClient( $conn, $id )
    {
        $ini =& eZINI::instance( 'ezftp.ini' );
        $this->settings = $ini->group( 'eZFTPSettings' );
        $this->user=null;
        $this->id = $id;
        $this->dataTransfer = false;
        $this->conn = $conn;
        $this->pasv = false;
        $this->loggedIn = false;
        $this->cwd = "/";
        $this->buffer = '';
        $this->command      = "";
        $this->parameter    = "";
        $this->buffer       = "";
        $this->transferType = "A";
    }
    
    public function run()
    {
        if ( !socket_getpeername( $this->conn, $addr, $port ) )
        {
        	eZDebug::writeError( 'Socket type is not AF_INET  AF_INET6 neither AF_UNIX' , 'eZFTPClient::run' );
            return false;
        }
        $this->addr = $addr;
        $this->port = $port;
        
        if ( !is_resource( $this->conn ) )
        {
            eZDebug::writeError( 'Socket connection is not a valid' , 'eZFTPClient::run' );
            return false;
        }            
        
        $this->send( "220 " . $this->settings['ServerName'] );

        return true;
    }

    public function interact()
    {
        if ( strlen( $this->buffer ) )
        {
            $this->command      = trim( strtoupper( substr( trim( $this->buffer ), 0, 4 ) ) );
            $this->parameter    = trim( substr( trim( $this->buffer ), 4 ) );

            switch ( $this->command )
            {
            	case 'QUIT':
                    $this->cmdQuit();
                    return false;
                    break;
                case 'USER':
                    $this->cmdUser();
                    return true;
                    break;
                case 'PASS':
                    $this->cmdPass();
                    return true;
                    break;
            }
            
            if ( !$this->loggedIn )
            {
                $this->send( "530 Not logged in." );
            }
            
            switch ( $this->command )
            {
                case 'LIST':
                case 'NLST':
                    $this->cmdList();
                    break;
                case 'PASV':
                    $this->cmdPasv();
                    break;
                case 'PASS':
                    $this->cmdPass();
                    break;
//                case 'PORT':
//                    $this->cmdPort();
//                    break;
                case 'SYST':
                    $this->cmdSyst();
                    break;
                case 'PWD':
                    $this->cmdPwd();
                    break;
                case 'CWD':
                    $this->cmdCwd();
                    break;
                case 'CDUP':
                    $this->cmdUp();
                    break;
                case 'TYPE':
                    $this->cmdType();
                    break;
                case 'NOOP':
                    $this->cmdNoop();
                    break;
//                case 'RETR':
//                    $this->cmdRetr();
//                    break;
//                case 'SIZE':
//                    $this->cmdSize();
//                    break;
//                case 'STOR':
//                case 'APPE':
//                    $this->cmdStor();
//                    break;
                case 'HELP':
                    $this->cmdHelp();
                    break;
//                case 'SITE':
//                    $this->cmdSite();
//                    break;
//                case 'MKD':
//                    $this->cmdMkd();
//                    break;
//                case 'RMD':
//                    $this->cmdRmd();
//                    break;
//                case 'RNFR':
//                    $this->cmdRnfr();
//                    break;
//                case 'RNTO':
//                    $this->cmdRnto();
//                    break;
                default:    
                    $this->send("502 Command not implemented." );
            }
            
            return true;
        }
    }
    

    public function dataFinish()
    {
        $this->dataTransfer = false;
        $this->send( "226 Transfer complete." );
    }
    
    public function send( $str )
    {
        socket_write( $this->conn, $str . "\n" );
    }
    
    private function disconnect()
    {
        if ( is_resource( $this->conn ) )
            @socket_close( $this->conn );

        if ( $this->pasv )
        {
            if ( is_resource( $this->dataConn ) )
                @socket_close( $this->dataConn );
                
            if ( is_resource( $this->dataSocket ) )
                @socket_close( $this->dataSocket );
            
            $pool = &$GLOBALS['eZFTPDataPortPool'];    
            unset( $pool[$this->dataPort] );
           
        }
    }

    /*
    NAME: type
    SYNTAX: type <A, I>
    DESCRIPTION: sets the file transfertype (Ascii or Binary)
    */
    private function cmdType()
    {
        $type = trim(strtoupper($this->parameter));

        if ( strlen( $type ) != 1 )
        {
            $this->send("501 Syntax error in parameters or arguments.");
        }
        elseif ( $type != "A" && $type != "I" )
        {
            $this->send("501 Syntax error in parameters or arguments.");
        }
        else
        {
            $this->transferType = $type;
            $this->send("200 type set.");
        }
    }

    /*
    NAME: cwd / cdup
    SYNTAX: cwd <directory> / cdup
    DESCRIPTION: changes current directory to <directory> / changes current directory to parent directory...
    NOTE: -
    */
    private function cmdUp()
    {
    	$splittedCwd = preg_split( "/\//", $this->cwd, -1, PREG_SPLIT_NO_EMPTY );
        
        if ( count( $splittedCwd ) )
        {
            array_pop( $splittedCwd );
            $terminate = ( count( $splittedCwd ) > 0 ) ? "/" : "";
            $this->parameter = "/" . implode( "/", $splittedCwd ) . $terminate;
        }
        else
        {
            $this->parameter = $this->cwd;
        }

        $this->cmdCwd();
    }

    /*
    NAME: cwd / cdup
    SYNTAX: cwd <directory> / cdup
    DESCRIPTION: changes current directory to <directory> / changes current directory to parent directory...
    NOTE: -
    */
    private function cmdCwd()
    {
        $path = trim( $this->parameter );
        
        //empty path = root dir
        if ( !strlen( $path ) )
        {
        	$newCwd = '/';
        }
        else
        {
            //absolute path
            if ( substr( $path, 0, 1 ) == "/" )
            {
            	$newCwd = rtrim( $path, "/" );
            }
            //relative path
            else
            {
            	$newCwd =  rtrim( $this->cwd, '/' ) . '/' . rtrim( $path, "/");
            }
        }
        
        if ( !$this->io->exists( $newCwd ) )
        {
            $this->send( "450 Directory does not exist." );
        }
        elseif ( !$this->io->canRead( $newCwd ) )
        {
            $this->send( "550 Permission denied." );
        }
        elseif ( $this->io->type( $newCwd ) == "dir" )
        {
            $this->cwd = $newCwd;
            $this->send( "250 CWD command succesfull." );
        }
        else
        {
            $this->send( "450 Requested file action not taken." );
        }
    }
    
    /*
    NAME: help
    SYNTAX: help
    DESCRIPTION: shows the list of available commands...
    NOTE: -
    */
    private function cmdHelp()
    {
        $this->send(
            "214-" . $this->settings['serverName'] . "\n"
            ."214-Commands available:\n"
//            ."214-APPE\n"
            ."214-CDUP\n"
            ."214-CWD\n"
//            ."214-DELE\n"
            ."214-HELP\n"
            ."214-LIST\n"
//            ."214-MKD\n"
            ."214-NOOP\n"
            ."214-PASS\n"
            ."214-PASV\n"
//            ."214-PORT\n"
            ."214-PWD\n"
            ."214-QUIT\n"
//            ."214-RETR\n"
//            ."214-RMD\n"
//            ."214-RNFR\n"
//            ."214-RNTO\n"
//            ."214-SIZE\n"
//            ."214-STOR\n"
            ."214-SYST\n"
            ."214-TYPE\n"
            ."214-USER\n"
            ."214 HELP command successful."
        );
    }

    /*
    NAME: list
    SYNTAX: list
    DESCRIPTION: returns the filelist of the current directory...
    NOTE: should implement the <directory> parameter to be RFC-compliant...
    */
    private function cmdList()
    {
        $this->dataTransfer = new eZFTPDataTransfert( &$this );

        if ( !$this->dataTransfer->open() )
        {
            $this->send( "425 Can't open data connection." );
            $this->dataTransfer->close();
            return;
        }
        
        $this->send( "150 Opening  " . $this->transferText() . " data connection." );
        
        while ( !$this->dataTransfer->done )
            $this->dataTransfer->interact();

        $this->dataFinish();
    }

    private function cmdNoop()
    {
        $this->send( "200 Nothing Done." );
    }

    /*
    NAME: pass
    SYNTAX: pass <password>
    DESCRIPTION: checks <password>, whether it's correct...
    NOTE: added authentication library support by Phanatic (26/12/2002 )
    */
    private function cmdPass()
    {
        if ( !$this->login )
        {
            $this->login = "";
            $this->loggedIn = false;
            $this->send( "530 Not logged in." );
            return;
        }

        $user = false;
        include_once( 'kernel/classes/datatypes/ezuser/ezuserloginhandler.php' );
        $ini =& eZINI::instance( 'site.ini' );
        if ( $ini->hasVariable( 'UserSettings', 'LoginHandler' ) )
        {
            $loginHandlers = $ini->variable( 'UserSettings', 'LoginHandler' );
        }
        else
        {
            $loginHandlers = array( 'standard' );
        }

        foreach ( array_keys ( $loginHandlers ) as $key )
        {
            $loginHandler = $loginHandlers[$key];
            $userClass =& eZUserLoginHandler::instance( $loginHandler );
            $user = $userClass->loginUser( $this->login, $this->parameter );
            if ( get_class( $user ) == 'ezuser' )
                break;
        }
        
        if ( get_class( $user ) != 'eZUser' )
        {
            $this->send( "530 Not logged in." );
            $this->loggedIn = false;
            $this->cmdQuit();
        }
        else
        {
            $this->send( "230 User " . $this->login . " logged in from " . $this->addr . "." );
            $this->loggedIn = true;
            $this->user = $user;
            $this->userUid = '33';
            $this->userGid = '33';
            $this->userHomeDir = '/';
            $this->io = new eZFTPInOut( $this->userHomeDir, $this->user );
        }
    }

    private function cmdPasv()
    {

        //$pool = &$GLOBALS['eZFTPPool'];
        $pool = &$GLOBALS['eZFTPDataPortPool'];

        if ( $this->pasv )
        {
            if ( is_resource( $this->dataConn ) )
                socket_close( $this->dataConn );

            if ( is_resource( $this->dataSocket ) )
                socket_close( $this->dataSocket );

            $this->dataConn = false;
            $this->dataSocket = false;

            if ( $this->dataPort )
                unset( $pool[$this->dataPort] );
                //$pool->remove( $this->dataPort );

        }

        $this->pasv = true;

        $lowPort = $this->settings['LowPort'];
        $highPort = $this->settings['HighPort'];

        $try = 0;

        if ( ( $socket = socket_create( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
        {
            $this->send( "425 Can't open data connection." );
            return;
        }

        // reuse listening socket address 
        if ( ! @socket_set_option( $socket, SOL_SOCKET, SO_REUSEADDR, 1 ) )
        {
            $this->send( "425 Can't open data connection." );
            return;
        }

        for ( $port = $lowPort; $port <= $highPort && $try < 4; $port++ )
        {
            //if ( ! $pool->exists( $port ) )
            if ( ! array_key_exists( $port, $pool ) )
            {
                $try++;

                $c = socket_bind( $socket, $this->settings['ListenAddress'], $port );

                if ( $c >= 0 )
                {
                    //$pool->add( $port );
                    $pool[$port] = 1;
                    break;
                }
            }
        }

        if ( ! $c )
        {
            $this->send( "452 Can't open data connection." );
            return;
        }

        socket_listen( $socket );

        $this->dataSocket = &$socket;
        $this->dataPort = $port;

        $p1 = $port >>  8;
        $p2 = $port & 0xff;

        $tmp = str_replace( ".", ",", $this->settings['ListenAddress'] );
        $this->send( "227 Entering Passive Mode ({$tmp},{$p1},{$p2})." );
    }

    /*
    NAME: pwd
    SYNTAX: pwd
    DESCRIPTION: returns current directory...
    NOTE: -
    */
    private function cmdPwd()
    {
        $this->send( "257 \"" . $this->cwd . "\" is current directory." );
    }

    /*
    NAME: quit
    SYNTAX: quit
    DESCRIPTION: closes the connection to the server...
    NOTE: -
    */
    private function cmdQuit()
    {
        $this->send( "221 Disconnected from ".$this->settings['ServerName']." FTP Server. Have a nice day." );
        $this->disconnect();
    }

    /*
    NAME: syst
    SYNTAX: syst
    DESCRIPTION: returns system type...
    NOTE: -
    */
    private function cmdSyst()
    {
        $this->send( "215 UNIX Type: L8" );
    }

    /*
    NAME: user
    SYNTAX: user <login>
    DESCRIPTION: logs <login> in...
    NOTE: -
    */
    private function cmdUser()
    {
        $this->loggedIn = false;
        $this->login = $this->parameter;
        $this->send( "331 Password required for " . $this->login . "." );
    }

    private function transferText()
    {
        return ( $this->transferType == "A" ) ? "ASCII mode" : "Binary mode";
    }
}
?>