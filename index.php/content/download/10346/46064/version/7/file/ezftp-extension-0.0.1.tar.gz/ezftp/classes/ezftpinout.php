<?php

include_once( 'extension/ezftp/classes/ezftpinout.php' );

class eZFTPInOut
{
	private $root;
    private $user;
    public $FolderClasses;

	public function eZFTPInOut( $root, &$user )
    {
		$this->user = &$user;
        $this->root = $root;
        $this->FolderClasses = null;
	}

    public function ls( $path )
    {
        $path = $this->splitFirstPathElement( $path, $currentSite );

        eZDebug::writeDebug( 'current site is : ' . $currentSite, 'eZFTPInOut::ls' );
        eZDebug::writeDebug( 'current path is : ' . $path, 'eZFTPInOut::ls' );

        //we are on the root dir
        if ( !$currentSite )
        {
            eZDebug::writeDebug( 'listing root dir', 'eZFTPInOut::ls' );
            return $this->rootLs();
        }

        eZFTPServer::setCurrentSite( $currentSite );
        
        // We are inside a site
        if ( !$path )
        {
            eZDebug::writeDebug( 'listing siteaccess', 'eZFTPInOut::ls' );
            return $this->siteLs( $currentSite );
        }
        
        $path = $this->splitFirstPathElement( $path, $virtualFolder );
        
        eZDebug::writeDebug( 'listing folder', 'eZFTPInOut::ls' );
        return $this->folderLs( $currentSite, $virtualFolder, $path );
	}
  
    public function exists( $path )
    {
        return true;
    }

    public function type( $path )
    {
        return 'dir';
    }

    public function canRead( $path )
    {
    	return true;
    }
    
    public function canWrite( $path )
    {
        return true;
    }
    
    public function size( $path )
    {
    	return 0;
    }
    
    public function remove( $path )
    {
    	return;
    }
    
    private function perms( $path )
    {
        return 'drwxr-xr-x';
    }

    private function virtualContentFolderName()
    {
        return ezi18n( 'kernel/content', "content" );
    }

    private function virtualMediaFolderName()
    {
        return ezi18n( 'kernel/content', "media" );
    }
    
    /*!
     \return An array containing the names of all folders in the virtual root.
    */
    function virtualFolderList()
    {
        return array($this->virtualContentFolderName(), $this->virtualMediaFolderName() );
    }
    
    /*!
     * Format a datetime for ftp output 
     */
    private function formatTime( $time )
    {
        //if the file has been created on this year
        if ( date( 'Y' , $time ) == date( 'Y', time() ) )
        {
            //date with time
            return date( 'M d H:i', $time );
        }
        else
        {
            //date with year
            return date( 'M d Y', $time );
        }
    }

    /*!
      Gets and returns a list of the available sites (from site.ini).
    */
    private function availableSites()
    {
        // The site list is an array of strings.
        $siteList = array();

        // Grab the sitelist from the ini file.
        $ini = eZINI::instance();
        $siteList = $ini->variable( 'SiteSettings', 'SiteList' );

        // Return the site list.
        return $siteList ;
    }

   /*!
      Takes the first path element from \a $path and removes it from
      the path, the extracted part will be placed in \a $name.
      \return A string containing the rest of the path,
              the path will not contain a starting slash.
      \param $path A string defining a path of elements delimited by a slash,
                   if the path starts with a slash it will be removed.
      \param[out] $element The name of the first path element without any slashes.

      \code
      $path = '/path/to/item/';
      $newPath = eZWebDAVContentServer::splitFirstPathElement( $path, $root );
      print( $root ); // prints 'path', $newPath is now 'to/item/'
      $newPath = eZWebDAVContentServer::splitFirstPathElement( $newPath, $second );
      print( $second ); // prints 'to', $newPath is now 'item/'
      $newPath = eZWebDAVContentServer::splitFirstPathElement( $newPath, $third );
      print( $third ); // prints 'item', $newPath is now ''
      \endcode
    */
    private function splitFirstPathElement( $path, &$element )
    {
        if ( $path[0] == '/' )
            $path = substr( $path, 1 );
        $pos = strpos( $path, '/' );
        if ( $pos === false )
        {
            $element = $path;
            $path = '';
        }
        else
        {
            $element = substr( $path, 0, $pos );
            $path = substr( $path, $pos + 1 );
        }
        return $path;
    }
    
    private function rootLs()
    {
        // At the end: we'll return an array of entry-arrays.
        $entries = array();

        // Get list of available sites.
        $sites = $this->availableSites();

        // For all available sites:
        foreach ( $sites as $site )
        {
            // Set up attributes for the virtual site-list folder:
            $entry = array();
            $entry['name']     = $site;
            $entry['size']     = '0';
            $entry['owner'] = 'ezpublish';
            $entry['group'] = 'ezpublish';
            $entry['time'] = $this->formatTime( filectime( 'settings/siteaccess/' . $site ) );
            $entry['perms']    = 'dr-xr-x---';

            $entries[] = $entry;
        }

        return $entries;
    }
    
    private function siteLs( $site )
    {
        // At the end: we'll return an array of entry-arrays.
        $entries = array();

        $defctime = filectime( 'settings/siteaccess/' . $site );

        $list = $this->virtualFolderList();
        foreach ( $list as $filename )
        {
            $entry = array();
            $entry['name']     = $filename;
            $entry['size']     = '0';
            $entry['owner'] = 'ezpublish';
            $entry['group'] = 'ezpublish';
            $entry['time'] = $this->formatTime( $defctime );
            $entry['perms']    = 'dr-xr-x---';
            $entries[] = $entry;
        }

        return $entries;
    }
    
    private function folderLs( $currentSite, $virtualFolder, $path )
    {
        $nodePath = $this->internalNodePath( $virtualFolder, $path );
        $node = $this->fetchNodeByTranslation( $nodePath );
         return $this->fetchContentList( $node );
    }
    
    /*!
     \private
     \return A path that corresponds to the internal path of nodes.
    */
    private function internalNodePath( $virtualFolder, $path )
    {
        // All root nodes needs to prepend their name to get the correct path
        // except for the content root which uses the path directly.
        if ( $virtualFolder == $this->virtualMediaFolderName() )
        {
            $nodePath = 'media';
            if ( strlen( $path ) > 0 )
                $nodePath .= '/' . $path;
        }
        else
        {
            $nodePath = $path;
        }
        return $nodePath;
    }

    /*!
      Attempts to fetch a possible/existing node by translating
      the inputted string/path to a node-number.
    */
    function fetchNodeByTranslation( $nodePathString )
    {
        // Get rid of possible extensions, remove .jpeg .txt .html etc..
        $nodePathString = $this->fileBasename( $nodePathString );

        // Strip away last slash
        if ( strlen( $nodePathString ) > 0 and
             $nodePathString[strlen( $nodePathString ) - 1] == '/' )
        {
            $nodePathString = substr( $nodePathString, 0, strlen( $nodePathString ) - 1 );
        }

        if ( strlen( $nodePathString ) > 0 )
        {
            $nodePathString = eZURLAliasML::convertPathToAlias( $nodePathString );
        }

        // Attempt to get nodeID from the URL.
        $nodeID = eZURLAliasML::fetchNodeIDByPath( $nodePathString );
        if ( !$nodeID )
        {
            return false;
        }

        // Attempt to fetch the node.
        $node = eZContentObjectTreeNode::fetch( $nodeID );

        // Return the node.
        return $node;
    }

    /*!
      \return The string \a $name without the final suffix (.jpg, .gif etc.)
    */
    function fileBasename( $name )
    {
        $pos = strrpos( $name, '.' );
        if ( $pos !== false )
        {
            $name = substr( $name, 0, $pos );
        }
        return $name;
    }
    
    /*!
      Gets and returns the content of an actual node.
      List of other nodes belonging to the target node
      (one level below it) will be returned.
    */
    function fetchContentList( &$node )
    {
        // We'll return an array of entries (which is an array of attributes).
        $entries = array();

        // Get all the children of the target node.
        $subTree = $node->subTree( array ( 'Depth' => 1 ) );

        // Build the entries array by going through all the
        // nodes in the subtree and getting their attributes:
        foreach ( $subTree as $someNode )
        {
            $entries[] = $this->fetchNodeInfo( $someNode );
        }

        // Return the content of the target.
        return $entries;
    }
    

    /*!
      Gathers information about a given node (specified as parameter).
    */
    function fetchNodeInfo( &$node )
    {
        // When finished, we'll return an array of attributes/properties.
        $entry = array();

        $object = $node->attribute( 'object' );

        // By default, everything is displayed as a folder:
        // Trim the name of the node, it is in some cases whitespace in eZ Publish      
        $entry['name']     = trim( $node->attribute( 'name' ) );
        $entry['size']     = '0';
        $entry['owner'] = 'ezpublish';
        $entry['group'] = 'ezpublish';
        $entry['time'] = $this->formatTime( $object->attribute( 'published' ) );
        $entry['perms']    = 'dr-xr-x---';
        
        //include_once( 'kernel/classes/ezcontentupload.php' );
        $upload = new eZContentUpload();
        $info = $upload->objectFileInfo( $object );
        $suffix = '';
        $class = $object->contentClass();
        $isObjectFolder = $this->isObjectFolder( $object, $class );

        if ( $isObjectFolder )
        {
            // We do nothing, the default is to see it as a folder
        }
        else if ( $info )
        {
            $filePath = $info['filepath'];

            $entry['size'] = false;
            if ( isset( $info['filesize'] ) )
                $entry['size'] = $info['filesize'];

            // Fill in information from the actual file if they are missing.
            $file = eZClusterFileHandler::instance( $filePath );
            if ( !$entry['size'] and $file->exists() )
            {
                $entry['size'] = $file->size();
            }
            
            if ( !isset( $info['mime_type'] )  )
            {
                $mimeInfo = eZMimeType::findByURL( $filePath );
                $suffix = $mimeInfo['suffix'];
                if ( strlen( $suffix ) > 0 )
                    $entry['name'] .= '.' . $suffix;
            }
            else
            {
                // eZMimeType returns first suffix in its list
                // this could be another one than the original file extension
                // so let's try to get the suffix from the file path first
                $suffix = eZFile::suffix( $filePath );
                if ( !$suffix )
                {
                    $mimeInfo = eZMimeType::findByName( $info['mime_type'] );
                    $suffix = $mimeInfo['suffix'];
                }
                if ( strlen( $suffix ) > 0 )
                    $entry['name'] .= '.' . $suffix;
            }

            
            if ( $file->exists() )
            {
                $entry['time'] = $this->formatTime( $file->mtime() );
                $entry['perms']    = '-r-xr-x---';
            }
        }
        
        /*
        $scriptURL = $_SERVER["SCRIPT_URL"];
        if ( strlen( $scriptURL ) > 0 and $scriptURL[ strlen( $scriptURL ) - 1 ] != "/" )
            $scriptURL .= "/";

        $trimmedScriptURL = trim( $scriptURL, '/' );
        $scriptURLParts = explode( '/', $trimmedScriptURL );

        $urlPartCount = count( $scriptURLParts );

        if ( $urlPartCount >= 2 )
        {
            // one of the virtual folders
            // or inside one of the virtual folders
            $siteAccess = $scriptURLParts[0];
            $virtualFolder = $scriptURLParts[1];

            // only when the virtual folder is Content we need to add its path to the start URL
            // the paths of other top level folders (like Media) are included in URL aliases of their descending nodes
            if ( $virtualFolder == VIRTUAL_CONTENT_FOLDER_NAME )
            {
                $startURL = '/' . $siteAccess . '/' . $virtualFolder . '/';
            }
            else
            {
                $startURL = '/' . $siteAccess . '/';
            }
        }
        else
        {
            // site access level
            $startURL = $scriptURL;
        }

        // Set the href attribute (note that it doesn't just equal the name).
        if ( !isset( $entry['href'] ) )
        {
            if ( strlen( $suffix ) > 0 )
                    $suffix = '.' . $suffix;
            $entry["href"] = $startURL . $node->urlAlias() . $suffix;
        }
        */
        // Return array of attributes/properties (name, size, mime, times, etc.).
        return $entry;
    }

    /*!
      \return \c true if the object \a $object should always be considered a folder.
    */
    function isObjectFolder( $object, &$class )
    {
        $classIdentifier = $class->attribute( 'identifier' );
        if ( $this->FolderClasses === null )
        {
            $ini = eZINI::instance( 'ezftp.ini' );
            $folderClasses = array();
            if ( $ini->hasGroup( 'GeneralSettings' ) and
                 $ini->hasVariable( 'GeneralSettings', 'FolderClasses' ) )
            {
                $folderClasses = $ini->variable( 'GeneralSettings', 'FolderClasses' );
            }
            $this->FolderClasses = $folderClasses;
        }
        return in_array( $classIdentifier, $this->FolderClasses );
    }

}
?>
