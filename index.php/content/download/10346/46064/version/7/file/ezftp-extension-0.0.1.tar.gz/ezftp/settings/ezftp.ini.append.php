<?php /*

[eZFTPSettings]
ListenAddress=192.168.0.1
ListenPort=21
MaxConnexion=10
MaxConnexionPerIP=3
DynamicIP=disabled
DynamicIPInterface=eth0
ServerName=eZFTP 0.0.1 server (testing)
LowPort=15000
HighPort=16000

# List of classes that should always be seen as a folder.
# By default, if a class contains an image attribute it is seen as an image.
FolderClasses[]
FolderClasses[]=folder
#FolderClasses[]=article
#FolderClasses[]=your_custom_class

*/ ?>