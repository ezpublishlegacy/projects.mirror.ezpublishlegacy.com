<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezftp

*/ ?>