<?php
class eZFTPDataTransfert
{
    private $client;
    public $done;
    private $dataConn;
    private $dataFsp;
    
    function eZFTPDataTransfert( &$client )
    {
        $this->client = &$client ;
        $this->done = false;
    }
    
    function interact()
    {
        switch( $this->client->command )
        {
            case "RETR":
                if ( $data = $this->client->io->read( 1048576 ) )
                {
                    $this->send($data);
                }
                else
                {
                    $this->done = true;
                }
                break;
                
            case "STOR":
                if ( ( $buf = $this->read() ) !== false )
                {
                    if ( !strlen($buf) )
                        $this->done = true;
                    $this->client->io->write( $buf );
                }
                else
                {
                    $this->done = true;
                }
                break;
                
            case "LIST":
                $list = $this->client->io->ls( $this->client->cwd );
                if ( !$list )
                {
                    eZDebug::writeError( 'filelist is empty', 'eZFTPDataTransfert::interact' );
                    $this->send( '' );
                    $this->eol();
                    $this->done = true;
                }
                else
                {
                    foreach( $list as $info )
                    {
                        $formattedList = sprintf("%-11s%-2s%-15s%-15s%-10s%-13s".$info['name'], $info['perms'], "1", $info['owner'], $info['group'], $info['size'], $info['time']);
                        $this->send( $formattedList );
                        $this->eol();
                        $this->done = true;
                    }
                }
                
                break;
        }
        
        if ( $this->done )
        {
            if ( $this->client->command == "RETR" || $this->client->command == "STOR" )
                $this->client->io->close();
            $this->close();
        }
    }
    
    function close()
    {
        if ( !$this->client->pasv )
        {
            if ( is_resource( $this->dataFsp ) )
                fclose( $this->dataFsp );
            $this->dataFsp = false;
        }
        else
        {
            socket_close( $this->dataConn );
            $this->dataConn = false;
        }
    }
    
    function open()
    {
        if ( $this->client->pasv )
        {
            if ( !$conn = @socket_accept( $this->client->dataSocket  ) )
            {
                eZDebug::writeError( 'Can not get connection' , 'eZFTPDataTransfert::open' );
                return false;
            }

            if ( !socket_getpeername( $conn, $peerIp, $peerPort ) )
            {
                eZDebug::writeError( 'Can not get peer' , 'eZFTPDataTransfert::open' );
                $this->dataConn = false;
                return false;
            }
            else
            {
                eZDebug::writeDebug( "Client connected ($peerIp:$peerPort)" , 'eZFTPDataTransfert::open' );
            }

            $this->dataConn = &$conn;

        }
        else
        {
            $fsp = fsockopen( $this->client->dataAddr, $this->client->dataPort, $errno, $errstr, 30 );

            if ( !$fsp )
            {
                eZDebug::writeError( 'Could not connect to client' , 'eZFTPDataTransfert::open' );
                return false;
            }

            $this->dataFsp = $fsp;
        }

        return true;
    }

    function read()
    {
        if ( $this->client->pasv )
        {
            return socket_read($this->dataConn, 1024);
        }
        else
        {
            return fread($this->dataFsp, 1024);
        }
    }
    
    function send( $str )
    {   
        if ( $this->client->transferType == "A" )
        {
            $str = str_replace( '\r', '', $str );
            $str = str_replace( '\n', '\r\n', $str );
        }
        
        if ($this->client->pasv)
        {
            socket_write( $this->dataConn, $str, strlen( $str ) );
        }
        else
        {
            fputs( $this->dataFsp, $str );
        }
    }

    function eol()
    {
        $eol = ( $this->client->transferType == "A" ) ? "\r\n" : "\n";
        $this->send( $eol );
    }
}
?>