<?php /* #?ini charset="utf-8"?

[TreeMenu]
ShowClasses[]=personal_frontpage

*/ ?>
