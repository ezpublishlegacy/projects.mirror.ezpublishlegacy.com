<?php /* #?ini charset="utf-8"?

[WebsiteToolbarSettings]
AvailableForClasses[]=personal_frontpage

*/ ?>
