<!DOCTYPE TS><TS>
<context>
    <name>extension/ezuniquedatatypes</name>
    <message>
        <source>Unique string</source>
        <translation>Unique string</translation>
    </message>
     <message>
        <source>Unique URL</source>
        <translation>Unique URL</translation>
    </message>    
     <message>
        <source>Given URL alread exists in another content object of this type!</source>
        <translation>Given URL alread exists in another content object of this type!</translation>
    </message>
     <message>
        <source>Given string alread exists in another content object of this type!</source>
        <translation>Given string alread exists in another content object of this type!</translation>
    </message>  
     <message>
        <source>Only URLs beginning with  "%schemas" are accepted!</source>
        <translation>Only URLs beginning with  "%schemas" are accepted!</translation>
    </message> 
</context>
</TS>