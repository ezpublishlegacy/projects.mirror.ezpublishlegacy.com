<!DOCTYPE TS><TS>
<context>
    <name>extension/ezuniquedatatypes</name>
    <message>
        <source>Unique string</source>
        <translation>Unikalny ciąg</translation>
    </message>
     <message>
        <source>Unique URL</source>
        <translation>Unikalny URL</translation>
    </message>
     <message>
        <source>Given URL alread exists in another content object of this type!</source>
        <translation>Podany URL już istnieje zapisany w innym obiekcie tego typu!</translation>
    </message>
     <message>
        <source>Given string alread exists in another content object of this type!</source>
        <translation>Podany ciąg już istnieje zapisany w innym obiekcie tego typu!</translation>
    </message>   
     <message>
        <source>Only URLs beginning with  "%schemas" are accepted!</source>
        <translation>Wyłącznie adresy rozpoczynające się od "%schemas" są akceptowalne!</translation>
    </message>    
</context>
</TS>
