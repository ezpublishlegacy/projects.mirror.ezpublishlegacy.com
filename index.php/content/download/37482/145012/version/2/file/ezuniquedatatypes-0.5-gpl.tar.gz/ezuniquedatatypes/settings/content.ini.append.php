<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezuniquedatatypes
AvailableDataTypes[]=ezuniqueurl
AvailableDataTypes[]=ezuniquestring

*/ ?>
