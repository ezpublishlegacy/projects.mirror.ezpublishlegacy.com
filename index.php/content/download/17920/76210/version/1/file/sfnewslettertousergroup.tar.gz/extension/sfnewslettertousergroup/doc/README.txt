This extension is an add-on for eznewsletter.
Therefor it requires eznewsletter to be installed and set up properly.
It has been tested with eznewsletter 1.6.0.

sfnewslettertousergroup automatically creates SubscriptionLists for each UserGroup and
adds all Users from the Usergroup as subscribers to the corresponding Subscriptionlists.

This makes it possible to send email newsletters to all your registered users 
without manually adding them as subscribers to newsletters by
adding its subscription list to your recipient list.