[NameSettings]
PrependSubscriptionListsString=auto_

[UserSettings]
AdminUserID=14

[UserGroupSettings]
IgnoreGroup[]
# Example: Ignore Usergroup with ObjectID 12
#IgnoreGroup[]=12
# Example: Ignore Usergroups with ObjectIDs 12 and 17
# IgnoreGroup[]=12
# IgnoreGroup[]=17