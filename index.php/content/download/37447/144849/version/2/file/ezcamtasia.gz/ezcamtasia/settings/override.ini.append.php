[embed_camtasia_video]
Source=content/view/embed.tpl
MatchFile=embed/camtasia_video.tpl
Subdir=templates
Match[class_identifier]=camtasia_video
