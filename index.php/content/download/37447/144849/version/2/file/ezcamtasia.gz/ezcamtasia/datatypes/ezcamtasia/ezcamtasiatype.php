<?php
/*

    ezcamtasia.php Datatype
    -----------------------
    Extends the eZBinaryFileType to extract the contents of a Camtasia .Zip file.

    Copyright (C) 2009 Lyrix, Inc. <http://lyrix.com> / Betsy Gamrat

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Camtasia product data: http://www.techsmith.com/camtasia.asp

*/

class ezcamtasia extends eZBinaryFileType
{
	/* Link that describes how the Camtasia content should be created */
	const HELP_TEXT='<p><a href="http://www.techsmith.com/learn/camtasia/6/share/export-zip.asp">http://www.techsmith.com/learn/camtasia/6/share/export-zip.asp</a></p>';
	
	const DATA_TYPE_STRING = "ezcamtasia";

	const HTML_FILE='/camtasia.html';
	const HTML_EMBED_FILE='/camtasia_embed.html';

	private $contentSubtree;
	private $requiredFiles;
	private $installationDirectory;

	/*!
	  Constructor
	*/
	function __construct()
	{
		parent::__construct();
		$this->eZDataType( self::DATA_TYPE_STRING, ezi18n( 'kernel/classes/datatypes', 'Camtasia .zip file', 'Datatype name' ),	 
			array('translation_allowed'=>true,'serialize_supported' => true ) );
		$ini = eZINI::instance( 'ezcamtasia.ini' );
		$this->installationDirectory = $ini->variable( 'Installation', 'Directory' );
		$this->contentSubtree = $ini->variable( 'FileSettings', 'VersionedFiles' );
		$this->requiredFiles = $ini->variable( 'Validation', 'RequiredFiles' );
		/* If the string is quoted, remove the quotes */
		while (($this->requiredFiles[0]=='"') || ($this->requiredFiles[0]=="\'"))
			$this->requiredFiles=substr($this->requiredFiles,1,-1);
	}

	function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
	{
		parent::initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute );

		/* This ensures that the Camtasia content is copied from the previous version */
		if ($originalContentObjectAttribute->attribute('content')!==NULL)
		{
			$contentDirectory=$this->zipPath ( $contentObjectAttribute );		
			$previousVersionPath=$this->previousVersionPath($contentObjectAttribute,$contentDirectory,
			$originalContentObjectAttribute->attribute('version'));
			if (is_dir($previousVersionPath))
			{
				eZDir::mkdir( $contentDirectory );
				eZDir::copy( $previousVersionPath,$contentDirectory,false,true );
			}
		}
	}

	function storeObjectAttribute ( $contentObjectAttribute )
	{
		/* This method extracts the Camtasia content from the stored file, if possible. */

		$bValid=true;

		$rResult=parent::storeObjectAttribute ( $contentObjectAttribute );
		$contentObjectAttributeId=$contentObjectAttribute->attribute('id');
		$contentDirectory=$this->zipPath ( $contentObjectAttribute );
		$currentVersion=$contentObjectAttribute->attribute('version');

		if ($contentObjectAttribute->attribute('content')!=NULL)
		{
			$binaryFile = eZBinaryFile::fetch( $contentObjectAttributeId, $currentVersion );
			if ( $binaryFile instanceof eZBinaryFile )
			{
				/* Get the file data */
				$fileInfo=$binaryFile->storedFileInfo();
				$sFilename=$fileInfo['filepath'];
				if (is_file($sFilename)) 
				{
					/* Unzip the zip file */
					$zip = zip_open($sFilename);
					if (is_resource($zip))
					{
						$bValid=false;
						$zEntry=zip_read($zip);
						$zEntryName=array();
						while (is_resource($zEntry))
						{
							$zEntryName[]=$z=basename(zip_entry_name($zEntry));
							if (strpos($z,'.html')!==false)
								$bValid=true;
							$zEntry=zip_read($zip);
						}
						zip_close($zip);
						$aReqdFiles=explode(',',$this->requiredFiles);
						$bValid=$bValid && (count(array_intersect($aReqdFiles,$zEntryName))==count($aReqdFiles));
						if ($bValid)
							$bValid=$this->createCamtasiaContent($contentObjectAttribute,$sFilename);
						else
						{
							eZDebug::writeError($fileInfo['original_filename'].' is missing required files.  Required files are:'.
								$this->requiredFiles.'.  '.
								'They are defined in extension/ezcamtasia/settings/ezcamtasia.ini.php.  '.
								'Refer to '.strip_tags(self::HELP_TEXT),'ezcamtasia');
							$bValid=false;
						}
					}	
					else
					{
						eZDebug::writeError('Could not open '.$fileInfo['original_filename'].'.  A valid .zip file is required. '.
							'Refer to '.strip_tags(self::HELP_TEXT),'ezcamtasia');
						$bValid=false;
					}
				}
				else
				{
					eZDebug::writeError('Could not open '.$fileInfo['original_filename'].' for validation.','ezcamtasia');
					$bValid=false;
				}
			}
			else
			{
				eZDebug::writeError($fileInfo['original_filename'].' is not a file.','ezcamtasia');
				$bValid=false;;
			}
		}
		if (!$bValid)
		{
			$contentDirectory=$this->zipPath ( $contentObjectAttribute );
			$sHTMLFile=$contentDirectory.self::HTML_FILE;
			/* Error display alerts users if the submitted file was unusable. */
			eZDir::mkdir($contentDirectory,0755,true);
			file_put_contents($sHTMLFile,
				'<div class="warning"><h2>File error</h2><p>Could not create Camtasia content from the file submitted.</p>'.self::HELP_TEXT.'</div>');
		}
		return $rResult;
	}

	function attributePath ( $contentObjectAttribute )
	{
		$pathParts = array( eZSys::storageDirectory(), $this->contentSubtree, $contentObjectAttribute->attribute( 'id' ) );
		return implode ( '/',$pathParts );
	}

	function zipPath ( $contentObjectAttribute )
	{
		$attributeVersion = $contentObjectAttribute->attribute('version');
		$attributeLanguage = $contentObjectAttribute->attribute('language_code');
		return $this->attributePath( $contentObjectAttribute ) . '/' . $attributeVersion . '-' . $attributeLanguage;
	}

	function previousVersionPath($contentObjectAttribute,$contentDirectory,$previousVersion)
	{
		/* $offset is ADDed to the current version.  To get an earlier version, pass in a negative number. */
		$attributeID=$contentObjectAttribute->attribute( 'id' );
		$currentVersion=$contentObjectAttribute->attribute( 'version' );
		$adjacentVersion=$previousVersion;
		return preg_replace("/$attributeID\/$currentVersion/","$attributeID/$adjacentVersion",$contentDirectory);
	}

	function createCamtasiaContent ( $contentObjectAttribute,$zipFile )
	{
		$contentDirectory=$this->zipPath ( $contentObjectAttribute );
		eZDir::mkdir($contentDirectory,0755,true);
		$sHTMLFile=$contentDirectory.self::HTML_FILE;
		$sHTMLEmbedFile=$contentDirectory.self::HTML_EMBED_FILE;

		/* Unzip the zip file */
		$zip = new ZipArchive;
		if ($zip->open($zipFile) === TRUE) 
		{
			/* Get the name of the subdirectory the files will be extracted to */
			$subDir=dirname($zip->getNameIndex(0));
			$zip->extractTo($contentDirectory);
			$zip->close();
			/* Find the HTML for the video */
			$aHTMLFile=glob($contentDirectory.'/'.$subDir.'/*.html');
			$sFileData=file_get_contents($aHTMLFile[0]);
			/* Leave the script, object, embed, param, and div tags */
			$sHTML=trim(preg_replace(array('/<title>.*<\/title>/i','/^[\s]*$/m'),
				array('',''),strip_tags($sFileData,'<script><object><embed><param><div><title><style><a>')));
			/* Remove the style tag and content */
			$iStart=stripos($sHTML,'<style');
			if ($iStart!==false)
			{
				$iEnd=strripos($sHTML,'</style>');
				$sHTML=substr($sHTML,0,$iStart-1).substr($sHTML,$iEnd+8);
			}
			/* Get the directory name */
			$sPath=$this->installationDirectory.$contentDirectory.'/'.$subDir.'/${1}';
			/* Substitute the directory name on references to .swf, .js, and FirstFrame.png */
			$sHTML=preg_replace(array('/["|\']([^"|^\']*(\.swf|\.js))["|\']/','/(FirstFrame\.png)/'),
				array('"'.$sPath.'"',$sPath),$sHTML);

			$aDimensions=preg_match('/width="(\d*)" height="(\d*)"/',$sHTML,$aMatches);
			$iWidth=(int)((int)$aMatches[1]/1.5);
			$iHeight=(int)((int)$aMatches[2]/1.5);
			$sEmbedHTML=preg_replace('/width="(\d*)" height="(\d*)"/','width="'.$iWidth.'" height="'.$iHeight.'"',$sHTML);
			
			/* Write out the updated HTML */
			if ((file_put_contents($sHTMLFile,$sHTML) === FALSE) || (file_put_contents($sHTMLEmbedFile,$sEmbedHTML) === FALSE))
			{
				eZDebug::writeError('Camtasia HTML file or HTML embed file write failed ('.$zipFile.') to '.$sHTMLFile,'ezcamtasia');
				return false;
			}
			
		}
		else 
		{
			eZDebug::writeError('Could not open '.$zipFile.'.  Status: '.$zip->getStatusString(),'ezcamtasia');
			file_put_contents($sHTMLFile,'<p class="error">Could not open Camtasia Zip file.</p>'.self::HELP_TEXT);
			return false;
		}
		return true;
	}

	function deleteStoredObjectAttribute( $contentObjectAttribute, $version = null )
	{
		/* This ensures the .zip file content is deleted */
		$contentObject = eZContentObject::fetch($contentObjectAttribute->attribute( 'contentobject_id' ));
		$mainNode = eZContentObjectTreeNode::fetch($contentObject->mainNodeID());
		$contentDirectory=$this->zipPath($contentObjectAttribute);
		eZDir::recursiveDelete( $contentDirectory );

		/* If this was the last version, delete the attribute storage */
		$attributeDirectory=$this->attributePath ( $contentObjectAttribute );
		$aSubDirs=eZDir::findSubdirs( $attributeDirectory, true, false );
		if (count($aSubDirs)==0)
			eZDir::recursiveDelete( $attributeDirectory );

		/* eZ will remove the .zip file itself */
		return parent::deleteStoredObjectAttribute( $contentObjectAttribute, $version );
	}
}
eZDataType::register( ezcamtasia::DATA_TYPE_STRING, "ezcamtasia" );
?>

