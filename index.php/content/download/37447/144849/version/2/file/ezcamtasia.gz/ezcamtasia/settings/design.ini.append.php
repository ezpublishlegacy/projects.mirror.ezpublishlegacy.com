<?php /*
[ExtensionSettings]
DesignExtensions[]=ezcamtasia
*/ ?>

