<?php /*
[DataTypeSettings]
ExtensionDirectories[]=ezcamtasia
AvailableDataTypes[]=ezcamtasia
*/ ?>
