<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Forma %formname</translation>
    </message>
    <message>
        <source>Thank you for your feedback.</source>
        <translation>Gracias por su contacto.</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Ya ha enviado este formulario. Los datos previos enviados fueron los siguientes.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Regresar al sitio</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearch</name>
    <message>
        <source>Advanced search</source>
        <translation>Búsqueda avanzada</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Buscar todas las palabras</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Buscar la frase exacta</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Buscar con al menos una de las palabras</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicada</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Cualquier momento</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Último día</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Última semana</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Últimos 3 meses</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Último año</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Mostrar por página</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 ítems</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 ítems</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 ítems</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 ítems</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 ítems</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>No se encontraron resultados buscando &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Búsqueda de &quot;%1&quot; regresó %2 resultados</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearchh</name>
    <message>
        <source>Last month</source>
        <translation>Último mes</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Visualizar</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
        <translation>Para seleccionar objetos, seleccione la casilla apropiada y luego haga click en el botón &quot;Seleccionar&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Para seleccionar un objeto que es hijo de uno de los objetos mostrados, haga click sobre el nombre del objeto y obtendrá una lista de los hijos del mismo.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Regresar</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Primer nivel</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse_mode_list</name>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/diff</name>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Versiones de &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Archivado</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Rechazado</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Borrador no modificado</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Este objeto no tiene versiones.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Diferencias entre versiones %oldVersion y %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Versión anterior</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Cambios en línea</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Bloquear cambios</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nueva versión</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/draft</name>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todos</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Deseleccionar todos</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Vaciar borradores</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Estos son los objetos que está trabajando. Los borradores le pertenecen y sólo pueden ser vistos por Usted.
       Usted puede editar los borradores o eliminarlos si no los necesita mas.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>No tiene borradores</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit</name>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Grabar y salir</translation>
    </message>
    <message>
        <source>Store the draft that is being edited and exit from edit mode.</source>
        <translation>Almacena el borrador que está siendo editado y sale de la edición.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <source>No translation</source>
        <translation>Sin traducciones</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traducir</translation>
    </message>
    <message>
        <source>Edit the current object showing the selected language as a reference.</source>
        <translation>Editar el objeto actual mostrando el lenguaje seleccionado como referencia.</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para publicación</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Almacenar borrador</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <source>not translatable</source>
        <translation>no es traducible</translation>
    </message>
    <message>
        <source>required</source>
        <translation>requerido</translation>
    </message>
    <message>
        <source>information collector</source>
        <translation>recolector de información</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_draft</name>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>La versión publicada actual es %version en fecha %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>La última modificación fue realizada en %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>el objeto le pertenece a %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Este objeto está siendo editado por alguien más, incluyendolo a Usted.
    Usted puede continuar con la edición de uno de sus borradores o crear uno nuevo.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Este objeto está siendo editado por Usted.
          Usted puede continuar con la edición de uno de sus borradores o crear uno nuevo.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Este objeto está siendo editado por alguien más.
          Usted debería contactar a la persona sobre el borrador o crear uno nuevo para su edición personal.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Borradores actuales</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propietario</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nuevo borrador</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_languages</name>
    <message>
        <source>Existing languages</source>
        <translation>Lenguajes existentes</translation>
    </message>
    <message>
        <source>Select the language you want to use when editing the object</source>
        <translation>Seleccione el lenguaje que desea utilizar cuando edite el objeto</translation>
    </message>
    <message>
        <source>New languages</source>
        <translation>Nuevos lenguajes</translation>
    </message>
    <message>
        <source>Select the language you want to add to the object</source>
        <translation>Seleccione el lenguaje que desea agregar al objeto</translation>
    </message>
    <message>
        <source>Select the language the added translation will be based on</source>
        <translation>Seleccione el lenguaje en el cual se basará la traducción agregada</translation>
    </message>
    <message>
        <source>use an empty, untranslated draft</source>
        <translation>utilizar un borrador vacio, no traducido</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to create a translation in another language.</source>
        <translation>No tiene sufucientes permisos para crear una traducción.</translation>
    </message>
    <message>
        <source>However you can select one of the following languages for editing</source>
        <translation>Sin embargo puede seleccionar uno de los siguientes lenguajes para editar</translation>
    </message>
    <message>
        <source>You do not have permission to edit the object in any available languages.</source>
        <translation>No tiene los suficientes permisos para editar el objeto en cualquier lenguaje disponible.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/history</name>
    <message>
        <source>Version not a draft</source>
        <translation>Versión no borrador</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Versión %1 no está disponible para editar, sólo los borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Para editar esta versión debe crear una copia.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Versión (no suyas)</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Versión %1 no fue creada por Usted, sólo sus propios borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Incapáz de crear una nueva versión</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>El límite en el historial de versiones ha sido excedido y no pueden ser eliminadas por el sistema las versiones no almacenadas.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Puede cambiar la configuración del historial de versiones en content.ini, eliminar versiones de borradores o editar existentes.</translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Versiones de &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Seleccione la versión #%version_number para eliminar.</translation>
    </message>
    <message>
        <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
        <translation>Versión #%version_number no puede ser eliminada porque es la publicada o Usted no tiene los permisos suficientes para eliminarla.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Ver el contenido de la versión #%version_number. Traducción: %translation.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Almacenado</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Rechazado</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Borrador sin modificar</translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Crear una copia de la versión #%version_number.</translation>
    </message>
    <message>
        <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
        <translation>Usted no puede hacer copias de versiones porque no tiene permisos para editar el objeto.</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Editar los contenidos de la versión #%version_number.</translation>
    </message>
    <message>
        <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
        <translation>Usted no puede editar el contenido de la versión #%version_number porque no es un borrador o porque no tiene permisos suficientes para editarla.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Este objeto no tiene ninguna versión.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar seleccionados</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Eliminar las versiones seleccionadas del objeto.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Volver</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>New drafts [%newerDraftCount]</source>
        <translation>Borradores nuevos [%newerDraftCount]</translation>
    </message>
    <message>
        <source>This object does not have any drafts.</source>
        <translation>Este objeto no tiene ningún borrador.</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Diferencias entre las versiones %oldVersion y %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Versión anterior</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Cambios en línea</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Cambios en bloque</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nueva versión</translation>
    </message>
    <message>
        <source>Back to history</source>
        <translation>Volver a historial</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Para más opciones intente la %1Búsqueda avanzada%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Las siguientes palabras fueron excluídas de la búsqueda</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>No se encontraron resultados para &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Consejos de búsqueda</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Revisar ortografía de las palabras.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Intente cambiar algunas palabras. Ej.: portal en lugar de portales.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Intente con más palabras clave generales.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Menos palabras en la búsqueda dá mayor cantidad de resultados; intente reducir la cantidad hasta que obtenga resultados.</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Búsqueda para &quot;%1&quot; regresó %2 resultados</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/versions</name>
    <message>
        <source>Versions for: %1</source>
        <translation>Versiones para %1</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Versión no borrador</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
        <translation>Versión %1 no está disponible para edición; sólo los borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Para editar esta versión debe crear una copia de la misma.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Versión (no suyas)</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Versión %1 no fue creada por usted; sólo sus borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Incapáz de crear nueva versión</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Límite en historial de versión ha sido excedido y no puede ser eliminada por el sistema la versión no almacenada.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Puede cambiar la configuración del historial de versiones en content.ini, eliminar versiones de borradores o editar existentes.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Copiar y editar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/view/versionview</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the draft that is being displayed.</source>
        <translation>Editar el borrador que se muestra.</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publicar</translation>
    </message>
    <message>
        <source>Publish the draft that is being displayed.</source>
        <translation>Publicar el borrador que se muestra..</translation>
    </message>
    <message>
        <source>This version is not a draft and thus it can not be edited.</source>
        <translation>Esta versión no es un borrador y por lo tanto no puede ser editada.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/comment</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para publicar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/file</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para publicar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_reply</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para publicar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_topic</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para publicar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/forum</name>
    <message>
        <source>Latest from</source>
        <translation>Ultimo desde</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezinfo/about</name>
    <message>
        <source>eZ Publish information: %version</source>
        <translation>Información eZ Publish: %version </translation>
    </message>
    <message>
        <source>What is eZ publish?</source>
        <translation>¿Qué es eZ publish?</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Contribuyentes</translation>
    </message>
    <message>
        <source>Copyright Notice</source>
        <translation>Noticia de Copyright</translation>
    </message>
    <message>
        <source>Third-Party Software</source>
        <translation>Software de terceros</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Extensiones</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <source>New Comment</source>
        <translation>Nuevo comentarios</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/documentation_page</name>
    <message>
        <source>Table of Contents</source>
        <translation>Tabla de contenido</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation>Creado:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Modificado:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event</name>
    <message>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_calendar</name>
    <message>
        <source>Mon</source>
        <translation>Lun</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>Mar</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>Mie</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>Jue</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>Sab</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>Dom</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_program</name>
    <message>
        <source>Past events</source>
        <translation>Eventos anteriores</translation>
    </message>
    <message>
        <source>Future events</source>
        <translation>Futuros eventos</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/feedback_form</name>
    <message>
        <source>Send form</source>
        <translation>Enviar Formulario</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <source>New topic</source>
        <translation>Nuevo Tópico</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Mantenerme actualizado</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Debe entrar con su usuario para accesar los foros. Puede hacerlo %login_link_start%aqui%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Tópico</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Respuestas</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Últ. respuesta</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_reply</name>
    <message>
        <source>Message preview</source>
        <translation>Previsualización del mensaje</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Tópico</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Moderado por</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_topic</name>
    <message>
        <source>Previous topic</source>
        <translation>Tópico previo</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Próximo tópico</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Nueva respuesta</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Mantenerme actualizado</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so</source>
        <translation>Debe entrar con su usuario para accesar los foros. Puede hacerlo</translation>
    </message>
    <message>
        <source>here</source>
        <translation>aquí</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Moderado por</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Eliminar este item.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forums</name>
    <message>
        <source>Topics</source>
        <translation>Tópicos</translation>
    </message>
    <message>
        <source>Posts</source>
        <translation>Publicaciones</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Ultima respuesta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/gallery</name>
    <message>
        <source>View as slideshow</source>
        <translation>Ver como presentación</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/image</name>
    <message>
        <source>Previous image</source>
        <translation>Imagen previa</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Próxima imagen</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to basket</source>
        <translation>Agregar a la cesta</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>agregar a lista de deseos</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Personas que lo han comprado</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/horizontallylistedsubitems/event</name>
    <message>
        <source>Category</source>
        <translation type="obsolete">Categoria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event</name>
    <message>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event_calendar</name>
    <message>
        <source>Next events</source>
        <translation>Eventos próximos</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/flash</name>
    <message>
        <source>View flash</source>
        <translation>Ver FLASH</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum</name>
    <message>
        <source>Number of Topics</source>
        <translation>No. de tópicos</translation>
    </message>
    <message>
        <source>Number of Posts</source>
        <translation>No. de publicaciones</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Últ. respuesta</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Entrar en foro</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum_reply</name>
    <message>
        <source>Reply to:</source>
        <translation>Responder a:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/quicktime</name>
    <message>
        <source>View movie</source>
        <translation>Ver película</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/real_video</name>
    <message>
        <source>View movie</source>
        <translation>Ver película</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/windows_media</name>
    <message>
        <source>View movie</source>
        <translation>Ver película</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/link</name>
    <message>
        <source>%sitetitle front page</source>
        <translation>%sitetitle página inicio</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Buscar %sitetitle</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Versión para imprimir</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/node/removeobject</name>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>¿Seguro que desea eliminar estos items?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename y sus %childcount hijos. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation></translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Mover a papelera</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Si %trashname es seleccionado, encontrará los items en la papelara.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/addingresult</name>
    <message>
        <source>Add to my notifications</source>
        <translation>Agregar a mis notificaciones</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>Notificación para el nodo &lt;%node_name&gt; ya existe.</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>Notificación para el nodo &lt;%node_name&gt; fue agregado con éxito.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/settings</name>
    <message>
        <source>Notification settings</source>
        <translation>Configuración de notificación</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Tienda</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/parts/website_toolbar</name>
    <message>
        <source>Create here</source>
        <translation>Crear aquí</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Reemplazar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/settings/edit</name>
    <message>
        <source>Node notification</source>
        <translation>Nodo de notificación</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <source>Shopping basket</source>
        <translation>Cesta de compras</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Información de cuenta</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar orden</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Los siguientes ítems fueron eliminados de su cesta, porque los productos fueron cambiados</translation>
    </message>
    <message>
        <source>VAT is unknown</source>
        <translation>IVA es desconocido</translation>
    </message>
    <message>
        <source>VAT percentage is not yet known for some of the items being purchased.</source>
        <translation>porcentaje de IVA no es conocido aún para algunos ítems que se están comprando.</translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation>Este significa que alguna información sobre Usted aún no está disponible y será obtenida durante la confirmación.</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Intento de agregar objeto sin precio a la cesta.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Su pago fue abortado.</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio inc. IVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Total exc. IVA</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Total inc. IVA</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>desconocido</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT</source>
        <translation>Subtotal exc. IVA</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT</source>
        <translation>Subtotal inc. IVA</translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation>Envío</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total orden</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Continuar compras</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>No tiene productos en su cesta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/confirmorder</name>
    <message>
        <source>Shopping basket</source>
        <translation>Cesta de compras</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Información de cuenta</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar orden</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio inc. IVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Total exc. IVA</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Total inc. IVA</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sumario de la orden</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Subtotal de ítems</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total orden</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/customerorderview</name>
    <message>
        <source>Customer Information</source>
        <translation>Información de cliente</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista de ordenes</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Total exc. IVA</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Total inc. IVA</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Lista de compra</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderview</name>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Orden %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio inc. IVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Total exc. IVA</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Total inc. IVA</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sumario de la orden</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Subtotal de ítems</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total orden</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>Historial de ordenes</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/userregister</name>
    <message>
        <source>Shopping basket</source>
        <translation>Cesta de compras</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Información de cuenta</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar orden</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Información de su cuenta</translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with * must be filled in</source>
        <translation>Entrada no válida, todos los campos marcados con * deben llenarse</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Primer nombre</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Apellido</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Correo electrónico</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Compañía</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Calle</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>CP</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Todos los campos marcados con * deben llenarse.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/wishlist</name>
    <message>
        <source>Wish list</source>
        <translation>Lista de deseos</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Tienda</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Eliminar items</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Vaciar lista de deseos</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/simplified_treemenu/show_simplified_menu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Plegar/Desplegar</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>ID nodo: %node_id Visible: %visibility</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/activate</name>
    <message>
        <source>Activate account</source>
        <translation>Activar cuenta</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Su cuenta está activada.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Disculpe, la clave suministrada no es válida. Cuenta no fue activada.</translation>
    </message>
    <message>
        <source>Your account is already active.</source>
        <translation>Su cuenta ya se encuentra activa.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <source>User profile</source>
        <translation>Perfil de usuario</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Correo electrónico</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>My orders</source>
        <translation>Mis ordenes</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Mis configuraciones de notificación</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation>Mi lista de deseos</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Editar perfil</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar clave</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/forgotpassword</name>
    <message>
        <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Un correo ha sido enviado a la dirección: %1. Este correo contiene un enlace que debe visitar, haciendo click en el mismo, para que pueda ser confirmado que el usuario correcto está obteniendo el password.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>No existe ningún usuario con ese correo.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Clave fue generada satisfactoriamente y enviada a: %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>La clave es inválida o ha sido utilizada. </translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>¿Olvidó su clave?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Si olvidó su clave podemos generar una nueva. Todo lo que necesita es introducir su correo electrónico y le crearemos una nueva clave.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Correo electrónico</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Generar nueva clave</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/login</name>
    <message>
        <source>Login</source>
        <translation>Entrar</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>No es posible entrar</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Se requiere un nombre de usuaurio y clave válidos para entrar.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Acceso no permitido</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>No tiene acceso permitido a %1.</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Clave</translation>
    </message>
    <message>
        <source>Log in to the administration interface of eZ publish</source>
        <translation>Entrar en la interfase administratíva de eZ publish</translation>
    </message>
    <message>
        <source>Remember me</source>
        <translation>Recordarme</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Entrada</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>Registrar</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>¿Olvidó su clave?</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <source>Register user</source>
        <translation>Registrar usuario</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Entrada no válida</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Entrada fue almacenada con éxito</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Incapáz de registrar nuevo usuario</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Regresar</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/success</name>
    <message>
        <source>User registered</source>
        <translation>Usuario registrado</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Su cuenta fue creada con éxito. Un correo de confirmación le será enviado a la dirección de correo especificada. Siga las instrucciones en ese correo para activar su cuenta.</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Su cuenta fue creada con éxito.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <source>The file could not be found.</source>
        <translation>El archivo no puede ser encontrado.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezprice</name>
    <message>
        <source>Price</source>
        <translation>Precio</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Su precio</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Su descuento</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/sitemap</name>
    <message>
        <source>Site map</source>
        <translation>Mapa del sitio</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Feedback from %1</source>
        <translation>Contacto de %1</translation>
    </message>
    <message>
        <source>The following feedback was collected</source>
        <translation>La siguiente información de contacto fue recolectada</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Información recolectada de %1</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>La siguiente información fue recolectada</translation>
    </message>
</context>
</TS>
