**************************************************

Words Limit Operator

**************************************************

Author : Mingxing Chen
Email : mxchen@eab.co.uk
Date : 2009/03/23

1/ Unzip file in your extension directory

2/ Activate the extension in the admin interface

3/ To use operator in a template :

{$string|wordtrunc($word_limit)}
