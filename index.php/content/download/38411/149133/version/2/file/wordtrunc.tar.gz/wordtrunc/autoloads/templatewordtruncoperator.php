<?php

/*!
  \class   TemplateWordtruncOperator templatewordtruncoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator wordtrunc. By using wordtrunc you can...
  \version 1.0
  \date    Monday 23 March 2009 9:27:40 am
  \author  Mingxing Chen mxchen@eab.co.uk

  

  Example:
\code
{$value|wordtrunc('$number')|wash}
\endcode
*/


class TemplateWordtruncOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TemplateWordtruncOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'wordtrunc' );
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'wordtrunc' => array( 'number' => array( 'type' => 'integer',
                                                                     'required' => false,
                                                                     'default' => 0 ) ) );
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {
       $number = $namedParameters['number'];
        // Example code. This code must be modified to do what the operator should do. Currently it only trims text.
        switch ( $operatorName )
        {
            case 'wordtrunc':
            {
		$seq='...';
		$length=preg_match_all( "#(\w+)#", $operatorValue, $dummy_match );
		if($length>$number)
                $operatorValue = $this->string_limit_words( $operatorValue, $number).$seq;
		else
		$operatorValue=$operatorValue;
            } break;
        }
    }
    
    function string_limit_words($string, $word_limit) {
     $words = explode(' ', $string);
     return implode(' ', array_slice($words, 0, $word_limit));
   }
}

?>
