<?php

[TemplateSettings]
ExtensionAutoloadPath[]=wordtrunc

?>