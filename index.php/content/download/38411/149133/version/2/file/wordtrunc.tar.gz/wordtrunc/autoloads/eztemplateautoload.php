<?php

// Operator autoloading

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/wordtrunc/autoloads/templatewordtruncoperator.php',
                                    'class' => 'TemplateWordtruncOperator',
                                    'operator_names' => array( 'wordtrunc' ) );

?>