<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=unityweb

[ExtensionSettings]
ActiveExtensions[]=unityweb

[RegionalSettings]
TranslationExtensions[]=unityweb

*/?>