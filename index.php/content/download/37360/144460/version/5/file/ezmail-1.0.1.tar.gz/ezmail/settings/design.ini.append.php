<?php /* 

[ExtensionSettings]
DesignExtensions[]=ezmail

*/ ?>
