<?php /*

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/mailcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/mailsubitemscontextmenu.tpl

*/ ?>