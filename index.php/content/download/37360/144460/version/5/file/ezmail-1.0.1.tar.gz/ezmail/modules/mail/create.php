<?php
//
// Copyright (C) 2005 Lukasz Serwatka <lukasz@serwatka.net>.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

$Module =& $Params["Module"];
$parameters = $Params['Parameters'];

$nodeID = 0;
$objectID = 0;

$object = null;

if ( isset( $parameters['validation'] ) ) 
{
	$validated = $parameters['validation'];	
}
else 
{
	$validated = false;
}

$http =& eZHTTPTool::instance();
$tpl =& templateInit();

if ( $http->hasPostVariable( 'NodeID' ) AND is_numeric( $http->postVariable( 'NodeID' ) ) ) 
{
	$nodeID = $http->postVariable( 'NodeID' );	
}

if ( $http->hasPostVariable( 'ObjectID' ) AND is_numeric( $http->postVariable( 'ObjectID' ) ) ) 
{
	$objectID = $http->postVariable( 'ObjectID' );	
}

if ( $objectID != 0 )
	$object = eZContentObject::fetch( $objectID );

if ( is_object( $object ) )
{
	$ini =& eZINI::instance();

	$userClassID = $ini->variable( 'UserSettings', 'UserClassID' );
	$contentClassID = $object->attribute( 'contentclass_id' );

	if ( $contentClassID == $userClassID )
	{
		$user =& eZUser::fetch( $object->attribute( 'id' ) );
		$tpl->setVariable( 'user', $user );
	}
}

$tpl->setVariable( 'validaton', $validated );

$Result = array();
$Result['content'] = $tpl->fetch( 'design:mail/create.tpl' );
$Result['path'] = array( array( 'url' => '/mail/create',
                                'text' => "Create a new message") );
?>