<?php
//
// Copyright (C) 2005 Lukasz Serwatka <lukasz@serwatka.net>.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

$Module = array( 'name' => 'mail' );

$ViewList = array();
$ViewList['create'] = array( 'functions' => array( 'edit' ),
							 'script' => 'create.php',
						     'ui_context' => 'administration',
						     'default_navigation_part' => 'ezusernavigationpart' );
$ViewList['send'] = array( 'script' => 'send.php',
						   'ui_context' => 'administration',
						   'default_navigation_part' => 'ezusernavigationpart',
						   'single_post_actions' => array( 'SendButton' => 'Send',
						   								   'BackButton' => 'Back',
						   								   'CancelButton' => 'Cancel' ) );
?>
