<?php
//
// Copyright (C) 2005 Lukasz Serwatka <lukasz@serwatka.net>.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( 'lib/ezutils/classes/ezmailtransport.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

$Module =& $Params["Module"];

$http =& eZHTTPTool::instance();
$tpl =& templateInit();

if ( $Module->isCurrentAction( 'Cancel' ) ) 
{   
	$contentINI =& eZINI::instance( 'content.ini' );
    $userRootNodeID = $contentINI->variable( 'NodeSettings', 'UserRootNode' );
   	return $Module->redirectTo( '/content/view/full/' . $userRootNodeID );
}    
    
if ( $Module->isCurrentAction( 'Back' ) ) 
{   
    $contentINI =& eZINI::instance( 'content.ini' );
    $userRootNodeID = $contentINI->variable( 'NodeSettings', 'UserRootNode' );
	return $Module->redirectTo( '/content/view/full/' . $userRootNodeID );
}

if ( $Module->isCurrentAction( 'Send' ) ) 
{
	$mail = new eZMail();
	$receiver = false;
	$mailBody = '';
	$mailSubject = '';
	$emailSender = '';
	$contentType = 'text/plain';
	$replyTo = '';

	switch ( $http->postVariable( 'ContentType' ) )
	{
		case 0:
			$contentType = 'text/plain';
			break;
		case 1:
			$contentType = 'text/html';
			break;
	}
	
	if ( $http->hasPostVariable( 'ReplyTo' ) )
	{
		$replyTo = $http->postVariable( 'ReplyTo' );
		
		if ( $replyTo != '' )
		{
			if ( !eZMail::validate( $replyTo ) )
			{
				return $Module->run( 'create', array( 'validation' => true ) );
			}
		}
	}
	
	$mail->setContentType( $contentType );
	$mail->setReplyTo( $replyTo );
	
	$mail->setExtraHeader( 'X-Priority', $http->postVariable( 'Priority' ) );

	if ( $http->hasPostVariable( 'Message' ) )
	{
		$mailBody = $http->postVariable( 'Message' );
		
		if ( $mailBody == '' ) 
		{
			return $Module->run( 'create', array( 'validation' => true ) );
		
		}
	}
	
	if ( $http->hasPostVariable( 'Subject' ) )
	{
		$mailSubject = $http->postVariable( 'Subject' );
		
		if ( $mailSubject == '' ) 
		{
			return $Module->run( 'create', array( 'validation' => true ) );
		
		}
	}
	
	if ( $http->hasPostVariable( 'To' ) )
	{
		$receiver = $http->postVariable( 'To' );
		
		if ( $receiver == '' ) 
		{
			return $Module->run( 'create', array( 'validation' => true ) );
		
		}
		if ( !eZMail::validate( $receiver ) )
		{
			return $Module->run( 'create', array( 'validation' => true ) );
		}
	}
	
	$ini =& eZINI::instance();

	$emailSender = $ini->variable( 'MailSettings', 'EmailSender' );
		
	$mail->setReceiver( $receiver );
	$mail->setSender( $emailSender );
	$mail->setSubject( $mailSubject );
	$mail->setBody( $mailBody );
	$mailResult = eZMailTransport::send( $mail );
	
	$tpl->setVariable( 'mail_result', $mailResult );
}

$Result = array();
$Result['content'] = $tpl->fetch( 'design:mail/send.tpl' );
$Result['path'] = array( array( 'url' => '/mail/send',
                                'text' => "Send message") );
?>