<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezmail

*/ ?>