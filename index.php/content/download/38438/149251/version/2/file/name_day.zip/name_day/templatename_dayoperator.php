<?php
/*!
  \class   TemplateName_dayOperator templatename_dayoperator.php
  \ingroup eZTemplateOperators
  \brief   Configuration of the operator name_day. Using  name_day you can display name day of the basing on input.
  \version 1.0
  \date    05.10.2007 8:20:49 am
  \author  Juliusz Calyniuk

  

  Example:
\code
{$value|name_day|wash}
\endcode
*/

class TemplateName_dayOperator
{
    function TemplateName_dayOperator()
    {
    }

    function operatorList()
    {
        return array( 'name_day' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    function namedParameterList()
    {
        return array( 'name_day' => array( 'first_param' => array( 'type' => 'string',
                                                                   'required' => false,
                                                                   'default' => 'default text' ),
                                           'second_param' => array( 'type' => 'integer',
                                                                    'required' => false,
                                                                    'default' => 0 ) ) );
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        include_once('extension/name_day/mod_imieniny.php');

        $firstParam = $namedParameters['first_param'];
        $secondParam = $namedParameters['second_param'];

        switch ( $operatorName )
        {
            case 'name_day':
            {
                $id = $firstParam . '-' . $secondParam;
                $operatorValue = $name_day["$id"];
                trim( $operatorValue );
            } break;
        }
    }
}

?>
