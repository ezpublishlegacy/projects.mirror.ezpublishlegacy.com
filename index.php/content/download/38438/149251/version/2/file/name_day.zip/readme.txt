****************************************************************************
*
*	eZ Publish template operator - Name-day
*   Copyright (C) 2007  Webstyle Systems, http://www.ws-webstyle.com
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
****************************************************************************

It's a template operator that displays names according to given day and month.

Installation:
1) Copy this edit handler to extensions directory of eZ Publish
2) Turn on extension in administration panel or by adding activating it in
override/site.ini.append.php settings file:

[ExtensionSettings]
ActiveExtensions[]=name_day

Enjoy

Usage:
{$variable|name_day($param1, $param2)}

where:
$param1 - month
$param2 - day of the month