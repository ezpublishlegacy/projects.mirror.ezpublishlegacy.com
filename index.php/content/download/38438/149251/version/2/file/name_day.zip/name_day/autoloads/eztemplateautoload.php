<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/name_day/templatename_dayoperator.php',
                                    'class' => 'TemplateName_dayOperator',
                                    'operator_names' => array( 'name_day' ) );
?>