
[ezjscServer]
FunctionList[]=groupdocssignature

[ezjscServer_groupdocssignature]
Class=GroupdocssignatureServerCallFunctions
File=extension/groupdocssignature/classes/groupdocssignatureservercallfunctions.php
//Functions[]=groupdocssignature
// {*Not a valid ezjscServerRouter argument: &quot;ezjscdemo::search&quot;*}
// {*http://svn.projects.ez.no/ezjscore/trunk/packages/ezjscore_extension/documents/example/ezjscore_demo/FAQ - point 4*}

