<?php /*
[NavigationPart]
Part[groupdocsnavigationpart]=GD Signature
[TopAdminMenu]
Tabs[]=groupdocssig
[Topmenu_groupdocssig]
NavigationPartIdentifier=groupdocsnavigationpart
Name=Groupdocs Signature
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocssignature/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>