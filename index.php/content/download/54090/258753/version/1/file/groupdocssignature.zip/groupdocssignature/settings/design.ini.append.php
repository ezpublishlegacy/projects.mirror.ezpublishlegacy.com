<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocssignature

#[StylesheetSettings]
#BackendCSSFileList[]=gdsignature_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdsignature.js
*/ ?>