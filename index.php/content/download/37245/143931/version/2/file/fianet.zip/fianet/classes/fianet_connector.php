<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/


function send_request(&$process, &$event){
    $http =& eZHTTPTool::instance();
    include_once( 'kernel/classes/ezorder.php' );
    include_once( 'kernel/classes/ezorderitem.php' );
    include_once( 'kernel/classes/ezcontentobject.php' );
    include_once( 'kernel/classes/ezcontentobjectattribute.php' );
    include_once( 'lib/ezutils/classes/ezini.php' );
    include_once( 'lib/ezxml/classes/ezxml.php' );
    include_once( 'lib/ezutils/classes/ezlog.php' );
	eZLog::write( 'Debut envoi a FiaNet '."\n", 'fianet.log' );

	include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
	$log = eZPaymentLogger::CreateForAdd( "var/log/mercanetType.log" );
    $log->writeTimedString( 'Fianet' );


    $ini = eZINI::instance( 'fianet.ini' );
    $StatusCanceledId = $ini->variable( 'Orders', 'StatusCanceledId' );
    $siteId = $ini->variable( 'Site', 'siteId' );
    $parameters =& $process->attribute('parameter_list');

    $orderID = $parameters['order_id'];
    $userID = $parameters['user_id'];
	eZLog::write( 'UserId donne par les parameters '.$userID."\n", 'fianet.log' );
    $o_order = eZOrder::fetch($orderID);
    $userID = $o_order->attribute('user_id');
    eZLog::write( 'UserId de la commande '.$userID."\n", 'fianet.log' );

    $refId = $o_order->attribute('order_nr');

    $tab_civilite = array('monsieur','madame','mademoiselle');

    $o_user = eZContentObject::fetch($userID);

    $user = $o_user->dataMap();
    $firstName = ( isset( $user['first_name'] ) )? $user['first_name']->content() : '';
    $lastName = ( isset( $user['last_name'] ) )? $user['last_name']->content() : '';
    $company = ( isset( $user['company'] ) )? $user['company']->content() : '';
    $street1 = ( isset( $user['street1'] ) )? $user['street1']->content() : '';
    $street2 = ( isset( $user['street2'] ) )? $user['street2']->content() : '';
    $zipCode = ( isset( $user['zipcode'] ) )? $user['zipcode']->content() : '';
    $city = ( isset( $user['city'] ) )? $user['city']->content() : '';
    $phone = ( isset( $user['phone'] ) )? $user['phone']->content() : '';
    $civ_tmp = ( isset( $user['civilite'] ) )? $user['civilite']->content() : '';
    $civilite = $tab_civilite[$civ_tmp[0]];
    $country = "FRANCE";
    /* On recupere l'adresse IP de l'internaute */
    if (getenv('HTTP_CLIENT_IP')) {
	$remoteip = getenv('HTTP_CLIENT_IP');
    } elseif (getenv('HTTP_X_FORWARDED_FOR')) {
	$remoteip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif (getenv('HTTP_X_FORWARDED')) {
	$remoteip = getenv('HTTP_X_FORWARDED');
    } elseif (getenv('HTTP_FORWARDED_FOR')) {
	$remoteip = getenv('HTTP_FORWARDED_FOR');
    } elseif (getenv('HTTP_FORWARDED')) {
	$remoteip = getenv('HTTP_FORWARDED');
    } else {
	$remoteip = $_SERVER['REMOTE_ADDR'];
    }
    /* Si il y a une adress de livraison differente */
    if ($o_order->attribute('data_text_2') != ''){
        $adressLivraison = explode("\n",$o_order->attribute('data_text_2'));
        $firstNameLivraison = $adressLivraison[2];
        $firstNameLivraison = ltrim( str_replace(array("<first-name>","</first-name>"),'',$firstNameLivraison));
        $lastNameLivraison = $adressLivraison[3];
        $lastNameLivraison = ltrim( str_replace(array("<last-name>","</last-name>"),'',$lastNameLivraison));
        $societeLivraison = $adressLivraison[4];
        $societeLivraison = ltrim( str_replace(array("<company>","</company>"),'',$societeLivraison));
        $street1Livraison = $adressLivraison[5];
        $street1Livraison = ltrim( str_replace(array("<street1>","</street1>"),'',$street1Livraison));
        $street2Livraison = $adressLivraison[6];
        $street2Livraison = ltrim( str_replace(array("<street2>","</street2>"),'',$street2Livraison));
        $zipCodeLivraison = $adressLivraison[7];
        $zipCodeLivraison = ltrim( str_replace(array("<zipcode>","</zipcode>"),'',$zipCodeLivraison));
        $cityLivraison = $adressLivraison[8];
        $cityLivraison = ltrim( str_replace(array("<city>","</city>"),'',$cityLivraison));
        $phoneLivraison= $adressLivraison[9];
        $phoneLivraison=ltrim( str_replace(array("<phone>","</phone>"),'',$phoneLivraison));
        $civiliteLivraison =$adressLivraison[10];
        $civiliteLivraison =ltrim( str_replace(array("<civilite>","</civilite>"),'',$civiliteLivraison));
        $civiliteLivraison =$tab_civilite[$iciviliteLivraison];
    }

    /* Ici nous avons recupere les donnees de livraison et facturation */
    $request = '<?xml version="1.0" encoding="ISO-8859-1"?><control>';
    $request .= '<utilisateur type="facturation"';
    ($company!='')? $request .= ' qualite="1">' : $request .= ' qualite="2">';
    $request .= '<nom titre="'.$civilite.'">'.$lastName.'</nom>';
    /* On verifie si le telephone est un portable */
    if (!strncmp($phone, "06", 2)) {
        $request .= '<telmobile>'.$phone.'</telmobile>';
    } else {
        $request .= '<telhome>'.$phone.'</telhome>';
    }
    $request .= '<prenom>'.$firstName.'</prenom>';
    $request .= '<societe>'.$company.'</societe>';
    $request .= '<email>'.$o_order->attribute('email').'</email>';
    $request .= '</utilisateur>';
    $request .= '<adresse type="facturation" format="1">';
    $request .= '<rue1>'.$street1.'</rue1>';
    $request .= '<rue2>'.$street2.'</rue2>';
    $request .= '<cpostal>'.$zipCode.'</cpostal>';
    $request .= '<ville>'.$city.'</ville>';
    $request .= '<pays>'.$country.'</pays>';
    $request .= '</adresse>';
    if ($adressLivraison and $societeLivraison != "Nexecom"){
        if ( strtoupper($lastName) != strtoupper($lastNameLivraison) or strtoupper($firstName) != strtoupper($firstNameLivraison) ){
            $request .= '<utilisateur type="livraison"';
            ($societeLivraison!='')? $request .= ' qualite="1">' : $request .= ' qualite="2">';
            $request .= '<nom titre="'.$civiliteLivraison.'">'.$lastNameLivraison.'</nom>';
            if (!strncmp($phoneLivraison, "06", 2)) {
		$request .= '<telmobile>'.$phoneLivraison.'</telmobile>';
            } else {
		$request .= '<telhome>'.$phoneLivraison.'</telhome>';
            }
            $request .= '<prenom>'.$firstNameLivraison.'</prenom>';
            $request .= '<societe>'.$societeLivraison.'</societe>';
            $request .= '</utilisateur>';
        }
        $request .= '<adresse type="livraison" format="1">';
        $request .= '<rue1>'.$street1Livraison.'</rue1>';
        $request .= '<rue2>'.$street2Livraison.'</rue2>';
        $request .= '<cpostal>'.$zipCodeLivraison.'</cpostal>';
        $request .= '<ville>'.$cityLivraison.'</ville>';
        $request .= '<pays>'.$country.'</pays>';
        $request .= '</adresse>';
    }
    /* Balise obligatoire de paiement */
    $request .= '<paiement><type>carte</type></paiement>';

    /* On va rentrer toutes les infos sur la commande */
    $request .= '<infocommande>';
    $products = $o_order->productItems();

    $countProd = 0;
    $requestTemp = "";
    $price = 0;
    foreach ($products as $product){
        $o_product = eZContentObject::fetch($product['item_object']->attribute('contentobject_id'));
        $o_prod = $o_product->dataMap();
        $product_number = $o_prod['product_number']->content();
        $requestTemp .= '<produit ref="'.$product_number.'" nb="'.$product['item_count'].'">'.$product['object_name'].'</produit>';
        $price = $price + $product['total_price_inc_vat'];
    }

    $request .= '<list nbproduit="'.$countProd.'">';
    $request .= $requestTemp;
    $request .= '</list>';

    $livraison = eZOrderItem::fetchList( $orderID );
    if ($livraison){
        $price = $price + $livraison[0]->priceIncVAT();
    }

    $request .= '<montant devise="EUR">'.$price.'</montant>';
    $request .= '<refid>'.$refId.'</refid>';
    $request .= '<siteid>'.$siteId.'</siteid>';
    $request .= '<transport>';
    $request .= '<type>';
    if ($societeLivraison == "Societe"){
        $request .= '1</type>';
        $request .= '<nom>Societe</nom>';
    }else{
        $request .= '4</type>';
        $request .= '<nom>Colissimo</nom>';
    }
    $request .= '<rapidite>2</rapidite>';
    $request .= '</transport>';
    // $request .= '<ip timestamp="'.date("Y-m-d H:i:s").'">'.$_SERVER['REMOTE_ADDR'].'</ip>';
    $request .= '<ip timestamp="'.date("Y-m-d H:i:s").'">'.$remoteip.'</ip>';


    $request .= '</infocommande>';
    $request .= '</control>';

	$accentued = array("À","�?","Â","Ã","Ä","Å","Æ","Ç","È","É","Ê","Ë","Ì","�?","Î","�?","�?","Ñ","Ò","Ó","Ô","Õ","Ö","Ø","Ù","Ú","Û","Ü","�?","Þ","ß","à","á","â","ã","ä","å","æ","ç","è","é","ê","ë","ì","í","î","ï","ð","ñ","ò","ó","ô","õ","ö","ø","ù","ú","û","ü","ý","ý","þ","ÿ");
	$noaccentued = array("A","A","A","A","A","A","A","C","E","E","E","E","I","I","I","I","D","N","O","O","O","O","O","O","U","U","U","U","Y","b","s","a","a","a","a","a","a","a","c","e","e","e","e","i","i","i","i","d","n","o","o","o","o","o","o","u","u","u","u","y","y","b","y");
	$request = str_replace($accentued, $noaccentued, $request);

	$uri = "https://secure.fia-net.com/fscreener/engine/redirect.cgi";
	$port = "443";
    include_once( 'lib/ezutils/classes/ezhttptool.php' );
    $http =& eZHTTPTool::instance();

	$postParameters['siteid'] = $siteId;
    $postParameters['controlcallback'] = $request;

    eZLog::write( 'Donnees preparees et prete a etre envoyees '."\n", 'fianet.log' );

	$payment = $o_order->attribute('payment');

	for ( $i = 1; $i<=3; $i++){
		eZLog::write( 'Envoi ... '."\n", 'fianet.log' );
	    $http->sendHTTPRequest( $uri, $port, $postParameters, 'eZ publish', false );
	}
	
	eZLog::write( 'Fin traitement  '."\n", 'fianet.log' );

    return true;
}

?>
