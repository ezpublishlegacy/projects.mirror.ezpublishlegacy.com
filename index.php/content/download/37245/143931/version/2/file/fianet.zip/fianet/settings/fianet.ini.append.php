<?php */

[Orders]
StatusCanceledId=1000
ClassResponseId=30

[Site]
siteId=4385
login=//edit your login
password=//edit your pass
*/ ?>
