<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

define( "eZFianetType_EventName", "ezfianet" );

class eZFianetType extends eZWorkflowEventType
{
	const WORKFLOW_TYPE_STRING = 'ezfianet';
    function eZFianetType()
    {
        $this->eZWorkflowEventType( eZFianetType_EventName, "FiaNet");
        $this->setTriggerTypes(array('shop'=>array('checkout'=>array('after'))));
    }

    function execute(&$process, &$event)
    {
        include_once( eZExtension::baseDirectory() . '/fianet/classes/fianet_connector.php' );
        include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
		$log = eZPaymentLogger::CreateForAdd( "var/log/mercanetType.log" );
		$log->writeTimedString( 'Declenchement Fianet' );
        send_request(&$process, &$event);
        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }
}
// ez3.xx
//eZWorkflowEventType::registerType( eZFianetType_EventName , "ezfianettype" );
// ez4.x
eZWorkflowEventType::registerEventType( eZFianetType::WORKFLOW_TYPE_STRING, "eZFianetType" );

?>
