<?php /*

[EventSettings]
ExtensionDirectories[]=fianet
AvailableEventTypes[]=event_ezfianet

*/ ?>
