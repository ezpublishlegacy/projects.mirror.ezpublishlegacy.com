<?php /*

[ExtensionSettings]
DesignExtensions[]=fianet

*/ ?>
