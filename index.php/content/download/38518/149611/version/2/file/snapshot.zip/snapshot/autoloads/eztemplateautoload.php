<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/snapshot/autoloads/snapshot.php',
         'class' => 'MySnapshotOperator',
         'operator_names' => array( 'ezsnapshot' ) );

?>