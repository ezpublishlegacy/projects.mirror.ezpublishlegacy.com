<?php

[General]
SavePathRoot[]=var/storage/snapshot_images/

?>
