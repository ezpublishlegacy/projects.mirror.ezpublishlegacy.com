Snapshot Operator
-----------------


0. Intro
--------
This extension is the result of the attempt to grab the first frame of any swf-file to use it as a preview. Unfortunatly I didn't get there, but the thing works for many other movie formats so I publish it anyway. Hope it can be be usefull for sombody else.

The operator uses the ffmpeg (http://ffmpeg.sourceforge.net) and ffmpeg-php (http://ffmpeg-php.sourceforge.net) software, and these are prerequisits to get this thing to work.

Shold work on any of the movie-formats as specified in http://ffmpeg.sourceforge.net/ffmpeg-doc.html#SEC16, but has only been tested with avi and mpeg. 


1. Installation
---------------

a) Install the ffmpeg and ffmpeg-software.


b) Follow these steps to add the Snapshot datatype to your ezp installation:

   1) Extract the archive into the /extension directory
  
   2) Activate in the admin interface

c) Configure the snapshot.ini.append.php file to specify where you want the images to be saved. Don't forget chmod'ing :-)



2. Features
-----------
- grabs a snapshot of a movie and saves it as a png
- then return the path to this image



3. Usage
--------
This is an example of usage in a template:

<img src="{ezsnapshot($my_fetched_node.data_map.file.content.filepath,2)}">


4. ToDo
-------
- add resizing



Developed by Felix Laate (felix@enternett.no).