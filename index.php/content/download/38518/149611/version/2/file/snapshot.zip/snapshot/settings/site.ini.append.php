<?php

[TemplateSettings]
ExtensionAutoloadPath[]=snapshot

?>