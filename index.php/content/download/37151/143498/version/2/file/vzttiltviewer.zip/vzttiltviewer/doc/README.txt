INTRO: 
The VZTTiltViewer uses tiltviewer flash http://www.simpleviewer.net/tiltviewer/ to present gallery

DESCRIPTION:
This extension allowes you to show images either from your Flickr account or from local images in the gallery
The setting "useFlickr" determins which option to use.
Edit the settings for Flickr tags etc.
If you want to use local images in the gallery, set the "usFlickr" setting to false for activating xml-option.
This allowes for creating an xml-file with imageinfo that the tiltviewer-flash can read.
Remember to give writing permissions for /extension/vzttiltviewer/design/standard/javascript folder
Configuration is described here http://www.simpleviewer.net/tiltviewer/support/options.html

REQUIREMENTS:
- eZ publish 4.x
- Access to chmod if you want to use the xml option

INSTALLATION:
Read INSTALL.txt =)

USE
Check site.ini for settings that allowes you to 
- change colors on frame, border, etc.
- allow/disallow flipoverbutton, link, reload etc.
- change size of frame
- change nr. of rows and columns

