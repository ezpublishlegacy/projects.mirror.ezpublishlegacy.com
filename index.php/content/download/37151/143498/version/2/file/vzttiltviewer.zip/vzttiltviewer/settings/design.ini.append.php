<?php /* 

[ExtensionSettings]
DesignExtensions[]=vzttiltviewer

*/ ?>
