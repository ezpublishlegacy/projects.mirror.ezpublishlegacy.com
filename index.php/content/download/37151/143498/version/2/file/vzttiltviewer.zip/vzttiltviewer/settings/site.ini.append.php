<?php /*

[TemplateSettings]
AutoloadPathList[]=extension/vzttiltviewer/autoloads

[VztTWSettings]
#Flickr settings
useFlickr=false
user_id=22671198@N02
tag_mode=all
tags=jump,smile
showTakenByText=true
#Framesettings
useReloadButton=true
showFlipButton=true
showLinkButton=true
columns=4
rows=4
linkLabel=Show image
frameColor=0x000000
backColor=0xcccccc
bkgndInnerColor=0xffffff
bkgndOuterColor=0xffffff
langGoFull=Go Fullscreen
langExitFull=Exit Fullscreen
langAbout=About
allowFullScreen=true
frameHeight=565
frameWidth=565
#Xml
maxJPGSize=200
xmlURL=

#http://www.simpleviewer.net/tiltviewer/support/options.html

*/
?>