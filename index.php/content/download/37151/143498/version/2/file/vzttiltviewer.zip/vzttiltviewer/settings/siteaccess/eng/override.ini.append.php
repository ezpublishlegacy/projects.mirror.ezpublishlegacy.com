<?php /* #?ini charset="iso-8859-1"?

[full_album_gallery]
Source=node/view/full.tpl
MatchFile=full/albumgallery.tpl
Subdir=templates
Match[class_identifier]=gallery

*/ ?>