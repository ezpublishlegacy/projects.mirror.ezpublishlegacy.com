<?php

/*
VZTTiltViewer

Copyright (C) 2010 VZT 
Written by Petter Arneson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

class VZTTiltViewer
{

    function VZTTiltViewer()
    {
        $this->Operators = array( 'vzttiltviewer');
    }

    function operatorList()
    {
        return $this->Operators;
    }

    function namedParameterPerOperator()
    {
        return true;
    }

    function namedParameterList()
    {
        return array( 	'vzttiltviewer' => array( 	'args' => array( 'type' => 'array',
                                                                 'required' => true,
                                                                 'default' => '' ) ) );
	}

    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace,
                     $currentNamespace, &$operatorValue, $namedParameters )
    {
        switch ( $operatorName )
        {
            case 'vzttiltviewer':
            {
                $operatorValue = $this->VZTOperatorResult( $namedParameters['args'] );
            } break;
        }
    }

    function VZTOperatorResult( $args )
    {

		switch ( $args['function'] )
        {
			case 'writexml':
            {
				$imgStr   = $args['imgstring'];
				$gallery  = $args['galleryid'];
				/* $startStr = '<?xml version="1.0" encoding="UTF-8"?><tiltviewergallery><photos>'; */
				$startStr = '<tiltviewergallery><photos>';
				$endStr   = '</photos></tiltviewergallery>';
				$xmlStr   = $startStr.$imgStr.$endStr;
				$name 	  = "gallery".$gallery.".xml";
				$path	  = "extension/vzttiltviewer/design/standard/javascript/";
				$filename = $path.$name;
				
				$create = false;
				
				if(!$handle = fopen($filename, "r"))
				{
					$create = true;
				}
				else
				{
					$fileStr 	= fread($handle, filesize($filename));
					$md5fileStr = md5($fileStr);
					$md5xmlStr  = md5($xmlStr);
					
					if($md5fileStr != $md5xmlStr)
					{
						$create = true;
					}
	
					fclose($handle);
				}
				
				if($create)
				{
						
					if (!$handle = fopen($filename, 'w')) {
						echo "Could not create file ($filename)";
						exit;
					}
					if (fwrite($handle, $xmlStr) === FALSE) {
						echo "Could not write to file ($filename)";
						exit;
					}
					//echo "Success, wrote ($xmlStr) to file ($filename)";
					fclose($handle);
				}
				
			} break;
			
        }
    }


    var $Operators;
}

?>
