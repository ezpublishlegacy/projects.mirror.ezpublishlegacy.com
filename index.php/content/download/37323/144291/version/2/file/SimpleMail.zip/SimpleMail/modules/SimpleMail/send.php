<?php
//
// Created on: <2006/11> pike@labforculture.org
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//


	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( 'kernel/common/template.php' );


	$Module =& $Params['Module'];
	$success = false;

	$SimpleMailINI =& eZINI::instance( MODULE_INI_FILE,"extension/SimpleMail/settings" );
	$SimpleMailIniSection = 'SimpleMailSettings';
	$http =& eZHTTPTool::instance();

	$formtpl = ($http->hasVariable("formtpl")) ?$http->variable("formtpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultFormTemplate' );
	$successtpl = ($http->hasVariable("successtpl")) ?$http->variable("successtpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSuccesTemplate' );
	$errortpl = ($http->hasVariable("errortpl")) ?$http->variable("errortpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultErrorTemplate' );
	$mailtpl = ($http->hasVariable("mailtpl")) ?$http->variable("mailtpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultMailTemplate' );
	$recipient = ($http->hasVariable("recipient")) ?$http->variable("recipient"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultRecipient' );
	$sender = ($http->hasVariable("sender")) ?$http->variable("sender"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSender' );
	$subject = ($http->hasVariable("subject")) ?$http->variable("subject"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSubject' );


	$valid_recipients =	$SimpleMailINI->variable( $SimpleMailIniSection, 'AllowedRecipients' );
	$always_bcc =	$SimpleMailINI->variable( $SimpleMailIniSection, 'AlwaysBCC' );

	if (is_array($recipient)) $recipients = $recipient;
	else $recipients = explode(",",$recipient);
	$recipientsok = true;
	foreach ($recipients as $arecipient) {
		$recipientsok = $recipientsok && (in_array($arecipient,$valid_recipients));
	}
	$recipient = implode($recipients,",");

	$data = array();

	/* loop the other data myself. ezhttptool doesnt do that */
	foreach($_GET as $name=>$value) {
		switch ($name) {
			case "formtpl":
			case "successtpl":
			case "errortpl":
			case "mailtpl":
			case "recipient":
			case "sender":
			case "subject":
			case "submit":
			case "error":
				break;
			default :
				$data[$name]=$value;
		}
	}
	foreach($_POST as $name=>$value) {
		switch ($name) {
			case "formtpl":
			case "successtpl":
			case "errortpl":
			case "mailtpl":
			case "recipient":
			case "sender":
			case "subject":
			case "submit":
			case "error":
				break;
			default :
				$data[$name]=$value;
		}
	}

	/* simply mail it */



	$view_parameters = array(
		"formtpl" => $formtpl ,
		"successtpl" => $successtpl ,
		"errortpl" => $errortpl ,
		"mailtpl" => $mailtpl ,
		"recipient" => $recipient ,
		"sender" => $sender ,
		"subject" => $subject ,
		"error" => "",
		"data" => $data
	);

	if (count($recipients)) {
		if ($recipientsok) {
			if ($sender) {
				$tpl =& templateInit();
				$tpl->setVariable( 'view_parameters', $view_parameters );
				$body = $tpl->fetch( 'design:SimpleMail/'.$mailtpl.'.tpl' );
	
				$headers = "";
				$headers .= "From: $sender\n";
				$headers .= "X-Mailer: EZPublish SimpleMail\n"; // mailer
				if ($always_bcc) $headers .= "bcc:$always_bcc\n";
				
				// -------- mail ------------
				$success = mail($recipient, $subject, $body, $headers);
				// -------- ---- ------------
				
				if (!$success) {
					$view_parameters["error"] = "Perhaps your server doesn't allow this ?";
				}
			} else {
				$view_parameters["error"] = "Sorry, a sender address is required.";
				$success=false;
	
			}
		} else {
			if (count($recipients)==1) $view_parameters["error"] = "Sorry, <$recipient> is not listed as a valid recipient.";
			else $view_parameters["error"] = "Sorry, one of the recipients in '$recipient' is not listed as a valid recipient.";
			$success=false;
		}
	} else {
		$view_parameters["error"] = "Sorry, at least one recipient is required.";
		$success=false;
	}

	$Result = array();
	$tpl =& templateInit();
	$tpl->setVariable( 'view_parameters', $view_parameters );
	if ($success) {
		$Result['content'] = $tpl->fetch( 'design:SimpleMail/'.$successtpl.'.tpl' );
		$Result['path'] = array(
			array( 'url' => false,									'text' => 'Mail' ),
			array( 'url' => '/SimpleMail/'.$formtpl, 				'text' => 'Form' ),
			array( 'url' => false,									'text' => 'Sent' ),
		);
	} else {
	 	$Result['content'] = $tpl->fetch( 'design:SimpleMail/'.$errortpl.'.tpl' );
	 	$Result['path'] = array(
			array( 'url' => false,									'text' => 'Mail' ),
			array( 'url' => '/SimpleMail/'.$formtpl, 				'text' => 'Form' ),
			array( 'url' => false,									'text' => 'Error' ),
		);
	}
?>