<?php
	//
	// Created on: <2006/11> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//


	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( 'kernel/common/template.php' );

	$SimpleMailINI =& eZINI::instance( MODULE_INI_FILE,"extension/SimpleMail/settings" );
	$SimpleMailIniSection = 'SimpleMailSettings';

	$http =& eZHTTPTool::instance();

	// you came here with a view. because of how module.php
	// works, this view must have been one defined in module.ini
	$formtpl =$Params['FunctionName'];

	// all other params can be set by http
	$successtpl = ($http->hasVariable("successtpl")) ?$http->variable("successtpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSuccesTemplate' );
	$errortpl = ($http->hasVariable("errortpl")) ?$http->variable("errortpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultErrorTemplate' );
	$mailtpl = ($http->hasVariable("mailtpl")) ?$http->variable("mailtpl"):$SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultMailTemplate' );

	$recipient = ($http->hasVariable("recipient")) ?$http->variable("recipient"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultRecipient' );
	$sender = ($http->hasVariable("sender")) ?$http->variable("sender"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSender' );
	$subject = ($http->hasVariable("subject")) ?$http->variable("subject"): $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultSubject' );

	// if someone tries to set recipient, check if thats ok
	$valid_recipients =	$SimpleMailINI->variable( $SimpleMailIniSection, 'AllowedRecipients' );
	if (!in_array($recipient,$valid_recipients)) {
		$recipient = $SimpleMailINI->variable( $SimpleMailIniSection, 'DefaultRecipient' );
	}

	$data = array(); // no data yet


	$view_parameters = array(
		"formtpl" 		=> $formtpl ,
		"successtpl" 	=> $successtpl ,
		"errortpl" 		=> $errortpl ,
		"mailtpl" 		=> $mailtpl ,
		"recipient" 	=> $recipient ,
		"sender" 		=> $sender ,
		"subject" 		=> $subject ,
		"error" 		=> "" ,
		"data" 		=> $data
	);



	$tpl =& templateInit();
	$tpl->setVariable( 'view_parameters', $view_parameters );

	$Result = array();
	$Result['content'] = $tpl->fetch( 'design:SimpleMail/'.$formtpl.'.tpl' );
	$Result['path'] = array(
		array( 'url' => false,						'text' => 'Mail' ),
		array( 'url' => '/SimpleMail/'.$formtpl, 	'text' => 'Form' )
	);


?>