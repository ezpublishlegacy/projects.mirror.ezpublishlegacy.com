<?php
/*
[ExtensionSettings]
DesignExtensions[]=SimpleMail
*/
?>