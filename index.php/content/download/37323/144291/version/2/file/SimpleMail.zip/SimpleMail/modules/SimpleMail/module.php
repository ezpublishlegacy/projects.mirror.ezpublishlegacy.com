<?php
//
// Created on: <16-Feb-2005>
//
// Copyright (C) 2005-2004 Olivier Pierret & NSI-SA. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

define( "MODULE_INI_FILE", "module.ini" );

$Module = array( 'name' => 'SimpleMail' );

$SimpleMailINI =& eZINI::instance( MODULE_INI_FILE,"extension/SimpleMail/settings" );
$SimpleMailIniSection = 'SimpleMailSettings';
$templates = $SimpleMailINI->variable( $SimpleMailIniSection, 'FormTemplates' );


$ViewList = array();
foreach($templates as $template) {
	// all templates will automatically be views using form.php
	// form.php detects the view of the module to
	// decide which template to parse
	$ViewList[$template] 		= array('script' => 'form.php' );
}
// the send view is reserved for send.php
// send.php takes http variables
// to decide which templates to parse
$ViewList['send'] 		= array('script' => 'send.php' );




?>