
// SimpleMail for ezPublish
// Created: <2006/11> pike@labforculture.org

=============
SIMPLEMAIL
=============

SimpleMail simply sends mail. It does not bother with nodes,
objects, content classes or information collectors. It receives
a form - a template you write - and mails it to a recipient.

In fact, it uses several templates:
	 - a form
	 - a succespage
	 - an errorpage
	 - a mailmessage
	 
You can override these in your own design. You can also
define new templates for them. Read on.

=============
HOW TO INSTALL
=============

- Copy the extensiondir to your /extension/ folder
- Go to the admin - setup / extensions
- Enable the extension
- Clear all caches
- Goto http://youradminurl/SimpleMail/form

and have fun.

if you want to use your form in public -makes sense-
remember to give the Anonymous user rights to 
execute all functions in module SimpleMail

=============
HOW TO ADD A RECIPIENT
=============

The recipient is defined inside the form, either as input
or as a hidden field. for example:

 <input type="hidden" name="recipient" value="spam@me.com" />

However, to be able to send mail to that address,
you need to add it to the list of valid recipients:

- open SimpleMail/settings/module.ini.append.php
- add "AllowedRecipients[]=spam@me.com" and save it
- clear all caches


=============
HOW TO CREATE NEW FORMS
=============

You can override the default form in your own design

- go to SimpleMail/design/yourdesign/templates/SimpleMail
- write a new form template ("form.tpl") there 
- clear all caches
- browse to http://yoursiteurl/SimpleMail/form

You can also create other forms in your design

- go to SimpleMail/design/yourdesign/templates/SimpleMail
- write a new form template ("example.tpl") there 
- open SimpleMail/settings/module.ini.append.php
- add "FormTemplates[]= example" and save it
- clear all caches
- browse to http://yoursiteurl/SimpleMail/example

in fact, there is already an example there.

but that's only the form. the other pages - succes,
error, mail - are defined inside the form: 

<input type="hidden"  name="errortpl" 	value="error" />
<input type="hidden"  name="mailtpl" 	value="mail"  /><input type="hidden"  name="formtpl" 	value="yourform"  /><input type="hidden"  name="successtpl" value="yourform2"  />

in the example above, 
- the first two lines are redundant; they are defaults. 
- if you wouldn't specify the third line,
  the error template would include the "default form template"
  instead of your form in case of an error. 
- The fourth line defines a result (succes) page. 
  You should create it yourself; or use the default


=============
FORM FIELDS
=============
		
Inside the form, these formfields have reserved meanings:
	
"formtpl" 	the name of the view you started with 
"successtpl" 	the name of the tpl for succespage
"errortpl" 	the name of the tpl for errorpage
"mailtpl" 	the name of the tpl for sent out mail
"recipient" 	recipient of the message; each recipient 
		must be listed in the ini as a valid recipient;
		can be comma separated list or multiple form fields
"sender" 	sender of the message
"subject" 	subject of the message
"submit"	the dumb name of a standard submit button
"error"		string containg errormsg if any
	
All other fields are stored in 

"data" 		a hash of all other fields
	
The values (or defaults) are available in the following 
templates as $view_parameters['fieldname']

Therefore, your custom fields will be available as 
$view_parameters['data'].yourfield

eg

<input type="hidden" name="recipient" value="{$view_parameters['recipient']}" />
<input type="text" name="message" value="{$view_parameters['data'].message}" />

=============
FAQ
=============

>> it's not sending mail
> it's using php's mail() function, not ezMail.
> is your server set up to send mail from php ?
> check the logs.

>> why do you use $view_parameters in form.tpl ?
> because error.tpl includes form.tpl, below the errormessage. 
> by using the $view_parameters in form.tpl, the form inputs
> will be prefilled for a 'retry' on error



$2c!
*-pike


