<?php
/*
[ModuleSettings]
ExtensionRepositories[]=SimpleMail

[SimpleMailSettings]

FormTemplates[]
FormTemplates[]=form
FormTemplates[]=example

DefaultFormTemplate=form
DefaultSuccesTemplate=success
DefaultErrorTemplate=error
DefaultMailTemplate=mail

DefaultRecipient=spam@ez.no
DefaultSender=spam@ez.no
DefaultSubject=Message from SimpleMail

AllowedRecipients[]
AllowedRecipients[]=spam@ez.no
AllowedRecipients[]=nospam@ez.no

#AlwaysBCC=allspam@ez.no



*/
?>
