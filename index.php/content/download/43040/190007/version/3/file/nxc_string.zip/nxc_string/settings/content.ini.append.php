<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=nxc_string
AvailableDataTypes[]=nxcstring
*/ ?>
