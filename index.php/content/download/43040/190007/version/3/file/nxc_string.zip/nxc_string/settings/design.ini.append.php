<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nxc_string

[JavaScriptSettings]
#JavaScriptList[]=nxc.some_script.js
#BackendJavaScriptList[]=nxc.some_script.js

[StylesheetSettings]
FrontendCSSFileList[]=nxc.string.css
BackendCSSFileList[]=nxc.string.css
*/ ?>
