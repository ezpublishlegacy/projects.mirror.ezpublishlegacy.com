<?php
/**
 * @package nxcString
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    08 Sep 2011
 **/

return array (
	'nxcStringLimitation' => './datatypes/nxcstring/limitation.php'
);
?>
