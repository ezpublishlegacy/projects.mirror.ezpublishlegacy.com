<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="TranslatedByGoogleAPI">NXC cordes</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="TranslatedByGoogleAPI">Entrée requise.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="TranslatedByGoogleAPI">La valeur par défaut</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Limitations Matching</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="TranslatedByGoogleAPI">Il n&amp;#39;ya pas de limites</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Non-correspondance des limites</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="TranslatedByGoogleAPI">Nouvelle limitation</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="unfinished">Matching</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="TranslatedByGoogleAPI">Non-appariement</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="TranslatedByGoogleAPI">Ajouter</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="TranslatedByGoogleAPI">Expression régulière</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="TranslatedByGoogleAPI">Descriptif</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="TranslatedByGoogleAPI">Message d&amp;#39;erreur</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="TranslatedByGoogleAPI">Mise à jour</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="TranslatedByGoogleAPI">Retirer</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="TranslatedByGoogleAPI">Vide</translation>
    </message>
  </context>
</TS>
