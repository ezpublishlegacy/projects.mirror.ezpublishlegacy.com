<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="unfinished">NXC String</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="TranslatedByGoogleAPI">Input richiesto.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="TranslatedByGoogleAPI">Valore di default</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Limitazioni di corrispondenza</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="TranslatedByGoogleAPI">Non ci sono limitazioni</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Non-matching limitazioni</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="TranslatedByGoogleAPI">Nuova limitazione</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="TranslatedByGoogleAPI">Corrispondenza</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="TranslatedByGoogleAPI">Non-matching</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="TranslatedByGoogleAPI">Aggiungere</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="TranslatedByGoogleAPI">Espressione regolare</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="TranslatedByGoogleAPI">Descrizione</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="TranslatedByGoogleAPI">Messaggio di errore</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="TranslatedByGoogleAPI">Aggiornare</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="TranslatedByGoogleAPI">Rimuovere</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="TranslatedByGoogleAPI">Vuoto</translation>
    </message>
  </context>
</TS>
