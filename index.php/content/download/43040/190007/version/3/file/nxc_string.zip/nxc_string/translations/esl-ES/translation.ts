<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="TranslatedByGoogleAPI">NXC cadena</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="TranslatedByGoogleAPI">Entrada requerida.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="TranslatedByGoogleAPI">El valor por defecto</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Limitaciones a juego</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="TranslatedByGoogleAPI">No hay limitaciones</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="TranslatedByGoogleAPI">No coincidencia de las limitaciones</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="TranslatedByGoogleAPI">Nueva limitación</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="TranslatedByGoogleAPI">Coincidencia</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="TranslatedByGoogleAPI">No coincidencia de</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="TranslatedByGoogleAPI">Añadir</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="TranslatedByGoogleAPI">Expresión regular</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="TranslatedByGoogleAPI">Descripción</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="TranslatedByGoogleAPI">Mensaje de error</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="TranslatedByGoogleAPI">Actualización</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="TranslatedByGoogleAPI">Eliminar</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="TranslatedByGoogleAPI">Vacío</translation>
    </message>
  </context>
</TS>
