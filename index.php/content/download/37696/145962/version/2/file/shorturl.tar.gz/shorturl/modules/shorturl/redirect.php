<?php

$Module =& $Params["Module"];
if( $Params['ID'] > 0 ) {
	$db =& eZDB::instance();
	$rows = $db->arrayQuery( 'SELECT * FROM ezurl WHERE id=' . $Params['ID'] );
	if( count( $rows ) > 0 ) {
		$url =& $rows[0];
		if( array_key_exists( 'redirect_count', $url )) {
			$db->query( 'UPDATE ezurl SET redirect_count=redirect_count+1 WHERE id=' . $url['id'] );
		}
		return $Module->redirectTo( $url['url'] );	
	}
}
return $Module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
?>
