<?php

$Module = array( "name" => "shorturl" );

$ViewList = array();
$ViewList["redirect"] = array( "script" => "redirect.php", "params" => array( "ID" ));
?>
