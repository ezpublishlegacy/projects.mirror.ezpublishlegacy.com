#?ini charset="iso-8859-1"?
# eZ publish configuration file for content module
#

[ModuleSettings]
ExtensionRepositories[]=shorturl

[ExtensionSettings]
DesignExtensions[]=shorturl
