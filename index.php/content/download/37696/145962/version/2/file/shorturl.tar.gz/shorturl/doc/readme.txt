﻿
ShortURL extension for eZ publish
---------------------------------

Copyright (C) 2008 IRC (http://www.irc.nl)
Written by Harry Oosterveen

This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this library; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Features
--------

The extension replaces external links in an eZ publish page with a shorter, indirect URL of the form http://www.mysite.com/url/12345 . Here, all links that start with 'http' are considered external links. They may appear as part of an ezxmltext or as a ezurl datatype.

The first purpose is to avoid extremely long links, that may disturb the layout of a text (sort of automatic tinyurl). In addition, it allows for counting the exit links--via which link visitors to your website are leaving.

How it works
------------

Each external link in eZ publish is stored in a table, ezurl. The extension uses the 'id' field of the record in this table to identify the link.
Relevant templates are replaced, so they show a link of the form '/url/12345' instead of the original link, where '12345' is the id of the link in the ezurl table.

The url '/url/12345' is translated to /shorturl/redirect (either by the webserver (serverwide) or the url-translation table of your eZ site. The 'redirect' module reads the original link from the ezurl table, and redirects to it.

Issues
------

In the content/datatype/view/ezxmltags/link.tpl, which displays links in xmltext, only the $href variable is available, not the $url_id. You have to edit the file
kernel/classes/datatypes/ezxmltext/handlers/output/ezxhtmlxmloutput.php to make this variable available, as described in the install.txt file.