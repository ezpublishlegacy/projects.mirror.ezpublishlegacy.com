<!DOCTYPE TS><TS>
<context>
    <name>smilecalendar/design/standard/content/datatype</name>
    <message>
        <source>calendar</source>
        <translation>calendrier</translation>
    </message>
</context>
</TS>
