<?php /*

[ezdate_override]
Source=content/datatype/edit/ezdate.tpl
MatchFile=content/datatype/edit/ezdate_override.tpl
Subdir=templates


*/ ?>