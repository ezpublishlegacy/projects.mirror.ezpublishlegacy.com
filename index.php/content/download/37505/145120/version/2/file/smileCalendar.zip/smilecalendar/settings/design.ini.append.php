<?php /*
[ExtensionSettings]
DesignExtensions[]=smilecalendar

[JavaScriptSettings]
JavaScriptList[]=YahooUI/yahoo-dom-event/yahoo-dom-event.js
JavaScriptList[]=YahooUI/calendar/calendar-min.js
JavaScriptList[]=smileCalendar.js

[StylesheetSettings]
CSSFileList[]=YahooUI/calendar/assets/calendar.css
CSSFileList[]=smileCalendar.css


*/
?>
