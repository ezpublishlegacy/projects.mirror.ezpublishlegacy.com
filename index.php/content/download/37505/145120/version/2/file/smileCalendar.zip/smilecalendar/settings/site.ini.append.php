<?php /*

[RegionalSettings]
TranslationExtensions[]=smilecalendar

*/ ?>