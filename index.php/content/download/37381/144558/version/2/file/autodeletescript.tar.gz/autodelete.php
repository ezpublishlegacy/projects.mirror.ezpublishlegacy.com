Automatic delete objects upon time (a complete script)

- I need a script which removes some published objects based on date. Here is the way to solve this.

{*
  Automatic delete objects upon time (a complete script)
  (C) 2005/2006 Oslo University College
  perespen@gmail.com

  This file may be distributed and/or modified under the terms of the
  "GNU General Public License" version 2 as published by the Free
  Software Foundation and appearing in the file LICENSE included in
  the packaging of this file.
  
  WARNING!
  Remember backup before you start.
  
  This script comes with no warranty. The author of this script will not be held liable for any damages caused or alleged to be caused directly or indirectly by this script.

  In this example we delete objects of class x which is the event-class. The objects are removed if the 'til_dato' (to_date in english) has passed the value of yesterday�s date. Every object under [your_node_id] is then checked.

*}


// Get top node
$node =& eZContentObjectTreeNode::fetch( [your_node_id] );


// Find all events
$subTree =& $node->subTree( array ( 'ClassFilterType' => 'include',
                                   'ClassFilterArray' => array( [your_class_id] )
                                   ) );
// Check old events
echo ("Check old events\n");

$yesterday  = mktime (5,0,0,date("m")  ,date("d")-1,date("Y"));
foreach ( $subTree as $node )
{
    $object =& $node->attribute( 'object' );
    $attributeMap = $object->dataMap();
    $todate = $attributeMap['til_dato']->content();

    if ( $todate->timeStamp() < $yesterday )
    {
        echo ("removing event: " . $attributeMap['tittel']->content() . "\n");
        $object->remove();

    }
}

