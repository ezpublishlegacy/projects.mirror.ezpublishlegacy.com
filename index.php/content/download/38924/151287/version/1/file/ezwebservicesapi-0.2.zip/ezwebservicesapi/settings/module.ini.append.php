<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezwebservicesapi
ModuleList[]=ezwebservicesapi

*/ ?>