<?php

// we're lazy bastards
include_once( 'extension/ezwebservicesapi/xmlrpc/common.php' );

?>
