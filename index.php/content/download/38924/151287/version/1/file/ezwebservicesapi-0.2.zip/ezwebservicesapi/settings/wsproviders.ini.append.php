<?php /*

[GeneralSettings]
EnableXMLRPC=true
EnableJSONRPC=true

[ExtensionSettings]
XMLRPCExtensions[]=ezwebservicesapi
JSONRPCExtensions[]=ezwebservicesapi

*/ ?>