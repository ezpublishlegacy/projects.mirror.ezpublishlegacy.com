********************************************************************************
TOP LIST GENERATOR

Author : Norman Leutner 
Date : February 2006

changes:
2006-02-22 V1.0 Creation
2006-02-22 V1.1 modified sql Statement against SQL-injection
                Operator can now be used with $limit and $offset as URL 
                parameters

********************************************************************************

This template operator returns an array of users with their corresponding number of 
created contentobjects of a given class id.

Input parameters are:

	$class_id
	$offset
	$limit

Installation:

1/ Unzip file in your extension directory

2/ Activate the extension in the admin interface

3/ To use operator in a template :



Usage:

{def $topten = topauthors($class_id,$offset,$limit)} 

This one returns the top 10 users with the most created folders:

{def $topten = topauthors('1','0','10')} 