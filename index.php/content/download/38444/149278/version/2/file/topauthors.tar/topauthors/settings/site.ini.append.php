<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=topauthors

*/ ?>