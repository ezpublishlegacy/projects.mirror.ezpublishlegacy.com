<?php

define('TOP_AUTHORS_FOLDER','topauthors');

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => eZExtension::baseDirectory() . '/' . TOP_AUTHORS_FOLDER . '/autoloads/topauthorsoperators.php',
         'class' => 'TopAuthorsOperators',
         'operator_names' => array( 'topauthors') );

?>
