<?php
class topAuthorsInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://ez.no/community/contribs/template_plugins/topauthors'>topauthors</a>",
            'Version' => "1.1",
            'Copyright' => "Copyright (C) 2007, <a href='http://www.all2e.com/'>all2e GmbH</a>",
            'Author' => "Norman Leutner",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>