<?php

$Module = array( "name" => "Easy User Creation" );

$ViewList 						= array();
$ViewList["do"] 				= array('functions' => array( 'createuser' ),
										"script" => "do.php");

$FunctionList['createuser'] = array( );

?>
