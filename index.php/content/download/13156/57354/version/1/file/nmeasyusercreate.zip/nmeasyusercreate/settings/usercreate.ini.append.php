<?php
/*

[Defaults]
FirstName=Fornavn
LastName=Etternavn
# 12 = guest accounts
UserGroupNodeID=12

[AllowedSelfRegisterUserGroups]
#GroupID[]=
*/
?>