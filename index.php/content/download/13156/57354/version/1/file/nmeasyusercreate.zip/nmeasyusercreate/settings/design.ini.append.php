<?php
/*
[ExtensionSettings]
DesignExtensions[]=nmeasyusercreate
*/
?>