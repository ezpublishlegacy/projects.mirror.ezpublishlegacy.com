<?php
class collectexportInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/collectexport'>Collected Information Export</a>",
            'Version' => "1.0.2",
            'Copyright' => "Copyright (C) 2006 - 2007, <a href='http://silverhand.fr/'>Vitalis Mathias</a> and <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Vitalis Mathias",
            'License' => "GNU General Public License"
        );
    }
}
?>