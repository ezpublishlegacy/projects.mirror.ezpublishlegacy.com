<?php

define( 'WS_PROTOCOL', 'xmlrpc' );
require( 'extension/ggwebservices/webservicescontroller.php' );

?>