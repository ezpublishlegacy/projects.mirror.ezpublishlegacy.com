---------------------------------------------------------------
       French Translation for eZ newsletter extension
---------------------------------------------------------------

What is it?
-----------
This archive provides a french translation file for eZ Newsletter extension (available at http://ez.no/community/contribs/applications/ez_newsletter ).

Installation
------------
- Unpack the archive in the eznewsletter extension's folder. You should then have a folder named 'extension/ezxnewsletter/translations', which will contain all derivatives translations. The 'fre-FR' folder inside will contain a file named translation.ts, which is the translation file himself.
- If you never set any additional translation for this extension, you will have to add the translation path of the extension to you configuration. In order to achieve this, you should have to insert that kind of code:

[RegionalSettings]
TranslationExtensions[]=ezxnewsletter

in a site.ini override (The file extension/ezxnewsletter/settings/site.ini.append.php will do the job)
- Clear your caches. The french translation will now be available for french users.

Author
------
Alexandre Nion (alexandre.nion@linagora.com)