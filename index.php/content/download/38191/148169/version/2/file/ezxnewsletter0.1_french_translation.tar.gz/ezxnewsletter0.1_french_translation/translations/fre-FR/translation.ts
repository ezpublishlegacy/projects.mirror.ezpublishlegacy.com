<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Editer &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Traduire le contenu de %from à %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Publier le contenu du brouillon en cours d&apos;édition. Le brouillon deviendra ainsi la version publiée de l&apos;objet.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Sauvegarder le brouillon</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Sauvegarder le contenu du brouillon en cours d&apos;édition. Utilisez ce bouton pour sauvegarder régulièrement votre travail au cours de l&apos;édition.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Supprimer le brouillon</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Etes-vous sur de vouloir supprimer le brouillon?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Supprimer le brouillon en cours d&apos;édition. Seront également supprimées les traductions qui appartiennent au brouillon (s&apos;il y en a).</translation>
    </message>
    <message>
        <source>Related objects [%related_objects]</source>
        <translation>Objets liés [%related_objects]</translation>
    </message>
    <message>
        <source>Related images [%related_images]</source>
        <translation>Images liées [%related_images]</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>Vous n&apos;avez pas la permission de voir cet objet</translation>
    </message>
    <message>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>Copiez ce code et collez-le dans le champ XML.</translation>
    </message>
    <message>
        <source>Related files [%related_files]</source>
        <translation>Fichiers liés [%related_files]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Type de fichier</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Taille</translation>
    </message>
    <message>
        <source>XML code</source>
        <translation>Code XML</translation>
    </message>
    <message>
        <source>Related content [%related_objects]</source>
        <translation>Contenu lié [%related_objects]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>Il n&apos;y a aucun objet lié à celui en cours d&apos;édition.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Supprimer la sélection</translation>
    </message>
    <message>
        <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
        <translation>Supprimer les éléments sélectionnés de la liste ci-dessous. Seules les relations seront supprimées. Les éléments ne seront pas effacés.</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Ajouter un existant</translation>
    </message>
    <message>
        <source>Add an existing item as a related object.</source>
        <translation>Ajouter un élément existant en tant qu&apos;objet lié.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Télécharger un nouveau</translation>
    </message>
    <message>
        <source>Upload a file and add it as a related object.</source>
        <translation>Télécharger un fichier et l&apos;ajouter en tant qu&apos;objet lié.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Year</source>
        <translation>Année</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mois</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Jour</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Heure</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minute</translation>
    </message>
</context>
<context>
    <name>ezxnewsletter</name>
    <message>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>External HTML</source>
        <translation>HTML externe</translation>
    </message>
    <message>
        <source>Not send</source>
        <translation>Non envoyé</translation>
    </message>
    <message>
        <source>Building sending list</source>
        <translation>Construction de la liste d&apos;envoi</translation>
    </message>
    <message>
        <source>Sending</source>
        <translation>Envoi en cours</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Brouillon</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Send mailing</source>
        <translation>Envoyer le courrier</translation>
    </message>
    <message>
        <source>Mark as sent</source>
        <translation>Marquer comme envoyé</translation>
    </message>
    <message>
        <source>On hold</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>Not set</source>
        <translation>Non paramétré</translation>
    </message>
    <message>
        <source>Silver</source>
        <translation>Argent</translation>
    </message>
    <message>
        <source>Gold</source>
        <translation>Or</translation>
    </message>
    <message>
        <source>Platinum</source>
        <translation>Platine</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>En cours</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmé</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approuvé</translation>
    </message>
    <message>
        <source>Removed self</source>
        <translation>Supprimé par le souscripteur</translation>
    </message>
    <message>
        <source>Removed by admin</source>
        <translation>Supprimer par l&apos;administrateur</translation>
    </message>
    <message>
        <source>Confirm user</source>
        <translation>Confirmer l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Confirm and approve user</source>
        <translation>Confirmer et approuver l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Select a source for newsletter articles</source>
        <translation>Sélectionner une source pour les articles de newsletter</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a source location for articles to be used in the newsletter, and click &quot;OK&quot;.</source>
        <translation>A l&apos;aide des boutons radios, choisissez un emplacement d&apos;origine pour les articles à utiliser dans la newsletter, puis cliquez sur &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Naviguer à l&apos;aide des onglets (ci-dessus), du menu arborescent (à gauche) et de la liste de contenus (au milieu).</translation>
    </message>
    <message>
        <source>Please select an eZ publish user.</source>
        <translation>Veuillez sélectionner un utilisateur eZ publish.</translation>
    </message>
    <message>
        <source>Confirm bounce entry removal</source>
        <translation>Confirmer la suppression de la notification de rejet</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entry?</source>
        <translation>Etes-vous sur(e) de vouloir supprimer la notification de rejet?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entries?</source>
        <translation>Etes-vous sur(e) de vouloir supprimer les notifications de rejet?</translation>
    </message>
    <message>
        <source>The following bounce entries will be removed</source>
        <translation>Les notifications de rejet suivantes vont être supprimées</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <source>Proceed only if you know what you are doing.</source>
        <translation>Poursuivre uniquement si vous savez ce que vous faîtes.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>Confirm newsletter removal</source>
        <translation>Confirmer la suppression de la newsletter</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter?</source>
        <translation>Etes-vous sur de vouloir supprimer cette newsletter?</translation>
    </message>
    <message>
        <source>The following newsletters will be removed</source>
        <translation>Les newsletters suivantes vont être supprimées</translation>
    </message>
    <message>
        <source>Confirm newsletter type removal</source>
        <translation>Confirmer la suppression du type de newsletter</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter type?</source>
        <translation>Etes-vous sur de vouloir supprimer ce type de newsletter?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter types?</source>
        <translation>Etes-vous sur de vouloir supprimer les types de newsletter?</translation>
    </message>
    <message>
        <source>The following newsletter types will be removed</source>
        <translation>Les types de newsletter suivants vons être supprimés</translation>
    </message>
    <message>
        <source>Confirm onhold entry removal</source>
        <translation>Confirmer la suppression de l&apos;élément en attente</translation>
    </message>
    <message>
        <source>The following entries on hold will be removed</source>
        <translation>Les éléments en attente suivants vont être supprimés</translation>
    </message>
    <message>
        <source>Edit Newsletter</source>
        <translation>Editer la newsletter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Newsletter send date</source>
        <translation>Date d&apos;envoi de la newsletter</translation>
    </message>
    <message>
        <source>Newsletter category</source>
        <translation>Catégorie de la newsletter</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Format d&apos;envoi</translation>
    </message>
    <message>
        <source>Send preview address</source>
        <translation>Adresse de prévisualisation</translation>
    </message>
    <message>
        <source>Send preview</source>
        <translation>Envoyer la prévisualisation</translation>
    </message>
    <message>
        <source>Message on hold</source>
        <translation>Message en attente</translation>
    </message>
    <message>
        <source>Send item data:</source>
        <translation>Envoyer les données de l&apos;élément:</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Newsletter ID</source>
        <translation>Identifiant de la Newsletter</translation>
    </message>
    <message>
        <source>Newsletter name</source>
        <translation>Nom de la newsletter</translation>
    </message>
    <message>
        <source>Sent to address</source>
        <translation>Envoyé à l&apos;adresse</translation>
    </message>
    <message>
        <source>Recipient name</source>
        <translation>Nom du destinataire</translation>
    </message>
    <message>
        <source>Set new sendout status</source>
        <translation>Ajouter un nouveau statut d&apos;envoi</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Définir</translation>
    </message>
    <message>
        <source>Back to on hold list</source>
        <translation>Retour à la liste des éléments en attente</translation>
    </message>
    <message>
        <source>Edit Newsletter type</source>
        <translation>Editer le type de newsletter</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining the newsletter.</source>
        <translation>Utiliser le champs de description pour donner plus d&apos;informations sur la newsletter.</translation>
    </message>
    <message>
        <source>Sender address</source>
        <translation>Adresse de l&apos;expéditeur</translation>
    </message>
    <message>
        <source>Personalize Newsletter</source>
        <translation>Personnaliser la newsletter</translation>
    </message>
    <message>
        <source>Valid content classes</source>
        <translation>Classes de contenu valides</translation>
    </message>
    <message>
        <source>Allowed output formats</source>
        <translation>Formats d&apos;envoi autorisés</translation>
    </message>
    <message>
        <source>Subscription lists</source>
        <translation>Listes de souscription</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Boîte de réception</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objets liés</translation>
    </message>
    <message>
        <source>Add related object</source>
        <translation>Ajouter un objet lié</translation>
    </message>
    <message>
        <source>Remove object location</source>
        <translation>Supprimer l&apos;emplacement de l&apos;objet</translation>
    </message>
    <message>
        <source>No object relation selected</source>
        <translation>Aucune relation d&apos;objet définie</translation>
    </message>
    <message>
        <source>Newsletter suggestion inbox</source>
        <translation>Boîte de suggestion de newsletter</translation>
    </message>
    <message>
        <source>Change inbox placement</source>
        <translation>Modifier l&apos;emplacement de la boîte</translation>
    </message>
    <message>
        <source>Delete inbox placement</source>
        <translation>Supprimer l&apos;emplacement de la boîte</translation>
    </message>
    <message>
        <source>No newsletter placement is specified</source>
        <translation>Aucun emplacement de newsletter spécifié</translation>
    </message>
    <message>
        <source>Add inbox placement</source>
        <translation>Ajouter un emplacement de boîte</translation>
    </message>
    <message>
        <source>Newsletter placement</source>
        <translation>Emplacement de la newsletter</translation>
    </message>
    <message>
        <source>Change newsletter placement</source>
        <translation>Modifier l&apos;emplacement de newsletter</translation>
    </message>
    <message>
        <source>Delete newletter placement</source>
        <translation>Supprimer l&apos;emplacement de newsletter</translation>
    </message>
    <message>
        <source>Add newsletter placement</source>
        <translation>Ajouter un emplacement de newsletter</translation>
    </message>
    <message>
        <source>Edit &lt;%subscription_name&gt; [Subscription]</source>
        <translation>Editer &lt;%subscription_name&gt; [Souscription]</translation>
    </message>
    <message>
        <source>Name of the subscriber.</source>
        <translation>Nom du souscripteur.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation>E-mail du souscripteur.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>eZ publish user</source>
        <translation>utliisateur eZ publish</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Sélectionner</translation>
    </message>
    <message>
        <source>Apply the changes and return subscription list view.</source>
        <translation>Appliquer les changements et retourner à la vue de liste de souscriptions.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Vip</source>
        <translation>VIP</translation>
    </message>
    <message>
        <source>VIP status</source>
        <translation>Statut VIP</translation>
    </message>
    <message>
        <source>OutputFormat</source>
        <translation>Format de sortie</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>Abandonner les changements et retourner à la liste des souscriptions.</translation>
    </message>
    <message>
        <source>Edit &lt;%subscription_list_name&gt; [Subscription list]</source>
        <translation>Editer &lt;%subscription_list_name&gt; [Liste de souscription]</translation>
    </message>
    <message>
        <source>Name of the subscription list.</source>
        <translation>Nom de la liste de souscription.</translation>
    </message>
    <message>
        <source>RegistrationURL</source>
        <translation>URL d&apos;enregistrement</translation>
    </message>
    <message>
        <source>URL : %url</source>
        <translation>URL : %url</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>URL to subscription.</source>
        <translation>URL de souscription.</translation>
    </message>
    <message>
        <source>Generate hash</source>
        <translation>Générer l&apos;empreinte</translation>
    </message>
    <message>
        <source>Generate hash for URL.</source>
        <translation>Générer l&apos;empreinte pour l&apos;URL.</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining what subscription list is beeing used to.</source>
        <translation>Utiliser le champs de description pour expliquer à quoi sert la liste de souscription.</translation>
    </message>
    <message>
        <source>Login steps</source>
        <translation>Etapes d&apos;enregistrement</translation>
    </message>
    <message>
        <source>Require password</source>
        <translation>Nécessite un mot de passe</translation>
    </message>
    <message>
        <source>Allow anonymous users</source>
        <translation>Autoriser les utilisateurs anonymes</translation>
    </message>
    <message>
        <source>Auto confirm registered users</source>
        <translation>Auto-confirmer les utilisateurs enregistrés</translation>
    </message>
    <message>
        <source>Automaticly confirm registered users</source>
        <translation>Confirmer automatiquement les utilisateurs enregistrés</translation>
    </message>
    <message>
        <source>Auto approve registered users</source>
        <translation>Approuver automatiquement les utilisateurs enregistrés</translation>
    </message>
    <message>
        <source>Newsletter archive</source>
        <translation>Archive des newsletter</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Créateur</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Créé</translation>
    </message>
    <message>
        <source>Send Status</source>
        <translation>Envoyer le statut</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># envoyées</translation>
    </message>
    <message>
        <source># read</source>
        <translation># lues</translation>
    </message>
    <message>
        <source>Preview Newsletter</source>
        <translation>Prévisualiser la newsletter</translation>
    </message>
    <message>
        <source>Newsletter drafts</source>
        <translation>Brouillons de newsletter</translation>
    </message>
    <message>
        <source>Newsletter in progress</source>
        <translation>Newsletter en cours de rédaction</translation>
    </message>
    <message>
        <source>Soft bounce</source>
        <translation>Notification logicielle</translation>
    </message>
    <message>
        <source>Hard bounce</source>
        <translation>Notification matérielle</translation>
    </message>
    <message>
        <source>Newsletter bounces</source>
        <translation>Notifications de rejet de la newsletter</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverser la sélection.</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation>Nombre de notifications</translation>
    </message>
    <message>
        <source>Bounce type</source>
        <translation>Type de notification</translation>
    </message>
    <message>
        <source>Bounce arrived</source>
        <translation>Notification reçue</translation>
    </message>
    <message>
        <source>No bounces detected</source>
        <translation>Aucune notification reçue</translation>
    </message>
    <message>
        <source>Select bounce to clear bounce entry</source>
        <translation>Sélectionner une notification pour vider l&apos;entrée de notification</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Supprimer la sélection</translation>
    </message>
    <message>
        <source>Remove selected bounce entries.</source>
        <translation>Supprimer les notifications de rejet sélectionnées.</translation>
    </message>
    <message>
        <source>Send items on hold</source>
        <translation>Envoyer les éléments en attente</translation>
    </message>
    <message>
        <source>Modify</source>
        <translation>Modifier</translation>
    </message>
    <message>
        <source>No messages on hold detected</source>
        <translation>Aucun message en attente détecté</translation>
    </message>
    <message>
        <source>Select an iten on hold to delete the scheduled sendout</source>
        <translation>Sélectionner un élément en attente pour en supprimer la planification d&apos;envoi</translation>
    </message>
    <message>
        <source>Remove selected entries on hold.</source>
        <translation>Supprimer les entrées en attente sélectionnées.</translation>
    </message>
    <message>
        <source>Newsletter types</source>
        <translation>Types de newsletter</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Créé par</translation>
    </message>
    <message>
        <source>Article pool</source>
        <translation>Emplacement des articles</translation>
    </message>
    <message>
        <source>Created on</source>
        <translation>Créé le</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>No newsletters defined</source>
        <translation>Aucune newsletter définie</translation>
    </message>
    <message>
        <source>Select newsletter type for removal</source>
        <translation>Sélectionner une newsletter à supprimer</translation>
    </message>
    <message>
        <source>newsletter</source>
        <translation>newsletter</translation>
    </message>
    <message>
        <source>Create a new newsletter of the type &lt;%newsletter_type&gt;</source>
        <translation>Créer une nouvelle newsletter de type &lt;%newsletter_type&gt;</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; newsletter type.</source>
        <translation>Editer le type de newsletter &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected newsletter types.</source>
        <translation>Supprimer les types de newsletter sélectionnés.</translation>
    </message>
    <message>
        <source>New newsletter type</source>
        <translation>Nouveau type de newsletter</translation>
    </message>
    <message>
        <source>Create a new newsletter type.</source>
        <translation>Créer un nouveau type de newsletter.</translation>
    </message>
    <message>
        <source>Subscribers</source>
        <translation>Souscripteurs</translation>
    </message>
    <message>
        <source>Select subscription list for removal</source>
        <translation>Sélectionner une liste de souscription à supprimer</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription list.</source>
        <translation>Editer la liste de souscription &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected subscription list.</source>
        <translation>Supprimer la liste de souscription sélectionnée.</translation>
    </message>
    <message>
        <source>New subscription list</source>
        <translation>Nouvelle liste de souscription</translation>
    </message>
    <message>
        <source>Create a new subscription list.</source>
        <translation>Créer une nouvelle liste de souscription.</translation>
    </message>
    <message>
        <source>Newsletter subscription verification</source>
        <translation>Vérification de la souscription à la newsletter</translation>
    </message>
    <message>
        <source>Hi %name

Thank you for registering to the subscription list %listName. To activate your subscription
you must go to this link: %link .

For editing you settings, please visit : %settingsLink .

Have a nice day.</source>
        <translation>Bonjour %name

Merci de vous être enregistré(e) à la liste de souscription %listName. Pour activer votre souscription, vous devez suivre ce lien: %link.

Pour modifier votre profil, veuillez suivre le lien suivant : %settingsLink.

Bonne journée.</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Souscrire</translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation>Ajouter à la souscription.</translation>
    </message>
    <message>
        <source>Cancel, and discard.</source>
        <translation>Abandonner, et effacer.</translation>
    </message>
    <message>
        <source>Thank you for registering</source>
        <translation>Merci de vous être enregistré(e)</translation>
    </message>
    <message>
        <source>Thank you for registering to %name.</source>
        <translation>Merci de vous être enregistré(e) à %name.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuer</translation>
    </message>
    <message>
        <source>Subscription activated</source>
        <translation>Souscription activée</translation>
    </message>
    <message>
        <source>Hi %name

Your subscription to %subscriptionName has now been activated.</source>
        <translation>Bonjour %name

Votre souscription à %subscriptionName est maintenant activée.</translation>
    </message>
    <message>
        <source>Import suscribers to subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Importer des souscripteurs à la liste de souscription &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Télécharger le fichier</translation>
    </message>
    <message>
        <source>Import subscriptions</source>
        <translation>Importer les souscriptions</translation>
    </message>
    <message>
        <source>Select row to import</source>
        <translation>Sélectionner une ligne à importer</translation>
    </message>
    <message>
        <source>Cancel subscription import.</source>
        <translation>Abandonner l&apos;import de souscriptions.</translation>
    </message>
    <message>
        <source>Import selected</source>
        <translation>Import sélectionné</translation>
    </message>
    <message>
        <source>Import selected.</source>
        <translation>Import sélectionné.</translation>
    </message>
    <message>
        <source>Subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Liste de souscription &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <source>No related object specified</source>
        <translation>Aucun objet lié défini</translation>
    </message>
    <message>
        <source>Edit current subscription list.</source>
        <translation>Editer la liste de souscription actuelle.</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Statut:</translation>
    </message>
    <message>
        <source>Show all</source>
        <translation>Montrer tout</translation>
    </message>
    <message>
        <source>VIP:</source>
        <translation>VIP:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <source>Filter  subscription list.</source>
        <translation>Filtrer la liste de souscription.</translation>
    </message>
    <message>
        <source>Subscriber list</source>
        <translation>Liste de souscripteurs</translation>
    </message>
    <message>
        <source>VIP</source>
        <translation>VIP</translation>
    </message>
    <message>
        <source>Removed</source>
        <translation>Supprimé</translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation>Sélectionnez un souscripteur à supprimer</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n/a</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription.</source>
        <translation>Editer la souscription &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation>Supprimer la souscription sélectionnée.</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nouvelle souscription</translation>
    </message>
    <message>
        <source>Create a new subscription.</source>
        <translation>Créer une nouvelle souscription.</translation>
    </message>
    <message>
        <source>Import contact from CSV file</source>
        <translation>Importer un contact à partir d&apos;un fichier CSV</translation>
    </message>
    <message>
        <source>Edit user settings</source>
        <translation>Editer les paramètres de l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Your subscriptions</source>
        <translation>Vos souscriptions</translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation>Aucune souscription disponible</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mettre à jour</translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation>Paramètres de mise à jour.</translation>
    </message>
    <message>
        <source>Please enter your password</source>
        <translation>Veillez saisir votre mot de passe</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Valider</translation>
    </message>
    <message>
        <source>Sent item data:</source>
        <translation>Données de l&apos;élément envoyées:</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Envoyé</translation>
    </message>
    <message>
        <source>Subscription ID</source>
        <translation>ID de souscription</translation>
    </message>
    <message>
        <source>Subscriber data:</source>
        <translation>Données du souscripteur:</translation>
    </message>
    <message>
        <source>Subscriber name</source>
        <translation>Nom du souscripteur</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bounce details:</source>
        <translation>Informations sur la notification:</translation>
    </message>
    <message>
        <source>Bounce response message:</source>
        <translation>Message de réponse de la notification:</translation>
    </message>
    <message>
        <source>Subscription data:</source>
        <translation>Données de souscription:</translation>
    </message>
    <message>
        <source>Subscription list name</source>
        <translation>Nom de la liste de souscription</translation>
    </message>
    <message>
        <source>Set new subscription status</source>
        <translation>Définir un nouveau statut de souscription</translation>
    </message>
    <message>
        <source>Back to bounce list</source>
        <translation>Retour à la liste des notifications de rejet</translation>
    </message>
    <message>
        <source>Newsletter type</source>
        <translation>Type de newsletter</translation>
    </message>
    <message>
        <source>%newsletter_type_name [Newsletter type]</source>
        <translation>%newsletter_type_name [Type de newsletter]</translation>
    </message>
    <message>
        <source>Create newsletter</source>
        <translation>Créer une newsletter</translation>
    </message>
    <message>
        <source>Default subscription</source>
        <translation>Souscription par défaut</translation>
    </message>
    <message>
        <source>Suggestion inbox</source>
        <translation>Boîte de suggestion</translation>
    </message>
    <message>
        <source>No inbox set</source>
        <translation>Aucune boîte définie</translation>
    </message>
    <message>
        <source>Edit this newsletter type.</source>
        <translation>Editer ce type de newsletter.</translation>
    </message>
    <message>
        <source>Newsletter lists</source>
        <translation>Listes de newsletters</translation>
    </message>
    <message>
        <source>Email address &quot;%address&quot; did not validate</source>
        <translation>L&apos;adresse e-mail &quot;%address&quot; n&apos;a pas été validée</translation>
    </message>
    <message>
        <source>Edit newslettertype</source>
        <translation>Editer le type de newsletter</translation>
    </message>
    <message>
        <source>Edit Subscription</source>
        <translation>Editer la souscription</translation>
    </message>
    <message>
        <source>Subscription Lists</source>
        <translation>Listes de souscriptions</translation>
    </message>
    <message>
        <source>View newsletter type</source>
        <translation>Voir le type de newsletter</translation>
    </message>
    <message>
        <source>Messages on hold</source>
        <translation>Messages en attente</translation>
    </message>
    <message>
        <source>Newsletter items on hold</source>
        <translation>Newsletters en attente</translation>
    </message>
    <message>
        <source>View newsletter bounce entry</source>
        <translation>Voir la notification de rejet de la newsletter</translation>
    </message>
    <message>
        <source>View newsletter bounces</source>
        <translation>Voir les notifications de rejet de la newsletter</translation>
    </message>
    <message>
        <source>Newsletters</source>
        <translation>Newsletters</translation>
    </message>
    <message>
        <source>You&apos;re already a registered subscriber</source>
        <translation>Vous êtes déjà enregistré</translation>
    </message>
    <message>
        <source>Passwords did not match.</source>
        <translation>Les mots de passe ne correspondent pas.</translation>
    </message>
    <message>
        <source>You must enter a name.</source>
        <translation>Vous devez saisir un nom.</translation>
    </message>
    <message>
        <source>You must provide a valid email address.</source>
        <translation>Vous devez fournir une adresse e-mail valide.</translation>
    </message>
    <message>
        <source>Register subscription</source>
        <translation>Enregistrer la souscription</translation>
    </message>
    <message>
        <source>Activate Subscription</source>
        <translation>Activer la souscription</translation>
    </message>
    <message>
        <source>Subscription List</source>
        <translation>Liste de souscriptions</translation>
    </message>
    <message>
        <source>Unsuscribe</source>
        <translation>Se désabonner</translation>
    </message>
    <message>
        <source>The given email address is already in use. Please use another.</source>
        <translation>L&apos;adresse e-mail spécifiée est déjà enregistrée. Veuillez en utiliser une autre.</translation>
    </message>
    <message>
        <source>Password did not match</source>
        <translation>Le mot de passe ne correspond pas</translation>
    </message>
</context>
<context>
    <name>ezxnewslettert</name>
    <message>
        <source>Back to subscription list</source>
        <translation>Retour à la liste de souscription</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>RowNum</source>
        <translation>Numéro de ligne</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Back to subscription lists</source>
        <translation>Retour aux listes de souscription</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Newsletter read</source>
        <translation>Newsletter lue</translation>
    </message>
</context>
</TS>
