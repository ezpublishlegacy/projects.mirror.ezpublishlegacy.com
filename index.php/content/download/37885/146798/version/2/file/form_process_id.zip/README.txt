README for /form/process spam prevention mod
--------------------------------------------

eZ publish 3.2 is vulnerable to spam attacks because email sender and receiver
are sent as HTTP POST variables to the function, and the function does not check
that the response is coming from a local page.

This solution use a HTTP POST variable named ContentObjectID in the mail form,
with the contentobject_id as the value. The /form/process function fetch the
content object (of the new Form class), and get the information needed to send
the email.

The file form_process_id.php is a modified version of kernel/form/process.php.


INSTALLATION

1) Move form_process_id.php to kernel/form/

2) Edit module.php, change process.php to form_process_id.php:

  $ViewList["process"] = array(
      "script" => "form_process_id.php" );

3) Make a new class Form with fields like (example):

  0 title
  1 description
  2 mail_from
  3 mail_to
  4 mail_subject
  5 redirect

4) Make sure the indexes above corresponds to the correct index of the
contentObjectAttributes array in form_process_id.php:

  $emailSender = $contentObjectAttributes[2]->attribute('data_text');
  $receiver    = $contentObjectAttributes[3]->attribute('data_text');
  $mailSubject = $contentObjectAttributes[4]->attribute('data_text');
  $redirectURL = $contentObjectAttributes[5]->attribute('data_text');

5) Make a new object of class Form.

6) Override node/view/full.tpl for the form node and make a new template with
the form fields you need. Create a hidden field named ContentObjectID in the
form and parse $node.contentobject_id as value.

Example:

  <form action="/form/process" method="post">
    <input type="hidden" name="ContentObjectID"
           value="{$node.contentobject_id}" />
    <input name="Text" type="text" value=""  />
    <input type="submit" />
  </form>

7) Clear cache.

That's it!

Roy Viggo Pedersen

