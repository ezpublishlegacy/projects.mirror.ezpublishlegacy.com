<?php
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZ publish Firstgate Payment Extension extension
// SOFTWARE RELEASE: 0.x
// COPYRIGHT NOTICE: Copyright (C) 2007 Andreas Adelsberger a.adelsberger[at]gmx.at>
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//


/*! \file firstgatechecker.php
*/

/*!
  \class FirstgateChecker firstgatechecker.php
  \brief The class FirstgateChecker implements
  functions to perform verification of the
  firstgate's callback.
*/

include_once( 'kernel/shop/classes/ezpaymentcallbackchecker.php' );

class FirstgateChecker extends eZPaymentCallbackChecker
{
    /*!
        Constructor.
    */
    function FirstgateChecker( $iniFile )
    {
        $this->eZPaymentCallbackChecker( $iniFile );
        $this->logger =& eZPaymentLogger::CreateForAdd( 'var/log/FirstgateChecker.log' );    
    }

   
    
    /**
     * validates all params from firstgate
     *
     * @return boolean
     */
    function validateFirstgate(){
    	$fg_linknr 	   = $_SERVER["HTTP_X_CONTENTID"]; //Premium Link Number
		$fg_price   	   = $_SERVER["HTTP_X_PRICE"]; //Millicents !
		$fg_uid 	   = $_SERVER["HTTP_X_USERID"]; //Firstgate Customer Reference Number
		$fg_ip 		   = $_SERVER["REMOTE_ADDR"];
		$fg_currency = $_SERVER["HTTP_X_CURRENCY"];
		$servIp			=$_SERVER['HTTP_X_FORWARDED_FOR'];
		
		$this->logger->writeTimedString( $fg_linknr, 'premium link number ' );
		$this->logger->writeTimedString( $fg_price, 'millicents ' );
		$this->logger->writeTimedString( $fg_uid, 'firstgate customer reference number ' );
		$this->logger->writeTimedString( $fg_ip, 'remote address ' );
		$this->logger->writeTimedString( $fg_currency, 'currency ' );
		$this->logger->writeTimedString( $servIp, 'HTTP_X_FORWARDED_FOR' );
		
		$serverIpRange     = $this->ini->variable( 'ServerSettings', 'serverIpRange');
		//check IP Range
		// funzt wegen router bei lokalem testrechner nicht
		if(substr($fg_ip,0,11) != $serverIpRange && $fg_ip !='192.168.1.254')
		{
			$this->logger->writeTimedString( $serverIpRange, 'invalid serverIpRange. serverIpRange is ' );
			return false;
		}
		//check Currency
		if (!$this->checkCurrency($fg_currency))
		{
			$this->logger->writeTimedString( $fg_currency, 'invalid currency. currency is ' );
			return false;
		}
		
		
		//Check UserID
		if(empty($fg_uid) || is_nan($fg_uid))
			{
				$this->logger->writeTimedString( $fg_uid, 'invalid user_id. user id is ' );
			return false;
		}
		
		if(empty($fg_price) || is_nan($fg_price))
		{
			$this->logger->writeTimedString( $fg_price, 'invalid price. price is ' );
		return false;
		}
		
    	return true;
    }

    /*!
        Convinces of completion of the payment.
    */
    function checkPaymentStatus()
    {
        if( $this->checkDataField( 'payment_status', 'Completed' ) )
        {
            return true;
        }

        $this->logger->writeTimedString( 'checkPaymentStatus faild' );
        return false;
    }

    // overrides
    /*!
        Creates resquest string which is used to 
        confirm firstgate's callback.
    */
    function &buildRequestString()
    {
        $request = "cmd=_notify-validate";
        foreach( $this->callbackData as $key => $value )
        {
            $request .= "&$key=".urlencode( $value );
        }
        return $request;
    }
    
    function &handleResponse( &$socket )
    {
        if( $socket )
        {
            while ( !feof( $socket ) )
            {
                $response = fgets ( $socket, 1024 );
            }
      
            fclose( $socket );
            return $response;
        }

        $this->logger->writeTimedString( "socket = $socket is invalid.", 'handlePOSTResponse faild' );
        return null;
    }
    
   
}

?>
