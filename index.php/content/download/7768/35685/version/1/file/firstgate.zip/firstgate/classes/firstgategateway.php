<?php
///
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZ publish Firstgate Payment Extension extension
// SOFTWARE RELEASE: 0.x
// COPYRIGHT NOTICE: Copyright (C) 2007 Andreas Adelsberger a.adelsberger[at]gmx.at>
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##

/*! \file ezfirstgategateway.php
*/

/*!
\class FirstgateGateway ezfirstgategateway.php
\brief The class FirstgateGateway implements
functions to perform redirection to the Firstgate
payment server.
*/

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezredirectgateway.php' );

//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_FIRSTGATE", "firstgate" );

class FirstgateGateway extends eZRedirectGateway
{
	/*!
	Constructor.
	*/
	function FirstgateGateway()
	{
		//__DEBUG__
		$this->logger   = eZPaymentLogger::CreateForAdd( "var/log/FirstgateType.log" );
		$this->logger->writeTimedString( 'FirstgateGateway::FirstgateGateway()' );
		//___end____
	}

	/*!
	Creates new FirstgateGateway object.
	*/
	function &createPaymentObject( &$processID, &$orderID )
	{
		//__DEBUG__
		$this->logger->writeTimedString("createPaymentObject");
		//___end____

		return eZPaymentObject::createNew( $processID, $orderID, 'Firstgate' );
	}

	/*!
	Creates redirectional url to firstgate server.
	*/
	function &createRedirectionUrl( &$process )
	{
		//__DEBUG__
		$this->logger->writeTimedString("createRedirectionUrl");
		//___end____

		$firstgateINI      =& eZINI::instance( 'firstgate.ini' );

		$firstgateServer   = $firstgateINI->variable( 'ServerSettings', 'ServerName');
		$requestURI     = $firstgateINI->variable( 'ServerSettings', 'RequestURI');
		$business       = urlencode( $firstgateINI->variable( 'FirstgateSettings', 'Business' ) );

		$processParams  =& $process->attribute( 'parameter_list' );
		$orderID        = $processParams['order_id'];

		$indexDir       = eZSys::indexDir();
		$localHost      = eZSys::serverURL();
		$localURI       = eZSys::serverVariable( 'REQUEST_URI' );

		$order          =& eZOrder::fetch( $orderID );


		$amount         = urlencode( $this->convertToCent($order->attribute( 'total_inc_vat' )) );


		include_once( 'lib/ezlocale/classes/ezlocale.php' );
		$locale         =& eZLocale::instance();
		$currency       = urlencode($locale->currencyShortName());
		$countryCode    = urlencode($locale->countryCode());

		/*$maxDescLen     = $firstgateINI->variable( 'FirstgateSettings', 'MaxDescriptionLength');
		$itemName       = urlencode( $this->createShortDescription( $order, $maxDescLen ) );

		$accountInfo    = $order->attribute( 'account_information' );
		$first_name     = urlencode( $accountInfo['first_name'] );
		$last_name      = urlencode( $accountInfo['last_name'] );
		$street         = urlencode( $accountInfo['street2'] );
		$zip            = urlencode( $accountInfo['zip'] );
		$state          = urlencode( $accountInfo['state'] );
		$place          = urlencode( $accountInfo['place'] );
		$image_url      = "$localHost" . urlencode( $firstgateINI->variable( 'FirstgateSettings', 'LogoURI' ) );
		$background     = urlencode( $firstgateINI->variable( 'FirstgateSettings', 'BackgroundColor' ) );
		$pageStyle      = urlencode( $firstgateINI->variable( 'FirstgateSettings', 'PageStyle' ) );
		$noNote         = urlencode( $firstgateINI->variable( 'FirstgateSettings', 'NoNote' ) );
		$noteLabel      = ($noNote == 1) ? '' : urlencode( $firstgateINI->variable( 'FirstgateSettings', 'NoteLabel' ) );
		$noShipping     = 1;*/

		


		$url =  $firstgateServer  . $requestURI    .
		"?price=$amount"               .
		"&cb_currency=$currency"      .

		"&cb_content_name_utf=$itemName"               .
		"&custom=$orderID"              .
		"&mc_gross=$amount"              .
		"&mc_currency=$currency"              .
		"&externalBDRID=$orderID";


		//__DEBUG__
		$this->logger->writeTimedString("business       = $business");
		$this->logger->writeTimedString("item_name      = $itemName");
		$this->logger->writeTimedString("custom         = $orderID");
		$this->logger->writeTimedString("no_shipping    = $noShipping");
		$this->logger->writeTimedString("localHost      = $localHost");
		$this->logger->writeTimedString("amount         = $amount");
		$this->logger->writeTimedString("currency_code  = $currency");
		$this->logger->writeTimedString("notify_url     = $localHost"    . $indexDir . "/firstgate/notify_url/");
		$this->logger->writeTimedString("return         = $localHost"    . $indexDir . "/shop/checkout/");
		$this->logger->writeTimedString("cancel_return  = $localHost"    . $indexDir ."/shop/basket/");
		//___end____

		return $url;
	}
	function convertToCent($n){
		$arr=array();
		$arr=explode('.',$n);
		$newnum=$arr[0];
		if(isset($arr[1])){
			$rest=$arr[1];
			if($rest[0]){
				$newnum.=$rest[0];
			}else{
				$newnum.=0;
			}

			if($rest[1]){
				$newnum.=$rest[1];
			}else{
				$newnum.=0;
			}
		}else{
			$newnum.="00";
		}
		return $newnum;
	}
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_FIRSTGATE, "firstgategateway", "Firstgate" );

?>
