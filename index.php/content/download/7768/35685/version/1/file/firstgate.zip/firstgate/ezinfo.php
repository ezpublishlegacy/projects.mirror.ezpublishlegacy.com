<?php
class ezsspInfo
{
    function info()
    {
        return array(
            'Name' => "Firstgate Payment Gateway",
            'Version' => "0.x",
            'Copyright' => "Copyright (C) 2007 Andreas Adelsberger",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>