<?php /* #?ini charset="utf-8"?

[ServerSettings]
#get your personal LinkURL from your Premium Account Settings on clickandbuy.com
ServerName=http://premium-xxxxxxxxxxx.eu.clickandbuy.com
RequestURI=/
# serverIpRange of the Firstgate server, check your sample transactionscript from firstgate for this
serverIpRange=0000.00.00.

[FirstgateSettings]
errorURL=/shop/basket/
successURL=/shop/orderview/
redirURL=/firstgate/success/

*/ ?>

