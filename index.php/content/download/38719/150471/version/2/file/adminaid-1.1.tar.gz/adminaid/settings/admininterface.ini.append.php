<?php /*

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/ezaidcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/ezaidsubitemscontextmenu.tpl

*/ ?>
