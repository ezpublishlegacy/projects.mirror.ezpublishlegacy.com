<?php /*

[ModuleSettings]
ExtensionRepositories[]=adminaid
ModuleList[]=aid

*/ ?>
