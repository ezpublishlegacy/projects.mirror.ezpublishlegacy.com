var classggSysinfoTemplateOperators =
[
    [ "modify", "classggSysinfoTemplateOperators.html#a6c3fe79e681f8f09984626fe596920c6", null ],
    [ "namedParameterList", "classggSysinfoTemplateOperators.html#abcf4cab1b6ee11aabfc52857c2e28517", null ],
    [ "namedParameterPerOperator", "classggSysinfoTemplateOperators.html#a41649d0e1eaa9078d4d00c787c8461c4", null ],
    [ "operatorList", "classggSysinfoTemplateOperators.html#a44345af724661996f0a5298da1a8b4c5", null ],
    [ "$operators", "classggSysinfoTemplateOperators.html#abd471265ad1529fdda0ca7898d338720", null ]
];