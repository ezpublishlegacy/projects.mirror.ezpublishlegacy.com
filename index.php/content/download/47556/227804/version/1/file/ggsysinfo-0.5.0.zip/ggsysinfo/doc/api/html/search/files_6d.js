var searchData=
[
  ['magic_5fquotes_5fgpc_2ephp',['magic_quotes_gpc.php',['../magic__quotes__gpc_8php.html',1,'']]],
  ['memory_5flimit_2ephp',['memory_limit.php',['../memory__limit_8php.html',1,'']]],
  ['module_2ephp',['module.php',['../module_8php.html',1,'']]],
  ['modulelist_2ephp',['modulelist.php',['../modulelist_8php.html',1,'']]]
];
