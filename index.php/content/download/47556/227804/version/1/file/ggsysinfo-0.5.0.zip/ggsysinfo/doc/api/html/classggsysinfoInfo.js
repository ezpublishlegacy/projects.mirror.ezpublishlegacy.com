var classggsysinfoInfo =
[
    [ "info", "classggsysinfoInfo.html#a38ef7f54293cf3a246a6e6b395b4f29b", null ]
];