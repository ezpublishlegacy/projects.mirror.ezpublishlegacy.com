var classPhpSecInfo__Test__Application =
[
    [ "getMoreInfoURL", "classPhpSecInfo__Test__Application.html#ab850424a547db2e3b8789953f3e284a7", null ],
    [ "isTestable", "classPhpSecInfo__Test__Application.html#ab916dab272e83c3f8416c8aa0df4b78f", null ],
    [ "$test_group", "classPhpSecInfo__Test__Application.html#ae244c4431782319dfde2f9e86372b88d", null ]
];