var searchData=
[
  ['img_5fheight',['IMG_HEIGHT',['../lib_2wincache_8php.html#ad9590e86086a175f332b936d7c3b4fa1',1,'wincache.php']]],
  ['img_5fwidth',['IMG_WIDTH',['../lib_2wincache_8php.html#a1b9828b3866fa6525434b10a5d4ad94c',1,'wincache.php']]],
  ['ini_5fmax_5flength',['INI_MAX_LENGTH',['../lib_2wincache_8php.html#adb8cfd66a356932c3b97b1f6778d29fd',1,'wincache.php']]]
];
