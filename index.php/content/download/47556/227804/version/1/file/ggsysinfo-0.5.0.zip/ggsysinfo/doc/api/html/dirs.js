var dirs =
[
    [ "autoloads", "dir_4c93d58374759c1aa5f6b43a436b2a88.html", null ],
    [ "classes", "dir_806c81abe804811c848fe5b6cff58b7d.html", null ],
    [ "modules", "dir_7d743583266a47afbc2aaf603a45a453.html", "dir_7d743583266a47afbc2aaf603a45a453" ]
];