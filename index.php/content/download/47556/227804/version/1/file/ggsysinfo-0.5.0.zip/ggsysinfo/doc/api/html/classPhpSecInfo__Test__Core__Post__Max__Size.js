var classPhpSecInfo__Test__Core__Post__Max__Size =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Post__Max__Size.html#a257e221a203f28f4c75165ecf10d2375", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Post__Max__Size.html#ac3237617f4e40b0a8850703820907038", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Post__Max__Size.html#ab14a52482b7d798a87cd18d10e85d692", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Post__Max__Size.html#aac98393491929afcc03a661ce89b182f", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Post__Max__Size.html#a330f0553e4f7b7b44ce61f86a9cd440e", null ]
];