var classPhpSecInfo__Test__Curl =
[
    [ "_setMessages", "classPhpSecInfo__Test__Curl.html#a5fcd2b69fb22376f0756683d4b07667f", null ],
    [ "isTestable", "classPhpSecInfo__Test__Curl.html#af16efae6809f8dbe975a6100fe27e8c5", null ],
    [ "$test_group", "classPhpSecInfo__Test__Curl.html#a6966b3a7112ecfec1f25a9777e5a4520", null ]
];