var lib_2apc_8php =
[
    [ "OB_HOST_STATS", "lib_2apc_8php.html#aa4af8ff01e60fabf96995ddc14a4fdb0", null ],
    [ "OB_SYS_CACHE", "lib_2apc_8php.html#a4ecd28d4be9db5aaf264fe69d51c3833", null ],
    [ "OB_SYS_CACHE_DIR", "lib_2apc_8php.html#a5ab846ef690355cb857bff3ed19ddb38", null ],
    [ "OB_USER_CACHE", "lib_2apc_8php.html#a938e80ee21cbba2a382e61446e28b327", null ],
    [ "OB_VERSION_CHECK", "lib_2apc_8php.html#ab78876072f9c53046d934991518a632e", null ],
    [ "USE_AUTHENTICATION", "lib_2apc_8php.html#aca81c3821e1da1f77c8f73ece68135d7", null ],
    [ "defaults", "lib_2apc_8php.html#a8989c99d750c3d9959e55bcda06e5d2f", null ],
    [ "$cache_mode", "lib_2apc_8php.html#a7597abf82803e7fe3d7131d787a76f5e", null ],
    [ "$host", "lib_2apc_8php.html#a711797613cb863ca0756df789c396bf2", null ],
    [ "$MY_SELF", "lib_2apc_8php.html#aed5246b981c902f6818ec5970bb544cc", null ],
    [ "$MY_SELF_WO_SORT", "lib_2apc_8php.html#a30c707f8c1cba9eaac1a6bdb545714d7", null ],
    [ "$PHP_SELF", "lib_2apc_8php.html#a437087dc97412d2ff08eb6af84b3146a", null ],
    [ "$scope_list", "lib_2apc_8php.html#a01d0434634cbc472caa48debd9777336", null ],
    [ "$time", "lib_2apc_8php.html#a78db1a0602e3b6ac1d9a1b5ec103c160", null ],
    [ "$vardom", "lib_2apc_8php.html#a328b51485fe668ca94bc29f07344e8d2", null ],
    [ "$VERSION", "lib_2apc_8php.html#aef5a2efb341306b1b027ab3e775bbf4e", null ]
];