var classPhpSecInfo__Test__Session__Use__Trans__Sid =
[
    [ "_execTest", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html#a21688a79aeff0505fcadb8e614b7d579", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html#aefd11d843f5bdab6b1fe3ca77784372b", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html#ac8c3109316e50387c35ae92cac3f1690", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html#a146666c3ab60d40ef71fe04f3b0b1e75", null ],
    [ "$test_name", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html#a7bbc16f78e846b11d48911fbd14bd655", null ]
];