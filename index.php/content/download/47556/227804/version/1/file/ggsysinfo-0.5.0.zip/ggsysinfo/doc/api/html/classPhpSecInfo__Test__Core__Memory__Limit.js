var classPhpSecInfo__Test__Core__Memory__Limit =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Memory__Limit.html#ae0c6a73a68235021e23b9fe95539b7ca", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Memory__Limit.html#a356960b5c7945c04856bd9beaf4684b4", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Memory__Limit.html#abfd05508daf045fd405c03a1d662762b", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Memory__Limit.html#a3d969eb76f1f403ab1c1d3d3c8353c7a", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Memory__Limit.html#a15622a7d1f9340bd288277fead474bee", null ]
];