var searchData=
[
  ['cache_5fmax_5fentry',['CACHE_MAX_ENTRY',['../lib_2wincache_8php.html#adace60ced48252677f0aa76833f04d8b',1,'wincache.php']]]
];
