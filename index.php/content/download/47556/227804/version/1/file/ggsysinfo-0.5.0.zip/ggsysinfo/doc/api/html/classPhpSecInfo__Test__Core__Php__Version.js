var classPhpSecInfo__Test__Core__Php__Version =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Php__Version.html#a7bf498db241b222002d3c6ab3bfcc310", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Php__Version.html#a39b6b9eaeff77ea8d37703526e2faaaf", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Php__Version.html#aa09c26bd8e9810af7e2d97216bf49012", null ],
    [ "getMoreInfoURL", "classPhpSecInfo__Test__Core__Php__Version.html#ae6c26fa4a52baad569bf790150aa9347", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Php__Version.html#a131fc4b2154c78d47952b2e89b1ce291", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Php__Version.html#aeb877eb5fd5dc1311a8a28ddb6b6e7ce", null ]
];