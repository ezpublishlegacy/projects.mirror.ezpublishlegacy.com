var classPhpSecInfo__Test__Session =
[
    [ "isTestable", "classPhpSecInfo__Test__Session.html#aa04862858a347611ad4ad9d7df882d74", null ],
    [ "$test_group", "classPhpSecInfo__Test__Session.html#a81d11468e61f5511c1443c3d54732643", null ]
];