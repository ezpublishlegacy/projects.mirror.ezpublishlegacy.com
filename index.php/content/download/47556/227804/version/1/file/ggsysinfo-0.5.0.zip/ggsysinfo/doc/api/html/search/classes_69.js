var searchData=
[
  ['inichecker',['iniChecker',['../classiniChecker.html',1,'']]]
];
