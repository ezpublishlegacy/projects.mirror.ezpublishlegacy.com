var searchData=
[
  ['fcache_5fdata',['FCACHE_DATA',['../lib_2wincache_8php.html#a548c11089d95fc5246fe769994aabc61',1,'FCACHE_DATA():&#160;wincache.php'],['../lib_2wincache_8php.html#a548c11089d95fc5246fe769994aabc61',1,'FCACHE_DATA():&#160;wincache.php']]],
  ['fetchlist_2ephp',['fetchlist.php',['../fetchlist_8php.html',1,'']]],
  ['file_5fsupport_2ephp',['file_support.php',['../file__support_8php.html',1,'']]],
  ['file_5fuploads_2ephp',['file_uploads.php',['../file__uploads_8php.html',1,'']]],
  ['footer_2etpl_2ephp',['footer.tpl.php',['../footer_8tpl_8php.html',1,'']]],
  ['force_5fredirect_2ephp',['force_redirect.php',['../force__redirect_8php.html',1,'']]],
  ['foreach',['foreach',['../xcache_8tpl_8php.html#a4809ee6ced342b3e1c334c556614dc64',1,'foreach():&#160;xcache.tpl.php'],['../logstats_8php.html#ae0062112b34d614fdd11117cd5d0e0f8',1,'foreach():&#160;logstats.php']]]
];
