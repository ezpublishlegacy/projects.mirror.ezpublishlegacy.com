var classPhpSecInfo__Test__Core__Allow__Url__Include =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#a5c13345def50b13c9548f9ce9c7aaa07", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#a4d38c61e9961eaec84fe298c084ed814", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#af76d8554ca6738a81ed421b7615b90da", null ],
    [ "isTestable", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#aa81f196619520c13980a533d09b46d86", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#a16020f6a43b1615a5142f4e3545d7980", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Allow__Url__Include.html#a4f45ff485fee5fbf9044e149507a3aa3", null ]
];