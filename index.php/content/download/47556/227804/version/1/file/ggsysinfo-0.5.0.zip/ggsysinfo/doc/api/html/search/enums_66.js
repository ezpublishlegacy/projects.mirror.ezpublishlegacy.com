var searchData=
[
  ['fcache_5fdata',['FCACHE_DATA',['../lib_2wincache_8php.html#a548c11089d95fc5246fe769994aabc61',1,'wincache.php']]]
];
