var searchData=
[
  ['ob_5fhost_5fstats',['OB_HOST_STATS',['../lib_2apc_8php.html#aa4af8ff01e60fabf96995ddc14a4fdb0',1,'apc.php']]],
  ['ob_5fsys_5fcache',['OB_SYS_CACHE',['../lib_2apc_8php.html#a4ecd28d4be9db5aaf264fe69d51c3833',1,'apc.php']]],
  ['ob_5fsys_5fcache_5fdir',['OB_SYS_CACHE_DIR',['../lib_2apc_8php.html#a5ab846ef690355cb857bff3ed19ddb38',1,'apc.php']]],
  ['ob_5fuser_5fcache',['OB_USER_CACHE',['../lib_2apc_8php.html#a938e80ee21cbba2a382e61446e28b327',1,'apc.php']]],
  ['ob_5fversion_5fcheck',['OB_VERSION_CHECK',['../lib_2apc_8php.html#ab78876072f9c53046d934991518a632e',1,'apc.php']]],
  ['ocache_5fdata',['OCACHE_DATA',['../lib_2wincache_8php.html#a5a0d568d7237ca56ee94fafd3ad05739',1,'wincache.php']]]
];
