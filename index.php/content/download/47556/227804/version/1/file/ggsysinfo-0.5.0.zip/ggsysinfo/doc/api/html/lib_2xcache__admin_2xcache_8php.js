var lib_2xcache__admin_2xcache_8php =
[
    [ "age", "lib_2xcache__admin_2xcache_8php.html#aa003d55f74898cd456cdc89fe98eb40a", null ],
    [ "number_formats", "lib_2xcache__admin_2xcache_8php.html#a580755d645b7efc4b1e1537690e03c46", null ],
    [ "size", "lib_2xcache__admin_2xcache_8php.html#af4f70018d6b4006715881088cdb3b7f3", null ],
    [ "switcher", "lib_2xcache__admin_2xcache_8php.html#abeeb5336e230b1e2c0b3ca3b8d8315bb", null ]
];