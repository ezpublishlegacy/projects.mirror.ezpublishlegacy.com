var logstats_8php =
[
    [ "$cachedir", "logstats_8php.html#a01f61437be9e9a04ee228f5d455265db", null ],
    [ "$debug", "logstats_8php.html#a85ae3e64cd40e9564adceb010085e9dd", null ],
    [ "$errormsg", "logstats_8php.html#a83574f02617bcbd33ccea0debd1f7f68", null ],
    [ "$logfiles", "logstats_8php.html#a6c8f5bb2a5b327e231c5cf7e75ecb4ca", null ],
    [ "$logFilesList", "logstats_8php.html#a6cddb3da9180ba209766510fea966354", null ],
    [ "$tpl", "logstats_8php.html#a04b1944cdb09f9a4e290cde7a12499e6", null ],
    [ "foreach", "logstats_8php.html#ae0062112b34d614fdd11117cd5d0e0f8", null ]
];