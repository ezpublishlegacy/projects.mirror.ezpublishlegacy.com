var classPhpSecInfo__Test__Suhosin__Extension =
[
    [ "_execTest", "classPhpSecInfo__Test__Suhosin__Extension.html#ac1b3fb38940876bd723343db9068bd7c", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Suhosin__Extension.html#a7cf77267f0e5f3fd1a644e63dab58236", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Suhosin__Extension.html#a4d79737d5709bcd8d990815d4fe90efa", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Suhosin__Extension.html#aaf0d7c3ad954cadab9af594b6483bf2f", null ],
    [ "$test_name", "classPhpSecInfo__Test__Suhosin__Extension.html#ac1df8a803143bedeefe48c1ffb1557b4", null ]
];