var inisettingsqa_8php =
[
    [ "$ezgeshi_available", "inisettingsqa_8php.html#a68f987d99d41d85784f2945b3c153717", null ],
    [ "$warnings", "inisettingsqa_8php.html#a46209434b2ef1d7554dc5135de969432", null ]
];