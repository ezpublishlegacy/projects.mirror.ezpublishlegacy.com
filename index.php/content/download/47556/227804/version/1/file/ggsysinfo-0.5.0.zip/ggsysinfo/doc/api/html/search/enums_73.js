var searchData=
[
  ['scache_5fdata',['SCACHE_DATA',['../lib_2wincache_8php.html#ab27bb597d712cf0eac94cc2c5272754e',1,'wincache.php']]],
  ['subkey_5fmax_5flength',['SUBKEY_MAX_LENGTH',['../lib_2wincache_8php.html#a5aea6ae85812e4ae380679a553553ef7',1,'wincache.php']]],
  ['summary_5fdata',['SUMMARY_DATA',['../lib_2wincache_8php.html#a7f64a99a0d58c149dc577ae94e740cb7',1,'wincache.php']]]
];
