var memory__limit_8php =
[
    [ "PHPSECINFO_MEMORY_LIMIT", "memory__limit_8php.html#aac980fdf060366198710f64c8ab837d9", null ]
];