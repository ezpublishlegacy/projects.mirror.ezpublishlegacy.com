var logview_8php =
[
    [ "$cachedir", "logview_8php.html#a01f61437be9e9a04ee228f5d455265db", null ],
    [ "$data", "logview_8php.html#a6efc15b5a2314dd4b5aaa556a375c6d6", null ],
    [ "$debug", "logview_8php.html#a85ae3e64cd40e9564adceb010085e9dd", null ],
    [ "$errormsg", "logview_8php.html#a83574f02617bcbd33ccea0debd1f7f68", null ],
    [ "$extra_path", "logview_8php.html#a60dcbca38cc28483912e00755511e590", null ],
    [ "$logfiles", "logview_8php.html#a6c8f5bb2a5b327e231c5cf7e75ecb4ca", null ],
    [ "$logname", "logview_8php.html#ab2a70475dc0f7c4cd426723e2595d484", null ]
];