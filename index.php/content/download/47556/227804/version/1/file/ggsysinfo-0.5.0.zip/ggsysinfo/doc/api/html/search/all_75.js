var searchData=
[
  ['ucache_5fdata',['UCACHE_DATA',['../lib_2wincache_8php.html#a9e65acf108f31b2e6926795d6b3dfc20',1,'UCACHE_DATA():&#160;wincache.php'],['../lib_2wincache_8php.html#a9e65acf108f31b2e6926795d6b3dfc20',1,'UCACHE_DATA():&#160;wincache.php']]],
  ['uid_2ephp',['uid.php',['../uid_8php.html',1,'']]],
  ['upload_5fmax_5ffilesize_2ephp',['upload_max_filesize.php',['../upload__max__filesize_8php.html',1,'']]],
  ['upload_5ftmp_5fdir_2ephp',['upload_tmp_dir.php',['../upload__tmp__dir_8php.html',1,'']]],
  ['use_5fauthentication',['USE_AUTHENTICATION',['../lib_2apc_8php.html#aca81c3821e1da1f77c8f73ece68135d7',1,'USE_AUTHENTICATION():&#160;apc.php'],['../lib_2wincache_8php.html#aca81c3821e1da1f77c8f73ece68135d7',1,'USE_AUTHENTICATION():&#160;wincache.php']]],
  ['use_5ftrans_5fsid_2ephp',['use_trans_sid.php',['../use__trans__sid_8php.html',1,'']]],
  ['username',['USERNAME',['../lib_2wincache_8php.html#a6025db9a8bf1da67ef5ec5e18aa2156b',1,'wincache.php']]]
];
