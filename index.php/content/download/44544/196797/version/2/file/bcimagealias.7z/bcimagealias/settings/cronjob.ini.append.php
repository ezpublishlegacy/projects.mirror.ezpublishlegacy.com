<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=bcimagealias

[CronjobPart-bcimagealiascreate]
Scripts[]
Scripts[]=bcimagealiascreate.php

[CronjobPart-bcimagealiasregenerate]
Scripts[]
Scripts[]=bcimagealiasregenerate.php

[CronjobPart-bcimagealiasremove]
Scripts[]
Scripts[]=bcimagealiasremove.php

*/ ?>
