<?php /* #?ini charset="utf-8"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=bcimagealias/popup_context_menu.tpl
SubitemsContextMenuTemplateArray[]=bcimagealias/popup_context_menu_subitems.tpl
ClassMenuTemplateArray[]=bcimagealias/popup_class_menu_additions.tpl
SubMenuTemplateArray[]=bcimagealias/popup_sub_menu_additions.tpl

*/ ?>
