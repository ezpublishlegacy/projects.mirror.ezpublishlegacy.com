<?php /*

[ExtensionSettings]
DesignExtensions[]=ezmultiupload

[StylesheetSettings]
CSSFileList[]=ezmultiupload.css
*/ ?>