<?php /*

[MultiUploadSettings]
AvailableClasses[]
AvailableClasses[]=folder
AvailableClasses[]=gallery

AvailableSubtreeNode[]

MultiuploadHandlers[]

[FileTypeSettings_folder]
FileType[]
FileType[]=*.odt
FileType[]=*.flv
FileType[]=*.xap
FileType[]=*.doc

[FileTypeSettings_gallery]
FileType[]
FileType[]=*.jpg
FileType[]=*.png
FileType[]=*.gif

*/ ?>
