<?php
/*
[ExtensionSettings]
DesignExtensions[]=topdrop

[StylesheetSettings]
CSSFileList[]=dropdown.css

# Some menu can go to the left, Colums are counted from the left side
# goleft=4 means that the first 4 menu will drop on the right, while the last one will drop on the left.

[TopDrop]
goleft=6

*/
?>
