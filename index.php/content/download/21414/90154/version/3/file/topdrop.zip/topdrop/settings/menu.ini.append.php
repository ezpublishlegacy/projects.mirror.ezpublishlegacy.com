<?php /* #?ini charset="iso-8859-1"?

[SelectedMenu]
CurrentMenu=DoubleTop
TopMenu=double_top
LeftMenu=

*/ ?>