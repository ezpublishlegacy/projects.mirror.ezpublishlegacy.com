<?php /*
[NavigationPart]
Part[groupdocsnavigationpart]=GD Comparison
[TopAdminMenu]
Tabs[]=groupdocsc
[Topmenu_groupdocsc]
NavigationPartIdentifier=groupdocsnavigationpart
Name=Groupdocs Comparison
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocscomparison/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>