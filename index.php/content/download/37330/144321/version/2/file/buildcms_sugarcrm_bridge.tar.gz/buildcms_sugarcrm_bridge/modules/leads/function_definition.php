<?php
/*

Copyright (C) 2006 BuildCMS.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Full documentation and new releases can be found here:
http://www.buildcms.com/tech_corner/modules

*/

$FunctionList = array();

// Register a new lead to the SugarCRM database
$FunctionList['lead_dbWrite'] = array(
							'name' => 'BuildCMS :: SugarCRM Bridge - Write lead to database',
							'call_method' => array( 
										'include_file' => 'extension/buildcms_sugarcrm_bridge/modules/leads/leads_register.php',
										'class' => 'Leads',
										'method' => 'dbWrite' ),
										'parameter_type' => 'standard',
										'parameters' => array() );

// Check that a new lead post is valid 
$FunctionList['lead_postValidate'] = array(
							'name' => 'BuildCMS :: SugarCRM Bridge - Validate new lead post',
							'call_method' => array( 
										'include_file' => 'extension/buildcms_sugarcrm_bridge/modules/leads/leads_register.php',
										'class' => 'Leads',
										'method' => 'postValidate' ),
										'parameter_type' => 'standard',
										'parameters' => array() );
?>
