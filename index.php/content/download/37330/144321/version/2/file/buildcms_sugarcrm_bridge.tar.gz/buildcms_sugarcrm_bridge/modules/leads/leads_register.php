<?php
/*

Copyright (C) 2006 BuildCMS.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Full documentation and new releases can be found here:
http://www.buildcms.com/tech_corner/modules

*/


// Include eZ publish libaries
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezdb/classes/ezdb.php" );
include_once( "lib/ezlocale/classes/ezdatetime.php" );

class Leads

{


   function dbWrite()

   {
   
   		/*
   			The data array that should be sent together with this functions can hold:
   				
   				first_name*
				last_name*
				title
				lead_source_description
				phone_mobile
				phone_work
				phone_fax
				email1
				primary_address_street
				primary_address_city
				primary_address_state
				primary_address_postalcode
				primary_address_country
				description
				account_name
   			
   				* Variables with * is required
   		
   		*/
   
   		//Set local variables
   		$v = array();
   		$data = $_POST;
   
		// Load settings
		$time = new eZDateTime();
		$http =& eZHTTPTool::instance();
		$ini =& eZINI::instance( "buildcms_sugarcrm_bridge.ini" );
		
		$v['sugarcrm_register_lead_user'] = $ini->variable( 'SugarLeadInfo', 'RegisterUserID');
		$v['unique_id'] = $http->getSessionKey() . $time->currentTimeStamp();

		//Make database connection array
		$dsn = array(
        'server'        => $ini->variable( 'SugarDatabase', 'Server'),
        'user'          => $ini->variable( 'SugarDatabase', 'User'),
        'password'      => $ini->variable( 'SugarDatabase', 'Password'),
        'database'      => $ini->variable( 'SugarDatabase', 'Database'),
        'show_errors' => true
        );

		$extdb =& eZDB::instance( 'ezmysql', $dsn, true );

		//Escape input data strings
		foreach ($data as $key => $value) {
  	
  			$data["$key"] = $extdb->escapeString( $data["$key"] );
		
		}

		//Check input array
		if (is_array($data) AND is_string($data['first_name']) AND is_string($data['last_name'])){
		
		
				// Write lead to database
				$query = "INSERT INTO `leads` 
				(`id`, 
				`deleted`, 
				`converted`, 
				`date_entered`, 
				`date_modified`, 
				`modified_user_id`, 
				`assigned_user_id`, 
				`created_by`, 
				`salutation`, 
				`first_name`, 
				`last_name`, 
				`title`, 
				`refered_by`, 
				`lead_source`, 
				`lead_source_description`, 
				`status`, 
				`status_description`, 
				`department`, 
				`reports_to_id`, 
				`do_not_call`, 
				`phone_home`, 
				`phone_mobile`, 
				`phone_work`, 
				`phone_other`, 
				`phone_fax`, 
				`email1`, 
				`email2`, 
				`email_opt_out`, 
				`primary_address_street`, 
				`primary_address_city`, 
				`primary_address_state`, 
				`primary_address_postalcode`, 
				`primary_address_country`, 
				`alt_address_street`, 
				`alt_address_city`, 
				`alt_address_state`, 
				`alt_address_postalcode`, 
				`alt_address_country`, 
				`description`, 
				`account_name`, 
				`account_description`, 
				`contact_id`, 
				`account_id`, 
				`opportunity_id`, 
				`opportunity_name`, 
				`opportunity_amount`, 
				`campaign_id`, 
				`portal_name`, 
				`portal_app`, 
				`invalid_email`)
				
				VALUES 
				($extdb->md5( '{$v['unique_id']}' ), 
					'0', 
					'0',
					NOW(),
					NOW(), 
					NULL, 
					'{$v['sugarcrm_register_lead_user']}',
					'{$v['sugarcrm_register_lead_user']}', 
					NULL,
					'{$data['first_name']}',
					'{$data['last_name']}',
					'{$data['title']}', 
					NULL, 
					'Web Site', 
					'{$data['lead_source_description']}',
					'New',
					NULL,
					NULL,
					NULL,
					'off', 
					NULL, 
					'{$data['phone_mobile']}',
					'{$data['phone_work']}', 
					NULL, 
					'{$data['phone_fax']}', 
					'{$data[email1]}', 
					NULL, 
					'off', 
					'{$data['primary_address_street']}', 
					'{$data['primary_address_city']}', 
					'{$data['primary_address_state']}',
					'{$data['primary_address_postalcode']}', 
					'{$data['primary_address_country']}', 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					'{$data['description']}', 
					'{$data['account_name']}',
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					NULL, 
					'0')";
				$extdb->arrayQuery( $query );
				$extdb->close();
				
				return array( 'result' => TRUE );
		
		}
		else{
		
			return array( 'result' => FALSE );
			
		}

   	}


   	function postValidate(){
   
   		$http =& eZHTTPTool::instance();
   
   		if ($http->hasVariable('first_name') AND $http->hasVariable('last_name')){
   
			return array( 'result' => TRUE );
		}
		
		else{
		
			return array( 'result' => FALSE );
		
		}


 
   	}

}

?>
