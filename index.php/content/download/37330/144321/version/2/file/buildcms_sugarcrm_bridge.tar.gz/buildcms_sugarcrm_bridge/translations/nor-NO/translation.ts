<!DOCTYPE TS><TS>
<context>
   <name>buildcms_sugarcrm_bridge/leads</name>
   <message>
       <source>Thank you for your registration</source>
       <translation>Takk for din registrering</translation>
   </message>
   <message>
       <source>Our sales team will contact you.</source>
       <translation>En av våre selgere vil kontakte deg.</translation>
   </message>
   <message>
       <source>Error during the registration</source>
       <translation>Feil under registering</translation>
   </message>
   <message>
       <source>Something went wrong during the registration process.</source>
       <translation>Noe gikk feil under registreringen</translation>
   </message>
   <message>
       <source>Register new lead</source>
       <translation>Registrer ny lead</translation>
   </message>   
   <message>
       <source>SugarCRM Bridge is a eZ publish extension developed by BuildCMS. This function of the SugarCRM Bridge extension allow you to register leads from your eZ publish site directly into your SugarCRM database.</source>
       <translation>SugarCRM Bridge for eZ publish er en tilleggsmodul til eZ publish bygget av BuildCMS. Denne funksjonen av SugarCRM Bridge lar deg registrere nye lead direkte inn i din SugarCRM database.</translation>
   </message>   
   <message>
       <source>Lead information</source>
       <translation>Lead informasjon</translation>
   </message>   
   <message>
       <source>Please register your information and we will get in touch with you.</source>
       <translation>Registrer dine opplysninger så vil vi ta kontakt med deg.</translation>
   </message>
   <message>
       <source>Company name</source>
       <translation>Firmanavn</translation>
   </message>
   <message>
       <source>First name</source>
       <translation>Fornavn</translation>
   </message>
   <message>
       <source>Last name</source>
       <translation>Etternavn</translation>
   </message>
   <message>
       <source>Title</source>
       <translation>Titel</translation>
   </message>
   <message>
       <source>Lead source description</source>
       <translation>Lead kilde beskrivelse</translation>
   </message>
   <message>
       <source>Phone</source>
       <translation>Telefon</translation>
   </message>
   <message>
       <source>Fax</source>
       <translation>Faks</translation>
   </message>
   <message>
       <source>Mobile</source>
       <translation>Mobil</translation>
   </message>
   <message>
       <source>E-mail</source>
       <translation>E-post</translation>
   </message>
   <message>
       <source>City</source>
       <translation>Sted</translation>
   </message>
   <message>
       <source>Street</source>
       <translation>Gate</translation>
   </message>
   <message>
       <source>State</source>
       <translation>Fylke</translation>
   </message>
   <message>
       <source>Postalcode</source>
       <translation>Postnummer</translation>
   </message>
   <message>
       <source>Country</source>
       <translation>Land</translation>
   </message>
   <message>
       <source>Description</source>
       <translation>Beskrivelse</translation>
   </message>
   <message>
       <source>Send information</source>
       <translation>Send informasjon</translation>
   </message>
   <message>
       <source>Field marked with * is required</source>
       <translation>Feltene merket med * er påkrevet</translation>
   </message>
</context>
</TS>