<!DOCTYPE TS><TS>
<context>
   <name>buildcms_sugarcrm_bridge/leads</name>
   <message>
       <source>Thank you for your registration</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Our sales team will contact you.</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Error during the registration</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Something went wrong during the registration process.</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Register new lead</source>
       <translation type="unfinished"></translation>
   </message>   
   <message>
       <source>SugarCRM Bridge is a eZ publish extension developed by BuildCMS. This function of the SugarCRM Bridge extension allow you to register leads from your eZ publish site directly into your SugarCRM database.</source>
       <translation type="unfinished"></translation>
   </message>   
   <message>
       <source>Lead information</source>
       <translation type="unfinished"></translation>
   </message>   
   <message>
       <source>Please register your information and we will get in touch with you.</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Company name</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>First name</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Last name</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Title</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Lead source description</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Phone</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Fax</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Mobile</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>E-mail</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>City</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Street</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>State</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Postalcode</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Country</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Description</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Send information</source>
       <translation type="unfinished"></translation>
   </message>
   <message>
       <source>Field marked with * is required</source>
       <translation type="unfinished"></translation>
   </message>
</context>
</TS>