Information about BuildCMS SugarCRM Bridge.

=====================

All information about this extension and demos can be found at:
http://www.buildcms.com/tech_corner/modules/buildcms_sugarcrm_bridge

=====================

The full documentation and installation guide can be found at:
http://www.buildcms.com/tech_corner/documentation/buildcms_sugarcrm_bridge_register_lead

=====================

We are happy to receive feedback on our extensions and information 
about where our extensions are used in order to create reference lists. 

Feel free to send us an e-mail to post@buildcms.com.

Best regards
BuildCMS 