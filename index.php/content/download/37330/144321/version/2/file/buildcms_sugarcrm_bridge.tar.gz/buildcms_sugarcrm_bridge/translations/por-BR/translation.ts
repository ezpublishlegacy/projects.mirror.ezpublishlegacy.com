<!DOCTYPE TS><TS>
<context>
   <name>buildcms_sugarcrm_bridge/leads</name>
   <message>
       <source>Thank you for your registration</source>
       <translation>O seu registro foi efetuado. Muito obrigado.</translation>
   </message>
   <message>
       <source>Our sales team will contact you.</source>
       <translation>O nosso departamento de vendas entrará em contato com você em breve.</translation>
   </message>
   <message>
       <source>Error during the registration</source>
       <translation>Erro durante o registro</translation>
   </message>
   <message>
       <source>Something went wrong during the registration process.</source>
       <translation>Houve uma falha durante o processo de registro</translation>
   </message>
   <message>
       <source>Register new lead</source>
       <translation>Registrar um novo lead</translation>
   </message>   
   <message>
       <source>SugarCRM Bridge is a eZ publish extension developed by BuildCMS. This function of the SugarCRM Bridge extension allow you to register leads from your eZ publish site directly into your SugarCRM database.</source>
       <translation>SugarCRM Bridge é uma extensão para o eZ publish desenvolvida pela BuildCMS. Esta extensão permite o registro automático de novos leads do seu site eZ publish diretamente no seu banco de dados do SugarCRM.</translation>
   </message>   
   <message>
       <source>Lead information</source>
       <translation>Informação sobre o lead</translation>
   </message>   
   <message>
       <source>Please register your information and we will get in touch with you.</source>
       <translation>Por favor, forneça os seguintes dados:</translation>
   </message>
   <message>
       <source>Company name</source>
       <translation>Nome da empresa</translation>
   </message>
   <message>
       <source>First name</source>
       <translation>Nome</translation>
   </message>
   <message>
       <source>Last name</source>
       <translation>Sobrenome</translation>
   </message>
   <message>
       <source>Title</source>
       <translation>Cargo</translation>
   </message>
   <message>
       <source>Lead source description</source>
       <translation>Informações adicionais sobre o lead</translation>
   </message>
   <message>
       <source>Phone</source>
       <translation>Telefone</translation>
   </message>
   <message>
       <source>Fax</source>
       <translation>Fax</translation>
   </message>
   <message>
       <source>Mobile</source>
       <translation>Celular</translation>
   </message>
   <message>
       <source>E-mail</source>
       <translation>E-mail</translation>
   </message>
   <message>
       <source>City</source>
       <translation>Cidade</translation>
   </message>
   <message>
       <source>Street</source>
       <translation>Endereço</translation>
   </message>
   <message>
       <source>State</source>
       <translation>Estado</translation>
   </message>
   <message>
       <source>Postalcode</source>
       <translation>CEP</translation>
   </message>
   <message>
       <source>Country</source>
       <translation>País</translation>
   </message>
   <message>
       <source>Description</source>
       <translation>Descrição</translation>
   </message>
   <message>
       <source>Send information</source>
       <translation>Enviar</translation>
   </message>
   <message>
       <source>Field marked with * is required</source>
       <translation>Os campos marcados com * são de preenchimento obrigatório.</translation>
   </message>
</context>
</TS>