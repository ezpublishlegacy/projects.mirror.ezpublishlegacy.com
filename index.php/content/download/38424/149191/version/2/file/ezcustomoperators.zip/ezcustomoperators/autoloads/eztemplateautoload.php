<?php

// Operator autoloading
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =

array( 'script' => 'extension/ezcustomoperators/autoloads/mystringoperators.php',
        'class' => 'MyStringOperators',
        'operator_names' => array( 'addstrings', 'helloworld', 'acceptlanguage' )
     );
?>