<?php
class MyStringOperators
{
    /*!
    Constructor
    */
    function MyStringOperators()
    {
       $this->Operators = array( 'addstrings', 'helloworld', 'acceptlanguage' );
    }

    /*!
    Returns the operators in this class.
    */
    function &operatorList()
    {
       return $this->Operators;
    }

    /*!

    Return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
       return true;
    }

    /*!

    The first operator has two parameters, the other has none.
    See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array( 'addstrings'      => array(
                                            'string1' => array( 'type' => 'string', 'required' => true, 'default' => '' ),
                                            'string2' => array( 'type' => 'string', 'required' => true, 'default' => '' )
                                                ),
                      'helloworld'      => array(),
                      'acceptlanguage'  => array()
                    );
    }

    /*!
    Executes the needed operator(s).
    Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                    &$currentNamespace, &$operatorValue, &$namedParameters ) {
        switch ( $operatorName )
        {
            case 'addstrings':
            {
                $operatorValue = $this->addStrings( $namedParameters['string1'], $namedParameters['string2'] );
            } break;
            case 'helloworld':
            {
                $operatorValue = $this->helloWorld();
            } break;
            case 'acceptlanguage':
            {
                $operatorValue = $this->acceptLanguage();
            } break;
        }
    }

    /*!
    Return the sum of two strings.
    */
    function addStrings( $string1, $string2 )
    {
        return $string1 . $string2;
    }

    /*!
    Return a famous string.
    */
    function helloWorld()
    {
        return 'Hello World!';
    }

    /*!
    Return false, redirect to browser language
    */
    function acceptLanguage()
    {
        if ($_SERVER['REQUEST_URI'] == "/") {
            // get browser first language
            $acceptedLang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            switch ($acceptedLang) {
                case 'fr':
                    header("Location: /fr");
                    exit;
                    break;
                case 'en':
                    header("Location: /en");
                    exit;
                    break;
                case 'es':
                    header("Location: /es");
                    exit;
                    break;
                default:
                    header("Location: /en");
                    exit;
            }
        }

    }

    /// privatesection
    var $Operators;

}
 
?>