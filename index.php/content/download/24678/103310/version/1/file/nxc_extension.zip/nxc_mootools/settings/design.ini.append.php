<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=nxc_mootools

[JavaScriptSettings]
JavaScriptList[]=mootools-1.2.4-core.js
JavaScriptList[]=mootools-1.2.4.2-more.js
JavaScriptList[]=nxc.messagestack.js
JavaScriptList[]=nxc.notifymessage.js
JavaScriptList[]=nxc.lightbox.js
JavaScriptList[]=nxc.pagesnavigation.js
JavaScriptList[]=nxc.progressbar.js
JavaScriptList[]=nxc.ajaxcontainer.js

[StylesheetSettings]
CSSFileList[]=nxcmessagestack.css
CSSFileList[]=nxclightboxbox.css
CSSFileList[]=nxcpagesnavigation.css
CSSFileList[]=nxcprogressbar.css
CSSFileList[]=nxcajaxcontainer.css
*/ ?>