<?php
/**
 * @package nxcTestOrder
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    17 Mar 2010
 **/

$Module = array(
	'name'            => 'NXC Test order',
 	'variable_params' => true
);

$ViewList = array();
$ViewList['test'] = array(
	'functions' => array( 'test' ),
	'script'    => 'test.php'
);

$FunctionList = array();
$FunctionList['test'] = array();
?>