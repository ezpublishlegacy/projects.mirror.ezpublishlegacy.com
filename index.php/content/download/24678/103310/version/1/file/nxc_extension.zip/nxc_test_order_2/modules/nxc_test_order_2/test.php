<?php
/**
 * @package nxcTestOrder
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    17 Mar 2010
 **/

$ini = eZINI::instance( 'nxctestorder.ini' );

eZdebug::writeDebug( $ini->variable( 'Group1', 'Setting1' ) );
eZdebug::writeDebug( $ini->variable( 'Group1', 'Setting2' ) );	
eZdebug::writeDebug( $ini->variable( 'Group2', 'Setting1' ) );
?>