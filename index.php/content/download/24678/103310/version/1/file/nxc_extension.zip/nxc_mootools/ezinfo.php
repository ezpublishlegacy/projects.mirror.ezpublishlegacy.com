<?php
/**
 * @package nxcMootools
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    18 Jan 2010
 **/

class nxc_mootoolsInfo {
	public static function info() {
		return array(
			'Name'      => 'NXC Mootools',
			'Version'   => '1.0',
			'Author'    => 'Dolgushev Serhey <a href="mailto:serhey.dolgushev@nxc.no" target="blank">&lt;serhey.dolgushev@nxc.no&gt;</a>',
			'Copyright' => 'Copyright &copy; 2010 <a href="http://nxc.no" target="blank">NXC Consulting</a>'
		);
	}
}
?>