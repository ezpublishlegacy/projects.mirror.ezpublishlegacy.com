<?php
/**
 * @package nxcMootools
 * @class   nxcMootoolsAJAXResponse
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    05 Mar 2010
 *
 * Usage example
 * <code>
 * <?php
 * $response = new nxcMootoolsAJAXResponse();
 * $response->setStatus( nxcMootoolsAJAXResponse::STATUS_SUCCESS );
 * $response->setMessage( 'Some message' );
 * $response->addError( 'Some error1' );
 * $response->addError( 'Some error2' );
 * $response->addError( 'Some error3' );
 * $response->someVar1 = 'test';
 * $response->someVar2 = 'test2';
 * $response->output();
 * ?>
 * </code>
 **/

class nxcMootoolsAJAXResponse {

	const STATUS_ERROR   = 0;
	const STATUS_SUCCESS = 1;

	private $status;
	private $message;
	private $errors;
	private $data;

	public function __construct() {
		$this->status  = self::STATUS_ERROR;
		$this->message = null;
		$this->errors  = array();
		$this->data    = array();
	}

	public function setStatus( $status ) {
		$this->status = $status;
	}

	public function getStatus() {
		return $this->status;
	}

	public function setMessage( $message ) {
		$this->message = $message;
	}

	public function getMessage() {
		return $this->message;
	}

	public function addError( $error, $key = null ) {
		if( $key === null ) {
			$key = 'error_' . count( $this->errors );
		}

		$this->errors[ $key ] = $error;
	}

	public function getErrors() {
		return $this->errors;
	}

	public function __toString() {
		return json_encode(
			array(
				'status'  => $this->status,
				'message' => $this->message,
				'errors'  => $this->errors,
				'data'    => $this->data
			)
		);
	}

	public function __set( $name, $value ) {
		$this->data[ $name ] = $value;
	}

	public function __get( $name ) {
		return ( isset( $this->data[ $name ] ) ) ? $this->data[ $name ] : null;
	}

	public function output() {
		header( 'Content-Type: application/json' );
		echo $this;
		eZExecution::cleanExit();
	}
}
?>