<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=nxc_test_order_2/test
*/ ?>