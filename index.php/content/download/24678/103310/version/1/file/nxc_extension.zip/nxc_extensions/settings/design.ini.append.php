<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nxc_extensions

[StylesheetSettings]
CSSFileList[]=nxc_extensions.css
*/ ?>