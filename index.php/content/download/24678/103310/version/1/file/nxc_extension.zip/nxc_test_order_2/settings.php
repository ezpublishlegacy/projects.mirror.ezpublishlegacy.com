<?php
class nxc_test_order_2Settings extends nxcExtensionSettings {

	public $defaultOrder = 50;
	public $dependencies = array( 'nxc_test_order_1' );

	public function activate() {
		eZDebug::writeDebug( 'Extension ' . $this->name . ' activated' );
	}

	public function deactivate() {
		eZDebug::writeDebug( 'Extension ' . $this->name . ' deactivated' );
	}
}
?>