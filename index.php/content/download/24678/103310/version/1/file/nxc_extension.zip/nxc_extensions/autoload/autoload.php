<?php
/**
 * @package nxcExtensions
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    17 Mar 2010
 **/

return array (
	'nxcExtension'         => './classes/nxcextensions.php',
	'nxcExtensionSettings' => './classes/nxcextensionsettings.php'
);
?>