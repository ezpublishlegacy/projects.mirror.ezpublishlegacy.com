<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=nxc_test_order_2
ModuleList[]=nxc_test_order_2
*/ ?>