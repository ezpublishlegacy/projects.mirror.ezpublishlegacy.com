<?php /* #?ini charset="utf-8"?

[Group1]
Setting1[]
Setting1[]=nxc_test_order_1_setting_1_1
Setting1[]=nxc_test_order_1_setting_1_2

Setting2=nxc_test_order_1_setting_2

[Group2]
Setting1[]=nxc_test_order_1_setting_1_1
*/ ?>