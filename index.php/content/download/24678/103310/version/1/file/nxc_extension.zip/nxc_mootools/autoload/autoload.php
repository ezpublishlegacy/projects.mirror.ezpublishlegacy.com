<?php
/**
 * @package nxcMootools
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    05 Mar 2010
 **/

return array(
	'nxcMootoolsAJAXResponse' => './classes/nxcmootoolsajaxresponse.php'
);
?>