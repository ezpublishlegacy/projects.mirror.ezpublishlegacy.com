<?php
// modul1/list.php - Funktionsdatei der View list

// notwendige php Bibliothek fuer Templatefunktionen bekannt machen
include_once( "kernel/common/template.php" );

// aktuelle Objekt vom Typ eZModule holen
$Module = $Params['Module'];
// Ordered View Paremeter auslesen
// http://.../modul1/list/ $Params['ParamOne'] / $Params['ParamTwo']
// z.B    .../modul1/list/view/5
$valueParamOne = $Params['ParamOne'];
$valueParamTwo = $Params['ParamTwo'];

// UnOrdered View Paremeter auslesen
// http://.../modul1/list/ param4/$Params['4Param'] /param3/$Params['3Param']
// z.B    .../modul1/list/.../.../param4/141/param3/131
$valueParam3 = $Params['3Param'];
$valueParam4 = $Params['4Param'];

// Beispieldaten
$dataArray = array('Axel','Volker','Dirk','Jan','Felix');

// Variable JacDebug aus dem INI Block [JACExtensionSettings]
// der INI Datei jacextension.ini lesen
//include_once( "lib/ezutils/classes/ezini.php" );
$jacextensionINI = eZINI::instance( 'jacextension.ini' );
$jacDebug = $jacextensionINI->variable('JACExtensionSettings','JacDebug');

// Wenn Debug eingeschaltet mache irgendwas
if( $jacDebug === 'enabled' )
    echo 'jacextension.ini: [JACExtensionSetting] JacDebug=enabled';

// Templateobject initialisieren
$tpl = templateInit();

// View Parameter Array zum Setzn ins Template erzeugen
$viewParameters = array( 'param_one' => $valueParamOne,
                         'param_two' => $valueParamTwo,
                         'unordered_param3' =>  $valueParam3,
                         'unordered_param4' =>  $valueParam4);

// Parameter der View als Array dem Template übergeben
$tpl->setVariable( 'view_parameters', $viewParameters );
// Beispieldatenarray im Template setzen => {$data_array}
$tpl->setVariable( 'data_array', $dataArray );

$Result = array();

// Template parsen und Ergebnis für $module_result.content speichern
$Result['content'] = $tpl->fetch( 'design:modul1/list.tpl' );

// Pfad generieren   Modul1/list
$Result['path'] = array( array( 'url' => 'modul1/list','text' => 'Modul1' ),
                         array( 'url' => false,'text' => 'list' ) );


?>