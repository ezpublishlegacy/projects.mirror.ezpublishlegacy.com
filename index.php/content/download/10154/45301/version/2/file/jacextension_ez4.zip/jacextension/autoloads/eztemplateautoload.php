<?php

// Welche Operatoren sollen automatisch geladen werden?

$eZTemplateOperatorArray = array();

// Operator: jacdata
$eZTemplateOperatorArray[] = array( 'script' => 'extension/jacextension/autoloads/jacoperator.php',
                                    'class' => 'JACOperator',
                                    'operator_names' => array( 'jac' ) );
?>
