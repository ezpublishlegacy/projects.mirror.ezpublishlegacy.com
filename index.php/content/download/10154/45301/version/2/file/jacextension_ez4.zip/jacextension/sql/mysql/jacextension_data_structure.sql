CREATE TABLE `jacextension_data` (
`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user_id` INT( 11 ) NOT NULL ,
`created` INT( 11 ) NOT NULL ,
`value` VARCHAR( 50 ) NOT NULL 
) ENGINE = MYISAM ;