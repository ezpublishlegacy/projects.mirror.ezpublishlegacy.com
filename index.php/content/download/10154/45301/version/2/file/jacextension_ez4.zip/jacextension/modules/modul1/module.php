<?php
// Konfiguration der Views eines Moduls

$Module = array( 'name' => 'Example Modul1' );

$ViewList = array();

// neue View list mit 2 festen Parametern und
// 2 in der Reihenfolge variablen Parametern
// http://.../modul1/list/ $Params['ParamOne'] / $Params['ParamTwo']/ param4/$Params['4Param'] /param3/$Params['3Param']
$ViewList['list'] = array( 'script' => 'list.php',
                           'functions' => array( 'read' ),
                           'params' => array('ParamOne', 'ParamTwo'),
                           'unordered_params' => array('param3' => '3Param', 'param4' => '4Param') );

// http://.../modul1/create
$ViewList['create'] = array('script' => 'create.php',
                            'functions' => array( 'create' ),
                            'params' => array(),
                            'unordered_params' => array() );

// Die Funktionlisteinträge (Rollenfunktionen) werden
// in der Viewdefintion genutzt, damit in den Benutzerrollen auf
// einzelne View Funktionen Rechte vergeben werden können
$FunctionList = array();
$FunctionList['read'] = array();
$FunctionList['create'] = array();
?>