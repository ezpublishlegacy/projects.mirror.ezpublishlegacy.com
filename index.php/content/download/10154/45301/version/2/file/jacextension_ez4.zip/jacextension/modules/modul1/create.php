<?php
// modul1/create.php - Funktionsdatei der View create

// notwendige php Bibliothek fuer Templatefunktionen bekannt machen
include_once( "kernel/common/template.php" );

$Module = $Params['Module'];

// globle objectinstanz holen
$http = eZHTTPTool::instance();

$value = '';

// Wenn Variable 'name' per GET oder POST uebertragen wurde, Variable auslesen
if( $http->hasVariable('name') )
    $value =  $http->variable('name');


if( $value != '' )
{
    //include_once('kernel/classes/datatypes/ezuser/ezuser.php');
    // die ID des aktuellen Users abfragen
    $userId = eZUser::currentUserID();

    include_once('extension/jacextension/classes/jacextensiondata.php');
    // neue Datenobjekt generieren
    $JacDataObject = JACExtensionData::create( $userId, $value );

    eZDebug::writeDebug( '1.'.print_r( $JacDataObject, true ), 'JacDataObject vor dem Speichern: ID nicht gesetzt') ;

    // Objekt in Datenbank speichern
    $JacDataObject->store();

    eZDebug::writeDebug( '2.'.print_r( $JacDataObject, true ), 'JacDataObject nach dem Speichern: ID ist gesetzt') ;

    // id des neu angelegten Objekte erfragen
    $id = $JacDataObject->attribute('id');

    // loginnamen des users erfragen, der den Datensatz angelegt hat
    $userObject = $JacDataObject->attribute('user_object');
    $userName = $userObject->attribute('login');

    // Datensatz neu auslesen
    $dataObject = JACExtensionData::fetchByID($id);

    eZDebug::writeDebug( '3.'.print_r( $dataObject, true ), 'JacDataObject ausgelesen �ber Funktion fetchByID()');

    // Anzahl vorhandener Datensaetze ermitteln
    $count = JACExtensionData::getListCount();

    $statusMessage = 'Name: >>'. $value .'<< von Benutzer >>'.$userName.'<< in Datenbank mit der id >>'.
                    $id.'<< gespeichert! Neue Anzahl = '.$count ;
}
else
{
    $statusMessage = 'Bitte Daten eingeben';
}

include_once('extension/jacextension/classes/jacextensiondata.php');
// Listendaten einmal als Ojbekte und einmal als Array holen und in den Debug Output schreiben
$ObjectArray = JACExtensionData::fetchList(true);
eZDebug::writeDebug( '4. JacDataObjects: '.print_r( $ObjectArray, true ), 'fetchList( $asObject = true )');

$array = JACExtensionData::fetchList(false);
eZDebug::writeDebug( '5. JacDataArrays: '.print_r( $array, true ), 'fetchList( $asObject = false )');


// Templateobject initialisieren
$tpl = templateInit();
$tpl->setVariable( 'status_message', $statusMessage );

// Variable $statusMessage in den eZ Debug Output / Logdatei schreiben
// hier die 4 verschiedenen Typen Notice, Debug, Warning, Error
eZDebug::writeNotice( $statusMessage, 'jacextension:modul1/list.php');
eZDebug::writeDebug( $statusMessage, 'jacextension:modul1/list.php');
eZDebug::writeWarning( $statusMessage, 'jacextension:modul1/list.php');
eZDebug::writeError( $statusMessage, 'jacextension:modul1/list.php');

// $statusMessage eigene Logdatei schreiben nach ezroot/ var/log/jacextension_modul1.log
//include_once('lib/ezfile/classes/ezlog.php');
eZLog::write( $statusMessage, 'jacextension_modul1.log', 'var/log');

$Result = array();

// Template parsen und Ergebnis fuer $module_result.content speichern
$Result['content'] =& $tpl->fetch( 'design:modul1/create.tpl' );

// Pfad generieren   Modul1/create
$Result['path'] = array( array( 'url' => 'modul1/list','text' => 'Modul1' ),
                         array( 'url' => false,'text' => 'create' ) );


?>