<?php
// you have to update autoloads.php so that all classes are available
// php bin/php/ezpgenerateautoloads.php -e -v

$FunctionList = array();
// {fetch('modul1','list', hash('as_object', true()))|attribute(show)}
$FunctionList['list'] = array(
    'name' => 'list',
    'operation_types' => array( 'read' ),
    'call_method' => array(
      //  'include_file' => 'extension/jacextension/modules/modul1/ezmodul1functioncollection.php',
        'class' => 'eZModul1FunctionCollection',
        'method' => 'fetchJacExtensionDataList' ),
    'parameter_type' => 'standard',
    'parameters' => array( array( 'name' => 'as_object',
                                  'type' => 'integer',
                                  'required' => true ) )

   );

//{fetch('modul1','count', hash())}
$FunctionList['count'] = array(
    'name' => 'count',
    'operation_types' => array( 'read' ),
    'call_method' => array(
        //'include_file' => 'extension/jacextension/modules/modul1/ezmodul1functioncollection.php',
        'class' => 'eZModul1FunctionCollection',
        'method' => 'fetchJacExtensionDataListCount' ),
    'parameter_type' => 'standard',
    'parameters' => array()
    );



?>