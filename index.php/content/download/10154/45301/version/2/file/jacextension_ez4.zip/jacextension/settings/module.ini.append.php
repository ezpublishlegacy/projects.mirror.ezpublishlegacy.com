<?php /* #?ini charset="utf-8"?

# eZ mitteilen, das in jacextension nach Modulen gesucht werden soll

[ModuleSettings]
ExtensionRepositories[]=jacextension

*/ ?>


