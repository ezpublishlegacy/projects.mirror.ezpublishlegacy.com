<?php

include_once('extension/jacextension/classes/jacextensiondata.php');


class eZModul1FunctionCollection
{

    function eZModul1FunctionCollection()
    {
    }

    static function fetchJacExtensionDataList( $asObject )
    {
        return array( 'result' => JACExtensionData::fetchList($asObject) );
    }

    static function fetchJacExtensionDataListCount( )
    {
        return array( 'result' => JACExtensionData::getListCount() );
    }

}

?>
