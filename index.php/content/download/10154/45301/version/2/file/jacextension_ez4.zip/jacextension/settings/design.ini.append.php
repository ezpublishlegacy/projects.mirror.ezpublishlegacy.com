<?php /* #?ini charset="utf-8"?

# eZ Mitteilen, in jacextension nach designs zu suchen

[ExtensionSettings]
DesignExtensions[]=jacextension
*/ ?>


