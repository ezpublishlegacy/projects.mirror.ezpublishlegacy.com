<?php /* #?ini charset="utf-8"?

[ClassSettings]
Formats[datexmlschema]=%Y-%m-%d
Formats[datetimexmlschema]=%Y-%m-%dT%H:%i:%s
Formats[timexmlschema]=%H:%i:%s
*/
?>
