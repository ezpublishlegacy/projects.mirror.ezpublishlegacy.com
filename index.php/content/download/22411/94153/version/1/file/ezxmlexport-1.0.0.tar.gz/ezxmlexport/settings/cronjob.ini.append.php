<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezxmlexport

[CronjobPart-ezxmlexport]
Scripts[]=ezxmlexport.php
*/ ?>
