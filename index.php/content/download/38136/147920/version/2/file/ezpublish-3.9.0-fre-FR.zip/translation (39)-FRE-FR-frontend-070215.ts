<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Formulaire %formname<byte value="x9"/></translation>
    </message>
    <message>
        <source>Thank you for your feedback.</source>
        <translation>Merci de votre message.</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Vous avez déjà soumis des données par ce formulaire. Les données précédemment saisies étaient les suivantes.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Retour au site</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearch</name>
    <message>
        <source>Advanced search</source>
        <translation>Recherche avancée</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Rechercher tous les mots</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Rechercher la phrase exacte</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Rechercher avec au moins l&apos;un des mots</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>N&apos;importe quand</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>La veille</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>La semaine dernière</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Les 3 derniers mois</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>L&apos;année dernière</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Afficher par page</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 articles</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 articles</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 articles</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 articles</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 articles</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Aucun résultat n&apos;a été trouvé pour la recherche &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>La recherche pour &quot;%1&quot; a donné %2 résultats</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearchh</name>
    <message>
        <source>Last month</source>
        <translation>Le mois dernier</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
        <translation>Pour sélectionner des objets, cochez la case ou le bouton radio approprié et cliquez sur le bouton &quot;Sélectionner&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Pour sélectionner un objet enfant de l&apos;un des objets présentés, cliquez sur le nom de l&apos;objet et vous obtiendrez une liste de ses enfants.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Premier niveau </translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Sélectionner</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse_mode_list</name>
    <message>
        <source>Invert selection.</source>
        <translation>Inverser la sélection.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/diff</name>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Versions pour &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Créateur</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Brouillon</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Archivé</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Refusé</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Brouillon non modifié</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Cet objet n&apos;a aucune version.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Afficher les différences</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Différences entre les versions %oldVersion et %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Ancienne version</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Changements par ligne</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Changements par blocs</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nouvelle version</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/draft</name>
    <message>
        <source>Select all</source>
        <translation>Tout sélectionner</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Tout désélectionner</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mes brouillons</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Brouillon vide</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Voici les objets courants sur lesquels vous travaillez. Vous êtes le propriétaire de ces brouillons et ils ne peuvent être vus que par vous.
       Vous pouvez également éditer les brouillons ou supprimer ceux dont vous n&apos;avez plus besoin.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Langue</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Dernière modification</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Vous n&apos;avez pas de brouillons</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit</name>
    <message>
        <source>Manage versions</source>
        <translation>Gérer les versions</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Sauver et quitter</translation>
    </message>
    <message>
        <source>Store the draft that is being edited and exit from edit mode.</source>
        <translation>Sauver le brouillon qui est en cours d&apos;édition et sortir du mode Edition.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Prévue</translation>
    </message>
    <message>
        <source>No translation</source>
        <translation>Aucune traduction</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traduire</translation>
    </message>
    <message>
        <source>Edit the current object showing the selected language as a reference.</source>
        <translation>Editez l&apos;objet courant présentant la langue sélectionnée comme langue par défaut.</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Sauver le brouillon</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <source>not translatable</source>
        <translation>intraduisible</translation>
    </message>
    <message>
        <source>required</source>
        <translation>requis</translation>
    </message>
    <message>
        <source>information collector</source>
        <translation>collecteur d&apos;information</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_draft</name>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>La version publliée en cours est la version %version et a été publiée le %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>La dernière modification a été effectuée le %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Cet objet appartient à %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Cet objet est déjà en cours d&apos;édition par un autre utilisateur, vous y compris.
    Vous pouvez continuer l&apos;édition de l&apos;un de vos brouillons ou créer un nouveau brouillon.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Cet objet est déjà en cours d&apos;édition par vous-même.
        Vous pouvez continuer l&apos;édition de l&apos;un de vos brouillons ou créer un nouveau brouillon.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Cet objet est déjà en cours d&apos;édition par un autre utilisateur.
        Vous devriez soit contacter cette personne concernant ce brouillon ou vous créer un nouveau brouillon personnel.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Brouillons en cours</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propriétaire</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Créé</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Dernière modification</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nouveau brouillon</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_languages</name>
    <message>
        <source>Existing languages</source>
        <translation>Langues disponibles</translation>
    </message>
    <message>
        <source>Select the language you want to use when editing the object</source>
        <translation>Sélectionnez la langue que vous souhaitez utiliser pour éditer l&apos;objet</translation>
    </message>
    <message>
        <source>New languages</source>
        <translation>Nouvelles langues</translation>
    </message>
    <message>
        <source>Select the language you want to add to the object</source>
        <translation>Sélectionnez la langue que vous souhaitez utiliser pour ajouter l&apos;objet</translation>
    </message>
    <message>
        <source>Select the language the added translation will be based on</source>
        <translation>Sélectionnez la langue à partir de laquelle la nouvelle traduction se référera</translation>
    </message>
    <message>
        <source>use an empty, untranslated draft</source>
        <translation>utiliser un brouillon vide, non traduit</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to create a translation in another language.</source>
        <translation>Vous n&apos;avez pas les droits suffisants pour créer une traduction dans une autre langue.</translation>
    </message>
    <message>
        <source>However you can select one of the following languages for editing</source>
        <translation>Cependant, vous pouvez sélectionner l&apos;une des langues suivantes pour l&apos;édition</translation>
    </message>
    <message>
        <source>You do not have permission to edit the object in any available languages.</source>
        <translation>Vous n&apos;avez pas les droits suffisants pour éditer l&apos;objet dans aucune langue disponible.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/history</name>
    <message>
        <source>Version not a draft</source>
        <translation>Version pas un brouillon</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Version %1 n&apos;est plus disponible pour l&apos;édition, seuls les brouillons peuvent être édités.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Pour éditer cette version, créez en une copie.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Pas votre version</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Version %1 n&apos;a pas été créée par vous, seuls vos propres brouillons peuvent être édités.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Impossible de créer une nouvelle version</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>La limite de l&apos;historique de versions a été atteinte et aucune version archivée ne peut être supprimée du système.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Vous pouvez changer les paramètres d&apos;historique de version dans le content.ini, supprimer les brouillons de versions ou éditer les brouillons existants.</translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Versions pour &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Créateur</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Créé</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Sélectionnez la version #%version_number pour suppression.</translation>
    </message>
    <message>
        <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
        <translation>La version #%version_number ne peut être supprimée car elle est soit la version publiée de l&apos;objet ou parce que vous ne disposez pas des droits suffisants pour la supprimer.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Voir les contenus de la version #%version_number. Traduction : %translation.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Brouillon</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Archivé</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Refusé</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Brouillon non modifié</translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Créez une copie de la version #%version_number.</translation>
    </message>
    <message>
        <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
        <translation>Vous ne pouvez pas créer de copies de versions car vous ne disposez pas des droits suffisants pour éditer l&apos;objet.</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Editez les contenus de la version #%version_number.</translation>
    </message>
    <message>
        <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
        <translation>Vous ne pouvez pas éditer les contenus de la version #%version_number soit parce que ce n&apos;est pas un brouillon ou bien vous ne disposez pas des droits suffisants pour éditer l&apos;objet.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Cet objet n&apos;a aucune version.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Supprimer la sélection</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Supprimer les versions de l&apos;objet sélectionnées.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Afficher les différences</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Version publiée</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>New drafts [%newerDraftCount]</source>
        <translation>Nouveaux brouillons [%newerDraftCount]</translation>
    </message>
    <message>
        <source>This object does not have any drafts.</source>
        <translation>Cet objet n&apos;a aucun brouillon.</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Différences entre les versions %oldVersion et %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Ancienne version</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Changements par ligne</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Changements par blocs</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nouvelle version</translation>
    </message>
    <message>
        <source>Back to history</source>
        <translation>Retour à l&apos;historique</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Pour davantage d&apos;options essayez %1Advanced search%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Les éléments suivants ont été exclus de la recherche</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Aucun résultat n&apos;a été trouvé pour la recherche &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Conseils de recherche</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Vérifiez l&apos;orthographe des mots clés.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Essayez de changer certains mots clés, par exemple voiture au lieu de voitures.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Essayez des mots clés plus généraux.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Moins de mots clés donne plus de résulats. Essayez de réduire le nombre de mos clés jusqu&apos;à ce que vous obteniez un résultat.</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>La recherche pour &quot;%1&quot; a donné %2 résultats</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/versions</name>
    <message>
        <source>Versions for: %1</source>
        <translation>Versions pour : %1</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Version pas un brouillon</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
        <translation>Version %1 n&apos;est plus disponible pour l&apos;édition, seuls les brouillons peuvent être édités.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Pour éditer cette version, créez en une copie.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Pas votre version</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Version %1 n&apos;a pas été créée par vous, seuls vos propres brouillons peuvent être édités.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Impossible de créer une nouvelle version</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>La limite de l&apos;historique de versions a été atteinte et aucune version archivée ne peut être supprimée du système.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Vous pouvez changer les paramètres d&apos;historique de version dans le content.ini, supprimer les brouillons de versions ou éditer les brouillons existants.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Créateur</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Sauver et quitter</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/view/versionview</name>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Edit the draft that is being displayed.</source>
        <translation>Editer le brouillon qui est affiché.</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publier</translation>
    </message>
    <message>
        <source>Publish the draft that is being displayed.</source>
        <translation>Publiez le brouillon qui est affiché.</translation>
    </message>
    <message>
        <source>This version is not a draft and thus it can not be edited.</source>
        <translation>Cette version n&apos;est pas un brouillon et ne peut donc être éditée.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/comment</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/file</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_reply</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_topic</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/forum</name>
    <message>
        <source>Latest from</source>
        <translation>Le dernier depuis</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <source>New Comment</source>
        <translation>Nouveau commentaire</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event</name>
    <message>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_calendar</name>
    <message>
        <source>Mon</source>
        <translation>Lun</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>Mar</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>Mer</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>Jeu</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>Ven</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>Sam</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>Dim</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Aujourd&apos;hui</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_program</name>
    <message>
        <source>Past events</source>
        <translation>Evènements passés</translation>
    </message>
    <message>
        <source>Future events</source>
        <translation>Evènements à venir</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/feedback_form</name>
    <message>
        <source>Send form</source>
        <translation>Envoyer le formulaire</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <source>New topic</source>
        <translation>Nouveau sujet</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>M&apos;avertir des mises à jour</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Vous devez être identifié pour accéder aux forums. Pour ce faire %login_link_start%here%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Réponses</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Dernière réponse</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Pages</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_reply</name>
    <message>
        <source>Message preview</source>
        <translation>Prévue du message</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Modéré par</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_topic</name>
    <message>
        <source>Previous topic</source>
        <translation>Sujet précédent</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Sujet suivant</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Nouvelle réponse</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>M&apos;avertir des mises à jour</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so</source>
        <translation>Vous devez être identifié pour accéder aux forums. Pour ce faire</translation>
    </message>
    <message>
        <source>here</source>
        <translation>ici</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Modéré par</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Supprimer cet objet.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forums</name>
    <message>
        <source>Topics</source>
        <translation>Sujets</translation>
    </message>
    <message>
        <source>Posts</source>
        <translation>Posts</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Dernière réponse</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/gallery</name>
    <message>
        <source>View as slideshow</source>
        <translation>Voir sous forme de slides</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/image</name>
    <message>
        <source>Previous image</source>
        <translation>Image précédente</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Image suivante</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to basket</source>
        <translation>Ajouter au panier</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Ajouter à la liste de recommandations</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Les personnes ayant acheté ce produit ont également acheté</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/horizontallylistedsubitems/event</name>
    <message>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event</name>
    <message>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event_calendar</name>
    <message>
        <source>Next events</source>
        <translation>Prochains évènements</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/flash</name>
    <message>
        <source>View flash</source>
        <translation>Voir le flash</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum</name>
    <message>
        <source>Number of Topics</source>
        <translation>Nombre de sujets</translation>
    </message>
    <message>
        <source>Number of Posts</source>
        <translation>Nombre de posts</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Dernière réponse</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Entrer dans le forum</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum_reply</name>
    <message>
        <source>Reply to:</source>
        <translation>Répondre à :</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/quicktime</name>
    <message>
        <source>View movie</source>
        <translation>Voir le film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/real_video</name>
    <message>
        <source>View movie</source>
        <translation>Voir le film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/windows_media</name>
    <message>
        <source>View movie</source>
        <translation>Voir le film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/link</name>
    <message>
        <source>%sitetitle front page</source>
        <translation>page de garde %sitetitle</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Rechercher %sitetitle</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Version imprimable</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/node/removeobject</name>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Etes vous sur de vouloir supprimer ces objets ?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename et ses %childcount enfants. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Déplacer vers la corbeille</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Si %trashname est coché you retrouverez les objets supprimés dans la corbeille a posteriori.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/addingresult</name>
    <message>
        <source>Add to my notifications</source>
        <translation>Ajouter à mes notifications</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>La notification pour le noeud &lt;%node_name&gt; existe déjà.</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>La notification pour le noeud &lt;%node_name&gt; a été créée avec succès.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/settings</name>
    <message>
        <source>Notification settings</source>
        <translation>Paramètres de notification</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Sauver</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/parts/website_toolbar</name>
    <message>
        <source>Create here</source>
        <translation>Créer ici</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Déplacer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Remplacer</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/settings/edit</name>
    <message>
        <source>Node notification</source>
        <translation>Notification de noeud</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Sélectionner</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <source>Shopping basket</source>
        <translation>Panier d&apos;achat</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Information du compte</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmer la commande</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Panier</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Les articles suivants ont été retirés de votre panier car les produits ont changé depuis</translation>
    </message>
    <message>
        <source>VAT is unknown</source>
        <translation>La TVA n&apos;est pas renseignée</translation>
    </message>
    <message>
        <source>VAT percentage is not yet known for some of the items being purchased.</source>
        <translation>Le pourcentage de TVA n&apos;est pas encore connue pour certains des articles en cours d&apos;achat.</translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation>Ceci signifie probablement que quelques informations vous concernant ne sont pas encore disponibles et seront saisies lors de votre enregistrement.</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Tentative d&apos;ajout au panier d&apos;articles sans prix.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Votre paiement a été interrompu.</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Compte</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>TVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Prix TTC</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Remise</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Prix total HT</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Prix total TTC</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>inconnu</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualiser</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Options sélectionnées</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT</source>
        <translation>Sous total HT</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT</source>
        <translation>Sous total TTC</translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation>Expédition</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total de la commande</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Continuer les achats</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>S&apos;enregistrer</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Vous n&apos;avez pas de produit dans votre panier</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/confirmorder</name>
    <message>
        <source>Shopping basket</source>
        <translation>Panier d&apos;achat</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Information du compte</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmer la commande</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Articles</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Compte</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>TVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Prix TTC</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Remise</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Prix total HT</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Prix total TTC</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Options sélectionnées</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Récupitulatif de la commande</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Sous total d&apos;articles</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total de la commande</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/customerorderview</name>
    <message>
        <source>Customer Information</source>
        <translation>Informations du Client</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Liste de la commande</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Total HT</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Total TTC</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Liste d&apos;achats</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produit</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderview</name>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Commande %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Articles</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produit</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Compte</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>TVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Prix TTC</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Remise</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Prix total HT</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Prix total TTC</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Récupitulatif de la commande</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Récupitulatif</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Sous total d&apos;articles</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total de la commande</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>Historique de commande</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/userregister</name>
    <message>
        <source>Shopping basket</source>
        <translation>Panier d&apos;achat</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Information du compte</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmer la commande</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Information de votre compte</translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with * must be filled in</source>
        <translation>La saisie n&apos;a pas été validée : tous les champs marqués d&apos;une astérisque * doivent être remplis</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Prénom</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Société</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Rue</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>Code postal</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Localité</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Etat</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Pays</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuer</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Tous les champs marqués d&apos;une astérisque * doivent être remplis.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/wishlist</name>
    <message>
        <source>Wish list</source>
        <translation>Liste de recomandations</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produit</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Compte</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Options sélectionnées</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Sauver</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Supprimer les articles</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Liste de recommandations vide</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/simplified_treemenu/show_simplified_menu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Classer / Déclasser</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>Noeud ID : %node_id Visibility: %visibility</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/activate</name>
    <message>
        <source>Activate account</source>
        <translation>Activer le compte</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Votre compte est désormais activé.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Désolé, la clé soumise n&apos;était pas valide. Le compte n&apos;a pas été activé.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <source>User profile</source>
        <translation>Profil de l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mes brouillons</translation>
    </message>
    <message>
        <source>My orders</source>
        <translation>Mes commandes</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Mes paramètres de notification</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation>Ma liste de recomandations</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Editer le profil</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Changer de mot passe</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/forgotpassword</name>
    <message>
        <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Un email a été envoyé à l&apos;adresse suivante : %1. Cet email contient un lien sur lequel vous devrez cliquer afin de nous confirmer que le bon utilisateur reçoit bien le nouveau mot de passe.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Il n&apos;y a aucun utilisateur enregistré avec cet adresse courriel.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Le mot de passe a été généré avec succès et envoyé à : %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>La clé n&apos;est pas valide ou a été utilisée. </translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Avez vous oublié votre mot de passe ?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Si vous avez oublié votre mot de passe, nous pouvons en générer un nouveau pour vous. Tout ce que vous n&apos;avez qu&apos;à faire est de saisir votre adresse courriel et nous vous créerons un nouveau mot de passe.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Générer un nouveau mot de passe</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/login</name>
    <message>
        <source>Login</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Connexion impossible</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Un identifiant et un mot de passe valides sont nécessaires pour se connecter.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Accès refusé</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Vous n&apos;êtes pas autorisé à accéder à %1.</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot passe</translation>
    </message>
    <message>
        <source>Log in to the administration interface of eZ publish</source>
        <translation>Connexion à l&apos;interface d&apos;administration d&apos;eZ publish</translation>
    </message>
    <message>
        <source>Remember me</source>
        <translation>Se souvenir de moi</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Connexion</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>S&apos;enregistrer</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Mot de passe oublié ?</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <source>Register user</source>
        <translation>Enregistrer l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>L&apos;entrée n&apos;a pas été validée</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>L&apos;entrée a été enregistrée avec succès</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>S&apos;enregistrer</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Impossible d&apos;enregistrer un nouvel utilisateur</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/success</name>
    <message>
        <source>User registered</source>
        <translation>Utilisateur enregistré</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Votre compte a été créé avec succès. Un email vous sera envoyé à l&apos;adresse spécifiée
Vous devrez suivre les instructions fournies dans cet email pour activer
votre compte. </translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Votre compte a été créé avec succès.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <source>The file could not be found.</source>
        <translation>Le fichier n&apos;a pu être trouvé.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezprice</name>
    <message>
        <source>Price</source>
        <translation>Prix</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Votre prix</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Vous économisez</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/sitemap</name>
    <message>
        <source>Site map</source>
        <translation>Plan du site</translation>
    </message>
</context>
</TS>
