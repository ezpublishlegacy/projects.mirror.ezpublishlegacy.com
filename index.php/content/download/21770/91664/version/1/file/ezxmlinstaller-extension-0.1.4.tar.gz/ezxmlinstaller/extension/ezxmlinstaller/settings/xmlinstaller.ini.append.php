<?php /* #?ini charset="iso-8859-1"?

[XMLInstallerSettings]
#ExtensionDirectories[]
ExtensionDirectories[]=ezxmlinstaller

#XMLInstallerHandler[]
XMLInstallerHandler[]=ezassignroles
XMLInstallerHandler[]=ezcreatecontent
XMLInstallerHandler[]=ezsetsettings
XMLInstallerHandler[]=ezproccessinformation
XMLInstallerHandler[]=ezaddlocation
XMLInstallerHandler[]=ezhideunhide
XMLInstallerHandler[]=ezcreateclass
XMLInstallerHandler[]=ezcreaterole
XMLInstallerHandler[]=ezcreatesection
XMLInstallerHandler[]=ezcreateworkflow
XMLInstallerHandler[]=ezsendmail
XMLInstallerHandler[]=ezmodifycontent

*/?>
