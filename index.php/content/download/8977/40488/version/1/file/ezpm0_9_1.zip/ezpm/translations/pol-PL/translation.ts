<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezpm</name>
    <message>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <source>Body</source>
        <translation>Treść</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Od</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Do</translation>
    </message>
    <message>
        <source>Date sent</source>
        <translation>Wysłano</translation>
    </message>
    <message>
        <source>Date received</source>
        <translation>Odebrano</translation>
    </message>
    <message>
        <source>Date read</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
    <message>
        <source>Private messaging</source>
        <translation></translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Skrzynka odbiorcza</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Wiadomości wysłane</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Kopie robocze</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Kontakty</translation>
    </message>
    <message>
        <source>Contact list</source>
        <translation>Kontakty</translation>
    </message>
    <message>
        <source>Blacklist</source>
        <translation>Lista zablokowanych</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <source>Send message</source>
        <translation>Wyślij wiadomość</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Odpowiedz</translation>
    </message>
    <message>
        <source>Add to blacklist</source>
        <translation>Dodaj do listy zablokowanych</translation>
    </message>
    <message>
        <source>Add to contacts</source>
        <translation>Dodaj do kontaktów</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
    <message>
        <source>PM menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Czytaj</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <source>Create new message</source>
        <translation>Utwórz nową wiadomość</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Zachowaj kopię robczą</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Odrzuć kopię roboczą</translation>
    </message>
    <message>
        <source>Recipient</source>
        <translation>Odbiorca</translation>
    </message>
    <message>
        <source>Re: </source>
        <translation>Odp: </translation>
    </message>    
</context>
</TS>
