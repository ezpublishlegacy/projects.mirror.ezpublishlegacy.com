<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezpersonalfrontpage

*/ ?>
