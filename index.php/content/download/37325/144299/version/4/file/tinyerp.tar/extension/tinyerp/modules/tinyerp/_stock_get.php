<?
/*
##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be)
# Fabien Pinckaers <fp@tiny.be> Sat Oct 22 20:24:56 CEST 2005
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contact a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once( 'extension/tinyerp/modules/tinyerp/erpmodule.php' );

class _tinyerp_stock_get
{
	function _tinyerp_stock_get()
	{
	}

	function &fetchList( $offset, $limit )
	{
		$parameters = array(
			'offset' => $offset,
			'limit' => $limit );
		$lista =& erpmodule::fetchListFromDB( $parameters );
		return array( 'result' => &$lista );
	}

	function &_stock_get($itemnumber) {
		include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
		include_once( 'lib/ezutils/classes/ezini.php' );
		include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
		include_once("xmlrpcutils/utils.php");

		$ini =& eZINI::instance('tinyerp.ini');

		$user = eZUser::currentUser();
		$id = $user->id();
	  
		$erp_settings = $ini->group('ERP');

		$stock_info = xu_rpc_http_concise (
			array(
				'method'=> "execute",
				'host'  => $erp_settings['host'],
				'uri'   => $erp_settings['url'],
				'port'  => intval($erp_settings['port']),
				'args'  => Array(intval($erp_settings['user_id']),
					$erp_settings['user_password'],
					'esale.web',
					'stock_get', 
					intval($erp_settings['shop_id']),
					$itemnumber)
			)
		);

	  # if an erro oocurs display erromsg configured in tinyerp.ini
		if (! $stock_info) {
			$stock_settings = $ini->group('Stockinfo');
			$stock_info[stock] = $stock_settings["error"];
		}

		$lista [0] = array (stock => $stock_info);

		return array('result' => $lista);
	}
}
?>
