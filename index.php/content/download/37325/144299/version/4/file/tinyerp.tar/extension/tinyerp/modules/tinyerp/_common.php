<?
/*
##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be)
# Fabien Pinckaers <fp@tiny.be> Sat Oct 22 20:24:56 CEST 2005
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contact a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/


include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
include_once( 'kernel/classes/ezbasket.php' );
include_once("xmlrpcutils/utils.php");
include_once( 'lib/ezutils/classes/ezini.php' );

function _read_order($src)
{
	$order= array();
	$user_id = $src->attribute('user_id');
	$user_erp_id = eZUser::fetch($user_id);
	$UserContentObject = eZContentObject::fetch( $user_erp_id->id(),1);
	$attributeArray =& $UserContentObject->dataMap();
	$order["partner_id"] = $attributeArray['erp_nr']->content();
	$order["partner_name"] = $attributeArray['first_name']->content(). " ".$attributeArray['last_name']->content();
	$order["user_id"] = $user_erp_id->id();
	$order["notes"] = $src->attribute('data_text_1');
	$order["ref"] = $src->attribute('id');
	$order["date_create"] = $src->attribute('created');
	
	$product_list = array();

	$collection =  eZProductCollection::fetch($src->attribute('productcollection_id'));
	$collectionItems =& $collection->itemList( false );
	foreach( $collectionItems as $item)
	{
		$obj = ezContentObject::fetch($item['contentobject_id']);
		$prod = $obj->dataMap();
		$prod_id = intval($prod['product_number']->content());

		$product_list[] = Array(
			'name'=>$item['name'],
			'price_unit'=>floatval($item['price']),
			'product_id'=>$prod_id,
			'product_qty'=>intval($item['item_count'])
		);
	}
	$order["order_lines"] = $product_list ;
	return $order;
}

/*
 * Insert the following code in kernel/classes/ezbasket.php, function
 * updatePrices if you need a realtime customer product price calculation:
 *
 * include_once('extension/tinyerp/modules/tinyerp/_common.php');
 * $price_erp = _price_get($item);
 * if ($price_erp)
 *     $price = $price_erp;
*/
function _price_get($item, $user_id=0)
{
	$productContentObject =& $item->attribute( 'contentobject' );
	$map = $productContentObject->dataMap();
	$product_id = $map['product_number']->content();
	$product_qty = $item->attribute('item_count');

	if (! $user_id) {
		$user = eZUser::currentUser();
		$UserContentObject = eZContentObject::fetch( $user->id(),1);
		$attributeArray =& $UserContentObject->dataMap();
		$user_id = $attributeArray['erp_nr']->content();
	}
	$ini =& eZINI::instance('tinyerp.ini');
	$erp_settings = $ini->group('ERP');
	$price = xu_rpc_http_concise (
		array(
			'method'=> "execute",
			'host'  => $erp_settings['host'],
			'uri'   => $erp_settings['url'],
			'port'  => intval($erp_settings['port']),
			'args'  => Array(intval($erp_settings['user_id']),
				$erp_settings['user_password'],
				'esale.web',
				'price_get', 
				intval($product_id),
				intval($product_qty),
				intval($user_id)
			)
		)
	);
	return $price;
}

function _basket_get()
{
	$user = eZUser::currentUser();
	$basket =& eZBasket::currentBasket();


	$UserContentObject = eZContentObject::fetch( $user->id(),1);
	$attributeArray =& $UserContentObject->dataMap();

	$order= array();
	$order["partner_id"] = $attributeArray['erp_nr']->content();
	$order["partner_name"] = $attributeArray['first_name']->content(). " ".$attributeArray['last_name']->content();
	$order["user_id"] = $user->id();
	$order["date"] = date("Ymd");

	$product_list = array();

	$items =& $basket ->attribute( 'items');
	foreach( array_keys( $items ) as $key )
	{
		$itemArray =& $items[ $key ];
		$item =& $itemArray['item_object'];
		$productContentObject =& $item->attribute( 'contentobject' );
		$attributes =&  $productContentObject->contentObjectAttributes();
		$product = array();
		foreach ( $attributes as $attribute ) {
			$field = $attribute -> ContentClassAttributeIdentifier;
			switch ($field) {
				case "product_number":
					$product["product_id"] = $attribute -> DataText;
					break;
				case "title":
					$product["name"] = $attribute -> DataText;
					break;
				case "price":
					$product["price"] = $attribute -> DataFloat;
					break;
			}
		}
		$product["product_qty"] = $itemArray ["item_count"];
		$product_list[] = $product;
	}
	$order["products"] = $product_list ;
	return $order;
}

?>
