<?
/*
##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be)
# Fabien Pinckaers <fp@tiny.be> Sat Oct 22 20:24:56 CEST 2005
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contact a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/


include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

include_once( 'kernel/classes/ezorder.php' );
include_once( 'kernel/classes/ezorderstatus.php' );

include_once("xmlrpcutils/utils.php");
include_once("_common.php");

/*
 *
 * PRE:
 *    order_id = False   => Synchronise all orders
 *    order_id = 1       => Synchronise only order_id
 * POST:
 *    Number of uploaded orders
*/
function _order_sync($order_id=False)
{
	/*
	 * Requests states of all Tiny ERP orders that are in ezPublish
	*/

	$result = '';

	$orderArray =& eZOrder::active(true, 0);
	$pendings = Array();
	foreach ($orderArray as $order) {
		$pendings[$order->attribute('id')] = $order->attribute('order_nr');
	}
	$ini =& eZINI::instance('tinyerp.ini');
	$erp_settings = $ini->group('ERP');
	$states = xu_rpc_http_concise (
		array(
			'method'=> "execute",
			'host'  => $erp_settings['host'],
			'uri'   => $erp_settings['url'],
			'port'  => $erp_settings['port'],
			'args'  => Array($erp_settings['user_id'],
				$erp_settings['user_password'],
				'esale.order',
				'state_get', 
				array_keys($pendings))
		)
	);
	if (! states) {
		echo 'Connection to Tiny ERP Error';
	}

	/*
	 * Relations with Tiny ERP States and ezPublish order state
	 * Default ezConfiguration:
	 *     1: Pending
	 *     2: In Progress
	 *     3: Delivered
	 *
	*/

	$states_values = Array(
		"draft"=>2,
		"cancel"=>3,
		"done"=>3,
		"waiting_date"=>2,
		"manual"=>2,
		"progress"=>2,
		"shipping_except"=>2,
		"invoice_except"=>2
	);


	/*
	 * Update Status and create the list of new orders
	*/

	$state_nbr = 0;
	$toupload = Array();
	$db =& eZDB::instance();
	$db->begin();
	foreach ($orderArray as $order) {
		if ($states[$order->attribute('id')]) {
			if (array_key_exists($states[$order->attribute('id')], $states_values)) {
				$val = $states_values[$states[$order->attribute('id')]];
				if (! (($order->attribute('status_id'))==$val)) {
					$db->query( "UPDATE ezorder SET status_id = $val WHERE id = ".$order->attribute('id') );
					$result.="Order ".$order->attribute('id').' changed state to '.$val.'.<br/>';
					$state_nbr +=1;
				}
			}
		} else {
			$toupload[] = _read_order($order);
			$result.="Order ".$order->attribute('id').' uploaded to Tiny ERP.<br/>';
			$state_nbr +=1;
		}
	}
	$db->commit();
	if ($state_nbr ==0)
		$result.="No modification on orders made !";


	/*
	 * Send new orders to Tiny ERP
	*/

	$uploads = xu_rpc_http_concise (
		array(
			'method'=> "execute",
			'host'  => $erp_settings['host'],
			'uri'   => $erp_settings['url'],
			'port'  => intval($erp_settings['port']),
			'args'  => Array(intval($erp_settings['user_id']),
				$erp_settings['user_password'],
				'esale.order',
				'order_upload', 
				intval($erp_settings['shop_id']),
				$toupload)
		)
	);

	return $result;
}
