<?php
/*
##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be)
# Fabien Pinckaers <fp@tiny.be> Sat Oct 22 20:24:56 CEST 2005
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contact a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/



include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezorder.php' );

include_once("_common.php");
include_once("_order_sync.php");
include_once("_product_sync.php");

$Module =& $Params["Module"];

$result = '';
if ( $Module->isCurrentAction('SendOrders') )
	$result = _order_sync();

if ( $Module->isCurrentAction('SendProducts') )
	$result .= _product_sync();


/*
 * Create the ezPublish template
*/
$tpl =& templateInit();
$orderCount = eZOrder::activeCount(true, 0);
$tpl->setVariable( 'order_list_count', $orderCount );
$tpl->setVariable( 'result', $result );

$Result = array();
$Result['content'] = $tpl->fetch('design:tinyerp/tinyerp_admin.tpl' );
$Result['path'] = array( array( 'url' => '/tinyerp/tinyerp_admin',
                                'text' => "Tiny ERP Interface") );

?>
