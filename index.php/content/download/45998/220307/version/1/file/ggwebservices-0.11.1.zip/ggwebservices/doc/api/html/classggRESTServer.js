var classggRESTServer =
[
    [ "handleRequest", "classggRESTServer.html#a862e8d19ea195b874c59502d58850b84", null ],
    [ "parseRequest", "classggRESTServer.html#ade93886f7e2d2c352fce93d4c34fac68", null ],
    [ "prepareResponse", "classggRESTServer.html#ab88858e5a35f831eaab60c0492ed576e", null ],
    [ "$JsonpCallback", "classggRESTServer.html#aab10435522f75bd51f4a98f75f6e3b9c", null ],
    [ "$ResponseClass", "classggRESTServer.html#acf21a438a0066e51c16687b263566688", null ],
    [ "$ResponseType", "classggRESTServer.html#a7331aadf3a22e8e5bedbc60cea9dd1db", null ]
];