var classggJSONRPCServer =
[
    [ "parseRequest", "classggJSONRPCServer.html#a49edbc1a723cfe1d88f350066f46684d", null ],
    [ "prepareResponse", "classggJSONRPCServer.html#a962b7347755435b16846c15a090dda71", null ],
    [ "$Id", "classggJSONRPCServer.html#af07d855c999087a520b6ae26a551204b", null ],
    [ "$ResponseClass", "classggJSONRPCServer.html#acc0ef4ce15ce5d31842ed40845e87462", null ],
    [ "$typeMap", "classggJSONRPCServer.html#a02591253027da98a17765e9f868bbb6f", null ]
];