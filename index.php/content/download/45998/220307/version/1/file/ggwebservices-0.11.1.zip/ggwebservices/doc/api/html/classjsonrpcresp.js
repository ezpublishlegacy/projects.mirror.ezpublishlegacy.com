var classjsonrpcresp =
[
    [ "serialize", "classjsonrpcresp.html#ac4561611ce1b6cad05995c11cec8fdf1", null ],
    [ "$content_type", "classjsonrpcresp.html#af1ac5dbf6706284c06dba4e1d7e184af", null ],
    [ "$id", "classjsonrpcresp.html#a6368ed337087664bb02b33df4dac5605", null ]
];