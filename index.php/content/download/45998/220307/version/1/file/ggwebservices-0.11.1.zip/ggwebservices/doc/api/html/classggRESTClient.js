var classggRESTClient =
[
    [ "send", "classggRESTClient.html#a57159698a7c5b502462a643f4c7dac07", null ],
    [ "setOption", "classggRESTClient.html#a2e0067c298e2b2f9b1b69a42bc877e88", null ],
    [ "$NameVar", "classggRESTClient.html#a4480b74b3a92d7a9094dd3834ffa7063", null ],
    [ "$RequestType", "classggRESTClient.html#ae9e7c85d971667cda0dc9abfa07d6757", null ],
    [ "$ResponseClass", "classggRESTClient.html#acaf994b4970067905a59643304ab7057", null ],
    [ "$ResponseType", "classggRESTClient.html#a29b83b07577a953a3f43a6ce927801d5", null ],
    [ "$UserAgent", "classggRESTClient.html#abc402ff956f9574526ed8f21ecddbb4c", null ],
    [ "$Verb", "classggRESTClient.html#a4134d4456e4ea0688b6faacd144216e3", null ]
];