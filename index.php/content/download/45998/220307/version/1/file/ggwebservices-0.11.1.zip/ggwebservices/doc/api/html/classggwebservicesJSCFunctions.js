var classggwebservicesJSCFunctions =
[
    [ "listMethods", "classggwebservicesJSCFunctions.html#aeeda297ae96aaf26ef855b4c44be3a63", null ],
    [ "methodHelp", "classggwebservicesJSCFunctions.html#a37e6c4db0e3ba9734daa50976571439c", null ],
    [ "methodSignature", "classggwebservicesJSCFunctions.html#a60ea400c193623a1dad33227d8d97510", null ]
];