var dirs =
[
    [ "autoloads", "dir_93296b41b9945379efe332df2a20eedc.html", null ],
    [ "classes", "dir_444ae754327ddc3215c2e3e86c3cc1d1.html", null ],
    [ "cronjobs", "dir_2a55923535403aabc5e7396e3336e6bf.html", null ],
    [ "doc", "dir_0f0178060b506254b8141592cc99a0dd.html", "dir_0f0178060b506254b8141592cc99a0dd" ],
    [ "jsonrpc", "dir_2dad4fde66cccb6054650e964e7d8a14.html", null ],
    [ "lib", "dir_6bd66afc8ea4785181cef3c61698edd1.html", "dir_6bd66afc8ea4785181cef3c61698edd1" ],
    [ "modules", "dir_0b5bad077453aee88266a3edaa584cd5.html", "dir_0b5bad077453aee88266a3edaa584cd5" ],
    [ "rest", "dir_721f4c70916fa266a2334eeb8637baf3.html", null ],
    [ "tests", "dir_6a382a65d70cae8528b6e929d9000c3a.html", null ],
    [ "xmlrpc", "dir_05472eac427ba0741d891b63071002c4.html", null ]
];