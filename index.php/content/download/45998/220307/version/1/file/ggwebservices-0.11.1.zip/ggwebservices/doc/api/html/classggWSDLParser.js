var classggWSDLParser =
[
    [ "phpType2xsdType", "classggWSDLParser.html#a4b38845418114a8640d58dbc56c5ef8e", null ],
    [ "transformGetFunctionsResults", "classggWSDLParser.html#a5399fa193035ea8613dabf6d8c6e6100", null ]
];