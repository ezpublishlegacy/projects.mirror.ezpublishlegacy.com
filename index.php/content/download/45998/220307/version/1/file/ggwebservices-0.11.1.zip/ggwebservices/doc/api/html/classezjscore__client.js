var classezjscore__client =
[
    [ "$accepted_content_type", "classezjscore__client.html#ac1a43a4385619c25adea5a50a7c04feb", null ],
    [ "$no_multicall", "classezjscore__client.html#ab33514c6704075d6b8934ac6a83d08b3", null ],
    [ "$return_type", "classezjscore__client.html#a07af7d3128a09bbd150eea81948f332f", null ]
];