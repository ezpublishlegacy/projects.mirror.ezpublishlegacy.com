var classggSimpleTemplateXML =
[
    [ "__construct", "classggSimpleTemplateXML.html#a7ecb9d84e2ad6375ac44f4562148acab", null ],
    [ "attribute", "classggSimpleTemplateXML.html#a5429dcef73cbfa9482b4f98a1c527914", null ],
    [ "attributes", "classggSimpleTemplateXML.html#a1e2872e169c8bedd142357259aee1e7c", null ],
    [ "domNode2STX", "classggSimpleTemplateXML.html#a4d24814bd72a7784400c9e174a024836", null ],
    [ "hasAttribute", "classggSimpleTemplateXML.html#ae5ff5389c0d6f5c56c1bb4a336f64765", null ],
    [ "toArray", "classggSimpleTemplateXML.html#a56046408f35f7d78b6385125f690316a", null ],
    [ "toSimpleXML", "classggSimpleTemplateXML.html#a85e361ccc410bbfa2ca7657d15736642", null ],
    [ "$meta_attributes", "classggSimpleTemplateXML.html#a8ca94383ed965385e0f68e6c09d3cf3c", null ],
    [ "$node", "classggSimpleTemplateXML.html#a44796e7351e464da2def8eb18529a3ec", null ]
];