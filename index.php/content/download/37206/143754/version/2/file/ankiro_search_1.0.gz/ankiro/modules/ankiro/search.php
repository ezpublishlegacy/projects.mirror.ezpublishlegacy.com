<?php

/**
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Bellcom Open Source Aps <http://www.bellcom.dk>
 *
 */
include_once( 'kernel/common/template.php' );
require_once( realpath( dirname(__FILE__) . '/../../classes/class.ankiro.php' ) );

$pageNum = 1;
if ( !empty($Params['pageNum']) )
{
  $pageNum = $Params['pageNum'];
}

// Try to get "q" from get
$searchQuery = null;
if ( !empty($Params['searchQuery']) )
{
  $searchQuery = $Params['searchQuery'];
}

// Try to get "q" from post
if ( is_null($searchQuery) )
{
  $http = eZHTTPTool::instance();
  if ( $http->hasPostVariable('q') )
  {
    $searchQuery = $http->postVariable('q');
  }
}

$logEntryId = null;
if ( !empty($Params['logEntryId']) )
{
  $logEntryId = $Params['logEntryId'];
}

$totalNumResults = 0;
$ankiroTotalProcessingTime = 0;

if ( !is_null($searchQuery) )
{
  $ankiro = new ankiro();
  $ankiro->performSearch( $searchQuery, $pageNum, $logEntryId );
  $resultArray = $ankiro->getResultsAsArray();
  $totalNumResults = $ankiro->totalNumResults;
  $ankiroTotalProcessingTime = $ankiro->totalTime;

  // Control next/prev links -->>
  $from = 1;
  if ( $ankiro->rowOffset >= $ankiro->numRows )
  {
    $from = $ankiro->rowOffset + 1;
  }

  if ( $totalNumResults <= $from + ($ankiro->numRows - 1) )
  {
    $to = $totalNumResults;
  }
  else
  {
    $to = $from + ($ankiro->numRows - 1);
  }

  $hasPrev = true;
  $prevOffset = $pageNum - 1;
  if ( $prevOffset == 0 )
  {
    $hasPrev = false;
    $prevOffset = 1;
  }

  $hasNext = true;
  $nextOffset = $pageNum + 1;
  if ( $ankiro->lastRowOffset == $totalNumResults )
  {
    $hasNext = false;
  }

  // Build urls
  $prev_url = '/ankiro/search/q/'.$searchQuery; 
  $next_url = '/ankiro/search/q/'.$searchQuery;

  if ( $hasPrev )
  {
    $prev_url .= '/p/'. $prevOffset;
  }

  if ( $hasNext )
  {
    $next_url .= '/p/'. $nextOffset;
  }

  if ( isset($ankiro->logEntryId) && !is_null($ankiro->logEntryId) )
  {
    $prev_url .= '/l/'. $ankiro->logEntryId;
    $next_url .= '/l/'. $ankiro->logEntryId;
  }
}
// <<-- Control next/prev links

$tpl = templateInit();
$tpl->setVariable( 'result_count', $totalNumResults );
$tpl->setVariable( 'results', $resultArray );

$tpl->setVariable( 'next_url', $next_url );
$tpl->setVariable( 'this_url', $this_url );
$tpl->setVariable( 'prev_url', $prev_url );
$tpl->setVariable( 'hasNext', $hasNext );
$tpl->setVariable( 'hasPrev', $hasPrev );
$tpl->setVariable( 'result_from', $from );
$tpl->setVariable( 'result_to', $to );

$tpl->setVariable( 'ankiroProcessingTime', $ankiroTotalProcessingTime );

$Result = array();
$Result['content'] = $tpl->fetch( "design:results.tpl" );
$Result['path']    = array( 
                      array( 
                            'url' => false,
                            'text' => 'Search' 
                           ) 
                         );
?>
