<?php

/**
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Bellcom Open Source Aps <http://www.bellcom.dk>
 *
 */
$Module = array( 'name' => 'Ankiro search' );

$ViewList = array();
$ViewList['search'] = array(
  'script' => 'search.php',
  'unordered_params' => array( 'q' => 'searchQuery', 'p' => 'pageNum', 'l' => 'logEntryId' ),
);
/* q is called q when calling ankiro
 * p is called l when calling ankiro
 * l is called lid when calling ankiro
 */
?>
