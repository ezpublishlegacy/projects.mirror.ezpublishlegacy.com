<?php

/**
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Bellcom Open Source Aps <http://www.bellcom.dk>
 *
 */
class ankiro
{
  private $searchResults  = array();
  private $sxe            = null;
  public $totalNumResults = 0;
  public $numRows         = 0; // Number of rows per page, e.g. 10. If there is 15 results this will be 5 on the last page
  public $rowOffset       = 0; // Offset of the first row, e.g. 0
  public $lastRowOffset   = 0; // Offset of the last row, e.g. 10
  public $logEntryId      = 0; /* Unique identifier for the query when first executed.
                                * Should be parsed as a query string parameter when using 
                                * paging functions.
                                * Parameter name is "lid" when calling ankiro
                                */
  public $startTime       = null;
  public $endTime         = null;
  public $totalTime       = null;
  public $searchQuery     = null;
  // FIXME: Change the following url:
  const searchUrl         = 'http://search.ankiro.dk/s/';

  public function performSearch( $searchQuery = null, $pageNum = 1, $logEntryId = null )
  {
    // TODO: validate $searchQuery, $pageNum, use eZs error handling/loggin

    $this->searchQuery = $searchQuery;
    try 
    {
      $url = self::searchUrl .'?q='. urlencode($this->searchQuery);
      
      if ( $pageNum > 1 ) 
      {
        $url .= '&l='. (int) $pageNum;
      }

      if ( !is_null($logEntryId) )
      {
        $url .= '&lid='. $logEntryId;
      }

      $this->startTime = microtime();
      $this->sxe = new SimpleXMLElement( $url, NULL, true );
      $this->endTime = microtime();
      $this->totalTime = $this->endTime - $this->startTime;

      $attributes = $this->sxe->attributes();
      $this->totalNumResults = (int) $attributes['total-num-results'];
      $this->numRows = (int) $attributes['num-rows'];
      $this->rowOffset = (int) $attributes['row-offset'];
      $this->lastRowOffset = (int) $attributes['last-row-offset'];
      $this->logEntryId = (int) $attributes['log-entry-id'];
    }
    catch (Exception $e)
    {
      error_log(__LINE__.':'.__FILE__.' '. $e->getMessage() .' Search url called: "'. $url .'"');
    }
  }

  public function getResultsAsArray()
  {
    foreach ($this->sxe->Row as $row)
    {
      $result[] = array( 
        'uri'              => (string) $row->uri, 
        'presentation_uri' => (string) $row->presentation_uri,
        'title'            => (string) $row->title, 
        'text'             => (string) $row->context 
      );
    }
    return $result;
  }
}
?>
