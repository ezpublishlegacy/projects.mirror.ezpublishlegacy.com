var searchData=
[
  ['getlanguagecode',['getLanguageCode',['../classeZGoogleTranslateJSCFunctions.html#a21c8e4101b3b3ef3c4584b288a9db5d4',1,'eZGoogleTranslateJSCFunctions']]],
  ['getmsadmtoken',['getMSAdmToken',['../classeZGoogleTranslateJSCFunctions.html#a63cdee67add6068be5addf6fd9a62c9e',1,'eZGoogleTranslateJSCFunctions']]]
];
