var annotated =
[
    [ "ezgoogletranslateInfo", "classezgoogletranslateInfo.html", "classezgoogletranslateInfo" ],
    [ "eZGoogleTranslateJSCFunctions", "classeZGoogleTranslateJSCFunctions.html", "classeZGoogleTranslateJSCFunctions" ]
];