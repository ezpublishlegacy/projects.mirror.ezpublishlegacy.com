<?php /*

[ExtensionSettings]
DesignExtensions[]=ezgoogletranslate

*/?>