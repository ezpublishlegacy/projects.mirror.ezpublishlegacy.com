var files =
[
    [ "ezinfo.php", "ezinfo_8php.html", null ],
    [ "classes/ezgoogletranslatejscfunctions.php", "ezgoogletranslatejscfunctions_8php.html", null ]
];