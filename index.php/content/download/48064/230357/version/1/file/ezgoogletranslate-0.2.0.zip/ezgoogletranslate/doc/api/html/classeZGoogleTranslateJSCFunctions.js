var classeZGoogleTranslateJSCFunctions =
[
    [ "getLanguageCode", "classeZGoogleTranslateJSCFunctions.html#a21c8e4101b3b3ef3c4584b288a9db5d4", null ],
    [ "getMSAdmToken", "classeZGoogleTranslateJSCFunctions.html#a63cdee67add6068be5addf6fd9a62c9e", null ],
    [ "translate", "classeZGoogleTranslateJSCFunctions.html#acf686c6773ff6a4dc6cff31c03dc07b1", null ]
];