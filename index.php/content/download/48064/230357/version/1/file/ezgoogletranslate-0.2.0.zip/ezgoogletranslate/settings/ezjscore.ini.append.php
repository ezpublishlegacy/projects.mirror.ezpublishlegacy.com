<?php /*

[ezjscServer_googletranslate]
Class=eZGoogleTranslateJSCFunctions

*/ ?>
