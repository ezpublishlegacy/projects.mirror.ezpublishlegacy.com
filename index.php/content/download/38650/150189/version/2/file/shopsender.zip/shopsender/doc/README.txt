Workflow Shopsender

author:
Bj�rn Dieding<bjoern@xrow.de>, xrow GbR Germany

Setup:
Install extension. Use after checkout.

Usage:

If an Webshop order has multiple items from different owners. It will send an email to each product owner. Telling him his items were bought.