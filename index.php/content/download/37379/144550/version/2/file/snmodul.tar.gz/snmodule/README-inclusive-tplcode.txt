Subscription/newsletter module
------------------------------

- Subscription list (all subscribers are presented with id, email, subscription_node (path), keywords, approved or not). 
- List administration (add subscriber, edit, delete, approve, set invalid)
- Templatebased subscription and list view
- Automatic send newsletter

WARNING! Before you start:
- the best way to add this to your system, is to make an override directory for notification.

WARNING!
Remember backup of all necessary files before you start.
**********************************************************************  
This script  and all included files in this package comes with no 
warranty. The author of this script will not be held liable for any 
damages caused or alleged to be caused directly or indirectly by this 
script or the files added to this package.
**********************************************************************

How does this subscription-/newslettersystem work IRL with GUI (screenshots added)..
HOWTO:

- add an attribute for your class i.e. folder: can_subscribe and give it a name: "Allow subscription to this page".
- edit a folder object and check this value to allow subscription (if you have many folders in your system, you may have to change the folder-class through a php.script instead of changing the class in the admin-interface..you may get a timeout here and all the objects are not looped through)
- add code to your pagelayout.tpl for subscription-button:
- add design files and code files 
   Design files:
    Place edit.tpl, list.tpl and remove.tpl
    in /design/sitename/template/override/notification
   Kernel files:
    Place all the php.files in 
    /kernel/notification/
   but place the ezhiorule.php in
   /kernel/notification/rules/

- add and configure override/site.ini.append: 
  [MailSettings]
  AdminEmail=[add_email_address]
  EmailSender= [add_email_address]
  NotificationSender=[add_email_address]

- change settings/override/notification.ini.append and add with:
  [RuleSettings]
  RepositoryDirectories[]=kernel/notification/rules
  ExtensionDirectories[]

- fix a cronjob which includes messagedelivery.php to send newsletters

The norwegian word Abonner = english Subscribe if you want to change this in your code

-----------------------------------------------------------------
Code for subscribe-button on page:
-----------------------------------------------------------------

{switch name=sw match=$node.object.data_map.can_subscribe.data_int}
    {case match=true()}
<br />
<form action={"/notification/edit/"|ezurl} method="post" name="SubscribeForm">
    {include uri="design:gui/button.tpl" name=Subscribe id_name=SubscribeToNodeButton value=Abonner}
    <input type="hidden" name="SubscribeNodeID" value="{$node.node_id}">
    <input type="hidden" name="SubscribeNodeName" value="{$node.object.name}">
</form>
    {/case}
    {case}
    {/case}
{/switch}

-----------------------------------------------------------------
edit.tpl 
-----------------------------------------------------------------

<form action={concat($module.functions.edit.uri,"/",$rule_type,"/",$rule_id)|ezurl} method="post" name="Edit">
<h1>Subscribe on page: {$subscribe_node_name}</h1>
<table>
<tr>
<td colspan="2">
Send a message if &quot;{$subscribe_node_name}&quot; or one of the childobjects are changed, and it contains these keywords:
</td>
</tr>
<tr>
<td colspan="2">
<input type="text" name="keyword" value="" size="70">
</td>
</tr>
<tr>
<td colspan="2">
(Let this field be empty if you want a message every time a new object is beeing published)<br />&nbsp;
</td>
</tr>
<tr>
<td>
E-mail address:
</td>
<td>
<input type="text" name="SubscribeEmail" value="{$user_email}" size="40">
</td>
</tr>
</table>

<br />

<input type="hidden" name="sendMethod" value="email">
<input type="hidden" name="CurrentRuleID" value="{$rule_id}">
<input type="hidden" name="SubscribeNodeID" value="{$subscribe_node_id}">
{include uri="design:gui/button.tpl" name=Store id_name=StoreRuleButton value=Register}
<input type="button" value={"Discard"|i18n("design/standard/notification")} onClick="javascript: history.go(-1)">

</form>

-----------------------------------------------------------------
list.tpl 
-----------------------------------------------------------------

<form action={concat($module.functions.list.uri)|ezurl} method="post" name="RuleList">

{section show=$rule_list}
<table class="list" width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
    <th>{"ID:"|i18n("design/standard/notification")}</th>
    <th>{"Rule Type:"|i18n("design/standard/notification")}</th>
    <th>{"Class Name:"|i18n("design/standard/notification")}</th>
    <th>{"Path:"|i18n("design/standard/notification")}</th>
    <th>{"Keyword:"|i18n("design/standard/notification")}</th>
    <th>{"Additional constraint:"|i18n("design/standard/notification")}</th>
    <th>{"Edit:"|i18n("design/standard/notification")}</th>
    <th>{"Remove:"|i18n("design/standard/notification")}</th>
</tr>

{section name=Rule loop=$rule_list sequence=array(bglight,bgdark)}
<tr>
    <td class="{$Rule:sequence}" width="1%">{$Rule:item.id}</td>
    <td class="{$Rule:sequence}">{$Rule:item.type}</td>
    <td class="{$Rule:sequence}">{$Rule:item.contentclass_name}</td>
    <td class="{$Rule:sequence}">{$Rule:item.path}</td>
    <td class="{$Rule:sequence}">{$Rule:item.keyword}</td>
    <td class="{$Rule:sequence}">{section show=$Rule:item.has_constraint}Yes{/section}</td>
    <td class="{$Rule:sequence}" width="1%"><a href={concat($module.functions.edit.uri,"/",$Rule:item.type,"/",$Rule:item.id)|ezurl}><img name="edit" src={"ed
it.png"|ezimage} width="16" height="16" alt="{'Edit'|i18n('design/standard/notification')}" /></a></td>
    <td class="{$Rule:sequence}" width="1%"><input type="checkbox" name="Rule_id_checked[]" value="{$Rule:item.id}" /></td>
</tr>
{/section}
</table>
{/section}

<div class="buttonblock">
<select name="notification_rule_type">
{section name=Rules loop=$rule_type}
<option value="{$Rules:item.information.name}">{$Rules:item.information.name}</option>
{/section}
</select>
{include uri="design:gui/button.tpl" name=new id_name=NewRuleButton value="New Rule"|i18n("design/standard/notification")}
{include uri="design:gui/button.tpl" name=delete id_name=DeleteRuleButton value="Remove"|i18n("design/standard/notification")}
{include uri="design:gui/button.tpl" name=send id_name=SendButton value="Send Message"|i18n("design/standard/notification")}
</div>
</form>

--------------------------------------------------------------------
remove.tpl 
--------------------------------------------------------------------

{switch match=$what_happened}
  {case match=removed}
The subscription is ended.
  {/case}
  {case}
The subscription could not be ended, please contact administrator.
  {/case}
{/switch}

