<?php /* ?ini charset="iso-8859-1"?

[NavigationPart]
Part[ezshippingnavigationpart]=Shipping

[TopAdminMenu]
Tabs[]=shipping

[Topmenu_shipping]
Name=Shipping
Tooltip=manage the global shipping groups.
URL[]
URL[default]=ezshipping/grouplist
URL[browse]=ezshipping/grouplist
NavigationPartIdentifier=ezshippingnavigationpart

Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false



?>
