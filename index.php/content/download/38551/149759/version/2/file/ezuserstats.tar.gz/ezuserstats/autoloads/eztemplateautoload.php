<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezuserstats/autoloads/ezuserstats.php',
                                    'class' => 'eZUserStatsOperator',
                                    'operator_names' => array( 'userstats' ) );
?>
