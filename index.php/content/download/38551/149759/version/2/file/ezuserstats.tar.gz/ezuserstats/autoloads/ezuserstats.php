<?php
//
// Definition of eZUserStatsOperator class
//
// Created on: <19-Aug-2004 10:58:31 oh>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezuserstats.php
*/

/*!
  \class eZUserStatsOperator ezuserstats.php
  \brief The class eZUserStatsOperator does

*/
class eZUserStatsOperator
{
    /*!
    */
    function eZUserStatsOperator( $name = "userstats" )
    {
        $this->Operators = array( $name );
    }

    /*!
     Returns the template operators.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array( "class_id" => array( "type" => "array",
                                           "required" => true,
                                           "default" => "" ),
                      "this_month" => array( "type" => "boolean",
                                             "required" => false,
                                             "default" => false ),
                      "user_id" => array( "type" => "integer",
                                          "required" => true,
                                          "default" => 0 ) );
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $db =& eZDB::instance();

        $classIDArray = $namedParameters["class_id"];
        $thisMonth = $namedParameters["this_month"];
        $userID = $namedParameters["user_id"];
        $classID = implode( ", ", $classIDArray );
        $timeLimitSQL = "";

        if ( $thisMonth == 1 )
        {
            $days = date( "d" ) - 1;
            $hours = date( "G" );
            $minutes = date( "i" );

            $timeStamp = mktime() - ( ( $days * 60 * 60 * 24 ) + ( $hours * 60 * 60 ) + ( $minutes * 60 ) );
            $timeLimitSQL = " ezcontentobject_version.created > $timeStamp AND ";
        }

        $query = "SELECT count(*) as count, ezcontentobject.contentclass_id as id FROM
                      ezcontentobject_version, ezcontentobject
                  WHERE
                      $timeLimitSQL
                      ezcontentobject.contentclass_id in ($classID) AND
                      ezcontentobject.owner_id=$userID AND
                      ezcontentobject_version.contentobject_id=ezcontentobject.id AND
                      ezcontentobject_version.status=1
                  GROUP BY ezcontentobject.contentclass_id";

        $result =& $db->arrayQuery( $query );
        $sortedResult = array();

        foreach( $result as $row )
        {
            $sortedResult[$row['id']] = $row['count'];
        }

        $operatorValue = $sortedResult;
    }
    var $Operators;
}
?>
