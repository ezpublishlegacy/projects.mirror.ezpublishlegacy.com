charset
-------

Summary
~~~~~~~
Returns the current charset.

Usage
~~~~~
::

    charset()

Parameters
~~~~~~~~~~
None.
