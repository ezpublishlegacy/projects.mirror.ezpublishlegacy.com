<?php /*

[ExtensionSettings]
DesignExtensions[]=all2eqrcode

*/ ?>
