<?php
class all2eqrcodeInfo
{
    /*!
     Constructor
    */
	function info()
    {
        return array( 'Name' => "QR-Code Encoder",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://www.all2e.com' title='all2e GmbH'>all2e GmbH</a>",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}    

?>
