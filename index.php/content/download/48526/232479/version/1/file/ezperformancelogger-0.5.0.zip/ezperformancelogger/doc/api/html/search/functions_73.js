var searchData=
[
  ['save_5frun',['save_run',['../interfaceiXHProfRuns.html#a6969d83c3181c70ba05def354414147d',1,'iXHProfRuns\save_run()'],['../classXHProfRuns__Default.html#ae91af6dac754e6f7758afdd1d17ec9fd',1,'XHProfRuns_Default\save_run()']]],
  ['savedruns',['savedRuns',['../classeZXHProfLogger.html#a74de477561e817af21fe558a1b85c42a',1,'eZXHProfLogger']]],
  ['sort_5fcbk',['sort_cbk',['../xhprof_8php.html#ad597b83d7fc11ca129078baef0ac26eb',1,'xhprof.php']]],
  ['start',['start',['../classeZXHProfLogger.html#a8594f99222ba56d9c3a7498af48016dd',1,'eZXHProfLogger']]],
  ['stat_5fdescription',['stat_description',['../xhprof_8php.html#ac08d0b3dd7891ffed272a2eb33870518',1,'xhprof.php']]],
  ['stop',['stop',['../classeZXHProfLogger.html#acffa25e73c9ff4b031474586600ff6d4',1,'eZXHProfLogger']]],
  ['symbol_5freport',['symbol_report',['../xhprof_8php.html#abd3cec4a7ca1efc73e9e64313118bdaa',1,'xhprof.php']]]
];
