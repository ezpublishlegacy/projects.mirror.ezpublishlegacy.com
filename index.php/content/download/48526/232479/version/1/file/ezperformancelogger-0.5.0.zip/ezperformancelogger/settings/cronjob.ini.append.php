<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezperformancelogger

[CronjobPart-updateperfstats]
Scripts[]=updateperfstats.php

[CronjobPart-removexhprofdata]
Scripts[]=removexhprofdata.php

*/ ?>
