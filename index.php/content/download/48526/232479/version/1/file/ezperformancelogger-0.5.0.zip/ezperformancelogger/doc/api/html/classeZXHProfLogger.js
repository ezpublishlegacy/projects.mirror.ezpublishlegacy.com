var classeZXHProfLogger =
[
    [ "isRunning", "classeZXHProfLogger.html#a80dbdea0e69c9f740ef13d86e8754207", null ],
    [ "logDir", "classeZXHProfLogger.html#a8773763bf048b9f95d4b74c47e970d3b", null ],
    [ "removeSavedRuns", "classeZXHProfLogger.html#ad93053d75df80d41f14557bee9e97c37", null ],
    [ "runs", "classeZXHProfLogger.html#a9fb17d2010fa0b9ea638cd15aefc53e2", null ],
    [ "savedRuns", "classeZXHProfLogger.html#a74de477561e817af21fe558a1b85c42a", null ],
    [ "start", "classeZXHProfLogger.html#a8594f99222ba56d9c3a7498af48016dd", null ],
    [ "stop", "classeZXHProfLogger.html#acffa25e73c9ff4b031474586600ff6d4", null ],
    [ "$logdir", "classeZXHProfLogger.html#a5c4c55eb3c0818e4a86ba6fb0883f95f", null ],
    [ "$profilingRunning", "classeZXHProfLogger.html#a28dfe20749148010b3c5a53f51a83389", null ],
    [ "$runs", "classeZXHProfLogger.html#a6d845daa231251650e4b83849baad98d", null ]
];