var typeahead_8php =
[
    [ "$GLOBALS", "typeahead_8php.html#a14111e48d5768845bd9184269880ec8f", null ],
    [ "$xhprof_runs_impl", "typeahead_8php.html#a78f15e6581ee51820cb9b2e359e5bbb1", null ]
];