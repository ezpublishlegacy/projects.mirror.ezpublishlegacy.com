var searchData=
[
  ['_5f_5fconstruct',['__construct',['../classXHProfRuns__Default.html#a47cbeac1869d6f3ff020292c3b09a7ad',1,'XHProfRuns_Default']]]
];
