<?php /*

[OutputSettings]
OutputFilterName=eZPerfLogger

[Cache_xhprof]
name=eZPerformanceLogger xhprof traces cache
path=xhprof

*/ ?>