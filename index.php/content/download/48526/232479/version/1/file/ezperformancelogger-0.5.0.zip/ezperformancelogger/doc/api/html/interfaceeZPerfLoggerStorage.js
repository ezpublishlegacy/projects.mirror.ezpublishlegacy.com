var interfaceeZPerfLoggerStorage =
[
    [ "insertStats", "interfaceeZPerfLoggerStorage.html#ae9d081fbe8ea531a67c713ae23bef307", null ]
];