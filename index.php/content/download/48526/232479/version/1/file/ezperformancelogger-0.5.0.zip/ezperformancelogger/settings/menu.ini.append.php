<?php /*

[Leftmenu_setup]
Links[xhprof]=xhprof/list
LinkNames[xhprof]=XHProf Profiling

*/ ?>
