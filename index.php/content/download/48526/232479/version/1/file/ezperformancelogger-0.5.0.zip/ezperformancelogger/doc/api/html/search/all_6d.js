var searchData=
[
  ['measure',['measure',['../classeZPerfLogger.html#a9edd95d7316916a12f074e43faf102d8',1,'eZPerfLogger\measure()'],['../interfaceeZPerfLoggerProvider.html#ab515c10d471bc79c4637bd10ca9c5b0b',1,'eZPerfLoggerProvider\measure()']]],
  ['modify',['modify',['../classeZPerformanceLoggerOperators.html#a7b930e75bdfb8b69e186cafef7a50a6b',1,'eZPerformanceLoggerOperators']]],
  ['module_2ephp',['module.php',['../module_8php.html',1,'']]]
];
