var interfaceeZPerfLoggerProvider =
[
    [ "measure", "interfaceeZPerfLoggerProvider.html#ab515c10d471bc79c4637bd10ca9c5b0b", null ]
];