<?php
/*
        Store this file in the ./bin directory of eZp3
        Run the script delete all cached files and directories with wwwrun user



        clearvar.php v1.0 by Ekkehard D�rre 2003
Script from konik
16-Apr-2003 10:29 postet php.net under rmdir
*/

# Directory name with the cached files
# no trailing slash ('/') !!
$p_path = '../var/cache';



                            function rec_delete($p_path)
                            {

                             if(false === @is_dir($p_path)){
                              @unlink($p_path);
                               clearstatcache();
                               if (@file_exists($p_path)) {
                                if(substr_count($p_path,":")){
                                   @system("del ".eregi_replace("/","\\",$p_path));
                                }else{
                                   @system("rm $p_path");
                                 }
                               }
                              clearstatcache();
                               if (@file_exists($p_path)){
                                 return false;
                               }else{
                                 return true;
                               }
                             }else{
                               $dh = @opendir($p_path);
                               while(($file = @readdir($dh)) !==false ){
                               if($file != "." && $file != ".."){
                                  $fullpath = $p_path.$file;
                                  if(@is_dir($fullpath))$fullpath.="/";
                                   if (!rec_delete($fullpath)){
                                     closedir($dh);
                                     return false;
                                   }
                                 }
                               }
                               @closedir($dh);
                              @rmdir($p_path);
                               clearstatcache();
                               if (@file_exists($p_path)) {
                                if(substr_count($p_path,":")){
                                   @system("del ".eregi_replace("/","\\",$p_path));
                                }else{
                                   @system("rmdir $p_path");
                                 }
                              }
                               clearstatcache();
                               if (@file_exists($p_path)){
                                return false;
                               }else{
                                 return true;
                               }
                             }
                            }
echo '<pre>';
rec_delete($p_path);  # execute script

echo '</pre>';
?>


