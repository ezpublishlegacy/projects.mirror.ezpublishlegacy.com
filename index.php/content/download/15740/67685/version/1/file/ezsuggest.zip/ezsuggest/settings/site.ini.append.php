<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezsuggest


[RoleSettings]
PolicyOmitList[]=ezsuggest/search

*/ ?>
