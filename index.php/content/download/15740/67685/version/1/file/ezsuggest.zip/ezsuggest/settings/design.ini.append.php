<?php /*

[ExtensionSettings]
DesignExtensions[]=ezsuggest

[JavaScriptSettings]
JavaScriptList[]=spry/SpryData.js
JavaScriptList[]=spry/xpath.js
JavaScriptList[]=spry/SpryAutoSuggest.js

[StylesheetSettings]
CSSFileList[]=ezsuggest.css

*/ ?>