<?php
// Copyright (C) 2003 Triligon Networks SA. All rights reserved.
// This code is licensed under the GPL version 2.
//
// It specifically is NOT licensed under the eZ publish professional
// license for holder of that license.
//
// If GPL is a hindrance for your usage of this module, contact
// info@buz.ch, as we are willing to negotiate relicensing for you
// or everyone.
//
// As to eZ Systems incorporating this module into the professional
// licensed version: we will allow that in exchange for a professional
// license  


include_once( "kernel/classes/ezcalendar.php" );
include_once( "kernel/common/template.php" );

$http =& eZHTTPTool::instance();
$Module =& $Params["Module"];

$timestamp=$http->Variable('timestamp');
if ($timestamp < 1)
{
    $timestamp=time();
}
$db =& eZDB::instance();

$db->query( "INSERT INTO ezcalendarevents (userid, start_time, end_time, description) VALUES ( '".eZUser::currentUserID()."', '$timestamp', '".($timestamp+3600)."', '' )" );
// commit the transaction
// $db->commit(); //won't return id if commit is called with MySQL (not sure about Postgre)
// fetch the last automatically incremented value

$eventid = $db->lastSerialID( "ezcalendarevents", "eventid" );


$Module->redirectTo( $Module->functionURI( "edit" ) . "?eventid=$eventid" );
return;

?>
