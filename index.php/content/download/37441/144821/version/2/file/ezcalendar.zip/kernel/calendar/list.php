<?php
// Copyright (C) 2003 Triligon Networks SA. All rights reserved.
// This code is licensed under the GPL version 2.
//
// It specifically is NOT licensed under the eZ publish professional
// license for holder of that license.
//
// If GPL is a hindrance for your usage of this module, contact
// info@buz.ch, as we are willing to negotiate relicensing for you
// or everyone.
//
// As to eZ Systems incorporating this module into the professional
// licensed version: we will allow that in exchange for a professional
// license  


include_once( "kernel/classes/ezcalendar.php" );
include_once( "kernel/common/template.php" );

$http =& eZHTTPTool::instance();
$Module =& $Params["Module"];
$tpl =& templateInit();
$tpl->setVariable( 'module', $Module );

if ( $http->hasPostVariable( 'CreateEventButton' ) )
{
    $event = new eZEvent( array( 'userid' => $userid ) ); //fixme, we need to get the userid first.
    $event->store();
    $Module->redirectTo( $Module->functionURI( "edit" ) . '/' . $event->attribute( 'eventid' ) . '/' );
    return;
}

$start_time=$http->Variable('timestamp_start');
$end_time=$http->Variable('timestamp_end');

$list=ezCalendar::get_events($start_time,$end_time);

$tpl =& templateInit();

$tpl->setVariable("events", $list);

$Result = array();
$Result['content'] =& $tpl->fetch( "design:calendar/list.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'kernel/calendar', 'Calendar / List' ) ) );

?>
