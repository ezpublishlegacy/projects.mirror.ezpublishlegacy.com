<?php
// Copyright (C) 2003 Triligon Networks SA. All rights reserved.
// This code is licensed under the GPL version 2.
//
// It specifically is NOT licensed under the eZ publish professional
// license for holder of that license.
//
// If GPL is a hindrance for your usage of this module, contact
// info@buz.ch, as we are willing to negotiate relicensing for you
// or everyone.
//
// As to eZ Systems incorporating this module into the professional
// licensed version: we will allow that in exchange for a professional
// license  


/*!
  \class eZCalendar  ezcalendar.php
  \brief ezEvent handles user specific calendars

*/


  // include the library
include_once( "lib/ezdb/classes/ezdb.php" );


class ezCalendar
{
    var $events=NULL;
    var $events_lower_boundary=0;
    var $events_upper_boundary=0;
    // fetch the database instance
    
    function fetch_single_event($eventid)
    {
        $db =& eZDB::instance();
        
        $data=$db->arrayQuery( "SELECT * FROM ezcalendarevents WHERE eventid='$eventid'");
        return $data[0];
    }
    
    function fetch($lower_boundary, $upper_boundary)
    {
        
        $db =& eZDB::instance();
        $this->events =&$db->arrayQuery( "SELECT * FROM ezcalendarevents WHERE userid='".eZUser::currentUserID()."' AND end_time>='$lower_boundary' AND start_time<='$upper_boundary'");
        $this->events_lower_boundary=$lower_boundary;
        $this->events_upper_boundary=$upper_boundary;
    }
    
    function get_events($lower_boundary, $upper_boundary)
    {
        $return_values=array();

        if (($lower_boundary < $this->events_lower_boundary) OR ($upper_boundary > $this->events_upper_boundary) OR ($this->events==NULL))
        {
            ezCalendar::fetch($lower_boundary, $upper_boundary);
        }
        
        foreach ($this->events as $value)
        {
            if ((($value['start_time'] >= $lower_boundary) AND
                 ($value['start_time'] <= $upper_boundary)) OR

                (($value['end_time'] >= $lower_boundary) AND
                ($value['end_time'] <= $upper_boundary)) OR

                (($value['start_time'] <= $lower_boundary) AND
                ($value['end_time'] >= $upper_boundary)))
            {
                array_push($return_values, $value);
            }
        }
        return $return_values;
    }
    
    function calculate_day_boundaries($time=-1)
    {
        if ($time < 0)
        {
            $time=time();
        }
        
        $start_time=intval($time / 86400) * 86400-date("Z", $time)+86400; //It's not entirely clear to me why I need to add one day (86400) to all timestamps but this way it works.;
        $end_time=$start_time+86399;
        
        return(array($start_time, $end_time));
    }


    
    function calculate_week_boundaries($time=-1)
    {
        if ($time < 0)
        {
            $time=time();
        }
        $time_array=getdate($time);
        $start_time=mktime(0,0,0,$time_array['mon'], $time_array['mday'], $time_array['year']);
            
        if ($time_array['wday']==0)
        {
            $time_array['wday']=6;
        }

        else
        {
            $time_array['wday']=$time_array['wday']-1;
        }
        
        $start_time=$start_time-$time_array['wday']*86400;
        $end_time=$start_time+(86400*7)-1;
        return array($start_time, $end_time);
    }
    
    function calculate_month_boundaries($time=-1)
    {
        if ($time < 0)
        {
            $time=time();
        }
        $time_array=getdate($time);
        
        $start_time=mktime(0,0,0,$time_array['mon'],1, $time_array['year']);
        $end_time=mktime(23,59,59,$time_array['mon'],date('t', $start_time),$time_array['year']);
        
        return(array($start_time, $end_time));
    }

    function calculate_5_week_month_boundaries($time=-1)
    {
        $month_boundaries=ezCalendar::calculate_month_boundaries($time);
        
        
        $first_week_boundaries=ezCalendar::calculate_week_boundaries($month_boundaries[0]);
        $last_week_boundaries=ezCalendar::calculate_week_boundaries($month_boundaries[1]);
        
        return array($first_week_boundaries[0], $last_week_boundaries[1]);
    }
    
        
    function generate_months_of_years($time=-1)
    {
        if ($time < 0)
        {
            $time=time();
        }
        $time_array=getdate($time);

        $year=$time_array['year'];
        $month=1;
        $month_time_hash=array();
    
        while ($month < 13)
        {
            $my_time=mktime(0,0,0,$month,1,$year);
            $month_time_hash[date("F", $my_time)]=$my_time;
            $month++;
        }
    
        return $month_time_hash;
    }
    
    function render_day_css($time=-1, $show_hours=1, $height=720, $width=800, $box_width=736)
    {
        $time_array=ezCalendar::calculate_day_boundaries($time);

        $time_zone_offset=(int)date("Z", time());

        $todays_events=eZCalendar::get_events($time_array[0], $time_array[1]);
        

        if ($show_hours==1)
        {
            $data=$data."<div style=\"height:".$height."px; width:".$width."px\">\n";
            $hour=0;
            $hour_height=$height/24;
            $dark_color="#cedbf0";
            $light_color="#dce5f1";
            
            while ($hour < 24)
            {
                if (($hour%2)>0)
                {
                    $data=$data."<div style=\"background:$light_color; margin-right:5px;height:". $hour_height."px; width:".$width."px;\">$hour:00</div>\n";
                }
                else
                {
                    $data=$data."<div style=\"background:$dark_color; margin-right:5px;height:". $hour_height."px; width:".$width."px;\">$hour:00</div>\n";
                }
                $hour++;
            }
            $offset_from_left=64;
            $data=$data."</div><div style=\"height:".$height."px; width:".($box_width)."px; align:left\">\n";
        }
        else
        {
            $offset_from_left=0;
            $data="<div style=\"height:".$height."px; width:".$width."px; align:left\">";
        }
        
        foreach ($todays_events as $event)
        {
            $duration=$event['end_time']-$event['start_time'];
                
            if ($time_array[0] < $event['start_time'])
            {
                $offset_from_top=intval(($event['start_time']- $time_zone_offset - $time_array[0]+date("Z",$event['start_time'])) * ($height/86400));
            }
            else //event began some time before today
            {
                $offset_from_top=0;
            }
            
            if (($time_array[1]) > $event['end_time']) //event ends today
            {
                $box_height=intval(round($duration*($height/86400)));
            }

            else //event ends some time after today
            {
                $box_height=intval(round($height-$offset_from_top));
            }
            
            $data=$data."<div style=\"border-width:small; overflow:auto;  border-color:black; border-style:dotted; width:".$box_width."px; position:absolute; top:".$offset_from_top."px; height:".$box_height."px; left:".$offset_from_left."px\">
            <a href=\"./edit?eventid=". $event['eventid'] ."\">
            ".date("r", $event['start_time'])." ".$event['description']."<br>
            Duration: $duration</a></div>\n";
        }
        $data=$data."</div>";
        return $data;
    }
    
    function render_week_css($time=-1)
    {
        $week_boundaries=ezCalendar::calculate_week_boundaries($time);
        
        $data="<div style=\"position:absolute; top:0px; width:904px\">
                    <div style=\"position:absolute; top:0px; width:904px\"><a href=\"./week?timestamp=" . ($week_boundaries[0]-150000) ."\">Previous Week</a></div>
                    <div style=\"position:absolute; text-align:center; top:0px; width:904px\"><strong>Week ".date("W", $week_boundaries[0])." ". date("d.m.y",$week_boundaries[0]). " - " . date("d.m.y",$week_boundaries[1]). "</strong> (<a href=\"./month?timestamp=".$week_boundaries[0]."\">Month</a>)</div>
                    <div style=\"position:absolute; text-align:right; top:0px; width:904px\"><a href=\"./week?timestamp=" . ($week_boundaries[1]+150000) ."\">Next Week</a></div>
                    <div style=\"position:absolute; top:2em\">";
       
        if ($this->events==NULL)
        {
            ezCalendar::fetch($week_boundaries[0], $week_boundaries[1]);
        }
        //echo date("r", $week_boundaries[0]).date("r", $week_boundaries[1]);
        
        //generate top line with dates
        $counter=0;
        $offset=64;
        $day=$week_boundaries[0];
        
        while ($counter < 7)
        {
            $data=$data."<div style=\"height:40px; position:absolute; top:0px; left:".$offset."px\">
                        <a href=\"./day?timestamp=$day\"> ".date("l",$day)."
                        <br>".date("d.m.y",$day)."</a></div>\n";
            $offset=$offset + 120;
            $day=$day+86400;
            $counter++;
        }
        $data=$data."</div><div>
        
        <div style=\"position:absolute; width=904px; top:5em; height:720px\">";
        
        $data=$data."<div style=\"position:absolute; left:0px; width=184px\">".ezCalendar::render_day_css($week_boundaries[0], 1, 720, 904, 114). "</div>\n";

        $day=$week_boundaries[0]+86400;
        $offset=184;
        $counter=1;
        while ($counter < 7)
        {
            $data=$data."<div style=\"border-left-width:thin; border-left-style:solid; position:absolute; left:".$offset."px; width=120px\">".ezCalendar::render_day_css($day, 0, 720, 120, 114)."</div>\n";
            $counter++;
            $offset=$offset+120;
            $day=$day+86400;
        }
        
        $data=$data."</div>";
        return $data;
    }
    
    function extend_event($event)
    {
        $event['start_minute']=(string)(date("i", $event['start_time']));
        $event['start_hour']=(string)(date("H", $event['start_time']));
        $event['start_day']=(string)(date("d", $event['start_time']));
        $event['start_month']=(string)(date("m", $event['start_time']));
        $event['start_year']=(int)(date("Y", $event['start_time']));
        $event['start_month_text']=date("F", $event['start_time']);
        $event['start_day_text']=date("l", $event['start_time']);

        $event['end_minute']=(string)(date("i", $event['end_time']));
        $event['end_hour']=(string)(date("H", $event['end_time']));
        $event['end_day']=(string)(date("d", $event['end_time']));
        $event['end_month']=(string)(date("m", $event['end_time']));
        $event['end_year']=(int)(date("Y", $event['end_time']));
        $event['end_month_text']=date("F", $event['end_time']);
        $event['end_day_text']=date("l", $event['end_time']);
            
        return $event;
    } 
    
    function generate_list($start_time, $end_time)
    {
        ezCalendar::fetch($start_time, $end_time);
        
        $processed_events=array();
        
        foreach ($this->events as $event)
        {
            array_push($processed_events, ezCalendar::extend_event($event));
        }
        
        return $processed_events;
    }

    function generate_day($time=-1)
    {
        if ($time < 0)
        {
            $time=time()-86400;
        }
        
        $start_time=intval($time / 86400)*86400;

        if ($this->events==NULL)
        {
            ezCalendar::fetch($start_time, $start_time+86399);
        }

        $events=ezCalendar::get_events($start_time, $start_time+86399);
        $processed_events=array();
        
        foreach ($events as $event)
        {
            array_push($processed_events, ezCalendar::extend_event($event));
        }
        return $processed_events;
    }


    function generate_week($time=-1, $fill_in_day_data=1)
    {
        $week_boundaries=ezCalendar::calculate_week_boundaries($time);

        if (($this->events==NULL) AND ($fill_in_day_data==1))
        {
            ezCalendar::fetch($week_boundaries[0], $week_boundaries[1]);
        }
        $start_time=$week_boundaries[0];
        $wday=0;
        $day_time_hash=array();
        while ($wday < 7)
        {
            if ($fill_in_day_data==1)
            {
                array_push($day_time_hash, array("day" => date("d",$start_time),
                                                 "month" => date("m", $start_time),
                                                 "year" => date("y", $start_time),
                                                 "day_text" => date("l", $start_time),
                                                 "events" => ezCalendar::generate_day($start_time),
                                                 "start_time" => $start_time));
            }
            else
            {
                array_push($day_time_hash, array("day" => date("d",$start_time),
                                                 "month" => date("m", $start_time),
                                                 "year" => date("y", $start_time),
                                                 "day_text" => date("l", $start_time),
                                                 "start_time" => $start_time));
            }
            $start_time=$start_time+86400;
            $wday++;
        }
        return $day_time_hash;
    }


    
    function generate_5_week_month($time=-1, $fill_in_day_data=1)
    {
        $month_boundaries=ezCalendar::calculate_5_week_month_boundaries($time);
    
        if ($fill_in_day_data==1)
        {
            ezCalendar::fetch($month_boundaries[0], $month_boundaries[1]);
        }
        
        $month_array=array();
        $week_counter=0;
        while ($week_counter < 5)
        {
            array_push($month_array, ezCalendar::generate_week($month_boundaries[0], $fill_in_day_data));
            $month_boundaries[0]=$month_boundaries[0]+(7*86400);
            $week_counter++;
        }
        return $month_array;
        
    }

    function generate_year($time=-1, $fill_in_day_data=0)
    {
        $months=array();
        $counter=1;

        if ($time < 0)
        {
            $time=time();
        }

        $time_array=getdate($time);

        while($counter < 13)
        {
            $month_time=mktime(0,0,0,$counter,1,$time_array['year']);
            array_push($months, ezCalendar::generate_5_week_month($month_time, $fill_in_day_data));
            $counter++;
        }
        return $months;
    }
    
    
}

?>
