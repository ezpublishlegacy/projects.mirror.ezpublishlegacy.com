<?php
// Copyright (C) 2003 Triligon Networks SA. All rights reserved.
// This code is licensed under the GPL version 2.
//
// It specifically is NOT licensed under the eZ publish professional
// license for holder of that license.
//
// If GPL is a hindrance for your usage of this module, contact
// info@buz.ch, as we are willing to negotiate relicensing for you
// or everyone.
//
// As to eZ Systems incorporating this module into the professional
// licensed version: we will allow that in exchange for a professional
// license  

//

include_once( "kernel/classes/ezcalendar.php" );
include_once( "kernel/common/template.php" );

$http =& eZHTTPTool::instance();
$Module =& $Params["Module"];
$tpl =& templateInit();
$tpl->setVariable( 'module', $Module );

$eventid=$http->Variable('eventid');
$event=eZCalendar::fetch_single_event($eventid);

$tpl->setVariable('message', $http->Variable('message'));

if ($event['userid']!=eZUser::currentUserID())
{
    $tpl->setVariable('message', "Access denied");
}

else
{
    $tpl->setVariable('event', ezCalendar::extend_event($event));
}

$Result = array();
$Result['content'] =& $tpl->fetch( "design:calendar/edit.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'kernel/calendar', 'Calendar / Edit' ) ) )

?>
