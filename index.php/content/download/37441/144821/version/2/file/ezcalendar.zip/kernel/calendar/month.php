<?php
// Copyright (C) 2003 Triligon Networks SA. All rights reserved.
// This code is licensed under the GPL version 2.
//
// It specifically is NOT licensed under the eZ publish professional
// license for holder of that license.
//
// If GPL is a hindrance for your usage of this module, contact
// info@buz.ch, as we are willing to negotiate relicensing for you
// or everyone.
//
// As to eZ Systems incorporating this module into the professional
// licensed version: we will allow that in exchange for a professional
// license  


include_once( "kernel/classes/ezcalendar.php" );
//include_once( "kernel/common/template.php" );

$http =& eZHTTPTool::instance();
$Module =& $Params["Module"];

$timestamp=-1;

if ($http->hasVariable('timestamp'))
{
    $timestamp=$http->Variable('timestamp');
}

$events=ezCalendar::generate_5_week_month($timestamp);
/*echo "<plaintext>";
print_r($events);
echo "</plaintext>";*/
//$tpl->setVariable('events', $events);



$content='
<table width="100%">
    <thead>
        <tr>
            <td><a href="./month?timestamp='.($events[0][0]['start_time']-700000).'">&lt; Previous</a></td>
            <td colspan="5" align="center" ><h2>'.$events[2][0]['month'].'/'.$events[2][0]['year'].'</h2></td>
            <td align="right"><a href="./month?timestamp='.($events[4][6]['start_time']+700000).'">Next &gt;</a></td>
        </tr>
        <tr>
            <td width="14%"><strong>Monday</strong></td>
            <td width="14%"><strong>Tuesday</strong></td>
            <td width="14%"><strong>Wednesday</strong></td>
            <td width="14%"><strong>Thursday</strong></td>
            <td width="14%"><strong>Friday</strong></td>
            <td width="14%"><strong>Saturday</strong></td>
            <td width="14%"><strong>Sunday</strong></td>
        </tr>
    </thead>
    <tbody>';

foreach ($events as $week)
{
    $content=$content."<tr height=\"100\">";
    foreach ($week as $day)
    {
        if ($day['month'] == $events[2][0]['month'])
        {
            $content=$content."<td valign=\"top\" class=\"bgdark\"><a href=\"./day?timestamp=".$day['start_time']."\">".$day['day']."</a>";
        }
        else
        {
            $content=$content."<td valign=\"top\" class=\"bglight\"><a href=\"./day?timestamp=".$day['start_time']."\">".$day['day']."</a>";
        }
        foreach ($day['events'] as $event)
        {
            $content=$content."<br/><a href=\"./edit?eventid=".$event['eventid']."\"> ".$event['start_hour'].":".$event['start_minute']." ".$event['description']."</a>";
        }
        $content=$content."&nbsp;</td>";
    }
    
    $content=$content."</tr>";
}
$content=$content."</tbody></table>";
    
    

$Result = array();
$Result['content'] =& $content;
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'kernel/calendar', 'Calendar / Month' ) ) );

?>
