<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ggwebservices

[RegionalSettings]
TranslationExtensions[]=ggwebservices

*/ ?>