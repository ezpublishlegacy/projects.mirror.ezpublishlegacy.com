<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Webservices Debugger</source>
        <comment>Navigation part</comment>
        <translation>Debugger di webservices</translation>
    </message>
</context>
<context>
    <name>extension/ggwebservices</name>
    <message>
        <source>WS Debugger</source>
        <translation>Debugger WS</translation>
    </message>
    <message>
        <source>Local server</source>
        <translation>Server locale</translation>
    </message>
    <message>
        <source>Remote servers</source>
        <translation>Server remoti</translation>
    </message>
</context>
</TS>