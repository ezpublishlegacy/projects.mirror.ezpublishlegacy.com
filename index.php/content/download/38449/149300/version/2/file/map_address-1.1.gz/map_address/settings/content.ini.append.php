<?php /* #?ini charset="iso-8859-1"?

[CustomTagSettings]
AvailableCustomTags[]=map_address
IsInline[map_address]=true

[map_address]
CustomAttributes[]=height
CustomAttributes[]=width
CustomAttributes[]=zoom
CustomAttributesDefaults[height]=300
CustomAttributesDefaults[width]=500
CustomAttributesDefaults[zoom]=17
*/ ?>
