function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      if (oldonload) {
        oldonload();
      }
      func();
    }
  }
}

function load( address, map_id,zoom) {
 if (GBrowserIsCompatible()) {
   var map = new GMap2(document.getElementById(map_id));
   var geocoder = new GClientGeocoder();
   map.addControl(new GSmallMapControl());
   map.addControl(new GMapTypeControl());
   geocoder.getLatLng(
     address,
     function(point) {
       if (!point) {
         alert(address + " not found");
       } else {
         map.setCenter(point, zoom);
         var marker = new GMarker(point);
         map.addOverlay(marker);
         marker.openInfoWindowHtml(address);
       }
     }
   );
 }
}
