<?php /* #?ini charset="utf-8"?

[AdditionalMenuSettings]
SubMenuTemplateArray[]=popupmenu/popup_tag_menu.tpl

[WindowControlsSettings]
AdditionalTabs[]=eztags

[AdditionalTab_eztags]
Title=
Description=
NavigationPartName=ezcontentnavigationpart
HeaderTemplate=eztags_header.tpl
Template=eztags.tpl
*/
