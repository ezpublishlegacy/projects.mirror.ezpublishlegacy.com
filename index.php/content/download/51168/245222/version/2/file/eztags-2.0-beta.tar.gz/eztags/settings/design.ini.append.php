<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=eztags

[JavaScriptSettings]
FrontendJavaScriptList[]=ezjsc::jquery
FrontendJavaScriptList[]=ezjsc::jqueryio
FrontendJavaScriptList[]=jqmodal.js
FrontendJavaScriptList[]=jquery.eztags.js
FrontendJavaScriptList[]=tagsstructuremenu.js

BackendJavaScriptList[]=ezjsc::jquery
BackendJavaScriptList[]=ezjsc::jqueryio
BackendJavaScriptList[]=ezjsc::yui2
BackendJavaScriptList[]=jqmodal.js
BackendJavaScriptList[]=jquery.eztags.js
BackendJavaScriptList[]=tagsstructuremenu.js
BackendJavaScriptList[]=jquery.eztagschildren.js

[StylesheetSettings]
BackendCSSFileList[]=jqmodal.css
BackendCSSFileList[]=tagssuggest.css
BackendCSSFileList[]=contentstructure-tree.css

FrontendCSSFileList[]=jqmodal.css
FrontendCSSFileList[]=tagssuggest.css
FrontendCSSFileList[]=contentstructure-tree.css
*/
