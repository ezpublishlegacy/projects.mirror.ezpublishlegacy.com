<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezjsctags
FunctionList[]=ezjsctagschildren

[ezjscServer_ezjsctags]
Class=ezjscTags

[ezjscServer_ezjsctagschildren]
Class=ezjscTagsChildren
*/
