<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=eztags

[RegionalSettings]
TranslationExtensions[]=eztags
*/
