<?php

class eztagsInfo
{
    static public function info()
    {
        return array( 'Name'      => '<a href="http://projects.ez.no/eztags">eZ Tags LS</a> extension',
                      'Version'   => '//autogentag//',
                      'Copyright' => 'Copyright (C) 2010-2012 Netgen d.o.o., 1999-2012 eZ Systems AS',
                      'License'   => '//EZP_LICENSE//' );
    }
}
