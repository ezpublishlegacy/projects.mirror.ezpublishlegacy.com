<!DOCTYPE TS><TS>
<context>
   <name>extension/epoagreement</name>
   <message>
       <source>I accept these terms</source>
       <translation>J'accepte les termes du contrat.</translation>
   </message>
   <message>
       <source>You must accept terms.</source>
       <translation>Vous devez accepter les termes du contrat</translation>
   </message>
   <message>
       <source>Related agreement article node id</source>
       <translation>Id du noeud de type [Article] présentant le contrat</translation>
   </message>
   <message>
       <source>This text is only an introduction of the terms that need your agreement. If you want to read the full version, click here.</source>
       <translation>Le texte ci-dessus n'est que l'introduction du texte pour lequel votre accord est nécessaire. Pour le consulter dans son intégralité, cliquez ici.</translation>
   </message>
</context>
</TS>
