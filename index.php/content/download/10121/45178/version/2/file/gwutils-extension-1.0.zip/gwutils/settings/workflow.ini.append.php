<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=gwutils
AvailableEventTypes[]=event_gwupdatehidden

*/ ?>
