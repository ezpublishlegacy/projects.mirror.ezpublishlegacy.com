<?php /*

[oracle]
ColumnOptionTranslations[ezx_mbpaex.passwordvalidationregexp]=null

*/ ?>