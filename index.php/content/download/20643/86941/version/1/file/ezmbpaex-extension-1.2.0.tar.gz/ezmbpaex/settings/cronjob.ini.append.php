<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezmbpaex

[CronjobPart-ezmbpaex_send_expiry_notifications]
Scripts[]
Scripts[]=ezmbpaex_sendexpirynotifications.php

[CronjobPart-ezmbpaex_updatechildren]
Scripts[]
Scripts[]=ezmbpaex_updatechildren.php

*/ ?>