<?php /* #?ini charset="utf8"?

[ViewSettings]
GroupedInput[]=ezpaex

[EditSettings]
GroupedInput[]=ezpaex

[CollectionSettings]
GroupedInput[]=ezpaex

*/ ?>
