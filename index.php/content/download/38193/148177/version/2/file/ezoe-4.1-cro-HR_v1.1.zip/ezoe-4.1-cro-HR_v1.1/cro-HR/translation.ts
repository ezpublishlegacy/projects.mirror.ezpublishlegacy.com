<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Browse</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Za odabir objekata, koristite radiobutton ili checkbox oznaku te kliknite na &quot;Odaberi&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Za odabir objekta koji se nalazi pod jednim od prikazanih objekata, kliknite na naziv objekta za prikaz liste podobjekata.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Knjižne oznake</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Nazad</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Vršna razina</translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation>Prikaz podelemenata koristeći jednostavnu listu.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation>Sličica</translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation>Prikaz podelemenata koristeći sličice.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Obrni odabir.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Vrsta datoteke</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Disable editor</source>
        <translation>Isključivanje editora</translation>
    </message>
    <message>
        <source>Enable editor</source>
        <translation>Uključivanje editora</translation>
    </message>
</context>
<context>
    <name>design/standard/ezdhtml</name>
    <message>
        <source>Insert object</source>
        <translation>Ubaci objekt</translation>
    </message>
    <message>
        <source>Insert link</source>
        <translation>Ubaci link</translation>
    </message>
    <message>
        <source>Insert table</source>
        <translation>Ubaci tablicu</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Poništi</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Vrati</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Zadebljano</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Ukošeno</translation>
    </message>
    <message>
        <source>Numbered list</source>
        <translation>Pobrojana lista</translation>
    </message>
    <message>
        <source>Bullet list</source>
        <translation>Lista s točkama</translation>
    </message>
    <message>
        <source>Insert special character</source>
        <translation>Ubaci specijalni znak</translation>
    </message>
    <message>
        <source>Insert literal text</source>
        <translation>Ubaci literal tekst</translation>
    </message>
    <message>
        <source>Insert anchor</source>
        <translation>Ubaci anchor</translation>
    </message>
    <message>
        <source>Insert custom tag</source>
        <translation>Ubaci prilagođeni tag</translation>
    </message>
    <message>
        <source>Insert row</source>
        <translation>Ubaci redak</translation>
    </message>
    <message>
        <source>Insert column</source>
        <translation>Ubaci stupac</translation>
    </message>
    <message>
        <source>Delete row</source>
        <translation>Izbriši redak</translation>
    </message>
    <message>
        <source>Delete column</source>
        <translation>Izbriši stupac</translation>
    </message>
    <message>
        <source>Split cell</source>
        <translation>Podijeli ćeliju</translation>
    </message>
    <message>
        <source>Merge cell</source>
        <translation>Spoji ćeliju</translation>
    </message>
    <message>
        <source>Decrease list indent</source>
        <translation>Smanji uvučenost liste</translation>
    </message>
    <message>
        <source>Increase list indent</source>
        <translation>Povećaj uvučenost liste</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <source>Heading 1</source>
        <translation>Naslov 1</translation>
    </message>
    <message>
        <source>Heading 2</source>
        <translation>Naslov 2</translation>
    </message>
    <message>
        <source>Heading 3</source>
        <translation>Naslov 3</translation>
    </message>
    <message>
        <source>Heading 4</source>
        <translation>Naslov 4</translation>
    </message>
    <message>
        <source>Heading 5</source>
        <translation>Naslov 5</translation>
    </message>
    <message>
        <source>Heading 6</source>
        <translation>Naslov 6</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Postavke</translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation>Postavke linka</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Izreži</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiraj</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Zalijepi</translation>
    </message>
    <message>
        <source>Merge Cells</source>
        <translation>Spoji ćelije</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Označi sve</translation>
    </message>
    <message>
        <source>Split Cell</source>
        <translation>Podijeli ćeliju</translation>
    </message>
    <message>
        <source>Selected image type is not an anchor</source>
        <translation>Odabrana vrsta slike nije anchor</translation>
    </message>
    <message>
        <source>Class: </source>
        <translation>Klasa:</translation>
    </message>
    <message>
        <source>Class: [none]</source>
        <translation>Klasa: [nijedna]</translation>
    </message>
    <message>
        <source>Make link</source>
        <translation>Napravi link</translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>Separator</translation>
    </message>
    <message>
        <source>Problem to insert special character</source>
        <translation>Problem pri ubacivanju specijalnog znaka</translation>
    </message>
    <message>
        <source>Problem to insert class attribute</source>
        <translation>Problem pri ubacivanju css klase</translation>
    </message>
    <message>
        <source>Merge cells is not possible</source>
        <translation>Spajanje ćelija nije moguće</translation>
    </message>
    <message>
        <source>Split cell is not possible</source>
        <translation>Dijeljenje ćelije nije moguće</translation>
    </message>
    <message>
        <source>Delete column is not possible</source>
        <translation>Brisanje stupca nije moguće</translation>
    </message>
    <message>
        <source>Delete row is not possible</source>
        <translation>Brisanje retka nije moguće</translation>
    </message>
    <message>
        <source>Insert row is not possible</source>
        <translation>Ubacivanje retka nije moguće</translation>
    </message>
    <message>
        <source>Problem to insert a table</source>
        <translation>Problem pri ubacivanju tablice</translation>
    </message>
    <message>
        <source>Problem to insert literal</source>
        <translation>Problem pri ubacivanju literal taga</translation>
    </message>
    <message>
        <source>Selection is not a literal tag</source>
        <translation>Selektirano nije literal tag</translation>
    </message>
    <message>
        <source>Problem to insert an inline custom tag</source>
        <translation>Problem pri ubacivanju prilagođenog taga</translation>
    </message>
    <message>
        <source>Selected image type is not a custom tag</source>
        <translation>Odabran tip slike nije prilagođeni tag</translation>
    </message>
    <message>
        <source>Selected table type is not a custom tag</source>
        <translation>Odabran tip tablice nije prilagođeni tag</translation>
    </message>
    <message>
        <source>Problem to insert an object</source>
        <translation>Problem pri ubacivanju objekta</translation>
    </message>
    <message>
        <source>Problem to insert an anchor</source>
        <translation>Problem pri ubacivanju anchora</translation>
    </message>
    <message>
        <source>Problem to add a link</source>
        <translation>Problem pri dodavanju linka</translation>
    </message>
    <message>
        <source>Table Properties</source>
        <translation>Postavke tablice</translation>
    </message>
    <message>
        <source>Change To TH</source>
        <translation>Promijeni u TH</translation>
    </message>
    <message>
        <source>Change To TD</source>
        <translation>Promijeni u TD</translation>
    </message>
    <message>
        <source>Headings are not allowed inside a list.</source>
        <translation>Naslove nije moguće ubacivati unutar liste.</translation>
    </message>
    <message>
        <source>Error: The number of rows is required and has to be at least 1!</source>
        <translation>Pogreška: Treba unijeti broj redaka i mora biti barem 1!</translation>
    </message>
    <message>
        <source>Error: The number of columns is required and has to be at least 1!</source>
        <translation>Pogreška: Treba unijeti broj stupaca i mora biti barem 1!</translation>
    </message>
    <message>
        <source>Choose node</source>
        <translation>Odaberi čvor</translation>
    </message>
    <message>
        <source>Select a node and click the %buttonname button.
    Using bookmark items for quick selection is also possible.
    Click on node names to change the browse listing.</source>
        <translation>Odaberi čvor i klini na %buttonname
(sp)(sp)(sp)(sp)Također je moguće je koristiti knjižne oznake za brzi odabir
(sp)(sp)(sp)(sp)Klikni na naziv čvora za promjenu prikaza liste.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Choose object</source>
        <translation>Odaberi čvor</translation>
    </message>
    <message>
        <source>Select an object and click the %buttonname button.
    Click on object names to change the browse listing.
    Using bookmark items for quick selection is also possible.</source>
        <translation>Odaberi objekt i klikni na %buttonname.
(sp)(sp)(sp)(sp)Klikni na naziv objekta za izmjenu prikaza liste.
(sp)(sp)(sp)(sp)Također je moguće koristiti knjižne oznake za brzi odabir.</translation>
    </message>
    <message>
        <source>Choose objects</source>
        <translation>Odaberi objekte</translation>
    </message>
    <message>
        <source>Use the checkboxes to choose the objects that you wish to relate to
    and click the %buttonname button. Click on object names to change the browse listing.
    Using bookmark items for quick selection is also possible.</source>
        <translation>Koristi se checkboxem za odabir objekata koje želiš povezati
(sp)(sp)(sp)(sp)i klikni na %buttonname. Klikni na naziv objekta za izmjenu prikaza liste.
(sp)(sp)(sp)(sp)Također je moguće koristiti knjižne oznake za brzi odabir.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Select from available classes</source>
        <translation>Odaberi među ponuđenim klasama</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>none</source>
        <translation>nijedna</translation>
    </message>
    <message>
        <source>Select from available custom tags</source>
        <translation>Odaberi među ponuđenim prilagođenim tagovima</translation>
    </message>
    <message>
        <source>Custom tag</source>
        <translation>Prilagođeni tag</translation>
    </message>
    <message>
        <source>Inline</source>
        <translation>Inline</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Attribute name</source>
        <translation>Naziv atributa</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Vrijednost</translation>
    </message>
    <message>
        <source>There are no attributes defined</source>
        <translation>Nema definiranih atributa</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Ukloni odabrano</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Novi atribut</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <source>other</source>
        <translation>ostalo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Browse</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Open in new window</source>
        <translation>Otvaranje u novom prozoru</translation>
    </message>
    <message>
        <source>Title ( optional )</source>
        <translation>Naslov ( neobavezno )</translation>
    </message>
    <message>
        <source>ID ( optional )</source>
        <translation>ID ( neobavezno )</translation>
    </message>
    <message>
        <source>Upload local file</source>
        <translation>Prebacivanje lokalne datoteke (Upload)</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lokacija</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatski</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Datoteka</translation>
    </message>
    <message>
        <source>Upload is in progress, it may take a few seconds ...</source>
        <translation>Datoteka se prebacuje, to može potrajati nekoliko trenutaka...</translation>
    </message>
    <message>
        <source>Select from related objects or upload local files</source>
        <translation>Odaberi među povezanim objektima ili prebaci lokalnu datoteku</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Povezani objekti</translation>
    </message>
    <message>
        <source>Related images</source>
        <translation>Povezane slike</translation>
    </message>
    <message>
        <source>Related files</source>
        <translation>Povezane datoteke</translation>
    </message>
    <message>
        <source>Related content</source>
        <translation>Povezani sadržaj</translation>
    </message>
    <message>
        <source>There are no related objects.</source>
        <translation>Nema povezanih objekata.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Novo prebacivanje (upload)</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Dodaj postojeću</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centirano</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Lijevo</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Desno</translation>
    </message>
    <message>
        <source>Rows</source>
        <translation>Retci</translation>
    </message>
    <message>
        <source>Columns</source>
        <translation>Stupci</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Rub</translation>
    </message>
    <message>
        <source>Edit Cell properties</source>
        <translation>Promijeni postavke ćelije</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Širina</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Primijeni na</translation>
    </message>
    <message>
        <source>Cell</source>
        <translation>Ćelija</translation>
    </message>
    <message>
        <source>Row</source>
        <translation>Redak</translation>
    </message>
    <message>
        <source>Column</source>
        <translation>Stupac</translation>
    </message>
    <message>
        <source>Cell Properties</source>
        <translation>Postavke ćelije</translation>
    </message>
    <message>
        <source>No classes are available for the element: </source>
        <translation>Nema raspoloživih klasa za element:</translation>
    </message>
    <message>
        <source>Remove link</source>
        <translation>Ukloni link</translation>
    </message>
    <message>
        <source>Merge down</source>
        <translation>Spoji prema dolje</translation>
    </message>
    <message>
        <source>Custom tag properties</source>
        <translation>Postavke prilagođenog taga</translation>
    </message>
    <message>
        <source>Link properties</source>
        <translation>Postavke linka</translation>
    </message>
</context>
<context>
    <name>design/standard/ezdhtml/help</name>
    <message>
        <source>Online editor help</source>
        <translation>Pomoć za Online editor</translation>
    </message>
    <message>
        <source>Using the toolbar</source>
        <translation>Korištenje alatne trake</translation>
    </message>
    <message>
        <source>Undo the last operation in the editor. To undo more than one operation, keep clicking the button.</source>
        <translation>Poništavanje zadnje operacije u editoru. Za poništavanje više operacija, kliknite na gumb uzastopno više puta.</translation>
    </message>
    <message>
        <source>Reverse the &quot;Undo&quot; command.</source>
        <translation>Obrnuta &quot;Poništi&quot; naredba.</translation>
    </message>
    <message>
        <source>Make the selected text &lt;b&gt;bold&lt;/b&gt;. If the selected text is &lt;b&gt;bold&lt;/b&gt; already, this button will remove the formating.</source>
        <translation>&lt;b&gt;Podebljavanje&lt;/b&gt; odabranog teksta. Ukoliko je odabrani tekst već &lt;b&gt;podebljan&lt;/b&gt;, tada uklanja ovo formatiranje.</translation>
    </message>
    <message>
        <source>Make the selected text &lt;i&gt;italic&lt;/i&gt;. If the selected text is &lt;i&gt;italic&lt;/i&gt; already, this button will remove the formating.</source>
        <translation>&lt;i&gt;Ukošavanje&lt;/i&gt; odabranog teksta. Ukoliko je odabrani tekst već &lt;i&gt;ukošen&lt;/i&gt;, tada uklanja ovo formatiranje.</translation>
    </message>
    <message>
        <source>Decrease list indent. Use this button to change the level of a list item in a nested list.</source>
        <translation>Smanjenje uvučenosti liste. Koristite ovaj gumb da bi promijenili razinu člana liste u ugnježđenoj listi.</translation>
    </message>
    <message>
        <source>Increase list indent. Use this button to change the level of a list item in a nested list.</source>
        <translation>Povećanje uvučenosti liste. Koristite ovaj gumb za promjenu razine člana liste u ugnježđenoj listi.</translation>
    </message>
    <message>
        <source>Create a hyperlink. You can select text first and then click this button to make the text a link. If the checkbox &quot;Open in new window&quot; is checked, the link will be displayed in a new browser window.</source>
        <translation>Ubacivanje hiperlinka. Prvo odaberite tekst i onda kliknite na ovaj gumb za unos linka. Ukoliko je označeno &quot;Otvaranje u novom prozoru&quot;, tada će se link otvoriti u novom prozoru internet preglednika.</translation>
    </message>
    <message>
        <source>Insert literal text. Click the &quot;Insert literal&quot; button to insert a single column and single row table with purple background into the editor field. Text written in this field will be rendered literally in the final output.</source>
        <translation>Ubacivanje literal teksta. Kliknite na gumb &quot;Ubaci literal&quot; za ubacivanje ljubičastog polja (tablice) unutar editora. Uneseni tekst  unutar tog polja bit će prikazan sa literal svojstvom pri krajnjem prikazu.</translation>
    </message>
    <message>
        <source>Insert a special character. Click the button to open the special character window. Click on a character to insert it.</source>
        <translation>Ubacivanje specijalnog znaka. Kliknite na gumb za otvaranje prozora sa specijalnim znakovima a zatim na željeni znak kojeg želite ubaciti u editor.</translation>
    </message>
    <message>
        <source>Insert a table at the selected position. Tables with their border set to 0 are displayed with a red border color in the editor.</source>
        <translation>Ubacivanje tablice na odabranu poziciju. Tablice čija je debljina ruba namještena na 0 će biti prikazane sa crvenim obrubom.</translation>
    </message>
    <message>
        <source>Open the search window.</source>
        <translation>Otvori prozor za pretragu.</translation>
    </message>
    <message>
        <source>Open the help window.</source>
        <translation>Otvori prozor za pomoć.</translation>
    </message>
    <message>
        <source>Using the context menu</source>
        <translation>Korištenje kontekstnog izbornika</translation>
    </message>
    <message>
        <source>Right click using the mouse and choose one of the insert commands from context menu.</source>
        <translation>Kliknite na desnu tipku miša i odaberite jednu od naredbi za ubacivanje iz kontekstnog izbornika.</translation>
    </message>
    <message>
        <source>Edit table</source>
        <translation>Namještanje tablice</translation>
    </message>
    <message>
        <source>Edit link</source>
        <translation>Ažuriranje linka</translation>
    </message>
    <message>
        <source>Edit the class attribute of the tags header, paragraph, bold, italic, ol, ul</source>
        <translation>Primjena css klase na tagovima header, paragraph, bold, italic, ol, ul</translation>
    </message>
    <message>
        <source>Tips</source>
        <translation>Korisne crtice</translation>
    </message>
    <message>
        <source>The status bar will show the current tag name, all its parent tags and class information of the tag.</source>
        <translation>Statusna linija će prikazati trenutni naziv taga, sve tagove povrh trenutnog te informacije o css klasi koja je primjenjena na tag.</translation>
    </message>
    <message>
        <source>You can change the looks of the editor by editing editor.css in the extension/ezdhtml/design/standard/stylesheets/ezdhtml/ directory.</source>
        <translation>Moguće je mijenjati način prikaza editora mijenjajući editor.css unutar extension/ezdhtml/design/standard/stylesheets/ezdhtml/ direktorija.</translation>
    </message>
    <message>
        <source>You can edit wordmatch.ini under directory extension/ezdhtml/settings/ to make text copied from MS Word directly assigned to a desired class.</source>
        <translation>Moguće je namjestiti wordmatch.ini u direktoriju extension/ezdhtml/settings/ za omogućavanje automatske aplikacije css klasa na tekst koji je kopiran iz MS Worda.</translation>
    </message>
    <message>
        <source>Close Window</source>
        <translation>Zatvaranje prozora</translation>
    </message>
    <message>
        <source>Insert object, link, anchor, literal, custom tag, table</source>
        <translation>Ubacivanje objekta, linka, anchora, literala, prilagođenog taga, tablice</translation>
    </message>
    <message>
        <source>Create a numbered list. To create a new list item, press &quot;Enter&quot;. To end a list, press &quot;Enter&quot; key on an empty list item. If you click this button when the cursor is on a list item, the formatting will be removed.</source>
        <translation>Ubacivanje pobrojane liste. Za dodavanje novog elementa liste, pritisnite &quot;Enter&quot;. Za kraj liste pritisnite &quot;Enter&quot; u praznom elementu liste. Ukoliko kliknete na ovaj gumb kada se pokazivač nalazi unutar elementa liste, formatiranje će biti uklonjeno.</translation>
    </message>
    <message>
        <source>Create a bullet list. To create a new list item, press &quot;Enter&quot;. To end a list, press &quot;Enter&quot; key on an empty list item. If you click this button when the cursor is on a list item, the formatting will be removed.</source>
        <translation>Ubacivanje liste s točkama. Za dodavanje novog elementa liste, pritisnite &quot;Enter&quot;. Za kraj liste pritisnite &quot;Enter&quot; u praznom elementu liste. Ukoliko kliknete na ovaj gumb kada se pokazivač nalazi unutar elementa liste, formatiranje će biti uklonjeno.</translation>
    </message>
    <message>
        <source>Insert an image or any other object from the related objects list. For images you can specify size and/or alignment. You can add custom attributes by clicking the &quot;New attribute&quot; button. To upload local images/files, click &quot;Upload new&quot; button. In the upload local file window, choose the local file, specify the name of the new object, choose placement from list and then click &quot;Upload&quot; button. Note that embedded object will begin on a new line when displayed in the resulting XHTML.</source>
        <translation>Ubacivanje slike ili bilo kojeg drugog objekta iz liste povezanih objekata. Kod slike je moguće namjestiti željenu veličinu i poravnanje. Moguće je dodati vlastite atribute klikom na gumb &quot;Novi atribut&quot;. Za prebacivanje lokalne slike/dokumenta kliknite na &quot;Novo prebacivanje (upload)&quot;. U prozoru za prebacivanje datoteke odaberite lokalnu datoteku, unesite naziv novog objekta, odaberite lokaciju za smještaj novog objekta i kliknite na &quot;Upload&quot;. Napomena: embedded objekt će započeti sa prikazom u novoj liniji u rezultirajućem XHTML kodu.</translation>
    </message>
    <message>
        <source>Create an anchor. An anchor-like icon will appear in the editor.</source>
        <translation>Unos anchora. Anchor ikona će se prikazati u editoru.</translation>
    </message>
    <message>
        <source>Create a custom tag. Click the button to open the insert custom tag window with a list of available custom tags. Select the name of the custom tag you want to insert, write the tag contents in the textfield &quot;Text&quot; and click the &quot;OK&quot; button. You can add custom attributes by clicking the &quot;InsertAttribute&quot; button. Block custom tags are inserted as a single row and single column table. &quot;Text&quot; field is inactive for block custom tags. You can write text inside the table.</source>
        <translation>Unos prilagođenog taga. Kliknite na gumb za otvaranje prozora sa listom prilagođenih tagova. Odaberite naziv prilagođenog taga kojeg želite ubaciti, unesite sadržaj taga unutar polja za tekst i odaberite &quot;OK&quot;. Ubacivanje korisničkih atributa se vrši klikom na gumb &quot;&quot;InsertAttribute&quot;. Blok prilagođeni tagovi su ubačeni kao tablica sa jednim retkom i stupcem. Polje &quot;Tekst&quot; je neaktivno za block prilagođene tagove. Tekst možete unositi unutar tablice.</translation>
    </message>
    <message>
        <source>Insert a row above the current row.</source>
        <translation>Ubacivanje retka povrh trenutnog retka.</translation>
    </message>
    <message>
        <source>Insert a column to the left of the current cell.</source>
        <translation>Ubacivanje stupca lijevo od trenutnog retka.</translation>
    </message>
    <message>
        <source>Delete the current row.</source>
        <translation>Brisanje trenutnog retka.</translation>
    </message>
    <message>
        <source>Delete the current column.</source>
        <translation>Brisanje trenutnog stupca.</translation>
    </message>
    <message>
        <source>Split the current cell into two cells.</source>
        <translation>Dijeljenje trenutne ćelije u dvije ćelije.</translation>
    </message>
    <message>
        <source>Merge the selected cells in the same row (adding the attribute &quot;rowspan&quot; to the table cell). To merge cells in different rows (adding the attribute &quot;colspan&quot; to the table cell), right click the table cell and choose the command &quot;Merge down&quot;.</source>
        <translation>Spajanje odabrane ćelije u isti redak (dodavanjem atributa &quot;rowspan&quot; ćeliji tablice). Za spajanje ćelija iz različitih redaka (dodavanje atributa &quot;colspan&quot; ćeliji tablice), kliknite desnom tipkom na ćeliju tablice i odaberite naredbu &quot;Spoji prema dolje&quot;.</translation>
    </message>
    <message>
        <source>Move the pointer to a table cell, right click it and choose a command from the context menu. You can insert rows, insert columns,
delete rows, delete columns, split cells or insert objects, tables, links, anchors, custom tags and literal tags.
To set a table cell as the table header, choose &quot;TH&quot; from the context menu. To merge cells in different rows choose the command &quot;Merge down&quot;.
To edit table properties, choose &quot;Table Properties&quot;. To edit table cell properties, choose &quot;Cell Properties&quot;. A window will pop up where you can set cell width and cell class. You can set width and class either for the current cell, for all the cells in the current row or for all the cells in the current column by choosing Cell, Row, Column, respectively using the radiobuttons.</source>
        <translation>Pomaknite pokazivač miša na ćeliju tablice, kliknite desnom tipkom miša i odaberite naredbu iz kontekstnog izbornika. Možete ubacivati retke, ubacivati stupce,
brisati retke, brisati stupce, dijeliti ćelije ili ubacivati objekte, tablice, anchore, prilagođene tagove i literal tagove.
Za postavljanje ćelije tablice kao naslova tablice, odaberite &quot;TH&quot; iz kontekstnog izbornika. Za spajanje ćelija iz različitih redaka odaberite naredbu &quot;Spoji prema dolje&quot;.
Za namještanje postavki tablice, odaberite &quot;Postavke tablice&quot;. Za namještanje postavki ćelije tablice, odaberite &quot;Postavke ćelije&quot;. Prikazat će se prozor gdje je moguće namještati širinu i dužinu tablice te css klasu. Širina i visina se može namještati za trenutnu ćeliju, ali i za trenutni redak ili stupac, ovisno o tome je li uz pomoć radiobuttona odabrana ćelija, redak ili stupac.</translation>
    </message>
    <message>
        <source>Edit the properties of object, anchor, custom tag</source>
        <translation>Namještanje postavki objekta, anchora i prilagođenog taga</translation>
    </message>
    <message>
        <source>Right click the object and choose &quot;Properties&quot; from the context menu, the object properties window will pop up. Edit properties of the object and click &quot;OK&quot;. If no changes need to be done, simply click the &quot;Cancel&quot; button.</source>
        <translation>Kliknite desnom tipkom miša na objekt, odaberite &quot;Postavke&quot; iz kontekstnog izbornika nakon čega će se prikazati prozor s postavkama objekta. Ažurirajte postavke objekta i kliknite na &quot;OK&quot;. Ukoliko nije potrebno mijenjati postavke, odaberite &quot;Odustani&quot;.</translation>
    </message>
    <message>
        <source>Move the pointer to the link text and right click it. Select &quot;Link properties&quot; from the context menu if you want
to edit link properties. Select &quot;Remove Link&quot; if you just want to remove the link.</source>
        <translation>Pomaknite strelicu miša povrh linka i kliknite desnom tipkom. Odaberite &quot;Postavke linka&quot; iz kontekstnog izbornika ukoliko želite
ažurirati link. Odaberite &quot;Ukloni link&quot; ukoliko samo želite ukloniti link.</translation>
    </message>
    <message>
        <source>Move the pointer to the text and right click it. Do not make any text selection before right clicking. Choose the command &quot;Properties&quot; from the context menu. A window will pop up where you can assign a class to this tag (You need to define available classes for this tag in content.ini).</source>
        <translation>Pomaknite pokazivač miša na tekst i kliknite desnom tipkom. Ne označavajte tekst prije toga. Odaberite naredbu &quot;Postavke&quot; iz kontekstnog izbornika. Otvorit će se pop up prozor gdje je moguće primijeniti css klasu na ovaj tag (za korištenje ove opcije potrebno je predefinirati dozvoljene css klase u content.ini datoteci).</translation>
    </message>
    <message>
        <source>You can create a new line by holding the Shift key down and type Enter.</source>
        <translation>Za odlazak u novi red teksta pritisnite tipku Shift i onda tipku Enter.</translation>
    </message>
    <message>
        <source>You can create a new paragraph by pressing the Enter key.</source>
        <translation>Pritiskom na tipku Enter stvara se novi paragraf u tekstu. </translation>
    </message>
    <message>
        <source>You can make an image-link by selecting the image first and then either clicking the link button in the toolbar or choosing command &quot;Insert Link&quot; from context menu.</source>
        <translation>Za unos linka na slici prvo odaberite mišem sliku, zatim kliknite na gumb link u alatnoj traci ili odaberite naredbu &quot;Ubaci link&quot; iz kontekstnog izbornika.</translation>
    </message>
    <message>
        <source>Merge the selected cells into one cell. The cells must be empty.</source>
        <translation>Spajanje označenih ćelija tablice u jednu. Ćelije moraju biti prazne.</translation>
    </message>
    <message>
        <source>Move the pointer to a table cell, right click it and choose a command from the context menu. You can insert rows, insert columns,
delete rows, delete columns, split cells or insert objects, tables, links, anchors, custom tags and literal tags.
To set a table cell as the table header, choose &quot;Change to TH&quot; from the context menu.
To edit table properties, choose &quot;Table Properties&quot;. To edit table cell properties, choose &quot;Cell Properties&quot;. A window will pop up where you can set cell width and cell class. You can set width and class either for the current cell, for all the cells in the current row or for all the cells in the current column by choosing Cell, Row, Column, respectively using the radiobuttons.</source>
        <translation>Pomaknite pokazivač miša na ćeliju tablice, kliknite desnom tipkom miša i odaberite naredbu iz kontekstnog izbornika. Moguće je ubacivati retke, ubacivati stupce,
brisati retke, brisati stupce, dijeliti ćelije ili ubacivati objekte, tablice, anchore, prilagođene tagove i literal tagove.
Za postavljanje ćelije tablice kao naslova tablice, odaberite &quot;Promijeni u TH&quot; iz kontekstnog izbornika.
Za namještanje postavki tablice, odaberite &quot;Postavke tablice&quot;. Za namještanje postavki ćelije tablice, odaberite &quot;Postavke ćelije&quot;. Prikazat će se prozor u kojem je moguće namještati širinu i dužinu tablice te css klasu. Širina i visina se može namještati za trenutnu ćeliju, ali i za trenutni redak ili stupac, ovisno o tome je li odabrana ćelija, redak ili stupac.</translation>
    </message>
</context>
<context>
    <name>handlers/input</name>
    <message>
        <source>&apos;%1&apos; is not allowed to be a child of &apos;%2&apos;.</source>
        <translation>&apos;%1&apos; se ne može nalaziti ispod &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Node %1 does not exist.</source>
        <translation>Čvor %1 ne postoji.</translation>
    </message>
    <message>
        <source>Node &apos;%1&apos; does not exist.</source>
        <translation>Čvor &apos;%1&apos; ne postoji.</translation>
    </message>
    <message>
        <source>Wrong closing tag : &amp;lt;/%1&amp;gt;, ignoring.</source>
        <translation>Krivi završni tag : &amp;lt;/%1&amp;gt;, zanemareno.</translation>
    </message>
    <message>
        <source>Unknown tag: &amp;lt;%1&amp;gt;, ignoring.</source>
        <translation>Nepoznati tag:  : &amp;lt;/%1&amp;gt;, zanemareno.</translation>
    </message>
    <message>
        <source>Can&apos;t convert tag&apos;s name: &amp;lt;%1&amp;gt;, ignoring.</source>
        <translation>Nije moguće konvertirati naziv taga: &amp;lt;%1&amp;gt;, zanemareno.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Content required</source>
        <translation>Potrebno je unijeti sadržaj</translation>
    </message>
</context>
</TS>
