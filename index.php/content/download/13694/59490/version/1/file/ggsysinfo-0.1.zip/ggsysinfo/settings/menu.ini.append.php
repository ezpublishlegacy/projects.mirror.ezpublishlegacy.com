<?php /*

[NavigationPart]
Part[ezsysinfonavigationpart]=System Information

[TopAdminMenu]
Tabs[]=ggsysinfo

[Topmenu_ggsysinfo]
Name=System Information
Tooltip=Display detailed system information
URL[default]=sysinfo/php
NavigationPartIdentifier=ezsysinfonavigationpart

Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false

Shown[]
Shown[default]=true
Shown[browse]=false
Enabled[edit]=true
Shown[navigation]=true

*/ ?>