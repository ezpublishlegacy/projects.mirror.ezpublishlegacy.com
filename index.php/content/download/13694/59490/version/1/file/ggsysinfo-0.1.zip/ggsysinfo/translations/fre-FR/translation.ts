﻿<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>System Information</source>
		<comment>Navigation part</comment>
        <translation>Informations Système</translation>
    </message>
</context>
<context>
    <name>SysInfo</name>
    <message>
        <source>Cache search</source>
        <translation>Recherche dans le cache</translation>
    </message>
</context>
</TS>
