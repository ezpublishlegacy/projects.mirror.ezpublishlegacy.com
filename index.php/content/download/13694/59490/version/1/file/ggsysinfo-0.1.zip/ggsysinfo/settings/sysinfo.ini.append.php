<?php /*

[SystemStatus]
# List of http pages to be GETted for testing if the server has web access
WebBeacons[]
WebBeacons[]=http://www.google.com
#WebBeacons[]=http://www.yahoo.com
#WebBeacons[]=http://www.microsoft.com

# Email address that will be mailed a test message to check connectivity to mail server
MailReceiver=

*/?>