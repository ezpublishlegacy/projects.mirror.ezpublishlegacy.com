<?php /* 

[CronjobSettings]
ExtensionDirectories[]=ggsysinfo

*/ ?>
