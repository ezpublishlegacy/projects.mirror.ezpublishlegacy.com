<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=enhanced_admin

[JavaScriptSettings]
JavaScriptList[]=mootools.js
JavaScriptList[]=enhanced_admin.js

[StylesheetSettings]
CSSFileList[]=enhanced_admin.css

*/ ?>
