var classeZSH =
[
    [ "modify", "classeZSH.html#a32ee29053b945560f4ba9ad8aa170e86", null ],
    [ "namedParameterList", "classeZSH.html#a725b4a2690408e705316e723c7f3fd36", null ],
    [ "namedParameterPerOperator", "classeZSH.html#abdca99019748c259abf9cc8b4bd2d2a3", null ],
    [ "operatorList", "classeZSH.html#a099d7ff03edc4ffa088247d60f91fc60", null ]
];