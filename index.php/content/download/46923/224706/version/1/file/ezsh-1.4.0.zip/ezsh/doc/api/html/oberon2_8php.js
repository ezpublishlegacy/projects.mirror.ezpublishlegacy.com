var oberon2_8php =
[
    [ "$language_data", "oberon2_8php.html#a3f855a7e0ebc0899119af33dbb70d890", null ]
];