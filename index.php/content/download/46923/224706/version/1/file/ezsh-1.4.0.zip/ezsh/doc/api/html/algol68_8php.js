var algol68_8php =
[
    [ "$a68", "algol68_8php.html#a8d70f41a5b651b89b19f6eb0e581f745", null ],
    [ "$language_data", "algol68_8php.html#a3f855a7e0ebc0899119af33dbb70d890", null ]
];