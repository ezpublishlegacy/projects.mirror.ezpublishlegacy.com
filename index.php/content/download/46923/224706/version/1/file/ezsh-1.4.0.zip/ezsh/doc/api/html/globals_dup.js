var globals_dup =
[
    [ "$", "globals.html", null ],
    [ "g", "globals_0x67.html", null ]
];