var namespaces =
[
    [ "geshi", "namespacegeshi.html", null ]
];