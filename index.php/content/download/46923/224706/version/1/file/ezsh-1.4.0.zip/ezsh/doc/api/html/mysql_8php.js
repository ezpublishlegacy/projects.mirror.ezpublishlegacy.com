var mysql_8php =
[
    [ "$language_data", "mysql_8php.html#a3f855a7e0ebc0899119af33dbb70d890", null ]
];