var dirs =
[
    [ "autoloads", "dir_1f8947a81f0b57e3673e75b53f3e6b78.html", null ],
    [ "bin", "dir_8c5ac930458fdaf96cda8168a81bf5d4.html", "dir_8c5ac930458fdaf96cda8168a81bf5d4" ],
    [ "lib", "dir_13048dfe8345e335ef75a55f98e8ae8d.html", "dir_13048dfe8345e335ef75a55f98e8ae8d" ],
    [ "modules", "dir_3e7a17e4c4bf21db39fa42dbe59c4b47.html", "dir_3e7a17e4c4bf21db39fa42dbe59c4b47" ]
];