var globals_vars =
[
    [ "$", "globals_vars.html", null ]
];