var highlight_8php =
[
    [ "$errormsg", "highlight_8php.html#aafc8069b2e674572f7bdf45ec6b6bd57", null ],
    [ "$ezpath", "highlight_8php.html#a497510168b777167c953d8742126229e", null ],
    [ "$filename", "highlight_8php.html#a0722441477f957078ee2437054556cbc", null ],
    [ "$filepath", "highlight_8php.html#a5c29a1cb10c4fc0034298e423dd13924", null ],
    [ "$highlighted", "highlight_8php.html#ae16545f47147827d26e0701e0586b98f", null ],
    [ "$ini", "highlight_8php.html#a8f5f30fbe4092bf20ba2fcae8197ab09", null ],
    [ "$language", "highlight_8php.html#a83170d318260a5a2e2a79dccdd371b10", null ],
    [ "$Module", "highlight_8php.html#a643d60fb839b5d58f0725a88d0ecd1a0", null ],
    [ "$orig_filename", "highlight_8php.html#a92fe3b3d3849483463a22817d10058ea", null ],
    [ "$Result", "highlight_8php.html#a390d5702f3c15330fd764dbf08d5b2db", null ],
    [ "$Result", "highlight_8php.html#a0d32c70e3cf8c7b3fe5e4a499e9cd58f", null ],
    [ "$Result", "highlight_8php.html#a94a2cc5784adee982dec0235638f6251", null ],
    [ "$tpl", "highlight_8php.html#a04b1944cdb09f9a4e290cde7a12499e6", null ],
    [ "$user", "highlight_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ]
];