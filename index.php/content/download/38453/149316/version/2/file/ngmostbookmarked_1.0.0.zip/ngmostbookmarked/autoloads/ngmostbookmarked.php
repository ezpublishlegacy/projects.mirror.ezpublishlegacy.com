<?php

class BookmarkFetch
{
   /*!
    Constructor
   */
   function BookmarkFetch()
   {
       $this->Operators = array('most_bookmarked');
   }

   /*!
    Returns the operators in this class.
   */
   function &operatorList()
   {
       return $this->Operators;
   }
 
   /*!
    \return true to tell the template engine that the parameter list
   exists per operator type, this is needed for operator classes
   that have multiple operators.
   */
   function namedParameterPerOperator()
   {
       return true;
   }

   /*!
    The first operator has two parameters, the other has none.
    See eZTemplateOperator::namedParameterList()
   */

   function namedParameterList()
   {
       return array( 'most_bookmarked' => array( 'results_limit' => array( 'type' => 'string',
                                                                'required' => false,
                                                                'default' => '5' ),
                                            'last_bookmarks_limit' => array( 'type' => 'string',
                                                                'required' => false,
                                                                'default' => '300' ) )
	   );
   }

   /*!
    Executes the needed operator(s).
    Checks operator names, and calls the appropriate functions.
   */
   function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                    &$currentNamespace, &$operatorValue, &$namedParameters )
   {
       switch ( $operatorName )
       {
		   case 'most_bookmarked':
           {
               $operatorValue = $this->most_bookmarked( $namedParameters['results_limit'],
                                                   $namedParameters['last_bookmarks_limit'] );
           } break;
       }
   }

   function most_bookmarked( $args )
   {
		include_once( 'lib/ezdb/classes/ezdb.php' );

		$db =& eZDB::instance();

		$rows = $db->arrayQuery( "SELECT count(*) as cnt,node_id FROM (select * from ezcontentbrowsebookmark order by id desc limit 0,". $args['last_bookmarks_limit'] .") as freshbookmarks group by node_id order by cnt desc limit 0,". $args['results_limit'] );

		$nodes = false;
		include_once( 'kernel/classes/ezcontentobject.php' );
		foreach ( $rows as $row )
		{
			$nodes[] = eZContentObjectTreeNode::fetch( $row['node_id'] );
		}
		return $nodes;
   }

   /// \privatesection
   var $Operators;
}

?>