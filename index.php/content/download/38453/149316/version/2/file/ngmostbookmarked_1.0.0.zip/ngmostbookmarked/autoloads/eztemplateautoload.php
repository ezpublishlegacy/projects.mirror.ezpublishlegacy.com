<?php
// Operator autoloading
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
 array( 'script' => 'extension/ngmostbookmarked/autoloads/ngmostbookmarked.php',
        'class' => 'BookmarkFetch',
        'operator_names' => array('most_bookmarked' ) );

?>