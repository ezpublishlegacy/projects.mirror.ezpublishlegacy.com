ngmostbookmarked extension readme for eZ Publish

Version: 1.0.0


What is the ngmostbookmarked extension?
=======================================

ngmostbookmarked extension provides an template operator (most_bookmarked) which can be used to fetch most bookmarked nodes.

results_limit attribute limits the number of returned results, last_bookmarks_limit limits how many most recently added bookmarks will be used to determine top list.


{def $mostbookmarked = most_bookmarked( hash(results_limit, 6, last_bookmarks_limit, 250 ))}

{section var=Bookmarks loop=$mostbookmarked}
	{node_view_gui view=listitem categories content_node=$Bookmarks}
{/section}





Credits:

Netgen d.o.o. http://www.netgen.hr