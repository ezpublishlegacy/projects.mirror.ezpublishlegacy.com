<?php

/**
 * Global wrapper class for the PHPIDS-library
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIds
{

    /**
     * Virtual class properties
     *
     * @access protected
     * @var array( string => mixed )
     */
    protected $properties = array(
        'Config'       => null,
        'Interceptor'  => null,
        'IdsObject'    => null,
        'IdsReport'    => null,
        'InitObject'   => null,
        'libVersion'   => '',
        'libPath'      => '',
        'tmpPath'      => '',
        'initComplete' => false
    );

    /**
     * Virtual property isset access
     *
     * Isset is true for all properties that exist, although they maybe null.
     *
     * @access public
     * @param string $propertyName Name of the property to retrieve a value for
     * @return bool
     */
    public function __isset( $propertyName )
    {
        return array_key_exists( $propertyName, $this->properties );
    }

    /**
     * Virtual property read access
     *
     * Reading is allowed for all properties.
     *
     * @access public
     * @param string $propertyName Name of the property to retrieve a value for
     * @return mixed Property value
     * @throws phpIdsPropertyNotFoundException if given $propertyName could
     * not be found in $this->properties
     */
    public function __get( $propertyName )
    {
        if ( isset( $this->$propertyName ) )
        {
            return $this->properties[$propertyName];
        }
        throw new phpIdsPropertyNotFoundException( $propertyName );
    }

    /**
     * Virtual property write access
     *
     * Properties contained in array $restrictedProperties will not allow write access.
     *
     * @access public
     * @param string $propertyName Name of the property to retrieve a value for
     * @param mixed $propertyValue Value to set for the property
     * @throws phpIdsPropertyNotFoundException If given $propertyName could
     * not be found in $this->properties
     * @throws phpIdsPropertyPermissionException If you try to set protected properties
     */
    public function __set( $propertyName, $propertyValue )
    {
        if ( isset( $this->$propertyName ) )
        {
            $restrictedProperties = array(
                'Interceptor'
            );
            if ( in_array( $propertyName, $restrictedProperties ) )
            {
                throw new phpIdsPropertyPermissionException( $propertyName );
            }
            else
            {
                $this->properties[$propertyName] = $propertyValue;
            }
        }
        else
        {
            throw new phpIdsPropertyNotFoundException( $propertyName );
        }
    }

    /**
     * Constructor for this class
     *
     * @access public
     * @return object phpIds
     */
    public function __construct()
    {
        // Initialize intrusion detection object;
        $this->init();
    }

    /**
     * Initialization method for this class, called by constructor on tear up
     *
     * @access private
     * @return void
     * @throws phpIdsException
     */
    private function init()
    {
        try
        {
            $this->properties['Interceptor'] = new phpIdsInterceptor();

            $this->Config = eZINI::instance( 'phpids.ini' );
            $libVersion   = $this->Config->variable( 'PHPIDS', 'Version' );

            // Try to retrieve current library version and compose installation path
            if ( isset( $libVersion ) and !empty( $libVersion ) )
            {
                $this->libVersion = $libVersion;
                $libPath          = eZSys::siteDir() . 'extension/phpids/lib/phpids/{VERSION}/lib/';
                $this->libPath    = str_replace( '{VERSION}', $libVersion, $libPath );
                $this->tmpPath    = eZSys::cacheDirectory() . '/phpids/';
            }
            else
            {
                throw new phpIdsException( 'No version for library PHPIDS configured!' );
            }

            // Check if we can find the config file of the configured library
            if ( !is_file( $this->libPath . 'IDS/Config/Config.ini.php' ) )
            {
                throw new phpIdsException( 'Library PHPIDS not found!' );
            }

            // Create tempdir if not available
            if ( !is_dir( $this->tmpPath ) ) mkdir( $this->tmpPath );
            if ( !is_writable( $this->tmpPath ) )
            {
                throw new phpIdsException( "Directory $this->tmpPath is not writable!" );
            }

            // Add library installation path as a global include path;
            // Frickin' ugly as this is not neccessary when using autoloads;
            // still it's the way to go if we don't want to patch PHPIDS itself...
            // @todo Remove as soon as possible!
            set_include_path( get_include_path() . PATH_SEPARATOR . $this->libPath );

            // Tear up new PHPIDS initiation object;
            // We still include the native config of PHPIDS at this place, all
            // important settings will be overwritten later on in our very own
            // initiation object using eZINI-settings.
            $this->InitObject = IDS_Init::init( $this->libPath . 'IDS/Config/Config.ini.php' );

            if ($this->InitObject instanceof IDS_Init)
            {
                $this->InitObject->config['General']['base_path']     = $this->libPath . 'IDS/';
                $this->InitObject->config['General']['tmp_path']      = $this->tmpPath;
                $this->InitObject->config['General']['use_base_path'] = true;
                $this->InitObject->config['Caching']['caching']       = 'none';
                $this->InitObject->config['Caching']['path']          = $this->tmpPath . 'default_filter.cache';
                $this->InitObject->config['Logging']['path']          = $this->tmpPath . 'log.txt';
            }
            else
            {
                throw new phpIdsException( 'PHPIDS initiation failed!' );
            }

            // Initialize new intrusion detection monitor object
            $this->IdsObject = new IDS_Monitor( $this->Interceptor->getData(), $this->InitObject );

            // Make sure that instatiation succeeded
            if( !$this->IdsObject instanceof IDS_Monitor )
            {
                throw new phpIdsException( 'IDS instantiation failed!' );
            }

            // Register successful init
            $this->initComplete = true;

        }
        catch ( phpIdsException $e )
        {
            eZDebug::writeError( 'PHPIDS reports an error: ' . $e->getMessage() );
        }
        catch ( Exception $e )
        {
            eZDebug::writeError( 'PHPIDS reports an error: ' . $e->getMessage() );
        }
    }

    /**
     * Mapping-method to actually run the intrusion detection process
     *
     * @access public
     * @return object IDS_Report
     */
    public function runIds()
    {
        // Run analysis and capture time consumption of each detection run aswell.
        eZDebug::accumulatorStart( 'PHPIDS' );
        // Prevent multiple detection runs
        if ( $this->IdsReport === null )
        {
            $this->IdsReport = $this->IdsObject->run();
        }
        eZDebug::accumulatorStop( 'PHPIDS' );
        return $this->IdsReport;
    }

    /**
     * Getter to retrieve enriched analysis reports
     *
     * @access public
     * @param bool $fullAnalysis [optional] Switch to wrap result with full request analysis
     * @return array
     */
    public function getReport( $fullAnalysis = false )
    {
        if ( $fullAnalysis === true )
        {
            $Tracer = new phpIdsTracer();
            return array(
                'clientData' => $Tracer->getClientData(),
                'impact'     => $this->IdsReport->getImpact(),
                'tags'       => $this->IdsReport->getTags(),
                'idsReport'  => $this->IdsReport
            );
        }
        return $this->IdsReport;
    }

    /**
     * Standalone method to call for easy IDS usage
     *
     * @access public
     * @param bool $fullAnalysis [optional] Switch to wrap result with full request analysis
     * @static
     * @return mixed False in case of occuring errors, array in case of success
     */
    public static function run( $fullAnalysis = false )
    {
        $return = false;
        $Ids    = new phpIds();

        if ( $Ids instanceof phpIds and $Ids->initComplete === true )
        {
            $Ids->runIds();
            $return = $Ids->getReport( $fullAnalysis );
        }

        return $return;
    }

}
