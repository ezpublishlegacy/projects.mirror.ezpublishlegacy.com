<?php

/**
 * Interceptor class to gather all threatening inputs for the PHPIDS-library
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIdsInterceptor
{

    /**
     * Method to intercept all incoming data threat vectors
     *
     * @access private
     * @return array
     */
    public function getData()
    {
        // Bypassing all eZ HTTP Tools on purpose to make sure that we don't miss any incoming threat vector...
        return array(
            'REQUEST' => $_REQUEST,
            'GET'     => $_GET,
            'POST'    => $_POST,
            'COOKIE'  => $_COOKIE
        );
    }

}
