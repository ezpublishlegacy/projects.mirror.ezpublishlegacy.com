<?php/* #?ini charset="utf-8"?

[PHPIDS]
Version=0.7

[TRACER]
FingerprintSalt=35d91262b3c3ec8841b54169588c97f7

*/
?>