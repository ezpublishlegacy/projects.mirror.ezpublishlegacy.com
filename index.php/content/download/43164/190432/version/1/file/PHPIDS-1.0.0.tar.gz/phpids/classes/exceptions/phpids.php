<?php

/**
 * PHPIDS custom exception
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIdsException extends RuntimeException
{
    // Intentionally left blank.
}
