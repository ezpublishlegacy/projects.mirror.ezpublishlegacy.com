<?php

/**
 * Module to retrieve the current defense condition of this eZ Publish installation.
 * THIS MODULE IS UNDER CONSTRUCTION!
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */

//var_dump( phpIds::run() );
