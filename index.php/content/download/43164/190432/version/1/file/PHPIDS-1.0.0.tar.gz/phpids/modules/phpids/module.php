<?php

/**
 * File containing PHPIDS module definition
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */

$Module   = array( 'name' => 'phpids' );
$ViewList = array();

/*
$ViewList['defcon'] = array(
    'script' => 'defcon.php',
    'params' => array()
);
*/

$FunctionList = array();
