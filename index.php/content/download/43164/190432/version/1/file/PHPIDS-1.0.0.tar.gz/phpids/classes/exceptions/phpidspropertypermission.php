<?php

/**
 * phpIdsPropertyPermissionException
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIdsPropertyPermissionException extends RuntimeException
{

    /**
     * Class variable to store the errormessage template
     *
     * @var string
     * @access protected
     */
    protected $message = 'Extension PHPIDS reported an error: You are not allowed to set property "{PROPERTY}"!';

    /**
     * Constructor for this exception
     *
     * @param string $message
     * @access public
     * @return object RuntimeException
     */
    public function __construct( $message )
    {
        parent::__construct( $this->composeMessage( $message ) );
    }

    /**
     * Method to compose the final error message for this exception
     *
     * @param string $propertyName
     * @return string The processed errormessage
     */
    protected function composeMessage( $propertyName )
    {
        return str_replace( '{PROPERTY}', $propertyName, $this->message );
    }

}
