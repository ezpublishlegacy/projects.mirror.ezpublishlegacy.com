<?php/* #?ini charset="utf-8"?

[ExtensionSettings]
ActiveAccessExtensions[]=phpids

# [RoleSettings]
# PolicyOmitList[]=phpids/defcon

*/
?>