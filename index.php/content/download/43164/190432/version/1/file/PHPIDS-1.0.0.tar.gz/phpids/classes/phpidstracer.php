<?php

/**
 * Tool class to provide client information for threat analysis
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIdsTracer
{

    /**
     * Container property to store the extension configuration
     *
     * @access private
     * @var object eZINI
     */
    private $Config = null;

    /**
     * Container variable for client data
     *
     * @access private
     * @var array
     */
    private $clientData = array();

    /**
     * Constructor for this class
     *
     * @access public
     * @return void
     */
    public function __construct() {
        $this->Config = eZINI::instance( 'phpids.ini' );
        $this->setClientData();
    }

    /**
     * Method for converting IPv6 addresses to numeric values
     *
     * Optionally splits the numeric address value into two unsigned bigint
     * parts for further database usage (Required for numeric storage on MySQL
     * databases < v6)
     *
     * @see http://stackoverflow.com/questions/420680/
     * @static
     * @access private
     * @param string The IP address
     * @param int [optional] Indicator if the result should be splitted up for DB usage
     * @return long|array
     */
    private static function iPv6ToLong( $ip, $databaseParts = true )
    {
        $ip    = self::expandIPv6Notation( $ip );
        $parts = explode( ':', $ip );
        $ip    = array( '', '' );

        for ( $i = 0; $i < 4; $i++ )
        {
            $ip[0] .= str_pad( base_convert( $parts[$i], 16, 2 ), 16, 0, STR_PAD_LEFT );
        }

        for ( $i = 4; $i < 8; $i++ )
        {
            $ip[1] .= str_pad( base_convert( $parts[$i], 16, 2 ), 16, 0, STR_PAD_LEFT );
        }

        if ( $databaseParts === true )
        {
            return array( base_convert( $ip[0], 2, 10 ), base_convert( $ip[1], 2, 10 ) );
        } else {
            return base_convert( $ip[0], 2, 10 ) + base_convert( $ip[1], 2, 10 );
        }
    }

    /**
     * Method for replacing '::' with appropriate number of ':0' in IPv6 notations
     *
     * @access private
     * @static
     * @param string The IP address to be processed
     * @return string The processed IP address
     */
    private static function expandIPv6Notation( $ip )
    {
        if( strpos( $ip, '::' ) !== false )
        {
            $ip = str_replace( '::', str_repeat( ':0', 8 - substr_count( $ip, ':' ) ) . ':', $ip );
        }

        if( strpos( $ip, ':' ) === 0 ) $ip = '0' . $ip;

        return $ip;
    }

    /**
     * Method for converting an IPv4 address to IPv6
     *
     * @access private
     * @static
     * @param string IP Address in dot notation (e.g. 192.168.1.100)
     * @return string IPv6 formatted address or false if invalid input
     */
    private static function iPv4To6( $ip )
    {
        // Create mask for IPv4 addresses
        static $mask = '::ffff:';
        $ipv6        = ( strpos( $ip, '::' ) === 0 );
        $ipv4        = ( strpos( $ip, '.' ) > 0 );

        // Return false for invalid parameters
        if ( !$ipv4 && !$ipv6 ) return false;

        // Strip IPv4 compatibility notation
        if ( $ipv6 && $ipv4 ) $ip = substr( $ip, strrpos( $ip, ':' ) + 1 );

        // Return IP if assumed to be IPv6 already
        elseif ( !$ipv4 ) return $ip;
        $ip = array_pad( explode( '.', $ip ), 4, 0 );

        // Return false for invalid parameters
        if ( count( $ip ) > 4 ) return false;
        for ( $i=0; $i<4; $i++ ) if ( $ip[$i] > 255 ) return false;

        // Hexa conversion
        $part7 = base_convert( ( $ip[0] * 256 ) + $ip[1], 10, 16 );
        $part8 = base_convert( ( $ip[2] * 256 ) + $ip[3], 10, 16 );

        // Return the processed results
        return $mask . $part7 . ':' . $part8;
    }

    /**
     * Method for fetching user agent information
     *
     * @access private
     * @static
     * @return String
     */
    private static function getUserAgent()
    {
        $agent = 'unknown';
        if ( isset( $_SERVER['HTTP_USER_AGENT'] ) )
        {
            $agent = $_SERVER['HTTP_USER_AGENT'];
        }
        return $agent;
    }

    /**
     * Method for creating a user fingerprint to identify one single user
     *
     * @access private
     * @return string
     */
    private function getClientFingerprint()
    {
        $salt    = '';
        $iniSalt = $this->Config->variable( 'TRACER', 'FingerprintSalt' );
        $salt    = ( $iniSalt !== false ? $iniSalt : 'phpIdsTracer' );

        // Compose fingerprint string using the IP and user agent information
        $fingerPrint = self::getRemoteIp() . self::getUserAgent();

        // Salt this information
        $fingerPrint = $salt . $fingerPrint;

        // Now hash and return the entire string for fingerprinting
        return sha1( $fingerPrint );
    }

    /**
     * Method for retrieving the client's real IP address
     *
     * @access private
     * @static
     * @param bool [optional] Switch to determine whether the IP should be converted using iPv6ToLong
     * @param int [optional] Amount of parts that the IP will be split into for the database
     * @return string|long The IP address
     */
    private static function getRemoteIp( $forDatabase = false )
    {
        $ip = '0.0.0.0';

        // Make an attempt to retrieve the client's IP address
        if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && $_SERVER['HTTP_CLIENT_IP'] != '' )
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( isset($_SERVER['HTTP_X_FORWARDED_FOR'] ) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '' )
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif ( isset($_SERVER['REMOTE_ADDR'] ) && $_SERVER['REMOTE_ADDR'] != '' )
        {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        // Convert all incoming IPs into IPv6
        if ( ( $commaPos = strpos( $ip, ',' ) ) > 0 ) $ip = substr( $ip, 0, ( $commaPos - 1 ) );
        $ip = self::iPv4To6( $ip );

        return ( $forDatabase ? self::iPv6ToLong( $ip, true ) : $ip );
    }

    /**
     * Method to gather client data
     *
     * @access private
     * @return void
     */
    private function setClientData()
    {
        $this->clientData = array(
            'IPv6'            => self::getRemoteIp(),
            'IPv6forDatabase' => self::getRemoteIp( true ),
            'userAgent'       => self::getUserAgent(),
            'userFingerPrint' => $this->getClientFingerprint()
        );
    }

    /**
     * Getter for class property clientData
     *
     * @access public
     * @return array
     */
    public function getClientData()
    {
        return $this->clientData;
    }

}
