<?php

/**
 * File containing phpIdsInfo class
 *
 * @copyright Copyright (C) 2011 Simon Wippich <development@wippich.org>, all rights reserved.
 * @license GNU Lesser General Public License v3
 * @version 1.0.0
 * @package PHPIDS
 */
class phpIdsInfo
{
    static function info()
    {
        return array(
            'Name'      => "<a href='http://projects.ez.no/phpids'>PHPIDS</a>",
            'Version'   => "1.0.0",
            'Copyright' => 'Copyright (C) 2011 Simon Wippich',
            'License'   => 'GNU Lesser General Public License v3',
            'Includes the following third-party software' => array(
                'Name'      => 'PHPIDS (PHP-Intrusion Detection System)',
                'Version'   => '0.7',
                'Copyright' => 'Copyright (c) PHPIDS group -- http://phpids.org',
                'License'   => 'GNU Lesser General Public License v3'
            )
        );
    }
}
