<?php /* #?ini charset="utf-8"?

[GeneralSettings]

# List of all presets available. These should be lowercase and will later be
# used for specific blocks.
PresetList[]
PresetList[]=admindefault
PresetList[]=hint

# Each preset will be configured in its own ini block, which will be named
# following the pattern: Preset-{PRESET_NAME}
# Each preset block contains only one array variable which can store any
# combination of OverLib parameters as well as some extra values:
# - html_tab_begin: the opening HTML tag as OverLib holder (basically anything
#   that will be encapsulated inside tags, for example:
    - div (will produce <div>)
    - span id="12312" (will produce <span id="12312">) 
    - a class="some_link" (will produce <a class="some_link">)
# - html_tab_end: the closing HTML tag as OverLib holder (just like above) 
# - html_value: the HTML content that will become the holder content
# None of the above have to be used necessarily, default values will be 
# used instead.

[Preset-admindefault]
ParamList[]
ParamList[width]=250
ParamList[html_tag_begin]=span class="overlib_admindefault"
ParamList[html_tag_end]=span
ParamList[html_value]=?
ParamList[captionfontclass]=overlib_admindefault_cfc
ParamList[textfontclass]=overlib_admindefault_tfc
ParamList[bgclass]=overlib_admindefault_bgc
ParamList[fgclass]=overlib_admindefault_fgc

[Preset-hint]
ParamList[]

*/ ?>
