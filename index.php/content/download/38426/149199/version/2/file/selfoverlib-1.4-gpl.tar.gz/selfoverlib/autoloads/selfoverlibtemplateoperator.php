<?php

/**
 * SELF OverLib extension for eZ Publish 4.0
 * Written by Piotrek Karaś, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class SELFOverLibTemplateOperator {


    var $Operators;


    function __construct()
    {
        $this->Operators = array(
			'selfoverlib_display',
        );
    }


    function &operatorList()
    {
        return $this->Operators;
    }


    function namedParameterPerOperator()
    {
        return true;
    }


    function namedParameterList()
    {
        return array(
			'selfoverlib_display' => array(
                'param_array' => array(  
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
        ),
        );
    }


    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch( $operatorName )
        {
            case 'selfoverlib_display':
                {
                    $paramArray = $namedParameters['param_array'];
                    $operatorValue = $this->overlibBox( $paramArray );
                }
                break;
        }
    }


    /**
     * This method is used to remove or replace al troublesome characters
     * from parameter values, so that they work out best for OverLib.
     *
     * @param string $input
     * @return string
     */
    private function overlibClean( $input )
    {
        $input = str_replace( '"', '&quot;', $input);
        $input = str_replace( "'", "\'", $input);
        $input = eregi_replace( "[\r\n\t]", " ", $input );
        return $input;
    }


    /**
     * This method takes care of actual generation of OverLib HTML code.
     *
     * The idea behind this method is to make overlib management as flexible
     * as possible. Parameters passed to the operator can either be some key
     * elements or standard overlib params. This method will tell them apart
     * and put into proper processing and use.
     *
     * @param array $paramArray
     * @return string
     */
    private function overlibBox( $paramArray )
    {
        $html = '';
        $functionParams = array();

        // Default system values for key elements
        $htmlTagBegin = 'span';
        $htmlTagEnd = 'span';
        $htmlValue = '???';
        $content = '';

        // If one of the parameters passed is a preset declaration, get the
        // preset settings, check it, and if everything is valid, use preset
        // values for all parameters that are not defined through operator
        // param array (so to simulate override of preset values by local
        // values).
        if( isset( $paramArray['preset'] ) )
        {
            $preset = $paramArray['preset'];

            $ini = eZINI::instance( 'selfoverlib.ini' );
            if( $ini->hasGroup( 'GeneralSettings' ) )
            {
                $generalINI = $ini->group( 'GeneralSettings' );
                $presetList = $generalINI['PresetList'];
                if( in_array( $preset, $presetList ) )
                {
                    if( $ini->hasGroup( 'Preset-' . $preset ) )
                    {
                        $presetINI = $ini->group( 'Preset-' . $preset );
                        if( is_array( $presetINI['ParamList'] ) )
                        {
                            foreach( $presetINI['ParamList'] as $presetParamID => $presetParamValue )
                            {
                                if( !isset( $paramArray[$presetParamID] ) )
                                {
                                    $paramArray[$presetParamID] = $presetParamValue;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Process all the parameters that have been collected and put together
        // from preset settings and local parameters.
        // If the params stand some key functional values, apply speciall
        // processing. Otherwise, simply build a list of OverLib params.
        // Names of the params for OverLib params will be automatically brought
        // to uppercase. Note: They have to match OverLib param names - it's not
        // this methods task to validate them!
        foreach( $paramArray as $paramID => $paramValue )
        {
            switch( $paramID )
            {
                case 'preset':
                    // Do nothing here.
                    break;
                case 'html_tag_begin':
                    $htmlTagBegin = $paramValue;
                    break;
                case 'html_tag_end':
                    $htmlTagEnd = $paramValue;
                    break;
                case 'html_value':
                    $htmlValue = $paramValue;
                    break;
                case 'content':
                    $content = $paramValue;
                    break;
                default:
                    $functionParams[mb_strtoupper( $paramID )] = $this->overlibClean( $paramValue );
                    break;
            }
        }
        
        $content = $this->overlibClean( $content );

        // If no content set, do not display/return anything.
        if( !$content )
        {
            return $html;
        }

        // Generate OverLib code and return it.
        $html .= "<{$htmlTagBegin} onmouseover=\"return overlib('{$content}'";
        foreach( $functionParams as $paramID => $paramValue )
        {
            $html .= ",{$paramID},'{$paramValue}'";
        }
        $html .= ");\" onmouseout=\"return nd();\">{$htmlValue}</{$htmlTagEnd}>";
        
        // Return the code.
        return $html;
    }


};

?>
