<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=selfoverlib

[JavaScriptSettings]
JavaScriptList[]=overlib/overlib.js

[StylesheetSettings]
CSSFileList[]=overlib.css

*/ ?>
