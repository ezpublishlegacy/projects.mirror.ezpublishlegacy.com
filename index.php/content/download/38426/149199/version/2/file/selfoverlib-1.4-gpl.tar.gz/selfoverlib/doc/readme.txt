SELF OverLib extension for eZ Publish 4.0
version 1.4 stable
OverLib version: 4.21

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ez.ryba.eu

On top of OverLib JavaScript library
All details, license: http://www.bosrup.com/web/overlib/
Additional license: doc/overlib.txt



What is it?
-----------

This extension integrates a popular OverLib JavaScript library with eZ Publish. 
Beside providing a simple template operator for automated generation of OverLib
instances, it introduces a fallback configuration architecture for even easier
and flexible use. It is possible to use pre-configurable presets, 
ad-hoc configurated calls as well as any combination of the two approaches.

For each OverLib instance, a JavaScript code must be generated within HTML 
document that requires a number of paramter variables to be passed. 
Those variables control what text/content will be displayed, how the window 
will behave, what it will look like, will it be sticky, and so on. 
There are several problems with literally defining this JavaScript code 
in the templates:
- It is not easy to deal with special characters and escape strings, especially
  in the eZ template language,
- Static JavaScript code is not flexible in case of any future changes, 
  especially across big projects.

To cope with those problems, a simple template operator is introduced. 
The operator automatically deals with any special chars that could destroy 
JavaScript code. It is also configurable by means of presets. Any number 
of presets can be defined and each preset can define any combination 
of OverLib settings.

To ensure that overlib gets always generated properly and the JavaScript has 
every variable required, a setting fallback system is introduced. The following 
priority is used to determine the values of OverLib parameters:
1) Ad-hoc declarations (within the template itself, when using the operator),
2) Preset declarations (if a preset was declared and used)
3) Default system values.
And combination and order of parameters can be used.

Note: Please read the selfoverlib.ini configuration file for further details.

Note: Find out more about OverLib library at http://www.bosrup.com/web/overlib/



Template examples
-----------------

{* This is an adhoc declaration, it has no pre-configured settings,          *}
{* all the paramters that are not declared will have default OverLib values. *}
{selfoverlib_display( 
    hash( 
        'content', 'THIS IS MY OVERLIB TEXT', 
        'caption', 'THIS IS MY OVERLIB CAPTION', 
        'html_value', 'THIS IS THE ANCHOR',
        'width', '225',
    ) 
)}

{* This is a preset-based declaration. You do not have to define anything    *}
{* except for the preset and the content.                                    *}
{selfoverlib_display(
    hash( 
        'preset', 'admindefault', 
        'caption', 'Help: how to use it?', 
        'content', 'It order to use this functionality, you must...',
    )
)}



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components: Base, File



Tested with
-----------
eZ Publish 4.0.0
OverLib 4.21



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/selfoverlib/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=selfoverlib
