<?php
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

// Helper script for Selenium to run ezPublish functional tests.
//
// The script is developed for automation of some tasks that should be performed
// before and after running every particular Selenium test case.
// Script called from Selenium test suite html file with path to test case set in "test" URL parameter
// and performs "pre test" actions, after test case comletion script called again with
// "mode=complete" URL parameter and performs "after test" actions.
//
// Script uses the "eztests.ini" configuration file ( each setting is explained there ) 
// and one required URL parameter "test", that determines which test case to run. 
// Use "test" to specify the relative path to the desired test case. 
// Script will process the test case html and pass it to Selenium for execution.
// Additional Selenium command added to the end of list of test case commands to
// force Selenium call this script after test case executing.
// Script performs the following tasks:
//  Before executing test by Selenium:
// - Clears eZ publish caches
// - Prepars database to run test case.
//   Note that database is completely removed and then created from dump, all current data will be lost!
// - Set full path to the directory containing files for upload while test case execution.
// - Returns modified HTML table containing the test case commands as script output.
// After test execution:
// - Saving current state of the database.

/**
 * Parses ini file.
 * @return array with parsed values
 */
function parse_ini ( $iniFileName )
{
    $iniLines = file( $iniFileName );
    if ( $lines === false )
    {
        echo("Can't read $iniFileName");
        die();
    }
    
    $ini = array();
    
    foreach( $iniLines as $line )
    {
        //skip comments and empty lines
        if ( $line == '' or $line[0] == '#' )
            continue;
        
        if ( preg_match( "/^(.+)##.*/", $line, $regs ) )
            $line = $regs[1];
    
        if ( trim( $line ) == '' )
            continue;
    
        
        if ( preg_match("#^\[(.+)\]\s*$#", $line, $newBlockNameArray ) ) // check for new block
        {
            $newBlockName = trim( $newBlockNameArray[1] );
            $currentBlock = $newBlockName;
            continue;
        }
        else if (preg_match("#^([a-zA-Z0-9_-]+)(\\[([^\\]]*)\\])?=(.*)$#", $line, $valueArray ) )   // check for value
        {
            $varName = trim( $valueArray[1] );
            $varValue = $valueArray[4];

            if ( $valueArray[2] )
            {
                if ( $valueArray[3] )
                {
                    $keyName = $valueArray[3];
                    if ( isset( $ini[$currentBlock][$varName] ) and
                         is_array( $ini[$currentBlock][$varName] ) )
                    {
                        $ini[$currentBlock][$varName][$keyName] = $varValue;
                    }
                    else
                    {
                        $ini[$currentBlock][$varName] = array( $keyName => $varValue );
                    }
                }
            }
            else
            {
                $ini[$currentBlock][$varName]=$varValue;
            }
        }
    }
    return $ini;
}

$ini = parse_ini ( 'eztests.ini' );

$dbName = $ini['MySQLSettings']['DbName'];

$dbSocket = $ini['MySQLSettings']['socket'];
$dbSocket =( isset( $dbSocket ) && $dbSocket != '' ) ? '--socket='.$dbSocket : '';

$rewriteDump = $ini['MySQLSettings']['RewriteDumpIfExist'];
$rewriteDump = ( isset( $rewriteDump ) && $rewriteDump != 'true' ) ? false: true;

$testRootDir = $ini['TestsSettings']['TestsDir'];
$testFilesToUploadRootDir = $ini['TestsSettings']['FilesToUploadRootDir'];

$dumpDefaultArray = $ini['DefaultDbDump'];

$DependenciesArray = $ini['TestCaseDependencies']['Dependencies'];
if (!is_array ( $DependenciesArray) )
{
    $DependenciesArray = array();
}

// check if important parameters are readden correctly.
if ( !isset( $testRootDir ) ) 
{
    echo("Can't get path for tests from eztests.ini. Be sure that 'TestSuitesDir' is set.");
    die();
}

if ( !isset( $dbName ) ) 
{
    echo("Can't get database name from eztests.ini. Be sure that 'DbName' is set.");
    die();
}

if ( !isset($testFilesToUploadRootDir) )
{
    echo("Can't get path for sample files for uploading from eztests.ini. Be sure that 'FilesToUploadRootDir' is set.");
    die();
}

// process URL parameters
$testPath = $GLOBALS['HTTP_GET_VARS']['test'];
if ( !isset( $testPath ) || $testPath == '' )
{
    echo("Error: Test name not provided");
    die();
}

$testPathArray = pathinfo( $testPath );
$testDir = $testPathArray['dirname'];
$testFile = $testPathArray['basename'];

$testHtmlPath = $testRootDir.'/'.$testDir.'/'.$testFile;

if ( !file_exists( $testHtmlPath ) ) {
    echo "Error: Can't find test case html to load: ", $testHtmlPath;
    die();
}

$path_parts = pathinfo( $testHtmlPath );
$testCaseDir = $path_parts['dirname'];

//commented stub  for future support of individual test case ini files
/*
$iniPath = $path_parts['dirname'].$path_parts['basename'].'.ini';

if( !file_exists( $iniPath ) )
{
    echo "Error: Can't find test case ini file to load: ", $iniPath ;
    die();
}
else
{
   $testCaseIniArray = parse_ini( $iniPath );
}

$DbDumpToLoad = $testCaseIniArray['TestCaseSettings']['DbDumpToLoad'];
$DbDumpToSave = $testCaseIniArray['TestCaseSettings']['DbDumpToSave'];

$DbDumpToLoad = ( isset( $DbDumpToLoad ) )? $testCaseDir.'/'.$DbDumpToLoad : false;
$DbDumpToSave = ( isset( $DbDumpToSave ) )? $testCaseDir.'/'.$DbDumpToSave : false;
*/

//check if there is some tests dependent of current test
//if there is, than we need to save dump after execution current test.
if ( in_array( $testPath, $DependenciesArray ) )
{
    $DbDumpToSave = $testCaseDir.'/DumpDB/dumpDB.sql';
}
else
{
    $DbDumpToSave = false;
}

$mode = $GLOBALS['HTTP_GET_VARS']['mode'];
//
if ( $mode == 'complete' ) {
  if ( $DbDumpToSave !== false ) 
  {
      if ( file_exists( $DbDumpToSave ) && !$rewriteDump ) 
      {
//          echo 'Existent dump was not rewritten because of setting in eztests.ini<br>';
      }
      else
      {
        $DbDumpToSaveParts = pathinfo($DbDumpToSave); 
        if ( !file_exists( $DbDumpToSaveParts['dirname'] ) ) 
        {
            mkdir( $DbDumpToSaveParts['dirname'] );
        }
        echo "Current state of MySQL database $dbName saved to: $DbDumpToSave<br>";
        exec ( "mysqldump -uroot $dbSocket $dbName > $DbDumpToSave"  );
      }
  }
  echo 'Test case complete.';
  die();
}

if ( isset( $DependenciesArray[$testPath] ) ) // current test case is dependent from some other.
                                              // try to set path to correspondent dump.
{
    $path_parts = pathinfo( $DependenciesArray[$testPath] );
    $otherTestCaseDir = $path_parts['dirname'];

    $DbDumpToLoad[] = $testRootDir.'/'.$otherTestCaseDir.'/DumpDB/dumpDB.sql';
}

$needToClearDB = true;
if ( is_array( $DbDumpToLoad ) && count( $DbDumpToLoad ) > 0 ) 
{
    $dumpArray = $DbDumpToLoad;
}
else
{
    $dumpArray = $dumpDefaultArray;
}

foreach ( $dumpArray as $DbDumpToLoad ){
    if ( $DbDumpToLoad != false )
    {
        if ( file_exists( $DbDumpToLoad ) ) 
        {
            if ( $needToClearDB ) 
            {
                exec("mysqladmin $dbSocket -uroot -f drop $dbName 2>&1", $output );
                exec("mysqladmin $dbSocket -uroot -f create $dbName 2>&1", $output );
                $needToClearDB = false;
            }
            exec("mysql $dbSocket -uroot $dbName <$DbDumpToLoad 2>&1", $output);        
        }
        else
        {
            echo "Can't find MySQL dump file to load ($DbDumpToLoad) before $testHtmlPath test case executing.\n";
            echo "Please check eztests.ini";
            die();
        }
    }
}

//clear caches
foreach( $ini['CacheDirsToRemove'] as $dirToClear )
{
    exec("rm -r --preserve-root {$dirToClear}/*", $output);
}


$html = implode('', file( $testHtmlPath ) );

//form full path to each upload file by replacing contant with value from main ini file.
$html = str_replace( 'EZ_TESTS_UPLOAD_DIR', $testFilesToUploadRootDir, $html  );

//replacing  the name of database in test case code.
$html = str_replace( 'EZ_TESTS_DB_NAME', $dbName, $html  );

//insert command to the end of test case 
//to inform script that test was complete successfully.
$parts = explode ( '</tbody>', $html );

$istert_part = array();
$istert_part[] = "
<tr>
    <td>open</td>
    <td>/selenium/eztests/eztests.php?test=$testPath&mode=complete</td>
    <td></td>
</tr>
";
$istert_part[] = $parts[1];

array_splice( $parts, 1, count( $parts ), $istert_part);

$html = implode( $parts, '</tbody>' );

echo $html;
?>
