This file describe necessary settings for successful passing of example test cases.

1. You should have eZ publish 3.8  installed as "news site".

2. The "DebugRedirection" must be enabled in [DebugSettings] section in site.ini.append.php.

3. You must specify path to ExampleTestSiute.html in Selenium's TestRunner.html.
Replace src="./tests/TestSuite.html" with src="./eztests/tests/ExampleTestCases/ExampleTestSuite.html"
in line 58 in TestRunner.html.

4. You must specify full path to the "Image" directory in "FilesToUploadRootDir" setting in [TestsSettings]
section in eztests.ini.



