epie.gui.config.bind.filter_black_and_white = function() {
    epie.ezconnect.connect.instance().action({
        'action': 'filter_bw'
    });
}