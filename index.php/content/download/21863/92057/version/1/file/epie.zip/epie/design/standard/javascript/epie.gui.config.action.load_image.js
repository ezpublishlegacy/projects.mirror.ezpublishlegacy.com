epie.gui.config.action.load_image = function(image_id, image_version) {
    epie.ezconnect.prepare(image_id, image_version);
}