epie.ezconnect.failure_default = function(result) {
    // TODO: display a message in the gui?
}