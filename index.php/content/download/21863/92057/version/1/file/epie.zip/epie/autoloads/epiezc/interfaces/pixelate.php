<?php

interface EpIEezcImagePixelate {
    public function pixelate($region = null);
    //public function pixelate2();
}

?>
