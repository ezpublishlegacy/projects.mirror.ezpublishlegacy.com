<?php

class EpIEImageAction {
}

?>
