<?php

interface EpIEezcImageColorSpace {
    public function colorspace($space, $region = null);
    //public function pixelate2();
}

?>
