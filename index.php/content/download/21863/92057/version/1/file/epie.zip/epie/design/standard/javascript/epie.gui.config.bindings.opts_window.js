epie.gui.config.bindings.opts_window = [
    ];