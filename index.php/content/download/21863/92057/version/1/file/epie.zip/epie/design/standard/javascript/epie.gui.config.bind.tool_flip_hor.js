epie.gui.config.bind.tool_flip_hor = function() {
    epie.ezconnect.connect.instance().action({
        'action': 'tool_flip_hor'
    });
}