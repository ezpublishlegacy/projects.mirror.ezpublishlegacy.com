epie.gui.config.bind.filter_grain = function() {
    
    alert('kik le ckucj grain');
}