
/*EpIEGUI.configuration.binding = [
    {
        'id':           'epie_file',
        'click':        EpIEGUI.configuration.file,
        'shortcut':     'Alt + F'
    },
    {
        'id':           'epie_edition',
        'click':        function() { alert('edition') },
        'shortcut':     'Alt + E'
    },
    {
        'id':           'epie_help',
        'click':        function() { alert('help') },
        'shortcut':     'Alt + H'
    },
    {
        'id':           'epie_select',
        'click':        function() { alert('select') },
        'shortcut':     null
    },
    {
        'id':           'epie_undo',
        'click':        function() { alert('undo') },
        'shortcut':     'Ctrl + Z'
    },
    {
        'id':           'epie_redo',
        'click':        function() { alert('redo') },
        'shortcut':     'Ctrl + Y'
    },
    {
        'id':           'epie_pot',
        'click':        function() { alert('paint') },
        'shortcut':     null
    },
    {
        'id':           'epie_img',
        'click':        function() { alert('img') },
        'shortcut':     'Ctrl + I'
    },
    {
        'id':           'epie_watermark',
        'click':        function() { alert('watermak') },
        'shortcut':     null
    },
    {
        'id':           'epie_saturation',
        'click':        function() { alert('saturation') },
        'shortcut':     null
    },
    {
        'id':           'epie_blackandwhite',
        'click':        function() { alert('b&w') },
        'shortcut':     null
    },
    {
        'id':           'epie_grain',
        'click':        function() { alert('grain') },
        'shortcut':     null
    }
] */