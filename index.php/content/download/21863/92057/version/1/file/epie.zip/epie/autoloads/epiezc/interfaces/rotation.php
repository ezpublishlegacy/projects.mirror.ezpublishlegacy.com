<?php
interface EpIEezcImageRotate {
    public function rotate($angle, $color);
}

?>
