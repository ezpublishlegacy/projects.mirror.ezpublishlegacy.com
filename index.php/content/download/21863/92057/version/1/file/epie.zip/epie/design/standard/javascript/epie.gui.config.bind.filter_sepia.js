epie.gui.config.bind.filter_sepia = function() {
    epie.ezconnect.connect.instance().action({
        'action': 'filter_sepia'
    });
}