epie.gui.config.bind.tool_pixelate = function() {
    epie.ezconnect.connect.instance().action({
        'action': 'tool_pixelate'
    });
}

