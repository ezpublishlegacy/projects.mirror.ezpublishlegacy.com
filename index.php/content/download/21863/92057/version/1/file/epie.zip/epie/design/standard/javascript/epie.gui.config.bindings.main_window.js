epie.gui.config.bindings.main_window = [
    /*{
        'selector':     '#epie_file',
        'click':        epie.gui.config.bind.menu_file,
        'shortcut':     'Alt + F'
    },
    {
        'selector':     '#epie_edition',
        'click':        epie.gui.config.bind.menu_edit,
        'shortcut':     'Alt + E'
    },
    {
        'selector':     '#epie_help',
        'click':        epie.gui.config.bind.menu_help,
        'shortcut':     'Alt + H'
    },*/
    {
        'selector':     '#epie_close',
        'click':        epie.gui.config.bind.menu_close_without_saving,
        'shortcut':     null
    },
    {
        'selector':     '#epie_quit_without_saving',
        'click':        epie.gui.config.bind.menu_close_without_saving,
        'shortcut':     null
    },
    {
        'selector':     '#epie_save_and_close',
        'click':        epie.gui.config.bind.menu_save_and_close,
        'shortcut':     null
    }
    ];