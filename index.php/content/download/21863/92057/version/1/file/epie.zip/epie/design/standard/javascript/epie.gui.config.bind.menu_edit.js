epie.gui.config.bind.menu_edit = function() {
    alert('kik le click edit');
}