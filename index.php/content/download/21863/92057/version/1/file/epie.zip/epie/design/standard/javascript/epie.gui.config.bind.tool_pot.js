epie.gui.config.bind.tool_pot = function() {
    alert('kik le click pot');
}