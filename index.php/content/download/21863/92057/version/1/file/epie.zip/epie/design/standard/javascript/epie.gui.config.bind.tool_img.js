epie.gui.config.bind.tool_img = function() {
    alert('kik le click img');
}