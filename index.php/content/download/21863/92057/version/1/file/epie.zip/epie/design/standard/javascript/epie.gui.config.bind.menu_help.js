epie.gui.config.bind.menu_help = function() {
    alert('kik le click help');
}