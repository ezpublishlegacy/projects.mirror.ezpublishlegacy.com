epie.gui.config.bindings.variations_bar = [
];
