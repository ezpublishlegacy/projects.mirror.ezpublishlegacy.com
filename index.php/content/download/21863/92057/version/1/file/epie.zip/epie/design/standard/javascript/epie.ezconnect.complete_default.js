epie.ezconnect.complete_default = function(result) {
    epie.gui.epiegui.getInstance().main().hideLoading();
    epie.gui.epiegui.getInstance().freeze(false);
}