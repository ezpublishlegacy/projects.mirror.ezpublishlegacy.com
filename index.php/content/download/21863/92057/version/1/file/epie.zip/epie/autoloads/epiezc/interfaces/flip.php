<?php

interface EpIEezcImageFlip {
    public function horizontalFlip($region = null);
    public function verticalFlip($region = null);
}

?>
