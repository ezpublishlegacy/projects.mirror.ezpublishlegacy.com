epie.gui.config.bind.menu_file = function() {
    alert('kik le click file');
}