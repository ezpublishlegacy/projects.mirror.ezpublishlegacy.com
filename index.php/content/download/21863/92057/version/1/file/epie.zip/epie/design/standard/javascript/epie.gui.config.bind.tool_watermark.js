epie.gui.config.bind.tool_watermark = function() {
    alert('coming soon...');
}