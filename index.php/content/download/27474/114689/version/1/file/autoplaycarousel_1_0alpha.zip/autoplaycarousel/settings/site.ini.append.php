<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=autoplaycarousel

[RegionalSettings]
TranslationExtensions[]=autoplaycarousel

*/?>