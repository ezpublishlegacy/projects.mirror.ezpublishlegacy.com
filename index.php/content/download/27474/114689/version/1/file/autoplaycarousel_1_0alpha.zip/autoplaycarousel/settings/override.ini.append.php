<?php /* #?ini charset="utf-8"?


[block_autoplaycarousel_1]
Source=block/view/view.tpl
MatchFile=block/autoplaycarousel.tpl
Subdir=templates
Match[type]=AutoPlayCarousel
Match[view]=autoplaycarousel1

[block_autoplaycarousel_2]
Source=block/view/view.tpl
MatchFile=block/autoplaycarousel.tpl
Subdir=templates
Match[type]=AutoPlayCarousel
Match[view]=autoplaycarousel2

[block_autoplaycarousel_3]
Source=block/view/view.tpl
MatchFile=block/autoplaycarousel.tpl
Subdir=templates
Match[type]=AutoPlayCarousel
Match[view]=autoplaycarousel3

*/ ?>