<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=autoplaycarousel

[StylesheetSettings]
CSSFileList[]=autoplaycarousel.css

#[JavaScriptSettings]
#FrontendJavaScriptList[]
#FrontendJavaScriptList[]=swfobject.js
#FrontendJavaScriptList[]=json2.js

#BackendJavaScriptList[]
#BackendJavaScriptList[]=swfobject.js
#BackendJavaScriptList[]=json2.js
*/
?>
