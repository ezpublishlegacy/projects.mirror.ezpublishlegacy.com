<?php
$viewdesc = array (
  'desc' => 'Provides an interface for copying an entire subtree of nodes.',
);
?>