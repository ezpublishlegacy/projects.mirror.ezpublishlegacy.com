<?php
$fetchdesc = array (
  'return' => 'The number of phrases that have been searched (as an integer).',
  'desc' => 'Fetches the number of unique phrases that have been searched.',
);
?>