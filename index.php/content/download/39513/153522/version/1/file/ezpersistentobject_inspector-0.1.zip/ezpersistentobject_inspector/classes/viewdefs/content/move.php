<?php
$viewdesc = array (
  'desc' => 'Provides an interface for changing the location of a node.',
);
?>