<?php
$viewdesc = array (
  'desc' => 'Provides an interface for moving an attribute to a lower position.',
);
?>