<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating sales statistics.',
);
?>