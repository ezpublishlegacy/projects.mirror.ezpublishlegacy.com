<?php
$viewdesc = array (
  'desc' => 'Provides an interface for comparing two different versions of an object (DEPRECATED).',
);
?>