<?php
$viewdesc = array (
  'desc' => 'Provides an interface for tweaking user notification settings.',
);
?>