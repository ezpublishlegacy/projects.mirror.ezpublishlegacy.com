<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing virtual URLs.',
);
?>