<?php
$viewdesc = array (
  'desc' => 'Provides the interface that asks the user to confirm an order.',
);
?>