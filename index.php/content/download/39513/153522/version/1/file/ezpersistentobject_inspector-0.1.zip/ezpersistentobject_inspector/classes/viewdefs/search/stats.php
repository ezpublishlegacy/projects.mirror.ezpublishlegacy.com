<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing and resetting the search statistics.',
);
?>