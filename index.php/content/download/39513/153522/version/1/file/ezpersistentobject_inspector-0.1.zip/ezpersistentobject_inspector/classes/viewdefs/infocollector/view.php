<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing and deleting a specific collection.',
);
?>