<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating a list of all available workflow groups.',
);
?>