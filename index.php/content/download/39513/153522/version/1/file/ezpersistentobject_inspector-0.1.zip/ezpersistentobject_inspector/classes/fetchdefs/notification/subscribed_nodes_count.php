<?php
$fetchdesc = array (
  'return' => 'The number of nodes that the current user has subscribed to (as an integer).',
  'desc' => 'Fetches the number of nodes that the current user has subscribed to.',
);
?>