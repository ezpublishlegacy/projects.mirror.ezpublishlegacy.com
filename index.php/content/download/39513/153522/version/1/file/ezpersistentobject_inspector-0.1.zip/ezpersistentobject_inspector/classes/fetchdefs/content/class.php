<?php
$fetchdesc = array (
  'params' => 
  array (
    'class_id' => 
    array (
      'type' => 'integer',
      'required' => true,
      'desc' => 'The identifier or ID number of the of class that should be fetched.',
    ),
  ),
  'return' => 'The specified class as an ezcontentclass object or FALSE.',
  'desc' => 'Fetches a content class.',
);
?>