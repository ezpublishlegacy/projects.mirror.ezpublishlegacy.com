<?php
$viewdesc = array (
  'desc' => 'Provides an interface to the shopping basket of the current user.',
);
?>