<?php
$viewdesc = array (
  'desc' => 'Provides an interface for restoring objects from the trash.',
);
?>