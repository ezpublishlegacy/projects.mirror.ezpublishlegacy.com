<?php
$viewdesc = array (
  'desc' => 'Provides copyright information related to eZ publish.',
);
?>