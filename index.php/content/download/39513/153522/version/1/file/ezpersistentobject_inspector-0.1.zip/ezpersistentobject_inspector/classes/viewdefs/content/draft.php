<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing the current user\'s drafts.',
);
?>