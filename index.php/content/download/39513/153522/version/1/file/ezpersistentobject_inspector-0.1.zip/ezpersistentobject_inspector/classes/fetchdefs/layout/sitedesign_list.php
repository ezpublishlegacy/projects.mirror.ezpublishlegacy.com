<?php
$fetchdesc = array (
  'return' => 'An array of strings containing the design names.',
  'desc' => 'DEPRECATED (Fetches the names of the currently used designs.)',
);
?>