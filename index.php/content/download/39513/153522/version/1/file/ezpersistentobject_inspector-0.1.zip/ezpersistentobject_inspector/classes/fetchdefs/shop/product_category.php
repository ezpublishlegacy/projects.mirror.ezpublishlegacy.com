<?php
$fetchdesc = array (
  'params' => 
  array (
    'category_id' => 
    array (
      'type' => 'integer',
      'required' => true,
      'desc' => 'The identifier of the target product category.',
    ),
  ),
  'return' => 'An ezproductcategory object or FALSE.',
  'desc' => 'Fetches a product category.',
);
?>