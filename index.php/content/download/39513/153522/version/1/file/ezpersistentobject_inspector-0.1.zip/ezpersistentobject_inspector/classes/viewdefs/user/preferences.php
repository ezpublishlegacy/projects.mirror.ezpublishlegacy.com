<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing the preferences of the current user.',
);
?>