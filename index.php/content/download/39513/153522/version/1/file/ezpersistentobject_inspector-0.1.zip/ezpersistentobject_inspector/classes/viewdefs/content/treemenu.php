<?php
$viewdesc = array (
  'desc' => 'Fetches a node\'s list of children for the dynamic content structure tree menu.',
);
?>