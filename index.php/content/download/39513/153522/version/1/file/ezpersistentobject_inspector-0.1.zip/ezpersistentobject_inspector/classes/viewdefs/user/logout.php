<?php
$viewdesc = array (
  'desc' => 'Provides a mechanism that logs out a user.',
);
?>