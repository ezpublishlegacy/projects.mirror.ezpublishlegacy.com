<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing a version of an object.',
);
?>