<?php
//
// Definition of eZAutoLinkOperator class
//
// Created on: <07-Feb-2003 09:39:55 bf>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

class eZAutoLinkOperator
{
    /*!
     */
    function eZAutoLinkOperator( $name = 'autolink' )
    {
        $this->Operators = array( $name );
    }

    /*!
     Returns the operators in this class.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array( );
    }

    /*!
     \reimp
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        // Replace mail
        $operatorValue = preg_replace( "#([^=\"])(([a-zA-Z0-9_-]+\\.)*[a-zA-Z0-9_-]+@([a-zA-Z0-9_-]+\\.)*[a-zA-Z0-9_-]+)#", "\\1<a href='mailto:\\2'>\\2</a>", $operatorValue );

        // Replace images
        $operatorValue = preg_replace( '#(\s)((http://)([a-zA-Z0-9][a-zA-Z0-9-]*\.)+([a-zA-Z]{2,4})(:\d{2,5})?(/[a-zA-Z/.0-9_]*)?(jpg|jpeg|gif|png)\b)#', '\\1<img src="\\2" border="0">', " $operatorValue");

        // Replace URLS with 'http://' or 'ftp://' prefix
        $operatorValue = preg_replace( '#(\s)((http://|ftp://)([a-zA-Z0-9][a-zA-Z0-9-]*\.)+([a-zA-Z]{2,4})(:\d{2,5})?(/[a-zA-Z/.0-9_]*)?(\?[=a-zA-Z+%&0-9._\#]*)?\b)#', '\\1<a href="\\2" target="_blank">\\2</a>', $operatorValue );
        
        // Replace valid urls with no protocol specified - assume protocol will be HTTP
        $operatorValue = preg_replace( '#(\s)(([a-zA-Z0-9][a-zA-Z0-9-]*\.)+([a-zA-Z]{2,4})(:\d{2,5})?(/[a-zA-Z/.0-9_]*)?(\?[=a-zA-Z+%&0-9._\#]*)?\b)#', '\\1<a href="http://\\2" target="_blank">\\2</a>', $operatorValue);
    
    
        $operatorValue = substr( $operatorValue, 1 );

    }

    /// \privatesection
    var $Operators;
};

?>
