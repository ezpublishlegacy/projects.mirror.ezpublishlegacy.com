<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezdocblock

[RegionalSettings]
TranslationExtensions[]=ezdocblock

*/ ?>
