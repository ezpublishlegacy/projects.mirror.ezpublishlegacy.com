<?php

/**
 * eZ Doc Block extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


require_once( 'kernel/common/i18n.php' );

class eZDocBlockType extends eZDataType
{
    const DATA_TYPE_STRING = 'ezdocblock';
    const DOC_ATTRIBUTE_IDENTIFIER_FIELD = "data_text1";
    const DOC_ATTRIBUTE_IDENTIFIER_VARIABLE = "_ezdocblock_attribute_identifier_";
    const DOC_NODE_ID_FIELD = "data_int3";
    const DOC_NODE_ID_VARIABLE = "_ezdocblock_node_id_";
    const DISPLAY_TYPE_FIELD = "data_text2";
    const DISPLAY_TYPE_VARIABLE = "_ezdocblock_display_type_";
    const DISPLAY_MODE_FIELD = "data_text3";
    const DISPLAY_MODE_VARIABLE = "_ezdocblock_display_mode_";
    const DISPLAY_SCROLL_FIELD = "data_text4";
    const DISPLAY_SCROLL_VARIABLE = "_ezdocblock_display_scroll_";
    const SCROLL_SIZE_FIELD = "data_int2";
    const SCROLL_SIZE_VARIABLE = "_ezdocblock_scroll_size_";
    
    const DOCBLOCK_CHECK_FIELD = '_ezdocblock_check_';
    

    function __construct()
    {
        $this->eZDataType( self::DATA_TYPE_STRING, ezi18n( 'kernel/classes/datatypes', 'Doc block' ) );
    }


    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
    }


    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . self::DOCBLOCK_CHECK_FIELD . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data = $http->postVariable( $base . self::DOCBLOCK_CHECK_FIELD . $contentObjectAttribute->attribute( 'id' ) );
            $classAttribute = $contentObjectAttribute->contentClassAttribute();

            if ( $contentObjectAttribute->validateIsRequired() )
            {
                if( $data != '1' )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'extension/ezdocblock/class', 'Could not load a required external document - cannot proceed. Please contact site administrator.' ) );
                    return eZInputValidator::STATE_INVALID;
                }
            }
        }

        return eZInputValidator::STATE_ACCEPTED;
    }


    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . self::DOCBLOCK_CHECK_FIELD . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data = $http->postVariable( $base . self::DOCBLOCK_CHECK_FIELD . $contentObjectAttribute->attribute( 'id' ) );
            $contentObjectAttribute->setAttribute( 'data_text', $data );
            return true;
        }
        return false;
    }


    function storeObjectAttribute( $attribute )
    {
    }



    function storeDefinedClassAttribute( $attribute )
    {
    }


    function initializeClassAttribute( $classAttribute )
    {
    }



    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {

        return eZInputValidator::STATE_ACCEPTED;
    }

    function fixupClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        
    }


    function storeClassAttribute( $attribute, $version )
    {
    }


    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {

        $docNodeIDVariableName = $base . self::DOC_NODE_ID_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $docNodeIDVariableName ) )
        {
            $docNodeID = $http->postVariable( $docNodeIDVariableName );
            $classAttribute->setAttribute( self::DOC_NODE_ID_FIELD, $docNodeID );
        }

        $docAttributeIdentifierVariableName = $base . self::DOC_ATTRIBUTE_IDENTIFIER_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $docAttributeIdentifierVariableName ) )
        {
            $docAttributeIdentifier = $http->postVariable( $docAttributeIdentifierVariableName );
            $classAttribute->setAttribute( self::DOC_ATTRIBUTE_IDENTIFIER_FIELD, $docAttributeIdentifier );
        }

        $displayTypeVariableName = $base . self::DISPLAY_TYPE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $displayTypeVariableName ) )
        {
            $displayType = $http->postVariable( $displayTypeVariableName );
            $classAttribute->setAttribute( self::DISPLAY_TYPE_FIELD, $displayType );
        }

        $displayModeVariableName = $base . self::DISPLAY_MODE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $displayModeVariableName ) )
        {
            $displayMode = $http->postVariable( $displayModeVariableName );
            $classAttribute->setAttribute( self::DISPLAY_MODE_FIELD, $displayMode );
        }

        $displayScrollVariableName = $base . self::DISPLAY_SCROLL_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $displayScrollVariableName ) )
        {
            $scrollMode = $http->postVariable( $displayScrollVariableName );
            $classAttribute->setAttribute( self::DISPLAY_SCROLL_FIELD, $scrollMode );
        }

        $scrollSizeVariableName = $base . self::SCROLL_SIZE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $scrollSizeVariableName ) )
        {
            $scrollSize = $http->postVariable( $scrollSizeVariableName );
            $classAttribute->setAttribute( self::SCROLL_SIZE_FIELD, $scrollSize );
        }

        return true;
    }


    function objectAttributeContent( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }


    function isIndexable()
    {
        return false;
    }


    function isInformationCollector()
    {
        return false;
    }

}

eZDataType::register( eZDocBlockType::DATA_TYPE_STRING, 'eZDocBlockType' );

?>
