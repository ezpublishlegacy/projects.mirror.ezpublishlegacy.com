<!DOCTYPE TS><TS>
<context>
    <name>extension/ezdocblock/class</name>
    <message>
        <source>Document itself</source>
        <translation>Sam dokument</translation>
    </message>
    <message>
        <source>Link to document</source>
        <translation>Link do dokumentu</translation>
    </message>
    <message>
        <source>Edit mode</source>
        <translation>Tryb edycji</translation>
    </message>
    <message>
        <source>View mode</source>
        <translation>Tryb widoku</translation>
    </message>
    <message>
        <source>Both</source>
        <translation>Oba</translation>
    </message>
    <message>
        <source>Document identifier</source>
        <translation>Identyfikator dokumentu</translation>
    </message>
    <message>
        <source>Display type</source>
        <translation>Rodzaj wyświetlania</translation>
    </message>
    <message>
        <source>Display mode</source>
        <translation>Tryb wyświetlania</translation>
    </message>
    <message>
        <source>Scroll size</source>
        <translation>Rozmiar przewijania</translation>
    </message>
    <message>
        <source>Scroll document</source>
        <translation>Przewijaj dokument</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Puste</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID węzła</translation>
    </message>
    <message>
        <source>Attribute identifier</source>
        <translation>Identyfikator atrybutu</translation>
    </message>
    <message>
        <source>Could not load a required external document - cannot proceed. Please contact site administrator.</source>
        <translation>Nie udało się wczytać wymaganego zewnętrznego dokumentu - nie można kontynuować. Prosimy o kontakt z administracją serwisu.</translation>
    </message>
</context>
</TS>
