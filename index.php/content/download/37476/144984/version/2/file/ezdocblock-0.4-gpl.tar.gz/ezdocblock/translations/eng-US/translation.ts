<!DOCTYPE TS><TS>
<context>
    <name>extension/ezdocblock/class</name>
    <message>
        <source>Document itself</source>
        <translation>Document itself</translation>
    </message>
    <message>
        <source>Link to document</source>
        <translation>Link to document</translation>
    </message>
    <message>
        <source>Edit mode</source>
        <translation>Edit mode</translation>
    </message>
    <message>
        <source>View mode</source>
        <translation>View mode</translation>
    </message>
    <message>
        <source>Both</source>
        <translation>Both</translation>
    </message>
    <message>
        <source>Document identifier</source>
        <translation>Document identifier</translation>
    </message>
    <message>
        <source>Display type</source>
        <translation>Display type</translation>
    </message>
    <message>
        <source>Display mode</source>
        <translation>Display mode</translation>
    </message>
    <message>
        <source>Scroll size</source>
        <translation>Scroll size</translation>
    </message>
    <message>
        <source>Scroll document</source>
        <translation>Scroll document</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Empty</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Node ID</translation>
    </message>
    <message>
        <source>Attribute identifier</source>
        <translation>Attribute identifier</translation>
    </message>
    <message>
        <source>Could not load a required external document - cannot proceed. Please contact site administrator.</source>
        <translation>Could not load external document - cannot proceed. Please contact site administrator.</translation>
    </message>
</context>
</TS>
