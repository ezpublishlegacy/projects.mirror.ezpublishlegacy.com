eZ Doc Block extension for eZ Publish 4.0
version 0.4 beta

Written by Piotrek Karas, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ez.ryba.eu



About
-----

Doc Block datatype helps to build view/edit GUI (especially for forms) that 
need to display or link to outside content, usually terms, rules, disclaimers, 
documents, previews, or whatever else (further referred to as document).

The datatype is a simple half way between unnecessarily storing long texts many 
times and creating customized template solutions in order to reach outside 
document. In fact, it does not store any value, it only displays any node's 
attribute in a automatically controlled manner.

The object attribute's behavior is only controlled at the stage of editting 
the content class, which means only one document can be declared per attribute 
across all objects of given class. When you edit class attribute, you declare:
- Node ID (of the target document)
- Attribute identifier (of the target document)
- Display type (document itself, hyperlink to the document, or both)
- Display mode (view mode, edit mode, or both)
- Scrolled (only affects document display type, document can be scrolled in 
  a box of fixed height or displayed directly)
- Scroll size (only affects document display type, height of the box in pixels)

Additionally, for edit mode, if you mark the class attribute as required, 
the object attribute will not validate if target document (content object) 
is not found. This feature can secure a situation, in which target document 
was removed or has experienced another problem and was not found.

Collect mode is temporarily not available/fully checked.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezdocblock/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezdocblock

3. Clear cache.




Changelog
---------

# Planned:
- Support for information collection (as edit mode).

# v0.4 beta, local, 2008.01.12
+ Required forces successful object fetch/display validation.

# v0.3 beta, local, 2008.01.07
+ General improvements, code cleaning. 

# v0.2 beta, local, 2008.01.06
+ Switch from custom datatype link to node id and attribute identifier.

# v0.1 alpha, local, 2008.01.04
+ First working version. 

# v0.0 alpha, local, 2008.01.04
+ Start.


/+/ complete
/-/ plan or in progress
