<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezdocblock
AvailableDataTypes[]=ezdocblock

*/ ?>
