var dir_82597c321606dcd3429464fbd44dce9c =
[
    [ "initialize.php", "doc_2samples_2soap__server_2initialize_8php.html", "doc_2samples_2soap__server_2initialize_8php" ],
    [ "soap.ini.append.php", "soap_8ini_8append_8php.html", null ]
];