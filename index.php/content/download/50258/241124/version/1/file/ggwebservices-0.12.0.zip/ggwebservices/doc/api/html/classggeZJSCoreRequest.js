var classggeZJSCoreRequest =
[
    [ "decodeStream", "classggeZJSCoreRequest.html#a60603577bd742a9a77a1ab94b2615156", null ],
    [ "payload", "classggeZJSCoreRequest.html#a153c9af681ab4e2ee79d71a3022e2458", null ],
    [ "requestHeaders", "classggeZJSCoreRequest.html#a8718aae8f9bdbebec45a5512413cd863", null ],
    [ "requestURI", "classggeZJSCoreRequest.html#acaac4d0755e2d5941e09ca7e0b08bea8", null ],
    [ "$ContentType", "classggeZJSCoreRequest.html#afb9b0d38fe027813add2fea53d22169b", null ],
    [ "$Verb", "classggeZJSCoreRequest.html#a76f39590731351d9d074e5c5325dcfb3", null ]
];