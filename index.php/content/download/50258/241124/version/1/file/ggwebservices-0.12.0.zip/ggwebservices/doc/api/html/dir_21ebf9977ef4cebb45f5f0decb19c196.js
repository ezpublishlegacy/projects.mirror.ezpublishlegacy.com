var dir_21ebf9977ef4cebb45f5f0decb19c196 =
[
    [ "wsproviders.ini.append.php", "flickr__client_2wsproviders_8ini_8append_8php.html", null ]
];