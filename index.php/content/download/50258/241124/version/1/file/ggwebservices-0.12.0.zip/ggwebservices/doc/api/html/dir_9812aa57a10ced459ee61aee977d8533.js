var dir_9812aa57a10ced459ee61aee977d8533 =
[
    [ "wsproviders.ini.append.php", "solr__client_2wsproviders_8ini_8append_8php.html", null ]
];