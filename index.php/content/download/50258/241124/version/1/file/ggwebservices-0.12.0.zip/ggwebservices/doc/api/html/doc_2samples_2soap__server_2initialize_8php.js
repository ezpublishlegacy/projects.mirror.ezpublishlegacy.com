var doc_2samples_2soap__server_2initialize_8php =
[
    [ "helloWorld", "doc_2samples_2soap__server_2initialize_8php.html#ab82aa7c51c18835bf1aaed7cec701b87", null ],
    [ "helloWorld2", "doc_2samples_2soap__server_2initialize_8php.html#a747dfecc6dc560df584c08164878ef71", null ]
];