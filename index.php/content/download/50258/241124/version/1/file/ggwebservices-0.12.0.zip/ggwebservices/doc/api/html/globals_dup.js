var globals_dup =
[
    [ "$", "globals.html", null ],
    [ "_", "globals_0x5f.html", null ],
    [ "d", "globals_0x64.html", null ],
    [ "e", "globals_0x65.html", null ],
    [ "f", "globals_0x66.html", null ],
    [ "g", "globals_0x67.html", null ],
    [ "h", "globals_0x68.html", null ],
    [ "i", "globals_0x69.html", null ],
    [ "j", "globals_0x6a.html", null ],
    [ "p", "globals_0x70.html", null ],
    [ "s", "globals_0x73.html", null ],
    [ "w", "globals_0x77.html", null ],
    [ "x", "globals_0x78.html", null ]
];