var ezjscore_8inc_8php =
[
    [ "ezjscore_client", "classezjscore__client.html", "classezjscore__client" ],
    [ "ezjscoremsg", "classezjscoremsg.html", "classezjscoremsg" ],
    [ "ezjscoreresp", "classezjscoreresp.html", "classezjscoreresp" ],
    [ "ezjscoreval", "classezjscoreval.html", "classezjscoreval" ],
    [ "serialize_ezjscoreresp", "ezjscore_8inc_8php.html#a9f449a4c5b095444f044e795c733fe3a", null ],
    [ "serialize_ezjscoreval", "ezjscore_8inc_8php.html#a64e3fc501e1e994c3b3f34506aeab3fd", null ]
];