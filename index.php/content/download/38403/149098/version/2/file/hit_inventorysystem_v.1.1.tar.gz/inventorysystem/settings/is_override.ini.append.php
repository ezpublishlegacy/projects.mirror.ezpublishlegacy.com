<?php /* #?ini charset="iso-8859-1"?

[inventorysystem]
Source=node/view/full.tpl
MatchFile=inventorysystem.tpl
Subdir=templates
Match[class_identifier]=database

[is_location]
Source=node/view/full.tpl
MatchFile=is_location.tpl
Subdir=templates
Match[class_identifier]=is_location

[is_building]
Source=node/view/full.tpl
MatchFile=is_building.tpl
Subdir=templates
Match[class_identifier]=is_building

[is_building_part]
Source=node/view/full.tpl
MatchFile=is_building.tpl
Subdir=templates
Match[class_identifier]=is_building_part

[is_room]
Source=node/view/full.tpl
MatchFile=is_room.tpl
Subdir=templates
Match[class_identifier]=is_room

[is_inventory_general]
Source=node/view/full.tpl
MatchFile=is_inventory_general.tpl
Subdir=templates
Match[class_identifier]=is_inventory_general

[is_inventory_art]
Source=node/view/full.tpl
MatchFile=is_inventory_art.tpl
Subdir=templates
Match[class_identifier]=is_inventory_art

[is_loan]
Source=node/view/full.tpl
MatchFile=is_loan.tpl
Subdir=templates
Match[class_identifier]=is_loan

[is_category_container]
Source=node/view/full.tpl
MatchFile=is_category_container.tpl
Subdir=templates
Match[class_identifier]=is_category_container

[is_category]
Source=node/view/full.tpl
MatchFile=is_category.tpl
Subdir=templates
Match[class_identifier]=is_category

*/ ?>
