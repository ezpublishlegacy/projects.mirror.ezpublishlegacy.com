<?php
//
// Definition of loanNotification.php
//
// Created on: <26-Oct-2006 10:06:19 rla>
//
// SOFTWARE NAME: eZ publish
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file loanNotification.php
*/
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentclass.php' );

include_once( 'kernel/classes/datatype/ezdate/ezdatetype.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( 'lib/ezutils/classes/ezmailtransport.php' );
include_once( 'kernel/common/template.php' );

set_time_limit( 0 );

if ( !$isQuiet )
{
    $cli->output( 'Starting loanNotification cronjob' );
}

$currentDate = time();

$cli->output( 'Finding the loan contentclass ... ', false );

$ini =& eZINI::instance();
$inventoryIni =& eZINI::instance( 'inventorysystem.ini' );
$loanClassIdentifier = $inventoryIni->variable( 'InventorySettings', 'LoanClassIdentifier' );
$emailSender = $inventoryIni->variable( 'InventorySettings', 'EmailSender' );

$testMode = $inventoryIni->variable( 'InventorySettings', 'TestMode' );
$testModeEmailReceiver = $inventoryIni->variable( 'InventorySettings', 'TestModeEmailReceiver' );

$loanClass = eZContentClass::fetchByIdentifier( $loanClassIdentifier );

$loanClassID = $loanClass->ID;

$cli->output( 'Found class with id ' . $loanClassID );

$offset = 0;
$limit = 2;

$conds = array( 'contentclass_id' => $loanClassID,
                'status' => 1 );

$cli->output( 'Start processing loans ...' );

while ( true )
{
    $loanObjects = eZContentobject::fetchList( true, $conds, $offset, $limit );

    $offset += $limit;

    if ( !is_array( $loanObjects ) || count( $loanObjects) == 0 )
    {
        break;
    }

    foreach ( $loanObjects as $loanObject )
    {
        $objectID = $loanObject->ID;
	$parentObject = eZContentobject::fetchByNodeID( $loanObject->mainParentNodeID() );

        $dataMap = $loanObject->dataMap();
        $deliverBackDateAttribute = $dataMap[ 'deliver_back_date' ]->content();
        $deliver_back_date = $deliverBackDateAttribute->Date;

        $deliveredBackDateAttribute = $dataMap[ 'delivered_back_date' ]->content();
        $delivered_back_date = $deliveredBackDateAttribute->Date;

        if ( !$delivered_back_date && $deliver_back_date < $currentDate )
        {
            $responsibleAttribute = $dataMap[ 'responsible' ]->content();

            foreach ( $responsibleAttribute->Authors as $responsible )
            {
                $name = $responsible[ 'name' ];
                $email = $responsible[ 'email' ];

                $tpl =& templateInit();
                $tpl->setVariable( 'object', $loanObject );
                $tpl->setVariable( 'parent_object', $parentObject );
                $tpl->setVariable( 'responsible_name', $name );
                $tpl->setVariable( 'responsible_email', $email );

                $templateResult =& $tpl->fetch( 'design:cronjob_is_loan_notification.tpl' );
                $subject =& $tpl->variable( 'subject' );

                if ( $subject == '' )
                {
                    $subject = 'Loan notification for: $name';
                }

                $mail = new eZMail();
                $mail->setReceiver( $email );
                $mail->setSender( $emailSender );
                $mail->setReplyTo( $emailSender );

                if ( $testMode == 'enabled' )
                {
                    $mail->setReceiver( $testModeEmailReceiver );
                    $mail->setReplyTo( $testModeEmailReceiver );
                }

                $mail->setSubject( $subject );
                $mail->setBody( $templateResult );

                $mailResult = eZMailTransport::send( $mail );

		echo "Sent notification for " . $parentObject->Name . " to " . $email . "\n";

            }

        }
    }
    unset( $loanObjects );
}

$cli->output( 'Finished processing loans ...' );

?>
