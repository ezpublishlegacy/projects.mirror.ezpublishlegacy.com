<?php /* #?ini charset="iso-8859-1"?

[CronjobSettings]
#Extension directory for cronjobs.
ExtensionDirectories[]=inventorysystem

# This one will only run the loanNotication cronjob script
[CronjobPart-loanNotification]
Scripts[]=loanNotification.php

*/
?>
