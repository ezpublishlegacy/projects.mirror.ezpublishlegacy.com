<?php
//
// Definition of eZSampleShippingHandler class
//
// Created on: <29-Mar-2006 18:04:01 vs>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

$Module = array( "name" => "Shipping" );

$ViewList = array();

$ViewList['changeoptions'] = array(
    'script' => 'changeoptions.php',
    'functions' => array( 'changeoptions' ),
    'default_navigation_part' => 'ezshopnavigationpart',
    'single_post_actions' => array( 'StoreShippingOptionsButton'  => 'Store',
                                    'CalculateShippingCostButton' => 'Calculate',
                                    'CancelButton'                => 'Cancel' ),
    'post_action_parameters' => array( 'Store'     => array( 'DeliveredBy'         => 'DeliveredBy',
                                                             'Urgently'            => 'Urgently',
                                                             'ProductCollectionID' => 'ProductCollectionID' ),

                                       'Calculate' => array( 'DeliveredBy'         => 'DeliveredBy',
                                                             'Urgently'            => 'Urgently',
                                                             'ProductCollectionID' => 'ProductCollectionID' ),
                                     ),
    'params' => array( 'ProductCollectionID' )
);


$FunctionList['changeoptions'] = array( );

?>
