CREATE TABLE ezsampleshippinginfo (
    productcollection_id  int          NOT NULL PRIMARY KEY,
    delivered_by          varchar(100) NOT NULL,
    urgently              int          NOT NULL,
    cost                  float        NOT NULL
);
