<?php
//
// Created on: <29-Mar-2006 18:04:01 vs>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

$module =& $Params['Module'];

include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'kernel/classes/ezproductcollection.php' );
ext_activate( 'ezsampleshipping', 'classes/ezsampleshipping.php' );

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

if ( $module->isCurrentAction( 'Cancel' ) )
{
    $module->redirectTo( '/shop/basket/' );
    return;
}
elseif ( $module->isCurrentAction( 'Store' ) )
{
    $productCollectionID = (int) $module->actionParameter( 'ProductCollectionID' );
    $deliveredBy         =       $module->actionParameter( 'DeliveredBy' );
    $urgently            =       $module->hasActionParameter( 'Urgently' );

    $shippingOptions = array( 'delivered_by' => $deliveredBy,
                              'urgently'     => $urgently );

    $cost = eZSampleShipping::setOptions( $productCollectionID, $shippingOptions );

    $module->redirectTo( '/shop/basket/' );
    return;
}
elseif ( $module->isCurrentAction( 'Calculate' ) )
{
    $productCollectionID = (int) $module->actionParameter( 'ProductCollectionID' );
    $deliveredBy         =       $module->actionParameter( 'DeliveredBy' );
    $urgently            =       $module->hasActionParameter( 'Urgently' );

    $shippingOptions = array( 'delivered_by' => $deliveredBy,
                              'urgently'     => $urgently );

    $cost = eZSampleShipping::calculateCost( $productCollectionID, $shippingOptions );

    $tpl->setVariable( 'shipping_options', $shippingOptions );
    $tpl->setVariable( 'cost', $cost );
}
else // action: show current shipping options
{
    $productCollectionID = $Params['ProductCollectionID'];

    $shippingInfo = eZSampleShipping::getInfo( $productCollectionID );

    $tpl->setVariable( 'shipping_options', $shippingInfo );
    $tpl->setVariable( 'cost', $shippingInfo['cost'] );
}


// We need to access product collection from template
// to format currency correctly.
$productCollection = eZProductCollection::fetch( $productCollectionID );

$tpl->setVariable( 'product_collection', $productCollection );
$text =& $tpl->fetch( "design:shipping/changeoptions.tpl" );

// Build module result array
$Result = array();
$Result['content'] = $text;
$Result['path'] = array( array( 'url' => false,
                                'text' => "Shipping options" ) );
?>
