<?php /* #?ini charset="iso-8859-1"?

[CustomTagSettings]
AvailableCustomTags[]=include_googlemaps
IsInline[include_googlemaps]=true

[include_googlemaps]
CustomAttributes[]=key
CustomAttributes[]=width
CustomAttributes[]=height
CustomAttributes[]=description
CustomAttributes[]=description2
CustomAttributes[]=description3
CustomAttributes[]=description4
CustomAttributes[]=description5
CustomAttributes[]=search_address
CustomAttributes[]=lat
CustomAttributes[]=lng
CustomAttributes[]=zoom
CustomAttributes[]=name_button1
CustomAttributes[]=name_button2
CustomAttributes[]=name_button3
CustomAttributesDefaults[key]=HERE PAST YOUR GOOGLE KEY
CustomAttributesDefaults[width]=450
CustomAttributesDefaults[height]=450
CustomAttributesDefaults[description]=YOUR DESCRIPTION
CustomAttributesDefaults[search_address]=
CustomAttributesDefaults[lat]=YOUR NUMBER LATITUDE
CustomAttributesDefaults[lng]=YOUR NUMBER LONGITUDE
CustomAttributesDefaults[zoom]=7
CustomAttributesDefaults[name_button1]=Map
CustomAttributesDefaults[name_button2]=Satellite
CustomAttributesDefaults[name_button3]=Hybrid
*/ ?>
