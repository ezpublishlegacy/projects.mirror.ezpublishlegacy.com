<?php /*

[GeneralCondition]
# enabling this will send a trace of the communication to the debug log
snmp-access=disabled

/* ?>