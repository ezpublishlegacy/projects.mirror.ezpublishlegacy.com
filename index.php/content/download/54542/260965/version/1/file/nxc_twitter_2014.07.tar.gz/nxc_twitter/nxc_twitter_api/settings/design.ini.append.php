<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nxc_twitter_api

[StylesheetSettings]
BackendCSSFileList[]=nxc_twitter_api.css
*/ ?>
