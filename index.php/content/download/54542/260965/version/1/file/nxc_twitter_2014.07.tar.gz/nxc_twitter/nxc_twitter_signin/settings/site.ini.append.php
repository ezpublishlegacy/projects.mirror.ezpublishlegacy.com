<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=nxc_twitter_signin/signin
PolicyOmitList[]=nxc_twitter_signin/callback
*/ ?>
