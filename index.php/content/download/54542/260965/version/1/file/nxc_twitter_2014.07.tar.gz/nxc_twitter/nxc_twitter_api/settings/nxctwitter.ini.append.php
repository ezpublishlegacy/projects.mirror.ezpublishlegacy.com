<?php /* #?ini charset="utf-8"?

[TwitterAPI]
Key=kvYRwQrnPeaDfd0kj63WCQ
Secret=KYUMpdSFVvCDoNqqs7l4gSFohurQBW3kZwgT8r7ts
*/ ?>
