<?php /* #?ini charset="utf-8"?

[Cache]
CacheItems[]=nxctwitter

[Cache_nxctwitter]
name=NXC Twitter cache
id=nxc-twitter
tags[]=content
path=nxc-twitter
*/ ?>
