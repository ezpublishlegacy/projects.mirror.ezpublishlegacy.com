gmapsLocation Datatype Extension
Version 0.3
Developed by Blend Interactive
http://www.blendinteractive.com
----------------------
The GmapsLocation datatype extension provides a handy way to store 
latitude/longitude points on an object by using Google Maps to identify
and mark positions using their address.

Installation
---------------

1.) Obtain a Google Maps Key for all domains you'll be using by registering 
your domains with Google at http://www.google.com/apis/maps/

2.) Upload the gmapslocation folder to the extensions folder in your 
eZ Publish installation.

3.) Activate the extension from the 'Extensions' portion of the 
'Setup' tab in the eZ publish admin interface.

4.) Move the 'gmapsadmin' folder to the eZ Publish 'design' folder.

5.) Modify the site.ini.append.php file for your admin siteaccess to include
the 'gmapsadmin' design in the design path. For the default installation, 
change this:
SiteDesign=admin

to this: 

SiteDesign=gmapsadmin
AdditionalSiteDesignList[]=admin

6.) Add your GmapsKey to the site.ini under [SiteSettings] like so: 
GMapsKey=<Long string of characters from Google>

Use
---------------
To use the extension, add the 'GMaps Location' datatype to your classes using 
the class editor.

The most common use of the extension is to also Google Maps data on a public-
facing web site. See the samples folder for template samples that include this.


