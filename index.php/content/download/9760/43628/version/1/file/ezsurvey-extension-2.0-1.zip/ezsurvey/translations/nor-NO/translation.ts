<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Survey</source>
        <translation type="unfinished">Skjema</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Another language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Rediger</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to edit this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">Fjern</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/survey/menu</name>
    <message>
        <source>Survey</source>
        <translation type="unfinished">Spørreskjema</translation>
    </message>
    <message>
        <source>Survey list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related object configuration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ezsurvey/datatypes</name>
    <message>
        <source>Survey</source>
        <comment>Datatype name</comment>
        <translation type="unfinished">Spørreskjema</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Missing survey input.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>survey</name>
    <message>
        <source>Email entry</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Text of question</source>
        <translation>Spørsmålstekst</translation>
    </message>
    <message>
        <source>Mandatory answer</source>
        <translation>Obligatorisk svar</translation>
    </message>
    <message>
        <source>Default answer</source>
        <translation>Standardsvar</translation>
    </message>
    <message>
        <source>Formatted Paragraph</source>
        <translation>Formatert avsnitt</translation>
    </message>
    <message>
        <source>Text of paragraph</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Single/Multiple choice</source>
        <translation>Enkeltvalg/flervalg</translation>
    </message>
    <message>
        <source>Rendering style</source>
        <translation>Visningsmåte</translation>
    </message>
    <message>
        <source>Radio buttons in a row</source>
        <translation>Radioknapper horisontalt</translation>
    </message>
    <message>
        <source>Radio buttons in a column</source>
        <translation>Radioknapper vertikalt</translation>
    </message>
    <message>
        <source>Checkboxes in a row</source>
        <translation>Avkrysningsbokser horisontalt</translation>
    </message>
    <message>
        <source>Checkboxes in a column</source>
        <translation>Avkrysningsbokser vertikalt</translation>
    </message>
    <message>
        <source>Selector</source>
        <translation>Liste</translation>
    </message>
    <message>
        <source>Option label</source>
        <translation>Opsjonstekst</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Avkrysset</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Rekkefølge</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Valgt</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Ny opsjon</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Fjern valgte</translation>
    </message>
    <message>
        <source>Number entry</source>
        <translation>Tall</translation>
    </message>
    <message>
        <source>Integer values only</source>
        <translation>Kun heltall</translation>
    </message>
    <message>
        <source>Minimum value</source>
        <translation>Minimumsverdi</translation>
    </message>
    <message>
        <source>Maximum value</source>
        <translation>Maksimumsverdi</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>Avsnitt</translation>
    </message>
    <message>
        <source>Receiver</source>
        <translation>Mottaker</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Section header</source>
        <translation>Seksjonsoverskrift</translation>
    </message>
    <message>
        <source>Text of header</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Text entry</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Number of columns for an answer textarea</source>
        <translation>Antall kolonner for tekstområde</translation>
    </message>
    <message>
        <source>Number of rows</source>
        <translation>Antall rader for tekstområde</translation>
    </message>
    <message>
        <source>Edit Survey</source>
        <translation type="obsolete">Rediger spørreskjema</translation>
    </message>
    <message>
        <source>Survey title</source>
        <translation>Tittel for spørreskjema</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktivert</translation>
    </message>
    <message>
        <source>Valid from</source>
        <translation>Gyldig fra</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>År</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Måned</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Dag</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Time</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minutt</translation>
    </message>
    <message>
        <source>No limitation</source>
        <translation>Ingen begrensning</translation>
    </message>
    <message>
        <source>Valid to</source>
        <translation>Gyldig til</translation>
    </message>
    <message>
        <source>After &quot;Cancel&quot; redirect to URL</source>
        <translation>Etter &quot;Avbryt&quot;, gå til URL</translation>
    </message>
    <message>
        <source>After &quot;Submit&quot; redirect to URL</source>
        <translation>Etter &quot;Send&quot;, gå til URL</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>Copy question</source>
        <translation>Kopier spørsmål</translation>
    </message>
    <message>
        <source>Add question</source>
        <translation>Legg til spørsmål</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publiser</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aktiver</translation>
    </message>
    <message>
        <source>Apply and Preview</source>
        <translation>Aktiver og forhåndsvis</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Forkast</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Survey List</source>
        <translation type="obsolete">Liste over spørreskjema</translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="obsolete">Publisert</translation>
    </message>
    <message>
        <source>Validity</source>
        <translation type="obsolete">Gyldighet</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultater</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Survey no.</source>
        <translation type="obsolete">Spørreskjema nr.</translation>
    </message>
    <message>
        <source>not enabled</source>
        <translation type="obsolete">ikke aktivert</translation>
    </message>
    <message>
        <source>enabled</source>
        <translation type="obsolete">aktivert</translation>
    </message>
    <message>
        <source>not published</source>
        <translation type="obsolete">ikke publisert</translation>
    </message>
    <message>
        <source>published</source>
        <translation type="obsolete">publisert</translation>
    </message>
    <message>
        <source>valid</source>
        <translation type="obsolete">gyldig</translation>
    </message>
    <message>
        <source>not valid</source>
        <translation type="obsolete">ikke gyldig</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation type="obsolete">Lag kopi og rediger</translation>
    </message>
    <message>
        <source>New Survey</source>
        <translation type="obsolete">Nytt spørreskjema</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bekreft</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Last answers</source>
        <translation>Siste svar</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Antall</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Prosent</translation>
    </message>
    <message>
        <source>No results yet.</source>
        <translation>Ingen resultater ennå.</translation>
    </message>
    <message>
        <source>Back to the result overview</source>
        <translation type="obsolete">Tilbake til resultatoversikten</translation>
    </message>
    <message>
        <source>Participiant:</source>
        <translation>Deltaker:</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Tilbake</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Send</translation>
    </message>
    <message>
        <source>Please answer the question %number as well!</source>
        <translation>Vennligst svar på spørsmålet %number også!</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not a valid email address!</source>
        <translation>Teksten du oppga i spørsmål %number er ikke en gyldig e-postadresse!</translation>
    </message>
    <message>
        <source>You must enter the value for an option in the question with id %question!</source>
        <translation>Du må oppgi verdien til en opsjon i spørsmålet med id %question!</translation>
    </message>
    <message>
        <source>Options in the question with id %question must have unique values!</source>
        <translation>Opsjoner i spørsmålet med id %question må ha unike verdier!</translation>
    </message>
    <message>
        <source>You must enter at least one option in the question with id %question!</source>
        <translation type="obsolete">Du må oppgi minst en opsjon i spørsmålet med id %question!</translation>
    </message>
    <message>
        <source>Single/Multiple Choice</source>
        <translation>Enkeltvalg/flervalg</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not an integer number!</source>
        <translation>Teksten du oppga i spørsmål %number er ikke et heltall!</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not a number!</source>
        <translation>Teksten du oppga i spørsmål %number er ikke et tall!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not lower than or equal to %max!</source>
        <translation>Teksten du oppga i spørsmål %number er ikke et heltall, eller er ikke lavere enn eller lik %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be lower than or equal to %max!</source>
        <translation>Tallet du oppga i spørsmål %number må være lavere enn eller lik %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not greater than or equal to %min!</source>
        <translation>Tallet du oppga i spørsmål %number er ikke et heltall, eller er ikke større enn eller lik %min!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be greater than or equal to %min!</source>
        <translation>Tallet du oppga i spørsmål %number må være større enn eller lik %min!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not between %min and %max!</source>
        <translation>Tallet du oppga i spørsmål %number er ikke et heltall, eller er ikke mellom %min og %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be between %min and %max!</source>
        <translation>Tallet du oppga i spørsmål %number må være mellom %min og %max!</translation>
    </message>
    <message>
        <source>Entered text in the question with id %number is not an integer number!</source>
        <translation>Teksten du oppga i spørsmålet med id %number er ikke et heltall!</translation>
    </message>
    <message>
        <source>Entered text in the question with id %number is not an number!</source>
        <translation>Teksten du oppga i spørsmålet med id %number er ikke et tall!</translation>
    </message>
    <message>
        <source>Entered text &apos;%text&apos; in the question with id %number is not an email address!</source>
        <translation>Teksten du oppga i spørsmålet med id %number er ikke en gyldig e-postadresse!</translation>
    </message>
    <message>
        <source>Email addresses in the question with id %question must have unique values!</source>
        <translation type="obsolete">E-postadresser i spørsmålet med id %question må ha unike verdier!</translation>
    </message>
    <message>
        <source>Survey</source>
        <translation>Spørreskjema</translation>
    </message>
    <message>
        <source>No results</source>
        <translation>Ingen resultater</translation>
    </message>
    <message>
        <source>Survey Preview</source>
        <translation>Forhåndsvisning av spørreskjema</translation>
    </message>
    <message>
        <source>Result overview</source>
        <translation>Resultatoversikt</translation>
    </message>
    <message>
        <source>All answers</source>
        <translation type="obsolete">Alle svar</translation>
    </message>
    <message>
        <source>N. B. If you enter just one email address, user will not see this question. Instead the posting
will be directly sent to the address.</source>
        <translation>NB: Hvis du oppgir bare en e-postadresse vil ikke brukeren se dette spørsmålet. Svaret vil bli
sendt direkte til adressen du har oppgitt.</translation>
    </message>
    <message>
        <source>Receivers</source>
        <translation type="obsolete">Mottakere</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Preselected</source>
        <translation type="obsolete">Forvalgt</translation>
    </message>
    <message>
        <source>id</source>
        <translation>id</translation>
    </message>
    <message>
        <source>Persistent user input. ( Users will be able to edit survey later. )</source>
        <translation>Varige brukerdata (Brukerne kan redigere spørreskjemaet senere.)</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Synlig</translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="obsolete">ID</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the survey &apos;%1&apos; with all evaluations?</source>
        <translation>Er du sikker på at du vil fjerne spørreskjemaet &apos;%1&apos; og alle tilhørende svar?</translation>
    </message>
    <message>
        <source>Survey results for %title</source>
        <translation type="obsolete">Resultater for %title</translation>
    </message>
    <message>
        <source>Result</source>
        <translation type="obsolete">Resultat</translation>
    </message>
    <message>
        <source>Participant</source>
        <translation>Deltaker</translation>
    </message>
    <message>
        <source>Evaluated</source>
        <translation>Evaluert</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Vis</translation>
    </message>
    <message>
        <source>Questions marked with %mark% are required.</source>
        <translation>Spørsmål merket %mark% er obligatoriske.</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Embedded form</source>
        <translation>Innbygget skjema</translation>
    </message>
    <message>
        <source>Only one answer allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to log in in order to answer this survey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The survey is not active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The survey does already have an answer from you</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add extra option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related object entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit related object</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Enter the button to create a new related object to the survey.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add related content</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit survey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Survey list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persistent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not started</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filled Survey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following information was collected as the result of the survey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related object configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set the parent node for the survey attributes, which are of the type Related Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content class.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set the parent folder for the survey attributes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse for the parent node for the related survey attributes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update the configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Survey result overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>has %count answers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit survey results for: %result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Survey result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Survey results for %results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All evaluations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Evaluated:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The survey is not valid. Survey ID is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All values in Valid from need to be numeric.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email addresses in the question with id %number must have unique values!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is only allowed with 1 checked item for the question with id %question when you have radiobuttons!</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Uncheck options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uncheck option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the button &apos;Add existing&apos; or &apos;Add new&apos; to create a new related object to the survey.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
