<?php /* #?ini charset="utf-8"?


[full_survey]
Source=node/view/full.tpl
MatchFile=full/survey.tpl
Subdir=templates
Match[class_identifier]=survey


*/ ?>
