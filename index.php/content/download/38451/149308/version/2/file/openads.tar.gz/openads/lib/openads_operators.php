<?php

/* this file is part of the openads extension for eZ publish */

/* read the openads path from content.ini, and include the openads header */
include_once( "lib/ezutils/classes/ezini.php" );
$ini =& eZINI::instance( 'content.ini' );

$defaultOpenAdsServer = $ini->variable( 'openads', 'DefaultOpenAdsServer' );
$defaultOpenAdsServerScript = $ini->variable( 'openads', 'DefaultOpenAdsServerScript' );

define('MAX_PATH', $defaultOpenAdsServer);
@include_once(MAX_PATH.$defaultOpenAdsServerScript);


class OpenadsOperators
{
   /*!
    Constructor
   */

   function OpenadsOperators()
   {
       $this->Operators = array( 'openads_html' );
   }

 

   /*!
    Returns the operators in this class.
   */

   function &operatorList()
   {
       return $this->Operators;
   }

   /*!
	Return true to tell the template engine that the parameter list
   exists per operator type, this is needed for operator classes
   that have multiple operators.
   */

   function namedParameterPerOperator()
   {
       return true;
   }

 

   /*!
    See eZTemplateOperator::namedParameterList()
   */

   function namedParameterList()
   {
       return array( 'openads_html' => array( 'zone_id' => array( 'type' => 'integer',
                                                                'required' => true,
                                                                'default' => 0 ), 
                                            'campaign_id' => array( 'type' => 'integer',
                                                                'required' => true,
                                                                'default' => 0 ), 
                                            'banner_id' => array( 'type' => 'integer',
                                                                'required' => true,
                                                                'default' => 0 ), 
                                            'html_target' => array( 'type' => 'string',
                                                                'required' => true,
                                                                'default' => '_self' ), 
										)
					 );
   }







   /*!
    Executes the needed operator(s).
    Checks operator names, and calls the appropriate functions.

   zone_id,campaign_id,banner_id,target
   */


   function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                    &$currentNamespace, &$operatorValue, &$namedParameters )
   {
       switch ( $operatorName )
       {
           case 'openads_html':
           {
               $operatorValue = $this->openads_html( 																										$namedParameters['zone_id'],
												$namedParameters['campaign_id'],
												$namedParameters['banner_id'],
												$namedParameters['html_target']
												);
           } break;
       }
   }

 


   function openads_html( $zone_id, $campaign_id, $banner_id, $html_target )
   {

	if (!isset($phpAds_context)) {
		$phpAds_context = array();
	}
	$phpAds_raw = view_local('', $zone_id, $campaign_id , $banner_id, "'".$html_target."'", '', '0', $phpAds_context);
	return $phpAds_raw['html'];

/*
		return "<b> zone_id=".$zone_id."campaign_id=".$campaign_id."banner_id=".$banner_id."html_target=".$html_target."</b>";
*/
   }



   /// privatesection

   var $Operators;
}

?>