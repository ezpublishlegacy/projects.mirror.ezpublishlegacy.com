<?php
// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =

 array( 'script' => 'extension/openads/lib/openads_operators.php',
        'class' => 'OpenadsOperators',
        'operator_names' => array( 'openads_html' ) );
?>





