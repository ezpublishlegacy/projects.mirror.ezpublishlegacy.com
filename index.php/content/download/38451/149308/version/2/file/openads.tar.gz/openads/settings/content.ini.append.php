<?php /* #?ini charset="iso-8859-1"?

[CustomTagSettings]
AvailableCustomTags[]=openads
IsInline[openads]=true

[openads]
CustomAttributes[]=zone_id
CustomAttributes[]=campaign_id
CustomAttributes[]=banner_id
CustomAttributes[]=html_target
CustomAttributesDefaults[zone_id]=0
CustomAttributesDefaults[campaign_id]=1
CustomAttributesDefaults[banner_id]=0
CustomAttributesDefaults[html_target]=_self
DefaultOpenAdsServer=/home/customer/www/openads
DefaultOpenAdsServerScript=/www/delivery/alocal.php


*/ ?>
