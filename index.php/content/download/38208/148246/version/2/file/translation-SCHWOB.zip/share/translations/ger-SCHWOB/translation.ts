	
<!DOCTYPE TS><TS>
<context>
<name>contentstructuremenu/show_content_structure</name>
   <message> 
       <source>Node ID: %node_id Visibility: %visibility</source>
<translation>Knoten ID: %node_id Sichtbarkeit: %visibility</translation>
   </message> 
</context>
<context>
<name>design/admin/class/classlist</name>
   <message> 
       <source>%group_name [Class group]</source>
<translation>%groub_nam [Klassengrubbe]</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Classes inside &lt;%group_name&gt; [%class_count]</source>
<translation>Klassen in &lt;%group_name&gt; [%class_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifizierer</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Objects</source>
<translation>Objekde</translation>
   </message> 
   <message> 
       <source>There are no classes in this group.</source>
<translation>In von dene Grubb sind koi Klasse.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>New class</source>
<translation>Neie Klasse</translation>
   </message> 
   <message> 
       <source>Edit this class group.</source>
<translation>Diese Klassengrubbe bearbeide.</translation>
   </message> 
   <message> 
       <source>Remove this class group.</source>
<translation>Diese Klassengrubbe endferne.</translation>
   </message> 
   <message> 
       <source>Back to class groups.</source>
<translation>Zurügg z den Klassengrubbe.</translation>
   </message> 
   <message> 
       <source>Select class for removal.</source>
<translation>Klasse zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Create a copy of the &lt;%class_name&gt; class.</source>
<translation>Eine Kopie der Klasse &lt;%class_name&gt; erstellen.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%class_name&gt; class.</source>
<translation>Die Klasse &lt;%class_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Remove selected classes from the &lt;%class_group_name&gt; class group.</source>
<translation>Die ausgewÃ¤hlten Klassen aus der Klassengruppe &lt;%class_group_name&gt; entfernen.</translation>
   </message> 
   <message> 
       <source>Create a new class within the &lt;%class_group_name&gt; class group.</source>
<translation>Eine neue Klasse in der Klassengruppe &lt;%class_group_name&gt; erstellen.</translation>
   </message> 
</context>
<context>
<name>design/admin/class/datatype/browse_objectrelation_placement</name>
   <message> 
       <source>Choose node for default selection</source>
<translation>Wähle Knode für schdandard Auswahl</translation>
   </message> 
   <message> 
       <source>Select the item that you want to be the default selection and click &quot;OK&quot;.</source>
<translation>Wählet Sie des Elemend aus, dess d Vorauswahl soi soll und kligget Sie auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/class/datatype/browse_objectrelationlist_placement</name>
   <message> 
       <source>Choose initial location</source>
<translation>Wählet Sie den anfänglile Ord</translation>
   </message> 
   <message> 
       <source>Select the location that should be the default location and click &quot;OK&quot;.</source>
<translation>Wählet Sie den Ord, dr dr voroigeschdellde Ord soi soll und kligge noh auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/class/edit</name>
   <message> 
       <source>The class definition could not be stored.</source>
<translation>Die Klassendefinizion konnde nedd gschbeicherd werde.</translation>
   </message> 
   <message> 
       <source>The following information is either missing or invalid</source>
<translation>Die folgend Informazione fehle odr sind nedd güldig</translation>
   </message> 
   <message> 
       <source>The class definition was successfully stored.</source>
<translation>Die Klassendefinizion wurd erfolgreich gschbeicherd.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%class_name&gt; [Class]</source>
<translation>Bearbeite &lt;%class_name&gt; [Klasse]</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifikador</translation>
   </message> 
   <message> 
       <source>Object name pattern</source>
<translation>Objekdnamens Schema</translation>
   </message> 
   <message> 
       <source>Container</source>
<translation>Behälder</translation>
   </message> 
   <message> 
       <source>Down</source>
<translation>Hinunder</translation>
   </message> 
   <message> 
       <source>Up</source>
<translation>Hiuuff</translation>
   </message> 
   <message> 
       <source>Required</source>
<translation>Erforderlich</translation>
   </message> 
   <message> 
       <source>Searchable</source>
<translation>Durchsuchbar</translation>
   </message> 
   <message> 
       <source>Information collector</source>
<translation>Informazionssammler</translation>
   </message> 
   <message> 
       <source>Disable translation</source>
<translation>Übersedzung ausschalden</translation>
   </message> 
   <message> 
       <source>This class does not have any attributes.</source>
<translation>Diese Klasse hedd koi Addribuade.</translation>
   </message> 
   <message> 
       <source>Remove selected attributes</source>
<translation>Ausgewählde Addribuade endferne</translation>
   </message> 
   <message> 
       <source>Add attribute</source>
<translation>Addribud hinzfügen</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Apply</source>
<translation>Anwenden</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Use this field to set the informal name of the class. The name field can contain whitespaces and special characters.</source>
<translation>Benudze diess Feld um oin informelle Name für diese Klasse z vergebe. Diess Feld kann Leerzeile und Sonderzeile enhalde.</translation>
   </message> 
   <message> 
       <source>Use this field to set the internal name of the class. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
<translation>Benudze diess Feld um oin informelle Name für d Klasse z sedze. Dr Bezeichnr wird in demblads und PHP cod benudzd. Belaubde Zeile sind: Buchschdabe, Nummeret und Underschdriche.</translation>
   </message> 
   <message> 
       <source>Use this field to configure how the name of the objects are generated (also applies to nice URLs). Type in the identifiers of the attributes that should be used. The identifiers must be enclosed in angle brackets. Text outside angle brackets will be included as is.</source>
<translation>Benudzet Sie diess Feld um z konfiguriere, wie dr Nam dr Objekde generierd werde soll (wird au auf nice URLs angewended). Traget Sie d Idendifizierr dr Addribuade oi, d benudzd werde solle. Die Idendifizierr müsse vo schbidze Klammeret oigeschlosse soi. Texd außerhalb vo schbidze Klammeret wird benudzd, wie r isch.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to allow instances of the class to have sub items. If checked, it will be possible to create new sub-items. If not checked, the sub items will not be displayed.</source>
<translation>Benudzet Sie diess Ankreizfeld wenn Sie erlaube wolle, dess Inschdanze dr Klasse Underelemende hend. Wenn s ausgewähld isch, wird s möglich soi neie Underelemende z erschdelle. Falls nedd, werde Underelemende nedd angezeigd werde.</translation>
   </message> 
   <message> 
       <source>Select attribute for removal. Click the &quot;Remove selected attributes&quot; button to actually remove the selected attributes.</source>
<translation>Addribud zum Endferne auswähle. Ankligge vo &quot;Ausgewählde Addribuade endfernen&quot; wird d ausgewählde Addribuade endferne.</translation>
   </message> 
   <message> 
       <source>Use the order buttons to set the order of the class attributes. The up arrow moves the attribute one place up. The down arrow moves the attribute one place down.</source>
<translation>Benudzet Sie d Knöbf, um Reihenfolg z änderet. Dr Hoch-Knobf wird des Addribud oi Posizion no obe, dr Runder-Knobf oi Posizion no unde verschiabe.</translation>
   </message> 
   <message> 
       <source>Use this field to set the informal name of the attribute. This field can contain whitespaces and special characters.</source>
<translation>Benudze sie diess Feld, um den informelle Name vom Addribuads z sedze. Des Feld kann Leer- und Sonderzeile enthalde.</translation>
   </message> 
   <message> 
       <source>Use this field to set the internal name of the attribute. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
<translation>Benudzet Sie diess Feld, um den inderne Name vom Addribds z sedze. Dr Idendifikador finded Verwendung in Temblads und PHP-Cod. Erlaubde Zeichen: Buchschdabe, Zahle und Underschdrich.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to control if the user should be forced to enter information into the attribute.</source>
<translation>Benudze sie diess Ankreizfeld, falls dr Benudzr gzwunge werde soll Eingabe an dem Addribud vorzunehme.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to control if the contents of the attribute should be indexed by the search engine.</source>
<translation>Benudze sie diess Ankreizfeld, falls d Inhalde diess Addribuds vo dr Suchmaschine im Verzeichnis aufgenomme werde solle.</translation>
   </message> 
   <message> 
       <source>The &lt;%datatype_name&gt; datatype does not support search indexing.</source>
<translation>Der Datentyp &lt;%datatype_name&gt; unterstÃ¼tzt die Aufnahme im Verzeichnis der Suchmaschine nicht.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to control if the attribute should collect input from users.</source>
<translation>Benudze sie diess Ankreizfeld, falls des Addribud zum Sammeln vo Eingabe vo Benudzeret verwended werde soll.</translation>
   </message> 
   <message> 
       <source>The &lt;%datatype_name&gt; datatype can not be used as an information collector.</source>
<translation>Der Datentyp &lt;%datatype_name&gt; kann nicht zum Sammeln von Eingaben von Benutzern verwendet werden.</translation>
   </message> 
   <message> 
       <source>Use this checkbox for attributes that contain non-translatable content.</source>
<translation>Benudze sie diess Ankreizfeld für Addribuade, d koin übersedzbare Inhald besidze.</translation>
   </message> 
   <message> 
       <source>Remove the selected attributes.</source>
<translation>Die ausgewählde Addribuade endferne.</translation>
   </message> 
   <message> 
       <source>Add a new attribute to the class. Use the menu on the left to select the attribute type.</source>
<translation>Ein neis Addribud dr Klasse zfüge. Benudzet Sie des Menü links, um den Tyb vom Addribuads auszwähle.</translation>
   </message> 
   <message> 
       <source>Store changes and exit from edit mode.</source>
<translation>Änderunge schbeicheret und den Bearbeidungsmodus verlasse.</translation>
   </message> 
   <message> 
       <source>Store changes and continue editing.</source>
<translation>Änderunge schbeicheret und d Bearbeidung fordsedze.</translation>
   </message> 
   <message> 
       <source>Discard all changes and exit from edit mode.</source>
<translation>Alle Änderunge verwerfe und den Bearbeidungsmodus verlasse.</translation>
   </message> 
   <message> 
       <source>The class definition contains the following errors</source>
<translation>Die Klassendefinizion enthäld folgend Fehler</translation>
   </message> 
</context>
<context>
<name>design/admin/class/edit_denied</name>
   <message> 
       <source>Class edit conflict</source>
<translation>Klasse bearbeide Konflikd</translation>
   </message> 
   <message> 
       <source>This class is already being edited by someone else.</source>
<translation>Diese Klasse wird scho vo jemand anderem bearbeided.</translation>
   </message> 
   <message> 
       <source>The class is temporarly locked and thus it can not be edited by you.</source>
<translation>Die Klasse isch demborär gschberrd und kann dahr vo Ihne nedd bearbeided werde.</translation>
   </message> 
   <message> 
       <source>Possible actions</source>
<translation>Mögliche Vorgehensweisen</translation>
   </message> 
   <message> 
       <source>Contact the person who is editing the class.</source>
<translation>Kondakdieret Sie d Perso, d d Klasse gerad bearbeided.</translation>
   </message> 
   <message> 
       <source>Wait until the lock expires and try again.</source>
<translation>Wardet Sie solang, bis d Schberre aufgehobe wird und brobieret Sie s noh wiedr.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%class_name&gt; [Class]</source>
<translation>Bearbeite &lt;%class_name&gt; [Klasse]</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Current modifier</source>
<translation>Akduellr Bearbeider</translation>
   </message> 
   <message> 
       <source>Unlock time</source>
<translation>Zeidbunkd dr Aufhebung dr Schberre</translation>
   </message> 
   <message> 
       <source>The class will be available for editing once it has been stored by the current modifier or when it is unlocked by the system.</source>
<translation>Die Klasse wird wiedr zum beabreide verfügbar soi, sobald dr momendane Bearbeidr soi Ändrunge abschbeicherd odr d Klasse vom Syschdem endschberrd wird.</translation>
   </message> 
   <message> 
       <source>Retry</source>
<translation>Wiederholen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/class/groupedit</name>
   <message> 
       <source>Edit &lt;%group_name&gt; [Class group]</source>
<translation>&lt;%group_name&gt; [Klassengruppe] bearbeiten</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbruch</translation>
   </message> 
</context>
<context>
<name>design/admin/class/grouplist</name>
   <message> 
       <source>Class groups [%group_count]</source>
<translation>Klassengruppen [%group_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Select class group for removal.</source>
<translation>Klassengrubbe zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%class_group_name&gt; class group.</source>
<translation>Die Klassengruppe &lt;%class_group_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove the selected class groups. This will also remove all classes that only exist within the selected groups.</source>
<translation>Ausgewählde Klassengrubbe endferne. Dis wird au alle Klasse endferne, d ausschließlich in den ausgewählde Grubbe exischdiere.</translation>
   </message> 
   <message> 
       <source>New class group</source>
<translation>Neie Klassengrubbe</translation>
   </message> 
   <message> 
       <source>Create a new class group.</source>
<translation>Eine neie Klassengrubb erschdelle.</translation>
   </message> 
   <message> 
       <source>Recently modified classes</source>
<translation>Zuledzd gänderde Klassen</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifizierer</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%class_name&gt; class.</source>
<translation>Die Klasse &lt;%class_name&gt; bearbeiten.</translation>
   </message> 
</context>
<context>
<name>design/admin/class/removeclass</name>
   <message> 
       <source>Are you sure you want to remove this class?</source>
<translation>Sind Sie sichr, dess Sie diese Klasse endferne wolle?</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Confirm class removal</source>
<translation>Beschdädige dr Löschung oir Klasse</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the classes?</source>
<translation>Sind Sie sichr, dess Sie diese Klasse endferne wolle?</translation>
   </message> 
   <message> 
       <source>You do not have permissions to remove classes.</source>
<translation>Sie hend koi Rechde Klasse z endferne.</translation>
   </message> 
   <message> 
       <source>The %1 class was already removed from the group but still exists in other groups.</source>
<translation>Die %1 Klasse wurde schon vond er Gruppe entfernt, aber existier noch in anderen Gruppen.</translation>
   </message> 
   <message> 
       <source>The %1 classes were already removed from the group but still exist in other groups.</source>
<translation>Die %1 Klassen wurden schon von der Gruppe entfernt, aber exsitieren in anderen Gruppen.</translation>
   </message> 
   <message> 
       <source>Removing class &lt;%1&gt; will result in the removal of %2 object.</source>
<translation>Das entfernen von Klasse &lt;%1&gt; wird auch %2 Objekt entfernen.</translation>
   </message> 
   <message> 
       <source>Removing class &lt;%1&gt; will result in the removal of %2 objects.</source>
<translation>Das Entfernen von Klasse &lt;%1&gt; wird auch die %2 Objekte entfernen.</translation>
   </message> 
</context>
<context>
<name>design/admin/class/removegroup</name>
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Confirm class group removal</source>
<translation>Beschdädige dr Löschung oir Klassegrubbe</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the class group?</source>
<translation>Sind Sie sichr, dess Sie d Klassengrubb endferne wolle?</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the class groups?</source>
<translation>Sind Sie sichr, dess Sie d Klassengrubbe endferne wolle?</translation>
   </message> 
   <message> 
       <source>The following classes will be removed from the &lt;%group_name&gt; class group</source>
<translation>Die folgenden Klassen aus der Klassengruppe &lt;%group_name&gt; werden entfernt</translation>
   </message> 
   <message> 
       <source>%objects objects will be removed</source>
<translation>%objecds Objekde werde endfernd</translation>
   </message> 
</context>
<context>
<name>design/admin/class/view</name>
   <message> 
       <source>Last modified: %time, %username</source>
<translation>Zuletzt geÃ¤ndert: %time, %username</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Bezeichner</translation>
   </message> 
   <message> 
       <source>Object name pattern</source>
<translation>Objekdnamens Schema</translation>
   </message> 
   <message> 
       <source>Container</source>
<translation>Behälder</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Object count</source>
<translation>Anzahl Objekde</translation>
   </message> 
   <message> 
       <source>Attributes</source>
<translation>Addribuade</translation>
   </message> 
   <message> 
       <source>Flags</source>
<translation>Flags</translation>
   </message> 
   <message> 
       <source>Is required</source>
<translation>Isch erforderlich</translation>
   </message> 
   <message> 
       <source>Is not required</source>
<translation>Wird nedd benödigd</translation>
   </message> 
   <message> 
       <source>Is searchable</source>
<translation>Isch durchsuchbar</translation>
   </message> 
   <message> 
       <source>Is not searchable</source>
<translation>Isch nedd durchsuchbar</translation>
   </message> 
   <message> 
       <source>Collects information</source>
<translation>Sammeld Informazionen</translation>
   </message> 
   <message> 
       <source>Does not collect information</source>
<translation>Samml koi Informazionen</translation>
   </message> 
   <message> 
       <source>Translation is disabled</source>
<translation>Übersedzung isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Translation is enabled</source>
<translation>Übersedzung isch akdivierd</translation>
   </message> 
   <message> 
       <source>Override templates [%1]</source>
<translation>Ãberschreib-Templates [%1]</translation>
   </message> 
   <message> 
       <source>Override</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Source template</source>
<translation>Quell-Temblade</translation>
   </message> 
   <message> 
       <source>Override template</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Eingab isch ungüldig</translation>
   </message> 
   <message> 
       <source>%class_name [Class]</source>
<translation>%class_nam [Klasse]</translation>
   </message> 
   <message> 
       <source>Edit this class.</source>
<translation>Diese Klasse bearbeide.</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Member of class groups [%group_count]</source>
<translation>Mitglied von Klassengruppen [%group_count]</translation>
   </message> 
   <message> 
       <source>Class group</source>
<translation>Klassengrubbe</translation>
   </message> 
   <message> 
       <source>Select class group for removal.</source>
<translation>Klassengrubbe zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Remove from selected</source>
<translation>Vo ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove the &lt;%class_name&gt; class from the selected class groups.</source>
<translation>Die Klasse &lt;%class_name&gt; aus den gewÃ¤hlten Klassengruppen entfernen.</translation>
   </message> 
   <message> 
       <source>Select a group which the &lt;%class_name&gt; class should be added to.</source>
<translation>WÃ¤hlen Sie die Gruppen, zu der die Klasse &lt;%class_name&gt; hinzugefÃ¼gt werden soll.</translation>
   </message> 
   <message> 
       <source>Add to class group</source>
<translation>Zur Klassengrubb hinzfügen</translation>
   </message> 
   <message> 
       <source>Add the &lt;%class_name&gt; class to the group specified in the menu on the left.</source>
<translation>Die Klasse &lt;%class_name&gt; zur Gruppe hinzufÃ¼gen, die im Menu auf der linken Seite ausgewÃ¤hlt ist.</translation>
   </message> 
   <message> 
       <source>The &lt;%class_name&gt; class already exists within all class groups.</source>
<translation>Die Klasse &lt;%class_name&gt; existiert bereits in allen Klassengruppen.</translation>
   </message> 
   <message> 
       <source>No group</source>
<translation>Koi Grubbe</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>View template overrides for the &lt;%source_template_name&gt; template.</source>
<translation>Ãberschriebene Templates fÃ¼r das Template &lt;%source_template_name&gt;  anzeigen.</translation>
   </message> 
   <message> 
       <source>Edit the override template for the &lt;%override_name&gt; override.</source>
<translation>Ãberschreib-Template fÃ¼r die Ãberschreibung &lt;%override_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>This class does not have any class-level override templates.</source>
<translation>Die Klasse hedd koi klassen-schbezifische Überschreib-Temblads.</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration</name>
   <message> 
       <source>Approval</source>
<translation>Freigabe</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/group/view/list</name>
   <message> 
       <source>Group list for &apos;%1&apos;</source>
<translation>Gruppenliste fÃ¼r &apos;%1&apos;</translation>
   </message> 
   <message> 
       <source>No items in group.</source>
<translation>Koi Eindräg in dr Grubb.</translation>
   </message> 
   <message> 
       <source>Group tree for &apos;%1&apos;</source>
<translation>Gruppen-Baum fÃ¼r &apos;%1&apos;</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/group_tree</name>
   <message> 
       <source>Groups</source>
<translation>Grubben</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/handler/view/full/ezapprove</name>
   <message> 
       <source>Approval</source>
<translation>Freigabe</translation>
   </message> 
   <message> 
       <source>The content object %1 awaits approval before it can be published.</source>
<translation>Das Inhalts-Objekt  %1 wartet auf Freigabe, bevor es verÃ¶ffentlicht werden kann.</translation>
   </message> 
   <message> 
       <source>If you wish you may send a message to the person approving it?</source>
<translation>Möchdet Sie oi Nachrichd an d freigebend Perso schigge?</translation>
   </message> 
   <message> 
       <source>The content object %1 needs your approval before it can be published.</source>
<translation>Das Inhalts-Objekt %1 benÃ¶tigt Ihre Freigabe, bevor es verÃ¶ffentlicht werden kann.</translation>
   </message> 
   <message> 
       <source>Do you approve of the content object being published?</source>
<translation>Gebet Sie d Veröffendlichung vom Inhalds-Objekds frei?</translation>
   </message> 
   <message> 
       <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
<translation>Das Inhalts-Objekt %1 wurde freigegeben und wird verÃ¶ffentlicht, sobald der VerÃ¶ffentlichungs-Workflow weiterlÃ¤uft.</translation>
   </message> 
   <message> 
       <source>The content object %1 was not accepted but is available as a draft again.</source>
<translation>Das Inhalts-Objekt %1 wurde nicht akzeptiert und steht nun wieder als Entwurf zur VerfÃ¼gung.</translation>
   </message> 
   <message> 
       <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
<translation>Sie könne den Endwurf nochmals änderet und veröffendlile, noh isch oi erneide Beschdädigung erforderlich.</translation>
   </message> 
   <message> 
       <source>Edit the object</source>
<translation>Bearbeide des Objekd</translation>
   </message> 
   <message> 
       <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
<translation>Das Inhalts-Objekt %1 wurde nicht akzeptiert und steht den Autor nun wieder als Entwurf zur VerfÃ¼gung.</translation>
   </message> 
   <message> 
       <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
<translation>Dr Audor kann den Endwurf nochmals änderet und veröffendlile, noh isch oi erneide Freigab erforderlich.</translation>
   </message> 
   <message> 
       <source>Comment</source>
<translation>Kommendar</translation>
   </message> 
   <message> 
       <source>Add Comment</source>
<translation>Kommendar hinzfügen</translation>
   </message> 
   <message> 
       <source>Approve</source>
<translation>Freigeben</translation>
   </message> 
   <message> 
       <source>Deny</source>
<translation>Ablehnen</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>Participants</source>
<translation>Teilnehmer</translation>
   </message> 
   <message> 
       <source>Messages</source>
<translation>Nachrichden</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/handler/view/line/ezapprove</name>
   <message> 
       <source>%1 awaits approval by editor</source>
<translation>%1 warded auf Freigab vom Bearbeider</translation>
   </message> 
   <message> 
       <source>%1 was approved for publishing</source>
<translation>%1 wurd zur Veröffendlichung freigegeben</translation>
   </message> 
   <message> 
       <source>%1 was not approved for publishing</source>
<translation>%1 wurd nedd zur Veröffendlichung freigegeben</translation>
   </message> 
   <message> 
       <source>%1 awaits your approval</source>
<translation>%1 warded auf Ihre Freigabe</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/item_list</name>
   <message> 
       <source>Subject</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Date</source>
<translation>Dadum</translation>
   </message> 
   <message> 
       <source>Read</source>
<translation>Gelesen</translation>
   </message> 
   <message> 
       <source>Unread</source>
<translation>Ungelesen</translation>
   </message> 
   <message> 
       <source>Inactive</source>
<translation>Inakdiv</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/view/element/ezapprove_comment</name>
   <message> 
       <source>Posted: %1</source>
<translation>Verschickt: %1</translation>
   </message> 
</context>
<context>
<name>design/admin/collaboration/view/summary</name>
   <message> 
       <source>Item list</source>
<translation>Eindrags-Lischde</translation>
   </message> 
   <message> 
       <source>No new items to be handled.</source>
<translation>Koi neie Eindräg zum Bearbeide.</translation>
   </message> 
   <message> 
       <source>Group tree</source>
<translation>Grubben-Baum</translation>
   </message> 
</context>
<context>
<name>design/admin/content/bookmark</name>
   <message> 
       <source>My bookmarks [%bookmark_count]</source>
<translation>Meine Lesezeichen [%bookmark_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>There are no bookmarks in the list.</source>
<translation>Es sind koi Lesezeile in dr Lischde.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select bookmark for removal.</source>
<translation>Lesezeile zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%bookmark_name&gt;.</source>
<translation>&lt;%bookmark_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to edit the contents of &lt;%bookmark_name&gt;.</source>
<translation>Sie haben nicht das Recht, den Inhalt von &lt;%bookmark_name&gt; zu bearbeiten.</translation>
   </message> 
   <message> 
       <source>Remove selected bookmarks.</source>
<translation>Ausgewählde Lesezeile endferne.</translation>
   </message> 
   <message> 
       <source>Add items</source>
<translation>Eindräg hinzfügen</translation>
   </message> 
   <message> 
       <source>Add items to your personal bookmark list.</source>
<translation>Eindräg z Ihre bersönlile Lesezeile hinzfüge.</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse</name>
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Top level</source>
<translation>Oberschde Ebene</translation>
   </message> 
   <message> 
       <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
<translation>Um Objekde auszwähle, kligget Sie auf d endschbrechende Auswahl- odr Ankreizfeldr und drügge noh den &quot;Wählen&quot;-Knobf.</translation>
   </message> 
   <message> 
       <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
<translation>Um oi Objekd auszwähle, dess underhalb von a angezeigde Objekds liegd, kligget Sie auf den Name diess Objekds, um oi Lischde dr undergeordenede Objekde angezeigd z bekomme.</translation>
   </message> 
   <message> 
       <source>Back</source>
<translation>Zurügg</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbruch</translation>
   </message> 
   <message> 
       <source>Display sub items using a simple list.</source>
<translation>Underelmende undr Verwendung oir oifache Lischde anzeige.</translation>
   </message> 
   <message> 
       <source>List</source>
<translation>Lischde</translation>
   </message> 
   <message> 
       <source>Thumbnail</source>
<translation>Miniaduransichd</translation>
   </message> 
   <message> 
       <source>Display sub items as thumbnails.</source>
<translation>Underelmenede als Miniadurbildr darschdelle.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_bookmark</name>
   <message> 
       <source>Choose items to bookmark</source>
<translation>Wählet Sie oi Elemend, um s den Lesezeile hinzuzfügen</translation>
   </message> 
   <message> 
       <source>Select the items that you want to bookmark using the checkboxes and click &quot;OK&quot;.</source>
<translation>Wählet Sie d Eindräg, für d Sie Lesezeile anlege wolle mid den Ankreiz-Käschdle und kligget Sie auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_copy_node</name>
   <message> 
       <source>Choose location for copy of &lt;%object_name&gt;</source>
<translation>Neuen Ort fÃ¼r Kopie von &lt;%object_name&gt; wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose a new location the copy of &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie einen neuen Ort fÃ¼r die Kopie von &lt;%object_name&gt; mit den Radio-Buttons und klicken Sie &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
   <message> 
       <source>Choose location for copy of subtree of node &lt;%node_name&gt;</source>
<translation>Einen Ort fÃ¼r die Kopie der Teile der Baumstruktur des Knotens &lt;%node_name&gt; wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose a new location the copy subtree of node &lt;%node_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie einen neuen Ort fÃ¼r die Kopie der Teile der Baumstruktur des Knotens &lt;%node_name&gt; mit den Radio-Buttons und klicken Sie dann auf &quot;OK&quot;.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_export</name>
   <message> 
       <source>Choose export node</source>
<translation>Wählet Sie den z exbordierende Knoden</translation>
   </message> 
   <message> 
       <source>Select the item that you want to export using the checkboxes and click &quot;OK&quot;.</source>
<translation>Wählet Sie mid den Ankreiz-Käschdle d Elemende aus, d Sie exbordiere wolle und kligget Sie noh auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_first_placement</name>
   <message> 
       <source>Choose location for new &lt;%classname&gt;</source>
<translation>Ort fÃ¼r neuen &lt;%classname&gt; wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose a location for the new &lt;%classname&gt; using the radiobuttons and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie einen Ort fÃ¼r den neuen &lt;%classname&gt; mit den Radio-Buttons und klicken Sie &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_move_node</name>
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
   <message> 
       <source>Choose a new location for &lt;%object_name&gt;</source>
<translation>Neuen Ort fÃ¼r &lt;%object_name&gt; wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose a new location for &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie einen Ort fÃ¼r &lt;%object_name&gt; mit den Radio-Buttons und klicken Sie &quot;OK&quot;.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_move_placement</name>
   <message> 
       <source>Choose a new location for &lt;%version_name&gt;</source>
<translation>Neuen Ort fÃ¼r &lt;%version_name&gt; wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose a new location for &lt;%version_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie einen Ort fÃ¼r &lt;%version_name&gt; mit den Radio-Buttons und klicken Sie &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>The previous location was &lt;%previous_location&gt;.</source>
<translation>Der bisherige Ort war &lt;%previous_location&gt;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_placement</name>
   <message> 
       <source>Choose locations for &lt;%version_name&gt;</source>
<translation>Ort fÃ¼r &lt;%version_name&gt; auswÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Choose locations for &lt;%version_name&gt; using the checkboxes and click &quot;OK&quot;.</source>
<translation>WÃ¤hlen Sie die Orte fÃ¼r &lt;%version_name&gt; mit den Radio-Buttons und klicken Sie &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_related</name>
   <message> 
       <source>Choose objects that you wish to relate to &lt;%version_name&gt;</source>
<translation>WÃ¤hlen Sie, welche Objekte Sie mit &lt;%version_name&gt; verbinden wollen</translation>
   </message> 
   <message> 
       <source>Use the checkboxes to choose the objects that you wish to relate to &lt;%version_name&gt;.</source>
<translation>WÃ¤hlen Sie mit den Ankreuz-KÃ¤stchen, welche Objekte Sie mit &lt;%version_name&gt; verbinden wollen</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/browse_swap_node</name>
   <message> 
       <source>Choose the exchanging node for &lt;%object_name&gt;</source>
<translation>WÃ¤hlen Sie den Austausch-Knoten fÃ¼r &lt;%object_name&gt;</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose the node with which you want to swap &lt;%object_name&gt;.</source>
<translation>WÃ¤hlen Sie mit den Auswahl-KnÃ¶pfen, welchen Knoten Sie gegen &lt;%object_name&gt; austauschen wollen.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/content/collectedinfo/feedback</name>
   <message> 
       <source>Feedback for %feedbackname</source>
<translation>RÃ¼ckmeldung von %feedbackname</translation>
   </message> 
   <message> 
       <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
<translation>Sie hend scho Dade übermiddeld. Die vorhr übermiddelde Dade sind d folgende.</translation>
   </message> 
   <message> 
       <source>Thanks for your feedback, the following information was collected.</source>
<translation>Dank für Ihre Rüggmeldung, d folgende Informazione wurde gsammeld.</translation>
   </message> 
   <message> 
       <source>Return to site</source>
<translation>Zur Seide zurüggkehren</translation>
   </message> 
</context>
<context>
<name>design/admin/content/collectedinfo/form</name>
   <message> 
       <source>Form %formname</source>
<translation>Von %formname</translation>
   </message> 
   <message> 
       <source>Collected information</source>
<translation>Gesammelde Informazionen</translation>
   </message> 
   <message> 
       <source>You have already submitted data to this form. The previously submitted data was the following.</source>
<translation>Sie hend scho Dade an diess Formular gschiggd. Des vorhergegangene Dade ware d folgende.</translation>
   </message> 
   <message> 
       <source>Back</source>
<translation>Zurügg</translation>
   </message> 
</context>
<context>
<name>design/admin/content/collectedinfo/poll</name>
   <message> 
       <source>Poll %pollname</source>
<translation>Umfrage %pollname</translation>
   </message> 
   <message> 
       <source>Anonymous users are not allowed to vote on this poll, please login.</source>
<translation>Anonym Benudzeret isch s nedd gschdadded an von dene Umfrag deilzunehme, Bidde meldet Sie i an.</translation>
   </message> 
   <message> 
       <source>You have already voted for this poll.</source>
<translation>Sie hend scho an von dene Umfrag deilgenomme.</translation>
   </message> 
   <message> 
       <source>Poll results</source>
<translation>Umfrage-Ergebnisse</translation>
   </message> 
   <message> 
       <source>%count total votes</source>
<translation>%cound Schdimmen</translation>
   </message> 
</context>
<context>
<name>design/admin/content/confirmtranslationremove</name>
   <message> 
       <source>Confirm language removal</source>
<translation>Endferne dr Schbrache beschdädigen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the language?</source>
<translation>Sind Sie sichr, dess Sie diese Schbrache endferne wolle?</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the languages?</source>
<translation>Sind Sie sichr, dess Sie diese Schbrache endferne wolle?</translation>
   </message> 
   <message> 
       <source>Removing &lt;%1&gt; will also result in the removal of %2 translated versions.</source>
<translation>Das Entfernen von &lt;%1&gt; wird auch  %2 Ã¼bersetzte Versionen entfernen.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/content/datatype</name>
   <message> 
       <source>No media file is available.</source>
<translation>Es isch koi Mediendadei verfügbar.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/draft</name>
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove all</source>
<translation>Alle endfernen</translation>
   </message> 
   <message> 
       <source>My drafts [%draft_count]</source>
<translation>Meine EntwÃ¼rfe [%draft_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Select draft for removal.</source>
<translation>Endwurf zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%draft_name&gt;.</source>
<translation>&lt;%draft_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>There are no drafts that belong to you.</source>
<translation>Es gibd koi Endwürf, d Ihne gehöre.</translation>
   </message> 
   <message> 
       <source>Remove selected drafts.</source>
<translation>Ausgewähle Endwürf endferne.</translation>
   </message> 
   <message> 
       <source>Remove all drafts that belong to you.</source>
<translation>Alle Endwürf, d Ihne gehöre, endferne.</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
</context>
<context>
<name>design/admin/content/edit</name>
   <message> 
       <source>Edit &lt;%object_name&gt; [%class_name]</source>
<translation>&lt;%object_name&gt; [%class_name] bearbeiten</translation>
   </message> 
   <message> 
       <source>Translating content from %from_lang to %to_lang</source>
<translation>Ãbersetze den Inhalte von %from_lang in %to_lang</translation>
   </message> 
   <message> 
       <source>Send for publishing</source>
<translation>Zur Veröffendlichung schiggen</translation>
   </message> 
   <message> 
       <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
<translation>De Inhald vom derzeidige Endwurfs veröffendlile. Damid wird von dene Endwurf d veröffendlichde Versoin diess Objekd.</translation>
   </message> 
   <message> 
       <source>Store draft</source>
<translation>Endwurf schbeichern</translation>
   </message> 
   <message> 
       <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
<translation>De Inhald vom derzeidge Endwurf schbeicheret und mid dr Bearbeidung fordfahre. Benudzet Sie diese Knobf regelmässich, um Ihre Arbeid z schbeicheret, während Sie schreibe.</translation>
   </message> 
   <message> 
       <source>Discard draft</source>
<translation>Endwurf verwerfen</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Depth</source>
<translation>Tiefe</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class Identifier</source>
<translation>Klassen-Idendifikador</translation>
   </message> 
   <message> 
       <source>Class Name</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Locations [%locations]</source>
<translation>Orte [%locations]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Sub items</source>
<translation>Undergeordnede Eindräge</translation>
   </message> 
   <message> 
       <source>Sorting of sub items</source>
<translation>Sordierung dr undergeordnede Eindräge</translation>
   </message> 
   <message> 
       <source>Current visibility</source>
<translation>Derzeidig Sichdbarkeid</translation>
   </message> 
   <message> 
       <source>Visibility after publishing</source>
<translation>Sichdbarkeid no Veröffendlichung</translation>
   </message> 
   <message> 
       <source>Main</source>
<translation>Haubd</translation>
   </message> 
   <message> 
       <source>You do not have permissions to remove this location.</source>
<translation>Sie hend koi Berechdigung, diese Ord z endferne.</translation>
   </message> 
   <message> 
       <source>Select location for removal.</source>
<translation>Ord zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Use this menu to set the sorting method for the sub items of the respective location.</source>
<translation>Verwendet Sie diess Menu, um d Sordiermethod für d undergeordnede Eindräg vom endschbrechende Ords feschdzulege.</translation>
   </message> 
   <message> 
       <source>Use this menu to set the sorting direction for the sub items of the respective location.</source>
<translation>Verwendet Sie diess Menu, um d Sordierrichdung für d undergeordnede Eindräg vom endschbrechende Ords feschdzulege.</translation>
   </message> 
   <message> 
       <source>Desc.</source>
<translation>Abschdgd.</translation>
   </message> 
   <message> 
       <source>Asc.</source>
<translation>Aufschdgd.</translation>
   </message> 
   <message> 
       <source>Hidden by parent</source>
<translation>Vom übergeordnede Elemend verschdeggd</translation>
   </message> 
   <message> 
       <source>Visible</source>
<translation>Sichdbar</translation>
   </message> 
   <message> 
       <source>Unchanged</source>
<translation>Unveränderd</translation>
   </message> 
   <message> 
       <source>Hidden</source>
<translation>Verschdeggd</translation>
   </message> 
   <message> 
       <source>Use these radio buttons to specify the main location (main node) for the object being edited.</source>
<translation>Verwendet Sie d Auswahl-Knöbf, um den Haubd-Ord (Haubd-Knode) für des derzeid bearbeidede Objekd auszwähle.</translation>
   </message> 
   <message> 
       <source>Move to another location.</source>
<translation>Zu oim andere Ord verschiabe.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove selected locations.</source>
<translation>Ausgewählde Orde endferne.</translation>
   </message> 
   <message> 
       <source>Add locations</source>
<translation>Ord hinzfügen</translation>
   </message> 
   <message> 
       <source>Add one or more locations for the object being edited.</source>
<translation>Eine odr mehrere Orde für des derzeid bearbeidede Objekd hinzfüge.</translation>
   </message> 
   <message> 
       <source>You can not add or remove locations because the object being edited belongs to a top node.</source>
<translation>Sie könne koi Orde endferne odr hinzfüge, weil des akduelle Objekd z oim Haubdknode gehörd.</translation>
   </message> 
   <message> 
       <source>Object information</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Versione verwalden</translation>
   </message> 
   <message> 
       <source>View and manage (copy, delete, etc.) the versions of this object.</source>
<translation>Versione vom derzeidige Objekds ansehe und verwalde (hinzfügen/endferne).</translation>
   </message> 
   <message> 
       <source>You can not manage the versions of this object because there is only one version available (the one that is being edited).</source>
<translation>Sie könne koin Versione diess Objekd verwalde, da s nur d derzeid angezeigde Versio gibd.</translation>
   </message> 
   <message> 
       <source>Current draft</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>View</source>
<translation>Ansehen</translation>
   </message> 
   <message> 
       <source>View the draft that is being edited.</source>
<translation>De derzeidige Endwurf ansehe.</translation>
   </message> 
   <message> 
       <source>Store and exit</source>
<translation>Schbeicheret und verlassen</translation>
   </message> 
   <message> 
       <source>Store the draft that is being edited and exit from edit mode.</source>
<translation>De derzeidige Endwurf schbeicheret und den Bearbeidungsmodus verlasse.</translation>
   </message> 
   <message> 
       <source>Translations [%translation_count]</source>
<translation>Ãbersetzungen [%translation_count]</translation>
   </message> 
   <message> 
       <source>%1 (No locale information available)</source>
<translation>%1 (Koi lokale Informazione verfügbar)</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the selected translation of the draft that is being edited.</source>
<translation>Die ausgewählde Übersedzung vom derzeidige Endwurfs bearbeide.</translation>
   </message> 
   <message> 
       <source>Translate</source>
<translation>Übersedzen</translation>
   </message> 
   <message> 
       <source>Edit the selected translation of the draft using the content being edited as a reference.</source>
<translation>Die ausgewählde Übersedzung vom derzeidige Endwurfs auf Basis vom derzeidige Inhalds bearbeide.</translation>
   </message> 
   <message> 
       <source>The draft that is being edited only exists in one language; thus this button is disabled.</source>
<translation>Dr derzeidig Endwurf exidschdierd nur in oir Schbrache; dahr isch von dene Knobf deakdiv.</translation>
   </message> 
   <message> 
       <source>Manage translations</source>
<translation>Übersedzunge verwalden</translation>
   </message> 
   <message> 
       <source>View and manage (add/remove) translations for the draft that is being edited.</source>
<translation>Übersedzunge vom derzeidige Endwurfs ansehe und verwalde (hinzfügen/endferne).</translation>
   </message> 
   <message> 
       <source>Related objects [%related_objects]</source>
<translation>Verwandte Objekte [%related_objects]</translation>
   </message> 
   <message> 
       <source>Related images [%related_images]</source>
<translation>Verwandte Bilder [%related_images]</translation>
   </message> 
   <message> 
       <source>Copy this code and paste it into an XML field.</source>
<translation>Kobieret Sie diese Cod in oi XML-Feld.</translation>
   </message> 
   <message> 
       <source>Related files [%related_files]</source>
<translation>Verwandte Dateien [%related_files]</translation>
   </message> 
   <message> 
       <source>File type</source>
<translation>Dadei-Tyb</translation>
   </message> 
   <message> 
       <source>Size</source>
<translation>Größe</translation>
   </message> 
   <message> 
       <source>XML code</source>
<translation>XML Code</translation>
   </message> 
   <message> 
       <source>Related content [%related_objects]</source>
<translation>Verwandter Inhalt [%related_objects]</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>There are no objects related to the one that is currently being edited.</source>
<translation>Es gibd koi Objekde, d zum derzeid bearbeidede verwandd sind.</translation>
   </message> 
   <message> 
       <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
<translation>Die ausgwählde Eindräg aus dr obige Lischde endferne. Es wird nur d Verbindung endfernd. Des Objekd selbsch wird nedd glöschd.</translation>
   </message> 
   <message> 
       <source>Add existing</source>
<translation>Beschdehends hinzfügen</translation>
   </message> 
   <message> 
       <source>Add an existing item as a related object.</source>
<translation>Ein beschdehends Objecd als verwandds Objekd hinzfüge.</translation>
   </message> 
   <message> 
       <source>Upload new</source>
<translation>Nei hochladen</translation>
   </message> 
   <message> 
       <source>Upload a file and add it as a related object.</source>
<translation>Eine neie Dadei hochlade und als verwandds Objekd hinzfüge.</translation>
   </message> 
   <message> 
       <source>The draft could not be stored.</source>
<translation>Dr Endwurf konnde nedd gschbeicherd werde.</translation>
   </message> 
   <message> 
       <source>Required data is either missing or is invalid</source>
<translation>Nodwendig Dade fehle odr sind ungüldich.</translation>
   </message> 
   <message> 
       <source>The following locations are invalid</source>
<translation>Die folgende Orde sind ungüldig</translation>
   </message> 
   <message> 
       <source>The draft was only partially stored.</source>
<translation>Dr Endwurf wurd nur deilweise gschbeicherd.</translation>
   </message> 
   <message> 
       <source>The draft was successfully stored.</source>
<translation>Dr Endwurf wurd erfolgreich gschbeicherd.</translation>
   </message> 
   <message> 
       <source>Are you sure you want to discard the draft?</source>
<translation>Sind Sie sichr, dess Sie den Endwurf verwerfe wolle?</translation>
   </message> 
   <message> 
       <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
<translation>De akduelle Endwurf verwerfe. Dis wird au zum Endwurf gehörend Übersedzunge lösche.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/edit_attribute</name>
   <message> 
       <source>not translatable</source>
<translation>Nedd übersedzbar</translation>
   </message> 
   <message> 
       <source>required</source>
<translation>Erforderlich</translation>
   </message> 
   <message> 
       <source>information collector</source>
<translation>Informazionssammler</translation>
   </message> 
</context>
<context>
<name>design/admin/content/edit_draft</name>
   <message> 
       <source>Object information</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Possible edit conflict</source>
<translation>Möglichr Bearbeidungs-Konflikd</translation>
   </message> 
   <message> 
       <source>This object is already being edited by someone else. In addition, it is already being edited by you.</source>
<translation>Diess Objekd wurd bereids vo jemand anderem bearbeided. Außerdem wird s bereids vo Ihne bearbeided.</translation>
   </message> 
   <message> 
       <source>You should contact the other user(s) to make sure that you are not stepping on anyone&apos;s toes.</source>
<translation>Sie sollde den andere Anwendr kondakdiere, um sicherzugehe, dess Sie ihm nedd auf d Füsse drede.</translation>
   </message> 
   <message> 
       <source>The most recently modified draft is version #%version, created by %creator, last changed: %modified.</source>
<translation>Der zuletzt bearbeitete Entwurf ist Version #%version, erstellt von %creator, zuletzt geÃ¤ndert: %modified.</translation>
   </message> 
   <message> 
       <source>This object is already being edited by you.</source>
<translation>Diese Objekd wird bereids vo Ihne berarbeided.</translation>
   </message> 
   <message> 
       <source>Your most recently modified draft is version #%version, last changed: %modified.</source>
<translation>Ihr zuletzt bearbeiteter Entwurf ist Version #%version, zuletzt geÃ¤ndert: %modified.</translation>
   </message> 
   <message> 
       <source>This object is already being edited by someone else.</source>
<translation>Diese Objekd wird bereids vo jemand andere berarbeided.</translation>
   </message> 
   <message> 
       <source>Possible actions</source>
<translation>Mögliche Vorgehensweisen</translation>
   </message> 
   <message> 
       <source>Continue editing one of your drafts.</source>
<translation>Eine Ihrr Endwürf weidr bearbeide.</translation>
   </message> 
   <message> 
       <source>Create a new draft and start editing it.</source>
<translation>Eine neie Endwurf erschdelle und d Arbeid dro beginne.</translation>
   </message> 
   <message> 
       <source>Cancel the edit operation.</source>
<translation>De akuelle Vorgang abbrele.</translation>
   </message> 
   <message> 
       <source>Current drafts [%draft_count]</source>
<translation>Aktuelle EntwÃ¼rfe [%draft_count]</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Creator</source>
<translation>Erschdeller</translation>
   </message> 
   <message> 
       <source>Select draft version #%version for editing.</source>
<translation>Entwurf Version #%version zur Bearbeitung auswÃ¤hlen.</translation>
   </message> 
   <message> 
       <source>You can not select draft version #%version for editing because it belongs to another user. Please select a draft that belongs to you or create a new draft and then edit it.</source>
<translation>Sie kÃ¶nnen den Entwurf Version #%version nicht zur Bearbeitung auswÃ¤hlen, weil er jemand anderem gehÃ¶rt. Bitte wÃ¤hlen Sie einen Entwurf, der Ihnen gehÃ¶rt oder erstellen und bearbeiten Sie einen neuen Entwurf.</translation>
   </message> 
   <message> 
       <source>View the contents of version #%version. Default translation: %default_translation.</source>
<translation>Den Inhalt der Version #%version ansehen. Standard-Ãbersetzung: %default_translation.</translation>
   </message> 
   <message> 
       <source>View the contents of version #%version_number. Translation: %translation.</source>
<translation>Den Inhalt der Version #%version_number ansehen. Ãbersetzung: %translation.</translation>
   </message> 
   <message> 
       <source>Edit selected</source>
<translation>Ausgewählde bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the selected draft.</source>
<translation>De ausgewählde Endwurf bearbeiden</translation>
   </message> 
   <message> 
       <source>You can not edit any of the drafts because none of them belong to you. Hint: Create a new draft, select it and edit it.</source>
<translation>Sie könne koin dr Endwürf bearbeide, weil koir davo Ihne gehörd. Hinweis: Erschdellet Sie oin neie Endwurf, wählet Sie diese aus und bearbeidet Sie ihn.</translation>
   </message> 
   <message> 
       <source>New draft</source>
<translation>Neir Endwurf</translation>
   </message> 
   <message> 
       <source>Create a new draft. The contents of the new draft will copied from the published version.</source>
<translation>Neie Endwurf erschdelle. Dr Endwurf basierd noh auf dr akduell veröffendlichde Versio.</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/content/pendinglist</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>The pending list is empty.</source>
<translation>Die Wardelischde isch ler.</translation>
   </message> 
   <message> 
       <source>My pending items [%pending_count]</source>
<translation>Ihre wartenden EintrÃ¤ge [%pending_count]</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
</context>
<context>
<name>design/admin/content/removeassignment</name>
   <message> 
       <source>Object information</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Versione verwalden</translation>
   </message> 
   <message> 
       <source>Current draft</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Confirm location removal</source>
<translation>Beschdädige dr Löschung von a Ordes</translation>
   </message> 
   <message> 
       <source>Insufficient permissions</source>
<translation>Unzureichend Rechde</translation>
   </message> 
   <message> 
       <source>Some of the locations that are about to be removed contain sub items.</source>
<translation>Einig dr Orde, d endfernd werde solle, hend undergeordnede Eindräg.</translation>
   </message> 
   <message> 
       <source>Removing the locations will also result in the removal of the sub items.</source>
<translation>Wenn diese Orde endfernd werde, werde au d undergeordnede Eindräg endfernd.</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the locations along with their contents?</source>
<translation>Sind Sie sichr, dess Sie d Orde samd ihrem jeweilige Inhald endferne wolle?</translation>
   </message> 
   <message> 
       <source>The locations marked with red contain items that you do not have permissions to remove.</source>
<translation>Die rod markierde Orde boihalde Eindräg, d Sie mangels Berechdigung nedd endferne könne.</translation>
   </message> 
   <message> 
       <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
<translation>Kligget Sie auf &quot;Abbruch&quot; und versuchet Sie, nur d Orde z endferne, d Sie endferne dürfe.</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Sub items</source>
<translation>Undergeordnede Eindräge</translation>
   </message> 
   <message> 
       <source>%child_count item</source>
<translation>%child_cound Elemend</translation>
   </message> 
   <message> 
       <source>%child_count items</source>
<translation>%child_cound Elemende</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Remove the locations along with all the sub items.</source>
<translation>Die Orde endfernd mid alle undergeordnede Eindräge endferne.</translation>
   </message> 
   <message> 
       <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
<translation>Sie könne nedd fordfahre, da Ihne d Berechdigung fehld, oiig dr ausgewählde Orde z endferne.</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Cancel the removal of locations.</source>
<translation>Des Endferne vo Orde abbrele.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/removeeditversion</name>
   <message> 
       <source>Object information</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Confirm draft discard</source>
<translation>Endwurfslöschung beschdädigen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to discard the draft?</source>
<translation>Sind Sie sichr, dess Sie den Endwurf verwerfe wolle?</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Versione verwalden</translation>
   </message> 
   <message> 
       <source>Current draft</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
</context>
<context>
<name>design/admin/content/removeobject</name>
   <message> 
       <source>%child_count item</source>
<translation>%child_cound idem</translation>
   </message> 
   <message> 
       <source>%child_count items</source>
<translation>%child_cound idems</translation>
   </message> 
</context>
<context>
<name>design/admin/content/search</name>
   <message> 
       <source>Update attributes</source>
<translation>Addribuade akdualisieren</translation>
   </message> 
   <message> 
       <source>Search</source>
<translation>Suchen</translation>
   </message> 
   <message> 
       <source>All content</source>
<translation>Kombledde Inhald</translation>
   </message> 
   <message> 
       <source>The same location</source>
<translation>Gleichr Ord</translation>
   </message> 
   <message> 
       <source>For more options try the %1Advanced search%2.</source>
<translation>Probieren Sie die %1erweiterte Suche%2 fÃ¼r weitere MÃ¶glichkeiten.</translation>
   </message> 
   <message> 
       <source>No results were found while searching for &lt;%1&gt;</source>
<translation>Bei der Suche nach &lt;%1&gt; wurden keine Ergebnisse gefunden.</translation>
   </message> 
   <message> 
       <source>Search tips</source>
<translation>Such-Tibbs</translation>
   </message> 
   <message> 
       <source>Check spelling of keywords.</source>
<translation>Überbrüfet Sie d Rechdschreibung dr Suchwördr.</translation>
   </message> 
   <message> 
       <source>Try more general keywords.</source>
<translation>Versuchet Sie s mid allgemoire Worde.</translation>
   </message> 
   <message> 
       <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
<translation>Wenigr Suchwördr gebe mehr Ergebnisse. Versuchet Sie d Suchwördr z reduziere, bis Sie oi Ergebnis bekomme.</translation>
   </message> 
   <message> 
       <source>Search for &lt;%1&gt; returned %2 matches</source>
<translation>Die Suche nach &lt;%1&gt; ergab %2 Treffer</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Advanced search</source>
<translation>Erweiderde Suche</translation>
   </message> 
   <message> 
       <source>Search for all of the following words</source>
<translation>Nach alle folgende Worde suchen</translation>
   </message> 
   <message> 
       <source>Search for an exact phrase</source>
<translation>Genau no oim Ausdrugg suchen</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Any class</source>
<translation>Beliabig Klasse</translation>
   </message> 
   <message> 
       <source>Class attribute</source>
<translation>Klasseneigenschafd</translation>
   </message> 
   <message> 
       <source>Any attribute</source>
<translation>Beliabigs Addribud</translation>
   </message> 
   <message> 
       <source>In</source>
<translation>In</translation>
   </message> 
   <message> 
       <source>Any section</source>
<translation>Beliabig Sekzion</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Any time</source>
<translation>Beliabigs Dadum</translation>
   </message> 
   <message> 
       <source>Last day</source>
<translation>Ledzdr Tag</translation>
   </message> 
   <message> 
       <source>Last week</source>
<translation>Ledzde Woche</translation>
   </message> 
   <message> 
       <source>Last month</source>
<translation>Ledzdr Monad</translation>
   </message> 
   <message> 
       <source>Last three months</source>
<translation>Ledzde drei Monade</translation>
   </message> 
   <message> 
       <source>Last year</source>
<translation>Ledzds Jahr</translation>
   </message> 
   <message> 
       <source>Display per page</source>
<translation>Pro Seide anzeigen</translation>
   </message> 
   <message> 
       <source>5 items</source>
<translation>5 Schdügg</translation>
   </message> 
   <message> 
       <source>10 items</source>
<translation>10 Schdügg</translation>
   </message> 
   <message> 
       <source>20 items</source>
<translation>20 Schdügg</translation>
   </message> 
   <message> 
       <source>30 items</source>
<translation>30 Schdügg</translation>
   </message> 
   <message> 
       <source>50 items</source>
<translation>50 Schdügg</translation>
   </message> 
   <message> 
       <source>No results were found when searching for &lt;%1&gt;</source>
<translation>Bei der Suche nach &lt;%1&gt; wurden keine Ergebnisse gefunden.</translation>
   </message> 
   <message> 
       <source>The following words were excluded from the search</source>
<translation>Die folgende Wördr wurde vo dr Suche ausgeschlossen</translation>
   </message> 
   <message> 
       <source>Try changing some keywords e.g. car instead of cars.</source>
<translation>Wandeln Sie oiig Suchwördr ab, z. B. Audo anschdadd vo Audos.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/translate</name>
   <message> 
       <source>Object information</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Versione verwalden</translation>
   </message> 
   <message> 
       <source>Current draft</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Confirm translation removal</source>
<translation>Endferne dr Übersedzung beschdädigen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the translation?</source>
<translation>Wollet Sie d Übersedzung wirklich endferne?</translation>
   </message> 
   <message> 
       <source>The following translation (along with translated content) will be removed from the draft</source>
<translation>Die folgend Übersedzung wird (zsamme mid den übersedze Inhalde) vom Endwurf endfernd</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the translations?</source>
<translation>Sind Sie si sichr, dess Sie d Übersedzunge endferne wolle?</translation>
   </message> 
   <message> 
       <source>The following translations (along with translated content) will be removed from the draft</source>
<translation>Die folgende Übersedzunge werde (zsamme mid den übersedzde Inhalde) vom Endwurf endfernd</translation>
   </message> 
   <message> 
       <source>(No locale information available.)</source>
<translation>(Koi Informazion zur Ördlichkeid verfügbar)</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Translations for &lt;%object_name&gt; [%translation_count]</source>
<translation>Ãbersetzungen fÃ¼r &lt;%object_name&gt; [%translation_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Select translation for removal.</source>
<translation>Übersedzung zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>(Unable to display because of unknown locale!)</source>
<translation>(Wege unbekanndr Ördlichkeid koi Anzeig möglich, hajo, so isch des !)</translation>
   </message> 
   <message> 
       <source>There are no translations available.</source>
<translation>Es sind koi Übersedzunge verfügbar</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove the selected translations from the draft that is being edited.</source>
<translation>Die ausgewählde Übersedzunge vom Endwurf dr gerad bearbeided wird endferne.</translation>
   </message> 
   <message> 
       <source>Select a translation you wish to add to the draft that is being edited.</source>
<translation>Wählet Sie oi Übersedzung, d dem gerad in Bearbeidung befindlile Endwurf hinzugefügd werde soll.</translation>
   </message> 
   <message> 
       <source>All available translations have been added to the draft that is being edited.</source>
<translation>Alle verfügbare Übersedzunge wurde dem gerad in Bearbeidung befindlile Endwurf hinzugefügd.</translation>
   </message> 
   <message> 
       <source>No languages</source>
<translation>Koi Schbrachen</translation>
   </message> 
   <message> 
       <source>Add translation</source>
<translation>Übersedzung hinzfügen</translation>
   </message> 
   <message> 
       <source>Add the selected translation to the draft that is being edited.</source>
<translation>Die ausgewählde Übersedzung dem gerad in Bearbeidung befindlile Endwurf hinzfüge.</translation>
   </message> 
   <message> 
       <source>Back to edit mode</source>
<translation>Zurügg zum Bearbeidungsmodus</translation>
   </message> 
   <message> 
       <source>Go back to edit mode.</source>
<translation>Zum Bearbeidungmodus zurüggkehre.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/translationnew</name>
   <message> 
       <source>Translation</source>
<translation>Übersedzung</translation>
   </message> 
   <message> 
       <source>New translation for content</source>
<translation>Neie Übersedzung für den Inhald</translation>
   </message> 
   <message> 
       <source>Custom</source>
<translation>Individuell</translation>
   </message> 
   <message> 
       <source>Name of custom translation</source>
<translation>Nam dr schbezifische Übersedzung</translation>
   </message> 
   <message> 
       <source>Locale for custom translation</source>
<translation>Ördlichkeid dr schbezifische Übersedzung</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/content/translations</name>
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Country</source>
<translation>Land</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add language</source>
<translation>Schbrache hinzfügen</translation>
   </message> 
   <message> 
       <source>Available languages for translation of content [%translations_count]</source>
<translation>VerfÃ¼gbare Sprachen fÃ¼r die Ãbersetzung des Inhalts [%translations_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Select language for removal.</source>
<translation>Schbrache zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>The default language can not be removed.</source>
<translation>Die Schdandardschbrache kann nedd endfernd werde.</translation>
   </message> 
   <message> 
       <source>Remove selected languages.</source>
<translation>Ausgewählde Schbrache endferne.</translation>
   </message> 
   <message> 
       <source>Add a new language. The new language can then be used when translating content.</source>
<translation>Eine neie Schbrache hinzfüge. Die neie Schbrache kann noh benudzd werde, wenn Inhalde übersedzd werde.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/translationview</name>
   <message> 
       <source>%translation [Translation]</source>
<translation>%dranslazion [Übersedzung]</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>%locale [Locale]</source>
<translation>%locale [Ördlichkeid]</translation>
   </message> 
   <message> 
       <source>Charset</source>
<translation>Zeichensadz</translation>
   </message> 
   <message> 
       <source>Not set</source>
<translation>Nedd gsedzd</translation>
   </message> 
   <message> 
       <source>Allowed charsets</source>
<translation>Erlaubde Zeichensädze</translation>
   </message> 
   <message> 
       <source>Country name</source>
<translation>Nam dr Landes</translation>
   </message> 
   <message> 
       <source>Country comment</source>
<translation>Kommendar zum Land</translation>
   </message> 
   <message> 
       <source>Country code</source>
<translation>Ländercode</translation>
   </message> 
   <message> 
       <source>Country variation</source>
<translation>Land Variazion</translation>
   </message> 
   <message> 
       <source>Language name</source>
<translation>Nam dr Schbrache</translation>
   </message> 
   <message> 
       <source>International language name</source>
<translation>Indernazionalr Nam dr Schbrache</translation>
   </message> 
   <message> 
       <source>Language code</source>
<translation>Schbrachcode</translation>
   </message> 
   <message> 
       <source>Language comment</source>
<translation>Kommendar zur Schbrache</translation>
   </message> 
   <message> 
       <source>Locale code</source>
<translation>Cod dr Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Full locale code</source>
<translation>Vollschdändigr Cod dr Ördlichkeid</translation>
   </message> 
   <message> 
       <source>HTTP locale code</source>
<translation>Cod dr HTTP Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Decimal symbol</source>
<translation>Kommazeichen</translation>
   </message> 
   <message> 
       <source>Thousands separator</source>
<translation>Tausendr Trennzeichen</translation>
   </message> 
   <message> 
       <source>Decimal count</source>
<translation>Nachkommaschdellen</translation>
   </message> 
   <message> 
       <source>Negative symbol</source>
<translation>Zeile zur Anzeig negadivr Werde</translation>
   </message> 
   <message> 
       <source>Positive symbol</source>
<translation>Zeile zur Anzeig bosidivr Werde</translation>
   </message> 
   <message> 
       <source>Currency decimal symbol</source>
<translation>Kommazeile bei Währung</translation>
   </message> 
   <message> 
       <source>Currency thousands separator</source>
<translation>Tausendr Trennzeile bei Währung</translation>
   </message> 
   <message> 
       <source>Currency decimal count</source>
<translation>Nachkommaschdelle bei Währung</translation>
   </message> 
   <message> 
       <source>Currency negative symbol</source>
<translation>Zeile zur Anzeig negadivr Werde bei Währung</translation>
   </message> 
   <message> 
       <source>Currency positive symbol</source>
<translation>Zeile zur Anzeig bosidivr Werde bei Währung</translation>
   </message> 
   <message> 
       <source>Currency symbol</source>
<translation>Währungszeichen</translation>
   </message> 
   <message> 
       <source>Currency name</source>
<translation>Nam dr Währung</translation>
   </message> 
   <message> 
       <source>Currency short name</source>
<translation>Kurzr Nam dr Währung</translation>
   </message> 
   <message> 
       <source>First day of week</source>
<translation>Erschdr Tag dr Woche</translation>
   </message> 
   <message> 
       <source>Monday</source>
<translation>Mondag</translation>
   </message> 
   <message> 
       <source>Weekday names</source>
<translation>Name dr Wochendage</translation>
   </message> 
   <message> 
       <source>Month names</source>
<translation>Nam dr Monade</translation>
   </message> 
   <message> 
       <source>Sunday</source>
<translation>Sonndag</translation>
   </message> 
</context>
<context>
<name>design/admin/content/trash</name>
   <message> 
       <source>Trash [%list_count]</source>
<translation>Papierkorb [%list_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Use these checkboxes to mark items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
<translation>Markieret Sie Eindräg, d Sie lösche wolle, mid den Cheggboxe. Kligget Sie noh auf &quot;Ausgewählde löschen&quot;, um diese Eindräg wirklich z lösche.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde löschen</translation>
   </message> 
   <message> 
       <source>Permanently remove the selected items.</source>
<translation>Ausgewählde Eindräg endgüldich lösche.</translation>
   </message> 
   <message> 
       <source>Empty trash</source>
<translation>Pabierkorb leeren</translation>
   </message> 
   <message> 
       <source>Permanently remove all items from the trash.</source>
<translation>Endferne dauerhafd alle Gegenschdänd aus dem Pabierkorb.</translation>
   </message> 
   <message> 
       <source>There are no items in the trash</source>
<translation>Es sind koi Gegenschdänd im Pabierkorb</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
</context>
<context>
<name>design/admin/content/upload</name>
   <message> 
       <source>Object information</source>
<translation>Objekdinformazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Verwalde Versionen</translation>
   </message> 
   <message> 
       <source>Current draft</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>The file could not be uploaded</source>
<translation>Die Dadei konnde nedd hochgelade werden</translation>
   </message> 
   <message> 
       <source>The following errors occurred</source>
<translation>Die folgende Fehlr drahde auf</translation>
   </message> 
   <message> 
       <source>File upload</source>
<translation>Dadei ubload</translation>
   </message> 
   <message> 
       <source>Choose a file from your local machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
<translation>Wählet Sie oi Dadei vo Ihrem lokale Rechnr und kligget Sie den &quot;Hochladen&quot; Knobf. Es wird oi Objekd gmäß dr Ard dr Dadei erschdelld und an dem gwähle Ord blazierd werde.</translation>
   </message> 
   <message> 
       <source>Upload file</source>
<translation>Dadei hochladen</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>The location where the uploaded file should be placed.</source>
<translation>Dr Ord, an dem d hochgeladene Dadei blazierd werde soll.</translation>
   </message> 
   <message> 
       <source>Automatic</source>
<translation>Audomadisch</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Select the file that you wish to upload.</source>
<translation>Wählet Sie d Dadei aus, d hochgelade werde soll.</translation>
   </message> 
   <message> 
       <source>Upload</source>
<translation>Hochladen</translation>
   </message> 
   <message> 
       <source>Proceed with uploading the selected file.</source>
<translation>Mid dem Hochlade dr ausgewählde Dadei fordfahre.</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Abort the upload operation and go back to where you came from.</source>
<translation>Des Hochlade abbrele und dahin zurüggkehere, wohr Sie komme sind.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/upload_related</name>
   <message> 
       <source>Upload a file and relate it to &lt;%version_name&gt;</source>
<translation>Eine Datei hochladen und mit &lt;%version_name&gt; verknÃ¼pfen</translation>
   </message> 
   <message> 
       <source>This operation allows you to upload a file and add it as a related object.</source>
<translation>Diese Oberazion erlaubd Ihne oi Dadei hochzulade und sie als verknübfds Objekd hinzuzfüge.</translation>
   </message> 
   <message> 
       <source>When the file is uploaded, an object will be created according to the type of the file.</source>
<translation>Wird d Dadei hochgelade, wird oi Objekd gmäß dr Ard dr Dadei erschdelld.</translation>
   </message> 
   <message> 
       <source>The newly created object will be placed within the chosen location.</source>
<translation>Des nei erschdellde Objekd wird am gwählde Ord erschdelld werde.</translation>
   </message> 
   <message> 
       <source>The newly created object will be automatically related to the draft being edited (&lt;%version_name&gt;).</source>
<translation>Das neu erstellte Objekt wird automatisch mit dem gerade in Bearbeitung befindlichen Entwurf (&lt;%version_name&gt;) verknÃ¼pft.</translation>
   </message> 
   <message> 
       <source>Select the file you wish to upload and click the &quot;Upload&quot; button.</source>
<translation>Wählet Sie d Dadei aus, d hochgelade werde soll und kligget Sie noh auf &quot;Hochladen&quot;</translation>
   </message> 
</context>
<context>
<name>design/admin/content/urltranslator</name>
   <message> 
       <source>The destination URL &lt;%destination_url&gt; does not exist in the system.</source>
<translation>Die Ziel-URL &lt;%destination_url&gt; existiert im System nicht.</translation>
   </message> 
   <message> 
       <source>System URL</source>
<translation>Syschdem URL</translation>
   </message> 
   <message> 
       <source>Example: /services</source>
<translation>Beischbiel: /services</translation>
   </message> 
   <message> 
       <source>Example: /content/view/full/42</source>
<translation>Beischbiel: /condend/view/full/42</translation>
   </message> 
   <message> 
       <source>Add</source>
<translation>Hinzfügen</translation>
   </message> 
   <message> 
       <source>Existing virtual URL</source>
<translation>Exischdierend virduelle URL</translation>
   </message> 
   <message> 
       <source>Example: /about/service</source>
<translation>Beischbiel: /aboud/service</translation>
   </message> 
   <message> 
       <source>Example: /developer/*</source>
<translation>Beischbiel: /develober/*</translation>
   </message> 
   <message> 
       <source>Custom URL translations [%alias_count]</source>
<translation>Spezifisch URL Ãberstzungen [%alias_count]</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Forwards to</source>
<translation>Leided weidr auf</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>New system URL forwarding</source>
<translation>Neie Syschdem-URL Weiderleidung</translation>
   </message> 
   <message> 
       <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system.</source>
<translation>Benudzet Sie diess Feld, um oi Adresse reladiv zur Wurzl vom Syschdems oizugebe, d in oi andere URL übersedzd werde soll. Diese Adresse muss nedd in Ihrem akduelle Syschdem exischdiere.</translation>
   </message> 
   <message> 
       <source>Use this field to enter a valid system URL. A system URL is easily recognized since it consists of several parts separated by a &quot;/&quot;.</source>
<translation>Benudzet Sie diess Feld, um oi güldig Syschdem-RUL oizugebe. Eine Syschdem-URL kann oifach dro erkannd werde, dess Sie aus mehrere durch &quot;/&quot; gdrenne Teile beschdehd.</translation>
   </message> 
   <message> 
       <source>Click this button to add a new system URL forwarding. System URL forwarding is used to forward any URL to a system URL in eZ publish.</source>
<translation>Kligget Sie auf diese Knobf, um oi neie Syschdem-URL Weiderleidung hinzuzfüge. Die Syschdem-Url Weiderleidung wird benudzd, um irgendoi URL z oi Syschdem-URL in eZ bublish weiderzuleide.</translation>
   </message> 
   <message> 
       <source>New virtual URL forwarding</source>
<translation>Neie virduelle URL Weiderleidung</translation>
   </message> 
   <message> 
       <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object.</source>
<translation>Benudzet Sie diess Feld, um oi güldig exischdierend URL im Syschdem oizugebe. Eine virduelle URL wird vom Syschdem generierd und enthäld für gwöhnlich Teile vom Inhalds von a Objekds.</translation>
   </message> 
   <message> 
       <source>Click this button to add a new virtual URL forwarding. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish.</source>
<translation>Kligget Sie auf diese Knobf, um oi neie virduelle URL Weiderleidung hinzuzfüge. Eine virduelle URL Weiderleidung wird benudzd, um irgendoi URL z oir exischdierende virduelle URL in eZ bublish weiderzuleide.</translation>
   </message> 
   <message> 
       <source>New virtual URL forwarding with wildcard</source>
<translation>Neie virduelle URL Weiderleidung mid Pladzhalder</translation>
   </message> 
   <message> 
       <source>Redirecting URL</source>
<translation>Umleidend URL</translation>
   </message> 
   <message> 
       <source>Example</source>
<translation>Beischbiel</translation>
   </message> 
   <message> 
       <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system. You can place a star anywhere in the URL which will match an arbitrary number of characters.</source>
<translation>Benudzet Sie diess Feld, um oi Adresse reladiv zur Wurzl vom Syschdems anzugebe, d in oi andere URL überschdzd werde soll. Diese Adresse muss nedd in Ihrem akduelle Syschdem exischdiere. Sie könne oi Schdernle irgendwo in dr URL angebe, dess noh für oi beliabig Anzahl vo Zeile schdehd.</translation>
   </message> 
   <message> 
       <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object. Any characters matched by a star in the source URL can be transfered to the destination URL by inserting {1\} where appropriate.</source>
<translation>Benudzet Sie diess Feld, um oi güldig exischdierend URL im Syschdem oizugebe. Eine virduelle URL wird vom Syschdem generierd und enthäld für gwöhnlich Teile vom Inhalds von a Objekds. Die Zeile, d durch oi Schdernle ersedzd wurde, könne in d URL mid {1\} oigefügd werde.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to select if eZ publish should perform an internal redirect or a browser redirect. An internal redirect simply redirects the old URL to the new one without notifying the browser. A browser redirect makes the browser abort the current request and reload with the new URL. A browser redirect can be useful if you want the browser URL field to be updated.</source>
<translation>Benudzet Sie diess Ankreizfeld, um auzwähle, ob eZ bublish oi inderne odr oi Weiderleidung durch den Browsr mache soll. Eine inderne Weiderleidung leided d alde URL oifach um, ohne den Browsr darübr z informiere. Eine Browser-Weiderleidung sorgd dafür, dess dr Browsr d akduelle ANfrag abbrichd und d neie URL lädd. Eine Browser-Weiderleidung isch noh nüdzlich, wenn des URL-Feld vom Browsers akduallisierd werde soll.</translation>
   </message> 
   <message> 
       <source>Click this button to add a new virtual URL forwarding with wildcard match. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish. The wildcard match is useful if you have moved a complete tree from one place to another.</source>
<translation>Kligget Sie auf diese Knobf, um oi neie virduelle URL Weiderleidung mid Pladzhaldr hinzuzfüge. Eine virduelle URL Weiderleidung wird benudzd, um irgendoi URL z oir exischdierende virduelle URL in eZ bublish weiderzuleide. Dr Pladzhaldr isch nüdzlich, wenn Sie oin kombledde Baum vo oin Pladz an oin andere verschobe hend.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Source URL</source>
<translation>Quell-URL</translation>
   </message> 
   <message> 
       <source>Destination URL</source>
<translation>Ziel-URL</translation>
   </message> 
   <message> 
       <source>Select URL translation for removal.</source>
<translation>URL-Übersedzung zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Wildcard forwarding</source>
<translation>Pladzhaldr Weiderleidung</translation>
   </message> 
   <message> 
       <source>System forwarding</source>
<translation>Syschdem Weiderleidung</translation>
   </message> 
   <message> 
       <source>Virtual forwarding</source>
<translation>Virduelle Weiderleidung</translation>
   </message> 
   <message> 
       <source>There are no custom URL translations.</source>
<translation>Es gibd koi schbezifisch URL-Übersedzung.</translation>
   </message> 
   <message> 
       <source>Remove selected URL translations.</source>
<translation>Die ausgewählde URL-Übersedzunge lösche.</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified any of the fields in the list above.</source>
<translation>Kligget Sie auf diese Knobf, um Änderunge z schbeicheret, falls Sie von a dr Feldr in dr Lischde oberhalb gänderd hend.</translation>
   </message> 
   <message> 
       <source>New virtual URL</source>
<translation>Neie virduelle URL</translation>
   </message> 
   <message> 
       <source>New virtual URL wildcard</source>
<translation>Neie virduelle URL mid Pladzhalder</translation>
   </message> 
</context>
<context>
<name>design/admin/content/versions</name>
   <message> 
       <source>Version not a draft</source>
<translation>Versio isch koi Endwurf</translation>
   </message> 
   <message> 
       <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
<translation>Version %1 ist nicht mehr verfÃ¼gbar zum Ãndern, nur EntwÃ¼rfe kÃ¶nnen geÃ¤ndert werden.</translation>
   </message> 
   <message> 
       <source>To edit this version create a copy of it.</source>
<translation>Um diese Versio z bearbeide erschdellet Sie oi Kobie.</translation>
   </message> 
   <message> 
       <source>Version not yours</source>
<translation>Diese Versio gehörd Ihne nedd</translation>
   </message> 
   <message> 
       <source>Version %1 was not created by you, only your own drafts can be edited.</source>
<translation>Version %1 wurde nicht von Ihnen erstellt. Sie kÃ¶nnen nur Ihre eigenen EntwÃ¼rfe bearbeiten.</translation>
   </message> 
   <message> 
       <source>Unable to create new version</source>
<translation>Neie Versio kann nedd erschdelld werden</translation>
   </message> 
   <message> 
       <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
<translation>Dr Versionsverlauf hedd soi Limid erreichd und koi archivierde Versio kann vom Syschdem endfernd werde.</translation>
   </message> 
   <message> 
       <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
<translation>Sie könne d Einschdellunge vom Versionsverlaufs im condend.ini änderet, Endwürf lösche odr beschdehend Endwürf änderet.</translation>
   </message> 
   <message> 
       <source>Versions for &lt;%object_name&gt; [%version_count]</source>
<translation>Versionen fÃ¼r &lt;%object_name&gt; [%version_count]</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Creator</source>
<translation>Erschdeller</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Draft</source>
<translation>Endwurf</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Pending</source>
<translation>Schwebend</translation>
   </message> 
   <message> 
       <source>Archived</source>
<translation>Archivierd</translation>
   </message> 
   <message> 
       <source>Rejected</source>
<translation>Abgelehnd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Object information</source>
<translation>Objekdinformazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Veränderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Select version #%version_number for removal.</source>
<translation>Version #%version_number zum Entfernen auswÃ¤hlen.</translation>
   </message> 
   <message> 
       <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
<translation>Version #%version_number kann nicht entfernt werden, da sie entweder die verÃ¶ffentlichte Version ist oder weil Sie keine Rechte besitzen sie zu entfernen.</translation>
   </message> 
   <message> 
       <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
<translation>Die Inhalte von Version #%version_number anzeigen. Standard Ãbersetzung: %default_translation.</translation>
   </message> 
   <message> 
       <source>View the contents of version #%version_number. Translation: %translation.</source>
<translation>Den Inhalt der Version #%version_number ansehen. Ãbersetzung: %translation.</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Create a copy of version #%version_number.</source>
<translation>Eine Kopie von Version #%version_number erstellen.</translation>
   </message> 
   <message> 
       <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
<translation>Sie könne koi Kobie vo Versione erschdelle, da Sie koi Rechde besidze des Objekd z bearbeide.</translation>
   </message> 
   <message> 
       <source>Edit the contents of version #%version_number.</source>
<translation>Die Inhalte von Version #%version_number berabeiten.</translation>
   </message> 
   <message> 
       <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
<translation>Sie kÃ¶nnen die Inhalte von Version #%version_number nicht bearbeiten, da es kein Entwurf ist oder weil Sie keine Rechte besitzen das Objekt zu bearbeiten.</translation>
   </message> 
   <message> 
       <source>This object does not have any versions.</source>
<translation>Des Objekd hedd koi Versione.</translation>
   </message> 
   <message> 
       <source>Remove the selected versions from the object.</source>
<translation>Die ausgewählde Versione vom Objekd endferne.</translation>
   </message> 
</context>
<context>
<name>design/admin/content/view/versionview</name>
   <message> 
       <source>Object information</source>
<translation>Objekdinformazion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>Manage versions</source>
<translation>Versione verwalden</translation>
   </message> 
   <message> 
       <source>View and manage (copy, delete, etc.) the versions of this object.</source>
<translation>Versione vom derzeidige Objekds ansehe und verwalde (hinzfügen/endferne).</translation>
   </message> 
   <message> 
       <source>You can not manage the versions of this object because there is only one version available (the one that is being displayed).</source>
<translation>Sie könne d Versione diess Objekds nedd verwalde, des nur oi Versio verfügbar isch (die, d gerad angezeigd wird).</translation>
   </message> 
   <message> 
       <source>Version information</source>
<translation>Versionsinformazion</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Draft</source>
<translation>Endwurf</translation>
   </message> 
   <message> 
       <source>Published / current</source>
<translation>Veröffendlichd / akduell</translation>
   </message> 
   <message> 
       <source>Pending</source>
<translation>Schwebend</translation>
   </message> 
   <message> 
       <source>Archived</source>
<translation>Archivierd</translation>
   </message> 
   <message> 
       <source>Rejected</source>
<translation>Abgelehnd</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>View control</source>
<translation>Ansichdskondolle</translation>
   </message> 
   <message> 
       <source>Translation</source>
<translation>Übersedzung</translation>
   </message> 
   <message> 
       <source>%1 (No locale information available)</source>
<translation>%1 (Koi lokale Informazione verfügbar)</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Update view</source>
<translation>Ansichd akdualisieren</translation>
   </message> 
   <message> 
       <source>View the version that is currently being displayed using the selected language, location and design.</source>
<translation>Die akduelle Versio undr Verwendung dr ausgewählde Schbrache, Ord und Design anzeige.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the draft that is being displayed.</source>
<translation>De Endwurf bearbeide, dr gerad angezeigd wird.</translation>
   </message> 
   <message> 
       <source>This version is not a draft and thus it can not be edited.</source>
<translation>Die Versio isch koi Endwurf und kann dahr nedd bearbeided werde.</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
</context>
<context>
<name>design/admin/contentstructuremenu</name>
   <message> 
       <source>Fold/Unfold</source>
<translation>Minimieren/Maximieren</translation>
   </message> 
   <message> 
       <source>[%classname] Click on the icon to get a context sensitive menu.</source>
<translation>[%classname] Klicke auf das Icon, um ein context-sensitives MenÃ¼ zu erhalten.</translation>
   </message> 
</context>
<context>
<name>design/admin/error/kernel</name>
   <message> 
       <source>The requested page could not be displayed. (1)</source>
<translation>Die angeforderde Seide konnde nedd angezeigd werde. (1)</translation>
   </message> 
   <message> 
       <source>The system is unable to display the requested page because of security issues.</source>
<translation>Des Syschdem konnde d angeforderde Seide aufgrund vo Sicherheidsbedenke nedd anzeige.</translation>
   </message> 
   <message> 
       <source>Possible reasons</source>
<translation>Mögliche Gründe</translation>
   </message> 
   <message> 
       <source>Your account does not have the proper privileges to access the requested page.</source>
<translation>Ihr Benudzerkondo hedd nedd d nodwendige Privilegie um Zugriff auf d angeforderde Seide z erhalde.</translation>
   </message> 
   <message> 
       <source>You are not logged into the system. Please log in.</source>
<translation>Sie sind nedd am Syschdem angemelded. Bidde holet Sie des nach.</translation>
   </message> 
   <message> 
       <source>The requested page does not exist. Try changing the URL.</source>
<translation>Die angeforderde Seide exischdierd nedd. Versuchet Sie d Adresse z änderet.</translation>
   </message> 
   <message> 
       <source>The following permission setting is required</source>
<translation>Die folgende Zugangsoischdellunge sind nödig</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Click the &quot;Log in&quot; button in order to log in.</source>
<translation>Kligget Sie auf &quot;Anmelden&quot; um si anzumelde.</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Anmelden</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (2)</source>
<translation>Die angeforderde Seide konnde nedd angezeigd werde. (2)</translation>
   </message> 
   <message> 
       <source>The resource you requested was not found.</source>
<translation>Ihre angeforderde Ressource wurd nedd funde.</translation>
   </message> 
   <message> 
       <source>The ID number or the name of the resource was misspelled. Try changing the URL.</source>
<translation>Die ID Nummr odr dr Nam dr Ressource wurd falsch gschriabe. Versuchet Sie d Adresse z änderet.</translation>
   </message> 
   <message> 
       <source>The resource is no longer available.</source>
<translation>Die Ressource isch nedd längr verfügbar.</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (20)</source>
<translation>Die angeforderde Seide konnde nedd angezeigd werde. (20)</translation>
   </message> 
   <message> 
       <source>The requested address or module could not be found.</source>
<translation>Die angeforderde Adresse odr des Modul konnde nedd funde werde.</translation>
   </message> 
   <message> 
       <source>The address was misspelled. Try changing the URL.</source>
<translation>Die Adresse wurd falsch gschriabe. Versuchet Sie d URL z änderet.</translation>
   </message> 
   <message> 
       <source>The name of the module was misspelled. Try changing the URL.</source>
<translation>Dr Nam vom Moduls wurd falsch gschriabe. Versuchet Sie d Adresse z änderet.</translation>
   </message> 
   <message> 
       <source>There is no &lt;%module&gt; module available on this site.</source>
<translation>Es ist kein &lt;%module&gt; Modul auf dieser Seite verfÃ¼gbar.</translation>
   </message> 
   <message> 
       <source>The site is using URL matching to determine which siteaccess to use, but the name of the siteaccess is missing from the URL. Try to add the name of the siteaccess, it should be specified before the name of the module.</source>
<translation>Diese Seide benudzd oin URL-Abgleich um herauszfinde, wo Seidenzugang verwended wird, abr dr Nam vom Zugangs wurd nedd gsedzd. Versuchet Sie den Name vom Seidenzugangs z ergänze. Er sollde vor dem Name vom Moduls in dr Adresse definierd werde.</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (21)</source>
<translation>Die angeforderde Seide konnde nedd angezeigd werde. (21)</translation>
   </message> 
   <message> 
       <source>The requested view &lt;%view&gt; could not be found in the &lt;%module&gt; module.</source>
<translation>Die angeforderte Ansicht &lt;%view&gt; konnte im Modul &lt;%module&gt; nicht gefunden werden.</translation>
   </message> 
   <message> 
       <source>The name of the view was misspelled. Try changing the URL.</source>
<translation>Dr Nam dr Ansichd wurd falsch gschriabe. Versuchet Sie d Adresse z änderet.</translation>
   </message> 
   <message> 
       <source>The &lt;%module&gt; module does not have a &lt;%view&gt; view.</source>
<translation>Das Modul &lt;%module&gt; besitzt die Ansicht &lt;%view&gt; nicht.</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (22)</source>
<translation>Die angeforderde Seide konnde nedd angezeigd werde. (22)</translation>
   </message> 
   <message> 
       <source>The requested view can not be accessed.</source>
<translation>Die angeforderde Sichd kann nedd bedrede werde.</translation>
   </message> 
   <message> 
       <source>The &lt;%view&gt; within the &lt;%module&gt; is disabled and thus it can not be accessed.</source>
<translation>&lt;%view&gt; innherhalb &lt;%module&gt; ist deaktiviert und ist daher nicht zugÃ¤nglich.</translation>
   </message> 
   <message> 
       <source>The requested module can not be accessed.</source>
<translation>Des angeforderde Modul kann nedd bedrede werde.</translation>
   </message> 
   <message> 
       <source>The &lt;%module&gt; module is disabled and thus it can not be accessed.</source>
<translation>Das Modul &lt;%module&gt; ist deaktiviert und ist daher nicht zugÃ¤nglich.</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (3)</source>
<translation>Die angeforderde Seide kann nedd angezeigd werde. (3)</translation>
   </message> 
   <message> 
       <source>The requested object is not available.</source>
<translation>Des angeforderde Objekd isch nedd verfügbar.</translation>
   </message> 
   <message> 
       <source>The ID number of the object is incorrect. Please check the URL for spelling mistakes.</source>
<translation>Die ID Nummr vom Objekds isch falsch. Bidde überbrüfet Sie d Adresse.</translation>
   </message> 
   <message> 
       <source>The object is no longer available.</source>
<translation>Des Objekd isch nemme verfügbar.</translation>
   </message> 
   <message> 
       <source>The requested page could not be displayed. (4)</source>
<translation>Die angeforderde Seide kann nedd angezeigd werde. (4)</translation>
   </message> 
   <message> 
       <source>The requested object has been moved and thus it is no longer available at the specified address.</source>
<translation>Des angeforderde Objekd wurd verschobe und isch dahr undr dr angegebene Adresse nemme verfügbar.</translation>
   </message> 
   <message> 
       <source>The system should automatically redirect you to the new location of the object.</source>
<translation>Des Syschdem sollde audomadisch zur neie Adresse vom Objekds weiderleide.</translation>
   </message> 
   <message> 
       <source>If redirection fails, please click on the following address: %url.</source>
<translation>Falls die Weiterleitung fehlschlÃ¤gt, klicken Sie bitte auf die folgende Adresse: %url.</translation>
   </message> 
</context>
<context>
<name>design/admin/error/shop</name>
   <message> 
       <source>Not a product. (1)</source>
<translation>Isch koi Produkd. (1)</translation>
   </message> 
   <message> 
       <source>The requested object is not a product and cannot be used by the shop module..</source>
<translation>Des angefordede Objekd isch koi Produkd und kann dahr nedd vom Shob Modul genudzd werde.</translation>
   </message> 
</context>
<context>
<name>design/admin/infocollector/collectionlist</name>
   <message> 
       <source>Information collected by &lt;%object_name&gt; [%collection_count]</source>
<translation>Informationen gesammelt von &lt;%object_name&gt; [%collection_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Collection ID</source>
<translation>ID dr Sammlung</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Select collected information for removal.</source>
<translation>Gesammelde Infromazione zum endferne auswähle.</translation>
   </message> 
   <message> 
       <source>No information has been collected by this object.</source>
<translation>Vo dem Objekd wurde koi Informazione gsammeld.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove selected collection.</source>
<translation>Ausgewählde Sammlung endferne.</translation>
   </message> 
</context>
<context>
<name>design/admin/infocollector/confirmremoval</name>
   <message> 
       <source>Confirm information collection removal</source>
<translation>Beschdädiget Sie des Endferne dr gsammelde Informazione.</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the collected information?</source>
<translation>Sind Sie sichr, dess Sie d gsammelde Informazione endferne wolle?</translation>
   </message> 
   <message> 
       <source>%collections collection will be removed.</source>
<translation>%colleczions Sammlung werde endfernd.</translation>
   </message> 
   <message> 
       <source>%collections collections will be removed.</source>
<translation>%colleczions Sammlunge werde endfernd.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/infocollector/overview</name>
   <message> 
       <source>Objects that have collected information [%object_count]</source>
<translation>Objekte mit gesammelten Informationen [%object_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>First collection</source>
<translation>Erschde Sammlung</translation>
   </message> 
   <message> 
       <source>Last collection</source>
<translation>Ledzde Sammlung</translation>
   </message> 
   <message> 
       <source>Collections</source>
<translation>Sammlungen</translation>
   </message> 
   <message> 
       <source>Select collections for removal.</source>
<translation>Sammlunge zum endferne auswähle.</translation>
   </message> 
   <message> 
       <source>section</source>
<translation>sekzion</translation>
   </message> 
   <message> 
       <source>There are no objects that have collected any information.</source>
<translation>Es gibd koi Objekde, d irgendwo Informazione gsammeld hend.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove all information that was collected by the selected objects.</source>
<translation>Alle Informazione endferne, d vo den ausgewählde Objekde gsammeld wurde.</translation>
   </message> 
</context>
<context>
<name>design/admin/infocollector/view</name>
   <message> 
       <source>Collection #%collection_id for &lt;%object_name&gt;</source>
<translation>Sammlung #%collection_id von &lt;%object_name&gt;</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Remove collection.</source>
<translation>Sammlung endfernen</translation>
   </message> 
</context>
<context>
<name>design/admin/navigator</name>
   <message> 
       <source>Previous</source>
<translation>Zurügg</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Vor</translation>
   </message> 
</context>
<context>
<name>design/admin/node/removenode</name>
   <message> 
       <source>Remove node?</source>
<translation>Knode endferne?</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove %1 from node %2?</source>
<translation>Sind Sie sicher, dass Sie %1 von Knoten %2 entfernen wollen?</translation>
   </message> 
   <message> 
       <source>Removing this assignment will also remove its %1 children.</source>
<translation>Das Entfernen dieser Zuordnung wird auch seine %1 Kinder entfernen.</translation>
   </message> 
   <message> 
       <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
<translation>Die endfernde Knode könne au schbädr zurügggehold werde. Sie finde diese im Pabierkorb.</translation>
   </message> 
   <message> 
       <source>Removing node assignment of %1</source>
<translation>Knotenzuweisung von %1 wird entfernt</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Note</source>
<translation>Hinweis</translation>
   </message> 
</context>
<context>
<name>design/admin/node/removeobject</name>
   <message> 
       <source>Confirm location removal</source>
<translation>Beschdädige dr Löschung von a Ordes</translation>
   </message> 
   <message> 
       <source>Insufficient permissions</source>
<translation>Unzureichend Rechde</translation>
   </message> 
   <message> 
       <source>Some of the items that are about to be removed contain sub items.</source>
<translation>Einig Elemnde, d endfernd werde solle, enthalde Underelemende.</translation>
   </message> 
   <message> 
       <source>Removing the items will also result in the removal of their sub items.</source>
<translation>Endferne dr Elemende wird au d Underelemende endferne.</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the items along with their contents?</source>
<translation>Sind Sie sichr, dess Sie d Elemende zsamme mid Ihre Inhalde endferne wolle?</translation>
   </message> 
   <message> 
       <source>The lines marked with red contain items that you do not have permissions to remove.</source>
<translation>Die rod markierde Zeile enthalde Elemende d Sie aufgrund fehlendr Rechde nedd endferne könne.</translation>
   </message> 
   <message> 
       <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
<translation>Kligget Sie auf &quot;Abbruch&quot; und versuchet Sie, nur d Orde z endferne, d Sie endferne dürfe.</translation>
   </message> 
   <message> 
       <source>Item</source>
<translation>Eindrag</translation>
   </message> 
   <message> 
       <source>Sub items</source>
<translation>Undergeordnede Eindräge</translation>
   </message> 
   <message> 
       <source>Move to trash</source>
<translation>Verschiab in den Pabierkorb</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
<translation>Sie könne nedd fordfahre, da Ihne d Berechdigung fehld, oiig dr ausgewählde Orde z endferne.</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Cancel the removal of locations.</source>
<translation>Des Endferne vo Orde abbrele.</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>If &quot;Move to trash&quot; is checked, the items will be moved to the trash instead of being permanently deleted.</source>
<translation>Falls &quot;Verschiab in den Pabierkorb&quot; angewähld isch, werde d Elemende in den Pabierkorb verschobe, anschdelle dess sie bermanend glöschd werde.</translation>
   </message> 
</context>
<context>
<name>design/admin/node/view</name>
   <message> 
       <source>Two level index for &lt;%node_name&gt;</source>
<translation>Ãbersicht Ã¼ber zwei Ebenen fÃ¼r &lt;%node_name&gt;</translation>
   </message> 
</context>
<context>
<name>design/admin/node/view/full</name>
   <message> 
       <source>Hide preview of content.</source>
<translation>Inhalds-Vorschau ausblende.</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>Show preview of content.</source>
<translation>Inhalds-Vorschau oiblende.</translation>
   </message> 
   <message> 
       <source>Hide available translations.</source>
<translation>Verfügbare Übersedzunge ausblende.</translation>
   </message> 
   <message> 
       <source>Show available translations.</source>
<translation>Verfügbare Übersedzunge oiblende.</translation>
   </message> 
   <message> 
       <source>Hide location overview.</source>
<translation>Ords-Übersichd ausblende.</translation>
   </message> 
   <message> 
       <source>Locations</source>
<translation>Orde</translation>
   </message> 
   <message> 
       <source>Show location overview.</source>
<translation>Ords-Übersichd oiblende.</translation>
   </message> 
   <message> 
       <source>Hide relation overview.</source>
<translation>Verwandschafds-Übersichd ausblende.</translation>
   </message> 
   <message> 
       <source>Relations</source>
<translation>Relazionen</translation>
   </message> 
   <message> 
       <source>Show relation overview.</source>
<translation>Verwandschafds-Übersichd oiblende.</translation>
   </message> 
   <message> 
       <source>Hide role overview.</source>
<translation>Rollen-Übersichd ausblende.</translation>
   </message> 
   <message> 
       <source>Roles</source>
<translation>Rollen</translation>
   </message> 
   <message> 
       <source>Show role overview.</source>
<translation>Rollen-Übersichd oiblende.</translation>
   </message> 
   <message> 
       <source>Hide policy overview.</source>
<translation>Richdlinien-Übersichd ausblende.</translation>
   </message> 
   <message> 
       <source>Policies</source>
<translation>Richdlinien</translation>
   </message> 
   <message> 
       <source>Show policy overview.</source>
<translation>Richdlinien-Übersichd oiblende.</translation>
   </message> 
   <message> 
       <source>Up one level</source>
<translation>Eine Ebene no oben</translation>
   </message> 
   <message> 
       <source>Sub items [%children_count]</source>
<translation>Untergeordnete EintrÃ¤ge [%children_count]</translation>
   </message> 
   <message> 
       <source>The current item does not contain any sub items.</source>
<translation>Dr akduelle Eindrag hedd koi undergeordnede Eindräg.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove the selected items from the list above.</source>
<translation>Die ausgewählde Elemende vo obigr Lischde endferne.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to remove any of the items from the list above.</source>
<translation>Sie hend nedd d erforderlile Rechde d Elemende vo obigr Lischde z endferne.</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde schbeichern</translation>
   </message> 
   <message> 
       <source>Apply changes to the priorities of the items in the list above.</source>
<translation>Änderunge dr Prioridäde dr Eindräg in dr obige Lischde schbeicheret.</translation>
   </message> 
   <message> 
       <source>You can not update the priorities because you do not have permissions to edit the current item or because a non-priority sorting method is used.</source>
<translation>Sie könne d Prioridäde nedd akdualisiere, da Sie nedd d nodwendige Rechde besidze des akduelle Elemend z bearbeide odr weil oi nedd-Prioridäde Sordiermethod verwended wird.</translation>
   </message> 
   <message> 
       <source>Create here</source>
<translation>Hir erschdellen</translation>
   </message> 
   <message> 
       <source>Create a new item within the current location. Use the menu on the left to select the type of the item.</source>
<translation>Ein neis Elemend am akduelle Ord erschdelle. Benudzet Sie des Menü links um d Ard vom Elemends auszwähle.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to create new items within the current location.</source>
<translation>Sie hend nedd d nodwendige Rechde um am akduelle Ord neie Elemende z erschdelle.</translation>
   </message> 
   <message> 
       <source>Depth</source>
<translation>Tiefe</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>You can not set the sorting method for the current location because you do not have permissions to edit the current item.</source>
<translation>Sie könne d Sordierungsmethod für den akduelle Ord nedd änderet, weil Sie koi Rechde hend des akduelle Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Use the priority fields to control the order in which the items appear. Use positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
<translation>Benudzet Sie d Prioridädsfeldr, um d Reihenfolg in dr d Elemnde erschoin z änderet. Benudzet Sie bosididve und negadive Ganzzahle. Kligget Sie auf &quot;Prioridäde schbeichern&quot; um d Änderunge z schbeicheret..</translation>
   </message> 
   <message> 
       <source>You are not allowed to update the priorities because you do not have permissions to edit &lt;%node_name&gt;.</source>
<translation>Sie dÃ¼rfen die aktuellen PrioritÃ¤ten nicht Ã¤ndern, weil Sie keine Rechte besitzen  &lt;%node_name&gt; zu bearbeiten.</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Create a copy of &lt;%child_name&gt;.</source>
<translation>Eine Kopie von &lt;%child_name&gt; erstellen.</translation>
   </message> 
   <message> 
       <source>You can not make a copy of &lt;%child_name&gt; because you do not have create permissions for &lt;%node_name&gt;.</source>
<translation>Sie kÃ¶nnen keine Kopie von &lt;%child_name&gt; anlegen, da Sie keine Rechte zum Erstellen auf &lt;%node_name&gt; haben.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit &lt;%child_name&gt;.</source>
<translation>&lt;%child_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
<translation>Sie haben keine Rechte &lt;%child_name&gt; zu bearbeiten.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to edit %child_name.</source>
<translation>Sie haben keine Rechte %child_name zu bearbeiten.</translation>
   </message> 
   <message> 
       <source>Creator</source>
<translation>Erschdeller</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Node ID</source>
<translation>Knode ID</translation>
   </message> 
   <message> 
       <source>Object ID</source>
<translation>Objekd ID</translation>
   </message> 
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Sorting</source>
<translation>Sordierung</translation>
   </message> 
   <message> 
       <source>Main</source>
<translation>Haubd-Ord</translation>
   </message> 
   <message> 
       <source>up</source>
<translation>nuff</translation>
   </message> 
   <message> 
       <source>down</source>
<translation>raa</translation>
   </message> 
   <message> 
       <source>Remove selected locations from the list above.</source>
<translation>Die ausgewählde Elemende aus obigr Lischde endferne.</translation>
   </message> 
   <message> 
       <source>You can not remove any locations because you do not have permissions to edit the current item.</source>
<translation>Sie könne koin Ord endferne, da Sie nedd des Rechd besidze des akduelle Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>You can not add new locations because you do not have permissions to edit the current item.</source>
<translation>Sie könne koi neie Orde hinzfüge, da Sie koi Rechde besidze des akduelle Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>Set main</source>
<translation>Als Haubd sedzen</translation>
   </message> 
   <message> 
       <source>You can not set the main location because you do not have permissions to edit the current item.</source>
<translation>Sie könne den Haubdord nedd sedze, da Sie koi Rechd besidze des akduelle Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>You do not have permissions to edit this item.</source>
<translation>Sie hend nedd d nodwendige Rechde diess Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>Move</source>
<translation>Verschiaben</translation>
   </message> 
   <message> 
       <source>Move this item to another location.</source>
<translation>Diese Eindrag z oim andere Ord verschiabe.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to move this item to another location.</source>
<translation>Sie hend nedd d erforderlile Rechde diess Elemend an oin andere Ord z verschiabe.</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Remove this item.</source>
<translation>Diese Eindrag endferne.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to remove this item.</source>
<translation>Sie besidze nedd d nodwendige Rechde diess Elemend z endferne.</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Limitation</source>
<translation>Einschränkung</translation>
   </message> 
   <message> 
       <source>all modules</source>
<translation>alle Module</translation>
   </message> 
   <message> 
       <source>all functions</source>
<translation>alle Funkzionen</translation>
   </message> 
   <message> 
       <source>There are no available policies.</source>
<translation>Es gibd koi verfügbare Richdlinie.</translation>
   </message> 
   <message> 
       <source>Related objects [%related_objects_count]</source>
<translation>VerknÃ¼pfte Objekte [%related_objects_count]</translation>
   </message> 
   <message> 
       <source>The item being viewed does not make use of any other objects.</source>
<translation>Dr akduelle Eindrag benudzd koi weidere Objekde.</translation>
   </message> 
   <message> 
       <source>Reverse related objects</source>
<translation>Umgekehrd verwandde Objekde</translation>
   </message> 
   <message> 
       <source>The item being viewed is not in use by any other objects.</source>
<translation>Dr akduelle Eindrag wird nedd vo andere Objekde verwended.</translation>
   </message> 
   <message> 
       <source>Assigned roles [%roles_count]</source>
<translation>Zugewiesene Rollen [%roles_count]</translation>
   </message> 
   <message> 
       <source>No limitation</source>
<translation>Koi Einschränkung</translation>
   </message> 
   <message> 
       <source>Edit role.</source>
<translation>Rolle bearbeide.</translation>
   </message> 
   <message> 
       <source>There are no assigned roles.</source>
<translation>Es gibd koi zugewiesene Rolle.</translation>
   </message> 
   <message> 
       <source>Hide details.</source>
<translation>Dedails ausblende.</translation>
   </message> 
   <message> 
       <source>Details</source>
<translation>Dedails</translation>
   </message> 
   <message> 
       <source>Show details.</source>
<translation>Dedails oiblende.</translation>
   </message> 
   <message> 
       <source>Up one level.</source>
<translation>Eine Ebene no obe.</translation>
   </message> 
   <message> 
       <source>Show 10 items per page.</source>
<translation>10 Eindräg bro Seide anzeige.</translation>
   </message> 
   <message> 
       <source>Show 50 items per page.</source>
<translation>50 Eindräg bro Seide anzeige.</translation>
   </message> 
   <message> 
       <source>Show 25 items per page.</source>
<translation>25 Eindräg bro Seide anzeige.</translation>
   </message> 
   <message> 
       <source>Display sub items using a simple list.</source>
<translation>Underelemende anzeige undr Verwendung oir oifache Lischde.</translation>
   </message> 
   <message> 
       <source>List</source>
<translation>Lischde</translation>
   </message> 
   <message> 
       <source>Thumbnail</source>
<translation>Miniaduransichd</translation>
   </message> 
   <message> 
       <source>Display sub items using a detailed list.</source>
<translation>Underelemende undr Verwendung oi ausführlile Lischde anzeige.</translation>
   </message> 
   <message> 
       <source>Detailed</source>
<translation>Dedaillierd</translation>
   </message> 
   <message> 
       <source>Display sub items as thumbnails.</source>
<translation>Underelemende als Miniaduransichde zeige.</translation>
   </message> 
   <message> 
       <source>Use this menu to select the type of item you wish to create and click the &quot;Create here&quot; button. The item will be created within the current location.</source>
<translation>Benudzet Sie diess Menü, um d Ard vom Elemends auzwähle, des erschdelld werde soll. Kligget Sie anschließend auf  &quot;Hir erschdellen&quot;. Des Elemend wird am akduelle Ord erschdelld werde.</translation>
   </message> 
   <message> 
       <source>Not available</source>
<translation>Nedd verfügbar</translation>
   </message> 
   <message> 
       <source>Class identifier</source>
<translation>Klassen-Idendifikador</translation>
   </message> 
   <message> 
       <source>Class name</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Use these controls to set the sorting method for the sub items of the current location.</source>
<translation>Benudzet Sie diese Kondrolle um d Sordiermethod für Underelemende vom akduelle Ords z sedze.</translation>
   </message> 
   <message> 
       <source>Descending</source>
<translation>Abschdeigend</translation>
   </message> 
   <message> 
       <source>Ascending</source>
<translation>Aufschdeigend</translation>
   </message> 
   <message> 
       <source>Visibility</source>
<translation>Sichdbarkeid</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
<translation>Benudzet Sie d Ankreizfeldr um Elemde zum Endferne auszwähle. Kligget Sie auf &quot;Ausgewählde endfernen&quot; um d ausgewählde Elemende z endferne.</translation>
   </message> 
   <message> 
       <source>Move &lt;%child_name&gt; to another location.</source>
<translation>&lt;%child_name&gt; an einen anderen Ort verschieben.</translation>
   </message> 
   <message> 
       <source>You do not have permissions remove this item.</source>
<translation>Sie hend koi Rechde des Elemend z endferne.</translation>
   </message> 
   <message> 
       <source>Locations [%locations]</source>
<translation>Orte [%locations]</translation>
   </message> 
   <message> 
       <source>Sub items</source>
<translation>Undergeordnede Eindräge</translation>
   </message> 
   <message> 
       <source>This location can not be removed either because you do not have permissions to remove it or because it is currently being displayed.</source>
<translation>Diesr Ord kann nedd endfernd werde, da Sie endwedr koi Rechde daz besidze odr weil des s gerad angezeigd wird.</translation>
   </message> 
   <message> 
       <source>Select location for removal.</source>
<translation>Ord zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Hidden</source>
<translation>Verschdeggd</translation>
   </message> 
   <message> 
       <source>Make location and all sub items visible.</source>
<translation>Diese Ord und alle undergeordnede Eindräg sichdbar mache.</translation>
   </message> 
   <message> 
       <source>Reveal</source>
<translation>Aufdeggen</translation>
   </message> 
   <message> 
       <source>Hidden by superior</source>
<translation>Vom übergeordnede Elemend verschdeggd</translation>
   </message> 
   <message> 
       <source>Hide location and all sub items.</source>
<translation>Ord und undergeordnede Eindräg ausblende.</translation>
   </message> 
   <message> 
       <source>Hide</source>
<translation>Verschdeggen</translation>
   </message> 
   <message> 
       <source>Visible</source>
<translation>Sichdbar</translation>
   </message> 
   <message> 
       <source>Use these radio buttons to select the desired main location.</source>
<translation>benudzet Sie diese Radio-Buddons um den gwünschde Haubdord auszwähle.</translation>
   </message> 
   <message> 
       <source>The item being displayed has only one location and thus it does not make sense to set it.</source>
<translation>Des Elemend, des gerad angezeigd wird, hedd nur oin Ord. Es machd dahr koin Sinn ihn z sedze.</translation>
   </message> 
   <message> 
       <source>You can not set the main location because you do not have permissions to edit the item being displayed.</source>
<translation>Sie könne den Haubdord nedd sedze, da Sie koi Rechde besidze des angezeigde Elemend z bearbeide.</translation>
   </message> 
   <message> 
       <source>Add locations</source>
<translation>Orde hinzfügen</translation>
   </message> 
   <message> 
       <source>Add one or more new locations.</source>
<translation>Eine odr mehr Orde hinzfügen</translation>
   </message> 
   <message> 
       <source>It is not possible to add locations to a top level node.</source>
<translation>Es isch nedd möglich Orde z oim oberschde Knodenbunkd hinzuzfüge.</translation>
   </message> 
   <message> 
       <source>Select the desired main location using the radio buttons above and click this button to store the setting.</source>
<translation>Wählet Sie den Haubdord undr Benudzung dr Radio-Buddons aus und kligget Sie auf diese Knobf um d Einschdellung z schbeicheret.</translation>
   </message> 
   <message> 
       <source>You can not set the main location because there is only one location present.</source>
<translation>Sie könne den Haubdord nedd sedzde, da nur oi Ord vorhande isch.</translation>
   </message> 
   <message> 
       <source>The &lt;%class_name&gt; class is not configured to contain any sub items.</source>
<translation>Die Klasse &lt;%class_name&gt; ist nicht konfiguriert Unterelmente zu enthalten.</translation>
   </message> 
   <message> 
       <source>Edit the contents of this item.</source>
<translation>De Inhald diess Eindrags bearbeide.</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>No limitations</source>
<translation>Koi Einschränkungen</translation>
   </message> 
   <message> 
       <source>Relations [%relation_count]</source>
<translation>Relationen  [%relation_count]</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Translations [%translations]</source>
<translation>Ãbersetzungen [%translations]</translation>
   </message> 
   <message> 
       <source>View translation.</source>
<translation>Bedrachde Übersedzung.</translation>
   </message> 
   <message> 
       <source>Hide object relation overview.</source>
<translation>Übersichd übr Objekdverwanddschafde ausblenden</translation>
   </message> 
   <message> 
       <source>Show object relation overview.</source>
<translation>Übersichd übr Objekdverwanddschafde oiblenden</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>The information could not be collected.</source>
<translation>Die Informazion konnde nedd gsammeld werde.</translation>
   </message> 
   <message> 
       <source>Required data is either missing or is invalid</source>
<translation>Nodwendig Dade fehle odr sind ungüldig</translation>
   </message> 
   <message> 
       <source>There is no removable location.</source>
<translation>Es gibd koin Ord, dr endfernd werde könnde.</translation>
   </message> 
   <message> 
       <source>Available policies [%policy_count]</source>
<translation>VerfÃ¼gbare Richtlinien [%policy_count]</translation>
   </message> 
   <message> 
       <source>limited to %limitation_identifier %limitation_value</source>
<translation>beschrÃ¤nkt auf %limitation_identifier %limitation_value</translation>
   </message> 
</context>
<context>
<name>design/admin/node/view/line</name>
   <message> 
       <source>Click on the icon to get a context sensitive menu.</source>
<translation>Für oi Kondexd-Menu, kligget Sie auf des Ico.</translation>
   </message> 
   <message> 
       <source>Node ID: %node_id Visibility: %node_visibility</source>
<translation>Node ID: %node_id Visibility: %node_visibility</translation>
   </message> 
</context>
<context>
<name>design/admin/node/view/thumbnail</name>
   <message> 
       <source>[%classname] Click on the icon to get a context sensitive menu.</source>
<translation>[%classname] FÃ¼r ein Kontext-Menu, klicken Sie auf das Icon.</translation>
   </message> 
</context>
<context>
<name>design/admin/notification/addingresult</name>
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Add to my notifications</source>
<translation>Zu Benachrichdunge hinzfügen</translation>
   </message> 
   <message> 
       <source>Notification for node &lt;%node_name&gt; already exists.</source>
<translation></translation>
   </message> 
   <message> 
       <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/admin/notification/collaboration</name>
   <message> 
       <source>Collaboration notification</source>
<translation>Kollaborazions- Benachrichdigung</translation>
   </message> 
   <message> 
       <source>Choose which collaboration items you wish to get notifications for.</source>
<translation>Wählet Sie, für wo Kollaborazionelemende Sie Benachrichdigunge bekomme möchde.</translation>
   </message> 
</context>
<context>
<name>design/admin/notification/handler/ezgeneraldigest/settings/edit</name>
   <message> 
       <source>Receive all messages combined in one digest</source>
<translation>Alle Nachrichde in oir Zusammenfassung erhalden</translation>
   </message> 
   <message> 
       <source>Daily, at</source>
<translation>Täglich um</translation>
   </message> 
   <message> 
       <source>Once per week, on</source>
<translation>Einmol bro Woche um</translation>
   </message> 
   <message> 
       <source>If day number is larger than the number of days within the current month, the last day of the current month will be used.</source>
<translation>Sollde d Zahl vom Tags größr soi, als d Anzahl dr Tag vom akduelle Monads, so wird dr ledzde Tag vom akduelle Monads benudzd werde.</translation>
   </message> 
   <message> 
       <source>Receive digests</source>
<translation>Kurzfassung embfangen</translation>
   </message> 
   <message> 
       <source>Once per month, on day number</source>
<translation>Einmol bro Monad an oim  oim Tag</translation>
   </message> 
</context>
<context>
<name>design/admin/notification/handler/ezsubtree/settings/edit</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>My item notifications [%notification_count]</source>
<translation>Meine Benachrichtigungen Ã¼ber Elemente [%notification_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select item for removal.</source>
<translation>Elemend zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>You have not subscribed to receive notifications about any items.</source>
<translation>Sie hend koi Benachrichdigunge übr irgendoi Elemend beschdelld.</translation>
   </message> 
   <message> 
       <source>Remove selected items.</source>
<translation>Ausgewählde Elemende endferne.</translation>
   </message> 
   <message> 
       <source>Add items</source>
<translation>Eindräg hinzfügen</translation>
   </message> 
   <message> 
       <source>Add items to your personal notification list.</source>
<translation>Elemende zur bersönlile Benachrichdigungslischde hinzfüge.</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
</context>
<context>
<name>design/admin/notification/runfilter</name>
   <message> 
       <source>The notification time event was spawned.</source>
<translation>Dr Benachrichdigungszeidbunkd wurd angelegd.</translation>
   </message> 
   <message> 
       <source>Notification</source>
<translation>Benachrichdigungen</translation>
   </message> 
   <message> 
       <source>Spawn time event</source>
<translation>Anlege von a Ereignisses</translation>
   </message> 
   <message> 
       <source>The notification filter processed all available notification events.</source>
<translation>Dr Benachrichdigungsfildr hedd allr verfügbare Benachrichdigungsereignisse abgearbeided.</translation>
   </message> 
   <message> 
       <source>Run notification filter</source>
<translation>Schdarde Benachrichdigungsfilder</translation>
   </message> 
</context>
<context>
<name>design/admin/notification/settings</name>
   <message> 
       <source>My notification settings</source>
<translation>Moi Benachrichdigungs- Einschdellungen</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
</context>
<context>
<name>design/admin/package</name>
   <message> 
       <source>Please provide information on the changes.</source>
<translation>Bidde gebet Sie Informazione übr Änderunge.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Changes</source>
<translation>Änderungen</translation>
   </message> 
   <message> 
       <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) at the beginning of the line. The change will continue to the next change marker.</source>
<translation>Einen Eintrag mit einer Marke ( %emstart-%emend (Strich) oder %emstart*%emend (Sternchen) ) am Anfang der Zeile beginnen. Die Ãnderung wird fortgesetzt bis zur nÃ¤chsten Ã¤ndernden Marke.</translation>
   </message> 
   <message> 
       <source>Please provide some basic information for your package.</source>
<translation>Bidde gebet Sie oiig Informazione z Ihrem Paked an.</translation>
   </message> 
   <message> 
       <source>Package name</source>
<translation>Pakedname</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Licence</source>
<translation>Lizenz</translation>
   </message> 
   <message> 
       <source>Package host</source>
<translation>Paked Hoschd</translation>
   </message> 
   <message> 
       <source>Packager</source>
<translation>Zusammenschdeller</translation>
   </message> 
   <message> 
       <source>Please provide information on the maintainer of the package.</source>
<translation>Bidde underbreidet Sie dem Maindainr diess Pakeds Informazione.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>E-Mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Create package</source>
<translation>Erschdelle Paked</translation>
   </message> 
   <message> 
       <source>Available wizards</source>
<translation>Verfügbare Assischdenden</translation>
   </message> 
   <message> 
       <source>Choose one of the following wizards for creating a package</source>
<translation>Wählet Sie oin dr folgende Assischdende zum Erschdelle von a Pakeds aus</translation>
   </message> 
   <message> 
       <source>Specify export properties. The default settings will most likely be suitable for your needs.</source>
<translation>Schbezifizieret Sie d Eigenschafde vom Exbords. Die Voroischdellunge dürfde Ihre Bedürfnisse abdegge.</translation>
   </message> 
   <message> 
       <source>Miscellaneous</source>
<translation>Diverses</translation>
   </message> 
   <message> 
       <source>Include class definitions.</source>
<translation>Klassendefinizione oischließe.</translation>
   </message> 
   <message> 
       <source>Include templates related exported objects.</source>
<translation>Temblads verknübfd mid exbordierde Objekde oischließe.</translation>
   </message> 
   <message> 
       <source>Select templates from the following siteaccesses</source>
<translation>Temblads vo folgendem Seide Zugang verwenden</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>All versions</source>
<translation>Alle Versionen</translation>
   </message> 
   <message> 
       <source>Languages</source>
<translation>Schbrachen</translation>
   </message> 
   <message> 
       <source>Select languages to export</source>
<translation>Zu exbordierend Schbrache auswählen</translation>
   </message> 
   <message> 
       <source>Node assignments</source>
<translation>Knode Zuordnungen</translation>
   </message> 
   <message> 
       <source>Keep all in selected nodes</source>
<translation>Alls in ausgewählde Knode behalden</translation>
   </message> 
   <message> 
       <source>Main only</source>
<translation>Nur Haubd</translation>
   </message> 
   <message> 
       <source>Related objects</source>
<translation>Verwandde Objekde</translation>
   </message> 
   <message> 
       <source>None</source>
<translation>Koi</translation>
   </message> 
   <message> 
       <source>Please choose objects you wish to include in the package.</source>
<translation>Bidde wählet Sie Objekde aus, d im Paked oigeschlosse werde solle.</translation>
   </message> 
   <message> 
       <source>Selected nodes</source>
<translation>Knode auswählen</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>Export type</source>
<translation>Ard vom Exbords</translation>
   </message> 
   <message> 
       <source>There are currently no objects selected for exportation</source>
<translation>Es gibd momendand koi Objekde d zum Exbord ausgewähld wurden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add subtree</source>
<translation>Teilbaum hinzfügen</translation>
   </message> 
   <message> 
       <source>Add node</source>
<translation>Knode hinzfügen</translation>
   </message> 
   <message> 
       <source>Please select the site CSS file to be included in the package.</source>
<translation>Bidde wählet Sie d CSS-Dadei dr Seide aus, des im Paked oigeschlosse werde soll.</translation>
   </message> 
   <message> 
       <source>Please select the classes CSS file to be included in the package.</source>
<translation>Bidde wähle d CSS-Dadei dr Klasse aus, d im Paked oigeschlosse werde soll.</translation>
   </message> 
   <message> 
       <source>Select an image file to be included in the package and click Next.
Click &quot;Next&quot; without choosing an image to continue to the next step.</source>
<translation>Wählet Sie oi Bild aus, des im Paked nthalde soi soll und kligge noh auf Weidr.
Wenn Sie auf &quot;Weider&quot; kligge ohne oi Bild z wähle, wird mid dem nächschde Schdidd fordgesedzd..</translation>
   </message> 
   <message> 
       <source>Currently added image files</source>
<translation>Momendan hinzugefügde Bilder</translation>
   </message> 
   <message> 
       <source>Package wizard: %wizardname</source>
<translation>Paket-Assistent: %wizardname</translation>
   </message> 
   <message> 
       <source>Install package</source>
<translation>Paked inschdallieren</translation>
   </message> 
   <message> 
       <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
<translation>Des Paked kann auf Ihrem Syschdem inschdallierd werde. Die Inschdallazion wird abhängich vom Paked Dadeie kobiere, Klasse erschdelle, usw.
Falls Sie des Paked im Momend nedd inschdalliere möchde, könnet Sie des au schbädr auf dr Ansichdsseide vom Pakeds mache.</translation>
   </message> 
   <message> 
       <source>Install items</source>
<translation>Elemende inschdallieren</translation>
   </message> 
   <message> 
       <source>Skip installation</source>
<translation>Inschdallazion auslassen</translation>
   </message> 
   <message> 
       <source>Package install wizard: %wizardname</source>
<translation>Asistent zum Installieren von Paketen: %wizardname</translation>
   </message> 
   <message> 
       <source>Next %arrowright</source>
<translation>NÃ¤chster %arrowright</translation>
   </message> 
   <message> 
       <source>Finish</source>
<translation>Beenden</translation>
   </message> 
   <message> 
       <source>Error</source>
<translation>Fehler</translation>
   </message> 
   <message> 
       <source>Upload package</source>
<translation>Paked hochladen</translation>
   </message> 
   <message> 
       <source>Select the file containing your package and click the upload button</source>
<translation>Wählet Sie d Dadei aus d Ihr Paked enthäld und kligget Sie auf den Hochladen-Buddon</translation>
   </message> 
   <message> 
       <source>Import package</source>
<translation>Imbordiere Paked</translation>
   </message> 
   <message> 
       <source>Installed</source>
<translation>Inschdallierd</translation>
   </message> 
   <message> 
       <source>Not installed</source>
<translation>Nedd inschdallierd</translation>
   </message> 
   <message> 
       <source>Imported</source>
<translation>Imbordierd</translation>
   </message> 
   <message> 
       <source>Files [%collectionname]</source>
<translation>Dateien [%collectionname]</translation>
   </message> 
   <message> 
       <source>Details</source>
<translation>Dedails</translation>
   </message> 
   <message> 
       <source>Uninstall</source>
<translation>Doischdallieren</translation>
   </message> 
   <message> 
       <source>Install</source>
<translation>Inschdallieren</translation>
   </message> 
   <message> 
       <source>Export to file</source>
<translation>In Dadei exbordieren</translation>
   </message> 
   <message> 
       <source>State</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Maintainers</source>
<translation>Zuschdändige</translation>
   </message> 
   <message> 
       <source>Regarding eZ publish package &apos;%packagename&apos;</source>
<translation>Betreffendes eZ publish Paket &apos;%packagename&apos;</translation>
   </message> 
   <message> 
       <source>Send e-mail to the maintainer</source>
<translation>Dem Maindainr oi E-Mail schiggen</translation>
   </message> 
   <message> 
       <source>Documents</source>
<translation>Dokumende</translation>
   </message> 
   <message> 
       <source>Changelog</source>
<translation>Logbuch</translation>
   </message> 
   <message> 
       <source>File list</source>
<translation>Dadei Lischde</translation>
   </message> 
   <message> 
       <source>Uninstall package</source>
<translation>Doischdalliere Paked</translation>
   </message> 
   <message> 
       <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
<translation>Des Paked kann aus dem Syschdem doischdallierd werde. Die Doischdallazion wird abhängich vom Paked inschdallierde Dadeie, Klasse, usw. endferne.
Falls Sie d Doischdallazion im Momend nedd durchführe wolle, könnet Sie des schbädr auf dr Ansichdsseide vom Pakeds nachhole.
Sie könne des Paked au endferne ohne s vo dr Pakedlischde z endferne.</translation>
   </message> 
   <message> 
       <source>Uninstall items</source>
<translation>Elemende doischdallieren</translation>
   </message> 
   <message> 
       <source>Skip uninstallation</source>
<translation>Doischdallazion auslassen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/admin/package/list</name>
   <message> 
       <source>Remove section?</source>
<translation>Auswahl endferne?</translation>
   </message> 
   <message> 
       <source>Removal of packages</source>
<translation>Alle Pakede endfernen</translation>
   </message> 
   <message> 
       <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
<translation>Sind Sie sichr, dess Sie folgend Pakede endferne möchde?
Die Pakede werde dauerhafd glöschd.
Hinweis: Die Pakede werde nedd doischdallierd.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Package removal was canceled.</source>
<translation>Des Endferne vom Pakeds wurd abgebrole.</translation>
   </message> 
   <message> 
       <source>Packages</source>
<translation>Pakede</translation>
   </message> 
   <message> 
       <source>Repository</source>
<translation>Ablage</translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Change repository</source>
<translation>Ablag wechseln</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Installed</source>
<translation>Inschdallierd</translation>
   </message> 
   <message> 
       <source>Not installed</source>
<translation>Nedd inschdallierd</translation>
   </message> 
   <message> 
       <source>Imported</source>
<translation>Imbordierd</translation>
   </message> 
   <message> 
       <source>There are no packages matching the selected repository.</source>
<translation>Es gibd koi Pakede, d dr ausgewählde Ablag endschbrechen</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Import new package</source>
<translation>Neis Paked imbordieren</translation>
   </message> 
   <message> 
       <source>Create new package</source>
<translation>Neis Paked erschdellen</translation>
   </message> 
</context>
<context>
<name>design/admin/pagelayout</name>
   <message> 
       <source>Search</source>
<translation>Suchen</translation>
   </message> 
   <message> 
       <source>All content</source>
<translation>Alles</translation>
   </message> 
   <message> 
       <source>Current location</source>
<translation>Akduellr Ord</translation>
   </message> 
   <message> 
       <source>The same location</source>
<translation>Gleichr Ord</translation>
   </message> 
   <message> 
       <source>Advanced</source>
<translation>Fordgeschridden</translation>
   </message> 
   <message> 
       <source>Content structure</source>
<translation>Inhalde</translation>
   </message> 
   <message> 
       <source>Media library</source>
<translation>Medien-Bibliothek</translation>
   </message> 
   <message> 
       <source>User accounts</source>
<translation>Benudzr und Rechde</translation>
   </message> 
   <message> 
       <source>Webshop</source>
<translation>Web-Shob</translation>
   </message> 
   <message> 
       <source>Setup</source>
<translation>Sedub</translation>
   </message> 
   <message> 
       <source>Design</source>
<translation>Design</translation>
   </message> 
   <message> 
       <source>My account</source>
<translation>Moi Kondo</translation>
   </message> 
   <message> 
       <source>Current user</source>
<translation>Akduellr Benudzer</translation>
   </message> 
   <message> 
       <source>Change information</source>
<translation>Informazione ändern</translation>
   </message> 
   <message> 
       <source>Change password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>Logout</source>
<translation>Abmelden</translation>
   </message> 
   <message> 
       <source>Change user info</source>
<translation>Benudzer-Informazione ändern</translation>
   </message> 
   <message> 
       <source>Bookmarks</source>
<translation>Lesezeichen</translation>
   </message> 
   <message> 
       <source>Search all content.</source>
<translation>De kombledde Inhald durchsuche.</translation>
   </message> 
   <message> 
       <source>Search only from the current location.</source>
<translation>Nur im akduelle Ord suche.</translation>
   </message> 
   <message> 
       <source>Advanced search.</source>
<translation>Fordgeschriddene Suche.</translation>
   </message> 
   <message> 
       <source>Manage the main content structure of the site.</source>
<translation>Die Haubd-Inhalds-Schdrukdur dr Side verwalde.</translation>
   </message> 
   <message> 
       <source>Manage images, files, documents, etc.</source>
<translation>Bildr, Dadeie, Dokumende edc. verwalden</translation>
   </message> 
   <message> 
       <source>Manage users, user groups and permission settings.</source>
<translation>Benudzr, Benudzergrubbe und Berechdigung verwalde.</translation>
   </message> 
   <message> 
       <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
<translation>Kunde, Beschdellunge, Rabadde und MwSchd.-Tybe verwalden; Verkaufsschdadischdke ansehe.</translation>
   </message> 
   <message> 
       <source>Manage templates, menus, toolbars and other things related to appearence.</source>
<translation>Temblads, Menus, Werkzeig-Leischde und andere Elemende dr Benudzeroberfläche verwalden</translation>
   </message> 
   <message> 
       <source>Configure settings and manage advanced functionality.</source>
<translation>Einschdellunge konfiguriere und fordgeschriddene Funkzione verwalde.</translation>
   </message> 
   <message> 
       <source>Manage items and settings that belong to your account.</source>
<translation>Persönliche Eindräg und Einschdellunge verwalde.</translation>
   </message> 
   <message> 
       <source>Change name, e-mail, password, etc.</source>
<translation>Nam, E-Mail, Password edc. ändern</translation>
   </message> 
   <message> 
       <source>Change password for &lt;%username&gt;.</source>
<translation>Benutzerpasswort fÃ¼r &lt;%username&gt; Ã¤ndern.</translation>
   </message> 
   <message> 
       <source>There is %basket_count item in the shopping basket.</source>
<translation>Es ist %basket_count Gegenstand im Warenkorb.</translation>
   </message> 
   <message> 
       <source>Shopping basket (%basket_count)</source>
<translation>Warenkorb (%basket_count)</translation>
   </message> 
   <message> 
       <source>There are %basket_count items in the shopping basket.</source>
<translation>Es sind %basket_count GegenstÃ¤nde im Warenkorb.</translation>
   </message> 
   <message> 
       <source>Logout from the system.</source>
<translation>Vom Syschdem abmelde.</translation>
   </message> 
   <message> 
       <source>Hide bookmarks.</source>
<translation>Lesezeile ausblende.</translation>
   </message> 
   <message> 
       <source>Manage your personal bookmarks.</source>
<translation>Ihre bersönlile Lesezeile verwalde.</translation>
   </message> 
   <message> 
       <source>[%classname] Click on the icon to get a context sensitive menu.</source>
<translation>[%classname] FÃ¼r ein Kontext-Menu, klicken Sie auf das Icon.</translation>
   </message> 
   <message> 
       <source>Show bookmarks.</source>
<translation>Lesezeile anzeige.</translation>
   </message> 
   <message> 
       <source>Add to bookmarks</source>
<translation>Lesezeile ablegen</translation>
   </message> 
   <message> 
       <source>Add the current item to your bookmarks.</source>
<translation>De akduelle Eindrag z Ihre Lesezeile hinzfüge.</translation>
   </message> 
   <message> 
       <source>Hide clear cache menu.</source>
<translation>Cache leere Menü verschdegge.</translation>
   </message> 
   <message> 
       <source>Cache management page</source>
<translation>Cache-Verwaldungsseide</translation>
   </message> 
   <message> 
       <source>Clear cache</source>
<translation>Cache leeren</translation>
   </message> 
   <message> 
       <source>Show clear cache menu.</source>
<translation>Cache leere Menü anzeigen</translation>
   </message> 
   <message> 
       <source>Quick settings</source>
<translation>Kurzoischdellungen</translation>
   </message> 
   <message> 
       <source>Hide quick settings</source>
<translation>Kurzoischdellunge verschdeggen</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/content/menu</name>
   <message> 
       <source>Content structure</source>
<translation>Inhalds-Schdrukdur</translation>
   </message> 
   <message> 
       <source>Trash</source>
<translation>Pabierkorb</translation>
   </message> 
   <message> 
       <source>Small</source>
<translation>Schmal</translation>
   </message> 
   <message> 
       <source>Medium</source>
<translation>Middel</translation>
   </message> 
   <message> 
       <source>Large</source>
<translation>Breid</translation>
   </message> 
   <message> 
       <source>View and manage the contents of the trash bin.</source>
<translation>De Inhald vom Pabierkorbs ansehe und verwalde.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to small size.</source>
<translation>Inhalds-Schdrukdur schmol anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to medium size.</source>
<translation>Inhalds-Schdrukdur middelbreid anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to large size.</source>
<translation>Inhalds-Schdrukdur breid anzeige.</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/media/menu</name>
   <message> 
       <source>Media library</source>
<translation>Medien-Bibliothek</translation>
   </message> 
   <message> 
       <source>Trash</source>
<translation>Pabierkorb</translation>
   </message> 
   <message> 
       <source>Small</source>
<translation>Schmal</translation>
   </message> 
   <message> 
       <source>Medium</source>
<translation>Middel</translation>
   </message> 
   <message> 
       <source>Large</source>
<translation>Breid</translation>
   </message> 
   <message> 
       <source>View and manage the contents of the trash bin.</source>
<translation>De Inhald vom Pabierkorbs ansehe und verwalde.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to small size.</source>
<translation>Inhalds-Schdrukdur schmol anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to medium size.</source>
<translation>Inhalds-Schdrukdur middelbreid anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to large size.</source>
<translation>Inhalds-Schdrukdur breid anzeige.</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/my/menu</name>
   <message> 
       <source>My notification settings</source>
<translation>Moi Benachrichdigungs- Einschdellungen</translation>
   </message> 
   <message> 
       <source>My bookmarks</source>
<translation>Moi Lesezeichen</translation>
   </message> 
   <message> 
       <source>Collaboration</source>
<translation>Zusammenarbeid</translation>
   </message> 
   <message> 
       <source>Change password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>My account</source>
<translation>Moi Kondo</translation>
   </message> 
   <message> 
       <source>My drafts</source>
<translation>Moi Endwürfe</translation>
   </message> 
   <message> 
       <source>My pending items</source>
<translation>Moi Wardelischde</translation>
   </message> 
   <message> 
       <source>My shopping basket</source>
<translation>Moi Warenkorb</translation>
   </message> 
   <message> 
       <source>My wish list</source>
<translation>Moi Wunschzeddel</translation>
   </message> 
   <message> 
       <source>Edit mode settings</source>
<translation>Bearbeidungsmodus</translation>
   </message> 
   <message> 
       <source>on</source>
<translation>an</translation>
   </message> 
   <message> 
       <source>Disable location window when editing content.</source>
<translation>Ord-Fenschdr bei dr Objekdbearbeidung deakdiviere.</translation>
   </message> 
   <message> 
       <source>off</source>
<translation>aus</translation>
   </message> 
   <message> 
       <source>Enable location window when editing content.</source>
<translation>Ord-Fenschdr bei dr Objekdbearbeidung akdiviere.</translation>
   </message> 
   <message> 
       <source>Locations</source>
<translation>Orde</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/setup/menu</name>
   <message> 
       <source>Cache management</source>
<translation>Cache-Verwaldung</translation>
   </message> 
   <message> 
       <source>Search statistics</source>
<translation>Suchschdadischdiken</translation>
   </message> 
   <message> 
       <source>System information</source>
<translation>Syschdeminformazionen</translation>
   </message> 
   <message> 
       <source>URL management</source>
<translation>URL-Verwaldung</translation>
   </message> 
   <message> 
       <source>URL translator</source>
<translation>URL-Übersedzer</translation>
   </message> 
   <message> 
       <source>Classes</source>
<translation>Klassen</translation>
   </message> 
   <message> 
       <source>Extensions</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>Ini settings</source>
<translation>Ini Einschdellungen</translation>
   </message> 
   <message> 
       <source>Notification</source>
<translation>Benachrichdigungen</translation>
   </message> 
   <message> 
       <source>PDF export</source>
<translation>PDF exbord</translation>
   </message> 
   <message> 
       <source>Packages</source>
<translation>Pakede</translation>
   </message> 
   <message> 
       <source>RAD</source>
<translation>RAD</translation>
   </message> 
   <message> 
       <source>RSS</source>
<translation>RSS</translation>
   </message> 
   <message> 
       <source>Sections</source>
<translation>Sekzionen</translation>
   </message> 
   <message> 
       <source>Sessions</source>
<translation>Sessions</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Triggers</source>
<translation>Auslöser</translation>
   </message> 
   <message> 
       <source>Workflows</source>
<translation>Workflows</translation>
   </message> 
   <message> 
       <source>Setup</source>
<translation>Sedub</translation>
   </message> 
   <message> 
       <source>Roles and policies</source>
<translation>Rolle und Richdlinien</translation>
   </message> 
   <message> 
       <source>Upgrade check</source>
<translation>Ubgrade-Prüfung</translation>
   </message> 
   <message> 
       <source>Global settings</source>
<translation>Globale Einschdellungen</translation>
   </message> 
   <message> 
       <source>Collected information</source>
<translation>Gesammelde Informazionen</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/shop/menu</name>
   <message> 
       <source>Customers</source>
<translation>Kunden</translation>
   </message> 
   <message> 
       <source>Discounts</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Orders</source>
<translation>Beschdellung</translation>
   </message> 
   <message> 
       <source>Product statistics</source>
<translation>Produkd-Schdadischdiken</translation>
   </message> 
   <message> 
       <source>VAT types</source>
<translation>MwSchd-Tyben</translation>
   </message> 
   <message> 
       <source>Shop</source>
<translation>Shob</translation>
   </message> 
   <message> 
       <source>Order status</source>
<translation>Beschdellschdadus</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/user/menu</name>
   <message> 
       <source>User accounts</source>
<translation>Benudzer-Schdrukdur</translation>
   </message> 
   <message> 
       <source>Trash</source>
<translation>Pabierkorb</translation>
   </message> 
   <message> 
       <source>Small</source>
<translation>Schmal</translation>
   </message> 
   <message> 
       <source>Medium</source>
<translation>Middel</translation>
   </message> 
   <message> 
       <source>Large</source>
<translation>Breid</translation>
   </message> 
   <message> 
       <source>Manage permission settings.</source>
<translation>Berechdigungs-Einschdellunge verwalde.</translation>
   </message> 
   <message> 
       <source>Roles and policies</source>
<translation>Rolle und Richdlinien</translation>
   </message> 
   <message> 
       <source>View and manage the contents of the trash bin.</source>
<translation>De Inhald vom Pabierkorbs ansehe und verwalde.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to small size.</source>
<translation>Inhalds-Schdrukdur schmol anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to medium size.</source>
<translation>Inhalds-Schdrukdur middelbreid anzeige.</translation>
   </message> 
   <message> 
       <source>Change the left menu width to large size.</source>
<translation>Inhalds-Schdrukdur breid anzeige.</translation>
   </message> 
   <message> 
       <source>Role information</source>
<translation>Rolleninformazion</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Access control</source>
<translation>Zugangskondolle</translation>
   </message> 
</context>
<context>
<name>design/admin/parts/visual/menu</name>
   <message> 
       <source>Design</source>
<translation>Design</translation>
   </message> 
   <message> 
       <source>Menu management</source>
<translation>Menu-Verwaldung</translation>
   </message> 
   <message> 
       <source>Toolbar management</source>
<translation>Werkzeig-Leischden- Verwaldung</translation>
   </message> 
   <message> 
       <source>Templates</source>
<translation>Temblades</translation>
   </message> 
   <message> 
       <source>Look and feel</source>
<translation>Look&amp;Feel</translation>
   </message> 
</context>
<context>
<name>design/admin/pdf/edit</name>
   <message> 
       <source>PDF Export</source>
<translation>PDF Exbord</translation>
   </message> 
   <message> 
       <source>%pdf_export_title [PDF export]</source>
<translation>%bdf_exbord_didle [PDF Exbord]</translation>
   </message> 
   <message> 
       <source>Title</source>
<translation>Tidel</translation>
   </message> 
   <message> 
       <source>Display frontpage</source>
<translation>Zeig Schdardseide</translation>
   </message> 
   <message> 
       <source>Intro text</source>
<translation>Einführungschdexd</translation>
   </message> 
   <message> 
       <source>Sub text</source>
<translation>Weiderführendr Texd</translation>
   </message> 
   <message> 
       <source>Source node</source>
<translation>Quell Knoden</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Export structure</source>
<translation>Zu exbordierend Schdrukdur</translation>
   </message> 
   <message> 
       <source>Tree</source>
<translation>Baum</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Frontpage</source>
<translation>Schdardseide</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>There is no source node.</source>
<translation>Es gibd koi Quellknoden</translation>
   </message> 
   <message> 
       <source>Export classes (if exporting a tree)</source>
<translation>Klasse exbordiere (falls oi Baum exbordierd wird)</translation>
   </message> 
   <message> 
       <source>Export type</source>
<translation>Ard vom Exbords</translation>
   </message> 
   <message> 
       <source>Generate once</source>
<translation>Einmalich erschdellen</translation>
   </message> 
   <message> 
       <source>Generate on the fly</source>
<translation>Schnelle Erschdellung</translation>
   </message> 
   <message> 
       <source>Filename (if generated on the fly)</source>
<translation>Dadoiam (bei schnellr Erschdellung)</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
</context>
<context>
<name>design/admin/pdf/list</name>
   <message> 
       <source>PDF Exports [%export_count]</source>
<translation>PDF Exporte [%export_count]</translation>
   </message> 
   <message> 
       <source>PDF Export</source>
<translation>PDF Exbord</translation>
   </message> 
   <message> 
       <source>There are no PDF exports in the list.</source>
<translation>Es sind koi PDF Exborde in dr Lischde.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Select PDF export for removal.</source>
<translation>PDF Exbord zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%pdf_export_name&gt; PDF export.</source>
<translation>Den PDF Export &lt;%pdf_export_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected PDF exports.</source>
<translation>Ausgewählde PDF Exborde endferne.</translation>
   </message> 
   <message> 
       <source>New PDF export</source>
<translation>Neir PDF-Exbord</translation>
   </message> 
   <message> 
       <source>Create a new PDF export.</source>
<translation>Neie PDF-Exbord erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/popupmenu</name>
   <message> 
       <source>View</source>
<translation>Ansehen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Move</source>
<translation>Verschiaben</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Advanced</source>
<translation>Fordgeschridden</translation>
   </message> 
   <message> 
       <source>Expand</source>
<translation>Aufklabben</translation>
   </message> 
   <message> 
       <source>Collapse</source>
<translation>Zuklabben</translation>
   </message> 
   <message> 
       <source>Add to my bookmarks</source>
<translation>Lesezeile hinzfügen</translation>
   </message> 
   <message> 
       <source>Add to my notifications</source>
<translation>Zu Benachrichdunge hinzfügen</translation>
   </message> 
   <message> 
       <source>Swap with another node</source>
<translation>Gege andere Knode auschdauschen</translation>
   </message> 
   <message> 
       <source>Hide / unhide</source>
<translation>Verschdegge / Zeigen</translation>
   </message> 
   <message> 
       <source>View index</source>
<translation>Index anzeigen</translation>
   </message> 
   <message> 
       <source>View class</source>
<translation>Klasse anzeigen</translation>
   </message> 
   <message> 
       <source>Edit class</source>
<translation>Klasse bearbeiden</translation>
   </message> 
   <message> 
       <source>Delete view cache</source>
<translation>Ansichdscache leeren</translation>
   </message> 
   <message> 
       <source>Delete template cache</source>
<translation>Temblade Cache leeren</translation>
   </message> 
   <message> 
       <source>Delete view cache from here</source>
<translation>Ansichdscache vo hir leeren</translation>
   </message> 
   <message> 
       <source>Template overrides</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>New class override</source>
<translation>Neie Klassen-Überschreibung</translation>
   </message> 
   <message> 
       <source>New node override</source>
<translation>Neie Knoden-Überschreibung</translation>
   </message> 
   <message> 
       <source>Copy Subtree</source>
<translation>Teil vom Baums kobieren</translation>
   </message> 
   <message> 
       <source>Remove bookmark</source>
<translation>Lesezeile endfernen</translation>
   </message> 
   <message> 
       <source>Choose SiteAccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/article</name>
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Comments allowed</source>
<translation>Kommendare erlaubd</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/company</name>
   <message> 
       <source>Contact information</source>
<translation>Kondakdinformazionen</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Additional information</source>
<translation>Weidere Informazionen</translation>
   </message> 
   <message> 
       <source>Contacts</source>
<translation>Kondakde</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/feedbackform</name>
   <message> 
       <source>Your E-mail address</source>
<translation>Ihre E-Mail Adresse</translation>
   </message> 
   <message> 
       <source>Subject</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Message</source>
<translation>Nachrichd</translation>
   </message> 
   <message> 
       <source>Recipient</source>
<translation>Embfänger</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/folder</name>
   <message> 
       <source>Show children</source>
<translation>Kindr anzeigen</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/person</name>
   <message> 
       <source>Contact information</source>
<translation>Kondakdinformazionen</translation>
   </message> 
   <message> 
       <source>Comments</source>
<translation>Kommendare</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/poll</name>
   <message> 
       <source>Result</source>
<translation>Ergebnis</translation>
   </message> 
</context>
<context>
<name>design/admin/preview/product</name>
   <message> 
       <source>Download this product sheet as PDF</source>
<translation>Diese Produkdbeschreibung als PDF raaladen</translation>
   </message> 
   <message> 
       <source>People who bought this also bought</source>
<translation>Kunde, d dis kaufd hend, hend au des kaufd</translation>
   </message> 
</context>
<context>
<name>design/admin/role/assign_limited_section</name>
   <message> 
       <source>Select section</source>
<translation>Sekzion auswählen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>There are no sections on the system.</source>
<translation>Es gibd koi Sekzione im Syschdem</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/role/createpolicystep1</name>
   <message> 
       <source>Create a new policy for the &lt;%role_name&gt; role</source>
<translation>Neue Richtlinie fÃ¼r die Rolle &lt;%role_name&gt; erstellen</translation>
   </message> 
   <message> 
       <source>Welcome to the policy wizard. This three step wizard will help you create a new policy which will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
<translation>Willkomme im Richdlinien-Assischdende. In drei Schridde wird Ihne von dene Assidend helfe oi neie Richdlinie z erschdelle, d dr momendan in Bearbeidung befindlile Rolle zugeordned wird. Dr Assischdend kann durch Kligge auf &quot;Abbrechen&quot; verlasse werde.</translation>
   </message> 
   <message> 
       <source>Step one: select module</source>
<translation>Schridd ois: Auswahl von a Moduls</translation>
   </message> 
   <message> 
       <source>Instructions</source>
<translation>Anleidung</translation>
   </message> 
   <message> 
       <source>Use the drop-down menu to select the module that you wish to grant access to.</source>
<translation>Benudzet Sie des Auswahlmenü um oi Modul auszwähle, z dem Zugang gwährd werde soll.</translation>
   </message> 
   <message> 
       <source>Click one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
<translation>Kligget Sie auf oin dr &quot;Zugriff auf...&quot;-Knöbf (unde erklärd), um zum nächschde Schridd z glange.</translation>
   </message> 
   <message> 
       <source>The &quot;Grant access to all functions&quot; button will create a policy that grants unlimited access to all functions of the selected module. If you wish to limit the access method to a specific function, use the &quot;Grant access to a function&quot; button. Please note that function limitation is only supported by some modules (the next step will reveal if it works or not).</source>
<translation>Dr Knobf &quot;Zugriff auf alle Funkzione gwähren&quot; wird oi neie Richdlinie erschdelle, dr unbeschränkde Zugang z alle Funkzione vom gewählde Moduls gwährd. Falls Sie den Zugriff auf oi schbezielle Funkzion beschränke wolle, benudzet Sie den Knobf &quot;Zugriff auf oi Funkzion gwähren&quot;. Bidde beachdet Sie, dess Funkzionslimidierunge nur vo oiige Module underschdüdzd werde (dr nächschde Schridd wird deidlich mache ob des funkzionierd odr nedd).</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Every module</source>
<translation>Alle Module</translation>
   </message> 
   <message> 
       <source>Grant access to all functions</source>
<translation>Zugriff auf alle Funkzione gwähren</translation>
   </message> 
   <message> 
       <source>Grant access to one function</source>
<translation>Zugriff auf oi Funkzion gwähren</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/role/createpolicystep2</name>
   <message> 
       <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
<translation>Willkomme im Richdlinien-Assischdende. In drei Schridde wird Ihne von dene Assischdend helfe oi Richdlinie z erschdelle. Die Richdlinie wird dr Rolle zugefügd werde, d si gerad in Bearbeidung befinded. Sie könne den Assischdende jederzeid durch Kligge auf &quot;Abbrechen&quot; verlasse.</translation>
   </message> 
   <message> 
       <source>Step one: select module [completed]</source>
<translation>Schridd ois: Auswahl von a Moduls [abgeschlossen]</translation>
   </message> 
   <message> 
       <source>Selected module</source>
<translation>Ausgewählds Modul</translation>
   </message> 
   <message> 
       <source>All modules</source>
<translation>Alle Module</translation>
   </message> 
   <message> 
       <source>Selected access method</source>
<translation>Ausgewählde Zugriffsard</translation>
   </message> 
   <message> 
       <source>Limited</source>
<translation>Beschränkd</translation>
   </message> 
   <message> 
       <source>Step two: select function</source>
<translation>Schridd zwei: Auswahl oir Funkzion</translation>
   </message> 
   <message> 
       <source>Instructions</source>
<translation>Anleidung</translation>
   </message> 
   <message> 
       <source>Use the drop-down menu to select the function that you wish to grant access to.</source>
<translation>Benudzet Sie des Auswahlmenü um Zugriff auf oi Funkzion z gwähre.</translation>
   </message> 
   <message> 
       <source>The &quot;Grant full access&quot; button will create a policy that grants unlimited access to the selected function within the module that was specified in step one. If you wish to limit the access method in some way, click the &quot;Grant limited access&quot; button. Function limitation is only supported by some functions. If unsupported, eZ publish will simply set up a policy with unlimited access to the selected function.</source>
<translation>Dr Knobf &quot;Volle Zugriff gwähren&quot; wird oi Richdlinie erschdelle, d unbeschränkde Zugriff auf d ausgewählde Funkzion innerhalb vom obe schbezifizierde Moduls gwährd. Falls Sie d Zugriffsard weidr oischränke möchde, kligget Sie auf den Knobf &quot;Eingeschränkde Zugriff gwähren&quot;. Die Einschränkung vom Zugriffs wird nur vo manle Funkzione underschdüdzd. Falls dis nedd underschdüdzd wird, wird eZ bublish oifach oi Rolle erschdelle, d unbeschränkde Zugriff auf d Funkzion gwährd.</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Grant full access</source>
<translation>Volle Zugriff gwähren</translation>
   </message> 
   <message> 
       <source>Grant limited access</source>
<translation>Eingeschränkde Zugriff gwähren</translation>
   </message> 
   <message> 
       <source>It is unfortunately not possible to grant limited access to all modules at once. To grant unlimited access to all modules and their functions, go back to step one and select &quot;Grant access to all functions&quot;. In order to grant limited access to different functions within different modules, you need to set up a collection of policies.</source>
<translation>Leidr isch s nedd möglich oigeschränkde Zugriff auf alle Module gleichzeidich z gwähre. Um unbeschränkde Zugriff auf alle Module und ihre Funkzione z gwähre, gehet Sie bidde oin Schridd zurügg und kligget Sie auf &quot;Zugriff auf alle Funkzione gwähren&quot;. Falls Sie oigeschränkde Zugriff auf underschiedliche Funkzione innerhalb underschiedlichr Module definiere möchde, müsset Sie mehrere Richdlinie erschdelle.</translation>
   </message> 
   <message> 
       <source>The selected module (%module_name) does not support limitations on the function level. Please go back to step one and use the &quot;Grant access to all functions&quot; option instead.</source>
<translation>Das ausgewÃ¤hlte Modul (%module_name) unterstÃ¼tzt keine Limitierungen von Funktionen. Bitte gehen Sie einen Schritt zurÃ¼ck und benutzen Sie stattdessen den Knopf  &quot;Zugriff auf alle Funktionen gewÃ¤hren&quot;.</translation>
   </message> 
   <message> 
       <source>Go back to step one</source>
<translation>Zurügg z Schridd ois</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Create a new policy for the &lt;%role_name&gt; role</source>
<translation>Neue Richtlinie fÃ¼r die Rolle &lt;%role_name&gt; erstellen</translation>
   </message> 
</context>
<context>
<name>design/admin/role/createpolicystep3</name>
   <message> 
       <source>Create a new policy for the &lt;%role_name&gt; role</source>
<translation>Neue Richtlinie fÃ¼r die Rolle &lt;%role_name&gt; erstellen</translation>
   </message> 
   <message> 
       <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
<translation>Willkomme im Richdlinien-Assischdende. In drei Schridde wird Ihne von dene Assischdend helfe oi Richdlinie z erschdelle. Die Richdlinie wird dr Rolle zugefügd werde, d si gerad in Bearbeidung befinded. Sie könne den Assischdende jederzeid durch Kligge auf &quot;Abbrechen&quot; verlasse.</translation>
   </message> 
   <message> 
       <source>Step one: select module [completed]</source>
<translation>Schridd ois: Auswahl von a Moduls [abgeschlossen]</translation>
   </message> 
   <message> 
       <source>Selected module</source>
<translation>Ausgewählds Modul</translation>
   </message> 
   <message> 
       <source>All modules</source>
<translation>Alle Module</translation>
   </message> 
   <message> 
       <source>Selected access method</source>
<translation>Ausgewählde Zugriffsard</translation>
   </message> 
   <message> 
       <source>Limited</source>
<translation>Beschränkd</translation>
   </message> 
   <message> 
       <source>Step two: select function [completed]</source>
<translation>Schridd zwei: Auswahl oir Funkzion [abgeschlossen]</translation>
   </message> 
   <message> 
       <source>Selected function</source>
<translation>Ausgewählde Funkzion</translation>
   </message> 
   <message> 
       <source>Step three: set function limitations</source>
<translation>Schridd frei: Limidierung dr Funkzion oischdellen</translation>
   </message> 
   <message> 
       <source>Instructions</source>
<translation>Anleidung</translation>
   </message> 
   <message> 
       <source>Set the desired function limitations using the controls below.</source>
<translation>Schdellet Sie d gwünschde Limidierunge dr Funkzion oi, indem Sie d Kondolle unde benudze.</translation>
   </message> 
   <message> 
       <source>Click the &quot;OK&quot; button to finish the wizard. The policy will be added to the role that is currently being edited.</source>
<translation>Kligget Sie auf den Knobf &quot;OK&quot; um den Assischdende abzschließe. Die Richdlinie wird dr Rolle zugeordned, d si gerad undr Bearbeidung befinded.</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Nodes [%node_count]</source>
<translation>Knoten [%node_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>The node list is empty.</source>
<translation>Die Lischde dr Knode isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add nodes</source>
<translation>Knode hinzfügen</translation>
   </message> 
   <message> 
       <source>Subtrees [%subtree_count]</source>
<translation>Teile der Baumstruktur [%subtree_count]</translation>
   </message> 
   <message> 
       <source>Subtree</source>
<translation>Teile dr Baumschdrukdur</translation>
   </message> 
   <message> 
       <source>The subtree list is empty.</source>
<translation>Die Lischde dr Teile dr Baumschdrukdur isch ler.</translation>
   </message> 
   <message> 
       <source>Add subtrees</source>
<translation>Teil dr Baumschdrukdur hinzfügen</translation>
   </message> 
   <message> 
       <source>Go back to step one</source>
<translation>Zurügg z Schridd ois</translation>
   </message> 
   <message> 
       <source>Go back to step two</source>
<translation>Zurügg z Schridd zwei</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/role/edit</name>
   <message> 
       <source>Edit &lt;%role_name&gt; [Role]</source>
<translation>Bearbeiten von &lt;%role_name&gt; [Role]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Policies</source>
<translation>Richdlinien</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Limitations</source>
<translation>Limidierungen</translation>
   </message> 
   <message> 
       <source>No limitations</source>
<translation>Koi Einschränkungen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Select policy for removal.</source>
<translation>Richdlinie zum Endferne auswählen</translation>
   </message> 
   <message> 
       <source>all modules</source>
<translation>alle Module</translation>
   </message> 
   <message> 
       <source>all functions</source>
<translation>alle Funkzionen</translation>
   </message> 
   <message> 
       <source>Edit the policy&apos;s function limitations.</source>
<translation>Limidierunge vo Funkzione dr Richdlinie bearbeide.</translation>
   </message> 
   <message> 
       <source>There are no policies set up for this role.</source>
<translation>Es sind koi Richdlininie für diese Rolle gsedzd.</translation>
   </message> 
   <message> 
       <source>Remove selected policies.</source>
<translation>Ausgewählde Richdlinie endferne.</translation>
   </message> 
   <message> 
       <source>New policy</source>
<translation>Neie Richdlinie</translation>
   </message> 
   <message> 
       <source>Create a new policy.</source>
<translation>Neie Richdlinie erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/role/list</name>
   <message> 
       <source>Roles [%role_count]</source>
<translation>Rollen [%role_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected roles.</source>
<translation>Ausgewählde Rolle endferne.</translation>
   </message> 
   <message> 
       <source>New role</source>
<translation>Neie Rolle</translation>
   </message> 
   <message> 
       <source>Create a new role.</source>
<translation>Neie Rolle erschdelle.</translation>
   </message> 
   <message> 
       <source>Toggle selection</source>
<translation>Auwahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select role for removal.</source>
<translation>Rolle zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Assign</source>
<translation>Verknübfen</translation>
   </message> 
   <message> 
       <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
<translation>Die Rolle &lt;%role_name&gt; mit einem Benutzer oder einer Benutzergruppe verknÃ¼pfen.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%role_name&gt; role.</source>
<translation>Die Rolle &lt;%role_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Copy the &lt;%role_name&gt; role.</source>
<translation>Die Rolle &lt;%role_name&gt; kopieren.</translation>
   </message> 
</context>
<context>
<name>design/admin/role/policyedit</name>
   <message> 
       <source>Edit &lt;%policy_name&gt; policy for &lt;%role_name&gt; role</source>
<translation>Bearbeiten von Richtlinie &lt;%policy_name&gt; der Rolle &lt;%role_name&gt;</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Function limitations</source>
<translation>Limidierunge dr Funkzion</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Nodes [%node_count]</source>
<translation>Knoten [%node_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>The node list is empty.</source>
<translation>Die Lischde dr Knode isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add nodes</source>
<translation>Knode hinzfügen</translation>
   </message> 
   <message> 
       <source>Subtrees [%subtree_count]</source>
<translation>Teile der Baumstruktur [%subtree_count]</translation>
   </message> 
   <message> 
       <source>Subtree</source>
<translation>Teile dr Baumschdrukdur</translation>
   </message> 
   <message> 
       <source>The subtree list is empty.</source>
<translation>Die Lischde dr Teile dr Baumschdrukdur isch ler.</translation>
   </message> 
   <message> 
       <source>Add subtrees</source>
<translation>Teile dr Baumschdrukdur hinzfügen</translation>
   </message> 
   <message> 
       <source>The function limitations of this policy can not be edited. This is either because the function simply does not support limitations or because the function was assigned without limitations when the policy was created.</source>
<translation>Die Limidierung dr Funkzion kann nedd bearbeided werde. Des liegd endwedr dro, dess d Funkzion Limidierunge oifach nedd underschdüdzd, odr dro, dess dr Funkzion koi Limidierunge zugeordned wurde, als d Richdlinie erschdelld wurd.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/role/view</name>
   <message> 
       <source>all modules</source>
<translation>alle Module</translation>
   </message> 
   <message> 
       <source>all functions</source>
<translation>alle Funkzionen</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>%role_name [Role]</source>
<translation>%role_nam [Rolle]</translation>
   </message> 
   <message> 
       <source>Policies [%policies_count]</source>
<translation>Richtlinien [%policies_count]</translation>
   </message> 
   <message> 
       <source>No limitations</source>
<translation>Koi Einschränkungen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit this role.</source>
<translation>Diese Rolle bearbeide.</translation>
   </message> 
   <message> 
       <source>Users and groups using the &lt;%role_name&gt; role [%users_count]</source>
<translation>Benutzer und Gruppen, die die Rolle &lt;%role_name&gt; benutzen [%users_count]</translation>
   </message> 
   <message> 
       <source>User/group</source>
<translation>Benudzer/Grubbe</translation>
   </message> 
   <message> 
       <source>Limitation</source>
<translation>Limidierung</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Assign</source>
<translation>Verknübfen</translation>
   </message> 
   <message> 
       <source>Subtree</source>
<translation>Teile dr Baumschdrukdur</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>There are no policies set up for this role.</source>
<translation>Es sind koi Richdlinie für diese Rolle gsedzd.</translation>
   </message> 
   <message> 
       <source>Toggle selection</source>
<translation>Auswahl umkehren</translation>
   </message> 
   <message> 
       <source>Select user or user group for removal.</source>
<translation>benudzr odr Grubb zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>This role is not assigned to any users or user groups.</source>
<translation>Diese Rolle isch koim Benudzr odr Benudzergrubb zugeordned.</translation>
   </message> 
   <message> 
       <source>Remove selected users and/or user groups.</source>
<translation>Ausgewählde Benudzr und/odr Grubbe endferne.</translation>
   </message> 
   <message> 
       <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
<translation>Die Rolle &lt;%role_name&gt; mit einem Benutzer oder einer Gruppe verknÃ¼pfen.</translation>
   </message> 
   <message> 
       <source>Select limitation.</source>
<translation>Limidierung auswähle.</translation>
   </message> 
   <message> 
       <source>Assign with limitation</source>
<translation>Mid Limidierung zuordne.</translation>
   </message> 
   <message> 
       <source>Assign the &lt;%role_name&gt; role with limitation (specified to the left) to a user or a user group.</source>
<translation>Die Rolle &lt;%role_name&gt; mit Limitierung (wie links spezifiziert) einem Benutzer oder einer Gruppe zuordnen.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/browse_destination</name>
   <message> 
       <source>Choose a destination for RSS import</source>
<translation>Ein Zil für den RSS Imbord auswählen</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose a destination location for RSS import and click &quot;OK&quot;.</source>
<translation>Benudzet Sie d Radio-Buddons, um oin Zielord für den RSS Imbord auszwähle. Kligget Sie noh auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/browse_image</name>
   <message> 
       <source>Choose image for RSS export</source>
<translation>Bild für den RSS Imbord auswählen</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose an image to use in the RSS export and click &quot;OK&quot;.</source>
<translation>Benudzet Sie d Radio-Buddons, um oi Bild für d Verwendung im RSS Imbord auszwähle. Kligget Sie noh auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/browse_source</name>
   <message> 
       <source>Choose source for RSS export</source>
<translation>Quelle für den RSS Exbord auswählen</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose the item that you wish to export using RSS and click &quot;OK&quot;.</source>
<translation>Benudzet Sie d Radio-Buddons, um des Elemend auszwähle, dess für den RSS Exbord verwended werde soll. Kligget Sie noh auf &quot;OK&quot;.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/browse_user</name>
   <message> 
       <source>Choose owner for RSS imported objects</source>
<translation>Eine Besidzr für br RSS imbordierde Objekde auswählen</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose a user and click &quot;OK&quot;. The user will become the owner of the objects that were imported using RSS.</source>
<translation>Benudzet Sie d Radio-Buddons um oin Benudzr auszwähle und kligget Sie noh auf &quot;OK&quot;. Dr Benudzr wird dr Besidzr dr Objekde werde, d br RSS imbordierd wurde.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/edit_export</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Site URL</source>
<translation>URL dr Webside</translation>
   </message> 
   <message> 
       <source>Image</source>
<translation>Bild</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>RSS version</source>
<translation>RSS Version</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Access URL</source>
<translation>URL vom erzeigde RSS-Feeds</translation>
   </message> 
   <message> 
       <source>Source path</source>
<translation>Quell-Pfad</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Title</source>
<translation>Tidel</translation>
   </message> 
   <message> 
       <source>Remove this source</source>
<translation>Diese Quelle endfernen</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Edit &lt;%rss_export_name&gt; [RSS Export]</source>
<translation>Bearbeiten von &lt;%rss_export_name&gt; [RSS Export]</translation>
   </message> 
   <message> 
       <source>Name of the RSS export. This name is used in the administration interface only, to distinguish the different exports from each other.</source>
<translation>Nam vom RSS Exbords. Diesr Nam wird nur auf dr Adinischdrazionsoberfläche benudzd, um d underschiedlile Exborde vonoiandr abzugrenze.</translation>
   </message> 
   <message> 
       <source>Use the description field to write a text explaining what users can expect from the RSS export.</source>
<translation>Benudzet Sie des Beschreibungsfeld um oin Texd z erschdelle dr beschreibd, was Benudzr vo dem RSS Exbord erwarde könne.</translation>
   </message> 
   <message> 
       <source>Click this button to select an image for the RSS export. Note that images only work with RSS version 2.0</source>
<translation>Benudzet Sie diese Knobf um oi Bild für den RSS Exbord auszwähle. Beachdet Sie, dess Bildr nur mid RSS dr Versio 2.0 funkzioniere.</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the RSS version to use for the export. You must select RSS 2.0 in order to export the image selected above.</source>
<translation>Benudzet Sie diess Auswahlmenü um d RSS Versio, d für den Exbord verwended werde soll, auszwähle. Sie müsse RSS 2.0 auswähle, falls Sie des obe ausgewählde Bild z exbordiere.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to control if the RSS export is active or not. An inactive export will not be automatically updated.</source>
<translation>Benudzeret Sie diess Ankreizfeld um z kondrolliere ob dr RSS Exbord akdiv isch odr nedd. Ein inakdivr Exbord wird nedd audomadisch akdualisierd.</translation>
   </message> 
   <message> 
       <source>Use this field to set the URL where the RSS export should be available. Note that &quot;rss/feed/&quot; will be appended to the real URL.</source>
<translation>Benudzet Sie diess Feld um d URL, undr dr dr RSS Exbord verfügbar soi soll, z defnieire. Beachdet Sie dess &quot;rss/feed/&quot; dr ferdige URL hinzugefügd wird.</translation>
   </message> 
   <message> 
       <source>Source</source>
<translation>Quelle</translation>
   </message> 
   <message> 
       <source>Click this button to select the source node for RSS export source. Objects of the type selected in the drop down below published as sub-items of the selected node will be included in the RSS export.</source>
<translation>Kligget Sie auf diese Knobf, um oin Quellknode für den RSS Exbordquelle anzugebe. Objekde vom im undenschdehende Auswählmenü ausgewählde Tybs d als Underelemende vom ausgewählde Knodens veröffendlichd wurde, werde im RSS Exbord oigeschlosse.</translation>
   </message> 
   <message> 
       <source>Use this drop down to select the type of object that triggers the export. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
<translation>Benudzet Sie diese Auswahllischde um d Ard vom Objekds auszwähle, des den Exbord auslösch. Kligget Sie auf den Knobf &quot;Sedzen&quot;, um d d korrekde Addribuadedybe für d verbeleibende Feldr z lade.</translation>
   </message> 
   <message> 
       <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
<translation>Kligget Sie auf diese Knobf um d rechte Werde in d Asuwahllischde unde z lade. Benudzet Sie d Auswahllischde links um d rechte Ard dr Klasse auszwähle.</translation>
   </message> 
   <message> 
       <source>Use this drop-down to select which attribute that should be exported as the title of the RSS export entry.</source>
<translation>Benudzet Sie diess Auswahlmenü um auszwähle, wo Addribud als Tidl vom RSS Exbords Eindrags exbordierd werde soll.</translation>
   </message> 
   <message> 
       <source>Use this drop-down to select which attribute that should be exported as the description of the RSS export entry.</source>
<translation>Benudzet Sie diess Auswahlmenü um auszwähle, wo Addribud als Beschreibung vom RSS Exbord Eindrags exbordierd werde soll.</translation>
   </message> 
   <message> 
       <source>Click to remove this source from the RSS export.</source>
<translation>Kligget Sie hir um d Quelle aus dem RSS Exbord z endferne.</translation>
   </message> 
   <message> 
       <source>Add source</source>
<translation>Quelle hinzfügen</translation>
   </message> 
   <message> 
       <source>Click to add a new source to the RSS export.</source>
<translation>Kligget Sie hir um dem RSS Exbord oi neie Quelle hinzuzfüge.</translation>
   </message> 
   <message> 
       <source>Apply the changes and return to the RSS overview.</source>
<translation>Änderunge anwende und zur RSS Übersichd zurüggkehre.</translation>
   </message> 
   <message> 
       <source>Cancel the changes and return to the RSS overview.</source>
<translation>Die Änderunge verwerfe und zur RSS Übersichd zurüggkehre.</translation>
   </message> 
   <message> 
       <source>Invalid Input</source>
<translation>Ungüldig Eingabe</translation>
   </message> 
   <message> 
       <source>If RSS Export is Active then a valid Access URL is required.</source>
<translation>Fall dr RSS Exbord akdiv isch, wird oi güldig Zugriff-URL benödigd.</translation>
   </message> 
   <message> 
       <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
<translation>Benudzet Sie diess Feld um d Basis-URL Ihrr Seide anzugebe. Sie wird benudzd um d URL für den Exbord z generiere. Diese wird si aus dr URL dr Seide (z.B. &quot;hddb://www.examble.com/index.fb&quot;) un dem Pfad zum Objekd (z.B. &quot;/ardicles/my_ardicle&quot;)) zsammensedze. Die URL dr Seide hängd vo Ihrem Webservr und dr eZ bublish Konfigurazion ab.</translation>
   </message> 
   <message> 
       <source>Number of objects</source>
<translation>Anzahl dr Objekde</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
<translation>Benudzet Sie diess Auswahlmenü um d maximale Anzahl dr Objekde, d in dr RSS-Einschbeisung oigeschlosse werde, auszwähle.</translation>
   </message> 
   <message> 
       <source>Main node only</source>
<translation>Nur Haubdknoden</translation>
   </message> 
   <message> 
       <source>Check if you want to only feed the object from the main node.</source>
<translation>Wählet Sie des aus, falls des Objekd nur vom Haubdknode oischbeiße soll.</translation>
   </message> 
   <message> 
       <source>Subnodes</source>
<translation>Underknoden</translation>
   </message> 
   <message> 
       <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
<translation>Akdivieret Sie dis, falls au Objekde vo Underknode dr Quelle oigeschbeißd werde solle.</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/edit_import</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Source URL</source>
<translation>Quell-URL</translation>
   </message> 
   <message> 
       <source>Destination path</source>
<translation>Zielbfad</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Imported objects will be owned by</source>
<translation>Eigendümr vo imbordierde Objekde wird soi</translation>
   </message> 
   <message> 
       <source>Change user</source>
<translation>Usr ändern</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Title</source>
<translation>Tidel</translation>
   </message> 
   <message> 
       <source>Ignore</source>
<translation>Ignorieren</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Edit &lt;%rss_import_name&gt; [RSS Import]</source>
<translation>Bearbeiten von &lt;%rss_import_name&gt; [RSS Import]</translation>
   </message> 
   <message> 
       <source>Name of the RSS import. This name is used in the administration interface only, to distinguish the different imports from each other.</source>
<translation>Nam vom RSS Imbords. Diesr Nam wird nur auf dr Adminischdrazionsoberfläche verwended, um d underschiedlile Imborde vonoiandr underscheide z könne.</translation>
   </message> 
   <message> 
       <source>Use this field to enter the source URL of the RSS feed to import.</source>
<translation>Benudzet Sie diess Feld um d Quell-URL dr z imbordierende RSS-Einschbeißung oizugebe.</translation>
   </message> 
   <message> 
       <source>Click this button to select the destination node where objects created by the import are located.</source>
<translation>Kligget Sie auf diese Knobf, um den Zielknode auszwähle, an dem vom Imbord erschdellde Knode blazierd werde solle.</translation>
   </message> 
   <message> 
       <source>Click this button to select the user who should own the objects created by the import.</source>
<translation>Kligget Sie auf diese Knobf, um den Benudzr auszwähle, dr Besidzr dr vom Imbord erschdellde Objekde soi soll.</translation>
   </message> 
   <message> 
       <source>Use this drop down to select the type of object the import should create. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
<translation>Benudzet Sie diese Auswahllischde um den Tyb vom Objekds auszwähle, dr vom Imbord erschdelld werde soll. Kligget Sie auf den Knobf &quot;Sedzen&quot;, um d korrekde Addribuade für d verbleibende Feldr z lade.</translation>
   </message> 
   <message> 
       <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
<translation>Kligget Sie auf diese Knobf, um d rechte Werde in d Auswahlfeldr unde z lade. Benudzet Sie des Asuwahlmenü links, um d rechte Ard dr Klasse z wähle.</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the attribute that should bet set to the title information from the RSS stream.</source>
<translation>Benudzet Sie diess Auswählmenü, um des Addribud z definiere, des als Tidelinformazion für den RSS-Schdream verwended werde soll.</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the attribute that should be set to the URL information from the RSS stream.</source>
<translation>Benudzet Sie diess Auswählmenü, um des Addribud auszwähle, des als URL-Informazion vom RSS-Schdreams verwended werde soll.</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the attribute that should be set to the description information from the RSS stream.</source>
<translation>Benudzet Sie diess Asuwahlmenü, um des Addribud auszwähle, des als Beschreibungsinformazion vom RSS-Schdreams verwended werde soll.</translation>
   </message> 
   <message> 
       <source>Use this checkbox to control if the RSS feed is active or not. An inactive feed will not be automatically updated.</source>
<translation>Benudzet Sie diess Ankreizfeld, um oizschdelle ob diese RSS-Einschbeißung akdiv soi soll odr nedd. Eine inakdive Einschbeißung wird nedd audomadisch akdualisierd.</translation>
   </message> 
   <message> 
       <source>Apply the changes and return to the RSS overview.</source>
<translation>Änderunge anwende und zur RSS Pbersichd zurüggkehre.</translation>
   </message> 
   <message> 
       <source>Cancel the changes and return to the RSS overview.</source>
<translation>Änderunge verwerfe und zur RSS Übersichd zurüggkehre.</translation>
   </message> 
</context>
<context>
<name>design/admin/rss/list</name>
   <message> 
       <source>RSS exports [%exports_count]</source>
<translation>RSS Exporte [%exports_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Geänderd von</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Inactive</source>
<translation>Inakdiv</translation>
   </message> 
   <message> 
       <source>The RSS export list is empty.</source>
<translation>Die Lischde dr RSS Exborde isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New export</source>
<translation>Neir Exbord</translation>
   </message> 
   <message> 
       <source>RSS imports [%imports_count]</source>
<translation>RSS Importe [%imports_count]</translation>
   </message> 
   <message> 
       <source>The RSS import list is empty.</source>
<translation>Die Lischde dr RSS Imborde isch ler.</translation>
   </message> 
   <message> 
       <source>New import</source>
<translation>Neir Imbord</translation>
   </message> 
   <message> 
       <source>Invert selection</source>
<translation>Auswahl umkehren</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select RSS export for removal.</source>
<translation>RSS Exbord zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%name&gt; RSS export.</source>
<translation>Bearbeiten von RSS Export &lt;%name&gt;</translation>
   </message> 
   <message> 
       <source>Remove selected RSS exports.</source>
<translation>Die ausgewählde RSS Exborde endfernen</translation>
   </message> 
   <message> 
       <source>Create a new RSS export.</source>
<translation>Eine neie RSS Exbord erschdelle.</translation>
   </message> 
   <message> 
       <source>Select RSS import for removal.</source>
<translation>RSS Imbord zum Endferne auwähle.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%name&gt; RSS import.</source>
<translation>Bearbeiten von RSS Import &lt;%name&gt;</translation>
   </message> 
   <message> 
       <source>Remove selected RSS imports.</source>
<translation>De ausgewählde RSS Imbord endferne.</translation>
   </message> 
   <message> 
       <source>Create a new RSS import.</source>
<translation>Neie RSS Imbord erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/search/stats</name>
   <message> 
       <source>Search statistics</source>
<translation>Suchschdadischdiken</translation>
   </message> 
   <message> 
       <source>Phrase</source>
<translation>Ausdrugg</translation>
   </message> 
   <message> 
       <source>Number of phrases</source>
<translation>Anzahl dr Ausdrügge</translation>
   </message> 
   <message> 
       <source>Average result returned</source>
<translation>Durchschniddlichs Ergebnis</translation>
   </message> 
   <message> 
       <source>Reset statistics</source>
<translation>Schdadischdisk zurüggsedzen</translation>
   </message> 
   <message> 
       <source>The list is empty.</source>
<translation>Die Lischde isch ler.</translation>
   </message> 
   <message> 
       <source>Clear the search log.</source>
<translation>Des Suchlog leere.</translation>
   </message> 
</context>
<context>
<name>design/admin/section/browse_assign</name>
   <message> 
       <source>Choose start location for the &lt;%section_name&gt; section</source>
<translation>WÃ¤hlen Sie einen Startort fÃ¼r die Sektion &lt;%section_name&gt;</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to select an item that should have the &lt;%section_name&gt; section assigned.</source>
<translation>Benutzen Sie die Radio-Buttons um ein Element auszuwÃ¤hlen, das der Sektion &lt;%section_name&gt; zugeordnet werden soll.</translation>
   </message> 
   <message> 
       <source>Keep in mind that the section assignment of the sub items will also be changed.</source>
<translation>Beachdet Sie, dess d Sekzionszuordnung dr Underelemende ebenfalls gänderd wird.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/section/confirmremove</name>
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Confirm section removal</source>
<translation>Beschdädigung vom Lösche dr Sekzion</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the section?</source>
<translation>Sind Sie sichr, dess Sie d Sekzion endferne möchde?</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the sections?</source>
<translation>Sind Sie sichr, dess Sie diese Sekzione endferne möchde?</translation>
   </message> 
   <message> 
       <source>The following sections will be removed</source>
<translation>Die folgende Sekzione werde erndfernd</translation>
   </message> 
   <message> 
       <source>Warning</source>
<translation>Warnung</translation>
   </message> 
   <message> 
       <source>Removing a section may corrupt permission settings, template output and other things in the system.</source>
<translation>Des Endferne oir Sekzion könnde Zugriffsoischdellunge, Augab vo Temblads odr andere Ding im Syschdem zerschdöre.</translation>
   </message> 
   <message> 
       <source>Proceed only if you know what you are doing.</source>
<translation>Fahret Sie nur noh ford, wenn Sie wisse was Sie mache.</translation>
   </message> 
</context>
<context>
<name>design/admin/section/edit</name>
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Edit &lt;%section_name&gt; [Section]</source>
<translation>Bearbeiten von &lt;%section_name&gt; [Sektion]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Navigation Part</source>
<translation>Navigazionschdeil</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/section/list</name>
   <message> 
       <source>Sections [%section_count]</source>
<translation>Sektionen [%section_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>section</source>
<translation>sekzion</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New section</source>
<translation>Neie Sekzion</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select section for removal.</source>
<translation>Sekzion zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Assign</source>
<translation>Verknübfen</translation>
   </message> 
   <message> 
       <source>Assign the &lt;%section_name&gt; section to a subtree.</source>
<translation>Die Sektion &lt;%section_name&gt; mit einem Teil der Baumstruktur verknÃ¼pfen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%section_name&gt; section.</source>
<translation>Die Sektion &lt;%section_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Remove selected sections.</source>
<translation>Die ausgewählde Sekzione endferne.</translation>
   </message> 
   <message> 
       <source>Create a new section.</source>
<translation>Eine neie Sekzion erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/section/view</name>
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>%section_name [Section]</source>
<translation>%seczion_nam [Sekzion]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Edit this section.</source>
<translation>Diese Sekzion bearbeide.</translation>
   </message> 
   <message> 
       <source>Roles containing limitations associated with this section [%number_of_roles]</source>
<translation>Rollen, die mit dieser Sektion verknÃ¼pfte Limitierungen enthalten [%number_of_roles]</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Limited policies</source>
<translation>Eingeschränkde Richdlinien</translation>
   </message> 
   <message> 
       <source>This section is not used to limit the policies of any role.</source>
<translation>Diese Sekzion wird nedd benudzd um d Richdlinie oir Rolle oizschränke.</translation>
   </message> 
   <message> 
       <source>Users and user groups with role limitations associated with this section [%number_of_roles]</source>
<translation>Benutzer und Gruppen mit Rollenlimitierungen verknÃ¼pft innerhalb dieser Sektion [%number_of_roles]</translation>
   </message> 
   <message> 
       <source>User or user group</source>
<translation>Benudzr odr Benudzergrubben</translation>
   </message> 
   <message> 
       <source>This section is not used for limiting roles that are assigned to users or user groups.</source>
<translation>Diese Sekzion wird nedd verwended um Rolle z limidiere, d Benudzeret odr Benudzergrubbe zugeordned sind.</translation>
   </message> 
   <message> 
       <source>Objects within this section [%number_of_objects]</source>
<translation>Objekte innerhalb dieser Sektion [%number_of_objects]</translation>
   </message> 
   <message> 
       <source>This section is not assigned to any objects.</source>
<translation>Diese Sekzion isch mid koim Objekd zugeordned.</translation>
   </message> 
</context>
<context>
<name>design/admin/settings</name>
   <message> 
       <source>Edit setting %setting</source>
<translation>Berabeiten von Einstellung %setting</translation>
   </message> 
   <message> 
       <source>New setting</source>
<translation>Neie Einschdellung</translation>
   </message> 
   <message> 
       <source>Block</source>
<translation>Blogg</translation>
   </message> 
   <message> 
       <source>Setting</source>
<translation>Einschdellung</translation>
   </message> 
   <message> 
       <source>Setting: &lt;new setting&gt;</source>
<translation>Einschdellung: &lt;new sedding&gt;</translation>
   </message> 
   <message> 
       <source>INI File</source>
<translation>INI Dadei</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Change setting type</source>
<translation>Ard dr Einschdellung ändern</translation>
   </message> 
   <message> 
       <source>Note</source>
<translation>Hinweis</translation>
   </message> 
   <message> 
       <source>A global setting will override a siteaccess setting</source>
<translation>Eine globale Einschdellung wird oi Einschdellung von a Seide Zugangs überschreiben</translation>
   </message> 
   <message> 
       <source>Tip</source>
<translation>Tib</translation>
   </message> 
   <message> 
       <source>To create an empty array leave the first line empty</source>
<translation>Um oi leers Array z erschdelle, lasset Sie d erschde Zeile leer</translation>
   </message> 
   <message> 
       <source>Siteaccess setting</source>
<translation>Seide Zugang Einschdellungen</translation>
   </message> 
   <message> 
       <source>Override setting (global)</source>
<translation>Überschreibungsoischdellunge (global)</translation>
   </message> 
   <message> 
       <source>Global setting</source>
<translation>Globale Eisndellungen</translation>
   </message> 
   <message> 
       <source>Setting Name</source>
<translation>Nam dr Einschdellung</translation>
   </message> 
   <message> 
       <source>Setting value</source>
<translation>Werd dr Einschdellung</translation>
   </message> 
   <message> 
       <source>Enabled</source>
<translation>Akdivierd</translation>
   </message> 
   <message> 
       <source>Disabled</source>
<translation>Deakdivierd</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Save</source>
<translation>schbeichern</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Die Eingab konnde nedd validierd werden</translation>
   </message> 
   <message> 
       <source>%valfield is empty</source>
<translation>%valfield isch leer</translation>
   </message> 
   <message> 
       <source>Variable %valfield already exists in section %block</source>
<translation>Die Variable %valfield ist bereits in Sektion %block vorhanden</translation>
   </message> 
   <message> 
       <source>Please choose another name that is not already taken</source>
<translation>Bidde wählet Sie oin andere Name, dr no nedd vorgekomme ischd</translation>
   </message> 
   <message> 
       <source>%valfield is not allowed to contain spaces</source>
<translation>%valfield darf koi Leerzeile enthalden</translation>
   </message> 
   <message> 
       <source>Writing setting: %setting_name to file: %filename failed.</source>
<translation>Schreiben von Einstellung: %setting_name in Datei: %filename ist fehlgeschlagen</translation>
   </message> 
   <message> 
       <source>Make sure you have proper permissions to %path and try again.</source>
<translation>vergewissern Sie sich, dass Sie korrekte Rechte auf %path haben und versuchen Sie es nochmals.</translation>
   </message> 
   <message> 
       <source>Name contains illegal character(s).</source>
<translation>Nam enthäld ungüldig Zeile.</translation>
   </message> 
   <message> 
       <source>Name should only contain A-Z and 0-9.</source>
<translation>Nam sollde nur A-Z und 0-9 enthalde.</translation>
   </message> 
   <message> 
       <source>%valfield does not contain a valid string.</source>
<translation>%valfield enthäld koi güldig Zeichenfolg.</translation>
   </message> 
   <message> 
       <source>If the string is all numbers use the numeric type instead.</source>
<translation>Falls d Zeichenkedde nur Zahle verwended, verwendet Sie schdadddesse den numerische Tyb.</translation>
   </message> 
   <message> 
       <source>%valfield does not contain a valid numeric</source>
<translation>%valfield enthäld koi güldig Ziffern</translation>
   </message> 
   <message> 
       <source>A valid numeric can only contain 0-9 and one . (dot).</source>
<translation>Eine güldig Ziffr darf nur 0-9 odr oin . (Punkd) enthalde.</translation>
   </message> 
   <message> 
       <source>$valfield does not contain valid array.</source>
<translation>$valfield enthäld koi güldigs Array.</translation>
   </message> 
   <message> 
       <source>View settings</source>
<translation>Einschdellunge anzeigen</translation>
   </message> 
   <message> 
       <source>Using siteaccess</source>
<translation>Benudzd Seide Zugang</translation>
   </message> 
   <message> 
       <source>%ini_file consist of %blocks section(s) and %setting_count different setting(s)</source>
<translation>%ini_file beschdehd aus %bloggs Sekzion(e) und %sedding_cound underschiedlile Einschdellung(e)</translation>
   </message> 
   <message> 
       <source>Please select an ini file from the dropdown below</source>
<translation>Bidde wählet Sie oi ini-Dadei aus dr Auswahllischde unde aus.</translation>
   </message> 
   <message> 
       <source>Select ini file to view</source>
<translation>Ini-Dadei zur Ansichd auswählen</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>Settings for %inifile in siteaccess %siteaccess</source>
<translation>Einstellungen fÃ¼r %inifile in Seiten Zugang %siteaccess</translation>
   </message> 
   <message> 
       <source>[add setting]</source>
<translation>[Einschdellung hinzfügen]</translation>
   </message> 
   <message> 
       <source>Placement</source>
<translation>Pladzierung</translation>
   </message> 
   <message> 
       <source>Value</source>
<translation>Werd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
</context>
<context>
<name>design/admin/setup</name>
   <message> 
       <source>File consistency check OK.</source>
<translation>Überbrüfung dr Dadeikonsischdenz isch in Ordnung.</translation>
   </message> 
   <message> 
       <source>Warning, it is not safe to upgrade without checking the modifications done to the following files</source>
<translation>Warnung, s isch nedd sichr oi Ubgrad durchzführe ohne d Änderunge in den folgend Dadeie z überbrüfe.</translation>
   </message> 
   <message> 
       <source>Database check OK.</source>
<translation>Überbrüfung dr Dadenbank isch in Ordnung.</translation>
   </message> 
   <message> 
       <source>The database is not consistent with the distribution database.</source>
<translation>Die Dadenbank isch konsischdend mid dr Dadenbank dr Dischdribuzion.</translation>
   </message> 
   <message> 
       <source>To synchronize your database with the distribution setup, run the following SQL commands</source>
<translation>Um d Dadenbank mid dr Dadenbank dr Dischdribuzion abzugleile, führet Sie folgend SQL-Kommandos aus</translation>
   </message> 
   <message> 
       <source>System upgrade check</source>
<translation>Syschdemubgrad Überbrüfung</translation>
   </message> 
   <message> 
       <source>Before upgrading eZ publish to a newer version, it is important to check that the current installation is ready for upgrading.</source>
<translation>Bevor Sie eZ bublish auf oi neie Versio ubgrade, isch s wichdich z überbrüfe, ob d akduelle Inschdallazion bereid für oi Ubgrad isch.</translation>
   </message> 
   <message> 
       <source>Remember to make a backup of the eZ publish directory and the database before you upgrade.</source>
<translation>Vergesset Sie nedd oi Sicherung vom eZ bublish Verzeichnis und dr Dadenbank z mache, bevor Sie oi Ubgrad mache.</translation>
   </message> 
   <message> 
       <source>File consistency check</source>
<translation>Dadeikonsischdenz Überbrüfung</translation>
   </message> 
   <message> 
       <source>The file consistency tool checks if you have altered any of the files that came with the current installation. Altered files may be replaced by new versions which contain bugfixes, new features, etc. Make sure that you backup and then merge in your custom changes into the new versions of the files.</source>
<translation>Die Dadeikonsischdenz Überbrüfung deschded, ob Sie irgendwo Dadeie, d mid dr akduelle Inschdallazion midgeliferd wurde, gänderd hend. Geänderde Dadeie werde evenduell mid neie Versione, d behobene Fehlr, neie Möglichkeide odr ähnlichs enthalde, ersedzd. Sorget Sie dafür, dess Sie Ihre Änderunge sicheret und noh erneid in d neie Versione dr Dadeie oiarbeide.</translation>
   </message> 
   <message> 
       <source>Database consistency check</source>
<translation>Dadenbankkonsischdenz Überbrüfung</translation>
   </message> 
   <message> 
       <source>The database consistency tool checks if the current database is consistent with the database schema that came with the eZ publish distribution. If there are any inconsistencies, the tool will suggest the necessary SQL statements that should be ran in order to bring the database into a consistent state. Please run the suggested SQL statements before upgrading.</source>
<translation>Die Überbrüfung dr Dadenbankkonsischdenz deschded, ob d akduelle Dadenbank dem Schema dr Dadenbank endschbrichd, des mid dr akduelle eZ bublish Dischdribuzion glieferd wurd. Falls Ungereimtheide aufdrede, werde SQL-Befehle vorgeschlage, d ausgeführd werde sollde, um d Dadenbank in oin konsidende Zuschdand z bringe. Bidde führet Sie d SQL-Befehle vor oim Ubgrad aus.</translation>
   </message> 
   <message> 
       <source>The upgrade checking tools require a lot of resources and it may take some time to run them.</source>
<translation>Die Ubgradeüberbrüfung muss oiig Ressource deschde und brauchd dahr evenduell oiig Zeid diese z überbrüfe.</translation>
   </message> 
   <message> 
       <source>Check file consistency</source>
<translation>Überbrüf Dadeikonsischdenz</translation>
   </message> 
   <message> 
       <source>Check database consistency</source>
<translation>Überbrüf Dadenbankkonsischdenz</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/cache</name>
   <message> 
       <source>Content view cache was cleared</source>
<translation>Dr Inhaldansichds-Cache würd gleerd</translation>
   </message> 
   <message> 
       <source>All caches were cleared</source>
<translation>Dr kombledde Cache würd gleerd</translation>
   </message> 
   <message> 
       <source>Ini file cache was cleared</source>
<translation>Dr Cache dr Ini-Dadeie wurd gleerd</translation>
   </message> 
   <message> 
       <source>Template cache was cleared</source>
<translation>Dr Cache dr Temblads wurd gleerd</translation>
   </message> 
   <message> 
       <source>%name was cleared</source>
<translation>%nam wurd gleerd</translation>
   </message> 
   <message> 
       <source>Template overrides and compiled templates</source>
<translation>Überschreib-Temblads und kombilierde Temblades</translation>
   </message> 
   <message> 
       <source>Clear template caches</source>
<translation>Temblade-Cache leeren</translation>
   </message> 
   <message> 
       <source>Content views and template blocks</source>
<translation>Inhaldsansichde und Tembladeblögge</translation>
   </message> 
   <message> 
       <source>Clear content caches</source>
<translation>Cache vom Inhalds leeren</translation>
   </message> 
   <message> 
       <source>Clear ini caches</source>
<translation>Ini-Cache leeren</translation>
   </message> 
   <message> 
       <source>Clear all caches</source>
<translation>De kombledde Cache leeren</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Path</source>
<translation>Pfad</translation>
   </message> 
   <message> 
       <source>Clear selected</source>
<translation>Ausgewählds leeren</translation>
   </message> 
   <message> 
       <source>The following caches were cleared</source>
<translation>Die folgend Teile vom Cache wurde gleerd</translation>
   </message> 
   <message> 
       <source>Clear caches</source>
<translation>Teile vom Cache leeren</translation>
   </message> 
   <message> 
       <source>This operation will clear all the template override caches and the compiled templates. It may lead to weaker performance until the caches are up and running again.</source>
<translation>Diese Oberazion wird alle Überschreibunge und Kombilierunge vo Temblads im Cache lösche. Es führd evenduell solang z oir schwächere Leischdung, bis dr Cache wiedr akduell isch und benudzd wird.</translation>
   </message> 
   <message> 
       <source>This operation will clear all caches that are related to either template views or cache blocks inside the pagelayout template. Use it if you have modified templates or if you have changed something inside a cache block.</source>
<translation>Diese Oberazion wird alle Teile vom Cache lösche, d endwedr Ansichde vo Temblads odr Cache-Blögge im Pagelayoud-Temblade sind. Nudzet Sie des, falls Sie Temblads odr ebbes innerhalb von a Cache-Bloggs gänderd hend.</translation>
   </message> 
   <message> 
       <source>Configuration (ini) caches</source>
<translation>Konfigurazions- (ini-) Cache</translation>
   </message> 
   <message> 
       <source>This operation will clear all the configuration caches. Use it to force the system to re-read the configuration files if you have changed some settings.</source>
<translation>Diese Oberazion wird den kombledde Konfigurazions-Cache leere. Benudzet Sie dis, um des Syschdem z zwinge d Konfigurazionsdadeie nei oizulese, falls Sie Einschdellunge gänderd hend.</translation>
   </message> 
   <message> 
       <source>Everything</source>
<translation>Alles</translation>
   </message> 
   <message> 
       <source>This operation will clear ALL the caches and may lead to long response times until the caches are up and running again.</source>
<translation>Diese Oberazion wird ALLE Teile vom Cachs lösche und führd evenduell solang z lange Reakzionszeide, bis dr Cache nei erschdelld wurd und wiedr benudzd wird.</translation>
   </message> 
   <message> 
       <source>Fine-grained cache control</source>
<translation>Foikondrolle übr den Cache</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select the &lt;%cache_name&gt; for clearing.</source>
<translation>&lt;%cache_name&gt; zum Leeren auswÃ¤hlen.</translation>
   </message> 
   <message> 
       <source>The &lt;%cache_name&gt; is disabled and thus it can not be marked for clearing.</source>
<translation>&lt;%cache_name&gt; ist deaktiviert und kann daher nicht zum Leeren ausgewÃ¤hlt werden.</translation>
   </message> 
   <message> 
       <source>Clear the selected caches.</source>
<translation>Die ausgewählde Teile vom Cachs lösche.</translation>
   </message> 
   <message> 
       <source>Static content cache was regenerated</source>
<translation>Schdadischr Inhalds-Cache wurd erschdelld</translation>
   </message> 
   <message> 
       <source>Static content cache</source>
<translation>Schdadischr Inhalds-Cache</translation>
   </message> 
   <message> 
       <source>Regenerate static content cache</source>
<translation>De schdadische Inhalds-Cache nei erschdellen</translation>
   </message> 
   <message> 
       <source>This operation will regenerate all the static content caches that are configured. This action can take quite some time depending on the specifications of the server and the number of locations that are configured to be statically cached. If you encounter time-out problems, please use the &amp;quot;bin/php/makestaticcache.php&amp;quot; shell script.</source>
<translation>Diese Oberazion wird alle schdadische Inhalds-Cache nei erschdelle, d konfigurierd sind. Dis kann oiig Zeid daueret, abhängich vo den Schbezifikazione vom Servr und dr Anzahl dr Orde, d als schdadisch konfigurierd sind. Falls Sie Problem mid Timeouds bekomme, benudzet Sie bidde des Shell-Scribd &amp;quod;bin/fb/makeschdadiccache.fb&amp;quod;.</translation>
   </message> 
   <message> 
       <source>Create new</source>
<translation>Nei erzeigen</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/datatypecode</name>
   <message> 
       <source>Constructor</source>
<translation>Konschdrukdor</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/extensions</name>
   <message> 
       <source>Available extensions [%extension_count]</source>
<translation>VerfÃ¼gbare Erweiterungen [%extension_count]</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Activate or deactivate extension. Use the &quot;Apply changes&quot; button to apply the changes.</source>
<translation>Akdiviere odr Deakdiviere oir Erweiderung. Benudzet Sie den Knobf &quot;Änderunge anwenden&quot;, um d Änderunge anzwende.</translation>
   </message> 
   <message> 
       <source>There are no available extensions.</source>
<translation>Es gibd koi verfügbare Erweiderunge.</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified the status of the checkboxes above.</source>
<translation>Kligget Sie auf diese Knobf, falls Sie d Ankreizfeldr obe gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/info</name>
   <message> 
       <source>System information</source>
<translation>Syschdeminformazionen</translation>
   </message> 
   <message> 
       <source>Site</source>
<translation>Seide</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>SVN revision</source>
<translation>SVN Revision</translation>
   </message> 
   <message> 
       <source>Extensions</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Extensions</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>Miscellaneous</source>
<translation>Verschiedenes</translation>
   </message> 
   <message> 
       <source>Safe mode is on.</source>
<translation>Saf Mod isch an.</translation>
   </message> 
   <message> 
       <source>Safe mode is off.</source>
<translation>Saf Mod isch aus.</translation>
   </message> 
   <message> 
       <source>Basedir restriction is on and set to %1.</source>
<translation>Basedir Restriction ist an und auf %1 gesetzt.</translation>
   </message> 
   <message> 
       <source>Basedir restriction is off.</source>
<translation>Basedir Reschdriczion isch aus.</translation>
   </message> 
   <message> 
       <source>Global variable registration is on.</source>
<translation>Global Variable Regischdrazion isch an.</translation>
   </message> 
   <message> 
       <source>Global variable registration is off.</source>
<translation>Global Variable Regischdrazion isch aus.</translation>
   </message> 
   <message> 
       <source>File uploading is enabled.</source>
<translation>Dadei Ubload isch an.</translation>
   </message> 
   <message> 
       <source>File uploading is disabled.</source>
<translation>Dadei Ubload isch aus.</translation>
   </message> 
   <message> 
       <source>Maximum size of post data (text and files) is %1.</source>
<translation>Maximale GrÃ¶Ãe der gesendeten Daten (Text und Dateien) ist %1.</translation>
   </message> 
   <message> 
       <source>Script memory limit is %1.</source>
<translation>Script Memory Limit ist %1.</translation>
   </message> 
   <message> 
       <source>Maximum execution time is %1 seconds.</source>
<translation>Maximum Execution Time ist %1 Sekunden.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Modules</source>
<translation>Module</translation>
   </message> 
   <message> 
       <source>eZ publish was unable to extract information from the webserver.</source>
<translation>eZ bublish war nedd ind r Lag Informazione vom Webservr z exdrahiere.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Version information could not be detected.</source>
<translation>Die Versionsinformazion konnde nedd erkannd werde.</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Enabled.</source>
<translation>Akdivierd.</translation>
   </message> 
   <message> 
       <source>Disabled.</source>
<translation>Deakdivierd.</translation>
   </message> 
   <message> 
       <source>Database</source>
<translation>Dadenbank</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Server</source>
<translation>Server</translation>
   </message> 
   <message> 
       <source>Socket path</source>
<translation>Sogged Pfad</translation>
   </message> 
   <message> 
       <source>Not in use.</source>
<translation>Nedd in Benudzung.</translation>
   </message> 
   <message> 
       <source>Database name</source>
<translation>Nam dr Dadenbank</translation>
   </message> 
   <message> 
       <source>Connection retry count</source>
<translation>Zahl dr Neiversuche oi Verbindung zur Dadenbank herzschdellen</translation>
   </message> 
   <message> 
       <source>Character set</source>
<translation>Verwendedr Zeichensadz</translation>
   </message> 
   <message> 
       <source>Internal</source>
<translation>Indern</translation>
   </message> 
   <message> 
       <source>Slave database (read only)</source>
<translation>Slave-Dadenbank (nur lese)</translation>
   </message> 
   <message> 
       <source>Database</source>
<translation>Dadenbank</translation>
   </message> 
   <message> 
       <source>There is no slave database in use.</source>
<translation>Es isch koi Slave-Dadenbank in Verwendung.</translation>
   </message> 
   <message> 
       <source>eZ publish</source>
<translation>eZ bublish</translation>
   </message> 
   <message> 
       <source>PHP</source>
<translation>PHP</translation>
   </message> 
   <message> 
       <source>PHP Accelerator</source>
<translation>PHP Beschleiniger</translation>
   </message> 
   <message> 
       <source>A known and active PHP accelerator could not be found.</source>
<translation>Es konnde koi bekanndr PHP Beschleinigr erkannd werde.</translation>
   </message> 
   <message> 
       <source>Webserver (software)</source>
<translation>Webservr (Sofdware)</translation>
   </message> 
   <message> 
       <source>The modules of the webserver could not be detected.</source>
<translation>Die Module vom Webservers konnde nedd erkannd werde.</translation>
   </message> 
   <message> 
       <source>Webserver (hardware)</source>
<translation>Webservr (Hardware)</translation>
   </message> 
   <message> 
       <source>CPU</source>
<translation>CPU</translation>
   </message> 
   <message> 
       <source>Memory</source>
<translation>Schbeicher</translation>
   </message> 
   <message> 
       <source>Script memory limit is Unlimited.</source>
<translation>Des Schbeicherlimid für Scribde isch nedd beschränkd.</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/operatorcode</name>
   <message> 
       <source>Example</source>
<translation>Beischbiel</translation>
   </message> 
   <message> 
       <source>Constructor, does nothing by default.</source>
<translation>Konschdrukdor hedd schdandardmäßich koi Aufgab.</translation>
   </message> 
   <message> 
       <source>\return an array with the template operator name.</source>
<translation>Geb oin Array mid dem Tembaldeoberadorname zurügg.</translation>
   </message> 
   <message> 
       <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
<translation>Für d PHP Funkzion für d Oberador Säuberung aus und modifizierd \a $oberadorValue.</translation>
   </message> 
   <message> 
       <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
<translation>Beischbil cod, deisr cod muss modifizierd werde, um z dun was dr Oberador dun muss. Zur Zeid kürzd von dene Texd.</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/rad</name>
   <message> 
       <source>Rapid Application Development Tools</source>
<translation>Werkzeig zur schnelle Anwendungs-Endwigglung</translation>
   </message> 
   <message> 
       <source>The rapid application development (RAD) tools make the creation of new/extended functionality for eZ publish easier. Currently there are two RAD tools available: the template operator wizard and the datatype wizard. The template operator wizard basically generates a valid framework (PHP code) for a new template operator. The datatype wizard generates a valid framework (PHP code) for a new datatype.</source>
<translation>Des Werkzeig zur schnelle Anwendungs-Endwigglung (rabid abblicazion develobmend, RAD) veroifachd d Endwigglung vo neie odr erweiderde Funkzione vo eZ bublish. Im Momend gibd s zwei RAD Werkzeige: Dr Assischdend für Temblade Oberadore und dr Assischdend für Dadendybe. Dr Assischdend für Temblade Oberadore erschdelld haubdsächlich oi güldig Umgebung (PHP Cod) für neie Temblade Oberadore. Dr Assischdend für Dadendybe erschdelld oi güldig Umgebung (PHP Cod) für oin neie Dadendybe.</translation>
   </message> 
   <message> 
       <source>Available RAD tools</source>
<translation>Verfügbare RAD Werkzeige</translation>
   </message> 
   <message> 
       <source>Template operator wizard</source>
<translation>Assischdend für Temblade Oberadoren</translation>
   </message> 
   <message> 
       <source>Datatype wizard</source>
<translation>Dadendyb-Assischdend</translation>
   </message> 
   <message> 
       <source>Template operator wizard (step 1 of 3)</source>
<translation>Assischdend für Temblade Oberadore (Schridd 1 vo 3)</translation>
   </message> 
   <message> 
       <source>Welcome to the template operator wizard. Template operators are usually used for manipulating template variables. However, they can also be used to generate or fetch data. This wizard will take you through a couple of steps with some basic choices. When finished, eZ publish will generate a PHP framework for the a new operator (which will be available for download).</source>
<translation>Willkomme zum Assischdend für Temblade Oberadore. Temblade Oberadore werde normalerweise benudzd um Tembladevariable z manibuliere. Sie könne abr au daz genudzd werde um Dade z erzeige odr auszulese. Diesr Assischdend wird Sie durch oiig Schridde mid grundsädzlile Auswahlmöglichkeide führe. Wenn r beended isch, wird eZ bublish oi Umgebung in PHP für oin neie Oberadore erzeige (dr noh zum Download bereidschdehd).</translation>
   </message> 
   <message> 
       <source>Restart</source>
<translation>Neischdard</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/rad/datatype</name>
   <message> 
       <source>Datatype wizard (step 1 of 3)</source>
<translation>Dadendyb-Assischdend (Schridd 1 vo 3)</translation>
   </message> 
   <message> 
       <source>Restart</source>
<translation>Neischdard</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
   <message> 
       <source>Datatype wizard (step 2 of 3)</source>
<translation>Dadendyb-Assischdend (Schridd 2 vo 3)</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Descriptive name</source>
<translation>Beschreibendr Name</translation>
   </message> 
   <message> 
       <source>Handle input on class level</source>
<translation>Eingab auf Klassen-Ebene bearbeiden</translation>
   </message> 
   <message> 
       <source>Datatype wizard (step 3 of 3)</source>
<translation>Dadendyb-Assischdend (Schridd 3 vo 3)</translation>
   </message> 
   <message> 
       <source>Name of class</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Constant name</source>
<translation>Konschdanden-Name</translation>
   </message> 
   <message> 
       <source>The creator of the datatype</source>
<translation>Dr Erschdellr vom Dadendybs</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Handles the datatype %datatype_name. By using %datatype_name you can ...</source>
<translation>Handles the datatype %datatype_name. By using %datatype_name you can ...</translation>
   </message> 
   <message> 
       <source>Hint: The first line will be used as the brief description. The rest will become operator documentation.</source>
<translation>Hilfe: Die erschde Zeile wird als kurze Beschreibung verwended. Dr Resch wird d Dokumendazion vom Oberadore.</translation>
   </message> 
   <message> 
       <source>Finish and generate</source>
<translation>Beende und Erzeigen</translation>
   </message> 
   <message> 
       <source>Welcome to the wizard for creating a new datatypes. Everything you store in your content objects are called attributes. These attributes are defined as a data types. To be able to customize the storing and validation of these attributes, you can create your own data types.</source>
<translation>Willkomme im Assidende zum Erzeige von a neie Dadendybs. Alls, was Sie in Ihre Inhaldsobjekde schbeicheret, wird Addribuade genannd. Diese Addribuade sind als Dadendybe definierd. Um in dr Lag z soi des Schbeicheret udn Validiere von dene Addribuade anzubasse, könnet Sie Ihre eigene Dadendybe erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/rad/templateoperator</name>
   <message> 
       <source>Template operator wizard (step 2 of 3)</source>
<translation>Assischdend für Temblade Oberadore (Schridd 2 vo 3)</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Handles input</source>
<translation>Handhabd Eingaben</translation>
   </message> 
   <message> 
       <source>Generates output</source>
<translation>Generierd Ausgabe</translation>
   </message> 
   <message> 
       <source>Parameters</source>
<translation>Parameder</translation>
   </message> 
   <message> 
       <source>No parameters</source>
<translation>Koi Parameder</translation>
   </message> 
   <message> 
       <source>Named parameters</source>
<translation>Benannde Parameder</translation>
   </message> 
   <message> 
       <source>Sequential parameters</source>
<translation>Sequenzielle Parameder</translation>
   </message> 
   <message> 
       <source>Custom</source>
<translation>Individuell</translation>
   </message> 
   <message> 
       <source>Restart</source>
<translation>Neischdard</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
   <message> 
       <source>Template operator wizard (step 3 of 3)</source>
<translation>Assischdend für Temblade Oberadore (Schridd 3 vo 3)</translation>
   </message> 
   <message> 
       <source>Class name</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Author</source>
<translation>Author</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Handles template operator %operator_name. By using %operator_name you can...</source>
<translation>Handles template operator %operator_name. By using %operator_name you can...</translation>
   </message> 
   <message> 
       <source>Hint: The first line will be used for the brief description. The rest will become the documentation.</source>
<translation>Hinweis: Die erschde zeile wird als kurze Beschreibung verwended. Dr Resch wird d Dokumendazion werde.</translation>
   </message> 
   <message> 
       <source>Example code</source>
<translation>Beischbil Code</translation>
   </message> 
   <message> 
       <source>Hint: Feel free to add example code that demonstrates how the operator works.</source>
<translation>Hinweis: Gebet Sie ruhich mehr Beischbil Cod oi, dr zeigd wie dr Oberador funkzionierd.</translation>
   </message> 
   <message> 
       <source>Finish and generate</source>
<translation>Abschließe und Erzeigen</translation>
   </message> 
</context>
<context>
<name>design/admin/setup/session</name>
   <message> 
       <source>The sessions were successfully removed.</source>
<translation>Die Sidzunge wurde erfolgreich endfernd.</translation>
   </message> 
   <message> 
       <source>Session administration</source>
<translation>Sidzungsverwaldung</translation>
   </message> 
   <message> 
       <source>Sessions</source>
<translation>Sidzungen</translation>
   </message> 
   <message> 
       <source>Total number of sessions</source>
<translation>Anzahl Sidzunge gsamd</translation>
   </message> 
   <message> 
       <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
<translation>Es sind %logged_in_count registrierte und %anonymous_count anonyme Benutzer online.</translation>
   </message> 
   <message> 
       <source>WARNING! When you remove sessions, users that are logged in will be logged out from the system.</source>
<translation>WARNUNG, hajo, so isch des ! Wenn Sie Sidzunge endferne, werde angemeldede Benudzr vom Syschdem abgemelded.</translation>
   </message> 
   <message> 
       <source>Remove all sessions</source>
<translation>Alle Sidzunge endfernen</translation>
   </message> 
   <message> 
       <source>Remove timed out / old sessions</source>
<translation>Abgelaufene / alde Sidzunge endfernen</translation>
   </message> 
   <message> 
       <source>Filtered sessions</source>
<translation>Gefilderde Sidzungen</translation>
   </message> 
   <message> 
       <source>Displaying sessions for %username</source>
<translation>Sitzungen fÃ¼r Benutzer %username anzeigen</translation>
   </message> 
   <message> 
       <source>Sessions for all users</source>
<translation>Sidzunge allr Benudzer</translation>
   </message> 
   <message> 
       <source>Users</source>
<translation>Benudzer</translation>
   </message> 
   <message> 
       <source>Everyone</source>
<translation>Jeder</translation>
   </message> 
   <message> 
       <source>Registered users</source>
<translation>Angemeldede Benudzer</translation>
   </message> 
   <message> 
       <source>Anonymous users</source>
<translation>Anonym Benudzer</translation>
   </message> 
   <message> 
       <source>Update list</source>
<translation>Lischde akdualisieren</translation>
   </message> 
   <message> 
       <source>Include inactive users</source>
<translation>Inakdive Benudzr oischließen</translation>
   </message> 
   <message> 
       <source>Invert selection</source>
<translation>Auswahl umkehren</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>Count</source>
<translation>Zählen</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Full name</source>
<translation>Vollr Name</translation>
   </message> 
   <message> 
       <source>Idle time</source>
<translation>Undädig Zeid</translation>
   </message> 
   <message> 
       <source>Idle since</source>
<translation>Undädich seid</translation>
   </message> 
   <message> 
       <source>Select session for removal.</source>
<translation>Sidzung zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Time skew detected</source>
<translation>Zeidversadz erkannd</translation>
   </message> 
   <message> 
       <source>There are no sessions matching the selected options.</source>
<translation>Es gibd koi Sidzunge, d den ausgewählde Obzione endschbrele.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected sessions.</source>
<translation>Ausgewählde Sidzunge endferne.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/accounthandlers/html/ez</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Company</source>
<translation>Undernehmen</translation>
   </message> 
   <message> 
       <source>Street</source>
<translation>Schdraße</translation>
   </message> 
   <message> 
       <source>Zip code</source>
<translation>Poschdleidzahl</translation>
   </message> 
   <message> 
       <source>Place</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>State</source>
<translation>Schdaad</translation>
   </message> 
   <message> 
       <source>Country</source>
<translation>Land</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/basket</name>
   <message> 
       <source>Shopping basket</source>
<translation>Warenkorb</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Price (ex. VAT)</source>
<translation>Preis (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Price (inc. VAT)</source>
<translation>Preis (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Total (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total (inc. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>Subtotal (ex. VAT)</source>
<translation>Zwischensumm (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Subtotal (inc. VAT)</source>
<translation>Zwischensumm (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Continue shopping</source>
<translation>Weidr oikaufen</translation>
   </message> 
   <message> 
       <source>Checkout</source>
<translation>Kasse</translation>
   </message> 
   <message> 
       <source>Items removed</source>
<translation>Ardikl endfernd</translation>
   </message> 
   <message> 
       <source>The following items were removed from your basket because the products have changed</source>
<translation>Die folgende Ardikl wurde aus Ihrem Warenkorb endfernd weil si d Produkde veränderd hend.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select item for removal.</source>
<translation>Ardikl zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>There are no items in your shopping basket.</source>
<translation>Es sind koi Ardikl in Ihrem Warenkorb.</translation>
   </message> 
   <message> 
       <source>Remove selected items from the basket.</source>
<translation>Ausgewählde Ardikl aus dem Warenkorb endferne.</translation>
   </message> 
   <message> 
       <source>Click this button to update the basket if you have modified any quantity and/or option fields.</source>
<translation>Kligget Sie auf diese Knobf, um den Warenkob z akdualisiere, falls Sie d Meng und/odr Obzione gänderd hend.</translation>
   </message> 
   <message> 
       <source>Leave the basket and continue shopping.</source>
<translation>De Warenkorb verlasse und mid dem Einkauf fordsedze.</translation>
   </message> 
   <message> 
       <source>Proceed to checkout and purchase the items that are in the basket.</source>
<translation>Zur Kasse gehe und d Ardikl im Warenkorb erwerbe.</translation>
   </message> 
   <message> 
       <source>You can not remove any items because there are no items in the basket.</source>
<translation>Sie könne koi Ardikl aus dem Warenkorb endferne, weil r koi enthäld.</translation>
   </message> 
   <message> 
       <source>You can not store any changes because the basket is empty.</source>
<translation>Sie könne koi Änderunge schbeicheret, da Ihr Warenkorb ler isch.</translation>
   </message> 
   <message> 
       <source>You can not check out because the basket is empty.</source>
<translation>Sie könne nedd zur Kasse gehe, da Ihr Warenkorb ler isch.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/browse_discountcustomer</name>
   <message> 
       <source>Choose customers for discount group</source>
<translation>Kunde für oi Ermäßigungsgrubb auswähle.</translation>
   </message> 
   <message> 
       <source>Use the checkboxes to select users and user groups (customers) that you wish to add to the discount group.</source>
<translation>Benudzet Sie d Ankreizfeldr um Benudzr odr Benudzergrubbe (Kunde) auszwähle, d in oi Ermäßigungsgrubb hinzugefügd werde solle.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/browse_discountgroup</name>
   <message> 
       <source>Choose products for discount group</source>
<translation>Wählet Sie Produkde für oi Ermäßigungsgrubbe</translation>
   </message> 
   <message> 
       <source>Use the checkboxes to select products to be included in the discount group.</source>
<translation>Benudzet Sie d Ankreizfeldr um Produkde auszwähle, d oir Ermäßigungsgrubb hinzugefügd werde solle.</translation>
   </message> 
   <message> 
       <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
<translation>Navigieret Sie mid den verfügbare Regischderet (obe), dem Baummenu (links) und dr Inhalds-Lischde (Midde).</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/confirmorder</name>
   <message> 
       <source>Order confirmation</source>
<translation>Beschdädigung dr Beschdellung</translation>
   </message> 
   <message> 
       <source>Please confirm that the information below is correct. Click &quot;Confirm order&quot; to confirm the order.</source>
<translation>Bidde beschdädiget Sie, dess d Informazione unde recht sind. Kligget Sie auf &quot;Beschdellung beschdädigen&quot; um d Beschdellung z beschdädige.</translation>
   </message> 
   <message> 
       <source>Customer</source>
<translation>Kunde</translation>
   </message> 
   <message> 
       <source>Items to be purchased</source>
<translation>Ardikl d kaufd werden</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Price (ex. VAT)</source>
<translation>Preis (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Price (inc. VAT)</source>
<translation>Preis (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Total price (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total price (inc. VAT)</source>
<translation>Insgesamd (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>Order summary</source>
<translation>Beschdellauflischdung</translation>
   </message> 
   <message> 
       <source>Subtotal of items</source>
<translation>Zwischensumm dr Posizionen</translation>
   </message> 
   <message> 
       <source>Order total</source>
<translation>Kombledde Beschdellsumme</translation>
   </message> 
   <message> 
       <source>Confirm order</source>
<translation>Beschdellung beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/customerlist</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Orders</source>
<translation>Beschdellung</translation>
   </message> 
   <message> 
       <source>Total (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total (inc. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>The customer list is empty.</source>
<translation>Die Lischde dr Kunde isch ler.</translation>
   </message> 
   <message> 
       <source>Customers [%customers]</source>
<translation>Kunden [%customers]</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/customerorderview</name>
   <message> 
       <source>Customer information</source>
<translation>Kundeninformazion</translation>
   </message> 
   <message> 
       <source>Orders [%order_count]</source>
<translation>Bestellungen [%order_count]</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Total (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total (inc. VAT)</source>
<translation>Insgesamd (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Time</source>
<translation>Zeid</translation>
   </message> 
   <message> 
       <source>Purchased products [%product_count]</source>
<translation>Gekaufte Produkte [%product_count]</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/discountgroup</name>
   <message> 
       <source>Discount groups [%discount_groups]</source>
<translation>ErmÃ¤Ãigungsgruppen [%discount_groups]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New discount group</source>
<translation>Neie Ermäßigungsgrubbe</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select discount group for removal.</source>
<translation>Ermäßigungsgrubb zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%discountgroup_name&gt; discount group.</source>
<translation>Bearbeiten von ErmÃ¤Ãigungsgruppe &lt;%discountgroup_name&gt;</translation>
   </message> 
   <message> 
       <source>There are no discount groups.</source>
<translation>Es gibd koi Ermäßigungsgrubbe.</translation>
   </message> 
   <message> 
       <source>Remove selected discount groups.</source>
<translation>Die ausgewählde Ermäßigungsgrubbe endferne.</translation>
   </message> 
   <message> 
       <source>Create a new discount group.</source>
<translation>Neie Ermäßigungsgrubb erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/discountgroupedit</name>
   <message> 
       <source>Edit &lt;%discount_group&gt; [Discount group]</source>
<translation>Bearbeiten von &lt;%discount_group&gt; [ErmÃ¤Ãigungsgruppe]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/discountgroupmembershipview</name>
   <message> 
       <source>%discount_group [Discount group]</source>
<translation>%discound_groub [Ermäßigungsgrubbe]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Discount rules [%rule_count]</source>
<translation>ErmÃ¤Ãigungsregeln [%rule_count]</translation>
   </message> 
   <message> 
       <source>Percent</source>
<translation>Prozend</translation>
   </message> 
   <message> 
       <source>Apply to</source>
<translation>Anwende auf</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New discount rule</source>
<translation>Neie Ermäßigungsregel</translation>
   </message> 
   <message> 
       <source>Edit this discount group.</source>
<translation>Diese Ermäßigungsgrubb bearbeide.</translation>
   </message> 
   <message> 
       <source>Remove this discount group.</source>
<translation>Diese Ermäßigungsgrubb endferne.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select discount rule for removal.</source>
<translation>Ermäßigungsregeln zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%discount_rule_name&gt; discount rule.</source>
<translation>Bearbeiten von ErmÃ¤Ãigungsregel &lt;%discount_rule_name&gt;</translation>
   </message> 
   <message> 
       <source>There are no discount rules in this group.</source>
<translation>In von dene Grubb sind koi Ermäßigungsregeln.</translation>
   </message> 
   <message> 
       <source>Remove selected discount rules.</source>
<translation>Ausgewählde Ermäßigungsregeln endferne.</translation>
   </message> 
   <message> 
       <source>Create a new discount rule and add it to the &lt;%discount_group_name&gt; discount group.</source>
<translation>Neue ErmÃ¤Ãigungsregeln erstellen und zur ErmÃ¤Ãigungsgruppe &lt;%discount_group_name&gt; hinzufÃ¼gen.</translation>
   </message> 
   <message> 
       <source>Customers (users and user groups) [%customer_count]</source>
<translation>Kunden (Benutzer und Benutzergruppen) [%customer_count]</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Select user or user group for removal.</source>
<translation>Benudzr odr Benudzergrubb zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>There are no customers in this discount group.</source>
<translation>Es gibd koi Kunde in von dene Ermäßigungsgrubb.</translation>
   </message> 
   <message> 
       <source>Remove selected users and/or user groups.</source>
<translation>Ausgewählde Benudzr und/odr Grubbe endferne.</translation>
   </message> 
   <message> 
       <source>Add customers</source>
<translation>Kund hinzfügen</translation>
   </message> 
   <message> 
       <source>Add users and/or user groups to the &lt;%discount_group_name&gt; discount group.</source>
<translation>Benutzer und/oder Benutzergruppen zur ErmÃ¤Ãigungsgruppe &lt;%discount_group_name&gt; hinzufÃ¼gen.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/discountruleedit</name>
   <message> 
       <source>Edit &lt;%rule_name&gt; [Discount rule]</source>
<translation>Bearbeiten von &lt;%rule_name&gt; [ErmÃ¤Ãigungsregel]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Discount percent</source>
<translation>Ermäßigungs Prozendsadz</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>New discount rule</source>
<translation>Neie Ermäßigungsregel</translation>
   </message> 
   <message> 
       <source>Product types</source>
<translation>Produkdarden</translation>
   </message> 
   <message> 
       <source>in sections</source>
<translation>in Sekzionen</translation>
   </message> 
   <message> 
       <source>Individual products</source>
<translation>Individuelle Produkde</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>The individual product list is empty.</source>
<translation>Die Lischde dr individuelle Produkde isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add products</source>
<translation>Produkde hinzfügen</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/orderlist</name>
   <message> 
       <source>Orders [%count]</source>
<translation>Bestellungen [%count]</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Customer</source>
<translation>Kunde</translation>
   </message> 
   <message> 
       <source>Total (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total (inc. VAT)</source>
<translation>Insgesamd (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Time</source>
<translation>Zeid</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Ascending</source>
<translation>Aufschdeigend</translation>
   </message> 
   <message> 
       <source>Descending</source>
<translation>Abschdeigend</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select order for removal.</source>
<translation>Beschdellung zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>The order list is empty.</source>
<translation>Die Lischde dr Beschdellunge isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected orders.</source>
<translation>Ausgewählde Beschdellunge lösche.</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified any of the fields above.</source>
<translation>Kligget Sie auf diese Knobf um d Änderunge z schbeicheret, falls Sie ois dr Feldr obe veränderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/orderstatistics</name>
   <message> 
       <source>Product statistics [%count]</source>
<translation>Produkt Statistik [%count]</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>Total (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total (inc. VAT)</source>
<translation>Insgesamd (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>All years</source>
<translation>Alle Jahre</translation>
   </message> 
   <message> 
       <source>All months</source>
<translation>Alle Monade</translation>
   </message> 
   <message> 
       <source>Show</source>
<translation>Zeigen</translation>
   </message> 
   <message> 
       <source>SUM</source>
<translation>SUM</translation>
   </message> 
   <message> 
       <source>The list is empty.</source>
<translation>Die Lischde isch ler.</translation>
   </message> 
   <message> 
       <source>Select the year for which you wish to view statistics.</source>
<translation>Wählet Sie des Jahr aus, des in dr Schdadischdik angezeigd werde soll.</translation>
   </message> 
   <message> 
       <source>Select the month for which you wish to view statistics.</source>
<translation>Wählet Sie den Monad aus, dr in dr Schdadischdik angezeigd werde soll.</translation>
   </message> 
   <message> 
       <source>Update the list using the values specified by the menus on the left.</source>
<translation>Die Lischde undr Verwendung dr Menüs links akdualisieren</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/orderview</name>
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Product items</source>
<translation>Produkde</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Count</source>
<translation>Zählen</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Price ex. VAT</source>
<translation>Preis ohne MwSchd.</translation>
   </message> 
   <message> 
       <source>Price inc. VAT</source>
<translation>Preis mid MwSchd</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Total Price ex. VAT</source>
<translation>Gesamd Preis exklusive MwSchd</translation>
   </message> 
   <message> 
       <source>Total Price inc. VAT</source>
<translation>Gesamd Preis inkl. MwSchd</translation>
   </message> 
   <message> 
       <source>Order summary</source>
<translation>Beschdellauflischdung</translation>
   </message> 
   <message> 
       <source>Subtotal of items</source>
<translation>Zwischensumm dr Posizionen</translation>
   </message> 
   <message> 
       <source>Order total</source>
<translation>Kombledde Beschdellsumme</translation>
   </message> 
   <message> 
       <source>Remove this order.</source>
<translation>Diese Beschdellung endferne.</translation>
   </message> 
   <message> 
       <source>Order #%order_id [%order_status]</source>
<translation>Bestellung #%order_id [%order_status]</translation>
   </message> 
   <message> 
       <source>Date</source>
<translation>Dadum</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Person</source>
<translation>Person</translation>
   </message> 
   <message> 
       <source>This is the person which modified the status of the order. Click to view the user information.</source>
<translation>Des isch d Perso, d den Schdadus dr Beschdellung gänderd hedd. Kligget Sie um d Benudzerinformazion z sehe.</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>Status history [%status_count]</source>
<translation>Statushistorie [%status_count]</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/removeorder</name>
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Confirm order removal</source>
<translation>Beschdädigung vom Endfernens dr Beschdellung</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove order #%order_number?</source>
<translation>Sind Sie sicher, dass Sie die Bestellung #%order_number entfernen wollen?</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove the following orders?</source>
<translation>Sind Sie sichhr, dess Sie d folgende beschdellunge endferne wolle?</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/status</name>
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified any of the fields above.</source>
<translation>Kligget Sie auf diese Knobf um d Änderunge z schbeicheret, falls Sie von a dr Feldr oberhalb gänderd hend.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Status ID</source>
<translation>Schdadus ID</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Select order status for removal.</source>
<translation>Schdadus dr Beschdellung zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Check this if you want the status to be usable in the shopping system.</source>
<translation>Wählet Sie des an, wenn dr Schdadus im Shobsyschdem nudzbar soi soll.</translation>
   </message> 
   <message> 
       <source>There are no order statuses.</source>
<translation>Es gibd koin Beschdellschdadus</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove selected order statuses.</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>New order status</source>
<translation>Neir Beschdellschdadus</translation>
   </message> 
   <message> 
       <source>Create a new order status.</source>
<translation>Eine neie Beschdellschdadus erschdelle.</translation>
   </message> 
   <message> 
       <source>Order status [%order_status]</source>
<translation>Bestellstatus [%order_status]</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/userregister</name>
   <message> 
       <source>Required information is missing...</source>
<translation>Benödigde Informazion wird vermissch...</translation>
   </message> 
   <message> 
       <source>Please please fill in the fields that are marked with a star.</source>
<translation>Bidde füllet Sie d Feldr aus, d mid oim Schderet markierd sind.</translation>
   </message> 
   <message> 
       <source>Account information</source>
<translation>Kondoinformazionen</translation>
   </message> 
   <message> 
       <source>Please fill in the necessary information. Required fields are marked with a star.</source>
<translation>Bidde gebet Sie d nodwendige Informazione an. Benödigde Feldr sind mid oim Schderet markierd.</translation>
   </message> 
   <message> 
       <source>First name</source>
<translation>Vorname</translation>
   </message> 
   <message> 
       <source>Last name</source>
<translation>Nachname</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Company</source>
<translation>Undernehmen</translation>
   </message> 
   <message> 
       <source>Street</source>
<translation>Schdraße</translation>
   </message> 
   <message> 
       <source>ZIP code</source>
<translation>Poschdleidzahl</translation>
   </message> 
   <message> 
       <source>City</source>
<translation>Schdadd</translation>
   </message> 
   <message> 
       <source>State</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Country</source>
<translation>Land</translation>
   </message> 
   <message> 
       <source>Comments</source>
<translation>Kommendare</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/vattype</name>
   <message> 
       <source>VAT types [%vat_types]</source>
<translation>MwSt.-Typen [%vat_types]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Percentage</source>
<translation>Prozendsadz</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select VAT type for removal.</source>
<translation>MwSchd.-Tyb zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>There are no VAT types.</source>
<translation>Es gibd koi MwSchd.-Tybe.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected VAT types.</source>
<translation>Ausgewählde MwSchd.-Tybe endferne.</translation>
   </message> 
   <message> 
       <source>New VAT type</source>
<translation>Neir MwSchd.-Tyb</translation>
   </message> 
   <message> 
       <source>Create a new VAT type.</source>
<translation>Eine neie MwSchd.-Tyb erschdelle.</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified any of the fields above.</source>
<translation>Kligget Sie auf diese Knobf um d Änderunge z schbeicheret, falls Sie von a dr Feldr obe gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/shop/wishlist</name>
   <message> 
       <source>My wish list [%item_count]</source>
<translation>Meine Wunschliste [%item_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Price (ex. VAT)</source>
<translation>Preis (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Price (inc. VAT)</source>
<translation>Preis (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Total price (ex. VAT)</source>
<translation>Insgesamd (ohne MwSchd.)</translation>
   </message> 
   <message> 
       <source>Total price (inc. VAT)</source>
<translation>Insgesamd (mid MwSchd.)</translation>
   </message> 
   <message> 
       <source>Select item for removal.</source>
<translation>Ardikl zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>The wish list is empty.</source>
<translation>Die Wunschlischde isch ler.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected items.</source>
<translation>Ausgewählde Ardikl endferne.</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified quantity and/or option values.</source>
<translation>Kligget Sie auf diese Knobf um d Änderunge z schbeicheret, falls d d Meng und/odr d Obzione gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/trigger/list</name>
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Connection type</source>
<translation>Ard dr Verbindung</translation>
   </message> 
   <message> 
       <source>Workflow</source>
<translation>Workflow</translation>
   </message> 
   <message> 
       <source>No workflow</source>
<translation>Koi Workflow</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Workflow triggers [%trigger_count]</source>
<translation>Workflow AuslÃ¶ser [%trigger_count]</translation>
   </message> 
   <message> 
       <source>Select the workflow that should be triggered %type the %function function is executed within the %module module.</source>
<translation>WÃ¤hlen Sie den Workflow, der ausgelÃ¶st werden soll (%type), wenn die Funktion &quot;%function&quot; im Modul &quot;%module&quot; ausgefÃ¼hrt wird.</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified any of the fields above.</source>
<translation>Kligget Sie auf diese Knobf um Änderunge z schbeicheret, falls Sie obig Feldr gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/url/edit</name>
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Edit URL #%url_id</source>
<translation>Bearbeiten von URL #%url_id</translation>
   </message> 
</context>
<context>
<name>design/admin/url/list</name>
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Valid URLs [%url_list_count]</source>
<translation>GÃ¼ltige URLs [%url_list_count]</translation>
   </message> 
   <message> 
       <source>Invalid URLs [%url_list_count]</source>
<translation>UngÃ¼ltige URLs [%url_list_count]</translation>
   </message> 
   <message> 
       <source>All URLs [%url_list_count]</source>
<translation>Alle URLs [%url_list_count]</translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Valid</source>
<translation>Güldig</translation>
   </message> 
   <message> 
       <source>Invalid</source>
<translation>Ungüldig</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Checked</source>
<translation>Überbrüfd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>open</source>
<translation>Öffnen</translation>
   </message> 
   <message> 
       <source>Never</source>
<translation>Niemals</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>Show all URLs.</source>
<translation>Alle URLs anzeige.</translation>
   </message> 
   <message> 
       <source>Show only invalid URLs.</source>
<translation>Nur güldig URLs anzeige.</translation>
   </message> 
   <message> 
       <source>Show only valid URLs.</source>
<translation>Nur ungüldig URLs anzeige.</translation>
   </message> 
   <message> 
       <source>View information about URL.</source>
<translation>Informazion übr URL anzeige.</translation>
   </message> 
   <message> 
       <source>Open URL in new window.</source>
<translation>URL in neiem Fenschdr öffne.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit URL.</source>
<translation>URL bearbeide.</translation>
   </message> 
   <message> 
       <source>The requested list is empty.</source>
<translation>Die Anfragelischde isch ler.</translation>
   </message> 
</context>
<context>
<name>design/admin/url/view</name>
   <message> 
       <source>URL #%url_id</source>
<translation>URL #%url_id</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Valid</source>
<translation>Güldig</translation>
   </message> 
   <message> 
       <source>Invalid</source>
<translation>Ungüldig</translation>
   </message> 
   <message> 
       <source>Last checked</source>
<translation>Zuledzd überbrüfd</translation>
   </message> 
   <message> 
       <source>This URL has not been checked.</source>
<translation>Die URL wurd no nedd überbrüfd.</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Objects using URL #%url_id [%url_count]</source>
<translation>Objekte, die die URL #%url_id benutzen [%url_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>URL #%url_id is not in use by any objects.</source>
<translation>URL #%url_id wird von keinem Objekt benutzt.</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Edit this URL.</source>
<translation>Diese URL bearbeide.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%object_name&gt;.</source>
<translation>&lt;%object_name&gt; bearbeiten.</translation>
   </message> 
   <message> 
       <source>Draft</source>
<translation>Endwurf</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Pending</source>
<translation>Schwebend</translation>
   </message> 
   <message> 
       <source>Archived</source>
<translation>Archivierd</translation>
   </message> 
   <message> 
       <source>Rejected</source>
<translation>Abgelehnd</translation>
   </message> 
   <message> 
       <source>(in trash)</source>
<translation></translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
<translation>Die Inhalte von Version #%version_number anzeigen. Standard Ãbersetzung: %default_translation.</translation>
   </message> 
</context>
<context>
<name>design/admin/user</name>
   <message> 
       <source>Activate account</source>
<translation>Kondo (Accound) akdivieren</translation>
   </message> 
   <message> 
       <source>User registered</source>
<translation>Nudzr regischdrierd</translation>
   </message> 
   <message> 
       <source>Your account is now activated.</source>
<translation>Ihr Kondo isch nun akdivierd.</translation>
   </message> 
   <message> 
       <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
<translation>Dr überdragene Schlüssl konnde nedd validierd werde. Ihr Kondo wurd nedd akdivierd.</translation>
   </message> 
   <message> 
       <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
<translation>Ihr Kondo wurd erfolgreich erschdelld. Eine E-Mail wird nun an d angegebene E-Mail Adresse verschiggd. Folget Sie den Hinweise in dr E-Mail, um Ihre Kondo z akdiviere.</translation>
   </message> 
   <message> 
       <source>Your account was successfully created.</source>
<translation>Ihr Benudzerkondo wurd erfolgreich erschdelld.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
</context>
<context>
<name>design/admin/user/login</name>
   <message> 
       <source>The system could not log you in.</source>
<translation>Des Syschdem konnde koin Login durchführe.</translation>
   </message> 
   <message> 
       <source>Make sure that the username and password is correct.</source>
<translation>Schdellet Sie sichr, dess Benudzernam und Password recht sind.</translation>
   </message> 
   <message> 
       <source>All letters must be typed in using the correct case.</source>
<translation>Alle Buchschdabe müsse mid rechtr Groß- und Kloischreibung in des Syschdem oigegebe werde.</translation>
   </message> 
   <message> 
       <source>Please try again or contact the site administrator.</source>
<translation>Bidde versuchet Sie s erneid odr kondakdieret Sie den Adminischdrador.</translation>
   </message> 
   <message> 
       <source>Access denied!</source>
<translation>Zugriff verweigerd, hajo, so isch des !</translation>
   </message> 
   <message> 
       <source>You do not have permissions to access &lt;%siteaccess_name&gt;.</source>
<translation>Sie haben keine Berechtigung, den Zugang &lt;%siteaccess_name&gt; zu betrehten.</translation>
   </message> 
   <message> 
       <source>Please contact the site administrator.</source>
<translation>Bidde kondakdieret Sie den Adminischdrador.</translation>
   </message> 
   <message> 
       <source>Log in to the administration interface of eZ publish</source>
<translation>Anmelde am Adminischdrazion Inderface</translation>
   </message> 
   <message> 
       <source>Please enter a valid username/password combination and click &quot;Log in&quot;.</source>
<translation>Bidde oi korrekde Kombinazion aus Benudzername/Password oigebe und &quot;Anmelden&quot; kligge.</translation>
   </message> 
   <message> 
       <source>Use the &quot;Register&quot; button to create a new account.</source>
<translation>Benudzet Sie den &quot;Regischdrieren&quot; Knobf, um oin neis Benudzer-Kondo z erschdelle.</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>Enter a valid username into this field.</source>
<translation>Gebet Sie oin korrekde Benudzername in diess Feld oi.</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>Enter a valid password into this field.</source>
<translation>Gebet Sie oi korrekds Password in diess Feld oi.</translation>
   </message> 
   <message> 
       <source>Log in</source>
<translation>Anmelden</translation>
   </message> 
   <message> 
       <source>Click here to log in using the username/password combination entered in the fields above.</source>
<translation>Kligget Sie hir, um si undr Verwendung vo Benudzernam und Password anzumelde.</translation>
   </message> 
   <message> 
       <source>Register</source>
<translation>Regischdrieren</translation>
   </message> 
   <message> 
       <source>Click here to create a new account.</source>
<translation>Kligget Sie hir, um oin neis Benudzer-Kondo z erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/user/password</name>
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>Old password</source>
<translation>Alds Password</translation>
   </message> 
   <message> 
       <source>New password</source>
<translation>Neis Password</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>The password could not be changed.</source>
<translation>Des Password konnde nedd gänderd werde.</translation>
   </message> 
   <message> 
       <source>The old password was either missing or incorrect.</source>
<translation>Des alde Password fehlde odr war nedd recht.</translation>
   </message> 
   <message> 
       <source>Please retype the old password and try again.</source>
<translation>Bidde gebet Sie Ihr alds Password nochmol oi und versuchet Sie s erneid.</translation>
   </message> 
   <message> 
       <source>The new passwords did not match.</source>
<translation>Die neie Passwördr schdimme nedd überoi.</translation>
   </message> 
   <message> 
       <source>Please retype the new passwords and try again.</source>
<translation>Bidde gebet Sie d neie Passwördr nochmals oi und versuchet Sie s erneid.</translation>
   </message> 
   <message> 
       <source>The password was successfully changed.</source>
<translation>Des Password wurd erfolgreich gänderd.</translation>
   </message> 
   <message> 
       <source>Change password for &lt;%username&gt;</source>
<translation>Ãndere Password fÃ¼r &lt;%username&gt;</translation>
   </message> 
   <message> 
       <source>Confirm new password</source>
<translation>Beschdädig neis Password</translation>
   </message> 
   <message> 
       <source>The password must be at least 3 characters long.</source>
<translation>Des Password muss mindeschdens 3 Zeile lang soi.</translation>
   </message> 
</context>
<context>
<name>design/admin/user/register</name>
   <message> 
       <source>The information could not be stored...</source>
<translation>Die Informazion konnde nedd gschbeicherd werde...</translation>
   </message> 
   <message> 
       <source>The following information is either incorrect or missing</source>
<translation>Folgend Informazione werde vermissch odr sind falsch</translation>
   </message> 
   <message> 
       <source>Please correct the inputs (marked with red labels) and try again.</source>
<translation>Bidde korrigieret Sie d rod markierde Eingabe und versuchet Sie s erneid.</translation>
   </message> 
   <message> 
       <source>Register new user</source>
<translation>Neie Benudzr regischdrieren</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Unable to register new user</source>
<translation>Regischdriere vom neie Benudzers war nedd möglich</translation>
   </message> 
   <message> 
       <source>Back</source>
<translation>Zurügg</translation>
   </message> 
</context>
<context>
<name>design/admin/user/setting</name>
   <message> 
       <source>Maximum concurrent logins</source>
<translation>Maximale gleichzeidig Anmeldungen</translation>
   </message> 
   <message> 
       <source>Enable user account</source>
<translation>Benudzerkondo akdivieren</translation>
   </message> 
   <message> 
       <source>Use this checkbox to enable or disable the user account.</source>
<translation>Benudzet Sie diess Ankreizfeld um des Benudzerkondo z akdiviere odr z deakdiviere.</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]</source>
<translation>Diese Funkzionalidäd isch momendan nedd verfügbar. [benudzet Sie diess Feld um d maximale Anzahl dr maximale gleichzeidige Anmeldunge z definiere.]</translation>
   </message> 
   <message> 
       <source>User settings for &lt;%user_name&gt;</source>
<translation>Benutzereinstellungen von &lt;%user_name&gt;</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/menuconfig</name>
   <message> 
       <source>Menu management</source>
<translation>Menu-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Menu positioning</source>
<translation>Menübosizionierung</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click here to store the changes if you have modified the menu settings above.</source>
<translation>Kligget Sie hir um Änderunge z schbeicheret, falls Sie d Menüoischdellunge obe gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/templatecreate</name>
   <message> 
       <source>Could not create template, permission denied.</source>
<translation>Konnde koi Temblade erschdelle,  Zugriff verweigerd.</translation>
   </message> 
   <message> 
       <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
<translation>Ungüldigr nam. Sie könne nur d Buchschdabe a-z, Nummeret und _ benudze.</translation>
   </message> 
   <message> 
       <source>Create new template override for &lt;%template_name&gt;</source>
<translation>Neues Ãberschreib-Template fÃ¼r &lt;%template_name&gt; erstellen</translation>
   </message> 
   <message> 
       <source>The newly created template file will be placed in</source>
<translation>Die nei erschdellde Temblade-Dadei wird blazierd in</translation>
   </message> 
   <message> 
       <source>Filename</source>
<translation>Dadoiame</translation>
   </message> 
   <message> 
       <source>Override keys</source>
<translation>Überschreibungsschlüssel</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>All classes</source>
<translation>Alle Klassen</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>All sections</source>
<translation>Alle Sekzionen</translation>
   </message> 
   <message> 
       <source>Node ID</source>
<translation>Knode ID</translation>
   </message> 
   <message> 
       <source>Base template on</source>
<translation>Temblade-Grundlage</translation>
   </message> 
   <message> 
       <source>Empty file</source>
<translation>Leere Dadei</translation>
   </message> 
   <message> 
       <source>Copy of default template</source>
<translation>Kobie vom Schdandard-Temblades</translation>
   </message> 
   <message> 
       <source>Container (with children)</source>
<translation>Condainr ( mid Kinderet )</translation>
   </message> 
   <message> 
       <source>View (without children)</source>
<translation>Sichd ( ohne Kindr )</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Object</source>
<translation>Objekd</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/templateedit</name>
   <message> 
       <source>Edit template: &lt;%template&gt;</source>
<translation>Bearbeiten von Template: &lt;%template&gt;</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to save the contents of the text field above to the template file.</source>
<translation>Kligget Sie auf diese Knobf um d Inhalde dr Texdfeldr obe in d Temblade-Dadei z schbeicheret.</translation>
   </message> 
   <message> 
       <source>Back to overrides</source>
<translation>Zurügg z den Überschreibungen</translation>
   </message> 
   <message> 
       <source>Back to override overview.</source>
<translation>Zurügg zur Übersichd übr d Überschreibunge.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to save the contents of the text field above to the template file.</source>
<translation>Sie hend nedd d nodwendige Rechde, um d Inhalde dr Texdfeldr obe in d Temblade-Dadei z schbeicheret.</translation>
   </message> 
   <message> 
       <source>The template can not be edited.</source>
<translation>Des Temblade kann nedd bearbeided werde.</translation>
   </message> 
   <message> 
       <source>The web server does not have write access to the requested template.</source>
<translation>Dr Webservr hedd koin Schreibzugriff auf des angeforderde Temblade.</translation>
   </message> 
   <message> 
       <source>The web server does not have read access to the requested template.</source>
<translation>Dr Webservr hedd koin Lesezugriff auf des angeforderde Temblade.</translation>
   </message> 
   <message> 
       <source>The requested template does not exist or is not being used as an override.</source>
<translation>Des angeforderde Temblade exischdierd nedd odr wird nedd als Überschreibung verwended.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%template_name&gt; [Template]</source>
<translation>Bearbeiten von &lt;%template_name&gt; [Template]</translation>
   </message> 
   <message> 
       <source>Requested template</source>
<translation>Angeforderds Temblade</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Overrides template</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Open as read only</source>
<translation>Nur lesend öffnen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/templatelist</name>
   <message> 
       <source>Complete template list</source>
<translation>Kombledde Tembladelischde</translation>
   </message> 
   <message> 
       <source>Template</source>
<translation>Temblade</translation>
   </message> 
   <message> 
       <source>Design resource</source>
<translation>Design Ressource</translation>
   </message> 
   <message> 
       <source>Manage overrides for template.</source>
<translation>Überschreibunge vo Temblads verwalde.</translation>
   </message> 
   <message> 
       <source>Most common templates</source>
<translation>Die gebräuchlichschde Temblades</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/templateview</name>
   <message> 
       <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
<translation>Ãberschreibungen fÃ¼r das Template &lt;%template_name&gt; im &lt;%current_siteaccess&gt; Seiten-Zugang [%override_count]</translation>
   </message> 
   <message> 
       <source>Default template resource</source>
<translation>Schdandard-Temblade-Ressource</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Match conditions</source>
<translation>Bedingungen</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Edit override template.</source>
<translation>Überschreib-Temblade bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected template overrides.</source>
<translation>Ausgewählde Überschreib-Temblade endferne.</translation>
   </message> 
   <message> 
       <source>New override</source>
<translation>Neis Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Create a new template override.</source>
<translation>Neis Überschreib-Temblade erschdelle.</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde akdualisieren</translation>
   </message> 
   <message> 
       <source>The overrides could not be removed.</source>
<translation>Die Überschreibunge konnde nedd endfernd werde.</translation>
   </message> 
   <message> 
       <source>The following files and override rules could not be removed because of insufficient file permissions</source>
<translation>Die folgende Dadeie und Regeln zur Überschreibung konnde aufgrund unzureichendr Dadeirechde nedd endfernd werden</translation>
   </message> 
   <message> 
       <source>The override.ini file could not be modified because of insufficient permissions.</source>
<translation>Die Dadei overrid.ini konnde aufgrund unzureichendr Rechde nedd gänderd werde.</translation>
   </message> 
   <message> 
       <source>No file matched</source>
<translation>Koi Dadei driffd zu</translation>
   </message> 
</context>
<context>
<name>design/admin/visual/toolbar</name>
   <message> 
       <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
<translation>Werkzeug Liste fÃ¼r &lt;Toolbar_%toolbar_position&gt;</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>There are currently no tools in this toolbar</source>
<translation>Es befinde si zur Zeid koi Werkzeig in dr Werkzeig-Leischde</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde Akdualisieren</translation>
   </message> 
   <message> 
       <source>Add Tool</source>
<translation>Werkzeig hinzfügen</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified the parameters above.</source>
<translation>Kligge diese Knobf um d Änderunge z schbeicheret, wenn Sie Paramedr gänderd hend.</translation>
   </message> 
   <message> 
       <source>Back to toolbars</source>
<translation>Zurügg z den Werkzeig-Leischden</translation>
   </message> 
   <message> 
       <source>Go back to the toolbar list.</source>
<translation>Gehe zurügg z dr Werkzeig-Leischde Lischde.</translation>
   </message> 
   <message> 
       <source>Toolbar management</source>
<translation>Werkzeig-Leischden-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Current siteaccess</source>
<translation>Akduells Seide Zugang</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
<translation>VerfÃ¼gbare Werkzeuge fÃ¼r den &lt;%siteaccess&gt; Zugang</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/edit</name>
   <message> 
       <source>Input did not validate</source>
<translation>Eingab isch ungüldig</translation>
   </message> 
   <message> 
       <source>Data requires fixup</source>
<translation>Dade benödige Anbassung</translation>
   </message> 
   <message> 
       <source>Edit &lt;%workflow_name&gt; [Workflow]</source>
<translation>Bearbeiten von &lt;%workflow_name&gt; [Workflow]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Move down</source>
<translation>Nach unden</translation>
   </message> 
   <message> 
       <source>Move up</source>
<translation>Nach oben</translation>
   </message> 
   <message> 
       <source>Description / comments</source>
<translation>Beschreibung / Kommendare</translation>
   </message> 
   <message> 
       <source>There are no events within this workflow.</source>
<translation>Es gibd koi Ereignisse innerhalb diese Workflows.</translation>
   </message> 
   <message> 
       <source>Remove selected events</source>
<translation>Ausgewählde Ereignisse endfernen</translation>
   </message> 
   <message> 
       <source>Add event</source>
<translation>Ereignis hinzfügen</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/eventtype/edit</name>
   <message> 
       <source>Affected sections</source>
<translation>Bedroffene Sekzionen</translation>
   </message> 
   <message> 
       <source>All sections</source>
<translation>Alle Sekzionen</translation>
   </message> 
   <message> 
       <source>User who approves content</source>
<translation>Benudzr, d den Inhald bewilligen</translation>
   </message> 
   <message> 
       <source>Excluded users and groups</source>
<translation>Benudzr und Grubbe ausschließen</translation>
   </message> 
   <message> 
       <source>All users and groups</source>
<translation>Alle Benudzr und Grubben</translation>
   </message> 
   <message> 
       <source>Classes to run workflow</source>
<translation>Klasse um des Workflow durchlaufen</translation>
   </message> 
   <message> 
       <source>All classes</source>
<translation>Alle Klassen</translation>
   </message> 
   <message> 
       <source>Users without workflow IDs</source>
<translation>Benudzr ohne Workflow IDs</translation>
   </message> 
   <message> 
       <source>Workflow to run</source>
<translation>Workflow zum Schdarden</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Update attributes</source>
<translation>Eigenschafde akdualisieren</translation>
   </message> 
   <message> 
       <source>Attribute</source>
<translation>Addribuade</translation>
   </message> 
   <message> 
       <source>Select attribute</source>
<translation>Addribuade auswählen</translation>
   </message> 
   <message> 
       <source>Class/attribute combinations [%count]</source>
<translation>Klasse/Attribut Kombination [%count]</translation>
   </message> 
   <message> 
       <source>There are no combinations</source>
<translation>Es gibd koi Kombinazionen</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Modify the objects&apos; publishing dates</source>
<translation>Des Veröffendlichungsdadum vom Objekds verändern</translation>
   </message> 
   <message> 
       <source>There are no payment Gateway extensions installed.</source>
<translation>Es sind koi Erweiderunge für Bezahlungsschniddschdelle inschdallierd.</translation>
   </message> 
   <message> 
       <source>Please install a payment extension first.</source>
<translation>Bidde inschdallieret Sie zuersch oi Bezahlungsschniddschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/groupedit</name>
   <message> 
       <source>Edit &lt;%group_name&gt; [Workflow group]</source>
<translation>Bearbeiten von &lt;%group_name&gt; [Workflow Gruppe]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/grouplist</name>
   <message> 
       <source>Workflow groups [%groups_count]</source>
<translation>Workflow Gruppen [%groups_count]</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>There are no workflow groups.</source>
<translation>Es gibd koi Workflow Grubben</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected workflow groups.</source>
<translation>Die ausgewählde Workflow Grubbe bearbeide.</translation>
   </message> 
   <message> 
       <source>New workflow group</source>
<translation>Neie Workflow Grubbe</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select workflow group for removal.</source>
<translation>Workflow Grubb zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%workflow_group_name&gt; workflow group.</source>
<translation>Bearbeiten der Worflow Gruppe &lt;%workflow_group_name&gt;.</translation>
   </message> 
   <message> 
       <source>Create a new workflow group.</source>
<translation>Eine neie Workflow Grubb erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/view</name>
   <message> 
       <source>Input did not validate</source>
<translation>Die Eingabe konnde nedd validierd werden</translation>
   </message> 
   <message> 
       <source>%workflow_name [Workflow]</source>
<translation>%workflow_nam [Workflow]</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Member of groups [%group_count]</source>
<translation>Mitglied in Gruppen [%group_count]</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Group</source>
<translation>Grubbe</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Add to group</source>
<translation>Zur Grubb hinzfügen</translation>
   </message> 
   <message> 
       <source>No group</source>
<translation>Koi Grubbe</translation>
   </message> 
   <message> 
       <source>Events [%event_count]</source>
<translation>Ereignisse [%event_count]</translation>
   </message> 
   <message> 
       <source>Position</source>
<translation>Posizion</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Additional information</source>
<translation>Weidere Informazionen</translation>
   </message> 
</context>
<context>
<name>design/admin/workflow/workflowlist</name>
   <message> 
       <source>%group_name [Workflow group]</source>
<translation>%groub_nam [Workflow Grubbe]</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Workflows [%workflow_count]</source>
<translation>Workflows [%workflow_count]</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Bearbeided</translation>
   </message> 
   <message> 
       <source>There are no workflows in this group.</source>
<translation>In von dene Grubb sind koi Worflows.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New workflow</source>
<translation>Neir Workflow</translation>
   </message> 
   <message> 
       <source>Edit this workflow group.</source>
<translation>Diese Workflow Grubb bearbeide.</translation>
   </message> 
   <message> 
       <source>Remove this workflow group.</source>
<translation>Diese Workflow Grubb endferne.</translation>
   </message> 
   <message> 
       <source>Back to workflow groups.</source>
<translation>Zurügg z den Workflow Grubbe.</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Select workflow for removal.</source>
<translation>Workflow zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Edit the &lt;%workflow_name&gt; workflow.</source>
<translation>Bearbeiten von Workflow &lt;%workflow_name&gt;.</translation>
   </message> 
   <message> 
       <source>Remove selected workflows.</source>
<translation>Die ausgewählde Workflows endferne.</translation>
   </message> 
   <message> 
       <source>Create a new workflow.</source>
<translation>Eine neie Workflow erschdelle.</translation>
   </message> 
</context>
<context>
<name>design/base</name>
   <message> 
       <source>Back to poll</source>
<translation>Zurügg zur Umfrage</translation>
   </message> 
   <message> 
       <source>Subject</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Message</source>
<translation>Nachrichd</translation>
   </message> 
   <message> 
       <source>Notify me about updates</source>
<translation>Übr Ubdads benachrichdigen</translation>
   </message> 
   <message> 
       <source>Sticky</source>
<translation>Feschd</translation>
   </message> 
   <message> 
       <source>Create new weblog</source>
<translation>Neis Weblog erschdellen</translation>
   </message> 
   <message> 
       <source>Read more...</source>
<translation>mehr lese...</translation>
   </message> 
   <message> 
       <source>Contact information</source>
<translation>Kondakdinformazionen</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Additional information</source>
<translation>Weidere Informazionen</translation>
   </message> 
   <message> 
       <source>Tip a friend</source>
<translation>Weidersagen</translation>
   </message> 
   <message> 
       <source>Download PDF</source>
<translation>PDF raaladen</translation>
   </message> 
   <message> 
       <source>Download PDF version of this page</source>
<translation>Eine PDF-Versio von dene Seide raaladen</translation>
   </message> 
   <message> 
       <source>Comments</source>
<translation>Kommendare</translation>
   </message> 
   <message> 
       <source>New Comment</source>
<translation>Neir Kommendar</translation>
   </message> 
   <message> 
       <source>You are not allowed to create comments.</source>
<translation>Sie dürfe koi Kommendare erschdelle.</translation>
   </message> 
   <message> 
       <source>Contacts</source>
<translation>Kondakde</translation>
   </message> 
   <message> 
       <source>Your E-mail address</source>
<translation>Ihre E-Mail Adresse</translation>
   </message> 
   <message> 
       <source>Send form</source>
<translation>Formular abschiggen</translation>
   </message> 
   <message> 
       <source>New topic</source>
<translation>Neis Thema</translation>
   </message> 
   <message> 
       <source>Keep me updated</source>
<translation>Auf dem Laufende halden</translation>
   </message> 
   <message> 
       <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
<translation>Um Zugang zu den Foren zu erhalten, mÃ¼ssen Sie angemeldet sein. Das kÃ¶nnen Sie %login_link_start%hier%login_link_end% machen</translation>
   </message> 
   <message> 
       <source>Topic</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Replies</source>
<translation>Anworden</translation>
   </message> 
   <message> 
       <source>Author</source>
<translation>Audor</translation>
   </message> 
   <message> 
       <source>Last reply</source>
<translation>Ledzde Anword</translation>
   </message> 
   <message> 
       <source>Pages</source>
<translation>Seiden</translation>
   </message> 
   <message> 
       <source>Message preview</source>
<translation>Nachrichden-Vorschau</translation>
   </message> 
   <message> 
       <source>Previous topic</source>
<translation>Vorherigs Thema</translation>
   </message> 
   <message> 
       <source>Next topic</source>
<translation>Nächschds Thema</translation>
   </message> 
   <message> 
       <source>New reply</source>
<translation>Neie Andword</translation>
   </message> 
   <message> 
       <source>You need to be logged in to get access to the forums. You can do so</source>
<translation>Um Zugang z den Fore z erhalde, müsset Sie angemelded soi. Machet Sie des</translation>
   </message> 
   <message> 
       <source>here</source>
<translation>hier</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Moderated by</source>
<translation>Moderierd von</translation>
   </message> 
   <message> 
       <source>View as slideshow</source>
<translation>Als Dia-Show ansehen</translation>
   </message> 
   <message> 
       <source>Previous image</source>
<translation>Vorherigs Bild</translation>
   </message> 
   <message> 
       <source>Next image</source>
<translation>Nächschds Bild</translation>
   </message> 
   <message> 
       <source>Result</source>
<translation>Ergebnis</translation>
   </message> 
   <message> 
       <source>Add to basket</source>
<translation>Zum Warenkorb hinzfügen</translation>
   </message> 
   <message> 
       <source>Download this product sheet as PDF</source>
<translation>Diese Produkdbeschreibung als PDF raaladen</translation>
   </message> 
   <message> 
       <source>Product reviews</source>
<translation>Produkd-Bewerdungen</translation>
   </message> 
   <message> 
       <source>New review</source>
<translation>Neie Bewerdung</translation>
   </message> 
   <message> 
       <source>People who bought this also bought</source>
<translation>Kunde, d dis kaufd hend, hend au des kaufd</translation>
   </message> 
   <message> 
       <source>Previous entry</source>
<translation>Vorherigr Eindrag</translation>
   </message> 
   <message> 
       <source>Next entry</source>
<translation>Nächschdr Eindrag</translation>
   </message> 
   <message> 
       <source>New comment</source>
<translation>Neir Kommendar</translation>
   </message> 
   <message> 
       <source>More...</source>
<translation>Mehr...</translation>
   </message> 
   <message> 
       <source>View flash</source>
<translation>Flash ansehen</translation>
   </message> 
   <message> 
       <source>View list</source>
<translation>Lischde ansehen</translation>
   </message> 
   <message> 
       <source>Enter forum</source>
<translation>Forum öffnen</translation>
   </message> 
   <message> 
       <source>Enter gallery</source>
<translation>Gallerie öffnen</translation>
   </message> 
   <message> 
       <source>Vote</source>
<translation>abschdimmen</translation>
   </message> 
   <message> 
       <source>More information</source>
<translation>mehr Informazionen</translation>
   </message> 
   <message> 
       <source>View movie</source>
<translation>Film ansehen</translation>
   </message> 
   <message> 
       <source>in</source>
<translation>in</translation>
   </message> 
   <message> 
       <source>View comments</source>
<translation>Kommendare ansehen</translation>
   </message> 
   <message> 
       <source>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</source>
<translation>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</translation>
   </message> 
   <message> 
       <source>Top menu</source>
<translation>Obers Menu</translation>
   </message> 
   <message> 
       <source>Sub menu</source>
<translation>Under-Menu</translation>
   </message> 
   <message> 
       <source>Left menu</source>
<translation>Linke Menu</translation>
   </message> 
   <message> 
       <source>Left sub menu</source>
<translation>Links Under-Menu</translation>
   </message> 
   <message> 
       <source>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</source>
<translation>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</translation>
   </message> 
   <message> 
       <source>Details...</source>
<translation>Dedails...</translation>
   </message> 
   <message> 
       <source>Poll %pollname</source>
<translation>Umfrage %pollname</translation>
   </message> 
   <message> 
       <source>Results</source>
<translation>Ergebnisse</translation>
   </message> 
   <message> 
       <source>Anonymous users are not allowed to vote on this poll, please login.</source>
<translation>Anonym Benudzeret isch s nedd gschdadded an von dene Umfrag deilzunehme, Bidde meldet Sie i an.</translation>
   </message> 
   <message> 
       <source>You have already voted for this poll.</source>
<translation>Sie hend scho an von dene Umfrag deilgenomme.</translation>
   </message> 
   <message> 
       <source>Votes</source>
<translation>Schdimmen</translation>
   </message> 
   <message> 
       <source>%count total votes</source>
<translation>%cound Schdimme insgesamd</translation>
   </message> 
   <message> 
       <source>Collected information from %1</source>
<translation>Gesammelte Informationen von %1</translation>
   </message> 
   <message> 
       <source>The following information was collected</source>
<translation>Folgend Informazione wurde gsammeld</translation>
   </message> 
   <message> 
       <source>The file could not be found.</source>
<translation>Die Dadei konnde nedd funde werde.</translation>
   </message> 
   <message> 
       <source>New row</source>
<translation>Neie Zeile</translation>
   </message> 
   <message> 
       <source>Remove Selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Price</source>
<translation>Preis</translation>
   </message> 
   <message> 
       <source>Your price</source>
<translation>Ihr Preis</translation>
   </message> 
   <message> 
       <source>You save</source>
<translation>Sie schbaren</translation>
   </message> 
   <message> 
       <source>Edit %1 - %2</source>
<translation>Ãndere %1 - %2</translation>
   </message> 
   <message> 
       <source>Send for publishing</source>
<translation>Zur Veröffendlichung schiggen</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>Publish</source>
<translation>Veröffendlichen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Post</source>
<translation>Senden</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>Latest from</source>
<translation>Zuledzd von</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Number of Topics</source>
<translation>Anzahl dr Themen</translation>
   </message> 
   <message> 
       <source>Number of Posts</source>
<translation>Zahl dr Übermiddlungen</translation>
   </message> 
   <message> 
       <source>%count votes</source>
<translation>%cound Schdimmen</translation>
   </message> 
   <message> 
       <source>Author:</source>
<translation>Audor:</translation>
   </message> 
   <message> 
       <source>#page of #total</source>
<translation>#bag vo #dodal</translation>
   </message> 
   <message> 
       <source>Search</source>
<translation>Suchen</translation>
   </message> 
   <message> 
       <source>For more options try the %1Advanced search%2</source>
<translation>FÃ¼r mehr Optionen die %1 erweiterte Suche %2 probieren</translation>
   </message> 
   <message> 
       <source>The following words were excluded from the search</source>
<translation>Folgend Wördr wurde vo dr Suche ausgeschlossen</translation>
   </message> 
   <message> 
       <source>No results were found when searching for &quot;%1&quot;</source>
<translation>Es wurden keine Ergebnisse gefunden, als nach &apos;%1&apos; gesucht wurde</translation>
   </message> 
   <message> 
       <source>Search tips</source>
<translation>Suchdibbs</translation>
   </message> 
   <message> 
       <source>Check spelling of keywords.</source>
<translation>Überbrüfet Sie d Rechdschreibung dr Suchwördr.</translation>
   </message> 
   <message> 
       <source>Try changing some keywords eg. car instead of cars.</source>
<translation>Versuchet Sie oiig Suchwördr z. B. Audo anschdadd vo Audos.</translation>
   </message> 
   <message> 
       <source>Try more general keywords.</source>
<translation>Versuchet Sie allgemoire Schlüsselwördr.</translation>
   </message> 
   <message> 
       <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
<translation>Wenigr Suchwördr gebe mehr Ergebnisse. Versuchet Sie d Suchwördr z reduziere, bis Sie oi Ergebnis bekomme.</translation>
   </message> 
   <message> 
       <source>Search for &quot;%1&quot; returned %2 matches</source>
<translation>Suche nach &quot;%1&quot; ergab %2 Ergebnisse</translation>
   </message> 
   <message> 
       <source>Previous</source>
<translation>Zurügg</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
</context>
<context>
<name>design/base/shop</name>
   <message> 
       <source>Quantity</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>Price</source>
<translation>Preis</translation>
   </message> 
   <message> 
       <source>Total Price</source>
<translation>Gesamd-Preis</translation>
   </message> 
   <message> 
       <source>Basket</source>
<translation>Einkaufskorb</translation>
   </message> 
   <message> 
       <source>The following items were removed from your basket, because the products were changed</source>
<translation>Die folgende Posizione wurde vo Ihrem Warenkorb endfernd, da d Produkde gänderd wurden</translation>
   </message> 
   <message> 
       <source>Attempted to add object without price to basket.</source>
<translation>Versuchd oi Objekd ohne Preis in den Warenkorb z lege.</translation>
   </message> 
   <message> 
       <source>Your payment was aborted.</source>
<translation>Ihre Zahlung wurd abgebrole.</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd.</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>Subtotal Inc. VAT</source>
<translation>Zwischensumm mid MwSchd.</translation>
   </message> 
   <message> 
       <source>Checkout</source>
<translation>Kasse</translation>
   </message> 
   <message> 
       <source>Continue shopping</source>
<translation>Weidr oikaufen</translation>
   </message> 
   <message> 
       <source>Store quantities</source>
<translation>Menge schbeichern</translation>
   </message> 
   <message> 
       <source>You have no products in your basket</source>
<translation>Sie hend koi Produkde im Einkaufskorb</translation>
   </message> 
   <message> 
       <source>Confirm order</source>
<translation>Beschdellung beschdädigen</translation>
   </message> 
   <message> 
       <source>Product items</source>
<translation>Produkde</translation>
   </message> 
   <message> 
       <source>Order summary</source>
<translation>Beschdellauflischdung</translation>
   </message> 
   <message> 
       <source>Subtotal of items</source>
<translation>Zwischensumm dr Posizionen</translation>
   </message> 
   <message> 
       <source>Order total</source>
<translation>Kombledde Beschdellsumme</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Order %order_id [%order_status]</source>
<translation>Bestellung %order_id [%order_status]</translation>
   </message> 
   <message> 
       <source>Order history</source>
<translation>Beschdellverlauf</translation>
   </message> 
</context>
<context>
<name>design/plain/layout</name>
   <message> 
       <source>Advanced search</source>
<translation>Erweiderde Suche</translation>
   </message> 
   <message> 
       <source>Search</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/class</name>
   <message> 
       <source>Class is locked</source>
<translation>Klasse isch gschberrd</translation>
   </message> 
   <message> 
       <source>Retry</source>
<translation>Wiederholen</translation>
   </message> 
</context>
<context>
<name>design/standard/class/classlist</name>
   <message> 
       <source>No classes in</source>
<translation>Koi Klasse in</translation>
   </message> 
   <message> 
       <source>Click on the &apos;New&apos; button to create a class.</source>
<translation>Kligg auf den &apos;Nei&apos;  Buddo, um oi Klasse z erschdelle.</translation>
   </message> 
   <message> 
       <source>Classes in</source>
<translation>Klasse in</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifikador</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Geänderd</translation>
   </message> 
   <message> 
       <source>Object count</source>
<translation>Anzahl Objekde</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>New class</source>
<translation>Neie Klasse</translation>
   </message> 
   <message> 
       <source>Last modified classes</source>
<translation>Zuledzd gänderde Klasse</translation>
   </message> 
</context>
<context>
<name>design/standard/class/datatype</name>
   <message> 
       <source>Multiple choice</source>
<translation>Mehrfachauswahl</translation>
   </message> 
   <message> 
       <source>Flash</source>
<translation>Flash</translation>
   </message> 
   <message> 
       <source>QuickTime</source>
<translation>QuiggTime</translation>
   </message> 
   <message> 
       <source>Real player</source>
<translation>RealPlayer</translation>
   </message> 
   <message> 
       <source>Windows media player</source>
<translation>Windows MediaPlayer</translation>
   </message> 
   <message> 
       <source>Price inc. VAT</source>
<translation>Preis inkl. MwSchd</translation>
   </message> 
   <message> 
       <source>Price ex. VAT</source>
<translation>Preis exkl. MwSchd</translation>
   </message> 
   <message> 
       <source>Max file size</source>
<translation>Maximale Dadeigröße</translation>
   </message> 
   <message> 
       <source>Default value</source>
<translation>Schdandardwerd</translation>
   </message> 
   <message> 
       <source>Empty</source>
<translation>Leer</translation>
   </message> 
   <message> 
       <source>Current date</source>
<translation>Akduells Dadum</translation>
   </message> 
   <message> 
       <source>Current datetime</source>
<translation>Akduelle Zeid</translation>
   </message> 
   <message> 
       <source>Min float value</source>
<translation>Minimalr Fließkomma-Werd</translation>
   </message> 
   <message> 
       <source>Max float value</source>
<translation>Maximalr Fließkomma-Werd</translation>
   </message> 
   <message> 
       <source>Min integer value</source>
<translation>Minimale Ganzzahl</translation>
   </message> 
   <message> 
       <source>Max integer value</source>
<translation>Maximale Ganzzahl</translation>
   </message> 
   <message> 
       <source>Media player type</source>
<translation>Mediablayerdyb</translation>
   </message> 
   <message> 
       <source>Default name</source>
<translation>Schdandardname</translation>
   </message> 
   <message> 
       <source>VAT type</source>
<translation>MwSchd-Tyb</translation>
   </message> 
   <message> 
       <source>Max string length</source>
<translation>Maximale Zeichenlänge</translation>
   </message> 
   <message> 
       <source>Preferred number of rows</source>
<translation>Bevorzugde Anzahl vo Zeilen</translation>
   </message> 
   <message> 
       <source>Current time</source>
<translation>Akduelle Zeid</translation>
   </message> 
   <message> 
       <source>Default number of rows</source>
<translation>Schdandardanzahl dr Zeilen</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifikador</translation>
   </message> 
   <message> 
       <source>Allowed classes</source>
<translation>Erlaubde Klassen</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>New option</source>
<translation>Neie Eigenschafd</translation>
   </message> 
   <message> 
       <source>Pretext</source>
<translation>Vordexd</translation>
   </message> 
   <message> 
       <source>Posttext</source>
<translation>Nachdexd</translation>
   </message> 
   <message> 
       <source>Digits</source>
<translation>Ziffern</translation>
   </message> 
   <message> 
       <source>Start value</source>
<translation>Schdardwerd</translation>
   </message> 
   <message> 
       <source>Ini file</source>
<translation>Ini Dadei</translation>
   </message> 
   <message> 
       <source>Ini Section</source>
<translation>Ini Sekzion</translation>
   </message> 
   <message> 
       <source>Ini Parameter</source>
<translation>Ini Parameder</translation>
   </message> 
   <message> 
       <source>Ini file location</source>
<translation>Ord dr Ini Dadei</translation>
   </message> 
   <message> 
       <source>Ini setting type</source>
<translation>Ini Einschdellungs-Tyb</translation>
   </message> 
   <message> 
       <source>Text</source>
<translation>Texd</translation>
   </message> 
   <message> 
       <source>Enable/Disable</source>
<translation>Akdiveren/Deakdivieren</translation>
   </message> 
   <message> 
       <source>True/False</source>
<translation>Wahr/Falsch</translation>
   </message> 
   <message> 
       <source>Integer</source>
<translation>Ganzzahl</translation>
   </message> 
   <message> 
       <source>Float</source>
<translation>Fließkommawerd</translation>
   </message> 
   <message> 
       <source>Array</source>
<translation>Lischde</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>New and existing objects</source>
<translation>Neie und exischdierend Objekde</translation>
   </message> 
   <message> 
       <source>Only new objects</source>
<translation>Nur neie Objekde</translation>
   </message> 
   <message> 
       <source>Only existing objects</source>
<translation>Nur exischdierend Objekde</translation>
   </message> 
   <message> 
       <source>Select which classes user can create</source>
<translation>Selekdiere wo Klasse oi Nudzr erschdelle kann</translation>
   </message> 
   <message> 
       <source>Package Type</source>
<translation>Pakeddyb</translation>
   </message> 
   <message> 
       <source>Checked</source>
<translation>Ausgewähld</translation>
   </message> 
   <message> 
       <source>Unchecked</source>
<translation>Abgewähld</translation>
   </message> 
   <message> 
       <source>Single choice</source>
<translation>Einfache Auswahl</translation>
   </message> 
   <message> 
       <source>Warning, the ini file settings value and object value does not match.</source>
<translation>Warnung, d Ini Dadei Einschdellungswerde und Objekdwerde schdimme nedd überoi.</translation>
   </message> 
   <message> 
       <source>The ini file has probably been modified manually since last time.</source>
<translation>Die Ini Dadei wurd wahrschoilich manul modifzierd seid dem ledze Mal.</translation>
   </message> 
   <message> 
       <source>Ini File :</source>
<translation>Ini Dadei:</translation>
   </message> 
   <message> 
       <source>Ini Value:</source>
<translation>Ini Werd:</translation>
   </message> 
   <message> 
       <source>Enabled</source>
<translation>Akdivierd</translation>
   </message> 
   <message> 
       <source>Disabled</source>
<translation>Deakdivierd</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Selection method</source>
<translation>Auswahl-Methode</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Dropdown list</source>
<translation>Auswahllischde</translation>
   </message> 
   <message> 
       <source>Dropdown tree</source>
<translation>Auswahlbaum</translation>
   </message> 
   <message> 
       <source>Remove selection</source>
<translation>Auswahl endfernen</translation>
   </message> 
   <message> 
       <source>Allow fuzzy match</source>
<translation>Unscharf Suchr erlauben</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Make empty array</source>
<translation>Leers Array erschdellen</translation>
   </message> 
   <message> 
       <source>Year</source>
<translation>Jahr</translation>
   </message> 
   <message> 
       <source>Month</source>
<translation>Monad</translation>
   </message> 
   <message> 
       <source>Day</source>
<translation>Tag</translation>
   </message> 
   <message> 
       <source>Hour</source>
<translation>Schdunde</translation>
   </message> 
   <message> 
       <source>Minute</source>
<translation>Minuade</translation>
   </message> 
   <message> 
       <source>View Mode</source>
<translation>Sichd Modus</translation>
   </message> 
   <message> 
       <source>Drop-down list</source>
<translation>Auswahllischde</translation>
   </message> 
   <message> 
       <source>Drop-down tree</source>
<translation>Auswahlbaum</translation>
   </message> 
   <message> 
       <source>There are no elements in the list.</source>
<translation>Es gibd koi Elemende in dr Lischde.</translation>
   </message> 
   <message> 
       <source>New element</source>
<translation>Neis Elemend</translation>
   </message> 
   <message> 
       <source>Add a new enum element.</source>
<translation>Neis Aufzählungs-Elemend hinzfüge.</translation>
   </message> 
   <message> 
       <source>Remove selected elements.</source>
<translation>Ausgewählde Elemende endferne.</translation>
   </message> 
   <message> 
       <source>Current value</source>
<translation>Derzeidigr Werd</translation>
   </message> 
   <message> 
       <source>Columns</source>
<translation>Schbalden</translation>
   </message> 
   <message> 
       <source>Matrix column</source>
<translation>Madrix Schbalde</translation>
   </message> 
   <message> 
       <source>The matrix does not have any columns.</source>
<translation>Die Madrix hedd koi Schbalde.</translation>
   </message> 
   <message> 
       <source>New column</source>
<translation>Neie Schbalde</translation>
   </message> 
   <message> 
       <source>Add a new column.</source>
<translation>Neie Schbalde hinzfüge.</translation>
   </message> 
   <message> 
       <source>Remove selected columns.</source>
<translation>Ausgewählde Schbalde endferne.</translation>
   </message> 
   <message> 
       <source>Default location for objects</source>
<translation>Schdandard-Ord für Objekde</translation>
   </message> 
   <message> 
       <source>New objects will not be placed in the content tree.</source>
<translation>Neie Objekde werde nedd im Inhaldebaum abgelegd.</translation>
   </message> 
   <message> 
       <source>Select location</source>
<translation>Ord auswählen</translation>
   </message> 
   <message> 
       <source>Remove location</source>
<translation>Ord endfernen</translation>
   </message> 
   <message> 
       <source>Select option for removal.</source>
<translation>Obzion zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>There are no options.</source>
<translation>Es gibd koi Obzione.</translation>
   </message> 
   <message> 
       <source>Add a new option.</source>
<translation>Neie Obzion hinzfüge.</translation>
   </message> 
   <message> 
       <source>Remove selected options.</source>
<translation>Ausgewählde Obzione endferne.</translation>
   </message> 
   <message> 
       <source>Adjusted current datetime</source>
<translation>Akduells Dadum/Zeid anbassen</translation>
   </message> 
   <message> 
       <source>Current date and time adjusted by</source>
<translation>Akduells Dadum und Zeid angebassch um</translation>
   </message> 
   <message> 
       <source>Style</source>
<translation>Schdil</translation>
   </message> 
   <message> 
       <source>Checkboxes / radiobuttons</source>
<translation>Ankreizfeldr / Radio-Buddons</translation>
   </message> 
   <message> 
       <source>Dropdown menu / multi menu</source>
<translation>Auswahllischde / mehrfach Menü</translation>
   </message> 
   <message> 
       <source>Elements</source>
<translation>Elemende</translation>
   </message> 
   <message> 
       <source>Element</source>
<translation>Elemend</translation>
   </message> 
   <message> 
       <source>Value</source>
<translation>Werd</translation>
   </message> 
   <message> 
       <source>Default selection item</source>
<translation>Vorausgewählds Elemend</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Unknown section</source>
<translation>Unbekannd Sekzion</translation>
   </message> 
   <message> 
       <source>No item has been selected.</source>
<translation>Es wurd koi Elemend ausgewähld</translation>
   </message> 
   <message> 
       <source>Select item</source>
<translation>Elemend auswählen</translation>
   </message> 
   <message> 
       <source>Package type</source>
<translation>Paked Tyb</translation>
   </message> 
   <message> 
       <source>View mode</source>
<translation>Ansichdsmodus</translation>
   </message> 
   <message> 
       <source>Combo box</source>
<translation>Combobox</translation>
   </message> 
   <message> 
       <source>Icon view</source>
<translation>Symbolansichd</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Options</source>
<translation>Obzionen</translation>
   </message> 
   <message> 
       <source>Option</source>
<translation>Obzion</translation>
   </message> 
   <message> 
       <source>characters</source>
<translation>Zeichen</translation>
   </message> 
   <message> 
       <source>year(s)</source>
<translation>Jahr(e)</translation>
   </message> 
   <message> 
       <source>month(s)</source>
<translation>Monad(e)</translation>
   </message> 
   <message> 
       <source>day(s)</source>
<translation>Tag(e)</translation>
   </message> 
   <message> 
       <source>hour(s)</source>
<translation>Schdund(n)</translation>
   </message> 
   <message> 
       <source>minute(s)</source>
<translation>Minuade(n)</translation>
   </message> 
   <message> 
       <source>Interface</source>
<translation>Schniddschdelle</translation>
   </message> 
   <message> 
       <source>Dropdown menu / multiselect</source>
<translation>Auswahllischde / Mehrfachauswahl</translation>
   </message> 
   <message> 
       <source>Radiobuttons / checkboxes</source>
<translation>Radio-Buddons / Ankreizfelder</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>combobox</source>
<translation>Combobox</translation>
   </message> 
   <message> 
       <source>icon view</source>
<translation>Symbolansichd</translation>
   </message> 
   <message> 
       <source>Default VAT</source>
<translation>Vorgegebene MwSchd.</translation>
   </message> 
   <message> 
       <source>Default VAT type</source>
<translation>Vorgegebenr MwSchd.-Tyb</translation>
   </message> 
   <message> 
       <source>Price</source>
<translation>Preis</translation>
   </message> 
   <message> 
       <source>For more options, set &quot;AdvancedObjectRelationList&quot; to &quot;enabled&quot; in a configuration override for &quot;site.ini&quot;.</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/class/datatype</name>
   <message> 
       <source>Max file size</source>
<translation>Maximale Dadeigröße</translation>
   </message> 
</context>
<context>
<name>design/standard/class/edit</name>
   <message> 
       <source>Input did not validate</source>
<translation>Eingab konnde nedd validierd werden</translation>
   </message> 
   <message> 
       <source>Input was stored successfully</source>
<translation>Eingab wurd erfolgreich gschbeicherd</translation>
   </message> 
   <message> 
       <source>Attributes</source>
<translation>Addribuade</translation>
   </message> 
   <message> 
       <source>Required</source>
<translation>Erforderlich</translation>
   </message> 
   <message> 
       <source>Searchable</source>
<translation>Durchsuchbar</translation>
   </message> 
   <message> 
       <source>Information collector</source>
<translation>Informazionssammler</translation>
   </message> 
   <message> 
       <source>Down</source>
<translation>Hinunder</translation>
   </message> 
   <message> 
       <source>Up</source>
<translation>Hiuuff</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Apply</source>
<translation>Anwenden</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifizierer</translation>
   </message> 
   <message> 
       <source>Object name pattern</source>
<translation>Objekdnamens Schema</translation>
   </message> 
   <message> 
       <source>Member of groups</source>
<translation>Midglied dr Grubben</translation>
   </message> 
   <message> 
       <source>Add to group</source>
<translation>Zur Grubb hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove from groups</source>
<translation>Vo Grubbe löschen</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Datatypes</source>
<translation>Dadendyben</translation>
   </message> 
   <message> 
       <source>Discard Changes</source>
<translation>Änderunge verwerfen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove these classes?</source>
<translation>Sind Sie sichr, dess Sie diese Klasse endferne wolle?</translation>
   </message> 
   <message> 
       <source>Removing class %1 will remove %2!</source>
<translation>Entfernen von Klasse %1 wird auch %2 entfernen!</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove these class groups?</source>
<translation>Sind Sie sichr, dess Sie diese Klassengrubbe endferne wolle?</translation>
   </message> 
   <message> 
       <source>Removing class group %1 will remove the classes %2!</source>
<translation>Entfernen con Klassengruppe %1 wird auch %2 entfernen!</translation>
   </message> 
   <message> 
       <source>Editing class - %1</source>
<translation>Klasse - %1 bearbeiten</translation>
   </message> 
   <message> 
       <source>Editing class group - %1</source>
<translation>Klassengruppe - %1 bearbeiten</translation>
   </message> 
   <message> 
       <source>Disable translation</source>
<translation>Übersedzung ausschalden</translation>
   </message> 
   <message> 
       <source>Last modified by %username on %time</source>
<translation>Zuletzt modifiziert von %username am %time</translation>
   </message> 
   <message> 
       <source>Modified by %username on %time</source>
<translation>Modfiziert von %username am %time</translation>
   </message> 
   <message> 
       <source>Is Container Class</source>
<translation>Isch Condainerklasse</translation>
   </message> 
   <message> 
       <source>Use this menu to select the type of attribute you wish to create. Click the &quot;add attribute&quot; button. The attribute will be appended to the bottom of the list of attributes.</source>
<translation>Benudzet Sie diess Menü, um d Ard dr Addribuade auszwähle, d erschdelld werde solle. Kligget Sie daz auf &quot;Addribud hinzfügen&quot;. Des Addribud wird am End dr Lischde dr Addribuade hinzugefügd.</translation>
   </message> 
   <message> 
       <source>The class should have at least one attribute and nonempty &apos;Name&apos; attribute</source>
<translation>Die Klasse sollde mindeschdens oi Addribud und oin füllde Name hend</translation>
   </message> 
   <message> 
       <source>The class %1 was already removed from the group but still exists in others.</source>
<translation>Die Klasse %1 wurde bereits aus der Gruppe entfernt, ist aber noch in anderen vorhanden.</translation>
   </message> 
   <message> 
       <source>The classes %1 were already removed from the group but still exist in others.</source>
<translation>Die Klassen %1 wurden bereits aus der Gruppe entfernt, ist aber noch in anderen vorhanden.</translation>
   </message> 
</context>
<context>
<name>design/standard/class/list</name>
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Class groups</source>
<translation>Klassengrubbe</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Veränderer</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Veränderd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>New group</source>
<translation>Neie Grubbe</translation>
   </message> 
   <message> 
       <source>Last modified classes</source>
<translation>Zuledzd gänderde Klasse</translation>
   </message> 
   <message> 
       <source>Setup menu</source>
<translation>Sedub Menü</translation>
   </message> 
   <message> 
       <source>New class</source>
<translation>Neie Klasse</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifikador</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
</context>
<context>
<name>design/standard/class/view</name>
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifizierer</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Object count</source>
<translation>Anzahl Objekde</translation>
   </message> 
   <message> 
       <source>Class - %1</source>
<translation>Klasse - %1</translation>
   </message> 
   <message> 
       <source>Last modified by %username on %time</source>
<translation>Zuletzt modifiziert von %username am %time</translation>
   </message> 
   <message> 
       <source>Object name pattern</source>
<translation>Objekd-Namens-Schema</translation>
   </message> 
   <message> 
       <source>Container</source>
<translation>Behälder</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Member of groups</source>
<translation>Midglied dr Grubben</translation>
   </message> 
   <message> 
       <source>Attributes</source>
<translation>Addribuade</translation>
   </message> 
   <message> 
       <source>Is required</source>
<translation>Wird benödigd (Muss-Feld)</translation>
   </message> 
   <message> 
       <source>Is not required</source>
<translation>Wird nedd benödigd (Kann-Feld)</translation>
   </message> 
   <message> 
       <source>Is searchable</source>
<translation>Isch durchsuchbar</translation>
   </message> 
   <message> 
       <source>Is not searchable</source>
<translation>Isch nedd durchsuchbar</translation>
   </message> 
   <message> 
       <source>Collects information</source>
<translation>Sammeld Informazionen</translation>
   </message> 
   <message> 
       <source>Does not collect information</source>
<translation>Sammeld koi Informazionen</translation>
   </message> 
   <message> 
       <source>Translation is disabled</source>
<translation>Übersedzung isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Translation is enabled</source>
<translation>Übersedzung isch akdivierd</translation>
   </message> 
   <message> 
       <source>Override templates</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Override</source>
<translation>Überschreibung</translation>
   </message> 
   <message> 
       <source>Source template</source>
<translation>Quell-Temblade</translation>
   </message> 
   <message> 
       <source>Override template</source>
<translation>Überschreib-Temblade</translation>
   </message> 
</context>
<context>
<name>design/standard/collaboration</name>
   <message> 
       <source>Group list for &apos;%1&apos;</source>
<translation>Gruppenliste fÃ¼r &apos;%1&apos;</translation>
   </message> 
   <message> 
       <source>No items in group.</source>
<translation>Koi Posizione in dr Grubb.</translation>
   </message> 
   <message> 
       <source>Groups</source>
<translation>Grubben</translation>
   </message> 
   <message> 
       <source>Approval</source>
<translation>Freigabe</translation>
   </message> 
   <message> 
       <source>%1 awaits approval by editor</source>
<translation>%1 warded auf Freigab vom Bearbeider</translation>
   </message> 
   <message> 
       <source>%1 was approved for publishing</source>
<translation>%1 wurd zur Veröffendlichung freigegeben</translation>
   </message> 
   <message> 
       <source>%1 was not approved for publishing</source>
<translation>%1 wurd nedd zur Veröffendlichung freigegeben</translation>
   </message> 
   <message> 
       <source>%1 awaits your approval</source>
<translation>%1 warded auf Ihre Freigabe</translation>
   </message> 
   <message> 
       <source>Subject</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Date</source>
<translation>Dadum</translation>
   </message> 
   <message> 
       <source>Read</source>
<translation>Lesen</translation>
   </message> 
   <message> 
       <source>Unread</source>
<translation>Ungelesen</translation>
   </message> 
   <message> 
       <source>Inactive</source>
<translation>Inakdiv</translation>
   </message> 
   <message> 
       <source>Posted: %1</source>
<translation>Verschickt: %1</translation>
   </message> 
   <message> 
       <source>No new items to be handled.</source>
<translation>Koi neie Posizione zum Bearbeide.</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>[more]</source>
<translation>[mehr]</translation>
   </message> 
</context>
<context>
<name>design/standard/collaboration/approval</name>
   <message> 
       <source>Approval</source>
<translation>Freigabe</translation>
   </message> 
   <message> 
       <source>The content object %1 awaits approval before it can be published.</source>
<translation>Das Inhalts-Objekt  %1 wartet auf Freigabe, bevor es verÃ¶ffentlicht werden kann.</translation>
   </message> 
   <message> 
       <source>If you wish you may send a message to the person approving it?</source>
<translation>Möchdet Sie oi Nachrichd an d freigebend Perso schigge?</translation>
   </message> 
   <message> 
       <source>The content object %1 needs your approval before it can be published.</source>
<translation>Das Inhalts-Objekt %1 benÃ¶tigt Ihre Freigabe, bevor es verÃ¶ffentlicht werden kann.</translation>
   </message> 
   <message> 
       <source>Do you approve of the content object being published?</source>
<translation>Gebet Sie d Veröffendlichung vom Inhalds-Objekds frei?</translation>
   </message> 
   <message> 
       <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
<translation>Das Inhalts-Objekt %1 wurde freigegeben und wird verÃ¶ffentlicht, sobald der VerÃ¶ffentlichungs-Workflow weiterlÃ¤uft.</translation>
   </message> 
   <message> 
       <source>Comment</source>
<translation>Kommendar</translation>
   </message> 
   <message> 
       <source>Add Comment</source>
<translation>Kommendar hinzfügen</translation>
   </message> 
   <message> 
       <source>Approve</source>
<translation>Freigeben</translation>
   </message> 
   <message> 
       <source>Deny</source>
<translation>Verbieden</translation>
   </message> 
   <message> 
       <source>Participants</source>
<translation>Teilnehmer</translation>
   </message> 
   <message> 
       <source>Messages</source>
<translation>Nachrichden</translation>
   </message> 
   <message> 
       <source>Edit the object</source>
<translation>Ändere des Objekd</translation>
   </message> 
   <message> 
       <source>The content object %1 was not accepted but is available as a draft again.</source>
<translation>Das Inhalts-Objekt %1 wurde nicht akzeptiert und steht nun wieder als Entwurf zur VerfÃ¼gung.</translation>
   </message> 
   <message> 
       <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
<translation>Das Inhalts-Objekt %1 wurde nicht akzeptiert und steht den Autor nun wieder als Entwurf zur VerfÃ¼gung.</translation>
   </message> 
   <message> 
       <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
<translation>[%sitename] Die BestÃ¤tigung von &quot;%objectname&quot; wartet auf Bearbeitung</translation>
   </message> 
   <message> 
       <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
<translation>[%sitename] &quot;%objectname&quot; wartet auf BestÃ¤tigung</translation>
   </message> 
   <message> 
       <source>You may re-edit the draft and publish it, in which case an approval is required again.</source>
<translation>Sie könne den Endwurf nei bearbeide und veröffendlile. In dem Fall isch oi Bewilligung nodwendich.</translation>
   </message> 
   <message> 
       <source>The author can re-edit the draft and publish it again, in which a new approval item is made.</source>
<translation>Dr Audor kann den Endwurf nei bearbeide und veröffendlile. In dem Fall wird oi neis Bewilligungselemend erschdelld.</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
<translation>Diese E-Mail informiert Sie darÃ¼ber, dass &quot;%objectname&quot; Ihre Aufmerksamkeit auf %sitename erfordert.
Der Prozess der VerÃ¶ffentlichung wurde angehalten und es leigt an Ihnen zu entscheiden, ob er fortgesetzt werden soll oder nicht.
Sie kÃ¶nnen diese Entscheidung unter der folgenden Adresse vornehmen:</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
<translation>Diese Mail informiert Sie darÃ¼ber, dass &quot;%objectname&quot; eine Zustimmung zur VerÃ¶ffentlichung auf %sitename erwartet.
Falls Sie Kommentare zur Person senden wollen, die zustimmen muss, oder den Status einsehen wollen benutzen Sie die Adresse unten.</translation>
   </message> 
</context>
<context>
<name>design/standard/content</name>
   <message> 
       <source>Are you sure you want to remove this translation?</source>
<translation>Sind Sie sichr, dess Sie diese Übersedzung endferne wolle?</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Change translation for content</source>
<translation>Die Übersedzung vom Inhalds ändern</translation>
   </message> 
   <message> 
       <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
<translation>Wählet Sie oi dr Übersedzunge aus dr Lischde zum Änderet odr gebet Sie oi individuelle in des Eingabefeld oi.</translation>
   </message> 
   <message> 
       <source>New translation for content</source>
<translation>Neie Übersedzung für den Inhald</translation>
   </message> 
   <message> 
       <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
<translation>Wähle oi dr Übersedzunge aus dr Lischde zum Hinzfüge odr geb oi Individuelle in des Eingabefeld oi.</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Custom</source>
<translation>Individuell</translation>
   </message> 
   <message> 
       <source>Name of translation</source>
<translation>Nam dr Übersedzung</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Change</source>
<translation>Ändern</translation>
   </message> 
   <message> 
       <source>Create</source>
<translation>Erschdellen</translation>
   </message> 
   <message> 
       <source>Content translations</source>
<translation>Übersezunge vom Inhalds</translation>
   </message> 
   <message> 
       <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
<translation>Unde findet Sie oi Lischde vo akdive Übersedzunge, in d Condend Objekde übersedzd werde könne.</translation>
   </message> 
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Country</source>
<translation>Land</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>URL translator</source>
<translation>URL Übersedzer</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Add</source>
<translation>Hinzfügen</translation>
   </message> 
   <message> 
       <source>Removing &apos;%1&apos; will remove the translation itself and %2 translated versions!</source>
<translation>Das Entfernen von &apos;%1&apos; wird auch die Ãbersetzung entfernen und %2 Ã¼bersetzte Versionen!</translation>
   </message> 
</context>
<context>
<name>design/standard/content/browse</name>
   <message> 
       <source>Create new</source>
<translation>Nei erzeigen</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
<translation>Um Objekde auszwähle, wählet Sie d endschbrechende Radiobuddons odr Cheggboxe und kligget Sie den &quot;Wähle&quot; Buddo.</translation>
   </message> 
   <message> 
       <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
<translation>Um oi Objekd auszwähle, dess oi Kind von a dr dargeschdellde Objekde isch, kligget Sie den Objekdname, um oi Lischde dr Kindr diess Objekds z sehe.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Up one level</source>
<translation>Eine Ebene no oben</translation>
   </message> 
   <message> 
       <source>Top levels</source>
<translation>Oberschde Ebenen</translation>
   </message> 
   <message> 
       <source>Switch top levels by clicking one of these items.</source>
<translation>Wechseln z oir obere Ebene durch Kligge oir von dene Elemende.</translation>
   </message> 
   <message> 
       <source>Bookmarks</source>
<translation>Lesezeichen</translation>
   </message> 
   <message> 
       <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
<translation>Lesezeichen werden verwaltet durch &quot;%bookmarkname&quot; in Bereich &quot;%personalname&quot;.</translation>
   </message> 
   <message> 
       <source>My bookmarks</source>
<translation>Moi Lesezeichen</translation>
   </message> 
   <message> 
       <source>Personal</source>
<translation>Persönliches</translation>
   </message> 
   <message> 
       <source>Recent items</source>
<translation>Akduelle Elemende</translation>
   </message> 
   <message> 
       <source>Recent items are added on publishing.</source>
<translation>Akduelle Elemende werde beim Veröffendlile hinzugefügd.</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
</context>
<context>
<name>design/standard/content/copy</name>
   <message> 
       <source>Copying %1</source>
<translation>%1 kopieren</translation>
   </message> 
   <message> 
       <source>Copy all versions</source>
<translation>Alle Versione kobieren</translation>
   </message> 
   <message> 
       <source>Copy current version</source>
<translation>Akduelle Versio kobieren</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Version count is %1, and current version is %2.</source>
<translation>%1 Versionen sind verfÃ¼gbar und die aktuelle Version ist %2.</translation>
   </message> 
</context>
<context>
<name>design/standard/content/copy_subtree</name>
   <message> 
       <source>Copying subtree from node %1</source>
<translation>Teil der Baumstruktur von Knoten %1 kopieren</translation>
   </message> 
   <message> 
       <source>Copy all versions.</source>
<translation>Alle Versione kobiere.</translation>
   </message> 
   <message> 
       <source>Copy current version.</source>
<translation>Akduelle Versio kobiere.</translation>
   </message> 
   <message> 
       <source>Keep creators of contentobjects being copied unchaged.</source>
<translation>Die Erschdellr vo Objekde beim Kobiere unveränderd lasse.</translation>
   </message> 
   <message> 
       <source>Set new creator for contentobjects being copied.</source>
<translation>Neie Erschdellr für kobierde Objekde sedze.</translation>
   </message> 
   <message> 
       <source>Keep time of creation and modification of contentobjects being copied unchanged.</source>
<translation>Zeid dr Erschdellung odr Änderunge vo Objekde d kobierd werde unveränderd lasse.</translation>
   </message> 
   <message> 
       <source>Copy and publish contentobjects at current time.</source>
<translation>Kobiere und Veröffendlile vo Objekde zur akduelle Zeid.</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/content/copy_subtree_notification</name>
   <message> 
       <source>Copy Subtree Notification</source>
<translation>Benachrichdigunge übr Teile dr Baumschdrukdur kobieren</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
</context>
<context>
<name>design/standard/content/create</name>
   <message> 
       <source>Create new</source>
<translation>Nei erzeigen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/content/datatype</name>
   <message> 
       <source>Remove image</source>
<translation>Endferne Bild</translation>
   </message> 
   <message> 
       <source>High</source>
<translation>Hoch</translation>
   </message> 
   <message> 
       <source>Best</source>
<translation>Beschde</translation>
   </message> 
   <message> 
       <source>Low</source>
<translation>Gering</translation>
   </message> 
   <message> 
       <source>Autohigh</source>
<translation>Audomad. Auflösung hoch</translation>
   </message> 
   <message> 
       <source>Autolow</source>
<translation>Audomad. Auflösung niedrig</translation>
   </message> 
   <message> 
       <source>Autoplay</source>
<translation>Audo-Wiedergabe</translation>
   </message> 
   <message> 
       <source>Loop</source>
<translation>Schleife</translation>
   </message> 
   <message> 
       <source>Controller</source>
<translation>Condroller</translation>
   </message> 
   <message> 
       <source>ImageWindow</source>
<translation>Bildfenschder</translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>ControlPanel</source>
<translation>Bedienfeld</translation>
   </message> 
   <message> 
       <source>InfoVolumePanel</source>
<translation>Bedienfeld Info-Laudschdärke</translation>
   </message> 
   <message> 
       <source>InfoPanel</source>
<translation>Bedienfeld Info</translation>
   </message> 
   <message> 
       <source>User account information</source>
<translation>Benudzerdadeninformazionen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Filename</source>
<translation>Dadoiame</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Year</source>
<translation>Jahr</translation>
   </message> 
   <message> 
       <source>Month</source>
<translation>Monad</translation>
   </message> 
   <message> 
       <source>Day</source>
<translation>Tag</translation>
   </message> 
   <message> 
       <source>Hour</source>
<translation>Schdunde</translation>
   </message> 
   <message> 
       <source>Minute</source>
<translation>Minuade</translation>
   </message> 
   <message> 
       <source>Alternative image text</source>
<translation>Aldernadivr Bilddexd</translation>
   </message> 
   <message> 
       <source>Width</source>
<translation>Breide</translation>
   </message> 
   <message> 
       <source>Height</source>
<translation>Höhe</translation>
   </message> 
   <message> 
       <source>Quality</source>
<translation>Qualidäd</translation>
   </message> 
   <message> 
       <source>Controls</source>
<translation>Kondrollen</translation>
   </message> 
   <message> 
       <source>No relation</source>
<translation>Koi Verwanddschafd</translation>
   </message> 
   <message> 
       <source>Options</source>
<translation>Obzionen</translation>
   </message> 
   <message> 
       <source>Start value</source>
<translation>Schdardwerd</translation>
   </message> 
   <message> 
       <source>Stop value</source>
<translation>Schdobwerd</translation>
   </message> 
   <message> 
       <source>Step value</source>
<translation>Schriddweide</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Text</source>
<translation>Texd</translation>
   </message> 
   <message> 
       <source>User ID</source>
<translation>Usr ID</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>Confirm password</source>
<translation>Password beschdädigen</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>Price</source>
<translation>Preis</translation>
   </message> 
   <message> 
       <source>Email</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Remove object</source>
<translation>Objekd endfernen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>No media file is available.</source>
<translation>Es sind koi Mediendadeie verfügbar.</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Default</source>
<translation>Schdandard</translation>
   </message> 
   <message> 
       <source>Additional price</source>
<translation>Zusädzlichr Preis</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>Your price</source>
<translation>Ihr Preis</translation>
   </message> 
   <message> 
       <source>You save</source>
<translation>Sie schbaren</translation>
   </message> 
   <message> 
       <source>Select author row for removal.</source>
<translation>Audorenzeile zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Remove selected rows from the author list.</source>
<translation>Ausgewählde Zeile vo dr Lischde dr Audore endferne.</translation>
   </message> 
   <message> 
       <source>Add author</source>
<translation>Audor hinzfügen</translation>
   </message> 
   <message> 
       <source>Add a new row to the author list.</source>
<translation>Eine neie Zeile zur Lischde dr Audore hinzfüge.</translation>
   </message> 
   <message> 
       <source>MIME type</source>
<translation>MIME-Tyb</translation>
   </message> 
   <message> 
       <source>Size</source>
<translation>Größe</translation>
   </message> 
   <message> 
       <source>Remove the file from this draft.</source>
<translation>Die Dadei aus dem Endwurf endferne.</translation>
   </message> 
   <message> 
       <source>Remove selected rows from the matrix.</source>
<translation>Ausgewählde Zeile aus dr Madrix endferne.</translation>
   </message> 
   <message> 
       <source>Number of rows to add.</source>
<translation>Anzahl dr hinzuzfügende Zeile.</translation>
   </message> 
   <message> 
       <source>Add rows</source>
<translation>Zeile hinzfügen</translation>
   </message> 
   <message> 
       <source>Add new rows to the matrix.</source>
<translation>Eine neie Zeile zur Madrix hinzfüge.</translation>
   </message> 
   <message> 
       <source>Select multioption for removal.</source>
<translation>Mehrfachauswahl zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to set the default option.</source>
<translation>Benudzet Sie diese Radio-Buddons, um d vorausgewählde Obzion z defniniere.</translation>
   </message> 
   <message> 
       <source>Add option</source>
<translation>Obzion hinzfügen</translation>
   </message> 
   <message> 
       <source>Add a new option.</source>
<translation>Neie Obzion hinzfüge.</translation>
   </message> 
   <message> 
       <source>Remove selected options.</source>
<translation>Ausgewählde Obzione endferne.</translation>
   </message> 
   <message> 
       <source>Add multioption</source>
<translation>Neie Mehrfachauswahl hinzfügen</translation>
   </message> 
   <message> 
       <source>Add a new multioption.</source>
<translation>Neie Mehrfachauswahl.</translation>
   </message> 
   <message> 
       <source>Remove selected multioptions.</source>
<translation>Ausgewählde Mehrfachauswahle endferne.</translation>
   </message> 
   <message> 
       <source>Select option for removal.</source>
<translation>Obzion zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>There are no options.</source>
<translation>Es gibd koi Obzione.</translation>
   </message> 
   <message> 
       <source>Current file</source>
<translation>Akduelle Dadei</translation>
   </message> 
   <message> 
       <source>There is no file.</source>
<translation>Es gibd koi Dadei.</translation>
   </message> 
   <message> 
       <source>New file for upload</source>
<translation>Neie Dadei zum Hochladen</translation>
   </message> 
   <message> 
       <source>Current image</source>
<translation>Akduells Bild</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>There is no image file.</source>
<translation>Es gibd koi Bilddadei.</translation>
   </message> 
   <message> 
       <source>New image file for upload</source>
<translation>Neie Bilddadei zum Hochlade.</translation>
   </message> 
   <message> 
       <source>Select row for removal.</source>
<translation>Zeile zum Endferne auswähle.</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Flash</source>
<translation>Flash</translation>
   </message> 
   <message> 
       <source>QuickTime</source>
<translation>QuiggTime</translation>
   </message> 
   <message> 
       <source>Real player</source>
<translation>RealPlayer</translation>
   </message> 
   <message> 
       <source>Windows media player</source>
<translation>Windows MediaPlayer</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>Option</source>
<translation>Obzion</translation>
   </message> 
   <message> 
       <source>There are no multioptions.</source>
<translation>Es gibd koi Mehrfachauswahle.</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>There are no related objects.</source>
<translation>Es gibd koi verwandde Objekde.</translation>
   </message> 
   <message> 
       <source>Edit selected</source>
<translation>Ausgewählde bearbeiden</translation>
   </message> 
   <message> 
       <source>Create new object</source>
<translation>Neis Objekd erschdellen</translation>
   </message> 
   <message> 
       <source>There are no authors in the author list.</source>
<translation>Es befinde si koi Authore in dr Lischde dr Authore.</translation>
   </message> 
   <message> 
       <source>There are no rows in the matrix.</source>
<translation>Es befinde si koi Reihe in dr Madrix.</translation>
   </message> 
   <message> 
       <source>Option set name</source>
<translation>Nam dr Grubb vo Obzionen</translation>
   </message> 
   <message> 
       <source>Configure user account settings</source>
<translation>Benudzerkonden-Einschdellunge konfigurieren</translation>
   </message> 
   <message> 
       <source>Add object</source>
<translation></translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%object_name&gt; [%object_class]</source>
<translation></translation>
   </message> 
   <message> 
       <source>Add objects</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/content/edit</name>
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Eingab war nedd validierbar</translation>
   </message> 
   <message> 
       <source>Input was stored successfully</source>
<translation>Eingab wurd erfolgreich gschbeicherd</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Sort by</source>
<translation>Sordierd durch</translation>
   </message> 
   <message> 
       <source>Ordering</source>
<translation>Richdung</translation>
   </message> 
   <message> 
       <source>Main</source>
<translation>Haubd-Ord</translation>
   </message> 
   <message> 
       <source>Move</source>
<translation>Verschiaben</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Veränderd</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Depth</source>
<translation>Tiefe</translation>
   </message> 
   <message> 
       <source>Class Identifier</source>
<translation>Klassen-Idendifikador</translation>
   </message> 
   <message> 
       <source>Class Name</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>Send for publishing</source>
<translation>Zur Veröffendlichung freigeben</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Object info</source>
<translation>Objekd-Informazion</translation>
   </message> 
   <message> 
       <source>Not yet published</source>
<translation>Noch nedd veröffendlichd</translation>
   </message> 
   <message> 
       <source>Current</source>
<translation>Akduell</translation>
   </message> 
   <message> 
       <source>Manage</source>
<translation>Verwalden</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Related objects</source>
<translation>Verwandde Objekde</translation>
   </message> 
   <message> 
       <source>Find</source>
<translation>Finde</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Collected information from %1</source>
<translation>Gesammelte Informationen von %1</translation>
   </message> 
   <message> 
       <source>Store draft</source>
<translation>Schbeichere Endwurf</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Add locations</source>
<translation>Ord hinzfügen</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>Editing</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>%1 (No locale information available)</source>
<translation>%1 (Koi lokale Informazione verfügbar)</translation>
   </message> 
   <message> 
       <source>Validation failed</source>
<translation>nedd güldig</translation>
   </message> 
   <message> 
       <source>Location did not validate</source>
<translation>Ord war nedd güldig</translation>
   </message> 
   <message> 
       <source>Edit %1 - %2</source>
<translation>Ãndere %1 - %2</translation>
   </message> 
   <message> 
       <source>New draft</source>
<translation>Neir Endwurf</translation>
   </message> 
   <message> 
       <source>Feedback from %1</source>
<translation>RÃ¼ckmeldung von %1</translation>
   </message> 
   <message> 
       <source>The currently published version is %version and was published at %time.</source>
<translation>Die derzeitige verÃ¶ffentlichte Version ist %version und wurde verÃ¶ffendlicht am %time.</translation>
   </message> 
   <message> 
       <source>The last modification was done at %modified.</source>
<translation>Die letzte Ãnderung wurde getÃ¤tigt am %modified.</translation>
   </message> 
   <message> 
       <source>The object is owned by %owner.</source>
<translation>Das Objekt gehÃ¶rt %owner.</translation>
   </message> 
   <message> 
       <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
<translation>Des Objekd wird gerad vo jemand andere (odr Ihne selbsch) bearbeided.
Sie könne endwedr oin Ihrr Endwürf weidr bearbeide odr oin neie erschdelle.</translation>
   </message> 
   <message> 
       <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
<translation>Des Objekd wird scho vo Ihne edidierd.
Sie könne endwedr oin Ihrr Endwürf weidr bearbeide odr oin neie erschdelle.</translation>
   </message> 
   <message> 
       <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
<translation>Des Objekd wird scho vo jemand andere bearbeided.
Sie sollde endwedr d Perso deswege kondakdiere odr oin neie Endwurf zum bersönlile Bearbeide erschdelle.</translation>
   </message> 
   <message> 
       <source>Current drafts</source>
<translation>Derzeidigr Endwurf</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Owner</source>
<translation>Besidzer</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Input was partially stored</source>
<translation>Eingab wurd nur deilweise gschbeicherd</translation>
   </message> 
   <message> 
       <source>Are you sure you want to discard the draft %versionname?</source>
<translation>Sind Sie sicher, dass Sie den Entwurf %versionname verwerfen wollen?</translation>
   </message> 
   <message> 
       <source>Last Modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>The following feedback was collected</source>
<translation>Die folgend Rüggmeldung wurd gsammeld</translation>
   </message> 
   <message> 
       <source>The following information was collected</source>
<translation>Folgend Informazione wurde gsammeld</translation>
   </message> 
</context>
<context>
<name>design/standard/content/ezoption</name>
   <message> 
       <source>No value chosen</source>
<translation>Koi Werd gwähld</translation>
   </message> 
</context>
<context>
<name>design/standard/content/feedback</name>
   <message> 
       <source>Feedback for %feedbackname</source>
<translation>RÃ¼ckmeldung von %feedbackname</translation>
   </message> 
   <message> 
       <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
<translation>Sie hend scho Dade übermiddeld. Die vorhr übermiddelde Dade sind d folgende.</translation>
   </message> 
   <message> 
       <source>Thanks for your feedback, the following information was collected.</source>
<translation>Dank für Ihre Rüggmeldung, d folgende Informazione wurde gsammeld.</translation>
   </message> 
   <message> 
       <source>Return to site</source>
<translation>Zur Seide zurüggkehren</translation>
   </message> 
</context>
<context>
<name>design/standard/content/form</name>
   <message> 
       <source>Form %formname</source>
<translation>Von %formname</translation>
   </message> 
   <message> 
       <source>You have already submitted data to this form. The previously submitted data was the following.</source>
<translation>Sie hend scho Dade an diess Formular gschiggd. Des vorhergegangene Dade ware d folgende.</translation>
   </message> 
   <message> 
       <source>Return to site</source>
<translation>Zur Seide zurüggkehren</translation>
   </message> 
   <message> 
       <source>Collected information</source>
<translation>Gesammelde Informazionen</translation>
   </message> 
</context>
<context>
<name>design/standard/content/newcontent</name>
   <message> 
       <source>New content since last visit</source>
<translation>Neischdr Inhald seid dem ledze Besuch</translation>
   </message> 
   <message> 
       <source>There are no new content since your last visit.</source>
<translation>Es gibd koin neie Inhald seid dem ledzde Besuch.</translation>
   </message> 
   <message> 
       <source>Your last visit to this site was</source>
<translation>Dr ledzde Besuch von dene Seide war</translation>
   </message> 
</context>
<context>
<name>design/standard/content/pdf</name>
   <message> 
       <source>eZ publish PDF export</source>
<translation>eZ bublish PDF Exbord</translation>
   </message> 
   <message> 
       <source>#page of #total</source>
<translation>#bag vo #dodal</translation>
   </message> 
   <message> 
       <source>#level1 - #level2</source>
<translation>#level1 - #level2</translation>
   </message> 
   <message> 
       <source>#levelIndex1:#levelIndex2</source>
<translation>#levelIndex1:#levelIndex2</translation>
   </message> 
   <message> 
       <source>Content</source>
<translation>Inhald</translation>
   </message> 
   <message> 
       <source>Versionview not supported in PDF yet</source>
<translation>Versionansichde werde no nedd ündersüdzd im PDF exbord</translation>
   </message> 
</context>
<context>
<name>design/standard/content/poll</name>
   <message> 
       <source>Poll %pollname</source>
<translation>Umfrage %pollname</translation>
   </message> 
   <message> 
       <source>Anonymous users are not allowed to vote on this poll, please login.</source>
<translation>Anonym Benudzeret isch s nedd gschdadded an von dene Umfrag deilzunehme, Bidde meldet Sie i an.</translation>
   </message> 
   <message> 
       <source>You have already voted for this poll.</source>
<translation>Sie hend scho an von dene Umfrag deilgenomme.</translation>
   </message> 
   <message> 
       <source>%count total votes</source>
<translation>%cound Teilnehmer</translation>
   </message> 
   <message> 
       <source>Poll results</source>
<translation>Umfrag %bollname</translation>
   </message> 
</context>
<context>
<name>design/standard/content/search</name>
   <message> 
       <source>Advanced search</source>
<translation>Erweiderde Suche</translation>
   </message> 
   <message> 
       <source>Any class</source>
<translation>Alle Klassen</translation>
   </message> 
   <message> 
       <source>Update attributes</source>
<translation>Eigenschafde akdualisieren</translation>
   </message> 
   <message> 
       <source>Any section</source>
<translation>alle Sekzionen</translation>
   </message> 
   <message> 
       <source>Any time</source>
<translation>Jeds Dadum</translation>
   </message> 
   <message> 
       <source>Last day</source>
<translation>Ledzdr Tag</translation>
   </message> 
   <message> 
       <source>Last week</source>
<translation>Ledzde Woche</translation>
   </message> 
   <message> 
       <source>Last month</source>
<translation>Ledzdr Monad</translation>
   </message> 
   <message> 
       <source>Last three months</source>
<translation>Ledzde drei Monade</translation>
   </message> 
   <message> 
       <source>Last year</source>
<translation>Ledzds Jahr</translation>
   </message> 
   <message> 
       <source>Search</source>
<translation>Suchen</translation>
   </message> 
   <message> 
       <source>Search all the words</source>
<translation>Suche alle Wörder</translation>
   </message> 
   <message> 
       <source>Search the exact phrase</source>
<translation>Suche exakde Ausdrugg</translation>
   </message> 
   <message> 
       <source>Search with at least one of the words</source>
<translation>Suche mid mindeschdens oim von dene Wörder</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Class attribute</source>
<translation>Klasseneigenschafd</translation>
   </message> 
   <message> 
       <source>In</source>
<translation>In</translation>
   </message> 
   <message> 
       <source>Published</source>
<translation>Veröffendlichd</translation>
   </message> 
   <message> 
       <source>No results were found when searching for &quot;%1&quot;</source>
<translation>Es wurden keine Ergebnisse gefunden, als nach &apos;%1&apos; gesucht wurde</translation>
   </message> 
   <message> 
       <source>Search for &quot;%1&quot; returned %2 matches</source>
<translation>Suche nach &quot;%1&quot; ergab %2 Ergebnisse</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Display per page</source>
<translation>Pro Seide anzeigen</translation>
   </message> 
   <message> 
       <source>5 items</source>
<translation>5 Schdügg</translation>
   </message> 
   <message> 
       <source>10 items</source>
<translation>10 Schdügg</translation>
   </message> 
   <message> 
       <source>20 items</source>
<translation>20 Schdügg</translation>
   </message> 
   <message> 
       <source>30 items</source>
<translation>30 Schdügg</translation>
   </message> 
   <message> 
       <source>50 items</source>
<translation>50 Schdügg</translation>
   </message> 
   <message> 
       <source>Search tips</source>
<translation>Suchdibbs</translation>
   </message> 
   <message> 
       <source>Check spelling of keywords.</source>
<translation>Überbrüfet Sie d Rechdschreibung dr Suchwördr.</translation>
   </message> 
   <message> 
       <source>Try changing some keywords eg. car instead of cars.</source>
<translation>Versuchet Sie oiig Suchwördr z. B. Audo anschdadd vo Audos.</translation>
   </message> 
   <message> 
       <source>Try more general keywords.</source>
<translation>Versuchet Sie s mid allgemoire Wörderet.</translation>
   </message> 
   <message> 
       <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
<translation>Wenigr Suchwördr gebe mehr Ergebnisse, versuchet Sie d Suchwördr z reduziere, bis Sie oi Ergebnis bekomme.</translation>
   </message> 
   <message> 
       <source>For more options try the %1Advanced search%2</source>
<translation>FÃ¼r mehr Optionen die %1 erweiterte Suche %2 probieren</translation>
   </message> 
   <message> 
       <source>Any attribute</source>
<translation>Beliabigs Addribud</translation>
   </message> 
   <message> 
       <source>The following words were excluded from the search</source>
<translation>Nach folgende Worde wurd nedd gsuchd.</translation>
   </message> 
</context>
<context>
<name>design/standard/content/tipafriend</name>
   <message> 
       <source>Tip a friend</source>
<translation>Tibb an Freind</translation>
   </message> 
   <message> 
       <source>The message was sent.</source>
<translation>Die Nachrichd wurd versandd.</translation>
   </message> 
   <message> 
       <source>Click here to return to the original page.</source>
<translation>Hir kligge um zur originale Seide zurüggzkehre.</translation>
   </message> 
   <message> 
       <source>The message was not sent.</source>
<translation>Die Nachrichd wurd nedd versandd.</translation>
   </message> 
   <message> 
       <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
<translation>Die Nachrichd wurd aufgrund von a unbekannde Fehlers nedd versandd. Bidde benachrichde SIe den Adminischdrador übr diese Fehlr.</translation>
   </message> 
   <message> 
       <source>Your name</source>
<translation>Ihr Name</translation>
   </message> 
   <message> 
       <source>Your email address</source>
<translation>Ihre E-Mail Adresse</translation>
   </message> 
   <message> 
       <source>Receivers name</source>
<translation>Nam vom Embfängers</translation>
   </message> 
   <message> 
       <source>Receivers email address</source>
<translation>E-Mail Adresse vom Embfängers</translation>
   </message> 
   <message> 
       <source>Subject</source>
<translation>Thema</translation>
   </message> 
   <message> 
       <source>Comment</source>
<translation>Kommendar</translation>
   </message> 
   <message> 
       <source>Send</source>
<translation>Senden</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
<translation>Diese Nachricht wurde an Sie gesand, weil &quot;%1 &lt;%2&gt;&quot; dachte Sie fÃ¤nden diese Seite &quot;%3&quot; auf %4 interessant.</translation>
   </message> 
   <message> 
       <source>Please correct the following errors</source>
<translation>Bidde korrigieret Sie d folgende Fehler</translation>
   </message> 
   <message> 
       <source>This is the link to the page</source>
<translation>Dis isch dr Link z dr Seide</translation>
   </message> 
   <message> 
       <source>Comment by &quot;%1 &lt;%2&gt;&quot;</source>
<translation>Kommentar von &quot;%1 &lt;%2&gt;&quot;</translation>
   </message> 
</context>
<context>
<name>design/standard/content/translate</name>
   <message> 
       <source>(No locale information available)</source>
<translation>(Koi Lokalisierungsinformazione verfügbar)</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Add</source>
<translation>Hinzfügen</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Translate</source>
<translation>Übersedzen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>%1 input was stored successfully</source>
<translation>%1 Eingab wurd erfolgreich gschbeicherd</translation>
   </message> 
   <message> 
       <source>Locale</source>
<translation>Ördlichkeid</translation>
   </message> 
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Translate into</source>
<translation>Übersedz nach</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Translating &apos;%1&apos;</source>
<translation>Ãbersetze &apos;%1&apos;</translation>
   </message> 
   <message> 
       <source>Remove the following translations from &apos;%1&apos;</source>
<translation>Entferne die folgenden Ãbersetzungen von &apos;%1&apos;</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Eingab isch ungüldig</translation>
   </message> 
</context>
<context>
<name>design/standard/content/trash</name>
   <message> 
       <source>Trash</source>
<translation>Abfalleimer</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Current version</source>
<translation>Akduelle Version</translation>
   </message> 
   <message> 
       <source>Restore</source>
<translation>Wiederherschdellen</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Trash is empty</source>
<translation>Abfalleimr isch leer</translation>
   </message> 
   <message> 
       <source>Empty Trash</source>
<translation>Abfalleimr leeren</translation>
   </message> 
   <message> 
       <source>Select all</source>
<translation>Alle auswählen</translation>
   </message> 
   <message> 
       <source>Deselect all</source>
<translation>Alle abwählen</translation>
   </message> 
</context>
<context>
<name>design/standard/content/upload</name>
   <message> 
       <source>Upload file</source>
<translation>Dadei hochladen</translation>
   </message> 
   <message> 
       <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
<translation>Wählet Sie oi Dadei vo Ihrem lokale Rechnr und kligget Sie den &quot;Hochladen&quot; Knobf. Es wird oi Objekd gmäß dr Ard dr Dadei erschdelld und an dem gwähle Ord blazierd werde.</translation>
   </message> 
   <message> 
       <source>Some errors occurred</source>
<translation>Einig Fehlr drahde auf</translation>
   </message> 
   <message> 
       <source>Location</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>Automatic</source>
<translation>Audomadisch</translation>
   </message> 
   <message> 
       <source>Upload</source>
<translation>Hochladen</translation>
   </message> 
   <message> 
       <source>Click here to upload a file. The file will be placed within the location that is specified using the dropdown menu on the top.</source>
<translation>Kligget Sie hir, um oi Dadei hochzulade. Die Dadei wird an dem Ord blazierd, den Sie mid dem Drobdown-Menü obe gwähld hend.</translation>
   </message> 
</context>
<context>
<name>design/standard/content/version</name>
   <message> 
       <source>Version not a draft</source>
<translation>Versio isch koi Endwurf</translation>
   </message> 
   <message> 
       <source>To edit this version create a copy of it.</source>
<translation>Um diese Versio z bearbeide erschdellet Sie oi Kobie.</translation>
   </message> 
   <message> 
       <source>Version not yours</source>
<translation>Diese Versio gehörd Ihne nedd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Copy and edit</source>
<translation>Kobiere und bearbeiden</translation>
   </message> 
   <message> 
       <source>Versions for: %1</source>
<translation>Versionen fÃ¼r: %1</translation>
   </message> 
   <message> 
       <source>Version %1 was not created by you, only your own drafts can be edited.</source>
<translation>Version %1 wurde nicht von Ihnen erstellt. Sie kÃ¶nnen nur Ihre eigenen EntwÃ¼rfe bearbeiten.</translation>
   </message> 
   <message> 
       <source>Unable to create new version</source>
<translation>Neie Versio kann nedd erschdelld werden</translation>
   </message> 
   <message> 
       <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
<translation>Dr Versionsverlauf hedd soi Limid erreichd und koi archivierde Versio kann vom Syschdem endfernd werde.</translation>
   </message> 
   <message> 
       <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
<translation>Sie könne d Einschdellunge vom Versionsverlaufs im condend.ini änderet, Endwürf lösche odr beschdehend Endwürf änderet.</translation>
   </message> 
   <message> 
       <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
<translation>Version %1 kann nicht mehr bearbeitet werden, nur EntwÃ¼rfe kÃ¶nnen bearbeitet werden.</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Translations</source>
<translation>Übersedzungen</translation>
   </message> 
   <message> 
       <source>Creator</source>
<translation>Erschdeller</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Bearbeider</translation>
   </message> 
</context>
<context>
<name>design/standard/content/view</name>
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>My drafts</source>
<translation>Ihre Endwürfe</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>You have no drafts</source>
<translation>Sie hend koi Endwürfe</translation>
   </message> 
   <message> 
       <source>Related objects</source>
<translation>Verwandde Objekde</translation>
   </message> 
   <message> 
       <source>None</source>
<translation>Koi</translation>
   </message> 
   <message> 
       <source>Change</source>
<translation>Ändern</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Publish</source>
<translation>Veröffendlichen</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Current version</source>
<translation>Akduelle Version</translation>
   </message> 
   <message> 
       <source>Translation</source>
<translation>Übersedzung</translation>
   </message> 
   <message> 
       <source>Placement</source>
<translation>Pladzierung</translation>
   </message> 
   <message> 
       <source>Site Design</source>
<translation>Seidendesign</translation>
   </message> 
   <message> 
       <source>My bookmarks</source>
<translation>Moi Lesezeichen</translation>
   </message> 
   <message> 
       <source>Add bookmarks</source>
<translation>Lesezeile hinzfügen</translation>
   </message> 
   <message> 
       <source>You have no bookmarks</source>
<translation>Sie hend koi Lesezeichen</translation>
   </message> 
   <message> 
       <source>Last modified</source>
<translation>Zuledzd gänderd</translation>
   </message> 
   <message> 
       <source>Empty Draft</source>
<translation>Endwürf löschen</translation>
   </message> 
   <message> 
       <source>My pending list</source>
<translation>Moi Wardelischde</translation>
   </message> 
   <message> 
       <source>Your pending list is empty</source>
<translation>Ihre Wardelischde isch leer</translation>
   </message> 
   <message> 
       <source>Select all</source>
<translation>Alle auswählen</translation>
   </message> 
   <message> 
       <source>Deselect all</source>
<translation>Alle abwählen</translation>
   </message> 
   <message> 
       <source>Choose initial placement</source>
<translation>Wähle dr erschde Pladzierung</translation>
   </message> 
   <message> 
       <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Wo soll der/die/das neue %classname gespeichert werden? 

WÃ¤hlen Sie den Ort und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf einen Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose items to bookmark</source>
<translation>Wählet Sie oi Elemend, um s den Lesezeile hinzuzfügen</translation>
   </message> 
   <message> 
       <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
<translation>WÃ¤hlen Sie die Objekte aus, die Sie Ihrer Lesezeichen-Liste hinzufÃ¼gen wollen und klicken Sie dann auf &quot;%buttonname&quot;. 
Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose new placement</source>
<translation>Wählet Sie d neie Pladzierung</translation>
   </message> 
   <message> 
       <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie bitte die neue Platzierung fÃ¼r %name und klicken Sie dann auf &quot;%buttonname&quot;. 
Die bisherige Platzierung war in %placementname.

Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose placements</source>
<translation>Wähle dr Pladzierung</translation>
   </message> 
   <message> 
       <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie bitte die Platzierung fÃ¼r %name und klicken Sie dann auf &quot;%buttonname&quot;. 
Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose related objects</source>
<translation>Wähle dr verwndde Objekde</translation>
   </message> 
   <message> 
       <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
<translation>Welche Objekte sollen mit %name verwandt sein?
WÃ¤hlen Sie diese aus und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
<translation>Dies sind die Objekte asu Ihren Favoriten. Klicken Sie auf ein Objekt, um es anzusehen oder wenn die entsprechende Berechtigung haben, kÃ¶nnen Sie das Objekt bearbeiten durch klick des bearbeiten Buttons. Wenn Sie noch mehr Objekte hinzufÃ¼gen wollen, klicken Sie die %emphasize_startAdd Favoriten %emphasize_stop button.

Das Entfernen der Objekte wird Sie nur aus dieser Liste entfernen.</translation>
   </message> 
   <message> 
       <source>Choose node for default selection</source>
<translation>Wähle Knode für schdandard Auswahl</translation>
   </message> 
   <message> 
       <source>Please choose where you want to the default selection of objectrelation to start from.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie, bei welchem Knoten Sie bei &quot;Objektverwandschaft&quot; starten wollen.

WÃ¤hlen Sie den Ort und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf einen Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Collected info</source>
<translation>Gesammelde Informazionen</translation>
   </message> 
   <message> 
       <source>Choose new location for %objectname</source>
<translation>Neuen Ort fÃ¼r %objectname wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Please choose where you want to place %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Wo soll %objectname gespeichert werden? 
WÃ¤hlen Sie den Ort und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf einen Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Upload file</source>
<translation>Dadei hochladen</translation>
   </message> 
   <message> 
       <source>Choose the exchanging node for %objectname</source>
<translation>Den Tausch-Knoten fÃ¼r %objectname wÃ¤hlen</translation>
   </message> 
   <message> 
       <source>Please choose which node you want to exchange %objectname with.

    Select the node and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie, gegen welchen Knoten Sie %objectname austauschen wollen.

WÃ¤hlen Sie den Ort und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf einen Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
<translation>Dis sind d Objekde, an denet Sie gerad arbeide. Die Endwürf gehöre Ihne und könne nur vo Ihne gsehe werde.
      Sie könne oin Endwurf bearbeide odr Endwürf lösche, d Sie nemme braule.</translation>
   </message> 
   <message> 
       <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
<translation>Wähle oi Dadei vo vo Ihrem lokale Rechnr und kligget Sie den &quot;Hochladen&quot; Knobf. Es wird oi Objekd gmäß dr Ard dr Dadei erschdelld und an dem gwähle Ord blazierd werde.</translation>
   </message> 
   <message> 
       <source>Choose a new location the copy of %objectname</source>
<translation>WÃ¤hlen Sie einen neuen Ort fÃ¼r die Kopie von %objectname</translation>
   </message> 
   <message> 
       <source>Please choose where you want to copy %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Bitte wÃ¤hlen Sie, wohin Sie %objectname kopieren wollen.

    WÃ¤hlen Sie den neuen Ort und klicken Sie auf den Knopf %buttonname.
    Sollte die Liste der zuletzt verwendeten Elemente oder die der Lesezeichen zur VerfÃ¼gung stehen, kÃ¶nnen Sie den Ort auch daraus wÃ¤hlen.
    Klicken Sie auf die Namen der Orte, um durch die angezeigten Elemente zu blÃ¤ttern.</translation>
   </message> 
   <message> 
       <source>Choose new location for copy of subtree of node %node_name</source>
<translation>WÃ¤hlen Sie einen neuen Ort fÃ¼r die Kopie des Teiles der Baumstruktur von Knoten %node_name</translation>
   </message> 
   <message> 
       <source>Please choose where you want to copy subtree of node %node_name.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Bitte wÃ¤hlen Sie, wohin Sie den Teil der Baumstruktur von Knoten %node_name kopieren wollen.

    WÃ¤hlen Sie den neuen Ort und klicken Sie auf den Knopf %buttonname.
    Sollte die Liste der zuletzt verwendeten Elemente oder die der Lesezeichen zur VerfÃ¼gung stehen, kÃ¶nnen Sie den Ort auch daraus wÃ¤hlen.
    Klicken Sie auf die Namen der Orte, um durch die angezeigten Elemente zu blÃ¤ttern.</translation>
   </message> 
   <message> 
       <source>Site Access</source>
<translation>Seide Zugang</translation>
   </message> 
</context>
<context>
<name>design/standard/contentstructuremenu</name>
   <message> 
       <source>Fold/Unfold</source>
<translation>Minimieren/Maximieren</translation>
   </message> 
   <message> 
       <source>[%classname] Click on the icon to get a context sensitive menu.</source>
<translation>[%classname] Klicken Sie auf das Symbol, um ein vom Inhalt abhÃ¤ngiges MenÃ¼ zu erhalten.</translation>
   </message> 
</context>
<context>
<name>design/standard/design/templateadmin</name>
   <message> 
       <source>Template edit</source>
<translation>Temblade bearbeiden</translation>
   </message> 
   <message> 
       <source>Save</source>
<translation>schbeichern</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
</context>
<context>
<name>design/standard/design/templatecreate</name>
   <message> 
       <source>Could not create template, permission denied.</source>
<translation>Konnde des Temblade nedd erschdelle, Zugriff verweigerd.</translation>
   </message> 
   <message> 
       <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
<translation>Ungüldigr Nam. Sie könne nur d Buchschdabe a-z, Zifferet und _ benudze.</translation>
   </message> 
   <message> 
       <source>Create new template override for &lt;%template_name&gt;</source>
<translation>Neues Ãberschreib-Template fÃ¼r &lt;%template_name&gt; erstellen</translation>
   </message> 
   <message> 
       <source>The newly created template file will be placed in</source>
<translation>Die nei erschdellde Temblade-Dadei wird blazierd in</translation>
   </message> 
   <message> 
       <source>Filename</source>
<translation>Dadoiame</translation>
   </message> 
   <message> 
       <source>Override keys</source>
<translation>Überschreibungsschlüssel</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>All classes</source>
<translation>Alle Klassen</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>All sections</source>
<translation>Alle Sekzionen</translation>
   </message> 
   <message> 
       <source>Node ID</source>
<translation>Knode ID</translation>
   </message> 
   <message> 
       <source>Base template on</source>
<translation>Temblade-Grundlage</translation>
   </message> 
   <message> 
       <source>Empty file</source>
<translation>Leere Dadei</translation>
   </message> 
   <message> 
       <source>Copy of default template</source>
<translation>Kobie vom Schdandard-Temblades</translation>
   </message> 
   <message> 
       <source>Container (with children)</source>
<translation>Condainr ( mid Kinderet )</translation>
   </message> 
   <message> 
       <source>View (without children)</source>
<translation>Sichd ( ohne Kindr )</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Object</source>
<translation>Objekd</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/design/templatelist</name>
   <message> 
       <source>Complete template list</source>
<translation>Kombledde Tembladelischde</translation>
   </message> 
   <message> 
       <source>Template</source>
<translation>Temblade</translation>
   </message> 
   <message> 
       <source>Design resource</source>
<translation>Design Ressource</translation>
   </message> 
   <message> 
       <source>Most common templates</source>
<translation>Die gebräuchlichschde Temblades</translation>
   </message> 
</context>
<context>
<name>design/standard/design/templateview</name>
   <message> 
       <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
<translation>Ãberschreibungen fÃ¼r das Template &lt;%template_name&gt; im &lt;%current_siteaccess&gt; Seiten-Zugang [%override_count]</translation>
   </message> 
   <message> 
       <source>Default template resource</source>
<translation>Schdandard-Temblade-Ressource</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Match conditions</source>
<translation>Bedingungen</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>New override</source>
<translation>Neis Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde schbeichern</translation>
   </message> 
</context>
<context>
<name>design/standard/design/toolbar</name>
   <message> 
       <source>Tool List for Toolbar_%toolbar_position</source>
<translation>Werkzeug-Liste fÃ¼r Toolbar_%toolbar_position</translation>
   </message> 
   <message> 
       <source>Tool</source>
<translation>Werkzeige</translation>
   </message> 
   <message> 
       <source>Placement</source>
<translation>Pladzierung</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Update Placement</source>
<translation>Pladzierung akdualisieren</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Add Tool</source>
<translation>Werkzeig hinzfügen</translation>
   </message> 
   <message> 
       <source>Toolbar management</source>
<translation>Werkzeig-Leischden-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Current siteaccess</source>
<translation>Akduells Seide Zugang</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Available toolbars</source>
<translation>Verfügbare Werkzeig-Leischden</translation>
   </message> 
</context>
<context>
<name>design/standard/error/kernel</name>
   <message> 
       <source>Access denied</source>
<translation>Zugriff verweigerd</translation>
   </message> 
   <message> 
       <source>You don&apos;t have permission to access this area.</source>
<translation>Sie sind nedd berechdigd, diese Bereich z bedrede.</translation>
   </message> 
   <message> 
       <source>Not found</source>
<translation>Nedd funden</translation>
   </message> 
   <message> 
       <source>Module not found</source>
<translation>Modul nedd funden</translation>
   </message> 
   <message> 
       <source>View not found</source>
<translation>Sichd nedd funden</translation>
   </message> 
   <message> 
       <source>Click the Login button to login.</source>
<translation>De Anmeld Buddo kligge für den Login.</translation>
   </message> 
   <message> 
       <source>View is disabled</source>
<translation>Sichd isch deakivierd</translation>
   </message> 
   <message> 
       <source>Module is disabled</source>
<translation>Modul isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Your current user does not have the proper privileges to access this page.</source>
<translation>Ihr akduellr Benudzr hedd nedd d rechte Rechde, diese Seide z bedrede.</translation>
   </message> 
   <message> 
       <source>The resource you requested was not found.</source>
<translation>Ihre angeforderde Ressource wurd nedd funde.</translation>
   </message> 
   <message> 
       <source>The the id or name of the resource was misspelled, try changing it.</source>
<translation>Die ID odr dr Nam Ihrr Ressource isch falsch gschriabe, versuchet Sie dis z änderet.</translation>
   </message> 
   <message> 
       <source>The resource no longer exists on the site.</source>
<translation>Die Ressource exischdierd nemme auf von dene Seide.</translation>
   </message> 
   <message> 
       <source>The module does not exist on this site.</source>
<translation>Des Modul exischdierd nedd auf von dene Seide.</translation>
   </message> 
   <message> 
       <source>Object is unavailable</source>
<translation>Objekd isch nedd verfügbar</translation>
   </message> 
   <message> 
       <source>The object you requested is not currently available.</source>
<translation>Ihr angeforderds Objekd isch z.Z. nedd verfügbar.</translation>
   </message> 
   <message> 
       <source>The id or name of the object was misspelled, try changing it.</source>
<translation>Die ID odr dr Nam Ihrs Objekds isch falsch gschriabe, versuchet Sie dis z änderet.</translation>
   </message> 
   <message> 
       <source>The object is no longer available on the site.</source>
<translation>Des Objekd isch auf von dene Seide nemme verfügbar.</translation>
   </message> 
   <message> 
       <source>Object moved</source>
<translation>Objekd verschoben</translation>
   </message> 
   <message> 
       <source>The object is no longer available at this URL.</source>
<translation>Des Objekd isch nemme undr von dene URL erreichbar.</translation>
   </message> 
   <message> 
       <source>The requested module %module could not be found.</source>
<translation>Das angeforderte Modul %module konnte nicht gefunden werden.</translation>
   </message> 
   <message> 
       <source>The requested view %view could not be found in module %module</source>
<translation>Die angeforderte Sicht %view konnte nicht gefunden werden in Modul %modul</translation>
   </message> 
   <message> 
       <source>The view does not exist for the module %module.</source>
<translation>Sie Sicht existiert nicht fÃ¼r das das Modul %modul.</translation>
   </message> 
   <message> 
       <source>The view %module/%view is disabled and cannot be accessed.</source>
<translation>Die Sicht %module/%view is deaktiviert und kann nicht angefordert werden.</translation>
   </message> 
   <message> 
       <source>The module %module is disabled and cannot be accessed.</source>
<translation>Das Modul %module ist deaktiviert und kann nicht angefordert werden.</translation>
   </message> 
   <message> 
       <source>You should automatically be redirected to the new location. If not click %url.</source>
<translation>Sie sollten nun automatisch weitergeleitet werden zum neuen Bestimmungsort. Wenn nicht %url klicken.</translation>
   </message> 
   <message> 
       <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
<translation>Sie sind zur Zeid nedd angemelded auf von dene Seide, um endschbrechende Zugang z bekomme erschdellet Sie oin neie Benudzr odr meldet Sie si mid oim exischdierende Benudzr an.</translation>
   </message> 
   <message> 
       <source>Permission required</source>
<translation>Berechdigung erforderlich</translation>
   </message> 
   <message> 
       <source>Module :</source>
<translation>Modul :</translation>
   </message> 
   <message> 
       <source>Function :</source>
<translation>Funkzion :</translation>
   </message> 
   <message> 
       <source>You misspelled some parts of your URL, try changing it.</source>
<translation>Sie hend Teile dr URL falsch gschriabe. Versuchet Sie diese z änderet.</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>The module name was misspelled, try changing the URL.</source>
<translation>Dr Modulnam isch falsch gschriabe, versuchet Sie ihn z änderet.</translation>
   </message> 
   <message> 
       <source>This site uses siteaccess matching in the URL and you didn&apos;t supply one, try inserting a siteaccess name before the module in the URL .</source>
<translation>Diese Seide benudzd d Method vom Seidenzugangs innerhalb dr URL und Sie hend dis nedd angegebe. Versuche oin Seidenzugang vor dem Name vom Moduls in dr URL anzugebe.</translation>
   </message> 
   <message> 
       <source>The view name was misspelled, try changing the URL.</source>
<translation>Dr Nam dr Ansichd wurd falsch gschriabe. Versuchet Sie d URL anzubasse.</translation>
   </message> 
   <message> 
       <source>Possible reasons for this are</source>
<translation>Mögliche Gründ dafür sind</translation>
   </message> 
</context>
<context>
<name>design/standard/error/shop</name>
   <message> 
       <source>Not a product</source>
<translation>Isch koi Produkd</translation>
   </message> 
   <message> 
       <source>The requested object is not a product and cannot be used by the shop module.</source>
<translation>Des angeforderde Objekd isch koi Produkd und kann dahr nedd vor Shobmodul verwended werde.</translation>
   </message> 
</context>
<context>
<name>design/standard/form</name>
   <message> 
       <source>Thank you for your feedback</source>
<translation>Dank für ihre Anword</translation>
   </message> 
   <message> 
       <source>Your information was successfully received.</source>
<translation>Die Informazione wurde erfolgreich embfange.</translation>
   </message> 
</context>
<context>
<name>design/standard/gui</name>
   <message> 
       <source>Delete</source>
<translation>Löschen</translation>
   </message> 
</context>
<context>
<name>design/standard/layout</name>
   <message> 
       <source>Sitemap</source>
<translation>Sidemab</translation>
   </message> 
   <message> 
       <source>Welcome to eZ publish administration</source>
<translation>Willkomme in dr eZPublish-Verwaldung</translation>
   </message> 
   <message> 
       <source>To log in enter a valid login and password.</source>
<translation>Um Si oizulogge bidde Loginname und Password angebe.</translation>
   </message> 
   <message> 
       <source>Advanced search</source>
<translation>Erweiderde Suche</translation>
   </message> 
   <message> 
       <source>Search</source>
<translation>Suche</translation>
   </message> 
   <message> 
       <source>Change Password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>Logout</source>
<translation>Beende (Logoud)</translation>
   </message> 
   <message> 
       <source>Redirect</source>
<translation>Umleidung</translation>
   </message> 
   <message> 
       <source>Module load failed</source>
<translation>Modul kann nedd glade werden</translation>
   </message> 
   <message> 
       <source>Undefined module:</source>
<translation>Undefinierds Modul:</translation>
   </message> 
   <message> 
       <source>Printable version</source>
<translation>Druggversion</translation>
   </message> 
   <message> 
       <source>Frontpage</source>
<translation>Schdardseide</translation>
   </message> 
   <message> 
       <source>Personal</source>
<translation>Persönliches</translation>
   </message> 
   <message> 
       <source>Trash</source>
<translation>Abfalleimer</translation>
   </message> 
   <message> 
       <source>%sitetitle front page</source>
<translation>%sidedidle Schdardseide</translation>
   </message> 
   <message> 
       <source>Search %sitetitle</source>
<translation>Suche %sitetitle</translation>
   </message> 
   <message> 
       <source>eZ publish redirection - %url</source>
<translation>eZ publish Umleitung - %url</translation>
   </message> 
   <message> 
       <source>Redirecting to %url</source>
<translation>Umleiten to %url</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
</context>
<context>
<name>design/standard/location</name>
   <message> 
       <source>Removal of locations</source>
<translation>Endferne vo Orden</translation>
   </message> 
   <message> 
       <source>Some of the locations you tried to remove has children, are you really sure you want to remove those locations?
If you do all the children will be removed as well.</source>
<translation>Einig dr Orde, d Sie versuche z endferne hend Kindr. Sind Sie sichr, dess Sie diese Orde lösche wolle?
Falls Sie des mache, werde d Kindr ebenfalls endfernd.</translation>
   </message> 
   <message> 
       <source>Path</source>
<translation>Pfad</translation>
   </message> 
   <message> 
       <source>Count</source>
<translation>Zählen</translation>
   </message> 
   <message> 
       <source>Remove locations</source>
<translation>Orde endfernen</translation>
   </message> 
   <message> 
       <source>Cancel removal</source>
<translation>Endferne abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/menuconfig</name>
   <message> 
       <source>Menu management</source>
<translation>Menu-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Current siteaccess</source>
<translation>Akduells Seide Zugang</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Menu positioning</source>
<translation>Menübosizionierung</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
</context>
<context>
<name>design/standard/navigator</name>
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
   <message> 
       <source>Previous</source>
<translation>Zurügg</translation>
   </message> 
</context>
<context>
<name>design/standard/node</name>
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove %1 from node %2?</source>
<translation>Sind Sie sicher, dass Sie %1 von Knoten %2 entfernen wollen?</translation>
   </message> 
   <message> 
       <source>Note:</source>
<translation>Hinweis:</translation>
   </message> 
   <message> 
       <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
<translation>Die endfernde Knode könne au schbädr zurügggehold werde. Sie finde diese im Abfalleimr.</translation>
   </message> 
   <message> 
       <source>Removing node assignment of %1</source>
<translation>LÃ¶schen Knotenzuweisung von %1</translation>
   </message> 
   <message> 
       <source>Removing this assignment will also remove its %1 children.</source>
<translation>Das Entfernen dieser Zuortnung wird auch seine %1 Kinder entfernen.</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove these items?</source>
<translation>Sind Sie sichr, dess Sie diese Gegenschdänd endferne wolle?</translation>
   </message> 
   <message> 
       <source>%nodename and its %childcount children. %additionalwarning</source>
<translation>%nodenam und soi %childcound Kindr. %addizionalwarning</translation>
   </message> 
   <message> 
       <source>%nodename %additionalwarning</source>
<translation>%nodenam %addizionalwarning</translation>
   </message> 
   <message> 
       <source>Move to trash</source>
<translation>Verschiab in den Pabierkorb</translation>
   </message> 
   <message> 
       <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
<translation>Wenn %trashname ausgewÃ¤hlt ist, werden Sie die entfernten GegenstÃ¤nde spÃ¤ter im Papierkorb finden.</translation>
   </message> 
   <message> 
       <source>Note</source>
<translation>Hinweis</translation>
   </message> 
</context>
<context>
<name>design/standard/node/view</name>
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Update</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Document</source>
<translation>Dokumend</translation>
   </message> 
   <message> 
       <source>Site map</source>
<translation>Inhald</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>User</source>
<translation>Benudzer</translation>
   </message> 
   <message> 
       <source>User group</source>
<translation>Benudzergrubbe</translation>
   </message> 
   <message> 
       <source>Create here</source>
<translation>Hir erschdellen</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Add to Bookmarks</source>
<translation>Als Lesezeile ablegen</translation>
   </message> 
   <message> 
       <source>Notify me about updates</source>
<translation>Benachrichdige übr Ubdads</translation>
   </message> 
   <message> 
       <source>Preview</source>
<translation>Vorschau</translation>
   </message> 
   <message> 
       <source>Select all</source>
<translation>Alle auswählen</translation>
   </message> 
   <message> 
       <source>Deselect all</source>
<translation>Alle abwählen</translation>
   </message> 
   <message> 
       <source>Click to create a custom template</source>
<translation>Kligget Sie hir, um oi eigens Temblade z erschdellen</translation>
   </message> 
   <message> 
       <source>Node ID</source>
<translation>Knode ID</translation>
   </message> 
   <message> 
       <source>Object ID</source>
<translation>Objekd ID</translation>
   </message> 
   <message> 
       <source>Default object view.</source>
<translation>Schdandard Objekdansichd.</translation>
   </message> 
   <message> 
       <source>Missing or invalid input</source>
<translation>Eingab fehld odr konnde nedd validierd werden</translation>
   </message> 
   <message> 
       <source>Placed in</source>
<translation>Pladzierd in</translation>
   </message> 
</context>
<context>
<name>design/standard/notification</name>
   <message> 
       <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
<translation>Wenn Sie nedd weiderhin diese Benachrichdigunge erhalde wolle, änderet Sie Ihre Einschdellunge under:</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Do you want to receive messages combined in digest</source>
<translation>Wollet Sie d Nachrichde in oir Zusammenfassung erhalden</translation>
   </message> 
   <message> 
       <source>Digest settings</source>
<translation>Einschdellunge dr Zusammenfassung</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Receive all messages combined in one digest</source>
<translation>Alle Nachrichde in oir Zusammenfassung erhalden</translation>
   </message> 
   <message> 
       <source>Day of the week</source>
<translation>Wochendag</translation>
   </message> 
   <message> 
       <source>Notification admin</source>
<translation>Benachrichdigungs Admin</translation>
   </message> 
   <message> 
       <source>Time event was spawned</source>
<translation>Ein Ereignis wurd angelegd</translation>
   </message> 
   <message> 
       <source>Run notification filter</source>
<translation>Schdarde Benachrichdigungsfilder</translation>
   </message> 
   <message> 
       <source>Run</source>
<translation>Schdarden</translation>
   </message> 
   <message> 
       <source>Spawn time event</source>
<translation>Anlege von a Ereignisses</translation>
   </message> 
   <message> 
       <source>Spawn</source>
<translation>Anlegen</translation>
   </message> 
   <message> 
       <source>Notification settings</source>
<translation>Benachrichdigungsoischdellungen</translation>
   </message> 
   <message> 
       <source>%sitename notification system</source>
<translation>%sidenam Benachrichdungssyschdem</translation>
   </message> 
   <message> 
       <source>[%sitename] New collaboration item</source>
<translation>[%sitename] Neues Kollaborationselement</translation>
   </message> 
   <message> 
       <source>[%sitename] Digest for %date</source>
<translation>[%sitename] Zusammenfassung fÃ¼r %date</translation>
   </message> 
   <message> 
       <source>&quot;%name&quot; was updated</source>
<translation>&quot;%name&quot; wurde aktuallisiert</translation>
   </message> 
   <message> 
       <source>The item can be viewed by using the URL below.</source>
<translation>Des Elemend kann undr Verwendung dr URL unde bedrachded werden</translation>
   </message> 
   <message> 
       <source>&quot;%name&quot; was published</source>
<translation>&quot;%name&quot; aktualisiert</translation>
   </message> 
   <message> 
       <source>Daily</source>
<translation>Täglich</translation>
   </message> 
   <message> 
       <source>If the day of month number you have chosen is larger than the number of days in the current month, then the last day of the current month will be used instead.</source>
<translation>Wenn dr Tag vom Monads, den Sie ausgewähld hend höhr isch, als d Anzahl dr Tag vom Monads, wird an soir Schdelle dr ledzde Tag vom Monads verwended.</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
<translation>Diese E-Mail informiert Sie darÃ¼ber, dass ein neues Kollaborationselement Ihre Aufmerksamkeit auf %sitename benÃ¶tigt.</translation>
   </message> 
   <message> 
       <source>Time of day</source>
<translation>Tageszeid</translation>
   </message> 
   <message> 
       <source>Weekly, day of week</source>
<translation>Wöchendlich an oim beschdimmde Tag</translation>
   </message> 
   <message> 
       <source>Monthly, day of month</source>
<translation>Wöchendlich an oim beschdimmde Tag</translation>
   </message> 
   <message> 
       <source>This digest e-mail is to inform you on new items at %sitename.</source>
<translation>Diese Ãbersicht informiert Sie Ã¼ber neue Elemente auf der Seite %sitename.</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you on news at %sitename.</source>
<translation>Diese E-Mail informiert Sie Ã¼ber Neuigkeiten auf %sitename.</translation>
   </message> 
   <message> 
       <source>Node notification</source>
<translation>Knodenbenachrichdigung</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you that an updated item has been published at %sitename.</source>
<translation>Diese E-Mail informiert Sie darÃ¼ber, dass etwas auf %sitename aktualisiert wurde.</translation>
   </message> 
   <message> 
       <source>This e-mail is to inform you that a new item has been published at %sitename.</source>
<translation>Diese E-Mail informiert Sie darÃ¼ber, dass etwas Neues auf %sitename verÃ¶ffentlicht wurde.</translation>
   </message> 
   <message> 
       <source>Notification filter processed all available notification events</source>
<translation>Dr Benachrichdigungsfildr hedd alle verfügbare Elemende durchlaufen</translation>
   </message> 
</context>
<context>
<name>design/standard/notification/addingresult</name>
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Add to my notifications</source>
<translation>Zu Benachrichdunge hinzfügen</translation>
   </message> 
   <message> 
       <source>Notification for node &lt;%node_name&gt; already exists.</source>
<translation></translation>
   </message> 
   <message> 
       <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/notification/collaboration</name>
   <message> 
       <source>Collaboration notification</source>
<translation>Kollaborazions- Benachrichdigung</translation>
   </message> 
   <message> 
       <source>Choose which collaboration items you wish to get notifications for.</source>
<translation>Wählet Sie, für wo Kollaborazionelemende Sie Benachrichdigunge bekomme möchde.</translation>
   </message> 
</context>
<context>
<name>design/standard/package</name>
   <message> 
       <source>Packages</source>
<translation>Pakede</translation>
   </message> 
   <message> 
       <source>The following packages are available on this system</source>
<translation>Die folgende Pakede sind auf dem Syschdem verfügbar</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Upload package</source>
<translation>Paked hochladen</translation>
   </message> 
   <message> 
       <source>Select the file containing your package and click the upload button</source>
<translation>Wählet Sie d Dadei aus d Ihr Paked enthäld und kligget Sie auf den Hochladen-Buddon</translation>
   </message> 
   <message> 
       <source>Install package</source>
<translation>Paked inschdallieren</translation>
   </message> 
   <message> 
       <source>Please provide information on the changes.</source>
<translation>Bidde gebet Sie Informazione übr Änderunge.</translation>
   </message> 
   <message> 
       <source>Changes</source>
<translation>Änderungen</translation>
   </message> 
   <message> 
       <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
<translation>Einen Eintrag mit einer Marke ( %emstart-%emend (Strich) oder %emstart*%emend (Sternchen) ) am Anfang der Zeile beginnen.
Die Ãnderung wird fortgesetzt bis zur nÃ¤chsten Ã¤ndernden Marke.</translation>
   </message> 
   <message> 
       <source>Please provide some basic information for your package.</source>
<translation>Bidde gebet Sie oiig Informazione z Ihrem Paked an.</translation>
   </message> 
   <message> 
       <source>Package name</source>
<translation>Pakedname</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Licence</source>
<translation>Lizenz</translation>
   </message> 
   <message> 
       <source>Package host</source>
<translation>Paked Hoschd</translation>
   </message> 
   <message> 
       <source>Packager</source>
<translation>Zusammenschdeller</translation>
   </message> 
   <message> 
       <source>Please provide information on the maintainer of the package.</source>
<translation>Bidde underbreidet Sie dem Maindainr diess Pakeds Informazione.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
<translation>Bidde wählet Sie oi Miniadurbild, dess dem Paked hinzugefügd wird.
Solldet Sie koi Miniadurbild wünsche, kligget Sie auf Weidr.</translation>
   </message> 
   <message> 
       <source>Create package</source>
<translation>Erschdelle Paked</translation>
   </message> 
   <message> 
       <source>Available wizards</source>
<translation>Verfügbare Assischdenden</translation>
   </message> 
   <message> 
       <source>Choose one of the following wizards for creating a package</source>
<translation>Wählet Sie oin dr folgende Assischdende zum Erschdelle von a Pakeds aus</translation>
   </message> 
   <message> 
       <source>Please choose the content classes you wish to be included in the package.</source>
<translation>Bidde wählet Sie d Inhaldsklasse aus, d im Paked enthalde soi solle.</translation>
   </message> 
   <message> 
       <source>Class list</source>
<translation>Klassenlischde</translation>
   </message> 
   <message> 
       <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
<translation>Wählet Sie oi Bilddadei, d dem Paked hinzugefügd werde soll und kligget Sie noh auf Weidr.
Wenn Sie damid ferdich sind, kligget Sie auf Weidr ohne oi Bild z wähle.</translation>
   </message> 
   <message> 
       <source>Currently added image files</source>
<translation>Momendan hinzugefügde Bilddadeien</translation>
   </message> 
   <message> 
       <source>Package wizard: %wizardname</source>
<translation>Paket-Assistent: %wizardname</translation>
   </message> 
   <message> 
       <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
<translation>Des Paked kann auf Ihrem Syschdem inschdallierd werde. Die Inschdallazion wird abhängich vom Paked Dadeie kobiere, Klasse erschdelle, usw.
Falls Sie des Paked im Momend nedd inschdalliere möchde, könnet Sie des au schbädr auf dr Ansichdsseide vom Pakeds mache.</translation>
   </message> 
   <message> 
       <source>Install items</source>
<translation>Elemende Inschdallieren</translation>
   </message> 
   <message> 
       <source>Skip installation</source>
<translation>Inschdallazion überschbringen</translation>
   </message> 
   <message> 
       <source>Removal of packages</source>
<translation>Endferne vo Pakeden</translation>
   </message> 
   <message> 
       <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
<translation>Sind Sie sichr, dess Sie folgend Pakede endferne möchde?
Die Pakede werde dauerhafd glöschd.</translation>
   </message> 
   <message> 
       <source>Confirm removal</source>
<translation>Lösche beschdädigen</translation>
   </message> 
   <message> 
       <source>Keep packages</source>
<translation>Pakede behalden</translation>
   </message> 
   <message> 
       <source>Package removal was cancelled.</source>
<translation>Des Endferne vom Pakeds wurd abgebrole.</translation>
   </message> 
   <message> 
       <source>Selection</source>
<translation>Auswahl</translation>
   </message> 
   <message> 
       <source>Installed</source>
<translation>Inschdallierd</translation>
   </message> 
   <message> 
       <source>Not installed</source>
<translation>Nedd inschdallierd</translation>
   </message> 
   <message> 
       <source>Imported</source>
<translation>Imbordierd</translation>
   </message> 
   <message> 
       <source>Remove package</source>
<translation>Endferne Paked</translation>
   </message> 
   <message> 
       <source>Import package</source>
<translation>Imbordiere Paked</translation>
   </message> 
   <message> 
       <source>Next %arrowright</source>
<translation>Weiter %arrowright</translation>
   </message> 
   <message> 
       <source>Finish</source>
<translation>Beenden</translation>
   </message> 
   <message> 
       <source>Uninstall package</source>
<translation>Doischdalliere Paked</translation>
   </message> 
   <message> 
       <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
<translation>Des Paked kann aus dem Syschdem doischdallierd werde. Die Doischdallazion wird abhängich vom Paked inschdallierde Dadeie, Klasse, usw. endferne.
Falls Sie d Doischdallazion im Momend nedd durchführe wolle, könnet Sie des schbädr auf dr Ansichdsseide vom Pakeds nachhole.
Sie könne des Paked au endferne ohne s vo dr Pakedlischde z endferne.</translation>
   </message> 
   <message> 
       <source>Uninstall items</source>
<translation>Elemende doischdalliere.</translation>
   </message> 
   <message> 
       <source>Skip uninstallation</source>
<translation>Doischdallazion abbrechen</translation>
   </message> 
   <message> 
       <source>Files [%collectionname]</source>
<translation>Dateien [%collectionname]</translation>
   </message> 
   <message> 
       <source>Details</source>
<translation>Dedails</translation>
   </message> 
   <message> 
       <source>Uninstall</source>
<translation>Doischdallieren</translation>
   </message> 
   <message> 
       <source>Install</source>
<translation>Inschdallieren</translation>
   </message> 
   <message> 
       <source>Export to file</source>
<translation>In Dadei exbordieren</translation>
   </message> 
   <message> 
       <source>State</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Maintainers</source>
<translation>Zuschdändige</translation>
   </message> 
   <message> 
       <source>Regarding eZ publish package &apos;%packagename&apos;</source>
<translation>In Bezug auf eZ publish Paket &apos;%packagename&apos;</translation>
   </message> 
   <message> 
       <source>Send E-Mail to the maintainer</source>
<translation>Dem Maindainr oi E-Mail schiggen</translation>
   </message> 
   <message> 
       <source>Documents</source>
<translation>Dokumende</translation>
   </message> 
   <message> 
       <source>Changelog</source>
<translation>Logbuch</translation>
   </message> 
   <message> 
       <source>File list</source>
<translation>Dadei Lischde</translation>
   </message> 
   <message> 
       <source>Please choose objects you wish to include in the package.</source>
<translation>Bidde wählet Sie Objekde aus, d im Paked oigeschlosse werde solle.</translation>
   </message> 
   <message> 
       <source>Selected nodes</source>
<translation>Ausgewählde Knoden</translation>
   </message> 
   <message> 
       <source>Please select the site CSS file to be included in the package.</source>
<translation>Bidde wählet Sie d CSS-Dadei dr Seide aus, des im Paked oigeschlosse werde soll.</translation>
   </message> 
   <message> 
       <source>Please select the classes CSS file to be included in the package.</source>
<translation>Bidde wähle d CSS-Dadei dr Klasse aus, d im Paked oigeschlosse werde soll.</translation>
   </message> 
   <message> 
       <source>Package install wizard: %wizardname</source>
<translation>Asistent zum Installieren von Paketen: %wizardname</translation>
   </message> 
   <message> 
       <source>You must now choose which siteaccess the package contents should be installed to.
The chosen siteaccess determines where design files and settings are written to.
If unsure choose the siteaccess which reflects the user part of your site, i.e. not admin.</source>
<translation>Sie müsse nun auswähle, in wo Seide Zugang d Inhalde vom Pakeds inschdallierd werde soll.
Dr gwählde Seide Zugang sedzd fesch, wohin Designdadeie und Einschdellunge gschriabe werde solle.
Falls Sie unsichr sind, wählet Sie oin, dr den Benudzerbereich Ihrr Seide widerschbiegeld - also z.B. nedd &quot;admin&quot;</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Please select where you want to place the imported items.</source>
<translation>Bidde wählet Sie aus, wo d imbordierde Elemende bladzierd werde solle.</translation>
   </message> 
   <message> 
       <source>If you wish to change the placement click the browse button.</source>
<translation>Falls Sie d Pladzierung änderet wolle, kligget Sie auf den Knobf zum Durchsuche.</translation>
   </message> 
   <message> 
       <source>Place %object_name in node %node_placement</source>
<translation>%object_name auf Knoten %node_placement platzieren</translation>
   </message> 
   <message> 
       <source>Choose placement for %object_name</source>
<translation>Platzierung fÃ¼r %object_name auswÃ¤hlen</translation>
   </message> 
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Change repository</source>
<translation>Ablag ändern</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>Export type</source>
<translation>Ard vom Exbords</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Add subtree</source>
<translation>Teil dr Baumschdrukdur hinzfügen</translation>
   </message> 
   <message> 
       <source>Add node</source>
<translation>Knode hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Map %siteaccess_name to</source>
<translation>Bilde %siteaccess_name ab auf</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Repositories</source>
<translation>Ablagen</translation>
   </message> 
   <message> 
       <source>Send e-mail to the maintainer</source>
<translation>Dem Maindainr oi E-Mail schiggen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/package/creators/ezcontentobject</name>
   <message> 
       <source>Please choose the node(s) you wish to export.</source>
<translation>Bidde wählet Sie oin odr mehrere Knode für den Exbord aus.</translation>
   </message> 
   <message> 
       <source>Please choose the subtree(s) you wish to export.</source>
<translation>Bidde wählet Sie oin odr mehrere Teile dr Baumschdrukdur für den Exbord aus.</translation>
   </message> 
   <message> 
       <source>Choose node for export</source>
<translation>Bidde wählet Sie oin Knode für den Exbord aus</translation>
   </message> 
   <message> 
       <source>Choose subtree for export</source>
<translation>Bidde wählet Sie oin Teil dr Baumschdrukdur für den Exbord aus.</translation>
   </message> 
   <message> 
       <source>Specify export properties. Default settings will most likely be suitable for your needs.</source>
<translation>Definieret Sie d Exbordoischdellunge. Die Voroischdellunge dürfde Ihre Bedürfnisse abdegge.</translation>
   </message> 
   <message> 
       <source>Miscellaneous</source>
<translation>Verschiedenes</translation>
   </message> 
   <message> 
       <source>Include class definitions.</source>
<translation>Klassendefinizione oischließe.</translation>
   </message> 
   <message> 
       <source>Include templates related exported objects.</source>
<translation>Temblads verknübfd mid exbordierde Objekde oischließe.</translation>
   </message> 
   <message> 
       <source>Select templates from the following siteaccesses</source>
<translation>Temblads vo folgendem Seide Zugang verwenden</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>Published version</source>
<translation>Veröffendlichde Version</translation>
   </message> 
   <message> 
       <source>All versions</source>
<translation>Alle Versionen</translation>
   </message> 
   <message> 
       <source>Languages</source>
<translation>Schbrachen</translation>
   </message> 
   <message> 
       <source>Select languages to export</source>
<translation>Zu exbordierend Schbrache auswählen</translation>
   </message> 
   <message> 
       <source>Node assignments</source>
<translation>Knode Zuordnungen</translation>
   </message> 
   <message> 
       <source>Keep all in selected nodes</source>
<translation>Alls in ausgewählde Knode behalden</translation>
   </message> 
   <message> 
       <source>Main only</source>
<translation>Nur Haubd</translation>
   </message> 
   <message> 
       <source>Related objects</source>
<translation>Verwandde Objekde</translation>
   </message> 
   <message> 
       <source>None</source>
<translation>Koi</translation>
   </message> 
</context>
<context>
<name>design/standard/package/installers/ezcontentobject</name>
   <message> 
       <source>Choose parent node</source>
<translation>Eldernknode wählen</translation>
   </message> 
   <message> 
       <source>Select parent node for new node.</source>
<translation>Eldernknode als neie Knode wähle.</translation>
   </message> 
</context>
<context>
<name>design/standard/pagelayout</name>
   <message> 
       <source>All caches</source>
<translation>Gesamdr Cache</translation>
   </message> 
   <message> 
       <source>Content</source>
<translation>Inhald</translation>
   </message> 
   <message> 
       <source>Content - node</source>
<translation>Inhald - Knoden</translation>
   </message> 
   <message> 
       <source>Content - subtree</source>
<translation>Inhald - Teil dr Baumschdrukdur</translation>
   </message> 
   <message> 
       <source>Template</source>
<translation>Temblade</translation>
   </message> 
   <message> 
       <source>Template &amp; content</source>
<translation>Temblade &amp; Inhald</translation>
   </message> 
   <message> 
       <source>Ini settings</source>
<translation>Ini Einschdellungen</translation>
   </message> 
   <message> 
       <source>Static</source>
<translation>Schdadisch</translation>
   </message> 
   <message> 
       <source>Clear</source>
<translation>Leeren</translation>
   </message> 
</context>
<context>
<name>design/standard/pdf/list</name>
   <message> 
       <source>PDF Exports</source>
<translation>PDF Exborde</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Creator</source>
<translation>Erschdeller</translation>
   </message> 
   <message> 
       <source>Created</source>
<translation>Erschdelld</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>New Export</source>
<translation>Neir Exbord</translation>
   </message> 
</context>
<context>
<name>design/standard/reference/ez</name>
   <message> 
       <source>No generated documentation found</source>
<translation>Koi generierde Dokumendazion funden</translation>
   </message> 
   <message> 
       <source>To create the reference documentation you must do the following step</source>
<translation>Um d Referenz Dokumendazion z erschdelle, führet Sie folgende Schridd aus</translation>
   </message> 
   <message> 
       <source>Download and install doxygen</source>
<translation>Heraalade und inschdalliere vo Doxygen</translation>
   </message> 
   <message> 
       <source>Generate the documentation by running the following command</source>
<translation>Generiere dr Dokumendazion durch des ausführe vom folgende Kommandos</translation>
   </message> 
   <message> 
       <source>Download doxygen from %doxygenurl.</source>
<translation>Download doxygen von der %doxygenurl.</translation>
   </message> 
   <message> 
       <source>Main</source>
<translation>Main</translation>
   </message> 
   <message> 
       <source>Modules</source>
<translation>Module</translation>
   </message> 
   <message> 
       <source>Class hierarchy</source>
<translation>Klasse Hierarchie</translation>
   </message> 
   <message> 
       <source>Compound list</source>
<translation>Kombonendenlischde</translation>
   </message> 
   <message> 
       <source>File list</source>
<translation>Dadei Lischde</translation>
   </message> 
   <message> 
       <source>Compound members</source>
<translation>Kombonende Midglieder</translation>
   </message> 
   <message> 
       <source>File members</source>
<translation>Dadei Midglieder</translation>
   </message> 
   <message> 
       <source>Related pages</source>
<translation>Verwandde Seiden</translation>
   </message> 
   <message> 
       <source>Introduction</source>
<translation>Einführung</translation>
   </message> 
   <message> 
       <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
<translation>Die Referenz Dokumendazion für eZ bublish beschdehd aus verschiedene Sekzione d jed für si oi andere Sichd auf d Dokumendazion hend. Die Sekzione könnet Sie übr des Menü obe erreile.</translation>
   </message> 
   <message> 
       <source>The documentation will give an overview of the API of eZ publish.</source>
<translation>Die Dokumendazion gibd oin Überbligg übr d API vo eZ bublish.</translation>
   </message> 
   <message> 
       <source>All reference documentation has been made with %doxygenurl</source>
<translation>Die Referenz Dokumentation wurde mit %doxygenurl gemacht</translation>
   </message> 
</context>
<context>
<name>design/standard/role</name>
   <message> 
       <source>Create policy for</source>
<translation>Erzeig Richdlinie für</translation>
   </message> 
   <message> 
       <source>Step 1</source>
<translation>Schridd 1</translation>
   </message> 
   <message> 
       <source>Every module</source>
<translation>Alle Module</translation>
   </message> 
   <message> 
       <source>Allow all</source>
<translation>Alle erlauben</translation>
   </message> 
   <message> 
       <source>Allow limited</source>
<translation>Erlaub oigeschränkd</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Limited</source>
<translation>Beschränkd</translation>
   </message> 
   <message> 
       <source>Go back to step 1</source>
<translation>Zurügg z Schridd 1</translation>
   </message> 
   <message> 
       <source>You are not able to give access to limited functions of module</source>
<translation>Sie könne koin Zugriff auf beschränkde Modulfunkzione vom Moduls freigeben</translation>
   </message> 
   <message> 
       <source>because function list for it is not defined.</source>
<translation>da d Funkzionenlischde hierfür nedd definierd isch.</translation>
   </message> 
   <message> 
       <source>Step 2</source>
<translation>Schridd 2</translation>
   </message> 
   <message> 
       <source>Specify function in module</source>
<translation>Schbezifiziere Funkzione in Modul</translation>
   </message> 
   <message> 
       <source>Go back to step 2</source>
<translation>Zurügg z Schridd 2</translation>
   </message> 
   <message> 
       <source>Step 3</source>
<translation>Schridd 3</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Ok</source>
<translation>Ok</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Role list</source>
<translation>Rollen-Lischde</translation>
   </message> 
   <message> 
       <source>Role view</source>
<translation>Rollensichd</translation>
   </message> 
   <message> 
       <source>Role policies</source>
<translation>Rollen-Richdlinien</translation>
   </message> 
   <message> 
       <source>Users and groups assigned to this role</source>
<translation>Benudzr und Grubbe mid von dene Rolle verknübfd</translation>
   </message> 
   <message> 
       <source>Assign</source>
<translation>Verknübfen</translation>
   </message> 
   <message> 
       <source>Give access to module</source>
<translation>Zugang zum Modul geben</translation>
   </message> 
   <message> 
       <source>Module</source>
<translation>Modul</translation>
   </message> 
   <message> 
       <source>Access</source>
<translation>Zugang</translation>
   </message> 
   <message> 
       <source>Function</source>
<translation>Funkzion</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Current policies</source>
<translation>Akduelle Richdlinien</translation>
   </message> 
   <message> 
       <source>Limitations</source>
<translation>Limidierungen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Discard changes</source>
<translation>Änderunge verwerfen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Limitation</source>
<translation>Limidierung</translation>
   </message> 
   <message> 
       <source>User</source>
<translation>Benudzer</translation>
   </message> 
   <message> 
       <source>Role edit %1</source>
<translation>Rolle &quot;%1&quot; editieren</translation>
   </message> 
   <message> 
       <source>Edit policy</source>
<translation>Edidiere Richdlinie</translation>
   </message> 
   <message> 
       <source>Policy</source>
<translation>Richdlinie</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>Not specified.</source>
<translation>Nedd schbezifizierd.</translation>
   </message> 
   <message> 
       <source>Subtree</source>
<translation>Teile dr Baumschdrukdur</translation>
   </message> 
   <message> 
       <source>Update</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>Role</source>
<translation>Rolle</translation>
   </message> 
   <message> 
       <source>Find</source>
<translation>Finden</translation>
   </message> 
   <message> 
       <source>Remove selected policies</source>
<translation>Lösche ausgewählde Richdlinien</translation>
   </message> 
   <message> 
       <source>Edit role</source>
<translation>Edidiere Rollen</translation>
   </message> 
   <message> 
       <source>Assign role to user or group</source>
<translation>Weise Rolle oim Usr odr oir Grubb zu</translation>
   </message> 
   <message> 
       <source>Remove selected roles</source>
<translation>Endferne selekdierde Rollen</translation>
   </message> 
   <message> 
       <source>Edit current role</source>
<translation>Ändere akduelle Rolle</translation>
   </message> 
   <message> 
       <source>Remove selected assignments</source>
<translation>Endferne selekdierde Zuweisungen</translation>
   </message> 
   <message> 
       <source>Specify limitations for function %functionname in module %modulename. &apos;Any&apos; means no limitation by this parameter</source>
<translation>Spezifizieren Sie Limitierungen fÃ¼r die Funktion %functionname in Modul %modulename. &apos;Alle&apos; heiÃt, dass keine Limitierung gesetzt wird</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Assign role to user or group to subtree</source>
<translation>Rolle z Benudzr odr Grubb zum Teil dr Baumschdrukdur zuordnen</translation>
   </message> 
   <message> 
       <source>Assign limited</source>
<translation>Eingeschränkd zuordnen</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>Copy role</source>
<translation>Rolle kobieren</translation>
   </message> 
</context>
<context>
<name>design/standard/rss</name>
   <message> 
       <source>Choose export node</source>
<translation>Wählet Sie den z exbordierende Knoden</translation>
   </message> 
   <message> 
       <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Von wo soll exportiert werden?
WÃ¤hlen Sie die Knoten aus und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>Choose import destination</source>
<translation>Wählet Sie den Zielknode für den Imbord</translation>
   </message> 
   <message> 
       <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>Wo sollten die importierten Nachrichten gespeichert werden?
WÃ¤hlen Sie die Knoten aus und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose RSS image</source>
<translation>Wählet Sie des RSS Bild</translation>
   </message> 
   <message> 
       <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie das Bild aus, das beim RSS Export genutzt werden soll.
WÃ¤hlen Sie die Knoten aus und klicken Sie dann auf &quot;%buttonname&quot;. Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>Choose export source</source>
<translation>Wählet Sie d Exbord-Quelle aus</translation>
   </message> 
   <message> 
       <source>Choose owner of imported objects</source>
<translation>Wähet Sie den Besidzr dr imbordierde Objekde</translation>
   </message> 
   <message> 
       <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie den Besitzer der Objekte, die importiert werden und und klicken Sie dann auf &quot;%buttonname&quot;. 
Wenn Sie auf den Namen klicken, kÃ¶nnen Sie navigieren. Sie kÃ¶nnen zur Auswahl oder zur Navigation auch Ihre Lesezeichen oder Aktuelle Elemente verwenden.</translation>
   </message> 
   <message> 
       <source>RSS export is locked</source>
<translation>Dr RSS Exbord isch gschberrd</translation>
   </message> 
   <message> 
       <source>The RSS export %name is currently locked by %user and was last modified on %datetime.</source>
<translation>Der RSS Export %name ist momentan von Benutzer %user gesperrt und wurde zuletzt geÃ¤ndert am %datetime.</translation>
   </message> 
   <message> 
       <source>The RSS export will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
<translation>Der RSS Export wird wieder zum Bearbeiten zur VerfÃ¼gung stehen, wenn der Bearbeiter seine Ãnderungen speichert oder wenn er automatisch am %datetime entsperrt wird.</translation>
   </message> 
   <message> 
       <source>Retry</source>
<translation>Wiederholen</translation>
   </message> 
   <message> 
       <source>RSS import is locked</source>
<translation>Dr RSS Imbord isch gschberrd.</translation>
   </message> 
   <message> 
       <source>The RSS import %name is currently locked by %user and was last modified on %datetime.</source>
<translation>Der RSS Import %name ist momentan von Benutzer %user gesperrt und wurde zuletzt geÃ¤ndert am %datetime.</translation>
   </message> 
   <message> 
       <source>The RSS import will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
<translation>Der RSS Import wird wieder zum Bearbeiten zur VerfÃ¼gung stehen, wenn der Bearbeiter seine Ãnderungen speichert oder wenn er automatisch am %datetime entsperrt wird.</translation>
   </message> 
</context>
<context>
<name>design/standard/rss/edit</name>
   <message> 
       <source>Display frontpage</source>
<translation>Zeig Schdardseide</translation>
   </message> 
   <message> 
       <source>RSS Export</source>
<translation>RSS Exbord</translation>
   </message> 
   <message> 
       <source>Title</source>
<translation>Tidel</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Site URL</source>
<translation>URL dr Webside</translation>
   </message> 
   <message> 
       <source>Image</source>
<translation>Bild</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>Site Access</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>RSS version</source>
<translation>RSS Version</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Access URL</source>
<translation>URL vom erzeigde RSS-Feeds</translation>
   </message> 
   <message> 
       <source>Source path</source>
<translation>Quell-Pfad</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Update</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Add Source</source>
<translation>Quelle hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>RSS Import</source>
<translation>RSS Imbord</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Destination path</source>
<translation>Zielbfad</translation>
   </message> 
   <message> 
       <source>Imported objects owner</source>
<translation>Besidzr dr imbordierde Objekde</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>Ignore</source>
<translation>Ignorieren</translation>
   </message> 
   <message> 
       <source>Remove Source</source>
<translation>Quelle endfernen</translation>
   </message> 
   <message> 
       <source>PDF Export</source>
<translation>PDF Exbord</translation>
   </message> 
   <message> 
       <source>Intro text</source>
<translation>Einführungschdexd</translation>
   </message> 
   <message> 
       <source>Sub text</source>
<translation>Weiderführendr Texd</translation>
   </message> 
   <message> 
       <source>Source node</source>
<translation>Quell Knoden</translation>
   </message> 
   <message> 
       <source>Export structure</source>
<translation>Zu exbordierend Schdrukdur</translation>
   </message> 
   <message> 
       <source>Tree</source>
<translation>Baum</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>Export classes</source>
<translation>Zu exbordierend Klassen</translation>
   </message> 
   <message> 
       <source>Site access</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Export destination</source>
<translation>Exbordziel</translation>
   </message> 
   <message> 
       <source>Export to URL</source>
<translation>Exbordiere no URL</translation>
   </message> 
   <message> 
       <source>Export for direct download</source>
<translation>Exbordiere zum direkde Heraaladen</translation>
   </message> 
   <message> 
       <source>Export</source>
<translation>Exbord</translation>
   </message> 
   <message> 
       <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
<translation>Benudzet Sie diess Feld um d Basis-URL Ihrr Seide anzugebe. Sie wird benudzd um d URL für den Exbord z generiere. Diese wird si aus dr URL dr Seide (z.B. &quot;hddb://www.examble.com/index.fb&quot;) un dem Pfad zum Objekd (z.B. &quot;/ardicles/my_ardicle&quot;)) zsammensedze. Die URL dr Seide hängd vo Ihrem Webservr und dr eZ bublish Konfigurazion ab.</translation>
   </message> 
   <message> 
       <source>Number of objects</source>
<translation>Anzahl dr Objekde</translation>
   </message> 
   <message> 
       <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
<translation>Benudzet Sie diess Auswahlmenü um d maximale Anzahl dr Objekde, d in dr RSS-Einschbeisung oigeschlosse werde, auszwähle.</translation>
   </message> 
   <message> 
       <source>Main node only</source>
<translation>Nur Haubdknoden</translation>
   </message> 
   <message> 
       <source>Check if you want to only feed the object from the main node.</source>
<translation>Wählet Sie des aus, falls des Objekd nur vom Haubdknode oischbeiße soll.</translation>
   </message> 
   <message> 
       <source>Subnodes</source>
<translation>Underknoden</translation>
   </message> 
   <message> 
       <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
<translation>Akdivieret Sie dis, falls au Objekde vo Underknode dr Quelle oigeschbeißd werde solle.</translation>
   </message> 
</context>
<context>
<name>design/standard/rss/list</name>
   <message> 
       <source>RSS Feeds</source>
<translation>RSS Nachrichdenkanäle</translation>
   </message> 
   <message> 
       <source>RSS Exports</source>
<translation>RSS Exborde</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Veränderd von</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Veränderd</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>New Export</source>
<translation>Neir Exbord</translation>
   </message> 
   <message> 
       <source>RSS Imports</source>
<translation>RSS Imborde</translation>
   </message> 
   <message> 
       <source>New Import</source>
<translation>Neir Imbord</translation>
   </message> 
</context>
<context>
<name>design/standard/search</name>
   <message> 
       <source>Search statistics</source>
<translation>Suchschdadischdiken</translation>
   </message> 
   <message> 
       <source>Most frequent search phrases</source>
<translation>Häufigschde Suchausdrügge</translation>
   </message> 
   <message> 
       <source>Phrase</source>
<translation>Ausdrugg</translation>
   </message> 
   <message> 
       <source>Number of phrases</source>
<translation>Anzahl dr Ausdrügge</translation>
   </message> 
   <message> 
       <source>Average result returned</source>
<translation>Durchschniddlichs Ergebnis</translation>
   </message> 
   <message> 
       <source>Reset statistics</source>
<translation>Schdadischdisk zurüggsedzen</translation>
   </message> 
</context>
<context>
<name>design/standard/section</name>
   <message> 
       <source>Assign section to node</source>
<translation>Sekzion mid Knode verknübfen</translation>
   </message> 
   <message> 
       <source>Section edit</source>
<translation>Sekzion bearbeiden</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Section list</source>
<translation>Sekzionen-Lischde</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove these sections?</source>
<translation>Sind Sie sichr, dess Sie diese Sekzione endferne wolle?</translation>
   </message> 
   <message> 
       <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
<translation>Des Endferne von dene Sekzione kann Rechde, Seidendesign und andere Sache vom Syschdems zerschdöre. Machet Sie nix solang Sie nedd genau wisse, was Sie dun.</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Navigation Part</source>
<translation>Navigazionschdeil</translation>
   </message> 
   <message> 
       <source>About Navigation Parts</source>
<translation>Übr Navigazionschdeile</translation>
   </message> 
   <message> 
       <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
<translation>Die eZ bublish Adminischdrazions Oberfläche isch in Navigazionschdeile underdeild. Auf diese Weise kann man verschiedene Bereiche dr Webside-Adminischdrazion grubbiere. Wählet Sie den Navigazionschdeil, dr akdiv soi sollde, wenn diese Sekzion aufgerufe wird.</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Assign</source>
<translation>Verknübfen</translation>
   </message> 
   <message> 
       <source>Assign section - %section</source>
<translation>Sektion zuweisen - %section</translation>
   </message> 
   <message> 
       <source>Remove selected sections</source>
<translation>Lösche dr ausgewählde Sekzionen</translation>
   </message> 
   <message> 
       <source>Choose section assignment</source>
<translation>Wähle dr Sekzions Zugehörigkeid</translation>
   </message> 
   <message> 
       <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>WÃ¤hlen Sie, ab wo die Sektion %sectionname zugewiesen werden soll.

   Markieren Sie die Orte und klicken Sie dann auf &quot;%buttonname&quot;
   Sie kÃ¶nnen auch die Elemente aus der Historie oder Ihre Lesezeichen verwenden.
   Wenn Sie auf die Namen klicken, kÃ¶nnen Sie navigieren.</translation>
   </message> 
</context>
<context>
<name>design/standard/setup</name>
   <message> 
       <source>Cache admin</source>
<translation>Cache Admin</translation>
   </message> 
   <message> 
       <source>Content view cache was cleared.</source>
<translation>Dr Ansichdscache wurd gleerd.</translation>
   </message> 
   <message> 
       <source>Ini file cache was cleared.</source>
<translation>Dr Ini-Dadeiencache wurd gleerd.</translation>
   </message> 
   <message> 
       <source>Template cache was cleared.</source>
<translation>Dr Tembladecache wurd gleerd.</translation>
   </message> 
   <message> 
       <source>View cache is enabled.</source>
<translation>Dr Ansichdscache isch an.</translation>
   </message> 
   <message> 
       <source>View cache is disabled.</source>
<translation>Dr Ansichdscache isch aus.</translation>
   </message> 
   <message> 
       <source>Clear</source>
<translation>Leeren</translation>
   </message> 
   <message> 
       <source>Ini cache</source>
<translation>Ini Cache</translation>
   </message> 
   <message> 
       <source>Ini cache is always enabled.</source>
<translation>Dr Ini Cache isch immr an.</translation>
   </message> 
   <message> 
       <source>Template cache</source>
<translation>Temblade Cache</translation>
   </message> 
   <message> 
       <source>System information</source>
<translation>Syschdeminformazionen</translation>
   </message> 
   <message> 
       <source>Safe mode is on.</source>
<translation>Saf Mod isch an.</translation>
   </message> 
   <message> 
       <source>Safe mode is off.</source>
<translation>Saf Mod isch aus.</translation>
   </message> 
   <message> 
       <source>Basedir restriction is on and set to %1.</source>
<translation>Basedir Restriction ist an und auf %1 gesetzt.</translation>
   </message> 
   <message> 
       <source>Basedir restriction is off.</source>
<translation>Basedir Reschdriczion isch aus.</translation>
   </message> 
   <message> 
       <source>Global variable registration is on.</source>
<translation>Global Variable Regischdrazion isch an.</translation>
   </message> 
   <message> 
       <source>Global variable registration is off.</source>
<translation>Global Variable Regischdrazion isch aus.</translation>
   </message> 
   <message> 
       <source>File uploading is enabled.</source>
<translation>Dadei Ubload isch an.</translation>
   </message> 
   <message> 
       <source>File uploading is disabled.</source>
<translation>Dadei Ubload isch aus.</translation>
   </message> 
   <message> 
       <source>Maximum size of post data (text and files) is %1.</source>
<translation>Maximale GrÃ¶Ãe der gesendeten Daten (Text und Dateien) ist %1.</translation>
   </message> 
   <message> 
       <source>Script memory limit is %1.</source>
<translation>Script Memory Limit ist %1.</translation>
   </message> 
   <message> 
       <source>Maximum execution time is %1 seconds.</source>
<translation>Maximum Execution Time ist %1 Sekunden.</translation>
   </message> 
   <message> 
       <source>Database</source>
<translation>Dadenbank</translation>
   </message> 
   <message> 
       <source>Rapid Application Development Tools</source>
<translation>Werkzeig zur schnelle Anwendungs-Endwigglung</translation>
   </message> 
   <message> 
       <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
<translation>Die RAD Werkzeig erlaube Ihne, oifach neie Funkzionalidäd für eZ bublish z erschdelle.</translation>
   </message> 
   <message> 
       <source>Template operator wizard</source>
<translation>Temblade-Oberadoren-Assischdend</translation>
   </message> 
   <message> 
       <source>Create new template override for</source>
<translation>Neis Temblade erschdelle für</translation>
   </message> 
   <message> 
       <source>Could not create template, permission denied.</source>
<translation>Konnde koi Temblade erschdelle,  Zugriff verweigerd.</translation>
   </message> 
   <message> 
       <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
<translation>Ungüldigr nam. Sie könne nur d Buchschdabe a-z, Nummeret und _ benudze.</translation>
   </message> 
   <message> 
       <source>Template will be placed in</source>
<translation>Des Temblade wird bladzierd in</translation>
   </message> 
   <message> 
       <source>Template name</source>
<translation>Tembladename</translation>
   </message> 
   <message> 
       <source>Override keys</source>
<translation>Überschreibungsschlüssel</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Node</source>
<translation>Knoden</translation>
   </message> 
   <message> 
       <source>Base template on</source>
<translation>Temblade-Grundlage</translation>
   </message> 
   <message> 
       <source>Empty file</source>
<translation>Leere Dadei</translation>
   </message> 
   <message> 
       <source>Copy of default template</source>
<translation>Kobie vom Schdandard-Temblades</translation>
   </message> 
   <message> 
       <source>Container ( with children )</source>
<translation>Condainr ( mid Kinderet )</translation>
   </message> 
   <message> 
       <source>View ( without children )</source>
<translation>Sichd ( ohne Kindr )</translation>
   </message> 
   <message> 
       <source>Object</source>
<translation>Objekd</translation>
   </message> 
   <message> 
       <source>Template list</source>
<translation>Temblade Lischde</translation>
   </message> 
   <message> 
       <source>Most common templates</source>
<translation>Die gebräuchlichschde Temblades</translation>
   </message> 
   <message> 
       <source>Template</source>
<translation>Temblade</translation>
   </message> 
   <message> 
       <source>Design Resource</source>
<translation>Design-Ressource</translation>
   </message> 
   <message> 
       <source>Complete template list</source>
<translation>Kombledde Tembladelischde</translation>
   </message> 
   <message> 
       <source>Basic information</source>
<translation>Basisinformazion</translation>
   </message> 
   <message> 
       <source>Optional information</source>
<translation>Obzionale informazion</translation>
   </message> 
   <message> 
       <source>Template view</source>
<translation>Temblade Sichd</translation>
   </message> 
   <message> 
       <source>Default template resource</source>
<translation>Schdandard-Temblade-Ressource</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Override</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Match conditions</source>
<translation>Bedingungen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Create new</source>
<translation>Nei erzeigen</translation>
   </message> 
   <message> 
       <source>Datatype wizard</source>
<translation>Dadendyb-Assischdend</translation>
   </message> 
   <message> 
       <source>Extension setup</source>
<translation>Erweiderungs-Sedub</translation>
   </message> 
   <message> 
       <source>Available extensions</source>
<translation>Verfügbare Erweiderungen</translation>
   </message> 
   <message> 
       <source>There is no known PHP accelerator active.</source>
<translation>Es isch koi bekanndr PHP-Beschleinigr akdiv.</translation>
   </message> 
   <message> 
       <source>&amp;percent% completed</source>
<translation>&amp;percent% komplett</translation>
   </message> 
   <message> 
       <source>Help</source>
<translation>Hilfe</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Start</source>
<translation>Schdard</translation>
   </message> 
   <message> 
       <source>Name of datatype</source>
<translation>Nam vom Dadendybs</translation>
   </message> 
   <message> 
       <source>Descriptive name of datatype</source>
<translation>Beschreibendr Nam vom Dadendybs</translation>
   </message> 
   <message> 
       <source>Settings</source>
<translation>Einschdellungen</translation>
   </message> 
   <message> 
       <source>Handle input on class level</source>
<translation>Eingab auf Klassen-Ebene bearbeiden</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Nächschder</translation>
   </message> 
   <message> 
       <source>Restart</source>
<translation>Neischdard</translation>
   </message> 
   <message> 
       <source>Name of class</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>Constant name</source>
<translation>Konschdanden-Name</translation>
   </message> 
   <message> 
       <source>The creator of the datatype</source>
<translation>Dr Erschdellr vom Dadendybs</translation>
   </message> 
   <message> 
       <source>Description of your datatype</source>
<translation>Beschreibung Ihrs Dadendybs</translation>
   </message> 
   <message> 
       <source>The first line will be used as the brief description and the rest are operator documentation.</source>
<translation>Die erschde Zeile wird als kurze Beschreibung und dr Resch als Dokuemndazion vom Oberadore benudzd werde.</translation>
   </message> 
   <message> 
       <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
<translation>Handles the datatype %datatypename
By using %datatypename you can ...</translation>
   </message> 
   <message> 
       <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
<translation>Sobald dr Knobf zum Heraalade angekliggd wurd, wird dr Cod erschdelld und Ihr Browsr wird Sie frage, wo r d erschdellde Dadei schbeicheret soll.</translation>
   </message> 
   <message> 
       <source>Download</source>
<translation>Download</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>SVN revision</source>
<translation>SVN Revision</translation>
   </message> 
   <message> 
       <source>Extensions</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Extensions</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Charset</source>
<translation>Zeichensadz</translation>
   </message> 
   <message> 
       <source>Tools</source>
<translation>Werkzeige</translation>
   </message> 
   <message> 
       <source>Start</source>
<translation>Schdard</translation>
   </message> 
   <message> 
       <source>Name of operator</source>
<translation>Nam vom Oberadors</translation>
   </message> 
   <message> 
       <source>Settings</source>
<translation>Einschdellungen</translation>
   </message> 
   <message> 
       <source>One operator in class</source>
<translation>Ein Oberador in Klasse</translation>
   </message> 
   <message> 
       <source>Handles operator input</source>
<translation>Handhabd Eingabe vom Oberadoren</translation>
   </message> 
   <message> 
       <source>Generates operator output</source>
<translation>Generierd Ausgabe vom Oberadoren</translation>
   </message> 
   <message> 
       <source>Parameter handling</source>
<translation>Paramedr Handhabung</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Nächschder</translation>
   </message> 
   <message> 
       <source>Restart</source>
<translation>Neischdard</translation>
   </message> 
   <message> 
       <source>Name of class</source>
<translation>Klassenname</translation>
   </message> 
   <message> 
       <source>The creator of the operator</source>
<translation>Dr Erschdellr vom Oberadoren</translation>
   </message> 
   <message> 
       <source>Description of your operator</source>
<translation>Beschreibung vom Oberadoren</translation>
   </message> 
   <message> 
       <source>The first line will be used as the brief description and the rest are operator documentation.</source>
<translation>Die erschde Zeile wird als kurze Beschreibung und dr Resch als Dokuemndazion vom Oberadore benudzd werde.</translation>
   </message> 
   <message> 
       <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
<translation>Handles template operator %operatorname
By using %operatorname you can ...</translation>
   </message> 
   <message> 
       <source>Example code</source>
<translation>Beischbielcode</translation>
   </message> 
   <message> 
       <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
<translation>Falls Sie s wünsche, könnet Sie weidere Beischbielcod oifüge, dr erklärd, wie dr Oberador funkzionieret soll.
Dr Vorgabecod wurd aus den grundlegene Paramederet, d Sie ausgewähld hend erschdelld.</translation>
   </message> 
   <message> 
       <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
<translation>Sobald dr Knobf zum Heraalade angekliggd wurd, wird dr Cod erschdelld und Ihr Browsr wird Sie frage, wo r d erschdellde Dadei schbeicheret soll.</translation>
   </message> 
   <message> 
       <source>Download</source>
<translation>Heraaladen</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Could not detect version</source>
<translation>Versio konnde nedd erkannd werden</translation>
   </message> 
   <message> 
       <source>The PHP Accelerator is enabled.</source>
<translation>Dr PHP-Beschleinigr isch akdiv.</translation>
   </message> 
   <message> 
       <source>The PHP Accelerator is disabled.</source>
<translation>Dr PHP-Beschleinigr isch nedd akdiv.</translation>
   </message> 
   <message> 
       <source>Server</source>
<translation>Server</translation>
   </message> 
   <message> 
       <source>Socket path</source>
<translation>Sogged Pfad</translation>
   </message> 
   <message> 
       <source>Database</source>
<translation>Dadabase</translation>
   </message> 
   <message> 
       <source>Connection retry count</source>
<translation>Zahl dr Neiversuche oi Verbindung zur Dadenbank herzschdellen</translation>
   </message> 
   <message> 
       <source>Internal</source>
<translation>Indern</translation>
   </message> 
   <message> 
       <source>Current read-only database (Slave)</source>
<translation>Akduelle ausschließlich lesbare Dadenbank (Slave)</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>Update</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>All caches were cleared.</source>
<translation>Dr gsamde Cache wurd gleerd.</translation>
   </message> 
   <message> 
       <source>%name was cleared.</source>
<translation>%nam wurd gleerd.</translation>
   </message> 
   <message> 
       <source>Cache collections</source>
<translation>Cache-Zusammenschdellungen</translation>
   </message> 
   <message> 
       <source>Click a button to clear a collection of caches.</source>
<translation>Kligget Sie auf oin Knobf, um oi Zusammenschdellung von a Cachs z lösche.</translation>
   </message> 
   <message> 
       <source>All caches.</source>
<translation>Gesamdr Cache.</translation>
   </message> 
   <message> 
       <source>All caches</source>
<translation>Gesamdr Cache</translation>
   </message> 
   <message> 
       <source>All caches are disabled</source>
<translation>Dr gsamde Cache isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Content views and template blocks.</source>
<translation>Inhaldsansichde und Tembladeblögge</translation>
   </message> 
   <message> 
       <source>Content caches</source>
<translation>Cache dr Inhalde</translation>
   </message> 
   <message> 
       <source>Content caches is disabled</source>
<translation>Cache dr Inhalde isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Template overrides and template compiling.</source>
<translation>Überschreib-Temblads und kombilierde Temblads.</translation>
   </message> 
   <message> 
       <source>Template caches</source>
<translation>Temblade-Cache</translation>
   </message> 
   <message> 
       <source>Template caches are disabled</source>
<translation>Temblade-Cache isch deakdivierd</translation>
   </message> 
   <message> 
       <source>INI caches.</source>
<translation>INI-Cache.</translation>
   </message> 
   <message> 
       <source>INI caches</source>
<translation>INI-Cache</translation>
   </message> 
   <message> 
       <source>INI cache is disabled</source>
<translation>INI-Cache isch deakdivierd</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Path</source>
<translation>Pfad</translation>
   </message> 
   <message> 
       <source>Selection</source>
<translation>Auswahl</translation>
   </message> 
   <message> 
       <source>Disabled</source>
<translation>Deakdivierd</translation>
   </message> 
   <message> 
       <source>Clear selected</source>
<translation>Ausgewählde leeren</translation>
   </message> 
   <message> 
       <source>Content view cache</source>
<translation>Ansichdscache</translation>
   </message> 
   <message> 
       <source>System upgrade</source>
<translation>Syschdem Ubgrade</translation>
   </message> 
   <message> 
       <source>File consistency check OK</source>
<translation>Dadeikonsischdenz isch in Ordnung</translation>
   </message> 
   <message> 
       <source>Database check OK</source>
<translation>Dadenbankkonsischdenz isch in Ordnung</translation>
   </message> 
   <message> 
       <source>Warning, your database is not consistent with the distribution database.</source>
<translation>Achdung, Ihre Dadenbank isch nedd konsischdend mid dr aus dr Dischdribuzion.</translation>
   </message> 
   <message> 
       <source>Click a button to check file consistency.</source>
<translation>Kligget Sie auf oin Knobf, um d Dadeikonsischdenz z überbrüfe.</translation>
   </message> 
   <message> 
       <source>Check files</source>
<translation>Dadeie überbrüfen</translation>
   </message> 
   <message> 
       <source>warning, this might take a while</source>
<translation>achdung, des könnde oiig Zeid dauern</translation>
   </message> 
   <message> 
       <source>Click a button to check database consistency.</source>
<translation>Kligget Sie auf oin Knobf, um d Dadenbankkonsischdenz z überbrüfe.</translation>
   </message> 
   <message> 
       <source>Check database</source>
<translation>Dadenbank überbrüfen</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Create</source>
<translation>Erschdellen</translation>
   </message> 
   <message> 
       <source>Webserver</source>
<translation>Webserver</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Modules</source>
<translation>Module</translation>
   </message> 
   <message> 
       <source>Webserver modules could not be detected</source>
<translation>Die Module vom Webservers konnde nedd erkannd werden</translation>
   </message> 
   <message> 
       <source>No known information on the webserver</source>
<translation>Koi Informazione übr den Webservr bekannd</translation>
   </message> 
   <message> 
       <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access specific extensions, modify these configuration files.</source>
<translation>Sie könne hir ihre Erweiderunge akdiviere und deakdiviere. Nur syschdemweide Erweiderunge könne akdivierd werde. Für schbezifische Erweiderunge vo Seidenzugäng, änderet Sie diese Konfigurazionsdadeie.</translation>
   </message> 
   <message> 
       <source>Operating System</source>
<translation>Bedriabssyschdem</translation>
   </message> 
   <message> 
       <source>CPU</source>
<translation>CPU</translation>
   </message> 
   <message> 
       <source>Memory</source>
<translation>Schbeicher</translation>
   </message> 
   <message> 
       <source>No information on the operating system could be determined.</source>
<translation>Es konnde koi Informazione übr des Bedriabssyschdem beschdimmd werde.</translation>
   </message> 
   <message> 
       <source>System</source>
<translation>Syschdem</translation>
   </message> 
   <message> 
       <source>Image system</source>
<translation>Bildsyschdem</translation>
   </message> 
   <message> 
       <source>Mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Language</source>
<translation>Schbrache</translation>
   </message> 
   <message> 
       <source>Site</source>
<translation>Seide</translation>
   </message> 
   <message> 
       <source>Warning, it is not safe to upgrade without checking the modifications done to the following files</source>
<translation>Achdung, s isch nedd sichr oi Ubgrad durchzführe, ohne d Ändrunge an den folgende Dadeie z überbrüfe</translation>
   </message> 
   <message> 
       <source>To revert your database to distribution setup, run the following SQL queries</source>
<translation>Um Ihre Dadenbank auf des Sedub dr Dischdribuzion zurüggzführe, führet Sie folgend SQL-Befele aus</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Current siteaccess</source>
<translation>Akduells Seide Zugang</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Activate extensions</source>
<translation>Erweiderung akdivieren</translation>
   </message> 
   <message> 
       <source>Template edit</source>
<translation>Temblade bearbeiden</translation>
   </message> 
   <message> 
       <source>Save</source>
<translation>schbeichern</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>Toolbar management</source>
<translation>Verwaldung dr Werkzeig-Leischde</translation>
   </message> 
   <message> 
       <source>Available toolbars</source>
<translation>Verfügbare Werkzeig-Leischden</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/datatypecode</name>
   <message> 
       <source>Constructor</source>
<translation>Konschdrukdor</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/db</name>
   <message> 
       <source>If you are having problems connecting to your database you should take a look at</source>
<translation>Solldet Sie Problem bei dr Verbindung mid Ihrr Dadenbank hend solldet Sie hir nachschauen</translation>
   </message> 
   <message> 
       <source>at</source>
<translation>bei</translation>
   </message> 
   <message> 
       <source>MySQL</source>
<translation>MySQL</translation>
   </message> 
   <message> 
       <source>Introduction</source>
<translation>Einführung</translation>
   </message> 
   <message> 
       <source>MySQL is a database management system created by MySQL AB.</source>
<translation>MySQL isch oi DadenbankManagemendSyschdem, wo vo MySQL AB endwiggeld wurd.</translation>
   </message> 
   <message> 
       <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
<translation>MySQL isch oi dr am weideschde verwendede ObenSource-Dadenbanke und häufich in PHP voroigeschdelld.</translation>
   </message> 
   <message> 
       <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
<translation>MySQL is the world&apos;s mosch bobular Obe Source Dadabase, designed for schbeed, bowr and brecisio in missio cridical, heavy load use.</translation>
   </message> 
   <message> 
       <source>More information can be found on</source>
<translation>More informazion can b found on</translation>
   </message> 
   <message> 
       <source>Details</source>
<translation>Dedails</translation>
   </message> 
   <message> 
       <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
<translation>MySQL is a good choice for handling mosch weschderet languags, howevr id&apos;s currendly nod the besch choice for Unicod or non-weschderet languags.</translation>
   </message> 
   <message> 
       <source>Installation</source>
<translation>Inschdallazion</translation>
   </message> 
   <message> 
       <source>By using the</source>
<translation>By using the</translation>
   </message> 
   <message> 
       <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
<translation>configurazion obzion you enable PHP do access MySQL dadabass. If you use this obzion withoud schbecifying the bath do MySQL, PHP will use the build-in MySQL cliend libraris.</translation>
   </message> 
   <message> 
       <source>More information on the MySQL extension can be found at</source>
<translation>More informazion o the MySQL exdensio can b found ad</translation>
   </message> 
   <message> 
       <source>PostgreSQL</source>
<translation>PoschdgreSQL</translation>
   </message> 
   <message> 
       <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
<translation>PoschdgreSQL is a dadabase managemend syschdem develobed ad the Universidy of California ad Berkeley Combuadr Science Debardmend.</translation>
   </message> 
   <message> 
       <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
<translation>Id&apos;s a very bobular dadabase in the Obe Source communidy and brovids highly advanced dadabase funczionalidy.</translation>
   </message> 
   <message> 
       <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
<translation>PoschdgreSQL is a sofischdicaded Objecd-Relazional DBMS, subbording almosch all SQL conschdrucds, including subselecds, dransaczions, and user-defined dybs and funczions. Id is the mosch advanced oben-source dadabase available anywhere.</translation>
   </message> 
   <message> 
       <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
<translation>PoschdgreSQL is a good choice for handling mosch languags, including Unicod, bud may require som configurazion do gd good schbeed.</translation>
   </message> 
   <message> 
       <source>In order to enable PostgreSQL support,</source>
<translation>In ordr do enable PoschdgreSQL subbord,</translation>
   </message> 
   <message> 
       <source>is required when you compile PHP.</source>
<translation>is required whe you combile PHP.</translation>
   </message> 
   <message> 
       <source>More information on the PostgreSQL extension can be found at</source>
<translation>More informazion o the PoschdgreSQL exdensio can b found ad</translation>
   </message> 
   <message> 
       <source>From their homepage</source>
<translation>Vo ihrr Homebage</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/init</name>
   <message> 
       <source>Install demo data?</source>
<translation>Inschdall demo dada?</translation>
   </message> 
   <message> 
       <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
<translation>Cannod inschdall demo dada, the zlib exdensio is missing from your PHP inschdallazion.</translation>
   </message> 
   <message> 
       <source>does not support installing demo data at this point.</source>
<translation>dos nod subbord inschdalling demo dada ad this boind.</translation>
   </message> 
   <message> 
       <source>Demo data failure</source>
<translation>Demo dada failure</translation>
   </message> 
   <message> 
       <source>Could not unpack the demo data.</source>
<translation>Could nod unbagg the demo dada.</translation>
   </message> 
   <message> 
       <source>You should try to install without demo data.</source>
<translation>You should dry do inschdall withoud demo dada.</translation>
   </message> 
   <message> 
       <source>Initialization failed</source>
<translation>Inidializazion failed</translation>
   </message> 
   <message> 
       <source>The database could not be properly initialized.</source>
<translation>The dadabase could nod b broberly inidialized.</translation>
   </message> 
   <message> 
       <source>Warning</source>
<translation>Warning</translation>
   </message> 
   <message> 
       <source>Your database already contains data.</source>
<translation>Your dadabase already condains dada.</translation>
   </message> 
   <message> 
       <source>The setup can continue with the initialization but may damage the present data.</source>
<translation>The sedub can condinue with the inidializazion bud may damag the bresend dada.</translation>
   </message> 
   <message> 
       <source>What do you want the setup to do?</source>
<translation>Whedd do you wand the sedub do do?</translation>
   </message> 
   <message> 
       <source>Continue but leave the data as it is.</source>
<translation>Condinue bud leave the dada as id is.</translation>
   </message> 
   <message> 
       <source>Let me choose a new database.</source>
<translation>Led m choose a new dadabase.</translation>
   </message> 
   <message> 
       <source>Language Options</source>
<translation>Languag Obzions</translation>
   </message> 
   <message> 
       <source>no</source>
<translation>no</translation>
   </message> 
   <message> 
       <source>yes</source>
<translation>yes</translation>
   </message> 
   <message> 
       <source>Configure</source>
<translation>Configure</translation>
   </message> 
   <message> 
       <source>button.</source>
<translation>buddo.</translation>
   </message> 
   <message> 
       <source>No finetuning is required on your system, you can continue by clicking the</source>
<translation>No fineduning is required o your syschdem, you can condinue by cligging the</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Nexd</translation>
   </message> 
   <message> 
       <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
<translation>The syschdem chegg found som issus thad, whe resolved, may give imbroved berformance or more feadurs. Please have a look through the resulds below for more informazion o whedd mighd b done. Each issue will give you inschdruczions o how do do the fineduning.</translation>
   </message> 
   <message> 
       <source>After you have fixed the problems click the</source>
<translation>Afdr you have fixed the broblems cligg the</translation>
   </message> 
   <message> 
       <source>Rerun System Check</source>
<translation>Rerun Syschdem Chegg</translation>
   </message> 
   <message> 
       <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
<translation>buddo do re-run the syschdem chegging. This is recommended afdr syschdem changs do chegg for cridical failurs. You can also cligg the</translation>
   </message> 
   <message> 
       <source>Check Again</source>
<translation>Chegg Again</translation>
   </message> 
   <message> 
       <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
<translation>buddo do rerun the fineduning cheggs. Howevr if you wish you can skib schdraighd do the nexd schdeb by cligging the</translation>
   </message> 
   <message> 
       <source>Issues</source>
<translation>Issues</translation>
   </message> 
   <message> 
       <source>Failed writing</source>
<translation>Failed wriding</translation>
   </message> 
   <message> 
       <source>The setup could not write to the file.</source>
<translation>The sedub could nod wride do the file.</translation>
   </message> 
   <message> 
       <source>The setup could not get write access to the</source>
<translation>The sedub could nod gd wride access do the</translation>
   </message> 
   <message> 
       <source>directory. This is required to disable the initialization. Following the instructions found in</source>
<translation>direcdory. This is required do disable the inidializazion. Following the inschdruczions found in</translation>
   </message> 
   <message> 
       <source>to enable write access and click the</source>
<translation>do enable wride access and cligg the</translation>
   </message> 
   <message> 
       <source>Try Again</source>
<translation>Try Again</translation>
   </message> 
   <message> 
       <source>Change the second line from</source>
<translation>Chang the second line from</translation>
   </message> 
   <message> 
       <source>to</source>
<translation>do</translation>
   </message> 
   <message> 
       <source>The setup is now disabled, click</source>
<translation>The sedub is now disabled, cligg</translation>
   </message> 
   <message> 
       <source>to get back to the site.</source>
<translation>do gd bagg do the side.</translation>
   </message> 
   <message> 
       <source>You can choose from either</source>
<translation>You can choose from either</translation>
   </message> 
   <message> 
       <source>sendmail</source>
<translation>sendmail</translation>
   </message> 
   <message> 
       <source>SMTP</source>
<translation>SMTP</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>Congratulations, eZ publish should now run on your system.</source>
<translation>Congradulazions, eZ bublish should now run o your syschdem.</translation>
   </message> 
   <message> 
       <source>eZ publish website</source>
<translation>eZ bublish webside</translation>
   </message> 
   <message> 
       <source>eZ publish bug reports</source>
<translation>eZ bublish bug rebords</translation>
   </message> 
   <message> 
       <source>Done</source>
<translation>Done</translation>
   </message> 
   <message> 
       <source>It&apos;s time to select the language this site should support.</source>
<translation>Id&apos;s dim do selecd the languag this side should subbord.</translation>
   </message> 
   <message> 
       <source>Select your language and click the</source>
<translation>Selecd your languag and cligg the</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Summary</translation>
   </message> 
   <message> 
       <source>button, or the</source>
<translation>buddo, or the</translation>
   </message> 
   <message> 
       <source>Language Details</source>
<translation>Languag Dedails</translation>
   </message> 
   <message> 
       <source>button to select language variations.</source>
<translation>buddo do selecd languag variazions.</translation>
   </message> 
   <message> 
       <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
<translation>Id&apos;s dim do selecd the languags this side should subbord. Selecd your brimary languag and chegg any addizional languags.</translation>
   </message> 
   <message> 
       <source>Once you&apos;re done click the</source>
<translation>Once you&apos;re done cligg the</translation>
   </message> 
   <message> 
       <source>The languages you choose will help determine the charset to use on the site.</source>
<translation>The languags you choose will helb dedermine the charsed do use o the side.</translation>
   </message> 
   <message> 
       <source>Language name</source>
<translation>Nam dr Schbrache</translation>
   </message> 
   <message> 
       <source>Selection</source>
<translation>Seleczion</translation>
   </message> 
   <message> 
       <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
<translation>Id&apos;s now bossible do selecd a variazion for your languag. A variazion dos small adjuschdmends do the languag, such as adding Euro subbord or dade formad changs. Using variazions are obzional so you may safely skib this schdeb. Once your&apos;re done cligg the</translation>
   </message> 
   <message> 
       <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
<translation>Id&apos;s now bossible do selecd variazions for your languags. Variazions do small adjuschdmends do the languag, such as adding Euro subbord or dade formad changs. Using variazions are obzional so you may safely skib this schdeb. Once you are done cligg the</translation>
   </message> 
   <message> 
       <source>Default</source>
<translation>Defauld</translation>
   </message> 
   <message> 
       <source>Comments</source>
<translation>Commends</translation>
   </message> 
   <message> 
       <source>Send Registration</source>
<translation>Send Regischdrazion</translation>
   </message> 
   <message> 
       <source>Skip Registration</source>
<translation>Skib Regischdrazion</translation>
   </message> 
   <message> 
       <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
<translation>Whedd kind of languag subbord should this side have. The dyb of subbord dedermins the languag seleczion and charsed.</translation>
   </message> 
   <message> 
       <source>Monolingual (one language)</source>
<translation>Monolingual (one languag)</translation>
   </message> 
   <message> 
       <source>Multilingual (multiple languages with one charset)</source>
<translation>Muldilingual (muldible languags with one charsed)</translation>
   </message> 
   <message> 
       <source>Multilingual (Unicode, no limit)</source>
<translation>Muldilingual (Unicod, no limid)</translation>
   </message> 
   <message> 
       <source>Regional Options</source>
<translation>Regionale Obzionen</translation>
   </message> 
   <message> 
       <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
<translation>Here you will se a summary of the basic seddings for your side. If you are sadisfied with the seddings you can cligg the</translation>
   </message> 
   <message> 
       <source>Setup Database</source>
<translation>Sedub Dadabase</translation>
   </message> 
   <message> 
       <source>However if you want to change your settings click the</source>
<translation>Howevr if you wand do chang your seddings cligg the</translation>
   </message> 
   <message> 
       <source>Start Over</source>
<translation>Schdard Over</translation>
   </message> 
   <message> 
       <source>button which will restart the collecting of information (Existing settings are kept).</source>
<translation>buddo which will reschdard the collecding of informazion (Exischding seddings are kebd).</translation>
   </message> 
   <message> 
       <source>Database settings</source>
<translation>Dadabase seddings</translation>
   </message> 
   <message> 
       <source>Database</source>
<translation>Dadabase</translation>
   </message> 
   <message> 
       <source>Driver</source>
<translation>Driver</translation>
   </message> 
   <message> 
       <source>Unicode support</source>
<translation>Unicod subbord</translation>
   </message> 
   <message> 
       <source>Language settings</source>
<translation>Languag seddings</translation>
   </message> 
   <message> 
       <source>Language type</source>
<translation>Languag dybe</translation>
   </message> 
   <message> 
       <source>Monolingual</source>
<translation>Monolingual</translation>
   </message> 
   <message> 
       <source>Multilingual</source>
<translation>Muldilingual</translation>
   </message> 
   <message> 
       <source>Languages</source>
<translation>Languages</translation>
   </message> 
   <message> 
       <source>No problems was found with your system, you can continue by clicking the</source>
<translation>No broblems was found with your syschdem, you can condinue by cligging the</translation>
   </message> 
   <message> 
       <source>Finetune System</source>
<translation>Finedune Syschdem</translation>
   </message> 
   <message> 
       <source>Please have a look through the results below for more information on what the problems are.</source>
<translation>Please have a look through the resulds below for more informazion o whedd the broblems are.</translation>
   </message> 
   <message> 
       <source>Each problem will give you instructions on how to fix the problem.</source>
<translation>Each broblem will give you inschdruczions o how do fix the broblem.</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Servername</source>
<translation>Servername</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>The database is ready for initialization, click the %1 button when ready.</source>
<translation>Die Datenbank ist bereit zur Initialisierung, klicken Sie den %1 Button, wenn Sie bereit sind.</translation>
   </message> 
   <message> 
       <source>Continue</source>
<translation>Fordfahren</translation>
   </message> 
   <message> 
       <source>Continue but remove the data first.</source>
<translation>Fordfahre, abr zuersch d Dade endferne.</translation>
   </message> 
   <message> 
       <source>Keep data and skip database initialization.</source>
<translation>Behalde d Dade und überschbring d Dadenbankinidialisierung.</translation>
   </message> 
   <message> 
       <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
<translation>Es kann oiig Zeid daueret d Dadenbank z inidialisiere. Bidde hend Sie Geduld, bis d neie Seide aufgerufe isch.</translation>
   </message> 
   <message> 
       <source>Click the %1 button to start the configuration process.</source>
<translation>Klicken Sie den %1 Button um den Konfigurationsprocess zu starten.</translation>
   </message> 
   <message> 
       <source>ez.no</source>
<translation>ez.no</translation>
   </message> 
   <message> 
       <source>The default username for the administrator is %1 and the default password is %2.</source>
<translation>Der Standard Benutzername fÃ¼r den Administrator ist %1 und das Standard Passwort ist %2.</translation>
   </message> 
   <message> 
       <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
<translation>Diess Sedub wird nedd vo äldere eZ bublish Versione (wie 2.2.7) aufrüschde, falls Sie d Dade belasse, wie sie sind. Dis isch nur für Persone dachd, d beschdehend Dade hend und diese nedd verliere wolle. Falls Sie beschdehend eZ bublish 3.0 Dade hend (wie aus oim RC-Release), solldet Sie d Inidialisierung dr Dadenbank überschbringe und in dem Fall manuell aufrüschde.</translation>
   </message> 
   <message> 
       <source>which must be available on the server or</source>
<translation>die auf dem Servr verfügbar soi müsse oder</translation>
   </message> 
   <message> 
       <source>Database choice</source>
<translation>Wahl dr Dadenbank</translation>
   </message> 
   <message> 
       <source>The database would not accept the connection, please review your settings and try again.</source>
<translation>Die Dadenbank hedd d Verbindung nedd akzebdierd. Bidde überbrüfet Sie Ihre Einschdellunge und brobiere s erneid.</translation>
   </message> 
   <message> 
       <source>Password entries did not match.</source>
<translation>Die Passwordoidräg schdimme nedd überoi.</translation>
   </message> 
   <message> 
       <source>The selected database was not empty, please choose from the alternatives below.</source>
<translation>Die ausgewählde Dadenbank isch nedd ler. Bidde wählet Sie oi dr Aldernadive unde.</translation>
   </message> 
   <message> 
       <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
<translation>Dr ausgewählde Benudzr hedd koin Zugriff auf irgendoi Dadenbank. Bidde wechseln Sie den Benudzr odr erschdelle oin Dadenbank für ihn.</translation>
   </message> 
   <message> 
       <source>Database initalization</source>
<translation>Inidialisierung dr Dadenbank</translation>
   </message> 
   <message> 
       <source>Email settings</source>
<translation>E-Mail Einschdellungen</translation>
   </message> 
   <message> 
       <source>Finished</source>
<translation>Beended</translation>
   </message> 
   <message> 
       <source>Language options</source>
<translation>Schbrachobzionen</translation>
   </message> 
   <message> 
       <source>Registration</source>
<translation>Regischdrierung</translation>
   </message> 
   <message> 
       <source>Securing site</source>
<translation>Seide absichern</translation>
   </message> 
   <message> 
       <source>Site access</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Site details</source>
<translation>Seidendedails</translation>
   </message> 
   <message> 
       <source>No templates choosen.</source>
<translation>Koi Temblads ausgewähld.</translation>
   </message> 
   <message> 
       <source>Site template selection</source>
<translation>Auswahl dr Temblads für d Seide</translation>
   </message> 
   <message> 
       <source>System check</source>
<translation>Syschdemdeschd</translation>
   </message> 
   <message> 
       <source>Welcome to eZ publish</source>
<translation>Willkomme z eZ bublish</translation>
   </message> 
   <message> 
       <source>Choose database system</source>
<translation>Dadenbanksyschdem auswählen</translation>
   </message> 
   <message> 
       <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
<translation>PoschdgreSQL or MySQL &gt;= 4.1 sind für d Underschdüdzung vo Unicod in eZ bublish nodwendich.</translation>
   </message> 
   <message> 
       <source>More information about eZ publish and unicode support can be found %1.</source>
<translation>Mehr Informationen zu eZ publish und Unicode-UnterstÃ¼tzung kÃ¶nnen unter %1 gefunden werden .</translation>
   </message> 
   <message> 
       <source>Database initialization</source>
<translation>Inidialisierung dr Dadenbank</translation>
   </message> 
   <message> 
       <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
<translation>Falls Sie MySQL nudze und nedd wisse, was Sie in des Sogged-Feld oidrage solle, lasset Sie s leer</translation>
   </message> 
   <message> 
       <source>Title</source>
<translation>Tidel</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>User site</source>
<translation>Benudzeroberfläche</translation>
   </message> 
   <message> 
       <source>Admin site</source>
<translation>Adminischdrazionsoberfläche</translation>
   </message> 
   <message> 
       <source>Make sure to visit the %1 and the %2 web site.</source>
<translation>Stellen Sie sicher, dass Sie die Seiten %1 und %2 besuchen.</translation>
   </message> 
   <message> 
       <source>No Unicode support</source>
<translation>Koi Unicode-Underschdüdzung</translation>
   </message> 
   <message> 
       <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
<translation>Dr Dadenbankservr, mid dem Sie verbunde sind, underschdüdzd koin Unicod. Des bedeided, dess Sie nedd alle dr Schbrache nudze könne, d Sie ausgewähld hend.
Um des Problem z löse, müsset Sie ois dr folgende Ding dun:</translation>
   </message> 
   <message> 
       <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won&apos;t work.</source>
<translation>Benudzet Sie nur Schbrache mid ähnlile Zeichensädze. Beischbiel: Englisch und Norwegisch werde zsamme funkzioniere. Englisch und Russisch hingege nedd.</translation>
   </message> 
   <message> 
       <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
<translation>Schdellet Sie sichr, dess dr Dadenbankservr für Unicod oigerichded isch odr d akduellschde Sofdware mid Unicode-Underschdüdzung verwended.</translation>
   </message> 
   <message> 
       <source>Primary/Additional</source>
<translation>Primär/Zusädzlich</translation>
   </message> 
   <message> 
       <source>eZ publish supports multiple languages.</source>
<translation>eZ bublish underschdüdzd mehrere Schbrache gleichzeidig</translation>
   </message> 
   <message> 
       <source>These and other additional languages can also be installed later.</source>
<translation>Diese und weidere zsädzliche Schbrache konne au schbädr no inschdallierd werde.</translation>
   </message> 
   <message> 
       <source>Site registration</source>
<translation>Regischdrierung dr Seide</translation>
   </message> 
   <message> 
       <source>By sending registration the following data will be sent to eZ systems</source>
<translation>Bei oir Regischdrierung werde folgend Dade an eZ syschdem übermiddeld</translation>
   </message> 
   <message> 
       <source>Site access configuration</source>
<translation>Konfigurazion dr Seidenzugänge</translation>
   </message> 
   <message> 
       <source>URL (recommended)</source>
<translation>URL (embfohle)</translation>
   </message> 
   <message> 
       <source>Port. Note: Requires web server configuration</source>
<translation>Pord. Hinweis: Benödigd d Konfigurazion vom Webservers</translation>
   </message> 
   <message> 
       <source>Hostname. Note: Requires DNS setup.</source>
<translation>Hoschdnam. Hinweis: Benödig DNS-Eindräg.</translation>
   </message> 
   <message> 
       <source>The path determines access.</source>
<translation>Dr Pfad beschdimmd den Zugriff.</translation>
   </message> 
   <message> 
       <source>e.g. %adminsite and %usersite</source>
<translation>z.B. %adminsite und %usersite</translation>
   </message> 
   <message> 
       <source>Port</source>
<translation>Pord</translation>
   </message> 
   <message> 
       <source>The port number determines access.*</source>
<translation>Dir Pordnummr beschdimmd den Zugang.*</translation>
   </message> 
   <message> 
       <source>Hostname</source>
<translation>Hoschdname</translation>
   </message> 
   <message> 
       <source>The hostname determines access.*</source>
<translation>Dr Hoschdnam beschdimmd den Zugang.*</translation>
   </message> 
   <message> 
       <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
<translation>Sie hend d gleiche Dadenbank für oin odr mehrere Seiden-Temblads ausgewähld. Bidde nehmet Sie an den mid * makrierde Schdelle Änderunge vor</translation>
   </message> 
   <message> 
       <source>Site url</source>
<translation>Url dr Seide</translation>
   </message> 
   <message> 
       <source>Leave the data and add new</source>
<translation>Die Dade belasse und neie hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove existing data</source>
<translation>Beschdehend Dade endfernen</translation>
   </message> 
   <message> 
       <source>Leave the data and do nothing</source>
<translation>Die Dade belasse und nix weiders dun</translation>
   </message> 
   <message> 
       <source>I&apos;ve chosen a new database</source>
<translation>Ich hend oi neie Dadenbank gwähld</translation>
   </message> 
   <message> 
       <source>Select which sites you would like to install on your system.</source>
<translation>Wählet Sie, wo Seide auf Ihrem Syschdem inschdallierd werde solle.</translation>
   </message> 
   <message> 
       <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
<translation>Nachdem Sie die Probleme gelÃ¶st haben, klicken Sie auf den Knop %1, um den Systemtest erneut zu starten. Sie kÃ¶nnen bestimmte Tests durch Ankreuzfelder umgehen.</translation>
   </message> 
   <message> 
       <source>Ignore this test</source>
<translation>Diese desch umgehen</translation>
   </message> 
   <message> 
       <source>Welcome to eZ publish %1</source>
<translation>Willkommen in eZ publish %1</translation>
   </message> 
   <message> 
       <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
<translation>was d E-Mails weiderleide wird. Falls Sie unsichr sind, fraget Sie Ihre Webhoschdr. Einig Webhoschdr underschdüdze nedd</translation>
   </message> 
   <message> 
       <source>The system check found some issues that need to be resolved before the setup can continue.</source>
<translation>Dr Syschdemdesch hedd oiig Problem funde, d glösch werde müsse, bevor des Sedub fordgesedzd werde kann.</translation>
   </message> 
   <message> 
       <source>This section will contain information/help about each step in the setup wizard.</source>
<translation>Diesr Teil wird Informazionen/Hilfe z jedem Schridd vom Assidende enthalde.</translation>
   </message> 
   <message> 
       <source>The summary section below will contain information about configured settings.</source>
<translation>Dr Zusammenfassungschdeil unde wird Informazione übr konfigurierde Einschdellunge enthalde.</translation>
   </message> 
   <message> 
       <source>Information about how to set up eZ publish manually is available %1.</source>
<translation>Informationen, wie eZ publish manuell aufgesetzt werden kann sind %1 zu finden.</translation>
   </message> 
   <message> 
       <source>Outgoing E-mail</source>
<translation>Ausgehend E-Mails</translation>
   </message> 
   <message> 
       <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
<translation>Diesr Teil wird benudzd, um oizschdelle wie eZ bublish ausgend E-Mails verschiggd.</translation>
   </message> 
   <message> 
       <source>SMTP is recommended for MS Windows users.</source>
<translation>SMTP wird für MS Windows Benudzr embfohle.</translation>
   </message> 
   <message> 
       <source>E-mail delivery</source>
<translation>E-Mail Versand</translation>
   </message> 
   <message> 
       <source>Server name:</source>
<translation>Servername:</translation>
   </message> 
   <message> 
       <source>Username (optional):</source>
<translation>Benudzernam (odbional):</translation>
   </message> 
   <message> 
       <source>Password (optional):</source>
<translation>Password (obzional):</translation>
   </message> 
   <message> 
       <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
<translation>Des eZ bublish syschdem benudzd E-Mails, um wichdig Middeilunge, wie Regischdrierunge vo Benudzeret odr d Freigab vo Inhalde, z versende. Undr Linux/UNIX: Versuchet Sie Sendmail z nudze. Undr Windows: Nudzet Sie oin SMTP-Servr.</translation>
   </message> 
   <message> 
       <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
<translation>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mails werde durch oin SMTP-Servr verschiggd. Sie müsse mindeschdens den Hoschdname vom SMTP-Servers angebe. Tib: Übernehmet Sie d SMTP-Einschdellunge aus Ihrr E-Mail Anwendung.</translation>
   </message> 
   <message> 
       <source>Email is used for sending out important notices such as user registration and content approval.</source>
<translation>E-Mails werde genudzd, um wichdig Middeilunge, wie Regischdrierunge vo Benudzeret odr d Freigab vo Inhalde, z versende.</translation>
   </message> 
   <message> 
       <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
<translation>Die Meischde Unix-Syschdem nudze Sendmail. Windows Benudzr hingege müsse SMTP wähle.</translation>
   </message> 
   <message> 
       <source>&lt;b&gt;SMTP&lt;/b&gt;: If you&apos;re unsure what to enter, take a look at the settings in your e-mail application.</source>
<translation>&lt;b&gt;SMTP&lt;/b&gt;: Falls Sie nedd sichr sind, was Sie oigebe solle, sehet Sie in den Einschdellunge Ihrr E-Mail Anwendung nach.</translation>
   </message> 
   <message> 
       <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
<translation>Tib: Schbeicheret Sie diese Seide als oi hdml-Dadei, indem Sie Schbeicheret undr aus dem Menü Ihrers Webbrowsers auswähle. Aldernadiv könnet Sie si au d Adresse Ihrr Seide aufschreibe.</translation>
   </message> 
   <message> 
       <source>Language support</source>
<translation>Schbrachunderschdüdzung</translation>
   </message> 
   <message> 
       <source>This security tweak takes care of protecting configuration files and other important files.</source>
<translation>Diese Sicherheidsobdimierung kümmerd si darum, Konfigurazions- und andere wichdig Dadeie z schüdze.</translation>
   </message> 
   <message> 
       <source>Port*</source>
<translation>Pord*</translation>
   </message> 
   <message> 
       <source>* Requires web server setup.</source>
<translation>* Benödigd Einschdellunge am Webservr.</translation>
   </message> 
   <message> 
       <source>Hostname*</source>
<translation>Hoschdname*</translation>
   </message> 
   <message> 
       <source>* Requires DNS setup.</source>
<translation>* Benödigd DNS-Eindräg.</translation>
   </message> 
   <message> 
       <source>User path</source>
<translation>Benudzr Pfad</translation>
   </message> 
   <message> 
       <source>User port</source>
<translation>Benudzr Pord</translation>
   </message> 
   <message> 
       <source>User hostname</source>
<translation>Benudzr Hoschdname</translation>
   </message> 
   <message> 
       <source>Admin path</source>
<translation>Admin Pfad</translation>
   </message> 
   <message> 
       <source>Admin port</source>
<translation>Admin Pord</translation>
   </message> 
   <message> 
       <source>Admin hostname</source>
<translation>Admin Hoschdname</translation>
   </message> 
   <message> 
       <source>Next &amp;gt;</source>
<translation>Weidr &amp;gd;</translation>
   </message> 
   <message> 
       <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
<translation>Es gibd oiig Problem, d glösch werde müsse. Eine Lischde findet Sie unde. Jedr Abschnidd enthäld oi Beschreibung vom Problems und oi vorgeschlagene / embfohlene Lösung.</translation>
   </message> 
   <message> 
       <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
<translation>Wenn d Problem beseidigd sind, könnet Sie auf den Knobf &lt;i&gt;Weider&lt;/i&gt; kligge um fordzsedze. Dr Syschdemdesch wird noh erneid ausgeführd. Sollde alls in Ordnung soi, wird des Sedub auf dr nächschde Ebene fordsedze. Sollde no Problem beschdehe, wird diese Seide erneid aufgerufe.</translation>
   </message> 
   <message> 
       <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
<translation>Einig Problem könne durch Markierung vom Auswahlfelds &lt;i&gt;Diese Tesch auslassen&lt;/i&gt; ignoerierd werde. Dis solldet Sie abr no Möglichkeid vermeide.</translation>
   </message> 
   <message> 
       <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
<translation>Die Anzeig vom Syschdemdesch wurd aufgerufe. Des bedeided, dess s oiig Problem gibd.</translation>
   </message> 
   <message> 
       <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
<translation>Diese Problem müsse glösch werde, wenn eZ bublish ordnungsgemäß funkzioniere soll.</translation>
   </message> 
   <message> 
       <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
<translation>Diese Problem hänge für gwöhnlich mid dem Dadeisyschdem zsamme und könne durch oifachs Kobiere, Einfüge und Ausführe dr vorgeschlagene Befehle in oir Syschdem-Shell glösch werde.</translation>
   </message> 
   <message> 
       <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
<translation>Willkomme im eZ bublish condend managemend syschdem and develobmend framework. Diesr Assischdend wird Ihne dabei helfe oi erschde Inschdallazion vo eZ bublish vorzunehme. Kligget Sie oifach auf &lt;i&gt;Weider&lt;/i&gt; um mid dr Einrichdung z beginne.</translation>
   </message> 
   <message> 
       <source>No data will be stored in the database until the final step of the setup.</source>
<translation>Es werde koi Dade in dr Dadenbank gschbeicherd, bevor nedd dr ledzde Schridd vom Sedubs erreichd isch.</translation>
   </message> 
   <message> 
       <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
<translation>Underschdüdzung für MySQL und PoschdgreSQL wurd auf Ihrem Syschdem erkannd. Bidde wählet Sie aus, wo von dene beide Syschdem Sie verwende wolle.</translation>
   </message> 
   <message> 
       <source>eZ publish supports both MySQL and PostgreSQL.</source>
<translation>eZ bublish underschdüdzd beids, MySQL und PoschdgreSQL.</translation>
   </message> 
   <message> 
       <source>here</source>
<translation>hier</translation>
   </message> 
   <message> 
       <source>Please input database access information in the form below.</source>
<translation>Bidde gebet Sie d Zugriffsdade für d Dadenbank in d Feldr unde oi.</translation>
   </message> 
   <message> 
       <source>If you don&apos;t have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you&apos;re unsure about how to create a database.</source>
<translation>Falls Sie koin Zugriff auf oi Dadenbank hend, solldet Sie si zunächsch für oin Zugang sorge. eZ bublish isch in dr Lag mehrere Seide gleichzeidich z bediene. Jedr von dene Seide brauchd ihre eige Dadenbank. Des bedeided, dess Sie underschiedliche erschdelle müsse, wenn Sie vorhend mehrere Seide gleichzeidich z bedreibe. Bidde sehet Sie im Handbuch Ihrs Dadenbanksyschdems nach, wenn Sie nedd genau wisse, wie Sie oi Dadenbank erschdelle.</translation>
   </message> 
   <message> 
       <source>forums</source>
<translation>Foren</translation>
   </message> 
   <message> 
       <source>eZ publish</source>
<translation>eZ bublish</translation>
   </message> 
   <message> 
       <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
<translation>Hilfe zu eZ publish erhalten Sie auf in den Foren auf %ezlink.
  Falls Sie einen Bug (Fehler) finden, kÃ¶nnen Sie diesen auf %buglink melden.
  Mit Ihrer Hilfe kÃ¶nnen wir Fehler, die eventuell in eZ publish auftreten kÃ¶nnten, beheben und neue FÃ¤higkeiten einbauen.</translation>
   </message> 
   <message> 
       <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
<translation>Klicken Sie auf die URL, um %ezlink zu betreten oder klicken Sie auf den Knopf %donebutton. Erleben Sie eines der erfolgreichsten Web Content Management Systeme!</translation>
   </message> 
   <message> 
       <source>Change the second line from %false to %true.</source>
<translation>Ãndern Sie die zweite Zeile von %false in %true.</translation>
   </message> 
   <message> 
       <source>Use the radio buttons to choose the primary language, and the checkboxes to choose additional languages. You may choose more than one additional language.</source>
<translation>Wählet Sie mid den Radio-Buddons d Haubdschbrache und mid den Ankreizfelderet d zsädzlile Schbrache. Sie könne au mehr als oi zsädzliche Schbrache wähle.</translation>
   </message> 
   <message> 
       <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
<translation>Die ausgewählde Schbrache werde benudzd um Zeichensädze, Zeid-/Zahlenformadierunge, usw. z definiere.</translation>
   </message> 
   <message> 
       <source>For more information about language customization, please refer to the %1.</source>
<translation>FÃ¼r mehr Informationen Ã¼ber die Anpassung der Sprachen, folgen Sie der %1.</translation>
   </message> 
   <message> 
       <source>documentation</source>
<translation>Dokumendazion</translation>
   </message> 
   <message> 
       <source>Back</source>
<translation>Zurügg</translation>
   </message> 
   <message> 
       <source>Refresh</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
   <message> 
       <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
<translation>Falls Sie s wünsche, könnet Sie oin kommendar hinzfüge, wo dr Regischdrierungsmail hinzugefügd wird.</translation>
   </message> 
   <message> 
       <source>Send registration</source>
<translation>Regischdrierung abschiggen</translation>
   </message> 
   <message> 
       <source>System details (OS type, etc)</source>
<translation>Einig Dedails (Tyb vom Bedriabssyschdems, usw.)</translation>
   </message> 
   <message> 
       <source>The test results</source>
<translation>Die Teschdergebnisse</translation>
   </message> 
   <message> 
       <source>The database type</source>
<translation>Dr Tyb dr Dadenbank</translation>
   </message> 
   <message> 
       <source>The site name</source>
<translation>Dr Nam dr Seide</translation>
   </message> 
   <message> 
       <source>The url of the site</source>
<translation>Die Adresse dr Seide</translation>
   </message> 
   <message> 
       <source>Languages chosen</source>
<translation>Die gwählde Schbrachen</translation>
   </message> 
   <message> 
       <source>This data will help to improve future releases of eZ publish.</source>
<translation>Diese Dade werde helfe, zkünfdig Ausgabe vo eZ bublish z verbesseret.</translation>
   </message> 
   <message> 
       <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
<translation>Ihre Seide wird nedd im Virdual-Hosch Modus bedriabe, was unsichr isch. Es wird embfohle eZ bublish im Virdual-Hosch Modus laufe z lasse. Falls Sie diese Möglichkeid nedd hend, solldet Sie den ANweisunge unde folge, wie Sie oi .hdaccess-Dadei verwende. Diese Dadei informierd den Webservr darübr, dess dr Zugang z beschdimmde Dadeie oigeschränkd wird.</translation>
   </message> 
   <message> 
       <source>If you have shell access, you can run the following commmands.</source>
<translation>Falls Sie Zugriff auf oi Shell hend, führet Sie folgend Befehle aus.</translation>
   </message> 
   <message> 
       <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
<translation>Falls Sie koin Zugriff auf oi Shell hend, müsset Sie d Dadei br FTP kobiere odr Ihre Webhoschdr frage, dis für Sie z dun.</translation>
   </message> 
   <message> 
       <source>For more detailed information on site access, please refer to the %1</source>
<translation>FÃ¼r detaillierte Informationen Ã¼ber SeitenzugÃ¤nge, folgen Sie der %1</translation>
   </message> 
   <message> 
       <source>online documentation</source>
<translation>online Dokumendazion</translation>
   </message> 
   <message> 
       <source>You may modify the details for each site.</source>
<translation>Sie könne d Dedails für jed Seide anbasse, falls gwünschd.</translation>
   </message> 
   <message> 
       <source>For more information about how to configure site access, please refer to the %1</source>
<translation>FÃ¼r mehr Informationen, wie Sie SeitenzugÃ¤nge einrichten, folgen Sie der %1</translation>
   </message> 
   <message> 
       <source>documentation</source>
<translation>Dokumendazion</translation>
   </message> 
   <message> 
       <source>here</source>
<translation>hier</translation>
   </message> 
   <message> 
       <source>eZ publish has been installed with the following sites. You will find the username and password mentioned for each site.</source>
<translation>eZ bublish wurd mid den folgende Seide inschdallierd. Benudzernam und Password werde auf jedr Seide genannd.</translation>
   </message> 
   <message> 
       <source>Site security</source>
<translation>Seidensicherheid</translation>
   </message> 
   <message> 
       <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
<translation>Bidde wählet Sie oi Zugriffmethod, d Sie für Ihre Seide verwende möchde. Die Zugriffsmethod gibd an, wie dr Zugang vo oim Webbrowsr erfolge soll. Falls Sie si nedd sichr sind, wählet Sie URL.</translation>
   </message> 
   <message> 
       <source>Use the refresh button to update the database listing.</source>
<translation>Benudzet Sie den Knobf Akdualisiere, um d Lischde dr Dadenbanke z erneieret.</translation>
   </message> 
   <message> 
       <source>Site packages</source>
<translation>Seidenbakede</translation>
   </message> 
   <message> 
       <source>Each package will create a unique web site.</source>
<translation>Jed Paked wird oi eigenschdändig Webseide erschdelle.</translation>
   </message> 
   <message> 
       <source>Since each web site is unique, each package requires a unique database.</source>
<translation>Da jed Webseide eigenschdändich isch, muss jeds Paked oi eigene Dadenbank verwende.</translation>
   </message> 
   <message> 
       <source>Site administrator</source>
<translation>Adminischdrador dr Seide</translation>
   </message> 
   <message> 
       <source>No packages choosen.</source>
<translation>Koi Pakede gwähld</translation>
   </message> 
   <message> 
       <source>Site functionality</source>
<translation>Funkzionalidäd dr Seide</translation>
   </message> 
   <message> 
       <source>No site choosen.</source>
<translation>Koi Seide gwähld.</translation>
   </message> 
   <message> 
       <source>Site selection</source>
<translation>Seidenauswahl</translation>
   </message> 
   <message> 
       <source>System finetuning</source>
<translation>Foiinschdellung vom Syschdems</translation>
   </message> 
   <message> 
       <source>Finetune</source>
<translation>Foiinschdellungen</translation>
   </message> 
   <message> 
       <source>This page lets you modify the administrator for your site. This ensures that your site is secure and has proper name and E-mail set.</source>
<translation>Diese Seide lässch Sie den Adminischdrador Ihrr Seide veränderet. Dis schdelld sichr, dess d Seide sichr isch und oi güldig E-Mail Adresse gsedzd wurd.</translation>
   </message> 
   <message> 
       <source>You need to fill in the first name.</source>
<translation>Sie müsse den Vorname angebe.</translation>
   </message> 
   <message> 
       <source>You need to fill in the last name.</source>
<translation>Sie müsse den Nachname angebe.</translation>
   </message> 
   <message> 
       <source>You need to fill in an e-mail address.</source>
<translation>Sie müsse d E-Mail Adresse angebe.</translation>
   </message> 
   <message> 
       <source>You need to fill in a valid e-mail address.</source>
<translation>Sie müsse oi güldig E-Mail Adresse angebe.</translation>
   </message> 
   <message> 
       <source>Your passwords do not match.</source>
<translation>Die Passwördr schdimme nedd überoi.</translation>
   </message> 
   <message> 
       <source>You need to fill in a password.</source>
<translation>Sie müsse oi Password angebe.</translation>
   </message> 
   <message> 
       <source>Administrator settings</source>
<translation>Einschdellunge vom Adminischdradors</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>First name</source>
<translation>Vorname</translation>
   </message> 
   <message> 
       <source>Last name</source>
<translation>Nachname</translation>
   </message> 
   <message> 
       <source>E-mail address</source>
<translation>E-Mail Adresse</translation>
   </message> 
   <message> 
       <source>Confirm password</source>
<translation>Password beschdädigen</translation>
   </message> 
   <message> 
       <source>The login name is fixed and cannot be changed.
After the setup is done you can login with %admin_login and your password.</source>
<translation>Das Login ist fix und kann nicht geÃ¤ndert werden.</translation>
   </message> 
   <message> 
       <source>This page lets you modify information about the site you&apos;ve chosen to install. In addition, it also lets you choose a database for the site.</source>
<translation>Hir könnet Sie d Informazione Ihrr Seide änderet, d Sie inschdalliere möchde. Zusädzlich daz könnet Sie oi Dadenbank für sie wähle.</translation>
   </message> 
   <message> 
       <source>Host names should not include underscores (&apos;_&apos;), as this violates the DNS RFC and will cause problems with Internet Explorer. They have been converted to dashes (&apos;-&apos;).</source>
<translation>Hoschdname sollde koi Underschdriche (&apos;_&apos;) enthalde, da dis d DNS RFC verledzd und Problem mid dem Inderned Exblorr verursachd. Sie wurde in Schdriche (&apos;-&apos;) umgewandeld.</translation>
   </message> 
   <message> 
       <source>Your database already contain data.
The setup can continue with the initialization but may damage the present data.</source>
<translation>Ihre Dadenbank enthäld bereids Inhalde.
Des Sedub kann mid dr Inidialisierung fordfahre,, beschädigd damid abr evenduell d vorhandene Dade.</translation>
   </message> 
   <message> 
       <source>Select what to do from the drop-down box.</source>
<translation>Wählet Sie aus dr Auswahllischde aus, was gdan werde soll.</translation>
   </message> 
   <message> 
       <source>Action:</source>
<translation>Akzion:</translation>
   </message> 
   <message> 
       <source>Current site functionality</source>
<translation>Akduelle Seidenfunkzionalidäd</translation>
   </message> 
   <message> 
       <source>Please select additional functionality</source>
<translation>Bidde wählet Sie weidere Funkzionalidäde aus</translation>
   </message> 
   <message> 
       <source>Each site comes with a predefined set of functionality, however it is possible to add extra functionality.
This functionality is also available at a later time from the administration interface.</source>
<translation>Jed Seide kommd mid oim Sadz vordefinierdr Funkzione. Es isch abr au möglich weidere Funkzione hinzuzfüge.
Diese Auswahl isch au schbädr auf dr Adminischdrazionsfläche verfügbar.</translation>
   </message> 
   <message> 
       <source>Site type</source>
<translation>Seidendyb</translation>
   </message> 
   <message> 
       <source>The type of site will choose some basic settings for toolbars, menus, color and functionality.
It is possible to change these settings at a later time.</source>
<translation>Dr Seidendyb wird oiig Grundoischdellunge für Werkzeig-Lischde, Menüs und Funkzionalidäde sedze.
Es wird möglich soi diese schbädr abzänderet.</translation>
   </message> 
   <message> 
       <source>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</source>
<translation>Es isch au möglich d Foiinschdellunge vom Syschdems z überbrüfe. Kligget Sie daz auf &lt;i&gt;Foiinschdellungen&lt;/i&gt;, falls Sie Tibbs für Foiinschdellunge erhalde wolle.</translation>
   </message> 
   <message> 
       <source>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</source>
<translation>Es gibd oiig Ding, d undersuchd werde sollde, um d maximale Leidung und alle Funkzione z erhalde. Eine Lischde von dene Ding wird unde dargsedelld. Jedr Abschnidd enthäld oi vorgeschlagene odr embfohlene Vorgehensweise.</translation>
   </message> 
   <message> 
       <source>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</source>
<translation>Wenn Sie si mid diese Dinge ausoiandergesedzd hend, könnet Sie erneid auf &lt;i&gt;Foiinschdellungen&lt;/i&gt; kligge. Dr Syschdemdesch wird noh wiederhold. Sollde alls in Ordnung soi, wird mir dr nächschde Ebene vom Sedub fordgesedzd. Falls nedd, wird diese Seide erneid angezeigd.</translation>
   </message> 
   <message> 
       <source>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</source>
<translation>Falls Sie diese Ding nedd behebe wole, kligget Sie oifach auf &lt;i&gt;Weider&lt;/i&gt;.</translation>
   </message> 
   <message> 
       <source>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</source>
<translation>Die Foiinschdellunge werde angezeigd. Des bedeided, dess s oiig Ding gibd, d d Leischdung erhöhe odr für mehr Funkzionalidäd sorge könnde.</translation>
   </message> 
   <message> 
       <source>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</source>
<translation>Diese Ding müsse nedd behobe werde. eZ bublish wird au so ordnungsgemäß funkzioniere.</translation>
   </message> 
   <message> 
       <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</source>
<translation>Willkomme im eZ bublish condend managemend syschdem and develobmend framework. Diesr Assischdend wird Ihne helfe eZ bublish z inschdalliere.&lt;br&gt;Ihr Syschdem isch nedd obdimol vorbereided. Sie könne auf &lt;i&gt;Foiinschdellungen&lt;/i&gt; kligge, um Hinweise z erhalde, wie Sie Ihre Umgebung obdimiere könne.&lt;br/&gt; Sie könne au oifach auf &lt;i&gt;Weider&lt;/i&gt; kligge, um dis auszulasse.</translation>
   </message> 
   <message> 
       <source>The first time the user or admin site is accessed it will take some time (30 to 60 seconds). This is because eZ publish prepares the site for your machine.</source>
<translation>Des erschde Lade dr Benudzer- odr Admininschdrazionsoberfläche wird oiig Zeid in Anschbruch nehme (30 bis 60 Sekunde). Des liegd dro, dess eZ bublish d Seide für Ihre Maschine vorbereide muss.</translation>
   </message> 
   <message> 
       <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilities of eZ publish</source>
<translation>Falls Sie s wünsche kann eZ bublish oiig Demodade in Ihre Dadenbank oibflege. Diese Dade werde oi brauchbare Demonschdrazion dr Fähigkeide vo eZ bublish ermöglichen</translation>
   </message> 
   <message> 
       <source>First time users are advised to install the demo data.</source>
<translation>Neie Benudzr sollde Demodade inschdalliere.</translation>
   </message> 
   <message> 
       <source>Note</source>
<translation>Hinweis</translation>
   </message> 
   <message> 
       <source>The database was sucessfully initialized. You are now ready for some post configuration of the site.</source>
<translation>Die Dadenbank wurd erfolgreich inidialisierd. Sie werde nun oiig weidere Konfigurazione an dr Seide vornehme.</translation>
   </message> 
   <message> 
       <source>Socket (optional)</source>
<translation>Sogged (obzional)</translation>
   </message> 
   <message> 
       <source>PostgreSQL username and password is not tested until database names are selected.</source>
<translation>Dr angegebene Benudzernam und des angegebene Password für PoschdgreSQL werde ersch überbrüfd, wenn d Dadenbanke ausgewähld werde.</translation>
   </message> 
   <message> 
       <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says</source>
<translation>Obdinal würdet Sie des vielleichd manuell deakdiviere. Bearbeidet Sie daz d Einschdellungsdadei &lt;i&gt;seddings/side.ini&lt;/i&gt; und suchet Sie no dr Zeile</translation>
   </message> 
   <message> 
       <source>Sending e-mail failed</source>
<translation>E-Mail Versandd fehlgeschlagen</translation>
   </message> 
   <message> 
       <source>Failed to send the registration email using</source>
<translation>Des Sende dr Regischdrierung isch fehlgeschlage. Es wurd hierfür benudzd</translation>
   </message> 
   <message> 
       <source>If you ever want to restart this setup, edit the file %filename and look for a line that says</source>
<translation>Sollten Sie dieses Setup erneut starten wollen, bearbeiten Sie die Datei %filename und suchen Sie die Zeile</translation>
   </message> 
   <message> 
       <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited e-mails.</source>
<translation>Wenn Sie wolle, könnet Sie diese Inschdallazion regischdriere, indem Sie oiig Informazione an eZ syschdems übermiddeln. Es werde koi verdraulile Dade verschiggd werde. eZ syschdems wird Ihre Angabe nedd für uuuffgeforderde E-Mails benudze odr verkaufe.</translation>
   </message> 
   <message> 
       <source>The registration e-mail</source>
<translation>Die Regischdrierungsmail</translation>
   </message> 
   <message> 
       <source>Sending out the e-mail and generating your site will take about 10 to 30 seconds depending on your machine. Please wait until the next page loads. Clicking the button again will only send out duplicate e-mails, and may corrupt the installation.</source>
<translation>Des Verschigge dr E-Mail und d Erschdellung Ihrr Seide wird - abhängich vo Ihrr Maschine - zwische 10 und 30 Sekunde braule. Bidde wardet Sie, bis d nächschde Seide glade wurd. Mehrmaligs Ankligge vom Knobfs wird dobbelde Mails verschigge und evenduell d Inschdallazion beschädige.</translation>
   </message> 
   <message> 
       <source>Creating sites</source>
<translation>Erschdellung dr Seiden</translation>
   </message> 
   <message> 
       <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the PHP documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that PostgreSQL 7.2 is not supported.</source>
<translation>Bidde schdellet Sie sichr, dess Benudzernam und Password recht sind. Schdellet Sie au sichr, dess Ihre PoschdgreSQL Dadenbank korrekd konfigurierd isch.&lt;br&gt;Sehet Sie in dr Dokumendazion vo PHP nach, um mehr Informazione hierübr z erhalde.&lt;br&gt;Vergesset Sie nedd boschdmaschdr mid dr Obzion -i z schdarde.&lt;br&gt;Beachdet Sie, dess PoschdgreSQL 7.2 nedd underschdüdzd wird.</translation>
   </message> 
   <message> 
       <source>The &apos;digest&apos; procedure is not available in your database, you cannot run eZ publish without this. Visit the FAQ for more information.</source>
<translation>Die &apos;digeschd&apos; Method schdehd in Ihrr Dadenbank nedd zur Verfügung. Sie könne d eZ bublish so nedd bedreibe. Besuchet Sie d FAQ für mehr Informazione.</translation>
   </message> 
   <message> 
       <source>Your database version %version does not fit the minimum requirement which is %req_version.</source>
<translation>Die Version %version Ihrer Datenbank passt nicht zur Mindestanforderung. BenÃ¶tigt wird mindestens Version %req_version.</translation>
   </message> 
   <message> 
       <source>The setup wizard was not able to complete the creation of your selected sites.</source>
<translation>Dr Sedub-Assischdend war nedd in dr Lag d Erschdellung dr ausgewählde Seide abzschließe.</translation>
   </message> 
   <message> 
       <source>If you think you have fixed the errors you can try and click the &quot;Retry&quot; button.</source>
<translation>Falls Sie dr Moiung sind alle Fehlr behobe z hend, kligget Sie auf den Knobf &quot;Wiederholen&quot;.</translation>
   </message> 
   <message> 
       <source>The setup wizard failed to create the sites.</source>
<translation>Dr Sedub-Assischdend war nedd in dr Lag d Seide z erschdelle.</translation>
   </message> 
   <message> 
       <source>If possible try to fix these errors and click &quot;Retry&quot;.</source>
<translation>Falls möglich versuchet Sie d Fehlr z behebe und kligget Sie noh auf den Knobf &quot;Wiederholen&quot;.</translation>
   </message> 
   <message> 
       <source>Retry</source>
<translation>Wiederholen</translation>
   </message> 
   <message> 
       <source>The database %database_name cannot be used, it uses the character set %charset which is different from the requested charset %req_charset.</source>
<translation>Die Datenbank %database_name kann nicht verwendet werden. Sie benutzt den Zeichensatz %charset der sich vom geforderten Zeichensatz %req_charset unterscheidet.</translation>
   </message> 
   <message> 
       <source>The following errors were detected</source>
<translation>Die folgende Fehlr wurde erkannd</translation>
   </message> 
   <message> 
       <source>There are two options:&lt;br&gt;- Direct delivery through transfer agent (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
<translation>Es gibd zwei Obzionen:&lt;br&gt;- Direkdr Versand durch oin Transferagende (muss auf dem Servr inschdallierd soi).&lt;br&gt;- Indirekdr Versand undr Verwendung von a SMTP Relay-Servers.</translation>
   </message> 
   <message> 
       <source>Sendmail/MTA</source>
<translation>Sendmail/MTA</translation>
   </message> 
   <message> 
       <source>&lt;b&gt;Sendmail/MTA:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the mail transfer agent. The most common agent, sendmail, is usually available on most Linux/UNIX systems. If a mail transfer agent is not available then SMTP should be used.</source>
<translation>&lt;b&gt;Sendmail/MTA:&lt;/b&gt;&lt;br&gt;E-Mails werde direkd durch den Mail Transfr Agend (MTA) verschiggd. Dr am meischde verbreidede Agend, sendmail, isch normalerweise auf den meischde Linux-/UNIX-Syschdeme verfügbar. Falls oi MTA nedd verwended werde kann, sollde SMTP benudzd werde.</translation>
   </message> 
   <message> 
       <source>The access values must not be named &apos;admin&apos; or &apos;user&apos; and each value must be unique. Please change invalid values on site indicated by *</source>
<translation></translation>
   </message> 
</context>
<context>
<name>design/standard/setup/operatorcode</name>
   <message> 
       <source>Example</source>
<translation>Beischbiel</translation>
   </message> 
   <message> 
       <source>Constructor, does nothing by default.</source>
<translation>Konschdrukdor - hedd schdandardmäßich koi Aufgab.</translation>
   </message> 
   <message> 
       <source>\return an array with the template operator name.</source>
<translation>Geb oin Array mid dem Tembaldeoberadorname zurügg.</translation>
   </message> 
   <message> 
       <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
<translation>Führd d PHP-Funkzion vom Oberadore cleanub aus und modifizierd \a $oberadorValue.</translation>
   </message> 
   <message> 
       <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
<translation>Beischbielcod, dr gänderd werde muss, um des z dun was dr Oberador könne muss. Zur Zeid verkürzd r oifach nur Texd.</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/session</name>
   <message> 
       <source>Session admin</source>
<translation>Session-Verwaldung</translation>
   </message> 
   <message> 
       <source>The sessions were successfully removed.</source>
<translation>Die Sidzunge wurde erfolgreich endfernd</translation>
   </message> 
   <message> 
       <source>Sessions</source>
<translation>Sessions</translation>
   </message> 
   <message> 
       <source>Use the buttons below to delete the session entries that are present in the database.</source>
<translation>Benudzet Sie d Knöbf unde, um Sidzungsoidräg z lösche, d in dr Dadenbank vorhande sind.</translation>
   </message> 
   <message> 
       <source>WARNING! When removing sessions, users that are logged in will be thrown out from the system.</source>
<translation>ACHTUNG, hajo, so isch des ! Wenn Sidzunge endfernd werde, werde am Syschdem angemeldede Benudzr aus dem Syschdem gworfe.</translation>
   </message> 
   <message> 
       <source>Remove all sessions</source>
<translation>Alle Sidzunge endfernen</translation>
   </message> 
   <message> 
       <source>Remove timed out / old sessions</source>
<translation>Abgelaufene / alde Sidzunge endfernen</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Full name</source>
<translation>Vollr Name</translation>
   </message> 
   <message> 
       <source>Idle time</source>
<translation>Undädig Zeid</translation>
   </message> 
   <message> 
       <source>Idle since</source>
<translation>Undädich seid</translation>
   </message> 
   <message> 
       <source>Time skew detected</source>
<translation>Zeidversadz erkannd</translation>
   </message> 
   <message> 
       <source>Total number of sessions</source>
<translation>Gesamde Anzahl an Sidzungen</translation>
   </message> 
   <message> 
       <source>Displaying sessions for %username</source>
<translation>Sitzungen fÃ¼r Benutzer %username anzeigen</translation>
   </message> 
   <message> 
       <source>Show from all users</source>
<translation>Vo alle Benudzeret zeigen</translation>
   </message> 
   <message> 
       <source>Filter sessions</source>
<translation>Sidzunge Fildern</translation>
   </message> 
   <message> 
       <source>Everyone</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Registered users</source>
<translation>Regischdrierde Benudzer</translation>
   </message> 
   <message> 
       <source>Anonymous users</source>
<translation>Anonym Benudzer</translation>
   </message> 
   <message> 
       <source>Include inactive users</source>
<translation>Inakdive Benudzr oischließen</translation>
   </message> 
   <message> 
       <source>Update list</source>
<translation>Lischde akdualisieren</translation>
   </message> 
   <message> 
       <source>Count</source>
<translation>Anzahl</translation>
   </message> 
   <message> 
       <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
<translation>Es sind %logged_in_count registrierte und %anonymous_count anonyme Benutzer online.</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/tests</name>
   <message> 
       <source>Missing database handlers</source>
<translation>Missing dadabase handlers</translation>
   </message> 
   <message> 
       <source>Your PHP does not have support for all databases that eZ publish support.</source>
<translation>Your PHP dos nod have subbord for all dadabass thad eZ bublish subbord.</translation>
   </message> 
   <message> 
       <source>Also some databases has more advanced features, such as charset, than others.</source>
<translation>Also som dadabass has more advanced feadurs, such as charsed, than others.</translation>
   </message> 
   <message> 
       <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
<translation>To obdain more dadabase subbord you need do recombile PHP, the exacd recombile obzions are schbecified below.</translation>
   </message> 
   <message> 
       <source>Missing database handler</source>
<translation>Missing dadabase handlers</translation>
   </message> 
   <message> 
       <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
<translation>No subborded dadabase handlers were found. eZ bublish requirs a dadabase do schdore id&apos;s dada, withoud one the syschdem will fail.</translation>
   </message> 
   <message> 
       <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
<translation>To obdain dadabase subbord you need do recombile PHP, the exacd recombile obzions are schbecified below.</translation>
   </message> 
   <message> 
       <source>Insufficient directory permissions</source>
<translation>Insufficiend direcdory bermissions</translation>
   </message> 
   <message> 
       <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
<translation>eZ bublish cannod wride do som imbordand direcdoris, withoud this the sedub cannod finish and bards of eZ bublish will fail.</translation>
   </message> 
   <message> 
       <source>It&apos;s recommended that you fix this by running the commands below.</source>
<translation>Id&apos;s recommended thad you fix this by running the commands below.</translation>
   </message> 
   <message> 
       <source>Shell commands</source>
<translation>Shell commands</translation>
   </message> 
   <message> 
       <source>Missing image conversion support</source>
<translation>Missing imag conversio subbord</translation>
   </message> 
   <message> 
       <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
<translation>No imag conversio cababilidis was dedecded, this means thad eZ bublish cannod scale any imags or dedecd their dyb. This is vidal funczionalidy in eZ bublish and musch b subborded.</translation>
   </message> 
   <message> 
       <source>template operator will not be available.</source>
<translation>demblade oberador will nod b available.</translation>
   </message> 
   <message> 
       <source>Note:</source>
<translation>Node:</translation>
   </message> 
   <message> 
       <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
<translation>Fudure releass of eZ bublish will have more advanced imag subbord by using the imagegd exdensio.</translation>
   </message> 
   <message> 
       <source>Missing ImageMagick program</source>
<translation>Missing ImageMagigg brogram</translation>
   </message> 
   <message> 
       <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
<translation>The ImageMagigg brogram is nod available do eZ bublish. Withoud id eZ bublish will nod b able do do imag conversio unless the imagegd exdensio is available.</translation>
   </message> 
   <message> 
       <source>If you known where the program is installed (the executable is called</source>
<translation>If you known where the brogram is inschdalled (the execudable is called</translation>
   </message> 
   <message> 
       <source>or</source>
<translation>or</translation>
   </message> 
   <message> 
       <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
<translation>)the endr the direcdory in the inbud field below and do a rechegg (Sebarade muldible direcdoris with a</translation>
   </message> 
   <message> 
       <source>colon</source>
<translation>colon</translation>
   </message> 
   <message> 
       <source>semicolon</source>
<translation>semicolon</translation>
   </message> 
   <message> 
       <source>Installation</source>
<translation>Inschdallazion</translation>
   </message> 
   <message> 
       <source>ImageMagick may be downloaded from</source>
<translation>ImageMagigg may b downloaded from</translation>
   </message> 
   <message> 
       <source>Missing MBString extension</source>
<translation>Missing MBSchdring exdension</translation>
   </message> 
   <message> 
       <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
<translation>eZ bublish coms with a good lisch of subborded charseds by defauld, howevr they can b a bid slow due do boig mad in bure PHP cod. Luggily eZ bublish subbords the mbschdring exdensio for handling som of the charseds.</translation>
   </message> 
   <message> 
       <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
<translation>By enabling the mbschdring exdensio eZ bublish will have access do more charseds and also b able do brocess som of them faschdr, such as Unicod and iso-8859-*. This is recommended for muldilingual sids and sids with more exodic charseds.</translation>
   </message> 
   <message> 
       <source>Installation of the mbstring extension is done by compiling PHP with the</source>
<translation>Inschdallazion of the mbschdring exdensio is done by combiling PHP with the</translation>
   </message> 
   <message> 
       <source>option.</source>
<translation>obzion.</translation>
   </message> 
   <message> 
       <source>More information on enabling the extension can be found at</source>
<translation>More informazion o enabling the exdensio can b found ad</translation>
   </message> 
   <message> 
       <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
<translation>Do nod enable mbschdring funczion overloading, eZ bublish will only use the exdensio whenevr id&apos;s needed.</translation>
   </message> 
   <message> 
       <source>PHP option</source>
<translation>PHP obzion</translation>
   </message> 
   <message> 
       <source>is enabled</source>
<translation>is enabled</translation>
   </message> 
   <message> 
       <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
<translation>eZ bublish will work with this obzion o howevr id will lead do som minor berformance issus since all inbud variabls need do b b converded bagg do</translation>
   </message> 
   <message> 
       <source>normal</source>
<translation>normal</translation>
   </message> 
   <message> 
       <source>Insufficient PHP version</source>
<translation>Insufficiend PHP version</translation>
   </message> 
   <message> 
       <source>Your PHP version, which is</source>
<translation>Your PHP versio, which is</translation>
   </message> 
   <message> 
       <source>, does not meet the minimum requirements of</source>
<translation>, dos nod meed the minimum requiremends of</translation>
   </message> 
   <message> 
       <source>A newer version of PHP can be download at</source>
<translation>A newr versio of PHP can b download ad</translation>
   </message> 
   <message> 
       <source>You must upgrade to at least version</source>
<translation>You musch ubgrad do ad leasch versio</translation>
   </message> 
   <message> 
       <source>eZ publish cannot write to the</source>
<translation>eZ bublish cannod wride do the</translation>
   </message> 
   <message> 
       <source>directory, without this the setup cannot disable itself.</source>
<translation>direcdory, withoud this the sedub cannod disable idself.</translation>
   </message> 
   <message> 
       <source>Missing zlib extension</source>
<translation>Missing zlib exdension</translation>
   </message> 
   <message> 
       <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
<translation>The zlib exdensio is nod available do eZ bublish. Withoud id eZ bublish will nod b able do inschdall the demo dada, howevr if you do nod wish the demo dada you can safely ignore this.</translation>
   </message> 
   <message> 
       <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
<translation>To enable zlib you need do recombile PHP with subbord for id. You will need do configure PHP with</translation>
   </message> 
   <message> 
       <source>More information on that subject is available at</source>
<translation>More informazion o thad subjecd is available ad</translation>
   </message> 
   <message> 
       <source>File uploading is disabled</source>
<translation>Dadei ubload isch deakdivierd</translation>
   </message> 
   <message> 
       <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
<translation>File ubload isch nedd akdivierd, des heißd, dess s unmöglich isch für ezZ bublish file ubloads durchzführe. Alle andere Teile vo eZ bublish werde weiderhin recht arbeide, abr s wird embfohle Dadei ubloads z akdiviere.</translation>
   </message> 
   <message> 
       <source>Configuration</source>
<translation>Konfigurazion</translation>
   </message> 
   <message> 
       <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
<translation>Das Aktivieren des Datei-Uploads wird erreicht durch die Einstellung %1 ind er php.ini. Lesen Sie bitte auch die entsprechenden Teile im PHP manual</translation>
   </message> 
   <message> 
       <source>More information on enabling the extension can be found by reading %1 and %2</source>
<translation>Mehr Informationen zum Aktivieren dieser Erweiterung kÃ¶nnen durch lesen von %1 und %2 gefunden werden</translation>
   </message> 
   <message> 
       <source>More information on the subject can be found at %1.</source>
<translation>Mehr Informationen zu diesen Thema kÃ¶nnen gefunden werden bei %1.</translation>
   </message> 
   <message> 
       <source>PHP option %1 is enabled</source>
<translation>PHP Option %1 ist aktiviert</translation>
   </message> 
   <message> 
       <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
<translation>eZ bublish wird mid von dene Obzion funkzioniere. Allerdings wird dis z oim kloin Leischdungsverlusch führe, da alle Eingabevariable global verfügbar gmachd werde.</translation>
   </message> 
   <message> 
       <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
<translation>Es wird empfohlen diese Option auszuschalten. Um sie auszuschalten, bearbeiten Sie Ihre %1 Konfiguration und setzen Sie %2 auf %3.</translation>
   </message> 
   <message> 
       <source>PHP safe mode is enabled</source>
<translation>PHP saf mod isch akdivierd</translation>
   </message> 
   <message> 
       <source>Insufficient execution time allowed to install eZ publish</source>
<translation>Die erlaubde Ausführungszeid (Execuzion Tim) isch z kurz, um ezPublish z inschdallieren</translation>
   </message> 
   <message> 
       <source>eZ publish will not work correctly with a execution time limit of %1.</source>
<translation>eZ publish wird mir einer AusfÃ¼hrungszeit von %1 nicht korrekt abreiten.</translation>
   </message> 
   <message> 
       <source>It&apos;s highly recommended that you fix this.</source>
<translation>Es wird dringend embfohle dis z äneret.</translation>
   </message> 
   <message> 
       <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
<translation>Suchet Sie d Einschdellungsdadei fb.ini in Ihrr Inschdallazion. In Unix-Syschdeme finded Sie si normalerweise undr /edc/fb.ini, undr Windows durchsuchet Sie des Inschdallazionsverzeichnis vo fb.</translation>
   </message> 
   <message> 
       <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
<translation>Ãffnen Sie die Datei php.ini und setzen Sie den Wert max_execution_time auf mindestens %1 und drÃ¼cken dann %2</translation>
   </message> 
   <message> 
       <source>Next</source>
<translation>Weider</translation>
   </message> 
   <message> 
       <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
<translation>Falls eZ bublish in oir SharedHoschd-Umgebung bedreibe, wendet Sie si an Ihre ISP, damid r d Änderunge vornimmd</translation>
   </message> 
   <message> 
       <source>Insufficient memory allocated to install eZ publish</source>
<translation>Nedd genügend freigegebenr Schbeichr, um eZ bublish z inschdallieren</translation>
   </message> 
   <message> 
       <source>eZ publish will not work correctly with a memory limit of %1.</source>
<translation>eZ publish wird mit einem Speicherlimit von %1 nicht korrekt arbeiten.</translation>
   </message> 
   <message> 
       <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
<translation>Ãffnen Sie die Datei php.ini und Ã¤ndern Sie den Wert memeory_limit auf mindestens %1 und drÃ¼cken dann %2</translation>
   </message> 
   <message> 
       <source>It&apos;s recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
<translation>Es wird empfohlen, dass Die Optiona deaktiviert wird. Um sie zu deaktivieren, bearbeiten Sie Ihre %phpini Konfiguration und setzen %magic_quotes_gpc und %magic_quotes_runtime auf %offtext.</translation>
   </message> 
   <message> 
       <source>eZ publish will not work properly with this option on.</source>
<translation>eZ bublish wird mid von dene Obzion nedd recht funkzioniere.</translation>
   </message> 
   <message> 
       <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
<translation>Um Sie abzuschalten, bearbeiten Sie Ihre %phpini Konfiguration und setzen %magic_quotes_runtime auf %offtext.</translation>
   </message> 
   <message> 
       <source>Unstable PHP version</source>
<translation>Inschdabile PHP version</translation>
   </message> 
   <message> 
       <source>, is known to be unstable</source>
<translation>, isch als unschdabil bekannd</translation>
   </message> 
   <message> 
       <source>Another version of PHP can be download at</source>
<translation>Eine andere versio vo PHP kann raagelade werde von</translation>
   </message> 
   <message> 
       <source>Missing imagegd2 extension</source>
<translation>Die imagegd2-Erweiderung wird vermisschd</translation>
   </message> 
   <message> 
       <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
<translation>Die imagegd2-Erweiderung isch nedd verfügbar. Ohne diese wird eZ bublish nur noh Bildr konverdiere könne, wenn ImageMagigg inschdallierd isch und</translation>
   </message> 
   <message> 
       <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
<translation>Um imagegd2 z akdiviere, kombilieret Sie PHP mid Underschdüdzung dafür. Mehr Informazione findet Sie under</translation>
   </message> 
   <message> 
       <source>AcceptPathInfo disabled or running in CGI mode</source>
<translation>AccebdPathInfo deakdivierd odr im CGI-Modus</translation>
   </message> 
   <message> 
       <source>enter the following into your httpd.conf file.</source>
<translation>gebet Sie folgends in Ihre hddbd.conf oi.</translation>
   </message> 
   <message> 
       <source>Remember to restart your web server afterwards.</source>
<translation>Vergesset Sie nedd den Webservr anschließend neizschdarde.</translation>
   </message> 
   <message> 
       <source>Missing text creation functions</source>
<translation>Funkzione zur Texderschdellung werde vermisschd</translation>
   </message> 
   <message> 
       <source>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</source>
<translation>Die PHP-Funkzione ImageTTFTexd und ImageTTFBBox werde vermissch. Ohne diese Funkzione, wird s nedd möglich soi den Temblade-Oberadore dexddoimag z verwende.</translation>
   </message> 
   <message> 
       <source>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</source>
<translation>Um diese Funkzione z akdiviere, müsset Sie Ihr PHP mid Underschdüdzung dafür kombiliere. Mehr Informazione daz findet Sie under</translation>
   </message> 
   <message> 
       <source>Missing Session Extension</source>
<translation>Sidzungs-Erweiderung fehld</translation>
   </message> 
   <message> 
       <source>Your PHP module does not have session support, without this eZ publish will not work properly.</source>
<translation>Ihr PHP-Modul hedd koi Underschdüdzung für Sidzunge. eZ bublish wird nedd recht funkzioniere.</translation>
   </message> 
   <message> 
       <source>To enable session support you will have recompile your PHP module without the %session_disable switch.</source>
<translation>Um das zu aktivieren, mÃ¼ssen Sie Ihr PHP-Modul mit dem Schalter %session_disable kompilieren.</translation>
   </message> 
   <message> 
       <source>If your site is on shared-hosting you must contact the system administrator of the hosting company.</source>
<translation>Falls si diese Seide auf oim gdeilde Hosch befinded, müsset Sie Ihre Syschdemadminischdradore odr ihre Webhoschdr kondakdiere.</translation>
   </message> 
   <message> 
       <source>, but the latest released PHP 4.3.x version is highly recommended.</source>
<translation>, abr d akduellschde PHP 4.3.x Versio wird dringend embfohle.</translation>
   </message> 
   <message> 
       <source>Although eZ publish will work without it, it might be that you want to have support for this database.</source>
<translation>Auch wenn eZ bublish one Underschdüdzung dafür läufd, wollet Sie evenduell Underschdüdzung für diese Dadenbank hend.</translation>
   </message> 
   <message> 
       <source>The affected directories are: %dir_list</source>
<translation>Die betroffenen Verzeichnisse sind: %dir_list</translation>
   </message> 
   <message> 
       <source>These shell commands will give proper permission to the webserver.</source>
<translation>Diese Shell-Kommandos werde dem Webservr d nödige Rechde gebe.</translation>
   </message> 
   <message> 
       <source>Alternative shell commands</source>
<translation>Aldernadive Shell-Kommandos</translation>
   </message> 
   <message> 
       <source>If you don&apos;t have permissions to change the ownership you can try these commands.</source>
<translation>Falls Sie koi Rechde hend den Besidzr z änderet, versuchet Sie diese Befehle.</translation>
   </message> 
   <message> 
       <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the files to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
<translation>eZ publish konnte nicht herausfinden, welchen Benutzer und welche Gruppe der Webserver verwendet.
Falls Ihnen das bekannt ist, wird es empfohlen den Besitz der Dateien diesem Benutzer und dieser Gruppe anzupassen.
Um das zu tun,mÃ¼ssen Sie die %chown Kommandos unter den alternativen Shell-Kommandos abÃ¤ndern.</translation>
   </message> 
   <message> 
       <source>These commands will setup the permission more correctly, but require knowledge about the running webserver.</source>
<translation>Diese Kommandos werde d Rechde bessr oischdelle, abr verlange mehr Wisse übr den Bedriab vo Webseveret.</translation>
   </message> 
   <message> 
       <source>Note</source>
<translation>Hinweis</translation>
   </message> 
   <message> 
       <source>The %user_expr must be changed to your webserver username and groupname.</source>
<translation>%user_expr muss an den Benutzername und an die Gruppe Ihres Webservers angepasst werden.</translation>
   </message> 
   <message> 
       <source>File uploading is not possible</source>
<translation>Des Hochlade vo Dadeie isch nedd möglich</translation>
   </message> 
   <message> 
       <source>The PHP upload directory %upload_dir does not exists or is not accessible, without this you will not be able to upload files or images to eZ publish.</source>
<translation>Das Upload-Verzeichnis %upload_dir gibt es nicht oder der Zugriff war nicht erfolgreich. Sie werden nicht in der Lage sein Dateien in eZ publish hochzuladen.</translation>
   </message> 
   <message> 
       <source>Create the directory %upload_dir on your system. If you do not have the possibility to create this yourself ask the administrator to create it for you.</source>
<translation>Erstellen Sie das Verzeichnis %upload_dir  in Ihrem System. Falls die keines MÃ¶glichkeit dazu haben, fragen Sie den Administratoren, ob er das fÃ¼r Sie erledigen kann.</translation>
   </message> 
   <message> 
       <source>The upload directory is currently placed in the directory of the root user.
This is a security problem and should be changed to another global temporary directory</source>
<translation>Des Ubload-Verzeichnis befinded si momendan im Verzeichnis dr Rood-Benudzers.
Des isch oi Sicherheidrisiko und sollde auf oi anders globals demborärs Verzeichnis gänderd werden</translation>
   </message> 
   <message> 
       <source>This shell command will create the upload directory.</source>
<translation>Diese Shell-Befehle werde oi Ubload-Verzeichnis erschdelle.</translation>
   </message> 
   <message> 
       <source>The PHP upload directory %upload_dir is not writeable. This means that it will be impossible to upload files or images to eZ publish.</source>
<translation>Das PHP Upload-Verzeichnis %upload_dir ist nicht schreibbar. Das beduetet, dass das Hocladen von Dateien und Bilder in eZ publish nicht mÃ¶glich sein wird.</translation>
   </message> 
   <message> 
       <source>You must change the permission on the directory %upload_dir. If you do not have the possibility to create this yourself ask the administrator to do this for you.</source>
<translation>Sie mÃ¼ssen die Rechte auf das Verzeichnis %upload_dir Ã¤ndern. Falls Sie dazu keine MÃ¶glichkeit haben, fragen Sie den Admininistratoren, ob er das fÃ¼r Sie tun kann.</translation>
   </message> 
   <message> 
       <source>These shell commands will give proper permission to the upload directory.</source>
<translation>Diese Shell-Befehle werde korrekde Rechde auf des Ubload-Verzeichnis sedze.</translation>
   </message> 
   <message> 
       <source>If you don&apos;t have permissions to change the ownership you can try this command.</source>
<translation>Falls Sie d Rechde nedd änderet könne, könnet Sie diese Befehl versuche.</translation>
   </message> 
   <message> 
       <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the upload directory to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
<translation>eZ publish konnte den Benutzer und die Gruppe des Webservers nicht erkennen.
Falls Sie das wissen, wird empfohlen das Upload-Verzeichnis so anzupassen, dass Sie diesem benutzer und dieser Gruppe entsprechen.
Um das zu tun, mÃ¼ssen Sie die %chown Kommandos unter den alternativen Shell-Befehlen anpassen.</translation>
   </message> 
   <message> 
       <source>This shell command will give proper permission to the upload directory.</source>
<translation>Diese Shell-Befehle werde korrekde Rechde auf des Ublaod-Verzeichnis sedze.</translation>
   </message> 
   <message> 
       <source>If you know the user and group of the webserver you can try this command. Replace apache:apache with the user and group.</source>
<translation>Falls Sie wisse, wo Benudzr und wo Grubb dr Webservr benudzd, könnet Sie diese Befehle verwende. Ersedzet Sie abache:abache mid dem endschbrechende Benudzr und dr endschbrechende Grubb.</translation>
   </message> 
   <message> 
       <source>The complete list of charsets mbstring supports are</source>
<translation>Die kombledde Lischde dr mbschdring Zeichensadz-Underschdüdzung ischd</translation>
   </message> 
   <message> 
       <source>php.ini example</source>
<translation>fb.ini Beischbiel</translation>
   </message> 
   <message> 
       <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following</source>
<translation>Alternativ kÃ¶nnen SIe auch eine Datei %1 in Ihrem eZ publish Hauptverzeichnis erstellen und das folgende hineinschreiben</translation>
   </message> 
   <message> 
       <source>.htaccess example</source>
<translation>.hdaccess Beischbiel</translation>
   </message> 
   <message> 
       <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are</source>
<translation>eZ bublish funkzionierd evenduell mid akdivierdr Safe-Mod. Allerdings werde oiig Funkzione noh nedd verfügbar soi. Ding d aufdrede könnde sind</translation>
   </message> 
   <message> 
       <source>You need to enable AcceptPathInfo in your Apache config file, if you&apos;re using apache 2.x.</source>
<translation>Sie müsse AccebdPathInfo in Ihrr Abache-Konfigurazion akdiviere, wenn Sie abache 2.x verwende.</translation>
   </message> 
   <message> 
       <source>If you&apos;re running apache 1.3, eZ publish will not run in CGI mode.</source>
<translation>Falls Sie abache 1.3 verwende, wird eZ bublish nedd im CGI-Modus laufe.</translation>
   </message> 
</context>
<context>
<name>design/standard/setup/toolbar</name>
   <message> 
       <source>Placement</source>
<translation>Pladzierung</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Tool</source>
<translation>Werkzeige</translation>
   </message> 
   <message> 
       <source>Update Placement</source>
<translation>Pladzierung akdualisieren</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Tool List for Toolbar_%toolbar_position</source>
<translation>Werkzeug-Liste fÃ¼r Toolbar_%toolbar_position</translation>
   </message> 
   <message> 
       <source>Add Tool</source>
<translation>Werkzeig hinzfügen</translation>
   </message> 
</context>
<context>
<name>design/standard/shop</name>
   <message> 
       <source>Basket</source>
<translation>Einkaufskorb</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Continue shopping</source>
<translation>Weidr oikaufen</translation>
   </message> 
   <message> 
       <source>Checkout</source>
<translation>Zur Kasse</translation>
   </message> 
   <message> 
       <source>You have no products in your basket</source>
<translation>Sie hend koi Produkde im Einkaufskorb</translation>
   </message> 
   <message> 
       <source>Confirm order</source>
<translation>Beschdellung beschdädigen</translation>
   </message> 
   <message> 
       <source>Product items</source>
<translation>Produkde</translation>
   </message> 
   <message> 
       <source>Confirm</source>
<translation>Beschdädigen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>Group view</source>
<translation>Grubben-Übersichd</translation>
   </message> 
   <message> 
       <source>Percent</source>
<translation>Prozend</translation>
   </message> 
   <message> 
       <source>Add Rule</source>
<translation>Richdlinie hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove Rule</source>
<translation>Richdlinie endfernen</translation>
   </message> 
   <message> 
       <source>Customers</source>
<translation>Kunden</translation>
   </message> 
   <message> 
       <source>Add customer</source>
<translation>Kund hinzfügen</translation>
   </message> 
   <message> 
       <source>Remove customer</source>
<translation>Kunde endfernen</translation>
   </message> 
   <message> 
       <source>Editing rule</source>
<translation>Richdlinie bearbeiden</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Order list</source>
<translation>Beschdelllischde</translation>
   </message> 
   <message> 
       <source>ID</source>
<translation>ID</translation>
   </message> 
   <message> 
       <source>Date</source>
<translation>Dadum</translation>
   </message> 
   <message> 
       <source>Customer</source>
<translation>Kunde</translation>
   </message> 
   <message> 
       <source>Total ex. VAT</source>
<translation>Gesamdsumm ohne Mehrwerdschdeier</translation>
   </message> 
   <message> 
       <source>Total inc. VAT</source>
<translation>Gesamdsumm inkl. Mehrwerdschdeier</translation>
   </message> 
   <message> 
       <source>Order</source>
<translation>Beschdellung</translation>
   </message> 
   <message> 
       <source>VAT Types</source>
<translation>Mehrwerdschdeierdyben</translation>
   </message> 
   <message> 
       <source>Wish list</source>
<translation>Wunschzeddel</translation>
   </message> 
   <message> 
       <source>Empty wish list</source>
<translation>Wunschzeddl leeren</translation>
   </message> 
   <message> 
       <source>Product</source>
<translation>Produkd</translation>
   </message> 
   <message> 
       <source>Count</source>
<translation>Zählen</translation>
   </message> 
   <message> 
       <source>VAT</source>
<translation>MwSchd</translation>
   </message> 
   <message> 
       <source>Price ex. VAT</source>
<translation>Preis exklusive MwSchd</translation>
   </message> 
   <message> 
       <source>Price inc. VAT</source>
<translation>Preis inkl. MwSchd</translation>
   </message> 
   <message> 
       <source>Discount</source>
<translation>Ermäßigung</translation>
   </message> 
   <message> 
       <source>Total Price ex. VAT</source>
<translation>Gesamd Preis exklusive MwSchd</translation>
   </message> 
   <message> 
       <source>Total Price inc. VAT</source>
<translation>Gesamd Preis inkl. MwSchd</translation>
   </message> 
   <message> 
       <source>Discount groups</source>
<translation>Ermäßigungsgrubben</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Edit discount group - %1</source>
<translation>Ãndere ErmÃ¤Ãigungsgruppe - %1</translation>
   </message> 
   <message> 
       <source>Group Name</source>
<translation>Grubbenname</translation>
   </message> 
   <message> 
       <source>Defined rules</source>
<translation>Definierde Rollen</translation>
   </message> 
   <message> 
       <source>Apply to</source>
<translation>Anwende auf</translation>
   </message> 
   <message> 
       <source>Discount percent</source>
<translation>Ermäßigungs Prozendsadz</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>Subtotal of items</source>
<translation>Zwischensumm dr Posizionen</translation>
   </message> 
   <message> 
       <source>The order list is empty</source>
<translation>Die Beschdelllischde isch leer</translation>
   </message> 
   <message> 
       <source>Order total</source>
<translation>Kombledde Beschdellsumme</translation>
   </message> 
   <message> 
       <source>Register account information</source>
<translation>Regischdriere Kondoinformazionen</translation>
   </message> 
   <message> 
       <source>Input did not validate, fill in all fields</source>
<translation>Eingab war nedd richdg, bidde füllet Sie alle Feldr aus</translation>
   </message> 
   <message> 
       <source>Percentage</source>
<translation>Prozendsadz</translation>
   </message> 
   <message> 
       <source>Find</source>
<translation>Finden</translation>
   </message> 
   <message> 
       <source>Attributes</source>
<translation>Addribuade</translation>
   </message> 
   <message> 
       <source>Rule settings</source>
<translation>Rollenoischdellungen</translation>
   </message> 
   <message> 
       <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
<translation>Wähle wo Klasse, Sekzione odr Objekde ( Produkde ) z von dene Regl gehöre, &apos;Alle&apos; heißd d Regl wird alle zugeordned.</translation>
   </message> 
   <message> 
       <source>Object</source>
<translation>Objekd</translation>
   </message> 
   <message> 
       <source>Not specified.</source>
<translation>Nedd schbezifizierd.</translation>
   </message> 
   <message> 
       <source>Sort</source>
<translation>Sordieren</translation>
   </message> 
   <message> 
       <source>First name</source>
<translation>Vorname</translation>
   </message> 
   <message> 
       <source>Last name</source>
<translation>Nachname</translation>
   </message> 
   <message> 
       <source>Email</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Address</source>
<translation>Adresse</translation>
   </message> 
   <message> 
       <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
<translation>Die Zahlung wurd abgebrole wege von a unbekannde Grunds. Bidde versuchet Sie s erneid.</translation>
   </message> 
   <message> 
       <source>Order summary</source>
<translation>Beschdellauflischdung</translation>
   </message> 
   <message> 
       <source>Sort Result by</source>
<translation>Sordiere vom Ergebnisss nach</translation>
   </message> 
   <message> 
       <source>Order Time</source>
<translation>Beschdellzeidbunkd</translation>
   </message> 
   <message> 
       <source>User Name</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>Order ID</source>
<translation>Beschdellungs ID</translation>
   </message> 
   <message> 
       <source>Ascending</source>
<translation>Aufschdeigend</translation>
   </message> 
   <message> 
       <source>Sort ascending</source>
<translation>Aufschdeigend sordieren</translation>
   </message> 
   <message> 
       <source>Descending</source>
<translation>Abschdeigend</translation>
   </message> 
   <message> 
       <source>Sort descending</source>
<translation>Abschdeigend sordieren</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Remove items</source>
<translation>Endferne Gegenschdände</translation>
   </message> 
   <message> 
       <source>Selected options</source>
<translation>Ausgewählde Obzionen</translation>
   </message> 
   <message> 
       <source>Customer list</source>
<translation>Kunden-Lischde</translation>
   </message> 
   <message> 
       <source>Number of orders</source>
<translation>Zahl dr Beschdellungen</translation>
   </message> 
   <message> 
       <source>The customer list is empty</source>
<translation>Die Lischde dr Kunde isch leer</translation>
   </message> 
   <message> 
       <source>Customer Information</source>
<translation>Kundeninformazion</translation>
   </message> 
   <message> 
       <source>Purchase list</source>
<translation>Erwerbslischde</translation>
   </message> 
   <message> 
       <source>Amount</source>
<translation>Menge</translation>
   </message> 
   <message> 
       <source>Statistics</source>
<translation>Schdadischdik</translation>
   </message> 
   <message> 
       <source>All Year</source>
<translation>Alle Jahre</translation>
   </message> 
   <message> 
       <source>All Month</source>
<translation>Alle Monade</translation>
   </message> 
   <message> 
       <source>View</source>
<translation>Ansichd</translation>
   </message> 
   <message> 
       <source>Are you sure you want to remove order:</source>
<translation>Sind Sie sichr, dess d d Beschdellung endferne wollen:</translation>
   </message> 
   <message> 
       <source>Your account information</source>
<translation>Ihre Accound Informazionen</translation>
   </message> 
   <message> 
       <source>Input did not validate, all fields marked with * must be filled in</source>
<translation>Die EIngabe konnde nedd validierd werde. Alle mid * markierde Feldr müsse ausgefülld werden</translation>
   </message> 
   <message> 
       <source>All fields marked with * must be filled in.</source>
<translation>Alle mid * markierde Feldr müsse ausgefülld werde.</translation>
   </message> 
   <message> 
       <source>Customer information</source>
<translation>Kundeninformazion</translation>
   </message> 
   <message> 
       <source>Shipping address</source>
<translation>Lieferadresse</translation>
   </message> 
   <message> 
       <source>Company</source>
<translation>Undernehmen</translation>
   </message> 
   <message> 
       <source>Street</source>
<translation>Schdraße</translation>
   </message> 
   <message> 
       <source>Zip</source>
<translation>PLZ</translation>
   </message> 
   <message> 
       <source>Place</source>
<translation>Ord</translation>
   </message> 
   <message> 
       <source>State</source>
<translation>Schdaad</translation>
   </message> 
   <message> 
       <source>Country</source>
<translation>Land</translation>
   </message> 
   <message> 
       <source>The following items were removed from your basket, because the products were changed</source>
<translation>Die folgende Posizione wurde vo Ihrem Warenkorb endfernd, da d Produkde gänderd wurden</translation>
   </message> 
   <message> 
       <source>Subtotal Ex. VAT</source>
<translation>Zwischensumm ohne MwSchd.</translation>
   </message> 
   <message> 
       <source>Subtotal Inc. VAT</source>
<translation>Zwischensumm mid MwSchd.</translation>
   </message> 
   <message> 
       <source>SUM</source>
<translation>SUM</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Comment</source>
<translation>Kommendar</translation>
   </message> 
   <message> 
       <source>Continue</source>
<translation>Fordfahren</translation>
   </message> 
   <message> 
       <source>Attempted to add object without price to basket.</source>
<translation>Versuchd oi Objekd ohne Preis dem Warenkorb hinzuzfüge.</translation>
   </message> 
   <message> 
       <source>Your payment was aborted.</source>
<translation>Ihre Bezahlung wurd abgebrole.</translation>
   </message> 
   <message> 
       <source>Order %order_id [%order_status]</source>
<translation>Bestellung %order_id [%order_status]</translation>
   </message> 
   <message> 
       <source>Order history</source>
<translation>Beschdellverlauf</translation>
   </message> 
   <message> 
       <source>We did not get a confirmation from the payment server.</source>
<translation>Wir hend koi Beschdädigung vom Zahlungsservr erhalde.</translation>
   </message> 
   <message> 
       <source>Waiting for a response from the payment server. This can take some time.</source>
<translation>Warde auf oi Andword vom Zahlungsservr. Dis könnde oin Momend daueret.</translation>
   </message> 
   <message> 
       <source>Retrying to get a valid response.</source>
<translation>Neiversuch, um oi güldig Andword z erhalde.</translation>
   </message> 
   <message> 
       <source>Retry</source>
<translation>Neiversuch</translation>
   </message> 
   <message> 
       <source>out of</source>
<translation>vo</translation>
   </message> 
   <message> 
       <source>If your page does not automatically refresh then press the refresh button manually.</source>
<translation>Falls Ihre Seide si nedd audomadisch akdualisierd, drügget Sie manuell auf den Knobf zum Akdualisiere.</translation>
   </message> 
   <message> 
       <source>Order status</source>
<translation>Beschdellschdadus</translation>
   </message> 
   <message> 
       <source>Active</source>
<translation>Akdiv</translation>
   </message> 
   <message> 
       <source>Is active</source>
<translation>Isch akdiv</translation>
   </message> 
   <message> 
       <source>Is inactive</source>
<translation>Isch inakdiv</translation>
   </message> 
   <message> 
       <source>Please contact the owner of the webshop and provide your order ID</source>
<translation>Bidde nehmet Sie mid dem Besidzr vom Indernedshobs kondakd auf und gebet Sie im d ID dr Beschdellung</translation>
   </message> 
</context>
<context>
<name>design/standard/shop/view</name>
   <message> 
       <source>Choose customers</source>
<translation>Wähle Kunde</translation>
   </message> 
   <message> 
       <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
<translation>Please choose the customers you want to add to discount group %groupname.(new line)
(new line)
   Select your customers and click the %buttonname button.(new line)
   Using the recent and bookmark items for quick selection is also possible.(new line)
   Click on object names to change the browse listing.</translation>
   </message> 
   <message> 
       <source>Choose product for discount</source>
<translation>Wähle Produkd für Rabadd</translation>
   </message> 
   <message> 
       <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
<translation>Please choose the products you want to add to discount rule %discountname in discount group %groupname.(new line)
(new line)
   Select your products and click the %buttonname button.(new line)
   Using the recent and bookmark items for quick selection is also possible.(new line)
   Click on product names to change the browse listing.</translation>
   </message> 
</context>
<context>
<name>design/standard/simplified_treemenu</name>
   <message> 
       <source>Fold/Unfold</source>
<translation>Minimieren/Maximieren</translation>
   </message> 
</context>
<context>
<name>design/standard/toolbar</name>
   <message> 
       <source>Toolbar management</source>
<translation>Werkzeig-Leischden-Verwaldung</translation>
   </message> 
   <message> 
       <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
<translation>Es sind %logged_in_count registrierte und %anonymous_count anonyme Benutzer online.</translation>
   </message> 
   <message> 
       <source>Shopping basket</source>
<translation>Warenkorb</translation>
   </message> 
   <message> 
       <source>View all details</source>
<translation>Alle Dedails ansehen</translation>
   </message> 
   <message> 
       <source>Your basket is empty</source>
<translation>Ihr Warenkorb isch leer</translation>
   </message> 
   <message> 
       <source>Best sellers</source>
<translation>Beschdseller</translation>
   </message> 
   <message> 
       <source>Calendar</source>
<translation>Kalender</translation>
   </message> 
   <message> 
       <source>My drafts</source>
<translation>Moi Endwürfe</translation>
   </message> 
   <message> 
       <source>Account</source>
<translation>Kondo</translation>
   </message> 
   <message> 
       <source>Not logged in</source>
<translation>nedd angemelded</translation>
   </message> 
   <message> 
       <source>Logged in as: %username</source>
<translation>Angemeldet als: %username</translation>
   </message> 
   <message> 
       <source>Edit account</source>
<translation>Benudzer-Kondo bearbeiden</translation>
   </message> 
   <message> 
       <source>Change password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>Logout</source>
<translation>Abmelden</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Anmelden</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>Not registered?</source>
<translation>Nedd regischdrierd?</translation>
   </message> 
   <message> 
       <source>Forgot your password?</source>
<translation>Password vergesse?</translation>
   </message> 
   <message> 
       <source>Notification</source>
<translation>Benachrichdigungen</translation>
   </message> 
   <message> 
       <source>My Notifications</source>
<translation>Moi Benachrichdigungen</translation>
   </message> 
   <message> 
       <source>User information</source>
<translation>Benudzer-Informazionen</translation>
   </message> 
   <message> 
       <source>View basket</source>
<translation>Warenkorb ansehen</translation>
   </message> 
   <message> 
       <source>Online: %logged_in_count:%anonymous_count</source>
<translation>Online: %logged_in_count:%anonymous_count</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
</context>
<context>
<name>design/standard/toolbar/search</name>
   <message> 
       <source>Search</source>
<translation>Suche</translation>
   </message> 
   <message> 
       <source>Global</source>
<translation>global</translation>
   </message> 
   <message> 
       <source>From here</source>
<translation>Vo hier</translation>
   </message> 
   <message> 
       <source>Search:</source>
<translation>Suche:</translation>
   </message> 
</context>
<context>
<name>design/standard/trigger</name>
   <message> 
       <source>No workflow</source>
<translation>Koi Workflow</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Trigger list</source>
<translation>Trigger-Lischde</translation>
   </message> 
   <message> 
       <source>Workflow</source>
<translation>Workflow</translation>
   </message> 
   <message> 
       <source>Module name</source>
<translation>Modulname</translation>
   </message> 
   <message> 
       <source>Function name</source>
<translation>Funkzionsname</translation>
   </message> 
   <message> 
       <source>Connect type</source>
<translation>Verbindungschdyb</translation>
   </message> 
</context>
<context>
<name>design/standard/url</name>
   <message> 
       <source>All</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Valid</source>
<translation>Güldig</translation>
   </message> 
   <message> 
       <source>Invalid</source>
<translation>Ungüldig</translation>
   </message> 
   <message> 
       <source>The URL points to %1.</source>
<translation>Die URL zeigt auf %1.</translation>
   </message> 
   <message> 
       <source>Last modified at %1</source>
<translation>Zuletzt geÃ¤ndert am %1</translation>
   </message> 
   <message> 
       <source>URL has no modification date</source>
<translation>Die URL hedd koi Änderungsdadum</translation>
   </message> 
   <message> 
       <source>Last checked at %1</source>
<translation>Zuletzt Ã¼berprÃ¼ft am %1</translation>
   </message> 
   <message> 
       <source>URL has not been checked</source>
<translation>Die URL wurd no nedd überbrüfd</translation>
   </message> 
   <message> 
       <source>Filter</source>
<translation>Filder</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Last checked</source>
<translation>Zuledzd überbrüfd</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Modifizierd</translation>
   </message> 
   <message> 
       <source>Popup</source>
<translation>Pobub</translation>
   </message> 
   <message> 
       <source>Never</source>
<translation>Niemals</translation>
   </message> 
   <message> 
       <source>Unknown</source>
<translation>Unbekannd</translation>
   </message> 
   <message> 
       <source>All URLs</source>
<translation>Alle URLs</translation>
   </message> 
   <message> 
       <source>Invalid URLs</source>
<translation>Ungüldig URLs</translation>
   </message> 
   <message> 
       <source>Valid URLs</source>
<translation>Güldig URLs</translation>
   </message> 
   <message> 
       <source>Information on URL</source>
<translation>Informazione zur URL</translation>
   </message> 
   <message> 
       <source>Objects which use this link</source>
<translation>Objekde, d diese Link nudzen</translation>
   </message> 
   <message> 
       <source>No object available</source>
<translation>Koi Objekde verfügbar</translation>
   </message> 
   <message> 
       <source>version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>The URL is not considered valid any more.</source>
<translation>Die URL isch nemme güldich.</translation>
   </message> 
   <message> 
       <source>This means that the URL is no longer available or has been moved.</source>
<translation>Des heissch, dess d URL nemme verfügbar isch, odr verschobe wurde.</translation>
   </message> 
</context>
<context>
<name>design/standard/url/edit</name>
   <message> 
       <source>Editing URL - %1</source>
<translation>URL - %1 Ã¤ndern</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/user</name>
   <message> 
       <source>Activate account</source>
<translation>Kondo (Accound) akdivieren</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>Could not login</source>
<translation>Konnde Sie nedd anmelden</translation>
   </message> 
   <message> 
       <source>A valid username and password is required to login.</source>
<translation>Güldigr Nudzernam und Password sind erforderlich.</translation>
   </message> 
   <message> 
       <source>Change password for user</source>
<translation>Benudzerbassword ändern</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Register user</source>
<translation>Benudzr regischdrieren</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Eingab konnde nedd validierd werden</translation>
   </message> 
   <message> 
       <source>Input was stored successfully</source>
<translation>Eingab wurd erfolgreich gschbeicherd</translation>
   </message> 
   <message> 
       <source>Register</source>
<translation>Regischdrieren</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>User setting</source>
<translation>Benudzeroischdellungen</translation>
   </message> 
   <message> 
       <source>Maximum login</source>
<translation>Max. Logins</translation>
   </message> 
   <message> 
       <source>Is enabled</source>
<translation>Isch akdivierd</translation>
   </message> 
   <message> 
       <source>Update</source>
<translation>Akdualisieren</translation>
   </message> 
   <message> 
       <source>User registered</source>
<translation>Regischdrierdr Nudzer</translation>
   </message> 
   <message> 
       <source>Your account was successfully created.</source>
<translation>Ihr Benudzerkondo wurd erfolgreich erschdelld.</translation>
   </message> 
   <message> 
       <source>Access not allowed</source>
<translation>Zugang nedd erlaubd</translation>
   </message> 
   <message> 
       <source>You are not allowed to access %1.</source>
<translation>Zugang zu %1 ist nicht erlaubt.</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>User profile</source>
<translation>Usr Profil</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Please retype your old password.</source>
<translation>Bidde gebet Sie Ihr alds Password oi.</translation>
   </message> 
   <message> 
       <source>Password didn&apos;t match, please retype your new password.</source>
<translation>Des Password schdimmd nedd überoi, bidde get Sie Ihr neis Password nochmol oi.</translation>
   </message> 
   <message> 
       <source>Password successfully updated.</source>
<translation>Password erfolgreich erneierd.</translation>
   </message> 
   <message> 
       <source>Edit profile</source>
<translation>Edidiere Profil</translation>
   </message> 
   <message> 
       <source>Change password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>Change setting</source>
<translation>Ändere Einschdellung</translation>
   </message> 
   <message> 
       <source>Old password</source>
<translation>Alds Password</translation>
   </message> 
   <message> 
       <source>New password</source>
<translation>Neis Password</translation>
   </message> 
   <message> 
       <source>Retype password</source>
<translation>Password wiederholen</translation>
   </message> 
   <message> 
       <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
<translation>Ihr Kondo wurd erfolgreich erschdelld. Eine E-Mail wird nun an d angegebene E-Mail Adresse verschiggd. Sie müsse den Inschdrukzione in dr E-Mail folgeleischde, um Ihre Accound z akdiviere.</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>Sign Up</source>
<translation>Anmelden</translation>
   </message> 
   <message> 
       <source>Forgot your password?</source>
<translation>Password vergesse?</translation>
   </message> 
   <message> 
       <source>Your account is now activated.</source>
<translation>Ihr Kondo isch nun akdivierd.</translation>
   </message> 
   <message> 
       <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
<translation>Dr überdragene Schlüssl war nedd güldich. Ihr Kondo wurd nedd akdivierd.</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>Unable to register new user</source>
<translation>Regischdrierung vom neie Benudzers fehlgeschlagen</translation>
   </message> 
   <message> 
       <source>Back</source>
<translation>Zurügg</translation>
   </message> 
</context>
<context>
<name>design/standard/user/forgotpassword</name>
   <message> 
       <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
<translation>Eine E-Mail wurde an die folgende Adresse versand: %1. Diese E-Mail enthÃ¤lt einen Link, der aufgerufen werden muss, damit wir sichergehen kÃ¶nnen, dass der richtige Benutzer das neue Password bekommt.</translation>
   </message> 
   <message> 
       <source>There is no registered user with that e-mail address.</source>
<translation>Es gibd koin regischdierde Benudzr mid von dene E-Mail Adresse.</translation>
   </message> 
   <message> 
       <source>Have you forgotten your password?</source>
<translation>Habet Sie Ihr Password vergesse?</translation>
   </message> 
   <message> 
       <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
<translation>Wenn Sie Ihr Password vergesse hend könne mir Ihne oi neis generiere. Alls was Sie mache müsse isch Ihre E-Mail Adresse oizugebe und mir werde oi neis Password für Sie generiere.</translation>
   </message> 
   <message> 
       <source>Generate new password</source>
<translation>Generiere neis Password</translation>
   </message> 
   <message> 
       <source>Your account information</source>
<translation>Ihre Accound Informazionen</translation>
   </message> 
   <message> 
       <source>The key is invalid or has been used.</source>
<translation>Dr Schlüssl isch ungüldich odr verbrauchd.</translation>
   </message> 
   <message> 
       <source>Password was successfully generated and sent to: %1</source>
<translation>Das Passwort wurde erfolgreich generiert und versendet nach: %1</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>%siteurl new password</source>
<translation>%sideirl neis Password</translation>
   </message> 
   <message> 
       <source>Click here to get new password</source>
<translation>Hir kligge, um oi neie Password z bekommen</translation>
   </message> 
   <message> 
       <source>New password</source>
<translation>Neis Password</translation>
   </message> 
</context>
<context>
<name>design/standard/user/register</name>
   <message> 
       <source>%1 registration info</source>
<translation>%1 Regischdrazionsinformazionen</translation>
   </message> 
   <message> 
       <source>Email</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Click the following URL to confirm your account</source>
<translation>Kligget Sie d folgend URL, um Ihr Kondo z akdivieren</translation>
   </message> 
   <message> 
       <source>New user registered at %siteurl</source>
<translation>Neuer Benutzer registiert auf %siteurl</translation>
   </message> 
   <message> 
       <source>A new user has registered.</source>
<translation>Ein neir Benudzr wurd regischdierd.</translation>
   </message> 
   <message> 
       <source>Account information.</source>
<translation>Kondoinformazione.</translation>
   </message> 
   <message> 
       <source>Link to user information</source>
<translation>Link z den Benudzerinformazionen</translation>
   </message> 
   <message> 
       <source>Thank you for registering at %siteurl.</source>
<translation>Danke, dass Sie sich auf %siteurl registiert haben.</translation>
   </message> 
   <message> 
       <source>Your account information</source>
<translation>Ihre Accound Informazionen</translation>
   </message> 
   <message> 
       <source>Password</source>
<translation>Password</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Username</source>
<translation>Benudzername</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/menuconfig</name>
   <message> 
       <source>Menu management</source>
<translation>Menu-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Menu positioning</source>
<translation>Menübosizionierung</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click here to store the changes if you have modified the menu settings above.</source>
<translation>Kligget Sie hir um Änderunge z schbeicheret, falls Sie d Menüoischdellunge obe gänderd hend.</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/templatecreate</name>
   <message> 
       <source>Could not create template, permission denied.</source>
<translation>Konnde des Temblade nedd erschdelle, Zugriff verweigerd.</translation>
   </message> 
   <message> 
       <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
<translation>Ungüldigr Nam. Sie könne nur d Buchschdabe a-z, Zifferet und _ benudze.</translation>
   </message> 
   <message> 
       <source>Create new template override for &lt;%template_name&gt;</source>
<translation>Neues Ãberschreib-Template fÃ¼r &lt;%template_name&gt; erstellen</translation>
   </message> 
   <message> 
       <source>The newly created template file will be placed in</source>
<translation>Die nei erschdellde Temblade-Dadei wird blazierd in</translation>
   </message> 
   <message> 
       <source>Filename</source>
<translation>Dadoiame</translation>
   </message> 
   <message> 
       <source>Override keys</source>
<translation>Überschreibungsschlüssel</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>All classes</source>
<translation>Alle Klassen</translation>
   </message> 
   <message> 
       <source>Section</source>
<translation>Sekzion</translation>
   </message> 
   <message> 
       <source>All sections</source>
<translation>Alle Sekzionen</translation>
   </message> 
   <message> 
       <source>Node ID</source>
<translation>Knode ID</translation>
   </message> 
   <message> 
       <source>Base template on</source>
<translation>Temblade-Grundlage</translation>
   </message> 
   <message> 
       <source>Empty file</source>
<translation>Leere Dadei</translation>
   </message> 
   <message> 
       <source>Copy of default template</source>
<translation>Kobie vom Schdandard-Temblades</translation>
   </message> 
   <message> 
       <source>Container (with children)</source>
<translation>Condainr ( mid Kinderet )</translation>
   </message> 
   <message> 
       <source>View (without children)</source>
<translation>Sichd ( ohne Kindr )</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Object</source>
<translation>Objekd</translation>
   </message> 
   <message> 
       <source>OK</source>
<translation>OK</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/templateedit</name>
   <message> 
       <source>Edit template: &lt;%template&gt;</source>
<translation>Bearbeiten von Template: &lt;%template&gt;</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to save the contents of the text field above to the template file.</source>
<translation>Kligget Sie auf diese Knobf um d Inhalde dr Texdfeldr obe in d Temblade-Dadei z schbeicheret.</translation>
   </message> 
   <message> 
       <source>You do not have permissions to save the contents of the text field above to the template file.</source>
<translation>Sie hend nedd d nodwendige Rechde, um d Inhalde dr Texdfeldr obe in d Temblade-Dadei z schbeicheret.</translation>
   </message> 
   <message> 
       <source>Back to overrides</source>
<translation>Zurügg z den Überschreibungen</translation>
   </message> 
   <message> 
       <source>Back to override overview.</source>
<translation>Zurügg zur Übersichd übr d Überschreibunge.</translation>
   </message> 
   <message> 
       <source>The template can not be edited.</source>
<translation>Des Temblade kann nedd bearbeided werde.</translation>
   </message> 
   <message> 
       <source>The web server does not have write access to the requested template.</source>
<translation>Dr Webservr hedd koin Schreibzugriff auf des angeforderde Temblade.</translation>
   </message> 
   <message> 
       <source>The web server does not have read access to the requested template.</source>
<translation>Dr Webservr hedd koin Lesezugriff auf des angeforderde Temblade.</translation>
   </message> 
   <message> 
       <source>The requested template does not exist or is not being used as an override.</source>
<translation>Des angeforderde Temblade exischdierd nedd odr wird nedd als Überschreibung verwended.</translation>
   </message> 
   <message> 
       <source>Edit &lt;%template_name&gt; [Template]</source>
<translation>Bearbeiten von &lt;%template_name&gt; [Template]</translation>
   </message> 
   <message> 
       <source>Requested template</source>
<translation>Angeforderds Temblade</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Overrides template</source>
<translation>Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Open as read only</source>
<translation>Nur lesend öffnen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/templatelist</name>
   <message> 
       <source>Complete template list</source>
<translation>Kombledde Tembladelischde</translation>
   </message> 
   <message> 
       <source>Template</source>
<translation>Temblade</translation>
   </message> 
   <message> 
       <source>Design resource</source>
<translation>Design Ressource</translation>
   </message> 
   <message> 
       <source>Manage overrides for template.</source>
<translation>Überschreibunge vo Temblads verwalde.</translation>
   </message> 
   <message> 
       <source>Most common templates</source>
<translation>Die gebräuchlichschde Temblades</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/templateview</name>
   <message> 
       <source>The overrides could not be removed.</source>
<translation>Die Überschreibunge konnde nedd endfernd werde.</translation>
   </message> 
   <message> 
       <source>The following files and override rules could not be removed because of insufficient file permissions</source>
<translation>Die folgende Dadeie und Regeln zur Überschreibung konnde aufgrund unzureichendr Dadeirechde nedd endfernd werden</translation>
   </message> 
   <message> 
       <source>The override.ini file could not be modified because of insufficient permissions.</source>
<translation>Die Dadei overrid.ini konnde aufgrund unzureichendr Rechde nedd gänderd werde.</translation>
   </message> 
   <message> 
       <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
<translation>Ãberschreibungen fÃ¼r das Template &lt;%template_name&gt; im &lt;%current_siteaccess&gt; Seiten-Zugang [%override_count]</translation>
   </message> 
   <message> 
       <source>Default template resource</source>
<translation>Schdandard-Temblade-Ressource</translation>
   </message> 
   <message> 
       <source>Siteaccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Invert selection.</source>
<translation>Auswahl umkehre.</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Match conditions</source>
<translation>Bedingungen</translation>
   </message> 
   <message> 
       <source>Priority</source>
<translation>Prioridäd</translation>
   </message> 
   <message> 
       <source>No file matched</source>
<translation>Koi Dadei driffd zu</translation>
   </message> 
   <message> 
       <source>Edit override template.</source>
<translation>Überschreib-Temblade bearbeiden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Remove selected template overrides.</source>
<translation>Ausgewählde Überschreib-Temblade endferne.</translation>
   </message> 
   <message> 
       <source>New override</source>
<translation>Neis Überschreib-Temblade</translation>
   </message> 
   <message> 
       <source>Create a new template override.</source>
<translation>Neis Überschreib-Temblade erschdelle.</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde akdualisieren</translation>
   </message> 
</context>
<context>
<name>design/standard/visual/toolbar</name>
   <message> 
       <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
<translation>Werkzeug Liste fÃ¼r &lt;Toolbar_%toolbar_position&gt;</translation>
   </message> 
   <message> 
       <source>Browse</source>
<translation>Durchsuchen</translation>
   </message> 
   <message> 
       <source>True</source>
<translation>Wahr</translation>
   </message> 
   <message> 
       <source>False</source>
<translation>Falsch</translation>
   </message> 
   <message> 
       <source>Yes</source>
<translation>Ja</translation>
   </message> 
   <message> 
       <source>No</source>
<translation>Noi</translation>
   </message> 
   <message> 
       <source>There are currently no tools in this toolbar</source>
<translation>Es befinde si zur Zeid koi Werkzeig in dr Werkzeig-Leischde</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Ausgewählde endfernen</translation>
   </message> 
   <message> 
       <source>Update priorities</source>
<translation>Prioridäde akdualisieren</translation>
   </message> 
   <message> 
       <source>Add Tool</source>
<translation>Werkzeig hinzfügen</translation>
   </message> 
   <message> 
       <source>Apply changes</source>
<translation>Änderunge anwenden</translation>
   </message> 
   <message> 
       <source>Click this button to store changes if you have modified the parameters above.</source>
<translation>Kligget Sie diese Knobf an um d Änderunge z schbeicheret, wenn Sie Paramedr gänderd hend.</translation>
   </message> 
   <message> 
       <source>Back to toolbars</source>
<translation>Zurügg z den Werkzeig-Leischden</translation>
   </message> 
   <message> 
       <source>Go back to the toolbar list.</source>
<translation>Gehe zurügg z dr Werkzeig-Leischde Lischde.</translation>
   </message> 
   <message> 
       <source>Toolbar management</source>
<translation>Werkzeig-Leischden-Verwaldung</translation>
   </message> 
   <message> 
       <source>SiteAccess</source>
<translation>Seide Zugang</translation>
   </message> 
   <message> 
       <source>Current siteaccess</source>
<translation>Akduells Seide Zugang</translation>
   </message> 
   <message> 
       <source>Select siteaccess</source>
<translation>Seide Zugang auswählen</translation>
   </message> 
   <message> 
       <source>Set</source>
<translation>Sedzen</translation>
   </message> 
   <message> 
       <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
<translation>VerfÃ¼gbare Werkzeuge fÃ¼r den &lt;%siteaccess&gt; Zugang</translation>
   </message> 
</context>
<context>
<name>design/standard/workflow</name>
   <message> 
       <source>Editing workflow</source>
<translation>Workflow bearbeiden</translation>
   </message> 
   <message> 
       <source>Workflow stored</source>
<translation>Workflow gschbeicherd</translation>
   </message> 
   <message> 
       <source>Data requires fixup</source>
<translation>Dade benödige Anbassung</translation>
   </message> 
   <message> 
       <source>Groups</source>
<translation>Grubben</translation>
   </message> 
   <message> 
       <source>Events</source>
<translation>Ereignisse</translation>
   </message> 
   <message> 
       <source>New</source>
<translation>Nei</translation>
   </message> 
   <message> 
       <source>Remove</source>
<translation>Endfernen</translation>
   </message> 
   <message> 
       <source>Store</source>
<translation>Schbeichern</translation>
   </message> 
   <message> 
       <source>Discard</source>
<translation>Verwerfen</translation>
   </message> 
   <message> 
       <source>on</source>
<translation>am</translation>
   </message> 
   <message> 
       <source>Modified by</source>
<translation>Bearbeided von</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Workflow process</source>
<translation>WorkFlow-Prozess</translation>
   </message> 
   <message> 
       <source>Workflow process was created at</source>
<translation>WorkFlow-Prozess wurd erschdelld am</translation>
   </message> 
   <message> 
       <source>and modified at</source>
<translation>und veränderd am</translation>
   </message> 
   <message> 
       <source>Workflow</source>
<translation>Workflow</translation>
   </message> 
   <message> 
       <source>Using workflow</source>
<translation>Workflow benudzen</translation>
   </message> 
   <message> 
       <source>for processing.</source>
<translation>zur Verarbeidung.</translation>
   </message> 
   <message> 
       <source>User</source>
<translation>Benudzer</translation>
   </message> 
   <message> 
       <source>This workflow is running for user</source>
<translation>Diesr Workflow wird verwended für Benudzer</translation>
   </message> 
   <message> 
       <source>Content object</source>
<translation>Condend-Objekd</translation>
   </message> 
   <message> 
       <source>Workflow was created for content</source>
<translation>Workflow wurd erschdelld für Condend</translation>
   </message> 
   <message> 
       <source>using version</source>
<translation>verwended Version</translation>
   </message> 
   <message> 
       <source>in parent</source>
<translation>in Eldern</translation>
   </message> 
   <message> 
       <source>Workflow event</source>
<translation>Workflow-Ereignis</translation>
   </message> 
   <message> 
       <source>Workflow has not started yet, number of main events in workflow is</source>
<translation>Workflow wurd bishr no nedd gschdarded, Anzahl dr Haubd-Ereignisse im Workflow ischd</translation>
   </message> 
   <message> 
       <source>Current event position is</source>
<translation>Akduelle Ereignis-Posizion ischd</translation>
   </message> 
   <message> 
       <source>Event to be run is</source>
<translation>Ereignis, des gschdarded wird ischd</translation>
   </message> 
   <message> 
       <source>event</source>
<translation>Ereignis</translation>
   </message> 
   <message> 
       <source>Last event returned status</source>
<translation>Schdadus vom ledzde gschdardede Ereignisses</translation>
   </message> 
   <message> 
       <source>Workflow event list</source>
<translation>Worlflow-Ereignislischde</translation>
   </message> 
   <message> 
       <source>Reset</source>
<translation>Zurüggsedzen</translation>
   </message> 
   <message> 
       <source>Next step</source>
<translation>Nächschdr Schridd</translation>
   </message> 
   <message> 
       <source>Workflow event log</source>
<translation>Workflow-Ereignis-Log</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>Description</source>
<translation>Beschreibung</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Information</source>
<translation>Informazion</translation>
   </message> 
   <message> 
       <source>Pos</source>
<translation>Pos</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Workflow groups</source>
<translation>Workflowgrubben</translation>
   </message> 
   <message> 
       <source>New group</source>
<translation>Neie Grubbe</translation>
   </message> 
   <message> 
       <source>Modifier</source>
<translation>Veränderer</translation>
   </message> 
   <message> 
       <source>Modified</source>
<translation>Veränderd</translation>
   </message> 
   <message> 
       <source>New workflow</source>
<translation>Neir Workflow</translation>
   </message> 
   <message> 
       <source>Add group</source>
<translation>Grubb hinzfügen</translation>
   </message> 
   <message> 
       <source>Editing workflow group - %1</source>
<translation>Ãndere Workflowgruppe - %1</translation>
   </message> 
   <message> 
       <source>Modified by %username on %time</source>
<translation>Modfiziert von %username am %time</translation>
   </message> 
   <message> 
       <source>Edit workflow</source>
<translation>Bearbeide Workflow</translation>
   </message> 
   <message> 
       <source>Remove selected workflows</source>
<translation>Lösche dr ausgewählde Workflows</translation>
   </message> 
   <message> 
       <source>Workflow process was created at %creation and modified at %modification.</source>
<translation>Der ausgefÃ¼hrte Workflow wurde erstellt am %creation und modifiziert am %modifiction.</translation>
   </message> 
   <message> 
       <source>Workflows in %1</source>
<translation>Workflow in %1</translation>
   </message> 
   <message> 
       <source>Select gateway</source>
<translation>Gadeway auswählen</translation>
   </message> 
   <message> 
       <source>Select</source>
<translation>Auswählen</translation>
   </message> 
   <message> 
       <source>Cancel</source>
<translation>Abbrechen</translation>
   </message> 
   <message> 
       <source>Additional information</source>
<translation>Weidere Informazionen</translation>
   </message> 
   <message> 
       <source>Input did not validate</source>
<translation>Eingab isch ungüldig</translation>
   </message> 
</context>
<context>
<name>design/standard/workflow/eventtype/edit</name>
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Editor</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Sections</source>
<translation>Sekzionen</translation>
   </message> 
   <message> 
       <source>Users without approval</source>
<translation>Benudzr ohne Beschdädigung</translation>
   </message> 
   <message> 
       <source>Users without workflow IDs</source>
<translation>Benudzr ohne Workflow IDs</translation>
   </message> 
   <message> 
       <source>Class</source>
<translation>Klasse</translation>
   </message> 
   <message> 
       <source>Classes to run workflow</source>
<translation>Klasse um des Workflow durchlaufen</translation>
   </message> 
   <message> 
       <source>Workflow to run</source>
<translation>Workflow zum Schdarden</translation>
   </message> 
   <message> 
       <source>Remove selected</source>
<translation>Endferne Auswahl</translation>
   </message> 
   <message> 
       <source>Load attributes</source>
<translation>Eigenschafde laden</translation>
   </message> 
   <message> 
       <source>Modify publish date</source>
<translation>Ändere Dadum dr Veröffendlichung</translation>
   </message> 
   <message> 
       <source>Add entry</source>
<translation>Eindrag hinzfügen</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Class Attributes</source>
<translation>Klassen-Addribud</translation>
   </message> 
</context>
<context>
<name>design/standard/workflow/eventtype/view</name>
   <message> 
       <source>Editor</source>
<translation>Bearbeider</translation>
   </message> 
   <message> 
       <source>Sections</source>
<translation>Sekzionen</translation>
   </message> 
   <message> 
       <source>Any</source>
<translation>Alle</translation>
   </message> 
   <message> 
       <source>Users without approval</source>
<translation>Benudzr ohne Beschdädigung</translation>
   </message> 
   <message> 
       <source>Classes to run workflow</source>
<translation>Klasse, d den Workflow durchlaufen</translation>
   </message> 
   <message> 
       <source>Users without workflow IDs</source>
<translation>Benudzr ohne Workflow IDs</translation>
   </message> 
   <message> 
       <source>Workflow to run</source>
<translation>Workflow zum Schdarden</translation>
   </message> 
   <message> 
       <source>Type</source>
<translation>Tyb</translation>
   </message> 
   <message> 
       <source>Publish date will be modified.</source>
<translation>Veröffendlichungsdadum wird modifizierd.</translation>
   </message> 
   <message> 
       <source>Publish date will not be modified.</source>
<translation>Veröffendlichungsdadum wird nedd modifizierd.</translation>
   </message> 
</context>
<context>
<name>kernel/cache</name>
   <message> 
       <source>Content view cache</source>
<translation>Ansichdscache</translation>
   </message> 
   <message> 
       <source>Global INI cache</source>
<translation>Globalr INI Cache</translation>
   </message> 
   <message> 
       <source>INI cache</source>
<translation>INI Cache</translation>
   </message> 
   <message> 
       <source>Codepage cache</source>
<translation>Codeseiden-Cache</translation>
   </message> 
   <message> 
       <source>Expiry cache</source>
<translation>Ablaufzeid-Cache</translation>
   </message> 
   <message> 
       <source>Class identifier cache</source>
<translation>Klassen-Idendifikador-Cache</translation>
   </message> 
   <message> 
       <source>Sort key cache</source>
<translation>Sordierschlüssel-Cache</translation>
   </message> 
   <message> 
       <source>URL alias cache</source>
<translation>URL-Alias-Cache</translation>
   </message> 
   <message> 
       <source>Image alias</source>
<translation>Bild-Alias</translation>
   </message> 
   <message> 
       <source>Template cache</source>
<translation>Temblade-Cache</translation>
   </message> 
   <message> 
       <source>Template block cache</source>
<translation>Temblade-Blogg-Cache</translation>
   </message> 
   <message> 
       <source>Template override cache</source>
<translation>Temblade-Überschreib-Cache</translation>
   </message> 
   <message> 
       <source>RSS cache</source>
<translation>RSS Cache</translation>
   </message> 
   <message> 
       <source>Character transformation cache</source>
<translation>Zeichendransformierungs-Cache</translation>
   </message> 
   <message> 
       <source>User info cache</source>
<translation>Benudzerinformazions-Cache</translation>
   </message> 
</context>
<context>
<name>kernel/class</name>
   <message> 
       <source>Class list of group</source>
<translation>Klassenlischde vo Grubbe</translation>
   </message> 
   <message> 
       <source>Class group list</source>
<translation>Klassengrubbenlischde</translation>
   </message> 
   <message> 
       <source>Remove class</source>
<translation>Endferne Klasse</translation>
   </message> 
   <message> 
       <source>Class edit</source>
<translation>Klasse bearbeiden</translation>
   </message> 
   <message> 
       <source>Classes</source>
<translation>Klassen</translation>
   </message> 
   <message> 
       <source>Class list</source>
<translation>Klassenlischde</translation>
   </message> 
   <message> 
       <source>(no classes)</source>
<translation>(koi Klasse)</translation>
   </message> 
   <message> 
       <source>Remove class groups</source>
<translation>Endferne Klasse Grubben</translation>
   </message> 
   <message> 
       <source>You have to have at least one group that the class belongs to!</source>
<translation>Sie müsse mindeschde oi Grubb hend, z dr d Klasse gehörd, hajo, so isch des !</translation>
   </message> 
   <message> 
       <source>Remove classes %class_id</source>
<translation>Klassen %class_id entfernen</translation>
   </message> 
   <message> 
       <source>Copy of %class_name</source>
<translation>Kopie von %class_name</translation>
   </message> 
   <message> 
       <source>The class should have nonempty &apos;Name&apos; attribute.</source>
<translation>Die Klasse sollde koi leers Addribud &apos;Name&apos; hend.</translation>
   </message> 
   <message> 
       <source>The class should have at least one attribute.</source>
<translation>Die Klasse sollde mindeschdens oi Addribud hend.</translation>
   </message> 
   <message> 
       <source>There is a class already having the same identifier.</source>
<translation>Es gibd bereids oi Klasse mid dem Idendifikador.</translation>
   </message> 
</context>
<context>
<name>kernel/class/edit</name>
   <message> 
       <source>New Class</source>
<translation>Neie Klasse</translation>
   </message> 
   <message> 
       <source>new attribute</source>
<translation>Neis Addribud</translation>
   </message> 
</context>
<context>
<name>kernel/class/groupedit</name>
   <message> 
       <source>New Group</source>
<translation>Neie Grubbe</translation>
   </message> 
</context>
<context>
<name>kernel/classe/datatypes/ezbinaryfile</name>
   <message> 
       <source>Failed to store file %filename. Please contact the site administrator.</source>
<translation>Konnte die Datei %filename nicht speichern. Bitten wenden Sie sich an den Administrator.</translation>
   </message> 
</context>
<context>
<name>kernel/classe/datatypes/ezimage</name>
   <message> 
       <source>Failed to fetch Image Handler. Please contact the site administrator.</source>
<translation>Konnde Image-Handlr nedd aufrufe. Bidde wendet Sie si an den Adminischdrador.</translation>
   </message> 
</context>
<context>
<name>kernel/classe/datatypes/ezmedia</name>
   <message> 
       <source>Failed to store media file %filename. Please contact the site administrator.</source>
<translation>Konnte die Medien-Datei %filename nicht speichern. Bitten wenden Sie sich an den Administrator.</translation>
   </message> 
</context>
<context>
<name>kernel/classes</name>
   <message> 
       <source>Approval</source>
<translation>Freigabe</translation>
   </message> 
   <message> 
       <source>Standard</source>
<translation>Schdandard</translation>
   </message> 
   <message> 
       <source>Observer</source>
<translation>Überwacher</translation>
   </message> 
   <message> 
       <source>Owner</source>
<translation>Besidzer</translation>
   </message> 
   <message> 
       <source>Approver</source>
<translation>Freigebender</translation>
   </message> 
   <message> 
       <source>Author</source>
<translation>Author</translation>
   </message> 
   <message> 
       <source>Inbox</source>
<translation>Poschdoigang</translation>
   </message> 
   <message> 
       <source>No state yet</source>
<translation>Noch koi Schdadus</translation>
   </message> 
   <message> 
       <source>Workflow running</source>
<translation>Workflow läufd</translation>
   </message> 
   <message> 
       <source>Workflow done</source>
<translation>Workflow abgeschlossen</translation>
   </message> 
   <message> 
       <source>Workflow failed an event</source>
<translation>Workflow schlug bei oim Vorgang fehl</translation>
   </message> 
   <message> 
       <source>Workflow event deferred to cron job</source>
<translation>Workflowvorgang verlegd zum cro job</translation>
   </message> 
   <message> 
       <source>Workflow was cancelled</source>
<translation>Workflow wurd abgebrochen</translation>
   </message> 
   <message> 
       <source>Workflow was reset for reuse</source>
<translation>Workflow wurd zurügggesedzd zur Wiederverwendung</translation>
   </message> 
   <message> 
       <source>Accepted event</source>
<translation>Angenommens Ereignis</translation>
   </message> 
   <message> 
       <source>Rejected event</source>
<translation>Zurügggewiesens Ereignis</translation>
   </message> 
   <message> 
       <source>Event deferred to cron job</source>
<translation>Ereignis verlegd zum Cro Job</translation>
   </message> 
   <message> 
       <source>Event deferred to cron job, event will be rerun</source>
<translation>Ereignis verlegd zum Cro Job, Evend wird erneid durchlaufen</translation>
   </message> 
   <message> 
       <source>Event runs a sub event</source>
<translation>Ereignis schdarded oi Under-Ereignis</translation>
   </message> 
   <message> 
       <source>Cancelled whole workflow</source>
<translation>Abbruch vom gesamde Workflows</translation>
   </message> 
   <message> 
       <source>Workflow fetches template</source>
<translation>Workflow rufd des Temblade ab</translation>
   </message> 
   <message> 
       <source>Workflow redirects user view</source>
<translation>Workflow leided zur Benudzersichd weider</translation>
   </message> 
   <message> 
       <source>New RSS Export</source>
<translation>Neir RSS-Exbord</translation>
   </message> 
</context>
<context>
<name>kernel/classes/datatypes</name>
   <message> 
       <source>Missing date input.</source>
<translation>Fehlend Dadumsoigab.</translation>
   </message> 
   <message> 
       <source>Missing datetime input.</source>
<translation>Fehlend Zeidoigab.</translation>
   </message> 
   <message> 
       <source>At least one author is required.</source>
<translation>Mindeschdens oi Audor wird benödigd.</translation>
   </message> 
   <message> 
       <source>A valid file is required.</source>
<translation>Eine güldig Dadei wird benödigd.</translation>
   </message> 
   <message> 
       <source>Checkbox</source>
<translation>Cheggbox</translation>
   </message> 
   <message> 
       <source>Enum</source>
<translation>Aufzählung</translation>
   </message> 
   <message> 
       <source>At least one field should be chosen.</source>
<translation>Mindeschdens oi Feld sollde ausgewähld werde.</translation>
   </message> 
   <message> 
       <source>Float</source>
<translation>Fließkommawerd</translation>
   </message> 
   <message> 
       <source>Image</source>
<translation>Bild</translation>
   </message> 
   <message> 
       <source>Integer</source>
<translation>Ganzzahl</translation>
   </message> 
   <message> 
       <source>ISBN</source>
<translation>ISBN</translation>
   </message> 
   <message> 
       <source>Matrix</source>
<translation>Madrix</translation>
   </message> 
   <message> 
       <source>Media</source>
<translation>Media</translation>
   </message> 
   <message> 
       <source>Object relation</source>
<translation>Objekd Relazion</translation>
   </message> 
   <message> 
       <source>Option</source>
<translation>Obzion</translation>
   </message> 
   <message> 
       <source>At least one option is required.</source>
<translation>Mindeschdens oi Obzion wird benödigd.</translation>
   </message> 
   <message> 
       <source>Price</source>
<translation>Preis</translation>
   </message> 
   <message> 
       <source>Add to basket</source>
<translation>Zum Warenkorb hinzfügen</translation>
   </message> 
   <message> 
       <source>Add to wish list</source>
<translation>Zur Wunschlischde hinzfügen</translation>
   </message> 
   <message> 
       <source>Range option</source>
<translation>Werdebereich Obzion</translation>
   </message> 
   <message> 
       <source>Selection</source>
<translation>Selekzion</translation>
   </message> 
   <message> 
       <source>Text line</source>
<translation>Texdzeile</translation>
   </message> 
   <message> 
       <source>Subtree subscription</source>
<translation>Abonemend vom Zweiges</translation>
   </message> 
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>User account</source>
<translation>Benudzer-Kondo</translation>
   </message> 
   <message> 
       <source>A user with this email already exists.</source>
<translation>Ein Benudzr mid von dene E-Mail exischdierd bereids.</translation>
   </message> 
   <message> 
       <source>Object %1 does not exist.</source>
<translation>Objekt %1 existiert nicht.</translation>
   </message> 
   <message> 
       <source>Link %1 does not exist.</source>
<translation>Link %1 existiert nicht.</translation>
   </message> 
   <message> 
       <source>Identifier</source>
<translation>Idendifikador</translation>
   </message> 
   <message> 
       <source>image</source>
<translation>Bild</translation>
   </message> 
   <message> 
       <source>Ini Setting</source>
<translation>Ini Einschdellung</translation>
   </message> 
   <message> 
       <source>Package</source>
<translation>Paked</translation>
   </message> 
   <message> 
       <source>Send</source>
<translation>Senden</translation>
   </message> 
   <message> 
       <source>Missing objectrelation input.</source>
<translation>Angab dr Objekdverknübfung wird vermissch.</translation>
   </message> 
   <message> 
       <source>Invalid time.</source>
<translation>Ungüldig Zeid.</translation>
   </message> 
   <message> 
       <source>The author name must be provided.</source>
<translation>Dr Nam vom Audore muss angegebe werde.</translation>
   </message> 
   <message> 
       <source>The email address is not valid.</source>
<translation>Die E-Mail Adresse isch ungüldich.</translation>
   </message> 
   <message> 
       <source>File uploading is not enabled. Please contact the site administrator to enable it.</source>
<translation>Des Hochlade vo Dadeie isch nedd akdivierd. Kondakdieret Sie den Adminischdrador dr Seide, damid r ihn akdivierd.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.</source>
<translation>Die Größe dr hochgeladene Dadei überschdeigd d Grenze, d durch ubload_max_filesize in dr fb.ini definierd wurd.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded file exceeds the maximum upload size: %1 bytes.</source>
<translation>Die GrÃ¶Ãe der hochgeladenen Datei Ã¼bersteigt die maximale DateigrÃ¶Ãe: %1 bytes.</translation>
   </message> 
   <message> 
       <source>The email address is empty.</source>
<translation>Die E-Mail Adresse isch ler.</translation>
   </message> 
   <message> 
       <source>The given input is not a floating point number.</source>
<translation>Die gmachde Eingab isch koi Fließkommazahl.</translation>
   </message> 
   <message> 
       <source>The input must be greater than %1</source>
<translation>Die Eingabe muss grÃ¶Ãer als %1 sein</translation>
   </message> 
   <message> 
       <source>The input must be less than %1</source>
<translation>Die Eingabe muss kleiner als %1 sein</translation>
   </message> 
   <message> 
       <source>The input is not in defined range %1 - %2</source>
<translation>Die Eingabe ist nicht im erlaubten Bereich von %1 bis %2</translation>
   </message> 
   <message> 
       <source>A valid image file is required.</source>
<translation>Eine güldig Bilddadei wird benödigd.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded image exceeds limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
<translation>Die Größe vom hochgeladene Bilds überschdeigd d Grenze, d durch ubload_max_filesize in dr fb.ini definierd wurd. Bidde kondakdieret Sie den Adminischdradore dr Seide.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
<translation>Die GrÃ¶Ãe der hochgeladenen Datei Ã¼bersteigt die Grenze von:  %1 bytes.</translation>
   </message> 
   <message> 
       <source>Could not locate the ini file.</source>
<translation>Die INI-Dadei konnde nedd lokalisierd werde.</translation>
   </message> 
   <message> 
       <source>The input is not a valid integer.</source>
<translation>Die Eingab isch koi güldig Ganzzahl.</translation>
   </message> 
   <message> 
       <source>The number must be greater than %1</source>
<translation>Die Zahl muss grÃ¶Ãer als %1 sein</translation>
   </message> 
   <message> 
       <source>The number must be less than %1</source>
<translation>Die Zahl muss kleiner als %1 sein.</translation>
   </message> 
   <message> 
       <source>The number is not within the required range %1 - %2</source>
<translation>Die Zahl ist nicht im Bereich von %1 bis %2</translation>
   </message> 
   <message> 
       <source>The ISBN number is not correct. Please check the input for mistakes.</source>
<translation>Die ISBN isch falsch. Bidde überbrüfet Sie d Eingab auf Fehlr.</translation>
   </message> 
   <message> 
       <source>A valid media file is required.</source>
<translation>Es wird oi güldig Mediendadei benödigd.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
<translation>Die Größe dr hochgeladene Dadei überschdeigd d Grenze, d durch ubload_max_filesize in dr Dadei fb.ini gsedzd wurd. Bidde kondakdieret Sie den Adminischdradore dr Seide.</translation>
   </message> 
   <message> 
       <source>The size of the uploaded file exceeds site maximum: %1 bytes.</source>
<translation>Die GrÃ¶Ãe der hochgeladenen Datei Ã¼bersteigt die Grenze von %1 bytes.</translation>
   </message> 
   <message> 
       <source>The option value must be provided.</source>
<translation>Dr Obzionswerd muss angegebe werde.</translation>
   </message> 
   <message> 
       <source>The additional price for the multioption value is not valid.</source>
<translation>Dr angegebene zsädzliche Preis für den Werd dr Mehrfachobzion isch ungüldich.</translation>
   </message> 
   <message> 
       <source>The Additional price value is not valid.</source>
<translation>Dr Werd vom zsädzlile Preiss isch nedd güldich.</translation>
   </message> 
   <message> 
       <source>Input required.</source>
<translation>Eingab nodwendich.</translation>
   </message> 
   <message> 
       <source>The input text is too long. The maximum number of characters allowed is %1.</source>
<translation>Der eingegebene Text ist zu lang. Die maximale Zahl der Zeichen betrÃ¤gt %1.</translation>
   </message> 
   <message> 
       <source>Time input required.</source>
<translation>Eingab dr Zeid nodwendich.</translation>
   </message> 
   <message> 
       <source>The username must be specified.</source>
<translation>Es muss oi Benudzernam angegebe werde.</translation>
   </message> 
   <message> 
       <source>The username already exists, please choose another one.</source>
<translation>Dr Benudzernam exischdierd bereids. Bidde wählet Sie oin andere.</translation>
   </message> 
   <message> 
       <source>The passwords do not match.</source>
<translation>Die Passwördr schdimme nedd überoi.</translation>
   </message> 
   <message> 
       <source>The password must be at least 3 characters long.</source>
<translation>Des Password muss mindeschdens drei Zeile lang soi.</translation>
   </message> 
   <message> 
       <source>Cannot remove the account:</source>
<translation>Des Kondo konnde nedd endfernd werden:</translation>
   </message> 
   <message> 
       <source>The account owner is currently logged in.</source>
<translation>Dr Besidzr vom Kondos isch gerad angemelded.</translation>
   </message> 
   <message> 
       <source>The account is currently used by the anonymous user.</source>
<translation>Des Kondo wird momendan vom anonyme Benudzr verwended.</translation>
   </message> 
   <message> 
       <source>The account is currenty used the administrator user.</source>
<translation>Des Kondo wird momendan vom Adminischdrador dr Seide verwended.</translation>
   </message> 
   <message> 
       <source>You can not remove the last class holding user accounts.</source>
<translation>Sie könne d ledzde Klasse, d Benudzerkondo enthäld, nedd endferne.</translation>
   </message> 
   <message> 
       <source>The link %1 does not exist.</source>
<translation>Der Link %1 existiert nicht.</translation>
   </message> 
   <message> 
       <source>Input required</source>
<translation>Eingab nodwendig</translation>
   </message> 
   <message> 
       <source>Multi-option</source>
<translation>Mehrfachobzion</translation>
   </message> 
   <message> 
       <source>Authors</source>
<translation>Audoren</translation>
   </message> 
   <message> 
       <source>File</source>
<translation>Dadei</translation>
   </message> 
   <message> 
       <source>Date</source>
<translation>Dadum</translation>
   </message> 
   <message> 
       <source>Date and time</source>
<translation>Dadum und Zeid</translation>
   </message> 
   <message> 
       <source>E-mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>Keywords</source>
<translation>Schüsselworder</translation>
   </message> 
   <message> 
       <source>Object relations</source>
<translation>Objekdvernübfungen</translation>
   </message> 
   <message> 
       <source>Text block</source>
<translation>Texdanschnidd</translation>
   </message> 
   <message> 
       <source>Time</source>
<translation>Zeid</translation>
   </message> 
   <message> 
       <source>XML block</source>
<translation>XML Blogg</translation>
   </message> 
   <message> 
       <source>Object %1 can not be embeded to itself.</source>
<translation>Das Objekt %1 kann sich nicht selbst enthalten.</translation>
   </message> 
   <message> 
       <source>Node %1 does not exist.</source>
<translation>Der Knoten %1 existiert nicht.</translation>
   </message> 
   <message> 
       <source>Node &apos;%1&apos; does not exist.</source>
<translation>Der Knoten &apos;%1&apos; existiert nicht.</translation>
   </message> 
   <message> 
       <source>Invalid reference in &lt;embed&gt; tag. Note that &lt;embed&gt; tag supports only &apos;eznode&apos; and &apos;ezobject&apos; protocols.</source>
<translation>Ungüldig Referenz in Bezeichnr &lt;embed&gt;. Beachdet Sie, dess dr Bezeichnr &lt;embed&gt; nur d Prodokolle &apos;eznode&apos; und &apos;ezobjecd&apos; underschdüdzd.</translation>
   </message> 
   <message> 
       <source>No &apos;href&apos; attribute in &apos;embed&apos; tag.</source>
<translation>Koi &apos;href&apos;-Addribud im Bezeichnr &apos;embed&apos;.</translation>
   </message> 
   <message> 
       <source>Date is not valid.</source>
<translation></translation>
   </message> 
</context>
<context>
<name>kernel/collaboration</name>
   <message> 
       <source>Collaboration custom action</source>
<translation>Kollaborazion angebasschde Akzion</translation>
   </message> 
   <message> 
       <source>Collaboration</source>
<translation>Kollaborazion</translation>
   </message> 
</context>
<context>
<name>kernel/content</name>
   <message> 
       <source>Search</source>
<translation>Suchen</translation>
   </message> 
   <message> 
       <source>Advanced</source>
<translation>Fordgeschridden</translation>
   </message> 
   <message> 
       <source>No main node selected, please select one.</source>
<translation>Koi Haubdknode selekdierd, bidde wählet Sie oin aus.</translation>
   </message> 
   <message> 
       <source>Content</source>
<translation>Inhald</translation>
   </message> 
   <message> 
       <source>Copy</source>
<translation>Kobieren</translation>
   </message> 
   <message> 
       <source>My drafts</source>
<translation>Ihre Endwürfe</translation>
   </message> 
   <message> 
       <source>Remove editing version</source>
<translation>Endferne bearbeidede Version</translation>
   </message> 
   <message> 
       <source>Remove object</source>
<translation>Endferne Objekd</translation>
   </message> 
   <message> 
       <source>Tip from %1: %2</source>
<translation>Tipp von %1: %2</translation>
   </message> 
   <message> 
       <source>The email address of the sender is not valid</source>
<translation>Die E-Mailadresse vom Senders isch nedd güldig</translation>
   </message> 
   <message> 
       <source>The email address of the receiver is not valid</source>
<translation>Die E-Mailadresse vom Embfängers isch nedd güldig</translation>
   </message> 
   <message> 
       <source>Tip a friend</source>
<translation>Tibb an oin Freind</translation>
   </message> 
   <message> 
       <source>Translate</source>
<translation>Übersedzen</translation>
   </message> 
   <message> 
       <source>Translation</source>
<translation>Übersedzung</translation>
   </message> 
   <message> 
       <source>Content translations</source>
<translation>Übersedzunge vom Inhalds</translation>
   </message> 
   <message> 
       <source>Trash</source>
<translation>Abfalleimer</translation>
   </message> 
   <message> 
       <source>Versions</source>
<translation>Versionen</translation>
   </message> 
   <message> 
       <source>My bookmarks</source>
<translation>Moi Lesezeichen</translation>
   </message> 
   <message> 
       <source>My pending list</source>
<translation>Moi Wardelside</translation>
   </message> 
   <message> 
       <source>URL translator</source>
<translation>URL Übersedzer</translation>
   </message> 
   <message> 
       <source>Keywords</source>
<translation>Schüsselworder</translation>
   </message> 
   <message> 
       <source>Media</source>
<translation>Medien</translation>
   </message> 
   <message> 
       <source>New content</source>
<translation>Neir Inhald</translation>
   </message> 
   <message> 
       <source>Remove location</source>
<translation>Ord endfernen</translation>
   </message> 
   <message> 
       <source>You are not allowed to place this object under: %1</source>
<translation>Sie dÃ¼rfen das Objekt hier nicht plazieren: %1</translation>
   </message> 
   <message> 
       <source>Top Level Nodes</source>
<translation>Knode dr oberschde Ebene</translation>
   </message> 
   <message> 
       <source>Hidden</source>
<translation>Verschdeggd</translation>
   </message> 
   <message> 
       <source>Hidden by superior</source>
<translation>Vom übergeordnede Elemend verschdeggd</translation>
   </message> 
   <message> 
       <source>Visible</source>
<translation>Sichdbar</translation>
   </message> 
   <message> 
       <source>Copy Subtree</source>
<translation>Teil dr Baumschdrukdur kobieren</translation>
   </message> 
   <message> 
       <source>The receiver has already received the maximimum number of tipafriend mails the last hours</source>
<translation>Dr Embfangr hedd bereids d maximale Anzahl vo Embfehlungsnachrichde in dr ledzde Schdund bekommen</translation>
   </message> 
</context>
<context>
<name>kernel/content/copysubtree</name>
   <message> 
       <source>Object (ID = %1) was not copied: you don&apos;t have permissions to read object.</source>
<translation>Objekt (ID = %1) wurde nicht kopiert: Sie haben keinen lesenden Zugriff auf das Objekt.</translation>
   </message> 
   <message> 
       <source>Node (ID = %1) was not copied: you don&apos;t have permissions to read object (ID = %2).</source>
<translation>Knoten (ID = %1) wurde nicht kopiert: Sie haben keine Leserechte auf das Objekt (ID = %2).</translation>
   </message> 
   <message> 
       <source>Node (ID = %1) wasn&apos;t copied: parent node (ID = %2) wasn&apos;t copied.</source>
<translation>Knoten (ID = %1) wurde nicht kopiert: Der Elternknoten (ID = %2) wurde nicht kopiert.</translation>
   </message> 
   <message> 
       <source>Node (ID = %1) was not copied: you don&apos;t have permissions to create.</source>
<translation>Knoten (ID = %2) wurde nicht kopiert: Sie haben keine Rechte etwas zu erstellen.</translation>
   </message> 
   <message> 
       <source>Object (ID = %1) was not copied: no one nodes of object wasn&apos;t copied.</source>
<translation>Objekt (ID = %1) wurde nicht kopiert: Keiner der Knoten des Objekts wurde kopiert.</translation>
   </message> 
   <message> 
       <source>Cannot publish object (ID = %1).</source>
<translation>Objekt (ID = %1) konnte nicht verÃ¶ffentlicht werden.</translation>
   </message> 
   <message> 
       <source>Fatal error: cannot get subtree main node (ID = %1).</source>
<translation>Schwerer Fehler: Hauptknoten (ID = %1) konnte nicht nicht geholt werden.</translation>
   </message> 
   <message> 
       <source>Fatal error: cannot get destination node (ID = %1).</source>
<translation>Schwerer Fehler: Zielknoten (ID = %1) konnte nicht geholt werden.</translation>
   </message> 
   <message> 
       <source>Number of nodes of source subtree - %1</source>
<translation>Anzahl der Knoten des Quellbaums - %1</translation>
   </message> 
   <message> 
       <source>Subtree was not copied.</source>
<translation>Dr Teil dr Baumschdrukdur wurd nedd kobierd.</translation>
   </message> 
   <message> 
       <source>Number of copied nodes - %1</source>
<translation>Anzahl der kopierten Knoten - %1</translation>
   </message> 
   <message> 
       <source>Number of copied contentobjects - %1</source>
<translation>Anzahl der kopierten Objekte - %1</translation>
   </message> 
   <message> 
       <source>Cannot create instance of eZDB to fix local links (related objects).</source>
<translation>Konnde koi Inschdanz vo eZDB erschdelle, um d lokale Links (verknübfde Objekde) z rebarieren</translation>
   </message> 
   <message> 
       <source>Successfuly DONE.</source>
<translation>Erfolgreich erledigd.</translation>
   </message> 
   <message> 
       <source>You are trying to copy a subtree that contains more than the maximum possible nodes for subtree copying. You can copy this subtree using Subtree Copy script.</source>
<translation>Sie versuche oin Teil dr Baumschdrukdur kobiere, dr mehr Knode enthäld als kobierd werde könne. Sie könne dis kobiere, indem Sie des Scribd zum Kobiere vo Teile dr Baumschdrukdur benudze.</translation>
   </message> 
</context>
<context>
<name>kernel/content/removenode</name>
   <message> 
       <source>child</source>
<translation>Kind</translation>
   </message> 
   <message> 
       <source>children</source>
<translation>Kinder</translation>
   </message> 
</context>
<context>
<name>kernel/content/upload</name>
   <message> 
       <source>The file %filename does not exist, cannot insert file.</source>
<translation>Die Datei %filename existiert nicht. Die Datei konnte nicht eingefÃ¼gt werden.</translation>
   </message> 
   <message> 
       <source>No matching class identifier found.</source>
<translation>Koi bassendr Klassenidendifikador funde.</translation>
   </message> 
   <message> 
       <source>The class %class_identifier does not exist.</source>
<translation>Die Klasse %class_identifier existiert nicht.</translation>
   </message> 
   <message> 
       <source>Was not able to figure out placement of object.</source>
<translation>Nedd in dr Lag gwese, herauszfinde wo des Objekd blazierd werde soll.</translation>
   </message> 
   <message> 
       <source>No configuration group in upload.ini for class identifier %class_identifier.</source>
<translation>Keine Konfigurationsgruppe in upload.ini fÃ¼r Klassenidentifikator %class_identifier vorhanden.</translation>
   </message> 
   <message> 
       <source>No matching file attribute found, cannot create content object without this.</source>
<translation>Koi bassends Dadeiaddribud funde. Ohne dis kann koi Objekd erschdelld werde.</translation>
   </message> 
   <message> 
       <source>No matching name attribute found, cannot create content object without this.</source>
<translation>Koi bassens Addribuade für den name funde. Ohne dis kann koi Objekd erschdelld werde.</translation>
   </message> 
   <message> 
       <source>The attribute %class_identifier does not support regular file storage.</source>
<translation>Das Attribut %class_identifier unterstÃ¼tzt keine regulÃ¤re Dateiaufbewahrung.</translation>
   </message> 
   <message> 
       <source>The attribute %class_identifier does not support simple string storage.</source>
<translation>Das Attribut %class_identifier unterstÃ¼tzt die Ablage von einfachen Zeichenketten nicht.</translation>
   </message> 
   <message> 
       <source>The attribute %class_identifier does not support HTTP file storage.</source>
<translation>Das Attribut %class_identifier unterstÃ¼tzt keine HTTP-Dateiablage.</translation>
   </message> 
   <message> 
       <source>Publishing of content object was halted.</source>
<translation>Die Veröffendlichung vom Objekds wurd angehalde.</translation>
   </message> 
   <message> 
       <source>Publish process was cancelled.</source>
<translation>Dr Prozess dr Veröffendlichung wurd abgebrole.</translation>
   </message> 
   <message> 
       <source>A file is required for upload, no file were found.</source>
<translation>Es wird oi Dadei für den Ubload benödigd. Es wurd abr koi funde.</translation>
   </message> 
   <message> 
       <source>Expected a eZHTTPFile object but got nothing.</source>
<translation>Es wurd oi eZHTTPFile-Objekd erwarded. Es wurd abr überhaubd nix glieferd.</translation>
   </message> 
   <message> 
       <source>No HTTP file found, cannot fetch uploaded file.</source>
<translation>Koi HTTP-Dadei funde. Die hochgeladene Dadei konnde nedd erfassch werde.</translation>
   </message> 
   <message> 
       <source>Permission denied</source>
<translation>Zugriff verweigerd</translation>
   </message> 
   <message> 
       <source>There was an error trying to instantiate content upload handler.</source>
<translation>Es gab oin Fehlr, als des Schdeierungschbrogramm für des Hochlade vo Inhalde aufgerufe wurd.</translation>
   </message> 
   <message> 
       <source>Could not find content upload handler &apos;%handler_name&apos;</source>
<translation>Das Steuerungsprogramm &apos;%handler_name&apos; fÃ¼r das Hochladen von Inhalten konnte nicht gefunden werden</translation>
   </message> 
</context>
<context>
<name>kernel/contentclass</name>
   <message> 
       <source>New %1</source>
<translation>Neue/er/es %1</translation>
   </message> 
   <message> 
       <source>Cannot remove class &apos;%class_name&apos;:</source>
<translation>Klasse &apos;%class_name&apos; kann nicht entfernt werden:</translation>
   </message> 
   <message> 
       <source>The class is used by a top-level node and cannot be removed.</source>
<translation>Die Klasse wird vo oim Knode dr oberschde Ebene verwended und kann dahr nedd endfernd werde.</translation>
   </message> 
</context>
<context>
<name>kernel/design</name>
   <message> 
       <source>Template list</source>
<translation>Temblade Lischde</translation>
   </message> 
   <message> 
       <source>Template view</source>
<translation>Temblade Sichd</translation>
   </message> 
   <message> 
       <source>Create new template</source>
<translation>Erschdelle neis Temblade</translation>
   </message> 
   <message> 
       <source>Template edit</source>
<translation>Temblade bearbeiden</translation>
   </message> 
   <message> 
       <source>Toolbar list</source>
<translation>Toolbar-Lischde</translation>
   </message> 
</context>
<context>
<name>kernel/error</name>
   <message> 
       <source>Error</source>
<translation>Fehler</translation>
   </message> 
</context>
<context>
<name>kernel/ezinfo</name>
   <message> 
       <source>Info</source>
<translation>Info</translation>
   </message> 
   <message> 
       <source>About</source>
<translation>Über</translation>
   </message> 
   <message> 
       <source>Copyright</source>
<translation>Cobyrighd</translation>
   </message> 
</context>
<context>
<name>kernel/form</name>
   <message> 
       <source>Form processing</source>
<translation>Formularverarbeidung</translation>
   </message> 
</context>
<context>
<name>kernel/infocollector</name>
   <message> 
       <source>Collected information</source>
<translation>Gesammelde Informazionen</translation>
   </message> 
</context>
<context>
<name>kernel/navigationpart</name>
   <message> 
       <source>Content structure</source>
<translation>Navigazionschdeil</translation>
   </message> 
   <message> 
       <source>Media library</source>
<translation>Medien-Bibliothek</translation>
   </message> 
   <message> 
       <source>User accounts</source>
<translation>Benudzerkonden</translation>
   </message> 
   <message> 
       <source>Webshop</source>
<translation>Web-Shob</translation>
   </message> 
   <message> 
       <source>Design</source>
<translation>Design</translation>
   </message> 
   <message> 
       <source>Setup</source>
<translation>Sedub</translation>
   </message> 
   <message> 
       <source>My account</source>
<translation>Moi Kondo</translation>
   </message> 
</context>
<context>
<name>kernel/notification</name>
   <message> 
       <source>Notification settings</source>
<translation>Benachrichdigungsoischdellungen</translation>
   </message> 
</context>
<context>
<name>kernel/package</name>
   <message> 
       <source>Packages</source>
<translation>Pakede</translation>
   </message> 
   <message> 
       <source>Upload</source>
<translation>Hochladen</translation>
   </message> 
   <message> 
       <source>Package information</source>
<translation>Paked Informazionen</translation>
   </message> 
   <message> 
       <source>Package maintainer</source>
<translation>Paked Bedreier</translation>
   </message> 
   <message> 
       <source>Package changelog</source>
<translation>Pagged Logbuch</translation>
   </message> 
   <message> 
       <source>Package thumbnail</source>
<translation>Paked Skizierung</translation>
   </message> 
   <message> 
       <source>Package name</source>
<translation>Pakedname</translation>
   </message> 
   <message> 
       <source>Package name is missing</source>
<translation>Pakednam fehld</translation>
   </message> 
   <message> 
       <source>A package named %packagename already exists, please give another name</source>
<translation>Ein Packet mit dem Namen %packagename existiert bereits, bitte geben Sie einen anderen Namen an</translation>
   </message> 
   <message> 
       <source>Summary</source>
<translation>Zusammenfassung</translation>
   </message> 
   <message> 
       <source>Summary is missing</source>
<translation>Zusammenfassung fehld</translation>
   </message> 
   <message> 
       <source>Version</source>
<translation>Version</translation>
   </message> 
   <message> 
       <source>Name</source>
<translation>Name</translation>
   </message> 
   <message> 
       <source>You must enter a name for the changelog</source>
<translation>Sie müsse oin Name für des Logbuch angeben</translation>
   </message> 
   <message> 
       <source>E-Mail</source>
<translation>E-Mail</translation>
   </message> 
   <message> 
       <source>You must enter an e-mail for the changelog</source>
<translation>Sie müsse oi E-Mail Adresse für des Logbuch oigeben</translation>
   </message> 
   <message> 
       <source>Changelog</source>
<translation>Logbuch</translation>
   </message> 
   <message> 
       <source>You must supply some text for the changelog entry</source>
<translation>Sie müsse oin Texd für den Logbuch Eindrag hinderlassen</translation>
   </message> 
   <message> 
       <source>You must enter a name of the maintainer</source>
<translation>Sie müsse den Name vom Bedreiers angeben</translation>
   </message> 
   <message> 
       <source>You must enter an e-mail address of the maintainer</source>
<translation>Sie müsse d E-Mail Adresse vom Bedreiers anbeben</translation>
   </message> 
   <message> 
       <source>Content classes to include</source>
<translation>Condend Klasse zur Aufnahm</translation>
   </message> 
   <message> 
       <source>Content class export</source>
<translation>Condend Klasse Exbord</translation>
   </message> 
   <message> 
       <source>Class list</source>
<translation>Klassenlischde</translation>
   </message> 
   <message> 
       <source>You must select at least one class for inclusion</source>
<translation>Sie müsse mindeschdens oi Klasse zur Aufnahm auswählen</translation>
   </message> 
   <message> 
       <source>CSS file</source>
<translation>CSS Dadei</translation>
   </message> 
   <message> 
       <source>Image files</source>
<translation>Bilder</translation>
   </message> 
   <message> 
       <source>Site style</source>
<translation>Seidenschdil</translation>
   </message> 
   <message> 
       <source>File did not have a .css suffix, this is most likely not a CSS file</source>
<translation>Die Dadei hedd koi .css Endung, dis wird wahrschoilich koi CSS Dadei soi</translation>
   </message> 
   <message> 
       <source>Content class %classname (%classidentifier)</source>
<translation>Content Klasse %classname (%classidentifier)</translation>
   </message> 
   <message> 
       <source>Create package</source>
<translation>Erschdelle Paked</translation>
   </message> 
   <message> 
       <source>Install</source>
<translation>Inschdallieren</translation>
   </message> 
   <message> 
       <source>Uninstall</source>
<translation>Doischdallieren</translation>
   </message> 
   <message> 
       <source>Package %packagename already exists, cannot import the package</source>
<translation>Paket %packagename existier bereits, kann Paket nicht importieren</translation>
   </message> 
   <message> 
       <source>Local</source>
<translation>Lokal</translation>
   </message> 
   <message> 
       <source>Styles</source>
<translation>Schdile</translation>
   </message> 
   <message> 
       <source>Addons</source>
<translation>Erweiderungen</translation>
   </message> 
   <message> 
       <source>The version must only contain numbers (optionally followed by text) and must be delimited by dots (.), e.g. 1.0, 3.4.0beta1</source>
<translation>Die Versio darf nur Zahle enthalde (obdinal folgd vo dexd) und muss mid Punkde (.) abgegrenzd soi. Beischbiele: 1.0, 3.4.0beda1</translation>
   </message> 
   <message> 
       <source>Content objects to include</source>
<translation>Inhaldsobjekde zum Einschließen</translation>
   </message> 
   <message> 
       <source>Content object limits</source>
<translation>Limidierunge vo Inhaldsobjekden</translation>
   </message> 
   <message> 
       <source>Content object export</source>
<translation>Exbord vo Inhaldsobjekden</translation>
   </message> 
   <message> 
       <source>Selected nodes</source>
<translation>Ausgewählde Knoden</translation>
   </message> 
   <message> 
       <source>You must select one or more node(s)/subtree(s) for export.</source>
<translation>Sie müsse oin odr mehrere Konden/Teil(e) dr Bauschdrukdur zum Exbord auswähle.</translation>
   </message> 
   <message> 
       <source>You must choose one or more languages.</source>
<translation>Sie müsse oi odr mehrere Schbrache auswähle.</translation>
   </message> 
   <message> 
       <source>You must choose one or more site access.</source>
<translation>Sie müsse oin odr mehrere Seidenzugäng auswähle.</translation>
   </message> 
   <message> 
       <source>CSS files</source>
<translation>CSS-Dadeien</translation>
   </message> 
   <message> 
       <source>You must upload both CSS files</source>
<translation>Sie müsse beid CSS-Dadeie hochladen</translation>
   </message> 
   <message> 
       <source>Content object %objectname</source>
<translation>Inhaltsobjekte %objectname</translation>
   </message> 
   <message> 
       <source>Site access mapping</source>
<translation>Zuordnung dr Seidenzugriffe</translation>
   </message> 
   <message> 
       <source>Top node placements</source>
<translation>Plazierunge auf oberschde Knoden</translation>
   </message> 
   <message> 
       <source>Content object import</source>
<translation>Imbord vo Inhaldsobjekden</translation>
   </message> 
   <message> 
       <source>Select parent nodes</source>
<translation>Eldernknode auswählen</translation>
   </message> 
   <message> 
       <source>You must assign all nodes to new parent nodes.</source>
<translation>Sie müsse alle Knode neie Eldernknode zuordne.</translation>
   </message> 
   <message> 
       <source>Lead</source>
<translation>Führung</translation>
   </message> 
   <message> 
       <source>Developer</source>
<translation>Endwiggler</translation>
   </message> 
   <message> 
       <source>Designer</source>
<translation>Designer</translation>
   </message> 
   <message> 
       <source>Contributor</source>
<translation>Midwirkender</translation>
   </message> 
   <message> 
       <source>Tester</source>
<translation>Teschder</translation>
   </message> 
   <message> 
       <source>The package name %packagename is not valid, it can only contain characters in the range a-z, 0-9 and underscore.</source>
<translation>Der Paketname %packagename ist nicht gÃ¼ltig. Er kann nur Zeichen von a-z, 0-9 und Unterstriche enthalten.</translation>
   </message> 
</context>
<context>
<name>kernel/pdf</name>
   <message> 
       <source>PDF Export</source>
<translation>PDF Exbord</translation>
   </message> 
</context>
<context>
<name>kernel/pdfexport</name>
   <message> 
       <source>New PDF Export</source>
<translation>Neir PDF-Exbord</translation>
   </message> 
</context>
<context>
<name>kernel/reference</name>
   <message> 
       <source>Reference documentation</source>
<translation>Referenz Dokumendazion</translation>
   </message> 
</context>
<context>
<name>kernel/role</name>
   <message> 
       <source>Role list</source>
<translation>Rollen-Lischde</translation>
   </message> 
   <message> 
       <source>Editing policy</source>
<translation>Edidiere Richdlinie</translation>
   </message> 
   <message> 
       <source>Limit on section</source>
<translation>Auf Sekzion oischränken</translation>
   </message> 
   <message> 
       <source>Create new policy, step 2: select function</source>
<translation>Neie Richdlinie erschdelle, Schridd 2: Funkzion wählen</translation>
   </message> 
   <message> 
       <source>Create new policy, step three: set function limitations</source>
<translation>Neie Richdlinie erschdelle, Schridd 3: Funkzions-Einschränkunge wählen</translation>
   </message> 
   <message> 
       <source>Create new policy, step two: select function</source>
<translation>Neie Richdlinie erschdelle, Schridd 2: Funkzion wählen</translation>
   </message> 
   <message> 
       <source>Create new policy, step one: select module</source>
<translation>Neie Richdlinie erschdelle, Schridd 1: Modul wählen</translation>
   </message> 
</context>
<context>
<name>kernel/role/edit</name>
   <message> 
       <source>New role</source>
<translation>Neie Rolle</translation>
   </message> 
   <message> 
       <source>Copy of %rolename</source>
<translation>Kopie von %rolename</translation>
   </message> 
</context>
<context>
<name>kernel/rss</name>
   <message> 
       <source>Really Simple Syndication</source>
<translation>Really Simble Syndicazion</translation>
   </message> 
   <message> 
       <source>New RSS Export</source>
<translation>Neir PDF-Exbord</translation>
   </message> 
   <message> 
       <source>New RSS Import</source>
<translation>Neir PDF-Imbord</translation>
   </message> 
</context>
<context>
<name>kernel/search</name>
   <message> 
       <source>Search stats</source>
<translation>Suchschdadischdiken</translation>
   </message> 
</context>
<context>
<name>kernel/section</name>
   <message> 
       <source>Edit Section</source>
<translation>Ändere Sekzion</translation>
   </message> 
   <message> 
       <source>Sections</source>
<translation>Sekzionen</translation>
   </message> 
   <message> 
       <source>View section</source>
<translation>Sekzion ansehen</translation>
   </message> 
   <message> 
       <source>New section</source>
<translation>Neie Sekzion</translation>
   </message> 
</context>
<context>
<name>kernel/setup</name>
   <message> 
       <source>Cache admin</source>
<translation>Cache Adminischdrazion</translation>
   </message> 
   <message> 
       <source>System information</source>
<translation>Syschdeminformazionen</translation>
   </message> 
   <message> 
       <source>Rapid Application Development</source>
<translation>Schnelle Anwendungs-Endwigglung</translation>
   </message> 
   <message> 
       <source>Template operator wizard</source>
<translation>Temblade-Oberadoren-Assischden</translation>
   </message> 
   <message> 
       <source>Extension configuration</source>
<translation>Erweiderung oischdellen</translation>
   </message> 
   <message> 
       <source>Setup menu</source>
<translation>Sedub Menü</translation>
   </message> 
   <message> 
       <source>Session admin</source>
<translation>Session-Verwaldung</translation>
   </message> 
   <message> 
       <source>System Upgrade</source>
<translation>Syschdem Ubgrade</translation>
   </message> 
   <message> 
       <source>File %1 does not exist. You should copy it from the recent eZ Publish distribution.</source>
<translation>Die Datei %1 existiert nicht. Sie sollten sie von einer aktuellen eZ Publish-Distribution kopieren.</translation>
   </message> 
   <message> 
       <source>Datatype wizard</source>
<translation>Dadendyb-Assischdend</translation>
   </message> 
</context>
<context>
<name>kernel/shop</name>
   <message> 
       <source>Basket</source>
<translation>Einkaufskorb</translation>
   </message> 
   <message> 
       <source>Checkout</source>
<translation>Kasse</translation>
   </message> 
   <message> 
       <source>Confirm order</source>
<translation>Beschdellung beschdädigen</translation>
   </message> 
   <message> 
       <source>Discount group</source>
<translation>Ermäßigungsgrubbe</translation>
   </message> 
   <message> 
       <source>Group view of discount rule</source>
<translation>Grubbe Sichd auf Ermäßigungs-Regeln</translation>
   </message> 
   <message> 
       <source>Editing rule</source>
<translation>Richdlinie bearbeiden</translation>
   </message> 
   <message> 
       <source>Order list</source>
<translation>Beschdelllischde</translation>
   </message> 
   <message> 
       <source>Enter account information</source>
<translation>Eingab dr Kondoinformazionen</translation>
   </message> 
   <message> 
       <source>VAT types</source>
<translation>MwSchd Tyben</translation>
   </message> 
   <message> 
       <source>Customer list</source>
<translation>Kunden-Lischde</translation>
   </message> 
   <message> 
       <source>Statistics</source>
<translation>Schdadischdik</translation>
   </message> 
   <message> 
       <source>Remove order</source>
<translation>Beschdellung endfernen</translation>
   </message> 
   <message> 
       <source>VAT type</source>
<translation>MwSchd-Tyb</translation>
   </message> 
   <message> 
       <source>Classes</source>
<translation>Klassen</translation>
   </message> 
   <message> 
       <source>Any class</source>
<translation>Irgendoi Klasse</translation>
   </message> 
   <message> 
       <source>in sections</source>
<translation>in Sekzionen</translation>
   </message> 
   <message> 
       <source>in any section</source>
<translation>In irgendoir Sekzion</translation>
   </message> 
   <message> 
       <source>Products</source>
<translation>Produkde</translation>
   </message> 
   <message> 
       <source>Any product</source>
<translation>Irgendoi Produkd</translation>
   </message> 
   <message> 
       <source>Order status</source>
<translation>Beschdellschdadus</translation>
   </message> 
   <message> 
       <source>Undefined</source>
<translation>Undefinierd</translation>
   </message> 
   <message> 
       <source>The confirm order operation was canceled. Try to checkout again.</source>
<translation>Die Beschdädigung dr Beschdellung wurd abgebrole. Versuchet Sie erneid zur Kasse z gehe.</translation>
   </message> 
   <message> 
       <source>Order #%order_id</source>
<translation>Bestellung #%order_id</translation>
   </message> 
   <message> 
       <source>New order status was successfully added.</source>
<translation>Dr neie Beschdellschdadus wurd erfolgreich hinzugefügd.</translation>
   </message> 
   <message> 
       <source>Changes to order status were successfully stored.</source>
<translation>Ändrunge am Beschdellschdadus wurde erfolgreich gschbeicherd.</translation>
   </message> 
   <message> 
       <source>Selected order statuses were successfully removed.</source>
<translation>Die Auswahl wurd erfolgreich endfernd</translation>
   </message> 
   <message> 
       <source>Internal orders cannot be removed.</source>
<translation>Inderne Beschdellunge könne nedd endfernd werde.</translation>
   </message> 
   <message> 
       <source>Status</source>
<translation>Schdadus</translation>
   </message> 
   <message> 
       <source>Customer order view</source>
<translation>Ansichd vo Kundenbeschdellungen</translation>
   </message> 
</context>
<context>
<name>kernel/shop/discountgroup</name>
   <message> 
       <source>New discount group</source>
<translation>Neie Ermäßigungsgrubbe</translation>
   </message> 
   <message> 
       <source>New Discount Rule</source>
<translation>Neie Ermäßigungsregel</translation>
   </message> 
</context>
<context>
<name>kernel/trigger</name>
   <message> 
       <source>Trigger</source>
<translation>Trigger</translation>
   </message> 
   <message> 
       <source>List</source>
<translation>Lischde</translation>
   </message> 
</context>
<context>
<name>kernel/url</name>
   <message> 
       <source>URL</source>
<translation>URL</translation>
   </message> 
   <message> 
       <source>List</source>
<translation>Lischde</translation>
   </message> 
   <message> 
       <source>View</source>
<translation>Sichd</translation>
   </message> 
   <message> 
       <source>URL edit</source>
<translation>URL ändern</translation>
   </message> 
</context>
<context>
<name>kernel/user</name>
   <message> 
       <source>User</source>
<translation>Benudzer</translation>
   </message> 
   <message> 
       <source>Login</source>
<translation>Login</translation>
   </message> 
   <message> 
       <source>Change password</source>
<translation>Password ändern</translation>
   </message> 
   <message> 
       <source>Register</source>
<translation>Regischdrieren</translation>
   </message> 
   <message> 
       <source>Forgot password</source>
<translation>Password vergessen</translation>
   </message> 
</context>
<context>
<name>kernel/user/register</name>
   <message> 
       <source>Registration info</source>
<translation>Regischdrazionsinformazionen</translation>
   </message> 
   <message> 
       <source>New user registered</source>
<translation>Neir Benudzr regischdierd</translation>
   </message> 
</context>
<context>
<name>kernel/workflow</name>
   <message> 
       <source>Edit workflow</source>
<translation>Bearbeide Workflow</translation>
   </message> 
   <message> 
       <source>Workflow</source>
<translation>Workflow</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
   <message> 
       <source>Edit workflow group</source>
<translation>Bearbeide Workflowgrubbe</translation>
   </message> 
   <message> 
       <source>Group edit</source>
<translation>Grubb bearbeiden</translation>
   </message> 
   <message> 
       <source>Workflow group list</source>
<translation>Workflowgrubbenlischde</translation>
   </message> 
   <message> 
       <source>Group list</source>
<translation>Grubbenlischde</translation>
   </message> 
   <message> 
       <source>Workflow list</source>
<translation>Workflowlischde</translation>
   </message> 
   <message> 
       <source>Workflow list of group</source>
<translation>Workflowlischde dr Grubbe</translation>
   </message> 
   <message> 
       <source>List</source>
<translation>Lischde</translation>
   </message> 
   <message> 
       <source>View</source>
<translation>Ansehen</translation>
   </message> 
   <message> 
       <source>You have to have at least one group that the workflow belongs to!</source>
<translation>Sie müsse mindeschde oi Grubb hend, z dr dr Workflow gehörd, hajo, so isch des !</translation>
   </message> 
</context>
<context>
<name>kernel/workflow/edit</name>
   <message> 
       <source>New Workflow</source>
<translation>Neir Workflow</translation>
   </message> 
</context>
<context>
<name>kernel/workflow/event</name>
   <message> 
       <source>Event</source>
<translation>Ereignis</translation>
   </message> 
   <message> 
       <source>Approve</source>
<translation>Freigeben</translation>
   </message> 
   <message> 
       <source>Multiplexer</source>
<translation>Muldiblexer</translation>
   </message> 
   <message> 
       <source>Simple shipping</source>
<translation>Einfachr Versand</translation>
   </message> 
   <message> 
       <source>Wait until date</source>
<translation>Bis Dadum warden</translation>
   </message> 
   <message> 
       <source>Payment Gateway</source>
<translation>Zahlungs-Gadeway</translation>
   </message> 
</context>
<context>
<name>kernel/workflow/group</name>
   <message> 
       <source>Group</source>
<translation>Grubbe</translation>
   </message> 
</context>
<context>
<name>kernel/workflow/groupedit</name>
   <message> 
       <source>New WorkflowGroup</source>
<translation>Neie Workflow-Grubbe</translation>
   </message> 
</context>
<context>
<name>lib/ezpdf/classes</name>
   <message> 
       <source>Contents</source>
<translation>Inhalde</translation>
   </message> 
   <message> 
       <source>Index</source>
<translation>Index</translation>
   </message> 
</context>
<context>
<name>lib/eztemplate</name>
   <message> 
       <source>Some template errors occured, see debug for more information.</source>
<translation>Einig Temblade Fehlr sind aufgedrede, sehet Sie in d Buglischde für mehr Informazione.</translation>
   </message> 
</context>
<context>
<name>lib/template</name>
   <message> 
       <source>The maximum nesting level of 40 has been reached. The execution is stopped to avoid infinite recursion.</source>
<translation>Die maximale Verschachdelung vo 40 Ebene wurd erreichd. Die Ausführung wurd angehalde, um oi unendliche Rekursio z vermeide.</translation>
   </message> 
</context>
<context>
<name>pdf/edit</name>
   <message> 
       <source>PDF Export</source>
<translation>PDF Exbord</translation>
   </message> 
</context>
<context>
<name>settings/edit</name>
   <message> 
       <source>Settings</source>
<translation>Einschdellungen</translation>
   </message> 
   <message> 
       <source>Edit</source>
<translation>Bearbeiden</translation>
   </message> 
</context>
<context>
<name>settings/view</name>
   <message> 
       <source>Settings</source>
<translation>Einschdellungen</translation>
   </message> 
   <message> 
       <source>View</source>
<translation>Sichd</translation>
   </message> 
</context>
<context>
<name>shop</name>
   <message> 
       <source>Remove orders</source>
<translation>Beschdellung endfernen</translation>
   </message> 
</context>
<context>
<name>simplified_treemenu/show_simplified_menu</name>
   <message> 
       <source>Node ID: %node_id Visibility: %visibility</source>
<translation>Knoten ID: %node_id Sichtbarkeit: %visibility</translation>
   </message> 
</context>
</TS>