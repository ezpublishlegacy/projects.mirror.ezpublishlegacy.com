special translation for a south german dialect:


1. download and extract the ger-SCHWOB package
   
2. move the ger-SCHWOB.ini to
   EZ_PUBLISH_ROOT/share/locale/
   
3. create the directory 
   EZ_PUBLISH_ROOT/share/translations/ger-SCHWOB/
   and copy the translation.ts into it
   
4. configure your admin-siteaccess to use the locale "ger-SCHWOB"
   EZ_PUBLISH_ROOT/settings/siteaccess/<admin-site>/site.ini.append.php
   
   the modified site.ini should look like this:
   
   ...
   [RegionalSettings]
   Locale=ger-SCHWOB
   ContentObjectLocale=ger-DE
   TextTranslation=enabled
   ...
   
5. done! easy huh?
   now enjoy this fine schwaebisch-translation


silver.solutions gmbh, berlin
2006 - www.silversolutions.de
