<?php
/**
 * @package nxcCaptcha
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    13 Sep 2011
 **/

return array (
	'nxcCaptcha' => './classes/captcha.php'
);
?>
