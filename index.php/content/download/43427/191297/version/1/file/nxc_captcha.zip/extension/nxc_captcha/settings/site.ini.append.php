<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=nxc_captcha

[RoleSettings]
PolicyOmitList[]=nxc_captcha/get
*/ ?>
