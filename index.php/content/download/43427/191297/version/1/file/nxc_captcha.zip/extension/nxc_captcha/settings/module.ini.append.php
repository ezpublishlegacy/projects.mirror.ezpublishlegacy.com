<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=nxc_captcha
ModuleList[]=nxc_captcha
*/ ?>
