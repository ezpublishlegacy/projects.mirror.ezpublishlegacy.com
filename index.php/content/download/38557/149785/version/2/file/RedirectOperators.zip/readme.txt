*************************************************************************
**  Redirect operators  *************************************************
*************************************************************************

Use these operators when you need to perform a URL redirect from within a
template. The operators will send an HTTP header 301 Moved Permanently to
the browser.


Installation instructions
-------------------------
1. If it does not exist, create a directory named "extension" in the base
   ezpublish directory.

2. Unpack the ZIP file and copy the directory "RedirectOperators" to the
   extension directory.

3. Add the following to your settings/override/site.ini.append.php file:
   [ExtensionSettings]
   ActiveExtensions[]=RedirectOperators
   
4. Clear the caches.

5. Ready to go!


Usage
-----
From within a template, write:

  {redirectrelative( '<relative URI>' )} 

  for instance: {redirectrelative( '/path/to/file.php' )}

or

  {redirectabsolute( '<absolute URI>' )}
  
  for instance: {redirectabsolute( 'http://www.google.com' )}



Hope you find it useful! And if you know a better way to do the same, please
post a comment for this contribution.

Best,
Esben Visfeldt

--------------------------------------------------
 The mandatory disclaimer: use at your own risk! 
--------------------------------------------------