<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ggwebservices

[RegionalSettings]
TranslationExtensions[]=ggwebservices

# To allow calls to the exposed webservices
# from external (non-ajax) webservice clients
# that cannot use a session cookie,
# uncomment the folllwoing line:
[RoleSettings]
PolicyOmitList[]=webservices/execute

*/ ?>