<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ggwebservices

[CronjobPart-rotatewslogs]
Scripts[]=rotatewslogs.php

*/ ?>
