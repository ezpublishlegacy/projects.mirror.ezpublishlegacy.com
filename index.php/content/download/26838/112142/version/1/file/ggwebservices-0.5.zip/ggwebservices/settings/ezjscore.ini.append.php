<?php /*

[ezjscServer_ggwstemplate]
TemplateFunction=true

*/ ?>