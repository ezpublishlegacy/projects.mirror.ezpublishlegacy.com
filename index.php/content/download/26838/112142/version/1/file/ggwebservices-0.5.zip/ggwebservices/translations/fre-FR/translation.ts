<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Webservices Debugger</source>
        <comment>Navigation part</comment>
        <translation>Debogueur Webservices</translation>
    </message>
</context>
<context>
    <name>extension/ggwebservices</name>
    <message>
        <source>WS Debugger</source>
        <translation>Debogueu WS</translation>
    </message>
    <message>
        <source>Local server</source>
        <translation>Serveur local</translation>
    </message>
    <message>
        <source>Remote servers</source>
        <translation>Serveurs distants</translation>
    </message>
</context>
</TS>