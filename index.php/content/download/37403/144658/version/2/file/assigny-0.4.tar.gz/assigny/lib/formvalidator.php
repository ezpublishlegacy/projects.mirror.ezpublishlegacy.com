<?php
//
// Class for validating form data
// Copyright (C) <2005>  <Melonfire> <http://www.melonfire.com/contact/>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

// class definition
// class encapsulating data validation functions
class formValidator {

    // define properties
    var $_errorList;

    // define methods
    // constructor
    function formValidator() {
        $this->resetErrorList();
    }

    // initialize error list
    function resetErrorList() {
        $this->_errorList = array();
    }

    // check whether input is empty
    function isEmpty($value) {
        return (!isset($value) || trim($value) == '') ? true : false;
    }

    // check whether input is a string
    function isString($value) {
        return is_string($value);
    }

    // check whether input is a number
    function isNumber($value) {
        return is_numeric($value);
    }

    // check whether input is an integer
    function isInteger($value) {
        return (intval($value) == $value) ? true : false;
    }

    // check whether input is alphabetic
    function isAlpha($value) {
        return preg_match('/^[a-zA-Z ]+$/', $value);
    }

    // check whether input is within a numeric range
    function isWithinRange($value, $min, $max) {
        return (is_numeric($value) && $value >= $min && $value <= $max) ? true : false;
    }
    
    // check whether input is a valid email address
    function isEmailAddress($value) {
        return eregi('^([a-z0-9])+([\.a-z0-9_-])*@([a-z0-9_-])+(\.[a-z0-9_-]+)*\.([a-z]{2,6})$', $value);
    }

    // check if a value exists in an array
    function isInArray($array, $value) {
        return in_array($value, $array);
    }

    // add an error to the error list
    function addError($field, $message) {
        $this->_errorList[] = array('field' => $field, 'message' => $message);
    }

    // check if errors exist in the error list
    function isError() {
        return (sizeof($this->_errorList) > 0) ? true : false;
    }

    // return the error list to the caller
    function getErrorList() {
        return $this->_errorList;
    }
// end class definition
}
?>
