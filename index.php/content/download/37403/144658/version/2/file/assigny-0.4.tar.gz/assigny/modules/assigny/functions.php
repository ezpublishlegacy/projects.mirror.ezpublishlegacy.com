<?php
//
// Functions shared by different moduleviews
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

function storeFileAssignment ($fileID)
{
	include_once( 'classes/assignmentsdb.php' );
	
	$selectedNodeIDArray = eZContentBrowse::result( 'AssignyPlace' );
	
	if ( is_array($selectedNodeIDArray) )
	{
		// foreach node id write an db entry
		foreach ($selectedNodeIDArray as $rootNode)
		{
			$assigndb =& AssignmentsDB::create();
		
			$assigndb->setAttribute( 'file_id', $fileID);
			$assigndb->setAttribute( 'root_node', $rootNode );
			$assigndb->store();
		}
	}
	return ;
}

function buildFilePath()
{
	include_once( 'lib/ezutils/classes/ezini.php' );
	include_once( 'kernel/common/eztemplatedesignresource.php' );
	include_once('extension/assigny/lib/nwoerror.php');
	
	$ini =& eZINI::instance( 'assigny.ini' );
	// retrieve the path to the ezpublish folder
	eZSys::init( eZINI::instance() );
	$siteDir = eZSys::siteDir();
	// get the name of the current design directory
	$designDir = eZTemplateDesignResource::designSetting('site');
	// get the user specified part of the path
	if ( $ini->hasVariable('FileSettings', 'UploadLocation') )
	{
		$loc = $ini->variable('FileSettings', 'UploadLocation');
	}
	else
	{
		return new nwoError( 40 );
	}
	
	return ($siteDir.'design/'.$designDir.'/'.$loc);
}
?>
