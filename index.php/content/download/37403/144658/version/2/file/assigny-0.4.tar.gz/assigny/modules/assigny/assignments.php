<?php
//
// The 'manage' view of the assigny module
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

include_once( "kernel/classes/ezcontentbrowse.php" );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( "lib/ezutils/classes/ezini.php" );

include_once( "kernel/common/template.php" );

include_once( 'functions.php' );
include_once( 'classes/filesdb.php' );
include_once( 'classes/assignmentsdb.php' );
include_once( 'extension/assigny/lib/tplerror.php' );
include_once( 'extension/assigny/lib/formvalidator.php' );

$tpl =& templateInit();
$http =& eZHTTPTool::instance();
$err = new tplError();

/* BBP */
// write assignment to db
if ( $Module->isCurrentAction( 'AssignyPlace' ) )
{
	if ( !$http->hasPostVariable( 'BrowseCancelButton' ) )
	{
		$fileID = $http->sessionVariable( 'assigny_file_id' );
		if ( formValidator::isInteger($fileID) )
		{
			storeFileAssignment($fileID);
		}
	}
	$http->removeSessionVariable( 'assigny_file_id' );
}

// show content/browse for making assignmet
if ( $Module->isCurrentAction( 'Assign' ) )
{
	if ( $Module->hasActionParameter('FileID') )
	{
		$file_id = $Module->actionParameter('FileID');
		if ( formValidator::isInteger($file_id) )
		{
			$http->setSessionVariable( 'assigny_file_id', $file_id );

			// now send them to browse
			eZContentBrowse::browse( array( 'action_name' => 'AssignyPlace',
        		                                    'description_template' => 'design:assigny/browse_place.tpl',
        		                                    'content' => array(),
        		                                    'from_page' => '/assigny/assignments/',
        		                                    'cancel_page' => '/assigny/assignments/' ),
        		                             $Module );
        		return;
        	}
        }
        else
        {
        	$err->setError( 3, 'IMG');
        }
}
/* END BBP */

/* REMOVE ASSIGNMENT */
// no module used here, because i need the array
if ( $http->hasPostVariable( 'RemoveButton' ) )
{
	if ( $http->hasPostVariable('assign_id_array') )
	{
		$AssignIDArray = $http->postVariable('assign_id_array');
		foreach ( $AssignIDArray as $id )
		{
			AssignmentsDB::removeObject(AssignmentsDB::definition(),
						array( 'id' => $id) );
		}
	}
	else {
		$err->setError( 3, 'ASS');
	}
}

// build the list with assignments
$map = AssignmentsDB::fetchList();

$assignments = array();
$i = 0;
foreach ($map as $row)
{
	// get name of file
	$file = FilesDB::fetch($row->FileID);
	$assignments[$i]['file_name'] = $file->Name;
	$assignments[$i]['id'] = $row->ID;
	// get name of root node
	$node = eZContentObjectTreeNode::fetch($row->RootNode);
	$assignments[$i]['node_name'] = $node->ContentObject->Name;
	
	$i++;
}

// fetch all files from db
$map = FilesDB::fetchList(false);

// show template
$tpl->setVariable( 'errors', $err->getErrors() );
$tpl->setVariable( 'assignments', $assignments  );
$tpl->setVariable( 'files', $map  );
$tpl->setVariable( 'nav_part', 1  );
$Result = array();
$Result['pagelayout'] = 'assigny/as_pagelayout.tpl';
$Result['content'] = $tpl->fetch('design:assigny/assign.tpl');
?>
