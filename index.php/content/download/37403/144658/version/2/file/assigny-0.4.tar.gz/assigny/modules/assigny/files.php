<?php
//
// The remove view of the assigny module
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php');
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

include_once( 'classes/assignmentsdb.php' );
include_once( 'classes/filesdb.php' );
include_once( 'extension/assigny/lib/formvalidator.php' );
include_once( 'functions.php' );

// error handling
include_once( 'extension/assigny/lib/tplerror.php' );

$tpl =& templateInit();
$http =& eZHTTPTool::instance();
$err = new tplError();

/* CN */

/* Change name of file */
if ( $Module->isCurrentAction( 'ChangeName' ) )
{
	if ( $Module->hasActionParameter('FileID') )
	{
		// get the old name from db and write it to the form for convenience
		$fileID = $Module->actionParameter('FileID');
		$file = FilesDB::fetch( $fileID );
		$http->setSessionVariable( 'assigny_file_id', $fileID );
		$tpl->setVariable( 'old_name', $file->Name );
		$tpl->setVariable( 'nav_part', 2  );
		$Result = array();
		$Result['pagelayout'] = 'assigny/as_pagelayout.tpl';
		$Result['content'] = $tpl->fetch('design:assigny/change_name.tpl');
	
		return ;
	}
	else
	{
		$err->setError( 3, 'MAN');
	}
}

if ( $Module->isCurrentAction( 'UpdateName' ) )
{
	$file_id = $http->sessionVariable( 'assigny_file_id' );
	$name = $Module->actionParameter('Name');
	if ( formValidator::isAlpha($name) && formValidator::isInteger($file_id) )
	{
		FilesDB::updateName($file_id, $name);
	}
	else
	{
		$err->setError( 1, 'GEN');
		$tpl->setVariable( 'errors', $err->getErrors() );
		$tpl->setVariable( "nav_part", 2  );
		$Result = array();
		$Result['pagelayout'] = 'assigny/as_pagelayout.tpl';
		$Result['content'] = $tpl->fetch("design:assigny/change_name.tpl");
		
		return ;
	}
	$http->removeSessionVariable( 'assigny_file_id' );
}
/* END CN */

// Make Default
if ( $Module->isCurrentAction( 'MakeDefault' ) )
{
	if ( $Module->hasActionParameter('FileID') )
	{
		$file_id = $Module->actionParameter('FileID');
		if ( formValidator::isInteger($file_id) )
		{
			FilesDB::makeDefault( $file_id );
		}
	} 
	else
	{
		$err->setError( 3, 'MAN');
	}
}

// remove file
// no module used here, because i need the array
if ( $http->hasPostVariable( 'RemoveButton' ) )
{
	if ( $http->hasPostVariable('file_id_array') )
	{
		$fileIDArray = $http->postVariable('file_id_array');
		
		foreach ( $fileIDArray as $fileID )
		{
			// first delete all assignmets belonging to this file
			AssignmentsDB::removeObject(AssignmentsDB::definition(),
						array( 'file_id' => $fileID) );
	
			// now delete the file from db ...
			$file = FilesDB::fetch( $fileID ); // just want the path
			FilesDB::removeObject(FilesDB::definition(),
						array( 'id' => $fileID) );

			// ... and from the filesystem
			// read full file path from ini
			$ini =& eZINI::instance( 'assigny.ini' );

			if ( $ini->hasVariable( 'FileSettings', 'UploadLocation' ) )
			{
				$filePath = buildFilePath();
				$filename = substr(strrchr($file->Path, "/"), 1);
				$filepath = $filePath.$filename;
				if ( !$result = @unlink($filepath) )
				{
					$err->setError( 41, 'DEL', array($file->Name) );
				}
			}
			else 
			{
				$err->setError( 40, 'DEL' );
			}
		}
	}
	else
	{
		$err->setError( 3, 'DEL');
	}
}

// fetch all files from db
$map = FilesDB::fetchList(false);

// show template
$tpl->setVariable( 'errors', $err->getErrors() );
$tpl->setVariable( 'files', $map );
$tpl->setVariable( 'nav_part', 2 );
$Result = array();
$Result['pagelayout'] = 'assigny/as_pagelayout.tpl';
$Result['content'] = $tpl->fetch( 'design:assigny/files.tpl' );
?>
