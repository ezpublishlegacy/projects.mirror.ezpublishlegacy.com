<?php
//
// Definition of the fetch functions
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'extension/assigny/lib/xss.php' );
include_once( 'classes/assignmentsdb.php' );
include_once( 'classes/filesdb.php' );
include_once( 'functions.php' );
include_once( 'lib/eztemplate/classes/eztemplatemultipassparser.php' );

class assignyFunctionCollection
{
	function assignyFunctionCollection() {}
	function fetchFile($node_id = 0)
	{
		$ini =& eZINI::instance( 'assigny.ini' );

		// fetch all start_nodes from db
		$map = AssignmentsDB::fetchList(false);
		
		$file_id = 0; // just for sure
		if ($node_id > 0) // saves some trouble 
		{
			// get the parent to which node belongs
			$parent_node = $node_id;
			do
			{
				foreach ($map as $row)
				{
         				if ($row['root_node'] == $parent_node)
         				{	
               					$file_id = $row['file_id'];
               					break 2; // could save some time when arrays get bigger
               				}
				}
				// important that this is at the end
				// else in the case of current node == start_node will never match
				$parent_node = eZContentObjectTreeNode::getParentNodeId($parent_node);
			} while ($parent_node > 1); // the parent of 1 is 1, forever ... (how evil)

		}
		// now get the file path and alt
		if ($file_id) // get it from db
		{
			$file = FilesDB::fetch($file_id);
			$path = $file->Path;
			$name = $file->Name;
		}
		else // get the default file
		{
			$file = FilesDB::fetchDefault();
			$path = $file->Path;
			$name = $file->Name;
		}
		
		// now check if the content or the path should be returned
		// get allowed mime types from ini
		$filePath = buildFilePath();
		$content = null;
		if ( get_class($filePath) != 'nwoerror' )
		{
			if ( $ini->hasVariable( 'MimeTypes', 'ReturnContents' ) )
			{
				// variableArray returns an 2-D array
				$MimeTypes = array();
				$MimeTypeArray = $ini->variableArray( 'MimeTypes', 'ReturnContents' );
				foreach ($MimeTypeArray as $MimeType)
				{
					$MimeTypes[] = trim($MimeType[0]);
				}
				// get the file contents
				$Filename = substr(strrchr($path, "/"), 1);
				if ( in_array(mime_content_type($filePath.$Filename), $MimeTypes) )
				{
					// run it through the template parser
					include_once( "kernel/common/template.php" );
					$tpl =& templateInit();
					$content = $tpl->fetch($filePath.$Filename);
					// run some xss cleaning
					//$content = file_get_contents($filePath.$Filename);
					$content = xss::basicClean($content);
				}
			}
		}
		else
		{
			/* include here because of some stupid scoe issues */
			include_once( 'extension/assigny/lib/errortypes.php' );
			eZDebug::writeError( $errorTypes[40] );
		}
		
		return array('result' => array('path' => $path,
					       'content' => $content,
					       'name' => $name));
	}
}
?>
