<?php
//
// The upload view of the assigny module
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

include_once( 'kernel/classes/ezcontentbrowse.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'kernel/common/template.php' );

include_once( 'extension/assigny/lib/httpupload.php' );
include_once( 'extension/assigny/lib/formvalidator.php' );
include_once( 'functions.php' );

include_once( 'classes/filesdb.php' );
include_once( 'extension/assigny/lib/tplerror.php' );

$tpl =& templateInit();
$http =& eZHTTPTool::instance();
$err = new tplError();

// START: Read ini values
$ini =& eZINI::instance( 'assigny.ini' );

// MaxFileSize
if ( $ini->hasVariable( 'FileSettings', 'MaxFileSize' ) )
{
	$max_file_size = $ini->variable('FileSettings', 'MaxFileSize');
} else {
	// set it to a conservative value
	$max_file_size = 10000;
}

// UploadLocation
$upload_location = null;
$result = buildFilePath();
if ( get_class($result) != 'nwoerror' )
{
	$upload_location = $result;
} else
{
	$err->setError( $result->getError(), 'GEN', $result->getParams() );
}
// END: Read ini values

// we know placement(s), write it to db
if ( $Module->isCurrentAction( 'AssignyPlace' ) )
{
	if ( $http->hasPostVariable( 'BrowseCancelButton' ) )
	{
		$fileID = $http->sessionVariable( 'assigny_file_id' );
		if ( formValidator::isInteger($fileID) )
		{
			storeFileAssignment($fileID);
		}
	}
	$http->removeSessionVariable( 'assigny_file_id' );
}

// upload the file
if ( $Module->isCurrentAction('Upload') && (!is_null($upload_location)) )
{
	// get the name for the file
	$name = $Module->actionParameter('Name');
	if (formValidator::isAlpha($name))
	{
		// get allowed mime types from ini
		if ( $ini->hasVariable( 'MimeTypes', 'AllowedMimeTypes' ) )
		{
			// variableArray returns an 2-D array
			$MimeTypes = array();
			$MimeTypeArray = $ini->variableArray( 'MimeTypes', 'AllowedMimeTypes' );
			foreach ($MimeTypeArray as $MimeType)
			{
				$MimeTypes[] = trim($MimeType[0]);
			}
		}
		else
		{
			$MimeTypes = null;
		}
		
		// now here comes code which handles upload
		$file = new upload($MimeTypes, $max_file_size, $upload_location);
		$result = $file->putFile('assigny_file');

		// if upload was successful, add it to db
		if ( get_class($result) != 'nwoerror' )
		{
			$filesdb =& FilesDB::create();

			$filesdb->setAttribute( 'name', $name);
			// split off everything before image, to make it conform with every server
			$filesdb->setAttribute( 'path', stristr($result, 'images') );
			$filesdb->store();
			$file_id = $filesdb->attribute('id');
		
			$http->setSessionVariable( 'assigny_file_id', $file_id );

			// now send them to browse
			 eZContentBrowse::browse( array( 'action_name' => 'AssignyPlace',
        	                                    'description_template' => 'design:assigny/browse_place.tpl',
        	                                    'content' => array(),
        	                                    'from_page' => '/assigny/upload/',
        	                                    'cancel_page' => '/assigny/upload/' ),
        	                             $Module );
        	    	return ;
        	}
        	else
        	{
        		$err->setError( $result->getError(), 'GEN', $result->getParams() );
        	}
	}
	else
	{
		$err->setError( 1, 'GEN');
	}
}

// show template
$tpl->setVariable( 'errors', $err->getErrors() );
$tpl->setVariable( 'max_file_size', $max_file_size );
$tpl->setVariable( 'nav_part', 0  );
$Result = array();
$Result['pagelayout'] = 'assigny/as_pagelayout.tpl';
$Result['content'] =& $tpl->fetch('design:assigny/upload.tpl');
$Result['path'] = array( array( 'url' => '/assigny/upload/',
                                'text' => ezi18n( 'extension/assigny', 'Assigny Upload' ) ));
?>
