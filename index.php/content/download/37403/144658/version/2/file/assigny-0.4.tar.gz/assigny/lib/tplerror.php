<?php
//
// Class for setting errors and writing them to templates
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

class tplError {
	
	/**
	* array containing the errors
	*/
	var $errorStack = array();
	
	/**
	* variable holding the error types
	*/
	var $errorTypes = array();	
	
	/**
	* !public
	*/
	function tplError () 
	{
		// i include it here because of scope issues
		include_once('extension/assigny/lib/errortypes.php');
		$this->errorTypes = $errorTypes;
	}
	
	/**
	* set an tpl variable containing the error and type
	* !public
	*/
	function setError ($id, $type, $params = null)
	{
		$this->errorStack[] = array('msg' => $this->errorTypes[$id], 'type' => $type, 'params' => $params );
	}
	
	/**
	* return the stack
	* !public
	*/
	function getErrors ()
	{
		if ( is_array($this->errorStack) )
			return $this->errorStack;
		else 
			return 0;
	}
}
?>
