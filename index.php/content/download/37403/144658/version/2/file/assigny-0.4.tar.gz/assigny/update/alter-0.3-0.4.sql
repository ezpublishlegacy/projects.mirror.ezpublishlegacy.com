RENAME TABLE banner_images TO assigny_files;
RENAME TABLE banner_assign TO assigny_assignments;
ALTER TABLE assigny_assignments CHANGE COLUMN image_id file_id int;
ALTER TABLE assigny_assignments CHANGE COLUMN start_node root_node int;
