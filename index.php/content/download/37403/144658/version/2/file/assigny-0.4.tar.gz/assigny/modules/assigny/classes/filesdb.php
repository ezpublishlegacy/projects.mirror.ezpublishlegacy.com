<?php
//
// Definition of the banner_images Table and Functions
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

include_once( "kernel/classes/ezpersistentobject.php" );

class FilesDB extends eZPersistentObject
{
    /*!
    */
    function FilesDB( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function &definition()
    {
        return array( "fields" => array( "id" => array( 'name' => 'ID',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),
                                         "name" => array( 'name' => "Name",
                                                          'datatype' => 'varchar',
                                                          'default' => '',
                                                          'required' => true ),
                                         "path" => array( 'name' => "Path",
                                                          'datatype' => 'varchar',
                                                          'default' => '',
                                                          'required' => true ),
                                         "is_default" => array( 'name' => 'IsDefault',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),),
                      "keys" => array( "id" ),
                      "increment_key" => "id",
                      "class_name" => "FilesDB",
                      "name" => "assigny_files" );
    }

	// 'Get' an image (well not really)
	function &fetch( $id, $asObject = true )
	{
		return eZPersistentObject::fetchObject( FilesDB::definition(),
                                                null,
                                                array( "id" => $id
                                                      ),
                                                $asObject );
	}
	
	// Get everything
	function &fetchList( $asObject = true )
	{
		return eZPersistentObject::fetchObjectList( FilesDB::definition(),
                                                null,
                                                null,
                                                null,
                                                null,
                                                $asObject );
	}
       
	// update name of image
	function updateName ( $id, $name )
	{
 		$db =& eZDB::instance();
        	$query = 'UPDATE  assigny_files  SET name = \''. $name .'\' WHERE id = ' . $id;
        	$db->query( $query );
	}
       
	// fetch the default file
	function &fetchDefault ( $asObject = true ) 
	{
		return eZPersistentObject::fetchObject( FilesDB::definition(),
                                                null,
                                                array( 'is_default' => '1'
                                                      ),
                                                $asObject );
	}
       
	// set the default image
	function makeDefault ( $id )
	{
		$db =& eZDB::instance();
		// make the chosen one 1
		$query = 'UPDATE assigny_files SET is_default = \'1\' WHERE id = ' .$id;
		$db->query( $query );
		// reset the others to 0
		$query = 'UPDATE assigny_files SET is_default = \'0\' WHERE id != ' .$id;
		$db->query( $query );
	}
       
	// add a new image
	function &create()
	{
		$row = array(
		'id' => null,
		'name' => null,
		'path' => null,
		'is_default' => null);
		return new FilesDB( $row );
	}
}
?>
