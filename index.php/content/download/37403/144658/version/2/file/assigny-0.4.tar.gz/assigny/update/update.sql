DROP TABLE IF EXISTS assigny_files;
CREATE TABLE assigny_files (
 id INT(11) NOT NULL AUTO_INCREMENT,
 name VARCHAR(255) NOT NULL,
 path VARCHAR(255) NOT NULL,
 is_default INT(1) DEFAULT '0',
 PRIMARY KEY (id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS assigny_assignments;
CREATE TABLE assigny_assignments (
 id INT(11) NOT NULL AUTO_INCREMENT,
 file_id INT(11) NOT NULL,
 root_node INT(11) NOT NULL,
 PRIMARY KEY (id) 
) TYPE=MyISAM;
