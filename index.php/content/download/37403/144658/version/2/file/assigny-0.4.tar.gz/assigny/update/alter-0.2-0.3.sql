ALTER TABLE banner_images ADD is_default INT(1) DEFAULT '0';
