<?php
//
// Definition of error messages
// Copyright (C) <2005>  <Bernhard Reiter> <bhishmaparva@gmail.com>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

// < 10 = general errors (like in forms)
// < 20 = upload errors
// < 30 = assignment errors
// < 40 = image errors
$errorTypes = array(
		// General Errors
		1 => 'Please Enter only the following characters: A-Z and spaces',
		2 => 'Something went wrong with your form submission ... unexpected values',
		3 => 'Could not determine which file you chose. Probably you forgot to do it. Use the Radio Buttons for this',
		// Upload Errors
		20 => 'This file type is not permitted',
		21 => 'File size error',
		22 => 'File is not uploaded correctly',
		23 => 'Impossible to copy file to destination directory',
		24 => 'Please specify an Path where the file should be uploaded to',
		// Image Errors
		40 => 'Could not get Filepath from INI.',
		41 => 'Could not remove File. Perhaps it is still in use, or has the wrong permissions set'
);
?>
