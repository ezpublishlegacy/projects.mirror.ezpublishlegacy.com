<?php
include_once( "kernel/common/template.php" );
include_once( "kernel/classes/ezcontentobjecttreenode.php");

$module=&$Params['Module'];
$http = eZHTTPTool::instance();
$tpl =& templateInit();

$order='';
$counter='';
$node_id='';

//Get parameters
if ($http->hasPostVariable( 'OrderUpButton' ))
{
	$order = true;
}
if ($http->hasPostVariable( 'OrderDownButton' ))
{
	$order = false;
}
if ($http->hasPostVariable( 'Counter' ))
{
	$counter = $http->postVariable( 'Counter' );
	$counter++;
}
if ($http->hasPostVariable( 'NodeID' ))
{
	$node_id = $http->postVariable( 'NodeID' );
}
if ($http->hasPostVariable( 'RedirectURIAfterUpdateOrder' ))
{
	$redirect_uri_after_update_order = $http->postVariable( 'RedirectURIAfterUpdateOrder' );
}

//Get children
$children = eZContentObjectTreeNode::subtree(array('SortBy' =>  array( 'priority', true )), $node_id);

//Set the priority to something different than 0 (default)
foreach ($children as $i => $child)
{
	if ($i+1!=$child->attribute('priority'))
	{
		print("Le noeud na pas la bonne priorite de base.<br/>");
		$child->setAttribute('priority', $i+1);
		$child->store();
	}
	$prio[$child->attribute('priority')]=$child;
}
//Set the order
if ($order)
{
	$counter2=$counter-1;
}
else
{
	$counter2=$counter+1;
}
//Swap the priority
$first=$prio[$counter];
$second=$prio[$counter2];

$p_first = $first->attribute('priority');
$p_second = $second->attribute('priority');

$first->setAttribute('priority', $p_second);
$second->setAttribute('priority', $p_first);

$first->store();
$second->store();

//print("AVANT = de $p_first vers $p_second<br/>");
//print("APRES = de ".$first->attribute('priority')." vers ".$second->attribute('priority')."<br/>");

//Redirect
$module->redirectTo($redirect_uri_after_update_order);

?>