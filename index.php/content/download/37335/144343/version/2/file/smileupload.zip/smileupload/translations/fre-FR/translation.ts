<!DOCTYPE TS><TS>
<context>
	<name>design/smileupload/upload</name>
	<message>
		<source>Upload</source>
		<translation>Envoyer des fichiers sur le serveur</translation>	
	</message>
	<message>
		<source>Your browser does not support applets. Or you have disabled applet in your options. To use this applet, please install the newest version of Sun's java. You can get it from java.com.</source>
		<translation>Votre navigateur ne supporte pas les applets. Ou bien vous avez désactivé les applets dans vos options. Pour utiliser cet applet, installez la dernière version de Java de Sun. Elle est disponible sur java.com.</translation>	
	</message>
	<message>
		<source>Create the content</source>
		<translation>Créer le contenu</translation>	
	</message>
</context>
<context>
	<name>design/admin/edit</name>
	<message>
		<source>Manage pictures</source>
		<translation>Gérer les images</translation>	
	</message>
	<message>
		<source>Place before.</source>
		<translation>Placer avant.</translation>	
	</message>
	<message>
		<source>Place after.</source>
		<translation>Placer après.</translation>	
	</message>
	<message>
		<source>Remove.</source>
		<translation>Supprimer.</translation>	
	</message>
	<message>
		<source>Add several images.</source>
		<translation>Ajouter plusieurs images.</translation>	
	</message>
	<message>
		<source>There are no images in this diaporama. You can add several images by clicking on the Add button.</source>
		<translation>Il n'y aucune image dans ce diaporama. Vous pouvez ajouter des images en cliquant sur le bouton Ajouter.</translation>	
	</message>
</context>
</TS>