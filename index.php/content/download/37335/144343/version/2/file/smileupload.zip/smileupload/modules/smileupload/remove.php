<?php
include_once( "kernel/common/template.php" );

$module=&$Params['Module'];
$http = eZHTTPTool::instance();
$tpl =& templateInit();

$deleteIDArray=array();
$confirm=false;
$cancel=false;
$redirect_uri_after_remove='smilegame/menu';
$no_remove_confirm=0;

if ($http->hasPostVariable( 'DeleteIDArray' ))
{
	$deleteIDArray = $http->postVariable( "DeleteIDArray" );
}
if ($http->hasPostVariable('RedirectURIAfterRemove'))
{
	$redirect_uri_after_remove=$http->postVariable('RedirectURIAfterRemove');
}
if ($http->hasPostVariable('NoConfirmRemove'))
{
	$no_remove_confirm=$http->postVariable('NoConfirmRemove');
}

if ($http->hasPostVariable('ConfirmButton'))
{
	$confirm=true;
}
elseif ($http->hasPostVariable('CancelButton'))
{
	$cancel=true;
}

if (count($deleteIDArray)!=0 and (($confirm and !$cancel) or $no_remove_confirm))
{
	//Confirmation
	$moveToTrash=false;
	eZContentObjectTreeNode::removeSubtrees( $deleteIDArray, $moveToTrash );
	//$http->removeSessionVariable( "DeleteIDArray" );
	$module->redirectTo( $redirect_uri_after_remove) ;
}
elseif (count($deleteIDArray)==0 and $no_remove_confirm!=0)
{
	$module->redirectTo( $redirect_uri_after_remove) ;
}
elseif ($cancel)
{
	//Cancel
	$module->redirectTo($redirect_uri_after_remove);
}
?>