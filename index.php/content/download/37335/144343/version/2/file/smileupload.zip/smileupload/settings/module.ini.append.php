<?php /* #?ini charset="iso-8859-1"?
[ModuleSettings]
ExtensionRepositories[]=smileupload
*/
?>
