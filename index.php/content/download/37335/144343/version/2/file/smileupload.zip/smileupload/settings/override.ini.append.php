<?php /* #?ini charset="utf-8"?

[edit_diaporama]
Source=content/edit.tpl
MatchFile=content/edit_diaporama.tpl
Subdir=templates
Match[class_identifier]=diaporama

*/ ?>