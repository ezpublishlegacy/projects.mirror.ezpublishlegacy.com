<?php
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php');
include_once( "lib/ezlocale/classes/ezdatetime.php");
$module =& $Params['Module'];
$http =& eZHTTPTool::instance();

/****************************************************/
/*                DEBUT DES FONCTIONS               */
/****************************************************/

function create($class_id, $param, $user_id)
{
	$parent_node_id = $param['parent_node_id'];
	$attributs = $param['attributs'];

	$node = & eZContentObjectTreeNode :: fetch($parent_node_id);
	$ob=$node->object();
	$section = $ob->attribute('section_id');

	if ($node) {
	//if (false) {	
		$class = eZContentClass :: fetch($class_id);
		$contentObject = & $class->instantiate($user_id, $section);
		$contentObject->setAttribute('created', eZDateTime::currentTimeStamp() );
		$contentObject->setAttribute('modified', eZDateTime::currentTimeStamp() );

		$contentObject->store();
		$nodeAssignment = & eZNodeAssignment :: create(array ('contentobject_id' => $contentObject->attribute('id'), 'contentobject_version' => $contentObject->attribute('current_version'), 'parent_node' => $node->attribute('node_id'), 'sort_field' => 2, 'sort_order' => 0, 'is_main' => 1));

		$nodeAssignment->store();
		$version = & $contentObject->version(1);
		$version->setAttribute('status', EZ_VERSION_STATUS_DRAFT);
		$version->setAttribute('created', eZDateTime::currentTimeStamp() );
		$version->setAttribute('modified', eZDateTime::currentTimeStamp() );
		$version->store();

		$version = & $contentObject->attribute('current');
		$contentObjectAttributes = & $version->contentObjectAttributes();

		//Integration des attributs
		foreach ($contentObjectAttributes as $contentObjectAttribute)
		{
			foreach($attributs as $key => $attribut)
			{
				if ($contentObjectAttribute->attribute('contentclass_attribute_identifier')==$key)
				{
	
					if ($key=='image')
					{
						$f = $attribut;
						if(!file_exists($f))
						{
							print("The file has been removed.\n");
						}
					
						$imageHandler = $contentObjectAttribute->attribute( 'content' );
						$imageHandler->initializeFromFile($f, '', basename($f)) ;
					
						$imageHandler->store() ;
					}
					if ($key == 'name')
					{
						$contentObjectAttribute->setAttribute('data_text',$attribut);
						$contentObjectAttribute->store();
					}
				}
			}
		}

		include_once ('lib/ezutils/classes/ezoperationhandler.php');
		$operationResult = eZOperationHandler :: execute('content', 'publish', array ('object_id' => $contentObject->attribute('id'), 'version' => 1));

		$class = eZContentClass :: fetch($class_id);
		$contentObject->setName($class->contentObjectName($contentObject));
		$contentObject->store();

		eZContentObject::clearCache();

		return $contentObject->mainNodeID();
	}
}

function getFiles($directory) {
	if($dir = opendir($directory)) {
		$tmp = array();
		while($file = readdir($dir)) {
			if($file != "." && $file != ".." && $file[0] != '.') {
				array_push($tmp, $directory . "/" . $file);
			}
		}
		closedir($dir);
		return $tmp;
	}
}

function clean($dir)
{
	if ($handle = opendir("$dir")) {
		while (false !== ($item = readdir($handle))) {
			if ($item != "." && $item != "..") {
				if (is_dir("$dir/$item")) {
					clean("$dir/$item");
				} else {
					unlink("$dir/$item");
					echo " removing $dir/$item<br>\n";
				}
			}
		}
		closedir($handle);
		rmdir($dir);
	}
}
/****************************************************/
/*                FIN DES FONCTIONS                 */
/****************************************************/
/****************************************************/
/*                  DEBUT DU SCRIPT                 */
/****************************************************/
$save_path="var/diaporama";
$tpl =& templateInit();
$Result = array();

$node_id=$Params['NodeID'];

$save_path="var/diaporama/$node_id";
$user_id = eZUser :: currentUserID();

if (!is_dir($save_path))
{
	$error="There are no images uploaded.";	
}
else
{
	$files=getFiles($save_path);
	$param['parent_node_id']=$node_id;
	foreach($files as $file)
	{
		$name=explode(".",basename($file));
		array_pop($name);
		$clean_name=ucwords(implode(' ', $name));
		$param['attributs']=array('image'=>$file, 'name'=>$clean_name);
		create(5, $param, $user_id);
	}
	clean($save_path);
}
if ($http->hasSessionVariable('RedirectURIAfterAdd'))
{
	$redirect_uri = $http->sessionVariable('RedirectURIAfterAdd');
	$http->removeSessionVariable('RedirectURIAfterAdd');
}
else
{
	$redirect_uri = "content/view/full/$node_id";
}

$module->redirectTo($redirect_uri);
/****************************************************/
/*                  FIN DU SCRIPT                   */
/****************************************************/

?>
