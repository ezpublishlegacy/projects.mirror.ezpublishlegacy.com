<?php
chdir(realpath("../../../"));
$node_id=$_GET['node_id'];

$save_path="var/diaporama";
if (!is_dir($save_path))
{
	mkdir($save_path, 0777);
}
if (!is_dir("$save_path/$node_id"))
{
	mkdir("$save_path/$node_id", 0777);
}

foreach($_FILES as $tagname=>$objekt)
{
 // get the temporary name (e.g. /tmp/php34634.tmp)
 $tempName = $objekt['tmp_name'];
 
 // get the real filename
 $realName = $objekt['name'];
 $size = $objekt['size'];
 
 // where to save the file?
 $target = "$save_path/$node_id/" . $realName;
 
 // print something to the user
 print("<br>$realName ($size bytes) \n");
 flush();
 move_uploaded_file($tempName,$target);
 flush();
}


flush();

?>