<?
$Module = array( 'name' => 'smileupload' );
$ViewList = array();
$ViewList['upload'] = array(
	'script' => 'upload.php',
	'default_navigation_part' => 'ezsmileuploadnavigationpart',
	'params' => array( 'NodeID' )
);
$ViewList['create'] = array(
	'script' => 'create.php',
	'default_navigation_part' => 'ezsmileuploadnavigationpart',
	'params' => array( 'NodeID' )
);
$ViewList['order'] = array(
	'script' => 'order.php',
	'default_navigation_part' => 'ezsmileuploadnavigationpart'	
);
$ViewList['remove'] = array(
    'script' => 'remove.php',
    'ui_context' => 'view',
    'default_navigation_part' => 'ezsmileuploadnavigationpart',
    'single_post_actions' => array( 'RemoveButton' => 'RemoveAction'),
    'post_action_parameters' => array( 'RemoveAction' => array( 'DeleteIDArray' => 'DeleteIDArray' ))
    );
?>