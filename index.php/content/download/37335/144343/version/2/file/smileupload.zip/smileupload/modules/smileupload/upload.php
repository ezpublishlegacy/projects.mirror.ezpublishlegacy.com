<?php
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php');
$module =& $Params['Module'];
$http =& eZHTTPTool::instance();
if ($http->hasPostVariable('NodeID'))
{
	$node_id=$http->postVariable("NodeID");
}
if ($http->hasPostVariable('RedirectURIAfterAdd'))
{
	$redirect_uri=$http->postVariable('RedirectURIAfterAdd');
	$http->setSessionVariable('RedirectURIAfterAdd', $redirect_uri);
}


$tpl =& templateInit();

$tpl->setVariable('node_id', $node_id);

$Result = array();
$Result['content'] = $tpl->fetch( "design:smileupload/upload.tpl" );
$Result['path'] = array( array( 'url' => false,
                       'text' => 'Slideshow' ),
                       array( 'url' => false,
                       'text' => 'Creation' ) );

?>
