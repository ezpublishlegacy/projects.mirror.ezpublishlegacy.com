<!DOCTYPE TS><TS>
<context>
    <name>countryshipping/design/standard/class/datatype/edit/ezshipping</name>
    <message>
        <source>Shipping group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default currency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The currency list is emty, please add one or more currencies in the %href_startCurrency list%href_end.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startFirst value:%bold_end The value that are added for the first item to a product.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startAdditional value:%bold_end The value that are added for the second and all other items of the same product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default shipping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Auto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Emty]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional country shipping (first / additional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values (%code)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected countries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add additional countries:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/class/datatype/view/ezshipping</name>
    <message>
        <source>Default shipping group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default currency code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default shipping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional country shipping (first / additional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values (%code)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> (Auto)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/content/datatype/edit/ezshipping</name>
    <message>
        <source>Shipping group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default currency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startFirst value:%bold_end The value that are added for the first item to a product.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startAdditional value:%bold_end The value that are added for the second and all other items of the same product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default shipping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Auto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Emty]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional country shipping (first / additional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values (%code)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected countries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add additional countries:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add countries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/content/datatype/view/ezshipping</name>
    <message>
        <source>Default shipping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional country shipping (first / additional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values (%code)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> (Auto)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/ezshipping</name>
    <message>
        <source>Default currency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The currencylist is emty, please add one or more currencies in the %href_startCurrency list%href_end.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startFirst value:%bold_end The value that are added for the first item to a product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%bold_startAdditional value:%bold_end The value that are added for the second and all other items of the same product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default shipping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Auto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Emty]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add currency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional country shipping (first / additional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values (%code)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected countries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add additional countries:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add countries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/ezshipping/groupedit</name>
    <message>
        <source>Edit Shipping group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store changes and exit from edit mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard all changes and exit from edit mode.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/ezshipping/grouplist</name>
    <message>
        <source>Shipping group list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected shipping groups.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New shipping group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new shippinggroup.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>countryshipping/design/standard/shop</name>
    <message>
        <source>Shipping: (Inc. %vat_value% VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total shipping Inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ezshipping</name>
    <message>
        <source>Shipping edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Shipping</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
