function getFCK(id)
{
	
   var framename = "fck"+id+"___Frame";
   var  fckiframe = window.frames[framename];
//   c_showPropsDump(fckiframe.FCKConfig,"fckiframe.FCKConfig");
   
   var res = "";  
   res = fckiframe.FCK.GetXHTML( fckiframe.FCKConfig.FormatOutput ) ; 
   //if ( fckiframe.FCKConfig.EnableXHTML ) res = fckiframe.FCK.GetXHTML( fckiframe.FCKConfig.FormatOutput ) ; 
   //else  res = fckiframe.FCK.GetHTML( fckiframe.FCKConfig.FormatOutput ) ;
   //var textBox = document.getElementsByName("ContentObjectAttribute_data_text_"+id);
   var textBox = document.getElementsByName(id);
   if (textBox.length==1){	
      textBox[0].value="<literal class='html'>"+res+"</literal>";
   }  
}

function putFCK(id)
{
   var  fckiframe = window.frames["fck"+id+"___Frame"];
   var textBox = document.getElementsByName(id);

   if (textBox.length==1){	
      var res = textBox[0].value;
      var regex = /<literal class=\'html\'>/i;
       res = res.replace(regex,"");
      regex = /<\/literal>/m;
       res = res.replace(regex,"");
       fckiframe.FCK.SetHTML(res ) ;  
}     

}

