<?php

include("extension/fckeditor/FCKeditor/fckeditor.php") ;

class fckeditoroperator
{
    /*!
     Constructor
    */
    function fckeditoroperator()
    {
    }

    /*!
     Returns the operators in this class.
    */
    function operatorList()
    {
        return array( 'writefck' );

    }

    /*!
     \return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     The first operator  non parameters
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array('writefck'  => array( 'params' => array( 'type' => 'array',
                                                             'required' => false,
                                                             'default' => array( ) ) ) );
    }

    /*!
     Executes the needed operator(s).
     Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                     &$currentNamespace, &$operatorValue, &$namedParameters )
    {
    	$params = & $namedParameters['params'];
    	if ( count( $params ) == 0 )
    	{
		    $params = array( 'id' => null);
	}


        switch ( $operatorName )
        {
            case 'writefck':
            {
		//if ( isset( $params['id'] ) && is_numeric( $params['id'] ) )	
		$id = $params['id'];
    
		$oFCKeditor = new FCKeditor("fck".$id) ;
		$oFCKeditor->BasePath	= '/extension/fckeditor/FCKeditor/' ;
		$oFCKeditor->Value		= 'This is some <strong>sample text</strong>. You are using <a href="http://www.fckeditor.net/">FCKeditor</a>.' ;
		$retVal = $oFCKeditor->getHTML() ;

		//$retVal2 = 'function getFCK(id){ var framename = "fck"+id+"___Frame"; var  fckiframe = window.frames[framename];  var res = "";  res = fckiframe.FCK.GetXHTML( fckiframe.FCKConfig.FormatOutput ) ;  var textBox = document.getElementsByName(id); if (textBox.length==1){ textBox[0].value="<literal class=\'html\'>"+res+"</literal>"; }};function putFCK(id){ var fckiframe = window.frames["fck"+id+"___Frame"]; var textBox = document.getElementsByName(id); if (textBox.length==1){ var res = textBox[0].value; var regex = /<literal class=\'html\'>/i; res = res.replace(regex,""); regex = /<\/literal>/m; res = res.replace(regex,""); fckiframe.FCK.SetHTML(res ) ; } }';

		//$retVal .= $retVal2;
		$retVal .= "<div class='buttonblock'><input type='button' Value='copy from FCKeditor to textbox' onclick=\"getFCK('$id')\"><input type='button' Value='copy from textbox to FCKeditor' onclick=\"putFCK('$id')\"></div>";
                $operatorValue = $retVal;

            } break;
        }
    }

}

?>
