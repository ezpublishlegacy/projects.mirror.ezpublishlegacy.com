<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/fckeditor/autoloads/fckeditor.php',
         'class' => 'fckeditoroperator',
         'operator_names' => array( 'writefck' ) );

?>
