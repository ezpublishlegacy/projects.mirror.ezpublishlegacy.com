<?php
// Blocks
define("_MB_X509_LOGIN","Login");
define("_MB_X509_REGISTER","Register");
define('_MB_X509_INSTRUCTION', 'Para entrar, por favor inserte su certificado digital X509.');
define('_MBL_X509_VERIFY_SUCCESS', 'El nombre %s (%s) fue verificado con éxito como su identidad digital.');
?>
