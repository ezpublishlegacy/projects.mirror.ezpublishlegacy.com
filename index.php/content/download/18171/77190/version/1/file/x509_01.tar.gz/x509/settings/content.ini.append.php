<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
#ExtensionDirectories[]=x509
#AvailableDataTypes[]=x509

*/ ?>
