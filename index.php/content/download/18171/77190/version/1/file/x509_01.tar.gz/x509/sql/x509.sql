CREATE TABLE IF NOT EXISTS `x509_users` (
  `id` int(11) NOT NULL auto_increment,
  `sslclientmserial` varchar(255) default NULL,
  `sslclientsdn` varchar(400) default NULL,
  `sslclientsdncn` varchar(400) default NULL,
  `sslclientcert` text default NULL,  
  `user_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
