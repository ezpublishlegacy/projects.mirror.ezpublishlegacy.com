<?php
include_once( "lib/ezdb/classes/ezdb.php" );
include_once( 'kernel/classes/ezpersistentobject.php' );
//include_once( 'extension/x509/classes/x509_lib_wrapper.php' );

class x509_user extends eZPersistentObject
{

  function x509_user(&$row)
  {
    $this->eZPersistentObject( $row );
  }

  static function definition()
  { 
  
    return array( 'fields' => array(
                    'id' => array(
                      'name' => 'id',
                      'datatype' => 'integer',
                      'default' => 0,
                      'required' => true ),
                    'sslclientmserial' => array(
                      'name' => 'sslclientmserial',
                      'datatype' => 'string',
                      'default' => 0,
                      'required' => true ),
                    'sslclientsdn' => array(
                      'name' => 'sslclientsdn',
                      'datatype' => 'string',
                      'default' => 0,
                      'required' => true ),
                    'sslclientsdncn' => array(
                      'name' => 'sslclientsdncn',
                      'datatype' => 'string',
                      'default' => 0,
                      'required' => true ),
                    'sslclientcert' => array(
                      'name' => 'sslclientcert',
                      'datatype' => 'string',
                      'default' => 0,
                      'required' => true ),                                                                  
                    'user_id' => array(
                      'name' => 'user_id',
                      'datatype' => 'integer',
                      'default' => 0,
                      'required' => true ),
                    'created_at' => array(
                      'name' => 'created_at',
                      'datatype' => 'integer',
                      'default' => 0,
                      'required' => true ),
                    'last_login' => array(
                      'name' => 'last_login',
                      'datatype' => 'integer',
                      'default' => 0,
                      'required' => true ),
                  ),
                  'function_attributes' => array(
                      'user' => 'getUser',
                  ),
                  'keys' => array( 'id' ),
                  "increment_key" => "id",
                  'sort' => array( 'last_login' => 'desc' ),
                  'class_name' => 'x509_user',
                  'name' => 'x509_users' 
                );
  }

  static function &fetch( $sslclientcert )
  {
    $conds = array( 'sslclientcert' => $sslclientcert);
    $object = x509_user::fetchObject( x509_user::definition(), null, $conds);
    return $object;
  }

  static function &fetchByID( $id )
  {
    $conds = array( 'id' => $id);
    $object = x509_user::fetchObject( x509_user::definition(), null, $conds);
    return $object;
  }

  static function &fetchByURL( $id )
  {
    $conds = array( 'sslclientcert' => $id);
    $object = x509_user::fetchObject( x509_user::definition(), null, $conds);
    return $object;
  }


  static function &fetchByUserID( $id )
  {
    $conds = array( 'user_id' => $id);
    $objects = x509_user::fetchObjectList( x509_user::definition(), null, $conds);
    return $objects;
  }
  
  static function &fetchAll()
  {
    $conds = array();
    $objects = x509_user::fetchObjectList( x509_user::definition(), null, $conds);
    return $objects;
  }  

  function &getUser()
  {
    $user = eZUser::fetch($this->attribute('user_id'));
    return $user;
  }

  static function &create($row=array())
  {
    $object = new x509_user($row);
    $object->setAttribute('created_at', time() );
    return $object;
  }


    /*!
       Updates the user's last visit timestamp
    */
  function updateLastVisit()
  {
    if ( isset( $GLOBALS['x509UpdatedLastVisit'] ) )
      return;

    $this->setAttribute('last_login', time() );
    $this->store();
    $GLOBALS['x509UpdatedLastVisit'] = true;
  }


	function &setFullname($id) 
	{
		$user = eZUser::fetch($id);
		if (!isset($_SERVER["SSL_CLIENT_S_DN_CN"])) return false;
		// Alterar nome do usuario
		list($fullname,$cpf) = explode(':',$_SERVER["SSL_CLIENT_S_DN_CN"],2);
		list($first_name,$last_name) = explode(' ',$fullname,2);
		if (!empty($first_name) and !empty($last_name)) {
          $userID = $contentObjectID = $user->attribute( 'contentobject_id' );
          $contentObject = eZContentObject::fetch( $userID );
          $version = $contentObject->attribute( 'current' );
		  $contentObjectAttributes = $version->contentObjectAttributes();
		  
		  if ($contentObject->Name == $fullname) return true; // Draft problem

          // find ant set 'name' and 'description' attributes (as standard user group class)
          $firstNameIdentifier = 'first_name';
          $lastNameIdentifier = 'last_name';
          $firstNameAttribute = null;
          $lastNameAttribute = null;

          foreach( $contentObjectAttributes as $attribute )
          {
              if ( $attribute->attribute( 'contentclass_attribute_identifier' ) == $firstNameIdentifier )
              {
                  $firstNameAttribute = $attribute;
              }
              else if ( $attribute->attribute( 'contentclass_attribute_identifier' ) == $lastNameIdentifier )
              {
                  $lastNameAttribute = $attribute;
              }
          }
          if ( $firstNameAttribute )
          {
            if ( $isUtf8Encoding )
                  $first_name = utf8_decode( $first_name );
            $firstNameAttribute->setAttribute( 'data_text', $first_name );
            $firstNameAttribute->store();
          }
          if ( $lastNameAttribute )
          {
            if ( $isUtf8Encoding )
                $last_name = utf8_decode( $last_name );
            $lastNameAttribute->setAttribute( 'data_text', $last_name );
            $lastNameAttribute->store();
         }

         $contentClass = $contentObject->attribute( 'content_class' );
         $name = $contentClass->contentObjectName( $contentObject );
         $contentObject->setName( $name );
         $user->store();
         return true;
	   }    
	   return false;
	}

}

?>
