<?php
define('_GR_GREETING', 'Hola, ');
define('_MB_X509_VERIFY_CERTIFICATE', 'Verificar certificado:');
define('_MB_X509_VERIFY', 'Verificar');
define('_MB_X509_VERIFY_CANCELED', 'Verificación cancelada.');
define('_MB_X509_VERIFY_FAILED', 'La autenticación por certificado X509 falló: ');
define('_MB_X509_VERIFY_SUCCESS', 'El nombre %s (%s) fue verificado con éxito como su identidad digital.');
//LINK
define('_MB_X509_INSERT_SUCESS', 'El nombre %s (%s) fue <b>registrado</b> con éxito como su identidad digital.');
define('_MB_X509_ERROR_REGISTRED', 'El nombre %s (%s) <b>ya está registrado</b> en el banco de datos.');
define('_MB_X509_MISSING', 'Faltando certificado!');
define('_MB_X509_USER_PASS_INVALID', 'Usuario o Seña inválido.');
define('_MB_X509_UNKNOWN_ERROR', 'Perdón, fue encontrado un error desconocido. ');
//REGISTER
define('_MB_X509_USERNAME_SHORT', 'nombre de usuario muy corto');
define('_MB_X509_USERNAME_ALREADY_USED', 'El usuario <b>%s</b> ya está en uso.<br />Elegir otro nombre de usuario.');

define('_MI_X509_BLOCK_DESCRIPTION', 'Mostrar caja de login X509');
define('_MB_X509_TEMPLATE1_DESCRIPTION', 'Pantalla del usuario X509');
define('_MB_X509_TEMPLATE2_DESCRIPTION', 'Nuevo diálogo de usuario X509');
define('_MB_X509_TEMPLATE3_DESCRIPTION', 'Pantalla genérica');

?>
