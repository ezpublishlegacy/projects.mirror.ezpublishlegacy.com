<!DOCTYPE TS><TS>
<context>
    <name>design/standard/x509</name>
    <message>
        <source>X509 Certificate for %user_name</source>
        <translation>Certificado X509 para %user_name</translation>
    </message>
    <message>
        <source>X509 Certificate</source>
        <translation>Certificado X509</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Remover</translation>
    </message>
	<message>
        <source>Remove selected</source>
        <translation>Remover selecionados</translation>
    </message>
    <message>
        <source>Register new X509 Certificate</source>
        <translation>Cadastrar novo Certificado X509</translation>
    </message>
    <message>    
        <source>You don't have any registered X509 Certificate's</source>
        <translation>Você não possui nenhum certificado digital X509 cadastrado</translation>
    </message>
    
    <message>
        <source>Have an X509 Certificate?</source>
        <translation>Você possui um Certificado Digital X509?</translation>
    </message>
    <message>
        <source>Sign in below:</source>
        <translation>Acesse abaixo:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Cadastrar</translation>
    </message>
    <message>
        <source>Insert your X509 certifiate</source>
        <translation>Insira o seu Certificado Digital X509</translation>
    </message>

    <message>
        <source>My X509 Certificates</source>
        <translation>Meus Certificados Digitais X509</translation>
    </message>   

    <message>
        <source>Created</source>
        <translation>Criado</translation>
    </message>  
    <message>
        <source>Last Login</source>
        <translation>Último login</translation>
    </message>  
    <message>
        <source>Never logged in</source>
        <translation>Nunca logou</translation>
    </message>  

    <message>
        <source>All X509 Certificates</source>
        <translation>Todos os Certificados X509</translation>
    </message>  
    <message>
        <source>The site has no registered X509 Certificates</source>
        <translation>O site não possui nenhum Certificano X509 cadastrado</translation>
    </message>    
    
</context>
</TS>
