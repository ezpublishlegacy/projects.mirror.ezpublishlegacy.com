<?php
define("_MI_X509_NAME","Autenticación X509");
define("_MI_X509_DESC","Permitir que los usuarios hagan login usando sus certificados digitales X509.");
define("_MI_X509_BNAME1","Login X509");
?>



