<?php
include_once ('kernel/common/template.php');
include_once ('kernel/common/eztemplatedesignresource.php');
include_once ("lib/ezutils/classes/ezhttptool.php");
include_once ('extension/x509/classes/x509_user.php');
//include_once ('extension/x509/classes/x509_lib_wrapper.php');

$Module = $Params['Module'];
$http = eZHTTPTool::instance();
$ini = eZINI::instance();
$tpl = templateInit();
$msg = false;
$error_msg = false;

// Get the currently logged in user
$user = eZUser::currentUser();

// Check if user is anonymous
if ( $user->isAnonymous() )
{
  // some kind or error here?
  return $Module->handleError( eZError::KERNEL_ACCESS_DENIED, 'kernel' );
}

$userID = $user->id();
$userObject = $user->attribute('contentobject');

if ( !$user)
    return $Module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
$userObject = $user->attribute( 'contentobject' );
if ( !$userObject )
    return $Module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );

if ($Module->isCurrentAction('Register') and $Module->hasActionParameter('X509URL')) 
{

  $x509_cert = $_SERVER["SSL_CLIENT_CERT"];

  if ($x509_cert != '')
  {
    // Does the URL already exist
    $x509_user = x509_user::fetchByURL($x509_cert);
    if (! $x509_user)
    {
      eZDebug::writeDebug( $x509_cert );
      
	  if (isset($_SERVER["SSL_CLIENT_CERT"]))
	  {
		  // This means the authentication succeeded; extract the
		  // identity URL and Simple Registration data (if it was
		  // returned).
		  $http->removeSessionVariable( "X509URL" );

		  $x509_user =& x509_user::create();
		  $x509_user->setAttribute('sslclientmserial', $_SERVER["SSL_CLIENT_M_SERIAL"]);
		  $x509_user->setAttribute('sslclientsdn', $_SERVER["SSL_CLIENT_S_DN"]);
		  $x509_user->setAttribute('sslclientsdncn', $_SERVER["SSL_CLIENT_S_DN_CN"]);
		  $x509_user->setAttribute('sslclientcert', $_SERVER["SSL_CLIENT_CERT"]);
		 
		  $x509_user->setAttribute('user_id', $userID);
		  $x509_user->store();

		  // Alter fullname
		  x509_user::setFullname($user->ContentObjectID);
		  // FIM altera nome

		  $msg = "Successfully verified and registered x509 certificate ".$_SERVER["SSL_CLIENT_S_DN_CN"];
	  }      
      
/*      eZDebug::writeDebug( $auth_request ); */
    }
    else
    {
      $error_msg = "Certificate already registered:".$_SERVER["SSL_CLIENT_S_DN_CN"];
    }
  }
  else
  {
    $error_msg = "Invlaid X509 certificate :".$x509_cert;
  }
}

if ($Module->isCurrentAction('Remove') and $Module->hasActionParameter('DeleteIDArray')) {

  $DeleteIDArray = $Module->actionParameter('DeleteIDArray');
  eZDebug::writeDebug( $DeleteIDArray );
    
  foreach ($DeleteIDArray as $arrayid=>$DeleteID) {
  	$certdel = x509_user::fetchByID($DeleteID);
  	if ($certdel->user_id != $userID && $userID != 14) { //Only the admin can delete certificates from other User
  		unset($DeleteIDArray[$arrayid]);
  	}
  }
  $cond = array('id' => array($DeleteIDArray));
  x509_user::removeObject(x509_user::definition(),$cond);
}

$title = "X509's for ".$userObject->attribute('name');

// Get a list of registered URLS for this user
$x509_certs = x509_user::fetchByUserID($userID);
$all_x509_certs = x509_user::fetchAll();
$tpl->setVariable( 'user', $user );
$tpl->setVariable( 'x509_urls', $x509_certs );
if ($userID == 14 ) $tpl->setVariable( 'all_x509_urls', $all_x509_certs ); //Only Admin
$tpl->setVariable( 'msg', $msg );
$tpl->setVariable( 'error_msg', $error_msg );


$path[] = array( 'url'       => false,
                 'url_alias' => false,
                 'node_id'   => 0,
                 'text'      => $title);

$Result = array();
$Result['content'] = $tpl->fetch("design:x509/list.tpl");
$Result['path'] = $path;

// Set navigation_part_identifier & res info 
$Result['content_info']['navigation_part_identifier'] = false;
if ( $Module->singleFunction() )
  $function = $Module->Module["function"];
else
  $function = $Module->Functions[$Params['FunctionName']];

if ( isset( $function['default_navigation_part'] ) )
{
  $Result['content_info']['navigation_part_identifier'] = $function['default_navigation_part'];
}
$res = eZTemplateDesignResource::instance();
$res->setKeys( array( array( 'navigation_part_identifier', $Result['content_info']['navigation_part_identifier'] )) );

?>
