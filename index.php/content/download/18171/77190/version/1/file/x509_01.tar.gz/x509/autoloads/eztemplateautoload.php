<?php
if ($user = eZUser::currentUser()) {
	// ContentObjectID == 14 == admin, not logout
	if ((eZModule::currentModule() == 'x509' || (eZModule::currentModule() == 'user' && ($user->ContentObjectID != 14) )) 
		&& (!eZSys::isSSLNow()) && (!eZSSLZone::enabled()) ){
		// Force SSL
		$sslRedirectionURL = "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		eZHTTPTool::redirect( $sslRedirectionURL );
		eZExecution::cleanExit();		
	}

	if ($x509s_user = x509_user::fetchByUserID($user->ContentObjectID)) {
		$x509_verified = false;
		//echo "User with registered certificate... ";		
		if ((!eZSys::isSSLNow()) && !eZSSLZone::enabled()) {
			// Force SSL
			$sslRedirectionURL = "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			eZHTTPTool::redirect( $sslRedirectionURL );
            eZExecution::cleanExit();		
		}
        		
		foreach ($x509s_user as $x509_user) {
			if (isset($_SERVER["SSL_CLIENT_CERT"]) 
				&& ($_SERVER["SSL_CLIENT_CERT"] == $x509_user->attribute('sslclientcert')) ) {
				//echo "Certificate valid and registred... ";
				$x509_verified = true;
				x509_user::setFullname($user->ContentObjectID);
			}
        }
        // Logout
        if (!$x509_verified && ($user->ContentObjectID != 14) ) { // ContentObjectID == 14 == admin, not logout
	        //echo "Certificate not inserted... ";
			$user->logoutCurrent();
        	$user = null;
        }
	}
}	
?>
