<?php /* #?ini charset="iso-8859-1"?
[NavigationPart]
Part[ezx509navigationpart]=x509

[TopAdminMenu]
Tabs[]=x509

[Topmenu_x509]
NavigationPartIdentifier=ezx509navigationpart
Name=X509
Tooltip=Registered X509 Certificates
URL[]
URL[default]=x509/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
