<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=phplist

[StylesheetSettings]
#CSSFileList[]=phplist.css

*/ ?>
