<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array(
    'class' => 'ngLanguageSwitcherTemplateFunctions',
    'operator_names' => array( 'ngurl' )
);
