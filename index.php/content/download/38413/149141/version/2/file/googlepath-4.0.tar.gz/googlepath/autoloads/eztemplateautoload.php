<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/googlepath/classes/templatemapsettingsoperator.php',
                                    'class' => 'TemplateMapsettingsOperator',
                                    'operator_names' => array( 'googleapikey' ) );
?>
