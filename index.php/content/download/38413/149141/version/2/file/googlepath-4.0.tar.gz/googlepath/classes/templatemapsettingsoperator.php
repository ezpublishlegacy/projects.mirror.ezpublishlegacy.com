<?php
/*!
  \class   TemplateMapsettingsOperator templategoogleapikeyoperator.php
  \ingroup eZTemplateOperators
  \brief   Gets the Google Map API key for the current siteaccess from the googlepath.ini file.
  \version 1.0
  \date    Tuesday 30 January 2007 2:39:12 pm
  \author  Michael Maclean

  

  Example:
\code
{googleapikey()}
\endcode
*/

/*
If you want to have autoloading of this operator you should create
a eztemplateautoload.php file and add the following code to it.
The autoload file must be placed somewhere specified in AutoloadPath
under the group TemplateSettings in settings/site.ini

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'templategoogleapikeyoperator.php',
                                    'class' => 'TemplateMapsettingsOperator',
                                    'operator_names' => array( 'googleapikey' ) );

If your template operator is in an extension, you need to add the following settings:

To extension/YOUREXTENSION/settings/site.ini.append:
---
[TemplateSettings]
ExtensionAutoloadPath[]=YOUREXTENSION
---

To extension/YOUREXTENSION/autoloads/eztemplateautoload.php:
----
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/YOUEXTENSION/YOURPATH/templategoogleapikeyoperator.php',
                                    'class' => 'TemplateMapsettingsOperator',
                                    'operator_names' => array( 'googleapikey' ) );
---

Create the files if they don't exist, and replace YOUREXTENSION and YOURPATH with the correct values.

*/


class TemplateMapsettingsOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TemplateMapsettingsOperator()
    {
    }

    /*!
     eturn an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'googleapikey' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'googleapikey' => array( 'site' => array( 'type' => 'string',
                                                               'required' => false,
                                                               'default' => null ),
                                                               ) );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $site = $namedParameters['site'];

        require_once( 'lib/ezutils/classes/ezini.php' );
        $ini = eZINI::instance( "googlepath.ini" );
        $keys = $ini->variable( "ApiKeys", "GoogleApiKeys" );
        $keysArray = array();
        foreach ( $keys as $key => $value ) {
            $tmp = explode(';', $value);
            $keysArray[$tmp[0]] = $tmp[1];
        }

        switch ( $operatorName )
        {
            case 'googleapikey':
            {
                if( isset($site) ) {
                    $operatorValue = $keysArray[$site];
                } else {
                    $operatorValue = $keysArray[eZSys::hostname()];
                }
            } break;
        }
    }
}

?>
