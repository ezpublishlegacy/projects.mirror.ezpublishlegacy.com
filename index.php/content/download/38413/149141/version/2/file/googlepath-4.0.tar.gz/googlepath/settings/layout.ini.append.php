<?php /* #?ini charset="iso-8859-1"?

[googlepath]
PageLayout=googlepath_pagelayout.tpl

*/ ?>

