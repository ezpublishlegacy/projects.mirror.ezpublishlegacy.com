<?php /*

[ExtensionSettings]
DesignExtensions[]=eznip

*/ ?>
