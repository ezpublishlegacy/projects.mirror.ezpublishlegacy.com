<?php

$Module = array( "name" => "MultipleNodeMove310" );

$ViewList = array();
$ViewList["move"] = array( "script" => "move.php", 'params' => array( ) );
$ViewList["addlocations"] = array( "script" => "addlocations.php", 'params' => array( ) );
$ViewList["select"] = array( "script" => "select.php", 'params' => array( ) );
$ViewList["add_locs_select"] = array( "script" => "add_locs_select.php", 'params' => array( ) );

?>
