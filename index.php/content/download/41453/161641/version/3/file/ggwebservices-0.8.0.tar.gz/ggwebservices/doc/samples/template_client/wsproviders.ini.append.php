<?php /*

[phpxmlrpc]
providerType=XMLRPC
providerUri=http://phpxmlrpc.sourceforge.net/server.php

[mssoapinterop]
providerType=PhpSOAP
providerUri=
WSDL=http://mssoapinterop.org/asmx/simple.asmx?WSDL

*/ ?>