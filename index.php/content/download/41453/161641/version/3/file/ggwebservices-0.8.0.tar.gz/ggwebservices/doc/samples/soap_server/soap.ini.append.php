<?php /*

[GeneralSettings]
EnableSOAP=true

[ExtensionSettings]
SOAPExtensions[]=yourextension

*/ ?>