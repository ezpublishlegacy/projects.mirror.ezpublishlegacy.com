<?php /*

[NavigationPart]
Part[nvnewsletter]=Newsletter

[TopAdminMenu]
Tabs[]=nvnewsletter

[Topmenu_nvnewsletter]
NavigationPartIdentifier=nvnewsletter
Name=Newsletter
Tooltip=Newsletter menu
URL[]
URL[default]=nvnewsletter/dashboard
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
