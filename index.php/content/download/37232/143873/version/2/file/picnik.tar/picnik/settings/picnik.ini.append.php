<?php /* #?ini charset="utf-8"?

[api]
#Your API KEY
key=
#picnik URL service
url=http://www.picnik.com/service

[optionnal_parameters]
#output tab lets you register your image on your own computer
pkOutTab=disabled

*/ ?>
