<?php
//
// Created on: <30/07/2008 jcohonner>
//
// EXTENSION NAME: Picnik
// EXTENSION RELEASE: 1.0
// COMPANY : Cosmosbay ~ Vectis - www.cosmosbay-vectis.com
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file picnikfunctioncollection.php
*/

/*!
  \class picnikFunctionCollection picnikfunctioncollection.php
  \brief The class eZContentFunctionCollection does access check for picnik extension
*/

class picnikFunctionCollection {


    /*!
     Constructor
    */
	function picnikFunctionCollection() {
		
	}

	function checkAccess($accessType,$contentObject) {
		
		$access = false;
		
		$user = eZUser::currentUser();
		$accessResult = $user->hasAccessTo( 'picnik' , $accessType);
		$accessWord = $accessResult['accessWord'];
		
		if ($accessWord=="yes") {
			$access=true;
		} elseif ($accessWord=="limited") {
			
			$policies = $accessResult['policies'];

			foreach ($policies as $pkey => $limitationArray) {
				
                if ( $access )
                {
                    break;
                }				


				/*
				 * Check only existing limitation
				 * if limitation key exists : value is false, otherwise true
				 */
				$lClass=!array_key_exists("Class",$limitationArray);
				$lSection=!array_key_exists("Section",$limitationArray);
				
				foreach ($limitationArray as $lkey => $limitation) {
					switch ($lkey) {
						
						case "Class" : 
							if (in_array($contentObject->attribute("contentclass_id"),$limitation)) {
								$lClass=true;
							}
							break;
							
						case "Section" : 
							if (in_array($contentObject->attribute("section_id"),$limitation)) {
								$lSection=true;
							}							
							break;
						
					}
				} //foreach policy limitations
				
			

				if ($lClass && $lSection) {
					$access = true; 
				}				
				
			} // foreach policies
		} //else = no, so result=false
		

		
		return array( 'result' => $access );
	}

}

?>
