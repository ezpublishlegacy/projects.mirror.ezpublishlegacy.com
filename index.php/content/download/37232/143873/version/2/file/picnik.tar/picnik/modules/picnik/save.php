<?php
//
// Created on: <30/07/2008 jcohonner>
//
// EXTENSION NAME: Picnik
// EXTENSION RELEASE: 1.0
// COMPANY : Cosmosbay ~ Vectis - www.cosmosbay-vectis.com
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file save.php
*/

// Some are not necessary for 4.0 due to autoload fonctionnality
// we keep them for 3.9 compatibility
include_once( "kernel/common/template.php" );
include_once( "kernel/classes/ezcontentcachemanager.php" );
include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezhttpfile.php" );

$module 		= & $Params['Module'];
$nameParameters = $module->getNamedParameters();
$http 			= eZHTTPTool::instance();

$doUpload=true;

//Redirect URL
if ( $http->hasVariable( "redirectURI" )) {
	//redirectURL has been sent to picnik and must be send back to us
	$urlredirect = $http->variable( "redirectURI" );
} elseif ( $http->hasSessionVariable( "LastAccessesURI" ) )  {
	$urlredirect = $http->sessionVariable( "LastAccessesURI" );
} else {
	// use main node url of content object
	$mainNode = $contentObject->mainNode();
	
	if ($mainNode) {
		$urlredirect = $mainNode->urlAlias();
	} else {
		//fallback issue : back to index
		$urlredirect = "/";
	}
}


//Attribute in URL /picnik/save/<AttributeId>/<Version>
$attributeId = $nameParameters['AttributeID'];
$version	 = $nameParameters['Version'];
$attribute   = eZContentObjectAttribute::fetch($attributeId,$version);


if (!$attribute) {
	$doUpload=false;	
}

//check datatype type
if ($attribute->attribute('data_type_string')!="ezimage") {
	$doUpload=false;	
}

// Check user rights on content object
$contentObject = $attribute->object();
if (!$contentObject->canEdit()) {
	$doUpload=false;	
}

$image_data=false;

if ($doUpload) {
	// Try to upload file
	$pkFileUrl = $http->variable('file');
	$image_data = file_get_contents( $pkFileUrl );
}

if (FALSE === $image_data) {
	// Download failed or user rights check failed ... 
	// this shouldn't happen very often
} else {
	$baseName = basename($pkFileUrl);

	//create a temporary file	
	$tmpFileName = eZSys::cacheDirectory()."/".time().$baseName;
	$tmpFile = fopen($tmpFileName,"w");
	fwrite( $tmpFile, $image_data );	
	fclose( $tmpFile);

	//import file in eZpublish	
	$imageHandler = $attribute->attribute('content');
	$imageHandler->initializeFromFile( $tmpFileName, false ,$baseName );
	$imageHandler->store( $contentObjectAttribute );
	
	//remove temporary file	
	unlink($tmpFileName); 
	
	//remove view cache (just in case...)
	eZContentCacheManager::clearObjectViewCacheIfNeeded( $contentObject->attribute('id') );
}

$module->redirectTo($urlredirect);

?>
