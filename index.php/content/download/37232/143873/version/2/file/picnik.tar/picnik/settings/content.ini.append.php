<? /* #?ini charset="utf-8"?

[EditSettings]
ExtensionDirectories[]=picnik

*/ ?>
