<?php /*

[ModuleSettings]
ExtensionRepositories[]=picnik
ModuleList[]=picnik


*/ ?>
