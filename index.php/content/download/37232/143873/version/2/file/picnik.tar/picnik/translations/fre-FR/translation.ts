<!DOCTYPE TS><TS>
<context>
    <name>picnik/edit</name>
    <message>
        <source>Edit with picnik</source>
        <translation>Modifier avec picnik</translation>
    </message>
    <message>
        <source>Import image from picnik</source>
        <translation>Nouvelle image depuis picnik</translation>
    </message>    
</context>

</TS>