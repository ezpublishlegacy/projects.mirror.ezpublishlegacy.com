<?php
//
// Created on: <30/07/2008 jcohonner>
//
// EXTENSION NAME: Picnik
// EXTENSION RELEASE: 1.0
// COMPANY : Cosmosbay ~ Vectis - www.cosmosbay-vectis.com
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file picnikhandler.php
*/

/*!
  \class picnikHandler picnikhandler.php
  \brief The class picnikHandler introduces a specific edit object action for Picnik
*/

class picnikHandler extends eZContentObjectEditHandler
{
    function fetchInput( $http, &$module, &$class, $object, &$version, $contentObjectAttributes, $editVersion, $editLanguage, $fromLanguage )
    {
    	//The specific submit button is named PicnikImageEdit[{attribute_id}_{attribute_version}]

		//remove include comment for ez 3.X
		//include_once "extension/picnik/modules/picnik/picnikfunctioncollection.php";

 		if ($http->hasVariable('PicnikImageEdit')) {
 			$picnikImageEditArray = $http->variable('PicnikImageEdit');

 			if (is_array($picnikImageEditArray)) {
 				foreach ($picnikImageEditArray as $attribute_key => $dummy_value) {
					 //Extract attribute id and version
					 $attributeValueTab = explode('_',$attribute_key);
					 
					 if (count($attributeValueTab)==2) {

						$attributeId = $attributeValueTab[0];
						$action	 = $attributeValueTab[1];
						
						$attribute=false;
						
						if ($action=="edit" || $action=="import") {
						
							foreach ($contentObjectAttributes as $contentAttribute) {
								if ($contentAttribute->attribute("id")==$attributeId)	{
									$attribute   = $contentAttribute;
								}
							}
						
							//security tests
							if (!$attribute) {
								return;	
							}
							
							if ($attribute->attribute('data_type_string')!="ezimage") {
								return;	
							}
							
							if (!$object->canEdit()) {
								return;	
							}

							$pkParameters = array();
							
							//When import action (= new image from picnik) : no _import parameter							
							if ($action=="edit") {
								//Image handling
								$attributeContent	= $attribute->content();
								
								if (!$attributeContent  || !$attributeContent->hasAttribute('original')) {
									return;	
								}
						
								//eZImage Content is an eZImageAliasHandler class
								//we only use original alias, we use eZURI to get full URL with domain server
								
								$originalImageTab	= $attributeContent->attribute('original');
								$originalImageFile  = $originalImageTab['url'];
								$originalImageUrl	= '/'.$originalImageTab['url'];
								eZURI::transformURI( $originalImageUrl, true, 'full' );
								$pkParameters["_import"]		=	$originalImageUrl;
							} else {	
								$pkParameters["_page"]	=	"/in/upload"; // place in picnik photo tab
							}

							//Picnik parameters
							$pkIni 		= 	new eZINI('picnik.ini');
							$pkUrl		=	$pkIni->variable('api','url');
							$pkKey		=	$pkIni->variable('api','key');
							$pkUrlSave	=	'picnik/save/'.$attributeId.'/'.$attribute->attribute("version").'/';
							eZURI::transformURI( $pkUrlSave, false, 'full' );							
							
							//URL construction
							$pkParameters["_export"]		=	$pkUrlSave;
							$pkParameters["_redirect"]		=	"none";
							$pkParameters["_export_method"]	=	"POST";
							$pkParameters["_export_agent"]	=	"browser";
							
							//Exclude parameter
							$pkFunctionCollection = new picnikFunctionCollection();
							$resultImport = $pkFunctionCollection->checkAccess("import",$object);
							if (!$resultImport["result"]) {
								$pkParameters["_exclude"]	=	"in";
							}
							
							//optionnal parameters from ini
							if (trim($pkIni->variable('optionnal_parameters','pkOutTab'))!="enabled") {
								if (array_key_exists("_exclude",$pkParameters)) {
									$pkParameters["_exclude"]	=	$pkParameters["_exclude"].",out";
								} else {
									$pkParameters["_exclude"]	=	"out";
								}
							}			
							
							//redirect parameter : 
							//   _close_target action when user choose close from picnik without export action
							//   redirectURI : this is not a picnik parameter. all parameter without "_" will be send back at export
							$bachToEditUrl = "/content/edit/".$object->attribute("id")."/".$version->attribute("version")."/".$editLanguage;
							eZURI::transformURI( $bachToEditUrl, true, 'full' );
							
							$pkParameters["_close_target"]	=	$bachToEditUrl;
							$pkParameters["redirectURI"]	=	$bachToEditUrl;

							
							$urlredirect = $pkUrl.'?_apikey='.rawurlencode($pkKey);
							
							foreach ($pkParameters as $pkkey => $pkvalue) {
								$urlredirect.="&".$pkkey."=".rawurlencode($pkvalue);
							}

							$module->redirectTo($urlredirect);
														
						}
					}
 				}
 			}
 		}
    }
 
 	//remove "static" for ez 3.X
    static function storeActionList()
    {
    	return array('PicnikImageEdit');
    	
    }
 
    function publish( $contentObjectID, $contentObjectVersion )
    {
 
    }
}
?>
