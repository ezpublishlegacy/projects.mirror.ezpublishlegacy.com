<?php
  // Operator autoloading
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezsiteaccessoperator/autoloads/ezsiteaccessoperator.php',
                                    'class' => 'ezSiteAccessOperator',
                                    'operator_names' => array('siteaccess'));

?>
