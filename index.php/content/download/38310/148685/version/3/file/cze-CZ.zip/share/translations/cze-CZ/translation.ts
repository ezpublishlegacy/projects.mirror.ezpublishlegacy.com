<!DOCTYPE TS><TS>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Obsah</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Titulní strana</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Mapa stránek</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Koncepty</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Změnit heslo</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Obchod</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Seznam objednávek</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Typy daní</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Sleva</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Uživatelé</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Role</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Spolupráce</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Třídy</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sekce</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation></translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Překlady</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Statistiky vyhledávání</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Osobní</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size:</source>
        <translation>Max velikost souboru:</translation>
    </message>
    <message>
        <source>Default value:</source>
        <translation>Pøednastavená hodnota:</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Prázdný</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Aktuální datum</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Aktuální datum a čas</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Vícenásobný výběr</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enum Element:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enum Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Odstranit vybrané</translation>
    </message>
    <message>
        <source>Min float value:</source>
        <translation>Min hodnota (desetinné č.):</translation>
    </message>
    <message>
        <source>Max float value:</source>
        <translation>Max hodnota (desetinné č.):</translation>
    </message>
    <message>
        <source>Min integer value:</source>
        <translation>Min hodnota (celé č.):</translation>
    </message>
    <message>
        <source>Max integer value:</source>
        <translation>Max hodnota (celé č.):</translation>
    </message>
    <message>
        <source>Media player type:</source>
        <translation>Media player:</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows media player</translation>
    </message>
    <message>
        <source>Default name:</source>
        <translation>Přednastavené jméno:</translation>
    </message>
    <message>
        <source>VAT type:</source>
        <translation>Typ daně:</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cena včetně daně</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Cena bez daně</translation>
    </message>
    <message>
        <source>Max string length:</source>
        <translation>Max délka řetězce:</translation>
    </message>
    <message>
        <source>Preferred number of rows:</source>
        <translation>Požadovaný počet řádků:</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Aktuální čas</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class</source>
        <translation>Editování třídy</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Vytvořil</translation>
    </message>
    <message>
        <source>on</source>
        <translation>dne</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation>Naposledy změnil</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation>Identifikátor:</translation>
    </message>
    <message>
        <source>Object name pattern:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Member of groups:</source>
        <translation>Člen skupiny:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Přidat do skupiny</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Odstranit ze skupin</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Zadaná data nejsou platná</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Zadání bylo úspěšně uloženo</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributy</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Požadovaná hodnota</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>K prohledávání</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Dolu</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Nahoru</translation>
    </message>
    <message>
        <source>Datatypes:</source>
        <translation>Typy dat:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Opustit změny</translation>
    </message>
    <message>
        <source>Editing class group</source>
        <translation>Editování skupiny tříd</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Změnil</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Opustit</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Opravdu chcete odstranit tyto třídy?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Odstraněním třídy %1 bude odstraněno %2!</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Opravdu chcete odstranit tyto skupiny tříd?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Odstraněním skupiny tříd %1 budou odstraněny třídy %2!</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Defined class groups</source>
        <translation>Definovaná třída skupin</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:Jméno:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation>Změnil:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Změněno:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes in </source>
        <translation>Zádné třídy v</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Třídy v</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation>ID:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation>Identifikátor:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation>Změnil:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Změněno:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Copy:</source>
        <translation>Kopírovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Seznam tříd pro &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Ve skupině nejsou žádné položky.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Skupiny</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Schválit</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 čeká na schválení editora</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 čeká na schválení k publikování</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 nebol schváleno k  publikování</translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 čeká na Vaše schválení </translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Předmět</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Přečteno</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nové</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Neaktivní</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Odesláno: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Žádné nové položky ke zpracování.</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Schválit</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was deferred and is available as a draft.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>The content object %1 was deferred and will be available as a draft.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Poznámka</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Přidat poznámku</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Schválit</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation></translation>
    </message>
    <message>
        <source>Defer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Zprávy</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Opravdu chcete odstranit tento překlad?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Změnit překlad pro obsah</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Nový překlad pro obsah</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Překlady</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Jméno překladu</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Místní nastavení</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Změnit</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Vytvořit</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Překlady obsahu</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Níže jsou vypsány jazyky do nichž může být obsah přeložen.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Země:</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation>Místní nastavení:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying:</source>
        <translation>Kopíruji:</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Verze</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Kopírovat všechny verze</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Kopírovat aktuální verzi</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Vytvořit nový</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>New author</source>
        <translation>Nový autor</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Odstranit vybrané</translation>
    </message>
    <message>
        <source>Filename:</source>
        <translation>Název souboru:</translation>
    </message>
    <message>
        <source>MIME Type:</source>
        <translation>MIME Type:</translation>
    </message>
    <message>
        <source>Filesize:</source>
        <translation>Velikost souboru:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Year:</source>
        <translation>Rok:</translation>
    </message>
    <message>
        <source>Month:</source>
        <translation>Měsíc:</translation>
    </message>
    <message>
        <source>Day:</source>
        <translation>Den:</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation>Hodina:</translation>
    </message>
    <message>
        <source>Minute:</source>
        <translation>Minuta:</translation>
    </message>
    <message>
        <source>Image filename:</source>
        <translation>Název souboru obrázku:</translation>
    </message>
    <message>
        <source>Alternative image text:</source>
        <translation>Náhradní text k obrázku:</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Odstranit obrázek</translation>
    </message>
    <message>
        <source>ISBN:</source>
        <translation>ISBN:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Šířka:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Výška:</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Kvalita:</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Dobrá</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Nízká</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controls:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>InfoPanel</translation>
    </message>
    <message>
        <source>Existing filename:</source>
        <translation>Soubor:</translation>
    </message>
    <message>
        <source>Existing orignal filename:</source>
        <translation>Původní soubor:</translation>
    </message>
    <message>
        <source>Existing mime/type:</source>
        <translation>Mime/type:</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Najdi objekt</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Volby:</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nová volba</translation>
    </message>
    <message>
        <source>Start value:</source>
        <translation>Počáteční hodnota:</translation>
    </message>
    <message>
        <source>Stop value:</source>
        <translation>Koncová kodnota:</translation>
    </message>
    <message>
        <source>Step value:</source>
        <translation>Krok:</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>User ID:</source>
        <translation>ID uživatele:</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation>Login:</translation>
    </message>
    <message>
        <source>E-Mail:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Potvrzení hesla:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Cena:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Vaše cena:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Ušetříte:</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Info o uživatelském účtu</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation>Email:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from:</source>
        <translation>Informace získány z:</translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation>Byly získány tyto informace:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <source>Store Draft</source>
        <translation>Uložit koncept</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Poslat k vydání</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Opustit</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Setřídit podle</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Třídění</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Hlavní</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Přesunout</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Jméno</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Vydáno</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Změněno</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekce</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Hloubka</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Identifikátor třídy</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Jméno třídy</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Přidat umístění</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Info o objektu</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation>Vytvořeno:</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Zatím nevydáno</translation>
    </message>
    <message>
        <source>Version info</source>
        <translation>Info o verzi</translation>
    </message>
    <message>
        <source>Editing:</source>
        <translation>Edituji:</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Aktuální</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Překlady</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Příbuzné objekty</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Najít</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>Kontrola platnosti neuspěla</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Zadaná data nejsou platná</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Zadané umístění není platné</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Zadání bylo úspěšně uloženo</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Opravdu chcete odstranit tento koncept?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Pokročilé vyhledávání</translation>
    </message>
    <message>
        <source>No results were found when searching for:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for:</source>
        <translation>Hledej:</translation>
    </message>
    <message>
        <source>returned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all the words:</source>
        <translation>Hledej všechna slova:</translation>
    </message>
    <message>
        <source>Search the exact phrase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search with at least one of the words:</source>
        <translation>Najdi alespoň jedno ze slov:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation>Třida:</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Jakákoliv třída</translation>
    </message>
    <message>
        <source>Class attribute:</source>
        <translation>Atributy třídy:</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In:</source>
        <translation>V:</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Jakákoliv sekce</translation>
    </message>
    <message>
        <source>Published:</source>
        <translation>Vydáno:</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Jakýkoliv čas</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Včera</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Minulý týden</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Minulý měsíc</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Minulé 3 měsíc</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Loni</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <source>For more options try the %1advanced search%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No results were found for searching:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object name</source>
        <translation>Jméno objektu</translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Jméno třídy</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating</source>
        <translation>Překládám</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 bylo úspěšně uloženo</translation>
    </message>
    <message>
        <source>Remove the following translations from</source>
        <translation>Odstranit následující překlady z</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation>Místní nastavení:</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Info o místním nastavení není k dispozici)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Translate into:</source>
        <translation>Přeložit do:</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Překlady</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Přeložit</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Edit Object</source>
        <translation>Editovat objekt</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation>Třida:</translation>
    </message>
    <message>
        <source>Section:</source>
        <translation>Sekce:</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation>Aktuální verze:</translation>
    </message>
    <message>
        <source>Restore:</source>
        <translation>Obnovit:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Koš je prázdný </translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for:</source>
        <translation>Verze pro:</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Verze není koncept</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <source>is not available for editing anymore, only drafts can be edited.</source>
        <translation>není možno editovat, pouze koncepty jsou editovatelné.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Pro editaci vytvořte kopii.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Verze není Vaše</translation>
    </message>
    <message>
        <source>was not created by you, only your own drafts can be edited.</source>
        <translation>nebyla Vámi vytvořena, smíte editovat pouze Vaše koncepty.</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Verze:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Stav:</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Překlady:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Vytvořil:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Změněno:</translation>
    </message>
    <message>
        <source>Object Edit</source>
        <translation>Editovat objekt</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation>Procházet</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Select:</source>
        <translation>Vybrat:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Vybrat</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Koncepty</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation>Třida:</translation>
    </message>
    <message>
        <source>Section:</source>
        <translation>Sekce:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Verze:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Nemáte žádné koncepty</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation>Aktuální verze:</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Příbuzné objekty</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <source>Translation:</source>
        <translation>Překlady:</translation>
    </message>
    <message>
        <source>Placement:</source>
        <translation>Umístění:</translation>
    </message>
    <message>
        <source>Site Design:</source>
        <translation>Design stránek:</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Změnit</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Vydat</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Verze</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Přístup odepřen</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>Nemáte přístup do této části.</translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Stlačte tlačítko login pro přihlášení.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nenalezeno</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Modul nenalezen</translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation>Požadovaný modul &apos;%1&apos; nebyl nalezen.</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Pohled nenalezen</translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation>Požadovaný pohled &apos;%1&apos; nebyl v modulu &apos;%2&apos; nalezen</translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation>Nedostupný</translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation>Objekt není dostupný.</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Vítejte v eZ publish administraci</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Zadejte jméno a heslo.</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Stránky:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Verze:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logout</translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation>%1 titulní strana</translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation>Hledat %1</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Formátovat pro tisk</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Pokročilé vyhledávání</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Titulní strana</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Mapa stránek</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Osobní</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Změnit heslo</translation>
    </message>
    <message>
        <source>Redirecting to:</source>
        <translation>Přesměrovávám na:</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Přesměrovat</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Restart</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Chyba při nahrávání modulu</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Nedefinovaný modul:</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Předchozí</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Další</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Opravdu chcete odstranit %1 z uzlu %2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation>Odstaněním tohoto přiřazení bude také odstraněn %1!</translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation>Odstraňování přiřazení</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation>Opravdu chcete odstranit tyto uzly?</translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2!</source>
        <translation>Odstraněním %1 bude odstraněn také uzel a jeho %2!</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Následující položky byly odstraněny z Vašeho nákupního koše, protože údaje o zboží byly změněny</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation>Třida:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorita:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Copy:</source>
        <translation>Kopírovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Uživatel</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Skupina uživatelů</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Mapa stránek</translation>
    </message>
    <message>
        <source>Object:</source>
        <translation>Objekt:</translation>
    </message>
    <message>
        <source>Section ID:</source>
        <translation>ID sekce:</translation>
    </message>
    <message>
        <source>You are not allowed to create child objects</source>
        <translation>Nemáte oprávnění vytvořit potomky objektu</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Notification registration form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Method:</source>
        <translation>Způsob odeslání:</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>Internal message</source>
        <translation>Interní zpráva</translation>
    </message>
    <message>
        <source>Send day:</source>
        <translation>Kdy poslat (den):</translation>
    </message>
    <message>
        <source>Immediately</source>
        <translation>Hned</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>V pondělí</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>V úterý</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Ve středu</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Ve čtvrtek</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>V pátek</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>V sobotu</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>V neděli</translation>
    </message>
    <message>
        <source>Send time:</source>
        <translation>Kdy poslat (čas):</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrovat</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Opustit</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation>ID:</translation>
    </message>
    <message>
        <source>Rule Type:</source>
        <translation>Typ pravidla:</translation>
    </message>
    <message>
        <source>Class Name:</source>
        <translation>Jméno třídy:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Cesta:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation>Klíčové slovo:</translation>
    </message>
    <message>
        <source>Additional constraint:</source>
        <translation>Další omezení:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>New Rule</source>
        <translation>Nové pravidlo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation>Poslat zprávu</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/rules</name>
    <message>
        <source>Content Class Name:</source>
        <translation>Jméno třídy obsahu:</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Cesta:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation>Klíčové slovo:</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Vytvořit strategii pro</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Krok 1</translation>
    </message>
    <message>
        <source>Give access to module:</source>
        <translation>Udělit přístup k modulu:</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Každý modul</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Povolit vše</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Povolit omezeně</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Module:</source>
        <translation>Modul:</translation>
    </message>
    <message>
        <source>Access:</source>
        <translation>Přístup:</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Omezený</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Vrátit se ke kroku 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Krok 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Vyberte funkci v modulu</translation>
    </message>
    <message>
        <source>Function:</source>
        <translation>Funkce:</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Vrátit se ke kroku 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Krok 3</translation>
    </message>
    <message>
        <source>Specify limitations in function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;Any&apos; means no limitation by this parameter.</source>
        <translation>&apos;Jakýkoliv&apos; znamená bez omezení pro tento parametr.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Jakýkoliv</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation>Editovat pravidlo</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Current policies:</source>
        <translation>Aktuální strategie:</translation>
    </message>
    <message>
        <source>Limitations:</source>
        <translation>Omezení:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Opustit změny</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Seznam pravidel</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation>Přiřadit:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Zobrazení pravidla</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limitation:</source>
        <translation>Omezení:</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Uživatelé a skupiny kteří mají přiřazené toto pravidlo</translation>
    </message>
    <message>
        <source>User:</source>
        <translation>Uživatel:</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Přiřadit</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Statistiky vyhledávání</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Nejhledanější slova</translation>
    </message>
    <message>
        <source>Phrase:</source>
        <translation>Fráze:</translation>
    </message>
    <message>
        <source>Number of phrases:</source>
        <translation>Počet slov:</translation>
    </message>
    <message>
        <source>Average result returned:</source>
        <translation>Průměrně vyhledaných odpovědí:</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section</source>
        <translation>Přiřaďit sekci</translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation>Přiřaďit sekci k uzlu</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Opravdu chcete odstranit tyto sekce?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Odstraněním těchto sekcí můžete poškodit oprávnění, design stránek a jiné další věci v systému. Pokud opravdu nevíte co děláte, nedělejte to.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Editovat sekci</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Navigation Part:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Obsah</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Obchod</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Uživatelé</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Osobní</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Seznam sekcí</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation>ID:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation>Přiřadit:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>site registration</source>
        <translation>registrace stránek</translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation>Info o stránkách:</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titulek</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation>PHP info:</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation>OS info:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Jméno</translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation>Database info:</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Ovladač</translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <source>Supported</source>
        <translation>Podporováno</translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation>Nepodporováno</translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation>Ukázková data:</translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation>Ukázková data byla nainstalována.</translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation>Ukázková data nebyla nainstalována.</translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation>Email info:</translation>
    </message>
    <message>
        <source>Transport</source>
        <translation>Přenos</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>sendmail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation>Konverze obrázků:</translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation>Byl nalezen ImageMagick a bude využíván.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Spustitelný</translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation>ImageGD extension byla nalezena a bude využívána.</translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation>Regional info:</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Jednojazyčný</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Vícejazyčný</translation>
    </message>
    <message>
        <source>Primary</source>
        <translation>Primární</translation>
    </message>
    <message>
        <source>Additional</source>
        <translation>Druhotný</translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation>Velice důležité testy:</translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Úspěch</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Neúspěch</translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation>Další testy:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <source>setup</source>
        <translation>nastavení</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Pokud máte problém s připojením k databázi, podívejte se na</translation>
    </message>
    <message>
        <source>at</source>
        <translation>na</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation></translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Úvod</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL je relační databáze od MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>Je v současné době jedním z nejpopulárnějších datatabází z Open Source a často používanou ve spojení s PHP.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>Jejich internetové stránky:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL je nejpopulárnější Open Source databáze, navrhovaná s důrazem na rychlost.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Více informací můžete najít na</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detaily</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL je výborná pro uchovávání dat v jazycích nevyužívajících diakritiku. Není však tou nejlepší volbou pro Unicode a ostatní jazyky.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalace</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>Použitím</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Více informací o MySQL můžete najít na</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL je relační databáze, vyvýjená na University of California v Berkeley na Computer Science Department.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>Je to velice populární Open Source databáze a nabízí velice pokročilé funkce.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Pro povolení podpory PostgreSQL,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>je nutno překompilovat PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Více informací o PostgreSQL můžete najít na</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the</source>
        <translation>Databáze je připravena na inicializaci, stlačte</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Vytvořit databázi</translation>
    </message>
    <message>
        <source>button when ready.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation>Pokud máte zájem můžou být do databáze zavedena ukázková data. Můžete takto dostat představu o možnostech eZ publish</translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation>Nováčkům je doporučováno nainstalovat ukázková data.</translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation>Nainstalovat ukázková data?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>Nelze nainstalovat ukázková data, chybí zlib modul v instalaci Vašeho PHP.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Chyba při istalování ukázkových dat</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Nelze dekomprimovat ukázková data.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Doporučujeme zkusit instalaci bez ukázkových dat.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Inicializace selhala</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>Datábáze nemohla být správně inicializována.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Vaše databáze již obsahuje data.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>Pokračováním instalace budou smazána stávající data.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Co vše požadujete nastavit?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Pokračuj, ale ponechej data bezezměny.</translation>
    </message>
    <message>
        <source>Continue and remove the data.</source>
        <translation>Pokračuj a smaž data.</translation>
    </message>
    <message>
        <source>Continue and skip database initialization.</source>
        <translation>Pokračuj a vynech inicializaci databáze.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Chci si vybrat novou databázi.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Poznámka:</translation>
    </message>
    <message>
        <source>It can take some time creating the database so please be patient and wait until the new page is finished.</source>
        <translation>Vytváření databáze může trvat pár minut. Buďte prosím trpěliví a počkejte dokud nebude zobrazena následující stránka.</translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation>Nyní je potřeba vybrat databázi. Výběr předurčí podporu jazyků. (Once you are done click)</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Výběr jazyků</translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>Driver:</source>
        <translation>Ovladač:</translation>
    </message>
    <message>
        <source>Unicode support:</source>
        <translation>Podpora Unicode:</translation>
    </message>
    <message>
        <source>no</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <source>The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Konfigurovat</translation>
    </message>
    <message>
        <source>button to start the configuration process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation>Není připojení na databázi</translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation>Nelze se připojit k databázi.</translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation>Nelze se připojit k databázi. Zkontrolujte nastavení a zkuste znovu.</translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button.</source>
        <translation>tlačítko.</translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation>Pokud máte eZ publish databázi již vytvořenou zadejte informace o ní.</translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation>Prázdné heslo</translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation>Musíte zadat heslo pro přístup do databáze.</translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation>Zadané heslo a potvrzení hesla nejsou stejné.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Neznámá chyba</translation>
    </message>
    <message>
        <source>Servername:</source>
        <translation>Název serveru:</translation>
    </message>
    <message>
        <source>Socket:</source>
        <translation>Socket:</translation>
    </message>
    <message>
        <source>Databasename:</source>
        <translation>Jméno databáze:</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Uživatelské jméno:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Potvrzení hesla:</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>Kontrola systému našla několik věcí, které je třeba poopravit pro dosažení lepšího výkonu nebo umožnění více funkcí. Prosím podívejte se na níže uvedený seznam. Každá položka obsahuje postup k opravě.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>Když jste provedli opravy, stlačte tlačítko</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Spusťe znovu kontrolu systému</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>pro znovu-spustění kontroly. Toto je zvláště doporučeno po úpravách částí systému, jestli nebyly vytvořeny nějaké žávažné chyby. Také můžete použít tlačítko</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Zkontroluj vyladění systému znovu</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>pro opětovné zkontrolování vyladění systému. Pokud si přejete přikročit k dalšímu kroku, stlačte </translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Seznam</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Chyba při zápisu</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>Nelze psát do souboru. </translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>Nelze zapisovat do</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Zkus znovu</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Změň druhou řádku z</translation>
    </message>
    <message>
        <source>to</source>
        <translation>na</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Pro odesílání elektronické pošty (E-mailů) si můžete vybrat mezi</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>sendmail-em</translation>
    </message>
    <message>
        <source>which must available on the server or</source>
        <translation>(musí být na serveru nainstalován), nebo</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation>. Pokud si nejste jisti, kontaktujete správce. Někde není podpora</translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server name</source>
        <translation>Název serveru</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Uživatelské jméno</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation>Chyba při odesílání Emailu</translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation>Chyba při odesílání registrace Emailem</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to the</source>
        <translation>Pokud potřebujete pomoc s eZ publish, navštivte</translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>web eZ publish</translation>
    </message>
    <message>
        <source>If you find a bug (error), please go to</source>
        <translation>Pokud najdete chybu, prosím nahlašte ji na</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>eZ publish hlášení chyb</translation>
    </message>
    <message>
        <source>and report it.</source>
        <translation>a tam ji popište.</translation>
    </message>
    <message>
        <source>With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>S Vaší pomocí můžeme lépe opravovat chyby a implementovat nové vlastnovi.</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the URL to access your new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <source>button. Enjoy one of the most successful web content management systems!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Odeslat registraci</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Přeskočit registraci</translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title of your site:</source>
        <translation>Název Vašich stránek:</translation>
    </message>
    <message>
        <source>URL to your site:</source>
        <translation>URL Vašich stránek:</translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Jednojazyčné</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Vícejazyčné (všechny jazyky mají stejnou znakovou sadu)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Vícejazyčné (s využitím unicode)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Místní nastavení</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Nastavení databáze</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Databáze</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Ovladač</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Podpora Unicode</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Výběr jazyků</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Typ jazyka</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Jednojazyčný</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Vícejazyčný</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Jazyky</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>Nebyly nalezeny žádné chyby, můžete pokračovat v průvodci nastavení stlačením</translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation>Pokud si přejete vyladit Váš systém, stlačte </translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Vyladit systém</translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation>Kontrola systému našla několik chyb, které je třeba opravit.</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Prosím podívejte se na uvedený seznam chyb.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>U každé chyby je uveden postup jak jí odstranit.</translation>
    </message>
    <message>
        <source>button to re-run the system checking.</source>
        <translation>tlačítko pro znovu-spustění  kontroly systému.</translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish</source>
        <translation>Vítejte v průvodci nastavení eZ publish </translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation>V této části budou provedeny nezbytné kroky pro řádné nastavení systému ez Publish</translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation>Pro provedení kontroly systému stiskněte tlačítko Zkontrolovat systém.</translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation>Pokud si přejete systém nastavit ručně, stlačte tlačítko</translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation>Zakázat průvodce nastavení</translation>
    </message>
    <message>
        <source>System Check</source>
        <translation>Zkontrolovat systém</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Chybí ovladače databází</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Vaše PHP nemá podporu všech databází, se kterými může eZ publish spolupracovat.</translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>eZ publish může fungovat i bez tohoto, můžete se však stát, že podporu pro konkrétní databázi budete vyžadovat.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Některé databáze mají vlastnosti a podpory znakových sad, které jiným chybí.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Pro podporu databází je třeba překompilovat PHP. Přesný návod je uveden níže.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Chybí ovladače databáze</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>Nebyly nalezeny ovladače pro žádnou databázi. eZ publish vyžaduje databázi pro uložení dat, bez tohoto nemůže pracovat.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Pro podporu databází je třeba překompilovat PHP. Přesný návod je uveden níže.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Nedostatečná práva pro přístup do adresáře</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish nemůže zapisovat do některých důležitých adresářů. Bez tohoto nelze dokončit průvodce instalací ani provozovat systém eZ publish.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Doporučujeme opravu spustěním příkazů uvedených níže.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Příkazy</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Zakázané uploadovaní (nahrávání) souborů</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>Zakázání uploadování souborů postihne pouze určitou část systému. Pokud nebudete pracovat se soubory, není toto nutné. Každopádně doporučujeme toto povolit.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Konfigurace</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Povolení uploadu souborů se provádí nastavením %1 v php.ini. Pro více informací o možnostech této volby doporučujeme manuál PHP</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Více informace můžete získat přečtením %1 a %1</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Chybí podpora konverzí obrázků</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>Nebyl nalezen žádný využitelný program pro konverzi obrázků. To znamená že eZ publish nebude moci provádět změny velikost obrázků ani detekovat jejich typ. Pro běh systému je tato funkce životně důležitá.</translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation>Chybí imagegd extension</translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>Chybí imagegd extension. Bez ní bude eZ publish pro konverze obrázků využívat pouze ImageMagick a</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>operátor pro šablony nebude funkční.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Poznámka:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Budoucí verze eZ publish budou mít pokročilejší funkce pro manipulaci s obrázky a budou více využívat  imagegd extension.</translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Pro podporu imagegd je třeba překompilovat PHP. Více informací naleznete na</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Chybí program ImageMagic</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>Chybí program ImageMagic. Pokud není k dispozici  imagegd extension nebude systém eZ publish schopen provádět konverze obrázků.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Pokud máte tento program nainstalovaný (soubor se jmenuje</translation>
    </message>
    <message>
        <source>or</source>
        <translation>nebo</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>) pak zadejte adresář do pole níže a proveďte kontrolu znovu. (Adresáře od sebe oddělte</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>dvojtečkou</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>středníkem</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalace</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagick můžete stáhnout z</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Chybí MBString extension</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>eZ publish podporuje pěknou řádku znakových sad. Tato podpora však může být poměrně pomalá, neboť je psána v čistém PHP jazyce. Nastěstí lze pro některé znakové sady využít mbstring extension.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>Povolením mbstring extension získá eZ publish možnost pracovat s více znakovými sadami a tato práce bude rychlejší. Pro vícejazyčné stránky je toto doporučováno.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation>Seznam znakových sad které mbstring podporuje:</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>Pro instalace mbstring extension je třeba překompilovat PHP s volbou</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Více informací můžete najít na</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>Nepovolujte mbstring function overloading.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>PHP volba</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>je povolena</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish bude pracovat správně, ačkoliv to povede k jistým mírným ztrátám výkonu, neboť všechny vstupní proměnné musí být převedeny zpět do </translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normálního tvaru</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your</source>
        <translation>Doporučuje se tuto volbu vypnout. Toto provedete editací vašeho</translation>
    </message>
    <message>
        <source>configuration and set</source>
        <translation>konfiguračního souboru, nastavením</translation>
    </message>
    <message>
        <source>and</source>
        <translation>a</translation>
    </message>
    <message>
        <source>to</source>
        <translation>na hodnotu</translation>
    </message>
    <message>
        <source>More information on the subject can be found at</source>
        <translation>Více informací naleznete na</translation>
    </message>
    <message>
        <source>Configuration example:</source>
        <translation>Příklad:</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Nedostačující (nízká) verze PHP</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Verze Vašeho PHP je</translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>, což nepostačuje minimálním požadavkům</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>Novější verzi PHP můžete stáhnout na</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Musíte upgradovat (povýšit) alespoň na verzi</translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation>, novější verze, v současné době 4.2.3, je vřeje doporučována.</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish nemůže zapisovat do</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>adresáře, bez tohoto nemůže být průvodce nastavením zakázán.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>Chybí zlib extension</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>Chybá zlib extension. Bez ní nelze instalovat ukázková data. Pokud si však instalovat tyto data nepřejete, můžete pokračovat dále.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>Pro povolení zlib je třeba přikompilovat podporu v PHP. Budete muset zkonfigurovat PHP s</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Více informací naleznete na</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price ex. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price inc. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount:</source>
        <translation>Sleva:</translation>
    </message>
    <message>
        <source>Total Price ex. VAT:</source>
        <translation type="unfinished">neco</translation>
    </message>
    <message>
        <source>Total Price inc. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defined discount groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing discount group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defined rules:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount percent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose which classes or sections applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percentage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Triggers list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triggers editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Platný</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Neplatný</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>Tato URL již není platná.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>Toto znamená, že url již není k dispozici, nebo bylo přesunuto.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>URL ukazuje na %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Naposledy změněno  %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>U URL není datum poslední změny</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Poslední kontrola %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>URL zkontrolováno</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Activate account</source>
        <translation>Aktivovat účet</translation>
    </message>
    <message>
        <source>Login ID:</source>
        <translation>Login ID:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Aktivovat</translation>
    </message>
    <message>
        <source>Registed user profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login:</source>
        <translation>Login:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation>e-mail:</translation>
    </message>
    <message>
        <source>Update Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Změnit heslo</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation>Změnit nastavení</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Nelze přihlásit</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Pro přihlášení zadejte správný login a heslo.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Přístup odepřen</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Přístup k %1 odepřen.</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation>Založit účet</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Změnit heslo pro uživatele</translation>
    </message>
    <message>
        <source>Old Password:</source>
        <translation>Staré heslo:</translation>
    </message>
    <message>
        <source>New Password:</source>
        <translation>Nové heslo:</translation>
    </message>
    <message>
        <source>Retype Password:</source>
        <translation>Potvrzení nového hesla:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Registrovat uživatele</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Zadaná data nejsou platná</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Zadání bylo úspěšně uloženo</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrovat</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Opustit</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Uživatelské nastavení</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Je povoleno</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Uživatel registrován</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Nový účet byl úspěšné vytvořen.</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Editing workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Skupiny</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Události</translation>
    </message>
    <message>
        <source>Pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Popis:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Opustit</translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Vytvořil</translation>
    </message>
    <message>
        <source>on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Změnil</translation>
    </message>
    <message>
        <source>Defined workflow groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Editovat:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Odstranit:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation>Uživatel</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>using version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Další krok</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Jméno</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informace</translation>
    </message>
    <message>
        <source>Defined workflows for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation>Změnil:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Změněno:</translation>
    </message>
    <message>
        <source>Temporary workflows for</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sections:</source>
        <translation>Sekce:</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Jakýkoliv</translation>
    </message>
    <message>
        <source>Users without approval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Zpráva:</translation>
    </message>
    <message>
        <source>Section IDs:</source>
        <translation>ID sekce:</translation>
    </message>
    <message>
        <source>Users without workflow IDs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days:</source>
        <translation>Dny:</translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation>Hodiny:</translation>
    </message>
    <message>
        <source>Minutes:</source>
        <translation>Minuty:</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Odstranit vybrané</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class:</source>
        <translation>Třida:</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>Atributy třídy:</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/result</name>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Seznam tříd ve skupině</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Seznam skupin tříd</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Odstranit třídu</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Editovat třídu</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Třídy</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Seznam tříd</translation>
    </message>
    <message>
        <source> object</source>
        <translation>objekt</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>objekty</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Odstranit třídy</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(nejsou žádné třídy)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Odstranit třídu skupin</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Schválit</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Pozorovatel</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Vlastník</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Schvalovatel</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Přijaté</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Přijatá událost</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Odmítnutá událost</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatype/ezbinaryfiletype</name>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Není povolen upload souborů, nelze pracovat se soubory.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is requied.</source>
        <comment>eZAuthorType</comment>
        <translation>Je vyžadován alespoň jeden autor.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation>Jméno autora by mělo být zadáno.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation>Neplatná emailová adresa.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation>Je požadován existující soubor.</translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation>Chybí datum.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Chybí datum a čas.</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation>Je požadována platná emailová adresa.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation>Neplatná emailová adresa.</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation>Měla by být vybrána alespoň jedna volba.</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation>Není zadáno desetinné číslo.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation>Číslo musí být větší než %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation>Číslo musí být menší než %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation>Číslo musí být z rozsahu %1 - %2</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation>Je požadován existující obrázek.</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation>Není zadáno celé číslo.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Číslo musí být větší než %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Číslo musí být menší než %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation>Číslo musí být z rozsahu %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation>Zadané ISBN není platné. Prosím zadejte správné</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation>Formát ISBN neni platný.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation>Je požadován existující soubor.</translation>
    </message>
    <message>
        <source>At least one option is requied.</source>
        <comment>eZOptionType</comment>
        <translation>Musí být vybrána alespoň jedna volba.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation>Text je přílis dlouhý, maximální délka textu je %1.</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Chybí datum.</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation>Tento login již existuje, prosím vyberte jiný.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation>Neplatná emailová adresa.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>Zadané heslo a potvrzení hesla nejsou stejné.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation>Heslo musí mít alespoň 3 znaky.</translation>
    </message>
    <message>
        <source>Object </source>
        <translation>Objekt</translation>
    </message>
    <message>
        <source>Link </source>
        <translation>Link </translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Spolupráce</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Není vybrán hlavní uzel, prosím vyberte jej.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Obsah</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Koncepty</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Odstranit objekt</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Přeložit</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Překlad</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Verze</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>potomka</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>potomků</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Tyto uzly budou také odebrány:</translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>potomek</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>potomků</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notification rule list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Statistiky vyhledávání</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Editovat sekci</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sekce</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Nákupní koš</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Potvrdit objednávku</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Slevová skupina</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Seznam objednávek</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Typy daní</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation>Seznam</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Seznam</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Pohled</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Uživatel</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Změnit heslo</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrovat</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Editovat skupinu</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation>Seznam</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Došlo k několika chybám při zpracovávání šablony, více info v debugu.</translation>
    </message>
</context>
</TS>
