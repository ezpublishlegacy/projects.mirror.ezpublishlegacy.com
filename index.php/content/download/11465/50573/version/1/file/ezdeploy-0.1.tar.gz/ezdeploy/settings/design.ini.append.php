<?php /*

[ExtensionSettings]
DesignExtensions[]=ezdeploy

*/ ?>