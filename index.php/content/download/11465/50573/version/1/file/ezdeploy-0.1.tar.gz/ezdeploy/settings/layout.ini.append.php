<?php /*

[offline]
PageLayout=offline_pagelayout.tpl

*/ ?>