<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezservervars

*/ ?>