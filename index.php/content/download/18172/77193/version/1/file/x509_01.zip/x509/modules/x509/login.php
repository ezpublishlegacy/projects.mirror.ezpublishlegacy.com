<?php
include_once ('kernel/common/template.php');
include_once ('kernel/common/eztemplatedesignresource.php');
include_once ("lib/ezutils/classes/ezhttptool.php");
include_once ('extension/x509/classes/x509_user.php');
//include_once ('extension/x509/classes/x509_lib_wrapper.php');

$Module = $Params['Module'];

$http = eZHTTPTool::instance();
$ini = eZINI::instance();

$userRedirectURI = '';

$loginWarning = false;

$siteAccessAllowed = true;
$siteAccessName = false;

if (isset ($Params['SiteAccessAllowed']))
	$siteAccessAllowed = $Params['SiteAccessAllowed'];
if (isset ($Params['SiteAccessName']))
	$siteAccessName = $Params['SiteAccessName'];

$postData = ''; // Will contain post data from previous page.
if ($http->hasSessionVariable('$_POST_BeforeLogin')) {
	$postData = $http->sessionVariable('$_POST_BeforeLogin');
  $http->removeSessionVariable('$_POST_BeforeLogin');
}

if ($Module->hasActionParameter('X509URL'))
{
  $x509_cert = $Module->actionParameter('X509URL');
}
elseif ($http->hasSessionVariable( "X509URL" ))
{
  $x509_cert = $http->sessionVariable( "X509URL" );
}
else
{
  $loginWarning = true;
}
$x509_cert = $_SERVER["SSL_CLIENT_CERT"];

if ($http->hasSessionVariable('X509Action'))
{
  $action = $http->sessionVariable('X509Action');
  $http->removeSessionVariable( "X509Action" );
  if ($action == 'login')
  {
    $msg = '';


    if (isset($_SERVER["SSL_CLIENT_CERT"])) 
    {
      // This means the authentication succeeded; extract the
      // identity URL and Simple Registration data (if it was
      // returned).
      $http->removeSessionVariable( "X509URL" );
      $x509_user = x509_user::fetchByURL($x509_cert);
      // TODO need to make sure we have a x509_user object
      $userID = $x509_user->attribute('user_id');
      $user = $x509_user->attribute('user');
      // Authorisation OK - Log the user in
      eZUser::setCurrentlyLoggedInUser($user, $userID);
      eZUser::updateLastVisit($userID);
      $x509_user->updateLastVisit();
      // Check access - sourced from user/login
      if ($user instanceof eZUser) 
      {
        $uri = eZURI::instance(eZSys::requestURI());
        $access = accessType($uri, eZSys::hostname(), eZSys::serverPort(), eZSys::indexFile());
        $siteAccessResult = $user->hasAccessTo('user', 'login');
        $hasAccessToSite = false;
        // A check that the user has rights to access current siteaccess.
        if ($siteAccessResult['accessWord'] == 'limited') 
        {
        
           $hasAccessToSite = $user->canLoginToSiteAccess( $GLOBALS['eZCurrentAccess'] );       
        }
        elseif ($siteAccessResult['accessWord'] == 'yes') 
        {
          $hasAccessToSite = true;
        }
        // If the user doesn't have the rights.
        if ( !$hasAccessToSite )
        {
            $user->logoutCurrent();
            $user = null;
            $siteAccessName = $GLOBALS['eZCurrentAccess']['name'];
            $siteAccessAllowed = false;
        } 
      }
      // Work out where we are going to redirect them to
      $requireUserLogin = ( $ini->variable( "SiteAccessSettings", "RequireUserLogin" ) == "true" );
      if ( !$requireUserLogin )
      {
        if ( $http->hasSessionVariable( "LastAccessesURI" ) )
          $userRedirectURI = $http->sessionVariable( "LastAccessesURI" );
      }
    
      if ( $http->hasSessionVariable( "RedirectAfterLogin" ) )
      {
        $userRedirectURI = $http->sessionVariable( "RedirectAfterLogin" );
        $http->removeSessionVariable( "RedirectAfterLogin" );
      }
       
      $redirectionURI = $userRedirectURI;
      // Determine if we already know redirection URI.
      $haveRedirectionURI = ($redirectionURI != '' && $redirectionURI != '/');
    
      if (!$haveRedirectionURI)
        $redirectionURI = $ini->variable('SiteSettings', 'DefaultPage');
    
       /* If the user has successfully passed authorization
        * and we don't know redirection URI yet.
        */
       if (is_object($user) && !$haveRedirectionURI) 
       {
       /*
        * Choose where to redirect the user to after successful login.
        * The checks are done in the following order:
        * 1. Per-user.
        * 2. Per-group.
        *    If the user object is published under several groups, main node is chosen
        *    (it its URI non-empty; otherwise first non-empty URI is chosen from the group list -- if any).
        *
        * See doc/features/3.8/advanced_redirection_after_user_login.txt for more information.
        */
     
        // First, let's determine which attributes we should search redirection URI in.
        $userUriAttrName = '';
        $groupUriAttrName = '';
        if ($ini->hasVariable('UserSettings', 'LoginRedirectionUriAttribute')) 
        {
          $uriAttrNames = $ini->variable('UserSettings', 'LoginRedirectionUriAttribute');
          if (is_array($uriAttrNames)) 
          {
            if (isset ($uriAttrNames['user']))
              $userUriAttrName = $uriAttrNames['user'];
     
            if (isset ($uriAttrNames['group']))
              $groupUriAttrName = $uriAttrNames['group'];
          }
        }
     
        $userObject = $user->attribute('contentobject');
     
        // 1. Check if redirection URI is specified for the user
        $userUriSpecified = false;
        if ($userUriAttrName) 
        {
          $userDataMap = $userObject->attribute('data_map');
          if (!isset ($userDataMap[$userUriAttrName])) 
          {
            eZDebug::writeWarning("Cannot find redirection URI: there is no attribute '$userUriAttrName' in object '" .
            $userObject->attribute('name') .
              "' of class '" .
              $userObject->attribute('class_name') . "'.");
          }
          elseif (($uriAttribute = $userDataMap[$userUriAttrName]) && ($uri = $uriAttribute->attribute('content'))) 
          {
            $redirectionURI = $uri;
            $userUriSpecified = true;
          }
        }
     
        // 2.Check if redirection URI is specified for at least one of the user's groups (preferring main parent group).
        if (!$userUriSpecified && $groupUriAttrName && $user->hasAttribute('groups')) 
        {
          $groups = $user->attribute('groups');
     
          if (isset ($groups) && is_array($groups)) 
          {
            $chosenGroupURI = '';
            foreach ($groups as $groupID) 
            {
              $group = eZContentObject::fetch($groupID);
              $groupDataMap = $group->attribute('data_map');
              $isMainParent = ($group->attribute('main_node_id') == $userObject->attribute('main_parent_node_id'));
     
              if (!isset ($groupDataMap[$groupUriAttrName])) 
              {
                eZDebug::writeWarning("Cannot find redirection URI: there is no attribute '$groupUriAttrName' in object '" .
                  $group->attribute('name') .
                  "' of class '" .
                  $group->attribute('class_name') . "'.");
                continue;
              }
              $uri = $groupDataMap[$groupUriAttrName]->attribute('content');
              if ($uri) 
              {
                if ($isMainParent) 
                {
                  $chosenGroupURI = $uri;
                  break;
                }
                elseif (!$chosenGroupURI) 
                  $chosenGroupURI = $uri;
              }
            }
     
            if ($chosenGroupURI) // if we've chose an URI from one of the user's groups.
              $redirectionURI = $chosenGroupURI;
          }
        }
      }
     
      $userID = 0;
      if ($user instanceof eZUser)
        $userID = $user->id();
      if ($userID > 0) 
      {
        if ($http->hasPostVariable('Cookie')) 
        {
          $ini = eZINI::instance();
          $rememberMeTimeout = $ini->hasVariable('Session', 'RememberMeTimeout') ? $ini->variable('Session', 'RememberMeTimeout') : false;
          if ($rememberMeTimeout) 
          {
            $GLOBALS['RememberMeTimeout'] = $rememberMeTimeout;
            eZSessionStop();
            eZSessionStart();
            unset ($GLOBALS['RememberMeTimeout']);
          }
     
       }
       $http->removeSessionVariable('eZUserLoggedInID');
       $http->setSessionVariable('eZUserLoggedInID', $userID);
    
       // Remove all temporary drafts
       //include_once( 'kernel/classes/ezcontentobject.php' );
       eZContentObject::cleanupAllInternalDrafts($userID);
       return $Module->redirectTo($redirectionURI);
      }
    }
    
    $userIsNotAllowedToLogin = false;
    $failedLoginAttempts = false;
    $maxNumOfFailedLogin = !eZUser::isTrusted() ? eZUser::maxNumberOfFailedLogin() : false;
    
    // Should we show message about failed login attempt and max number of failed login
    if ( $loginWarning and isset( $GLOBALS['eZFailedLoginAttemptUserID'] ) )
    {
        $ini = eZINI::instance();
        $showMessageIfExceeded = $ini->hasVariable( 'UserSettings', 'ShowMessageIfExceeded' ) ? $ini->variable( 'UserSettings', 'ShowMessageIfExceeded' ) == 'true' : false;
    
        $failedUserID = $GLOBALS['eZFailedLoginAttemptUserID'];
        $failedLoginAttempts = eZUser::failedLoginAttempts( $failedUserID );
    
        $canLogin = eZUser::isEnabledAfterFailedLogin( $failedUserID );
        if ( $showMessageIfExceeded and !$canLogin )
            $userIsNotAllowedToLogin = true;
    }
  }
}
else
{
  if ($Module->isCurrentAction('Login') and 
      $Module->hasActionParameter('X509URL') and
      !$http->hasPostVariable( "X509Register" )) {

  	$x509_cert = $_SERVER["SSL_CLIENT_CERT"];
  	$userRedirectURI = $Module->actionParameter('UserRedirectURI');

  	if (trim($userRedirectURI) == "") {
  		// Only use redirection if RequireUserLogin is disabled
  		$requireUserLogin = ($ini->variable("SiteAccessSettings", "RequireUserLogin") == "true");
  		if (!$requireUserLogin) {
  			if ($http->hasSessionVariable("LastAccessesURI"))
  				$userRedirectURI = $http->sessionVariable("LastAccessesURI");
  		}

  		if ($http->hasSessionVariable("RedirectAfterLogin")) {
  			$userRedirectURI = $http->sessionVariable("RedirectAfterLogin");
  		}
  	}
    else
    {
      $http->setSessionVariable('RedirectAfterLogin', $userRedirectURI);
    }
	  // Save array of previous post variables in session variable
  	$post = $http->attribute('post');
  	$lastPostVars = array ();
  	foreach (array_keys($post) as $postKey) {
  		if (substr($postKey, 0, 5) == 'Last_')
  			$lastPostVars[substr($postKey, 5, strlen($postKey))] = $post[$postKey];
  	}
  	if (count($lastPostVars) > 0) {
  		$postData = $lastPostVars;
  		$http->setSessionVariable('LastPostVars', $lastPostVars);
  	}
  
    // TODO: need to check if this is a url and error if not.
  	if ($x509_cert) {
  

      // See if we can get a registered URL
  		$x509_user = x509_user::fetch($x509_cert);
    
      // TODO If the user is already logged in and the URL is not registedto to anyone - register URL for this user

	  	if ($x509_user) {

      // Get userID & user object  associated with URL 
	  		$userID = $x509_user->attribute('user_id');
	  		$user = $x509_user->attribute('user');

        // TODO Is the user is already logged in and the URL is registered to them - redircet to where they were going
  
        // TODO Is the user is already logged in and the URL is registered another user - error saying - logout and try again?

        // Store $x509_cert in session
	  		$http->setSessionVariable('X509URL', $x509_cert);
  			$http->setSessionVariable('X509Action', 'login');
  			//return $Module->redirectTo($redirect_url);
  			return $Module->redirectTo('x509/login');
  
  		} else {
  			// URL is not registered
  			eZDebug::writeDebug($x509_cert . " is not registered", "x509::login");
        		$loginWarning = true;
        // Need to display a custom x509 error and include the login screen
	  	  //	return $Module->redirectTo('user/login');
	  	}
  	} else {
  		/// User didn't enter a URL
      		$loginWarning = true;
  		eZDebug::writeDebug("User did not enter a URL", "x509::login");
      // Need to display a custom x509 error and include the login screen
	  	//return $Module->redirectTo('user/login');
	  }
  } elseif ($http->hasPostVariable( "X509Register" )) {
    // User has access the link directly
  	$x509_cert = $Module->actionParameter('X509URL');
    $http->setSessionVariable('X509URL', $x509_cert);
 
    return $Module->redirectTo( 'x509/register' );
  }
}

$tpl = templateInit();

$tpl->setVariable( 'x509_url', $x509_cert, 'User' );
$tpl->setVariable( 'post_data', $postData, 'User' );
$tpl->setVariable( 'redirect_uri', $userRedirectURI, 'User' );
$tpl->setVariable( 'warning', array( 'bad_login' => $loginWarning ), 'User' );

$tpl->setVariable( 'site_access', array( 'allowed' => $siteAccessAllowed,
                                         'name' => $siteAccessName ) );
$tpl->setVariable( 'user_is_not_allowed_to_login', $userIsNotAllowedToLogin, 'User' );
$tpl->setVariable( 'failed_login_attempts', $failedLoginAttempts, 'User' );
$tpl->setVariable( 'max_num_of_failed_login', $maxNumOfFailedLogin, 'User' );


$Result = array();
$Result['content'] = $tpl->fetch( 'design:user/login.tpl' );
$Result['path'] = array( array( 'text' => ezi18n( 'kernel/user', 'User' ),
                                'url' => false ),
                         array( 'text' => ezi18n( 'kernel/user', 'Login' ),
                                'url' => false ) );
if ( $ini->variable( 'SiteSettings', 'LoginPage' ) == 'custom' )
    $Result['pagelayout'] = 'loginpagelayout.tpl';


?>
