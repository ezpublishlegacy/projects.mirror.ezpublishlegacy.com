<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=x509

[StylesheetSettings]
CSSFileList[]=x509.css

*/ ?>

