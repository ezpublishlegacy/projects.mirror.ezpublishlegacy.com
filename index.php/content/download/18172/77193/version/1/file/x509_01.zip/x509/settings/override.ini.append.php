<?php /* #?ini charset="utf-8"?

[login]
Source=user/login.tpl
MatchFile=user/login.tpl
Subdir=templates

[edit]
Source=user/edit.tpl
MatchFile=user/edit.tpl
Subdir=templates

[page_header_links]
Source=page_header_links.tpl
MatchFile=page_header_links.tpl
Subdir=templates
*/ ?>
