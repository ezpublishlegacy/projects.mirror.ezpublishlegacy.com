Módulo X509 para Ez
==============================
Autor: Sidney Medeiros (sidneyrmedeiros@gmail.com)
Data: 2009-07-09
Licensa: GPL
Versão: 0.1

RESUMO
======
O Módulo X509 permite usuários logar em sites Ez com seus Certificados Digitais X509.


DOWNLOAD
========

http://cursos.cdtc.org.br


INSTALAÇÃO
==========

Para instalar este módulo siga os seguintes passos (considerando que seu servidor web está configurado para SSL ):
Copie a pasta x509 para o seguinte diretório:
ezbublish/extension/

Insira o banco de dados da extensão X509 da seguinte forma:
mysql -u ezpublish -p ezpublish < ezbublish/extension/x509/sql/x509.sql


Entre na página de administração do Ez Publish e clique em:
Configuração->Extensões

Marque a extensão X509 e clique em:
"Aplicar Mudanças"

Agora o módulo está corretamente instalado. Basta clicar na nova aba "X509" para cadastrar um certificado para o usuário.


Caso ocorra erro de redirecionamento quando sair do SSL, faça a sequinte alteração no seguinte arquivo (possivel falha no EZ):
kernel/classes/ezsslzone.php

            $host = $ini->variable( 'SiteSettings', 'SiteURL' );
            //Correção
            $host = eZSys::serverVariable( 'HTTP_HOST' );


Regras:
Um certificado não pode ser cadastrado para mais de um usuário
Uma vez cadastardo um certificado, o usuário só pode se logar com o certificado (menos o admin geral)
Caso o usuário remova o certificado durante uma sessão, ele será deslogado.

Obs: 
Para continuar a permitir login por login e senha para usuarios com certificado, basta remover o arquivo: x509/autoloads/eztemplateautoload.php
O administrador pode remover qualquer certificado cadastrado
Caso use SSLZONE, pode ser necessário alterar a configuração do seguinte arquivo conforme seu site: x509/setting/site.ini.append.php
