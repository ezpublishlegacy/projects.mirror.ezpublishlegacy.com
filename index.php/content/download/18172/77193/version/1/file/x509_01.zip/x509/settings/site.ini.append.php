<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=x509

[RegionalSettings]
TranslationExtensions[]=x509

[SiteAccessSettings]
AnonymousAccessList[]=x509/register
AnonymousAccessList[]=x509/login
AnonymousAccessList[]=x509/complete

[RoleSettings]
PolicyOmitList[]=x509
ShowAccessDeniedReason=enabled

[SiteSettings]
SSLPort=443

[SSLZoneSettings]
# Enable/disable the SSL zones functionality.
#SSLZones=enabled

# Content subtrees we must use SSL for.
# (currently, only content/view and content/edit respect this setting)
#SSLSubtrees[]
#SSLSubtrees[]=/          

# Default access mode is plain HTTP.
# Define a view as 'ssl' to force HTTPS access mode for this view.
# If a view is defined as 'keep' then access mode is unknown
# for this view, and the previous access mode is kept.
ModuleViewAccessMode[x509/*]=ssl
ModuleViewAccessMode[user/*]=ssl
#ModuleViewAccessMode[content/*]=keep
#ModuleViewAccessMode[content/*]=ssl

*/ ?>
