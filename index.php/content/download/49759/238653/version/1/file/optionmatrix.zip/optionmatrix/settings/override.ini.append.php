<?php /* #?ini charset="utf-8"?

[optionmatrix_form_full]
Source=node/view/full.tpl
MatchFile=full/optionmatrix_form.tpl
Subdir=templates
Match[class_identifier]=optionmatrix_form

?>
