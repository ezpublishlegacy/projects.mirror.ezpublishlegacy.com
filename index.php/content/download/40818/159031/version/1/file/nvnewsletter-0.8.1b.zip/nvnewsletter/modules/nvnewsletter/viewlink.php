<?php
/**
 * Module view link
 * @package nvNewsletter
 */
$Module = $Params['Module'];
$http = eZHTTPTool::instance();
$lnk = $http->getVariable('lnk');

$objectID = $Params['ObjectID'];
$userID   = (int)$Params['UserID'];
$hash     = (string)$Params['Hash'];

$nvnewsletterIni = eZINI::instance( 'nvnewsletter.ini' );
$bbEnabled = ($nvnewsletterIni->variable('TrackingSettings', 'BigBrotherEnabled') == 'true') ? true : false;

if ($bbEnabled) {
    if ($receiver = nvNewsletterReceiver::fetch($userID)) {
        $userHash = nvNewsletterTools::getUserHash($receiver->email_address);
    }

    if (!nvNewsletterTools::hashMatch($userHash, $hash)) {
        $userID = null;
    }
} else {
    $userID = null;
}

if( !is_numeric( $objectID ) )
{
    $objectID = 0;
}

// Check URL
if ( !nvNewsletterClickTrack::objectAndURLMatch( $lnk, $objectID ) )
{
    eZExecution::cleanExit();
}

if ( $objectID )
{
    $newsletter = nvNewsletter::fetchByContentObjectID( $objectID );
    
    if ( $newsletter && $newsletter->status == nvNewsletter::STATUS_SENT ) 
    {
        $statistics = nvNewsletterStatistics::fetchByNewsletterAction( $newsletter->attribute('id'),
                                                                       nvNewsletterStatistics::NEWSLETTER_LINK_CLICK );
        $statistics = nvNewsletterStatistics::create( $newsletter->attribute('id'),
                                                      $userID, 
                                                      nvNewsletterStatistics::NEWSLETTER_LINK_CLICK);
        
        $link = nvNewsletterClickTrackLink::fetchByLink( $lnk );

        if ( !$link )
        {
            $link = nvNewsletterClickTrackLink::create( $lnk );
        }

        $statistics->setAttribute('data_int', $link->attribute('id'));
        $statistics->store();

        $click = nvNewsletterClickTrack::create($newsletter->attribute('id'), $link->attribute('id'), $userID);
    }
}

eZHTTPTool::redirect( $lnk );
eZExecution::cleanExit();
?>
