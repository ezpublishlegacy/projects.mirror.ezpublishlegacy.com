<?php
/**
 * File containing the nvNewsletterInfo class
 *
 * @copyright Copyright (c) 2010 NXC Finland. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author NXC Finland <http://www.nxc.fi>
 * @package nvNewsletter
 */

class nvNewsletterInfo
{
    static function info()
    {
        return array( 'Name' => '<a href="http://projects.ez.no/nvnewsletter">nvNewsletter</a> by <a href="http://www.nxc.fi/">NXC Finland Oy</a>',
                      'Version' => '0.8.1b',
                      'Copyright' => 'Copyright (C) 2009-' . date('Y') . ' NXC Finland Oy',
                      'Author' => 'NXC Finland Oy',
                      'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
