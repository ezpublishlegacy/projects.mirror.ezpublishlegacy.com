<?php
/**
 * Module view newsletter stats
 * @package nvNewsletter
 */
$extension = 'nvnewsletter';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

$http = eZHTTPTool::instance();
$newsletterID = $Params['NewsletterID'];
$action = $Params['Action'];
$Module = $Params['Module'];

$newsletter = nvNewsletter::fetch($newsletterID);
if ($action && $action != '0') {
    $stats = nvNewsletterStatistics::fetchByNewsletterAction($newsletterID, $action);
} else {
    $stats = nvNewsletterStatistics::fetchByNewsletter($newsletterID);
}

$tpl = nvNewsletterTemplate::factory();
$tpl->setVariable( 'newsletter', $newsletter );
$tpl->setVariable( 'stats', $stats );
$tpl->setVariable( 'action_filter', $action );

$Result = array();
$Result['newsletter_menu'] = 'design:parts/content/newsletter_menu.tpl';
$Result['left_menu'] = 'design:parts/content/nvnewsletter_menu.tpl';
$Result['content'] = $tpl->fetch( "design:$extension/view_newsletter_stats.tpl" );
$Result['path'] = array(array(
            'url' => false,
            'text' => ezi18n('nvnewsletter/view_newsletter_stats', 'View newsletter stats')));
?>
