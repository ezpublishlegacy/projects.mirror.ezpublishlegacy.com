<?php /*

## Default overrides

[nvnewsletter_arrow]
Source=content/datatype/view/ezxmltags/arrow.tpl
MatchFile=newsletteritems/arrow.tpl
Subdir=templates
Match[viewmode]=nvnewsletterhtml

[nvnewsletter_embed]
Source=content/datatype/view/ezxmltags/embed.tpl
MatchFile=newsletteritems/embed.tpl
Subdir=templates
Match[viewmode]=nvnewsletterhtml

[nvnewsletter_image]
Source=content/datatype/view/ezimage.tpl
MatchFile=newsletteritems/ezimage.tpl
Subdir=templates
Match[viewmode]=nvnewsletterhtml

[nvnewsletter_edit]
Source=content/edit.tpl
MatchFile=edit/newsletter.tpl
Subdir=templates
Match[section]=7

[nvnewsletter_versionview]
Source=content/view/versionview.tpl
MatchFile=versionview/newsletter.tpl
Subdir=templates
Match[section]=7

*/ ?>
