<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=nvnewsletter

[RegionalSettings]
TranslationExtensions[]=nvnewsletter

[MailSettings]
AllowedCharsets[]
AllowedCharsets[]=utf-8
AllowedCharsets[]=iso-8859-1

[RoleSettings]
PolicyOmitList[]=nvnewsletter/viewmail
PolicyOmitList[]=nvnewsletter/viewlink
PolicyOmitList[]=nvnewsletter/unsubscribe
PolicyOmitList[]=nvnewsletter/subscribe

*/ ?>
