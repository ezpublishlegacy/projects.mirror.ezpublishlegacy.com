One-click new object and publish/preview hack
---------------------------------------------
STEVO 10/01/03


this is a dirty hack for 3.3 to allow users to add input to a form before an object exists. submitting this form creates the object, populates the attributes with the form data and tries to publish it. the idea is to allow blog style comment forms. 


provisos
--------

only works with textline, textfield and xmltextfield datatypes but only cos i'm lazy

it involves altering kernel/content files but the changes are self contained and the role and validation processes are left intact.


how
---

it works with new content actions 'DirectPublish' and 'DirectPreview'. when the form is submitted:

new object is created
relevant post data is stored in the session
user is redirected to edit the object
relevant session data is retrieved into post varaibles
attempts to publish or preview as per usual


alterations
-----------

backup kernel/content/action.php and kernel/content/edit.php
replace with the included files (from 3.3-0) or...

edit kernel/content/action.php
insert at line 44:
// ---------------
if ( $http->hasPostVariable( 'DirectPublishButton' ) || $http->hasPostVariable( 'DirectPreviewButton' ) )
{
    if ( ( $http->hasPostVariable( 'ClassID' ) && $http->hasPostVariable( 'NodeID' ) ))
    {
        $node =& eZContentObjectTreeNode::fetch( $http->postVariable( 'NodeID' ) );
        $contentClassID = $http->postVariable( 'ClassID' );
        $parentContentObject =& $node->attribute( 'object' );

        if ( $parentContentObject->checkAccess( 'create', $http->postVariable( 'ClassID' ),  $parentContentObject->attribute( 'contentclass_id' ) ) == '1' )
        {
            $user =& eZUser::currentUser();
            $userID =& $user->attribute( 'contentobject_id' );
            $sectionID = $parentContentObject->attribute( 'section_id' );

            $class =& eZContentClass::fetch( $contentClassID );
            $contentObject =& $class->instantiate( $userID, $sectionID );
            $nodeAssignment =& eZNodeAssignment::create( array(
                                                             'contentobject_id' => $contentObject->attribute( 'id' ),
                                                             'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                             'parent_node' => $node->attribute( 'node_id' ),
                                                             'is_main' => 1
                                                             )
                                                         );
            $nodeAssignment->store();

            $attribute_list = $contentObject->contentObjectAttributes(true);
            $attribute_id_list = array();
            $dp_name_list = array();

            foreach ($attribute_list as $attribute)
            {
                $varkey = 'ContentObjectAttribute_';
                $varkey .= ($attribute->DataTypeString == 'ezstring') ? 'ezstring_' : '';
                $varkey .= 'data_text_'.$attribute->ID;
                $varname = 'dp_attribute_'.$attribute->contentClassAttributeIdentifier();
                $var = ($http->hasPostVariable( $varname )) ? $http->postVariable( $varname ) : '';

                $http->setSessionVariable( $varkey, $var );
                $attribute_id_list[] = $attribute->ID;
                $dp_name_list[] = $varkey;
            }

            $http->setSessionVariable( 'dp_name_list', $dp_name_list);
            $http->setSessionVariable( 'MainNodeID', $node->attribute( 'node_id' ) );
            $http->setSessionVariable( 'ContentObjectAttribute_id', $attribute_id_list );
            
            $action = ($http->hasPostVariable( 'DirectPublishButton' ) ) ? 'PublishButton' : 'PreviewButton';
            $http->setSessionVariable( 'dp_action', $action );

            $parameters = array( $contentObject->attribute( 'id' ),
                                 $contentObject->attribute( 'current_version' ) );

            $module->redirectToView( 'edit', $parameters );
            return;
        }
    }
}
// ---------------

edit kernel/content/edit.php
insert at line 53:
// ---------------
if ( $http->hasSessionVariable( 'dp_action' ) )
{
   $http->setPostVariable( 'ContentObjectAttribute_id', $http->hasSessionVariable( 'ContentObjectAttribute_id' ) );
   $http->removeSessionVariable( 'ContentObjectAttribute_id' );
   foreach ( $http->sessionVariable( 'dp_name_list' ) as $name )
   {
       $http->setPostVariable( $name, $http->sessionVariable( $name ) );
       $http->removeSessionVariable( $name );
   }
   $http->setPostVariable( 'MainNodeID', $http->sessionVariable( 'MainNodeID' ) );
   
   $http->setPostVariable( $http->sessionVariable( 'dp_action' ), 'Post' );
   $http->removeSessionVariable( 'MainNodeID' );
   $http->removeSessionVariable( 'dp_name_list' );
   $http->removeSessionVariable( 'dp_action' );
}
// ---------------


templates:
----------

the form to use in templates is similar to a NewButton form:


<form enctype="multipart/form-data" method="post" action={"content/action/"|ezurl}>

{* include these replacing PARENTNODEID with the node where you want the new object to go (ie current node {$node.node_id}) and CLASSID with the class id of the new object *}
<input type="hidden" name="NodeID" value="PARENTNODEID" />
<input type="hidden" name="ClassID" value="CLASSID" />


{* for each textline, textfield or xmltextfield attribute include one of these replacing CLASSATTRIBUTEIDENTIFIER with the relevant identifier from your class definition (eg 'title', 'intro' etc for the standard article class) *}
<input type="text" name="dp_attribute_CLASSATTRIBUTEIDENTIFIER" value=""  />


{* include these instead of a 'NewButton' *}
<input class="button" type="submit" name="DirectPublishButton" value="Post" />
<input class="button" type="submit" name="DirectPreviewButton" value="Preview" />


</form>




