<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/topapps/classes/topappsoperator.php',
                                    'class' => 'TopAppsOperator',
                                    'operator_names' => array( 'topapps' ) );

?>
