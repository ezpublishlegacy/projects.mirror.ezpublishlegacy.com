<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ggwebservices

*/ ?>