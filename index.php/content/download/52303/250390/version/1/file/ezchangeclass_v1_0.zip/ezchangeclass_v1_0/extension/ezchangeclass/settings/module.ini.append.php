<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ModuleList[]=changeclass
ExtensionRepositories[]=ezchangeclass

*/?>
