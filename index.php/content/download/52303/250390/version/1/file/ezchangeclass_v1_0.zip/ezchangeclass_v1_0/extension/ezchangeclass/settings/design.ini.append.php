<?php /* 

[ExtensionSettings]
DesignExtensions[]=ezchangeclass

*/ ?>
