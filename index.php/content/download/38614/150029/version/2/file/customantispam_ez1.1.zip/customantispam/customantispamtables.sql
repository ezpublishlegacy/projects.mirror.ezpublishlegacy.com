CREATE TABLE customantispam (id int(10) NOT NULL, createtime int(10) NOT NULL, word VARCHAR(20) NOT NULL, UNIQUE KEY id (id));

CREATE TABLE customanticount (id int(10) NOT NULL AUTO_INCREMENT, UNIQUE KEY id (id));