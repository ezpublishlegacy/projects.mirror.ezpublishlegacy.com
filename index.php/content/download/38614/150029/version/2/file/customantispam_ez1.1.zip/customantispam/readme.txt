Peter's Custom Anti-Spam Image for eZ Publish
Version 1.1
Compatible with eZ Publish 3.8+

Install instructions:

1) Unzip the customantispam directory into the eZ Publish extension directory.

2) Activate the extension in the eZ Publish Administration Interface by clicking on the Setup tab, then the Extensions menu item.

3) Run the SQL query in customantispamtables.sql to insert the necessary tables into the same database as your eZ Publish installation.

4) Add a policy under the Anonymous Role (click the User accounts tab, then the Roles and Policies link) to grant full access to the customantispam module.

5) Add a new workflow. Click the Setup tab, then the Workflows menu item. Click the New workflow group button and enter any name you want (such as "Anti-spam"). In the new workflow group, click the New workflow button. Name it "Anti-spam" and select the event "Event / Custom anti-spam", then click the Add event button.

6) Add a new trigger by clicking the Setup tab, then the Triggers menu item. Under the "content" module, "publish" function and "before" connection type, select the workflow "anti-spam" then click the Apply changes button.

7) Find your comment template (for ezwebin, it's extension/ezwebin/design/ezwebin/override/templates/edit/comment.tpl).

Add {set-block scope=root variable=cache_ttl}0{/set-block} at the top of your template.

If you are putting the anti-spam protection into a different template (such as directly in a blog post if you are using Kristof's powercontent extension at http://ezpedia.org/wiki/en/ez/powercontent to add a comment form directly in a template), add cache-blocks around the sections of the page preceding and following the anti-spam code:

{cache-block}
Start of page
{/cache-block}
anti-spam code
{cache-block}
Rest of page
{/cache-block}

However, cache-blocks are probably not necessary if you are editing the edit/comment.tpl template.
Add the following code to the form, usually above the message text area:

<div class="block">
{def $antispam = custom_anti_spam()}
<label>Anti-spam word</label><div class="labelbreak"></div>
<input type="hidden" name="matchthis" value="{$antispam}" />
<a href={concat("/customantispam/audio/(audio)/",$antispam)|ezurl("double")}><img src={concat("/customantispam/image/(image)/",$antispam)|ezurl("double")} style="border: 1px solid black" alt="Click to hear an audio file of the anti-spam word"/></a><div class="labelbreak"></div>
<input type="text" name="securitycode" size="10" />
</div>