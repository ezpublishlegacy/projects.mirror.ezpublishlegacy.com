<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=customantispam

*/
?>