<?php

$Module = array( 'name' => 'Custom Anti-Spam' );

$ViewList = array();
$ViewList['image'] = array(
    'default_navigation_part' => 'ezcontentnavigationpart',
    'ui_context' => 'read',
    'script' => 'image.php',
    'params' => array(  ) );

$ViewList['audio'] = array(
    'default_navigation_part' => 'ezcontentnavigationpart',
    'ui_context' => 'read',
    'script' => 'audio.php',
    'params' => array(  ) );

?>