<?php
/*

[EventSettings]
ExtensionDirectories[]=customantispam
AvailableEventTypes[]=event_customantispam
AvailableEventTypes[]=event_invalid_audio

*/
?>