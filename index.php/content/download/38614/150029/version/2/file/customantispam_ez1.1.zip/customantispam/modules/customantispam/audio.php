<?php

include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'extension/customantispam/mp3_class.php' );
include_once( 'kernel/common/template.php' );

    $userParams =& $Params['UserParameters'];
    $module =& $Params['Module'];
    $cas_sounds = 'extension/customantispam/sounds/';
	// Validate the input from the URL
	$cas_antiselect = intval($userParams['audio']);

	// Get the word from the database
	$db =& eZDB::instance();
	$cas_antirow = $db->arrayQuery( "SELECT word FROM customantispam WHERE id = $cas_antiselect" );
	if (empty($cas_antirow)) {
		$tpl =& templateInit();		      
		$Result = array();
		$Result['content'] =& $tpl->fetch( 'design:workflow/eventtype/result/event_invalid_audio.tpl' );
		$Result['path'] = array( array( 'url' => false, 'text' => 'Invalid Audio' ) );
	}
	else {
		$cas_antispam = $cas_antirow[0]['word'];
	
		// Get the word
		$petersword = strtolower($cas_antispam);

		$word_count = strlen($petersword);

		// Set up the first file
		if ($word_count > 0) {
			$mp3 = new mp3($cas_sounds . substr($petersword, 0, 1) . '.mp3');
			$mp3->striptags();
		}

		for ($i = 1; $i < $word_count; ++$i) {
			$cas_character = $cas_sounds . substr($petersword, $i, 1);
			$cas_mp3equivalent = new mp3($cas_character . '.mp3');
			$mp3->mergeBehind($cas_mp3equivalent);
			$mp3->striptags();
		}
		$mp3->output('word.mp3');
	}

?>