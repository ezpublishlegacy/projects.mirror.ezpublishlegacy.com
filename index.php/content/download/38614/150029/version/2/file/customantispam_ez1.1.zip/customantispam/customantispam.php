<?php
include_once( 'lib/ezdb/classes/ezdb.php' );

class CustomAntiSpam
{
    /*!
      Constructor, does nothing by default.
    */
    function CustomAntiSpam()
    {
    }

    /*!
     
Return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'custom_anti_spam' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'custom_anti_spam' => array( 'first_param' => array( 'type' => 'string',
                                                                           'required' => false,
                                                                           'default' => 'default text' ),
                                                   'second_param' => array( 'type' => 'integer',
                                                                            'required' => false,
                                                                            'default' => 0 ) ) );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {

        // Example code, this code must be modified to do what the operator should do
        switch ( $operatorName )
        {
            case 'custom_anti_spam':
            {
		$db =& eZDB::instance();

		$random_word = $this->random_text(7);

		// Insert a row into the count database to generate an auto_increment number
		$db->query('INSERT INTO customanticount (id) VALUES (NULL)');

		// Get the id of the inserted count to feed to the word table and image generator
		$operatorValue = mysql_insert_id();

		// Put the random word into the database
		$db->query('INSERT INTO customantispam (id, createtime, word) VALUES (' . $operatorValue . ', ' . time() . ', \'' . $random_word . '\')');

		// Delete the row from the count table
		$db->query('DELETE FROM customanticount WHERE id = ' . $operatorValue);

		// Do some table admin while we can :D
		if (strlen($operatorValue) == 10) {

			// Delete all rows from the count table
			$db->query('DELETE FROM customanticount');

			// Reset the table's auto increment if it's getting too huge
			$db->query('ALTER TABLE customanticount AUTO_INCREMENT=1');

			// Delete any anti-spam words more than a day old
			$db->query('DELETE FROM customantispam WHERE ' . time() . ' > createtime + 86400');
		}
            } break;
        }
    }
    function random_text($length) {

	// this will consist of all letters and numbers
	$character_pool = "23456789bcdfghkmnpqrstwxyz";
	$character_count = strlen($character_pool) - 1;
	$code = "";
	$i = 0;
	while ($i < $length) {
		$code .= substr($character_pool, mt_rand(0, $character_count), 1);
		++$i;
		}
		return $code;
    }

}
?>