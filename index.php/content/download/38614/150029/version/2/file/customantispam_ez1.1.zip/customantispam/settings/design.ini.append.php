<?php
/*

[ExtensionSettings]
DesignExtensions[]=customantispam

*/
?>