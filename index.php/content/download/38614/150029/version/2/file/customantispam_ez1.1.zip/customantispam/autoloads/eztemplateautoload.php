<?php

 

// Operator autoloading

 

$eZTemplateOperatorArray = array();


$eZTemplateOperatorArray[] =

 array( 'script' => 'extension/customantispam/customantispam.php',

        'class' => 'CustomAntiSpam',

        'operator_names' => array( 'custom_anti_spam' ) );

 ?>