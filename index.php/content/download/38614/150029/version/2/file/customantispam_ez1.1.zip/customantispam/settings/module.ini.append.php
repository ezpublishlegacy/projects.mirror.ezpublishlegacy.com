[ModuleSettings]
ExtensionRepositories[]=customantispam
ModuleList[]=customantispam