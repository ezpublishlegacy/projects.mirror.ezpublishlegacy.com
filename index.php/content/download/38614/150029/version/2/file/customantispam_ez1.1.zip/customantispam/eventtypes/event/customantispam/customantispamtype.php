<?php

include_once( 'lib/ezdb/classes/ezdb.php' );
define( 'EZ_WORKFLOW_TYPE_CUSTOMANTISPAM_ID', 'customantispam' );
include_once('kernel/classes/ezworkflowtype.php');
include_once('lib/ezutils/classes/ezoperationhandler.php');

class CustomAntiSpamType extends eZWorkflowEventType
{
    function CustomAntiSpamType()
    {
        $this->eZWorkflowEventType
                ( EZ_WORKFLOW_TYPE_CUSTOMANTISPAM_ID, 
                        'Custom anti-spam' );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( 'before' ) ) ) );
    }

    function execute( &$process, &$event )
    {
        $http =& eZHTTPTool::instance();

        if( $http->hasPostVariable ( 'matchthis' ) )
	{
		$db =& eZDB::instance();

			// Validate the form input values
			if( $http->hasPostVariable ( 'securitycode' ) )
			{
				$securitycode = substr( strval( $http->postVariable ( 'securitycode' ) ), 0, 50 );
			} else {
				$process->Template = array( 'templateName' => 'design:workflow/eventtype/result/event_customantispam.tpl' );
				return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
			}

			$matchnum = intval( $http->postVariable ( 'matchthis' ) );

			// Get the anti-spam word from the database
			$match_row = $db->arrayQuery('SELECT word FROM customantispam WHERE id = ' . $matchnum);

			// Return an error if the row number doesn't exist
			if (empty($match_row)) {
				$process->Template = array( 'templateName' => 'design:workflow/eventtype/result/event_customantispam.tpl' );
				return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
			} 
			else {
				$matchthis = $match_row[0]['word'];
			}
			
			// Check whether the words match
			if ( strtolower($securitycode) != $matchthis) {
				$process->Template = array( 'templateName' => 'design:workflow/eventtype/result/event_customantispam.tpl' );
				return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
			}
			else {
				// The word matched, so delete the row for the anti-spam word so that it cannot be used again
				$db->query('DELETE FROM customantispam WHERE id = ' . $matchnum);
				unset( $matchthis );

				// Do some more table admin while we can :D
				// Delete any anti-spam words more than a day old
				$db->query('DELETE FROM customantispam WHERE ' . time() . ' > createtime + 86400');
			}
			
		return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
   	}
    }
}

eZWorkflowEventType::registerType ( EZ_WORKFLOW_TYPE_CUSTOMANTISPAM_ID, 'customantispamtype' );

?>