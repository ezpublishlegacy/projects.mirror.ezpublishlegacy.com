<?php /*
#
# $Id: module.ini.append.php 24 2009-10-04 15:22:02Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezvideoflv/ezp4/tags/ezvideoflv_0.3/ezvideoflv/settings/module.ini.append.php $
#

[ModuleSettings]
ExtensionRepositories[]=ezvideoflv
ModuleList[]=video

*/ ?>
