<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=all2e1pixeloutmp3flashplayer

*/ ?>
