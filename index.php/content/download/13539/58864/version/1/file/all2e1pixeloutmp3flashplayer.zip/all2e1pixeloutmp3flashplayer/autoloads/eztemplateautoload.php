<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/all2e1pixeloutmp3flashplayer/autoloads/all2e1PixelOutMp3FlashPlayerOperators.php',
         'class' => 'all2e1PixelOutMp3FlashPlayerOperators',
         'operator_names' => array( 'mp3player' ) );

?>
