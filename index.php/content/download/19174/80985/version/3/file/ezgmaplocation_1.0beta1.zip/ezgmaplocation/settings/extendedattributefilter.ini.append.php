<?php /*

[ezgmlLocationFilter]
ExtensionName=ezgmaplocation
ClassName=ezgmlLocationFilter
MethodName=createSqlParts
FileName=classes/ezgmllocationfilter.php

*/ ?>