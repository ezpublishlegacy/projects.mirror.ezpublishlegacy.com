<?php /*

[ExtensionSettings]
DesignExtensions[]=ezgmaplocation

*/ ?>