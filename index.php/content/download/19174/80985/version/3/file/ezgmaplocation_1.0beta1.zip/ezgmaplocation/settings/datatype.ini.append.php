<?php /*

[EditSettings]
GroupedInput[]=ezgmaplocation

*/ ?>