<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="sv">
<defaultcodec></defaultcodec>
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <source>GMap Location</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing Latitude/Longitude input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Map</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
