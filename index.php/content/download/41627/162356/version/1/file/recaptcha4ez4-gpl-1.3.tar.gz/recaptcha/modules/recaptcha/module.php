<?php

$Module = array( "name" => "reCAPTCHA" );

$ViewList = array();

$FunctionList = array();
$FunctionList['bypass_captcha'] = array();

?>
