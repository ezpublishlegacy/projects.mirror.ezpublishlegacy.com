<?php
/*

[RegionalSettings]
TranslationExtensions[]=keywords_nodes

*/
?>