<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de_DE">
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Keywords Nodes</source>
        <translation>Schlüsselwörter Knoten</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Schlüsselwörter</translation>
    </message>
    <message>
        <source>Affect</source>
        <translation>Hinzufügen</translation>
    </message>
     <message>
        <source>Note: Affect a keyword will add a location to the current node in the selected 'Keyword Node'.</source>
        <translation>Annmerkung : Ein Schlüsselwort hinzu fügen bedeutet einen neuen Ort des Schlüsselwortknotens hinzu zu fügen</translation>
    </message>
    <message>
        <source>There isn't available keywords.</source>
        <translation>Es sind keine Schlüsselwörter verfügbar</translation>
    </message>
     <message>
        <source>Keywords already affected</source>
        <translation>Benutzte Schlüsselwörter</translation>
    </message>
     <message>
        <source>There isn't affected keywords.</source>
        <translation>Keine benutzten Schlüsselwörter vorhanden.</translation>
   </message>
   <message>
        <source>Remove</source>
        <translation>Löschen</translation>
    </message>
</context>
</TS>
