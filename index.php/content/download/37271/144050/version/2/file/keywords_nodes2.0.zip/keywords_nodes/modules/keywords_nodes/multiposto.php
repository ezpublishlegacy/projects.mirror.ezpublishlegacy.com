<?php
include_once( 'extension/keywords_nodes/modules/keywords_nodes/classes/multipos.php' );
include_once( 'kernel/common/template.php' );
$Module =& $Params["Module"];
$http =& eZHTTPTool::instance();
$source=$http->postVariable('keywords_nodes_source') ;
$sourceMain = eZContentObjectTreeNode::fetch( $source );
$sourceMainID = $sourceMain->attribute( 'main_node_id' );
$destination=$http->postVariable('keywords_nodes_destination') ;
$tabDelete=$http->postVariable('keywords_nodes_delete');

if ($http->postVariable('keywords_nodes_submit')) multipos::multipos($source,$destination);
if ($http->postVariable('keywords_nodes_delete_submit'))  multipos::del_multipos($tabDelete);

$Module->redirect('content', 'view', array( 'full', $sourceMainID ));
?>