<?php
/*
[ExtensionSettings]
DesignExtensions[]=keywords_nodes

[StylesheetSettings]
CSSFileList[]=keywords_nodes.css

*/
?>