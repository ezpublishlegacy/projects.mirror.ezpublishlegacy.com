<?php

$Module = array( 'name' => 'Keywrods Nodes' );

$ViewList = array();
$ViewList['multiposto'] = array(
    'script' => 'multiposto.php',
    'functions' => array( ),
    'params' => array ( ) );
?>