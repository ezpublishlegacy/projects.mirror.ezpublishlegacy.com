<!DOCTYPE TS><TS>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Keywords Nodes</source>
        <translation>Noeud de mots clés</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Mots clés</translation>
    </message>
    <message>
        <source>Affect</source>
        <translation>Affecter</translation>
    </message>
     <message>
        <source>Note: Affect a keyword will add a location to the current node in the selected 'Keyword Node'.</source>
        <translation>Note : Affecter un mot clés ajoutera une location au noeud courant dans le 'Noeud Mot clé' selectionné.</translation>
    </message>
    <message>
        <source>There isn't available keywords.</source>
        <translation>Il n'y a pas de mots clés disponibles.</translation>
    </message>
     <message>
        <source>Keywords already affected</source>
        <translation>Mots clés déjà affectés</translation>
    </message>
     <message>
        <source>There isn't affected keywords.</source>
        <translation>Il n'y a pas de mots clés affectés.</translation>
   </message>
   <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
</TS>
