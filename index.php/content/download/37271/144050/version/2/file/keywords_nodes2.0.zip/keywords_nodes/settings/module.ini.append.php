<?php
/*
[ModuleSettings]
ExtensionRepositories[]=keywords_nodes


*/
?>