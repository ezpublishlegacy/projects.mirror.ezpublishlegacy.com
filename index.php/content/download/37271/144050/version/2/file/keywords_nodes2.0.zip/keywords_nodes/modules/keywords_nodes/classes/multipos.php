<?php

include_once( "kernel/classes/eznodeassignment.php" );

class multipos
{
	function multipos($nodeToAddID,$selectedNodeIDs)
	{
	    // print_r($selectedNodeIDs);
	    
	   
	    foreach ( $selectedNodeIDs as $selectedNodeID ){
	    $nodeRemoveList = array();
		$nodeToAdd = eZContentObjectTreeNode::fetch( $nodeToAddID );
		$object =& $nodeToAdd->attribute( 'object' );
		$objectID = $object->attribute( 'id' );
        $nodeAssignmentList = eZNodeAssignment::fetchForObject( $objectID, $object->attribute( 'current_version' ), 0, false );
        $assignedNodes =& $object->assignedNodes();
        $parentNodeIDArray = array();
        foreach ( $assignedNodes as $assignedNode )
        {
            $assignedNodeID = $assignedNode->attribute( 'node_id' );
            $append = false;
            foreach ( $nodeAssignmentList as $nodeAssignment )
	        {
	            if ( $nodeAssignment['parent_node'] == $assignedNode->attribute( 'parent_node_id' ) )
	            {
	                $append = true;
	                break;
	            }
	        }
	        if ( $append )
	        {
	            $parentNodeIDArray[] = $assignedNode->attribute( 'parent_node_id' );
	        }
        }
        $db =& eZDB::instance();
        $db->begin();
        $locationAdded = false;
        if ( !in_array( $selectedNodeID, $parentNodeIDArray ) )
        {
                $insertedNode =& $object->addLocation( $selectedNodeID, true );
                // Now set is as published and fix main_node_id
                $insertedNode->setAttribute( 'contentobject_is_published', 1 );
                $insertedNode->setAttribute( 'main_node_id', $nodeToAdd->attribute( 'main_node_id' ) );
                $insertedNode->setAttribute( 'contentobject_version', $nodeToAdd->attribute( 'contentobject_version' ) );
                // Make sure the path_identification_string is set correctly.
                $insertedNode->updateSubTreePath();
                $insertedNode->sync();
        }
        $db->commit();
	    }
        include_once( 'kernel/classes/ezcontentcachemanager.php' );
   		eZContentCacheManager::clearContentCacheIfNeeded( $objectID );
	}
	
	function del_multipos($tabDelete)
	{
		$nodes = array();
	    foreach ( $tabDelete as $locationID )   $nodes[] = eZContentObjectTreeNode::fetch( $locationID );
	    $nodeRemoveList = array();
	    foreach ( array_keys( $nodes ) as $key )
	    {
	        $node =& $nodes[$key];
	        if ( $node )
	        {
	            $nodeRemoveList[] =& $node;
	            unset( $node );
	        }
	    }
	    $db =& eZDB::instance();
	    $db->begin();
	    foreach ( $nodeRemoveList as $key => $node )
	        $node->remove();
	    $db->commit();
		}
}

?>