<?php
/*

[ClassesIdentifier]
identifier[]=actualite
identifier[]=offre

[SelectionTypes]
# choose select or checkbox, checkbox is default
selectiontype=checkbox

#Actualites 
[TopKeywordsNode_actualite]
nodes[]=1586
GlobalSubtreeDisplaySkipDepth=1

[SubtreeDepth_weblog]

[KeywordsContainerClasse_actualite]
classes[]=rubrique


#Offre 
[TopKeywordsNode_offre]
nodes[]=1605
subtree[]=111
GlobalSubtreeDisplaySkipDepth=1

[SubtreeDepth_offre]
subtree[111]=1

[KeywordsContainerClasse_offre]
classes[]=rubrique



*/
?>