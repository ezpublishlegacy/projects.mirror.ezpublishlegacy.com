<?php
/*

[ModuleSettings]
ExtensionRepositories[]=mzcategoryselection

*/
?>
