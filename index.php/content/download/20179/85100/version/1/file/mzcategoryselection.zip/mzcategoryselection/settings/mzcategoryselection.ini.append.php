<?php
/*

[CategoryClassFilterSettings]
default[]
#default[]=demo_cs4
#default[]=decision_table
#food[]
#food[]=decision_table

*/
?>
