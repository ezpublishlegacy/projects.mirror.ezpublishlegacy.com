<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=mzcategoryselection
AvailableDataTypes[]=mzcategoryselection


*/
?>
