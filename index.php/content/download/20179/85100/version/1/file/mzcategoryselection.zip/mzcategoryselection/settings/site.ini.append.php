<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=mzcategoryselection

*/
?>
