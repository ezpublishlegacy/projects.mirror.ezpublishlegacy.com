<?php
/*

[ExtensionSettings]
DesignExtensions[]=mzcategoryselection

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
JavaScriptList[]=mzcategoryselection.js

*/
?>
