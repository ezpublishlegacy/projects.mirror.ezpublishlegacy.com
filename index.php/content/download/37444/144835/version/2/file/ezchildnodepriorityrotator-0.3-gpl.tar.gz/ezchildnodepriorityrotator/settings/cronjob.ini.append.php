<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezchildnodepriorityrotator

[CronjobPart-rotate]
Scripts[]=ezchildnodepriorityrotator.php

*/ ?>
