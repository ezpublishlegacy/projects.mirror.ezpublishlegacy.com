eZ Child Node Priority Rotator extension for eZ Publish 4.0
version 0.3 beta

Written by Piotrek Karas, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ryba.eu



What is it?
-----------

eZ Child Node Priority Rotator is a cronjob-based extension for eZ Publish
that makes it possible to dynamically change values of integer-datatype-based
attributes that are dedicated for sorting purposes, or do the same with the 
built-in nodes' priority parameter.

ATTRIBUTE MODE

Simply designate one integer-based attribute in the content class for sorting
purposes. Create your content, assign virtually any value you want to the new
priority field. Create your templates that use this field for sorthing purposes.

Then configure the extension. Define any number of presets in the configuration
file. Each preset consists of the following information:
- parent node ID (script will only look for nodes in this branch
- depth of search
- top priority value (this will be the highest value ever assigned automatically
  by the script).
- an array of class identifiers with their corresponding attribute id of the
  sorting attribute.
Look for extra information in the configuration file. Finally, setup a cronjob.

PRIORITY MODE

This mode doesn't require any additional attributes in content classes. It uses 
the built-in priority parameter and a very similar configuration.

GENERAL

Each time the script runs, each preset will be run independently.
Within each preset, all values will be decremented by one, while the 
last one will be brought to the top (top priority value). A number
of additional algorithms will be performed in order to secure a valuable sorting
data base.

The extension should by itself cope with priority doubles.

NOTE: This extension performs direct modifications of database tables!
If for any reason you do not want to allow that, don't use this extension! 
The author has done his best to ensure extension's safe performance and safe 
DB update queries as well as predict possible problems. Still, this is direct 
modification of data in core tables! 

NOTE: In attribute mode, this extension modifies all versions of given content 
object's attribute, no matter if visible, hidden, drafts, or in trash. 
Therefore, new sorting attributes should not be used for any other purposes.

NOTE: This extension, when working in attribute mode, doesn't take multiple 
locations under consideraton in attribute type rotation. If multiple locations
for a given content object appear on the list, most probably priority will be
overwritten.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components: Base, File



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezchildnodepriorityrotator/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezchildnodepriorityrotator

3. Prepare content classes by adding a dedicated integer-datatype attribute.

4. Configure ezchildnodepriorityrotator.ini file according to your preferences.

5. Configure cronjobs according to your needs.

6. Clear cache.



Changelog
---------

# v0.3 beta, public, 2007.12.19
+ Bug fix for priority mode, bad calculations (submitted by qradek.com).

# v0.2 beta, public, 2007.12.18
+ Completely new working mode - sorting of node's priority parameter.

# v0.1 beta, local, 2007.12.18
+ Rather stable version (with testing in mind ;).
+ Rotation of attribute-based sorting.  

# v0.0 alpha, local, 2007.12.18
+ Start.


/+/ complete
/-/ plan or in progress
