<?php

/**
 * eZ Child Node Priority Rotator extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


function findMinPriorityIndex( $array )
{
	$minIndex = -1;
	$currentMinPriority = 9999999;
	foreach( $array as $arrayKey => $arrayItem )
	{
		if( $arrayItem['SortPriority'] < $currentMinPriority )
		{
			$currentMinPriority = $arrayItem['SortPriority'];
			$minIndex = $arrayKey;
		}
	}
	return $minIndex;
}

function findMinValueByKey( $array )
{
	$minValue = 9999999;
	foreach( $array as $arrayKey => $arrayItem )
	{
		if( $arrayItem['data_int'] < $minValue )
		{
			$minValue = $arrayItem['data_int'];
		}
	}
	return $minValue;
}

if( !$isQuiet ) {$cli->output();}
if( !$isQuiet ) {$cli->output( 'eZ Child Node Priority Rotator initializing...' );}
if( !$isQuiet ) {$cli->output();}
$db = eZDB::instance();

include_once( "lib/ezutils/classes/ezini.php" );
$ini = eZINI::instance('childnodepriorityrotator.ini');
$iniGeneralSettings = $ini->group( 'GeneralSettings' );

if( !$isQuiet ) {$cli->output( 'Getting class index...', false );}
$classList = eZContentClass::fetchList();
$classIdentifierArray = array();
foreach( $classList as $class )
{
	$classIdentifierArray[] = $class->Identifier;
}
if( !$isQuiet ) {$cli->output( 'DONE!' );}


foreach( $iniGeneralSettings['RotationPreset'] as $preset )
{
	if( !$isQuiet ) {$cli->output();}

	$presetBlock = 'Preset-'.$preset;
	if( $ini->hasGroup( $presetBlock ) )
	{
		$iniPreset = $ini->group( $presetBlock );
		$iniPresetError = 0;

		switch( $iniPreset['RotationMode'] )
		{
			case 'attribute':
				if( !$isQuiet ) {$cli->output( '+++ Preset "'.$preset.'" [mode: '.$iniPreset['RotationMode'].'] +++' );}
				break;
			case 'priority':
				if( !$isQuiet ) {$cli->output( '+++ Preset "'.$preset.'" [mode: '.$iniPreset['RotationMode'].'] +++' );}
				break;
			case 'default':
				if( !$isQuiet ) {$cli->output( '+++ Preset "'.$preset.'" [mode: '.$iniPreset['RotationMode'].'] +++' );}
				if( !$isQuiet ) {$cli->output( 'Unknown preset mode "'.$iniPreset['RotationMode'].'"! Preset skipped!' );}
				$iniPresetError++;
				break;
		}

		if( !$iniPresetError )
		{
			if( !isset( $iniPreset['TopPriority'] ) )
			{
				if( !$isQuiet ) {$cli->output( 'Top priority is not set!' );}
				$iniPresetError++;
			}
			else
			{
				if( !is_numeric( $iniPreset['TopPriority'] ) )
				{
					if( !$isQuiet ) {$cli->output( 'Invalid priority: "'.$iniPreset['TopPriority'].'"!' );}
					$iniPresetError++;
				}
				else
				{
					if( $iniPreset['TopPriority'] > 9999999 )
					{
						$iniPreset['TopPriority'] = 9999999;
					}
				}
			}

			if( !isset( $iniPreset['ParentNodeID'] ) )
			{
				if( !$isQuiet ) {$cli->output( 'Parent node ID is not set!' );}
				$iniPresetError++;
			}
			else
			{
				if( !is_numeric( $iniPreset['ParentNodeID'] ) )
				{
					if( !$isQuiet ) {$cli->output( 'Invalid parent node ID: "'.$iniPreset['ParentNodeID'].'"!' );}
					$iniPresetError++;
				}
			}
			if( !isset( $iniPreset['ChildNodeDepth'] ) )
			{
				if( !$isQuiet ) {$cli->output( 'Child nodes depth is not set!' );}
				$iniPresetError++;
			}
			else
			{
				if( !is_numeric( $iniPreset['ChildNodeDepth'] ) )
				{
					if( !$isQuiet ) {$cli->output( 'Invalid depth value: "'.$iniPreset['ChildNodeDepth'].'"!' );}
					$iniPresetError++;
				}
			}
			if( !is_array( $iniPreset['ChildNodesList'] ) )
			{
				if( !$isQuiet ) {$cli->output( 'Child nodes class identifiers and attribute IDs not set!' );}
				$iniPresetError++;
			}
			else
			{
				switch( $iniPreset['RotationMode'] )
				{
					case 'attribute':
						foreach( $iniPreset['ChildNodesList'] as $classIdentifier => $classAttributeID )
						{
							if( !is_numeric( $classAttributeID ) )
							{
								if( !$isQuiet ) {$cli->output( 'Invalid class attribute ID: "'.$classAttributeID.'"!' );}
								$iniPresetError++;
							}
							if( !in_array( $classIdentifier, $classIdentifierArray ) )
							{
								if( !$isQuiet ) {$cli->output( 'Unknown class identifier : "'.$classIdentifier.'"!' );}
								$iniPresetError++;
							}
						}
						break;
					case 'priority':
						foreach( $iniPreset['ChildNodesList'] as $classIdentifier )
						{
							if( !in_array( $classIdentifier, $classIdentifierArray ) )
							{
								if( !$isQuiet ) {$cli->output( 'Unknown class identifier : "'.$classIdentifier.'"!' );}
								$iniPresetError++;
							}
						}
				}
			}
		}
		if( !$iniPresetError )
		{
			if( !$isQuiet ) {$cli->output( 'No configuration errors detected.' );}

			switch( $iniPreset['RotationMode'] )
			{
				case 'attribute':

					if( !$isQuiet ) {$cli->output( 'Getting priority matrix...', false );}
					$queryContentClassAttributeID = "( ";
					$cntQuery = 0;
					foreach( $iniPreset['ChildNodesList'] as $classIdentifier => $classAttributeID )
					{
						$cntQuery++;
						if( $cntQuery > 1 )
						{
							$queryContentClassAttributeID .= "OR ";
						}
						$queryContentClassAttributeID .= "contentclassattribute_id=".$classAttributeID." ";
					}
					$queryContentClassAttributeID .= " ) ";

					$query = "SELECT contentclassattribute_id, contentobject_id, data_int
						FROM ezcontentobject_attribute 
						WHERE ".$queryContentClassAttributeID." 
						GROUP BY contentobject_id ";
					$result = $db->arrayQuery( $query );

					$sortFullMatrix = array();
					foreach( $result as $row )
					{
						$sortFullMatrix[$row['contentobject_id']] = $row;
					}
					if( !$isQuiet ) {$cli->output( 'DONE!' );}


					$childNodesParams = array(
						'Depth' => $iniPreset['ChildNodeDepth'],
						'ClassFilterType' => 'include',
						'ClassFilterArray' => array_keys( $iniPreset['ChildNodesList'] ),
					);


					$childNodesList = eZContentObjectTreeNode::subTreeByNodeID( $childNodesParams, $iniPreset['ParentNodeID'] );

					$childNodesListCount = count( $childNodesList );
					if( !$isQuiet ) {$cli->output( 'Found '.$childNodesListCount.' nodes...' );}

					$childNodesDataArray = array();
					foreach( $childNodesList as $childNode )
					{
						array_push( $childNodesDataArray, array(
							'ContentObjectID' => $childNode->ContentObjectID,
							'ContentClassIdentifier' => $childNode->ClassIdentifier,
							'ContentClassAttributeID' => $iniPreset['ChildNodesList'][$childNode->ClassIdentifier],
							'NodeID' => $childNode->NodeID,
							'Name' => $childNode->Name,
							'SortPriority' => $sortFullMatrix[$childNode->ContentObjectID]['data_int'],
						) );
					}

					$nodeMinPriorityIndex = findMinPriorityIndex( $childNodesDataArray );

					$nodeDoublesArray = array();
					$nodeDoublesCount = 0;
					$nodeMinValue = findMinValueByKey( $sortFullMatrix );

					foreach( $childNodesDataArray as $key => $node )
					{
						if( !$isQuiet ) {$cli->output( $node['Name'].' (NodeID:'.$node['NodeID'].', Class:'.$node['ContentClassIdentifier'].') had position '.$sortFullMatrix[$node['ContentObjectID']]['data_int'], false );}

						if( $nodeMinPriorityIndex == $key )
						{
							$newPosition = $iniPreset['TopPriority'];
							if( in_array( $newPosition, $nodeDoublesArray ) || $newPosition > $iniPreset['TopPriority'] )
							{
								$nodeDoublesCount++;
								$newPosition = $nodeMinValue - $nodeDoublesCount;
							}
							array_push( $nodeDoublesArray, $newPosition );

							$querySetValue = "SET data_int=".$newPosition.", sort_key_int=data_int ";
							if( !$isQuiet ) {$cli->output( ', new position '.$iniPreset['TopPriority'] );}
						}
						else
						{
							$newPosition = $sortFullMatrix[$node['ContentObjectID']]['data_int']-1;
							if( in_array( $newPosition, $nodeDoublesArray ) || $newPosition > $iniPreset['TopPriority'] )
							{
								$nodeDoublesCount++;
								$newPosition = $nodeMinValue - $nodeDoublesCount;
							}
							array_push( $nodeDoublesArray, $newPosition );

							$querySetValue = "SET data_int=".$newPosition.", sort_key_int=data_int ";
							if( !$isQuiet ) {$cli->output( ', new position '.($newPosition) );}
						}

						$query = "UPDATE ezcontentobject_attribute ".
						$querySetValue.
							"WHERE contentobject_id=".$node['ContentObjectID']."
							AND contentclassattribute_id=".$node['ContentClassAttributeID'];
						$db->query( $query );
					}

					break;

					
				case 'priority':

					if( !$isQuiet ) {$cli->output( 'Getting priority matrix...', false );}

					// TODO: This query should be optimized so that it only grabs a limited, required amount of data!
					$query = "SELECT node_id, priority 
						FROM ezcontentobject_tree ";
					$result = $db->arrayQuery( $query );

					$sortFullMatrix = array();
					foreach( $result as $row )
					{
						$sortFullMatrix[$row['node_id']] = $row;
					}
					if( !$isQuiet ) {$cli->output( 'DONE!' );}


					$childNodesParams = array(
						'Depth' => $iniPreset['ChildNodeDepth'],
						'ClassFilterType' => 'include',
						'ClassFilterArray' => array_values( $iniPreset['ChildNodesList'] ),
					);

					$childNodesList = eZContentObjectTreeNode::subTreeByNodeID( $childNodesParams, $iniPreset['ParentNodeID'] );

					$childNodesListCount = count( $childNodesList );
					if( !$isQuiet ) {$cli->output( 'Found '.$childNodesListCount.' nodes...' );}

					$childNodesDataArray = array();
					foreach( $childNodesList as $childNode )
					{
						array_push( $childNodesDataArray, array(
							'ContentObjectID' => $childNode->ContentObjectID,
							'ContentClassIdentifier' => $childNode->ClassIdentifier,
							'ContentClassAttributeID' => $iniPreset['ChildNodesList'][$childNode->ClassIdentifier],
							'NodeID' => $childNode->NodeID,
							'Name' => $childNode->Name,
							'SortPriority' => $sortFullMatrix[$childNode->NodeID]['priority'],
						) );
					}

					$nodeMinPriorityIndex = findMinPriorityIndex( $childNodesDataArray );

					$nodeDoublesArray = array();
					$nodeDoublesCount = 0;
					$nodeMinValue = findMinValueByKey( $sortFullMatrix );

					foreach( $childNodesDataArray as $key => $node )
					{
						if( !$isQuiet ) {$cli->output( $node['Name'].' (NodeID:'.$node['NodeID'].', Class:'.$node['ContentClassIdentifier'].') had position '.$sortFullMatrix[$node['NodeID']]['priority'], false );}

						if( $nodeMinPriorityIndex == $key )
						{
							$newPosition = $iniPreset['TopPriority'];
							if( in_array( $newPosition, $nodeDoublesArray ) || $newPosition > $iniPreset['TopPriority'] )
							{
								$nodeDoublesCount++;
								$newPosition = $nodeMinValue - $nodeDoublesCount;
							}
							array_push( $nodeDoublesArray, $newPosition );

							$querySetValue = "SET priority=".$newPosition." ";
							if( !$isQuiet ) {$cli->output( ', new position '.$iniPreset['TopPriority'] );}
						}
						else
						{
							$newPosition = $sortFullMatrix[$node['NodeID']]['priority']-1;
							if( in_array( $newPosition, $nodeDoublesArray ) || $newPosition > $iniPreset['TopPriority'] )
							{
								$nodeDoublesCount++;
								$newPosition = $nodeMinValue - $nodeDoublesCount;
							}
							array_push( $nodeDoublesArray, $newPosition );

							$querySetValue = "SET priority=".$newPosition." ";
							if( !$isQuiet ) {$cli->output( ', new position '.($newPosition) );}
						}

						$query = "UPDATE ezcontentobject_tree ".
						$querySetValue.
							"WHERE node_id=".$node['NodeID'];
						$db->query( $query );
					}
					break;

			}
			if( !$isQuiet ) {$cli->output( 'Preset finished!' );}
		}
		else
		{
			if( !$isQuiet ) {$cli->output( 'Preset skipped!' );}
		}
	}
	else
	{
		if( !$isQuiet ) {$cli->output( 'No configuration found for preset! Preset skipped!' );}
	}
}

if( !$isQuiet ) {$cli->output();}
if( !$isQuiet ) {$cli->output( 'eZ Child Node Priority Rotator closing...' );}
if( !$isQuiet ) {$cli->output();}


?>
