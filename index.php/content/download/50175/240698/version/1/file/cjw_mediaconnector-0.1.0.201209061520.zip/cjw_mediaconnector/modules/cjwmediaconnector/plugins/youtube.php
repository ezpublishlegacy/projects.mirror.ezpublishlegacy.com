<?php
/**
 * File youtube.php
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @subpackage modules
 * @filesource
 */

$module     = $Params[ 'Module' ];
$parameters = array();

if ( isset( $Params[ 'Parameters' ] ) )
{
    $parameters = $Params[ 'Parameters' ];
}

// ToDo: Describe parameter array keys

switch ( $parameters[ 0 ] )
{
    case 'status':
        switch ( $parameters[ 1 ] )
        {
            case 'update':
                if ( $parameters[ 2 ] && $parameters[ 3 ] )
                {
                    // ToDo: if can edit
                    $ytObject = new CjwMediaconnectorYoutube( $parameters[ 2 ] );
                    $ytObject->updateStatusByRemoteId( $parameters[ 3 ] );

                    eZContentCacheManager::clearContentCache( $parameters[ 5 ] );
                    return $module->redirectTo( 'content/view/full/' . $parameters[ 4 ] );
                }
            break;

            case 'inspectresponsexml':
                $eZContentObject = eZContentObject::fetch( $parameters[ 3 ] );
                $dataMap         = $eZContentObject->dataMap();

                foreach ( $dataMap as $attribute )
                {
                    if ( $attribute->DataTypeString == $parameters[ 2 ] )
                    {
                        $content = $attribute->content();
                        break;
                    }
                }

                header( 'Content-type: text/xml' );
                echo $content->DataText2;

                eZExecution::cleanExit();
            break;
        }
    break;
}

?>