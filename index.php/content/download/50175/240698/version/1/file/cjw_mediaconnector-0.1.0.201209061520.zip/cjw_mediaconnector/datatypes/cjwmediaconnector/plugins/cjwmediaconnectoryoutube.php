<?php
/**
 * File containing the CjwMediaconnectorYoutube class
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @filesource
 */
/**
 * Youtube plugin class, handles youtube auth and file operations
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class CjwMediaconnectorYoutube extends CjwMediaconnectorPlugins
{
    /**
     *
     * @var string
     */
    var $DeveloperKey;

    /**
     * DB-Setting
     *
     * @var string
     */
    var $UserName;

    /**
     * DB-Setting
     *
     * @var string
     */
    var $Password;

    /**
     *
     * @var string
     */
    var $Source;

    /**
     *
     * @var unkown_type
     */
    var $ClassAttributeMappings;

    /**
     *
     * @var string
     */
    var $Plugin;

    /**
     *
     * @var unknown_type
     */
    var $PluginOptions;

    /**
     *
     * @var string
     */
    var $ContentObjectID;

    /**
     *
     * @var boolean
     */
    var $KeepLocalFile = false;

    /**
     *
     * @var boolean
     */
    var $Debug = false;

    /**
     *
     * @var boolean
     */
    var $FakeYt = false;

    /**
     * Constructor, initializes a new remote file object
     *
     * @param string $mediaconnectorPlugin
     * @return void
     */
    public function __construct( $mediaconnectorPlugin )
    {
        $pluginsSettingsArray = CjwMediaconnectorPlugins::getPluginSettings( $mediaconnectorPlugin );

        $this->DeveloperKey  = $pluginsSettingsArray[ 'DeveloperKey' ];
        $this->UserName      = $pluginsSettingsArray[ 'UserName' ];
        $this->Password      = $pluginsSettingsArray[ 'Password' ];
        $this->Source        = $pluginsSettingsArray[ 'Source' ];
        $this->Plugin        = $mediaconnectorPlugin;

        if ( array_key_exists( 'KeepLocalFile', $pluginsSettingsArray ) )
        {
            if ( $pluginsSettingsArray[ 'KeepLocalFile' ] == 'true' )
            {
                $this->KeepLocalFile = true;
            }
        }

        if ( array_key_exists( 'FakeYt', $pluginsSettingsArray ) )
        {
            if ( $pluginsSettingsArray[ 'FakeYt' ] == 'true' )
            {
                $this->FakeYt = true;
            }
        }

        if ( array_key_exists( 'Debug', $pluginsSettingsArray ) )
        {
            if ( $pluginsSettingsArray[ 'Debug' ] == 'true' )
            {
                $this->Debug = true;
            }
        }

        $this->ClassAttributeMappings = $pluginsSettingsArray[ 'ClassAttributeMappings' ];
    }

    /**
     * Get an yt auth token
     *
     * @return string
     */
    private function login()
    {
        $url = 'https://www.google.com/youtube/accounts/ClientLogin';

        $postData = 'Email=' . $this->UserName . '&Passwd=' . $this->Password . '&service=youtube&source=' . $this->Source;

        $curl = curl_init( $url );
        curl_setopt( $curl, CURLOPT_HEADER, 'Content-Type:application/x-www-form-urlencoded' );
        curl_setopt( $curl, CURLOPT_POST, 1 );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, $postData );
        curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 1 );

        if ( $this->FakeYt === FALSE )
        {
            $response = curl_exec( $curl );

            list( $auth, $youtubeuser )                  = explode( "\n", $response );
            list( $authlabel, $authValue )               = array_map( 'trim', explode( '=', $auth ) );
            list( $youtubeuserlabel, $youtubeuservalue ) = array_map( 'trim', explode( '=', $youtubeuser ) );
        }
        else
        {
            $authValue = 'FakeYt_authValue';
            $response  = 'FakeYt_response';
        }

        $curlError = curl_error( $curl );
        $curlInfo  = curl_getinfo( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        if ( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: curl info:\n" . print_r( $curlInfo, true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: post data: " . str_replace( $this->Password, '*****', $postData ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: response: \n" . $response, __METHOD__ );
        }

        return $authValue;
    }

    /**
     * Build an yt xml api request
     *
     * @return string
     */
    private function buildXmlApiRequest()
    {
        $eZContentObject = eZContentObject::fetch( $this->ContentObjectID );
        $ytAccessControl = $this->PluginOptions[ 'access' ];
        $ytCategory      = $this->PluginOptions[ 'category' ];
        $ytKeywords      = $this->PluginOptions[ 'keywords' ];
        $dataMap         = $eZContentObject->dataMap();
        $ytTitle         = $dataMap[ $this->ClassAttributeMappings[ 'ytTitle' ] ]->DataText;
        $ytDesc          = $dataMap[ $this->ClassAttributeMappings[ 'ytDesc' ] ]->DataText;
        $ytDesc          = trim( strip_tags( $ytDesc ) );

        $xml = '<?xml version="1.0"?>
<entry xmlns="http://www.w3.org/2005/Atom"
  xmlns:media="http://search.yahoo.com/mrss/"
  xmlns:yt="http://gdata.youtube.com/schemas/2007">
  <media:group>
    <media:title type="plain">' . $ytTitle . '</media:title>
    <media:description type="plain">
      ' . $ytDesc . '
    </media:description>
    <media:category scheme="http://gdata.youtube.com/schemas/2007/categories.cat">
        ' . $ytCategory . '
    </media:category>
    <media:keywords>' . $ytKeywords . '</media:keywords>
  </media:group>';

        foreach ( $ytAccessControl as $key => $value )
        {
            if ( $value != 'empty' )
            {
                $xml .= '<yt:accessControl action="' . $value . '" permission="denied"/>';
            }
        }

        $xml .= '</entry>';

        return $xml;
    }

    /**
     * Parse an yt api response
     *
     * @param string $response
     * @return array
     */
    private function parseApiResponse( $response )
    {
        $ytResponseArray = array( 'id'     => '',
                                  'status' => '',
                                  'url'    => '',
                                  'thumbs' => '',
                                  'errors' => '' );

        $responseXmlObject = simplexml_load_string( trim( $response ) );

        if ( $responseXmlObject )
        {
            // http://alisothegeek.com/2011/07/picking-apart-xml-feeds-and-namespaces-with-php-and-simplexml/
            foreach ( $responseXmlObject->getNameSpaces( true ) as $key => $children )
            {
                $$key = $responseXmlObject->children( $children );
            }

            if ( $responseXmlObject->id )
            {
                $youtubeId = explode( ':', $responseXmlObject->id );

                $ytResponseArray[ 'id' ] = $youtubeId[ 3 ];
            }

            if ( $app->control )
            {
                $state   = $responseXmlObject->xpath( 'app:control' );
                $ytState = $state[ 0 ]->xpath( 'yt:state' );

                // processing, restricted, deleted, rejected and failed
                $ytResponseArray[ 'status' ] = (string) $ytState[ 0 ]->attributes()->name;

                if ( $ytResponseArray[ 'status' ] != 'processing' )
                {
                    $ytResponseArray[ 'status' ] .= ' : ' . (string) $ytState[ 0 ]->attributes()->reasonCode;
                }
                else
                {
                    $ytResponseArray[ 'url' ] = '';
                }
            }
            else
            {
                $ytResponseArray[ 'status' ] = 'published';
            }

            if ( $media->group->content )
            {
                $youtubeUrl = $media->group->content->attributes()->url;
                $youtubeUrl = explode( '?', $youtubeUrl );

                $ytResponseArray[ 'url' ] = $youtubeUrl[ 0 ];
            }

            if ( $media->group->thumbnail )
            {
                $default   = $media->group->thumbnail[ 0 ]->attributes()->url;
                $hqdefault = $media->group->thumbnail[ 1 ]->attributes()->url;

                $ytResponseArray[ 'thumbs' ] = $default . '|' . $hqdefault;
            }
        }
        else
        {
            $ytResponseArray[ 'errors' ] = $response;
            $ytResponseArray[ 'status' ] = 'error';
        }

        return $ytResponseArray;
    }

    /**
     * Uploads an file to yt
     * http://code.google.com/intl/de-DE/apis/youtube/2.0/developers_guide_protocol_direct_uploading.html
     * http://stackoverflow.com/questions/2126330/uploading-large-video-via-youtube-api-causing-out-of-memory
     *
     * @param string $filePath
     * @param string $mimeType
     * @return string
     */
    private function uploadDirect( $filePath, $mimeType )
    {
        $host     = 'uploads.gdata.youtube.com';
        $baseName = basename( $filePath );

        $authValue = $this->login();

        $xmlAPIRequest = $this->buildXmlApiRequest();

        $boundaryString = substr( md5( rand( 0, 32000 ) ), 0, 10 );

        $postData  = '--' . $boundaryString . "\r\n";
        $postData .= 'Content-Type: application/atom+xml; charset=UTF-8' . "\r\n\r\n";
        $postData .= $xmlAPIRequest . "\r\n";
        $postData .= '--' . $boundaryString . "\r\n";
        $postData .= 'Content-Type: ' . $mimeType . "\r\n";
        $postData .= 'Content-Transfer-Encoding: binary' . "\r\n\r\n";

        // create temporary file handle
        $tfh = tmpfile();

        fwrite( $tfh, $postData );

        $videoFile = fopen( $filePath, 'r' );
        stream_copy_to_stream( $videoFile, $tfh );
        fclose( $videoFile );

        fwrite( $tfh, "\r\n--$boundaryString--\r\n" );

        $postData .= $filePath;
        $postData .= "\r\n--$boundaryString--\r\n";

        $info = fstat( $tfh );
        rewind( $tfh );

        $contentLength = $info[ 'size' ];

        $header  = 'POST /feeds/api/users/default/uploads HTTP/1.1' . "\r\n";
        $header .= 'Host: ' . $host . "\r\n";
        $header .= 'Authorization: GoogleLogin auth="' . $authValue . '"' . "\r\n";
        $header .= 'GData-Version: 2' . "\r\n";
        $header .= 'X-GData-Key: key=' . $this->DeveloperKey . "\r\n";
        $header .= 'Slug: ' . $baseName . "\r\n";
        $header .= 'Content-Type: multipart/related; boundary="' . $boundaryString . '"' . "\r\n";
        $header .= 'Content-Length: ' . $contentLength . "\r\n";
        $header .= 'Connection: close' . "\r\n\r\n";

        if ( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: post header:\n" . str_replace( $this->DeveloperKey, '*****', $header ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: post body:\n" . $postData, __METHOD__ );
        }

        if ( $this->FakeYt === FALSE )
        {
            $conn = fsockopen( $host, 80, $errno, $errstr );
            // if $errno, $errstr

            /* write http request to $conn */
            fwrite( $conn, $header );

            // write post data from stream to stream
            $bytes = stream_copy_to_stream( $tfh, $conn );

            $response = '';

            while( !feof( $conn ) )
            {
                $response .= fgets( $conn, 128 );
            }

            fclose( $conn );
        }
        else
        {
            $bytes = '00000';
            $response = 'FakeYt_response Connection: close ' . $this->fakeYtResponse();
        }

        if ( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: bytes body: " . $bytes, __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: response\n" . $response, __METHOD__ );
        }

        $responseBody = explode( 'Connection: close', $response );
        $response     = trim( $responseBody[ 1 ] );

        return $response;
    }

    /**
     * Handles storing of remote files (create, update) and auth
     *
     * @param object &$mediaObject
     * @param boolean $hasHttpFile
     * @param integer $contentObjectID
     * @return boolean
     */
    function store( &$mediaObject, $hasHttpFile, $contentObjectID )
    {
        // store Logik, mögliche Fälle:
        // 1. object neu angelegt, speichern kein file => nichts machen
        // 2. object neu angelegt, speichern file vorhanden => upload direct
        // 3. object aktualisiert, speichern file vorhanden, vorher keins => upload direct
        // 4. object aktualisiert, speichern kein file, vorher keins => nichts machen = wie 1.
        // 5. object aktualisiert, speichern file vorhanden, vorher auch, hash nicht gleich => delete, upload direct
        // 6. object aktualisiert, speichern file vorhanden, vorher auch, hash ist gleich => update
        // 7. object bearbeiten file löschen => delete, nicht relevant da funktion direkt aufgerufen wird
        // 8. object gelöscht => delete aber nur einmal! (versionen) und nur wenn vorher file vorhanden war

        $this->ContentObjectID = $contentObjectID;
        $this->PluginOptions   = unserialize( $mediaObject->attribute( 'plugin_options' ) );

        $oldHash = $mediaObject->attribute( 'hash' );
        $newHash = '';
        $response = '';

        // Fall 1, 4
        if ( $hasHttpFile === FALSE && $oldHash == '' )
        {
            return $mediaObject;
        }

        // Fall 2, 3, 5, 6
        if ( $hasHttpFile !== FALSE )
        {
            $filePath = $mediaObject->filepath();
            $newHash  = md5_file( $filePath );
        }

        // Fall 5
        if ( $newHash != '' && $oldHash != '' && $newHash != $oldHash )
        {
            $this->delete( $mediaObject->attribute( 'remote_id' ) );
        }

        // Fall 2, 3, 5
        if ( $newHash != '' && $newHash != $oldHash )
        {
            $mimeType = $mediaObject->attribute( 'mime_type' );

            $mediaObject->setAttribute( 'status', 'uploading' );
            $mediaObject->store();

            // Direct upload
            $response = $this->uploadDirect( $filePath, $mimeType );

            // remove local (temp) file
            if ( $this->KeepLocalFile === FALSE )
            {
                $localFile = eZClusterFileHandler::instance( $filePath );

                if ( $localFile->exists() )
                {
                    $localFile->delete();
                }

                $mediaObject->setAttribute( 'filename', '' );
            }
        }

        // Fall 6
        if ( $newHash == '' && $oldHash != '' )
        {
            $response = $this->updateByRemoteId( $mediaObject->attribute( 'remote_id' ) );
            $newHash  = $oldHash;
        }

        if ( $response )
        {
            $ytResponseArray = $this->parseApiResponse( $response );

            $mediaObject->setAttribute( 'remote_id', $ytResponseArray[ 'id' ] );
            $mediaObject->setAttribute( 'status', $ytResponseArray[ 'status' ] );
            $mediaObject->setAttribute( 'url', $ytResponseArray[ 'url' ] );
            $mediaObject->setAttribute( 'data_text1', $ytResponseArray[ 'thumbs' ] );
            $mediaObject->setAttribute( 'data_text2', $response );
        }

        $mediaObject->setAttribute( 'hash', $newHash );

        $mediaObject->store();

        return true;
    }

    /**
     * Update the status for an video file (local)
     * http://code.google.com/intl/de-DE/apis/youtube/2.0/developers_guide_protocol.html#Check_Upload_Status
     *
     * @param string $remoteId
     * @return boolean
     */
    function updateStatusByRemoteId( $remoteId )
    {
        $response = $this->exists( $remoteId );

        $ytResponseArray = $this->parseApiResponse( $response );

        $ytVideoStatus = $ytResponseArray['status'];

        $db = eZDB::instance();

        $rows = $db->arrayQuery( "SELECT
                                      contentobject_attribute_id,version
                                  FROM
                                      cjwmediaconnector
                                  WHERE
                                      remote_id='$remoteId'
                                  ORDER BY version DESC
                                  LIMIT 1" );

        $contentObjectAttributeID      = $rows[ 0 ][ 'contentobject_attribute_id' ];
        $contentObjectAttributeVersion = $rows[ 0 ][ 'version' ];

        $db->query( "UPDATE
                        cjwmediaconnector SET status='" . $ytVideoStatus . "'
                     WHERE
                        contentobject_attribute_id=" . $contentObjectAttributeID . "
                     AND
                        version=" . $contentObjectAttributeVersion );

        $db->query( "UPDATE
                        cjwmediaconnector SET data_text2='" . addslashes( $response ) . "'
                     WHERE
                        contentobject_attribute_id=" . $contentObjectAttributeID . "
                     AND
                        version=" . $contentObjectAttributeVersion );

        return true;
    }

    /**
     * Update yt meta data for an viedo file (remote)
     * http://code.google.com/intl/de-DE/apis/youtube/2.0/developers_guide_protocol_updating_and_deleting_videos.html#Updating_Video_Entry
     *
     * @param string $remoteId
     * @return string
     */
    private function updateByRemoteId( $remoteId )
    {
        $url = 'https://gdata.youtube.com/feeds/api/users/' . $this->UserName . '/uploads/' . $remoteId;

        $xmlAPIRequest = $this->buildXmlApiRequest();

        $authValue = $this->login();

        $headers = array( 'Authorization: GoogleLogin auth=' . $authValue,
                          'GData-Version: 2',
                          'X-GData-Key: key=' . $this->DeveloperKey,
                          'Content-length: ' . strlen( $xmlAPIRequest ),
                          'Content-Type: application/atom+xml; charset=UTF-8' );

        $curl = curl_init( $url );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $curl, CURLOPT_TIMEOUT, 10 );
        curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'PUT' );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, $xmlAPIRequest );

        if ( $this->FakeYt === FALSE )
        {
            $response = curl_exec( $curl );
        }
        else
        {
            $response = $this->fakeYtResponse();
        }

        $curlError = curl_error( $curl );
        $curlInfo = curl_getinfo( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        if ( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: curl info:\n" . print_r( $curlInfo, true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: put headers: \n" . print_r( str_replace( $this->DeveloperKey, '*****', $headers ), true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: put body: \n" . $xmlAPIRequest, __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: put response\n" . $response, __METHOD__ );
        }

        return $response;
    }

    /**
     * check if video file exists, if true get remote file information
     * http://code.google.com/intl/de-DE/apis/youtube/2.0/developers_guide_protocol.html#Check_Upload_Status
     *
     * @param string $remoteId
     * @return boolean
     */
    function exists( $remoteId )
    {
        $url = 'http://gdata.youtube.com/feeds/api/users/' . $this->UserName . '/uploads/' . $remoteId;

        $curl = curl_init( $url );
        curl_setopt( $curl, CURLOPT_GET, 1 );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );

        if ( $this->FakeYt === FALSE )
        {
            $response = curl_exec( $curl );
        }
        else
        {
            $response = $this->fakeYtResponse();
        }

        $curlError = curl_error( $curl );
        $curlInfo  = curl_getinfo( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        if ( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: curl info:\n" . print_r( $curlInfo, true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: get response:\n" . $response, __METHOD__ );
        }

        if ( $curlError != '' )
        {
            return false;
        }
        else
        {
            return $response;
        }
    }

    /**
     * Get an remote file, handles auth
     *
     * @param string $remoteId
     * @return void
     */
    function download( $remoteId )
    {
        /* not allowed by yt terms of service http://www.mailinglistarchive.com/html/youtube-api-gdata@googlegroups.com/2011-09/msg00183.html
        $mimeType = CjwMediaconnectorData::fetchByRemoteId( $remoteId, false );
        $mimeType = $mimeType[0]['mime-type'];

        $authValue = $this->login();

        $url = 'http://www.youtube.com/download_my_video?v='.$remoteId;

        $headers = array( 'Authorization: GoogleLogin auth='.$authValue,
                          'GData-Version: 2',
                          'X-GData-Key: key='.$this->DeveloperKey );

        $curl = curl_init();
        curl_setopt( $curl, CURLOPT_URL, $url );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 0 );

        header( 'Content-type: '.$mimeType.';' );

        curl_exec( $curl );

        $curlError = curl_error( $curl );
        $curlInfo = curl_getinfo( $curl );

        curl_close( $curl );

        if( $curlError != '' )
            eZDebug::writeError( "cjw_mediaconnector: curl error: ".$curlError, __METHOD__ );
        */

        eZExecution::cleanExit();
    }

    /**
     * Handles deletion of remote files (auth)
     * http://code.google.com/intl/de-DE/apis/youtube/2.0/developers_guide_protocol_updating_and_deleting_videos.html#Deleting_a_video
     *
     * @param string $remoteId
     * @return boolean
     */
    function delete( $remoteId )
    {
        // prevent not necessarily yt delete requests (remove object with versions)
        $db = eZDB::instance();

        $rows = $db->arrayQuery( "SELECT
                                      status
                                  FROM
                                      cjwmediaconnector
                                  WHERE
                                      remote_id='$remoteId'
                                  AND
                                      plugin='$this->Plugin'
                                  LIMIT 1" );

        if ( $rows[ 0 ][ 'status' ] == 'deleted' )
        {
            return true;
        }

        $authValue = $this->login();

        $url = 'http://gdata.youtube.com/feeds/api/users/' . $this->UserName . '/uploads/' . $remoteId;

        $headers = array( 'Authorization: GoogleLogin auth=' . $authValue,
                          'GData-Version: 2',
                          'X-GData-Key: key=' . $this->DeveloperKey,
                          'Content-Type: application/atom+xml; charset=UTF-8' );

        $curl = curl_init( $url );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $curl, CURLOPT_TIMEOUT, 10 );
        curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'DELETE' );

        if ( $this->FakeYt === FALSE )
        {
            $response = curl_exec( $curl );
        }
        else
        {
            $response = 'FakeYt_response';
        }

        $curlError = curl_error( $curl );
        $curlInfo  = curl_getinfo( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        if( $this->Debug !== FALSE )
        {
            eZDebug::writeDebug( "cjw_mediaconnector: curl info:\n" . print_r( $curlInfo, true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: delete headers:\n" . print_r( str_replace( $this->DeveloperKey, '*****', $headers ), true ), __METHOD__ );
            eZDebug::writeDebug( "cjw_mediaconnector: delete response\n" . $response, __METHOD__ );
        }

        // prevent not necessarily yt delete requests (remove object with versions)
        $db->query( "UPDATE
                         cjwmediaconnector
                     SET
                         status='deleted'
                     WHERE
                         remote_id='$remoteId'
                     AND
                         plugin='$this->Plugin'" );

        return true;
    }

    /**
     * For testing and debugging
     *
     * @return string
     */
    private function fakeYtResponse()
    {
        $ytTitle = 'fakeYtTitle';
        $ytDesc  = 'fakeYtDescription';

        if ( $this->ContentObjectID )
        {
            $eZContentObject = eZContentObject::fetch( $this->ContentObjectID );
            $dataMap         = $eZContentObject->dataMap();
            $ytTitle         = $dataMap[ $this->ClassAttributeMappings[ 'ytTitle' ] ]->DataText;
            $ytDesc          = $dataMap[ $this->ClassAttributeMappings[ 'ytDesc' ] ]->DataText;
            $ytDesc          = trim( strip_tags( $ytDesc ) );
        }

        $category     = $this->PluginOptions[ 'category' ];
        $keywords     = $this->PluginOptions[ 'keywords' ];
        $fakeYtStatus = 'fakeYtStatus_' . time();
        $fakeYtId     =  'fakeYtId';

        $response = "<?xml version='1.0' encoding='UTF-8'?>
<entry xmlns='http://www.w3.org/2005/Atom' xmlns:app='http://www.w3.org/2007/app' xmlns:media='http://search.yahoo.com/mrss/' xmlns:gd='http://schemas.google.com/g/2005' xmlns:yt='http://gdata.youtube.com/schemas/2007' gd:etag='W/&quot;DEAFRH47eCp7I2A9WhVTFEo.&quot;'>
    <id>tag:youtube.com,2008:video:$fakeYtId</id>
    <published>2012-02-29T00:51:55.000Z</published>
    <updated>2012-02-29T00:51:55.000Z</updated>
    <app:edited>2012-02-29T00:51:55.000Z</app:edited>
    <app:control>
        <app:draft>yes</app:draft>
        <yt:state name='$fakeYtStatus'/>
    </app:control>
    <category scheme='http://schemas.google.com/g/2005#kind' term='http://gdata.youtube.com/schemas/2007#video'/>
    <category scheme='http://gdata.youtube.com/schemas/2007/categories.cat' term='$category' label='$category'/>
    <category scheme='http://gdata.youtube.com/schemas/2007/keywords.cat' term='$keywords'/>
    <title>$ytTitle</title>
    <link rel='alternate' type='text/html' href='http://www.youtube.com/watch?v=$fakeYtId&amp;feature=youtube_gdata'/>
    <link rel='http://gdata.youtube.com/schemas/2007#video.complaints' type='application/atom+xml' href='http://gdata.youtube.com/feeds/api/videos/$fakeYtId/complaints'/>
    <link rel='http://gdata.youtube.com/schemas/2007#video.related' type='application/atom+xml' href='http://gdata.youtube.com/feeds/api/videos/$fakeYtId/related'/>
    <link rel='http://gdata.youtube.com/schemas/2007#video.captionTracks' type='application/atom+xml' href='http://gdata.youtube.com/feeds/api/videos/$fakeYtId/captions' yt:hasEntries='false'/>
    <link rel='http://gdata.youtube.com/schemas/2007#insight.views' type='text/html' href='http://insight.youtube.com/video-analytics/csvreports?query=$fakeYtId&amp;type=v&amp;starttime=1235865600000&amp;endtime=1330387200000&amp;user_starttime=1329782400000&amp;user_endtime=1330387200000&amp;region=world&amp;token=TIbs9wZbnM3MgwabvN5CPIyqWDB8MTMzMDQ3ODUxNUAxMzMwNDc2NzE1&amp;hl=en_US'/>
    <link rel='self' type='application/atom+xml' href='http://gdata.youtube.com/feeds/api/users/USERNAME/uploads/$fakeYtId'/>
    <link rel='edit' type='application/atom+xml' href='http://gdata.youtube.com/feeds/api/users/USERNAME/uploads/$fakeYtId'/>
    <author>
        <name>USERNAME</name>
        <uri>http://gdata.youtube.com/feeds/api/users/USERNAME</uri>
    </author>";

        foreach( $ytAccessControl as $key => $value )
        {
            if( $value != 'empty' )
            {
                $response .= "<yt:accessControl action='$value' permission='denied'/>";
            }
        }

    $response .= "<media:group>
        <media:category label='$category' scheme='http://gdata.youtube.com/schemas/2007/categories.cat'>$category</media:category>
        <media:content url='http://www.youtube.com/v/$fakeYtId?version=3&amp;f=user_uploads&amp;d=AYNzVEfSDYovc4FZN7SZzDcO88HsQjpE1a8d1GxQnGDm&amp;app=youtube_gdata' type='application/x-shockwave-flash' medium='video' isDefault='true' expression='full' duration='0' yt:format='5'/>
        <media:credit role='uploader' scheme='urn:youtube' yt:display='USERNAME'>USERNAME</media:credit>
        <media:description type='plain'>$ytDesc</media:description>
        <media:keywords>$keywords</media:keywords>
        <media:license type='text/html' href='http://www.youtube.com/t/terms'>youtube</media:license>
        <media:player url='http://www.youtube.com/watch?v=$fakeYtId&amp;feature=youtube_gdata_player'/>
        <media:thumbnail url='http://i.ytimg.com/vi/$fakeYtId/default.jpg' height='90' width='120' time='00:00:00' yt:name='default'/>
        <media:thumbnail url='http://i.ytimg.com/vi/$fakeYtId/hqdefault.jpg' height='360' width='480' yt:name='hqdefault'/>
        <media:thumbnail url='http://i.ytimg.com/vi/$fakeYtId/1.jpg' height='90' width='120' time='00:00:00' yt:name='start'/>
        <media:thumbnail url='http://i.ytimg.com/vi/$fakeYtId/2.jpg' height='90' width='120' time='00:00:00' yt:name='middle'/>
        <media:thumbnail url='http://i.ytimg.com/vi/$fakeYtId/3.jpg' height='90' width='120' time='00:00:00' yt:name='end'/>
        <media:title type='plain'>$ytTitle</media:title>
        <yt:duration seconds='0'/>
        <yt:uploaded>2012-02-29T00:51:55.000Z</yt:uploaded>
        <yt:videoid>$fakeYtId</yt:videoid>
    </media:group>
</entry>";

        return $response;
    }
}

?>