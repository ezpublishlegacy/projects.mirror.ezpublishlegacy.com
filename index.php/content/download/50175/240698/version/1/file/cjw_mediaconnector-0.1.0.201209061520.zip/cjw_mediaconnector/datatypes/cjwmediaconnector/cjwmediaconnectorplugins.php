<?php
/**
 * File containing the CjwMediaconnectorPlugins class
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @filesource
 */
/**
 * methods used by mediaconnector plugins
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class CjwMediaconnectorPlugins
{
    /**
     * Constructor
     *
     * @return void
     */
    function __construct(){}

    /**
     * Get the type for an cjwmediaconnector plugin
     *
     * @param string $plugin
     * @return string | boolean
     */
    static function getPluginType( $plugin )
    {
        $pluginType = false;

        $cjwMediaconnectorIni = eZINI::instance( 'cjw_mediaconnector.ini' );

        if ( $cjwMediaconnectorIni->hasVariable( 'MediaconnectorPluginSettings_' . $plugin, 'PluginType' ) )
        {
            $pluginType = $cjwMediaconnectorIni->variable( 'MediaconnectorPluginSettings_' . $plugin, 'PluginType' );
        }

        return $pluginType;
    }

    /**
     * Get the settings for an cjwmediaconnector plugin
     *
     * @param string $plugin
     * @return array | boolean
     */
    protected function getPluginSettings( $plugin )
    {
        $cjwMediaconnectorIni = eZINI::instance( 'cjw_mediaconnector.ini' );

        $iniGroupName = 'MediaconnectorPluginSettings_' . $plugin;
        $hasIniGroup  = $cjwMediaconnectorIni->hasGroup( $iniGroupName );

        if ( $hasIniGroup !== FALSE )
        {
            return $cjwMediaconnectorIni->BlockValues[ $iniGroupName ];
        }
        else
        {
            return false;
        }
    }

    /**
     * Handles storing of remote files (auth, create, update)
     *
     * @param object &$mediaObject
     * @param boolean $hasHttpFile
     * @param integer $contentObjectID
     * @return boolean
     */
    protected function store( &$mediaObject, $hasHttpFile, $contentObjectID )
    {
        return true;
    }

    /**
     * Handles deletion of remote files (auth)
     *
     * @param string $remoteId
     * @return boolean
     */
    protected function delete( $remoteId )
    {
        return true;
    }

    /**
     * Get an remote file, handles auth
     *
     * @param string $remoteId
     * @return boolean
     */
    protected function download( $remoteId )
    {
        return true;
    }
}

?>