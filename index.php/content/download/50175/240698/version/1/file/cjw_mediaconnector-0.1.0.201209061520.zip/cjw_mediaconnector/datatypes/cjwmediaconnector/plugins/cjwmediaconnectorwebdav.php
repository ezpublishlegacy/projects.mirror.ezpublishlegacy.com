<?php
/**
 * File containing the CjwMediaconnectorWebdav class
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @filesource
 */
/**
 * WebDav plugin class, handles WebDav auth and file operations
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class CjwMediaconnectorWebdav extends CjwMediaconnectorPlugins
{
    /**
     * DB-Setting
     *
     * @var string
     */
    var $UserName;

    /**
     * DB-Setting
     *
     * @var string
     */
    var $Password;

    /**
     * DB-Setting
     *
     * @var string
     */
    var $Server;

    /**
     *
     * @var string
     */
    var $Directory;

    /**
     *
     * @var boolean
     */
    var $KeepLocalFile = false;

    /**
     * Constructor, initializes a new remote file object
     *
     * @param string $mediaconnectorPlugin
     * @return void
     */
    function __construct( $mediaconnectorPlugin )
    {
        $pluginsSettingsArray = CjwMediaconnectorPlugins::getPluginSettings( $mediaconnectorPlugin );

        $this->UserName  = $pluginsSettingsArray[ 'UserName' ];
        $this->Password  = $pluginsSettingsArray[ 'Password' ];
        $this->Server    = $pluginsSettingsArray[ 'Server' ];
        $this->Directory = $pluginsSettingsArray[ 'Directory' ];

        if ( array_key_exists( 'KeepLocalFile', $pluginsSettingsArray ) )
        {
            if ( $pluginsSettingsArray[ 'KeepLocalFile' ] == 'true' )
            {
                $this->KeepLocalFile = true;
            }
        }
    }

    /**
     * Handles storing of remote files (create, update) and auth
     *
     * @param object &$mediaObject
     * @param boolean $hasHttpFile
     * @param integer $contentObjectID
     * @return boolean
     */
    function store( &$mediaObject, $hasHttpFile, $contentObjectID )
    {
        if ( $hasHttpFile !== FALSE )
        {
            $filePath = $mediaObject->filepath();

            $fp   = fopen( $filePath, 'r' );
            $url  = 'http://' . $this->Server . $this->Directory . $mediaObject->attribute( 'filename' );

            $curl = curl_init();

            curl_setopt( $curl, CURLOPT_URL, $url );
            // ? curl_setopt( $curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC );
            curl_setopt( $curl, CURLOPT_USERPWD, $this->UserName . ':' . $this->Password );
            curl_setopt( $curl, CURLOPT_PUT, 1 );
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
            curl_setopt( $curl, CURLOPT_INFILE, $fp );
            curl_setopt( $curl, CURLOPT_INFILESIZE, filesize( $filePath ) );

            $response  = curl_exec( $curl );
            $curlError = curl_error( $curl );
            curl_close( $curl );
            fclose( $fp );

            if ( $curlError == '' )
            {
                $mediaObject->setAttribute( 'remote_id', $mediaObject->attribute( 'filename' ) );
                $mediaObject->setAttribute( 'url', $url );
                $mediaObject->setAttribute( 'status', 'published' );
            }
            else
            {
                $mediaObject->setAttribute( 'remote_id', '' );
                $mediaObject->setAttribute( 'url', '' );
                $mediaObject->setAttribute( 'status', 'error: '.$curlError );

                eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
            }

            $mediaObject->setAttribute( 'data_text1', $response );

            // remove local (temp) file
            if ( $this->KeepLocalFile === FALSE )
            {
                $localFile = eZClusterFileHandler::instance( $filePath );

                if ( $localFile->exists() )
                {
                    $localFile->delete();
                }

                $mediaObject->setAttribute( 'filename', '' );
            }

            $mediaObject->store();
        }

        return true;
    }

    /**
     * Get an remote file, handles auth
     *
     * @param string $remoteId
     * @return void
     */
    function download( $remoteId )
    {
        $mimeType = CjwMediaconnectorData::fetchByRemoteId( $remoteId, false );
        $mimeType = $mimeType[ 0 ][ 'mime-type' ];

        $url  = 'http://' . $this->Server . $this->Directory . $remoteId;

        $curl = curl_init();

        curl_setopt( $curl, CURLOPT_URL, $url );
        curl_setopt( $curl, CURLOPT_USERPWD, $this->UserName . ':' . $this->Password );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 0 );

        header( 'Content-type: ' . $mimeType.';' );

        curl_exec( $curl );

        $curlError = curl_error( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        eZExecution::cleanExit();
    }

    /**
     * Handles deletion of remote files (auth)
     *
     * @param string $remoteId
     * @return boolean
     */
    function delete( $remoteId )
    {
        $url = 'http://' . $this->Server . $this->Directory . $remoteId;

        $curl = curl_init();

        curl_setopt( $curl, CURLOPT_URL, $url );
        curl_setopt( $curl, CURLOPT_USERPWD, $this->UserName . ':' . $this->Password );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'DELETE' );

        $response  = curl_exec( $curl );
        $curlError = curl_error( $curl );

        curl_close( $curl );

        if ( $curlError != '' )
        {
            eZDebug::writeError( "cjw_mediaconnector: curl error: " . $curlError, __METHOD__ );
        }

        return true;
    }
}

?>