<?php
/**
 * File module.php
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @subpackage modules
 * @filesource
 */

$Module = array( 'name' => 'CJW Media Connector', 'variable_params' => true );

$ViewList = array();

$ViewList[ 'media' ]   = array( 'script'                  => 'media.php',
                                'functions'               => array( 'media' ),
                                'default_navigation_part' => 'cjwmediaconnectoravigationpart' );

$ViewList[ 'youtube' ] = array( 'script'                  => 'plugins/youtube.php',
                                'functions'               => array( 'youtube' ),
                                'default_navigation_part' => 'cjwmediaconnectoravigationpart' );

$FunctionList              = array();
$FunctionList[ 'media' ]   = array();
$FunctionList[ 'youtube' ] = array();

?>
