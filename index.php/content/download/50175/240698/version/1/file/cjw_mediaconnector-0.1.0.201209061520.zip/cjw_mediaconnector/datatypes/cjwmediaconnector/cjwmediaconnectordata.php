<?php
/**
 * File containing the CjwMediaconnectorData class
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @filesource
 */
/**
 * Handles registered media files objects persistant data
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class CjwMediaconnectorData extends eZPersistentObject
{
    /**
    *
    * @var integer
    */
    public $ContentObjectAttributeID;

    /**
    *
    * @var string
    */
    public $Filename;

    /**
    *
    * @var string
    */
    public $OriginalFilename;

    /**
    *
    * @var string
    */
    public $RemoteID;

    /**
    *
    * @var string
    */
    public $Status;

    /**
    *
    * @var string
    */
    public $URL;

    /**
    *
    * @var string
    */
    public $MimeType;

    /**
    *
    * @var string
    */
    public $Plugin;

    /**
    *
    * @var string
    */
    public $PluginType;

    /**
    *
    * @var string
    */
    public $PluginOptions;

    /**
     * Constructor
     *
     * @param unknown_type $row
     * @return void
     */
    function CjwMediaconnectorData( $row )
    {
        $this->eZPersistentObject( $row );
    }

    /**
     * DB-Definition
     *
     * @return array
     */
    static function definition()
    {
        static $definition = array( 'fields' => array( 'contentobject_attribute_id' => array( 'name'              => 'ContentObjectAttributeID',
                                                                                              'datatype'          => 'integer',
                                                                                              'default'           => 0,
                                                                                              'required'          => true,
                                                                                              'foreign_class'     => 'eZContentObjectAttribute',
                                                                                              'foreign_attribute' => 'id',
                                                                                              'multiplicity'      => '1..*' ),

                                                       'version'                    => array( 'name'              => 'Version',
                                                                                              'datatype'          => 'integer',
                                                                                              'default'           => 0,
                                                                                              'required'          => true ),

                                                       'filename'                   => array( 'name'              => 'Filename',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'original_filename'          => array( 'name'              => 'OriginalFilename',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'remote_id'                  => array( 'name'              => 'RemoteID',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'hash'                       => array( 'name'              => 'Hash',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'status'                     => array( 'name'              => 'Status',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'url'                        => array( 'name'              => 'URL',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'data_text1'                 => array( 'name'              => 'DataText1',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'data_text2'                 => array( 'name'              => 'DataText2',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'plugin_options'             => array( 'name'              => 'PluginOptions',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'mime_type'                  => array( 'name'              => 'MimeType',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'plugin_type'                => array( 'name'              => 'PluginType',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true ),

                                                       'plugin'                     => array( 'name'              => 'Plugin',
                                                                                              'datatype'          => 'string',
                                                                                              'default'           => '',
                                                                                              'required'          => true )
                                                     ),

                                    'keys'   => array( 'contentobject_attribute_id', 'version' ),

                                    'function_attributes' => array( 'filesize'           => 'filesize',
                                                                    'filepath'           => 'filepath',
                                                                    'mime_type_category' => 'mimeTypeCategory',
                                                                    'mime_type_part'     => 'mimeTypePart' ),

                                    'relations' => array( 'contentobject_attribute_id' => array( 'class' => 'ezcontentobjectattribute',
                                                                                                 'field' => 'id' ),
                                                          'version'                    => array( 'class' => 'ezcontentobjectattribute',
                                                                                                 'field' => 'version' )
                                                        ),

                                    'class_name' => 'CjwMediaconnectorData',

                                    'name'       => 'cjwmediaconnector' );
        return $definition;
    }

    /**
     * Get file size
     *
     * @return float
     */
    function fileSize()
    {
        $fileInfo = $this->storedFileInfo();

        $file = eZClusterFileHandler::instance( $fileInfo[ 'filepath' ] );

        if ( $file->exists() )
        {
            return $file->size();
        }

        return 0;
    }

    /**
     * Get file path
     *
     * @return string
     */
    function filePath()
    {
        $fileInfo = $this->storedFileInfo();

        return $fileInfo[ 'filepath' ];
    }

    /**
     * Get mime type category
     *
     * @return string
     */
    function mimeTypeCategory()
    {
        $types = explode( '/', eZPersistentObject::attribute( 'mime_type' ) );

        return $types[ 0 ];
    }

    /**
     * Get mime type part
     *
     * @return string
     */
    function mimeTypePart()
    {
        $types = explode( '/', eZPersistentObject::attribute( 'mime_type' ) );

        return $types[ 1 ];
    }

    /**
     * Create
     *
     * @param integer $contentObjectAttributeID
     * @param string $version
     * @param string $plugin
     * @param string $pluginType
     * @return CjwMediaconnectorData
     */
    static function create( $contentObjectAttributeID, $version, $plugin = '', $pluginType = '' )
    {
        $row = array( 'contentobject_attribute_id' => $contentObjectAttributeID,
                      'version'                    => $version,
                      'filename'                   => '',
                      'original_filename'          => '',
                      'remote_id'                  => '',
                      'hash'                       => '',
                      'status'                     => '',
                      'url'                        => '',
                      'data_text1'                 => '',
                      'data_text2'                 => '',
                      'plugin_options'             => '',
                      'mime_type'                  => '',
                      'plugin_type'                => $pluginType,
                      'plugin'                     => $plugin
                    );

        return new CjwMediaconnectorData( $row );
    }

    /**
     * Fetch
     *
     * @param string $id
     * @param string $version
     * @param boolean $asObject
     * @return array
     */
    static function fetch( $id, $version, $asObject = true )
    {
        if ( $version == null )
        {
            return eZPersistentObject::fetchObjectList( CjwMediaconnectorData::definition(),
                                                        null,
                                                        array( 'contentobject_attribute_id' => $id ),
                                                        null,
                                                        null,
                                                        $asObject );
        }
        else
        {
            return eZPersistentObject::fetchObject( CjwMediaconnectorData::definition(),
                                                    null,
                                                    array( 'contentobject_attribute_id' => $id,
                                                           'version'                    => $version ),
                                                    $asObject );
        }
    }

    /**
     * Fetch by file name
     *
     * @param string $filename
     * @param string $version
     * @param boolean $asObject
     * @return array
     */
    static function fetchByFileName( $filename, $version = null, $asObject = true )
    {
        if ( $version == null )
        {
            return eZPersistentObject::fetchObjectList( CjwMediaconnectorData::definition(),
                                                        null,
                                                        array( 'filename' => $filename ),
                                                        null,
                                                        null,
                                                        $asObject );
        }
        else
        {
            return eZPersistentObject::fetchObject( CjwMediaconnectorData::definition(),
                                                    null,
                                                    array( 'filename' => $filename,
                                                           'version'  => $version ),
                                                    $asObject );
        }
    }

    /**
     * Fetch by remoteId
     *
     * @param string $remoteId
     * @param boolean $asObject
     * @return array
     */
    static function fetchByRemoteId( $remoteId, $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( CjwMediaconnectorData::definition(),
                                                    null,
                                                    array( 'remote_id' => $remoteId ),
                                                    null,
                                                    null,
                                                    $asObject );
    }

    /**
     * Fetch media objects by content object id
     *
     * @param integer $contentObjectID contentobject id
     * @param string $languageCode language code
     * @param boolean $asObject if return object
     * @return array
     */
    static function fetchByContentObjectID( $contentObjectID, $languageCode = null, $asObject = true )
    {
        $condition = array();

        $condition[ 'contentobject_id' ] = $contentObjectID;
        $condition[ 'data_type_string' ] = 'cjwmediaconnector';

        if ( $languageCode != null )
        {
            $condition[ 'language_code' ] = $languageCode;
        }

        $custom = array( array( 'operation' => 'DISTINCT id',
                                'name'      => 'id' ) );

        $ids = eZPersistentObject::fetchObjectList( eZContentObjectAttribute::definition(),
                                                    array(),
                                                    $condition,
                                                    null,
                                                    null,
                                                    false,
                                                    false,
                                                    $custom );

        $mediaFiles = array();

        foreach ( $ids as $id )
        {
            $mediaFileObjectAttribute = CjwMediaconnectorData::fetch( $id[ 'id' ], null, $asObject );
            $mediaFiles               = array_merge( $mediaFiles, $mediaFileObjectAttribute );
        }

        return $mediaFiles;
    }

    /**
     * Remove by Id
     *
     * @param integer $id
     * @param string $version
     * @return void
     */
    static function removeByID( $id, $version )
    {
        if ( $version == null )
        {
            eZPersistentObject::removeObject( CjwMediaconnectorData::definition(),
                                              array( 'contentobject_attribute_id' => $id ) );
        }
        else
        {
            eZPersistentObject::removeObject( CjwMediaconnectorData::definition(),
                                              array( 'contentobject_attribute_id' => $id,
                                                     'version'                    => $version ) );
        }
    }

    /**
     * Get file info
     *
     * @return array
     */
    function storedFileInfo()
    {
        $fileName         = $this->attribute( 'filename' );
        $mimeType         = $this->attribute( 'mime_type' );
        $originalFileName = $this->attribute( 'original_filename' );
        $url              = $this->attribute( 'url' );
        $storageDir       = eZSys::storageDirectory();
        $group            = '';
        $type             = '';

        if ( $mimeType )
        {
            list( $group, $type ) = explode( '/', $mimeType );
        }

        $filePath = $storageDir . '/original/' . $group . '/' . $fileName;

        return array( 'filename'          => $fileName,
                      'original_filename' => $originalFileName,
                      'filepath'          => $filePath,
                      'url'               => $url,
                      'mime_type'         => $mimeType );
    }
}

?>