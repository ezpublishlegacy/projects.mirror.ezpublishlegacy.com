<?php /* #?ini charset="utf-8"? */
/**
 * File containing the template ini
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @subpackage ini
 * @filesource
 */

/*

[PHP]
# used in content/datatype/edit template
PHPOperatorList[unserialize]=unserialize

*/ ?>