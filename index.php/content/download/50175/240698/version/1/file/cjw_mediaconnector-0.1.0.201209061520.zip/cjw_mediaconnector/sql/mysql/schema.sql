
CREATE TABLE IF NOT EXISTS `cjwmediaconnector` (
  `contentobject_attribute_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(50) NOT NULL DEFAULT '',
  `original_filename` varchar(255) NOT NULL DEFAULT '',
  `remote_id` varchar(255) NOT NULL,
  `hash` char(32) NOT NULL,
  `status` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `data_text1` longtext NOT NULL,
  `data_text2` longtext NOT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `plugin_type` varchar(128) NOT NULL,
  `plugin_options` longtext NOT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contentobject_attribute_id`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
