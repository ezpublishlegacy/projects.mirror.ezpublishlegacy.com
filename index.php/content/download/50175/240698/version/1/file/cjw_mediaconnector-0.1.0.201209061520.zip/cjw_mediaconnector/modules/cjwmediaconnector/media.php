<?php
/**
 * File media.php
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @subpackage modules
 * @filesource
 */

$module     = $Params['Module'];
$parameters = array();

if( isset( $Params[ 'Parameters' ] ) )
{
    $parameters = $Params[ 'Parameters' ];
}

// ToDo: Describe parameter array keys

switch ( $parameters[ 0 ] )
{
    case 'download':
        if ( $parameters[ 1 ] && $parameters[ 2 ] )
        {
            // ToDo: if can read
            $pluginType      = CjwMediaconnectorPlugins::getPluginType( $parameters[ 1 ] );
            $pluginClassName = 'CjwMediaconnector' . $pluginType;

            if ( class_exists( $pluginClassName ) )
            {
                $ytObject = new $pluginClassName( $parameters[ 1 ] );
                $ytObject->download( $parameters[ 2 ] );
            }
        }
    break;
}

?>