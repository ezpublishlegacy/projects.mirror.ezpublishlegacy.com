<?php
/**
 * File containing the CjwMediaconnectorType class
 *
 * @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_mediaconnector
 * @filesource
 */
/**
 * class handles storage and playback of mediaconnector files
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class CjwMediaconnectorType extends eZDataType
{
    /**
     *
     * @var string
     */
    const DATA_TYPE_STRING = "cjwmediaconnector";

    /**
    *
    * @var string
    */
    const MAX_FILESIZE_FIELD = 'data_int1';

    /**
    *
    * @var string
    */
    const MAX_FILESIZE_VARIABLE = '_cjwmediaconnector_max_filesize_';

    /**
    *
    * @var string
    */
    const TYPE_FIELD = 'data_text1';

    /**
    *
    * @var string
    */
    const PLUGIN_TYPE_FIELD = 'data_text2';

    /**
    *
    * @var string
    */
    const PLUGIN_OPTIONS_FIELD = 'data_text5';

    /**
    *
    * @var string
    */
    const TYPE_VARIABLE = '_cjwmediaconnector_type_';

    /**
     * Constructor
     *
     * @return void
     */
    function CjwMediaconnectorType()
    {
        $this->eZDataType( self::DATA_TYPE_STRING, ezpI18n::tr( 'kernel/classes/datatypes', "CJW Mediaconnector Media", 'Datatype name' ),
                           array( 'serialize_supported' => false ) );
    }

    /**
     * Sets value according to current version
     *
     * @see eZDataType::postInitializeObjectAttribute()
     */
    function postInitializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != FALSE )
        {
            $contentObjectAttributeID = $originalContentObjectAttribute->attribute( 'id' );

            $version = $contentObjectAttribute->attribute( 'version' );
            $oldfile = CjwMediaconnectorData::fetch( $contentObjectAttributeID, $currentVersion );

            if ( $oldfile != null )
            {
                $oldfile->setAttribute( 'contentobject_attribute_id', $contentObjectAttribute->attribute( 'id' ) );
                $oldfile->setAttribute( 'version',  $version );
                $oldfile->store();
            }
        }
        else
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

            $version = $contentObjectAttribute->attribute( 'version' );

            $contentClassAttribute = $contentObjectAttribute->contentClassAttribute();

            $plugin     = $contentClassAttribute->attribute( self::TYPE_FIELD );
            $pluginType = $contentClassAttribute->attribute( self::PLUGIN_TYPE_FIELD );

            $media = CjwMediaconnectorData::create( $contentObjectAttributeID, $version, $plugin, $pluginType );

            $media->setAttribute( 'plugin', $plugin );
            $media->setAttribute( 'plugin_type', $pluginType );
            $media->store();
        }
    }

    /**
     * The object is being moved to trash, do any necessary changes to the attribute.
     * Rename file and update db row with new name, so that access to the file using old links no longer works.
     *
     * @see eZDataType::trashStoredObjectAttribute()
     */
    function trashStoredObjectAttribute( $contentObjectAttribute, $version = null )
    {
        $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

        $sys         = eZSys::instance();
        $storage_dir = $sys->storageDirectory();

        if ( $version == null )
        {
            $mediaFiles = CjwMediaconnectorData::fetch( $contentObjectAttributeID, null );
        }
        else
        {
            $mediaFiles = array( CjwMediaconnectorData::fetch( $contentObjectAttributeID, $version ) );
        }

        foreach ( $mediaFiles as $mediaFile )
        {
            if ( $mediaFile == null )
            {
                continue;
            }

            $mimeType                = $mediaFile->attribute( 'mime_type' );
            list( $prefix, $suffix ) = explode( '/', $mimeType );
            $orig_dir                = $storage_dir . '/original/' . $prefix;
            $fileName                = $mediaFile->attribute( 'filename' );

            // Check if there are any other records in cjwmediaconnector that point to that fileName.
            $mediaObjectsWithSameFileName = CjwMediaconnectorData::fetchByFileName( $fileName );

            $filePath = $orig_dir . '/' . $fileName;
            $file     = eZClusterFileHandler::instance( $filePath );

            if ( $file->exists() and count( $mediaObjectsWithSameFileName ) <= 1 )
            {
                // create dest filename in the same manner as eZHTTPFile::store()
                // grab file's suffix
                $fileSuffix = eZFile::suffix( $fileName );

                // prepend dot
                if ( $fileSuffix )
                {
                    $fileSuffix = '.' . $fileSuffix;
                }

                // grab filename without suffix
                $fileBaseName = basename( $fileName, $fileSuffix );

                // create dest filename
                $newFileName = md5( $fileBaseName . microtime() . mt_rand() ) . $fileSuffix;
                $newFilePath = $orig_dir . '/' . $newFileName;

                // rename the file, and update the database data
                $file->move( $newFilePath );

                $mediaFile->setAttribute( 'filename', $newFileName );
                $mediaFile->store();
            }
        }
    }

    /**
     * Delete stored attribute
     *
     * @see eZDataType::deleteStoredObjectAttribute()
     */
    function deleteStoredObjectAttribute( $contentObjectAttribute, $version = null )
    {
        $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

        $sys          = eZSys::instance();
        $storage_dir = $sys->storageDirectory();

        if ( $version == null )
        {
            $mediaFiles    = CjwMediaconnectorData::fetch( $contentObjectAttributeID, null );
            $remoteIdArray = array();

            foreach ( $mediaFiles as $mediaFile )
            {
                $mimeType                = $mediaFile->attribute( 'mime_type' );
                list( $prefix, $suffix ) = explode( '/', $mimeType );
                $orig_dir                = $storage_dir . '/original/' . $prefix;
                $fileName                = $mediaFile->attribute( 'filename' );

                if ( $fileName != '' )
                {
                    $file = eZClusterFileHandler::instance( $orig_dir . '/' . $fileName );

                    if ( $file->exists() )
                    {
                        $file->delete();
                    }
                }

                // hook: remove remote files
                if ( $mediaFile->attribute( 'remote_id' ) != '' )
                {
                    $plugin          = $mediaFile->attribute( 'plugin' );
                    $pluginType      = $mediaFile->attribute( 'plugin_type' );
                    $pluginClassName = 'CjwMediaconnector' . $pluginType;

                    if ( class_exists( $pluginClassName ) )
                    {
                        eZDebug::writeDebug( "cjw_mediaconnector: call $pluginClassName::delete", __METHOD__ );
                        $cjwMediaObject = new $pluginClassName( $plugin );
                        $cjwMediaObject->delete( $mediaFile->attribute( 'remote_id' ) );
                    }
                    else
                    {
                        eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
                    }
                }
            }
        }
        else
        {
            $mediaFiles = CjwMediaconnectorData::fetchByContentObjectID( $contentObjectAttribute->attribute( 'contentobject_id' ) );

            $count             = 0;
            $currentBinaryFile = CjwMediaconnectorData::fetch( $contentObjectAttributeID, $version );

            if ( $currentBinaryFile != null )
            {
                $mimeType                =  $currentBinaryFile->attribute( 'mime_type' );
                $currentFileName         = $currentBinaryFile->attribute( 'filename' );
                list( $prefix, $suffix ) = is_string( $mimeType ) && $mimeType ? explode( '/', $mimeType ) : array( null, null );
                $orig_dir                = $storage_dir . '/original/' . $prefix;

                foreach ( $mediaFiles as $mediaFile )
                {
                    $fileName = $mediaFile->attribute( 'filename' );

                    if( $currentFileName == $fileName )
                    {
                        $count += 1;
                    }
                }

                if ( $count == 1 && $currentFileName != '' )
                {
                    $file = eZClusterFileHandler::instance( $orig_dir . '/' . $currentFileName );

                    if ( $file->exists() )
                    {
                        $file->delete();
                    }
                }

                // hook: remove remote files
                $plugin          = $currentBinaryFile->attribute( 'plugin' );
                $pluginType      = $currentBinaryFile->attribute( 'plugin_type' );
                $pluginClassName = 'CjwMediaconnector' . $pluginType;

                if ( class_exists( $pluginClassName ) )
                {
                    eZDebug::writeDebug( "cjw_mediaconnector: call $pluginClassName::delete", __METHOD__ );
                    $cjwMediaObject = new $pluginClassName( $plugin );
                    $cjwMediaObject->delete( $currentBinaryFile->attribute( 'remote_id' ) );
                }
                else
                {
                    eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
                }
            }
        }

        CjwMediaconnectorData::removeByID( $contentObjectAttributeID, $version );
    }

    /**
     * Validates the input and returns true if the input was
     * valid for this datatype.
     *
     * @see eZDataType::validateObjectAttributeHTTPInput()
     */
    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
        $httpFileName   = $base . '_data_mediafilename_' . $contentObjectAttribute->attribute( 'id' );
        $maxSize        = 1024 * 1024 * $classAttribute->attribute( self::MAX_FILESIZE_FIELD );
        $mustUpload     = false;

        if ( $contentObjectAttribute->validateIsRequired() )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

            $version = $contentObjectAttribute->attribute( "version" );
            $media   = CjwMediaconnectorData::fetch( $contentObjectAttributeID, $version );

            if ( $media === null || $media->attribute( 'filename' ) == FALSE )
            {
                $mustUpload = true;
            }
        }

        $canFetchResult = eZHTTPFile::canFetch( $httpFileName, $maxSize );

        if ( $mustUpload && $canFetchResult == eZHTTPFile::UPLOADEDFILE_DOES_NOT_EXIST )
        {
            $contentObjectAttribute->setValidationError( ezpI18n::tr( 'kernel/classes/datatypes',
                                                        'A valid media file is required.' ) );

            return eZInputValidator::STATE_INVALID;
        }

        if ( $canFetchResult == eZHTTPFile::UPLOADEDFILE_EXCEEDS_PHP_LIMIT )
        {
            $contentObjectAttribute->setValidationError( ezpI18n::tr( 'kernel/classes/datatypes',
                                                        'The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.') );

            return eZInputValidator::STATE_INVALID;
        }

        if ( $canFetchResult == eZHTTPFile::UPLOADEDFILE_EXCEEDS_MAX_SIZE )
        {
            $contentObjectAttribute->setValidationError( ezpI18n::tr( 'kernel/classes/datatypes',
                                                        'The size of the uploaded file exceeds site maximum: %1 bytes.' ), $maxSize );

            return eZInputValidator::STATE_INVALID;
        }

        return eZInputValidator::STATE_ACCEPTED;
    }

    /**
     * Checks if file uploads are enabled, if not it gives a warning.
     *
     * @return void
     */
    function checkFileUploads()
    {
        $isFileUploadsEnabled = ini_get( 'file_uploads' ) != 0;

        if ( $isFileUploadsEnabled == FALSE )
        {
            if ( empty( $GLOBALS[ 'CjwMediaconnectorTypeWarningAdded' ] ) )
            {
                eZAppendWarningItem( array( 'error' => array( 'type' => 'kernel',
                                                              'number' => eZError::KERNEL_NOT_AVAILABLE ),
                                            'text' => ezpI18n::tr( 'kernel/classes/datatypes',
                                                                   'File uploading is not enabled. Please contact the site administrator to enable it.' ) ) );
                $GLOBALS[ 'CjwMediaconnectorTypeWarningAdded' ] = true;
            }
        }
    }

    /**
     * Fetches input and stores it in the data instance.
     *
     * @see eZDataType::fetchObjectAttributeHTTPInput()
     */
    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        CjwMediaconnectorType::checkFileUploads();

        $classAttribute = $contentObjectAttribute->contentClassAttribute();

        $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

        $version = $contentObjectAttribute->attribute( 'version' );
        $media   = CjwMediaconnectorData::fetch( $contentObjectAttributeID, $version );

        if ( $media == null )
        {
            $contentClassAttribute = $contentObjectAttribute->contentClassAttribute();
            $plugin                = $contentClassAttribute->attribute( 'data_text1' );
            $pluginType            = $contentClassAttribute->attribute( 'data_text2' );
            $media                 = CjwMediaconnectorData::create( $contentObjectAttributeID, $version, $plugin, $pluginType );
        }

        $media->setAttribute( 'contentobject_attribute_id', $contentObjectAttributeID );
        $media->setAttribute( 'version', $version );

        // store serialized plugin options
        if ( $http->hasPostVariable( $base . '_data_media_options_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $pluginOptionsArray      = $http->postVariable( $base . '_data_media_options_' . $contentObjectAttribute->attribute( 'id' ) );
            $pluginOptionsSerialized = serialize( $pluginOptionsArray );

            $media->setAttribute( 'plugin_options', $pluginOptionsSerialized );

            // store persistent for usage in datatype edit template
            $classAttribute->setAttribute( self::PLUGIN_OPTIONS_FIELD, $pluginOptionsSerialized );
            $classAttribute->store();
        }

        $mediaFilePostVarName = $base . '_data_mediafilename_' . $contentObjectAttribute->attribute( 'id' );

        if ( eZHTTPFile::canFetch( $mediaFilePostVarName ) )
        {
            $mediaFile = eZHTTPFile::fetch( $mediaFilePostVarName );
        }
        else
        {
            $mediaFile = null;
        }

        if ( $mediaFile instanceof eZHTTPFile )
        {
            $mimeData = eZMimeType::findByFileContents( $mediaFile->attribute( 'original_filename' ) );
            $mime     = $mimeData[ 'name' ];

            if ( $mime == '' )
            {
                $mime = $mediaFile->attribute( 'mime_type' );
            }

            $extension = eZFile::suffix( $mediaFile->attribute( 'original_filename' ) );

            $mediaFile->setMimeType( $mime );

            if ( $mediaFile->store( 'original', $extension ) == FALSE )
            {
                eZDebug::writeError( 'Failed to store http-file: ' . $mediaFile->attribute( 'original_filename' ),
                                     'CjwMediaconnectorType' );

                return false;
            }

            $orig_dir = $mediaFile->storageDir( 'original' );

            $media->setAttribute( 'filename', basename( $mediaFile->attribute( 'filename' ) ) );
            $media->setAttribute( 'original_filename', $mediaFile->attribute( 'original_filename' ) );
            $media->setAttribute( 'mime_type', $mime );

            $filePath = $mediaFile->attribute( 'filename' );

            $fileHandler = eZClusterFileHandler::instance();
            $fileHandler->fileStore( $filePath, 'media', true, $mime );

            $hasHttpFile = true;
        }
        else
        {
            $hasHttpFile = false;
        }

        // hook: remote file store / update
        // muss auch mit leerem http file ausgeführt werden, damit bei bestimmten diensten (yt) die metadaten geupdatet werden
        $pluginType      = $media->attribute( 'plugin_type' );
        $pluginClassName = 'CjwMediaconnector' . $pluginType;

        if ( class_exists( $pluginClassName ) )
        {
            eZDebug::writeDebug( 'cjw_mediaconnector: call '.$pluginClassName.'->store', __METHOD__ );
            $cjwMediaObject = new $pluginClassName( $media->attribute( 'plugin' ) );
            $cjwMediaObject->store( $media, $hasHttpFile, $contentObjectAttribute->ContentObjectID );
        }
        else
        {
            eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
        }
        //

        $media->store();

        $contentObjectAttribute->setContent( $media );

        return true;
    }

    /**
     * @see eZDataType::storeObjectAttribute()
     */
    function storeObjectAttribute( $contentObjectAttribute ) {}

    /**
     * @see eZDataType::customObjectAttributeHTTPAction()
     */
    function customObjectAttributeHTTPAction( $http, $action, $contentObjectAttribute, $parameters )
    {
        if ( $action == 'delete_media' )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );

            $version = $contentObjectAttribute->attribute( 'version' );

            $this->deleteStoredObjectAttribute( $contentObjectAttribute, $version );

            $contentClassAttribute = $contentObjectAttribute->contentClassAttribute();
            $plugin                = $contentClassAttribute->attribute( 'data_text1' );
            $pluginType            = $contentClassAttribute->attribute( 'data_text2' );
            $media                 = CjwMediaconnectorData::create( $contentObjectAttributeID, $version, $plugin, $pluginType );

            $contentObjectAttribute->setContent( $media );
        }
    }

    /**
     * HTTP file insertion is supported.
     *
     * @see eZDataType::isHTTPFileInsertionSupported()
     */
    function isHTTPFileInsertionSupported()
    {
        return true;
    }

    /**
     * Regular file insertion is supported.
     *
     * @see eZDataType::isRegularFileInsertionSupported()
     */
    function isRegularFileInsertionSupported()
    {
        return true;
    }

    /**
     * Inserts the file using the CjwMediaconnectorData class.
     *
     * @see eZDataType::insertHTTPFile()
     */
    function insertHTTPFile( $object, $objectVersion, $objectLanguage,
                             $objectAttribute, $httpFile, $mimeData,
                             &$result )
    {
        $result = array( 'errors'          => array(),
                         'require_storage' => false );

        $attributeID = $objectAttribute->attribute( 'id' );

        $contentClassAttribute = $objectAttribute->contentClassAttribute();
        $plugin                = $contentClassAttribute->attribute( 'data_text1' );
        $pluginType            = $contentClassAttribute->attribute( 'data_text2' );
        $media                 = CjwMediaconnectorData::fetch( $attributeID, $objectVersion );

        if ( $media === null )
        {
            $media = CjwMediaconnectorData::create( $attributeID, $objectVersion, $plugin, $pluginType );
        }

        $httpFile->setMimeType( $mimeData[ 'name' ] );

        if ( $httpFile->store( 'original', false, false ) == FALSE )
        {
            $result[ 'errors' ][] = array( 'description' => ezpI18n::tr( 'kernel/classes/datatypes/cjwmediaconnector',
                                                                         'Failed to store media file %filename. Please contact the site administrator.', null,
                                                                        array( '%filename' => $httpFile->attribute( "original_filename" ) ) ) );


            $hasHttpFile = false;

            return false;
        }
        else
        {
            $hasHttpFile = true;
        }

        $classAttribute = $objectAttribute->contentClassAttribute();

        $media->setAttribute( 'contentobject_attribute_id', $attributeID );
        $media->setAttribute( 'version', $objectVersion );
        $media->setAttribute( 'filename', basename( $httpFile->attribute( 'filename' ) ) );
        $media->setAttribute( 'original_filename', $httpFile->attribute( 'original_filename' ) );
        $media->setAttribute( 'mime_type', $mimeData[ 'name' ] );
        $media->setAttribute( 'plugin', $plugin );
        $media->setAttribute( 'plugin_type', $pluginType );

        $filePath    = $httpFile->attribute( 'filename' );
        $fileHandler = eZClusterFileHandler::instance();

        $fileHandler->fileStore( $filePath, 'mediafile', true, $mimeData[ 'name' ] );

        // hook: remote file store / update
        $pluginClassName = 'CjwMediaconnector' . $pluginType;

        if ( class_exists( $pluginClassName ) )
        {
            eZDebug::writeDebug( 'cjw_mediaconnector: call '.$pluginClassName.'->store', __METHOD__ );
            $cjwMediaObject = new $pluginClassName( $plugin );
            $cjwMediaObject->store( $media, $hasHttpFile, $objectAttribute->ContentObjectID );
        }
        else
        {
            eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
        }
        //

        $media->store();

        $objectAttribute->setContent( $media );

        return true;
    }

    /**
     * Inserts the file using the CjwMediaconnectorData class.
     *
     * @see eZDataType::insertRegularFile()
     */
    function insertRegularFile( $object, $objectVersion, $objectLanguage,
                                $objectAttribute, $filePath,
                                &$result )
    {
        $result = array( 'errors'          => array(),
                         'require_storage' => false );

        $attributeID = $objectAttribute->attribute( 'id' );

        $contentClassAttribute = $objectAttribute->contentClassAttribute();
        $plugin                = $contentClassAttribute->attribute( 'data_text1' );
        $pluginType            = $contentClassAttribute->attribute( 'data_text2' );
        $media                 = CjwMediaconnectorData::fetch( $attributeID, $objectVersion );

        if ( $media === null )
        {
            $media = CjwMediaconnectorData::create( $attributeID, $objectVersion, $plugin, $pluginType );
        }

        $fileName             = basename( $filePath );
        $mimeData             = eZMimeType::findByFileContents( $filePath );
        $storageDir           = eZSys::storageDirectory();
        list( $group, $type ) = explode( '/', $mimeData[ 'name' ] );
        $destination          = $storageDir . '/original/' . $group;

        if ( file_exists( $destination ) === FALSE )
        {
            if ( eZDir::mkdir( $destination, false, true ) == FALSE )
            {
                return false;
            }

            $hasFile = false;
        }
        else
        {
            $hasFile = true;
        }

        // create dest filename in the same manner as eZHTTPFile::store()
        // grab file's suffix
        $fileSuffix = eZFile::suffix( $fileName );

        // prepend dot
        if( $fileSuffix )
        {
            $fileSuffix = '.' . $fileSuffix;
        }

        // grab filename without suffix
        $fileBaseName = basename( $fileName, $fileSuffix );

        // create dest filename
        $destFileName = md5( $fileBaseName . microtime() . mt_rand() ) . $fileSuffix;
        $destination  = $destination . '/' . $destFileName;

        copy( $filePath, $destination );

        $fileHandler = eZClusterFileHandler::instance();
        $fileHandler->fileStore( $destination, 'mediafile', true, $mimeData[ 'name' ] );

        $classAttribute = $objectAttribute->contentClassAttribute();

        $media->setAttribute( 'contentobject_attribute_id', $attributeID );
        $media->setAttribute( 'version', $objectVersion );
        $media->setAttribute( 'filename', $destFileName );
        $media->setAttribute( 'original_filename', $fileName );
        $media->setAttribute( 'mime_type', $mimeData[ 'name' ] );
        $media->setAttribute( 'plugin', $plugin );
        $media->setAttribute( 'plugin_type', $pluginType );

        // hook: remote file store / update
        $pluginClassName = 'CjwMediaconnector'.$pluginType;

        if ( class_exists( $pluginClassName ) )
        {
            eZDebug::writeDebug( 'cjw_mediaconnector: call '.$pluginClassName.'->store', __METHOD__ );
            $cjwMediaObject = new $pluginClassName( $plugin );
            $cjwMediaObject->store( $media, $hasFile, $objectAttribute->ContentObjectID );
        }
        else
        {
            eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
        }
        //

        $media->store();

        $objectAttribute->setContent( $media );

        return true;
    }

    /**
     * We support file information
     *
     * @see eZDataType::hasStoredFileInformation()
     */
    function hasStoredFileInformation( $object, $objectVersion, $objectLanguage,
                                       $objectAttribute )
    {
        return true;
    }

    /**
     * Extracts file information for the media entry.
     *
     * @see eZDataType::storedFileInformation()
     */
    function storedFileInformation( $object, $objectVersion, $objectLanguage,
                                    $objectAttribute )
    {
        $mediaFile = CjwMediaconnectorData::fetch( $objectAttribute->attribute( 'id' ),
                                      $objectAttribute->attribute( 'version' ) );

        if ( $mediaFile )
        {
            return $mediaFile->storedFileInfo();
        }

        return false;
    }

    /**
     * @see eZDataType::storeClassAttribute()
     */
    function storeClassAttribute( $attribute, $version )
    {
    }

    /**
     * @see eZDataType::storeDefinedClassAttribute()
     */
    function storeDefinedClassAttribute( $attribute )
    {
    }

    /**
     * @see eZDataType::validateClassAttributeHTTPInput()
     */
    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        return eZInputValidator::STATE_ACCEPTED;
    }

    /**
     * @see eZDataType::fixupClassAttributeHTTPInput()
     */
    function fixupClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
    }

    /**
     * @see eZDataType::fetchClassAttributeHTTPInput()
     */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $filesizeName = $base . self::MAX_FILESIZE_VARIABLE . $classAttribute->attribute( 'id' );
        $typeName     = $base . self::TYPE_VARIABLE . $classAttribute->attribute( 'id' );

        if ( $http->hasPostVariable( $filesizeName ) != FALSE )
        {
            $filesizeValue = $http->postVariable( $filesizeName );
            $classAttribute->setAttribute( self::MAX_FILESIZE_FIELD, $filesizeValue );
        }

        if ( $http->hasPostVariable( $typeName ) != FALSE )
        {
            $typeValue = $http->postVariable( $typeName );
            $classAttribute->setAttribute( self::TYPE_FIELD, $typeValue );

            $pluginTypeValue = CjwMediaconnectorPlugins::getPluginType( $typeValue );
            $classAttribute->setAttribute( self::PLUGIN_TYPE_FIELD, $pluginTypeValue );
        }
    }

    /**
     * Returns the object title.
     *
     * @see eZDataType::title()
     */
    function title( $contentObjectAttribute, $name = 'original_filename' )
    {
        $mediaFile = CjwMediaconnectorData::fetch( $contentObjectAttribute->attribute( 'id' ),
                                                   $contentObjectAttribute->attribute( 'version' ) );

        if ( $mediaFile != null )
        {
            $value = $mediaFile->attribute( $name );
        }
        else
        {
            $value = '';
        }

        return $value;
    }

    /**
     * @see eZDataType::hasObjectAttributeContent()
     */
    function hasObjectAttributeContent( $contentObjectAttribute )
    {
        $mediaFile = CjwMediaconnectorData::fetch( $contentObjectAttribute->attribute( 'id' ),
                                                   $contentObjectAttribute->attribute( 'version' ) );

        if ( $mediaFile == FALSE || $mediaFile->attribute( 'filename' ) == '' )
        {
            return false;
        }

        return true;
    }

    /**
     * @see eZDataType::objectAttributeContent()
     */
    function objectAttributeContent( $contentObjectAttribute )
    {
        $mediaFile = CjwMediaconnectorData::fetch( $contentObjectAttribute->attribute( 'id' ),
                                                   $contentObjectAttribute->attribute( 'version' ) );

        if ( $mediaFile == FALSE )
        {
            $retValue = false;

            return $retValue;
        }

        return $mediaFile;
    }

    /**
     * @see eZDataType::metaData()
     */
    function metaData( $contentObjectAttribute )
    {
        return '';
    }

    /**
     * Return string representation of an contentobjectattribute data for simplified export.
     *
     * @see eZDataType::toString()
     */
    function toString( $objectAttribute )
    {
        $mediaFile = $objectAttribute->content();

        if ( is_object( $mediaFile ) )
        {
            return implode( '|', array( $mediaFile->attribute( 'filepath' ), $mediaFile->attribute( 'original_filename' ) ) );
        }
        else
        {
            return '';
        }
    }

    /**
     * @see eZDataType::fromString()
     */
    function fromString( $objectAttribute, $string )
    {
        if ( $string == FALSE )
        {
            return true;
        }

        $result = array();

        return $this->insertRegularFile( $objectAttribute->attribute( 'object' ),
                                         $objectAttribute->attribute( 'version' ),
                                         $objectAttribute->attribute( 'language_code' ),
                                         $objectAttribute,
                                         $string,
                                         $result );
    }

    /**
     * @see eZDataType::serializeContentClassAttribute()
     */
    function serializeContentClassAttribute( $classAttribute, $attributeNode, $attributeParametersNode )
    {
        $maxSize = $classAttribute->attribute( self::MAX_FILESIZE_FIELD );
        $type    = $classAttribute->attribute( self::TYPE_FIELD );
        $dom     = $attributeParametersNode->ownerDocument;

        $maxSizeNode = $dom->createElement( 'max-size' );

        $maxSizeNode->appendChild( $dom->createTextNode( $maxSize ) );
        $maxSizeNode->setAttribute( 'unit-size', 'mega' );
        $attributeParametersNode->appendChild( $maxSizeNode );

        $typeNode = $dom->createElement( 'type' );

        $typeNode->appendChild( $dom->createTextNode( $type ) );
        $attributeParametersNode->appendChild( $typeNode );
    }

    /**
     * @see eZDataType::unserializeContentClassAttribute()
     */
    function unserializeContentClassAttribute( $classAttribute, $attributeNode, $attributeParametersNode )
    {
        $sizeNode = $attributeParametersNode->getElementsByTagName( 'max-size' )->item( 0 );
        $maxSize  = $sizeNode->textContent;
        $unitSize = $sizeNode->getAttribute( 'unit-size' );
        $type     = $attributeParametersNode->getElementsByTagName( 'type' )->item( 0 )->textContent;

        $classAttribute->setAttribute( self::MAX_FILESIZE_FIELD, $maxSize );
        $classAttribute->setAttribute( self::TYPE_FIELD, $type );
    }

    /**
     * @see eZDataType::serializeContentObjectAttribute()
     */
    function serializeContentObjectAttribute( $package, $objectAttribute )
    {
        $node = $this->createContentObjectAttributeDOMNode( $objectAttribute );

        $mediaFile = $objectAttribute->attribute( 'content' );

        if ( $mediaFile == FALSE )
        {
            // Media type content could not be found.
            return $node;
        }

        $fileKey = md5( mt_rand() );

        $fileInfo = $mediaFile->storedFileInfo();
        $package->appendSimpleFile( $fileKey, $fileInfo[ 'filepath' ] );

        $dom = $node->ownerDocument;

        $mediaNode = $dom->createElement( 'media-file' );
        $mediaNode->setAttribute( 'filesize', $mediaFile->attribute( 'filesize' ) );
        $mediaNode->setAttribute( 'filename', $mediaFile->attribute( 'filename' ) );
        $mediaNode->setAttribute( 'original-filename', $mediaFile->attribute( 'original_filename' ) );
        $mediaNode->setAttribute( 'mime-type', $mediaFile->attribute( 'mime_type' ) );
        $mediaNode->setAttribute( 'filekey', $fileKey );

        $mediaNode->setAttribute( 'plugin', $mediaFile->attribute( 'plugin' ) );
        $node->appendChild( $mediaNode );

        return $node;
    }

    /**
     * @see eZDataType::unserializeContentObjectAttribute()
     */
    function unserializeContentObjectAttribute( $package, $objectAttribute, $attributeNode )
    {
        $mediaNode = $attributeNode->getElementsByTagName( 'media-file' )->item( 0 );

        if ( $mediaNode == FALSE )
        {
            // No media type data found.
            return;
        }

        $contentClassAttribute = $objectAttribute->contentClassAttribute();
        $plugin                = $contentClassAttribute->attribute( 'data_text1' );
        $pluginType            = $contentClassAttribute->attribute( 'data_text2' );

        $mediaFile  = CjwMediaconnectorData::create( $objectAttribute->attribute( 'id' ), $objectAttribute->attribute( 'version' ), $plugin, $pluginType );
        $sourcePath = $package->simpleFilePath( $mediaNode->getAttribute( 'filekey' ) );

        $ini = eZINI::instance();

        $mimeType                                = $mediaNode->getAttribute( 'mime-type' );
        list( $mimeTypeCategory, $mimeTypeName ) = explode( '/', $mimeType );
        $destinationPath                         = eZSys::storageDirectory() . '/original/' . $mimeTypeCategory . '/';

        if ( file_exists( $destinationPath ) === FALSE )
        {
            if ( eZDir::mkdir( $destinationPath, false, true ) == FALSE )
            {
                return false;
            }

            $hasFile = false;
        }
        else
        {
            $hasFile = true;
        }

        $basename = basename( $mediaNode->getAttribute( 'filename' ) );

        while ( file_exists( $destinationPath . $basename ) )
        {
            $basename = substr( md5( mt_rand() ), 0, 8 ) . '.' . eZFile::suffix( $mediaNode->getAttribute( 'filename' ) );
        }

        eZFileHandler::copy( $sourcePath, $destinationPath . $basename );

        eZDebug::writeNotice( 'Copied: ' . $sourcePath . ' to: ' . $destinationPath . $basename,
                              'CjwMediaconnectorType::unserializeContentObjectAttribute()' );

        $mediaFile->setAttribute( 'contentobject_attribute_id', $objectAttribute->attribute( 'id' ) );
        $mediaFile->setAttribute( 'filename', $basename );
        $mediaFile->setAttribute( 'original_filename', $mediaNode->getAttribute( 'original-filename' ) );
        $mediaFile->setAttribute( 'mime_type', $mediaNode->getAttribute( 'mime-type' ) );
        $media->setAttribute( 'plugin', $plugin );
        $media->setAttribute( 'plugin_type', $pluginType );

        $fileHandler = eZClusterFileHandler::instance();
        $fileHandler->fileStore( $destinationPath . $basename, 'mediafile', true );

        // hook: remote file store / update
        $pluginClassName = 'CjwMediaconnector' . $pluginType;

        if ( class_exists( $pluginClassName ) )
        {
            eZDebug::writeDebug( 'cjw_mediaconnector: call ' . $pluginClassName . '->store', __METHOD__ );
            $cjwMediaObject = new $pluginClassName( $plugin );
            $cjwMediaObject->store( $media, $hasFile, $objectAttribute->ContentObjectID );
        }
        else
        {
            eZDebug::writeError( "Unable to find the PHP class '$pluginClassName' associated with the cjwmediaconnector plugin '$activePlugin', will be ignored", __METHOD__ );
        }
        //

        $mediaFile->store();
    }

    /**
     * @see eZDataType::supportsBatchInitializeObjectAttribute()
     */
    function supportsBatchInitializeObjectAttribute()
    {
        return true;
    }
}

eZDataType::register( CjwMediaconnectorType::DATA_TYPE_STRING, "CjwMediaconnectorType" );

?>
