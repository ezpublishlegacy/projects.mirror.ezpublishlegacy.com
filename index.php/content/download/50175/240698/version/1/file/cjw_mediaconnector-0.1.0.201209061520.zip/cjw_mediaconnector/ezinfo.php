<?php
/**
* File containing cjw_mediaconnectorInfo class
*
* @copyright Copyright (C) 2011-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
* @license http://ez.no/licenses/gnu_gpl GNU GPL v2
* @version //autogentag//
* @package cjw_mediaconnector
*/
/**
 * Class description here
 *
 * @version //autogentag//
 * @package cjw_mediaconnector
 */
class cjw_mediaconnectorInfo
{
    const SOFTWARE_VERSION = '0.1.0.201209061520';

    function info()
    {
        return array( 'Name'             => 'CJW Media Connector',
                      'Version'          => self::SOFTWARE_VERSION,
                      'eZ version'       => '4.x',
                      'Copyright'        => '(C) 2011-' . date( 'Y' ) . ' <a href="http://www.cjw-network.com">CJW Network</a> [ <a href="http://www.coolscreen.de">coolscreen.de - enterprise internet</a> &amp; <a href="http://www.jac-systeme.de">JAC Systeme</a> &amp; <a href="http://www.webmanufaktur.ch">Webmanufaktur</a> ]',
                      'License'          => 'GNU General Public License v2.0',
                      'More Information' => '<a href="http://www.cjw-network.com">http://www.cjw-network.com</a>'
                    );
    }
}

?>