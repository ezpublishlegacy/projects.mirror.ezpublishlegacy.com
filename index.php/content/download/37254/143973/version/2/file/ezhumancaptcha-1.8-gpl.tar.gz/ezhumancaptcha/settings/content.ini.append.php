<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezhumancaptcha
AvailableDataTypes[]=ezhumancaptcha

*/ ?>
