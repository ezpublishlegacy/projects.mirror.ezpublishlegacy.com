<!DOCTYPE TS><TS>
<context>
    <name>extension/ezhumancaptcha</name>
    <message>
        <source>Human CAPTCHA</source>
        <translation>Human CAPTCHA</translation>
    </message>
    <message>
        <source>The CAPTCHA code is empty</source>
        <translation>The CAPTCHA code is empty</translation>
    </message>    
    <message>
        <source>The CAPTCHA code is not valid</source>
        <translation>The CAPTCHA code is not valid</translation>
    </message>    
    <message>
        <source>The CAPTCHA code is not set</source>
        <translation>The CAPTCHA code is not set</translation>
    </message>
    <message>
        <source>The CAPTCHA attribute is missing</source>
        <translation>The CAPTCHA attribute is missing</translation>
    </message>   
    <message>
        <source>CAPTCHA validation successful</source>
        <translation>CAPTCHA validation successful</translation>
    </message> 
    <message>
        <source>CAPTCHA validation failed</source>
        <translation>CAPTCHA validation failed</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Send</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Back</translation>
    </message>
</context>
</TS>
