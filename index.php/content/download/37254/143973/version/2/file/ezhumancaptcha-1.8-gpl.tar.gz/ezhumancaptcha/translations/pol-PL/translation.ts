<!DOCTYPE TS><TS>
<context>
    <name>extension/ezhumancaptcha</name>
    <message>
        <source>Human CAPTCHA</source>
        <translation>Human CAPTCHA</translation>
    </message>
    <message>
        <source>The CAPTCHA code is empty</source>
        <translation>Kod zabezpieczający nie został uzupełniony</translation>
    </message>    
    <message>
        <source>The CAPTCHA code is not valid</source>
        <translation>Wprowadzony kod zabezpieczający jest nieprawidłowy</translation>
    </message>    
    <message>
        <source>The CAPTCHA code is not set</source>
        <translation>Kod zabezpieczający nie został zainicjowany</translation>
    </message>
    <message>
        <source>The CAPTCHA attribute is missing</source>
        <translation>Atrybut CAPTCHA nie został znaleziony</translation>
    </message>
    <message>
        <source>CAPTCHA validation successful</source>
        <translation>Walidacja kodu zabezpieczającego pomyślna</translation>
    </message>
    <message>
        <source>CAPTCHA validation failed</source>
        <translation>Walidacja kodu zabezpieczającego niepomyślna</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Powrót</translation>
    </message>
</context>
</TS>
