<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezhumancaptcha

[RegionalSettings]
TranslationExtensions[]=ezhumancaptcha

*/ ?>
