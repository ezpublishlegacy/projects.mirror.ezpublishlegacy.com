<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezhumancaptcha

*/ ?>
