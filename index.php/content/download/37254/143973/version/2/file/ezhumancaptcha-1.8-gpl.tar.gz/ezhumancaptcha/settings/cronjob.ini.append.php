<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezhumancaptcha

[CronjobPart-infrequent]
Scripts[]=ezhumancaptcha_cleanup.php

[CronjobPart-chown]
Scripts[]=chown.php

[CronjobPart-every15minutes]
Scripts[]=test.php

*/ ?>

