<!DOCTYPE TS><TS>
  <context>
    <name>contentstructuremenu/show_content_structure</name>
    <message>
      <source>Node ID: %node_id Visibility: %visibility</source>
      <translation>Node ID: %node_id Visibility: %visibility</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/classlist</name>
    <message>
      <source>%group_name [Class group]</source>
      <translation>%group_name [Class group]</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this class group.</source>
      <translation>Edit this class group.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove this class group.</source>
      <translation>Remove this class group.</translation>
    </message>
    <message>
      <source>Back to class groups.</source>
      <translation>Back to class groups.</translation>
    </message>
    <message>
      <source>Classes inside &lt;%group_name&gt; [%class_count]</source>
      <translation>Classes inside &lt;%group_name&gt; [%class_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Objects</source>
      <translation>Objects</translation>
    </message>
    <message>
      <source>Select class for removal.</source>
      <translation>Select class for removal.</translation>
    </message>
    <message>
      <source>Create a copy of the &lt;%class_name&gt; class.</source>
      <translation>Create a copy of the &lt;%class_name&gt; class.</translation>
    </message>
    <message>
      <source>Edit the &lt;%class_name&gt; class.</source>
      <translation>Edit the &lt;%class_name&gt; class.</translation>
    </message>
    <message>
      <source>There are no classes in this group.</source>
      <translation>There are no classes in this group.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected classes from the &lt;%class_group_name&gt; class group.</source>
      <translation>Remove selected classes from the &lt;%class_group_name&gt; class group.</translation>
    </message>
    <message>
      <source>New class</source>
      <translation>New class</translation>
    </message>
    <message>
      <source>Create a new class within the &lt;%class_group_name&gt; class group.</source>
      <translation>Create a new class within the &lt;%class_group_name&gt; class group.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/datatype/browse_objectrelation_placement</name>
    <message>
      <source>Choose node for default selection</source>
      <translation>Choose node for default selection</translation>
    </message>
    <message>
      <source>Select the item that you want to be the default selection and click &quot;OK&quot;.</source>
      <translation>Select the item that you want to be the default selection and click &quot;OK&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/datatype/browse_objectrelationlist_placement</name>
    <message>
      <source>Choose initial location</source>
      <translation>Choose initial location</translation>
    </message>
    <message>
      <source>Select the location that should be the default location and click &quot;OK&quot;.</source>
      <translation>Select the location that should be the default location and click &quot;OK&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/edit</name>
    <message>
      <source>The class definition could not be stored.</source>
      <translation>The class definition could not be stored.</translation>
    </message>
    <message>
      <source>The following information is either missing or invalid</source>
      <translation>The following information is either missing or invalid</translation>
    </message>
    <message>
      <source>The class definition was successfully stored.</source>
      <translation>The class definition was successfully stored.</translation>
    </message>
    <message>
      <source>The class definition contains the following errors</source>
      <translation>The class definition contains the following errors</translation>
    </message>
    <message>
      <source>Edit &lt;%class_name&gt; [Class]</source>
      <translation>Edit &lt;%class_name&gt; [Class]</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Use this field to set the informal name of the class. The name field can contain whitespaces and special characters.</source>
      <translation>Use this field to set the informal name of the class. The name field can contain whitespaces and special characters.</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Use this field to set the internal name of the class. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
      <translation>Use this field to set the internal name of the class. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</translation>
    </message>
    <message>
      <source>Object name pattern</source>
      <translation>Object name pattern</translation>
    </message>
    <message>
      <source>Use this field to configure how the name of the objects are generated (also applies to nice URLs). Type in the identifiers of the attributes that should be used. The identifiers must be enclosed in angle brackets. Text outside angle brackets will be included as is.</source>
      <translation>Use this field to configure how the name of the objects are generated (also applies to nice URLs). Type in the identifiers of the attributes that should be used. The identifiers must be enclosed in angle brackets. Text outside angle brackets will be included as is.</translation>
    </message>
    <message>
      <source>Container</source>
      <translation>Container</translation>
    </message>
    <message>
      <source>Use this checkbox to allow instances of the class to have sub items. If checked, it will be possible to create new sub-items. If not checked, the sub items will not be displayed.</source>
      <translation>Use this checkbox to allow instances of the class to have sub items. If checked, it will be possible to create new sub-items. If not checked, the sub items will not be displayed.</translation>
    </message>
    <message>
      <source>Use this checkbox to set the default availability for the objects of this class. The availablility controls wether an object should be shown even if it does not exist in one of the languages specified by the &quot;SiteLanguageList&quot; setting. If this is the case, the system will use the main language of the object.</source>
      <translation>Use this checkbox to set the default availability for the objects of this class. The availablility controls wether an object should be shown even if it does not exist in one of the languages specified by the &quot;SiteLanguageList&quot; setting. If this is the case, the system will use the main language of the object.</translation>
    </message>
    <message>
      <source>Select attribute for removal. Click the &quot;Remove selected attributes&quot; button to actually remove the selected attributes.</source>
      <translation>Select attribute for removal. Click the &quot;Remove selected attributes&quot; button to actually remove the selected attributes.</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Down</translation>
    </message>
    <message>
      <source>Use the order buttons to set the order of the class attributes. The up arrow moves the attribute one place up. The down arrow moves the attribute one place down.</source>
      <translation>Use the order buttons to set the order of the class attributes. The up arrow moves the attribute one place up. The down arrow moves the attribute one place down.</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Up</translation>
    </message>
    <message>
      <source>Use this field to set the informal name of the attribute. This field can contain whitespaces and special characters.</source>
      <translation>Use this field to set the informal name of the attribute. This field can contain whitespaces and special characters.</translation>
    </message>
    <message>
      <source>Use this field to set the internal name of the attribute. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
      <translation>Use this field to set the internal name of the attribute. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</translation>
    </message>
    <message>
      <source>Use this checkbox to control if the user should be forced to enter information into the attribute.</source>
      <translation>Use this checkbox to control if the user should be forced to enter information into the attribute.</translation>
    </message>
    <message>
      <source>Required</source>
      <translation>Required</translation>
    </message>
    <message>
      <source>Use this checkbox to control if the contents of the attribute should be indexed by the search engine.</source>
      <translation>Use this checkbox to control if the contents of the attribute should be indexed by the search engine.</translation>
    </message>
    <message>
      <source>The &lt;%datatype_name&gt; datatype does not support search indexing.</source>
      <translation>The &lt;%datatype_name&gt; datatype does not support search indexing.</translation>
    </message>
    <message>
      <source>Searchable</source>
      <translation>Searchable</translation>
    </message>
    <message>
      <source>Use this checkbox to control if the attribute should collect input from users.</source>
      <translation>Use this checkbox to control if the attribute should collect input from users.</translation>
    </message>
    <message>
      <source>The &lt;%datatype_name&gt; datatype can not be used as an information collector.</source>
      <translation>The &lt;%datatype_name&gt; datatype can not be used as an information collector.</translation>
    </message>
    <message>
      <source>Information collector</source>
      <translation>Information collector</translation>
    </message>
    <message>
      <source>Use this checkbox for attributes that contain non-translatable content.</source>
      <translation>Use this checkbox for attributes that contain non-translatable content.</translation>
    </message>
    <message>
      <source>Disable translation</source>
      <translation>Disable translation</translation>
    </message>
    <message>
      <source>This class does not have any attributes.</source>
      <translation>This class does not have any attributes.</translation>
    </message>
    <message>
      <source>Remove selected attributes</source>
      <translation>Remove selected attributes</translation>
    </message>
    <message>
      <source>Remove the selected attributes.</source>
      <translation>Remove the selected attributes.</translation>
    </message>
    <message>
      <source>Add attribute</source>
      <translation>Add attribute</translation>
    </message>
    <message>
      <source>Add a new attribute to the class. Use the menu on the left to select the attribute type.</source>
      <translation>Add a new attribute to the class. Use the menu on the left to select the attribute type.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Store changes and exit from edit mode.</source>
      <translation>Store changes and exit from edit mode.</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Apply</translation>
    </message>
    <message>
      <source>Store changes and continue editing.</source>
      <translation>Store changes and continue editing.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Discard all changes and exit from edit mode.</source>
      <translation>Discard all changes and exit from edit mode.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/edit_denied</name>
    <message>
      <source>Class edit conflict</source>
      <translation>Class edit conflict</translation>
    </message>
    <message>
      <source>This class is already being edited by someone else.</source>
      <translation>This class is already being edited by someone else.</translation>
    </message>
    <message>
      <source>The class is temporarly locked and thus it can not be edited by you.</source>
      <translation>The class is temporarly locked and thus it can not be edited by you.</translation>
    </message>
    <message>
      <source>Possible actions</source>
      <translation>Possible actions</translation>
    </message>
    <message>
      <source>Contact the person who is editing the class.</source>
      <translation>Contact the person who is editing the class.</translation>
    </message>
    <message>
      <source>Wait until the lock expires and try again.</source>
      <translation>Wait until the lock expires and try again.</translation>
    </message>
    <message>
      <source>Edit &lt;%class_name&gt; [Class]</source>
      <translation>Edit &lt;%class_name&gt; [Class]</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Current modifier</source>
      <translation>Current modifier</translation>
    </message>
    <message>
      <source>Unlock time</source>
      <translation>Unlock time</translation>
    </message>
    <message>
      <source>The class will be available for editing once it has been stored by the current modifier or when it is unlocked by the system.</source>
      <translation>The class will be available for editing once it has been stored by the current modifier or when it is unlocked by the system.</translation>
    </message>
    <message>
      <source>Retry</source>
      <translation>Retry</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/groupedit</name>
    <message>
      <source>Edit &lt;%group_name&gt; [Class group]</source>
      <translation>Edit &lt;%group_name&gt; [Class group]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/grouplist</name>
    <message>
      <source>Class groups [%group_count]</source>
      <translation>Class groups [%group_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Select class group for removal.</source>
      <translation>Select class group for removal.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%class_group_name&gt; class group.</source>
      <translation>Edit the &lt;%class_group_name&gt; class group.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove the selected class groups. This will also remove all classes that only exist within the selected groups.</source>
      <translation>Remove the selected class groups. This will also remove all classes that only exist within the selected groups.</translation>
    </message>
    <message>
      <source>New class group</source>
      <translation>New class group</translation>
    </message>
    <message>
      <source>Create a new class group.</source>
      <translation>Create a new class group.</translation>
    </message>
    <message>
      <source>Recently modified classes</source>
      <translation>Recently modified classes</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Edit the &lt;%class_name&gt; class.</source>
      <translation>Edit the &lt;%class_name&gt; class.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/removeclass</name>
    <message>
      <source>Confirm class removal</source>
      <translation>Confirm class removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the classes?</source>
      <translation>Are you sure you want to remove the classes?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove this class?</source>
      <translation>Are you sure you want to remove this class?</translation>
    </message>
    <message>
      <source>You do not have permissions to remove classes.</source>
      <translation>You do not have permissions to remove classes.</translation>
    </message>
    <message>
      <source>The %1 class was already removed from the group but still exists in other groups.</source>
      <translation>The %1 class was already removed from the group but still exists in other groups.</translation>
    </message>
    <message>
      <source>The %1 classes were already removed from the group but still exist in other groups.</source>
      <translation>The %1 classes were already removed from the group but still exist in other groups.</translation>
    </message>
    <message>
      <source>Removing class &lt;%1&gt; will result in the removal of %2 object and all it's sub-items.</source>
      <translation>Removing class &lt;%1&gt; will result in the removal of %2 object and all it's sub-items.</translation>
    </message>
    <message>
      <source>Removing class &lt;%1&gt; will result in the removal of %2 objects and all their sub-items.</source>
      <translation>Removing class &lt;%1&gt; will result in the removal of %2 objects and all their sub-items.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/removegroup</name>
    <message>
      <source>Confirm class group removal</source>
      <translation>Confirm class group removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the class group?</source>
      <translation>Are you sure you want to remove the class group?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the class groups?</source>
      <translation>Are you sure you want to remove the class groups?</translation>
    </message>
    <message>
      <source>The following classes will be removed from the &lt;%group_name&gt; class group</source>
      <translation>The following classes will be removed from the &lt;%group_name&gt; class group</translation>
    </message>
    <message>
      <source>%objects objects will be removed</source>
      <translation>%objects objects will be removed</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/class/view</name>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>%class_name [Class]</source>
      <translation>%class_name [Class]</translation>
    </message>
    <message>
      <source>Last modified: %time, %username</source>
      <translation>Last modified: %time, %username</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Object name pattern</source>
      <translation>Object name pattern</translation>
    </message>
    <message>
      <source>Container</source>
      <translation>Container</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Default object availability</source>
      <translation>Default object availability</translation>
    </message>
    <message>
      <source>Not available</source>
      <translation>Not available</translation>
    </message>
    <message>
      <source>Available</source>
      <translation>Available</translation>
    </message>
    <message>
      <source>Object count</source>
      <translation>Object count</translation>
    </message>
    <message>
      <source>Attributes</source>
      <translation>Attributes</translation>
    </message>
    <message>
      <source>Flags</source>
      <translation>Flags</translation>
    </message>
    <message>
      <source>Is required</source>
      <translation>Is required</translation>
    </message>
    <message>
      <source>Is not required</source>
      <translation>Is not required</translation>
    </message>
    <message>
      <source>Is searchable</source>
      <translation>Is searchable</translation>
    </message>
    <message>
      <source>Is not searchable</source>
      <translation>Is not searchable</translation>
    </message>
    <message>
      <source>Collects information</source>
      <translation>Collects information</translation>
    </message>
    <message>
      <source>Does not collect information</source>
      <translation>Does not collect information</translation>
    </message>
    <message>
      <source>Translation is disabled</source>
      <translation>Translation is disabled</translation>
    </message>
    <message>
      <source>Translation is enabled</source>
      <translation>Translation is enabled</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this class.</source>
      <translation>Edit this class.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Member of class groups [%group_count]</source>
      <translation>Member of class groups [%group_count]</translation>
    </message>
    <message>
      <source>Class group</source>
      <translation>Class group</translation>
    </message>
    <message>
      <source>Select class group for removal.</source>
      <translation>Select class group for removal.</translation>
    </message>
    <message>
      <source>Remove from selected</source>
      <translation>Remove from selected</translation>
    </message>
    <message>
      <source>Remove the &lt;%class_name&gt; class from the selected class groups.</source>
      <translation>Remove the &lt;%class_name&gt; class from the selected class groups.</translation>
    </message>
    <message>
      <source>Select a group which the &lt;%class_name&gt; class should be added to.</source>
      <translation>Select a group which the &lt;%class_name&gt; class should be added to.</translation>
    </message>
    <message>
      <source>Add to class group</source>
      <translation>Add to class group</translation>
    </message>
    <message>
      <source>Add the &lt;%class_name&gt; class to the group specified in the menu on the left.</source>
      <translation>Add the &lt;%class_name&gt; class to the group specified in the menu on the left.</translation>
    </message>
    <message>
      <source>The &lt;%class_name&gt; class already exists within all class groups.</source>
      <translation>The &lt;%class_name&gt; class already exists within all class groups.</translation>
    </message>
    <message>
      <source>No group</source>
      <translation>No group</translation>
    </message>
    <message>
      <source>Override templates [%1]</source>
      <translation>Override templates [%1]</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Override</source>
      <translation>Override</translation>
    </message>
    <message>
      <source>Source template</source>
      <translation>Source template</translation>
    </message>
    <message>
      <source>Override template</source>
      <translation>Override template</translation>
    </message>
    <message>
      <source>View template overrides for the &lt;%source_template_name&gt; template.</source>
      <translation>View template overrides for the &lt;%source_template_name&gt; template.</translation>
    </message>
    <message>
      <source>Edit the override template for the &lt;%override_name&gt; override.</source>
      <translation>Edit the override template for the &lt;%override_name&gt; override.</translation>
    </message>
    <message>
      <source>This class does not have any class-level override templates.</source>
      <translation>This class does not have any class-level override templates.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration</name>
    <message>
      <source>Approval</source>
      <translation>Approval</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/group/view/list</name>
    <message>
      <source>Group list for '%1'</source>
      <translation>Group list for '%1'</translation>
    </message>
    <message>
      <source>No items in group.</source>
      <translation>No items in group.</translation>
    </message>
    <message>
      <source>Group tree for '%1'</source>
      <translation>Group tree for '%1'</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/group_tree</name>
    <message>
      <source>Groups</source>
      <translation>Groups</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/handler/view/full/ezapprove</name>
    <message>
      <source>Approval</source>
      <translation>Approval</translation>
    </message>
    <message>
      <source>The content object %1 awaits approval before it can be published.</source>
      <translation>The content object %1 awaits approval before it can be published.</translation>
    </message>
    <message>
      <source>If you wish you may send a message to the person approving it?</source>
      <translation>If you wish you may send a message to the person approving it?</translation>
    </message>
    <message>
      <source>The content object %1 needs your approval before it can be published.</source>
      <translation>The content object %1 needs your approval before it can be published.</translation>
    </message>
    <message>
      <source>Do you approve of the content object being published?</source>
      <translation>Do you approve of the content object being published?</translation>
    </message>
    <message>
      <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
      <translation>The content object %1 was approved and will be published once the publishing workflow continues.</translation>
    </message>
    <message>
      <source>The content object %1 [deleted] was approved and will be published once the publishing workflow continues.</source>
      <translation>The content object %1 [deleted] was approved and will be published once the publishing workflow continues.</translation>
    </message>
    <message>
      <source>The content object %1 was not accepted but is available as a draft again.</source>
      <translation>The content object %1 was not accepted but is available as a draft again.</translation>
    </message>
    <message>
      <source>The content object %1 [deleted] was not accepted but is available as a draft again.</source>
      <translation>The content object %1 [deleted] was not accepted but is available as a draft again.</translation>
    </message>
    <message>
      <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
      <translation>You may reedit the draft and publish it, in which case an approval is required again.</translation>
    </message>
    <message>
      <source>Edit the object</source>
      <translation>Edit the object</translation>
    </message>
    <message>
      <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
      <translation>The content object %1 was not accepted but will be available as a draft for the author.</translation>
    </message>
    <message>
      <source>The content object %1 [deleted] was not accepted but will be available as a draft for the author.</source>
      <translation>The content object %1 [deleted] was not accepted but will be available as a draft for the author.</translation>
    </message>
    <message>
      <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
      <translation>The author can reedit the draft and publish it again, in which a new approval item is made.</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comment</translation>
    </message>
    <message>
      <source>Add Comment</source>
      <translation>Add Comment</translation>
    </message>
    <message>
      <source>Approve</source>
      <translation>Approve</translation>
    </message>
    <message>
      <source>Deny</source>
      <translation>Deny</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Participants</source>
      <translation>Participants</translation>
    </message>
    <message>
      <source>Messages</source>
      <translation>Messages</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/handler/view/line/ezapprove</name>
    <message>
      <source>The content object %1 [deleted]</source>
      <translation>The content object %1 [deleted]</translation>
    </message>
    <message>
      <source>%1 awaits approval by editor</source>
      <translation>%1 awaits approval by editor</translation>
    </message>
    <message>
      <source>%1 awaits your approval</source>
      <translation>%1 awaits your approval</translation>
    </message>
    <message>
      <source>%1 was approved for publishing</source>
      <translation>%1 was approved for publishing</translation>
    </message>
    <message>
      <source>%1 was not approved for publishing</source>
      <translation>%1 was not approved for publishing</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/item_list</name>
    <message>
      <source>Subject</source>
      <translation>Subject</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Date</translation>
    </message>
    <message>
      <source>Read</source>
      <translation>Read</translation>
    </message>
    <message>
      <source>Unread</source>
      <translation>Unread</translation>
    </message>
    <message>
      <source>Inactive</source>
      <translation>Inactive</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/view/element/ezapprove_comment</name>
    <message>
      <source>Posted: %1</source>
      <translation>Posted: %1</translation>
    </message>
  </context>
  <context>
    <name>design/admin/collaboration/view/summary</name>
    <message>
      <source>Item list</source>
      <translation>Item list</translation>
    </message>
    <message>
      <source>No new items to be handled.</source>
      <translation>No new items to be handled.</translation>
    </message>
    <message>
      <source>Group tree</source>
      <translation>Group tree</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/bookmark</name>
    <message>
      <source>My bookmarks [%bookmark_count]</source>
      <translation>My bookmarks [%bookmark_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Select bookmark for removal.</source>
      <translation>Select bookmark for removal.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit &lt;%bookmark_name&gt;.</source>
      <translation>Edit &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
      <source>You do not have permissions to edit the contents of &lt;%bookmark_name&gt;.</source>
      <translation>You do not have permissions to edit the contents of &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
      <source>There are no bookmarks in the list.</source>
      <translation>There are no bookmarks in the list.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected bookmarks.</source>
      <translation>Remove selected bookmarks.</translation>
    </message>
    <message>
      <source>Add items</source>
      <translation>Add items</translation>
    </message>
    <message>
      <source>Add items to your personal bookmark list.</source>
      <translation>Add items to your personal bookmark list.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse</name>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
      <translation>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</translation>
    </message>
    <message>
      <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
      <translation>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</translation>
    </message>
    <message>
      <source>Bookmarks</source>
      <translation>Bookmarks</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
    <message>
      <source>Top level</source>
      <translation>Top level</translation>
    </message>
    <message>
      <source>Display sub items using a simple list.</source>
      <translation>Display sub items using a simple list.</translation>
    </message>
    <message>
      <source>List</source>
      <translation>List</translation>
    </message>
    <message>
      <source>Thumbnail</source>
      <translation>Thumbnail</translation>
    </message>
    <message>
      <source>Display sub items as thumbnails.</source>
      <translation>Display sub items as thumbnails.</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_bookmark</name>
    <message>
      <source>Choose items to bookmark</source>
      <translation>Choose items to bookmark</translation>
    </message>
    <message>
      <source>Select the items that you want to bookmark using the checkboxes and click &quot;Select&quot;.</source>
      <translation>Select the items that you want to bookmark using the checkboxes and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_copy_node</name>
    <message>
      <source>Choose location for copy of &lt;%object_name&gt;</source>
      <translation>Choose location for copy of &lt;%object_name&gt;</translation>
    </message>
    <message>
      <source>Choose a new location for the copy of &lt;%object_name&gt; using the radio buttons and click &quot;Select&quot;.</source>
      <translation>Choose a new location for the copy of &lt;%object_name&gt; using the radio buttons and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
    <message>
      <source>Choose location for the copy of subtree of node &lt;%node_name&gt;</source>
      <translation>Choose location for the copy of subtree of node &lt;%node_name&gt;</translation>
    </message>
    <message>
      <source>Choose a new location for the copy of subtree of node &lt;%node_name&gt; using the radio buttons and click &quot;Select&quot;.</source>
      <translation>Choose a new location for the copy of subtree of node &lt;%node_name&gt; using the radio buttons and click &quot;Select&quot;.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_export</name>
    <message>
      <source>Choose export node</source>
      <translation>Choose export node</translation>
    </message>
    <message>
      <source>Select the item that you want to export using the checkboxes and click &quot;Select&quot;.</source>
      <translation>Select the item that you want to export using the checkboxes and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_first_placement</name>
    <message>
      <source>Choose location for new &lt;%classname&gt;</source>
      <translation>Choose location for new &lt;%classname&gt;</translation>
    </message>
    <message>
      <source>Choose a location for the new &lt;%classname&gt; using the radiobuttons and click &quot;Select&quot;.</source>
      <translation>Choose a location for the new &lt;%classname&gt; using the radiobuttons and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_move_node</name>
    <message>
      <source>Choose a new location for &lt;%object_name&gt;</source>
      <translation>Choose a new location for &lt;%object_name&gt;</translation>
    </message>
    <message>
      <source>Choose a new location for &lt;%object_name&gt; using the radio buttons and click &quot;Select&quot;.</source>
      <translation>Choose a new location for &lt;%object_name&gt; using the radio buttons and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_move_placement</name>
    <message>
      <source>Choose a new location for &lt;%version_name&gt;</source>
      <translation>Choose a new location for &lt;%version_name&gt;</translation>
    </message>
    <message>
      <source>Choose a new location for &lt;%version_name&gt; using the radio buttons and click &quot;Select&quot;.</source>
      <translation>Choose a new location for &lt;%version_name&gt; using the radio buttons and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>The previous location was &lt;%previous_location&gt;.</source>
      <translation>The previous location was &lt;%previous_location&gt;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_placement</name>
    <message>
      <source>Choose locations for &lt;%version_name&gt;</source>
      <translation>Choose locations for &lt;%version_name&gt;</translation>
    </message>
    <message>
      <source>Choose locations for &lt;%version_name&gt; using the checkboxes and click &quot;Select&quot;.</source>
      <translation>Choose locations for &lt;%version_name&gt; using the checkboxes and click &quot;Select&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_related</name>
    <message>
      <source>Choose objects that you wish to relate to &lt;%version_name&gt;</source>
      <translation>Choose objects that you wish to relate to &lt;%version_name&gt;</translation>
    </message>
    <message>
      <source>Use the checkboxes to choose the objects that you wish to relate to &lt;%version_name&gt;.</source>
      <translation>Use the checkboxes to choose the objects that you wish to relate to &lt;%version_name&gt;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/browse_swap_node</name>
    <message>
      <source>Choose the exchanging node for &lt;%object_name&gt;</source>
      <translation>Choose the exchanging node for &lt;%object_name&gt;</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose the node with which you want to swap &lt;%object_name&gt;.</source>
      <translation>Use the radio buttons to choose the node with which you want to swap &lt;%object_name&gt;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/children_reverserelatedlist</name>
    <message>
      <source>Item</source>
      <translation>Item</translation>
    </message>
    <message>
      <source>Objects referring to this one</source>
      <translation>Objects referring to this one</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/collectedinfo/feedback</name>
    <message>
      <source>Feedback for %feedbackname</source>
      <translation>Feedback for %feedbackname</translation>
    </message>
    <message>
      <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
      <translation>You have already submitted data to this feedback. The previously submitted data was the following.</translation>
    </message>
    <message>
      <source>Thanks for your feedback, the following information was collected.</source>
      <translation>Thanks for your feedback, the following information was collected.</translation>
    </message>
    <message>
      <source>Return to site</source>
      <translation>Return to site</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/collectedinfo/form</name>
    <message>
      <source>Form %formname</source>
      <translation>Form %formname</translation>
    </message>
    <message>
      <source>You have already submitted data to this form. The previously submitted data was the following.</source>
      <translation>You have already submitted data to this form. The previously submitted data was the following.</translation>
    </message>
    <message>
      <source>Collected information</source>
      <translation>Collected information</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/collectedinfo/poll</name>
    <message>
      <source>Poll %pollname</source>
      <translation>Poll %pollname</translation>
    </message>
    <message>
      <source>Anonymous users are not allowed to vote on this poll, please login.</source>
      <translation>Anonymous users are not allowed to vote on this poll, please login.</translation>
    </message>
    <message>
      <source>You have already voted for this poll.</source>
      <translation>You have already voted for this poll.</translation>
    </message>
    <message>
      <source>Poll results</source>
      <translation>Poll results</translation>
    </message>
    <message>
      <source>%count total votes</source>
      <translation>%count total votes</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/confirmtranslationremove</name>
    <message>
      <source>Confirm language removal</source>
      <translation>Confirm language removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the language?</source>
      <translation>Are you sure you want to remove the language?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the languages?</source>
      <translation>Are you sure you want to remove the languages?</translation>
    </message>
    <message>
      <source>Removing &lt;%1&gt; will also result in the removal of %2 translated versions.</source>
      <translation>Removing &lt;%1&gt; will also result in the removal of %2 translated versions.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/create_languages</name>
    <message>
      <source>Language selection</source>
      <translation>Language selection</translation>
    </message>
    <message>
      <source>You do not have permissions to create an object of the requested class in any language.</source>
      <translation>You do not have permissions to create an object of the requested class in any language.</translation>
    </message>
    <message>
      <source>Select the language in which you want to create the object</source>
      <translation>Select the language in which you want to create the object</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/datatype</name>
    <message>
      <source>No media file is available.</source>
      <translation>No media file is available.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/datatype/ezuser</name>
    <message>
      <source>Account status</source>
      <translation>Account status</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/diff</name>
    <message>
      <source>Versions for &lt;%object_name&gt; [%version_count]</source>
      <translation>Versions for &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Archived</source>
      <translation>Archived</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rejected</translation>
    </message>
    <message>
      <source>Untouched draft</source>
      <translation>Untouched draft</translation>
    </message>
    <message>
      <source>Show differences</source>
      <translation>Show differences</translation>
    </message>
    <message>
      <source>Differences between versions %oldVersion and %newVersion</source>
      <translation>Differences between versions %oldVersion and %newVersion</translation>
    </message>
    <message>
      <source>Old version</source>
      <translation>Old version</translation>
    </message>
    <message>
      <source>Inline changes</source>
      <translation>Inline changes</translation>
    </message>
    <message>
      <source>Block changes</source>
      <translation>Block changes</translation>
    </message>
    <message>
      <source>New version</source>
      <translation>New version</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/draft</name>
    <message>
      <source>My drafts [%draft_count]</source>
      <translation>My drafts [%draft_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Select draft for removal.</source>
      <translation>Select draft for removal.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Edit &lt;%draft_name&gt;.</source>
      <translation>Edit &lt;%draft_name&gt;.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>There are no drafts that belong to you.</source>
      <translation>There are no drafts that belong to you.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected drafts.</source>
      <translation>Remove selected drafts.</translation>
    </message>
    <message>
      <source>Remove all</source>
      <translation>Remove all</translation>
    </message>
    <message>
      <source>Are you sure you want to remove all drafts?</source>
      <translation>Are you sure you want to remove all drafts?</translation>
    </message>
    <message>
      <source>Remove all drafts that belong to you.</source>
      <translation>Remove all drafts that belong to you.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/edit</name>
    <message>
      <source>Edit &lt;%object_name&gt; [%class_name]</source>
      <translation>Edit &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
      <source>Translating content from %from_lang to %to_lang</source>
      <translation>Translating content from %from_lang to %to_lang</translation>
    </message>
    <message>
      <source>Send for publishing</source>
      <translation>Send for publishing</translation>
    </message>
    <message>
      <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
      <translation>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</translation>
    </message>
    <message>
      <source>Store draft</source>
      <translation>Store draft</translation>
    </message>
    <message>
      <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
      <translation>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</translation>
    </message>
    <message>
      <source>Discard draft</source>
      <translation>Discard draft</translation>
    </message>
    <message>
      <source>Are you sure you want to discard the draft?</source>
      <translation>Are you sure you want to discard the draft?</translation>
    </message>
    <message>
      <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
      <translation>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</translation>
    </message>
    <message>
      <source>Publish data</source>
      <translation>Publish data</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Depth</source>
      <translation>Depth</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class Identifier</source>
      <translation>Class Identifier</translation>
    </message>
    <message>
      <source>Class Name</source>
      <translation>Class Name</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Locations [%locations]</source>
      <translation>Locations [%locations]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Sub items</source>
      <translation>Sub items</translation>
    </message>
    <message>
      <source>Sorting of sub items</source>
      <translation>Sorting of sub items</translation>
    </message>
    <message>
      <source>Current visibility</source>
      <translation>Current visibility</translation>
    </message>
    <message>
      <source>Visibility after publishing</source>
      <translation>Visibility after publishing</translation>
    </message>
    <message>
      <source>Main</source>
      <translation>Main</translation>
    </message>
    <message>
      <source>This location will remain unchanged when object is published.</source>
      <translation>This location will remain unchanged when object is published.</translation>
    </message>
    <message>
      <source>This location will be created when object is published.</source>
      <translation>This location will be created when object is published.</translation>
    </message>
    <message>
      <source>This location will be moved when object is published.</source>
      <translation>This location will be moved when object is published.</translation>
    </message>
    <message>
      <source>This location will be removed when object is published.</source>
      <translation>This location will be removed when object is published.</translation>
    </message>
    <message>
      <source>You do not have permissions to remove this location.</source>
      <translation>You do not have permissions to remove this location.</translation>
    </message>
    <message>
      <source>Select location for removal.</source>
      <translation>Select location for removal.</translation>
    </message>
    <message>
      <source>Use this menu to set the sorting method for the sub items of the respective location.</source>
      <translation>Use this menu to set the sorting method for the sub items of the respective location.</translation>
    </message>
    <message>
      <source>Use this menu to set the sorting direction for the sub items of the respective location.</source>
      <translation>Use this menu to set the sorting direction for the sub items of the respective location.</translation>
    </message>
    <message>
      <source>Asc.</source>
      <translation>Asc.</translation>
    </message>
    <message>
      <source>Desc.</source>
      <translation>Desc.</translation>
    </message>
    <message>
      <source>Hidden by parent</source>
      <translation>Hidden by parent</translation>
    </message>
    <message>
      <source>Visible</source>
      <translation>Visible</translation>
    </message>
    <message>
      <source>Unchanged</source>
      <translation>Unchanged</translation>
    </message>
    <message>
      <source>Hidden</source>
      <translation>Hidden</translation>
    </message>
    <message>
      <source>Use these radio buttons to specify the main location (main node) for the object being edited.</source>
      <translation>Use these radio buttons to specify the main location (main node) for the object being edited.</translation>
    </message>
    <message>
      <source>Move to another location.</source>
      <translation>Move to another location.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected locations.</source>
      <translation>Remove selected locations.</translation>
    </message>
    <message>
      <source>Add locations</source>
      <translation>Add locations</translation>
    </message>
    <message>
      <source>Add one or more locations for the object being edited.</source>
      <translation>Add one or more locations for the object being edited.</translation>
    </message>
    <message>
      <source>You can not add or remove locations because the object being edited belongs to a top node.</source>
      <translation>You can not add or remove locations because the object being edited belongs to a top node.</translation>
    </message>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Manage versions</source>
      <translation>Manage versions</translation>
    </message>
    <message>
      <source>View and manage (copy, delete, etc.) the versions of this object.</source>
      <translation>View and manage (copy, delete, etc.) the versions of this object.</translation>
    </message>
    <message>
      <source>You can not manage the versions of this object because there is only one version available (the one that is being edited).</source>
      <translation>You can not manage the versions of this object because there is only one version available (the one that is being edited).</translation>
    </message>
    <message>
      <source>Current draft</source>
      <translation>Current draft</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
    <message>
      <source>View the draft that is being edited.</source>
      <translation>View the draft that is being edited.</translation>
    </message>
    <message>
      <source>Store and exit</source>
      <translation>Store and exit</translation>
    </message>
    <message>
      <source>Store the draft that is being edited and exit from edit mode.</source>
      <translation>Store the draft that is being edited and exit from edit mode.</translation>
    </message>
    <message>
      <source>Translate from</source>
      <translation>Translate from</translation>
    </message>
    <message>
      <source>No translation</source>
      <translation>No translation</translation>
    </message>
    <message>
      <source>Translate</source>
      <translation>Translate</translation>
    </message>
    <message>
      <source>Edit the current object showing the selected language as a reference.</source>
      <translation>Edit the current object showing the selected language as a reference.</translation>
    </message>
    <message>
      <source>Related objects [%related_objects]</source>
      <translation>Related objects [%related_objects]</translation>
    </message>
    <message>
      <source>Related images [%related_images]</source>
      <translation>Related images [%related_images]</translation>
    </message>
    <message>
      <source>You do not have sufficient permissions to view this object</source>
      <translation>You do not have sufficient permissions to view this object</translation>
    </message>
    <message>
      <source>Copy this code and paste it into an XML field.</source>
      <translation>Copy this code and paste it into an XML field.</translation>
    </message>
    <message>
      <source>Related files [%related_files]</source>
      <translation>Related files [%related_files]</translation>
    </message>
    <message>
      <source>File type</source>
      <translation>File type</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Size</translation>
    </message>
    <message>
      <source>XML code</source>
      <translation>XML code</translation>
    </message>
    <message>
      <source>Related content [%related_objects]</source>
      <translation>Related content [%related_objects]</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>There are no objects related to the one that is currently being edited.</source>
      <translation>There are no objects related to the one that is currently being edited.</translation>
    </message>
    <message>
      <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
      <translation>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</translation>
    </message>
    <message>
      <source>Add existing</source>
      <translation>Add existing</translation>
    </message>
    <message>
      <source>Add an existing item as a related object.</source>
      <translation>Add an existing item as a related object.</translation>
    </message>
    <message>
      <source>Upload new</source>
      <translation>Upload new</translation>
    </message>
    <message>
      <source>Upload a file and add it as a related object.</source>
      <translation>Upload a file and add it as a related object.</translation>
    </message>
    <message>
      <source>The draft could not be stored.</source>
      <translation>The draft could not be stored.</translation>
    </message>
    <message>
      <source>Required data is either missing or is invalid</source>
      <translation>Required data is either missing or is invalid</translation>
    </message>
    <message>
      <source>The following locations are invalid</source>
      <translation>The following locations are invalid</translation>
    </message>
    <message>
      <source>The draft was only partially stored.</source>
      <translation>The draft was only partially stored.</translation>
    </message>
    <message>
      <source>The draft was successfully stored.</source>
      <translation>The draft was successfully stored.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/edit_attribute</name>
    <message>
      <source>not translatable</source>
      <translation>not translatable</translation>
    </message>
    <message>
      <source>required</source>
      <translation>required</translation>
    </message>
    <message>
      <source>information collector</source>
      <translation>information collector</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/edit_draft</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Possible edit conflict</source>
      <translation>Possible edit conflict</translation>
    </message>
    <message>
      <source>The object has already been published by someone else.</source>
      <translation>The object has already been published by someone else.</translation>
    </message>
    <message>
      <source>You should contact the other user(s) to make sure that you are not stepping on anyone's toes.</source>
      <translation>You should contact the other user(s) to make sure that you are not stepping on anyone's toes.</translation>
    </message>
    <message>
      <source>Possible actions</source>
      <translation>Possible actions</translation>
    </message>
    <message>
      <source>Publish data as it is (and overwriting the published data).</source>
      <translation>Publish data as it is (and overwriting the published data).</translation>
    </message>
    <message>
      <source>Go back to editing and show the published data.</source>
      <translation>Go back to editing and show the published data.</translation>
    </message>
    <message>
      <source>Conflicting versions [%draft_count]</source>
      <translation>Conflicting versions [%draft_count]</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>View the contents of version #%version. Translation: %translation.</source>
      <translation>View the contents of version #%version. Translation: %translation.</translation>
    </message>
    <message>
      <source>View the contents of version #%version_number. Translation: %translation.</source>
      <translation>View the contents of version #%version_number. Translation: %translation.</translation>
    </message>
    <message>
      <source>Show the published data</source>
      <translation>Show the published data</translation>
    </message>
    <message>
      <source>Create a new draft. The contents of the new draft will copied from the published version.</source>
      <translation>Create a new draft. The contents of the new draft will copied from the published version.</translation>
    </message>
    <message>
      <source>This object is already being edited by someone else. In addition, it is already being edited by you.</source>
      <translation>This object is already being edited by someone else. In addition, it is already being edited by you.</translation>
    </message>
    <message>
      <source>The most recently modified draft is version #%version, created by %creator, last changed: %modified.</source>
      <translation>The most recently modified draft is version #%version, created by %creator, last changed: %modified.</translation>
    </message>
    <message>
      <source>This object is already being edited by you.</source>
      <translation>This object is already being edited by you.</translation>
    </message>
    <message>
      <source>Your most recently modified draft is version #%version, last changed: %modified.</source>
      <translation>Your most recently modified draft is version #%version, last changed: %modified.</translation>
    </message>
    <message>
      <source>This object is already being edited by someone else.</source>
      <translation>This object is already being edited by someone else.</translation>
    </message>
    <message>
      <source>Continue editing one of your drafts.</source>
      <translation>Continue editing one of your drafts.</translation>
    </message>
    <message>
      <source>Create a new draft and start editing it.</source>
      <translation>Create a new draft and start editing it.</translation>
    </message>
    <message>
      <source>Cancel the edit operation.</source>
      <translation>Cancel the edit operation.</translation>
    </message>
    <message>
      <source>Current drafts [%draft_count]</source>
      <translation>Current drafts [%draft_count]</translation>
    </message>
    <message>
      <source>Select draft version #%version for editing.</source>
      <translation>Select draft version #%version for editing.</translation>
    </message>
    <message>
      <source>You can not select draft version #%version for editing because it belongs to another user. Please select a draft that belongs to you or create a new draft and then edit it.</source>
      <translation>You can not select draft version #%version for editing because it belongs to another user. Please select a draft that belongs to you or create a new draft and then edit it.</translation>
    </message>
    <message>
      <source>Edit selected</source>
      <translation>Edit selected</translation>
    </message>
    <message>
      <source>Edit the selected draft.</source>
      <translation>Edit the selected draft.</translation>
    </message>
    <message>
      <source>You can not edit any of the drafts because none of them belong to you. Hint: Create a new draft, select it and edit it.</source>
      <translation>You can not edit any of the drafts because none of them belong to you. Hint: Create a new draft, select it and edit it.</translation>
    </message>
    <message>
      <source>New draft</source>
      <translation>New draft</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/edit_languages</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Edit &lt;%object_name&gt;</source>
      <translation>Edit &lt;%object_name&gt;</translation>
    </message>
    <message>
      <source>Existing languages</source>
      <translation>Existing languages</translation>
    </message>
    <message>
      <source>Select the language you want to edit</source>
      <translation>Select the language you want to edit</translation>
    </message>
    <message>
      <source>New languages</source>
      <translation>New languages</translation>
    </message>
    <message>
      <source>Select the language you want to add</source>
      <translation>Select the language you want to add</translation>
    </message>
    <message>
      <source>Select the language the added translation will be based on</source>
      <translation>Select the language the added translation will be based on</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>You do not have sufficient permissions to create a translation in another language.</source>
      <translation>You do not have sufficient permissions to create a translation in another language.</translation>
    </message>
    <message>
      <source>However you can select one of the following languages for editing</source>
      <translation>However you can select one of the following languages for editing</translation>
    </message>
    <message>
      <source>You do not have permission to edit the object in any available languages.</source>
      <translation>You do not have permission to edit the object in any available languages.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/pendinglist</name>
    <message>
      <source>My pending items [%pending_count]</source>
      <translation>My pending items [%pending_count]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>The pending list is empty.</source>
      <translation>The pending list is empty.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/removeassignment</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Manage versions</source>
      <translation>Manage versions</translation>
    </message>
    <message>
      <source>Current draft</source>
      <translation>Current draft</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Confirm location removal</source>
      <translation>Confirm location removal</translation>
    </message>
    <message>
      <source>Insufficient permissions</source>
      <translation>Insufficient permissions</translation>
    </message>
    <message>
      <source>Some of the locations that are about to be removed contain sub items.</source>
      <translation>Some of the locations that are about to be removed contain sub items.</translation>
    </message>
    <message>
      <source>Removing the locations will also result in the removal of the sub items.</source>
      <translation>Removing the locations will also result in the removal of the sub items.</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the locations along with their contents?</source>
      <translation>Are you sure you want to remove the locations along with their contents?</translation>
    </message>
    <message>
      <source>The locations marked with red contain items that you do not have permissions to remove.</source>
      <translation>The locations marked with red contain items that you do not have permissions to remove.</translation>
    </message>
    <message>
      <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
      <translation>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Sub items</source>
      <translation>Sub items</translation>
    </message>
    <message>
      <source>%child_count item</source>
      <translation>%child_count item</translation>
    </message>
    <message>
      <source>%child_count items</source>
      <translation>%child_count items</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Remove the locations along with all the sub items.</source>
      <translation>Remove the locations along with all the sub items.</translation>
    </message>
    <message>
      <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
      <translation>You can not continue because you do not have permissions to remove some of the selected locations.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel the removal of locations.</source>
      <translation>Cancel the removal of locations.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/removeeditversion</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Manage versions</source>
      <translation>Manage versions</translation>
    </message>
    <message>
      <source>Current draft</source>
      <translation>Current draft</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Confirm draft discard</source>
      <translation>Confirm draft discard</translation>
    </message>
    <message>
      <source>Are you sure you want to discard the draft?</source>
      <translation>Are you sure you want to discard the draft?</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/removeobject</name>
    <message>
      <source>%child_count item</source>
      <translation>%child_count item</translation>
    </message>
    <message>
      <source>%child_count items</source>
      <translation>%child_count items</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/restore</name>
    <message>
      <source>Object retrieval</source>
      <translation>Object retrieval</translation>
    </message>
    <message>
      <source>The object will be restored at its original location.</source>
      <translation>The object will be restored at its original location.</translation>
    </message>
    <message>
      <source>Restore at original location (below &lt;%nodeName&gt;).</source>
      <translation>Restore at original location (below &lt;%nodeName&gt;).</translation>
    </message>
    <message>
      <source>The system will let you specify a location by browsing the tree.</source>
      <translation>The system will let you specify a location by browsing the tree.</translation>
    </message>
    <message>
      <source>Select a location.</source>
      <translation>Select a location.</translation>
    </message>
    <message>
      <source>Restore at original location (unavailable).</source>
      <translation>Restore at original location (unavailable).</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Continue restoring &lt;%name&gt;.</source>
      <translation>Continue restoring &lt;%name&gt;.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Do not restore &lt;%name&gt; and return to trash.</source>
      <translation>Do not restore &lt;%name&gt; and return to trash.</translation>
    </message>
    <message>
      <source>Restoring object &lt;%name&gt; [%className]</source>
      <translation>Restoring object &lt;%name&gt; [%className]</translation>
    </message>
    <message>
      <source>The system will restore the original location of the object.</source>
      <translation>The system will restore the original location of the object.</translation>
    </message>
    <message>
      <source>Restore original location &lt;%nodeName&gt;</source>
      <translation>Restore original location &lt;%nodeName&gt;</translation>
    </message>
    <message>
      <source>The system will let you browse for a location for the object.</source>
      <translation>The system will let you browse for a location for the object.</translation>
    </message>
    <message>
      <source>Browse for location</source>
      <translation>Browse for location</translation>
    </message>
    <message>
      <source>Restore original locations</source>
      <translation>Restore original locations</translation>
    </message>
    <message>
      <source>Restore &lt;%name&gt; to the specified location.</source>
      <translation>Restore &lt;%name&gt; to the specified location.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/reverserelatedlist</name>
    <message>
      <source>&quot;%contentObjectName&quot; [%children_count]: Sub items that are used by other objects </source>
      <translation>&quot;%contentObjectName&quot; [%children_count]: Sub items that are used by other objects </translation>
    </message>
    <message>
      <source>This subtree/item has no external relations.</source>
      <translation>This subtree/item has no external relations.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/search</name>
    <message>
      <source>Advanced search</source>
      <translation>Advanced search</translation>
    </message>
    <message>
      <source>Search for all of the following words</source>
      <translation>Search for all of the following words</translation>
    </message>
    <message>
      <source>Search for an exact phrase</source>
      <translation>Search for an exact phrase</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Any class</source>
      <translation>Any class</translation>
    </message>
    <message>
      <source>Class attribute</source>
      <translation>Class attribute</translation>
    </message>
    <message>
      <source>Any attribute</source>
      <translation>Any attribute</translation>
    </message>
    <message>
      <source>Update attributes</source>
      <translation>Update attributes</translation>
    </message>
    <message>
      <source>In</source>
      <translation>In</translation>
    </message>
    <message>
      <source>Any section</source>
      <translation>Any section</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Any time</source>
      <translation>Any time</translation>
    </message>
    <message>
      <source>Last day</source>
      <translation>Last day</translation>
    </message>
    <message>
      <source>Last week</source>
      <translation>Last week</translation>
    </message>
    <message>
      <source>Last month</source>
      <translation>Last month</translation>
    </message>
    <message>
      <source>Last three months</source>
      <translation>Last three months</translation>
    </message>
    <message>
      <source>Last year</source>
      <translation>Last year</translation>
    </message>
    <message>
      <source>Display per page</source>
      <translation>Display per page</translation>
    </message>
    <message>
      <source>5 items</source>
      <translation>5 items</translation>
    </message>
    <message>
      <source>10 items</source>
      <translation>10 items</translation>
    </message>
    <message>
      <source>20 items</source>
      <translation>20 items</translation>
    </message>
    <message>
      <source>30 items</source>
      <translation>30 items</translation>
    </message>
    <message>
      <source>50 items</source>
      <translation>50 items</translation>
    </message>
    <message>
      <source>No results were found when searching for &lt;%1&gt;</source>
      <translation>No results were found when searching for &lt;%1&gt;</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>Search for &lt;%1&gt; returned %2 matches</source>
      <translation>Search for &lt;%1&gt; returned %2 matches</translation>
    </message>
    <message>
      <source>All content</source>
      <translation>All content</translation>
    </message>
    <message>
      <source>The same location</source>
      <translation>The same location</translation>
    </message>
    <message>
      <source>For more options try the %1Advanced search%2.</source>
      <comment>The parameters are link start and end tags.</comment>
      <translation>For more options try the %1Advanced search%2.</translation>
    </message>
    <message>
      <source>The following words were excluded from the search</source>
      <translation>The following words were excluded from the search</translation>
    </message>
    <message>
      <source>No results were found while searching for &lt;%1&gt;</source>
      <translation>No results were found while searching for &lt;%1&gt;</translation>
    </message>
    <message>
      <source>Search tips</source>
      <translation>Search tips</translation>
    </message>
    <message>
      <source>Check spelling of keywords.</source>
      <translation>Check spelling of keywords.</translation>
    </message>
    <message>
      <source>Try changing some keywords e.g. car instead of cars.</source>
      <translation>Try changing some keywords e.g. car instead of cars.</translation>
    </message>
    <message>
      <source>Try more general keywords.</source>
      <translation>Try more general keywords.</translation>
    </message>
    <message>
      <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
      <translation>Fewer keywords gives more results, try reducing keywords until you get a result.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/translationnew</name>
    <message>
      <source>Translation</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>New translation for content</source>
      <translation>New translation for content</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Custom</translation>
    </message>
    <message>
      <source>Name of custom translation</source>
      <translation>Name of custom translation</translation>
    </message>
    <message>
      <source>Locale for custom translation</source>
      <translation>Locale for custom translation</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/translations</name>
    <message>
      <source>Available languages for translation of content [%translations_count]</source>
      <translation>Available languages for translation of content [%translations_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>The language can not be removed because it is in use.</source>
      <translation>The language can not be removed because it is in use.</translation>
    </message>
    <message>
      <source>Select language for removal.</source>
      <translation>Select language for removal.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected languages.</source>
      <translation>Remove selected languages.</translation>
    </message>
    <message>
      <source>Add language</source>
      <translation>Add language</translation>
    </message>
    <message>
      <source>Add a new language. The new language can then be used when translating content.</source>
      <translation>Add a new language. The new language can then be used when translating content.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/translationview</name>
    <message>
      <source>%translation [Translation]</source>
      <translation>%translation [Translation]</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>%locale [Locale]</source>
      <translation>%locale [Locale]</translation>
    </message>
    <message>
      <source>Charset</source>
      <translation>Charset</translation>
    </message>
    <message>
      <source>Not set</source>
      <translation>Not set</translation>
    </message>
    <message>
      <source>Allowed charsets</source>
      <translation>Allowed charsets</translation>
    </message>
    <message>
      <source>Country name</source>
      <translation>Country name</translation>
    </message>
    <message>
      <source>Country comment</source>
      <translation>Country comment</translation>
    </message>
    <message>
      <source>Country code</source>
      <translation>Country code</translation>
    </message>
    <message>
      <source>Country variation</source>
      <translation>Country variation</translation>
    </message>
    <message>
      <source>Language name</source>
      <translation>Language name</translation>
    </message>
    <message>
      <source>International language name</source>
      <translation>International language name</translation>
    </message>
    <message>
      <source>Language code</source>
      <translation>Language code</translation>
    </message>
    <message>
      <source>Language comment</source>
      <translation>Language comment</translation>
    </message>
    <message>
      <source>Locale code</source>
      <translation>Locale code</translation>
    </message>
    <message>
      <source>Full locale code</source>
      <translation>Full locale code</translation>
    </message>
    <message>
      <source>HTTP locale code</source>
      <translation>HTTP locale code</translation>
    </message>
    <message>
      <source>Decimal symbol</source>
      <translation>Decimal symbol</translation>
    </message>
    <message>
      <source>Thousands separator</source>
      <translation>Thousands separator</translation>
    </message>
    <message>
      <source>Decimal count</source>
      <translation>Decimal count</translation>
    </message>
    <message>
      <source>Negative symbol</source>
      <translation>Negative symbol</translation>
    </message>
    <message>
      <source>Positive symbol</source>
      <translation>Positive symbol</translation>
    </message>
    <message>
      <source>Currency decimal symbol</source>
      <translation>Currency decimal symbol</translation>
    </message>
    <message>
      <source>Currency thousands separator</source>
      <translation>Currency thousands separator</translation>
    </message>
    <message>
      <source>Currency decimal count</source>
      <translation>Currency decimal count</translation>
    </message>
    <message>
      <source>Currency negative symbol</source>
      <translation>Currency negative symbol</translation>
    </message>
    <message>
      <source>Currency positive symbol</source>
      <translation>Currency positive symbol</translation>
    </message>
    <message>
      <source>Currency symbol</source>
      <translation>Currency symbol</translation>
    </message>
    <message>
      <source>Currency name</source>
      <translation>Currency name</translation>
    </message>
    <message>
      <source>Currency short name</source>
      <translation>Currency short name</translation>
    </message>
    <message>
      <source>First day of week</source>
      <translation>First day of week</translation>
    </message>
    <message>
      <source>Monday</source>
      <translation>Monday</translation>
    </message>
    <message>
      <source>Sunday</source>
      <translation>Sunday</translation>
    </message>
    <message>
      <source>Weekday names</source>
      <translation>Weekday names</translation>
    </message>
    <message>
      <source>Month names</source>
      <translation>Month names</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/trash</name>
    <message>
      <source>Trash [%list_count]</source>
      <translation>Trash [%list_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Use these checkboxes to mark items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
      <translation>Use these checkboxes to mark items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Restore</source>
      <translation>Restore</translation>
    </message>
    <message>
      <source>There are no items in the trash</source>
      <translation>There are no items in the trash</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Permanently remove the selected items.</source>
      <translation>Permanently remove the selected items.</translation>
    </message>
    <message>
      <source>Empty trash</source>
      <translation>Empty trash</translation>
    </message>
    <message>
      <source>Permanently remove all items from the trash.</source>
      <translation>Permanently remove all items from the trash.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/upload</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Manage versions</source>
      <translation>Manage versions</translation>
    </message>
    <message>
      <source>Current draft</source>
      <translation>Current draft</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>The file could not be uploaded</source>
      <translation>The file could not be uploaded</translation>
    </message>
    <message>
      <source>The following errors occurred</source>
      <translation>The following errors occurred</translation>
    </message>
    <message>
      <source>File upload</source>
      <translation>File upload</translation>
    </message>
    <message>
      <source>Choose a file from your local machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
      <translation>Choose a file from your local machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</translation>
    </message>
    <message>
      <source>Upload file</source>
      <translation>Upload file</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>The location where the uploaded file should be placed.</source>
      <translation>The location where the uploaded file should be placed.</translation>
    </message>
    <message>
      <source>Automatic</source>
      <translation>Automatic</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Select the file that you wish to upload.</source>
      <translation>Select the file that you wish to upload.</translation>
    </message>
    <message>
      <source>Upload</source>
      <translation>Upload</translation>
    </message>
    <message>
      <source>Proceed with uploading the selected file.</source>
      <translation>Proceed with uploading the selected file.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Abort the upload operation and go back to where you came from.</source>
      <translation>Abort the upload operation and go back to where you came from.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/upload_related</name>
    <message>
      <source>Upload a file and relate it to &lt;%version_name&gt;</source>
      <translation>Upload a file and relate it to &lt;%version_name&gt;</translation>
    </message>
    <message>
      <source>This operation allows you to upload a file and add it as a related object.</source>
      <translation>This operation allows you to upload a file and add it as a related object.</translation>
    </message>
    <message>
      <source>When the file is uploaded, an object will be created according to the type of the file.</source>
      <translation>When the file is uploaded, an object will be created according to the type of the file.</translation>
    </message>
    <message>
      <source>The newly created object will be placed within the chosen location.</source>
      <translation>The newly created object will be placed within the chosen location.</translation>
    </message>
    <message>
      <source>The newly created object will be automatically related to the draft being edited (&lt;%version_name&gt;).</source>
      <translation>The newly created object will be automatically related to the draft being edited (&lt;%version_name&gt;).</translation>
    </message>
    <message>
      <source>Select the file you wish to upload and click the &quot;Upload&quot; button.</source>
      <translation>Select the file you wish to upload and click the &quot;Upload&quot; button.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/urltranslator</name>
    <message>
      <source>The requested URL forwarding could not be created.</source>
      <translation>The requested URL forwarding could not be created.</translation>
    </message>
    <message>
      <source>The destination URL &lt;%destination_url&gt; does not exist in the system.</source>
      <translation>The destination URL &lt;%destination_url&gt; does not exist in the system.</translation>
    </message>
    <message>
      <source>New system URL forwarding</source>
      <translation>New system URL forwarding</translation>
    </message>
    <message>
      <source>New virtual URL</source>
      <translation>New virtual URL</translation>
    </message>
    <message>
      <source>System URL</source>
      <translation>System URL</translation>
    </message>
    <message>
      <source>Example: /services</source>
      <translation>Example: /services</translation>
    </message>
    <message>
      <source>Example: /content/view/full/42</source>
      <translation>Example: /content/view/full/42</translation>
    </message>
    <message>
      <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system.</source>
      <translation>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system.</translation>
    </message>
    <message>
      <source>Use this field to enter a valid system URL. A system URL is easily recognized since it consists of several parts separated by a &quot;/&quot;.</source>
      <translation>Use this field to enter a valid system URL. A system URL is easily recognized since it consists of several parts separated by a &quot;/&quot;.</translation>
    </message>
    <message>
      <source>Add</source>
      <translation>Add</translation>
    </message>
    <message>
      <source>Click this button to add a new system URL forwarding. System URL forwarding is used to forward any URL to a system URL in eZ publish.</source>
      <translation>Click this button to add a new system URL forwarding. System URL forwarding is used to forward any URL to a system URL in eZ publish.</translation>
    </message>
    <message>
      <source>New virtual URL forwarding</source>
      <translation>New virtual URL forwarding</translation>
    </message>
    <message>
      <source>Existing virtual URL</source>
      <translation>Existing virtual URL</translation>
    </message>
    <message>
      <source>Example: /about/service</source>
      <translation>Example: /about/service</translation>
    </message>
    <message>
      <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object.</source>
      <translation>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object.</translation>
    </message>
    <message>
      <source>Click this button to add a new virtual URL forwarding. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish.</source>
      <translation>Click this button to add a new virtual URL forwarding. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish.</translation>
    </message>
    <message>
      <source>New virtual URL forwarding with wildcard</source>
      <translation>New virtual URL forwarding with wildcard</translation>
    </message>
    <message>
      <source>New virtual URL wildcard</source>
      <translation>New virtual URL wildcard</translation>
    </message>
    <message>
      <source>Redirecting URL</source>
      <translation>Redirecting URL</translation>
    </message>
    <message>
      <source>Example: /developer/*</source>
      <translation>Example: /developer/*</translation>
    </message>
    <message>
      <source>Example</source>
      <translation>Example</translation>
    </message>
    <message>
      <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system. You can place a star anywhere in the URL which will match an arbitrary number of characters.</source>
      <translation>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system. You can place a star anywhere in the URL which will match an arbitrary number of characters.</translation>
    </message>
    <message>
      <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object. Any characters matched by a star in the source URL can be transfered to the destination URL by inserting {1\} where appropriate.</source>
      <translation>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object. Any characters matched by a star in the source URL can be transfered to the destination URL by inserting {1\} where appropriate.</translation>
    </message>
    <message>
      <source>Use this checkbox to select if eZ publish should perform an internal redirect or a browser redirect. An internal redirect simply redirects the old URL to the new one without notifying the browser. A browser redirect makes the browser abort the current request and reload with the new URL. A browser redirect can be useful if you want the browser URL field to be updated.</source>
      <translation>Use this checkbox to select if eZ publish should perform an internal redirect or a browser redirect. An internal redirect simply redirects the old URL to the new one without notifying the browser. A browser redirect makes the browser abort the current request and reload with the new URL. A browser redirect can be useful if you want the browser URL field to be updated.</translation>
    </message>
    <message>
      <source>Click this button to add a new virtual URL forwarding with wildcard match. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish. The wildcard match is useful if you have moved a complete tree from one place to another.</source>
      <translation>Click this button to add a new virtual URL forwarding with wildcard match. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish. The wildcard match is useful if you have moved a complete tree from one place to another.</translation>
    </message>
    <message>
      <source>Custom URL translations [%alias_count]</source>
      <translation>Custom URL translations [%alias_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Source URL</source>
      <translation>Source URL</translation>
    </message>
    <message>
      <source>Destination URL</source>
      <translation>Destination URL</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Select URL translation for removal.</source>
      <translation>Select URL translation for removal.</translation>
    </message>
    <message>
      <source>Forwards to</source>
      <translation>Forwards to</translation>
    </message>
    <message>
      <source>Wildcard forwarding</source>
      <translation>Wildcard forwarding</translation>
    </message>
    <message>
      <source>System forwarding</source>
      <translation>System forwarding</translation>
    </message>
    <message>
      <source>Virtual forwarding</source>
      <translation>Virtual forwarding</translation>
    </message>
    <message>
      <source>There are no custom URL translations.</source>
      <translation>There are no custom URL translations.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected URL translations.</source>
      <translation>Remove selected URL translations.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields in the list above.</source>
      <translation>Click this button to store changes if you have modified any of the fields in the list above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/versions</name>
    <message>
      <source>This object does not have any versions.</source>
      <translation>This object does not have any versions.</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Archived</source>
      <translation>Archived</translation>
    </message>
    <message>
      <source>Untouched draft</source>
      <translation>Untouched draft</translation>
    </message>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Version not a draft</source>
      <translation>Version not a draft</translation>
    </message>
    <message>
      <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
      <translation>Version %1 is not available for editing anymore, only drafts can be edited.</translation>
    </message>
    <message>
      <source>To edit this version create a copy of it.</source>
      <translation>To edit this version create a copy of it.</translation>
    </message>
    <message>
      <source>Version not yours</source>
      <translation>Version not yours</translation>
    </message>
    <message>
      <source>Version %1 was not created by you, only your own drafts can be edited.</source>
      <translation>Version %1 was not created by you, only your own drafts can be edited.</translation>
    </message>
    <message>
      <source>Unable to create new version</source>
      <translation>Unable to create new version</translation>
    </message>
    <message>
      <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
      <translation>Version history limit has been exceeded and no archived version can be removed by the system.</translation>
    </message>
    <message>
      <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
      <translation>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</translation>
    </message>
    <message>
      <source>Versions for &lt;%object_name&gt; [%version_count]</source>
      <translation>Versions for &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Select version #%version_number for removal.</source>
      <translation>Select version #%version_number for removal.</translation>
    </message>
    <message>
      <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
      <translation>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</translation>
    </message>
    <message>
      <source>View the contents of version #%version_number. Translation: %translation.</source>
      <translation>View the contents of version #%version_number. Translation: %translation.</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rejected</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Create a copy of version #%version_number.</source>
      <translation>Create a copy of version #%version_number.</translation>
    </message>
    <message>
      <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
      <translation>You can not make copies of versions because you do not have permissions to edit the object.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the contents of version #%version_number.</source>
      <translation>Edit the contents of version #%version_number.</translation>
    </message>
    <message>
      <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
      <translation>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove the selected versions from the object.</source>
      <translation>Remove the selected versions from the object.</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
  </context>
  <context>
    <name>design/admin/content/view/versionview</name>
    <message>
      <source>Object information</source>
      <translation>Object information</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>Manage versions</source>
      <translation>Manage versions</translation>
    </message>
    <message>
      <source>View and manage (copy, delete, etc.) the versions of this object.</source>
      <translation>View and manage (copy, delete, etc.) the versions of this object.</translation>
    </message>
    <message>
      <source>You can not manage the versions of this object because there is only one version available (the one that is being displayed).</source>
      <translation>You can not manage the versions of this object because there is only one version available (the one that is being displayed).</translation>
    </message>
    <message>
      <source>Version information</source>
      <translation>Version information</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Published / current</source>
      <translation>Published / current</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Archived</source>
      <translation>Archived</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rejected</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>View control</source>
      <translation>View control</translation>
    </message>
    <message>
      <source>Translation</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>%1 (No locale information available)</source>
      <translation>%1 (No locale information available)</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Update view</source>
      <translation>Update view</translation>
    </message>
    <message>
      <source>View the version that is currently being displayed using the selected language, location and design.</source>
      <translation>View the version that is currently being displayed using the selected language, location and design.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the draft that is being displayed.</source>
      <translation>Edit the draft that is being displayed.</translation>
    </message>
    <message>
      <source>Publish</source>
      <translation>Publish</translation>
    </message>
    <message>
      <source>Publish the draft that is being displayed.</source>
      <translation>Publish the draft that is being displayed.</translation>
    </message>
    <message>
      <source>This version is not a draft and thus it can not be edited.</source>
      <translation>This version is not a draft and thus it can not be edited.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/contentstructuremenu</name>
    <message>
      <source>Fold/Unfold</source>
      <translation>Fold/Unfold</translation>
    </message>
    <message>
      <source>[%classname] Click on the icon to get a context sensitive menu.</source>
      <translation>[%classname] Click on the icon to get a context sensitive menu.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/error/kernel</name>
    <message>
      <source>The requested page could not be displayed. (1)</source>
      <translation>The requested page could not be displayed. (1)</translation>
    </message>
    <message>
      <source>The system is unable to display the requested page because of security issues.</source>
      <translation>The system is unable to display the requested page because of security issues.</translation>
    </message>
    <message>
      <source>Possible reasons</source>
      <translation>Possible reasons</translation>
    </message>
    <message>
      <source>Your account does not have the proper privileges to access the requested page.</source>
      <translation>Your account does not have the proper privileges to access the requested page.</translation>
    </message>
    <message>
      <source>You are not logged into the system. Please log in.</source>
      <translation>You are not logged into the system. Please log in.</translation>
    </message>
    <message>
      <source>The requested page does not exist. Try changing the URL.</source>
      <translation>The requested page does not exist. Try changing the URL.</translation>
    </message>
    <message>
      <source>The following permission setting is required</source>
      <translation>The following permission setting is required</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Click the &quot;Log in&quot; button in order to log in.</source>
      <translation>Click the &quot;Log in&quot; button in order to log in.</translation>
    </message>
    <message>
      <source>Login</source>
      <comment>Button</comment>
      <translation>Login</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (2)</source>
      <translation>The requested page could not be displayed. (2)</translation>
    </message>
    <message>
      <source>The resource you requested was not found.</source>
      <translation>The resource you requested was not found.</translation>
    </message>
    <message>
      <source>The ID number or the name of the resource was misspelled. Try changing the URL.</source>
      <translation>The ID number or the name of the resource was misspelled. Try changing the URL.</translation>
    </message>
    <message>
      <source>The resource is no longer available.</source>
      <translation>The resource is no longer available.</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (20)</source>
      <translation>The requested page could not be displayed. (20)</translation>
    </message>
    <message>
      <source>The requested address or module could not be found.</source>
      <translation>The requested address or module could not be found.</translation>
    </message>
    <message>
      <source>The address was misspelled. Try changing the URL.</source>
      <translation>The address was misspelled. Try changing the URL.</translation>
    </message>
    <message>
      <source>The name of the module was misspelled. Try changing the URL.</source>
      <translation>The name of the module was misspelled. Try changing the URL.</translation>
    </message>
    <message>
      <source>There is no &lt;%module&gt; module available on this site.</source>
      <translation>There is no &lt;%module&gt; module available on this site.</translation>
    </message>
    <message>
      <source>The site is using URL matching to determine which siteaccess to use, but the name of the siteaccess is missing from the URL. Try to add the name of the siteaccess, it should be specified before the name of the module.</source>
      <translation>The site is using URL matching to determine which siteaccess to use, but the name of the siteaccess is missing from the URL. Try to add the name of the siteaccess, it should be specified before the name of the module.</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (21)</source>
      <translation>The requested page could not be displayed. (21)</translation>
    </message>
    <message>
      <source>The requested view &lt;%view&gt; could not be found in the &lt;%module&gt; module.</source>
      <translation>The requested view &lt;%view&gt; could not be found in the &lt;%module&gt; module.</translation>
    </message>
    <message>
      <source>The name of the view was misspelled. Try changing the URL.</source>
      <translation>The name of the view was misspelled. Try changing the URL.</translation>
    </message>
    <message>
      <source>The &lt;%module&gt; module does not have a &lt;%view&gt; view.</source>
      <translation>The &lt;%module&gt; module does not have a &lt;%view&gt; view.</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (22)</source>
      <translation>The requested page could not be displayed. (22)</translation>
    </message>
    <message>
      <source>The requested view can not be accessed.</source>
      <translation>The requested view can not be accessed.</translation>
    </message>
    <message>
      <source>The &lt;%view&gt; within the &lt;%module&gt; is disabled and thus it can not be accessed.</source>
      <translation>The &lt;%view&gt; within the &lt;%module&gt; is disabled and thus it can not be accessed.</translation>
    </message>
    <message>
      <source>The requested module can not be accessed.</source>
      <translation>The requested module can not be accessed.</translation>
    </message>
    <message>
      <source>The &lt;%module&gt; module is disabled and thus it can not be accessed.</source>
      <translation>The &lt;%module&gt; module is disabled and thus it can not be accessed.</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (3)</source>
      <translation>The requested page could not be displayed. (3)</translation>
    </message>
    <message>
      <source>The requested object is not available.</source>
      <translation>The requested object is not available.</translation>
    </message>
    <message>
      <source>The ID number of the object is incorrect. Please check the URL for spelling mistakes.</source>
      <translation>The ID number of the object is incorrect. Please check the URL for spelling mistakes.</translation>
    </message>
    <message>
      <source>The object is no longer available.</source>
      <translation>The object is no longer available.</translation>
    </message>
    <message>
      <source>The requested page could not be displayed. (4)</source>
      <translation>The requested page could not be displayed. (4)</translation>
    </message>
    <message>
      <source>The requested object has been moved and thus it is no longer available at the specified address.</source>
      <translation>The requested object has been moved and thus it is no longer available at the specified address.</translation>
    </message>
    <message>
      <source>The system should automatically redirect you to the new location of the object.</source>
      <translation>The system should automatically redirect you to the new location of the object.</translation>
    </message>
    <message>
      <source>If redirection fails, please click on the following address: %url.</source>
      <translation>If redirection fails, please click on the following address: %url.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/error/shop</name>
    <message>
      <source>Not a product. (1)</source>
      <translation>Not a product. (1)</translation>
    </message>
    <message>
      <source>The requested object is not a product and cannot be used by the shop module..</source>
      <translation>The requested object is not a product and cannot be used by the shop module..</translation>
    </message>
    <message>
      <source>Incompatible product type. (2)</source>
      <translation>Incompatible product type. (2)</translation>
    </message>
    <message>
      <source>The requested object and current basket have incompatible price datatypes.</source>
      <translation>The requested object and current basket have incompatible price datatypes.</translation>
    </message>
    <message>
      <source>Invalid preferred currency. (3)</source>
      <translation>Invalid preferred currency. (3)</translation>
    </message>
    <message>
      <source>'%1' currency doesn't exist.</source>
      <translation>'%1' currency doesn't exist.</translation>
    </message>
    <message>
      <source>Invalid preferred currency. (4)</source>
      <translation>Invalid preferred currency. (4)</translation>
    </message>
    <message>
      <source>'%1' can't be used because it's inactive.</source>
      <translation>'%1' can't be used because it's inactive.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/infocollector/collectionlist</name>
    <message>
      <source>Information collected by &lt;%object_name&gt; [%collection_count]</source>
      <translation>Information collected by &lt;%object_name&gt; [%collection_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Collection ID</source>
      <translation>Collection ID</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Select collected information for removal.</source>
      <translation>Select collected information for removal.</translation>
    </message>
    <message>
      <source>Unknown user</source>
      <translation>Unknown user</translation>
    </message>
    <message>
      <source>No information has been collected by this object.</source>
      <translation>No information has been collected by this object.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected collection.</source>
      <translation>Remove selected collection.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/infocollector/confirmremoval</name>
    <message>
      <source>Confirm information collection removal</source>
      <translation>Confirm information collection removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the collected information?</source>
      <translation>Are you sure you want to remove the collected information?</translation>
    </message>
    <message>
      <source>%collections collection will be removed.</source>
      <translation>%collections collection will be removed.</translation>
    </message>
    <message>
      <source>%collections collections will be removed.</source>
      <translation>%collections collections will be removed.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/infocollector/overview</name>
    <message>
      <source>Objects that have collected information [%object_count]</source>
      <translation>Objects that have collected information [%object_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>First collection</source>
      <translation>First collection</translation>
    </message>
    <message>
      <source>Last collection</source>
      <translation>Last collection</translation>
    </message>
    <message>
      <source>Collections</source>
      <translation>Collections</translation>
    </message>
    <message>
      <source>Select collections for removal.</source>
      <translation>Select collections for removal.</translation>
    </message>
    <message>
      <source>section</source>
      <translation>section</translation>
    </message>
    <message>
      <source>There are no objects that have collected any information.</source>
      <translation>There are no objects that have collected any information.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove all information that was collected by the selected objects.</source>
      <translation>Remove all information that was collected by the selected objects.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/infocollector/view</name>
    <message>
      <source>Collection #%collection_id for &lt;%object_name&gt;</source>
      <translation>Collection #%collection_id for &lt;%object_name&gt;</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Unknown user</source>
      <translation>Unknown user</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove collection.</source>
      <translation>Remove collection.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/navigator</name>
    <message>
      <source>Previous</source>
      <translation>Previous</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/removenode</name>
    <message>
      <source>Remove node?</source>
      <translation>Remove node?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove %1 from node %2?</source>
      <translation>Are you sure you want to remove %1 from node %2?</translation>
    </message>
    <message>
      <source>Removing this assignment will also remove its %1 children.</source>
      <translation>Removing this assignment will also remove its %1 children.</translation>
    </message>
    <message>
      <source>Note</source>
      <translation>Note</translation>
    </message>
    <message>
      <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
      <translation>Removed nodes can be retrieved later. You will find them in the trash.</translation>
    </message>
    <message>
      <source>Removing node assignment of %1</source>
      <translation>Removing node assignment of %1</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/removeobject</name>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Confirm translation removal</source>
      <translation>Confirm translation removal</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel the removal of translations.</source>
      <translation>Cancel the removal of translations.</translation>
    </message>
    <message>
      <source>Please choose the location where you wish to restore &lt;%name&gt;.</source>
      <translation>Please choose the location where you wish to restore &lt;%name&gt;.</translation>
    </message>
    <message>
      <source>Confirm location removal</source>
      <translation>Confirm location removal</translation>
    </message>
    <message>
      <source>Insufficient permissions</source>
      <translation>Insufficient permissions</translation>
    </message>
    <message>
      <source>Some of the items that are about to be removed contain sub items.</source>
      <translation>Some of the items that are about to be removed contain sub items.</translation>
    </message>
    <message>
      <source>Some of the subtrees or objects selected for removal are used by other objects. Select the menu from the content tree, and</source>
      <translation>Some of the subtrees or objects selected for removal are used by other objects. Select the menu from the content tree, and</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Advanced</translation>
    </message>
    <message>
      <source>Reverse related for subtree</source>
      <translation>Reverse related for subtree</translation>
    </message>
    <message>
      <source>The lines marked with red contain more than the maximum possible nodes for subtree removing and will not be deleted. You can remove this subtree using Subtree Remove script.</source>
      <translation>The lines marked with red contain more than the maximum possible nodes for subtree removing and will not be deleted. You can remove this subtree using Subtree Remove script.</translation>
    </message>
    <message>
      <source>Removing the items will also result in the removal of their sub items.</source>
      <translation>Removing the items will also result in the removal of their sub items.</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the items along with their contents?</source>
      <translation>Are you sure you want to remove the items along with their contents?</translation>
    </message>
    <message>
      <source>The lines marked with red contain items that you do not have permissions to remove.</source>
      <translation>The lines marked with red contain items that you do not have permissions to remove.</translation>
    </message>
    <message>
      <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
      <translation>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</translation>
    </message>
    <message>
      <source>Some of the objects selected for removal are used by other objects. Select the menu from the content tree, and</source>
      <translation>Some of the objects selected for removal are used by other objects. Select the menu from the content tree, and</translation>
    </message>
    <message>
      <source>Item</source>
      <translation>Item</translation>
    </message>
    <message>
      <source>Sub items</source>
      <translation>Sub items</translation>
    </message>
    <message>
      <source>If &quot;Move to trash&quot; is checked, the items will be moved to the trash instead of being permanently deleted.</source>
      <translation>If &quot;Move to trash&quot; is checked, the items will be moved to the trash instead of being permanently deleted.</translation>
    </message>
    <message>
      <source>Move to trash</source>
      <translation>Move to trash</translation>
    </message>
    <message>
      <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
      <translation>You can not continue because you do not have permissions to remove some of the selected locations.</translation>
    </message>
    <message>
      <source>Cancel the removal of locations.</source>
      <translation>Cancel the removal of locations.</translation>
    </message>
    <message>
      <source>The system will let you restore the object &lt;%name&gt;. Please choose where you wish to restore it to.</source>
      <translation>The system will let you restore the object &lt;%name&gt;. Please choose where you wish to restore it to.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/view</name>
    <message>
      <source>Two level index for &lt;%node_name&gt;</source>
      <translation>Two level index for &lt;%node_name&gt;</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/view/embed</name>
    <message>
      <source> - You do not have sufficient permissions to view this object</source>
      <translation> - You do not have sufficient permissions to view this object</translation>
    </message>
    <message>
      <source>You do not have sufficient permissions to view this object</source>
      <translation>You do not have sufficient permissions to view this object</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/view/full</name>
    <message>
      <source>Hide preview of content.</source>
      <translation>Hide preview of content.</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Show preview of content.</source>
      <translation>Show preview of content.</translation>
    </message>
    <message>
      <source>Hide details.</source>
      <translation>Hide details.</translation>
    </message>
    <message>
      <source>Details</source>
      <translation>Details</translation>
    </message>
    <message>
      <source>Show details.</source>
      <translation>Show details.</translation>
    </message>
    <message>
      <source>Hide available translations.</source>
      <translation>Hide available translations.</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Show available translations.</source>
      <translation>Show available translations.</translation>
    </message>
    <message>
      <source>Hide location overview.</source>
      <translation>Hide location overview.</translation>
    </message>
    <message>
      <source>Locations</source>
      <translation>Locations</translation>
    </message>
    <message>
      <source>Show location overview.</source>
      <translation>Show location overview.</translation>
    </message>
    <message>
      <source>Hide relation overview.</source>
      <translation>Hide relation overview.</translation>
    </message>
    <message>
      <source>Relations</source>
      <translation>Relations</translation>
    </message>
    <message>
      <source>Show relation overview.</source>
      <translation>Show relation overview.</translation>
    </message>
    <message>
      <source>Hide role overview.</source>
      <translation>Hide role overview.</translation>
    </message>
    <message>
      <source>Roles</source>
      <translation>Roles</translation>
    </message>
    <message>
      <source>Show role overview.</source>
      <translation>Show role overview.</translation>
    </message>
    <message>
      <source>Hide policy overview.</source>
      <translation>Hide policy overview.</translation>
    </message>
    <message>
      <source>Policies</source>
      <translation>Policies</translation>
    </message>
    <message>
      <source>Show policy overview.</source>
      <translation>Show policy overview.</translation>
    </message>
    <message>
      <source>Up one level.</source>
      <translation>Up one level.</translation>
    </message>
    <message>
      <source>Sub items [%children_count]</source>
      <translation>Sub items [%children_count]</translation>
    </message>
    <message>
      <source>Show 10 items per page.</source>
      <translation>Show 10 items per page.</translation>
    </message>
    <message>
      <source>Show 50 items per page.</source>
      <translation>Show 50 items per page.</translation>
    </message>
    <message>
      <source>Show 25 items per page.</source>
      <translation>Show 25 items per page.</translation>
    </message>
    <message>
      <source>Display sub items using a simple list.</source>
      <translation>Display sub items using a simple list.</translation>
    </message>
    <message>
      <source>List</source>
      <translation>List</translation>
    </message>
    <message>
      <source>Thumbnail</source>
      <translation>Thumbnail</translation>
    </message>
    <message>
      <source>Display sub items using a detailed list.</source>
      <translation>Display sub items using a detailed list.</translation>
    </message>
    <message>
      <source>Detailed</source>
      <translation>Detailed</translation>
    </message>
    <message>
      <source>Display sub items as thumbnails.</source>
      <translation>Display sub items as thumbnails.</translation>
    </message>
    <message>
      <source>The current item does not contain any sub items.</source>
      <translation>The current item does not contain any sub items.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove the selected items from the list above.</source>
      <translation>Remove the selected items from the list above.</translation>
    </message>
    <message>
      <source>You do not have permissions to remove any of the items from the list above.</source>
      <translation>You do not have permissions to remove any of the items from the list above.</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
    <message>
      <source>Apply changes to the priorities of the items in the list above.</source>
      <translation>Apply changes to the priorities of the items in the list above.</translation>
    </message>
    <message>
      <source>You can not update the priorities because you do not have permissions to edit the current item or because a non-priority sorting method is used.</source>
      <translation>You can not update the priorities because you do not have permissions to edit the current item or because a non-priority sorting method is used.</translation>
    </message>
    <message>
      <source>Use this menu to select the type of item you wish to create and click the &quot;Create here&quot; button. The item will be created within the current location.</source>
      <translation>Use this menu to select the type of item you wish to create and click the &quot;Create here&quot; button. The item will be created within the current location.</translation>
    </message>
    <message>
      <source>Use this menu to select the language you wish use for the creation and click the &quot;Create here&quot; button. The item will be created within the current location.</source>
      <translation>Use this menu to select the language you wish use for the creation and click the &quot;Create here&quot; button. The item will be created within the current location.</translation>
    </message>
    <message>
      <source>Create here</source>
      <translation>Create here</translation>
    </message>
    <message>
      <source>Create a new item within the current location. Use the menu on the left to select the type of the item.</source>
      <translation>Create a new item within the current location. Use the menu on the left to select the type of the item.</translation>
    </message>
    <message>
      <source>Not available</source>
      <translation>Not available</translation>
    </message>
    <message>
      <source>You do not have permissions to create new items within the current location.</source>
      <translation>You do not have permissions to create new items within the current location.</translation>
    </message>
    <message>
      <source>Sorting</source>
      <translation>Sorting</translation>
    </message>
    <message>
      <source>Class identifier</source>
      <translation>Class identifier</translation>
    </message>
    <message>
      <source>Class name</source>
      <translation>Class name</translation>
    </message>
    <message>
      <source>Depth</source>
      <translation>Depth</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>You can not set the sorting method for the current location because you do not have permissions to edit the current item.</source>
      <translation>You can not set the sorting method for the current location because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>Use these controls to set the sorting method for the sub items of the current location.</source>
      <translation>Use these controls to set the sorting method for the sub items of the current location.</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Visibility</source>
      <translation>Visibility</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
      <translation>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</translation>
    </message>
    <message>
      <source>You do not have permissions to remove this item.</source>
      <translation>You do not have permissions to remove this item.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Use the priority fields to control the order in which the items appear. Use positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
      <translation>Use the priority fields to control the order in which the items appear. Use positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</translation>
    </message>
    <message>
      <source>You are not allowed to update the priorities because you do not have permissions to edit &lt;%node_name&gt;.</source>
      <translation>You are not allowed to update the priorities because you do not have permissions to edit &lt;%node_name&gt;.</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Create a copy of &lt;%child_name&gt;.</source>
      <translation>Create a copy of &lt;%child_name&gt;.</translation>
    </message>
    <message>
      <source>You can not make a copy of &lt;%child_name&gt; because you do not have create permissions for &lt;%node_name&gt;.</source>
      <translation>You can not make a copy of &lt;%child_name&gt; because you do not have create permissions for &lt;%node_name&gt;.</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Move</translation>
    </message>
    <message>
      <source>Move &lt;%child_name&gt; to another location.</source>
      <translation>Move &lt;%child_name&gt; to another location.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit &lt;%child_name&gt;.</source>
      <translation>Edit &lt;%child_name&gt;.</translation>
    </message>
    <message>
      <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
      <translation>You do not have permissions to edit &lt;%child_name&gt;.</translation>
    </message>
    <message>
      <source>You do not have permissions remove this item.</source>
      <translation>You do not have permissions remove this item.</translation>
    </message>
    <message>
      <source>(disabled)</source>
      <translation>(disabled)</translation>
    </message>
    <message>
      <source>You do not have permissions to edit %child_name.</source>
      <translation>You do not have permissions to edit %child_name.</translation>
    </message>
    <message>
      <source>Published at</source>
      <translation>Published at</translation>
    </message>
    <message>
      <source>Node ID</source>
      <translation>Node ID</translation>
    </message>
    <message>
      <source>Object ID</source>
      <translation>Object ID</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>The information could not be collected.</source>
      <translation>The information could not be collected.</translation>
    </message>
    <message>
      <source>Required data is either missing or is invalid</source>
      <translation>Required data is either missing or is invalid</translation>
    </message>
    <message>
      <source>Locations [%locations]</source>
      <translation>Locations [%locations]</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Sub items</source>
      <translation>Sub items</translation>
    </message>
    <message>
      <source>Main</source>
      <translation>Main</translation>
    </message>
    <message>
      <source>Select location for removal.</source>
      <translation>Select location for removal.</translation>
    </message>
    <message>
      <source>This location can not be removed either because you do not have permissions to remove it or because it is currently being displayed.</source>
      <translation>This location can not be removed either because you do not have permissions to remove it or because it is currently being displayed.</translation>
    </message>
    <message>
      <source>down</source>
      <translation>down</translation>
    </message>
    <message>
      <source>up</source>
      <translation>up</translation>
    </message>
    <message>
      <source>Hidden</source>
      <translation>Hidden</translation>
    </message>
    <message>
      <source>Make location and all sub items visible.</source>
      <translation>Make location and all sub items visible.</translation>
    </message>
    <message>
      <source>Reveal</source>
      <translation>Reveal</translation>
    </message>
    <message>
      <source>Hidden by superior</source>
      <translation>Hidden by superior</translation>
    </message>
    <message>
      <source>Hide location and all sub items.</source>
      <translation>Hide location and all sub items.</translation>
    </message>
    <message>
      <source>Hide</source>
      <translation>Hide</translation>
    </message>
    <message>
      <source>Visible</source>
      <translation>Visible</translation>
    </message>
    <message>
      <source>Use these radio buttons to select the desired main location.</source>
      <translation>Use these radio buttons to select the desired main location.</translation>
    </message>
    <message>
      <source>The item being displayed has only one location and thus it does not make sense to set it.</source>
      <translation>The item being displayed has only one location and thus it does not make sense to set it.</translation>
    </message>
    <message>
      <source>You can not set the main location because you do not have permissions to edit the item being displayed.</source>
      <translation>You can not set the main location because you do not have permissions to edit the item being displayed.</translation>
    </message>
    <message>
      <source>Remove selected locations from the list above.</source>
      <translation>Remove selected locations from the list above.</translation>
    </message>
    <message>
      <source>There is no removable location.</source>
      <translation>There is no removable location.</translation>
    </message>
    <message>
      <source>Add locations</source>
      <translation>Add locations</translation>
    </message>
    <message>
      <source>Add one or more new locations.</source>
      <translation>Add one or more new locations.</translation>
    </message>
    <message>
      <source>It is not possible to add locations to a top level node.</source>
      <translation>It is not possible to add locations to a top level node.</translation>
    </message>
    <message>
      <source>You can not remove any locations because you do not have permissions to edit the current item.</source>
      <translation>You can not remove any locations because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>You can not add new locations because you do not have permissions to edit the current item.</source>
      <translation>You can not add new locations because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>Set main</source>
      <translation>Set main</translation>
    </message>
    <message>
      <source>Select the desired main location using the radio buttons above and click this button to store the setting.</source>
      <translation>Select the desired main location using the radio buttons above and click this button to store the setting.</translation>
    </message>
    <message>
      <source>You can not set the main location because there is only one location present.</source>
      <translation>You can not set the main location because there is only one location present.</translation>
    </message>
    <message>
      <source>You can not set the main location because you do not have permissions to edit the current item.</source>
      <translation>You can not set the main location because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>Up one level</source>
      <translation>Up one level</translation>
    </message>
    <message>
      <source>The &lt;%class_name&gt; class is not configured to contain any sub items.</source>
      <translation>The &lt;%class_name&gt; class is not configured to contain any sub items.</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Another language</source>
      <translation>Another language</translation>
    </message>
    <message>
      <source>Edit the contents of this item.</source>
      <translation>Edit the contents of this item.</translation>
    </message>
    <message>
      <source>You do not have permissions to edit this item.</source>
      <translation>You do not have permissions to edit this item.</translation>
    </message>
    <message>
      <source>Move this item to another location.</source>
      <translation>Move this item to another location.</translation>
    </message>
    <message>
      <source>You do not have permissions to move this item to another location.</source>
      <translation>You do not have permissions to move this item to another location.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove this item.</source>
      <translation>Remove this item.</translation>
    </message>
    <message>
      <source>Available policies [%policy_count]</source>
      <translation>Available policies [%policy_count]</translation>
    </message>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Limitation</source>
      <translation>Limitation</translation>
    </message>
    <message>
      <source>limited to %limitation_identifier %limitation_value</source>
      <translation>limited to %limitation_identifier %limitation_value</translation>
    </message>
    <message>
      <source>all modules</source>
      <translation>all modules</translation>
    </message>
    <message>
      <source>all functions</source>
      <translation>all functions</translation>
    </message>
    <message>
      <source>No limitations</source>
      <translation>No limitations</translation>
    </message>
    <message>
      <source>There are no available policies.</source>
      <translation>There are no available policies.</translation>
    </message>
    <message>
      <source>Relations [%relation_count]</source>
      <translation>Relations [%relation_count]</translation>
    </message>
    <message>
      <source>Related objects [%related_objects_count]</source>
      <translation>Related objects [%related_objects_count]</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>The item being viewed does not make use of any other objects.</source>
      <translation>The item being viewed does not make use of any other objects.</translation>
    </message>
    <message>
      <source>Reverse related objects [%related_objects_count]</source>
      <translation>Reverse related objects [%related_objects_count]</translation>
    </message>
    <message>
      <source>The item being viewed is not in use by any other objects.</source>
      <translation>The item being viewed is not in use by any other objects.</translation>
    </message>
    <message>
      <source>Assigned roles [%roles_count]</source>
      <translation>Assigned roles [%roles_count]</translation>
    </message>
    <message>
      <source>No limitation</source>
      <translation>No limitation</translation>
    </message>
    <message>
      <source>Edit role.</source>
      <translation>Edit role.</translation>
    </message>
    <message>
      <source>There are no assigned roles.</source>
      <translation>There are no assigned roles.</translation>
    </message>
    <message>
      <source>Translations [%translations]</source>
      <translation>Translations [%translations]</translation>
    </message>
    <message>
      <source>Existing languages</source>
      <translation>Existing languages</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>View translation.</source>
      <translation>View translation.</translation>
    </message>
    <message>
      <source>Use these radio buttons to select the desired main language.</source>
      <translation>Use these radio buttons to select the desired main language.</translation>
    </message>
    <message>
      <source>Edit in &lt;%language_name&gt;.</source>
      <translation>Edit in &lt;%language_name&gt;.</translation>
    </message>
    <message>
      <source>Remove selected languages from the list above.</source>
      <translation>Remove selected languages from the list above.</translation>
    </message>
    <message>
      <source>There is no removable language.</source>
      <translation>There is no removable language.</translation>
    </message>
    <message>
      <source>You can not remove any language because you do not have permissions to edit the current item.</source>
      <translation>You can not remove any language because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>Select the desired main language using the radio buttons above and click this button to store the setting.</source>
      <translation>Select the desired main language using the radio buttons above and click this button to store the setting.</translation>
    </message>
    <message>
      <source>You can not change the main language because the object is not translated to any other languages.</source>
      <translation>You can not change the main language because the object is not translated to any other languages.</translation>
    </message>
    <message>
      <source>You can not change the main language because you do not have permissions to edit the current item.</source>
      <translation>You can not change the main language because you do not have permissions to edit the current item.</translation>
    </message>
    <message>
      <source>Use the main language if there is no prioritized translation.</source>
      <translation>Use the main language if there is no prioritized translation.</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Use this button to store the value of the checkbox above.</source>
      <translation>Use this button to store the value of the checkbox above.</translation>
    </message>
    <message>
      <source>You do not have sufficient permissions to change this setting.</source>
      <translation>You do not have sufficient permissions to change this setting.</translation>
    </message>
    <message>
      <source>Hide object relation overview.</source>
      <translation>Hide object relation overview.</translation>
    </message>
    <message>
      <source>Show object relation overview.</source>
      <translation>Show object relation overview.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/view/line</name>
    <message>
      <source>Click on the icon to get a context sensitive menu.</source>
      <translation>Click on the icon to get a context sensitive menu.</translation>
    </message>
    <message>
      <source>Node ID: %node_id Visibility: %node_visibility</source>
      <translation>Node ID: %node_id Visibility: %node_visibility</translation>
    </message>
  </context>
  <context>
    <name>design/admin/node/view/thumbnail</name>
    <message>
      <source>[%classname] Click on the icon to get a context sensitive menu.</source>
      <translation>[%classname] Click on the icon to get a context sensitive menu.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/addingresult</name>
    <message>
      <source>Add to my notifications</source>
      <translation>Add to my notifications</translation>
    </message>
    <message>
      <source>Notification for node &lt;%node_name&gt; already exists.</source>
      <translation>Notification for node &lt;%node_name&gt; already exists.</translation>
    </message>
    <message>
      <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
      <translation>Notification for node &lt;%node_name&gt; was added successfully.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/collaboration</name>
    <message>
      <source>Collaboration notification</source>
      <translation>Collaboration notification</translation>
    </message>
    <message>
      <source>Choose which collaboration items you wish to get notifications for.</source>
      <translation>Choose which collaboration items you wish to get notifications for.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/handler/ezgeneraldigest/settings/edit</name>
    <message>
      <source>Receive all messages combined in one digest</source>
      <translation>Receive all messages combined in one digest</translation>
    </message>
    <message>
      <source>Receive digests</source>
      <translation>Receive digests</translation>
    </message>
    <message>
      <source>Daily, at</source>
      <translation>Daily, at</translation>
    </message>
    <message>
      <source>Once per week, on </source>
      <translation>Once per week, on </translation>
    </message>
    <message>
      <source>Once per month, on day number</source>
      <translation>Once per month, on day number</translation>
    </message>
    <message>
      <source>If day number is larger than the number of days within the current month, the last day of the current month will be used.</source>
      <translation>If day number is larger than the number of days within the current month, the last day of the current month will be used.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/handler/ezsubtree/settings/edit</name>
    <message>
      <source>My item notifications [%notification_count]</source>
      <translation>My item notifications [%notification_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Select item for removal.</source>
      <translation>Select item for removal.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>You have not subscribed to receive notifications about any items.</source>
      <translation>You have not subscribed to receive notifications about any items.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected items.</source>
      <translation>Remove selected items.</translation>
    </message>
    <message>
      <source>Add items</source>
      <translation>Add items</translation>
    </message>
    <message>
      <source>Add items to your personal notification list.</source>
      <translation>Add items to your personal notification list.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/runfilter</name>
    <message>
      <source>The notification filter processed all available notification events.</source>
      <translation>The notification filter processed all available notification events.</translation>
    </message>
    <message>
      <source>The notification time event was spawned.</source>
      <translation>The notification time event was spawned.</translation>
    </message>
    <message>
      <source>Notification</source>
      <translation>Notification</translation>
    </message>
    <message>
      <source>Run notification filter</source>
      <translation>Run notification filter</translation>
    </message>
    <message>
      <source>Spawn time event</source>
      <translation>Spawn time event</translation>
    </message>
  </context>
  <context>
    <name>design/admin/notification/settings</name>
    <message>
      <source>My notification settings</source>
      <translation>My notification settings</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
  </context>
  <context>
    <name>design/admin/package</name>
    <message>
      <source>Please provide information on the changes.</source>
      <translation>Please provide information on the changes.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Changes</translation>
    </message>
    <message>
      <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) at the beginning of the line. The change will continue to the next change marker.</source>
      <translation>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) at the beginning of the line. The change will continue to the next change marker.</translation>
    </message>
    <message>
      <source>Please provide some basic information for your package.</source>
      <translation>Please provide some basic information for your package.</translation>
    </message>
    <message>
      <source>Package name</source>
      <translation>Package name</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Licence</source>
      <translation>Licence</translation>
    </message>
    <message>
      <source>Package host</source>
      <translation>Package host</translation>
    </message>
    <message>
      <source>Packager</source>
      <translation>Packager</translation>
    </message>
    <message>
      <source>Please provide information on the maintainer of the package.</source>
      <translation>Please provide information on the maintainer of the package.</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>Maintainer name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>E-Mail</source>
      <translation>E-Mail</translation>
    </message>
    <message>
      <source>Role</source>
      <comment>Maintainer role</comment>
      <translation>Role</translation>
    </message>
    <message>
      <source>Create package</source>
      <translation>Create package</translation>
    </message>
    <message>
      <source>Available wizards</source>
      <translation>Available wizards</translation>
    </message>
    <message>
      <source>Choose one of the following wizards for creating a package</source>
      <translation>Choose one of the following wizards for creating a package</translation>
    </message>
    <message>
      <source>Specify export properties. The default settings will most likely be suitable for your needs.</source>
      <translation>Specify export properties. The default settings will most likely be suitable for your needs.</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Miscellaneous</translation>
    </message>
    <message>
      <source>Include class definitions.</source>
      <translation>Include class definitions.</translation>
    </message>
    <message>
      <source>Include templates related exported objects.</source>
      <translation>Include templates related exported objects.</translation>
    </message>
    <message>
      <source>Select templates from the following siteaccesses</source>
      <translation>Select templates from the following siteaccesses</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>All versions</source>
      <translation>All versions</translation>
    </message>
    <message>
      <source>Languages</source>
      <translation>Languages</translation>
    </message>
    <message>
      <source>Select languages to export</source>
      <translation>Select languages to export</translation>
    </message>
    <message>
      <source>Node assignments</source>
      <translation>Node assignments</translation>
    </message>
    <message>
      <source>Keep all in selected nodes</source>
      <translation>Keep all in selected nodes</translation>
    </message>
    <message>
      <source>Main only</source>
      <translation>Main only</translation>
    </message>
    <message>
      <source>Related objects</source>
      <translation>Related objects</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Please choose objects you wish to include in the package.</source>
      <translation>Please choose objects you wish to include in the package.</translation>
    </message>
    <message>
      <source>Selected nodes</source>
      <translation>Selected nodes</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Export type</source>
      <translation>Export type</translation>
    </message>
    <message>
      <source>There are currently no objects selected for exportation</source>
      <translation>There are currently no objects selected for exportation</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add subtree</source>
      <translation>Add subtree</translation>
    </message>
    <message>
      <source>Add node</source>
      <translation>Add node</translation>
    </message>
    <message>
      <source>Please select the site CSS file to be included in the package.</source>
      <translation>Please select the site CSS file to be included in the package.</translation>
    </message>
    <message>
      <source>Please select the classes CSS file to be included in the package.</source>
      <translation>Please select the classes CSS file to be included in the package.</translation>
    </message>
    <message>
      <source>Select an image file to be included in the package and click Next.
Click &quot;Next&quot; without choosing an image to continue to the next step.</source>
      <translation>Select an image file to be included in the package and click Next.
Click &quot;Next&quot; without choosing an image to continue to the next step.</translation>
    </message>
    <message>
      <source>Currently added image files</source>
      <translation>Currently added image files</translation>
    </message>
    <message>
      <source>Package wizard: %wizardname</source>
      <translation>Package wizard: %wizardname</translation>
    </message>
    <message>
      <source>Install package</source>
      <translation>Install package</translation>
    </message>
    <message>
      <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
      <translation>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</translation>
    </message>
    <message>
      <source>Install items</source>
      <translation>Install items</translation>
    </message>
    <message>
      <source>Skip installation</source>
      <translation>Skip installation</translation>
    </message>
    <message>
      <source>Package install wizard: %wizardname</source>
      <translation>Package install wizard: %wizardname</translation>
    </message>
    <message>
      <source>Next %arrowright</source>
      <translation>Next %arrowright</translation>
    </message>
    <message>
      <source>Continue</source>
      <translation>Continue</translation>
    </message>
    <message>
      <source>Uninstall package</source>
      <translation>Uninstall package</translation>
    </message>
    <message>
      <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
      <translation>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</translation>
    </message>
    <message>
      <source>Uninstall items</source>
      <translation>Uninstall items</translation>
    </message>
    <message>
      <source>Skip uninstallation</source>
      <translation>Skip uninstallation</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Upload package</source>
      <translation>Upload package</translation>
    </message>
    <message>
      <source>Select the file containing your package and click the upload button</source>
      <translation>Select the file containing your package and click the upload button</translation>
    </message>
    <message>
      <source>Import package</source>
      <translation>Import package</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Installed</translation>
    </message>
    <message>
      <source>Not installed</source>
      <translation>Not installed</translation>
    </message>
    <message>
      <source>Imported</source>
      <translation>Imported</translation>
    </message>
    <message>
      <source>Files [%collectionname]</source>
      <translation>Files [%collectionname]</translation>
    </message>
    <message>
      <source>Details</source>
      <translation>Details</translation>
    </message>
    <message>
      <source>Uninstall</source>
      <translation>Uninstall</translation>
    </message>
    <message>
      <source>Install</source>
      <translation>Install</translation>
    </message>
    <message>
      <source>Export to file</source>
      <translation>Export to file</translation>
    </message>
    <message>
      <source>State</source>
      <translation>State</translation>
    </message>
    <message>
      <source>Maintainers</source>
      <translation>Maintainers</translation>
    </message>
    <message>
      <source>Regarding eZ publish package '%packagename'</source>
      <translation>Regarding eZ publish package '%packagename'</translation>
    </message>
    <message>
      <source>Send e-mail to the maintainer</source>
      <translation>Send e-mail to the maintainer</translation>
    </message>
    <message>
      <source>Documents</source>
      <translation>Documents</translation>
    </message>
    <message>
      <source>Changelog</source>
      <translation>Changelog</translation>
    </message>
    <message>
      <source>File list</source>
      <translation>File list</translation>
    </message>
  </context>
  <context>
    <name>design/admin/package/list</name>
    <message>
      <source>Remove section?</source>
      <translation>Remove section?</translation>
    </message>
    <message>
      <source>Removal of packages</source>
      <translation>Removal of packages</translation>
    </message>
    <message>
      <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
      <translation>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Package removal was canceled.</source>
      <translation>Package removal was canceled.</translation>
    </message>
    <message>
      <source>Packages</source>
      <translation>Packages</translation>
    </message>
    <message>
      <source>Repository</source>
      <translation>Repository</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>Change repository</source>
      <translation>Change repository</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Installed</translation>
    </message>
    <message>
      <source>Not installed</source>
      <translation>Not installed</translation>
    </message>
    <message>
      <source>Imported</source>
      <translation>Imported</translation>
    </message>
    <message>
      <source>There are no packages matching the selected repository.</source>
      <translation>There are no packages matching the selected repository.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Import new package</source>
      <translation>Import new package</translation>
    </message>
    <message>
      <source>Create new package</source>
      <translation>Create new package</translation>
    </message>
  </context>
  <context>
    <name>design/admin/pagelayout</name>
    <message>
      <source>Content structure</source>
      <translation>Content structure</translation>
    </message>
    <message>
      <source>Manage the main content structure of the site.</source>
      <translation>Manage the main content structure of the site.</translation>
    </message>
    <message>
      <source>Media library</source>
      <translation>Media library</translation>
    </message>
    <message>
      <source>Manage images, files, documents, etc.</source>
      <translation>Manage images, files, documents, etc.</translation>
    </message>
    <message>
      <source>User accounts</source>
      <translation>User accounts</translation>
    </message>
    <message>
      <source>Manage users, user groups and permission settings.</source>
      <translation>Manage users, user groups and permission settings.</translation>
    </message>
    <message>
      <source>Webshop</source>
      <translation>Webshop</translation>
    </message>
    <message>
      <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
      <translation>Manage customers, orders, discounts and GST types; view sales statistics.</translation>
    </message>
    <message>
      <source>Design</source>
      <translation>Design</translation>
    </message>
    <message>
      <source>Manage templates, menus, toolbars and other things related to appearence.</source>
      <translation>Manage templates, menus, toolbars and other things related to appearence.</translation>
    </message>
    <message>
      <source>Setup</source>
      <translation>Setup</translation>
    </message>
    <message>
      <source>Configure settings and manage advanced functionality.</source>
      <translation>Configure settings and manage advanced functionality.</translation>
    </message>
    <message>
      <source>My account</source>
      <translation>My account</translation>
    </message>
    <message>
      <source>Manage items and settings that belong to your account.</source>
      <translation>Manage items and settings that belong to your account.</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>Search all content.</source>
      <translation>Search all content.</translation>
    </message>
    <message>
      <source>All content</source>
      <translation>All content</translation>
    </message>
    <message>
      <source>Search only from the current location.</source>
      <translation>Search only from the current location.</translation>
    </message>
    <message>
      <source>Current location</source>
      <translation>Current location</translation>
    </message>
    <message>
      <source>The same location</source>
      <translation>The same location</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Advanced</translation>
    </message>
    <message>
      <source>Advanced search.</source>
      <translation>Advanced search.</translation>
    </message>
    <message>
      <source>Hide bookmarks.</source>
      <translation>Hide bookmarks.</translation>
    </message>
    <message>
      <source>Manage your personal bookmarks.</source>
      <translation>Manage your personal bookmarks.</translation>
    </message>
    <message>
      <source>Bookmarks</source>
      <translation>Bookmarks</translation>
    </message>
    <message>
      <source>[%classname] Click on the icon to get a context sensitive menu.</source>
      <translation>[%classname] Click on the icon to get a context sensitive menu.</translation>
    </message>
    <message>
      <source>Add to bookmarks</source>
      <translation>Add to bookmarks</translation>
    </message>
    <message>
      <source>Add the current item to your bookmarks.</source>
      <translation>Add the current item to your bookmarks.</translation>
    </message>
    <message>
      <source>Show bookmarks.</source>
      <translation>Show bookmarks.</translation>
    </message>
    <message>
      <source>Hide clear cache menu.</source>
      <translation>Hide clear cache menu.</translation>
    </message>
    <message>
      <source>Cache management page</source>
      <translation>Cache management page</translation>
    </message>
    <message>
      <source>Clear cache</source>
      <translation>Clear cache</translation>
    </message>
    <message>
      <source>Show clear cache menu.</source>
      <translation>Show clear cache menu.</translation>
    </message>
    <message>
      <source>Current user</source>
      <translation>Current user</translation>
    </message>
    <message>
      <source>Change name, e-mail, password, etc.</source>
      <translation>Change name, e-mail, password, etc.</translation>
    </message>
    <message>
      <source>Change information</source>
      <translation>Change information</translation>
    </message>
    <message>
      <source>Change user info</source>
      <translation>Change user info</translation>
    </message>
    <message>
      <source>Change password for &lt;%username&gt;.</source>
      <translation>Change password for &lt;%username&gt;.</translation>
    </message>
    <message>
      <source>Change password</source>
      <translation>Change password</translation>
    </message>
    <message>
      <source>There is %basket_count item in the shopping basket.</source>
      <translation>There is %basket_count item in the shopping basket.</translation>
    </message>
    <message>
      <source>Shopping basket (%basket_count)</source>
      <translation>Shopping basket (%basket_count)</translation>
    </message>
    <message>
      <source>There are %basket_count items in the shopping basket.</source>
      <translation>There are %basket_count items in the shopping basket.</translation>
    </message>
    <message>
      <source>Logout from the system.</source>
      <translation>Logout from the system.</translation>
    </message>
    <message>
      <source>Logout</source>
      <translation>Logout</translation>
    </message>
    <message>
      <source>Quick settings</source>
      <translation>Quick settings</translation>
    </message>
    <message>
      <source>Hide quick settings</source>
      <translation>Hide quick settings</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/content/menu</name>
    <message>
      <source>Hide content structure.</source>
      <translation>Hide content structure.</translation>
    </message>
    <message>
      <source>Content structure</source>
      <translation>Content structure</translation>
    </message>
    <message>
      <source>Show content structure.</source>
      <translation>Show content structure.</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>View and manage the contents of the trash bin.</source>
      <translation>View and manage the contents of the trash bin.</translation>
    </message>
    <message>
      <source>Change the left menu width to small size.</source>
      <translation>Change the left menu width to small size.</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Small</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Medium</translation>
    </message>
    <message>
      <source>Change the left menu width to large size.</source>
      <translation>Change the left menu width to large size.</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Large</translation>
    </message>
    <message>
      <source>Change the left menu width to medium size.</source>
      <translation>Change the left menu width to medium size.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/media/menu</name>
    <message>
      <source>Media library</source>
      <translation>Media library</translation>
    </message>
    <message>
      <source>View and manage the contents of the trash bin.</source>
      <translation>View and manage the contents of the trash bin.</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>Change the left menu width to small size.</source>
      <translation>Change the left menu width to small size.</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Small</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Medium</translation>
    </message>
    <message>
      <source>Change the left menu width to large size.</source>
      <translation>Change the left menu width to large size.</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Large</translation>
    </message>
    <message>
      <source>Change the left menu width to medium size.</source>
      <translation>Change the left menu width to medium size.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/my/menu</name>
    <message>
      <source>My account</source>
      <translation>My account</translation>
    </message>
    <message>
      <source>My drafts</source>
      <translation>My drafts</translation>
    </message>
    <message>
      <source>My pending items</source>
      <translation>My pending items</translation>
    </message>
    <message>
      <source>My notification settings</source>
      <translation>My notification settings</translation>
    </message>
    <message>
      <source>My bookmarks</source>
      <translation>My bookmarks</translation>
    </message>
    <message>
      <source>Collaboration</source>
      <translation>Collaboration</translation>
    </message>
    <message>
      <source>Change password</source>
      <translation>Change password</translation>
    </message>
    <message>
      <source>My shopping basket</source>
      <translation>My shopping basket</translation>
    </message>
    <message>
      <source>My wish list</source>
      <translation>My wish list</translation>
    </message>
    <message>
      <source>Edit mode settings</source>
      <translation>Edit mode settings</translation>
    </message>
    <message>
      <source>Locations</source>
      <translation>Locations</translation>
    </message>
    <message>
      <source>on</source>
      <translation>on</translation>
    </message>
    <message>
      <source>Disable location window when editing content.</source>
      <translation>Disable location window when editing content.</translation>
    </message>
    <message>
      <source>off</source>
      <translation>off</translation>
    </message>
    <message>
      <source>Enable location window when editing content.</source>
      <translation>Enable location window when editing content.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/setup/menu</name>
    <message>
      <source>Setup</source>
      <translation>Setup</translation>
    </message>
    <message>
      <source>Cache management</source>
      <translation>Cache management</translation>
    </message>
    <message>
      <source>Classes</source>
      <translation>Classes</translation>
    </message>
    <message>
      <source>Collected information</source>
      <translation>Collected information</translation>
    </message>
    <message>
      <source>Extensions</source>
      <translation>Extensions</translation>
    </message>
    <message>
      <source>Global settings</source>
      <translation>Global settings</translation>
    </message>
    <message>
      <source>Ini settings</source>
      <translation>Ini settings</translation>
    </message>
    <message>
      <source>Languages</source>
      <translation>Languages</translation>
    </message>
    <message>
      <source>Notification</source>
      <translation>Notification</translation>
    </message>
    <message>
      <source>PDF export</source>
      <comment>PDF export</comment>
      <translation>PDF export</translation>
    </message>
    <message>
      <source>Packages</source>
      <translation>Packages</translation>
    </message>
    <message>
      <source>RAD</source>
      <comment>Rapid Application Development</comment>
      <translation>RAD</translation>
    </message>
    <message>
      <source>Roles and policies</source>
      <translation>Roles and policies</translation>
    </message>
    <message>
      <source>RSS</source>
      <translation>RSS</translation>
    </message>
    <message>
      <source>Search statistics</source>
      <translation>Search statistics</translation>
    </message>
    <message>
      <source>Sections</source>
      <translation>Sections</translation>
    </message>
    <message>
      <source>Sessions</source>
      <translation>Sessions</translation>
    </message>
    <message>
      <source>System information</source>
      <translation>System information</translation>
    </message>
    <message>
      <source>Upgrade check</source>
      <translation>Upgrade check</translation>
    </message>
    <message>
      <source>Triggers</source>
      <translation>Triggers</translation>
    </message>
    <message>
      <source>URL management</source>
      <translation>URL management</translation>
    </message>
    <message>
      <source>URL translator</source>
      <translation>URL translator</translation>
    </message>
    <message>
      <source>Workflows</source>
      <translation>Workflows</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/shop/menu</name>
    <message>
      <source>Shop</source>
      <translation>Shop</translation>
    </message>
    <message>
      <source>Customers</source>
      <translation>Customers</translation>
    </message>
    <message>
      <source>Discounts</source>
      <translation>Discounts</translation>
    </message>
    <message>
      <source>Orders</source>
      <translation>Orders</translation>
    </message>
    <message>
      <source>Archive</source>
      <translation>Archive</translation>
    </message>
    <message>
      <source>Order status</source>
      <translation>Order status</translation>
    </message>
    <message>
      <source>Product statistics</source>
      <translation>Product statistics</translation>
    </message>
    <message>
      <source>VAT types</source>
      <translation>GST types</translation>
    </message>
    <message>
      <source>VAT rules</source>
      <translation>GST rules</translation>
    </message>
    <message>
      <source>Product categories</source>
      <translation>Product categories</translation>
    </message>
    <message>
      <source>Currencies</source>
      <translation>Currencies</translation>
    </message>
    <message>
      <source>Preferred currency</source>
      <translation>Preferred currency</translation>
    </message>
    <message>
      <source>Products overview</source>
      <translation>Products overview</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/user/menu</name>
    <message>
      <source>Role information</source>
      <translation>Role information</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>User accounts</source>
      <translation>User accounts</translation>
    </message>
    <message>
      <source>View and manage the contents of the trash bin.</source>
      <translation>View and manage the contents of the trash bin.</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>Change the left menu width to small size.</source>
      <translation>Change the left menu width to small size.</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Small</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Medium</translation>
    </message>
    <message>
      <source>Change the left menu width to large size.</source>
      <translation>Change the left menu width to large size.</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Large</translation>
    </message>
    <message>
      <source>Change the left menu width to medium size.</source>
      <translation>Change the left menu width to medium size.</translation>
    </message>
    <message>
      <source>Access control</source>
      <translation>Access control</translation>
    </message>
    <message>
      <source>Manage permission settings.</source>
      <translation>Manage permission settings.</translation>
    </message>
    <message>
      <source>Roles and policies</source>
      <translation>Roles and policies</translation>
    </message>
  </context>
  <context>
    <name>design/admin/parts/visual/menu</name>
    <message>
      <source>Design</source>
      <translation>Design</translation>
    </message>
    <message>
      <source>Look and feel</source>
      <translation>Look and feel</translation>
    </message>
    <message>
      <source>Menu management</source>
      <translation>Menu management</translation>
    </message>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>Templates</source>
      <translation>Templates</translation>
    </message>
  </context>
  <context>
    <name>design/admin/pdf/edit</name>
    <message>
      <source>PDF Export</source>
      <translation>PDF Export</translation>
    </message>
    <message>
      <source>%pdf_export_title [PDF export]</source>
      <translation>%pdf_export_title [PDF export]</translation>
    </message>
    <message>
      <source>Title</source>
      <translation>Title</translation>
    </message>
    <message>
      <source>Frontpage</source>
      <translation>Frontpage</translation>
    </message>
    <message>
      <source>Display frontpage</source>
      <translation>Display frontpage</translation>
    </message>
    <message>
      <source>Intro text</source>
      <translation>Intro text</translation>
    </message>
    <message>
      <source>Sub text</source>
      <translation>Sub text</translation>
    </message>
    <message>
      <source>Source node</source>
      <translation>Source node</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>There is no source node.</source>
      <translation>There is no source node.</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Export structure</source>
      <translation>Export structure</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Tree</source>
      <translation>Tree</translation>
    </message>
    <message>
      <source>Export classes (if exporting a tree)</source>
      <translation>Export classes (if exporting a tree)</translation>
    </message>
    <message>
      <source>Export type</source>
      <translation>Export type</translation>
    </message>
    <message>
      <source>Generate once</source>
      <translation>Generate once</translation>
    </message>
    <message>
      <source>Generate on the fly</source>
      <translation>Generate on the fly</translation>
    </message>
    <message>
      <source>Filename (if generated on the fly)</source>
      <translation>Filename (if generated on the fly)</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>The PDF export could not be stored.</source>
      <translation>The PDF export could not be stored.</translation>
    </message>
    <message>
      <source>Required data is either missing or is invalid</source>
      <translation>Required data is either missing or is invalid</translation>
    </message>
  </context>
  <context>
    <name>design/admin/pdf/list</name>
    <message>
      <source>PDF Exports [%export_count]</source>
      <translation>PDF Exports [%export_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Select PDF export for removal.</source>
      <translation>Select PDF export for removal.</translation>
    </message>
    <message>
      <source>PDF Export</source>
      <translation>PDF Export</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%pdf_export_name&gt; PDF export.</source>
      <translation>Edit the &lt;%pdf_export_name&gt; PDF export.</translation>
    </message>
    <message>
      <source>There are no PDF exports in the list.</source>
      <translation>There are no PDF exports in the list.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected PDF exports.</source>
      <translation>Remove selected PDF exports.</translation>
    </message>
    <message>
      <source>New PDF export</source>
      <translation>New PDF export</translation>
    </message>
    <message>
      <source>Create a new PDF export.</source>
      <translation>Create a new PDF export.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/popupmenu</name>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
    <message>
      <source>Edit in</source>
      <translation>Edit in</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Copy Subtree</source>
      <translation>Copy Subtree</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Move</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Advanced</translation>
    </message>
    <message>
      <source>Expand</source>
      <translation>Expand</translation>
    </message>
    <message>
      <source>Collapse</source>
      <translation>Collapse</translation>
    </message>
    <message>
      <source>Add to my bookmarks</source>
      <translation>Add to my bookmarks</translation>
    </message>
    <message>
      <source>Add to my notifications</source>
      <translation>Add to my notifications</translation>
    </message>
    <message>
      <source>Another language</source>
      <translation>Another language</translation>
    </message>
    <message>
      <source>Swap with another node</source>
      <translation>Swap with another node</translation>
    </message>
    <message>
      <source>Hide / unhide</source>
      <translation>Hide / unhide</translation>
    </message>
    <message>
      <source>View index</source>
      <translation>View index</translation>
    </message>
    <message>
      <source>Reverse related for subtree</source>
      <translation>Reverse related for subtree</translation>
    </message>
    <message>
      <source>Compare versions</source>
      <translation>Compare versions</translation>
    </message>
    <message>
      <source>View class</source>
      <translation>View class</translation>
    </message>
    <message>
      <source>Edit class</source>
      <translation>Edit class</translation>
    </message>
    <message>
      <source>Delete view cache</source>
      <translation>Delete view cache</translation>
    </message>
    <message>
      <source>Delete template cache</source>
      <translation>Delete template cache</translation>
    </message>
    <message>
      <source>Delete view cache from here</source>
      <translation>Delete view cache from here</translation>
    </message>
    <message>
      <source>Template overrides</source>
      <translation>Template overrides</translation>
    </message>
    <message>
      <source>New class override</source>
      <translation>New class override</translation>
    </message>
    <message>
      <source>New node override</source>
      <translation>New node override</translation>
    </message>
    <message>
      <source>Remove bookmark</source>
      <translation>Remove bookmark</translation>
    </message>
    <message>
      <source>Choose SiteAccess</source>
      <translation>Choose SiteAccess</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/article</name>
    <message>
      <source>Comments allowed</source>
      <translation>Comments allowed</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/company</name>
    <message>
      <source>Contact information</source>
      <translation>Contact information</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Additional information</source>
      <translation>Additional information</translation>
    </message>
    <message>
      <source>Contacts</source>
      <translation>Contacts</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/feedbackform</name>
    <message>
      <source>Your E-mail address</source>
      <translation>Your E-mail address</translation>
    </message>
    <message>
      <source>Subject</source>
      <translation>Subject</translation>
    </message>
    <message>
      <source>Message</source>
      <translation>Message</translation>
    </message>
    <message>
      <source>Recipient</source>
      <translation>Recipient</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/folder</name>
    <message>
      <source>Show children</source>
      <translation>Show children</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/person</name>
    <message>
      <source>Contact information</source>
      <translation>Contact information</translation>
    </message>
    <message>
      <source>Comments</source>
      <translation>Comments</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/poll</name>
    <message>
      <source>Result</source>
      <translation>Result</translation>
    </message>
  </context>
  <context>
    <name>design/admin/preview/product</name>
    <message>
      <source>Download this product sheet as PDF</source>
      <translation>Download this product sheet as PDF</translation>
    </message>
    <message>
      <source>People who bought this also bought</source>
      <translation>People who bought this also bought</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/assign_limited_section</name>
    <message>
      <source>Select section</source>
      <translation>Select section</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>There are no sections on the system.</source>
      <translation>There are no sections on the system.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/createpolicystep1</name>
    <message>
      <source>Create a new policy for the &lt;%role_name&gt; role</source>
      <translation>Create a new policy for the &lt;%role_name&gt; role</translation>
    </message>
    <message>
      <source>Welcome to the policy wizard. This three step wizard will help you create a new policy which will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
      <translation>Welcome to the policy wizard. This three step wizard will help you create a new policy which will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</translation>
    </message>
    <message>
      <source>Step one: select module</source>
      <translation>Step one: select module</translation>
    </message>
    <message>
      <source>Instructions</source>
      <translation>Instructions</translation>
    </message>
    <message>
      <source>Use the drop-down menu to select the module that you wish to grant access to.</source>
      <translation>Use the drop-down menu to select the module that you wish to grant access to.</translation>
    </message>
    <message>
      <source>Click one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
      <translation>Click one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</translation>
    </message>
    <message>
      <source>The &quot;Grant access to all functions&quot; button will create a policy that grants unlimited access to all functions of the selected module. If you wish to limit the access method to a specific function, use the &quot;Grant access to a function&quot; button. Please note that function limitation is only supported by some modules (the next step will reveal if it works or not).</source>
      <translation>The &quot;Grant access to all functions&quot; button will create a policy that grants unlimited access to all functions of the selected module. If you wish to limit the access method to a specific function, use the &quot;Grant access to a function&quot; button. Please note that function limitation is only supported by some modules (the next step will reveal if it works or not).</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Every module</source>
      <translation>Every module</translation>
    </message>
    <message>
      <source>Grant access to all functions</source>
      <translation>Grant access to all functions</translation>
    </message>
    <message>
      <source>Grant access to one function</source>
      <translation>Grant access to one function</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/createpolicystep2</name>
    <message>
      <source>Create a new policy for the &lt;%role_name&gt; role</source>
      <translation>Create a new policy for the &lt;%role_name&gt; role</translation>
    </message>
    <message>
      <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
      <translation>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</translation>
    </message>
    <message>
      <source>Step one: select module [completed]</source>
      <translation>Step one: select module [completed]</translation>
    </message>
    <message>
      <source>Selected module</source>
      <translation>Selected module</translation>
    </message>
    <message>
      <source>All modules</source>
      <translation>All modules</translation>
    </message>
    <message>
      <source>Selected access method</source>
      <translation>Selected access method</translation>
    </message>
    <message>
      <source>Limited</source>
      <translation>Limited</translation>
    </message>
    <message>
      <source>Step two: select function</source>
      <translation>Step two: select function</translation>
    </message>
    <message>
      <source>Instructions</source>
      <translation>Instructions</translation>
    </message>
    <message>
      <source>Use the drop-down menu to select the function that you wish to grant access to.</source>
      <translation>Use the drop-down menu to select the function that you wish to grant access to.</translation>
    </message>
    <message>
      <source>Click on one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
      <translation>Click on one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</translation>
    </message>
    <message>
      <source>The &quot;Grant full access&quot; button will create a policy that grants unlimited access to the selected function within the module that was specified in step one. If you wish to limit the access method in some way, click the &quot;Grant limited access&quot; button. Function limitation is only supported by some functions. If unsupported, eZ publish will simply set up a policy with unlimited access to the selected function.</source>
      <translation>The &quot;Grant full access&quot; button will create a policy that grants unlimited access to the selected function within the module that was specified in step one. If you wish to limit the access method in some way, click the &quot;Grant limited access&quot; button. Function limitation is only supported by some functions. If unsupported, eZ publish will simply set up a policy with unlimited access to the selected function.</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Grant full access</source>
      <translation>Grant full access</translation>
    </message>
    <message>
      <source>Grant limited access</source>
      <translation>Grant limited access</translation>
    </message>
    <message>
      <source>It is unfortunately not possible to grant limited access to all modules at once. To grant unlimited access to all modules and their functions, go back to step one and select &quot;Grant access to all functions&quot;. In order to grant limited access to different functions within different modules, you need to set up a collection of policies.</source>
      <translation>It is unfortunately not possible to grant limited access to all modules at once. To grant unlimited access to all modules and their functions, go back to step one and select &quot;Grant access to all functions&quot;. In order to grant limited access to different functions within different modules, you need to set up a collection of policies.</translation>
    </message>
    <message>
      <source>The selected module (%module_name) does not support limitations on the function level. Please go back to step one and use the &quot;Grant access to all functions&quot; option instead.</source>
      <translation>The selected module (%module_name) does not support limitations on the function level. Please go back to step one and use the &quot;Grant access to all functions&quot; option instead.</translation>
    </message>
    <message>
      <source>Go back to step one</source>
      <translation>Go back to step one</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/createpolicystep3</name>
    <message>
      <source>Create a new policy for the &lt;%role_name&gt; role</source>
      <translation>Create a new policy for the &lt;%role_name&gt; role</translation>
    </message>
    <message>
      <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
      <translation>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</translation>
    </message>
    <message>
      <source>Step one: select module [completed]</source>
      <translation>Step one: select module [completed]</translation>
    </message>
    <message>
      <source>Selected module</source>
      <translation>Selected module</translation>
    </message>
    <message>
      <source>All modules</source>
      <translation>All modules</translation>
    </message>
    <message>
      <source>Selected access method</source>
      <translation>Selected access method</translation>
    </message>
    <message>
      <source>Limited</source>
      <translation>Limited</translation>
    </message>
    <message>
      <source>Step two: select function [completed]</source>
      <translation>Step two: select function [completed]</translation>
    </message>
    <message>
      <source>Selected function</source>
      <translation>Selected function</translation>
    </message>
    <message>
      <source>Step three: set function limitations</source>
      <translation>Step three: set function limitations</translation>
    </message>
    <message>
      <source>Instructions</source>
      <translation>Instructions</translation>
    </message>
    <message>
      <source>Set the desired function limitations using the controls below.</source>
      <translation>Set the desired function limitations using the controls below.</translation>
    </message>
    <message>
      <source>Click the &quot;OK&quot; button to finish the wizard. The policy will be added to the role that is currently being edited.</source>
      <translation>Click the &quot;OK&quot; button to finish the wizard. The policy will be added to the role that is currently being edited.</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Nodes [%node_count]</source>
      <translation>Nodes [%node_count]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>The node list is empty.</source>
      <translation>The node list is empty.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add nodes</source>
      <translation>Add nodes</translation>
    </message>
    <message>
      <source>Subtrees [%subtree_count]</source>
      <translation>Subtrees [%subtree_count]</translation>
    </message>
    <message>
      <source>Subtree</source>
      <translation>Subtree</translation>
    </message>
    <message>
      <source>The subtree list is empty.</source>
      <translation>The subtree list is empty.</translation>
    </message>
    <message>
      <source>Add subtrees</source>
      <translation>Add subtrees</translation>
    </message>
    <message>
      <source>Go back to step one</source>
      <translation>Go back to step one</translation>
    </message>
    <message>
      <source>Go back to step two</source>
      <translation>Go back to step two</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/edit</name>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>Edit &lt;%role_name&gt; [Role]</source>
      <translation>Edit &lt;%role_name&gt; [Role]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Policies</source>
      <translation>Policies</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Limitations</source>
      <translation>Limitations</translation>
    </message>
    <message>
      <source>Select policy for removal.</source>
      <translation>Select policy for removal.</translation>
    </message>
    <message>
      <source>all modules</source>
      <translation>all modules</translation>
    </message>
    <message>
      <source>all functions</source>
      <translation>all functions</translation>
    </message>
    <message>
      <source>No limitations</source>
      <translation>No limitations</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the policy's function limitations.</source>
      <translation>Edit the policy's function limitations.</translation>
    </message>
    <message>
      <source>There are no policies set up for this role.</source>
      <translation>There are no policies set up for this role.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected policies.</source>
      <translation>Remove selected policies.</translation>
    </message>
    <message>
      <source>New policy</source>
      <translation>New policy</translation>
    </message>
    <message>
      <source>Create a new policy.</source>
      <translation>Create a new policy.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/list</name>
    <message>
      <source>Roles [%role_count]</source>
      <translation>Roles [%role_count]</translation>
    </message>
    <message>
      <source>Toggle selection</source>
      <translation>Toggle selection</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Select role for removal.</source>
      <translation>Select role for removal.</translation>
    </message>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>Assign</source>
      <translation>Assign</translation>
    </message>
    <message>
      <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
      <translation>Assign the &lt;%role_name&gt; role to a user or a user group.</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Copy the &lt;%role_name&gt; role.</source>
      <translation>Copy the &lt;%role_name&gt; role.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%role_name&gt; role.</source>
      <translation>Edit the &lt;%role_name&gt; role.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected roles.</source>
      <translation>Remove selected roles.</translation>
    </message>
    <message>
      <source>New role</source>
      <translation>New role</translation>
    </message>
    <message>
      <source>Create a new role.</source>
      <translation>Create a new role.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/policyedit</name>
    <message>
      <source>Edit &lt;%policy_name&gt; policy for &lt;%role_name&gt; role</source>
      <translation>Edit &lt;%policy_name&gt; policy for &lt;%role_name&gt; role</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Function limitations</source>
      <translation>Function limitations</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Nodes [%node_count]</source>
      <translation>Nodes [%node_count]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>The node list is empty.</source>
      <translation>The node list is empty.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add nodes</source>
      <translation>Add nodes</translation>
    </message>
    <message>
      <source>Subtrees [%subtree_count]</source>
      <translation>Subtrees [%subtree_count]</translation>
    </message>
    <message>
      <source>Subtree</source>
      <translation>Subtree</translation>
    </message>
    <message>
      <source>The subtree list is empty.</source>
      <translation>The subtree list is empty.</translation>
    </message>
    <message>
      <source>Add subtrees</source>
      <translation>Add subtrees</translation>
    </message>
    <message>
      <source>The function limitations of this policy can not be edited. This is either because the function simply does not support limitations or because the function was assigned without limitations when the policy was created.</source>
      <translation>The function limitations of this policy can not be edited. This is either because the function simply does not support limitations or because the function was assigned without limitations when the policy was created.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/role/view</name>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>%role_name [Role]</source>
      <translation>%role_name [Role]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Policies [%policies_count]</source>
      <translation>Policies [%policies_count]</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Limitation</source>
      <translation>Limitation</translation>
    </message>
    <message>
      <source>all modules</source>
      <translation>all modules</translation>
    </message>
    <message>
      <source>all functions</source>
      <translation>all functions</translation>
    </message>
    <message>
      <source>No limitations</source>
      <translation>No limitations</translation>
    </message>
    <message>
      <source>There are no policies set up for this role.</source>
      <translation>There are no policies set up for this role.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this role.</source>
      <translation>Edit this role.</translation>
    </message>
    <message>
      <source>Users and groups using the &lt;%role_name&gt; role [%users_count]</source>
      <translation>Users and groups using the &lt;%role_name&gt; role [%users_count]</translation>
    </message>
    <message>
      <source>Toggle selection</source>
      <translation>Toggle selection</translation>
    </message>
    <message>
      <source>User/group</source>
      <translation>User/group</translation>
    </message>
    <message>
      <source>Select user or user group for removal.</source>
      <translation>Select user or user group for removal.</translation>
    </message>
    <message>
      <source>This role is not assigned to any users or user groups.</source>
      <translation>This role is not assigned to any users or user groups.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected users and/or user groups.</source>
      <translation>Remove selected users and/or user groups.</translation>
    </message>
    <message>
      <source>Assign</source>
      <translation>Assign</translation>
    </message>
    <message>
      <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
      <translation>Assign the &lt;%role_name&gt; role to a user or a user group.</translation>
    </message>
    <message>
      <source>Select limitation.</source>
      <translation>Select limitation.</translation>
    </message>
    <message>
      <source>Subtree</source>
      <translation>Subtree</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Assign with limitation</source>
      <translation>Assign with limitation</translation>
    </message>
    <message>
      <source>Assign the &lt;%role_name&gt; role with limitation (specified to the left) to a user or a user group.</source>
      <translation>Assign the &lt;%role_name&gt; role with limitation (specified to the left) to a user or a user group.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/browse_destination</name>
    <message>
      <source>Choose a destination for RSS import</source>
      <translation>Choose a destination for RSS import</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose a destination location for RSS import and click &quot;OK&quot;.</source>
      <translation>Use the radio buttons to choose a destination location for RSS import and click &quot;OK&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/browse_image</name>
    <message>
      <source>Choose image for RSS export</source>
      <translation>Choose image for RSS export</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose an image to use in the RSS export and click &quot;OK&quot;.</source>
      <translation>Use the radio buttons to choose an image to use in the RSS export and click &quot;OK&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/browse_source</name>
    <message>
      <source>Choose source for RSS export</source>
      <translation>Choose source for RSS export</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose the item that you wish to export using RSS and click &quot;OK&quot;.</source>
      <translation>Use the radio buttons to choose the item that you wish to export using RSS and click &quot;OK&quot;.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/browse_user</name>
    <message>
      <source>Choose owner for RSS imported objects</source>
      <translation>Choose owner for RSS imported objects</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose a user and click &quot;OK&quot;. The user will become the owner of the objects that were imported using RSS.</source>
      <translation>Use the radio buttons to choose a user and click &quot;OK&quot;. The user will become the owner of the objects that were imported using RSS.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/edit_export</name>
    <message>
      <source>Edit &lt;%rss_export_name&gt; [RSS Export]</source>
      <translation>Edit &lt;%rss_export_name&gt; [RSS Export]</translation>
    </message>
    <message>
      <source>Invalid Input</source>
      <translation>Invalid Input</translation>
    </message>
    <message>
      <source>If RSS Export is Active then a valid Access URL is required.</source>
      <translation>If RSS Export is Active then a valid Access URL is required.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Name of the RSS export. This name is used in the administration interface only, to distinguish the different exports from each other.</source>
      <translation>Name of the RSS export. This name is used in the administration interface only, to distinguish the different exports from each other.</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Use the description field to write a text explaining what users can expect from the RSS export.</source>
      <translation>Use the description field to write a text explaining what users can expect from the RSS export.</translation>
    </message>
    <message>
      <source>Site URL</source>
      <translation>Site URL</translation>
    </message>
    <message>
      <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
      <translation>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Image</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Click this button to select an image for the RSS export. Note that images only work with RSS version 2.0</source>
      <translation>Click this button to select an image for the RSS export. Note that images only work with RSS version 2.0</translation>
    </message>
    <message>
      <source>Remove image</source>
      <translation>Remove image</translation>
    </message>
    <message>
      <source>Click to remove image from RSS export.</source>
      <translation>Click to remove image from RSS export.</translation>
    </message>
    <message>
      <source>RSS version</source>
      <translation>RSS version</translation>
    </message>
    <message>
      <source>Use this drop-down menu to select the RSS version to use for the export. You must select RSS 2.0 in order to export the image selected above.</source>
      <translation>Use this drop-down menu to select the RSS version to use for the export. You must select RSS 2.0 in order to export the image selected above.</translation>
    </message>
    <message>
      <source>Number of objects</source>
      <translation>Number of objects</translation>
    </message>
    <message>
      <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
      <translation>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Use this checkbox to control if the RSS export is active or not. An inactive export will not be automatically updated.</source>
      <translation>Use this checkbox to control if the RSS export is active or not. An inactive export will not be automatically updated.</translation>
    </message>
    <message>
      <source>Main node only</source>
      <translation>Main node only</translation>
    </message>
    <message>
      <source>Check if you want to only feed the object from the main node.</source>
      <translation>Check if you want to only feed the object from the main node.</translation>
    </message>
    <message>
      <source>Access URL</source>
      <translation>Access URL</translation>
    </message>
    <message>
      <source>Use this field to set the URL where the RSS export should be available. Note that &quot;rss/feed/&quot; will be appended to the real URL. </source>
      <translation>Use this field to set the URL where the RSS export should be available. Note that &quot;rss/feed/&quot; will be appended to the real URL. </translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Source</translation>
    </message>
    <message>
      <source>Source path</source>
      <translation>Source path</translation>
    </message>
    <message>
      <source>Click this button to select the source node for RSS export source. Objects of the type selected in the drop down below published as sub-items of the selected node will be included in the RSS export.</source>
      <translation>Click this button to select the source node for RSS export source. Objects of the type selected in the drop down below published as sub-items of the selected node will be included in the RSS export.</translation>
    </message>
    <message>
      <source>Subnodes</source>
      <translation>Subnodes</translation>
    </message>
    <message>
      <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
      <translation>Activate this checkbox if also objects from the subnodes of the source should be feeded.</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Use this drop down to select the type of object that triggers the export. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
      <translation>Use this drop down to select the type of object that triggers the export. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
      <translation>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</translation>
    </message>
    <message>
      <source>Title</source>
      <translation>Title</translation>
    </message>
    <message>
      <source>Use this drop-down to select which attribute that should be exported as the title of the RSS export entry.</source>
      <translation>Use this drop-down to select which attribute that should be exported as the title of the RSS export entry.</translation>
    </message>
    <message>
      <source>Use this drop-down to select which attribute that should be exported as the description of the RSS export entry.</source>
      <translation>Use this drop-down to select which attribute that should be exported as the description of the RSS export entry.</translation>
    </message>
    <message>
      <source>Remove this source</source>
      <translation>Remove this source</translation>
    </message>
    <message>
      <source>Click to remove this source from the RSS export.</source>
      <translation>Click to remove this source from the RSS export.</translation>
    </message>
    <message>
      <source>Add source</source>
      <translation>Add source</translation>
    </message>
    <message>
      <source>Click to add a new source to the RSS export.</source>
      <translation>Click to add a new source to the RSS export.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Apply the changes and return to the RSS overview.</source>
      <translation>Apply the changes and return to the RSS overview.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel the changes and return to the RSS overview.</source>
      <translation>Cancel the changes and return to the RSS overview.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/edit_import</name>
    <message>
      <source>Edit &lt;%rss_import_name&gt; [RSS Import]</source>
      <translation>Edit &lt;%rss_import_name&gt; [RSS Import]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Name of the RSS import. This name is used in the administration interface only, to distinguish the different imports from each other.</source>
      <translation>Name of the RSS import. This name is used in the administration interface only, to distinguish the different imports from each other.</translation>
    </message>
    <message>
      <source>Source URL</source>
      <translation>Source URL</translation>
    </message>
    <message>
      <source>Use this field to enter the source URL of the RSS feed to import.</source>
      <translation>Use this field to enter the source URL of the RSS feed to import.</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Click this button to proceede, and analyze the import feed.</source>
      <translation>Click this button to proceede, and analyze the import feed.</translation>
    </message>
    <message>
      <source>RSS Version</source>
      <translation>RSS Version</translation>
    </message>
    <message>
      <source>Destination path</source>
      <translation>Destination path</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Click this button to select the destination node where objects created by the import are located.</source>
      <translation>Click this button to select the destination node where objects created by the import are located.</translation>
    </message>
    <message>
      <source>Imported objects will be owned by</source>
      <translation>Imported objects will be owned by</translation>
    </message>
    <message>
      <source>Change user</source>
      <translation>Change user</translation>
    </message>
    <message>
      <source>Click this button to select the user who should own the objects created by the import.</source>
      <translation>Click this button to select the user who should own the objects created by the import.</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Use this drop down to select the type of object the import should create. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
      <translation>Use this drop down to select the type of object the import should create. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
      <translation>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</translation>
    </message>
    <message>
      <source>Class Attributes</source>
      <translation>Class Attributes</translation>
    </message>
    <message>
      <source>Use this drop-down menu to select the attribute that should bet set as information from the RSS stream.</source>
      <translation>Use this drop-down menu to select the attribute that should bet set as information from the RSS stream.</translation>
    </message>
    <message>
      <source>Ignore</source>
      <translation>Ignore</translation>
    </message>
    <message>
      <source>Object attributes</source>
      <translation>Object attributes</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Use this checkbox to control if the RSS feed is active or not. An inactive feed will not be automatically updated.</source>
      <translation>Use this checkbox to control if the RSS feed is active or not. An inactive feed will not be automatically updated.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Apply the changes and return to the RSS overview.</source>
      <translation>Apply the changes and return to the RSS overview.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel the changes and return to the RSS overview.</source>
      <translation>Cancel the changes and return to the RSS overview.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/rss/list</name>
    <message>
      <source>RSS exports [%exports_count]</source>
      <translation>RSS exports [%exports_count]</translation>
    </message>
    <message>
      <source>Invert selection</source>
      <translation>Invert selection</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Select RSS export for removal.</source>
      <translation>Select RSS export for removal.</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Inactive</source>
      <translation>Inactive</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%name&gt; RSS export.</source>
      <translation>Edit the &lt;%name&gt; RSS export.</translation>
    </message>
    <message>
      <source>The RSS export list is empty.</source>
      <translation>The RSS export list is empty.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected RSS exports.</source>
      <translation>Remove selected RSS exports.</translation>
    </message>
    <message>
      <source>New export</source>
      <translation>New export</translation>
    </message>
    <message>
      <source>Create a new RSS export.</source>
      <translation>Create a new RSS export.</translation>
    </message>
    <message>
      <source>RSS imports [%imports_count]</source>
      <translation>RSS imports [%imports_count]</translation>
    </message>
    <message>
      <source>Select RSS import for removal.</source>
      <translation>Select RSS import for removal.</translation>
    </message>
    <message>
      <source>Edit the &lt;%name&gt; RSS import.</source>
      <translation>Edit the &lt;%name&gt; RSS import.</translation>
    </message>
    <message>
      <source>The RSS import list is empty.</source>
      <translation>The RSS import list is empty.</translation>
    </message>
    <message>
      <source>Remove selected RSS imports.</source>
      <translation>Remove selected RSS imports.</translation>
    </message>
    <message>
      <source>New import</source>
      <translation>New import</translation>
    </message>
    <message>
      <source>Create a new RSS import.</source>
      <translation>Create a new RSS import.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/search/stats</name>
    <message>
      <source>Search statistics</source>
      <translation>Search statistics</translation>
    </message>
    <message>
      <source>Phrase</source>
      <translation>Phrase</translation>
    </message>
    <message>
      <source>Number of phrases</source>
      <translation>Number of phrases</translation>
    </message>
    <message>
      <source>Average result returned</source>
      <translation>Average result returned</translation>
    </message>
    <message>
      <source>The list is empty.</source>
      <translation>The list is empty.</translation>
    </message>
    <message>
      <source>Reset statistics</source>
      <translation>Reset statistics</translation>
    </message>
    <message>
      <source>Clear the search log.</source>
      <translation>Clear the search log.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/section/browse_assign</name>
    <message>
      <source>Choose start location for the &lt;%section_name&gt; section</source>
      <translation>Choose start location for the &lt;%section_name&gt; section</translation>
    </message>
    <message>
      <source>Use the radio buttons to select an item that should have the &lt;%section_name&gt; section assigned.</source>
      <translation>Use the radio buttons to select an item that should have the &lt;%section_name&gt; section assigned.</translation>
    </message>
    <message>
      <source>Keep in mind that the section assignment of the sub items will also be changed.</source>
      <translation>Keep in mind that the section assignment of the sub items will also be changed.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/section/confirmremove</name>
    <message>
      <source>Confirm section removal</source>
      <translation>Confirm section removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the section?</source>
      <translation>Are you sure you want to remove the section?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the sections?</source>
      <translation>Are you sure you want to remove the sections?</translation>
    </message>
    <message>
      <source>The following sections will be removed</source>
      <translation>The following sections will be removed</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Warning</translation>
    </message>
    <message>
      <source>Removing a section may corrupt permission settings, template output and other things in the system.</source>
      <translation>Removing a section may corrupt permission settings, template output and other things in the system.</translation>
    </message>
    <message>
      <source>Proceed only if you know what you are doing.</source>
      <translation>Proceed only if you know what you are doing.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/section/edit</name>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Edit &lt;%section_name&gt; [Section]</source>
      <translation>Edit &lt;%section_name&gt; [Section]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Navigation Part</source>
      <translation>Navigation Part</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/section/list</name>
    <message>
      <source>Sections [%section_count]</source>
      <translation>Sections [%section_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Select section for removal.</source>
      <translation>Select section for removal.</translation>
    </message>
    <message>
      <source>section</source>
      <translation>section</translation>
    </message>
    <message>
      <source>Assign</source>
      <translation>Assign</translation>
    </message>
    <message>
      <source>Assign the &lt;%section_name&gt; section to a subtree.</source>
      <translation>Assign the &lt;%section_name&gt; section to a subtree.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%section_name&gt; section.</source>
      <translation>Edit the &lt;%section_name&gt; section.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected sections.</source>
      <translation>Remove selected sections.</translation>
    </message>
    <message>
      <source>New section</source>
      <translation>New section</translation>
    </message>
    <message>
      <source>Create a new section.</source>
      <translation>Create a new section.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/section/view</name>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>%section_name [Section]</source>
      <translation>%section_name [Section]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this section.</source>
      <translation>Edit this section.</translation>
    </message>
    <message>
      <source>Roles containing limitations associated with this section [%number_of_roles]</source>
      <translation>Roles containing limitations associated with this section [%number_of_roles]</translation>
    </message>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>Limited policies</source>
      <translation>Limited policies</translation>
    </message>
    <message>
      <source>This section is not used to limit the policies of any role.</source>
      <translation>This section is not used to limit the policies of any role.</translation>
    </message>
    <message>
      <source>Users and user groups with role limitations associated with this section [%number_of_roles]</source>
      <translation>Users and user groups with role limitations associated with this section [%number_of_roles]</translation>
    </message>
    <message>
      <source>User or user group</source>
      <translation>User or user group</translation>
    </message>
    <message>
      <source>This section is not used for limiting roles that are assigned to users or user groups. </source>
      <translation>This section is not used for limiting roles that are assigned to users or user groups. </translation>
    </message>
    <message>
      <source>Objects within this section [%number_of_objects]</source>
      <translation>Objects within this section [%number_of_objects]</translation>
    </message>
    <message>
      <source>This section is not assigned to any objects.</source>
      <translation>This section is not assigned to any objects.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/settings</name>
    <message>
      <source>Edit setting %setting</source>
      <translation>Edit setting %setting</translation>
    </message>
    <message>
      <source>New setting</source>
      <translation>New setting</translation>
    </message>
    <message>
      <source>Ini setting</source>
      <translation>Ini setting</translation>
    </message>
    <message>
      <source>INI File</source>
      <translation>INI File</translation>
    </message>
    <message>
      <source>Block</source>
      <translation>Block</translation>
    </message>
    <message>
      <source>Setting</source>
      <translation>Setting</translation>
    </message>
    <message>
      <source>Setting: &lt;new setting&gt;</source>
      <translation>Setting: &lt;new setting&gt;</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Values for each location setting are shown. The first values are lowest priority, and the values towards the end will have higher priority than the first ones.</source>
      <translation>Values for each location setting are shown. The first values are lowest priority, and the values towards the end will have higher priority than the first ones.</translation>
    </message>
    <message>
      <source>Tip</source>
      <translation>Tip</translation>
    </message>
    <message>
      <source>To create an empty array leave the first line empty</source>
      <translation>To create an empty array leave the first line empty</translation>
    </message>
    <message>
      <source>Change setting type</source>
      <translation>Change setting type</translation>
    </message>
    <message>
      <source>Location (prioritized list shown)</source>
      <translation>Location (prioritized list shown)</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Value</translation>
    </message>
    <message>
      <source>Default (cannot change)</source>
      <translation>Default (cannot change)</translation>
    </message>
    <message>
      <source>No value</source>
      <translation>No value</translation>
    </message>
    <message>
      <source>Siteaccess setting</source>
      <translation>Siteaccess setting</translation>
    </message>
    <message>
      <source>Override setting (global)</source>
      <translation>Override setting (global)</translation>
    </message>
    <message>
      <source>Setting Name</source>
      <translation>Setting Name</translation>
    </message>
    <message>
      <source>Setting value</source>
      <translation>Setting value</translation>
    </message>
    <message>
      <source>Enabled</source>
      <translation>Enabled</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Disabled</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Save</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>%valfield is empty</source>
      <translation>%valfield is empty</translation>
    </message>
    <message>
      <source>Variable %valfield already exists in section %block</source>
      <translation>Variable %valfield already exists in section %block</translation>
    </message>
    <message>
      <source>Please choose another name that is not already taken</source>
      <translation>Please choose another name that is not already taken</translation>
    </message>
    <message>
      <source>%valfield is not allowed to contain spaces</source>
      <translation>%valfield is not allowed to contain spaces</translation>
    </message>
    <message>
      <source>Writing setting: %setting_name to file: %filename failed.</source>
      <translation>Writing setting: %setting_name to file: %filename failed.</translation>
    </message>
    <message>
      <source>Make sure you have proper permissions to %path and try again.</source>
      <translation>Make sure you have proper permissions to %path and try again.</translation>
    </message>
    <message>
      <source>Name contains illegal character(s).</source>
      <translation>Name contains illegal character(s).</translation>
    </message>
    <message>
      <source>Name should only contain A-Z and 0-9.</source>
      <translation>Name should only contain A-Z and 0-9.</translation>
    </message>
    <message>
      <source>%valfield does not contain a valid string.</source>
      <translation>%valfield does not contain a valid string.</translation>
    </message>
    <message>
      <source>If the string is all numbers use the numeric type instead.</source>
      <translation>If the string is all numbers use the numeric type instead.</translation>
    </message>
    <message>
      <source>%valfield does not contain a valid numeric</source>
      <translation>%valfield does not contain a valid numeric</translation>
    </message>
    <message>
      <source>A valid numeric can only contain 0-9 and one . (dot). </source>
      <translation>A valid numeric can only contain 0-9 and one . (dot). </translation>
    </message>
    <message>
      <source>$valfield does not contain valid array.</source>
      <translation>$valfield does not contain valid array.</translation>
    </message>
    <message>
      <source>View settings</source>
      <translation>View settings</translation>
    </message>
    <message>
      <source>Using siteaccess</source>
      <translation>Using siteaccess</translation>
    </message>
    <message>
      <source>%ini_file consist of %blocks section(s) and %setting_count different setting(s)</source>
      <translation>%ini_file consist of %blocks section(s) and %setting_count different setting(s)</translation>
    </message>
    <message>
      <source>Please select an ini file from the dropdown below</source>
      <translation>Please select an ini file from the dropdown below</translation>
    </message>
    <message>
      <source>Select ini file to view</source>
      <translation>Select ini file to view</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Settings for %inifile in siteaccess %siteaccess</source>
      <translation>Settings for %inifile in siteaccess %siteaccess</translation>
    </message>
    <message>
      <source>[add setting]</source>
      <translation>[add setting]</translation>
    </message>
    <message>
      <source>Placement</source>
      <translation>Placement</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup</name>
    <message>
      <source>File consistency check OK.</source>
      <translation>File consistency check OK.</translation>
    </message>
    <message>
      <source>Warning, it is not safe to upgrade without checking the modifications done to the following files</source>
      <translation>Warning, it is not safe to upgrade without checking the modifications done to the following files</translation>
    </message>
    <message>
      <source>Database check OK.</source>
      <translation>Database check OK.</translation>
    </message>
    <message>
      <source>The database is not consistent with the distribution database.</source>
      <translation>The database is not consistent with the distribution database.</translation>
    </message>
    <message>
      <source>To synchronize your database with the distribution setup, run the following SQL commands</source>
      <translation>To synchronize your database with the distribution setup, run the following SQL commands</translation>
    </message>
    <message>
      <source>System upgrade check</source>
      <translation>System upgrade check</translation>
    </message>
    <message>
      <source>Before upgrading eZ publish to a newer version, it is important to check that the current installation is ready for upgrading.</source>
      <translation>Before upgrading eZ publish to a newer version, it is important to check that the current installation is ready for upgrading.</translation>
    </message>
    <message>
      <source>Remember to make a backup of the eZ publish directory and the database before you upgrade.</source>
      <translation>Remember to make a backup of the eZ publish directory and the database before you upgrade.</translation>
    </message>
    <message>
      <source>File consistency check</source>
      <translation>File consistency check</translation>
    </message>
    <message>
      <source>The file consistency tool checks if you have altered any of the files that came with the current installation. Altered files may be replaced by new versions which contain bugfixes, new features, etc. Make sure that you backup and then merge in your custom changes into the new versions of the files.</source>
      <translation>The file consistency tool checks if you have altered any of the files that came with the current installation. Altered files may be replaced by new versions which contain bugfixes, new features, etc. Make sure that you backup and then merge in your custom changes into the new versions of the files.</translation>
    </message>
    <message>
      <source>Database consistency check</source>
      <translation>Database consistency check</translation>
    </message>
    <message>
      <source>The database consistency tool checks if the current database is consistent with the database schema that came with the eZ publish distribution. If there are any inconsistencies, the tool will suggest the necessary SQL statements that should be ran in order to bring the database into a consistent state. Please run the suggested SQL statements before upgrading.</source>
      <translation>The database consistency tool checks if the current database is consistent with the database schema that came with the eZ publish distribution. If there are any inconsistencies, the tool will suggest the necessary SQL statements that should be ran in order to bring the database into a consistent state. Please run the suggested SQL statements before upgrading.</translation>
    </message>
    <message>
      <source>The upgrade checking tools require a lot of resources and it may take some time to run them.</source>
      <translation>The upgrade checking tools require a lot of resources and it may take some time to run them.</translation>
    </message>
    <message>
      <source>Check file consistency</source>
      <translation>Check file consistency</translation>
    </message>
    <message>
      <source>Check database consistency</source>
      <translation>Check database consistency</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/cache</name>
    <message>
      <source>Content view cache was cleared</source>
      <translation>Content view cache was cleared</translation>
    </message>
    <message>
      <source>All caches were cleared</source>
      <translation>All caches were cleared</translation>
    </message>
    <message>
      <source>Ini file cache was cleared</source>
      <translation>Ini file cache was cleared</translation>
    </message>
    <message>
      <source>Template cache was cleared</source>
      <translation>Template cache was cleared</translation>
    </message>
    <message>
      <source>Static content cache was regenerated</source>
      <translation>Static content cache was regenerated</translation>
    </message>
    <message>
      <source>The following caches were cleared</source>
      <translation>The following caches were cleared</translation>
    </message>
    <message>
      <source>%name was cleared</source>
      <translation>%name was cleared</translation>
    </message>
    <message>
      <source>Clear caches</source>
      <translation>Clear caches</translation>
    </message>
    <message>
      <source>Template overrides and compiled templates</source>
      <translation>Template overrides and compiled templates</translation>
    </message>
    <message>
      <source>Clear template caches</source>
      <translation>Clear template caches</translation>
    </message>
    <message>
      <source>This operation will clear all the template override caches and the compiled templates. It may lead to weaker performance until the caches are up and running again.</source>
      <translation>This operation will clear all the template override caches and the compiled templates. It may lead to weaker performance until the caches are up and running again.</translation>
    </message>
    <message>
      <source>Content views and template blocks</source>
      <translation>Content views and template blocks</translation>
    </message>
    <message>
      <source>Clear content caches</source>
      <translation>Clear content caches</translation>
    </message>
    <message>
      <source>This operation will clear all caches that are related to either template views or cache blocks inside the pagelayout template. Use it if you have modified templates or if you have changed something inside a cache block.</source>
      <translation>This operation will clear all caches that are related to either template views or cache blocks inside the pagelayout template. Use it if you have modified templates or if you have changed something inside a cache block.</translation>
    </message>
    <message>
      <source>Configuration (ini) caches</source>
      <translation>Configuration (ini) caches</translation>
    </message>
    <message>
      <source>Clear ini caches</source>
      <translation>Clear ini caches</translation>
    </message>
    <message>
      <source>This operation will clear all the configuration caches. Use it to force the system to re-read the configuration files if you have changed some settings.</source>
      <translation>This operation will clear all the configuration caches. Use it to force the system to re-read the configuration files if you have changed some settings.</translation>
    </message>
    <message>
      <source>Everything</source>
      <translation>Everything</translation>
    </message>
    <message>
      <source>Clear all caches</source>
      <translation>Clear all caches</translation>
    </message>
    <message>
      <source>This operation will clear ALL the caches and may lead to long response times until the caches are up and running again.</source>
      <translation>This operation will clear ALL the caches and may lead to long response times until the caches are up and running again.</translation>
    </message>
    <message>
      <source>Fine-grained cache control</source>
      <translation>Fine-grained cache control</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Path</translation>
    </message>
    <message>
      <source>Select the &lt;%cache_name&gt; for clearing.</source>
      <translation>Select the &lt;%cache_name&gt; for clearing.</translation>
    </message>
    <message>
      <source>The &lt;%cache_name&gt; is disabled and thus it can not be marked for clearing.</source>
      <translation>The &lt;%cache_name&gt; is disabled and thus it can not be marked for clearing.</translation>
    </message>
    <message>
      <source>Clear selected</source>
      <translation>Clear selected</translation>
    </message>
    <message>
      <source>Clear the selected caches.</source>
      <translation>Clear the selected caches.</translation>
    </message>
    <message>
      <source>Static content cache</source>
      <translation>Static content cache</translation>
    </message>
    <message>
      <source>Regenerate static content cache</source>
      <translation>Regenerate static content cache</translation>
    </message>
    <message>
      <source>Create new</source>
      <translation>Create new</translation>
    </message>
    <message>
      <source>This operation will regenerate all the static content caches that are configured. This action can take quite some time depending on the specifications of the server and the number of locations that are configured to be statically cached. If you encounter time-out problems, please use the &amp;quot;bin/php/makestaticcache.php&amp;quot; shell script.</source>
      <translation>This operation will regenerate all the static content caches that are configured. This action can take quite some time depending on the specifications of the server and the number of locations that are configured to be statically cached. If you encounter time-out problems, please use the &amp;quot;bin/php/makestaticcache.php&amp;quot; shell script.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/datatypecode</name>
    <message>
      <source>Constructor</source>
      <translation>Constructor</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/extensions</name>
    <message>
      <source>Available extensions [%extension_count]</source>
      <translation>Available extensions [%extension_count]</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Activate or deactivate extension. Use the &quot;Apply changes&quot; button to apply the changes.</source>
      <translation>Activate or deactivate extension. Use the &quot;Apply changes&quot; button to apply the changes.</translation>
    </message>
    <message>
      <source>There are no available extensions.</source>
      <translation>There are no available extensions.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified the status of the checkboxes above.</source>
      <translation>Click this button to store changes if you have modified the status of the checkboxes above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/info</name>
    <message>
      <source>System information</source>
      <translation>System information</translation>
    </message>
    <message>
      <source>eZ publish</source>
      <translation>eZ publish</translation>
    </message>
    <message>
      <source>Site</source>
      <translation>Site</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>eZ publish version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>SVN revision</source>
      <comment>eZ publish version</comment>
      <translation>SVN revision</translation>
    </message>
    <message>
      <source>Extensions</source>
      <comment>eZ publish extensions</comment>
      <translation>Extensions</translation>
    </message>
    <message>
      <source>Not in use.</source>
      <translation>Not in use.</translation>
    </message>
    <message>
      <source>PHP</source>
      <translation>PHP</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>PHP version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Extensions</source>
      <comment>PHP extensions</comment>
      <translation>Extensions</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Miscellaneous</translation>
    </message>
    <message>
      <source>Safe mode is on.</source>
      <translation>Safe mode is on.</translation>
    </message>
    <message>
      <source>Safe mode is off.</source>
      <translation>Safe mode is off.</translation>
    </message>
    <message>
      <source>Basedir restriction is on and set to %1.</source>
      <translation>Basedir restriction is on and set to %1.</translation>
    </message>
    <message>
      <source>Basedir restriction is off.</source>
      <translation>Basedir restriction is off.</translation>
    </message>
    <message>
      <source>Global variable registration is on.</source>
      <translation>Global variable registration is on.</translation>
    </message>
    <message>
      <source>Global variable registration is off.</source>
      <translation>Global variable registration is off.</translation>
    </message>
    <message>
      <source>File uploading is enabled.</source>
      <translation>File uploading is enabled.</translation>
    </message>
    <message>
      <source>File uploading is disabled.</source>
      <translation>File uploading is disabled.</translation>
    </message>
    <message>
      <source>Maximum size of post data (text and files) is %1.</source>
      <translation>Maximum size of post data (text and files) is %1.</translation>
    </message>
    <message>
      <source>Script memory limit is %1.</source>
      <translation>Script memory limit is %1.</translation>
    </message>
    <message>
      <source>Script memory limit is Unlimited.</source>
      <translation>Script memory limit is Unlimited.</translation>
    </message>
    <message>
      <source>Maximum execution time is %1 seconds.</source>
      <translation>Maximum execution time is %1 seconds.</translation>
    </message>
    <message>
      <source>PHP Accelerator</source>
      <translation>PHP Accelerator</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>PHP Accelerator name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>PHP Accelerator version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Version information could not be detected.</source>
      <translation>Version information could not be detected.</translation>
    </message>
    <message>
      <source>Status</source>
      <comment>PHP Accelerator status</comment>
      <translation>Status</translation>
    </message>
    <message>
      <source>Enabled.</source>
      <translation>Enabled.</translation>
    </message>
    <message>
      <source>Disabled.</source>
      <translation>Disabled.</translation>
    </message>
    <message>
      <source>A known and active PHP accelerator could not be found.</source>
      <translation>A known and active PHP accelerator could not be found.</translation>
    </message>
    <message>
      <source>Webserver (software)</source>
      <comment>Webserver title</comment>
      <translation>Webserver (software)</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>Webserver name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>Webserver version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Modules</source>
      <comment>Webserver modules</comment>
      <translation>Modules</translation>
    </message>
    <message>
      <source>The modules of the webserver could not be detected.</source>
      <comment>Webserver modules</comment>
      <translation>The modules of the webserver could not be detected.</translation>
    </message>
    <message>
      <source>eZ publish was unable to extract information from the webserver.</source>
      <translation>eZ publish was unable to extract information from the webserver.</translation>
    </message>
    <message>
      <source>Webserver (hardware)</source>
      <translation>Webserver (hardware)</translation>
    </message>
    <message>
      <source>CPU</source>
      <comment>CPU info</comment>
      <translation>CPU</translation>
    </message>
    <message>
      <source>Memory</source>
      <comment>Memory info</comment>
      <translation>Memory</translation>
    </message>
    <message>
      <source>Database</source>
      <translation>Database</translation>
    </message>
    <message>
      <source>Type</source>
      <comment>Database type</comment>
      <translation>Type</translation>
    </message>
    <message>
      <source>Server</source>
      <comment>Database server</comment>
      <translation>Server</translation>
    </message>
    <message>
      <source>Socket path</source>
      <comment>Database socket path</comment>
      <translation>Socket path</translation>
    </message>
    <message>
      <source>Database name</source>
      <comment>Database name</comment>
      <translation>Database name</translation>
    </message>
    <message>
      <source>Connection retry count</source>
      <comment>Database retry count</comment>
      <translation>Connection retry count</translation>
    </message>
    <message>
      <source>Character set</source>
      <comment>Database charset</comment>
      <translation>Character set</translation>
    </message>
    <message>
      <source>Internal</source>
      <translation>Internal</translation>
    </message>
    <message>
      <source>Slave database (read only)</source>
      <translation>Slave database (read only)</translation>
    </message>
    <message>
      <source>Database</source>
      <comment>Database name</comment>
      <translation>Database</translation>
    </message>
    <message>
      <source>There is no slave database in use.</source>
      <translation>There is no slave database in use.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/operatorcode</name>
    <message>
      <source>Example</source>
      <translation>Example</translation>
    </message>
    <message>
      <source>Constructor, does nothing by default.</source>
      <translation>Constructor, does nothing by default.</translation>
    </message>
    <message>
      <source>\return an array with the template operator name.</source>
      <translation>\return an array with the template operator name.</translation>
    </message>
    <message>
      <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
      <translation>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</translation>
    </message>
    <message>
      <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
      <translation>Example code, this code must be modified to do what the operator should do, currently it only trims text.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/rad</name>
    <message>
      <source>Rapid Application Development Tools</source>
      <translation>Rapid Application Development Tools</translation>
    </message>
    <message>
      <source>The rapid application development (RAD) tools make the creation of new/extended functionality for eZ publish easier. Currently there are two RAD tools available: the template operator wizard and the datatype wizard. The template operator wizard basically generates a valid framework (PHP code) for a new template operator. The datatype wizard generates a valid framework (PHP code) for a new datatype.</source>
      <translation>The rapid application development (RAD) tools make the creation of new/extended functionality for eZ publish easier. Currently there are two RAD tools available: the template operator wizard and the datatype wizard. The template operator wizard basically generates a valid framework (PHP code) for a new template operator. The datatype wizard generates a valid framework (PHP code) for a new datatype.</translation>
    </message>
    <message>
      <source>Available RAD tools</source>
      <translation>Available RAD tools</translation>
    </message>
    <message>
      <source>Template operator wizard</source>
      <translation>Template operator wizard</translation>
    </message>
    <message>
      <source>Datatype wizard</source>
      <translation>Datatype wizard</translation>
    </message>
    <message>
      <source>Template operator wizard (step 1 of 3)</source>
      <translation>Template operator wizard (step 1 of 3)</translation>
    </message>
    <message>
      <source>Welcome to the template operator wizard. Template operators are usually used for manipulating template variables. However, they can also be used to generate or fetch data. This wizard will take you through a couple of steps with some basic choices. When finished, eZ publish will generate a PHP framework for the a new operator (which will be available for download).</source>
      <translation>Welcome to the template operator wizard. Template operators are usually used for manipulating template variables. However, they can also be used to generate or fetch data. This wizard will take you through a couple of steps with some basic choices. When finished, eZ publish will generate a PHP framework for the a new operator (which will be available for download).</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/rad/datatype</name>
    <message>
      <source>Datatype wizard (step 1 of 3)</source>
      <translation>Datatype wizard (step 1 of 3)</translation>
    </message>
    <message>
      <source>Welcome to the wizard for creating a new datatypes. Everything you store in your content objects are called attributes. These attributes are defined as a data types. To be able to customize the storing and validation of these attributes, you can create your own data types.</source>
      <translation>Welcome to the wizard for creating a new datatypes. Everything you store in your content objects are called attributes. These attributes are defined as a data types. To be able to customize the storing and validation of these attributes, you can create your own data types.</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
    <message>
      <source>Datatype wizard (step 2 of 3)</source>
      <translation>Datatype wizard (step 2 of 3)</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Descriptive name</source>
      <translation>Descriptive name</translation>
    </message>
    <message>
      <source>Handle input on class level</source>
      <translation>Handle input on class level</translation>
    </message>
    <message>
      <source>Datatype wizard (step 3 of 3)</source>
      <translation>Datatype wizard (step 3 of 3)</translation>
    </message>
    <message>
      <source>Name of class</source>
      <translation>Name of class</translation>
    </message>
    <message>
      <source>Constant name</source>
      <translation>Constant name</translation>
    </message>
    <message>
      <source>The creator of the datatype</source>
      <translation>The creator of the datatype</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Handles the datatype %datatype_name. By using %datatype_name you can ...</source>
      <translation>Handles the datatype %datatype_name. By using %datatype_name you can ...</translation>
    </message>
    <message>
      <source>Hint: The first line will be used as the brief description. The rest will become operator documentation.</source>
      <translation>Hint: The first line will be used as the brief description. The rest will become operator documentation.</translation>
    </message>
    <message>
      <source>Finish and generate</source>
      <translation>Finish and generate</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/rad/templateoperator</name>
    <message>
      <source>Template operator wizard (step 2 of 3)</source>
      <translation>Template operator wizard (step 2 of 3)</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Handles input</source>
      <translation>Handles input</translation>
    </message>
    <message>
      <source>Generates output</source>
      <translation>Generates output</translation>
    </message>
    <message>
      <source>Parameters</source>
      <translation>Parameters</translation>
    </message>
    <message>
      <source>No parameters</source>
      <translation>No parameters</translation>
    </message>
    <message>
      <source>Named parameters</source>
      <translation>Named parameters</translation>
    </message>
    <message>
      <source>Sequential parameters</source>
      <translation>Sequential parameters</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Custom</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
    <message>
      <source>Template operator wizard (step 3 of 3)</source>
      <translation>Template operator wizard (step 3 of 3)</translation>
    </message>
    <message>
      <source>Class name</source>
      <translation>Class name</translation>
    </message>
    <message>
      <source>Author</source>
      <translation>Author</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Handles template operator %operator_name. By using %operator_name you can...</source>
      <translation>Handles template operator %operator_name. By using %operator_name you can...</translation>
    </message>
    <message>
      <source>Hint: The first line will be used for the brief description. The rest will become the documentation.</source>
      <translation>Hint: The first line will be used for the brief description. The rest will become the documentation.</translation>
    </message>
    <message>
      <source>Example code</source>
      <translation>Example code</translation>
    </message>
    <message>
      <source>Hint: Feel free to add example code that demonstrates how the operator works.</source>
      <translation>Hint: Feel free to add example code that demonstrates how the operator works.</translation>
    </message>
    <message>
      <source>Finish and generate</source>
      <translation>Finish and generate</translation>
    </message>
  </context>
  <context>
    <name>design/admin/setup/session</name>
    <message>
      <source>The sessions were successfully removed.</source>
      <translation>The sessions were successfully removed.</translation>
    </message>
    <message>
      <source>Session administration</source>
      <translation>Session administration</translation>
    </message>
    <message>
      <source>Sessions</source>
      <translation>Sessions</translation>
    </message>
    <message>
      <source>Total number of sessions</source>
      <translation>Total number of sessions</translation>
    </message>
    <message>
      <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
      <translation>There are %logged_in_count registered and %anonymous_count anonymous users online.</translation>
    </message>
    <message>
      <source>WARNING! When you remove sessions, users that are logged in will be logged out from the system.</source>
      <translation>WARNING! When you remove sessions, users that are logged in will be logged out from the system.</translation>
    </message>
    <message>
      <source>Remove all sessions</source>
      <translation>Remove all sessions</translation>
    </message>
    <message>
      <source>Remove timed out / old sessions</source>
      <translation>Remove timed out / old sessions</translation>
    </message>
    <message>
      <source>Filtered sessions</source>
      <translation>Filtered sessions</translation>
    </message>
    <message>
      <source>Displaying sessions for %username</source>
      <translation>Displaying sessions for %username</translation>
    </message>
    <message>
      <source>Sessions for all users</source>
      <translation>Sessions for all users</translation>
    </message>
    <message>
      <source>Users</source>
      <translation>Users</translation>
    </message>
    <message>
      <source>Everyone</source>
      <translation>Everyone</translation>
    </message>
    <message>
      <source>Registered users</source>
      <translation>Registered users</translation>
    </message>
    <message>
      <source>Anonymous users</source>
      <translation>Anonymous users</translation>
    </message>
    <message>
      <source>Update list</source>
      <translation>Update list</translation>
    </message>
    <message>
      <source>Include inactive users</source>
      <translation>Include inactive users</translation>
    </message>
    <message>
      <source>Invert selection</source>
      <translation>Invert selection</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Count</source>
      <translation>Count</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Full name</source>
      <translation>Full name</translation>
    </message>
    <message>
      <source>Idle time</source>
      <translation>Idle time</translation>
    </message>
    <message>
      <source>Idle since</source>
      <translation>Idle since</translation>
    </message>
    <message>
      <source>Select session for removal.</source>
      <translation>Select session for removal.</translation>
    </message>
    <message>
      <source>Time skew detected</source>
      <translation>Time skew detected</translation>
    </message>
    <message>
      <source>There are no sessions matching the selected options.</source>
      <translation>There are no sessions matching the selected options.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected sessions.</source>
      <translation>Remove selected sessions.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/accounthandlers/html/ez</name>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Company</source>
      <translation>Company</translation>
    </message>
    <message>
      <source>Street</source>
      <translation>Street</translation>
    </message>
    <message>
      <source>Zip code</source>
      <translation>Zip code</translation>
    </message>
    <message>
      <source>Place</source>
      <translation>Place</translation>
    </message>
    <message>
      <source>State</source>
      <translation>State</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/archivelist</name>
    <message>
      <source>Archived orders [%count]</source>
      <translation>Archived orders [%count]</translation>
    </message>
    <message>
      <source>Time</source>
      <translation>Time</translation>
    </message>
    <message>
      <source>Customer</source>
      <translation>Customer</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Select order for removal.</source>
      <translation>Select order for removal.</translation>
    </message>
    <message>
      <source>The order list is empty.</source>
      <translation>The order list is empty.</translation>
    </message>
    <message>
      <source>Unarchive selected</source>
      <translation>Unarchive selected</translation>
    </message>
    <message>
      <source>Unarchive selected orders.</source>
      <translation>Unarchive selected orders.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/basket</name>
    <message>
      <source>Items removed</source>
      <translation>Items removed</translation>
    </message>
    <message>
      <source>The following items were removed from your basket because the products have changed</source>
      <translation>The following items were removed from your basket because the products have changed</translation>
    </message>
    <message>
      <source>VAT is unknown</source>
      <translation>GST is unknown</translation>
    </message>
    <message>
      <source>VAT percentage is not yet known for some of the items being purchased.</source>
      <translation>GST percentage is not yet known for some of the items being purchased.</translation>
    </message>
    <message>
      <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
      <translation>This probably means that some information about you is not yet available and will be obtained during checkout.</translation>
    </message>
    <message>
      <source>Shopping basket</source>
      <translation>Shopping basket</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price (ex. VAT)</source>
      <translation>Price (ex. GST)</translation>
    </message>
    <message>
      <source>Price (inc. VAT)</source>
      <translation>Price (inc. GST)</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>Select item for removal.</source>
      <translation>Select item for removal.</translation>
    </message>
    <message>
      <source>unknown</source>
      <translation>unknown</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>Subtotal of items</source>
      <translation>Subtotal of items</translation>
    </message>
    <message>
      <source>Shipping</source>
      <translation>Shipping</translation>
    </message>
    <message>
      <source>Order total</source>
      <translation>Order total</translation>
    </message>
    <message>
      <source>There are no items in your shopping basket.</source>
      <translation>There are no items in your shopping basket.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected items from the basket.</source>
      <translation>Remove selected items from the basket.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to update the basket if you have modified any quantity and/or option fields.</source>
      <translation>Click this button to update the basket if you have modified any quantity and/or option fields.</translation>
    </message>
    <message>
      <source>Continue shopping</source>
      <translation>Continue shopping</translation>
    </message>
    <message>
      <source>Leave the basket and continue shopping.</source>
      <translation>Leave the basket and continue shopping.</translation>
    </message>
    <message>
      <source>Checkout</source>
      <translation>Checkout</translation>
    </message>
    <message>
      <source>Proceed to checkout and purchase the items that are in the basket.</source>
      <translation>Proceed to checkout and purchase the items that are in the basket.</translation>
    </message>
    <message>
      <source>You can not remove any items because there are no items in the basket.</source>
      <translation>You can not remove any items because there are no items in the basket.</translation>
    </message>
    <message>
      <source>You can not store any changes because the basket is empty.</source>
      <translation>You can not store any changes because the basket is empty.</translation>
    </message>
    <message>
      <source>You can not check out because the basket is empty.</source>
      <translation>You can not check out because the basket is empty.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/browse_discountcustomer</name>
    <message>
      <source>Choose customers for discount group</source>
      <translation>Choose customers for discount group</translation>
    </message>
    <message>
      <source>Use the checkboxes to select users and user groups (customers) that you wish to add to the discount group.</source>
      <translation>Use the checkboxes to select users and user groups (customers) that you wish to add to the discount group.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/browse_discountgroup</name>
    <message>
      <source>Choose products for discount group</source>
      <translation>Choose products for discount group</translation>
    </message>
    <message>
      <source>Use the checkboxes to select products to be included in the discount group.</source>
      <translation>Use the checkboxes to select products to be included in the discount group.</translation>
    </message>
    <message>
      <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
      <translation>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/confirmorder</name>
    <message>
      <source>Order confirmation</source>
      <translation>Order confirmation</translation>
    </message>
    <message>
      <source>Please confirm that the information below is correct. Click &quot;Confirm order&quot; to confirm the order.</source>
      <translation>Please confirm that the information below is correct. Click &quot;Confirm order&quot; to confirm the order.</translation>
    </message>
    <message>
      <source>Customer</source>
      <translation>Customer</translation>
    </message>
    <message>
      <source>Items to be purchased</source>
      <translation>Items to be purchased</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price (ex. VAT)</source>
      <translation>Price (ex. GST)</translation>
    </message>
    <message>
      <source>Price (inc. VAT)</source>
      <translation>Price (inc. GST)</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total price (ex. VAT)</source>
      <translation>Total price (ex. GST)</translation>
    </message>
    <message>
      <source>Total price (inc. VAT)</source>
      <translation>Total price (inc. GST)</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>Order summary</source>
      <translation>Order summary</translation>
    </message>
    <message>
      <source>Subtotal of items</source>
      <translation>Subtotal of items</translation>
    </message>
    <message>
      <source>Order total</source>
      <translation>Order total</translation>
    </message>
    <message>
      <source>Confirm order</source>
      <translation>Confirm order</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/currencylist</name>
    <message>
      <source>Currencies</source>
      <translation>Currencies</translation>
    </message>
    <message>
      <source>Show 10 items per page.</source>
      <translation>Show 10 items per page.</translation>
    </message>
    <message>
      <source>Show 50 items per page.</source>
      <translation>Show 50 items per page.</translation>
    </message>
    <message>
      <source>Show 25 items per page.</source>
      <translation>Show 25 items per page.</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Code</source>
      <translation>Code</translation>
    </message>
    <message>
      <source>Symbol</source>
      <translation>Symbol</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Auto rate</source>
      <translation>Auto rate</translation>
    </message>
    <message>
      <source>Custom rate</source>
      <translation>Custom rate</translation>
    </message>
    <message>
      <source>Factor</source>
      <translation>Factor</translation>
    </message>
    <message>
      <source>Rate</source>
      <translation>Rate</translation>
    </message>
    <message>
      <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
      <translation>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</translation>
    </message>
    <message>
      <source>Unknown currency name</source>
      <translation>Unknown currency name</translation>
    </message>
    <message>
      <source>Select status</source>
      <translation>Select status</translation>
    </message>
    <message>
      <source>N/A</source>
      <translation>N/A</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit '%currency_code' currency.</source>
      <translation>Edit '%currency_code' currency.</translation>
    </message>
    <message>
      <source>The available currency list is empty</source>
      <translation>The available currency list is empty</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected currencies from the list above.</source>
      <translation>Remove selected currencies from the list above.</translation>
    </message>
    <message>
      <source>New currency</source>
      <translation>New currency</translation>
    </message>
    <message>
      <source>Add new currency to the list above.</source>
      <translation>Add new currency to the list above.</translation>
    </message>
    <message>
      <source>Update auto rates</source>
      <translation>Update auto rates</translation>
    </message>
    <message>
      <source>Update auto rates.</source>
      <translation>Update auto rates.</translation>
    </message>
    <message>
      <source>Update autoprices</source>
      <translation>Update autoprices</translation>
    </message>
    <message>
      <source>Update autoprices.</source>
      <translation>Update autoprices.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Apply statuses, custom rates, factor values.</source>
      <translation>Apply statuses, custom rates, factor values.</translation>
    </message>
    <message>
      <source>Preferred currency</source>
      <translation>Preferred currency</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/customerlist</name>
    <message>
      <source>Customers [%customers]</source>
      <translation>Customers [%customers]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Orders</source>
      <translation>Orders</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>The customer list is empty.</source>
      <translation>The customer list is empty.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/customerorderview</name>
    <message>
      <source>Customer information</source>
      <translation>Customer information</translation>
    </message>
    <message>
      <source>Orders [%order_count]</source>
      <translation>Orders [%order_count]</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>Time</source>
      <translation>Time</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Purchased products [%product_count]</source>
      <translation>Purchased products [%product_count]</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/discountgroup</name>
    <message>
      <source>Discount groups [%discount_groups]</source>
      <translation>Discount groups [%discount_groups]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Select discount group for removal.</source>
      <translation>Select discount group for removal.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%discountgroup_name&gt; discount group.</source>
      <translation>Edit the &lt;%discountgroup_name&gt; discount group.</translation>
    </message>
    <message>
      <source>There are no discount groups.</source>
      <translation>There are no discount groups.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected discount groups.</source>
      <translation>Remove selected discount groups.</translation>
    </message>
    <message>
      <source>New discount group</source>
      <translation>New discount group</translation>
    </message>
    <message>
      <source>Create a new discount group.</source>
      <translation>Create a new discount group.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/discountgroupedit</name>
    <message>
      <source>Edit &lt;%discount_group&gt; [Discount group]</source>
      <translation>Edit &lt;%discount_group&gt; [Discount group]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/discountgroupmembershipview</name>
    <message>
      <source>%discount_group [Discount group]</source>
      <translation>%discount_group [Discount group]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this discount group.</source>
      <translation>Edit this discount group.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove this discount group.</source>
      <translation>Remove this discount group.</translation>
    </message>
    <message>
      <source>Discount rules [%rule_count]</source>
      <translation>Discount rules [%rule_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Percent</source>
      <translation>Percent</translation>
    </message>
    <message>
      <source>Apply to</source>
      <translation>Apply to</translation>
    </message>
    <message>
      <source>Select discount rule for removal.</source>
      <translation>Select discount rule for removal.</translation>
    </message>
    <message>
      <source>Edit the &lt;%discount_rule_name&gt; discount rule.</source>
      <translation>Edit the &lt;%discount_rule_name&gt; discount rule.</translation>
    </message>
    <message>
      <source>There are no discount rules in this group.</source>
      <translation>There are no discount rules in this group.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected discount rules.</source>
      <translation>Remove selected discount rules.</translation>
    </message>
    <message>
      <source>New discount rule</source>
      <translation>New discount rule</translation>
    </message>
    <message>
      <source>Create a new discount rule and add it to the &lt;%discount_group_name&gt; discount group.</source>
      <translation>Create a new discount rule and add it to the &lt;%discount_group_name&gt; discount group.</translation>
    </message>
    <message>
      <source>Customers (users and user groups) [%customer_count]</source>
      <translation>Customers (users and user groups) [%customer_count]</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Select user or user group for removal.</source>
      <translation>Select user or user group for removal.</translation>
    </message>
    <message>
      <source>There are no customers in this discount group.</source>
      <translation>There are no customers in this discount group.</translation>
    </message>
    <message>
      <source>Remove selected users and/or user groups.</source>
      <translation>Remove selected users and/or user groups.</translation>
    </message>
    <message>
      <source>Add customers</source>
      <translation>Add customers</translation>
    </message>
    <message>
      <source>Add users and/or user groups to the &lt;%discount_group_name&gt; discount group.</source>
      <translation>Add users and/or user groups to the &lt;%discount_group_name&gt; discount group.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/discountruleedit</name>
    <message>
      <source>New discount rule</source>
      <translation>New discount rule</translation>
    </message>
    <message>
      <source>Edit &lt;%rule_name&gt; [Discount rule]</source>
      <translation>Edit &lt;%rule_name&gt; [Discount rule]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Discount percent</source>
      <translation>Discount percent</translation>
    </message>
    <message>
      <source>Product types</source>
      <translation>Product types</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>in sections</source>
      <translation>in sections</translation>
    </message>
    <message>
      <source>Individual products</source>
      <translation>Individual products</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>The individual product list is empty.</source>
      <translation>The individual product list is empty.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add products</source>
      <translation>Add products</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/editcurrency</name>
    <message>
      <source>Create currency</source>
      <translation>Create currency</translation>
    </message>
    <message>
      <source>Edit '%currency_code' currency</source>
      <translation>Edit '%currency_code' currency</translation>
    </message>
    <message>
      <source>Currency code</source>
      <translation>Currency code</translation>
    </message>
    <message>
      <source>(Use three capital letters)</source>
      <translation>(Use three capital letters)</translation>
    </message>
    <message>
      <source>Currency symbol</source>
      <translation>Currency symbol</translation>
    </message>
    <message>
      <source>Formatting locale</source>
      <translation>Formatting locale</translation>
    </message>
    <message>
      <source>Select locale for formatting price values.</source>
      <translation>Select locale for formatting price values.</translation>
    </message>
    <message>
      <source>Custom rate</source>
      <translation>Custom rate</translation>
    </message>
    <message>
      <source>Rate factor</source>
      <translation>Rate factor</translation>
    </message>
    <message>
      <source>Unable to edit</source>
      <translation>Unable to edit</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Create</translation>
    </message>
    <message>
      <source>Finish creating currency.</source>
      <translation>Finish creating currency.</translation>
    </message>
    <message>
      <source>Store changes</source>
      <translation>Store changes</translation>
    </message>
    <message>
      <source>Store changes.</source>
      <translation>Store changes.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel creating new currency.</source>
      <translation>Cancel creating new currency.</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
    <message>
      <source>Back to the currency list</source>
      <translation>Back to the currency list</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/editvatrule</name>
    <message>
      <source>Edit VAT charging rule</source>
      <translation>Edit GST charging rule</translation>
    </message>
    <message>
      <source>Create new VAT charging rule</source>
      <translation>Create new GST charging rule</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Product categories</source>
      <translation>Product categories</translation>
    </message>
    <message>
      <source>VAT type</source>
      <translation>GST type</translation>
    </message>
    <message>
      <source>Store changes</source>
      <translation>Store changes</translation>
    </message>
    <message>
      <source>Store changes.</source>
      <translation>Store changes.</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Create</translation>
    </message>
    <message>
      <source>Finish creating currency.</source>
      <translation>Finish creating currency.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Cancel creating new currency.</source>
      <translation>Cancel creating new currency.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/orderlist</name>
    <message>
      <source>Orders [%count]</source>
      <translation>Orders [%count]</translation>
    </message>
    <message>
      <source>Time</source>
      <translation>Time</translation>
    </message>
    <message>
      <source>Customer</source>
      <translation>Customer</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Select order for removal.</source>
      <translation>Select order for removal.</translation>
    </message>
    <message>
      <source>( removed )</source>
      <translation>( removed )</translation>
    </message>
    <message>
      <source>The order list is empty.</source>
      <translation>The order list is empty.</translation>
    </message>
    <message>
      <source>Archive selected</source>
      <translation>Archive selected</translation>
    </message>
    <message>
      <source>Archive selected orders.</source>
      <translation>Archive selected orders.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields above.</source>
      <translation>Click this button to store changes if you have modified any of the fields above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/orderstatistics</name>
    <message>
      <source>Product statistics [%count]</source>
      <translation>Product statistics [%count]</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
    <message>
      <source>Total (ex. VAT)</source>
      <translation>Total (ex. GST)</translation>
    </message>
    <message>
      <source>Total (inc. VAT)</source>
      <translation>Total (inc. GST)</translation>
    </message>
    <message>
      <source>SUM</source>
      <translation>SUM</translation>
    </message>
    <message>
      <source>The list is empty.</source>
      <translation>The list is empty.</translation>
    </message>
    <message>
      <source>Select the year for which you wish to view statistics.</source>
      <translation>Select the year for which you wish to view statistics.</translation>
    </message>
    <message>
      <source>All years</source>
      <translation>All years</translation>
    </message>
    <message>
      <source>Select the month for which you wish to view statistics.</source>
      <translation>Select the month for which you wish to view statistics.</translation>
    </message>
    <message>
      <source>All months</source>
      <translation>All months</translation>
    </message>
    <message>
      <source>Show</source>
      <translation>Show</translation>
    </message>
    <message>
      <source>Update the list using the values specified by the menus on the left.</source>
      <translation>Update the list using the values specified by the menus on the left.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/orderview</name>
    <message>
      <source>Order #%order_id [%order_status]</source>
      <translation>Order #%order_id [%order_status]</translation>
    </message>
    <message>
      <source>Product items</source>
      <translation>Product items</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Count</source>
      <translation>Count</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price ex. VAT</source>
      <translation>Price ex. GST</translation>
    </message>
    <message>
      <source>Price inc. VAT</source>
      <translation>Price inc. GST</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total Price ex. VAT</source>
      <translation>Total Price ex. GST</translation>
    </message>
    <message>
      <source>Total Price inc. VAT</source>
      <translation>Total Price inc. GST</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>Order summary</source>
      <translation>Order summary</translation>
    </message>
    <message>
      <source>Subtotal of items</source>
      <translation>Subtotal of items</translation>
    </message>
    <message>
      <source>Order total</source>
      <translation>Order total</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove this order.</source>
      <translation>Remove this order.</translation>
    </message>
    <message>
      <source>Status history [%status_count]</source>
      <translation>Status history [%status_count]</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Date</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Person</source>
      <translation>Person</translation>
    </message>
    <message>
      <source>This is the person which modified the status of the order. Click to view the user information.</source>
      <translation>This is the person which modified the status of the order. Click to view the user information.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/preferredcurrency</name>
    <message>
      <source>The available currency list is empty</source>
      <translation>The available currency list is empty</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/productcategories</name>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Product categories [%categories]</source>
      <translation>Product categories [%categories]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Select product category for removal.</source>
      <translation>Select product category for removal.</translation>
    </message>
    <message>
      <source>There are no product categories.</source>
      <translation>There are no product categories.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected product categories.</source>
      <translation>Remove selected product categories.</translation>
    </message>
    <message>
      <source>New product category</source>
      <translation>New product category</translation>
    </message>
    <message>
      <source>Create a new product category.</source>
      <translation>Create a new product category.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields above.</source>
      <translation>Click this button to store changes if you have modified any of the fields above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/productsoverview</name>
    <message>
      <source>Products overview</source>
      <translation>Products overview</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
    <message>
      <source>Show 10 items per page.</source>
      <translation>Show 10 items per page.</translation>
    </message>
    <message>
      <source>Show 50 items per page.</source>
      <translation>Show 50 items per page.</translation>
    </message>
    <message>
      <source>Show 25 items per page.</source>
      <translation>Show 25 items per page.</translation>
    </message>
    <message>
      <source>The product list is empty.</source>
      <translation>The product list is empty.</translation>
    </message>
    <message>
      <source>Select product class.</source>
      <translation>Select product class.</translation>
    </message>
    <message>
      <source>Show products</source>
      <translation>Show products</translation>
    </message>
    <message>
      <source>Show products of selected class.</source>
      <translation>Show products of selected class.</translation>
    </message>
    <message>
      <source>Sorting</source>
      <translation>Sorting</translation>
    </message>
    <message>
      <source>Select sorting field.</source>
      <translation>Select sorting field.</translation>
    </message>
    <message>
      <source>Select sorting order.</source>
      <translation>Select sorting order.</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Sort products</source>
      <translation>Sort products</translation>
    </message>
    <message>
      <source>Sort products.</source>
      <translation>Sort products.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/removeorder</name>
    <message>
      <source>Confirm order removal</source>
      <translation>Confirm order removal</translation>
    </message>
    <message>
      <source>Are you sure you want to remove order #%order_number?</source>
      <translation>Are you sure you want to remove order #%order_number?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the following orders?</source>
      <translation>Are you sure you want to remove the following orders?</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/removeproductcategories</name>
    <message>
      <source>Confirm removal of product categories</source>
      <translation>Confirm removal of product categories</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the categories?</source>
      <translation>Are you sure you want to remove the categories?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove this category?</source>
      <translation>Are you sure you want to remove this category?</translation>
    </message>
    <message>
      <source>Removing category &lt;%1&gt; will result in modifying 1 VAT charging rule.</source>
      <translation>Removing category &lt;%1&gt; will result in modifying 1 GST charging rule.</translation>
    </message>
    <message>
      <source>Removing category &lt;%1&gt; will result in modifying %2 VAT charging rules.</source>
      <translation>Removing category &lt;%1&gt; will result in modifying %2 GST charging rules.</translation>
    </message>
    <message>
      <source>Removing category &lt;%1&gt; will result in resetting category for 1 product.</source>
      <translation>Removing category &lt;%1&gt; will result in resetting category for 1 product.</translation>
    </message>
    <message>
      <source>Removing category &lt;%1&gt; will result in resetting category for %2 products.</source>
      <translation>Removing category &lt;%1&gt; will result in resetting category for %2 products.</translation>
    </message>
    <message>
      <source>Note that the removal may cause conflicts in VAT charging rules.</source>
      <translation>Note that the removal may cause conflicts in GST charging rules.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/removevattypes</name>
    <message>
      <source>Confirm removal of the VAT types</source>
      <translation>Confirm removal of the GST types</translation>
    </message>
    <message>
      <source>Confirm removal of this VAT type</source>
      <translation>Confirm removal of this GST type</translation>
    </message>
    <message>
      <source>Removing VAT types</source>
      <translation>Removing GST types</translation>
    </message>
    <message>
      <source>Removing VAT type</source>
      <translation>Removing GST type</translation>
    </message>
    <message>
      <source>Unable to remove the VAT types</source>
      <translation>Unable to remove the GST types</translation>
    </message>
    <message>
      <source>Unable to remove this VAT type</source>
      <translation>Unable to remove this GST type</translation>
    </message>
    <message>
      <source>Are you sure you want to remove the VAT types?</source>
      <translation>Are you sure you want to remove the GST types?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove this VAT type?</source>
      <translation>Are you sure you want to remove this GST type?</translation>
    </message>
    <message>
      <source>VAT type &lt;%1&gt; is set as default for 1 product class.</source>
      <translation>GST type &lt;%1&gt; is set as default for 1 product class.</translation>
    </message>
    <message>
      <source>VAT type &lt;%1&gt; is set as default for %2 product classes.</source>
      <translation>GST type &lt;%1&gt; is set as default for %2 product classes.</translation>
    </message>
    <message>
      <source>Removing VAT type &lt;%1&gt; will result in removal of 1 VAT charging rule.</source>
      <translation>Removing GST type &lt;%1&gt; will result in removal of 1 GST charging rule.</translation>
    </message>
    <message>
      <source>Removing VAT type &lt;%1&gt; will result in removal of %2 VAT charging rules.</source>
      <translation>Removing GST type &lt;%1&gt; will result in removal of %2 GST charging rules.</translation>
    </message>
    <message>
      <source>Removing VAT type &lt;%1&gt; will result in resetting VAT type for 1 product to its default value.</source>
      <translation>Removing GST type &lt;%1&gt; will result in resetting GST type for 1 product to its default value.</translation>
    </message>
    <message>
      <source>Removing VAT type &lt;%1&gt; will result in resetting VAT type for %2 products to its default value.</source>
      <translation>Removing GST type &lt;%1&gt; will result in resetting GST type for %2 products to its default value.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/status</name>
    <message>
      <source>Order status [%order_status]</source>
      <translation>Order status [%order_status]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Status ID</source>
      <translation>Status ID</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Select order status for removal.</source>
      <translation>Select order status for removal.</translation>
    </message>
    <message>
      <source>Check this if you want the status to be usable in the shopping system.</source>
      <translation>Check this if you want the status to be usable in the shopping system.</translation>
    </message>
    <message>
      <source>There are no order statuses.</source>
      <translation>There are no order statuses.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected order statuses.</source>
      <translation>Remove selected order statuses.</translation>
    </message>
    <message>
      <source>New order status</source>
      <translation>New order status</translation>
    </message>
    <message>
      <source>Create a new order status.</source>
      <translation>Create a new order status.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields above.</source>
      <translation>Click this button to store changes if you have modified any of the fields above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/userregister</name>
    <message>
      <source>Required information is missing...</source>
      <translation>Required information is missing...</translation>
    </message>
    <message>
      <source>Please please fill in the fields that are marked with a star.</source>
      <translation>Please please fill in the fields that are marked with a star.</translation>
    </message>
    <message>
      <source>Account information</source>
      <translation>Account information</translation>
    </message>
    <message>
      <source>Please fill in the necessary information. Required fields are marked with a star.</source>
      <translation>Please fill in the necessary information. Required fields are marked with a star.</translation>
    </message>
    <message>
      <source>First name</source>
      <translation>First name</translation>
    </message>
    <message>
      <source>Last name</source>
      <translation>Last name</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Company</source>
      <translation>Company</translation>
    </message>
    <message>
      <source>Street</source>
      <translation>Street</translation>
    </message>
    <message>
      <source>ZIP code</source>
      <translation>ZIP code</translation>
    </message>
    <message>
      <source>City</source>
      <translation>City</translation>
    </message>
    <message>
      <source>State</source>
      <translation>State</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Comments</source>
      <translation>Comments</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/vatrules</name>
    <message>
      <source>Wrong or missing rules.</source>
      <translation>Wrong or missing rules.</translation>
    </message>
    <message>
      <source>Errors in VAT rules configuration may lead to charging wrong VAT for your products. Please fix them.</source>
      <translation>Errors in GST rules configuration may lead to charging wrong GST for your products. Please fix them.</translation>
    </message>
    <message>
      <source>VAT charging rules [%rules]</source>
      <translation>GST charging rules [%rules]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Product categories</source>
      <translation>Product categories</translation>
    </message>
    <message>
      <source>VAT type</source>
      <translation>GST type</translation>
    </message>
    <message>
      <source>Select rule for removal.</source>
      <translation>Select rule for removal.</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit rule.</source>
      <translation>Edit rule.</translation>
    </message>
    <message>
      <source>There are no VAT charging rules.</source>
      <translation>There are no GST charging rules.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected VAT charging rules.</source>
      <translation>Remove selected GST charging rules.</translation>
    </message>
    <message>
      <source>New rule</source>
      <translation>New rule</translation>
    </message>
    <message>
      <source>Create a new VAT charging rule.</source>
      <translation>Create a new GST charging rule.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/vattype</name>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>VAT types [%vat_types]</source>
      <translation>GST types [%vat_types]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Percentage</source>
      <translation>Percentage</translation>
    </message>
    <message>
      <source>Select VAT type for removal.</source>
      <translation>Select GST type for removal.</translation>
    </message>
    <message>
      <source>There are no VAT types.</source>
      <translation>There are no GST types.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected VAT types.</source>
      <translation>Remove selected GST types.</translation>
    </message>
    <message>
      <source>New VAT type</source>
      <translation>New GST type</translation>
    </message>
    <message>
      <source>Create a new VAT type.</source>
      <translation>Create a new GST type.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields above.</source>
      <translation>Click this button to store changes if you have modified any of the fields above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/shop/wishlist</name>
    <message>
      <source>My wish list [%item_count]</source>
      <translation>My wish list [%item_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price (ex. VAT)</source>
      <translation>Price (ex. GST)</translation>
    </message>
    <message>
      <source>Price (inc. VAT)</source>
      <translation>Price (inc. GST)</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total price (ex. VAT)</source>
      <translation>Total price (ex. GST)</translation>
    </message>
    <message>
      <source>Total price (inc. VAT)</source>
      <translation>Total price (inc. GST)</translation>
    </message>
    <message>
      <source>Select item for removal.</source>
      <translation>Select item for removal.</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>The wish list is empty.</source>
      <translation>The wish list is empty.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected items.</source>
      <translation>Remove selected items.</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified quantity and/or option values.</source>
      <translation>Click this button to store changes if you have modified quantity and/or option values.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/trigger/list</name>
    <message>
      <source>Workflow triggers [%trigger_count]</source>
      <translation>Workflow triggers [%trigger_count]</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Connection type</source>
      <translation>Connection type</translation>
    </message>
    <message>
      <source>Workflow</source>
      <translation>Workflow</translation>
    </message>
    <message>
      <source>Select the workflow that should be triggered %type the %function function is executed within the %module module.</source>
      <translation>Select the workflow that should be triggered %type the %function function is executed within the %module module.</translation>
    </message>
    <message>
      <source>No workflow</source>
      <translation>No workflow</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified any of the fields above.</source>
      <translation>Click this button to store changes if you have modified any of the fields above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/url/edit</name>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>Edit URL #%url_id</source>
      <translation>Edit URL #%url_id</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/url/list</name>
    <message>
      <source>Valid URLs [%url_list_count]</source>
      <translation>Valid URLs [%url_list_count]</translation>
    </message>
    <message>
      <source>Invalid URLs [%url_list_count]</source>
      <translation>Invalid URLs [%url_list_count]</translation>
    </message>
    <message>
      <source>All URLs [%url_list_count]</source>
      <translation>All URLs [%url_list_count]</translation>
    </message>
    <message>
      <source>Show all URLs.</source>
      <translation>Show all URLs.</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>Valid</source>
      <translation>Valid</translation>
    </message>
    <message>
      <source>Show only invalid URLs.</source>
      <translation>Show only invalid URLs.</translation>
    </message>
    <message>
      <source>Invalid</source>
      <translation>Invalid</translation>
    </message>
    <message>
      <source>Show only valid URLs.</source>
      <translation>Show only valid URLs.</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Checked</source>
      <translation>Checked</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>View information about URL.</source>
      <translation>View information about URL.</translation>
    </message>
    <message>
      <source>Open URL in new window.</source>
      <translation>Open URL in new window.</translation>
    </message>
    <message>
      <source>open</source>
      <translation>open</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Never</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit URL.</source>
      <translation>Edit URL.</translation>
    </message>
    <message>
      <source>The requested list is empty.</source>
      <translation>The requested list is empty.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/url/view</name>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>URL #%url_id</source>
      <translation>URL #%url_id</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Archived</source>
      <translation>Archived</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rejected</translation>
    </message>
    <message>
      <source> (in trash)</source>
      <translation> (in trash)</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Valid</source>
      <translation>Valid</translation>
    </message>
    <message>
      <source>Invalid</source>
      <translation>Invalid</translation>
    </message>
    <message>
      <source>Last checked</source>
      <translation>Last checked</translation>
    </message>
    <message>
      <source>This URL has not been checked.</source>
      <translation>This URL has not been checked.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this URL.</source>
      <translation>Edit this URL.</translation>
    </message>
    <message>
      <source>Objects using URL #%url_id [%url_count]</source>
      <translation>Objects using URL #%url_id [%url_count]</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>View the contents of version #%version_number.</source>
      <translation>View the contents of version #%version_number.</translation>
    </message>
    <message>
      <source>Edit &lt;%object_name&gt;.</source>
      <translation>Edit &lt;%object_name&gt;.</translation>
    </message>
    <message>
      <source>URL #%url_id is not in use by any objects.</source>
      <translation>URL #%url_id is not in use by any objects.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/user</name>
    <message>
      <source>Activate account</source>
      <translation>Activate account</translation>
    </message>
    <message>
      <source>Your account is now activated.</source>
      <translation>Your account is now activated.</translation>
    </message>
    <message>
      <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
      <translation>Sorry, the key submitted was not a valid key. Account was not activated.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>User registered</source>
      <translation>User registered</translation>
    </message>
    <message>
      <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
      <translation>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</translation>
    </message>
    <message>
      <source>Your account was successfully created.</source>
      <translation>Your account was successfully created.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/user/login</name>
    <message>
      <source>The system could not log you in.</source>
      <translation>The system could not log you in.</translation>
    </message>
    <message>
      <source>Make sure that the username and password is correct.</source>
      <translation>Make sure that the username and password is correct.</translation>
    </message>
    <message>
      <source>All letters must be typed in using the correct case.</source>
      <translation>All letters must be typed in using the correct case.</translation>
    </message>
    <message>
      <source>Please try again or contact the site administrator.</source>
      <translation>Please try again or contact the site administrator.</translation>
    </message>
    <message>
      <source>Access denied!</source>
      <translation>Access denied!</translation>
    </message>
    <message>
      <source>You do not have permissions to access &lt;%siteaccess_name&gt;.</source>
      <translation>You do not have permissions to access &lt;%siteaccess_name&gt;.</translation>
    </message>
    <message>
      <source>Please contact the site administrator.</source>
      <translation>Please contact the site administrator.</translation>
    </message>
    <message>
      <source>Log in to the administration interface of eZ publish</source>
      <translation>Log in to the administration interface of eZ publish</translation>
    </message>
    <message>
      <source>Please enter a valid username/password combination and click &quot;Log in&quot;.</source>
      <translation>Please enter a valid username/password combination and click &quot;Log in&quot;.</translation>
    </message>
    <message>
      <source>Use the &quot;Register&quot; button to create a new account.</source>
      <translation>Use the &quot;Register&quot; button to create a new account.</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Enter a valid username into this field.</source>
      <translation>Enter a valid username into this field.</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Enter a valid password into this field.</source>
      <translation>Enter a valid password into this field.</translation>
    </message>
    <message>
      <source>Log in</source>
      <comment>Login button</comment>
      <translation>Log in</translation>
    </message>
    <message>
      <source>Click here to log in using the username/password combination entered in the fields above.</source>
      <translation>Click here to log in using the username/password combination entered in the fields above.</translation>
    </message>
    <message>
      <source>Register</source>
      <comment>Register button</comment>
      <translation>Register</translation>
    </message>
    <message>
      <source>Click here to create a new account.</source>
      <translation>Click here to create a new account.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/user/password</name>
    <message>
      <source>The password could not be changed.</source>
      <translation>The password could not be changed.</translation>
    </message>
    <message>
      <source>The old password was either missing or incorrect.</source>
      <translation>The old password was either missing or incorrect.</translation>
    </message>
    <message>
      <source>Please retype the old password and try again.</source>
      <translation>Please retype the old password and try again.</translation>
    </message>
    <message>
      <source>The new passwords did not match.</source>
      <translation>The new passwords did not match.</translation>
    </message>
    <message>
      <source>Please retype the new passwords and try again.</source>
      <translation>Please retype the new passwords and try again.</translation>
    </message>
    <message>
      <source>The password must be at least 3 characters long.</source>
      <translation>The password must be at least 3 characters long.</translation>
    </message>
    <message>
      <source>The password was successfully changed.</source>
      <translation>The password was successfully changed.</translation>
    </message>
    <message>
      <source>Change password for &lt;%username&gt;</source>
      <translation>Change password for &lt;%username&gt;</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Old password</source>
      <translation>Old password</translation>
    </message>
    <message>
      <source>New password</source>
      <translation>New password</translation>
    </message>
    <message>
      <source>Confirm new password</source>
      <translation>Confirm new password</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/user/register</name>
    <message>
      <source>The information could not be stored...</source>
      <translation>The information could not be stored...</translation>
    </message>
    <message>
      <source>The following information is either incorrect or missing</source>
      <translation>The following information is either incorrect or missing</translation>
    </message>
    <message>
      <source>Please correct the inputs (marked with red labels) and try again.</source>
      <translation>Please correct the inputs (marked with red labels) and try again.</translation>
    </message>
    <message>
      <source>Register new user</source>
      <translation>Register new user</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Unable to register new user</source>
      <translation>Unable to register new user</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
  </context>
  <context>
    <name>design/admin/user/setting</name>
    <message>
      <source>User settings for &lt;%user_name&gt;</source>
      <translation>User settings for &lt;%user_name&gt;</translation>
    </message>
    <message>
      <source>Maximum concurrent logins</source>
      <translation>Maximum concurrent logins</translation>
    </message>
    <message>
      <source>This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]</source>
      <translation>This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]</translation>
    </message>
    <message>
      <source>Enable user account</source>
      <translation>Enable user account</translation>
    </message>
    <message>
      <source>Use this checkbox to enable or disable the user account.</source>
      <translation>Use this checkbox to enable or disable the user account.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/menuconfig</name>
    <message>
      <source>Menu management</source>
      <translation>Menu management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Menu positioning</source>
      <translation>Menu positioning</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click here to store the changes if you have modified the menu settings above.</source>
      <translation>Click here to store the changes if you have modified the menu settings above.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/templatecreate</name>
    <message>
      <source>Could not create template, permission denied.</source>
      <translation>Could not create template, permission denied.</translation>
    </message>
    <message>
      <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
      <translation>Invalid name. You can only use the characters a-z, numbers and _.</translation>
    </message>
    <message>
      <source>Create new template override for &lt;%template_name&gt;</source>
      <translation>Create new template override for &lt;%template_name&gt;</translation>
    </message>
    <message>
      <source>The newly created template file will be placed in</source>
      <translation>The newly created template file will be placed in</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Filename</translation>
    </message>
    <message>
      <source>Override keys</source>
      <translation>Override keys</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>All classes</source>
      <translation>All classes</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>All sections</source>
      <translation>All sections</translation>
    </message>
    <message>
      <source>Node ID</source>
      <translation>Node ID</translation>
    </message>
    <message>
      <source>Base template on</source>
      <translation>Base template on</translation>
    </message>
    <message>
      <source>Empty file</source>
      <translation>Empty file</translation>
    </message>
    <message>
      <source>Copy of default template</source>
      <translation>Copy of default template</translation>
    </message>
    <message>
      <source>Container (with children)</source>
      <translation>Container (with children)</translation>
    </message>
    <message>
      <source>View (without children)</source>
      <translation>View (without children)</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Object</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/templateedit</name>
    <message>
      <source>Edit template: &lt;%template&gt;</source>
      <translation>Edit template: &lt;%template&gt;</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to save the contents of the text field above to the template file.</source>
      <translation>Click this button to save the contents of the text field above to the template file.</translation>
    </message>
    <message>
      <source>You do not have permissions to save the contents of the text field above to the template file.</source>
      <translation>You do not have permissions to save the contents of the text field above to the template file.</translation>
    </message>
    <message>
      <source>Back to overrides</source>
      <translation>Back to overrides</translation>
    </message>
    <message>
      <source>Back to override overview.</source>
      <translation>Back to override overview.</translation>
    </message>
    <message>
      <source>The template can not be edited.</source>
      <translation>The template can not be edited.</translation>
    </message>
    <message>
      <source>The web server does not have write access to the requested template.</source>
      <translation>The web server does not have write access to the requested template.</translation>
    </message>
    <message>
      <source>The web server does not have read access to the requested template.</source>
      <translation>The web server does not have read access to the requested template.</translation>
    </message>
    <message>
      <source>The requested template does not exist or is not being used as an override.</source>
      <translation>The requested template does not exist or is not being used as an override.</translation>
    </message>
    <message>
      <source>Edit &lt;%template_name&gt; [Template]</source>
      <translation>Edit &lt;%template_name&gt; [Template]</translation>
    </message>
    <message>
      <source>Requested template</source>
      <translation>Requested template</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Overrides template</source>
      <translation>Overrides template</translation>
    </message>
    <message>
      <source>Open as read only</source>
      <translation>Open as read only</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/templatelist</name>
    <message>
      <source>Template list</source>
      <translation>Template list</translation>
    </message>
    <message>
      <source>Template</source>
      <translation>Template</translation>
    </message>
    <message>
      <source>Design resource</source>
      <translation>Design resource</translation>
    </message>
    <message>
      <source>Manage overrides for template.</source>
      <translation>Manage overrides for template.</translation>
    </message>
    <message>
      <source>Most common templates</source>
      <translation>Most common templates</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/templateview</name>
    <message>
      <source>The overrides could not be removed.</source>
      <translation>The overrides could not be removed.</translation>
    </message>
    <message>
      <source>The following files and override rules could not be removed because of insufficient file permissions</source>
      <translation>The following files and override rules could not be removed because of insufficient file permissions</translation>
    </message>
    <message>
      <source>The override.ini file could not be modified because of insufficient permissions.</source>
      <translation>The override.ini file could not be modified because of insufficient permissions.</translation>
    </message>
    <message>
      <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
      <translation>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</translation>
    </message>
    <message>
      <source>Default template resource</source>
      <translation>Default template resource</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Match conditions</source>
      <translation>Match conditions</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>No file matched</source>
      <translation>No file matched</translation>
    </message>
    <message>
      <source>Edit override template.</source>
      <translation>Edit override template.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected template overrides.</source>
      <translation>Remove selected template overrides.</translation>
    </message>
    <message>
      <source>New override</source>
      <translation>New override</translation>
    </message>
    <message>
      <source>Create a new template override.</source>
      <translation>Create a new template override.</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
  </context>
  <context>
    <name>design/admin/visual/toolbar</name>
    <message>
      <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
      <translation>Tool List for &lt;Toolbar_%toolbar_position&gt;</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>There are currently no tools in this toolbar</source>
      <translation>There are currently no tools in this toolbar</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
    <message>
      <source>Add Tool</source>
      <translation>Add Tool</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified the parameters above.</source>
      <translation>Click this button to store changes if you have modified the parameters above.</translation>
    </message>
    <message>
      <source>Back to toolbars</source>
      <translation>Back to toolbars</translation>
    </message>
    <message>
      <source>Go back to the toolbar list.</source>
      <translation>Go back to the toolbar list.</translation>
    </message>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Current siteaccess</source>
      <translation>Current siteaccess</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
      <translation>Available toolbars for the &lt;%siteaccess&gt; siteaccess</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/edit</name>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Data requires fixup</source>
      <translation>Data requires fixup</translation>
    </message>
    <message>
      <source>Edit &lt;%workflow_name&gt; [Workflow]</source>
      <translation>Edit &lt;%workflow_name&gt; [Workflow]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Move down</source>
      <translation>Move down</translation>
    </message>
    <message>
      <source>Move up</source>
      <translation>Move up</translation>
    </message>
    <message>
      <source>Description / comments</source>
      <translation>Description / comments</translation>
    </message>
    <message>
      <source>There are no events within this workflow.</source>
      <translation>There are no events within this workflow.</translation>
    </message>
    <message>
      <source>Remove selected events</source>
      <translation>Remove selected events</translation>
    </message>
    <message>
      <source>Add event</source>
      <translation>Add event</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
      <source>Affected sections</source>
      <translation>Affected sections</translation>
    </message>
    <message>
      <source>All sections</source>
      <translation>All sections</translation>
    </message>
    <message>
      <source>Affected languages</source>
      <translation>Affected languages</translation>
    </message>
    <message>
      <source>All languages</source>
      <translation>All languages</translation>
    </message>
    <message>
      <source>Users who approves content</source>
      <translation>Users who approves content</translation>
    </message>
    <message>
      <source>User</source>
      <translation>User</translation>
    </message>
    <message>
      <source>No users selected.</source>
      <translation>No users selected.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add users</source>
      <translation>Add users</translation>
    </message>
    <message>
      <source>Groups who approves content</source>
      <translation>Groups who approves content</translation>
    </message>
    <message>
      <source>Group</source>
      <translation>Group</translation>
    </message>
    <message>
      <source>No groups selected.</source>
      <translation>No groups selected.</translation>
    </message>
    <message>
      <source>Add groups</source>
      <translation>Add groups</translation>
    </message>
    <message>
      <source>Excluded user groups ( users in these groups do not need to have their content approved )</source>
      <translation>Excluded user groups ( users in these groups do not need to have their content approved )</translation>
    </message>
    <message>
      <source>User and user groups</source>
      <translation>User and user groups</translation>
    </message>
    <message>
      <source>Classes to run workflow</source>
      <translation>Classes to run workflow</translation>
    </message>
    <message>
      <source>All classes</source>
      <translation>All classes</translation>
    </message>
    <message>
      <source>Users without workflow IDs</source>
      <translation>Users without workflow IDs</translation>
    </message>
    <message>
      <source>Workflow to run</source>
      <translation>Workflow to run</translation>
    </message>
    <message>
      <source>You have to create a workflow before using this event.</source>
      <translation>You have to create a workflow before using this event.</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>There are no payment Gateway extensions installed.</source>
      <translation>There are no payment Gateway extensions installed.</translation>
    </message>
    <message>
      <source>Please install a payment extension first.</source>
      <translation>Please install a payment extension first.</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Update attributes</source>
      <translation>Update attributes</translation>
    </message>
    <message>
      <source>Attribute</source>
      <translation>Attribute</translation>
    </message>
    <message>
      <source>Select attribute</source>
      <translation>Select attribute</translation>
    </message>
    <message>
      <source>Class/attribute combinations [%count]</source>
      <translation>Class/attribute combinations [%count]</translation>
    </message>
    <message>
      <source>There are no combinations</source>
      <translation>There are no combinations</translation>
    </message>
    <message>
      <source>Modify the objects' publishing dates</source>
      <translation>Modify the objects' publishing dates</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/groupedit</name>
    <message>
      <source>Edit &lt;%group_name&gt; [Workflow group]</source>
      <translation>Edit &lt;%group_name&gt; [Workflow group]</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/grouplist</name>
    <message>
      <source>Workflow groups [%groups_count]</source>
      <translation>Workflow groups [%groups_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Select workflow group for removal.</source>
      <translation>Select workflow group for removal.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit the &lt;%workflow_group_name&gt; workflow group.</source>
      <translation>Edit the &lt;%workflow_group_name&gt; workflow group.</translation>
    </message>
    <message>
      <source>There are no workflow groups.</source>
      <translation>There are no workflow groups.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected workflow groups.</source>
      <translation>Remove selected workflow groups.</translation>
    </message>
    <message>
      <source>New workflow group</source>
      <translation>New workflow group</translation>
    </message>
    <message>
      <source>Create a new workflow group.</source>
      <translation>Create a new workflow group.</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/view</name>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>%workflow_name [Workflow]</source>
      <translation>%workflow_name [Workflow]</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Member of groups [%group_count]</source>
      <translation>Member of groups [%group_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Group</source>
      <translation>Group</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Add to group</source>
      <translation>Add to group</translation>
    </message>
    <message>
      <source>No group</source>
      <translation>No group</translation>
    </message>
    <message>
      <source>Events [%event_count]</source>
      <translation>Events [%event_count]</translation>
    </message>
    <message>
      <source>Position</source>
      <translation>Position</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Additional information</source>
      <translation>Additional information</translation>
    </message>
  </context>
  <context>
    <name>design/admin/workflow/workflowlist</name>
    <message>
      <source>%group_name [Workflow group]</source>
      <translation>%group_name [Workflow group]</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit this workflow group.</source>
      <translation>Edit this workflow group.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove this workflow group.</source>
      <translation>Remove this workflow group.</translation>
    </message>
    <message>
      <source>Back to workflow groups.</source>
      <translation>Back to workflow groups.</translation>
    </message>
    <message>
      <source>Workflows [%workflow_count]</source>
      <translation>Workflows [%workflow_count]</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Select workflow for removal.</source>
      <translation>Select workflow for removal.</translation>
    </message>
    <message>
      <source>Edit the &lt;%workflow_name&gt; workflow.</source>
      <translation>Edit the &lt;%workflow_name&gt; workflow.</translation>
    </message>
    <message>
      <source>There are no workflows in this group.</source>
      <translation>There are no workflows in this group.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected workflows.</source>
      <translation>Remove selected workflows.</translation>
    </message>
    <message>
      <source>New workflow</source>
      <translation>New workflow</translation>
    </message>
    <message>
      <source>Create a new workflow.</source>
      <translation>Create a new workflow.</translation>
    </message>
  </context>
  <context>
    <name>design/base</name>
    <message>
      <source>Poll %pollname</source>
      <translation>Poll %pollname</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Results</translation>
    </message>
    <message>
      <source>Anonymous users are not allowed to vote on this poll, please login.</source>
      <translation>Anonymous users are not allowed to vote on this poll, please login.</translation>
    </message>
    <message>
      <source>You have already voted for this poll.</source>
      <translation>You have already voted for this poll.</translation>
    </message>
    <message>
      <source>Votes</source>
      <translation>Votes</translation>
    </message>
    <message>
      <source>%count total votes</source>
      <translation>%count total votes</translation>
    </message>
    <message>
      <source>Back to poll</source>
      <translation>Back to poll</translation>
    </message>
    <message>
      <source>Collected information from %1</source>
      <translation>Collected information from %1</translation>
    </message>
    <message>
      <source>The following information was collected</source>
      <translation>The following information was collected</translation>
    </message>
    <message>
      <source>The file could not be found.</source>
      <translation>The file could not be found.</translation>
    </message>
    <message>
      <source>New row</source>
      <translation>New row</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Remove Selected</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
    <message>
      <source>Your price</source>
      <translation>Your price</translation>
    </message>
    <message>
      <source>You save</source>
      <translation>You save</translation>
    </message>
    <message>
      <source>N/A</source>
      <translation>N/A</translation>
    </message>
    <message>
      <source>Edit %1 - %2</source>
      <translation>Edit %1 - %2</translation>
    </message>
    <message>
      <source>Send for publishing</source>
      <translation>Send for publishing</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Publish</source>
      <translation>Publish</translation>
    </message>
    <message>
      <source>Subject</source>
      <translation>Subject</translation>
    </message>
    <message>
      <source>Message</source>
      <translation>Message</translation>
    </message>
    <message>
      <source>Notify me about updates</source>
      <translation>Notify me about updates</translation>
    </message>
    <message>
      <source>Sticky</source>
      <translation>Sticky</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Create new weblog</source>
      <translation>Create new weblog</translation>
    </message>
    <message>
      <source>Post</source>
      <translation>Post</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Read more...</source>
      <translation>Read more...</translation>
    </message>
    <message>
      <source>Contact information</source>
      <translation>Contact information</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Additional information</source>
      <translation>Additional information</translation>
    </message>
    <message>
      <source>Latest from</source>
      <translation>Latest from</translation>
    </message>
    <message>
      <source>Vote</source>
      <translation>Vote</translation>
    </message>
    <message>
      <source>Tip a friend</source>
      <translation>Tip a friend</translation>
    </message>
    <message>
      <source>Download PDF</source>
      <translation>Download PDF</translation>
    </message>
    <message>
      <source>Download PDF version of this page</source>
      <translation>Download PDF version of this page</translation>
    </message>
    <message>
      <source>Comments</source>
      <translation>Comments</translation>
    </message>
    <message>
      <source>New Comment</source>
      <translation>New Comment</translation>
    </message>
    <message>
      <source>You are not allowed to create comments.</source>
      <translation>You are not allowed to create comments.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Contacts</source>
      <translation>Contacts</translation>
    </message>
    <message>
      <source>Your E-mail address</source>
      <translation>Your E-mail address</translation>
    </message>
    <message>
      <source>Send form</source>
      <translation>Send form</translation>
    </message>
    <message>
      <source>New topic</source>
      <translation>New topic</translation>
    </message>
    <message>
      <source>Keep me updated</source>
      <translation>Keep me updated</translation>
    </message>
    <message>
      <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
      <translation>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</translation>
    </message>
    <message>
      <source>Topic</source>
      <translation>Topic</translation>
    </message>
    <message>
      <source>Replies</source>
      <translation>Replies</translation>
    </message>
    <message>
      <source>Author</source>
      <translation>Author</translation>
    </message>
    <message>
      <source>Last reply</source>
      <translation>Last reply</translation>
    </message>
    <message>
      <source>Pages</source>
      <translation>Pages</translation>
    </message>
    <message>
      <source>Message preview</source>
      <translation>Message preview</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Moderated by</source>
      <translation>Moderated by</translation>
    </message>
    <message>
      <source>Previous topic</source>
      <translation>Previous topic</translation>
    </message>
    <message>
      <source>Next topic</source>
      <translation>Next topic</translation>
    </message>
    <message>
      <source>New reply</source>
      <translation>New reply</translation>
    </message>
    <message>
      <source>You need to be logged in to get access to the forums. You can do so</source>
      <translation>You need to be logged in to get access to the forums. You can do so</translation>
    </message>
    <message>
      <source>here</source>
      <translation>here</translation>
    </message>
    <message>
      <source>View as slideshow</source>
      <translation>View as slideshow</translation>
    </message>
    <message>
      <source>Previous image</source>
      <translation>Previous image</translation>
    </message>
    <message>
      <source>Next image</source>
      <translation>Next image</translation>
    </message>
    <message>
      <source>Add to basket</source>
      <translation>Add to basket</translation>
    </message>
    <message>
      <source>Download this product sheet as PDF</source>
      <translation>Download this product sheet as PDF</translation>
    </message>
    <message>
      <source>Product reviews</source>
      <translation>Product reviews</translation>
    </message>
    <message>
      <source>New review</source>
      <translation>New review</translation>
    </message>
    <message>
      <source>People who bought this also bought</source>
      <translation>People who bought this also bought</translation>
    </message>
    <message>
      <source>Result</source>
      <translation>Result</translation>
    </message>
    <message>
      <source>Previous entry</source>
      <translation>Previous entry</translation>
    </message>
    <message>
      <source>Next entry</source>
      <translation>Next entry</translation>
    </message>
    <message>
      <source>New comment</source>
      <translation>New comment</translation>
    </message>
    <message>
      <source>More...</source>
      <translation>More...</translation>
    </message>
    <message>
      <source>Details...</source>
      <translation>Details...</translation>
    </message>
    <message>
      <source>View flash</source>
      <translation>View flash</translation>
    </message>
    <message>
      <source>View list</source>
      <translation>View list</translation>
    </message>
    <message>
      <source>Number of Topics</source>
      <translation>Number of Topics</translation>
    </message>
    <message>
      <source>Number of Posts</source>
      <translation>Number of Posts</translation>
    </message>
    <message>
      <source>Enter forum</source>
      <translation>Enter forum</translation>
    </message>
    <message>
      <source>Reply to:</source>
      <translation>Reply to:</translation>
    </message>
    <message>
      <source>Enter gallery</source>
      <translation>Enter gallery</translation>
    </message>
    <message>
      <source>More information</source>
      <translation>More information</translation>
    </message>
    <message>
      <source>%count votes</source>
      <translation>%count votes</translation>
    </message>
    <message>
      <source>View movie</source>
      <translation>View movie</translation>
    </message>
    <message>
      <source>in</source>
      <translation>in</translation>
    </message>
    <message>
      <source>View comments</source>
      <translation>View comments</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Author: </translation>
    </message>
    <message>
      <source>#page of #total</source>
      <translation>#page of #total</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>For more options try the %1Advanced search%2</source>
      <comment>The parameters are link start and end tags.</comment>
      <translation>For more options try the %1Advanced search%2</translation>
    </message>
    <message>
      <source>The following words were excluded from the search</source>
      <translation>The following words were excluded from the search</translation>
    </message>
    <message>
      <source>No results were found when searching for &quot;%1&quot;</source>
      <translation>No results were found when searching for &quot;%1&quot;</translation>
    </message>
    <message>
      <source>Search tips</source>
      <translation>Search tips</translation>
    </message>
    <message>
      <source>Check spelling of keywords.</source>
      <translation>Check spelling of keywords.</translation>
    </message>
    <message>
      <source>Try changing some keywords eg. car instead of cars.</source>
      <translation>Try changing some keywords eg. car instead of cars.</translation>
    </message>
    <message>
      <source>Try more general keywords.</source>
      <translation>Try more general keywords.</translation>
    </message>
    <message>
      <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
      <translation>Fewer keywords gives more results, try reducing keywords until you get a result.</translation>
    </message>
    <message>
      <source>Search for &quot;%1&quot; returned %2 matches</source>
      <translation>Search for &quot;%1&quot; returned %2 matches</translation>
    </message>
    <message>
      <source>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</source>
      <translation>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</translation>
    </message>
    <message>
      <source>Top menu</source>
      <translation>Top menu</translation>
    </message>
    <message>
      <source>Sub menu</source>
      <translation>Sub menu</translation>
    </message>
    <message>
      <source>Left menu</source>
      <translation>Left menu</translation>
    </message>
    <message>
      <source>Left sub menu</source>
      <translation>Left sub menu</translation>
    </message>
    <message>
      <source>Previous</source>
      <translation>Previous</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
    <message>
      <source>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</source>
      <translation>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</translation>
    </message>
  </context>
  <context>
    <name>design/base/shop</name>
    <message>
      <source>Basket</source>
      <translation>Basket</translation>
    </message>
    <message>
      <source>The following items were removed from your basket, because the products were changed</source>
      <translation>The following items were removed from your basket, because the products were changed</translation>
    </message>
    <message>
      <source>VAT is unknown</source>
      <translation>GST is unknown</translation>
    </message>
    <message>
      <source>VAT percentage is not yet known for some of the items being purchased.</source>
      <translation>GST percentage is not yet known for some of the items being purchased.</translation>
    </message>
    <message>
      <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
      <translation>This probably means that some information about you is not yet available and will be obtained during checkout.</translation>
    </message>
    <message>
      <source>Quantity</source>
      <translation>Quantity</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total Price</source>
      <translation>Total Price</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>unknown</source>
      <translation>unknown</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>Subtotal Inc. VAT</source>
      <translation>Subtotal Inc. GST</translation>
    </message>
    <message>
      <source>Checkout</source>
      <translation>Checkout</translation>
    </message>
    <message>
      <source>Continue shopping</source>
      <translation>Continue shopping</translation>
    </message>
    <message>
      <source>Store quantities</source>
      <translation>Store quantities</translation>
    </message>
    <message>
      <source>You have no products in your basket</source>
      <translation>You have no products in your basket</translation>
    </message>
    <message>
      <source>Confirm order</source>
      <translation>Confirm order</translation>
    </message>
    <message>
      <source>Product items</source>
      <translation>Product items</translation>
    </message>
    <message>
      <source>Order summary</source>
      <translation>Order summary</translation>
    </message>
    <message>
      <source>Subtotal of items</source>
      <translation>Subtotal of items</translation>
    </message>
    <message>
      <source>Order total</source>
      <translation>Order total</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Order %order_id [%order_status]</source>
      <translation>Order %order_id [%order_status]</translation>
    </message>
    <message>
      <source>Order history</source>
      <translation>Order history</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class</name>
    <message>
      <source>Class is locked</source>
      <translation>Class is locked</translation>
    </message>
    <message>
      <source>Retry</source>
      <translation>Retry</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/classlist</name>
    <message>
      <source>No classes in </source>
      <translation>No classes in </translation>
    </message>
    <message>
      <source>Click on the 'New' button to create a class.</source>
      <translation>Click on the 'New' button to create a class.</translation>
    </message>
    <message>
      <source>Classes in</source>
      <translation>Classes in</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Object count</source>
      <translation>Object count</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>New class</source>
      <translation>New class</translation>
    </message>
    <message>
      <source>Last modified classes</source>
      <translation>Last modified classes</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/datatype</name>
    <message>
      <source>Max file size</source>
      <translation>Max file size</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation>Default value</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation>Empty</translation>
    </message>
    <message>
      <source>Current date</source>
      <translation>Current date</translation>
    </message>
    <message>
      <source>Current datetime</source>
      <translation>Current datetime</translation>
    </message>
    <message>
      <source>Adjusted current datetime</source>
      <translation>Adjusted current datetime</translation>
    </message>
    <message>
      <source>Current date and time adjusted by</source>
      <translation>Current date and time adjusted by</translation>
    </message>
    <message>
      <source>Year</source>
      <translation>Year</translation>
    </message>
    <message>
      <source>Month</source>
      <translation>Month</translation>
    </message>
    <message>
      <source>Day</source>
      <translation>Day</translation>
    </message>
    <message>
      <source>Hour</source>
      <translation>Hour</translation>
    </message>
    <message>
      <source>Minute</source>
      <translation>Minute</translation>
    </message>
    <message>
      <source>Multiple choice</source>
      <translation>Multiple choice</translation>
    </message>
    <message>
      <source>Style</source>
      <translation>Style</translation>
    </message>
    <message>
      <source>Checkboxes / radiobuttons</source>
      <translation>Checkboxes / radiobuttons</translation>
    </message>
    <message>
      <source>Dropdown menu / multi menu</source>
      <translation>Dropdown menu / multi menu</translation>
    </message>
    <message>
      <source>Elements</source>
      <translation>Elements</translation>
    </message>
    <message>
      <source>Element</source>
      <translation>Element</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Value</translation>
    </message>
    <message>
      <source>There are no elements in the list.</source>
      <translation>There are no elements in the list.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected elements.</source>
      <translation>Remove selected elements.</translation>
    </message>
    <message>
      <source>New element</source>
      <translation>New element</translation>
    </message>
    <message>
      <source>Add a new enum element.</source>
      <translation>Add a new enum element.</translation>
    </message>
    <message>
      <source>Min float value</source>
      <translation>Min float value</translation>
    </message>
    <message>
      <source>Max float value</source>
      <translation>Max float value</translation>
    </message>
    <message>
      <source>Pretext</source>
      <translation>Pretext</translation>
    </message>
    <message>
      <source>Posttext</source>
      <translation>Posttext</translation>
    </message>
    <message>
      <source>Digits</source>
      <translation>Digits</translation>
    </message>
    <message>
      <source>Start value</source>
      <translation>Start value</translation>
    </message>
    <message>
      <source>Ini file</source>
      <translation>Ini file</translation>
    </message>
    <message>
      <source>Ini Section</source>
      <translation>Ini Section</translation>
    </message>
    <message>
      <source>Ini Parameter</source>
      <translation>Ini Parameter</translation>
    </message>
    <message>
      <source>Ini file location</source>
      <translation>Ini file location</translation>
    </message>
    <message>
      <source>Ini setting type</source>
      <translation>Ini setting type</translation>
    </message>
    <message>
      <source>Text</source>
      <translation>Text</translation>
    </message>
    <message>
      <source>Enable/Disable</source>
      <translation>Enable/Disable</translation>
    </message>
    <message>
      <source>True/False</source>
      <translation>True/False</translation>
    </message>
    <message>
      <source>Integer</source>
      <translation>Integer</translation>
    </message>
    <message>
      <source>Float</source>
      <translation>Float</translation>
    </message>
    <message>
      <source>Array</source>
      <translation>Array</translation>
    </message>
    <message>
      <source>Min integer value</source>
      <translation>Min integer value</translation>
    </message>
    <message>
      <source>Max integer value</source>
      <translation>Max integer value</translation>
    </message>
    <message>
      <source>Default number of rows</source>
      <translation>Default number of rows</translation>
    </message>
    <message>
      <source>Columns</source>
      <translation>Columns</translation>
    </message>
    <message>
      <source>Matrix column</source>
      <translation>Matrix column</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>The matrix does not have any columns.</source>
      <translation>The matrix does not have any columns.</translation>
    </message>
    <message>
      <source>Remove selected columns.</source>
      <translation>Remove selected columns.</translation>
    </message>
    <message>
      <source>New column</source>
      <translation>New column</translation>
    </message>
    <message>
      <source>Add a new column.</source>
      <translation>Add a new column.</translation>
    </message>
    <message>
      <source>Media player type</source>
      <translation>Media player type</translation>
    </message>
    <message>
      <source>Flash</source>
      <translation>Flash</translation>
    </message>
    <message>
      <source>QuickTime</source>
      <translation>QuickTime</translation>
    </message>
    <message>
      <source>Real player</source>
      <translation>Real player</translation>
    </message>
    <message>
      <source>Windows media player</source>
      <translation>Windows media player</translation>
    </message>
    <message>
      <source>Default currency</source>
      <translation>Default currency</translation>
    </message>
    <message>
      <source>Default VAT</source>
      <translation>Default GST</translation>
    </message>
    <message>
      <source>Price inc. VAT</source>
      <translation>Price inc. GST</translation>
    </message>
    <message>
      <source>Price ex. VAT</source>
      <translation>Price ex. GST</translation>
    </message>
    <message>
      <source>Default VAT type</source>
      <translation>Default GST type</translation>
    </message>
    <message>
      <source>Selection method</source>
      <translation>Selection method</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Dropdown list</source>
      <translation>Dropdown list</translation>
    </message>
    <message>
      <source>Dropdown tree</source>
      <translation>Dropdown tree</translation>
    </message>
    <message>
      <source>Default selection item</source>
      <translation>Default selection item</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Unknown section</source>
      <translation>Unknown section</translation>
    </message>
    <message>
      <source>Remove selection</source>
      <translation>Remove selection</translation>
    </message>
    <message>
      <source>No item has been selected.</source>
      <translation>No item has been selected.</translation>
    </message>
    <message>
      <source>Select item</source>
      <translation>Select item</translation>
    </message>
    <message>
      <source>Allow fuzzy match</source>
      <translation>Allow fuzzy match</translation>
    </message>
    <message>
      <source>New and existing objects</source>
      <translation>New and existing objects</translation>
    </message>
    <message>
      <source>Only new objects</source>
      <translation>Only new objects</translation>
    </message>
    <message>
      <source>Only existing objects</source>
      <translation>Only existing objects</translation>
    </message>
    <message>
      <source>For more options, set &quot;AdvancedObjectRelationList&quot; to &quot;enabled&quot; in a configuration override for &quot;site.ini&quot;.</source>
      <translation>For more options, set &quot;AdvancedObjectRelationList&quot; to &quot;enabled&quot; in a configuration override for &quot;site.ini&quot;.</translation>
    </message>
    <message>
      <source>Allowed classes</source>
      <translation>Allowed classes</translation>
    </message>
    <message>
      <source>Select which classes user can create</source>
      <translation>Select which classes user can create</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Default location for objects</source>
      <translation>Default location for objects</translation>
    </message>
    <message>
      <source>New objects will not be placed in the content tree.</source>
      <translation>New objects will not be placed in the content tree.</translation>
    </message>
    <message>
      <source>Remove location</source>
      <translation>Remove location</translation>
    </message>
    <message>
      <source>Select location</source>
      <translation>Select location</translation>
    </message>
    <message>
      <source>Default name</source>
      <translation>Default name</translation>
    </message>
    <message>
      <source>Package type</source>
      <translation>Package type</translation>
    </message>
    <message>
      <source>View mode</source>
      <translation>View mode</translation>
    </message>
    <message>
      <source>Combo box</source>
      <translation>Combo box</translation>
    </message>
    <message>
      <source>Icon view</source>
      <translation>Icon view</translation>
    </message>
    <message>
      <source>Single choice</source>
      <translation>Single choice</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Option</source>
      <translation>Option</translation>
    </message>
    <message>
      <source>Select option for removal.</source>
      <translation>Select option for removal.</translation>
    </message>
    <message>
      <source>There are no options.</source>
      <translation>There are no options.</translation>
    </message>
    <message>
      <source>Remove selected options.</source>
      <translation>Remove selected options.</translation>
    </message>
    <message>
      <source>New option</source>
      <translation>New option</translation>
    </message>
    <message>
      <source>Add a new option.</source>
      <translation>Add a new option.</translation>
    </message>
    <message>
      <source>Max string length</source>
      <translation>Max string length</translation>
    </message>
    <message>
      <source>characters</source>
      <translation>characters</translation>
    </message>
    <message>
      <source>Preferred number of rows</source>
      <translation>Preferred number of rows</translation>
    </message>
    <message>
      <source>Current time</source>
      <translation>Current time</translation>
    </message>
    <message>
      <source>Unchecked</source>
      <translation>Unchecked</translation>
    </message>
    <message>
      <source>Checked</source>
      <translation>Checked</translation>
    </message>
    <message>
      <source>year(s)</source>
      <translation>year(s)</translation>
    </message>
    <message>
      <source>month(s)</source>
      <translation>month(s)</translation>
    </message>
    <message>
      <source>day(s)</source>
      <translation>day(s)</translation>
    </message>
    <message>
      <source>hour(s)</source>
      <translation>hour(s)</translation>
    </message>
    <message>
      <source>minute(s)</source>
      <translation>minute(s)</translation>
    </message>
    <message>
      <source>Interface</source>
      <translation>Interface</translation>
    </message>
    <message>
      <source>Dropdown menu / multiselect</source>
      <translation>Dropdown menu / multiselect</translation>
    </message>
    <message>
      <source>Radiobuttons / checkboxes</source>
      <translation>Radiobuttons / checkboxes</translation>
    </message>
    <message>
      <source>Current value</source>
      <translation>Current value</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>VAT type</source>
      <translation>GST type</translation>
    </message>
    <message>
      <source>Drop-down list</source>
      <translation>Drop-down list</translation>
    </message>
    <message>
      <source>Drop-down tree</source>
      <translation>Drop-down tree</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Package Type</source>
      <translation>Package Type</translation>
    </message>
    <message>
      <source>View Mode</source>
      <translation>View Mode</translation>
    </message>
    <message>
      <source>combobox</source>
      <translation>combobox</translation>
    </message>
    <message>
      <source>icon view</source>
      <translation>icon view</translation>
    </message>
    <message>
      <source>Warning, the ini file settings value and object value does not match.</source>
      <translation>Warning, the ini file settings value and object value does not match.</translation>
    </message>
    <message>
      <source>The ini file has probably been modified manually since last time.</source>
      <translation>The ini file has probably been modified manually since last time.</translation>
    </message>
    <message>
      <source>Ini File : </source>
      <translation>Ini File : </translation>
    </message>
    <message>
      <source>Ini Value: </source>
      <translation>Ini Value: </translation>
    </message>
    <message>
      <source>Enabled</source>
      <translation>Enabled</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Disabled</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Make empty array</source>
      <translation>Make empty array</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/datatype </name>
    <message>
      <source>Max file size</source>
      <translation>Max file size</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/edit</name>
    <message>
      <source>Default object availability</source>
      <translation>Default object availability</translation>
    </message>
    <message>
      <source>Use this menu to select the type of attribute you wish to create. Click the &quot;add attribute&quot; button. The attribute will be appended to the bottom of the list of attributes.</source>
      <translation>Use this menu to select the type of attribute you wish to create. Click the &quot;add attribute&quot; button. The attribute will be appended to the bottom of the list of attributes.</translation>
    </message>
    <message>
      <source>Editing class - %1</source>
      <translation>Editing class - %1</translation>
    </message>
    <message>
      <source>Last modified by %username on %time</source>
      <translation>Last modified by %username on %time</translation>
    </message>
    <message>
      <source>The class should have at least one attribute and nonempty 'Name' attribute</source>
      <translation>The class should have at least one attribute and nonempty 'Name' attribute</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Object name pattern</source>
      <translation>Object name pattern</translation>
    </message>
    <message>
      <source>Is Container Class</source>
      <translation>Is Container Class</translation>
    </message>
    <message>
      <source>Objects always available (default value)</source>
      <translation>Objects always available (default value)</translation>
    </message>
    <message>
      <source>Member of groups</source>
      <translation>Member of groups</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Add to group</source>
      <translation>Add to group</translation>
    </message>
    <message>
      <source>Remove from groups</source>
      <translation>Remove from groups</translation>
    </message>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Input was stored successfully</source>
      <translation>Input was stored successfully</translation>
    </message>
    <message>
      <source>Attributes</source>
      <translation>Attributes</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Required</source>
      <translation>Required</translation>
    </message>
    <message>
      <source>Searchable</source>
      <translation>Searchable</translation>
    </message>
    <message>
      <source>Information collector</source>
      <translation>Information collector</translation>
    </message>
    <message>
      <source>Disable translation</source>
      <translation>Disable translation</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Down</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Up</translation>
    </message>
    <message>
      <source>Datatypes</source>
      <translation>Datatypes</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Apply</translation>
    </message>
    <message>
      <source>Discard Changes</source>
      <translation>Discard Changes</translation>
    </message>
    <message>
      <source>Editing class group - %1</source>
      <translation>Editing class group - %1</translation>
    </message>
    <message>
      <source>Modified by %username on %time</source>
      <translation>Modified by %username on %time</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Are you sure you want to remove these classes?</source>
      <translation>Are you sure you want to remove these classes?</translation>
    </message>
    <message>
      <source>The class %1 was already removed from the group but still exists in others.</source>
      <translation>The class %1 was already removed from the group but still exists in others.</translation>
    </message>
    <message>
      <source>The classes %1 were already removed from the group but still exist in others.</source>
      <translation>The classes %1 were already removed from the group but still exist in others.</translation>
    </message>
    <message>
      <source>Removing class %1 will remove %2!</source>
      <translation>Removing class %1 will remove %2!</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Are you sure you want to remove these class groups?</source>
      <translation>Are you sure you want to remove these class groups?</translation>
    </message>
    <message>
      <source>Removing class group %1 will remove the classes %2!</source>
      <translation>Removing class group %1 will remove the classes %2!</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/list</name>
    <message>
      <source>Class groups</source>
      <translation>Class groups</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>New class</source>
      <translation>New class</translation>
    </message>
    <message>
      <source>New group</source>
      <translation>New group</translation>
    </message>
    <message>
      <source>Last modified classes</source>
      <translation>Last modified classes</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Setup menu</source>
      <translation>Setup menu</translation>
    </message>
  </context>
  <context>
    <name>design/standard/class/view</name>
    <message>
      <source>Class - %1</source>
      <translation>Class - %1</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Last modified by %username on %time</source>
      <translation>Last modified by %username on %time</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>Object name pattern</source>
      <translation>Object name pattern</translation>
    </message>
    <message>
      <source>Container</source>
      <translation>Container</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Objects always available (default value)</source>
      <translation>Objects always available (default value)</translation>
    </message>
    <message>
      <source>Object count</source>
      <translation>Object count</translation>
    </message>
    <message>
      <source>Member of groups</source>
      <translation>Member of groups</translation>
    </message>
    <message>
      <source>Attributes</source>
      <translation>Attributes</translation>
    </message>
    <message>
      <source>Is required</source>
      <translation>Is required</translation>
    </message>
    <message>
      <source>Is not required</source>
      <translation>Is not required</translation>
    </message>
    <message>
      <source>Is searchable</source>
      <translation>Is searchable</translation>
    </message>
    <message>
      <source>Is not searchable</source>
      <translation>Is not searchable</translation>
    </message>
    <message>
      <source>Collects information</source>
      <translation>Collects information</translation>
    </message>
    <message>
      <source>Does not collect information</source>
      <translation>Does not collect information</translation>
    </message>
    <message>
      <source>Translation is disabled</source>
      <translation>Translation is disabled</translation>
    </message>
    <message>
      <source>Translation is enabled</source>
      <translation>Translation is enabled</translation>
    </message>
    <message>
      <source>Override templates</source>
      <translation>Override templates</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Override</source>
      <translation>Override</translation>
    </message>
    <message>
      <source>Source template</source>
      <translation>Source template</translation>
    </message>
    <message>
      <source>Override template</source>
      <translation>Override template</translation>
    </message>
  </context>
  <context>
    <name>design/standard/collaboration</name>
    <message>
      <source>Group list for '%1'</source>
      <translation>Group list for '%1'</translation>
    </message>
    <message>
      <source>No items in group.</source>
      <translation>No items in group.</translation>
    </message>
    <message>
      <source>Groups</source>
      <translation>Groups</translation>
    </message>
    <message>
      <source>Approval</source>
      <translation>Approval</translation>
    </message>
    <message>
      <source>Subject</source>
      <translation>Subject</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Date</translation>
    </message>
    <message>
      <source>Read</source>
      <translation>Read</translation>
    </message>
    <message>
      <source>Unread</source>
      <translation>Unread</translation>
    </message>
    <message>
      <source>Inactive</source>
      <translation>Inactive</translation>
    </message>
    <message>
      <source>[more]</source>
      <translation>[more]</translation>
    </message>
    <message>
      <source>Posted: %1</source>
      <translation>Posted: %1</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>No new items to be handled.</source>
      <translation>No new items to be handled.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/collaboration/approval</name>
    <message>
      <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
      <translation>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</translation>
    </message>
    <message>
      <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
      <translation>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</translation>
    </message>
    <message>
      <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
      <translation>[%sitename] &quot;%objectname&quot; awaits approval</translation>
    </message>
    <message>
      <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
      <translation>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</translation>
    </message>
    <message>
      <source>Approval</source>
      <translation>Approval</translation>
    </message>
    <message>
      <source>The content object %1 awaits approval before it can be published.</source>
      <translation>The content object %1 awaits approval before it can be published.</translation>
    </message>
    <message>
      <source>If you wish you may send a message to the person approving it?</source>
      <translation>If you wish you may send a message to the person approving it?</translation>
    </message>
    <message>
      <source>The content object %1 needs your approval before it can be published.</source>
      <translation>The content object %1 needs your approval before it can be published.</translation>
    </message>
    <message>
      <source>Do you approve of the content object being published?</source>
      <translation>Do you approve of the content object being published?</translation>
    </message>
    <message>
      <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
      <translation>The content object %1 was approved and will be published once the publishing workflow continues.</translation>
    </message>
    <message>
      <source>The content object %1 was not accepted but is available as a draft again.</source>
      <translation>The content object %1 was not accepted but is available as a draft again.</translation>
    </message>
    <message>
      <source>You may re-edit the draft and publish it, in which case an approval is required again.</source>
      <translation>You may re-edit the draft and publish it, in which case an approval is required again.</translation>
    </message>
    <message>
      <source>Edit the object</source>
      <translation>Edit the object</translation>
    </message>
    <message>
      <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
      <translation>The content object %1 was not accepted but will be available as a draft for the author.</translation>
    </message>
    <message>
      <source>The author can re-edit the draft and publish it again, in which a new approval item is made.</source>
      <translation>The author can re-edit the draft and publish it again, in which a new approval item is made.</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comment</translation>
    </message>
    <message>
      <source>Add Comment</source>
      <translation>Add Comment</translation>
    </message>
    <message>
      <source>Approve</source>
      <translation>Approve</translation>
    </message>
    <message>
      <source>Deny</source>
      <translation>Deny</translation>
    </message>
    <message>
      <source>Participants</source>
      <translation>Participants</translation>
    </message>
    <message>
      <source>Messages</source>
      <translation>Messages</translation>
    </message>
  </context>
  <context>
    <name>design/standard/collaboration/handler/view/line/ezapprove</name>
    <message>
      <source>The content object %1 [deleted]</source>
      <translation>The content object %1 [deleted]</translation>
    </message>
    <message>
      <source>%1 awaits approval by editor</source>
      <translation>%1 awaits approval by editor</translation>
    </message>
    <message>
      <source>%1 awaits your approval</source>
      <translation>%1 awaits your approval</translation>
    </message>
    <message>
      <source>%1 was approved for publishing</source>
      <translation>%1 was approved for publishing</translation>
    </message>
    <message>
      <source>%1 was not approved for publishing</source>
      <translation>%1 was not approved for publishing</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content</name>
    <message>
      <source>Are you sure you want to remove this translation?</source>
      <translation>Are you sure you want to remove this translation?</translation>
    </message>
    <message>
      <source>Removing '%1' will remove the translation itself and %2 translated versions!</source>
      <translation>Removing '%1' will remove the translation itself and %2 translated versions!</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Change translation for content</source>
      <translation>Change translation for content</translation>
    </message>
    <message>
      <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
      <translation>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</translation>
    </message>
    <message>
      <source>New translation for content</source>
      <translation>New translation for content</translation>
    </message>
    <message>
      <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
      <translation>Pick one of the translations from the list to add or enter a new custom one in the input fields.</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Custom</translation>
    </message>
    <message>
      <source>Name of translation</source>
      <translation>Name of translation</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>Change</source>
      <translation>Change</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Create</translation>
    </message>
    <message>
      <source>Content translations</source>
      <translation>Content translations</translation>
    </message>
    <message>
      <source>Below you'll find a list of active translations which content objects may be translated into.</source>
      <translation>Below you'll find a list of active translations which content objects may be translated into.</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>URL translator</source>
      <translation>URL translator</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Add</source>
      <translation>Add</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/browse</name>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
      <translation>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</translation>
    </message>
    <message>
      <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
      <translation>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Up one level</source>
      <translation>Up one level</translation>
    </message>
    <message>
      <source>Top levels</source>
      <translation>Top levels</translation>
    </message>
    <message>
      <source>Switch top levels by clicking one of these items.</source>
      <translation>Switch top levels by clicking one of these items.</translation>
    </message>
    <message>
      <source>Bookmarks</source>
      <translation>Bookmarks</translation>
    </message>
    <message>
      <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
      <translation>Bookmark items are managed using %bookmarkname in the %personalname part.</translation>
    </message>
    <message>
      <source>My bookmarks</source>
      <translation>My bookmarks</translation>
    </message>
    <message>
      <source>Personal</source>
      <translation>Personal</translation>
    </message>
    <message>
      <source>Recent items</source>
      <translation>Recent items</translation>
    </message>
    <message>
      <source>Recent items are added on publishing.</source>
      <translation>Recent items are added on publishing.</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Create new</source>
      <translation>Create new</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/copy</name>
    <message>
      <source>Copying %1</source>
      <translation>Copying %1</translation>
    </message>
    <message>
      <source>Version count is %1, and current version is %2.</source>
      <translation>Version count is %1, and current version is %2.</translation>
    </message>
    <message>
      <source>Copy all versions</source>
      <translation>Copy all versions</translation>
    </message>
    <message>
      <source>Copy current version</source>
      <translation>Copy current version</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/copy_subtree</name>
    <message>
      <source>Copying subtree from node %1</source>
      <translation>Copying subtree from node %1</translation>
    </message>
    <message>
      <source>Copy all versions.</source>
      <translation>Copy all versions.</translation>
    </message>
    <message>
      <source>Copy current version.</source>
      <translation>Copy current version.</translation>
    </message>
    <message>
      <source>Keep creators of contentobjects being copied unchaged.</source>
      <translation>Keep creators of contentobjects being copied unchaged.</translation>
    </message>
    <message>
      <source>Set new creator for contentobjects being copied.</source>
      <translation>Set new creator for contentobjects being copied.</translation>
    </message>
    <message>
      <source>Keep time of creation and modification of contentobjects being copied unchanged.</source>
      <translation>Keep time of creation and modification of contentobjects being copied unchanged.</translation>
    </message>
    <message>
      <source>Copy and publish contentobjects at current time.</source>
      <translation>Copy and publish contentobjects at current time.</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/copy_subtree_notification</name>
    <message>
      <source>Copy Subtree Notification</source>
      <translation>Copy Subtree Notification</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/create</name>
    <message>
      <source>Create new</source>
      <translation>Create new</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/create_languages</name>
    <message>
      <source>Existing languages</source>
      <translation>Existing languages</translation>
    </message>
    <message>
      <source>Select the language in which you want to create an object</source>
      <translation>Select the language in which you want to create an object</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/datatype</name>
    <message>
      <source>Not specified</source>
      <translation>Not specified</translation>
    </message>
    <message>
      <source>Year</source>
      <translation>Year</translation>
    </message>
    <message>
      <source>Month</source>
      <translation>Month</translation>
    </message>
    <message>
      <source>Day</source>
      <translation>Day</translation>
    </message>
    <message>
      <source>Hour</source>
      <translation>Hour</translation>
    </message>
    <message>
      <source>Minute</source>
      <translation>Minute</translation>
    </message>
    <message>
      <source>There are no options.</source>
      <translation>There are no options.</translation>
    </message>
    <message>
      <source>Version: %old</source>
      <translation>Version: %old</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Version: %new</source>
      <translation>Version: %new</translation>
    </message>
    <message>
      <source>Diff output disabled for %type</source>
      <translation>Diff output disabled for %type</translation>
    </message>
    <message>
      <source>Image version %ver</source>
      <translation>Image version %ver</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Filename</translation>
    </message>
    <message>
      <source>MIME type</source>
      <translation>MIME type</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Size</translation>
    </message>
    <message>
      <source>Alternative image text</source>
      <translation>Alternative image text</translation>
    </message>
    <message>
      <source>There is no image file.</source>
      <translation>There is no image file.</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Flash</source>
      <translation>Flash</translation>
    </message>
    <message>
      <source>QuickTime</source>
      <translation>QuickTime</translation>
    </message>
    <message>
      <source>Real player</source>
      <translation>Real player</translation>
    </message>
    <message>
      <source>Windows media player</source>
      <translation>Windows media player</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>Version %ver</source>
      <translation>Version %ver</translation>
    </message>
    <message>
      <source>Width</source>
      <translation>Width</translation>
    </message>
    <message>
      <source>Height</source>
      <translation>Height</translation>
    </message>
    <message>
      <source>Quality</source>
      <translation>Quality</translation>
    </message>
    <message>
      <source>Autoplay</source>
      <translation>Autoplay</translation>
    </message>
    <message>
      <source>Loop</source>
      <translation>Loop</translation>
    </message>
    <message>
      <source>Current file</source>
      <translation>Current file</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Controller</translation>
    </message>
    <message>
      <source>Controls</source>
      <translation>Controls</translation>
    </message>
    <message>
      <source>No media file is available.</source>
      <translation>No media file is available.</translation>
    </message>
    <message>
      <source>Related object ID</source>
      <translation>Related object ID</translation>
    </message>
    <message>
      <source>Object name</source>
      <translation>Object name</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>No relation</source>
      <translation>No relation</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Object version</source>
      <translation>Object version</translation>
    </message>
    <message>
      <source>Select author row for removal.</source>
      <translation>Select author row for removal.</translation>
    </message>
    <message>
      <source>There are no authors in the author list.</source>
      <translation>There are no authors in the author list.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected rows from the author list.</source>
      <translation>Remove selected rows from the author list.</translation>
    </message>
    <message>
      <source>Add author</source>
      <translation>Add author</translation>
    </message>
    <message>
      <source>Add a new row to the author list.</source>
      <translation>Add a new row to the author list.</translation>
    </message>
    <message>
      <source>There is no file.</source>
      <translation>There is no file.</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Remove the file from this draft.</source>
      <translation>Remove the file from this draft.</translation>
    </message>
    <message>
      <source>New file for upload</source>
      <translation>New file for upload</translation>
    </message>
    <message>
      <source>Current image</source>
      <translation>Current image</translation>
    </message>
    <message>
      <source>Remove image</source>
      <translation>Remove image</translation>
    </message>
    <message>
      <source>New image file for upload</source>
      <translation>New image file for upload</translation>
    </message>
    <message>
      <source>Select row for removal.</source>
      <translation>Select row for removal.</translation>
    </message>
    <message>
      <source>There are no rows in the matrix.</source>
      <translation>There are no rows in the matrix.</translation>
    </message>
    <message>
      <source>Remove selected rows from the matrix.</source>
      <translation>Remove selected rows from the matrix.</translation>
    </message>
    <message>
      <source>Number of rows to add.</source>
      <translation>Number of rows to add.</translation>
    </message>
    <message>
      <source>Add rows</source>
      <translation>Add rows</translation>
    </message>
    <message>
      <source>Add new rows to the matrix.</source>
      <translation>Add new rows to the matrix.</translation>
    </message>
    <message>
      <source>High</source>
      <translation>High</translation>
    </message>
    <message>
      <source>Best</source>
      <translation>Best</translation>
    </message>
    <message>
      <source>Low</source>
      <translation>Low</translation>
    </message>
    <message>
      <source>Autohigh</source>
      <translation>Autohigh</translation>
    </message>
    <message>
      <source>Autolow</source>
      <translation>Autolow</translation>
    </message>
    <message>
      <source>ImageWindow</source>
      <translation>ImageWindow</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>ControlPanel</source>
      <translation>ControlPanel</translation>
    </message>
    <message>
      <source>InfoVolumePanel</source>
      <translation>InfoVolumePanel</translation>
    </message>
    <message>
      <source>InfoPanel</source>
      <translation>InfoPanel</translation>
    </message>
    <message>
      <source>Option set name</source>
      <translation>Option set name</translation>
    </message>
    <message>
      <source>Select multioption for removal.</source>
      <translation>Select multioption for removal.</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Option</source>
      <translation>Option</translation>
    </message>
    <message>
      <source>Additional price</source>
      <translation>Additional price</translation>
    </message>
    <message>
      <source>Default</source>
      <translation>Default</translation>
    </message>
    <message>
      <source>Select option for removal.</source>
      <translation>Select option for removal.</translation>
    </message>
    <message>
      <source>Use the radio buttons to set the default option.</source>
      <translation>Use the radio buttons to set the default option.</translation>
    </message>
    <message>
      <source>Remove selected options.</source>
      <translation>Remove selected options.</translation>
    </message>
    <message>
      <source>Add option</source>
      <translation>Add option</translation>
    </message>
    <message>
      <source>Add a new option.</source>
      <translation>Add a new option.</translation>
    </message>
    <message>
      <source>There are no multioptions.</source>
      <translation>There are no multioptions.</translation>
    </message>
    <message>
      <source>Remove selected multioptions.</source>
      <translation>Remove selected multioptions.</translation>
    </message>
    <message>
      <source>Add multioption</source>
      <translation>Add multioption</translation>
    </message>
    <message>
      <source>Add a new multioption.</source>
      <translation>Add a new multioption.</translation>
    </message>
    <message>
      <source>Currency</source>
      <translation>Currency</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Value</translation>
    </message>
    <message>
      <source>Select price for removal.</source>
      <translation>Select price for removal.</translation>
    </message>
    <message>
      <source>Auto</source>
      <translation>Auto</translation>
    </message>
    <message>
      <source>Remove selected prices.</source>
      <translation>Remove selected prices.</translation>
    </message>
    <message>
      <source>Price list is empty</source>
      <translation>Price list is empty</translation>
    </message>
    <message>
      <source>Set custom price</source>
      <translation>Set custom price</translation>
    </message>
    <message>
      <source>Set custom price.</source>
      <translation>Set custom price.</translation>
    </message>
    <message>
      <source>There are no available currencies.</source>
      <translation>There are no available currencies.</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price inc. VAT</source>
      <translation>Price inc. GST</translation>
    </message>
    <message>
      <source>Price ex. VAT</source>
      <translation>Price ex. GST</translation>
    </message>
    <message>
      <source>VAT type</source>
      <translation>GST type</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Remove object</source>
      <translation>Remove object</translation>
    </message>
    <message>
      <source>Add object</source>
      <translation>Add object</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Edit &lt;%object_name&gt; [%object_class]</source>
      <translation>Edit &lt;%object_name&gt; [%object_class]</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>There are no related objects.</source>
      <translation>There are no related objects.</translation>
    </message>
    <message>
      <source>Edit selected</source>
      <translation>Edit selected</translation>
    </message>
    <message>
      <source>Add objects</source>
      <translation>Add objects</translation>
    </message>
    <message>
      <source>Create new object</source>
      <translation>Create new object</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Start value</source>
      <translation>Start value</translation>
    </message>
    <message>
      <source>Stop value</source>
      <translation>Stop value</translation>
    </message>
    <message>
      <source>Step value</source>
      <translation>Step value</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>Text</source>
      <translation>Text</translation>
    </message>
    <message>
      <source>User ID</source>
      <translation>User ID</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Confirm password</source>
      <translation>Confirm password</translation>
    </message>
    <message>
      <source>Current account status:</source>
      <translation>Current account status:</translation>
    </message>
    <message>
      <source>enabled</source>
      <translation>enabled</translation>
    </message>
    <message>
      <source>disabled</source>
      <translation>disabled</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
    <message>
      <source>Your price</source>
      <translation>Your price</translation>
    </message>
    <message>
      <source>You save</source>
      <translation>You save</translation>
    </message>
    <message>
      <source>User account information</source>
      <translation>User account information</translation>
    </message>
    <message>
      <source>Email</source>
      <translation>Email</translation>
    </message>
    <message>
      <source>N/A</source>
      <translation>N/A</translation>
    </message>
    <message>
      <source>Configure user account settings</source>
      <translation>Configure user account settings</translation>
    </message>
    <message>
      <source>Using tag '%tagname' with class '%class' is not allowed.</source>
      <translation>Using tag '%tagname' with class '%class' is not allowed.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/diff</name>
    <message>
      <source>Versions for &lt;%object_name&gt; [%version_count]</source>
      <translation>Versions for &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Archived</source>
      <translation>Archived</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rejected</translation>
    </message>
    <message>
      <source>Untouched draft</source>
      <translation>Untouched draft</translation>
    </message>
    <message>
      <source>Show differences</source>
      <translation>Show differences</translation>
    </message>
    <message>
      <source>Differences between versions %oldVersion and %newVersion</source>
      <translation>Differences between versions %oldVersion and %newVersion</translation>
    </message>
    <message>
      <source>Old version</source>
      <translation>Old version</translation>
    </message>
    <message>
      <source>Inline changes</source>
      <translation>Inline changes</translation>
    </message>
    <message>
      <source>Block changes</source>
      <translation>Block changes</translation>
    </message>
    <message>
      <source>New version</source>
      <translation>New version</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/edit</name>
    <message>
      <source>Feedback from %1</source>
      <translation>Feedback from %1</translation>
    </message>
    <message>
      <source>The following feedback was collected</source>
      <translation>The following feedback was collected</translation>
    </message>
    <message>
      <source>Collected information from %1</source>
      <translation>Collected information from %1</translation>
    </message>
    <message>
      <source>The following information was collected</source>
      <translation>The following information was collected</translation>
    </message>
    <message>
      <source>Edit %1 - %2</source>
      <translation>Edit %1 - %2</translation>
    </message>
    <message>
      <source>Send for publishing</source>
      <translation>Send for publishing</translation>
    </message>
    <message>
      <source>Store draft</source>
      <translation>Store draft</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>The currently published version is %version and was published at %time.</source>
      <translation>The currently published version is %version and was published at %time.</translation>
    </message>
    <message>
      <source>The last modification was done at %modified.</source>
      <translation>The last modification was done at %modified.</translation>
    </message>
    <message>
      <source>The object is owned by %owner.</source>
      <translation>The object is owned by %owner.</translation>
    </message>
    <message>
      <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
      <translation>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</translation>
    </message>
    <message>
      <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
      <translation>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</translation>
    </message>
    <message>
      <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
      <translation>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</translation>
    </message>
    <message>
      <source>Current drafts</source>
      <translation>Current drafts</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Owner</source>
      <translation>Owner</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>New draft</source>
      <translation>New draft</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Depth</source>
      <translation>Depth</translation>
    </message>
    <message>
      <source>Class Identifier</source>
      <translation>Class Identifier</translation>
    </message>
    <message>
      <source>Class Name</source>
      <translation>Class Name</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Sort by</source>
      <translation>Sort by</translation>
    </message>
    <message>
      <source>Ordering</source>
      <translation>Ordering</translation>
    </message>
    <message>
      <source>Main</source>
      <translation>Main</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Move</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Add locations</source>
      <translation>Add locations</translation>
    </message>
    <message>
      <source>Object info</source>
      <translation>Object info</translation>
    </message>
    <message>
      <source>Not yet published</source>
      <translation>Not yet published</translation>
    </message>
    <message>
      <source>Last Modified</source>
      <translation>Last Modified</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>Editing</source>
      <translation>Editing</translation>
    </message>
    <message>
      <source>Current</source>
      <translation>Current</translation>
    </message>
    <message>
      <source>Manage</source>
      <translation>Manage</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>No translation</source>
      <translation>No translation</translation>
    </message>
    <message>
      <source>Translate</source>
      <translation>Translate</translation>
    </message>
    <message>
      <source>Related objects</source>
      <translation>Related objects</translation>
    </message>
    <message>
      <source>Find</source>
      <translation>Find</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Validation failed</source>
      <translation>Validation failed</translation>
    </message>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Location did not validate</source>
      <translation>Location did not validate</translation>
    </message>
    <message>
      <source>Input was partially stored</source>
      <translation>Input was partially stored</translation>
    </message>
    <message>
      <source>Input was stored successfully</source>
      <translation>Input was stored successfully</translation>
    </message>
    <message>
      <source>Are you sure you want to discard the draft %versionname?</source>
      <translation>Are you sure you want to discard the draft %versionname?</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/edit_languages</name>
    <message>
      <source>Existing languages</source>
      <translation>Existing languages</translation>
    </message>
    <message>
      <source>Select the language you want to use when editing the object</source>
      <translation>Select the language you want to use when editing the object</translation>
    </message>
    <message>
      <source>New languages</source>
      <translation>New languages</translation>
    </message>
    <message>
      <source>Select the language you want to add to the object</source>
      <translation>Select the language you want to add to the object</translation>
    </message>
    <message>
      <source>Select the language the added translation will be based on</source>
      <translation>Select the language the added translation will be based on</translation>
    </message>
    <message>
      <source>use an empty, untranslated draft</source>
      <translation>use an empty, untranslated draft</translation>
    </message>
    <message>
      <source>You do not have sufficient permissions to create a translation in another language.</source>
      <translation>You do not have sufficient permissions to create a translation in another language.</translation>
    </message>
    <message>
      <source>However you can select one of the following languages for editing</source>
      <translation>However you can select one of the following languages for editing</translation>
    </message>
    <message>
      <source>You do not have permission to edit the object in any available languages.</source>
      <translation>You do not have permission to edit the object in any available languages.</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/ezoption</name>
    <message>
      <source>No value chosen</source>
      <translation>No value chosen</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/feedback</name>
    <message>
      <source>Feedback for %feedbackname</source>
      <translation>Feedback for %feedbackname</translation>
    </message>
    <message>
      <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
      <translation>You have already submitted data to this feedback. The previously submitted data was the following.</translation>
    </message>
    <message>
      <source>Thanks for your feedback, the following information was collected.</source>
      <translation>Thanks for your feedback, the following information was collected.</translation>
    </message>
    <message>
      <source>Return to site</source>
      <translation>Return to site</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/form</name>
    <message>
      <source>Form %formname</source>
      <translation>Form %formname</translation>
    </message>
    <message>
      <source>Collected information</source>
      <translation>Collected information</translation>
    </message>
    <message>
      <source>You have already submitted data to this form. The previously submitted data was the following.</source>
      <translation>You have already submitted data to this form. The previously submitted data was the following.</translation>
    </message>
    <message>
      <source>Return to site</source>
      <translation>Return to site</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/newcontent</name>
    <message>
      <source>New content since last visit</source>
      <translation>New content since last visit</translation>
    </message>
    <message>
      <source>Your last visit to this site was</source>
      <translation>Your last visit to this site was</translation>
    </message>
    <message>
      <source>There is no new content since your last visit.</source>
      <translation>There is no new content since your last visit.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/pdf</name>
    <message>
      <source>eZ publish PDF export</source>
      <translation>eZ publish PDF export</translation>
    </message>
    <message>
      <source>#page of #total</source>
      <translation>#page of #total</translation>
    </message>
    <message>
      <source>#level1 - #level2</source>
      <translation>#level1 - #level2</translation>
    </message>
    <message>
      <source>#levelIndex1:#levelIndex2</source>
      <translation>#levelIndex1:#levelIndex2</translation>
    </message>
    <message>
      <source>Content</source>
      <translation>Content</translation>
    </message>
    <message>
      <source>Versionview not supported in PDF yet</source>
      <translation>Versionview not supported in PDF yet</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/poll</name>
    <message>
      <source>Poll %pollname</source>
      <translation>Poll %pollname</translation>
    </message>
    <message>
      <source>Poll results</source>
      <translation>Poll results</translation>
    </message>
    <message>
      <source>Anonymous users are not allowed to vote on this poll, please login.</source>
      <translation>Anonymous users are not allowed to vote on this poll, please login.</translation>
    </message>
    <message>
      <source>You have already voted for this poll.</source>
      <translation>You have already voted for this poll.</translation>
    </message>
    <message>
      <source>%count total votes</source>
      <translation>%count total votes</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/removetranslation</name>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/search</name>
    <message>
      <source>Advanced search</source>
      <translation>Advanced search</translation>
    </message>
    <message>
      <source>Search all the words</source>
      <translation>Search all the words</translation>
    </message>
    <message>
      <source>Search the exact phrase</source>
      <translation>Search the exact phrase</translation>
    </message>
    <message>
      <source>Search with at least one of the words</source>
      <translation>Search with at least one of the words</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Any class</source>
      <translation>Any class</translation>
    </message>
    <message>
      <source>Class attribute</source>
      <translation>Class attribute</translation>
    </message>
    <message>
      <source>Any attribute</source>
      <translation>Any attribute</translation>
    </message>
    <message>
      <source>Update attributes</source>
      <translation>Update attributes</translation>
    </message>
    <message>
      <source>In</source>
      <translation>In</translation>
    </message>
    <message>
      <source>Any section</source>
      <translation>Any section</translation>
    </message>
    <message>
      <source>Published</source>
      <translation>Published</translation>
    </message>
    <message>
      <source>Any time</source>
      <translation>Any time</translation>
    </message>
    <message>
      <source>Last day</source>
      <translation>Last day</translation>
    </message>
    <message>
      <source>Last week</source>
      <translation>Last week</translation>
    </message>
    <message>
      <source>Last month</source>
      <translation>Last month</translation>
    </message>
    <message>
      <source>Last three months</source>
      <translation>Last three months</translation>
    </message>
    <message>
      <source>Last year</source>
      <translation>Last year</translation>
    </message>
    <message>
      <source>Display per page</source>
      <translation>Display per page</translation>
    </message>
    <message>
      <source>5 items</source>
      <translation>5 items</translation>
    </message>
    <message>
      <source>10 items</source>
      <translation>10 items</translation>
    </message>
    <message>
      <source>20 items</source>
      <translation>20 items</translation>
    </message>
    <message>
      <source>30 items</source>
      <translation>30 items</translation>
    </message>
    <message>
      <source>50 items</source>
      <translation>50 items</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>No results were found when searching for &quot;%1&quot;</source>
      <translation>No results were found when searching for &quot;%1&quot;</translation>
    </message>
    <message>
      <source>Search for &quot;%1&quot; returned %2 matches</source>
      <translation>Search for &quot;%1&quot; returned %2 matches</translation>
    </message>
    <message>
      <source>For more options try the %1Advanced search%2</source>
      <comment>The parameters are link start and end tags.</comment>
      <translation>For more options try the %1Advanced search%2</translation>
    </message>
    <message>
      <source>The following words were excluded from the search</source>
      <translation>The following words were excluded from the search</translation>
    </message>
    <message>
      <source>Search tips</source>
      <translation>Search tips</translation>
    </message>
    <message>
      <source>Check spelling of keywords.</source>
      <translation>Check spelling of keywords.</translation>
    </message>
    <message>
      <source>Try changing some keywords eg. car instead of cars.</source>
      <translation>Try changing some keywords eg. car instead of cars.</translation>
    </message>
    <message>
      <source>Try more general keywords.</source>
      <translation>Try more general keywords.</translation>
    </message>
    <message>
      <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
      <translation>Fewer keywords gives more results, try reducing keywords until you get a result.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/tipafriend</name>
    <message>
      <source>Tip a friend</source>
      <translation>Tip a friend</translation>
    </message>
    <message>
      <source>The message was sent.</source>
      <translation>The message was sent.</translation>
    </message>
    <message>
      <source>Click here to return to the original page.</source>
      <translation>Click here to return to the original page.</translation>
    </message>
    <message>
      <source>The message was not sent.</source>
      <translation>The message was not sent.</translation>
    </message>
    <message>
      <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
      <translation>The message was not sent due to an unknown error. Please notify the site administrator about this error.</translation>
    </message>
    <message>
      <source>Please correct the following errors</source>
      <translation>Please correct the following errors</translation>
    </message>
    <message>
      <source>Your name</source>
      <translation>Your name</translation>
    </message>
    <message>
      <source>Your email address</source>
      <translation>Your email address</translation>
    </message>
    <message>
      <source>Receivers name</source>
      <translation>Receivers name</translation>
    </message>
    <message>
      <source>Receivers email address</source>
      <translation>Receivers email address</translation>
    </message>
    <message>
      <source>Subject</source>
      <translation>Subject</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comment</translation>
    </message>
    <message>
      <source>Send</source>
      <translation>Send</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
      <translation>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</translation>
    </message>
    <message>
      <source>This is the link to the page</source>
      <translation>This is the link to the page</translation>
    </message>
    <message>
      <source>Comment by &quot;%1 &lt;%2&gt;&quot;</source>
      <translation>Comment by &quot;%1 &lt;%2&gt;&quot;</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/trash</name>
    <message>
      <source>Select all</source>
      <translation>Select all</translation>
    </message>
    <message>
      <source>Deselect all</source>
      <translation>Deselect all</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>Empty Trash</source>
      <translation>Empty Trash</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Current version</source>
      <translation>Current version</translation>
    </message>
    <message>
      <source>Restore</source>
      <translation>Restore</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Trash is empty</source>
      <translation>Trash is empty</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/upload</name>
    <message>
      <source>Upload file</source>
      <translation>Upload file</translation>
    </message>
    <message>
      <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
      <translation>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</translation>
    </message>
    <message>
      <source>Some errors occurred</source>
      <translation>Some errors occurred</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>Automatic</source>
      <translation>Automatic</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Upload</source>
      <translation>Upload</translation>
    </message>
    <message>
      <source>Click here to upload a file. The file will be placed within the location that is specified using the dropdown menu on the top.</source>
      <translation>Click here to upload a file. The file will be placed within the location that is specified using the dropdown menu on the top.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/version</name>
    <message>
      <source>Versions for: %1</source>
      <translation>Versions for: %1</translation>
    </message>
    <message>
      <source>Version not a draft</source>
      <translation>Version not a draft</translation>
    </message>
    <message>
      <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
      <translation>Version %1 is not available for editing any more, only drafts can be edited.</translation>
    </message>
    <message>
      <source>To edit this version create a copy of it.</source>
      <translation>To edit this version create a copy of it.</translation>
    </message>
    <message>
      <source>Version not yours</source>
      <translation>Version not yours</translation>
    </message>
    <message>
      <source>Version %1 was not created by you, only your own drafts can be edited.</source>
      <translation>Version %1 was not created by you, only your own drafts can be edited.</translation>
    </message>
    <message>
      <source>Unable to create new version</source>
      <translation>Unable to create new version</translation>
    </message>
    <message>
      <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
      <translation>Version history limit has been exceeded and no archived version can be removed by the system.</translation>
    </message>
    <message>
      <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
      <translation>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Translations</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Copy and edit</source>
      <translation>Copy and edit</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/versions</name>
    <message>
      <source>This object does not have any versions.</source>
      <translation>This object does not have any versions.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/content/view</name>
    <message>
      <source>Choose node for default selection</source>
      <translation>Choose node for default selection</translation>
    </message>
    <message>
      <source>Please choose where you want to the default selection of objectrelation to start from.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to the default selection of objectrelation to start from.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Choose initial placement</source>
      <translation>Choose initial placement</translation>
    </message>
    <message>
      <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>My bookmarks</source>
      <translation>My bookmarks</translation>
    </message>
    <message>
      <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
      <translation>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>You have no bookmarks</source>
      <translation>You have no bookmarks</translation>
    </message>
    <message>
      <source>Add bookmarks</source>
      <translation>Add bookmarks</translation>
    </message>
    <message>
      <source>Choose items to bookmark</source>
      <translation>Choose items to bookmark</translation>
    </message>
    <message>
      <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
      <translation>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose a new location for the copy of %objectname</source>
      <translation>Choose a new location for the copy of %objectname</translation>
    </message>
    <message>
      <source>Please choose where you want to copy %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to copy %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose new location for the copy of subtree of node %node_name</source>
      <translation>Choose new location for the copy of subtree of node %node_name</translation>
    </message>
    <message>
      <source>Please choose where you want to copy subtree of node %node_name.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to copy subtree of node %node_name.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose new location for %objectname</source>
      <translation>Choose new location for %objectname</translation>
    </message>
    <message>
      <source>Please choose where you want to place %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to place %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose new placement</source>
      <translation>Choose new placement</translation>
    </message>
    <message>
      <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
      <translation>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose placements</source>
      <translation>Choose placements</translation>
    </message>
    <message>
      <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose related objects</source>
      <translation>Choose related objects</translation>
    </message>
    <message>
      <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
      <translation>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose the exchanging node for %objectname</source>
      <translation>Choose the exchanging node for %objectname</translation>
    </message>
    <message>
      <source>Please choose which node you want to exchange %objectname with.

    Select the node and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose which node you want to exchange %objectname with.

    Select the node and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Collected info</source>
      <translation>Collected info</translation>
    </message>
    <message>
      <source>Select all</source>
      <translation>Select all</translation>
    </message>
    <message>
      <source>Deselect all</source>
      <translation>Deselect all</translation>
    </message>
    <message>
      <source>My drafts</source>
      <translation>My drafts</translation>
    </message>
    <message>
      <source>Empty Draft</source>
      <translation>Empty Draft</translation>
    </message>
    <message>
      <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don't need them any more.</source>
      <translation>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don't need them any more.</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Last modified</source>
      <translation>Last modified</translation>
    </message>
    <message>
      <source>You have no drafts</source>
      <translation>You have no drafts</translation>
    </message>
    <message>
      <source>Related objects</source>
      <translation>Related objects</translation>
    </message>
    <message>
      <source>My pending list</source>
      <translation>My pending list</translation>
    </message>
    <message>
      <source>Your pending list is empty</source>
      <translation>Your pending list is empty</translation>
    </message>
    <message>
      <source>Upload file</source>
      <translation>Upload file</translation>
    </message>
    <message>
      <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.
</source>
      <translation>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.
</translation>
    </message>
    <message>
      <source>Current version</source>
      <translation>Current version</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Translation</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>Placement</source>
      <translation>Placement</translation>
    </message>
    <message>
      <source>Site Design</source>
      <translation>Site Design</translation>
    </message>
    <message>
      <source>Change</source>
      <translation>Change</translation>
    </message>
    <message>
      <source>Publish</source>
      <translation>Publish</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>Site Access</source>
      <translation>Site Access</translation>
    </message>
  </context>
  <context>
    <name>design/standard/contentstructuremenu</name>
    <message>
      <source>Fold/Unfold</source>
      <translation>Fold/Unfold</translation>
    </message>
    <message>
      <source>[%classname] Click on the icon to get a context sensitive menu.</source>
      <translation>[%classname] Click on the icon to get a context sensitive menu.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/design/templateadmin</name>
    <message>
      <source>Template edit</source>
      <translation>Template edit</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Save</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
  </context>
  <context>
    <name>design/standard/design/templatecreate</name>
    <message>
      <source>Could not create template, permission denied.</source>
      <translation>Could not create template, permission denied.</translation>
    </message>
    <message>
      <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
      <translation>Invalid name. You can only use the characters a-z, numbers and _.</translation>
    </message>
    <message>
      <source>Create new template override for &lt;%template_name&gt;</source>
      <translation>Create new template override for &lt;%template_name&gt;</translation>
    </message>
    <message>
      <source>The newly created template file will be placed in</source>
      <translation>The newly created template file will be placed in</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Filename</translation>
    </message>
    <message>
      <source>Override keys</source>
      <translation>Override keys</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>All classes</source>
      <translation>All classes</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>All sections</source>
      <translation>All sections</translation>
    </message>
    <message>
      <source>Node ID</source>
      <translation>Node ID</translation>
    </message>
    <message>
      <source>Base template on</source>
      <translation>Base template on</translation>
    </message>
    <message>
      <source>Empty file</source>
      <translation>Empty file</translation>
    </message>
    <message>
      <source>Copy of default template</source>
      <translation>Copy of default template</translation>
    </message>
    <message>
      <source>Container (with children)</source>
      <translation>Container (with children)</translation>
    </message>
    <message>
      <source>View (without children)</source>
      <translation>View (without children)</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Object</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/design/templatelist</name>
    <message>
      <source>Complete template list</source>
      <translation>Complete template list</translation>
    </message>
    <message>
      <source>Template</source>
      <translation>Template</translation>
    </message>
    <message>
      <source>Design resource</source>
      <translation>Design resource</translation>
    </message>
    <message>
      <source>Most common templates</source>
      <translation>Most common templates</translation>
    </message>
  </context>
  <context>
    <name>design/standard/design/templateview</name>
    <message>
      <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
      <translation>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</translation>
    </message>
    <message>
      <source>Default template resource</source>
      <translation>Default template resource</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Match conditions</source>
      <translation>Match conditions</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>New override</source>
      <translation>New override</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
  </context>
  <context>
    <name>design/standard/design/toolbar</name>
    <message>
      <source>Tool List for Toolbar_%toolbar_position</source>
      <translation>Tool List for Toolbar_%toolbar_position</translation>
    </message>
    <message>
      <source>Tool</source>
      <translation>Tool</translation>
    </message>
    <message>
      <source>Placement</source>
      <translation>Placement</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Update Placement</source>
      <translation>Update Placement</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Add Tool</source>
      <translation>Add Tool</translation>
    </message>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Current siteaccess</source>
      <translation>Current siteaccess</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Available toolbars</source>
      <translation>Available toolbars</translation>
    </message>
  </context>
  <context>
    <name>design/standard/edit/</name>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Global (override)</source>
      <translation>Global (override)</translation>
    </message>
  </context>
  <context>
    <name>design/standard/error/kernel</name>
    <message>
      <source>Access denied</source>
      <translation>Access denied</translation>
    </message>
    <message>
      <source>You don't have permission to access this area.</source>
      <translation>You don't have permission to access this area.</translation>
    </message>
    <message>
      <source>Possible reasons for this are</source>
      <translation>Possible reasons for this are</translation>
    </message>
    <message>
      <source>Your current user does not have the proper privileges to access this page.</source>
      <translation>Your current user does not have the proper privileges to access this page.</translation>
    </message>
    <message>
      <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
      <translation>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</translation>
    </message>
    <message>
      <source>You misspelled some parts of your URL, try changing it.</source>
      <translation>You misspelled some parts of your URL, try changing it.</translation>
    </message>
    <message>
      <source>Permission required</source>
      <translation>Permission required</translation>
    </message>
    <message>
      <source>Module : </source>
      <translation>Module : </translation>
    </message>
    <message>
      <source>Function : </source>
      <translation>Function : </translation>
    </message>
    <message>
      <source>Click the Login button to login.</source>
      <translation>Click the Login button to login.</translation>
    </message>
    <message>
      <source>Login</source>
      <comment>Button</comment>
      <translation>Login</translation>
    </message>
    <message>
      <source>Not found</source>
      <translation>Not found</translation>
    </message>
    <message>
      <source>The resource you requested was not found.</source>
      <translation>The resource you requested was not found.</translation>
    </message>
    <message>
      <source>The the id or name of the resource was misspelled, try changing it.</source>
      <translation>The the id or name of the resource was misspelled, try changing it.</translation>
    </message>
    <message>
      <source>The resource no longer exists on the site.</source>
      <translation>The resource no longer exists on the site.</translation>
    </message>
    <message>
      <source>Module not found</source>
      <translation>Module not found</translation>
    </message>
    <message>
      <source>The requested module %module could not be found.</source>
      <translation>The requested module %module could not be found.</translation>
    </message>
    <message>
      <source>The module name was misspelled, try changing the URL.</source>
      <translation>The module name was misspelled, try changing the URL.</translation>
    </message>
    <message>
      <source>The module does not exist on this site.</source>
      <translation>The module does not exist on this site.</translation>
    </message>
    <message>
      <source>This site uses siteaccess matching in the URL and you didn't supply one, try inserting a siteaccess name before the module in the URL .</source>
      <translation>This site uses siteaccess matching in the URL and you didn't supply one, try inserting a siteaccess name before the module in the URL .</translation>
    </message>
    <message>
      <source>View not found</source>
      <translation>View not found</translation>
    </message>
    <message>
      <source>The requested view %view could not be found in module %module</source>
      <translation>The requested view %view could not be found in module %module</translation>
    </message>
    <message>
      <source>The view name was misspelled, try changing the URL.</source>
      <translation>The view name was misspelled, try changing the URL.</translation>
    </message>
    <message>
      <source>The view does not exist for the module %module.</source>
      <translation>The view does not exist for the module %module.</translation>
    </message>
    <message>
      <source>View is disabled</source>
      <translation>View is disabled</translation>
    </message>
    <message>
      <source>The view %module/%view is disabled and cannot be accessed.</source>
      <translation>The view %module/%view is disabled and cannot be accessed.</translation>
    </message>
    <message>
      <source>Module is disabled</source>
      <translation>Module is disabled</translation>
    </message>
    <message>
      <source>The module %module is disabled and cannot be accessed.</source>
      <translation>The module %module is disabled and cannot be accessed.</translation>
    </message>
    <message>
      <source>Object is unavailable</source>
      <translation>Object is unavailable</translation>
    </message>
    <message>
      <source>The object you requested is not currently available.</source>
      <translation>The object you requested is not currently available.</translation>
    </message>
    <message>
      <source>The id or name of the object was misspelled, try changing it.</source>
      <translation>The id or name of the object was misspelled, try changing it.</translation>
    </message>
    <message>
      <source>The object is no longer available on the site.</source>
      <translation>The object is no longer available on the site.</translation>
    </message>
    <message>
      <source>Object moved</source>
      <translation>Object moved</translation>
    </message>
    <message>
      <source>The object is no longer available at this URL.</source>
      <translation>The object is no longer available at this URL.</translation>
    </message>
    <message>
      <source>You should automatically be redirected to the new location. If not click %url.</source>
      <translation>You should automatically be redirected to the new location. If not click %url.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/error/shop</name>
    <message>
      <source>Not a product</source>
      <translation>Not a product</translation>
    </message>
    <message>
      <source>The requested object is not a product and cannot be used by the shop module.</source>
      <translation>The requested object is not a product and cannot be used by the shop module.</translation>
    </message>
    <message>
      <source>Incompatible product type</source>
      <translation>Incompatible product type</translation>
    </message>
    <message>
      <source>The requested object and current basket have incompatible price datatypes.</source>
      <translation>The requested object and current basket have incompatible price datatypes.</translation>
    </message>
    <message>
      <source>Invalid preferred currency</source>
      <translation>Invalid preferred currency</translation>
    </message>
    <message>
      <source>'%1' currency doesn't exist.</source>
      <translation>'%1' currency doesn't exist.</translation>
    </message>
    <message>
      <source>'%1' can't be used because it's inactive.</source>
      <translation>'%1' can't be used because it's inactive.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/form</name>
    <message>
      <source>Thank you for your feedback</source>
      <translation>Thank you for your feedback</translation>
    </message>
    <message>
      <source>Your information was successfully received.</source>
      <translation>Your information was successfully received.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/gui</name>
    <message>
      <source>Delete</source>
      <translation>Delete</translation>
    </message>
  </context>
  <context>
    <name>design/standard/layout</name>
    <message>
      <source>Filter</source>
      <translation>Filter</translation>
    </message>
    <message>
      <source>%sitetitle front page</source>
      <translation>%sitetitle front page</translation>
    </message>
    <message>
      <source>Search %sitetitle</source>
      <translation>Search %sitetitle</translation>
    </message>
    <message>
      <source>Printable version</source>
      <translation>Printable version</translation>
    </message>
    <message>
      <source>Welcome to eZ publish administration</source>
      <translation>Welcome to eZ publish administration</translation>
    </message>
    <message>
      <source>To log in enter a valid login and password.</source>
      <translation>To log in enter a valid login and password.</translation>
    </message>
    <message>
      <source>Advanced search</source>
      <translation>Advanced search</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Frontpage</source>
      <translation>Frontpage</translation>
    </message>
    <message>
      <source>Sitemap</source>
      <translation>Sitemap</translation>
    </message>
    <message>
      <source>Personal</source>
      <translation>Personal</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>Change Password</source>
      <translation>Change Password</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Logout</source>
      <translation>Logout</translation>
    </message>
    <message>
      <source>eZ publish redirection - %url</source>
      <translation>eZ publish redirection - %url</translation>
    </message>
    <message>
      <source>Redirecting to %url</source>
      <translation>Redirecting to %url</translation>
    </message>
    <message>
      <source>Redirect</source>
      <translation>Redirect</translation>
    </message>
    <message>
      <source>Module load failed</source>
      <translation>Module load failed</translation>
    </message>
    <message>
      <source>Undefined module: </source>
      <translation>Undefined module: </translation>
    </message>
  </context>
  <context>
    <name>design/standard/location</name>
    <message>
      <source>Removal of locations</source>
      <translation>Removal of locations</translation>
    </message>
    <message>
      <source>Some of the locations you tried to remove has children, are you really sure you want to remove those locations?
If you do all the children will be removed as well.</source>
      <translation>Some of the locations you tried to remove has children, are you really sure you want to remove those locations?
If you do all the children will be removed as well.</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Path</translation>
    </message>
    <message>
      <source>Count</source>
      <translation>Count</translation>
    </message>
    <message>
      <source>Remove locations</source>
      <translation>Remove locations</translation>
    </message>
    <message>
      <source>Cancel removal</source>
      <translation>Cancel removal</translation>
    </message>
  </context>
  <context>
    <name>design/standard/menuconfig</name>
    <message>
      <source>Menu management</source>
      <translation>Menu management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Current siteaccess</source>
      <translation>Current siteaccess</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Menu positioning</source>
      <translation>Menu positioning</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
  </context>
  <context>
    <name>design/standard/navigator</name>
    <message>
      <source>Previous</source>
      <translation>Previous</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
  </context>
  <context>
    <name>design/standard/node</name>
    <message>
      <source>Are you sure you want to remove the following translations from object &lt;%1&gt;?</source>
      <translation>Are you sure you want to remove the following translations from object &lt;%1&gt;?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove %1 from node %2?</source>
      <translation>Are you sure you want to remove %1 from node %2?</translation>
    </message>
    <message>
      <source>Removing this assignment will also remove its %1 children.</source>
      <translation>Removing this assignment will also remove its %1 children.</translation>
    </message>
    <message>
      <source>Note:</source>
      <translation>Note:</translation>
    </message>
    <message>
      <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
      <translation>Removed nodes can be retrieved later. You will find them in the trash.</translation>
    </message>
    <message>
      <source>Removing node assignment of %1</source>
      <translation>Removing node assignment of %1</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Are you sure you want to remove these items?</source>
      <translation>Are you sure you want to remove these items?</translation>
    </message>
    <message>
      <source>%nodename and its %childcount children. %additionalwarning</source>
      <translation>%nodename and its %childcount children. %additionalwarning</translation>
    </message>
    <message>
      <source>%nodename %additionalwarning</source>
      <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
      <source>Move to trash</source>
      <translation>Move to trash</translation>
    </message>
    <message>
      <source>Note</source>
      <translation>Note</translation>
    </message>
    <message>
      <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
      <translation>If %trashname is checked you will find the removed items in the trash afterwards.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/node/view</name>
    <message>
      <source>Missing or invalid input</source>
      <translation>Missing or invalid input</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>User</source>
      <translation>User</translation>
    </message>
    <message>
      <source>User group</source>
      <translation>User group</translation>
    </message>
    <message>
      <source>Document</source>
      <translation>Document</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Select all</source>
      <translation>Select all</translation>
    </message>
    <message>
      <source>Deselect all</source>
      <translation>Deselect all</translation>
    </message>
    <message>
      <source>Default object view.</source>
      <translation>Default object view.</translation>
    </message>
    <message>
      <source>Click to create a custom template</source>
      <translation>Click to create a custom template</translation>
    </message>
    <message>
      <source>Node ID</source>
      <translation>Node ID</translation>
    </message>
    <message>
      <source>Object ID</source>
      <translation>Object ID</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>Add to Bookmarks</source>
      <translation>Add to Bookmarks</translation>
    </message>
    <message>
      <source>Notify me about updates</source>
      <translation>Notify me about updates</translation>
    </message>
    <message>
      <source>Create here</source>
      <translation>Create here</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Placed in</source>
      <translation>Placed in</translation>
    </message>
    <message>
      <source>Site map</source>
      <translation>Site map</translation>
    </message>
  </context>
  <context>
    <name>design/standard/notification</name>
    <message>
      <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
      <translation>If you do not wish to continue receiving these notifications,
change your settings at:</translation>
    </message>
    <message>
      <source>%sitename notification system</source>
      <translation>%sitename notification system</translation>
    </message>
    <message>
      <source>[%sitename] New collaboration item</source>
      <translation>[%sitename] New collaboration item</translation>
    </message>
    <message>
      <source>This e-mail is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
      <translation>This e-mail is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</translation>
    </message>
    <message>
      <source>Receive all messages combined in one digest</source>
      <translation>Receive all messages combined in one digest</translation>
    </message>
    <message>
      <source>Time of day</source>
      <translation>Time of day</translation>
    </message>
    <message>
      <source>Daily</source>
      <translation>Daily</translation>
    </message>
    <message>
      <source>Weekly, day of week</source>
      <translation>Weekly, day of week</translation>
    </message>
    <message>
      <source>Monthly, day of month</source>
      <translation>Monthly, day of month</translation>
    </message>
    <message>
      <source>If the day of month number you have chosen is larger than the number of days in the current month, then the last day of the current month will be used instead.</source>
      <translation>If the day of month number you have chosen is larger than the number of days in the current month, then the last day of the current month will be used instead.</translation>
    </message>
    <message>
      <source>[%sitename] Digest for %date</source>
      <translation>[%sitename] Digest for %date</translation>
    </message>
    <message>
      <source>This digest e-mail is to inform you on new items at %sitename.</source>
      <translation>This digest e-mail is to inform you on new items at %sitename.</translation>
    </message>
    <message>
      <source>Do you want to receive messages combined in digest</source>
      <translation>Do you want to receive messages combined in digest</translation>
    </message>
    <message>
      <source>Digest settings</source>
      <translation>Digest settings</translation>
    </message>
    <message>
      <source>Day of the week</source>
      <translation>Day of the week</translation>
    </message>
    <message>
      <source>This e-mail is to inform you on news at %sitename.</source>
      <translation>This e-mail is to inform you on news at %sitename.</translation>
    </message>
    <message>
      <source>Node notification</source>
      <translation>Node notification</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>&quot;%name&quot; was updated</source>
      <translation>&quot;%name&quot; was updated</translation>
    </message>
    <message>
      <source>This e-mail is to inform you that an updated item has been published at %sitename.</source>
      <translation>This e-mail is to inform you that an updated item has been published at %sitename.</translation>
    </message>
    <message>
      <source>The item can be viewed by using the URL below.</source>
      <translation>The item can be viewed by using the URL below.</translation>
    </message>
    <message>
      <source>&quot;%name&quot; was published</source>
      <translation>&quot;%name&quot; was published</translation>
    </message>
    <message>
      <source>This e-mail is to inform you that a new item has been published at %sitename.</source>
      <translation>This e-mail is to inform you that a new item has been published at %sitename.</translation>
    </message>
    <message>
      <source>Notification settings</source>
      <translation>Notification settings</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Notification admin</source>
      <translation>Notification admin</translation>
    </message>
    <message>
      <source>Notification filter processed all available notification events</source>
      <translation>Notification filter processed all available notification events</translation>
    </message>
    <message>
      <source>Time event was spawned</source>
      <translation>Time event was spawned</translation>
    </message>
    <message>
      <source>Run notification filter</source>
      <translation>Run notification filter</translation>
    </message>
    <message>
      <source>Run</source>
      <translation>Run</translation>
    </message>
    <message>
      <source>Spawn time event</source>
      <translation>Spawn time event</translation>
    </message>
    <message>
      <source>Spawn</source>
      <translation>Spawn</translation>
    </message>
  </context>
  <context>
    <name>design/standard/notification/addingresult</name>
    <message>
      <source>Add to my notifications</source>
      <translation>Add to my notifications</translation>
    </message>
    <message>
      <source>Notification for node &lt;%node_name&gt; already exists.</source>
      <translation>Notification for node &lt;%node_name&gt; already exists.</translation>
    </message>
    <message>
      <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
      <translation>Notification for node &lt;%node_name&gt; was added successfully.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
  </context>
  <context>
    <name>design/standard/notification/collaboration</name>
    <message>
      <source>Collaboration notification</source>
      <translation>Collaboration notification</translation>
    </message>
    <message>
      <source>Choose which collaboration items you wish to get notifications for.</source>
      <translation>Choose which collaboration items you wish to get notifications for.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/package</name>
    <message>
      <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
      <translation>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</translation>
    </message>
    <message>
      <source>Installing package</source>
      <translation>Installing package</translation>
    </message>
    <message>
      <source>Please choose action:</source>
      <translation>Please choose action:</translation>
    </message>
    <message>
      <source>Use this choice for all the items</source>
      <translation>Use this choice for all the items</translation>
    </message>
    <message>
      <source>Unhandled installation error has occured.</source>
      <translation>Unhandled installation error has occured.</translation>
    </message>
    <message>
      <source>Continue</source>
      <translation>Continue</translation>
    </message>
    <message>
      <source>Cancel installation</source>
      <translation>Cancel installation</translation>
    </message>
    <message>
      <source>Uninstalling package</source>
      <translation>Uninstalling package</translation>
    </message>
    <message>
      <source>Unhandled uninstallation error has occured.</source>
      <translation>Unhandled uninstallation error has occured.</translation>
    </message>
    <message>
      <source>Cancel uninstallation</source>
      <translation>Cancel uninstallation</translation>
    </message>
    <message>
      <source>Please provide information on the changes.</source>
      <translation>Please provide information on the changes.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Changes</translation>
    </message>
    <message>
      <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
      <translation>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</translation>
    </message>
    <message>
      <source>Please provide some basic information for your package.</source>
      <translation>Please provide some basic information for your package.</translation>
    </message>
    <message>
      <source>Package name</source>
      <translation>Package name</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Licence</source>
      <translation>Licence</translation>
    </message>
    <message>
      <source>Package host</source>
      <translation>Package host</translation>
    </message>
    <message>
      <source>Packager</source>
      <translation>Packager</translation>
    </message>
    <message>
      <source>Please provide information on the maintainer of the package.</source>
      <translation>Please provide information on the maintainer of the package.</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>Maintainer name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Role</source>
      <comment>Maintainer role</comment>
      <translation>Role</translation>
    </message>
    <message>
      <source>Create package</source>
      <translation>Create package</translation>
    </message>
    <message>
      <source>Available wizards</source>
      <translation>Available wizards</translation>
    </message>
    <message>
      <source>Choose one of the following wizards for creating a package</source>
      <translation>Choose one of the following wizards for creating a package</translation>
    </message>
    <message>
      <source>Please choose the content classes you wish to be included in the package.</source>
      <translation>Please choose the content classes you wish to be included in the package.</translation>
    </message>
    <message>
      <source>Class list</source>
      <translation>Class list</translation>
    </message>
    <message>
      <source>Please choose objects you wish to include in the package.</source>
      <translation>Please choose objects you wish to include in the package.</translation>
    </message>
    <message>
      <source>Selected nodes</source>
      <translation>Selected nodes</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Export type</source>
      <translation>Export type</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Add subtree</source>
      <translation>Add subtree</translation>
    </message>
    <message>
      <source>Add node</source>
      <translation>Add node</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Please select an extension to be exported.</source>
      <translation>Please select an extension to be exported.</translation>
    </message>
    <message>
      <source>Please select the site CSS file to be included in the package.</source>
      <translation>Please select the site CSS file to be included in the package.</translation>
    </message>
    <message>
      <source>Please select the classes CSS file to be included in the package.</source>
      <translation>Please select the classes CSS file to be included in the package.</translation>
    </message>
    <message>
      <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
      <translation>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</translation>
    </message>
    <message>
      <source>Currently added image files</source>
      <translation>Currently added image files</translation>
    </message>
    <message>
      <source>Package wizard: %wizardname</source>
      <translation>Package wizard: %wizardname</translation>
    </message>
    <message>
      <source>Install package</source>
      <translation>Install package</translation>
    </message>
    <message>
      <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
      <translation>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</translation>
    </message>
    <message>
      <source>Install items</source>
      <translation>Install items</translation>
    </message>
    <message>
      <source>Skip installation</source>
      <translation>Skip installation</translation>
    </message>
    <message>
      <source>Use this choice for all items</source>
      <translation>Use this choice for all items</translation>
    </message>
    <message>
      <source>Package install wizard: %wizardname</source>
      <translation>Package install wizard: %wizardname</translation>
    </message>
    <message>
      <source>You must now choose which siteaccess the package contents should be installed to.
The chosen siteaccess determines where design files and settings are written to.
If unsure choose the siteaccess which reflects the user part of your site, i.e. not admin.</source>
      <translation>You must now choose which siteaccess the package contents should be installed to.
The chosen siteaccess determines where design files and settings are written to.
If unsure choose the siteaccess which reflects the user part of your site, i.e. not admin.</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Map %siteaccess_name to</source>
      <translation>Map %siteaccess_name to</translation>
    </message>
    <message>
      <source>Please select where you want to place the imported items.</source>
      <translation>Please select where you want to place the imported items.</translation>
    </message>
    <message>
      <source>If you wish to change the placement click the browse button.</source>
      <translation>If you wish to change the placement click the browse button.</translation>
    </message>
    <message>
      <source>Place %object_name in node %node_placement</source>
      <translation>Place %object_name in node %node_placement</translation>
    </message>
    <message>
      <source>Choose placement for %object_name</source>
      <translation>Choose placement for %object_name</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Removal of packages</source>
      <translation>Removal of packages</translation>
    </message>
    <message>
      <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
      <translation>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</translation>
    </message>
    <message>
      <source>Confirm removal</source>
      <translation>Confirm removal</translation>
    </message>
    <message>
      <source>Keep packages</source>
      <translation>Keep packages</translation>
    </message>
    <message>
      <source>Packages</source>
      <translation>Packages</translation>
    </message>
    <message>
      <source>Package removal was cancelled.</source>
      <translation>Package removal was cancelled.</translation>
    </message>
    <message>
      <source>The following packages are available on this system</source>
      <translation>The following packages are available on this system</translation>
    </message>
    <message>
      <source>Repositories</source>
      <translation>Repositories</translation>
    </message>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>Change repository</source>
      <translation>Change repository</translation>
    </message>
    <message>
      <source>Selection</source>
      <translation>Selection</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Installed</translation>
    </message>
    <message>
      <source>Not installed</source>
      <translation>Not installed</translation>
    </message>
    <message>
      <source>Imported</source>
      <translation>Imported</translation>
    </message>
    <message>
      <source>Remove package</source>
      <translation>Remove package</translation>
    </message>
    <message>
      <source>Import package</source>
      <translation>Import package</translation>
    </message>
    <message>
      <source>Next %arrowright</source>
      <translation>Next %arrowright</translation>
    </message>
    <message>
      <source>Finish</source>
      <translation>Finish</translation>
    </message>
    <message>
      <source>Uninstall package</source>
      <translation>Uninstall package</translation>
    </message>
    <message>
      <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
      <translation>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</translation>
    </message>
    <message>
      <source>Uninstall items</source>
      <translation>Uninstall items</translation>
    </message>
    <message>
      <source>Skip uninstallation</source>
      <translation>Skip uninstallation</translation>
    </message>
    <message>
      <source>Upload package</source>
      <translation>Upload package</translation>
    </message>
    <message>
      <source>Select the file containing your package and click the upload button</source>
      <translation>Select the file containing your package and click the upload button</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Files [%collectionname]</source>
      <translation>Files [%collectionname]</translation>
    </message>
    <message>
      <source>Details</source>
      <translation>Details</translation>
    </message>
    <message>
      <source>Uninstall</source>
      <translation>Uninstall</translation>
    </message>
    <message>
      <source>Install</source>
      <translation>Install</translation>
    </message>
    <message>
      <source>Export to file</source>
      <translation>Export to file</translation>
    </message>
    <message>
      <source>State</source>
      <translation>State</translation>
    </message>
    <message>
      <source>Maintainers</source>
      <translation>Maintainers</translation>
    </message>
    <message>
      <source>Regarding eZ publish package '%packagename'</source>
      <translation>Regarding eZ publish package '%packagename'</translation>
    </message>
    <message>
      <source>Send e-mail to the maintainer</source>
      <translation>Send e-mail to the maintainer</translation>
    </message>
    <message>
      <source>Documents</source>
      <translation>Documents</translation>
    </message>
    <message>
      <source>Changelog</source>
      <translation>Changelog</translation>
    </message>
    <message>
      <source>Send E-Mail to the maintainer</source>
      <translation>Send E-Mail to the maintainer</translation>
    </message>
    <message>
      <source>File list</source>
      <translation>File list</translation>
    </message>
  </context>
  <context>
    <name>design/standard/package/creators/ezcontentobject</name>
    <message>
      <source>Choose node for export</source>
      <translation>Choose node for export</translation>
    </message>
    <message>
      <source>Please choose the node(s) you wish to export.</source>
      <translation>Please choose the node(s) you wish to export.</translation>
    </message>
    <message>
      <source>Choose subtree for export</source>
      <translation>Choose subtree for export</translation>
    </message>
    <message>
      <source>Please choose the subtree(s) you wish to export.</source>
      <translation>Please choose the subtree(s) you wish to export.</translation>
    </message>
    <message>
      <source>Specify export properties. Default settings will most likely be suitable for your needs.</source>
      <translation>Specify export properties. Default settings will most likely be suitable for your needs.</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Miscellaneous</translation>
    </message>
    <message>
      <source>Include class definitions.</source>
      <translation>Include class definitions.</translation>
    </message>
    <message>
      <source>Include templates related exported objects.</source>
      <translation>Include templates related exported objects.</translation>
    </message>
    <message>
      <source>Select templates from the following siteaccesses</source>
      <translation>Select templates from the following siteaccesses</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>Published version</source>
      <translation>Published version</translation>
    </message>
    <message>
      <source>All versions</source>
      <translation>All versions</translation>
    </message>
    <message>
      <source>Languages</source>
      <translation>Languages</translation>
    </message>
    <message>
      <source>Select languages to export</source>
      <translation>Select languages to export</translation>
    </message>
    <message>
      <source>Node assignments</source>
      <translation>Node assignments</translation>
    </message>
    <message>
      <source>Keep all in selected nodes</source>
      <translation>Keep all in selected nodes</translation>
    </message>
    <message>
      <source>Main only</source>
      <translation>Main only</translation>
    </message>
    <message>
      <source>Related objects</source>
      <translation>Related objects</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
  </context>
  <context>
    <name>design/standard/package/installers/ezcontentobject</name>
    <message>
      <source>Choose parent node</source>
      <translation>Choose parent node</translation>
    </message>
    <message>
      <source>Select parent node for new node.</source>
      <translation>Select parent node for new node.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/pagelayout</name>
    <message>
      <source>All caches</source>
      <translation>All caches</translation>
    </message>
    <message>
      <source>Content</source>
      <translation>Content</translation>
    </message>
    <message>
      <source>Content - node</source>
      <translation>Content - node</translation>
    </message>
    <message>
      <source>Content - subtree</source>
      <translation>Content - subtree</translation>
    </message>
    <message>
      <source>Template</source>
      <translation>Template</translation>
    </message>
    <message>
      <source>Template &amp; content</source>
      <translation>Template &amp; content</translation>
    </message>
    <message>
      <source>Ini settings</source>
      <translation>Ini settings</translation>
    </message>
    <message>
      <source>Static</source>
      <translation>Static</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Clear</translation>
    </message>
  </context>
  <context>
    <name>design/standard/pdf/list</name>
    <message>
      <source>PDF Exports</source>
      <translation>PDF Exports</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Creator</source>
      <translation>Creator</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>Created</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>New Export</source>
      <translation>New Export</translation>
    </message>
  </context>
  <context>
    <name>design/standard/reference/ez</name>
    <message>
      <source>No generated documentation found</source>
      <translation>No generated documentation found</translation>
    </message>
    <message>
      <source>To create the reference documentation you must do the following step</source>
      <translation>To create the reference documentation you must do the following step</translation>
    </message>
    <message>
      <source>Download and install doxygen</source>
      <translation>Download and install doxygen</translation>
    </message>
    <message>
      <source>Generate the documentation by running the following command</source>
      <translation>Generate the documentation by running the following command</translation>
    </message>
    <message>
      <source>Download doxygen from %doxygenurl.</source>
      <translation>Download doxygen from %doxygenurl.</translation>
    </message>
    <message>
      <source>Main</source>
      <translation>Main</translation>
    </message>
    <message>
      <source>Modules</source>
      <translation>Modules</translation>
    </message>
    <message>
      <source>Class hierarchy</source>
      <translation>Class hierarchy</translation>
    </message>
    <message>
      <source>Compound list</source>
      <translation>Compound list</translation>
    </message>
    <message>
      <source>File list</source>
      <translation>File list</translation>
    </message>
    <message>
      <source>Compound members</source>
      <translation>Compound members</translation>
    </message>
    <message>
      <source>File members</source>
      <translation>File members</translation>
    </message>
    <message>
      <source>Related pages</source>
      <translation>Related pages</translation>
    </message>
    <message>
      <source>Introduction</source>
      <translation>Introduction</translation>
    </message>
    <message>
      <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
      <translation>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</translation>
    </message>
    <message>
      <source>The documentation will give an overview of the API of eZ publish.</source>
      <translation>The documentation will give an overview of the API of eZ publish.</translation>
    </message>
    <message>
      <source>All reference documentation has been made with %doxygenurl</source>
      <translation>All reference documentation has been made with %doxygenurl</translation>
    </message>
  </context>
  <context>
    <name>design/standard/role</name>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Create policy for</source>
      <translation>Create policy for</translation>
    </message>
    <message>
      <source>Step 1</source>
      <translation>Step 1</translation>
    </message>
    <message>
      <source>Give access to module</source>
      <translation>Give access to module</translation>
    </message>
    <message>
      <source>Every module</source>
      <translation>Every module</translation>
    </message>
    <message>
      <source>Allow all</source>
      <translation>Allow all</translation>
    </message>
    <message>
      <source>Allow limited</source>
      <translation>Allow limited</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Module</source>
      <translation>Module</translation>
    </message>
    <message>
      <source>Access</source>
      <translation>Access</translation>
    </message>
    <message>
      <source>Limited</source>
      <translation>Limited</translation>
    </message>
    <message>
      <source>Go back to step 1</source>
      <translation>Go back to step 1</translation>
    </message>
    <message>
      <source>You are not able to give access to limited functions of module</source>
      <translation>You are not able to give access to limited functions of module</translation>
    </message>
    <message>
      <source>because function list for it is not defined.</source>
      <translation>because function list for it is not defined.</translation>
    </message>
    <message>
      <source>Step 2</source>
      <translation>Step 2</translation>
    </message>
    <message>
      <source>Specify function in module</source>
      <translation>Specify function in module</translation>
    </message>
    <message>
      <source>Function</source>
      <translation>Function</translation>
    </message>
    <message>
      <source>Go back to step 2</source>
      <translation>Go back to step 2</translation>
    </message>
    <message>
      <source>Step 3</source>
      <translation>Step 3</translation>
    </message>
    <message>
      <source>Specify limitations for function %functionname in module %modulename. 'Any' means no limitation by this parameter</source>
      <translation>Specify limitations for function %functionname in module %modulename. 'Any' means no limitation by this parameter</translation>
    </message>
    <message>
      <source>Limitations</source>
      <translation>Limitations</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Not specified.</source>
      <translation>Not specified.</translation>
    </message>
    <message>
      <source>Find</source>
      <translation>Find</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Role edit %1</source>
      <translation>Role edit %1</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Current policies</source>
      <translation>Current policies</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit policy</source>
      <translation>Edit policy</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Remove selected policies</source>
      <translation>Remove selected policies</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Discard changes</source>
      <translation>Discard changes</translation>
    </message>
    <message>
      <source>Role list</source>
      <translation>Role list</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Assign</source>
      <translation>Assign</translation>
    </message>
    <message>
      <source>Subtree</source>
      <translation>Subtree</translation>
    </message>
    <message>
      <source>Edit role</source>
      <translation>Edit role</translation>
    </message>
    <message>
      <source>Copy role</source>
      <translation>Copy role</translation>
    </message>
    <message>
      <source>Assign role to user or group</source>
      <translation>Assign role to user or group</translation>
    </message>
    <message>
      <source>Assign role to user or group to subtree</source>
      <translation>Assign role to user or group to subtree</translation>
    </message>
    <message>
      <source>Remove selected roles</source>
      <translation>Remove selected roles</translation>
    </message>
    <message>
      <source>Policy</source>
      <translation>Policy</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Role view</source>
      <translation>Role view</translation>
    </message>
    <message>
      <source>Role</source>
      <translation>Role</translation>
    </message>
    <message>
      <source>Edit current role</source>
      <translation>Edit current role</translation>
    </message>
    <message>
      <source>Role policies</source>
      <translation>Role policies</translation>
    </message>
    <message>
      <source>Limitation</source>
      <translation>Limitation</translation>
    </message>
    <message>
      <source>Users and groups assigned to this role</source>
      <translation>Users and groups assigned to this role</translation>
    </message>
    <message>
      <source>User</source>
      <translation>User</translation>
    </message>
    <message>
      <source>Assign limited</source>
      <translation>Assign limited</translation>
    </message>
    <message>
      <source>Remove selected assignments</source>
      <translation>Remove selected assignments</translation>
    </message>
  </context>
  <context>
    <name>design/standard/rss</name>
    <message>
      <source>Choose export node</source>
      <translation>Choose export node</translation>
    </message>
    <message>
      <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Choose import destination</source>
      <translation>Choose import destination</translation>
    </message>
    <message>
      <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose RSS image</source>
      <translation>Choose RSS image</translation>
    </message>
    <message>
      <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose export source</source>
      <translation>Choose export source</translation>
    </message>
    <message>
      <source>Choose owner of imported objects</source>
      <translation>Choose owner of imported objects</translation>
    </message>
    <message>
      <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>RSS export is locked</source>
      <translation>RSS export is locked</translation>
    </message>
    <message>
      <source>The RSS export %name is currently locked by %user and was last modified on %datetime.</source>
      <translation>The RSS export %name is currently locked by %user and was last modified on %datetime.</translation>
    </message>
    <message>
      <source>The RSS export will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
      <translation>The RSS export will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</translation>
    </message>
    <message>
      <source>Retry</source>
      <translation>Retry</translation>
    </message>
    <message>
      <source>RSS import is locked</source>
      <translation>RSS import is locked</translation>
    </message>
    <message>
      <source>The RSS import %name is currently locked by %user and was last modified on %datetime.</source>
      <translation>The RSS import %name is currently locked by %user and was last modified on %datetime.</translation>
    </message>
    <message>
      <source>The RSS import will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
      <translation>The RSS import will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/rss/edit</name>
    <message>
      <source>PDF Export</source>
      <translation>PDF Export</translation>
    </message>
    <message>
      <source>Title</source>
      <translation>Title</translation>
    </message>
    <message>
      <source>Display frontpage</source>
      <translation>Display frontpage</translation>
    </message>
    <message>
      <source>Intro text</source>
      <translation>Intro text</translation>
    </message>
    <message>
      <source>Sub text</source>
      <translation>Sub text</translation>
    </message>
    <message>
      <source>Source node</source>
      <translation>Source node</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>Export structure</source>
      <translation>Export structure</translation>
    </message>
    <message>
      <source>Tree</source>
      <translation>Tree</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Export classes</source>
      <translation>Export classes</translation>
    </message>
    <message>
      <source>Export destination</source>
      <translation>Export destination</translation>
    </message>
    <message>
      <source>Export to URL</source>
      <translation>Export to URL</translation>
    </message>
    <message>
      <source>Export for direct download</source>
      <translation>Export for direct download</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Export</translation>
    </message>
    <message>
      <source>RSS Export</source>
      <translation>RSS Export</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Site URL</source>
      <translation>Site URL</translation>
    </message>
    <message>
      <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
      <translation>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Image</translation>
    </message>
    <message>
      <source>Site Access</source>
      <translation>Site Access</translation>
    </message>
    <message>
      <source>RSS version</source>
      <translation>RSS version</translation>
    </message>
    <message>
      <source>Number of objects</source>
      <translation>Number of objects</translation>
    </message>
    <message>
      <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
      <translation>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Main node only</source>
      <translation>Main node only</translation>
    </message>
    <message>
      <source>Check if you want to only feed the object from the main node.</source>
      <translation>Check if you want to only feed the object from the main node.</translation>
    </message>
    <message>
      <source>Access URL</source>
      <translation>Access URL</translation>
    </message>
    <message>
      <source>Source path</source>
      <translation>Source path</translation>
    </message>
    <message>
      <source>Subnodes</source>
      <translation>Subnodes</translation>
    </message>
    <message>
      <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
      <translation>Activate this checkbox if also objects from the subnodes of the source should be feeded.</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Remove Source</source>
      <translation>Remove Source</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Add Source</source>
      <translation>Add Source</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
  </context>
  <context>
    <name>design/standard/rss/list</name>
    <message>
      <source>RSS Feeds</source>
      <translation>RSS Feeds</translation>
    </message>
    <message>
      <source>RSS Exports</source>
      <translation>RSS Exports</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>New Export</source>
      <translation>New Export</translation>
    </message>
    <message>
      <source>RSS Imports</source>
      <translation>RSS Imports</translation>
    </message>
    <message>
      <source>New Import</source>
      <translation>New Import</translation>
    </message>
  </context>
  <context>
    <name>design/standard/search</name>
    <message>
      <source>Search statistics</source>
      <translation>Search statistics</translation>
    </message>
    <message>
      <source>Most frequent search phrases</source>
      <translation>Most frequent search phrases</translation>
    </message>
    <message>
      <source>Phrase</source>
      <translation>Phrase</translation>
    </message>
    <message>
      <source>Number of phrases</source>
      <translation>Number of phrases</translation>
    </message>
    <message>
      <source>Average result returned</source>
      <translation>Average result returned</translation>
    </message>
    <message>
      <source>Reset statistics</source>
      <translation>Reset statistics</translation>
    </message>
  </context>
  <context>
    <name>design/standard/section</name>
    <message>
      <source>Assign section - %section</source>
      <translation>Assign section - %section</translation>
    </message>
    <message>
      <source>Assign section to node</source>
      <translation>Assign section to node</translation>
    </message>
    <message>
      <source>Choose section assignment</source>
      <translation>Choose section assignment</translation>
    </message>
    <message>
      <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
      <translation>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</translation>
    </message>
    <message>
      <source>Are you sure you want to remove these sections?</source>
      <translation>Are you sure you want to remove these sections?</translation>
    </message>
    <message>
      <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
      <translation>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Section edit</source>
      <translation>Section edit</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Navigation Part</source>
      <translation>Navigation Part</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>About Navigation Parts</source>
      <translation>About Navigation Parts</translation>
    </message>
    <message>
      <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
      <translation>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</translation>
    </message>
    <message>
      <source>Section list</source>
      <translation>Section list</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Assign</source>
      <translation>Assign</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Remove selected sections</source>
      <translation>Remove selected sections</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup</name>
    <message>
      <source>Cache admin</source>
      <translation>Cache admin</translation>
    </message>
    <message>
      <source>Content view cache was cleared.</source>
      <translation>Content view cache was cleared.</translation>
    </message>
    <message>
      <source>All caches were cleared.</source>
      <translation>All caches were cleared.</translation>
    </message>
    <message>
      <source>Ini file cache was cleared.</source>
      <translation>Ini file cache was cleared.</translation>
    </message>
    <message>
      <source>Template cache was cleared.</source>
      <translation>Template cache was cleared.</translation>
    </message>
    <message>
      <source>%name was cleared.</source>
      <translation>%name was cleared.</translation>
    </message>
    <message>
      <source>Cache collections</source>
      <translation>Cache collections</translation>
    </message>
    <message>
      <source>Click a button to clear a collection of caches.</source>
      <translation>Click a button to clear a collection of caches.</translation>
    </message>
    <message>
      <source>All caches.</source>
      <translation>All caches.</translation>
    </message>
    <message>
      <source>All caches</source>
      <translation>All caches</translation>
    </message>
    <message>
      <source>All caches are disabled</source>
      <translation>All caches are disabled</translation>
    </message>
    <message>
      <source>Content views and template blocks.</source>
      <translation>Content views and template blocks.</translation>
    </message>
    <message>
      <source>Content caches</source>
      <translation>Content caches</translation>
    </message>
    <message>
      <source>Content caches is disabled</source>
      <translation>Content caches is disabled</translation>
    </message>
    <message>
      <source>Template overrides and template compiling.</source>
      <translation>Template overrides and template compiling.</translation>
    </message>
    <message>
      <source>Template caches</source>
      <translation>Template caches</translation>
    </message>
    <message>
      <source>Template caches are disabled</source>
      <translation>Template caches are disabled</translation>
    </message>
    <message>
      <source>INI caches.</source>
      <translation>INI caches.</translation>
    </message>
    <message>
      <source>INI caches</source>
      <translation>INI caches</translation>
    </message>
    <message>
      <source>INI cache is disabled</source>
      <translation>INI cache is disabled</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Path</translation>
    </message>
    <message>
      <source>Selection</source>
      <translation>Selection</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Disabled</translation>
    </message>
    <message>
      <source>Clear selected</source>
      <translation>Clear selected</translation>
    </message>
    <message>
      <source>Content view cache</source>
      <translation>Content view cache</translation>
    </message>
    <message>
      <source>View cache is enabled.</source>
      <translation>View cache is enabled.</translation>
    </message>
    <message>
      <source>View cache is disabled.</source>
      <translation>View cache is disabled.</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Clear</translation>
    </message>
    <message>
      <source>Ini cache</source>
      <translation>Ini cache</translation>
    </message>
    <message>
      <source>Ini cache is always enabled.</source>
      <translation>Ini cache is always enabled.</translation>
    </message>
    <message>
      <source>Template cache</source>
      <translation>Template cache</translation>
    </message>
    <message>
      <source>Datatype wizard</source>
      <translation>Datatype wizard</translation>
    </message>
    <message>
      <source>Start</source>
      <comment>Datatype start</comment>
      <translation>Start</translation>
    </message>
    <message>
      <source>Basic information</source>
      <translation>Basic information</translation>
    </message>
    <message>
      <source>Name of datatype</source>
      <comment>Datatype</comment>
      <translation>Name of datatype</translation>
    </message>
    <message>
      <source>Descriptive name of datatype</source>
      <comment>Datatype</comment>
      <translation>Descriptive name of datatype</translation>
    </message>
    <message>
      <source>Settings</source>
      <comment>Datatype</comment>
      <translation>Settings</translation>
    </message>
    <message>
      <source>Handle input on class level</source>
      <comment>Datatype</comment>
      <translation>Handle input on class level</translation>
    </message>
    <message>
      <source>Next</source>
      <comment>Datatype next</comment>
      <translation>Next</translation>
    </message>
    <message>
      <source>Restart</source>
      <comment>Datatype restart</comment>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Optional information</source>
      <translation>Optional information</translation>
    </message>
    <message>
      <source>Name of class</source>
      <comment>Datatype</comment>
      <translation>Name of class</translation>
    </message>
    <message>
      <source>Constant name</source>
      <comment>Datatype</comment>
      <translation>Constant name</translation>
    </message>
    <message>
      <source>The creator of the datatype</source>
      <comment>Datatype</comment>
      <translation>The creator of the datatype</translation>
    </message>
    <message>
      <source>Description of your datatype</source>
      <comment>Datatype</comment>
      <translation>Description of your datatype</translation>
    </message>
    <message>
      <source>The first line will be used as the brief description and the rest are operator documentation.</source>
      <comment>Datatype</comment>
      <translation>The first line will be used as the brief description and the rest are operator documentation.</translation>
    </message>
    <message>
      <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
      <comment>Datatype default description</comment>
      <translation>Handles the datatype %datatypename
By using %datatypename you can ...</translation>
    </message>
    <message>
      <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
      <comment>Datatype</comment>
      <translation>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</translation>
    </message>
    <message>
      <source>Download</source>
      <comment>Datatype download</comment>
      <translation>Download</translation>
    </message>
    <message>
      <source>Extension setup</source>
      <translation>Extension setup</translation>
    </message>
    <message>
      <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access specific extensions, modify these configuration files.</source>
      <translation>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access specific extensions, modify these configuration files.</translation>
    </message>
    <message>
      <source>Available extensions</source>
      <translation>Available extensions</translation>
    </message>
    <message>
      <source>Activate extensions</source>
      <translation>Activate extensions</translation>
    </message>
    <message>
      <source>System information</source>
      <translation>System information</translation>
    </message>
    <message>
      <source>Site</source>
      <translation>Site</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>eZ publish version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>SVN revision</source>
      <comment>eZ publish version</comment>
      <translation>SVN revision</translation>
    </message>
    <message>
      <source>Extensions</source>
      <comment>eZ publish extensions</comment>
      <translation>Extensions</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>PHP version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Extensions</source>
      <comment>PHP extensions</comment>
      <translation>Extensions</translation>
    </message>
    <message>
      <source>Safe mode is on.</source>
      <translation>Safe mode is on.</translation>
    </message>
    <message>
      <source>Safe mode is off.</source>
      <translation>Safe mode is off.</translation>
    </message>
    <message>
      <source>Basedir restriction is on and set to %1.</source>
      <translation>Basedir restriction is on and set to %1.</translation>
    </message>
    <message>
      <source>Basedir restriction is off.</source>
      <translation>Basedir restriction is off.</translation>
    </message>
    <message>
      <source>Global variable registration is on.</source>
      <translation>Global variable registration is on.</translation>
    </message>
    <message>
      <source>Global variable registration is off.</source>
      <translation>Global variable registration is off.</translation>
    </message>
    <message>
      <source>File uploading is enabled.</source>
      <translation>File uploading is enabled.</translation>
    </message>
    <message>
      <source>File uploading is disabled.</source>
      <translation>File uploading is disabled.</translation>
    </message>
    <message>
      <source>Maximum size of post data (text and files) is %1.</source>
      <translation>Maximum size of post data (text and files) is %1.</translation>
    </message>
    <message>
      <source>Script memory limit is %1.</source>
      <translation>Script memory limit is %1.</translation>
    </message>
    <message>
      <source>Maximum execution time is %1 seconds.</source>
      <translation>Maximum execution time is %1 seconds.</translation>
    </message>
    <message>
      <source>Webserver</source>
      <comment>Webserver title</comment>
      <translation>Webserver</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>Webserver name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>Webserver version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Modules</source>
      <comment>Webserver modules</comment>
      <translation>Modules</translation>
    </message>
    <message>
      <source>Webserver modules could not be detected</source>
      <comment>Webserver modules</comment>
      <translation>Webserver modules could not be detected</translation>
    </message>
    <message>
      <source>No known information on the webserver</source>
      <translation>No known information on the webserver</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>PHP Accelerator name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Version</source>
      <comment>PHP Accelerator version</comment>
      <translation>Version</translation>
    </message>
    <message>
      <source>Could not detect version</source>
      <translation>Could not detect version</translation>
    </message>
    <message>
      <source>The PHP Accelerator is enabled.</source>
      <translation>The PHP Accelerator is enabled.</translation>
    </message>
    <message>
      <source>The PHP Accelerator is disabled.</source>
      <translation>The PHP Accelerator is disabled.</translation>
    </message>
    <message>
      <source>There is no known PHP accelerator active.</source>
      <translation>There is no known PHP accelerator active.</translation>
    </message>
    <message>
      <source>Database</source>
      <translation>Database</translation>
    </message>
    <message>
      <source>Type</source>
      <comment>Database type</comment>
      <translation>Type</translation>
    </message>
    <message>
      <source>Server</source>
      <comment>Database server</comment>
      <translation>Server</translation>
    </message>
    <message>
      <source>Socket path</source>
      <comment>Database socket path</comment>
      <translation>Socket path</translation>
    </message>
    <message>
      <source>Database</source>
      <comment>Database name</comment>
      <translation>Database</translation>
    </message>
    <message>
      <source>Connection retry count</source>
      <comment>Database retry count</comment>
      <translation>Connection retry count</translation>
    </message>
    <message>
      <source>Charset</source>
      <comment>Database charset</comment>
      <translation>Charset</translation>
    </message>
    <message>
      <source>Internal</source>
      <translation>Internal</translation>
    </message>
    <message>
      <source>Operating System</source>
      <translation>Operating System</translation>
    </message>
    <message>
      <source>CPU</source>
      <comment>Database type</comment>
      <translation>CPU</translation>
    </message>
    <message>
      <source>Memory</source>
      <comment>Database server</comment>
      <translation>Memory</translation>
    </message>
    <message>
      <source>No information on the operating system could be determined.</source>
      <translation>No information on the operating system could be determined.</translation>
    </message>
    <message>
      <source>Current read-only database (Slave)</source>
      <translation>Current read-only database (Slave)</translation>
    </message>
    <message>
      <source>Details for site</source>
      <translation>Details for site</translation>
    </message>
    <message>
      <source>&amp;percent% completed</source>
      <translation>&amp;percent% completed</translation>
    </message>
    <message>
      <source>Rapid Application Development Tools</source>
      <translation>Rapid Application Development Tools</translation>
    </message>
    <message>
      <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
      <translation>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</translation>
    </message>
    <message>
      <source>Tools</source>
      <comment>RAD Tools</comment>
      <translation>Tools</translation>
    </message>
    <message>
      <source>Template operator wizard</source>
      <translation>Template operator wizard</translation>
    </message>
    <message>
      <source>System</source>
      <translation>System</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Image system</source>
      <translation>Image system</translation>
    </message>
    <message>
      <source>Mail</source>
      <translation>Mail</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>System upgrade</source>
      <translation>System upgrade</translation>
    </message>
    <message>
      <source>File consistency check OK</source>
      <translation>File consistency check OK</translation>
    </message>
    <message>
      <source>Warning, it is not safe to upgrade without checking the modifications done to the following files </source>
      <translation>Warning, it is not safe to upgrade without checking the modifications done to the following files </translation>
    </message>
    <message>
      <source>Database check OK</source>
      <translation>Database check OK</translation>
    </message>
    <message>
      <source>Warning, your database is not consistent with the distribution database.</source>
      <translation>Warning, your database is not consistent with the distribution database.</translation>
    </message>
    <message>
      <source>To revert your database to distribution setup, run the following SQL queries</source>
      <translation>To revert your database to distribution setup, run the following SQL queries</translation>
    </message>
    <message>
      <source>Click a button to check file consistency.</source>
      <translation>Click a button to check file consistency.</translation>
    </message>
    <message>
      <source>Check files</source>
      <translation>Check files</translation>
    </message>
    <message>
      <source>warning, this might take a while</source>
      <translation>warning, this might take a while</translation>
    </message>
    <message>
      <source>Click a button to check database consistency.</source>
      <translation>Click a button to check database consistency.</translation>
    </message>
    <message>
      <source>Check database</source>
      <translation>Check database</translation>
    </message>
    <message>
      <source>Create new template override for</source>
      <translation>Create new template override for</translation>
    </message>
    <message>
      <source>Could not create template, permission denied.</source>
      <translation>Could not create template, permission denied.</translation>
    </message>
    <message>
      <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
      <translation>Invalid name. You can only use the characters a-z, numbers and _.</translation>
    </message>
    <message>
      <source>Template will be placed in</source>
      <translation>Template will be placed in</translation>
    </message>
    <message>
      <source>Template name</source>
      <translation>Template name</translation>
    </message>
    <message>
      <source>Override keys</source>
      <translation>Override keys</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Node</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>Base template on</source>
      <translation>Base template on</translation>
    </message>
    <message>
      <source>Empty file</source>
      <translation>Empty file</translation>
    </message>
    <message>
      <source>Copy of default template</source>
      <translation>Copy of default template</translation>
    </message>
    <message>
      <source>Container ( with children )</source>
      <translation>Container ( with children )</translation>
    </message>
    <message>
      <source>View ( without children )</source>
      <translation>View ( without children )</translation>
    </message>
    <message>
      <source>Object</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Create</translation>
    </message>
    <message>
      <source>Template edit</source>
      <translation>Template edit</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Save</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Template list</source>
      <translation>Template list</translation>
    </message>
    <message>
      <source>Most common templates</source>
      <translation>Most common templates</translation>
    </message>
    <message>
      <source>Template</source>
      <translation>Template</translation>
    </message>
    <message>
      <source>Design Resource</source>
      <translation>Design Resource</translation>
    </message>
    <message>
      <source>Complete template list</source>
      <translation>Complete template list</translation>
    </message>
    <message>
      <source>Start</source>
      <comment>Template operator start</comment>
      <translation>Start</translation>
    </message>
    <message>
      <source>Name of operator</source>
      <comment>Template operator</comment>
      <translation>Name of operator</translation>
    </message>
    <message>
      <source>Settings</source>
      <comment>Template operator</comment>
      <translation>Settings</translation>
    </message>
    <message>
      <source>One operator in class</source>
      <comment>Template operator</comment>
      <translation>One operator in class</translation>
    </message>
    <message>
      <source>Handles operator input</source>
      <comment>Template operator</comment>
      <translation>Handles operator input</translation>
    </message>
    <message>
      <source>Generates operator output</source>
      <comment>Template operator</comment>
      <translation>Generates operator output</translation>
    </message>
    <message>
      <source>Parameter handling</source>
      <comment>Template operator</comment>
      <translation>Parameter handling</translation>
    </message>
    <message>
      <source>Next</source>
      <comment>Template operator next</comment>
      <translation>Next</translation>
    </message>
    <message>
      <source>Restart</source>
      <comment>Template operator restart</comment>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Name of class</source>
      <comment>Template operator</comment>
      <translation>Name of class</translation>
    </message>
    <message>
      <source>The creator of the operator</source>
      <comment>Template operator</comment>
      <translation>The creator of the operator</translation>
    </message>
    <message>
      <source>Description of your operator</source>
      <comment>Template operator</comment>
      <translation>Description of your operator</translation>
    </message>
    <message>
      <source>The first line will be used as the brief description and the rest are operator documentation.</source>
      <comment>Template operator</comment>
      <translation>The first line will be used as the brief description and the rest are operator documentation.</translation>
    </message>
    <message>
      <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
      <comment>Template operator default description</comment>
      <translation>Handles template operator %operatorname
By using %operatorname you can ...</translation>
    </message>
    <message>
      <source>Example code</source>
      <comment>Template operator</comment>
      <translation>Example code</translation>
    </message>
    <message>
      <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
      <comment>Template operator</comment>
      <translation>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</translation>
    </message>
    <message>
      <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
      <comment>Template operator</comment>
      <translation>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</translation>
    </message>
    <message>
      <source>Download</source>
      <comment>Template operator download</comment>
      <translation>Download</translation>
    </message>
    <message>
      <source>Template view</source>
      <translation>Template view</translation>
    </message>
    <message>
      <source>Default template resource</source>
      <translation>Default template resource</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Override</source>
      <translation>Override</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Match conditions</source>
      <translation>Match conditions</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Create new</source>
      <translation>Create new</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Current siteaccess</source>
      <translation>Current siteaccess</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Available toolbars</source>
      <translation>Available toolbars</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Help</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/datatypecode</name>
    <message>
      <source>Constructor</source>
      <translation>Constructor</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/db</name>
    <message>
      <source>If you are having problems connecting to your database you should take a look at</source>
      <translation>If you are having problems connecting to your database you should take a look at</translation>
    </message>
    <message>
      <source>at</source>
      <translation>at</translation>
    </message>
    <message>
      <source>MySQL</source>
      <translation>MySQL</translation>
    </message>
    <message>
      <source>Introduction</source>
      <translation>Introduction</translation>
    </message>
    <message>
      <source>MySQL is a database management system created by MySQL AB.</source>
      <translation>MySQL is a database management system created by MySQL AB.</translation>
    </message>
    <message>
      <source>It's currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
      <translation>It's currently one of the most popular databases in the Open Source community and most often on by default in PHP.</translation>
    </message>
    <message>
      <source>From their homepage</source>
      <translation>From their homepage</translation>
    </message>
    <message>
      <source>MySQL is the world's most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
      <translation>MySQL is the world's most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</translation>
    </message>
    <message>
      <source>More information can be found on</source>
      <translation>More information can be found on</translation>
    </message>
    <message>
      <source>Details</source>
      <translation>Details</translation>
    </message>
    <message>
      <source>MySQL is a good choice for handling most western languages, and as of version 4.1 it also supports Unicode.</source>
      <translation>MySQL is a good choice for handling most western languages, and as of version 4.1 it also supports Unicode.</translation>
    </message>
    <message>
      <source>Installation</source>
      <translation>Installation</translation>
    </message>
    <message>
      <source>By using the</source>
      <translation>By using the</translation>
    </message>
    <message>
      <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
      <translation>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</translation>
    </message>
    <message>
      <source>More information on the MySQL extension can be found at</source>
      <translation>More information on the MySQL extension can be found at</translation>
    </message>
    <message>
      <source>PostgreSQL</source>
      <translation>PostgreSQL</translation>
    </message>
    <message>
      <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
      <translation>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</translation>
    </message>
    <message>
      <source>It's a very popular database in the Open Source community and provides highly advanced database functionality.</source>
      <translation>It's a very popular database in the Open Source community and provides highly advanced database functionality.</translation>
    </message>
    <message>
      <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
      <translation>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</translation>
    </message>
    <message>
      <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
      <translation>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</translation>
    </message>
    <message>
      <source>In order to enable PostgreSQL support,</source>
      <translation>In order to enable PostgreSQL support,</translation>
    </message>
    <message>
      <source>is required when you compile PHP.</source>
      <translation>is required when you compile PHP.</translation>
    </message>
    <message>
      <source>More information on the PostgreSQL extension can be found at</source>
      <translation>More information on the PostgreSQL extension can be found at</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/init</name>
    <message>
      <source>Creating sites</source>
      <translation>Creating sites</translation>
    </message>
    <message>
      <source>Database choice</source>
      <translation>Database choice</translation>
    </message>
    <message>
      <source>Database initalization</source>
      <translation>Database initalization</translation>
    </message>
    <message>
      <source>Email settings</source>
      <translation>Email settings</translation>
    </message>
    <message>
      <source>Finished</source>
      <translation>Finished</translation>
    </message>
    <message>
      <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the PHP documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that PostgreSQL 7.2 is not supported.</source>
      <translation>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the PHP documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that PostgreSQL 7.2 is not supported.</translation>
    </message>
    <message>
      <source>The database would not accept the connection, please review your settings and try again.</source>
      <translation>The database would not accept the connection, please review your settings and try again.</translation>
    </message>
    <message>
      <source>Password entries did not match.</source>
      <translation>Password entries did not match.</translation>
    </message>
    <message>
      <source>The selected database was not empty, please choose from the alternatives below.</source>
      <translation>The selected database was not empty, please choose from the alternatives below.</translation>
    </message>
    <message>
      <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
      <translation>The selected selected user has not got access to any databases. Change user or create a database for the user.</translation>
    </message>
    <message>
      <source>The 'digest' procedure is not available in your database, you cannot run eZ publish without this. Visit the FAQ for more information.</source>
      <translation>The 'digest' procedure is not available in your database, you cannot run eZ publish without this. Visit the FAQ for more information.</translation>
    </message>
    <message>
      <source>Your database version %version does not fit the minimum requirement which is %req_version.</source>
      <translation>Your database version %version does not fit the minimum requirement which is %req_version.</translation>
    </message>
    <message>
      <source>The database [%database_name] cannot be used, the setup wizard wants to create the site in [%req_charset] but the database has been created using character set [%charset]. You will have to choose a database having support for [%req_charset] or modify [%database_name] .</source>
      <translation>The database [%database_name] cannot be used, the setup wizard wants to create the site in [%req_charset] but the database has been created using character set [%charset]. You will have to choose a database having support for [%req_charset] or modify [%database_name] .</translation>
    </message>
    <message>
      <source>Language options</source>
      <translation>Language options</translation>
    </message>
    <message>
      <source>Registration</source>
      <translation>Registration</translation>
    </message>
    <message>
      <source>Securing site</source>
      <translation>Securing site</translation>
    </message>
    <message>
      <source>Site access</source>
      <translation>Site access</translation>
    </message>
    <message>
      <source>Site administrator</source>
      <translation>Site administrator</translation>
    </message>
    <message>
      <source>Site details</source>
      <translation>Site details</translation>
    </message>
    <message>
      <source>No packages choosen.</source>
      <translation>No packages choosen.</translation>
    </message>
    <message>
      <source>Site functionality</source>
      <translation>Site functionality</translation>
    </message>
    <message>
      <source>No templates choosen.</source>
      <translation>No templates choosen.</translation>
    </message>
    <message>
      <source>Site template selection</source>
      <translation>Site template selection</translation>
    </message>
    <message>
      <source>Cannot write to file</source>
      <translation>Cannot write to file</translation>
    </message>
    <message>
      <source>Failed to copy %url to local file %filename</source>
      <translation>Failed to copy %url to local file %filename</translation>
    </message>
    <message>
      <source>Download of package '%pkg' failed. You may upload the package manually.</source>
      <translation>Download of package '%pkg' failed. You may upload the package manually.</translation>
    </message>
    <message>
      <source>Invalid package</source>
      <translation>Invalid package</translation>
    </message>
    <message>
      <source>No package selected for upload</source>
      <translation>No package selected for upload</translation>
    </message>
    <message>
      <source>Failed fetching upload package file</source>
      <translation>Failed fetching upload package file</translation>
    </message>
    <message>
      <source>Uploaded file is not an eZ publish package</source>
      <translation>Uploaded file is not an eZ publish package</translation>
    </message>
    <message>
      <source>No site package choosen.</source>
      <translation>No site package choosen.</translation>
    </message>
    <message>
      <source>Package '%packageName' and it's dependencies have been downloaded successfully. Press 'Next' to continue.</source>
      <translation>Package '%packageName' and it's dependencies have been downloaded successfully. Press 'Next' to continue.</translation>
    </message>
    <message>
      <source>Site selection</source>
      <translation>Site selection</translation>
    </message>
    <message>
      <source>Retreiving remote site packages list failed. You may upload packages manually.</source>
      <translation>Retreiving remote site packages list failed. You may upload packages manually.</translation>
    </message>
    <message>
      <source>System check</source>
      <translation>System check</translation>
    </message>
    <message>
      <source>System finetuning</source>
      <translation>System finetuning</translation>
    </message>
    <message>
      <source>Welcome to eZ publish</source>
      <translation>Welcome to eZ publish</translation>
    </message>
    <message>
      <source>The setup wizard was not able to complete the creation of your selected sites.</source>
      <translation>The setup wizard was not able to complete the creation of your selected sites.</translation>
    </message>
    <message>
      <source>The following errors were detected</source>
      <translation>The following errors were detected</translation>
    </message>
    <message>
      <source>If you think you have fixed the errors you can try and click the &quot;Retry&quot; button.</source>
      <translation>If you think you have fixed the errors you can try and click the &quot;Retry&quot; button.</translation>
    </message>
    <message>
      <source>The setup wizard failed to create the sites.</source>
      <translation>The setup wizard failed to create the sites.</translation>
    </message>
    <message>
      <source>If possible try to fix these errors and click &quot;Retry&quot;.</source>
      <translation>If possible try to fix these errors and click &quot;Retry&quot;.</translation>
    </message>
    <message>
      <source>The database is ready for initialization, click the %1 button when ready.</source>
      <translation>The database is ready for initialization, click the %1 button when ready.</translation>
    </message>
    <message>
      <source>Continue</source>
      <translation>Continue</translation>
    </message>
    <message>
      <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilities of eZ publish</source>
      <translation>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilities of eZ publish</translation>
    </message>
    <message>
      <source>First time users are advised to install the demo data.</source>
      <translation>First time users are advised to install the demo data.</translation>
    </message>
    <message>
      <source>Install demo data?</source>
      <translation>Install demo data?</translation>
    </message>
    <message>
      <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
      <translation>Cannot install demo data, the zlib extension is missing from your PHP installation.</translation>
    </message>
    <message>
      <source>does not support installing demo data at this point.</source>
      <translation>does not support installing demo data at this point.</translation>
    </message>
    <message>
      <source>Demo data failure</source>
      <translation>Demo data failure</translation>
    </message>
    <message>
      <source>Could not unpack the demo data.</source>
      <translation>Could not unpack the demo data.</translation>
    </message>
    <message>
      <source>You should try to install without demo data.</source>
      <translation>You should try to install without demo data.</translation>
    </message>
    <message>
      <source>Initialization failed</source>
      <translation>Initialization failed</translation>
    </message>
    <message>
      <source>The database could not be properly initialized.</source>
      <translation>The database could not be properly initialized.</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Warning</translation>
    </message>
    <message>
      <source>Your database already contains data.</source>
      <translation>Your database already contains data.</translation>
    </message>
    <message>
      <source>The setup can continue with the initialization but may damage the present data.</source>
      <translation>The setup can continue with the initialization but may damage the present data.</translation>
    </message>
    <message>
      <source>What do you want the setup to do?</source>
      <translation>What do you want the setup to do?</translation>
    </message>
    <message>
      <source>Note</source>
      <translation>Note</translation>
    </message>
    <message>
      <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don't want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
      <translation>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don't want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</translation>
    </message>
    <message>
      <source>Continue but leave the data as it is.</source>
      <translation>Continue but leave the data as it is.</translation>
    </message>
    <message>
      <source>Continue but remove the data first.</source>
      <translation>Continue but remove the data first.</translation>
    </message>
    <message>
      <source>Keep data and skip database initialization.</source>
      <translation>Keep data and skip database initialization.</translation>
    </message>
    <message>
      <source>Let me choose a new database.</source>
      <translation>Let me choose a new database.</translation>
    </message>
    <message>
      <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
      <translation>It can take some time initializing the database so please be patient and wait until the new page is finished.</translation>
    </message>
    <message>
      <source>Choose database system</source>
      <translation>Choose database system</translation>
    </message>
    <message>
      <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
      <translation>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</translation>
    </message>
    <message>
      <source>eZ publish supports both MySQL and PostgreSQL.</source>
      <translation>eZ publish supports both MySQL and PostgreSQL.</translation>
    </message>
    <message>
      <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
      <translation>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</translation>
    </message>
    <message>
      <source>More information about eZ publish and unicode support can be found %1.</source>
      <translation>More information about eZ publish and unicode support can be found %1.</translation>
    </message>
    <message>
      <source>here</source>
      <comment>link to unicode info</comment>
      <translation>here</translation>
    </message>
    <message>
      <source>The database was sucessfully initialized. You are now ready for some post configuration of the site.</source>
      <translation>The database was sucessfully initialized. You are now ready for some post configuration of the site.</translation>
    </message>
    <message>
      <source>Click the %1 button to start the configuration process.</source>
      <translation>Click the %1 button to start the configuration process.</translation>
    </message>
    <message>
      <source>Configure</source>
      <translation>Configure</translation>
    </message>
    <message>
      <source>Database initialization</source>
      <translation>Database initialization</translation>
    </message>
    <message>
      <source>Please input database access information in the form below.</source>
      <translation>Please input database access information in the form below.</translation>
    </message>
    <message>
      <source>Database</source>
      <translation>Database</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Servername</source>
      <translation>Servername</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Socket (optional)</source>
      <translation>Socket (optional)</translation>
    </message>
    <message>
      <source>If you don't have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you're unsure about how to create a database.</source>
      <translation>If you don't have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you're unsure about how to create a database.</translation>
    </message>
    <message>
      <source>PostgreSQL username and password is not tested until database names are selected.</source>
      <translation>PostgreSQL username and password is not tested until database names are selected.</translation>
    </message>
    <message>
      <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
      <translation>If you are using MySQL and do not know what to enter in the socket field, leave it blank</translation>
    </message>
    <message>
      <source>Language Options</source>
      <translation>Language Options</translation>
    </message>
    <message>
      <source>No finetuning is required on your system, you can continue by clicking the</source>
      <translation>No finetuning is required on your system, you can continue by clicking the</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
    <message>
      <source>button.</source>
      <translation>button.</translation>
    </message>
    <message>
      <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
      <translation>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</translation>
    </message>
    <message>
      <source>After you have fixed the problems click the</source>
      <translation>After you have fixed the problems click the</translation>
    </message>
    <message>
      <source>Rerun System Check</source>
      <translation>Rerun System Check</translation>
    </message>
    <message>
      <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
      <translation>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</translation>
    </message>
    <message>
      <source>Check Again</source>
      <translation>Check Again</translation>
    </message>
    <message>
      <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
      <translation>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</translation>
    </message>
    <message>
      <source>Issues</source>
      <translation>Issues</translation>
    </message>
    <message>
      <source>Failed writing</source>
      <translation>Failed writing</translation>
    </message>
    <message>
      <source>The setup could not write to the file.</source>
      <translation>The setup could not write to the file.</translation>
    </message>
    <message>
      <source>The setup could not get write access to the</source>
      <translation>The setup could not get write access to the</translation>
    </message>
    <message>
      <source>directory. This is required to disable the initialization. Following the instructions found in</source>
      <translation>directory. This is required to disable the initialization. Following the instructions found in</translation>
    </message>
    <message>
      <source>to enable write access and click the</source>
      <translation>to enable write access and click the</translation>
    </message>
    <message>
      <source>Try Again</source>
      <translation>Try Again</translation>
    </message>
    <message>
      <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says</source>
      <translation>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says</translation>
    </message>
    <message>
      <source>Change the second line from</source>
      <translation>Change the second line from</translation>
    </message>
    <message>
      <source>to</source>
      <translation>to</translation>
    </message>
    <message>
      <source>The setup is now disabled, click</source>
      <translation>The setup is now disabled, click</translation>
    </message>
    <message>
      <source>to get back to the site.</source>
      <translation>to get back to the site.</translation>
    </message>
    <message>
      <source>Outgoing E-mail</source>
      <translation>Outgoing E-mail</translation>
    </message>
    <message>
      <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
      <translation>This section is used to configure how eZ publish delivers its outgoing E-mail.</translation>
    </message>
    <message>
      <source>There are two options:&lt;br&gt;- Direct delivery through transfer agent (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
      <translation>There are two options:&lt;br&gt;- Direct delivery through transfer agent (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</translation>
    </message>
    <message>
      <source>You can choose from either</source>
      <translation>You can choose from either</translation>
    </message>
    <message>
      <source>sendmail</source>
      <translation>sendmail</translation>
    </message>
    <message>
      <source>which must be available on the server or</source>
      <translation>which must be available on the server or</translation>
    </message>
    <message>
      <source>SMTP</source>
      <translation>SMTP</translation>
    </message>
    <message>
      <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
      <translation>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</translation>
    </message>
    <message>
      <source>SMTP is recommended for MS Windows users.</source>
      <translation>SMTP is recommended for MS Windows users.</translation>
    </message>
    <message>
      <source>E-mail delivery</source>
      <translation>E-mail delivery</translation>
    </message>
    <message>
      <source>Sendmail/MTA</source>
      <translation>Sendmail/MTA</translation>
    </message>
    <message>
      <source>Server name: </source>
      <translation>Server name: </translation>
    </message>
    <message>
      <source>Username (optional): </source>
      <translation>Username (optional): </translation>
    </message>
    <message>
      <source>Password (optional): </source>
      <translation>Password (optional): </translation>
    </message>
    <message>
      <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
      <translation>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</translation>
    </message>
    <message>
      <source>&lt;b&gt;Sendmail/MTA:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the mail transfer agent. The most common agent, sendmail, is usually available on most Linux/UNIX systems. If a mail transfer agent is not available then SMTP should be used.</source>
      <translation>&lt;b&gt;Sendmail/MTA:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the mail transfer agent. The most common agent, sendmail, is usually available on most Linux/UNIX systems. If a mail transfer agent is not available then SMTP should be used.</translation>
    </message>
    <message>
      <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
      <translation>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</translation>
    </message>
    <message>
      <source>Email is used for sending out important notices such as user registration and content approval.</source>
      <translation>Email is used for sending out important notices such as user registration and content approval.</translation>
    </message>
    <message>
      <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
      <translation>Most Unix systems support sendmail, while windows users must choose SMTP.</translation>
    </message>
    <message>
      <source>&lt;b&gt;SMTP&lt;/b&gt;: If you're unsure what to enter, take a look at the settings in your e-mail application.</source>
      <translation>&lt;b&gt;SMTP&lt;/b&gt;: If you're unsure what to enter, take a look at the settings in your e-mail application.</translation>
    </message>
    <message>
      <source>eZ publish has been installed with your select site setup. You will find the username mentioned in the details below.</source>
      <translation>eZ publish has been installed with your select site setup. You will find the username mentioned in the details below.</translation>
    </message>
    <message>
      <source>The first time the user or admin site is accessed it will take some time (30 to 60 seconds). This is because eZ publish prepares the site for your machine.</source>
      <translation>The first time the user or admin site is accessed it will take some time (30 to 60 seconds). This is because eZ publish prepares the site for your machine.</translation>
    </message>
    <message>
      <source>Title</source>
      <translation>Title</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>User site</source>
      <translation>User site</translation>
    </message>
    <message>
      <source>Admin site</source>
      <translation>Admin site</translation>
    </message>
    <message>
      <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
      <translation>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</translation>
    </message>
    <message>
      <source>Make sure to visit the %1 and the %2 web site.</source>
      <translation>Make sure to visit the %1 and the %2 web site.</translation>
    </message>
    <message>
      <source>forums</source>
      <comment>forum link</comment>
      <translation>forums</translation>
    </message>
    <message>
      <source>eZ publish</source>
      <comment>eZ publish 3 link</comment>
      <translation>eZ publish</translation>
    </message>
    <message>
      <source>Sending e-mail failed</source>
      <translation>Sending e-mail failed</translation>
    </message>
    <message>
      <source>Failed to send the registration email using</source>
      <translation>Failed to send the registration email using</translation>
    </message>
    <message>
      <source>Congratulations, eZ publish should now run on your system.</source>
      <translation>Congratulations, eZ publish should now run on your system.</translation>
    </message>
    <message>
      <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
      <translation>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</translation>
    </message>
    <message>
      <source>eZ publish bug reports</source>
      <translation>eZ publish bug reports</translation>
    </message>
    <message>
      <source>ez.no</source>
      <translation>ez.no</translation>
    </message>
    <message>
      <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
      <translation>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</translation>
    </message>
    <message>
      <source>eZ publish website</source>
      <translation>eZ publish website</translation>
    </message>
    <message>
      <source>Done</source>
      <translation>Done</translation>
    </message>
    <message>
      <source>If you ever want to restart this setup, edit the file %filename and look for a line that says</source>
      <translation>If you ever want to restart this setup, edit the file %filename and look for a line that says</translation>
    </message>
    <message>
      <source>Change the second line from %false to %true.</source>
      <translation>Change the second line from %false to %true.</translation>
    </message>
    <message>
      <source>The default username for the administrator is %1 and the default password is %2.</source>
      <translation>The default username for the administrator is %1 and the default password is %2.</translation>
    </message>
    <message>
      <source>Language support</source>
      <translation>Language support</translation>
    </message>
    <message>
      <source>Use the radio buttons to choose the default language, and the checkboxes to choose additional languages. You will be able to use any of the selected languages for translating your content. The default language will determine the locale settings and will be used as the most prioritized language for your site.</source>
      <translation>Use the radio buttons to choose the default language, and the checkboxes to choose additional languages. You will be able to use any of the selected languages for translating your content. The default language will determine the locale settings and will be used as the most prioritized language for your site.</translation>
    </message>
    <message>
      <source>No Unicode support</source>
      <translation>No Unicode support</translation>
    </message>
    <message>
      <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
      <translation>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</translation>
    </message>
    <message>
      <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won't work.</source>
      <translation>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won't work.</translation>
    </message>
    <message>
      <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
      <translation>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</translation>
    </message>
    <message>
      <source>Default/Additional</source>
      <translation>Default/Additional</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Settings</translation>
    </message>
    <message>
      <source>When selected the wizard sets up the site using Unicode.</source>
      <translation>When selected the wizard sets up the site using Unicode.</translation>
    </message>
    <message>
      <source>Enable Unicode setup</source>
      <translation>Enable Unicode setup</translation>
    </message>
    <message>
      <source>This is disabled since the chosen database cannot use Unicode characters.</source>
      <translation>This is disabled since the chosen database cannot use Unicode characters.</translation>
    </message>
    <message>
      <source>eZ publish supports multiple languages.</source>
      <translation>eZ publish supports multiple languages.</translation>
    </message>
    <message>
      <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
      <translation>The selected languages are used to determine character sets, date / number formats, etc.</translation>
    </message>
    <message>
      <source>These and other additional languages can also be installed later.</source>
      <translation>These and other additional languages can also be installed later.</translation>
    </message>
    <message>
      <source>For more information about language customization, please refer to the %1.</source>
      <translation>For more information about language customization, please refer to the %1.</translation>
    </message>
    <message>
      <source>documentation</source>
      <comment>language information link</comment>
      <translation>documentation</translation>
    </message>
    <message>
      <source>Back</source>
      <comment>back button in installation</comment>
      <translation>Back</translation>
    </message>
    <message>
      <source>Refresh</source>
      <comment>Refresh button in installation</comment>
      <translation>Refresh</translation>
    </message>
    <message>
      <source>Retry</source>
      <comment>Retry button in installation</comment>
      <translation>Retry</translation>
    </message>
    <message>
      <source>Finetune</source>
      <comment>Finetune button in installation</comment>
      <translation>Finetune</translation>
    </message>
    <message>
      <source>Next</source>
      <comment>next button in installation</comment>
      <translation>Next</translation>
    </message>
    <message>
      <source>It's time to select the language this site should support.</source>
      <translation>It's time to select the language this site should support.</translation>
    </message>
    <message>
      <source>Select your language and click the</source>
      <translation>Select your language and click the</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>button, or the</source>
      <translation>button, or the</translation>
    </message>
    <message>
      <source>Language Details</source>
      <translation>Language Details</translation>
    </message>
    <message>
      <source>button to select language variations.</source>
      <translation>button to select language variations.</translation>
    </message>
    <message>
      <source>It's time to select the languages this site should support. Select your primary language and check any additional languages.</source>
      <translation>It's time to select the languages this site should support. Select your primary language and check any additional languages.</translation>
    </message>
    <message>
      <source>Once you're done click the</source>
      <translation>Once you're done click the</translation>
    </message>
    <message>
      <source>The languages you choose will help determine the charset to use on the site.</source>
      <translation>The languages you choose will help determine the charset to use on the site.</translation>
    </message>
    <message>
      <source>Language name</source>
      <translation>Language name</translation>
    </message>
    <message>
      <source>Selection</source>
      <translation>Selection</translation>
    </message>
    <message>
      <source>It's now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your're done click the</source>
      <translation>It's now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your're done click the</translation>
    </message>
    <message>
      <source>It's now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
      <translation>It's now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</translation>
    </message>
    <message>
      <source>Default</source>
      <translation>Default</translation>
    </message>
    <message>
      <source>Site registration</source>
      <translation>Site registration</translation>
    </message>
    <message>
      <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited e-mails.</source>
      <translation>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited e-mails.</translation>
    </message>
    <message>
      <source>The registration e-mail</source>
      <translation>The registration e-mail</translation>
    </message>
    <message>
      <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
      <translation>If you wish, you can also add some comments, which will be included in the registration E-mail.</translation>
    </message>
    <message>
      <source>Comments</source>
      <translation>Comments</translation>
    </message>
    <message>
      <source>Sending out the e-mail and generating your site will take about 10 to 30 seconds depending on your machine. Please wait until the next page loads. Clicking the button again will only send out duplicate e-mails, and may corrupt the installation.</source>
      <translation>Sending out the e-mail and generating your site will take about 10 to 30 seconds depending on your machine. Please wait until the next page loads. Clicking the button again will only send out duplicate e-mails, and may corrupt the installation.</translation>
    </message>
    <message>
      <source>Send registration</source>
      <translation>Send registration</translation>
    </message>
    <message>
      <source>Skip Registration</source>
      <translation>Skip Registration</translation>
    </message>
    <message>
      <source>Send Registration</source>
      <translation>Send Registration</translation>
    </message>
    <message>
      <source>By sending registration the following data will be sent to eZ systems</source>
      <translation>By sending registration the following data will be sent to eZ systems</translation>
    </message>
    <message>
      <source>System details (OS type, etc)</source>
      <translation>System details (OS type, etc)</translation>
    </message>
    <message>
      <source>The test results</source>
      <translation>The test results</translation>
    </message>
    <message>
      <source>The database type</source>
      <translation>The database type</translation>
    </message>
    <message>
      <source>The site name</source>
      <translation>The site name</translation>
    </message>
    <message>
      <source>The url of the site</source>
      <translation>The url of the site</translation>
    </message>
    <message>
      <source>Languages chosen</source>
      <translation>Languages chosen</translation>
    </message>
    <message>
      <source>This data will help to improve future releases of eZ publish.</source>
      <translation>This data will help to improve future releases of eZ publish.</translation>
    </message>
    <message>
      <source>Site security</source>
      <translation>Site security</translation>
    </message>
    <message>
      <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
      <translation>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</translation>
    </message>
    <message>
      <source>If you have shell access, you can run the following commmands.</source>
      <translation>If you have shell access, you can run the following commmands.</translation>
    </message>
    <message>
      <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
      <translation>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</translation>
    </message>
    <message>
      <source>This security tweak takes care of protecting configuration files and other important files.</source>
      <translation>This security tweak takes care of protecting configuration files and other important files.</translation>
    </message>
    <message>
      <source>Site access configuration</source>
      <translation>Site access configuration</translation>
    </message>
    <message>
      <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
      <translation>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</translation>
    </message>
    <message>
      <source>Access method</source>
      <translation>Access method</translation>
    </message>
    <message>
      <source>URL (recommended)</source>
      <translation>URL (recommended)</translation>
    </message>
    <message>
      <source>Port. Note: Requires web server configuration </source>
      <translation>Port. Note: Requires web server configuration </translation>
    </message>
    <message>
      <source>Port</source>
      <translation>Port</translation>
    </message>
    <message>
      <source>Hostname. Note: Requires DNS setup.</source>
      <translation>Hostname. Note: Requires DNS setup.</translation>
    </message>
    <message>
      <source>Hostname</source>
      <translation>Hostname</translation>
    </message>
    <message>
      <source>The path determines access.</source>
      <translation>The path determines access.</translation>
    </message>
    <message>
      <source>e.g. %adminsite and %usersite</source>
      <translation>e.g. %adminsite and %usersite</translation>
    </message>
    <message>
      <source>Port*</source>
      <translation>Port*</translation>
    </message>
    <message>
      <source>The port number determines access.*</source>
      <translation>The port number determines access.*</translation>
    </message>
    <message>
      <source>* Requires web server setup.</source>
      <translation>* Requires web server setup.</translation>
    </message>
    <message>
      <source>Hostname*</source>
      <translation>Hostname*</translation>
    </message>
    <message>
      <source>The hostname determines access.*</source>
      <translation>The hostname determines access.*</translation>
    </message>
    <message>
      <source>* Requires DNS setup.</source>
      <translation>* Requires DNS setup.</translation>
    </message>
    <message>
      <source>For more detailed information on site access, please refer to the %1</source>
      <translation>For more detailed information on site access, please refer to the %1</translation>
    </message>
    <message>
      <source>online documentation</source>
      <comment>site access documentation link</comment>
      <translation>online documentation</translation>
    </message>
    <message>
      <source>This page lets you modify the administrator for your site. This ensures that your site is secure and has proper name and E-mail set.</source>
      <translation>This page lets you modify the administrator for your site. This ensures that your site is secure and has proper name and E-mail set.</translation>
    </message>
    <message>
      <source>You need to fill in the first name.</source>
      <translation>You need to fill in the first name.</translation>
    </message>
    <message>
      <source>You need to fill in the last name.</source>
      <translation>You need to fill in the last name.</translation>
    </message>
    <message>
      <source>You need to fill in an e-mail address.</source>
      <translation>You need to fill in an e-mail address.</translation>
    </message>
    <message>
      <source>You need to fill in a valid e-mail address.</source>
      <translation>You need to fill in a valid e-mail address.</translation>
    </message>
    <message>
      <source>Your passwords do not match.</source>
      <translation>Your passwords do not match.</translation>
    </message>
    <message>
      <source>You need to fill in a password.</source>
      <translation>You need to fill in a password.</translation>
    </message>
    <message>
      <source>The password is too short.</source>
      <translation>The password is too short.</translation>
    </message>
    <message>
      <source>Administrator settings</source>
      <translation>Administrator settings</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>First name</source>
      <translation>First name</translation>
    </message>
    <message>
      <source>Last name</source>
      <translation>Last name</translation>
    </message>
    <message>
      <source>E-mail address</source>
      <translation>E-mail address</translation>
    </message>
    <message>
      <source>Confirm password</source>
      <translation>Confirm password</translation>
    </message>
    <message>
      <source>The login name is fixed and cannot be changed.
After the setup is done you can login with %admin_login and your password.</source>
      <translation>The login name is fixed and cannot be changed.
After the setup is done you can login with %admin_login and your password.</translation>
    </message>
    <message>
      <source>This page lets you modify information about the site you've chosen to install. In addition, it also lets you choose a database for the site.</source>
      <translation>This page lets you modify information about the site you've chosen to install. In addition, it also lets you choose a database for the site.</translation>
    </message>
    <message>
      <source>'User path' and 'Admin path' should only contain letters ('a-zA-Z'), digits ('0-9') and underscores ('_'). The access values must not be named 'admin' or 'user' and each value must be unique. Please change invalid values on site indicated by *</source>
      <translation>'User path' and 'Admin path' should only contain letters ('a-zA-Z'), digits ('0-9') and underscores ('_'). The access values must not be named 'admin' or 'user' and each value must be unique. Please change invalid values on site indicated by *</translation>
    </message>
    <message>
      <source>'User port' and 'Admin port' should only contain digits ('0-9'). Please change invalid values on site indicated by *</source>
      <translation>'User port' and 'Admin port' should only contain digits ('0-9'). Please change invalid values on site indicated by *</translation>
    </message>
    <message>
      <source>'User hostname' and 'Admin hostname' should only contain letters ('a-zA-Z'), digits ('0-9'), dashes ('-'), dots ('.') and colons (':'). Please change invalid values on site indicated by *</source>
      <translation>'User hostname' and 'Admin hostname' should only contain letters ('a-zA-Z'), digits ('0-9'), dashes ('-'), dots ('.') and colons (':'). Please change invalid values on site indicated by *</translation>
    </message>
    <message>
      <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
      <translation>You have chosen the same database for two or more site templates. Please change where indicated by *</translation>
    </message>
    <message>
      <source>Your database already contain data.
The setup can continue with the initialization but may damage the present data.</source>
      <translation>Your database already contain data.
The setup can continue with the initialization but may damage the present data.</translation>
    </message>
    <message>
      <source>Select what to do from the drop-down box.</source>
      <translation>Select what to do from the drop-down box.</translation>
    </message>
    <message>
      <source>Site url</source>
      <translation>Site url</translation>
    </message>
    <message>
      <source>User path</source>
      <translation>User path</translation>
    </message>
    <message>
      <source>User port</source>
      <translation>User port</translation>
    </message>
    <message>
      <source>User hostname</source>
      <translation>User hostname</translation>
    </message>
    <message>
      <source>Admin path</source>
      <translation>Admin path</translation>
    </message>
    <message>
      <source>Admin port</source>
      <translation>Admin port</translation>
    </message>
    <message>
      <source>Admin hostname</source>
      <translation>Admin hostname</translation>
    </message>
    <message>
      <source>Action: </source>
      <translation>Action: </translation>
    </message>
    <message>
      <source>Leave the data and add new</source>
      <translation>Leave the data and add new</translation>
    </message>
    <message>
      <source>Remove existing data</source>
      <translation>Remove existing data</translation>
    </message>
    <message>
      <source>Leave the data and do nothing</source>
      <translation>Leave the data and do nothing</translation>
    </message>
    <message>
      <source>I've chosen a new database</source>
      <translation>I've chosen a new database</translation>
    </message>
    <message>
      <source>You may modify the details for each site.</source>
      <translation>You may modify the details for each site.</translation>
    </message>
    <message>
      <source>For more information about how to configure site access, please refer to the %1</source>
      <translation>For more information about how to configure site access, please refer to the %1</translation>
    </message>
    <message>
      <source>documentation</source>
      <comment>site access documentation link</comment>
      <translation>documentation</translation>
    </message>
    <message>
      <source>Use the refresh button to update the database listing.</source>
      <translation>Use the refresh button to update the database listing.</translation>
    </message>
    <message>
      <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
      <translation>What kind of language support should this site have. The type of support determines the language selection and charset.</translation>
    </message>
    <message>
      <source>Monolingual (one language)</source>
      <translation>Monolingual (one language)</translation>
    </message>
    <message>
      <source>Multilingual (multiple languages with one charset)</source>
      <translation>Multilingual (multiple languages with one charset)</translation>
    </message>
    <message>
      <source>Multilingual (Unicode, no limit)</source>
      <translation>Multilingual (Unicode, no limit)</translation>
    </message>
    <message>
      <source>Regional Options</source>
      <translation>Regional Options</translation>
    </message>
    <message>
      <source>Current site functionality</source>
      <translation>Current site functionality</translation>
    </message>
    <message>
      <source>Please select additional functionality</source>
      <translation>Please select additional functionality</translation>
    </message>
    <message>
      <source>Each site comes with a predefined set of functionality, however it is possible to add extra functionality.
This functionality is also available at a later time from the administration interface.</source>
      <translation>Each site comes with a predefined set of functionality, however it is possible to add extra functionality.
This functionality is also available at a later time from the administration interface.</translation>
    </message>
    <message>
      <source>Site packages</source>
      <translation>Site packages</translation>
    </message>
    <message>
      <source>Select which sites you would like to install on your system.</source>
      <translation>Select which sites you would like to install on your system.</translation>
    </message>
    <message>
      <source>Each package will create a unique web site.</source>
      <translation>Each package will create a unique web site.</translation>
    </message>
    <message>
      <source>Since each web site is unique, each package requires a unique database.</source>
      <translation>Since each web site is unique, each package requires a unique database.</translation>
    </message>
    <message>
      <source>Site package</source>
      <translation>Site package</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Imported</source>
      <translation>Imported</translation>
    </message>
    <message>
      <source>Not imported</source>
      <translation>Not imported</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>No dependencies</source>
      <translation>No dependencies</translation>
    </message>
    <message>
      <source>Upload package</source>
      <translation>Upload package</translation>
    </message>
    <message>
      <source>Upload</source>
      <translation>Upload</translation>
    </message>
    <message>
      <source>The type of site will choose some basic settings for toolbars, menus, color and functionality.
It is possible to change these settings at a later time.</source>
      <translation>The type of site will choose some basic settings for toolbars, menus, color and functionality.
It is possible to change these settings at a later time.</translation>
    </message>
    <message>
      <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
      <translation>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</translation>
    </message>
    <message>
      <source>Setup Database</source>
      <translation>Setup Database</translation>
    </message>
    <message>
      <source>However if you want to change your settings click the</source>
      <translation>However if you want to change your settings click the</translation>
    </message>
    <message>
      <source>Start Over</source>
      <translation>Start Over</translation>
    </message>
    <message>
      <source>button which will restart the collecting of information (Existing settings are kept).</source>
      <translation>button which will restart the collecting of information (Existing settings are kept).</translation>
    </message>
    <message>
      <source>Database settings</source>
      <translation>Database settings</translation>
    </message>
    <message>
      <source>Driver</source>
      <translation>Driver</translation>
    </message>
    <message>
      <source>Unicode support</source>
      <translation>Unicode support</translation>
    </message>
    <message>
      <source>no</source>
      <translation>no</translation>
    </message>
    <message>
      <source>yes</source>
      <translation>yes</translation>
    </message>
    <message>
      <source>Language settings</source>
      <translation>Language settings</translation>
    </message>
    <message>
      <source>Language type</source>
      <translation>Language type</translation>
    </message>
    <message>
      <source>Monolingual</source>
      <translation>Monolingual</translation>
    </message>
    <message>
      <source>Multilingual</source>
      <translation>Multilingual</translation>
    </message>
    <message>
      <source>Languages</source>
      <translation>Languages</translation>
    </message>
    <message>
      <source>No problems was found with your system, you can continue by clicking the</source>
      <translation>No problems was found with your system, you can continue by clicking the</translation>
    </message>
    <message>
      <source>Next &amp;gt;</source>
      <translation>Next &amp;gt;</translation>
    </message>
    <message>
      <source>Finetune System</source>
      <translation>Finetune System</translation>
    </message>
    <message>
      <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
      <translation>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</translation>
    </message>
    <message>
      <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
      <translation>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</translation>
    </message>
    <message>
      <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
      <translation>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</translation>
    </message>
    <message>
      <source>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</source>
      <translation>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</translation>
    </message>
    <message>
      <source>The system check found some issues that need to be resolved before the setup can continue.</source>
      <translation>The system check found some issues that need to be resolved before the setup can continue.</translation>
    </message>
    <message>
      <source>Please have a look through the results below for more information on what the problems are.</source>
      <translation>Please have a look through the results below for more information on what the problems are.</translation>
    </message>
    <message>
      <source>Each problem will give you instructions on how to fix the problem.</source>
      <translation>Each problem will give you instructions on how to fix the problem.</translation>
    </message>
    <message>
      <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
      <translation>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</translation>
    </message>
    <message>
      <source>Ignore this test</source>
      <translation>Ignore this test</translation>
    </message>
    <message>
      <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
      <translation>The system check page is being displayed. This means that there are some problems/issues present.</translation>
    </message>
    <message>
      <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
      <translation>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</translation>
    </message>
    <message>
      <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
      <translation>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</translation>
    </message>
    <message>
      <source>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</source>
      <translation>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</translation>
    </message>
    <message>
      <source>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</source>
      <translation>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</translation>
    </message>
    <message>
      <source>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</source>
      <translation>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</translation>
    </message>
    <message>
      <source>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</source>
      <translation>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</translation>
    </message>
    <message>
      <source>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</source>
      <translation>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</translation>
    </message>
    <message>
      <source>Welcome to eZ publish %1</source>
      <translation>Welcome to eZ publish %1</translation>
    </message>
    <message>
      <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</source>
      <translation>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</translation>
    </message>
    <message>
      <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
      <translation>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</translation>
    </message>
    <message>
      <source>This section will contain information/help about each step in the setup wizard.</source>
      <translation>This section will contain information/help about each step in the setup wizard.</translation>
    </message>
    <message>
      <source>The summary section below will contain information about configured settings.</source>
      <translation>The summary section below will contain information about configured settings.</translation>
    </message>
    <message>
      <source>No data will be stored in the database until the final step of the setup.</source>
      <translation>No data will be stored in the database until the final step of the setup.</translation>
    </message>
    <message>
      <source>Information about how to set up eZ publish manually is available %1.</source>
      <translation>Information about how to set up eZ publish manually is available %1.</translation>
    </message>
    <message>
      <source>here</source>
      <comment>manual installation link</comment>
      <translation>here</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/operatorcode</name>
    <message>
      <source>Example</source>
      <translation>Example</translation>
    </message>
    <message>
      <source>Constructor, does nothing by default.</source>
      <translation>Constructor, does nothing by default.</translation>
    </message>
    <message>
      <source>\return an array with the template operator name.</source>
      <translation>\return an array with the template operator name.</translation>
    </message>
    <message>
      <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
      <translation>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</translation>
    </message>
    <message>
      <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
      <translation>Example code, this code must be modified to do what the operator should do, currently it only trims text.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/session</name>
    <message>
      <source>Session admin</source>
      <translation>Session admin</translation>
    </message>
    <message>
      <source>The sessions were successfully removed.</source>
      <translation>The sessions were successfully removed.</translation>
    </message>
    <message>
      <source>Sessions</source>
      <translation>Sessions</translation>
    </message>
    <message>
      <source>Total number of sessions</source>
      <translation>Total number of sessions</translation>
    </message>
    <message>
      <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
      <translation>There are %logged_in_count registered and %anonymous_count anonymous users online.</translation>
    </message>
    <message>
      <source>Use the buttons below to delete the session entries that are present in the database.</source>
      <translation>Use the buttons below to delete the session entries that are present in the database.</translation>
    </message>
    <message>
      <source>WARNING! When removing sessions, users that are logged in will be thrown out from the system.</source>
      <translation>WARNING! When removing sessions, users that are logged in will be thrown out from the system.</translation>
    </message>
    <message>
      <source>Remove all sessions</source>
      <translation>Remove all sessions</translation>
    </message>
    <message>
      <source>Remove timed out / old sessions</source>
      <translation>Remove timed out / old sessions</translation>
    </message>
    <message>
      <source>Displaying sessions for %username</source>
      <translation>Displaying sessions for %username</translation>
    </message>
    <message>
      <source>Show from all users</source>
      <translation>Show from all users</translation>
    </message>
    <message>
      <source>Filter sessions</source>
      <translation>Filter sessions</translation>
    </message>
    <message>
      <source>Everyone</source>
      <translation>Everyone</translation>
    </message>
    <message>
      <source>Registered users</source>
      <translation>Registered users</translation>
    </message>
    <message>
      <source>Anonymous users</source>
      <translation>Anonymous users</translation>
    </message>
    <message>
      <source>Include inactive users</source>
      <translation>Include inactive users</translation>
    </message>
    <message>
      <source>Update list</source>
      <translation>Update list</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Count</source>
      <translation>Count</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Full name</source>
      <translation>Full name</translation>
    </message>
    <message>
      <source>Idle time</source>
      <translation>Idle time</translation>
    </message>
    <message>
      <source>Idle since</source>
      <translation>Idle since</translation>
    </message>
    <message>
      <source>Time skew detected</source>
      <translation>Time skew detected</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/tests</name>
    <message>
      <source>AcceptPathInfo disabled or running in CGI mode</source>
      <translation>AcceptPathInfo disabled or running in CGI mode</translation>
    </message>
    <message>
      <source>You need to enable AcceptPathInfo in your Apache config file, if you're using apache 2.x.</source>
      <translation>You need to enable AcceptPathInfo in your Apache config file, if you're using apache 2.x.</translation>
    </message>
    <message>
      <source>If you're running apache 1.3, eZ publish will not run in CGI mode.</source>
      <translation>If you're running apache 1.3, eZ publish will not run in CGI mode.</translation>
    </message>
    <message>
      <source>enter the following into your httpd.conf file.</source>
      <translation>enter the following into your httpd.conf file.</translation>
    </message>
    <message>
      <source>Remember to restart your web server afterwards.</source>
      <translation>Remember to restart your web server afterwards.</translation>
    </message>
    <message>
      <source>allow_url_fopen ini setting is disabled</source>
      <translation>allow_url_fopen ini setting is disabled</translation>
    </message>
    <message>
      <source>You need to alter your PHP settings, and enable the 'allow_url_fopen' setting in your php.ini file.</source>
      <translation>You need to alter your PHP settings, and enable the 'allow_url_fopen' setting in your php.ini file.</translation>
    </message>
    <message>
      <source>Note : Failure here will also cause failure to the accept_path_info test.</source>
      <translation>Note : Failure here will also cause failure to the accept_path_info test.</translation>
    </message>
    <message>
      <source>Missing database handlers</source>
      <translation>Missing database handlers</translation>
    </message>
    <message>
      <source>Your PHP does not have support for all databases that eZ publish support.</source>
      <translation>Your PHP does not have support for all databases that eZ publish support.</translation>
    </message>
    <message>
      <source>Although eZ publish will work without it, it might be that you want to have support for this database.</source>
      <translation>Although eZ publish will work without it, it might be that you want to have support for this database.</translation>
    </message>
    <message>
      <source>Also some databases has more advanced features, such as charset, than others.</source>
      <translation>Also some databases has more advanced features, such as charset, than others.</translation>
    </message>
    <message>
      <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
      <translation>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</translation>
    </message>
    <message>
      <source>Missing database handler</source>
      <translation>Missing database handler</translation>
    </message>
    <message>
      <source>No supported database handlers were found. eZ publish requires a database to store it's data, without one the system will fail.</source>
      <translation>No supported database handlers were found. eZ publish requires a database to store it's data, without one the system will fail.</translation>
    </message>
    <message>
      <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
      <translation>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</translation>
    </message>
    <message>
      <source>Insufficient directory permissions</source>
      <translation>Insufficient directory permissions</translation>
    </message>
    <message>
      <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
      <translation>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</translation>
    </message>
    <message>
      <source>The affected directories are: %dir_list</source>
      <translation>The affected directories are: %dir_list</translation>
    </message>
    <message>
      <source>Shell commands</source>
      <translation>Shell commands</translation>
    </message>
    <message>
      <source>These shell commands will give proper permission to the webserver.</source>
      <translation>These shell commands will give proper permission to the webserver.</translation>
    </message>
    <message>
      <source>Alternative shell commands</source>
      <translation>Alternative shell commands</translation>
    </message>
    <message>
      <source>If you don't have permissions to change the ownership you can try these commands.</source>
      <translation>If you don't have permissions to change the ownership you can try these commands.</translation>
    </message>
    <message>
      <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it's recommended to change the ownership of the files to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
      <translation>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it's recommended to change the ownership of the files to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</translation>
    </message>
    <message>
      <source>These commands will setup the permission more correctly, but require knowledge about the running webserver.</source>
      <translation>These commands will setup the permission more correctly, but require knowledge about the running webserver.</translation>
    </message>
    <message>
      <source>Note</source>
      <translation>Note</translation>
    </message>
    <message>
      <source>The %user_expr must be changed to your webserver username and groupname.</source>
      <translation>The %user_expr must be changed to your webserver username and groupname.</translation>
    </message>
    <message>
      <source>Missed some directories</source>
      <translation>Missed some directories</translation>
    </message>
    <message>
      <source>eZ publish cannot create some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
      <translation>eZ publish cannot create some important directories, without this the setup cannot finish and parts of eZ publish will fail.</translation>
    </message>
    <message>
      <source>The nonexistent directories are: %dir_list</source>
      <translation>The nonexistent directories are: %dir_list</translation>
    </message>
    <message>
      <source>You can try the following shell commands to create necessary directories:</source>
      <translation>You can try the following shell commands to create necessary directories:</translation>
    </message>
    <message>
      <source>Files instead necessary directories</source>
      <translation>Files instead necessary directories</translation>
    </message>
    <message>
      <source>eZ publish cannot create some important directories, because there are an files instead of these directories in the same places with the same names.
You should replace these files with appropriate directories and give necessary permissions to them.
Without this the setup cannot finish and parts of eZ publish will fail.</source>
      <translation>eZ publish cannot create some important directories, because there are an files instead of these directories in the same places with the same names.
You should replace these files with appropriate directories and give necessary permissions to them.
Without this the setup cannot finish and parts of eZ publish will fail.</translation>
    </message>
    <message>
      <source>The affected directories (files) are: %dir_list</source>
      <translation>The affected directories (files) are: %dir_list</translation>
    </message>
    <message>
      <source>Insufficient execution time allowed to install eZ publish</source>
      <translation>Insufficient execution time allowed to install eZ publish</translation>
    </message>
    <message>
      <source>eZ publish will not work correctly with a execution time limit of %1.</source>
      <translation>eZ publish will not work correctly with a execution time limit of %1.</translation>
    </message>
    <message>
      <source>It's highly recommended that you fix this.</source>
      <translation>It's highly recommended that you fix this.</translation>
    </message>
    <message>
      <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
      <translation>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</translation>
    </message>
    <message>
      <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
      <translation>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Next</translation>
    </message>
    <message>
      <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
      <translation>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</translation>
    </message>
    <message>
      <source>File uploading is disabled</source>
      <translation>File uploading is disabled</translation>
    </message>
    <message>
      <source>File uploading is not possible</source>
      <translation>File uploading is not possible</translation>
    </message>
    <message>
      <source>File uploading is not enabled which means that it's impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it's recommended to enable file uploads.</source>
      <translation>File uploading is not enabled which means that it's impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it's recommended to enable file uploads.</translation>
    </message>
    <message>
      <source>Configuration</source>
      <translation>Configuration</translation>
    </message>
    <message>
      <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
      <translation>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</translation>
    </message>
    <message>
      <source>More information on enabling the extension can be found by reading %1 and %2</source>
      <translation>More information on enabling the extension can be found by reading %1 and %2</translation>
    </message>
    <message>
      <source>The PHP upload directory %upload_dir does not exists or is not accessible, without this you will not be able to upload files or images to eZ publish.</source>
      <translation>The PHP upload directory %upload_dir does not exists or is not accessible, without this you will not be able to upload files or images to eZ publish.</translation>
    </message>
    <message>
      <source>Create the directory %upload_dir on your system. If you do not have the possibility to create this yourself ask the administrator to create it for you.</source>
      <translation>Create the directory %upload_dir on your system. If you do not have the possibility to create this yourself ask the administrator to create it for you.</translation>
    </message>
    <message>
      <source>The upload directory is currently placed in the directory of the root user.
This is a security problem and should be changed to another global temporary directory</source>
      <translation>The upload directory is currently placed in the directory of the root user.
This is a security problem and should be changed to another global temporary directory</translation>
    </message>
    <message>
      <source>This shell command will create the upload directory.</source>
      <translation>This shell command will create the upload directory.</translation>
    </message>
    <message>
      <source>The PHP upload directory %upload_dir is not writeable. This means that it will be impossible to upload files or images to eZ publish.</source>
      <translation>The PHP upload directory %upload_dir is not writeable. This means that it will be impossible to upload files or images to eZ publish.</translation>
    </message>
    <message>
      <source>You must change the permission on the directory %upload_dir. If you do not have the possibility to create this yourself ask the administrator to do this for you.</source>
      <translation>You must change the permission on the directory %upload_dir. If you do not have the possibility to create this yourself ask the administrator to do this for you.</translation>
    </message>
    <message>
      <source>These shell commands will give proper permission to the upload directory.</source>
      <translation>These shell commands will give proper permission to the upload directory.</translation>
    </message>
    <message>
      <source>If you don't have permissions to change the ownership you can try this command.</source>
      <translation>If you don't have permissions to change the ownership you can try this command.</translation>
    </message>
    <message>
      <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it's recommended to change the ownership of the upload directory to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
      <translation>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it's recommended to change the ownership of the upload directory to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</translation>
    </message>
    <message>
      <source>This shell command will give proper permission to the upload directory.</source>
      <translation>This shell command will give proper permission to the upload directory.</translation>
    </message>
    <message>
      <source>If you know the user and group of the webserver you can try this command. Replace apache:apache with the user and group.</source>
      <translation>If you know the user and group of the webserver you can try this command. Replace apache:apache with the user and group.</translation>
    </message>
    <message>
      <source>Missing image conversion support</source>
      <translation>Missing image conversion support</translation>
    </message>
    <message>
      <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
      <translation>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</translation>
    </message>
    <message>
      <source>Missing imagegd2 extension</source>
      <translation>Missing imagegd2 extension</translation>
    </message>
    <message>
      <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
      <translation>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</translation>
    </message>
    <message>
      <source>template operator will not be available.</source>
      <translation>template operator will not be available.</translation>
    </message>
    <message>
      <source>Note:</source>
      <translation>Note:</translation>
    </message>
    <message>
      <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
      <translation>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</translation>
    </message>
    <message>
      <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
      <translation>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</translation>
    </message>
    <message>
      <source>Missing ImageMagick program</source>
      <translation>Missing ImageMagick program</translation>
    </message>
    <message>
      <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
      <translation>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</translation>
    </message>
    <message>
      <source>If you known where the program is installed (the executable is called</source>
      <translation>If you known where the program is installed (the executable is called</translation>
    </message>
    <message>
      <source>or</source>
      <translation>or</translation>
    </message>
    <message>
      <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
      <translation>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</translation>
    </message>
    <message>
      <source>colon</source>
      <translation>colon</translation>
    </message>
    <message>
      <source>semicolon</source>
      <translation>semicolon</translation>
    </message>
    <message>
      <source>Installation</source>
      <translation>Installation</translation>
    </message>
    <message>
      <source>ImageMagick may be downloaded from</source>
      <translation>ImageMagick may be downloaded from</translation>
    </message>
    <message>
      <source>Missing MBString extension</source>
      <translation>Missing MBString extension</translation>
    </message>
    <message>
      <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
      <translation>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</translation>
    </message>
    <message>
      <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
      <translation>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</translation>
    </message>
    <message>
      <source>The complete list of charsets mbstring supports are</source>
      <translation>The complete list of charsets mbstring supports are</translation>
    </message>
    <message>
      <source>Installation of the mbstring extension is done by compiling PHP with the</source>
      <translation>Installation of the mbstring extension is done by compiling PHP with the</translation>
    </message>
    <message>
      <source>option.</source>
      <translation>option.</translation>
    </message>
    <message>
      <source>More information on enabling the extension can be found at</source>
      <translation>More information on enabling the extension can be found at</translation>
    </message>
    <message>
      <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it's needed.</source>
      <translation>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it's needed.</translation>
    </message>
    <message>
      <source>Insufficient memory allocated to install eZ publish</source>
      <translation>Insufficient memory allocated to install eZ publish</translation>
    </message>
    <message>
      <source>eZ publish will not work correctly with a memory limit of %1.</source>
      <translation>eZ publish will not work correctly with a memory limit of %1.</translation>
    </message>
    <message>
      <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
      <translation>Open the php.ini file and change the memory_limit value to at least %1, and press %2</translation>
    </message>
    <message>
      <source>PHP option</source>
      <translation>PHP option</translation>
    </message>
    <message>
      <source>is enabled</source>
      <translation>is enabled</translation>
    </message>
    <message>
      <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
      <translation>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</translation>
    </message>
    <message>
      <source>normal</source>
      <translation>normal</translation>
    </message>
    <message>
      <source>It's recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
      <translation>It's recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</translation>
    </message>
    <message>
      <source>More information on the subject can be found at %1.</source>
      <translation>More information on the subject can be found at %1.</translation>
    </message>
    <message>
      <source>php.ini example</source>
      <translation>php.ini example</translation>
    </message>
    <message>
      <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following</source>
      <translation>Alternatively you may create a file called %1 in your eZ publish root folder and add the following</translation>
    </message>
    <message>
      <source>.htaccess example</source>
      <translation>.htaccess example</translation>
    </message>
    <message>
      <source>eZ publish will not work properly with this option on.</source>
      <translation>eZ publish will not work properly with this option on.</translation>
    </message>
    <message>
      <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
      <translation>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</translation>
    </message>
    <message>
      <source>PHP option %1 is enabled</source>
      <translation>PHP option %1 is enabled</translation>
    </message>
    <message>
      <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
      <translation>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</translation>
    </message>
    <message>
      <source>It's recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
      <translation>It's recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</translation>
    </message>
    <message>
      <source>Missing Session Extension</source>
      <translation>Missing Session Extension</translation>
    </message>
    <message>
      <source>Your PHP module does not have session support, without this eZ publish will not work properly.</source>
      <translation>Your PHP module does not have session support, without this eZ publish will not work properly.</translation>
    </message>
    <message>
      <source>To enable session support you will have recompile your PHP module without the %session_disable switch.</source>
      <translation>To enable session support you will have recompile your PHP module without the %session_disable switch.</translation>
    </message>
    <message>
      <source>If your site is on shared-hosting you must contact the system administrator of the hosting company.</source>
      <translation>If your site is on shared-hosting you must contact the system administrator of the hosting company.</translation>
    </message>
    <message>
      <source>Unstable PHP version</source>
      <translation>Unstable PHP version</translation>
    </message>
    <message>
      <source>Your PHP version, which is </source>
      <translation>Your PHP version, which is </translation>
    </message>
    <message>
      <source>, is known to be unstable</source>
      <translation>, is known to be unstable</translation>
    </message>
    <message>
      <source>Another version of PHP can be download at</source>
      <translation>Another version of PHP can be download at</translation>
    </message>
    <message>
      <source>Insufficient PHP version</source>
      <translation>Insufficient PHP version</translation>
    </message>
    <message>
      <source>, does not meet the minimum requirements of</source>
      <translation>, does not meet the minimum requirements of</translation>
    </message>
    <message>
      <source>A newer version of PHP can be download at</source>
      <translation>A newer version of PHP can be download at</translation>
    </message>
    <message>
      <source>You must upgrade to at least version </source>
      <translation>You must upgrade to at least version </translation>
    </message>
    <message>
      <source>, but the latest released PHP 4.4.x version is highly recommended.</source>
      <translation>, but the latest released PHP 4.4.x version is highly recommended.</translation>
    </message>
    <message>
      <source>PHP safe mode is enabled</source>
      <translation>PHP safe mode is enabled</translation>
    </message>
    <message>
      <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are</source>
      <translation>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are</translation>
    </message>
    <message>
      <source>eZ publish cannot write to the</source>
      <translation>eZ publish cannot write to the</translation>
    </message>
    <message>
      <source>directory, without this the setup cannot disable itself.</source>
      <translation>directory, without this the setup cannot disable itself.</translation>
    </message>
    <message>
      <source>It's recommended that you fix this by running the commands below.</source>
      <translation>It's recommended that you fix this by running the commands below.</translation>
    </message>
    <message>
      <source>Missing text creation functions</source>
      <translation>Missing text creation functions</translation>
    </message>
    <message>
      <source>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</source>
      <translation>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</translation>
    </message>
    <message>
      <source>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</source>
      <translation>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</translation>
    </message>
    <message>
      <source>Missing zlib extension</source>
      <translation>Missing zlib extension</translation>
    </message>
    <message>
      <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
      <translation>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</translation>
    </message>
    <message>
      <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
      <translation>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</translation>
    </message>
    <message>
      <source>More information on that subject is available at</source>
      <translation>More information on that subject is available at</translation>
    </message>
  </context>
  <context>
    <name>design/standard/setup/toolbar</name>
    <message>
      <source>Tool List for Toolbar_%toolbar_position</source>
      <translation>Tool List for Toolbar_%toolbar_position</translation>
    </message>
    <message>
      <source>Tool</source>
      <translation>Tool</translation>
    </message>
    <message>
      <source>Placement</source>
      <translation>Placement</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Update Placement</source>
      <translation>Update Placement</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Add Tool</source>
      <translation>Add Tool</translation>
    </message>
  </context>
  <context>
    <name>design/standard/shop</name>
    <message>
      <source>Incorrect quantity! The quantity of the product(s) must be numeric and not less than 1.</source>
      <translation>Incorrect quantity! The quantity of the product(s) must be numeric and not less than 1.</translation>
    </message>
    <message>
      <source>Attempted to add object without price to basket.</source>
      <translation>Attempted to add object without price to basket.</translation>
    </message>
    <message>
      <source>Your payment was aborted.</source>
      <translation>Your payment was aborted.</translation>
    </message>
    <message>
      <source>Customer information</source>
      <translation>Customer information</translation>
    </message>
    <message>
      <source>Email</source>
      <translation>Email</translation>
    </message>
    <message>
      <source>Shipping address</source>
      <translation>Shipping address</translation>
    </message>
    <message>
      <source>First name</source>
      <translation>First name</translation>
    </message>
    <message>
      <source>Last name</source>
      <translation>Last name</translation>
    </message>
    <message>
      <source>Address</source>
      <translation>Address</translation>
    </message>
    <message>
      <source>Customer</source>
      <translation>Customer</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Company</source>
      <translation>Company</translation>
    </message>
    <message>
      <source>Street</source>
      <translation>Street</translation>
    </message>
    <message>
      <source>Zip</source>
      <translation>Zip</translation>
    </message>
    <message>
      <source>Place</source>
      <translation>Place</translation>
    </message>
    <message>
      <source>State</source>
      <translation>State</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Country</translation>
    </message>
    <message>
      <source>Archive list</source>
      <translation>Archive list</translation>
    </message>
    <message>
      <source>Sort Result by</source>
      <translation>Sort Result by</translation>
    </message>
    <message>
      <source>Order Time</source>
      <translation>Order Time</translation>
    </message>
    <message>
      <source>User Name</source>
      <translation>User Name</translation>
    </message>
    <message>
      <source>Order ID</source>
      <translation>Order ID</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Sort ascending</source>
      <translation>Sort ascending</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Sort descending</source>
      <translation>Sort descending</translation>
    </message>
    <message>
      <source>Sort</source>
      <translation>Sort</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Date</translation>
    </message>
    <message>
      <source>Total ex. VAT</source>
      <translation>Total ex. GST</translation>
    </message>
    <message>
      <source>Total inc. VAT</source>
      <translation>Total inc. GST</translation>
    </message>
    <message>
      <source>The order list is empty</source>
      <translation>The order list is empty</translation>
    </message>
    <message>
      <source>Unarchive</source>
      <translation>Unarchive</translation>
    </message>
    <message>
      <source>Basket</source>
      <translation>Basket</translation>
    </message>
    <message>
      <source>The following items were removed from your basket, because the products were changed</source>
      <translation>The following items were removed from your basket, because the products were changed</translation>
    </message>
    <message>
      <source>VAT is unknown</source>
      <translation>GST is unknown</translation>
    </message>
    <message>
      <source>VAT percentage is not yet known for some of the items being purchased.</source>
      <translation>GST percentage is not yet known for some of the items being purchased.</translation>
    </message>
    <message>
      <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
      <translation>This probably means that some information about you is not yet available and will be obtained during checkout.</translation>
    </message>
    <message>
      <source>Product</source>
      <translation>Product</translation>
    </message>
    <message>
      <source>Count</source>
      <translation>Count</translation>
    </message>
    <message>
      <source>VAT</source>
      <translation>GST</translation>
    </message>
    <message>
      <source>Price ex. VAT</source>
      <translation>Price ex. GST</translation>
    </message>
    <message>
      <source>Price inc. VAT</source>
      <translation>Price inc. GST</translation>
    </message>
    <message>
      <source>Discount</source>
      <translation>Discount</translation>
    </message>
    <message>
      <source>Total Price ex. VAT</source>
      <translation>Total Price ex. GST</translation>
    </message>
    <message>
      <source>Total Price inc. VAT</source>
      <translation>Total Price inc. GST</translation>
    </message>
    <message>
      <source>unknown</source>
      <translation>unknown</translation>
    </message>
    <message>
      <source>Selected options</source>
      <translation>Selected options</translation>
    </message>
    <message>
      <source>Subtotal Ex. VAT</source>
      <translation>Subtotal Ex. GST</translation>
    </message>
    <message>
      <source>Subtotal Inc. VAT</source>
      <translation>Subtotal Inc. GST</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Continue shopping</source>
      <translation>Continue shopping</translation>
    </message>
    <message>
      <source>Checkout</source>
      <translation>Checkout</translation>
    </message>
    <message>
      <source>You have no products in your basket</source>
      <translation>You have no products in your basket</translation>
    </message>
    <message>
      <source>We did not get a confirmation from the payment server.</source>
      <translation>We did not get a confirmation from the payment server.</translation>
    </message>
    <message>
      <source>Please contact the owner of the webshop and provide your order ID</source>
      <translation>Please contact the owner of the webshop and provide your order ID</translation>
    </message>
    <message>
      <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
      <translation>Payment was cancelled for an unknown reason. Please try to buy again.</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
    <message>
      <source>Waiting for a response from the payment server. This can take some time.</source>
      <translation>Waiting for a response from the payment server. This can take some time.</translation>
    </message>
    <message>
      <source>Retrying to get a valid response.</source>
      <translation>Retrying to get a valid response.</translation>
    </message>
    <message>
      <source>Retry </source>
      <translation>Retry </translation>
    </message>
    <message>
      <source>out of </source>
      <translation>out of </translation>
    </message>
    <message>
      <source>If your page does not automatically refresh then press the refresh button manually.</source>
      <translation>If your page does not automatically refresh then press the refresh button manually.</translation>
    </message>
    <message>
      <source>Confirm order</source>
      <translation>Confirm order</translation>
    </message>
    <message>
      <source>Product items</source>
      <translation>Product items</translation>
    </message>
    <message>
      <source>Order summary</source>
      <translation>Order summary</translation>
    </message>
    <message>
      <source>Subtotal of items</source>
      <translation>Subtotal of items</translation>
    </message>
    <message>
      <source>Order total</source>
      <translation>Order total</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation>Confirm</translation>
    </message>
    <message>
      <source>Customer list</source>
      <translation>Customer list</translation>
    </message>
    <message>
      <source>Number of orders</source>
      <translation>Number of orders</translation>
    </message>
    <message>
      <source>The customer list is empty</source>
      <translation>The customer list is empty</translation>
    </message>
    <message>
      <source>Customer Information</source>
      <translation>Customer Information</translation>
    </message>
    <message>
      <source>Order list</source>
      <translation>Order list</translation>
    </message>
    <message>
      <source>Purchase list</source>
      <translation>Purchase list</translation>
    </message>
    <message>
      <source>Amount</source>
      <translation>Amount</translation>
    </message>
    <message>
      <source>Discount groups</source>
      <translation>Discount groups</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Edit discount group - %1</source>
      <translation>Edit discount group - %1</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Group view</source>
      <translation>Group view</translation>
    </message>
    <message>
      <source>Group Name</source>
      <translation>Group Name</translation>
    </message>
    <message>
      <source>Defined rules</source>
      <translation>Defined rules</translation>
    </message>
    <message>
      <source>Percent</source>
      <translation>Percent</translation>
    </message>
    <message>
      <source>Apply to</source>
      <translation>Apply to</translation>
    </message>
    <message>
      <source>Add Rule</source>
      <translation>Add Rule</translation>
    </message>
    <message>
      <source>Remove Rule</source>
      <translation>Remove Rule</translation>
    </message>
    <message>
      <source>Customers</source>
      <translation>Customers</translation>
    </message>
    <message>
      <source>Name</source>
      <comment>Customer name</comment>
      <translation>Name</translation>
    </message>
    <message>
      <source>Add customer</source>
      <translation>Add customer</translation>
    </message>
    <message>
      <source>Remove customer</source>
      <translation>Remove customer</translation>
    </message>
    <message>
      <source>Editing rule</source>
      <translation>Editing rule</translation>
    </message>
    <message>
      <source>Attributes</source>
      <translation>Attributes</translation>
    </message>
    <message>
      <source>Discount percent</source>
      <translation>Discount percent</translation>
    </message>
    <message>
      <source>Rule settings</source>
      <translation>Rule settings</translation>
    </message>
    <message>
      <source>Choose which classes, sections or objects ( products ) applied to this sub rule, 'Any' means the rule will applied to all.</source>
      <translation>Choose which classes, sections or objects ( products ) applied to this sub rule, 'Any' means the rule will applied to all.</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>Object</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>Not specified.</source>
      <translation>Not specified.</translation>
    </message>
    <message>
      <source>Find</source>
      <translation>Find</translation>
    </message>
    <message>
      <source>Order</source>
      <translation>Order</translation>
    </message>
    <message>
      <source>Archive</source>
      <translation>Archive</translation>
    </message>
    <message>
      <source>Statistics</source>
      <translation>Statistics</translation>
    </message>
    <message>
      <source>All Years</source>
      <translation>All Years</translation>
    </message>
    <message>
      <source>All Months</source>
      <translation>All Months</translation>
    </message>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
    <message>
      <source>SUM:</source>
      <translation>SUM:</translation>
    </message>
    <message>
      <source>Order %order_id [%order_status]</source>
      <translation>Order %order_id [%order_status]</translation>
    </message>
    <message>
      <source>Order history</source>
      <translation>Order history</translation>
    </message>
    <message>
      <source>Register account information</source>
      <translation>Register account information</translation>
    </message>
    <message>
      <source>Input did not validate, fill in all fields</source>
      <translation>Input did not validate, fill in all fields</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Are you sure you want to remove order: </source>
      <translation>Are you sure you want to remove order: </translation>
    </message>
    <message>
      <source>Order status</source>
      <translation>Order status</translation>
    </message>
    <message>
      <source>Active</source>
      <translation>Active</translation>
    </message>
    <message>
      <source>Is active</source>
      <translation>Is active</translation>
    </message>
    <message>
      <source>Is inactive</source>
      <translation>Is inactive</translation>
    </message>
    <message>
      <source>Your account information</source>
      <translation>Your account information</translation>
    </message>
    <message>
      <source>Input did not validate, all fields marked with * must be filled in</source>
      <translation>Input did not validate, all fields marked with * must be filled in</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comment</translation>
    </message>
    <message>
      <source>Continue</source>
      <translation>Continue</translation>
    </message>
    <message>
      <source>All fields marked with * must be filled in.</source>
      <translation>All fields marked with * must be filled in.</translation>
    </message>
    <message>
      <source>Wish list</source>
      <translation>Wish list</translation>
    </message>
    <message>
      <source>Remove items</source>
      <translation>Remove items</translation>
    </message>
    <message>
      <source>Empty wish list</source>
      <translation>Empty wish list</translation>
    </message>
  </context>
  <context>
    <name>design/standard/shop/currencynames</name>
    <message>
      <source>Argentine peso</source>
      <translation>Argentine peso</translation>
    </message>
    <message>
      <source>Australian dollar</source>
      <translation>Australian dollar</translation>
    </message>
    <message>
      <source>Bulgarian lev</source>
      <translation>Bulgarian lev</translation>
    </message>
    <message>
      <source>Brazilian real</source>
      <translation>Brazilian real</translation>
    </message>
    <message>
      <source>Canadian dollar</source>
      <translation>Canadian dollar</translation>
    </message>
    <message>
      <source>Swiss franc</source>
      <translation>Swiss franc</translation>
    </message>
    <message>
      <source>Chinese yuan renminbi</source>
      <translation>Chinese yuan renminbi</translation>
    </message>
    <message>
      <source>Cyprus pound</source>
      <translation>Cyprus pound</translation>
    </message>
    <message>
      <source>Czech koruna</source>
      <translation>Czech koruna</translation>
    </message>
    <message>
      <source>Danish krone</source>
      <translation>Danish krone</translation>
    </message>
    <message>
      <source>Estonian kroon</source>
      <translation>Estonian kroon</translation>
    </message>
    <message>
      <source>European euro</source>
      <translation>European euro</translation>
    </message>
    <message>
      <source>Pound sterling</source>
      <translation>Pound sterling</translation>
    </message>
    <message>
      <source>Hong Kong dollar</source>
      <translation>Hong Kong dollar</translation>
    </message>
    <message>
      <source>Croatian kuna</source>
      <translation>Croatian kuna</translation>
    </message>
    <message>
      <source>Hungarian forint</source>
      <translation>Hungarian forint</translation>
    </message>
    <message>
      <source>Icelandic krona</source>
      <translation>Icelandic krona</translation>
    </message>
    <message>
      <source>Japanese yen</source>
      <translation>Japanese yen</translation>
    </message>
    <message>
      <source>South Korean won</source>
      <translation>South Korean won</translation>
    </message>
    <message>
      <source>Lithuanian litas</source>
      <translation>Lithuanian litas</translation>
    </message>
    <message>
      <source>Latvian lats</source>
      <translation>Latvian lats</translation>
    </message>
    <message>
      <source>Maltese lira</source>
      <translation>Maltese lira</translation>
    </message>
    <message>
      <source>Mexican peso</source>
      <translation>Mexican peso</translation>
    </message>
    <message>
      <source>Norwegian Krone</source>
      <translation>Norwegian Krone</translation>
    </message>
    <message>
      <source>New Zealand dollar</source>
      <translation>New Zealand dollar</translation>
    </message>
    <message>
      <source>Polish zloty</source>
      <translation>Polish zloty</translation>
    </message>
    <message>
      <source>New Romanian leu</source>
      <translation>New Romanian leu</translation>
    </message>
    <message>
      <source>Russian rouble</source>
      <translation>Russian rouble</translation>
    </message>
    <message>
      <source>Swedish krona</source>
      <translation>Swedish krona</translation>
    </message>
    <message>
      <source>Singapore dollar</source>
      <translation>Singapore dollar</translation>
    </message>
    <message>
      <source>Slovenian tolar</source>
      <translation>Slovenian tolar</translation>
    </message>
    <message>
      <source>Slovak koruna</source>
      <translation>Slovak koruna</translation>
    </message>
    <message>
      <source>New Turkish lira</source>
      <translation>New Turkish lira</translation>
    </message>
    <message>
      <source>Ukrainian hryvnia</source>
      <translation>Ukrainian hryvnia</translation>
    </message>
    <message>
      <source>U.S.dollar</source>
      <translation>U.S.dollar</translation>
    </message>
  </context>
  <context>
    <name>design/standard/shop/preferredcurrency</name>
    <message>
      <source>Unknown currency name</source>
      <translation>Unknown currency name</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Set the selected currency as preferred.</source>
      <translation>Set the selected currency as preferred.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/shop/productsoverview</name>
    <message>
      <source>Products overview</source>
      <translation>Products overview</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Price</source>
      <translation>Price</translation>
    </message>
    <message>
      <source>Show 10 items per page.</source>
      <translation>Show 10 items per page.</translation>
    </message>
    <message>
      <source>Show 50 items per page.</source>
      <translation>Show 50 items per page.</translation>
    </message>
    <message>
      <source>Show 25 items per page.</source>
      <translation>Show 25 items per page.</translation>
    </message>
    <message>
      <source>The product list is empty.</source>
      <translation>The product list is empty.</translation>
    </message>
    <message>
      <source>Select product class.</source>
      <translation>Select product class.</translation>
    </message>
    <message>
      <source>Show products</source>
      <translation>Show products</translation>
    </message>
    <message>
      <source>Show products of selected class.</source>
      <translation>Show products of selected class.</translation>
    </message>
    <message>
      <source>Select sorting field.</source>
      <translation>Select sorting field.</translation>
    </message>
    <message>
      <source>Select sorting order.</source>
      <translation>Select sorting order.</translation>
    </message>
    <message>
      <source>Descending</source>
      <translation>Descending</translation>
    </message>
    <message>
      <source>Ascending</source>
      <translation>Ascending</translation>
    </message>
    <message>
      <source>Sort products</source>
      <translation>Sort products</translation>
    </message>
    <message>
      <source>Sort products.</source>
      <translation>Sort products.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/shop/view</name>
    <message>
      <source>Choose customers</source>
      <translation>Choose customers</translation>
    </message>
    <message>
      <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
      <translation>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</translation>
    </message>
    <message>
      <source>Choose product for discount</source>
      <translation>Choose product for discount</translation>
    </message>
    <message>
      <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
      <translation>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/simplified_treemenu</name>
    <message>
      <source>Fold/Unfold</source>
      <translation>Fold/Unfold</translation>
    </message>
  </context>
  <context>
    <name>design/standard/toolbar</name>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>Shopping basket</source>
      <translation>Shopping basket</translation>
    </message>
    <message>
      <source>View all details</source>
      <translation>View all details</translation>
    </message>
    <message>
      <source>Your basket is empty</source>
      <translation>Your basket is empty</translation>
    </message>
    <message>
      <source>Best sellers</source>
      <translation>Best sellers</translation>
    </message>
    <message>
      <source>Calendar</source>
      <translation>Calendar</translation>
    </message>
    <message>
      <source>My drafts</source>
      <translation>My drafts</translation>
    </message>
    <message>
      <source>Account</source>
      <translation>Account</translation>
    </message>
    <message>
      <source>Not logged in</source>
      <translation>Not logged in</translation>
    </message>
    <message>
      <source>Logged in as: %username</source>
      <translation>Logged in as: %username</translation>
    </message>
    <message>
      <source>Edit account</source>
      <translation>Edit account</translation>
    </message>
    <message>
      <source>Change password</source>
      <translation>Change password</translation>
    </message>
    <message>
      <source>Logout</source>
      <translation>Logout</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Not registered?</source>
      <translation>Not registered?</translation>
    </message>
    <message>
      <source>Forgot your password?</source>
      <translation>Forgot your password?</translation>
    </message>
    <message>
      <source>Notification</source>
      <translation>Notification</translation>
    </message>
    <message>
      <source>My Notifications</source>
      <translation>My Notifications</translation>
    </message>
    <message>
      <source>Preferred currency</source>
      <translation>Preferred currency</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Set the selected currency as preferred.</source>
      <translation>Set the selected currency as preferred.</translation>
    </message>
    <message>
      <source>There are no available currencies</source>
      <translation>There are no available currencies</translation>
    </message>
    <message>
      <source>Your country</source>
      <translation>Your country</translation>
    </message>
    <message>
      <source>User information</source>
      <translation>User information</translation>
    </message>
    <message>
      <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
      <translation>There are %logged_in_count registered and %anonymous_count anonymous users online.</translation>
    </message>
    <message>
      <source>View basket</source>
      <translation>View basket</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Online: %logged_in_count:%anonymous_count</source>
      <comment>Short user information</comment>
      <translation>Online: %logged_in_count:%anonymous_count</translation>
    </message>
  </context>
  <context>
    <name>design/standard/toolbar/search</name>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>Global</source>
      <translation>Global</translation>
    </message>
    <message>
      <source>From here</source>
      <translation>From here</translation>
    </message>
    <message>
      <source>Search: </source>
      <translation>Search: </translation>
    </message>
  </context>
  <context>
    <name>design/standard/toolbar/user_country</name>
    <message>
      <source>Not specified</source>
      <translation>Not specified</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Apply</translation>
    </message>
    <message>
      <source>Use the selected country for VAT charging.</source>
      <translation>Use the selected country for GST charging.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/trigger</name>
    <message>
      <source>Trigger list</source>
      <translation>Trigger list</translation>
    </message>
    <message>
      <source>Module name</source>
      <translation>Module name</translation>
    </message>
    <message>
      <source>Function name</source>
      <translation>Function name</translation>
    </message>
    <message>
      <source>Connect type</source>
      <translation>Connect type</translation>
    </message>
    <message>
      <source>Workflow</source>
      <translation>Workflow</translation>
    </message>
    <message>
      <source>No workflow</source>
      <translation>No workflow</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
  </context>
  <context>
    <name>design/standard/url</name>
    <message>
      <source>All</source>
      <translation>All</translation>
    </message>
    <message>
      <source>Valid</source>
      <translation>Valid</translation>
    </message>
    <message>
      <source>Invalid</source>
      <translation>Invalid</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filter</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>Last checked</source>
      <translation>Last checked</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>Popup</source>
      <translation>Popup</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Never</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Unknown</translation>
    </message>
    <message>
      <source>All URLs</source>
      <translation>All URLs</translation>
    </message>
    <message>
      <source>Invalid URLs</source>
      <translation>Invalid URLs</translation>
    </message>
    <message>
      <source>Valid URLs</source>
      <translation>Valid URLs</translation>
    </message>
    <message>
      <source>Information on URL</source>
      <translation>Information on URL</translation>
    </message>
    <message>
      <source>The URL is not considered valid any more.</source>
      <translation>The URL is not considered valid any more.</translation>
    </message>
    <message>
      <source>This means that the URL is no longer available or has been moved.</source>
      <translation>This means that the URL is no longer available or has been moved.</translation>
    </message>
    <message>
      <source>The URL points to %1.</source>
      <translation>The URL points to %1.</translation>
    </message>
    <message>
      <source>Objects which use this link</source>
      <translation>Objects which use this link</translation>
    </message>
    <message>
      <source>version</source>
      <translation>version</translation>
    </message>
    <message>
      <source>No object available</source>
      <translation>No object available</translation>
    </message>
    <message>
      <source>Last modified at %1</source>
      <translation>Last modified at %1</translation>
    </message>
    <message>
      <source>URL has no modification date</source>
      <translation>URL has no modification date</translation>
    </message>
    <message>
      <source>Last checked at %1</source>
      <translation>Last checked at %1</translation>
    </message>
    <message>
      <source>URL has not been checked</source>
      <translation>URL has not been checked</translation>
    </message>
  </context>
  <context>
    <name>design/standard/url/edit</name>
    <message>
      <source>Editing URL - %1</source>
      <translation>Editing URL - %1</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/user</name>
    <message>
      <source>The node (%1) specified in [UserSettings].DefaultUserPlacement setting in site.ini does not exist!</source>
      <translation>The node (%1) specified in [UserSettings].DefaultUserPlacement setting in site.ini does not exist!</translation>
    </message>
    <message>
      <source>Activate account</source>
      <translation>Activate account</translation>
    </message>
    <message>
      <source>Your account is now activated.</source>
      <translation>Your account is now activated.</translation>
    </message>
    <message>
      <source>Your account is already active.</source>
      <translation>Your account is already active.</translation>
    </message>
    <message>
      <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
      <translation>Sorry, the key submitted was not a valid key. Account was not activated.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>User profile</source>
      <translation>User profile</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Edit profile</source>
      <translation>Edit profile</translation>
    </message>
    <message>
      <source>Change password</source>
      <translation>Change password</translation>
    </message>
    <message>
      <source>Change setting</source>
      <translation>Change setting</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Could not login</source>
      <translation>Could not login</translation>
    </message>
    <message>
      <source>A valid username and password is required to login.</source>
      <translation>A valid username and password is required to login.</translation>
    </message>
    <message>
      <source>Access not allowed</source>
      <translation>Access not allowed</translation>
    </message>
    <message>
      <source>You are not allowed to access %1.</source>
      <translation>You are not allowed to access %1.</translation>
    </message>
    <message>
      <source>Username</source>
      <comment>User name</comment>
      <translation>Username</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Login</source>
      <comment>Button</comment>
      <translation>Login</translation>
    </message>
    <message>
      <source>Sign Up</source>
      <comment>Button</comment>
      <translation>Sign Up</translation>
    </message>
    <message>
      <source>Forgot your password?</source>
      <translation>Forgot your password?</translation>
    </message>
    <message>
      <source>Change password for user</source>
      <translation>Change password for user</translation>
    </message>
    <message>
      <source>Please retype your old password.</source>
      <translation>Please retype your old password.</translation>
    </message>
    <message>
      <source>Password didn't match, please retype your new password.</source>
      <translation>Password didn't match, please retype your new password.</translation>
    </message>
    <message>
      <source>Password successfully updated.</source>
      <translation>Password successfully updated.</translation>
    </message>
    <message>
      <source>Old password</source>
      <translation>Old password</translation>
    </message>
    <message>
      <source>New password</source>
      <translation>New password</translation>
    </message>
    <message>
      <source>Retype password</source>
      <translation>Retype password</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Register user</source>
      <translation>Register user</translation>
    </message>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Input was stored successfully</source>
      <translation>Input was stored successfully</translation>
    </message>
    <message>
      <source>Register</source>
      <translation>Register</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Unable to register new user</source>
      <translation>Unable to register new user</translation>
    </message>
    <message>
      <source>Back</source>
      <translation>Back</translation>
    </message>
    <message>
      <source>User setting</source>
      <translation>User setting</translation>
    </message>
    <message>
      <source>Maximum login</source>
      <translation>Maximum login</translation>
    </message>
    <message>
      <source>Is enabled</source>
      <translation>Is enabled</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Update</translation>
    </message>
    <message>
      <source>User registered</source>
      <translation>User registered</translation>
    </message>
    <message>
      <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
      <translation>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</translation>
    </message>
    <message>
      <source>Your account was successfully created.</source>
      <translation>Your account was successfully created.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/user/forgotpassword</name>
    <message>
      <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
      <translation>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</translation>
    </message>
    <message>
      <source>There is no registered user with that e-mail address.</source>
      <translation>There is no registered user with that e-mail address.</translation>
    </message>
    <message>
      <source>Password was successfully generated and sent to: %1</source>
      <translation>Password was successfully generated and sent to: %1</translation>
    </message>
    <message>
      <source>The key is invalid or has been used. </source>
      <translation>The key is invalid or has been used. </translation>
    </message>
    <message>
      <source>Have you forgotten your password?</source>
      <translation>Have you forgotten your password?</translation>
    </message>
    <message>
      <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
      <translation>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Generate new password</source>
      <translation>Generate new password</translation>
    </message>
    <message>
      <source>%siteurl new password</source>
      <translation>%siteurl new password</translation>
    </message>
    <message>
      <source>Your account information</source>
      <translation>Your account information</translation>
    </message>
    <message>
      <source>Click here to get new password</source>
      <translation>Click here to get new password</translation>
    </message>
    <message>
      <source>New password</source>
      <translation>New password</translation>
    </message>
  </context>
  <context>
    <name>design/standard/user/register</name>
    <message>
      <source>New user registered at %siteurl</source>
      <translation>New user registered at %siteurl</translation>
    </message>
    <message>
      <source>A new user has registered.</source>
      <translation>A new user has registered.</translation>
    </message>
    <message>
      <source>Account information.</source>
      <translation>Account information.</translation>
    </message>
    <message>
      <source>Username</source>
      <comment>Login name</comment>
      <translation>Username</translation>
    </message>
    <message>
      <source>E-mail</source>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>Link to user information</source>
      <translation>Link to user information</translation>
    </message>
    <message>
      <source>%1 registration info</source>
      <translation>%1 registration info</translation>
    </message>
    <message>
      <source>Thank you for registering at %siteurl.</source>
      <translation>Thank you for registering at %siteurl.</translation>
    </message>
    <message>
      <source>Your account information</source>
      <translation>Your account information</translation>
    </message>
    <message>
      <source>Username</source>
      <translation>Username</translation>
    </message>
    <message>
      <source>Email</source>
      <translation>Email</translation>
    </message>
    <message>
      <source>Password</source>
      <translation>Password</translation>
    </message>
    <message>
      <source>Click the following URL to confirm your account</source>
      <translation>Click the following URL to confirm your account</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/menuconfig</name>
    <message>
      <source>Menu management</source>
      <translation>Menu management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Menu positioning</source>
      <translation>Menu positioning</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click here to store the changes if you have modified the menu settings above.</source>
      <translation>Click here to store the changes if you have modified the menu settings above.</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/templatecreate</name>
    <message>
      <source>Could not create template, permission denied.</source>
      <translation>Could not create template, permission denied.</translation>
    </message>
    <message>
      <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
      <translation>Invalid name. You can only use the characters a-z, numbers and _.</translation>
    </message>
    <message>
      <source>Create new template override for &lt;%template_name&gt;</source>
      <translation>Create new template override for &lt;%template_name&gt;</translation>
    </message>
    <message>
      <source>The newly created template file will be placed in</source>
      <translation>The newly created template file will be placed in</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Filename</translation>
    </message>
    <message>
      <source>Override keys</source>
      <translation>Override keys</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>All classes</source>
      <translation>All classes</translation>
    </message>
    <message>
      <source>Section</source>
      <translation>Section</translation>
    </message>
    <message>
      <source>All sections</source>
      <translation>All sections</translation>
    </message>
    <message>
      <source>Node ID</source>
      <translation>Node ID</translation>
    </message>
    <message>
      <source>Base template on</source>
      <translation>Base template on</translation>
    </message>
    <message>
      <source>Empty file</source>
      <translation>Empty file</translation>
    </message>
    <message>
      <source>Copy of default template</source>
      <translation>Copy of default template</translation>
    </message>
    <message>
      <source>Container (with children)</source>
      <translation>Container (with children)</translation>
    </message>
    <message>
      <source>View (without children)</source>
      <translation>View (without children)</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Object</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/templateedit</name>
    <message>
      <source>Edit template: &lt;%template&gt;</source>
      <translation>Edit template: &lt;%template&gt;</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to save the contents of the text field above to the template file.</source>
      <translation>Click this button to save the contents of the text field above to the template file.</translation>
    </message>
    <message>
      <source>You do not have permissions to save the contents of the text field above to the template file.</source>
      <translation>You do not have permissions to save the contents of the text field above to the template file.</translation>
    </message>
    <message>
      <source>Back to overrides</source>
      <translation>Back to overrides</translation>
    </message>
    <message>
      <source>Back to override overview.</source>
      <translation>Back to override overview.</translation>
    </message>
    <message>
      <source>The template can not be edited.</source>
      <translation>The template can not be edited.</translation>
    </message>
    <message>
      <source>The web server does not have write access to the requested template.</source>
      <translation>The web server does not have write access to the requested template.</translation>
    </message>
    <message>
      <source>The web server does not have read access to the requested template.</source>
      <translation>The web server does not have read access to the requested template.</translation>
    </message>
    <message>
      <source>The requested template does not exist or is not being used as an override.</source>
      <translation>The requested template does not exist or is not being used as an override.</translation>
    </message>
    <message>
      <source>Edit &lt;%template_name&gt; [Template]</source>
      <translation>Edit &lt;%template_name&gt; [Template]</translation>
    </message>
    <message>
      <source>Requested template</source>
      <translation>Requested template</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Overrides template</source>
      <translation>Overrides template</translation>
    </message>
    <message>
      <source>Open as read only</source>
      <translation>Open as read only</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/templatelist</name>
    <message>
      <source>Complete template list</source>
      <translation>Complete template list</translation>
    </message>
    <message>
      <source>Template</source>
      <translation>Template</translation>
    </message>
    <message>
      <source>Design resource</source>
      <translation>Design resource</translation>
    </message>
    <message>
      <source>Manage overrides for template.</source>
      <translation>Manage overrides for template.</translation>
    </message>
    <message>
      <source>Most common templates</source>
      <translation>Most common templates</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/templateview</name>
    <message>
      <source>The overrides could not be removed.</source>
      <translation>The overrides could not be removed.</translation>
    </message>
    <message>
      <source>The following files and override rules could not be removed because of insufficient file permissions</source>
      <translation>The following files and override rules could not be removed because of insufficient file permissions</translation>
    </message>
    <message>
      <source>The override.ini file could not be modified because of insufficient permissions.</source>
      <translation>The override.ini file could not be modified because of insufficient permissions.</translation>
    </message>
    <message>
      <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
      <translation>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</translation>
    </message>
    <message>
      <source>Default template resource</source>
      <translation>Default template resource</translation>
    </message>
    <message>
      <source>Siteaccess</source>
      <translation>Siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Invert selection.</source>
      <translation>Invert selection.</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Match conditions</source>
      <translation>Match conditions</translation>
    </message>
    <message>
      <source>Priority</source>
      <translation>Priority</translation>
    </message>
    <message>
      <source>No file matched</source>
      <translation>No file matched</translation>
    </message>
    <message>
      <source>Edit override template.</source>
      <translation>Edit override template.</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Remove selected template overrides.</source>
      <translation>Remove selected template overrides.</translation>
    </message>
    <message>
      <source>New override</source>
      <translation>New override</translation>
    </message>
    <message>
      <source>Create a new template override.</source>
      <translation>Create a new template override.</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
  </context>
  <context>
    <name>design/standard/visual/toolbar</name>
    <message>
      <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
      <translation>Tool List for &lt;Toolbar_%toolbar_position&gt;</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Browse</translation>
    </message>
    <message>
      <source>True</source>
      <translation>True</translation>
    </message>
    <message>
      <source>False</source>
      <translation>False</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>There are currently no tools in this toolbar</source>
      <translation>There are currently no tools in this toolbar</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
    <message>
      <source>Update priorities</source>
      <translation>Update priorities</translation>
    </message>
    <message>
      <source>Add Tool</source>
      <translation>Add Tool</translation>
    </message>
    <message>
      <source>Apply changes</source>
      <translation>Apply changes</translation>
    </message>
    <message>
      <source>Click this button to store changes if you have modified the parameters above.</source>
      <translation>Click this button to store changes if you have modified the parameters above.</translation>
    </message>
    <message>
      <source>Back to toolbars</source>
      <translation>Back to toolbars</translation>
    </message>
    <message>
      <source>Go back to the toolbar list.</source>
      <translation>Go back to the toolbar list.</translation>
    </message>
    <message>
      <source>Toolbar management</source>
      <translation>Toolbar management</translation>
    </message>
    <message>
      <source>SiteAccess</source>
      <translation>SiteAccess</translation>
    </message>
    <message>
      <source>Current siteaccess</source>
      <translation>Current siteaccess</translation>
    </message>
    <message>
      <source>Select siteaccess</source>
      <translation>Select siteaccess</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Set</translation>
    </message>
    <message>
      <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
      <translation>Available toolbars for the &lt;%siteaccess&gt; siteaccess</translation>
    </message>
  </context>
  <context>
    <name>design/standard/workflow</name>
    <message>
      <source>Editing workflow</source>
      <translation>Editing workflow</translation>
    </message>
    <message>
      <source>Input did not validate</source>
      <translation>Input did not validate</translation>
    </message>
    <message>
      <source>Workflow stored</source>
      <translation>Workflow stored</translation>
    </message>
    <message>
      <source>Data requires fixup</source>
      <translation>Data requires fixup</translation>
    </message>
    <message>
      <source>Modified by</source>
      <translation>Modified by</translation>
    </message>
    <message>
      <source>on</source>
      <translation>on</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>Groups</source>
      <translation>Groups</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Add group</source>
      <translation>Add group</translation>
    </message>
    <message>
      <source>Events</source>
      <translation>Events</translation>
    </message>
    <message>
      <source>Pos</source>
      <translation>Pos</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Description</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>New</source>
      <translation>New</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Store</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Editing workflow group - %1</source>
      <translation>Editing workflow group - %1</translation>
    </message>
    <message>
      <source>Modified by %username on %time</source>
      <translation>Modified by %username on %time</translation>
    </message>
    <message>
      <source>Workflow groups</source>
      <translation>Workflow groups</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit workflow</source>
      <translation>Edit workflow</translation>
    </message>
    <message>
      <source>New group</source>
      <translation>New group</translation>
    </message>
    <message>
      <source>Remove selected workflows</source>
      <translation>Remove selected workflows</translation>
    </message>
    <message>
      <source>Workflow process</source>
      <translation>Workflow process</translation>
    </message>
    <message>
      <source>Workflow process was created at %creation and modified at %modification.</source>
      <translation>Workflow process was created at %creation and modified at %modification.</translation>
    </message>
    <message>
      <source>Workflow</source>
      <translation>Workflow</translation>
    </message>
    <message>
      <source>Using workflow</source>
      <translation>Using workflow</translation>
    </message>
    <message>
      <source>for processing.</source>
      <translation>for processing.</translation>
    </message>
    <message>
      <source>User</source>
      <translation>User</translation>
    </message>
    <message>
      <source>This workflow is running for user</source>
      <translation>This workflow is running for user</translation>
    </message>
    <message>
      <source>Content object</source>
      <translation>Content object</translation>
    </message>
    <message>
      <source>Workflow was created for content</source>
      <translation>Workflow was created for content</translation>
    </message>
    <message>
      <source>using version</source>
      <translation>using version</translation>
    </message>
    <message>
      <source>in parent</source>
      <translation>in parent</translation>
    </message>
    <message>
      <source>Workflow event</source>
      <translation>Workflow event</translation>
    </message>
    <message>
      <source>Workflow has not started yet, number of main events in workflow is</source>
      <translation>Workflow has not started yet, number of main events in workflow is</translation>
    </message>
    <message>
      <source>Current event position is</source>
      <translation>Current event position is</translation>
    </message>
    <message>
      <source>Event to be run is</source>
      <translation>Event to be run is</translation>
    </message>
    <message>
      <source>event</source>
      <translation>event</translation>
    </message>
    <message>
      <source>Last event returned status</source>
      <translation>Last event returned status</translation>
    </message>
    <message>
      <source>Workflow event list</source>
      <translation>Workflow event list</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reset</translation>
    </message>
    <message>
      <source>Next step</source>
      <translation>Next step</translation>
    </message>
    <message>
      <source>Workflow process was created at</source>
      <translation>Workflow process was created at</translation>
    </message>
    <message>
      <source>and modified at</source>
      <translation>and modified at</translation>
    </message>
    <message>
      <source>Workflow event log</source>
      <translation>Workflow event log</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Information</source>
      <translation>Information</translation>
    </message>
    <message>
      <source>Select gateway</source>
      <translation>Select gateway</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Select</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Additional information</source>
      <translation>Additional information</translation>
    </message>
    <message>
      <source>Workflows in %1</source>
      <comment>%1 is workflow group</comment>
      <translation>Workflows in %1</translation>
    </message>
    <message>
      <source>Modifier</source>
      <translation>Modifier</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modified</translation>
    </message>
    <message>
      <source>New workflow</source>
      <translation>New workflow</translation>
    </message>
  </context>
  <context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
      <source>Affected languages</source>
      <translation>Affected languages</translation>
    </message>
    <message>
      <source>All languages</source>
      <translation>All languages</translation>
    </message>
    <message>
      <source>Sections</source>
      <translation>Sections</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Classes to run workflow</source>
      <translation>Classes to run workflow</translation>
    </message>
    <message>
      <source>Users without workflow IDs</source>
      <translation>Users without workflow IDs</translation>
    </message>
    <message>
      <source>Workflow to run</source>
      <translation>Workflow to run</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Class</source>
      <translation>Class</translation>
    </message>
    <message>
      <source>Load attributes</source>
      <translation>Load attributes</translation>
    </message>
    <message>
      <source>Class Attributes</source>
      <translation>Class Attributes</translation>
    </message>
    <message>
      <source>Add entry</source>
      <translation>Add entry</translation>
    </message>
    <message>
      <source>Modify publish date</source>
      <translation>Modify publish date</translation>
    </message>
    <message>
      <source>Remove selected</source>
      <translation>Remove selected</translation>
    </message>
  </context>
  <context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
      <source>Approver users</source>
      <translation>Approver users</translation>
    </message>
    <message>
      <source>Approver groups</source>
      <translation>Approver groups</translation>
    </message>
    <message>
      <source>Sections</source>
      <translation>Sections</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>Users without approval</source>
      <translation>Users without approval</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Language</translation>
    </message>
    <message>
      <source>Classes to run workflow</source>
      <translation>Classes to run workflow</translation>
    </message>
    <message>
      <source>Users without workflow IDs</source>
      <translation>Users without workflow IDs</translation>
    </message>
    <message>
      <source>Workflow to run</source>
      <translation>Workflow to run</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Publish date will be modified.</source>
      <translation>Publish date will be modified.</translation>
    </message>
    <message>
      <source>Publish date will not be modified.</source>
      <translation>Publish date will not be modified.</translation>
    </message>
  </context>
  <context>
    <name>kernel/cache</name>
    <message>
      <source>Content view cache</source>
      <translation>Content view cache</translation>
    </message>
    <message>
      <source>Global INI cache</source>
      <translation>Global INI cache</translation>
    </message>
    <message>
      <source>INI cache</source>
      <translation>INI cache</translation>
    </message>
    <message>
      <source>Codepage cache</source>
      <translation>Codepage cache</translation>
    </message>
    <message>
      <source>Expiry cache</source>
      <translation>Expiry cache</translation>
    </message>
    <message>
      <source>Class identifier cache</source>
      <translation>Class identifier cache</translation>
    </message>
    <message>
      <source>Sort key cache</source>
      <translation>Sort key cache</translation>
    </message>
    <message>
      <source>URL alias cache</source>
      <translation>URL alias cache</translation>
    </message>
    <message>
      <source>Character transformation cache</source>
      <translation>Character transformation cache</translation>
    </message>
    <message>
      <source>Image alias</source>
      <translation>Image alias</translation>
    </message>
    <message>
      <source>Template cache</source>
      <translation>Template cache</translation>
    </message>
    <message>
      <source>Template block cache</source>
      <translation>Template block cache</translation>
    </message>
    <message>
      <source>Template override cache</source>
      <translation>Template override cache</translation>
    </message>
    <message>
      <source>RSS cache</source>
      <translation>RSS cache</translation>
    </message>
    <message>
      <source>User info cache</source>
      <translation>User info cache</translation>
    </message>
  </context>
  <context>
    <name>kernel/class</name>
    <message>
      <source>Class list of group</source>
      <translation>Class list of group</translation>
    </message>
    <message>
      <source>Classes</source>
      <translation>Classes</translation>
    </message>
    <message>
      <source>Remove class</source>
      <translation>Remove class</translation>
    </message>
    <message>
      <source>Class list</source>
      <translation>Class list</translation>
    </message>
    <message>
      <source>You have to have at least one group that the class belongs to!</source>
      <translation>You have to have at least one group that the class belongs to!</translation>
    </message>
    <message>
      <source>Could not load datatype: </source>
      <translation>Could not load datatype: </translation>
    </message>
    <message>
      <source>Editing this content class may cause data corruption in your system.</source>
      <translation>Editing this content class may cause data corruption in your system.</translation>
    </message>
    <message>
      <source>Press &quot;Cancel&quot; to safely exit this operation.</source>
      <translation>Press &quot;Cancel&quot; to safely exit this operation.</translation>
    </message>
    <message>
      <source>Please contact your eZ publish administrator to solve this problem.</source>
      <translation>Please contact your eZ publish administrator to solve this problem.</translation>
    </message>
    <message>
      <source>duplicate attribute identifier</source>
      <translation>duplicate attribute identifier</translation>
    </message>
    <message>
      <source>The class should have nonempty 'Name' attribute.</source>
      <translation>The class should have nonempty 'Name' attribute.</translation>
    </message>
    <message>
      <source>The class should have at least one attribute.</source>
      <translation>The class should have at least one attribute.</translation>
    </message>
    <message>
      <source>There is a class already having the same identifier.</source>
      <translation>There is a class already having the same identifier.</translation>
    </message>
    <message>
      <source>Class edit</source>
      <translation>Class edit</translation>
    </message>
    <message>
      <source>Class group list</source>
      <translation>Class group list</translation>
    </message>
    <message>
      <source>Remove classes %class_id</source>
      <translation>Remove classes %class_id</translation>
    </message>
    <message>
      <source>(no classes)</source>
      <translation>(no classes)</translation>
    </message>
    <message>
      <source>Remove class groups</source>
      <translation>Remove class groups</translation>
    </message>
    <message>
      <source>Copy of %class_name</source>
      <translation>Copy of %class_name</translation>
    </message>
  </context>
  <context>
    <name>kernel/class/edit</name>
    <message>
      <source>New Class</source>
      <translation>New Class</translation>
    </message>
    <message>
      <source>new attribute</source>
      <translation>new attribute</translation>
    </message>
  </context>
  <context>
    <name>kernel/class/groupedit</name>
    <message>
      <source>New Group</source>
      <translation>New Group</translation>
    </message>
  </context>
  <context>
    <name>kernel/classe/datatypes/ezbinaryfile</name>
    <message>
      <source>Failed to store file %filename. Please contact the site administrator.</source>
      <translation>Failed to store file %filename. Please contact the site administrator.</translation>
    </message>
  </context>
  <context>
    <name>kernel/classe/datatypes/ezimage</name>
    <message>
      <source>Failed to fetch Image Handler. Please contact the site administrator.</source>
      <translation>Failed to fetch Image Handler. Please contact the site administrator.</translation>
    </message>
  </context>
  <context>
    <name>kernel/classe/datatypes/ezmedia</name>
    <message>
      <source>Failed to store media file %filename. Please contact the site administrator.</source>
      <translation>Failed to store media file %filename. Please contact the site administrator.</translation>
    </message>
  </context>
  <context>
    <name>kernel/classes</name>
    <message>
      <source>Approval</source>
      <translation>Approval</translation>
    </message>
    <message>
      <source>Standard</source>
      <translation>Standard</translation>
    </message>
    <message>
      <source>Observer</source>
      <translation>Observer</translation>
    </message>
    <message>
      <source>Owner</source>
      <translation>Owner</translation>
    </message>
    <message>
      <source>Approver</source>
      <translation>Approver</translation>
    </message>
    <message>
      <source>Author</source>
      <translation>Author</translation>
    </message>
    <message>
      <source>Inbox</source>
      <translation>Inbox</translation>
    </message>
    <message>
      <source>New RSS Export</source>
      <translation>New RSS Export</translation>
    </message>
    <message>
      <source>No state yet</source>
      <translation>No state yet</translation>
    </message>
    <message>
      <source>Workflow running</source>
      <translation>Workflow running</translation>
    </message>
    <message>
      <source>Workflow done</source>
      <translation>Workflow done</translation>
    </message>
    <message>
      <source>Workflow failed an event</source>
      <translation>Workflow failed an event</translation>
    </message>
    <message>
      <source>Workflow event deferred to cron job</source>
      <translation>Workflow event deferred to cron job</translation>
    </message>
    <message>
      <source>Workflow was cancelled</source>
      <translation>Workflow was cancelled</translation>
    </message>
    <message>
      <source>Workflow fetches template</source>
      <translation>Workflow fetches template</translation>
    </message>
    <message>
      <source>Workflow redirects user view</source>
      <translation>Workflow redirects user view</translation>
    </message>
    <message>
      <source>Workflow was reset for reuse</source>
      <translation>Workflow was reset for reuse</translation>
    </message>
    <message>
      <source>Accepted event</source>
      <translation>Accepted event</translation>
    </message>
    <message>
      <source>Rejected event</source>
      <translation>Rejected event</translation>
    </message>
    <message>
      <source>Event deferred to cron job</source>
      <translation>Event deferred to cron job</translation>
    </message>
    <message>
      <source>Event deferred to cron job, event will be rerun</source>
      <translation>Event deferred to cron job, event will be rerun</translation>
    </message>
    <message>
      <source>Event runs a sub event</source>
      <translation>Event runs a sub event</translation>
    </message>
    <message>
      <source>Cancelled whole workflow</source>
      <translation>Cancelled whole workflow</translation>
    </message>
  </context>
  <context>
    <name>kernel/classes/datatypes</name>
    <message>
      <source>Authors</source>
      <comment>Datatype name</comment>
      <translation>Authors</translation>
    </message>
    <message>
      <source>At least one author is required.</source>
      <translation>At least one author is required.</translation>
    </message>
    <message>
      <source>The author name must be provided.</source>
      <translation>The author name must be provided.</translation>
    </message>
    <message>
      <source>The email address is not valid.</source>
      <translation>The email address is not valid.</translation>
    </message>
    <message>
      <source>File</source>
      <comment>Datatype name</comment>
      <translation>File</translation>
    </message>
    <message>
      <source>File uploading is not enabled. Please contact the site administrator to enable it.</source>
      <translation>File uploading is not enabled. Please contact the site administrator to enable it.</translation>
    </message>
    <message>
      <source>A valid file is required.</source>
      <translation>A valid file is required.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.</source>
      <translation>The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds the maximum upload size: %1 bytes.</source>
      <translation>The size of the uploaded file exceeds the maximum upload size: %1 bytes.</translation>
    </message>
    <message>
      <source>Checkbox</source>
      <comment>Datatype name</comment>
      <translation>Checkbox</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation>Input required.</translation>
    </message>
    <message>
      <source>Country</source>
      <comment>Datatype name</comment>
      <translation>Country</translation>
    </message>
    <message>
      <source>Date</source>
      <comment>Datatype name</comment>
      <translation>Date</translation>
    </message>
    <message>
      <source>Date is not valid.</source>
      <translation>Date is not valid.</translation>
    </message>
    <message>
      <source>Missing date input.</source>
      <translation>Missing date input.</translation>
    </message>
    <message>
      <source>Date and time</source>
      <comment>Datatype name</comment>
      <translation>Date and time</translation>
    </message>
    <message>
      <source>Time is not valid.</source>
      <translation>Time is not valid.</translation>
    </message>
    <message>
      <source>Missing datetime input.</source>
      <translation>Missing datetime input.</translation>
    </message>
    <message>
      <source>E-mail</source>
      <comment>Datatype name</comment>
      <translation>E-mail</translation>
    </message>
    <message>
      <source>The email address is empty.</source>
      <translation>The email address is empty.</translation>
    </message>
    <message>
      <source>Enum</source>
      <comment>Datatype name</comment>
      <translation>Enum</translation>
    </message>
    <message>
      <source>At least one field should be chosen.</source>
      <translation>At least one field should be chosen.</translation>
    </message>
    <message>
      <source>Float</source>
      <comment>Datatype name</comment>
      <translation>Float</translation>
    </message>
    <message>
      <source>The given input is not a floating point number.</source>
      <translation>The given input is not a floating point number.</translation>
    </message>
    <message>
      <source>The input must be greater than %1</source>
      <translation>The input must be greater than %1</translation>
    </message>
    <message>
      <source>The input must be less than %1</source>
      <translation>The input must be less than %1</translation>
    </message>
    <message>
      <source>The input is not in defined range %1 - %2</source>
      <translation>The input is not in defined range %1 - %2</translation>
    </message>
    <message>
      <source>Identifier</source>
      <comment>Datatype name</comment>
      <translation>Identifier</translation>
    </message>
    <message>
      <source>image</source>
      <comment>Default image name</comment>
      <translation>image</translation>
    </message>
    <message>
      <source>Image</source>
      <comment>Datatype name</comment>
      <translation>Image</translation>
    </message>
    <message>
      <source>The image file must have non-zero size.</source>
      <translation>The image file must have non-zero size.</translation>
    </message>
    <message>
      <source>A valid image file is required.</source>
      <translation>A valid image file is required.</translation>
    </message>
    <message>
      <source>The size of the uploaded image exceeds limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
      <translation>The size of the uploaded image exceeds limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
      <translation>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</translation>
    </message>
    <message>
      <source>Ini Setting</source>
      <comment>Datatype name</comment>
      <translation>Ini Setting</translation>
    </message>
    <message>
      <source>Could not locate the ini file.</source>
      <translation>Could not locate the ini file.</translation>
    </message>
    <message>
      <source>Wrong text field value.</source>
      <translation>Wrong text field value.</translation>
    </message>
    <message>
      <source>Integer</source>
      <comment>Datatype name</comment>
      <translation>Integer</translation>
    </message>
    <message>
      <source>The input is not a valid integer.</source>
      <translation>The input is not a valid integer.</translation>
    </message>
    <message>
      <source>The number must be greater than %1</source>
      <translation>The number must be greater than %1</translation>
    </message>
    <message>
      <source>The number must be less than %1</source>
      <translation>The number must be less than %1</translation>
    </message>
    <message>
      <source>The number is not within the required range %1 - %2</source>
      <translation>The number is not within the required range %1 - %2</translation>
    </message>
    <message>
      <source>ISBN</source>
      <comment>Datatype name</comment>
      <translation>ISBN</translation>
    </message>
    <message>
      <source>The ISBN number is not correct. Please check the input for mistakes.</source>
      <translation>The ISBN number is not correct. Please check the input for mistakes.</translation>
    </message>
    <message>
      <source>Keywords</source>
      <comment>Datatype name</comment>
      <translation>Keywords</translation>
    </message>
    <message>
      <source>Matrix</source>
      <comment>Datatype name</comment>
      <translation>Matrix</translation>
    </message>
    <message>
      <source>Missing matrix input.</source>
      <translation>Missing matrix input.</translation>
    </message>
    <message>
      <source>Media</source>
      <comment>Datatype name</comment>
      <translation>Media</translation>
    </message>
    <message>
      <source>A valid media file is required.</source>
      <translation>A valid media file is required.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
      <translation>The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds site maximum: %1 bytes.</source>
      <translation>The size of the uploaded file exceeds site maximum: %1 bytes.</translation>
    </message>
    <message>
      <source>Multi-option</source>
      <comment>Datatype name</comment>
      <translation>Multi-option</translation>
    </message>
    <message>
      <source>The option value must be provided.</source>
      <translation>The option value must be provided.</translation>
    </message>
    <message>
      <source>The additional price for the multioption value is not valid.</source>
      <translation>The additional price for the multioption value is not valid.</translation>
    </message>
    <message>
      <source>At least one option is required.</source>
      <translation>At least one option is required.</translation>
    </message>
    <message>
      <source>Option set name is required.</source>
      <translation>Option set name is required.</translation>
    </message>
    <message>
      <source>Multi-price</source>
      <comment>Datatype name</comment>
      <translation>Multi-price</translation>
    </message>
    <message>
      <source>Dynamic VAT cannot be included.</source>
      <translation>Dynamic GST cannot be included.</translation>
    </message>
    <message>
      <source>Invalid price for '%currencyCode' currency </source>
      <translation>Invalid price for '%currencyCode' currency </translation>
    </message>
    <message>
      <source>Add to basket</source>
      <translation>Add to basket</translation>
    </message>
    <message>
      <source>Add to wish list</source>
      <translation>Add to wish list</translation>
    </message>
    <message>
      <source>Object relation</source>
      <comment>Datatype name</comment>
      <translation>Object relation</translation>
    </message>
    <message>
      <source>Missing objectrelation input.</source>
      <translation>Missing objectrelation input.</translation>
    </message>
    <message>
      <source>Object relations</source>
      <comment>Datatype name</comment>
      <translation>Object relations</translation>
    </message>
    <message>
      <source>Missing objectrelation list input.</source>
      <translation>Missing objectrelation list input.</translation>
    </message>
    <message>
      <source>Option</source>
      <comment>Datatype name</comment>
      <translation>Option</translation>
    </message>
    <message>
      <source>NAME is required.</source>
      <translation>NAME is required.</translation>
    </message>
    <message>
      <source>The Additional price value is not valid.</source>
      <translation>The Additional price value is not valid.</translation>
    </message>
    <message>
      <source>Package</source>
      <comment>Datatype name</comment>
      <translation>Package</translation>
    </message>
    <message>
      <source>Price</source>
      <comment>Datatype name</comment>
      <translation>Price</translation>
    </message>
    <message>
      <source>Invalid price.</source>
      <translation>Invalid price.</translation>
    </message>
    <message>
      <source>Product category</source>
      <comment>Datatype name</comment>
      <translation>Product category</translation>
    </message>
    <message>
      <source>Range option</source>
      <comment>Datatype name</comment>
      <translation>Range option</translation>
    </message>
    <message>
      <source>Missing range option input.</source>
      <translation>Missing range option input.</translation>
    </message>
    <message>
      <source>Selection</source>
      <comment>Datatype name</comment>
      <translation>Selection</translation>
    </message>
    <message>
      <source>Text line</source>
      <comment>Datatype name</comment>
      <translation>Text line</translation>
    </message>
    <message>
      <source>The input text is too long. The maximum number of characters allowed is %1.</source>
      <translation>The input text is too long. The maximum number of characters allowed is %1.</translation>
    </message>
    <message>
      <source>Subtree subscription</source>
      <comment>Datatype name</comment>
      <translation>Subtree subscription</translation>
    </message>
    <message>
      <source>Text block</source>
      <comment>Datatype name</comment>
      <translation>Text block</translation>
    </message>
    <message>
      <source>Time</source>
      <comment>Datatype name</comment>
      <translation>Time</translation>
    </message>
    <message>
      <source>Invalid time.</source>
      <translation>Invalid time.</translation>
    </message>
    <message>
      <source>Time input required.</source>
      <translation>Time input required.</translation>
    </message>
    <message>
      <source>URL</source>
      <comment>Datatype name</comment>
      <translation>URL</translation>
    </message>
    <message>
      <source>User account</source>
      <comment>Datatype name</comment>
      <translation>User account</translation>
    </message>
    <message>
      <source>The username must be specified.</source>
      <translation>The username must be specified.</translation>
    </message>
    <message>
      <source>The username already exists, please choose another one.</source>
      <translation>The username already exists, please choose another one.</translation>
    </message>
    <message>
      <source>A user with this email already exists.</source>
      <translation>A user with this email already exists.</translation>
    </message>
    <message>
      <source>The passwords do not match.</source>
      <comment>eZUserType</comment>
      <translation>The passwords do not match.</translation>
    </message>
    <message>
      <source>The password must be at least 3 characters long.</source>
      <translation>The password must be at least 3 characters long.</translation>
    </message>
    <message>
      <source>The password mustn't be &quot;password&quot;.</source>
      <translation>The password mustn't be &quot;password&quot;.</translation>
    </message>
    <message>
      <source>Cannot remove the account:</source>
      <translation>Cannot remove the account:</translation>
    </message>
    <message>
      <source>The account owner is currently logged in.</source>
      <translation>The account owner is currently logged in.</translation>
    </message>
    <message>
      <source>The account is currently used by the anonymous user.</source>
      <translation>The account is currently used by the anonymous user.</translation>
    </message>
    <message>
      <source>The account is currenty used the administrator user.</source>
      <translation>The account is currenty used the administrator user.</translation>
    </message>
    <message>
      <source>You can not remove the last class holding user accounts.</source>
      <translation>You can not remove the last class holding user accounts.</translation>
    </message>
    <message>
      <source>XML block</source>
      <comment>Datatype name</comment>
      <translation>XML block</translation>
    </message>
    <message>
      <source>Content required</source>
      <translation>Content required</translation>
    </message>
    <message>
      <source>Node %1 does not exist.</source>
      <translation>Node %1 does not exist.</translation>
    </message>
    <message>
      <source>Node '%1' does not exist.</source>
      <translation>Node '%1' does not exist.</translation>
    </message>
    <message>
      <source>Using scripts in links is not allowed, link '%1' has been removed</source>
      <translation>Using scripts in links is not allowed, link '%1' has been removed</translation>
    </message>
    <message>
      <source>Invalid e-mail address: '%1'</source>
      <translation>Invalid e-mail address: '%1'</translation>
    </message>
    <message>
      <source>Object %1 can not be embeded to itself.</source>
      <translation>Object %1 can not be embeded to itself.</translation>
    </message>
    <message>
      <source>Invalid reference in &amp;lt;embed&amp;gt; tag. Note that &lt;embed&gt; tag supports only 'eznode' and 'ezobject' protocols.</source>
      <translation>Invalid reference in &amp;lt;embed&amp;gt; tag. Note that &lt;embed&gt; tag supports only 'eznode' and 'ezobject' protocols.</translation>
    </message>
    <message>
      <source>Send</source>
      <comment>Datatype information collector action</comment>
      <translation>Send</translation>
    </message>
  </context>
  <context>
    <name>kernel/collaboration</name>
    <message>
      <source>Collaboration custom action</source>
      <translation>Collaboration custom action</translation>
    </message>
    <message>
      <source>Collaboration</source>
      <translation>Collaboration</translation>
    </message>
  </context>
  <context>
    <name>kernel/content</name>
    <message>
      <source>Top Level Nodes</source>
      <translation>Top Level Nodes</translation>
    </message>
    <message>
      <source>Hidden</source>
      <translation>Hidden</translation>
    </message>
    <message>
      <source>Hidden by superior</source>
      <translation>Hidden by superior</translation>
    </message>
    <message>
      <source>Visible</source>
      <translation>Visible</translation>
    </message>
    <message>
      <source>Content</source>
      <translation>Content</translation>
    </message>
    <message>
      <source>Media</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Search</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Advanced</translation>
    </message>
    <message>
      <source>A node in the node assignment list has been deleted.</source>
      <translation>A node in the node assignment list has been deleted.</translation>
    </message>
    <message>
      <source>No main node selected, please select one.</source>
      <translation>No main node selected, please select one.</translation>
    </message>
    <message>
      <source>My bookmarks</source>
      <translation>My bookmarks</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copy</translation>
    </message>
    <message>
      <source>Copy Subtree</source>
      <translation>Copy Subtree</translation>
    </message>
    <message>
      <source>Differences</source>
      <translation>Differences</translation>
    </message>
    <message>
      <source>My drafts</source>
      <translation>My drafts</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Keywords</source>
      <translation>Keywords</translation>
    </message>
    <message>
      <source>New content</source>
      <translation>New content</translation>
    </message>
    <message>
      <source>You are not allowed to place this object under: %1</source>
      <translation>You are not allowed to place this object under: %1</translation>
    </message>
    <message>
      <source>My pending list</source>
      <translation>My pending list</translation>
    </message>
    <message>
      <source>Remove location</source>
      <translation>Remove location</translation>
    </message>
    <message>
      <source>Remove editing version</source>
      <translation>Remove editing version</translation>
    </message>
    <message>
      <source>Remove object</source>
      <translation>Remove object</translation>
    </message>
    <message>
      <source>&quot;$contentObjectName&quot;: Sub items that are used by other objects</source>
      <translation>&quot;$contentObjectName&quot;: Sub items that are used by other objects</translation>
    </message>
    <message>
      <source>Tip from %1: %2</source>
      <translation>Tip from %1: %2</translation>
    </message>
    <message>
      <source>The email address of the sender is not valid</source>
      <translation>The email address of the sender is not valid</translation>
    </message>
    <message>
      <source>The email address of the receiver is not valid</source>
      <translation>The email address of the receiver is not valid</translation>
    </message>
    <message>
      <source>The receiver has already received the maximimum number of tipafriend mails the last hours</source>
      <translation>The receiver has already received the maximimum number of tipafriend mails the last hours</translation>
    </message>
    <message>
      <source>Tip a friend</source>
      <translation>Tip a friend</translation>
    </message>
    <message>
      <source>Remove translation</source>
      <translation>Remove translation</translation>
    </message>
    <message>
      <source>Translation</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>Content translations</source>
      <translation>Content translations</translation>
    </message>
    <message>
      <source>Languages</source>
      <translation>Languages</translation>
    </message>
    <message>
      <source>Trash</source>
      <translation>Trash</translation>
    </message>
    <message>
      <source>URL translator</source>
      <translation>URL translator</translation>
    </message>
    <message>
      <source>Versions</source>
      <translation>Versions</translation>
    </message>
    <message>
      <source>Version preview</source>
      <translation>Version preview</translation>
    </message>
  </context>
  <context>
    <name>kernel/content/copysubtree</name>
    <message>
      <source>Object (ID = %1) was not copied: you don't have permissions to read object.</source>
      <translation>Object (ID = %1) was not copied: you don't have permissions to read object.</translation>
    </message>
    <message>
      <source>Node (ID = %1) was not copied: you don't have permissions to read object (ID = %2).</source>
      <translation>Node (ID = %1) was not copied: you don't have permissions to read object (ID = %2).</translation>
    </message>
    <message>
      <source>Node (ID = %1) wasn't copied: parent node (ID = %2) wasn't copied.</source>
      <translation>Node (ID = %1) wasn't copied: parent node (ID = %2) wasn't copied.</translation>
    </message>
    <message>
      <source>Node (ID = %1) was not copied: you don't have permissions to create.</source>
      <translation>Node (ID = %1) was not copied: you don't have permissions to create.</translation>
    </message>
    <message>
      <source>Object (ID = %1) was not copied: no one nodes of object wasn't copied.</source>
      <translation>Object (ID = %1) was not copied: no one nodes of object wasn't copied.</translation>
    </message>
    <message>
      <source>Cannot publish object (ID = %1).</source>
      <translation>Cannot publish object (ID = %1).</translation>
    </message>
    <message>
      <source>Fatal error: cannot get subtree main node (ID = %1).</source>
      <translation>Fatal error: cannot get subtree main node (ID = %1).</translation>
    </message>
    <message>
      <source>Fatal error: cannot get destination node (ID = %1).</source>
      <translation>Fatal error: cannot get destination node (ID = %1).</translation>
    </message>
    <message>
      <source>Number of nodes of source subtree - %1</source>
      <translation>Number of nodes of source subtree - %1</translation>
    </message>
    <message>
      <source>Subtree was not copied.</source>
      <translation>Subtree was not copied.</translation>
    </message>
    <message>
      <source>Number of copied nodes - %1</source>
      <translation>Number of copied nodes - %1</translation>
    </message>
    <message>
      <source>Number of copied contentobjects - %1</source>
      <translation>Number of copied contentobjects - %1</translation>
    </message>
    <message>
      <source>Cannot create instance of eZDB to fix local links (related objects).</source>
      <translation>Cannot create instance of eZDB to fix local links (related objects).</translation>
    </message>
    <message>
      <source>Successfuly DONE.</source>
      <translation>Successfuly DONE.</translation>
    </message>
    <message>
      <source>You are trying to copy a subtree that contains more than the maximum possible nodes for subtree copying. You can copy this subtree using Subtree Copy script.</source>
      <translation>You are trying to copy a subtree that contains more than the maximum possible nodes for subtree copying. You can copy this subtree using Subtree Copy script.</translation>
    </message>
  </context>
  <context>
    <name>kernel/content/removenode</name>
    <message>
      <source>child</source>
      <comment>1 child</comment>
      <translation>child</translation>
    </message>
    <message>
      <source>children</source>
      <comment>several children</comment>
      <translation>children</translation>
    </message>
  </context>
  <context>
    <name>kernel/content/restore</name>
    <message>
      <source>Restore object</source>
      <translation>Restore object</translation>
    </message>
  </context>
  <context>
    <name>kernel/content/upload</name>
    <message>
      <source>The file %filename does not exist, cannot insert file.</source>
      <translation>The file %filename does not exist, cannot insert file.</translation>
    </message>
    <message>
      <source>There was an error trying to instantiate content upload handler.</source>
      <translation>There was an error trying to instantiate content upload handler.</translation>
    </message>
    <message>
      <source>No matching class identifier found.</source>
      <translation>No matching class identifier found.</translation>
    </message>
    <message>
      <source>The class %class_identifier does not exist.</source>
      <translation>The class %class_identifier does not exist.</translation>
    </message>
    <message>
      <source>Was not able to figure out placement of object.</source>
      <translation>Was not able to figure out placement of object.</translation>
    </message>
    <message>
      <source>No configuration group in upload.ini for class identifier %class_identifier.</source>
      <translation>No configuration group in upload.ini for class identifier %class_identifier.</translation>
    </message>
    <message>
      <source>No matching file attribute found, cannot create content object without this.</source>
      <translation>No matching file attribute found, cannot create content object without this.</translation>
    </message>
    <message>
      <source>No matching name attribute found, cannot create content object without this.</source>
      <translation>No matching name attribute found, cannot create content object without this.</translation>
    </message>
    <message>
      <source>Permission denied</source>
      <translation>Permission denied</translation>
    </message>
    <message>
      <source>The attribute %class_identifier does not support regular file storage.</source>
      <translation>The attribute %class_identifier does not support regular file storage.</translation>
    </message>
    <message>
      <source>The attribute %class_identifier does not support simple string storage.</source>
      <translation>The attribute %class_identifier does not support simple string storage.</translation>
    </message>
    <message>
      <source>No HTTP file found, cannot fetch uploaded file.</source>
      <translation>No HTTP file found, cannot fetch uploaded file.</translation>
    </message>
    <message>
      <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
      <translation>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</translation>
    </message>
    <message>
      <source>The attribute %class_identifier does not support HTTP file storage.</source>
      <translation>The attribute %class_identifier does not support HTTP file storage.</translation>
    </message>
    <message>
      <source>Publishing of content object was halted.</source>
      <translation>Publishing of content object was halted.</translation>
    </message>
    <message>
      <source>Publish process was cancelled.</source>
      <translation>Publish process was cancelled.</translation>
    </message>
    <message>
      <source>A file is required for upload, no file were found.</source>
      <translation>A file is required for upload, no file were found.</translation>
    </message>
    <message>
      <source>Expected a eZHTTPFile object but got nothing.</source>
      <translation>Expected a eZHTTPFile object but got nothing.</translation>
    </message>
    <message>
      <source>Could not find content upload handler '%handler_name'</source>
      <translation>Could not find content upload handler '%handler_name'</translation>
    </message>
  </context>
  <context>
    <name>kernel/contentclass</name>
    <message>
      <source>New %1</source>
      <translation>New %1</translation>
    </message>
    <message>
      <source>Cannot remove class '%class_name':</source>
      <translation>Cannot remove class '%class_name':</translation>
    </message>
    <message>
      <source>The class is used by a top-level node and cannot be removed.</source>
      <translation>The class is used by a top-level node and cannot be removed.</translation>
    </message>
  </context>
  <context>
    <name>kernel/design</name>
    <message>
      <source>Template list</source>
      <translation>Template list</translation>
    </message>
    <message>
      <source>Template view</source>
      <translation>Template view</translation>
    </message>
    <message>
      <source>Create new template</source>
      <translation>Create new template</translation>
    </message>
    <message>
      <source>Template edit</source>
      <translation>Template edit</translation>
    </message>
    <message>
      <source>Toolbar list</source>
      <translation>Toolbar list</translation>
    </message>
  </context>
  <context>
    <name>kernel/error</name>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
  </context>
  <context>
    <name>kernel/ezinfo</name>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>About</source>
      <translation>About</translation>
    </message>
    <message>
      <source>Copyright</source>
      <translation>Copyright</translation>
    </message>
  </context>
  <context>
    <name>kernel/form</name>
    <message>
      <source>Form processing</source>
      <translation>Form processing</translation>
    </message>
  </context>
  <context>
    <name>kernel/infocollector</name>
    <message>
      <source>Collected information</source>
      <translation>Collected information</translation>
    </message>
  </context>
  <context>
    <name>kernel/navigationpart</name>
    <message>
      <source>Content structure</source>
      <comment>Navigation part</comment>
      <translation>Content structure</translation>
    </message>
    <message>
      <source>Media library</source>
      <comment>Navigation part</comment>
      <translation>Media library</translation>
    </message>
    <message>
      <source>User accounts</source>
      <comment>Navigation part</comment>
      <translation>User accounts</translation>
    </message>
    <message>
      <source>Webshop</source>
      <comment>Navigation part</comment>
      <translation>Webshop</translation>
    </message>
    <message>
      <source>Design</source>
      <comment>Navigation part</comment>
      <translation>Design</translation>
    </message>
    <message>
      <source>Setup</source>
      <comment>Navigation part</comment>
      <translation>Setup</translation>
    </message>
    <message>
      <source>My account</source>
      <comment>Navigation part</comment>
      <translation>My account</translation>
    </message>
  </context>
  <context>
    <name>kernel/notification</name>
    <message>
      <source>Notification settings</source>
      <translation>Notification settings</translation>
    </message>
  </context>
  <context>
    <name>kernel/package</name>
    <message>
      <source>Lead</source>
      <translation>Lead</translation>
    </message>
    <message>
      <source>Developer</source>
      <translation>Developer</translation>
    </message>
    <message>
      <source>Designer</source>
      <translation>Designer</translation>
    </message>
    <message>
      <source>Contributor</source>
      <translation>Contributor</translation>
    </message>
    <message>
      <source>Tester</source>
      <translation>Tester</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Local</translation>
    </message>
    <message>
      <source>Package information</source>
      <translation>Package information</translation>
    </message>
    <message>
      <source>Package maintainer</source>
      <translation>Package maintainer</translation>
    </message>
    <message>
      <source>Package changelog</source>
      <translation>Package changelog</translation>
    </message>
    <message>
      <source>Package thumbnail</source>
      <translation>Package thumbnail</translation>
    </message>
    <message>
      <source>Package name</source>
      <translation>Package name</translation>
    </message>
    <message>
      <source>Package name is missing</source>
      <translation>Package name is missing</translation>
    </message>
    <message>
      <source>A package named %packagename already exists, please give another name</source>
      <translation>A package named %packagename already exists, please give another name</translation>
    </message>
    <message>
      <source>The package name %packagename is not valid, it can only contain characters in the range a-z, 0-9 and underscore.</source>
      <translation>The package name %packagename is not valid, it can only contain characters in the range a-z, 0-9 and underscore.</translation>
    </message>
    <message>
      <source>Summary</source>
      <translation>Summary</translation>
    </message>
    <message>
      <source>Summary is missing</source>
      <translation>Summary is missing</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>The version must only contain numbers (optionally followed by text) and must be delimited by dots (.), e.g. 1.0, 3.4.0beta1</source>
      <translation>The version must only contain numbers (optionally followed by text) and must be delimited by dots (.), e.g. 1.0, 3.4.0beta1</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>You must enter a name for the changelog</source>
      <translation>You must enter a name for the changelog</translation>
    </message>
    <message>
      <source>E-Mail</source>
      <translation>E-Mail</translation>
    </message>
    <message>
      <source>You must enter an e-mail for the changelog</source>
      <translation>You must enter an e-mail for the changelog</translation>
    </message>
    <message>
      <source>Changelog</source>
      <translation>Changelog</translation>
    </message>
    <message>
      <source>You must supply some text for the changelog entry</source>
      <translation>You must supply some text for the changelog entry</translation>
    </message>
    <message>
      <source>You must enter a name of the maintainer</source>
      <translation>You must enter a name of the maintainer</translation>
    </message>
    <message>
      <source>You must enter an e-mail address of the maintainer</source>
      <translation>You must enter an e-mail address of the maintainer</translation>
    </message>
    <message>
      <source>Content classes to include</source>
      <translation>Content classes to include</translation>
    </message>
    <message>
      <source>Content class export</source>
      <translation>Content class export</translation>
    </message>
    <message>
      <source>Class list</source>
      <translation>Class list</translation>
    </message>
    <message>
      <source>You must select at least one class for inclusion</source>
      <translation>You must select at least one class for inclusion</translation>
    </message>
    <message>
      <source>Content objects to include</source>
      <translation>Content objects to include</translation>
    </message>
    <message>
      <source>Content object limits</source>
      <translation>Content object limits</translation>
    </message>
    <message>
      <source>Content object export</source>
      <translation>Content object export</translation>
    </message>
    <message>
      <source>Selected nodes</source>
      <translation>Selected nodes</translation>
    </message>
    <message>
      <source>You must select one or more node(s)/subtree(s) for export.</source>
      <translation>You must select one or more node(s)/subtree(s) for export.</translation>
    </message>
    <message>
      <source>You must choose one or more languages.</source>
      <translation>You must choose one or more languages.</translation>
    </message>
    <message>
      <source>You must choose one or more site access.</source>
      <translation>You must choose one or more site access.</translation>
    </message>
    <message>
      <source>Select an extension to be exported</source>
      <translation>Select an extension to be exported</translation>
    </message>
    <message>
      <source>Extension export</source>
      <translation>Extension export</translation>
    </message>
    <message>
      <source>Extension:</source>
      <translation>Extension:</translation>
    </message>
    <message>
      <source>You must select an extension</source>
      <translation>You must select an extension</translation>
    </message>
    <message>
      <source>CSS files</source>
      <translation>CSS files</translation>
    </message>
    <message>
      <source>Image files</source>
      <translation>Image files</translation>
    </message>
    <message>
      <source>Site style</source>
      <translation>Site style</translation>
    </message>
    <message>
      <source>CSS file</source>
      <translation>CSS file</translation>
    </message>
    <message>
      <source>You must upload both CSS files</source>
      <translation>You must upload both CSS files</translation>
    </message>
    <message>
      <source>File did not have a .css suffix, this is most likely not a CSS file</source>
      <translation>File did not have a .css suffix, this is most likely not a CSS file</translation>
    </message>
    <message>
      <source>Content class %classname (%classidentifier)</source>
      <translation>Content class %classname (%classidentifier)</translation>
    </message>
    <message>
      <source>Removing class '%classname' will result in the removal of %objectscount object(s) of this class and all their sub-items. Are you sure you want to uninstall it?</source>
      <translation>Removing class '%classname' will result in the removal of %objectscount object(s) of this class and all their sub-items. Are you sure you want to uninstall it?</translation>
    </message>
    <message>
      <source>Class '%classname' already exists.</source>
      <translation>Class '%classname' already exists.</translation>
    </message>
    <message>
      <source>Replace existing class</source>
      <translation>Replace existing class</translation>
    </message>
    <message>
      <source>(Warning! $objectsCount content object(s) and their sub-items will be removed)</source>
      <translation>(Warning! $objectsCount content object(s) and their sub-items will be removed)</translation>
    </message>
    <message>
      <source>Skip installing this class</source>
      <translation>Skip installing this class</translation>
    </message>
    <message>
      <source>Keep existing and create a new one</source>
      <translation>Keep existing and create a new one</translation>
    </message>
    <message>
      <source>%number content objects</source>
      <translation>%number content objects</translation>
    </message>
    <message>
      <source>Content object %objectname</source>
      <translation>Content object %objectname</translation>
    </message>
    <message>
      <source>Object '%objectname' has been modified since installation. Are you sure you want to remove it?</source>
      <translation>Object '%objectname' has been modified since installation. Are you sure you want to remove it?</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>Keep object</source>
      <translation>Keep object</translation>
    </message>
    <message>
      <source>Object '%objectname' has %childrencount sub-item(s) that will be removed.</source>
      <translation>Object '%objectname' has %childrencount sub-item(s) that will be removed.</translation>
    </message>
    <message>
      <source>Remove object and it's sub-item(s)</source>
      <translation>Remove object and it's sub-item(s)</translation>
    </message>
    <message>
      <source>Extension '%extensionname'</source>
      <translation>Extension '%extensionname'</translation>
    </message>
    <message>
      <source>Extension '%extensionname' already exists.</source>
      <translation>Extension '%extensionname' already exists.</translation>
    </message>
    <message>
      <source>Replace extension</source>
      <translation>Replace extension</translation>
    </message>
    <message>
      <source>Skip</source>
      <translation>Skip</translation>
    </message>
    <message>
      <source>Install script: %description</source>
      <translation>Install script: %description</translation>
    </message>
    <message>
      <source>Site access mapping</source>
      <translation>Site access mapping</translation>
    </message>
    <message>
      <source>Top node placements</source>
      <translation>Top node placements</translation>
    </message>
    <message>
      <source>Content object import</source>
      <translation>Content object import</translation>
    </message>
    <message>
      <source>Select parent nodes</source>
      <translation>Select parent nodes</translation>
    </message>
    <message>
      <source>You must assign all nodes to new parent nodes.</source>
      <translation>You must assign all nodes to new parent nodes.</translation>
    </message>
    <message>
      <source>Create package</source>
      <translation>Create package</translation>
    </message>
    <message>
      <source>Packages</source>
      <translation>Packages</translation>
    </message>
    <message>
      <source>Install</source>
      <translation>Install</translation>
    </message>
    <message>
      <source>Uninstall</source>
      <translation>Uninstall</translation>
    </message>
    <message>
      <source>Package %packagename already exists, cannot import the package</source>
      <translation>Package %packagename already exists, cannot import the package</translation>
    </message>
    <message>
      <source>Upload</source>
      <translation>Upload</translation>
    </message>
  </context>
  <context>
    <name>kernel/pdf</name>
    <message>
      <source>An export with such filename already exists.</source>
      <translation>An export with such filename already exists.</translation>
    </message>
    <message>
      <source>PDF Export</source>
      <translation>PDF Export</translation>
    </message>
  </context>
  <context>
    <name>kernel/pdfexport</name>
    <message>
      <source>New PDF Export</source>
      <translation>New PDF Export</translation>
    </message>
  </context>
  <context>
    <name>kernel/reference</name>
    <message>
      <source>Reference documentation</source>
      <translation>Reference documentation</translation>
    </message>
  </context>
  <context>
    <name>kernel/role</name>
    <message>
      <source>Limit on section</source>
      <translation>Limit on section</translation>
    </message>
    <message>
      <source>Create new policy, step 2: select function</source>
      <translation>Create new policy, step 2: select function</translation>
    </message>
    <message>
      <source>Create new policy, step three: set function limitations</source>
      <translation>Create new policy, step three: set function limitations</translation>
    </message>
    <message>
      <source>Create new policy, step two: select function</source>
      <translation>Create new policy, step two: select function</translation>
    </message>
    <message>
      <source>Create new policy, step one: select module</source>
      <translation>Create new policy, step one: select module</translation>
    </message>
    <message>
      <source>Role list</source>
      <translation>Role list</translation>
    </message>
    <message>
      <source>Editing policy</source>
      <translation>Editing policy</translation>
    </message>
  </context>
  <context>
    <name>kernel/role/edit</name>
    <message>
      <source>Copy of %rolename</source>
      <translation>Copy of %rolename</translation>
    </message>
    <message>
      <source>New role</source>
      <translation>New role</translation>
    </message>
  </context>
  <context>
    <name>kernel/rss</name>
    <message>
      <source>New RSS Export</source>
      <translation>New RSS Export</translation>
    </message>
    <message>
      <source>New RSS Import</source>
      <translation>New RSS Import</translation>
    </message>
    <message>
      <source>Really Simple Syndication</source>
      <translation>Really Simple Syndication</translation>
    </message>
  </context>
  <context>
    <name>kernel/search</name>
    <message>
      <source>Search stats</source>
      <translation>Search stats</translation>
    </message>
  </context>
  <context>
    <name>kernel/section</name>
    <message>
      <source>New section</source>
      <translation>New section</translation>
    </message>
    <message>
      <source>Edit Section</source>
      <translation>Edit Section</translation>
    </message>
    <message>
      <source>Sections</source>
      <translation>Sections</translation>
    </message>
    <message>
      <source>View section</source>
      <translation>View section</translation>
    </message>
  </context>
  <context>
    <name>kernel/setup</name>
    <message>
      <source>Cache admin</source>
      <translation>Cache admin</translation>
    </message>
    <message>
      <source>Datatype wizard</source>
      <translation>Datatype wizard</translation>
    </message>
    <message>
      <source>Extension configuration</source>
      <translation>Extension configuration</translation>
    </message>
    <message>
      <source>System information</source>
      <translation>System information</translation>
    </message>
    <message>
      <source>Rapid Application Development</source>
      <translation>Rapid Application Development</translation>
    </message>
    <message>
      <source>Session admin</source>
      <translation>Session admin</translation>
    </message>
    <message>
      <source>Setup menu</source>
      <translation>Setup menu</translation>
    </message>
    <message>
      <source>File %1 does not exist. You should copy it from the recent eZ Publish distribution.</source>
      <translation>File %1 does not exist. You should copy it from the recent eZ Publish distribution.</translation>
    </message>
    <message>
      <source>System Upgrade</source>
      <translation>System Upgrade</translation>
    </message>
    <message>
      <source>Template operator wizard</source>
      <translation>Template operator wizard</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop</name>
    <message>
      <source>Order status</source>
      <translation>Order status</translation>
    </message>
    <message>
      <source>Undefined</source>
      <translation>Undefined</translation>
    </message>
    <message>
      <source>Any</source>
      <translation>Any</translation>
    </message>
    <message>
      <source>VAT type</source>
      <translation>GST type</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Order list</source>
      <translation>Order list</translation>
    </message>
    <message>
      <source>Basket</source>
      <translation>Basket</translation>
    </message>
    <message>
      <source>Checkout</source>
      <translation>Checkout</translation>
    </message>
    <message>
      <source>'Autorates' were retrieved successfully</source>
      <translation>'Autorates' were retrieved successfully</translation>
    </message>
    <message>
      <source>Unknown body format in HTTP response. Expected 'text/xml'</source>
      <translation>Unknown body format in HTTP response. Expected 'text/xml'</translation>
    </message>
    <message>
      <source>Invalid HTTP response</source>
      <translation>Invalid HTTP response</translation>
    </message>
    <message>
      <source>Unable to send http request: %1:%2/%3</source>
      <translation>Unable to send http request: %1:%2/%3</translation>
    </message>
    <message>
      <source>eZExchangeRatesUpdateHandler: you should reimplement 'requestRates' method</source>
      <translation>eZExchangeRatesUpdateHandler: you should reimplement 'requestRates' method</translation>
    </message>
    <message>
      <source>'Auto' prices were updated successfully.</source>
      <translation>'Auto' prices were updated successfully.</translation>
    </message>
    <message>
      <source>'Auto' rates were updated successfully.</source>
      <translation>'Auto' rates were updated successfully.</translation>
    </message>
    <message>
      <source>Unable to calculate cross-rate for currency-pair '%1'/'%2'</source>
      <translation>Unable to calculate cross-rate for currency-pair '%1'/'%2'</translation>
    </message>
    <message>
      <source>Unable to determine currency for retrieved rates.</source>
      <translation>Unable to determine currency for retrieved rates.</translation>
    </message>
    <message>
      <source>Retrieved empty list of rates.</source>
      <translation>Retrieved empty list of rates.</translation>
    </message>
    <message>
      <source>Unable to create handler to update auto rates.</source>
      <translation>Unable to create handler to update auto rates.</translation>
    </message>
    <message>
      <source>Confirm order</source>
      <translation>Confirm order</translation>
    </message>
    <message>
      <source>The confirm order operation was canceled. Try to checkout again.</source>
      <translation>The confirm order operation was canceled. Try to checkout again.</translation>
    </message>
    <message>
      <source>Changes were stored successfully.</source>
      <translation>Changes were stored successfully.</translation>
    </message>
    <message>
      <source>Available currency list</source>
      <translation>Available currency list</translation>
    </message>
    <message>
      <source>Customer list</source>
      <translation>Customer list</translation>
    </message>
    <message>
      <source>Customer order view</source>
      <translation>Customer order view</translation>
    </message>
    <message>
      <source>Discount group</source>
      <translation>Discount group</translation>
    </message>
    <message>
      <source>Classes</source>
      <translation>Classes</translation>
    </message>
    <message>
      <source>Any class</source>
      <translation>Any class</translation>
    </message>
    <message>
      <source>in sections</source>
      <translation>in sections</translation>
    </message>
    <message>
      <source>in any section</source>
      <translation>in any section</translation>
    </message>
    <message>
      <source>Products</source>
      <translation>Products</translation>
    </message>
    <message>
      <source>Any product</source>
      <translation>Any product</translation>
    </message>
    <message>
      <source>Group view of discount rule</source>
      <translation>Group view of discount rule</translation>
    </message>
    <message>
      <source>Editing rule</source>
      <translation>Editing rule</translation>
    </message>
    <message>
      <source>Edit currency</source>
      <translation>Edit currency</translation>
    </message>
    <message>
      <source>Create new currency</source>
      <translation>Create new currency</translation>
    </message>
    <message>
      <source>Error checking out</source>
      <translation>Error checking out</translation>
    </message>
    <message>
      <source>Unable to calculate VAT percentage because your country is unknown. You can either fill country manually in your account information (if you are a registered user) or contact site administrator.</source>
      <translation>Unable to calculate GST percentage because your country is unknown. You can either fill country manually in your account information (if you are a registered user) or contact site administrator.</translation>
    </message>
    <message>
      <source>Shipping</source>
      <translation>Shipping</translation>
    </message>
    <message>
      <source>Statistics</source>
      <translation>Statistics</translation>
    </message>
    <message>
      <source>Order #%order_id</source>
      <translation>Order #%order_id</translation>
    </message>
    <message>
      <source>Preferred currency</source>
      <translation>Preferred currency</translation>
    </message>
    <message>
      <source>Products overview</source>
      <translation>Products overview</translation>
    </message>
    <message>
      <source>Enter account information</source>
      <translation>Enter account information</translation>
    </message>
    <message>
      <source>Remove order</source>
      <translation>Remove order</translation>
    </message>
    <message>
      <source>New order status was successfully added.</source>
      <translation>New order status was successfully added.</translation>
    </message>
    <message>
      <source>Changes to order status were successfully stored.</source>
      <translation>Changes to order status were successfully stored.</translation>
    </message>
    <message>
      <source>Selected order statuses were successfully removed.</source>
      <translation>Selected order statuses were successfully removed.</translation>
    </message>
    <message>
      <source>Internal orders cannot be removed.</source>
      <translation>Internal orders cannot be removed.</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>VAT types</source>
      <translation>GST types</translation>
    </message>
    <message>
      <source>Wishlist</source>
      <translation>Wishlist</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/classes/ezcurrencydata</name>
    <message>
      <source>Invalid characters in currency code.</source>
      <translation>Invalid characters in currency code.</translation>
    </message>
    <message>
      <source>Currency already exists.</source>
      <translation>Currency already exists.</translation>
    </message>
    <message>
      <source>Unknown error.</source>
      <translation>Unknown error.</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/discountgroup</name>
    <message>
      <source>New discount group</source>
      <translation>New discount group</translation>
    </message>
    <message>
      <source>New Discount Rule</source>
      <translation>New Discount Rule</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/editvatrule</name>
    <message>
      <source>Invalid data entered</source>
      <translation>Invalid data entered</translation>
    </message>
    <message>
      <source>Choose a country.</source>
      <translation>Choose a country.</translation>
    </message>
    <message>
      <source>Choose a VAT type.</source>
      <translation>Choose a GST type.</translation>
    </message>
    <message>
      <source>Conflicting rule</source>
      <translation>Conflicting rule</translation>
    </message>
    <message>
      <source>Default rule for any country already exists.</source>
      <translation>Default rule for any country already exists.</translation>
    </message>
    <message>
      <source>Rule not found</source>
      <translation>Rule not found</translation>
    </message>
    <message>
      <source>Edit VAT charging rule</source>
      <translation>Edit GST charging rule</translation>
    </message>
    <message>
      <source>Create new VAT charging rule</source>
      <translation>Create new GST charging rule</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/productcategories</name>
    <message>
      <source>Product category</source>
      <translation>Product category</translation>
    </message>
    <message>
      <source>Empty category names are not allowed (corrected).</source>
      <translation>Empty category names are not allowed (corrected).</translation>
    </message>
    <message>
      <source>Product categories</source>
      <translation>Product categories</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/vatrules</name>
    <message>
      <source>No default rule found. Please add rule having &quot;Any&quot; country and &quot;Any&quot; category.</source>
      <translation>No default rule found. Please add rule having &quot;Any&quot; country and &quot;Any&quot; category.</translation>
    </message>
    <message>
      <source>VAT rules</source>
      <translation>GST rules</translation>
    </message>
  </context>
  <context>
    <name>kernel/shop/vattype</name>
    <message>
      <source>Empty VAT type names are not allowed (corrected).</source>
      <translation>Empty GST type names are not allowed (corrected).</translation>
    </message>
    <message>
      <source>Wrong VAT percentage (corrected).</source>
      <translation>Wrong GST percentage (corrected).</translation>
    </message>
  </context>
  <context>
    <name>kernel/trigger</name>
    <message>
      <source>Trigger</source>
      <translation>Trigger</translation>
    </message>
    <message>
      <source>List</source>
      <translation>List</translation>
    </message>
  </context>
  <context>
    <name>kernel/url</name>
    <message>
      <source>URL edit</source>
      <translation>URL edit</translation>
    </message>
    <message>
      <source>URL</source>
      <translation>URL</translation>
    </message>
    <message>
      <source>List</source>
      <translation>List</translation>
    </message>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
  </context>
  <context>
    <name>kernel/user</name>
    <message>
      <source>User</source>
      <translation>User</translation>
    </message>
    <message>
      <source>Activate</source>
      <translation>Activate</translation>
    </message>
    <message>
      <source>User profile</source>
      <translation>User profile</translation>
    </message>
    <message>
      <source>Forgot password</source>
      <translation>Forgot password</translation>
    </message>
    <message>
      <source>Login</source>
      <translation>Login</translation>
    </message>
    <message>
      <source>Change password</source>
      <translation>Change password</translation>
    </message>
    <message>
      <source>Register</source>
      <translation>Register</translation>
    </message>
    <message>
      <source>Setting</source>
      <translation>Setting</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Success</translation>
    </message>
  </context>
  <context>
    <name>kernel/user/register</name>
    <message>
      <source>Registration info</source>
      <translation>Registration info</translation>
    </message>
    <message>
      <source>New user registered</source>
      <translation>New user registered</translation>
    </message>
  </context>
  <context>
    <name>kernel/workflow</name>
    <message>
      <source>You have to have at least one group that the workflow belongs to!</source>
      <translation>You have to have at least one group that the workflow belongs to!</translation>
    </message>
    <message>
      <source>Edit workflow</source>
      <translation>Edit workflow</translation>
    </message>
    <message>
      <source>Workflow</source>
      <translation>Workflow</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>Edit workflow group</source>
      <translation>Edit workflow group</translation>
    </message>
    <message>
      <source>Group edit</source>
      <translation>Group edit</translation>
    </message>
    <message>
      <source>Workflow group list</source>
      <translation>Workflow group list</translation>
    </message>
    <message>
      <source>Group list</source>
      <translation>Group list</translation>
    </message>
    <message>
      <source>Workflow list</source>
      <translation>Workflow list</translation>
    </message>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
    <message>
      <source>Workflow list of group</source>
      <translation>Workflow list of group</translation>
    </message>
    <message>
      <source>List</source>
      <translation>List</translation>
    </message>
  </context>
  <context>
    <name>kernel/workflow/edit</name>
    <message>
      <source>New Workflow</source>
      <translation>New Workflow</translation>
    </message>
  </context>
  <context>
    <name>kernel/workflow/event</name>
    <message>
      <source>Event</source>
      <translation>Event</translation>
    </message>
    <message>
      <source>Approve</source>
      <translation>Approve</translation>
    </message>
    <message>
      <source>Multiplexer</source>
      <translation>Multiplexer</translation>
    </message>
    <message>
      <source>Payment Gateway</source>
      <translation>Payment Gateway</translation>
    </message>
    <message>
      <source>Simple shipping</source>
      <translation>Simple shipping</translation>
    </message>
    <message>
      <source>Wait until date</source>
      <translation>Wait until date</translation>
    </message>
  </context>
  <context>
    <name>kernel/workflow/group</name>
    <message>
      <source>Group</source>
      <translation>Group</translation>
    </message>
  </context>
  <context>
    <name>kernel/workflow/groupedit</name>
    <message>
      <source>New WorkflowGroup</source>
      <translation>New WorkflowGroup</translation>
    </message>
  </context>
  <context>
    <name>lib/ezpdf/classes</name>
    <message>
      <source>Contents</source>
      <comment>Table of contents</comment>
      <translation>Contents</translation>
    </message>
    <message>
      <source>Index</source>
      <comment>Keyword index name</comment>
      <translation>Index</translation>
    </message>
  </context>
  <context>
    <name>lib/eztemplate</name>
    <message>
      <source>Some template errors occured, see debug for more information.</source>
      <translation>Some template errors occured, see debug for more information.</translation>
    </message>
  </context>
  <context>
    <name>lib/template</name>
    <message>
      <source>The maximum nesting level of 40 has been reached. The execution is stopped to avoid infinite recursion.</source>
      <translation>The maximum nesting level of 40 has been reached. The execution is stopped to avoid infinite recursion.</translation>
    </message>
  </context>
  <context>
    <name>pdf/edit</name>
    <message>
      <source>PDF Export</source>
      <translation>PDF Export</translation>
    </message>
  </context>
  <context>
    <name>settings/edit</name>
    <message>
      <source>Settings</source>
      <translation>Settings</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Edit</translation>
    </message>
  </context>
  <context>
    <name>settings/view</name>
    <message>
      <source>Settings</source>
      <translation>Settings</translation>
    </message>
    <message>
      <source>View</source>
      <translation>View</translation>
    </message>
  </context>
  <context>
    <name>shop</name>
    <message>
      <source>Remove orders</source>
      <translation>Remove orders</translation>
    </message>
  </context>
  <context>
    <name>simplified_treemenu/show_simplified_menu</name>
    <message>
      <source>Node ID: %node_id Visibility: %visibility</source>
      <translation>Node ID: %node_id Visibility: %visibility</translation>
    </message>
  </context>
</TS>
