<?php /* #?ini charset="iso-8859-1"?

[orfilter]
ExtensionName=oworfilter
ClassName=ORExtendedFilter
MethodName=CreateSqlParts
FileName=classes/orfilter.php

*/ ?>