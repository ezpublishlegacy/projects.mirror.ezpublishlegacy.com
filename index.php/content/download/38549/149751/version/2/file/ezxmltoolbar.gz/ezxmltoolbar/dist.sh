#!/bin/bash
EXTENSION_NAME="XML text toolbar"
EXTENSION_IDENTIFIER="ezxmltoolbar"
EXTENSION_SUMMARY="Toolbar which allows to show specified XML text attribute of conetnt object as toolbar."
EXTENSION_LICENSE="GPL/eZ publish professional licence"
EXTENSION_VERSION="1.0"
EXTENSION_PUBLISH_VERSION="3.5"
EXTENSION_ARCHIVE_NAME="ezxmltoolbar"
EXTENSION_PHP_VERSION="4.3.2"

