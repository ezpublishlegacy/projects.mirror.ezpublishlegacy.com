<?php
/**
 * File containing SQLICSVException class
 * @copyright Copyright (C) 2010 - SQLi Agency. All rights reserved
 * @licence http://www.gnu.org/licenses/gpl-2.0.txt GNU GPLv2
 * @author Jerome Vieilledent
 * @version 1.2.1
 * @package sqliimport
 * @subpackage sourcehandlers
 * @subpackage csv
 */

class SQLICSVException extends SQLIImportBaseException
{
    
}
