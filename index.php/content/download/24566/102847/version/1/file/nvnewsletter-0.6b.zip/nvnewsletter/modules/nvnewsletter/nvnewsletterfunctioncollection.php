<?php
/**
 * File containing the nvNewsletterFunctionCollection class
 * @package nvNewsletter
 */
class nvNewsletterFunctionCollection {
    function __construct() {
    }

    function fetchSenderCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletterSender::definition(),
                array(), array( 'status' => nvNewsletterSender::StatusPublished ), null, null, false, false, $customOperation);

        return array('result' => $rows[0]['count']);
    }

    function fetchReceiverGroupCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletterReceiverGroup::definition(),
                array(), array( 'status' => nvNewsletterReceiverGroup::StatusPublished ), null, null, false, false, $customOperation);

        return array('result' => $rows[0]['count']);
    }
    
    function fetchUnsubscribedCount() {
        $result = nvNewsletterReceiver::getUnsubscribedCount();
        return array('result' => $result);
    }

    function fetchReceiverCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletterReceiver::definition(),
                array(), array( 'status' => nvNewsletterReceiver::StatusPublished ), null, null, false, false, $customOperation);

        return array('result' => $rows[0]['count']);
    }

    function fetchReceiverFieldCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletterReceiverField::definition(),
                array(), array( 'status' => nvNewsletterReceiverField::StatusPublished ), null, null, false, false, $customOperation);

        return array('result' => $rows[0]['count']);
    }

    function fetchSentNewsletterCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletter::definition(),
                array(), array('status' => nvNewsletter::StatusSent), null, null, false, false,
                $customOperation);

        return array('result' => $rows[0]['count']);
    }

    function fetchInProgressNewsletterCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletter::definition(), 
                array(), null, null, null, false, false, $customOperation, false, ' WHERE status = '.nvNewsletter::StatusInProgress.' OR status = '.nvNewsletter::StatusSending);

        return array('result' => $rows[0]['count']);
    }

    function fetchDraftsNewsletterCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletter::definition(),
                array(), array('status' => nvNewsletter::StatusDraft), null, null, false, false,
                $customOperation);

        return array('result' => $rows[0]['count']);
    }

    function fetchFailedNewsletterCount() {
        $customOperation = array(array(
                    'operation' => 'count(*)',
                    'name' => 'count'));
        $rows = eZPersistentObject::fetchObjectList(nvNewsletter::definition(),
                array(), array('status' => nvNewsletter::StatusFailed), null, null, false, false,
                $customOperation);

        return array('result' => $rows[0]['count']);
    }
    
    function fetchGroups( $offset, $limit ) {
        $rows = nvNewsletterReceiverGroup::fetchByOffset( nvNewsletterReceiverGroup::StatusPublished, array( 'offset' => $offset, 'length' => $limit ), array( 'group_name' => 'asc' ) );
        return array('result' => $rows);
    }
    
    function getGroupMembers( $group_id, $offset, $limit ) {
        $ret = nvNewsletterReceiverGroup::members( $group_id, array( 'offset'=>$offset, 'length'=>$limit ) );
        return array( 'result' => $ret );
    }

    function getGroupMembersUnsubscribed( $group_id, $offset, $limit ) {
        $ret = nvNewsletterReceiverGroup::membersUnsubscribed( $group_id, array( 'offset'=>$offset, 'length'=>$limit ) );
        return array( 'result' => $ret );
    }
}
?>
