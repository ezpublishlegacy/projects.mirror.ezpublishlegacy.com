<?php
/**
 * File containing the nvNewsletter class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.6
 * @package nvNewsletter
 */
/**
 * Class nvNewsletter handles newsletters
 *
 * @todo Proper language support. Now it's recommended to create new template for every language.
 */
class nvNewsletter extends eZPersistentObject {
    const StatusDraft = 0;
    const StatusInProgress = 1;
    const StatusSending = 2;
    const StatusSent = 3;
    const StatusFailed = 4;

    function __construct($row) {
        parent::__construct($row);
    }

    static function definition() {
        return array(
                'fields' => array(
                    'id' => array(
                        'name' => 'id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'contentobject_id' => array(
                        'name' => 'contentobject_id',
                        'datatype' => 'integer',
                        'required' => true),
                    'contentobject_version' => array(
                        'name' => 'contentobject_version',
                        'datatype' => 'integer',
                        'required' => true),
                    'status' => array(
                        'name' => 'status',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'send_time' => array(
                        'name' => 'send_time',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'send_start_time' => array(
                        'name' => 'send_start_time',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'send_last_access_time' => array(
                        'name' => 'sender_last_access_time',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'send_end_time' => array(
                        'name' => 'sender_end_time',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'total_mail_count' => array(
                        'name' => 'total_mail_count',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => false),
                    'sent_mail_count' => array(
                        'name' => 'sent_mail_count',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => false),
                    'info' => array(
                        'name' => 'info',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'locale' => array(
                        'name' => 'locale',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false)),
                'keys'          => array('id'),
                'function_attributes' => array(
                        'contentobject' => 'getContentObject',
                        'opened_count' => 'getOpenedCount',
                        'opened_count_total' => 'getOpenedCountTotal',
                        'unsubscribe_count' => 'getUnsubscribeCount',
                        'link_click_count' => 'getLinkClickCount',
                        'links_clicked_by_date' => 'getLinksClickedGroupByDate',
                        'links_clicked' => 'getLinksClickedGroupByLink'),
                'increment_key' => 'id',
                'sort'          => array('id' => 'asc'),
                'class_name'    => 'nvNewsletter',
                'name'          => 'nvnewsletter_newsletters');
    }

    static function fetchByOffset($status = nvNewsletter::StatusDraft, $limit = false, $sorts = false, $asObject = true ) {
        if (!$sorts) {
            $sorts = array('id' => 'desc');
        }
        if (!$limit) {
            $limit = null;
        }
        $newsletterList = eZPersistentObject::fetchObjectList(
                nvNewsletter::definition(), null, array('status' => $status),
                $sorts, $limit, $asObject);

        return $newsletterList;
    }

    static function fetchByContentObjectID($contentObjectID, $asObject = true) {
        return eZPersistentObject::fetchObject(
                nvNewsletter::definition(), null,
                array('contentobject_id' => $contentObjectID), $asObject);
    }

    static function fetchInProgress($asObject = true) {
        $newsletterList = eZPersistentObject::fetchObjectList(
                nvNewsletter::definition(), null, null,
                array('send_time' => 'asc'), null, $asObject, false, null, null,
                ' WHERE status = '.nvNewsletter::StatusInProgress.' OR status = '.nvNewsletter::StatusSending);
        return $newsletterList;
    }

    static function fetchFailed($asObject = true) {
        $newsletterList = eZPersistentObject::fetchObjectList(
                nvNewsletter::definition(), null, null,
                array('send_time' => 'asc'), null, $asObject, false, null, null,
                ' WHERE status = '.nvNewsletter::StatusFailed);

        return $newsletterList;
    }

    static function fetchList($status = nvNewsletter::StatusDraft, $asObject = true, $conditions=false) {
        return eZPersistentObject::fetchObjectList(
                nvNewsletter::definition(), null, array('status' => $status), null, null,
                $asObject);
    }

    static function fetch($newsletterID, $asObject= true) {
        return eZPersistentObject::fetchObject(
                nvNewsletter::definition(), null,
                array('id' => $newsletterID), $asObject);
    }

    static function removeAll($id) {
        eZPersistentObject::removeObject(nvNewsletter::definition(),
                array('id' => $id));
        $db = eZDB::instance();
        $db->query("DELETE FROM nvnewsletter_clicktrack WHERE newsletter_id = $id");
        $db->query("DELETE FROM nvnewsletter_statistics WHERE newsletter_id = $id");
    }
    
    /**
     * Removes HTML-files, newsletter object and eZ node.
     *
     * @param int $id NewsletterID
     * @return boolean
     */
    static function removeNewsletter($id) {
    
        if (is_numeric($id)) {
        
            $newsletter = nvNewsletter::fetch($id);
            
            if ( $newsletter ) {
            
                // Get object ID
                $objectID = $newsletter->contentobject_id;
                $object = eZContentObject::fetch( $objectID );
                
                // Get node
                $nodeID = $object->attribute("main_node_id");
                $node   = eZContentObjectTreeNode::fetch( $nodeID );
                
                // Remove node if possible
                if ($node->canRemove()) {
                
                    if ( is_numeric( $nodeID ) ) {
                        eZContentObjectTreeNode::removeSubtrees( array( $nodeID ), false );
                        eZLog::write( "removeNewsletter (nvnewsletter.php): newsletter node removed with nodeID $nodeID", "nvnewsletter.log" );
                    }
                    
                    // Remove newsletter
                    self::removeFiles( $objectID );
                    self::removeAll( $id );
                    
                    eZLog::write( "removeNewsletter (nvnewsletter.php): newsletter object removed with newsletterID $id", "nvnewsletter.log" );
                    
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Remove newsletter files
     *
     * @param int $objectID
     * @return boolean
     */
    static function removeFiles( $objectID ) {
    
        if ( is_numeric( $objectID ) ) {
        
            if ( $dir = nvNewsletterTools::getDir( $objectID ) ) {
            
                if ( eZFileHandler::doExists( $dir ) ) {
                
                    eZDir::recursiveDelete( $dir );
                    eZLog::write( "removeFiles (nvnewsletter.php): newsletter dir removed with path $dir", "nvnewsletter.log" );
                    return true;
                }
            }
        }

        return false;
    }

    static function create() {
        $newsletter = new nvNewsletter(array(
                    'status' => nvNewsletter::StatusDraft));
        $newsletter->store();

        return $newsletter;
    }

    function getContentObject() {
        return eZContentObject::fetch($this->attribute('contentobject_id'));
    }
    
    function getOpenedCount() {
        return eZPersistentObject::count( nvNewsletterStatistics::definition(), 
                                         array( 'newsletter_id' => $this->attribute('id'),
                                                'action' => nvNewsletterStatistics::NewsletterRead ), 
                                         null);
    }
    
    function getOpenedCountTotal()
    {
        $stat = eZPersistentObject::fetchObjectList( nvNewsletterStatistics::definition(),
                                         array(), 
                                         array( 'newsletter_id' => $this->attribute('id'),
                                                'action' => nvNewsletterStatistics::NewsletterRead ), 
                                         null,
                                         null,
                                         false,
                                         false,
                                         array( array( 'operation' => 'SUM( data_int )', 
                                                       'name' => 'count' ) ) );
        return $stat[0]['count'];
    }
    
    function getLinkClickCount() {
        $stat = nvNewsletterStatistics::fetchByNewsletterAction($this->attribute('id'), nvNewsletterStatistics::NewsletterLinkClick);
        if ($stat) {
            return $stat[0]->attribute('data_int');
        }
        return 0;
    }
    
    function getLinksClickedGroupByLink()
    {
        $ret = eZPersistentObject::fetchObjectList( nvNewsletterClickTrack::definition(), 
                                                array(),
                                                array( 'newsletter_id' => $this->attribute('id') ), 
                                                true,
                                                null,
                                                false,
                                                array( 'nvnewsletter_clicktrack.link_id' ),
                                                array( 'link', array( 'operation' => 'SUM( data_int )', 
                                                              'name' => 'count' ) ),
                                                array( 'nvnewsletter_clicktrack_link' ),
                                                ' AND nvnewsletter_clicktrack_link.id = nvnewsletter_clicktrack.link_id');
        return $ret;
    }

    function getLinksClickedGroupByDate()
    {
        $ret = false;
        $results = eZPersistentObject::fetchObjectList( nvNewsletterClickTrack::definition(), 
                                                null,
                                                array( 'newsletter_id' => $this->attribute('id') ), 
                                                true,
                                                null,
                                                false, // couldn't get link field if as object
                                                false,
                                                array( 'link' ),
                                                array( 'nvnewsletter_clicktrack_link' ),
                                                ' AND nvnewsletter_clicktrack_link.id = nvnewsletter_clicktrack.link_id');
        if ( $results )
        {
            foreach ( $results as $result )
            {
                $ret[$result['action_date']][] = $result;
            }
            
            if ( is_array( $ret ) )
            {
                ksort( $ret );
            }
            
        }
        
        return $ret;
    }

    function getUnsubscribeCount() {
        $stat = nvNewsletterStatistics::fetchByNewsletterAction($this->attribute('id'), nvNewsletterStatistics::NewsletterUnsubscribe);
        if ($stat) {
            return count($stat);
        }
        return 0;
    }
    
    /**
     * Create newsletter
     *
     * @param int $objectID
     * @param int $objectVersion
     * @param string $language
     * @return boolean
     */
    static function createNewsletter($objectID, $objectVersion, $language) {
    
        // Set language and override siteaccess settings
        self::setPrioritizedLanguages($language);
        
        // Check directory structure
        if (!self::checkBaseDir($objectID)) {
            eZDebug::writeWarning("nvNewsletter: main dir generation failed");
            return false;
        }
        
        // Get newsletter data
        $data = self::generateNewsletterData($objectID, $objectVersion, $language);
        
        if (!$data) {
            eZLog::write( "createNewsletter (nvnewsletter.php): content generation failed with objectID $objectID and version $objectVersion", "nvnewsletter.log" );
            return false;
        }
    
        // HTML
        $htmlFileName = nvNewsletterTools::getFileName($objectID, $objectVersion, true, false, 'html', $language);
        $htmlContent  = $data['html'];
        
        // Text
        $textFileName = nvNewsletterTools::getFileName($objectID, $objectVersion, true, false, 'text', $language );
        $textContent  = nvNewsletterTools::br2nl( $data['text'] );
        
        $oldumask = @umask( 0 );

        $htmlCreated = eZFile::create($htmlFileName, false, trim($htmlContent));
        $textCreated = eZFile::create($textFileName, false, trim($textContent));
        
        $ini         = eZINI::instance('site.ini');
        
        // Fix file permissions
        $permissions = octdec( $ini->variable( 'FileSettings', 'LogFilePermissions' ) );
        
        @chmod( $htmlFileName, $permissions );
        @chmod( $textFileName, $permissions );
        
        @umask( $oldumask );

        if ($htmlCreated && $textCreated) {
            return true;
        }

        eZLog::write( "createNewsletter (nvnewsletter.php): email generation failed with objectID $objectID and version $objectVersion", "nvnewsletter.log" );
        
        return false;
    }
    
    /**
     * Generates newsletter content html and text file
     *
     * @param int $objectID
     * @param int $objectVersion
     * @param string $language
     * @return array containing html and text data
     */
    static function generateNewsletterData($objectID, $objectVersion, $language) {
        $contentObject = eZContentObject::fetch($objectID);
        if ($contentObject === null) {
            return false;
        }
        $versionObject = $contentObject->version($objectVersion);
        if ($versionObject === null || !$versionObject->attribute('can_read')) {
            return false;
        }

        $node = $versionObject->tempMainNode();
        
        if (!$node) {
            return false;
        }

        // Set vars
        $localVars = array( "cacheFileArray", "NodeID",  "Module", "tpl",
                            "LanguageCode",  "ViewMode", "Offset", "ini",
                            "cacheFileArray", "viewParameters", "collectionAttributes",
                            "validation" );

        $tpl            = templateInit();
        $LanguageCode   = $language;
        $ViewMode       = 'nvnewsletterhtml';

        // HTML
        $result = eZNodeviewfunctions::generateNodeViewData($tpl, $node, $contentObject,
                $LanguageCode, $ViewMode, false, false, false, false);
        $retval = array(
                'content' => $result,
                'scope'   => 'viewcache',
                'store'   => $result['cache_ttl'] != 0);
        if ($file !== false && $retval['store']) {
            $retval['binarydata'] = serialize($result);
        }

        $htmlData = $retval;

        // Text
        $ViewMode       = 'nvnewslettertext';

        $result = eZNodeviewfunctions::generateNodeViewData($tpl, $node, $contentObject,
                $LanguageCode, $ViewMode, false, false, false, false);
        $retval = array(
                'content' => $result,
                'scope'   => 'viewcache',
                'store'   => $result['cache_ttl'] != 0);
        if ($file !== false && $retval['store']) {
            $retval['binarydata'] = serialize($result);
        }

        $textData = $retval;

        $htmlError = $htmlData['content']['path'][0]['text'];
        $textError = $textData['content']['path'][0]['text'];
        
        if ($htmlError != 'Error' && $textError != 'Error') {
            return array(
                    'html' => $htmlData['content']['content'],
                    'text' => $textData['content']['content']);
        }
        
        return false;
    }
    
    /**
     * Set newsletter language
     *
     * @param mixed $languages
     */
    static function setPrioritizedLanguages($languages) {
        if (empty($languages)) {
            $ini         = eZINI::instance('site.ini');
            $languages   = $ini->variable('RegionalSettings', 'Locale');
        }

        if (!is_array($languages)) {
            $languages = array($languages);
        }
        
        eZContentLanguage::setPrioritizedLanguages($languages);
    }
    
    /**
     * Check if newsletter var directory exists
     *
     * @param int $objectID
     * @return boolean
     */
    static function checkBaseDir($objectID) {
        $tmpDir = nvNewsletterTools::getDir($objectID);

        if (!eZFileHandler::doExists($tmpDir)) {
            if (!eZDir::mkdir($tmpDir, eZDir::directoryPermission(), true)) {
                eZLog::write( "checkBaseDir (nvnewsletter.php): could not create temporary directory $tmpDir", "nvnewsletter.log" );
                return false;
            }
        }

        if (!eZFileHandler::doIsWriteable($tmpDir)) {
            eZLog::write( "checkBaseDir (nvnewsletter.php): please make $tmpDir writable", "nvnewsletter.log" );
            return false;
        }
        
        return true;
    }
    
    /**
     * Send preview newsletter
     *
     * @param string $email
     * @param int $format 0=text, 1=html
     * @param int $objectID
     * @param int $objectVersion
     * @param string $languageCode
     */
    static function sendPreview( $email, $format, $objectID, $objectVersion, $languageCode ) {
        $newsletter = new nvNewsletterMailer( $objectID, $objectVersion, $languageCode );
        $newsletter->sendMail( 0, $email, $format );
    }
}
?>
