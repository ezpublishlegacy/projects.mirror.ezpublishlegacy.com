<?php /*

[CustomTagSettings]
AvailableCustomTags[]
AvailableCustomTags[]=nvnewslettersubscribe
IsInline[]
IsInline[nvnewslettersubscribe]=false

[EditSettings]
ExtensionDirectories[]=nvnewsletter

[DataTypeSettings]
ExtensionDirectories[]=nvnewsletter
AvailableDataTypes[]=nvnewslettersender
AvailableDataTypes[]=nvnewslettergroups
AvailableDataTypes[]=nvnewslettersiteselect

[link]
AvailableClasses[]
AvailableClasses[]=tracker

*/ ?>
