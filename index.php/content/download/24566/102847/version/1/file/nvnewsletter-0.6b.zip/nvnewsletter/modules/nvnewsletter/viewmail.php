<?php
/**
 * Module view mail
 * @package nvNewsletter
 */
require_once( 'kernel/common/template.php' );

$hash          = (string)$Params['Hash'];
$objectID      = (int)$Params['ObjectID'];
$objectVersion = (int)$Params['ObjectVersion'];
$titleArray    = array();
$content       = false;

$object = eZContentObject::fetch( $objectID );

if ( $object ) {
    $content = nvNewsletterTools::getContent( $objectID, $objectVersion, 'html', $hash );
    $content = nvNewsletterTools::replaceUserCode( $content );
}

if ( !$content ) {
    eZLog::write( "nvNewsletter (viewmail.php): generated mail not found with objectID $objectID and hash $hash", "nvnewsletter.log" );
    $titleArray = array( array('url' => false, 'text' => 'Newsletter not found' ) );
    $content = 'Newsletter not found';
}

$tpl = templateInit();
$tpl->setVariable( 'result', array( 'content' => $content ) );

$Result['path']        = $titleArray;
$Result['content']     = $tpl->fetch( "design:viewmail.tpl" );
$Result['pagelayout']  = false;
?>