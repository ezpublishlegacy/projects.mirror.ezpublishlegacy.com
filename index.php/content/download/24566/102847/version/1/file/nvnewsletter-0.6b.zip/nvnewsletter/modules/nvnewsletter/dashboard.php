<?php
/**
 * Module dashboard
 * @package nvNewsletter
 */
require_once( 'kernel/common/template.php' );

$extension = 'nvnewsletter';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

$Module = $Params['Module'];
$http = eZHTTPTool::instance();

$tpl = templateInit();
$tpl->setVariable('module', $Module);

$newsletterDraft = nvNewsletter::fetchByOffset(nvNewsletter::StatusDraft, array( 'offset'=>0, 'limit'=>5 ) );
//$newsletterSent = nvNewsletter::fetchByOffset(nvNewsletter::StatusSent, array( 'offset'=>0, 'limit'=>5 ));

$tpl->setVariable('newsletter_draft_array', $newsletterDraft);

$Result = array();
$Result['newsletter_menu'] = 'design:parts/content/newsletter_menu.tpl';
$Result['left_menu'] = 'design:parts/content/nvnewsletter_menu.tpl';
$Result['content'] = $tpl->fetch("design:$extension/dashboard.tpl");
$Result['path'] = array(array(
            'url'  => false,
            'text' => 'Newsletter dashboard'));
?>
