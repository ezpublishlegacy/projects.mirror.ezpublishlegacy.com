<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=nvnewsletter

[StylesheetSettings]
CSSFileList[]=nvnewsletter.css


*/ ?>
