<?php
/**
 * File containing the nvNewsletterMailerQueries class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.6
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterMailerQueries contains queries for newsletter sending
 *
 * @todo Should be merged with nvNewsletter and nvNewsletterMailer classes
 */
class nvNewsletterMailerQueries {

    var     $db            = false;
    private $objectID      = false;
    private $objectVersion = false;
    private $objectIsSet   = false;

    /**
     * Constructor
     *
     * @param int $objectID
     * @param int $objectVersion
     */
    function __construct( $objectID=false, $objectVersion=false ) {
    
        $this->db = eZDB::instance();
        
        if ( is_numeric( $objectID ) && is_numeric( $objectVersion ) ) {
            $this->objectID      = $objectID;
            $this->objectVersion = $objectVersion;
            $this->objectIsSet   = true;
        }
    }
    
    /*
    function getInterruptedMails() {
    
        $db   = eZDB::instance();
        $rows = $db->arrayQuery( "SELECT 
          id, contentobject_id, contentobject_version, status, send_time, send_start_time, send_last_access_time, send_end_time, total_mail_count, sent_mail_count, info, locale 
        FROM 
          nvnewsletter_newsletters 
        WHERE 
          status = '".nvNewsletter::StatusSending."' 
        ORDER BY
          send_start_time ASC" );

        return $rows;
    }
    */
    
    /**
     * Get sent count
     */
    function getMailSentCount() {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
        
        $rows = $this->db->arrayQuery( "SELECT 
          sent_mail_count 
        FROM 
          nvnewsletter_newsletters 
        WHERE 
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion."
        LIMIT 1" );
        
        return $rows[0]['sent_mail_count'];
    }
    
    /**
     * Get mails
     */
    static function getMails() {
    
        $db = eZDB::instance();
        
        $rows = $db->arrayQuery( "SELECT 
          id, contentobject_id, contentobject_version, send_time, send_start_time, send_last_access_time, send_end_time, total_mail_count, sent_mail_count, info, locale 
        FROM 
          nvnewsletter_newsletters 
        WHERE 
          status = '".nvNewsletter::StatusInProgress."' AND send_time < NOW() 
        ORDER BY
          send_start_time ASC
        LIMIT 
          0,1" );
        return $rows;
    }
    
    /**
     * Start mail sending
     */
    function startMailSending() {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
        
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          status = '".nvNewsletter::StatusSending."', 
          send_start_time = NOW(),  
          send_last_access_time = NOW() 
        WHERE 
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion );
    }
    
    /**
     * Restart mail sending
     */
    function restartMailSending() {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
    
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          send_last_access_time = NOW(), 
          info = 'Mail sending interrupted - resending ".date('Y-m-d H:i:s')."'
        WHERE 
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion );
    }
    
    /**
     * Get receivers
     *
     * @param array $groupsArray
     */
    function getReceivers( $groupsArray ) {
    
        $rows = false;
        $temp = array();
        
        if ( is_array( $groupsArray ) ) {
            foreach ( $groupsArray as $group_id ) {
                if ( is_numeric( $group_id ) ) {
                    $temp[] = $group_id;
                }
            }
        }
        
        if ( is_array( $temp ) ) {
        
            $rows = $this->db->arrayQuery( "SELECT 
              r.id, r.email_address, g.mail_type 
            FROM 
              nvnewsletter_receivers_has_groups as g, nvnewsletter_receivers as r 
            WHERE 
              g.receivergroup_id IN (".implode( ', ', $temp ).") AND g.receiver_id = r.id
            GROUP BY 
              r.email_address" );
        }

        return $rows;
    }
    
    /**
     * Insert receiver data into temp table
     *
     * @param array $receiver
     */
    function insertReceiverIntoTempTable( $receiver ) {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
        
        if ( !is_numeric( $receiver["id"] ) ) {
            return false;
        }
        
        if ( !is_numeric( $receiver["mail_type"] ) ) {
            return false;
        }
        
        if ( !eZMail::validate( $receiver["email_address"] ) ) {
            return false;
        }
    
        $this->db->query( "INSERT INTO 
          nvnewsletter_receivers_mailtemp(contentobject_id, contentobject_version, user_id, email_address, mail_type) 
        VALUES
          (".$this->objectID.", ".$this->objectVersion.", ".$receiver["id"].", '".$receiver["email_address"]."', '".$receiver["mail_type"]."')" );
    }
    
    /**
     * Delete receiver from temp table
     *
     * @param int $receiverID
     */
    function deleteReceiverFromTempTable( $receiverID ) {
    
        if ( !is_numeric( $receiverID ) ) {
            return false;
        }
    
        $this->db->query( "
        DELETE FROM 
          nvnewsletter_receivers_mailtemp 
        WHERE 
          id = ".$receiverID." 
        LIMIT 1" );
    }
    
    /**
     * Get receivers from temp table for real mail sending
     */
    function getReceiversForActualSend() {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
    
        $rows = $this->db->arrayQuery( "SELECT 
          id, user_id, email_address, mail_type
        FROM 
          nvnewsletter_receivers_mailtemp 
        WHERE
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion."
        ORDER BY 
          email_address ASC" );
          
        return $rows;
    }
    
    /**
     * Update mail receiver count
     *
     * @param int $counter
     */
    function updateMailReceiverCount( $counter ) {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
        
        if ( !is_numeric( $counter ) ) {
            return false;
        }
    
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          total_mail_count = ".$counter." 
        WHERE 
          contentobject_id = ".$this->objectID." AND 
          contentobject_version = ".$this->objectVersion );
    }
    
    /**
     * Update last time when mail is sent
     *
     * @param int $counter
     */
    function updateMailLastSendTime( $counter=false ) {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
        
        if ( is_numeric($counter) ) {
            $counterSQL = ", sent_mail_count = $counter";
        }
        
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          send_last_access_time = NOW() 
          $counterSQL
        WHERE 
          contentobject_id = ".$this->objectID." AND 
          contentobject_version = ".$this->objectVersion );
    }
    
    /**
     * Update mail count and send times
     *
     * @param int $counter
     */
    function updateMailSendingEnd( $counter ) {
    
        if ( !$this->objectIsSet && !is_numeric( $counter ) ) {
            return false;
        }
    
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          status = '".nvNewsletter::StatusSent."',
          send_last_access_time = NOW(), 
          send_end_time = NOW(), 
          sent_mail_count = $counter 
        WHERE 
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion );
    }
    
    /**
     * Update errors
     *
     * @param string $errors
     */
    function updateErrors( $errors ) {
    
        if ( !$this->objectIsSet ) {
            return false;
        }
    
        $this->db->query( "UPDATE 
          nvnewsletter_newsletters 
        SET 
          status = '".nvNewsletter::StatusFailed."', 
          info = '".$this->db->escapeString( $errors )."' 
        WHERE 
          contentobject_id = ".$this->objectID." AND
          contentobject_version = ".$this->objectVersion );
    }
}
?>
