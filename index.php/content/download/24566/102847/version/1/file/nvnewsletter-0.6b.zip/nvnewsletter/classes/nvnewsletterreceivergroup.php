<?php
/**
 * File containing the nvNewsletterReceiverGroup class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.6
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterReceiverGroup handles newsletter receiver groups
 */
class nvNewsletterReceiverGroup extends eZPersistentObject {
    const StatusDraft = 0;
    const StatusPublished = 1;

    function __construct($row) {
        parent::__construct($row);
    }

    static function definition() {
        return array(
                'fields' => array(
                    'id' => array(
                        'name' => 'id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'group_name' => array(
                        'name' => 'group_name',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => true),
                    'group_description' => array(
                        'name' => 'group_description',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'status' => array(
                        'name' => 'status',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true)),
                'keys'          => array('id', 'status'),
                'increment_key' => 'id',
                'sort'          => array('id' => 'asc'),
                'function_attributes' => array(
                    'members_count' => 'membersCount',
                    'members_unsubscribed_count' => 'membersUnsubscribedCount' ),
                'class_name'    => 'nvNewsletterReceiverGroup',
                'name'          => 'nvnewsletter_receivergroups');
    }

    function attribute($attr, $noFunction = false) {
        $retVal = eZPersistentObject::attribute($attr);

        return $retVal;
    }

    static function fetchByOffset( $status=nvNewsletterReceiverGroup::StatusPublished, $limit=false, $sorts=false, $asObject=true ) {
        if (!$sorts) {
            $sorts = array('id' => 'asc');
        }
        if (!$limit) {
            $limit = null;
        }
        $groupList = eZPersistentObject::fetchObjectList(
                nvNewsletterReceiverGroup::definition(), null, array('status' => $status),
                $sorts, $limit, null, $asObject);

        return $groupList;
    }

    static function fetchList($status = nvNewsletterReceiverGroup::StatusPublished, $asObject = true) {
        return eZPersistentObject::fetchObjectList(
                nvNewsletterReceiverGroup::definition(), null, array('status' => $status), null, null, $asObject);
    }

    static function fetch($groupID, $status=nvNewsletterReceiverGroup::StatusPublished, $asObject=true) {
        return eZPersistentObject::fetchObject(
                nvNewsletterReceiverGroup::definition(), null,
                array('id' => $groupID, 'status' => $status), $asObject);
    }

    static function fetchDraft($id, $asObject = true) {
        $group = nvNewsletterReceiverGroup::fetch($id, nvNewsletterReceiverGroup::StatusDraft, $asObject);
        if (!$group) {
            $group = nvNewsletterReceiverGroup::fetch($id, nvNewsletterReceiverGroup::StatusPublished, $asObject);
            if ($group) {
                $group->setAttribute('status', nvNewsletterReceiverGroup::StatusDraft);
                $group->store();
            }
        }

        if (!$group) {
            return false;
        }

        return $group;
    }
    
    static function membersUnsubscribed( $receiverGroupID, $limit=false, $asObject=true ) {
    
        return eZPersistentObject::fetchObjectList( nvNewsletterReceiver::definition(), 
                                                    null, 
                                                    array( 'status' => nvNewsletterReceiver::StatusPublished ), 
                                                    null, 
                                                    $limit, 
                                                    $asObject,
                                                    null, 
                                                    null, 
                                                    array( 'nvnewsletter_receivers_has_groups_unsub' ), 
                                                    ' AND nvnewsletter_receivers_has_groups_unsub.receiver_id = nvnewsletter_receivers.id 
                                                      AND nvnewsletter_receivers_has_groups_unsub.receivergroup_id = '.$receiverGroupID );
    }
    
    function membersUnsubscribedCount() {
        $db = eZDB::instance();
        $members = $db->arrayQuery("SELECT COUNT( r.id ) AS count 
                                    FROM 
                                          nvnewsletter_receivers r, 
                                          nvnewsletter_receivers_has_groups_unsub nrhg 
                                    WHERE r.id = nrhg.receiver_id AND 
                                          r.status = ".nvNewsletterReceiver::StatusPublished." AND 
                                          nrhg.receivergroup_id = ".$this->attribute('id') );
        return $members[0]['count'];
    }
    
    static function members($receiverGroupID, $limit=false, $asObject=true) {
    
        return eZPersistentObject::fetchObjectList( nvNewsletterReceiver::definition(), 
                                                    null, 
                                                    array( 'status' => nvNewsletterReceiver::StatusPublished ), 
                                                    null, 
                                                    $limit, 
                                                    $asObject,
                                                    null, 
                                                    null, 
                                                    array( 'nvnewsletter_receivers_has_groups' ), 
                                                    ' AND nvnewsletter_receivers_has_groups.receiver_id = nvnewsletter_receivers.id 
                                                      AND nvnewsletter_receivers_has_groups.receivergroup_id = '.$receiverGroupID );
    }
    
    function membersCount() {
        $db = eZDB::instance();
        $members = $db->arrayQuery("SELECT COUNT( r.id ) AS count 
                                    FROM 
                                        nvnewsletter_receivers r, 
                                        nvnewsletter_receivers_has_groups nrhg 
                                    WHERE r.id = nrhg.receiver_id AND 
                                          r.status = ".nvNewsletterReceiver::StatusPublished." AND 
                                          nrhg.receivergroup_id = ".$this->attribute('id') );
        return $members[0]['count'];
    }

    function publish() {
        $this->setAttribute('status', nvNewsletterReceiverGroup::StatusPublished);
        $this->store();
        $this->removeDraft();
    }

    function removeDraft() {
        $groupDraft = nvNewsletterReceiverGroup::fetchDraft($this->attribute('id'));
        $groupDraft->remove();
    }

    static function removeAll($id) {
        eZPersistentObject::removeObject(nvNewsletterReceiverGroup::definition(),
                array('id' => $id));
        $db = eZDB::instance();
        $db->query("DELETE FROM nvnewsletter_receivers_has_groups WHERE receivergroup_id = $id");
        $db->query("DELETE FROM nvnewsletter_receivers_has_groups_unsub WHERE receivergroup_id = $id");
        $db->query("DELETE FROM nvnewsletter_receivers 
                    WHERE nvnewsletter_receivers.id NOT IN ( SELECT receiver_id FROM nvnewsletter_receivers_has_groups ) AND 
                          nvnewsletter_receivers.id NOT IN ( SELECT receiver_id FROM nvnewsletter_receivers_has_groups_unsub )");
        $db->query("DELETE FROM nvnewsletter_receivers_has_fields 
                    WHERE nvnewsletter_receivers_has_fields.receiver_id NOT IN ( SELECT receiver_id FROM nvnewsletter_receivers_has_groups ) AND 
                          nvnewsletter_receivers_has_fields.receiver_id NOT IN ( SELECT receiver_id FROM nvnewsletter_receivers_has_groups_unsub )");
    }

    static function create($name = '', $desc = '') {
        $group = new nvNewsletterReceiverGroup(array(
                    'group_name' => $name,
                    'group_description' => $desc,
                    'status' => nvNewsletterReceiverGroup::StatusDraft));
        $group->store();

        return $group;
    }
}
?>