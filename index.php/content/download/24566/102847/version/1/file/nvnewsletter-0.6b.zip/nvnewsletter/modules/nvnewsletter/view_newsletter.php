<?php
/**
 * Module view newsletter
 * @package nvNewsletter
 */
require_once( 'kernel/common/template.php' );

$extension = 'nvnewsletter';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

$http = eZHTTPTool::instance();
$newsletterID = $Params['NewsletterID'];
$Module = $Params['Module'];

$newsletter = nvNewsletter::fetch($newsletterID);

if (!$newsletter) {
    return $Module->handleError(eZError::KERNEL_NOT_AVAILABLE, 'kernel');
}

$tpl = templateInit();

$tpl->setVariable('newsletter', $newsletter);

$Result = array();
$Result['newsletter_menu'] = 'design:parts/content/newsletter_menu.tpl';
$Result['left_menu'] = 'design:parts/content/nvnewsletter_menu.tpl';
$Result['content'] = $tpl->fetch( "design:$extension/view_newsletter.tpl" );
$Result['path'] = array(array(
            'url' => false,
            'text' => ezi18n('nvnewsletter/view_newsletter', 'View newsletter')));
?>
