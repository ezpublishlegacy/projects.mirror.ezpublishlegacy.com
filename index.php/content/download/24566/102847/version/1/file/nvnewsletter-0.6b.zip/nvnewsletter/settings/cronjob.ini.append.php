<?php /*

[CronjobSettings]
ExtensionDirectories[]=nvnewsletter

[CronjobPart-sendmail]
Scripts[]=nvnewslettermailsender.php

*/ ?>
