<?php
/**
 * File containing the nvNewsletterTools class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.6
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterTools contains miscellaneous helper methods
 */
class nvNewsletterTools {

    function __construct(){}
    
    /**
     * Get hash from settings file
     *
     * @param string $type
     * @return string|array
     */
    static function getHash ( $type='User' ) {
        $ini = eZINI::instance( 'nvnewsletter.ini' );
        return $ini->variable( 'HashSettings', ucfirst($type).'Hash' );
    }
    
    /**
     * Breaks to new lines
     *
     * @param string $string
     * @return string
     */
    static function br2nl ( $string, $charlist = "\t\n\r\0\x0B" ) {
        $string = str_replace( str_split($charlist), "", $string );
        $string = ereg_replace( " +", " ", $string );
        $string = str_replace( "\n", "", $string );
        return preg_replace( '/\<br(\s*)?\/?\>/i', "\n", $string );
    }
    
    /**
     * Get newsletter directory with objectID
     *
     * @param int $objectID
     * @return string
     */
    static function getDir( $objectID=false ) {
    
        if ($objectID) {
            $fileSep      = eZSys::fileSeparator();
            $tmpDir       = eZSys::varDirectory().$fileSep.'nvnewsletter';
            $dirStructure = self::getNewsletterFileDir( $objectID );
            $tmpDir       = $tmpDir.$fileSep.$dirStructure;
            return $tmpDir;
         }
         return false;
    }
    
    /**
     * Get directory structure for files
     *
     * @param int $objectID
     * @return string
     */
    static function getNewsletterFileDir( $objectID ) {
    
        if ($objectID) {
            return $objectID;
        }
        
        return '0';
    }
    
    static function formatURLPath( $url )
    {
        if ( substr( $url, -1  ) == '/' ) 
        {
             $url = substr( $url, 0, -1  );
        }
        
        return $url;
    }
    
    /**
     * Get newsletter site link
     *
     * @param int $objectID
     * @param int $objectVersion
     * @return string
     */
    static function getLink ( $objectID, $objectVersion=false ) {
    
        $siteLink = '';
        
        $object  = eZContentObject::fetch( $objectID );
        
        if ( is_numeric( $objectVersion ) ) {
            $object = $object->version( $objectVersion );
        }
        
        $dataMap  = $object->DataMap();
        
        if ( $dataMap['site_selection'] ) {
        
            $content  = $dataMap['site_selection']->content();
            $siteLink = $content['selected'];
            $siteLink = explode( ';', $siteLink );
            $return = array();
            
            for ( $i=0; $i<=1; $i++ ) {
            
                if ( !empty( $siteLink[$i] ) ) {
                
                    $link = self::formatURLPath( $siteLink[$i] );

                    if ( substr( $link, 0, 7  ) != 'http://' ) {
                         $link = 'http://'.$link;
                    }
                    
                    $return[] = $link;
                }
            }
        }
        
        if ( empty( $return[1] ) ) {
            $return[1] = $return[0];
        }

        return $return;
    }
    
    /**
     * Build hash
     *
     * @param int $objectID
     * @param int $objectVersion
     * @param string $language
     * @return string
     */
    static function getFileHash ( $objectID, $objectVersion, $language ) {
        return md5( $objectID . $objectVersion . $language . self::getHash('File') );
    }
    
    /**
     * Build user hash
     *
     * @param string $email
     * @return string
     */
    static function getUserHash ( $email ) {
        return md5( $email . self::getHash('User') );
    }
    
    /**
     * Replace user code
     *
     * @param string $code
     * @return string
     */
    static function replaceUserCode ( $content ) {
        return str_replace( array('<NVN_USER_CODE>', '<NVN_TRACKER_CODE>'), array(nvNewsletterMailer::UserCodeReplacement, nvNewsletterMailer::TrackerCodeReplacement), $content );
    }
    
    /**
     * Get filename for the generated newsletter file
     *
     * @param int $objectID
     * @param int $objectVersion
     * @param boolean $withPath
     * @param boolean $hash
     * @param string $mode
     * @param string $language
     * @return string
     */
    static function getFileName ($objectID, $objectVersion, $withPath = false, $hash = false, $mode = 'html', $language = 'eng-GB') {
    
        if ($mode !== 'html') {
            $mode = 'text';
        }
        
        $ini = eZINI::instance('nvnewsletter.ini');
        
        if ($hash) {
            $generatedHash = $hash;
        } else {
            $generatedHash = self::getFileHash( $objectID, $objectVersion, $language );
        }
        
        $filename = $ini->variable('FileSettings', 'FilePrefix').$objectVersion.'_'.$mode.'_'.$generatedHash.'.html';
        
        if ($withPath) {
            $fileSep = eZSys::fileSeparator();
            $tmpDir  = self::getDir($objectID);
            
            return $tmpDir.$fileSep.$filename;
        } else {
            return $filename;
        }
    }
    
    /**
     * Get newsletter content
     *
     * @param int $objectID
     * @param int $objectVersion
     * @param string $mode
     * @param string $hash
     * @param string $language
     * @return mixed
     */
    static function getContent( $objectID, $objectVersion, $mode = 'html', $hash = false, $language = false ) {

        if ( !is_numeric( $objectID ) || !is_numeric( $objectVersion ) ) {
            return false;
        }
    
        if ($mode !== 'html') {
            $mode = 'text';
        }
        if ($hash) {
            $hash = self::sanitizeHTMLFileName($hash);
        }
        
        $filePath = self::getFileName($objectID, $objectVersion, true, $hash, $mode, $language);

        if (eZFileHandler::doExists($filePath)) {
            return file_get_contents($filePath);
        }
        
        return false;
    }
    
    /**
     * Sanitizes hash name
     *
     * @param string $hash
     * @return string
     */
    static function sanitizeHTMLFileName($hash) {
        return preg_replace('/[^A-Za-z0-9]+/', '', $hash);
    }

    /**
     * Clean orphaned newsletters
     *
     * @todo we have to find an alternative solution for this now that content object ids&versions are used
     */
    static function cleanOrphanedNewsletters() {
        /*
        $db = eZDB::instance();
        $db->query("DELETE FROM nvnewsletter_newsletters WHERE status = ".nvNewsletter::StatusDraft." AND mail_node_id NOT IN (SELECT node_id from ezcontentobject_tree)");
        */
    }
    
}
?>
