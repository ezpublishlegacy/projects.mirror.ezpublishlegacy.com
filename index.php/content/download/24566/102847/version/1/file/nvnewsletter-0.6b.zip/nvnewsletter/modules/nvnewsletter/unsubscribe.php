<?php
/**
 * Module unsubscribe
 * @package nvNewsletter
 */
require_once( 'kernel/common/template.php' );

$objectID    = (int)$Params['ObjectID'];
$userID      = (int)$Params['UserID'];
$hash        = (string)$Params['Hash'];
$titleArray  = array();
$success     = false;
$error       = false;

$user     = nvNewsletterReceiver::fetch( $userID );
$userHash = nvNewsletterTools::getUserHash( $user->email_address );

if ( $userHash == $hash && !empty( $hash ) ) 
{
    if ( $user->unsubscribe() ) 
    {
        $success = true;
        $newsletter = nvNewsletter::fetchByContentObjectID($objectID);
        
        if ($newsletter) 
        {
            $statistics = nvNewsletterStatistics::create( $newsletter->attribute('id'), 
                                                          $userID, nvNewsletterStatistics::NewsletterUnsubscribe, 
                                                          $hash);
        }
    }
}

if ( empty( $userID ) && empty( $hash ) ) 
{
    $error = 'usercode';
}

$tpl = templateInit();
$tpl->setVariable( 'result', array( 'success' => $success, 'error' => $error ) );

$Result['path']         = $titleArray;
$Result['content']      = $tpl->fetch( 'design:nvnewsletter/unsubscribe.tpl' );
$Result['pagelayout']   = true;
?>
