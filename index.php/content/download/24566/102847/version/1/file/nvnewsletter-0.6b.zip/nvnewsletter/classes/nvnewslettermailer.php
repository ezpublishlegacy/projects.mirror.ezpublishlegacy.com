<?php
/**
 * File containing the nvNewsletterMailer class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.6
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterMailer handles mail sending
 *
 * @todo Support other connection types as well (ezcMailSmtpTransport)
 * @todo Use all user fields in personalization
 */
class nvNewsletterMailer {
    
    const UserCodeReplacement    = '__USERCODE__';
    const TrackerCodeReplacement = '__TRACKERCODE__';

    private $nvnewsletterIni = null;
    private $siteIni = null;
    private $db = null;

    private $objectID = null;
    private $objectVersion = null;
    private $locale = null;

    private $transport = null;

    private $SenderFieldIdentifier = null;
    private $GroupsFieldIdentifier = null;

    private $senderName = null;
    private $senderEmail = null;
    private $replyToEmail = null;
    private $subject = null;
    private $charset = null;

    private $mail;
    private $plainTextOnly;
    private $bothParts;

    private $mailAvailability = false;
    private $pregeneratedDataAvailability = false;

    private $newsletterDataMap = null;
    private $newsletterGroups = null;

    private $personalTags = null;
    private $personalization = false;

    private $mailTextContentPersonal = false;
    private $mailHtmlContentPersonal = false;

    private $logEveryReceiver = false;

    /**
     * Constructor
     *
     * @param int $contentObjectID
     * @param int $contentObjectVersion
     * @param string $locale
     */
    function __construct( $contentObjectID, $contentObjectVersion, $locale ) {

        $this->nvnewsletterIni = eZINI::instance( 'nvnewsletter.ini' );
        $this->siteIni = eZINI::instance( 'site.ini' );
        $this->db = eZDB::instance();

        $this->objectID = $contentObjectID;
        $this->objectVersion = $contentObjectVersion;
        $this->locale = $locale;

        // Log
        if ( $this->nvnewsletterIni->variable( 'LogSettings', 'LogEveryReceiver' ) ) 
        {
            $this->logEveryReceiver = true;
        }

        // Fetch replacements and check if we need personalization
        $this->personalTags = $this->nvnewsletterIni->variable( 'Personalization', 'ReplaceTag' );

        if ( is_array( $this->personalTags ) && count($this->personalTags) > 0 )
        {
            $this->personalization = true;
        }
        
        // Charset
        $this->charset = $this->nvnewsletterIni->variable( 'MailSendSettings', 'Charset' );

        // Fetching defined mail transport method from site.ini
        $TransportType = $this->siteIni->variable( 'MailSettings', 'Transport' );

        if ( $TransportType == 'sendmail' ) {
            $this->transport = new ezcMailMtaTransport();
        } else {  
            // Create a new SMTP transport object with an SSLv3 connection.
            // The port will be 465 by default, use the 4th argument to change it.
            // Username and password (2nd and 3rd arguments) are left blank, which means
            // the mail host does not need authentication.
            // The 5th parameter is the optional $options object.
            $TransportServer   = $this->siteIni->variable( 'MailSettings', 'TransportServer' );
            $TransportPort     = $this->siteIni->variable( 'MailSettings', 'TransportPort' );
            $TransportUser     = $this->siteIni->variable( 'MailSettings', 'TransportUser' );
            $TransportPassword = $this->siteIni->variable( 'MailSettings', 'TransportPassword' );

            // Todo: support other connection types as well
            // http://www.ezcomponents.org/docs/api/latest/Mail/ezcMailSmtpTransport.html
            $options = new ezcMailSmtpTransportOptions();
            $options->connectionType = ezcMailSmtpTransport::CONNECTION_SSL;

            $this->transport = new ezcMailSmtpTransport( $TransportServer, $TransportUser, $TransportPassword, $TransportPort, $options );
        }

        $this->SenderFieldIdentifier = $this->nvnewsletterIni->variable( 'ContentClassSettings', 'SenderFieldIdentifier' );
        $this->GroupsFieldIdentifier = $this->nvnewsletterIni->variable( 'ContentClassSettings', 'GroupsFieldIdentifier' );

        $this->senderName   = $this->nvnewsletterIni->variable( 'MailSendSettings', 'MailDefaultSenderName' );
        $this->senderEmail  = $this->nvnewsletterIni->variable( 'MailSendSettings', 'MailDefaultSenderEmail' );
        $this->replyToEmail = $this->nvnewsletterIni->variable( 'MailSendSettings', 'MailDefaultReplyToEmail' );

        $contentObject = eZContentObject::fetch( $contentObjectID );
        $versionObject = $contentObject->version( $contentObjectVersion );

        if ( $newsletterData = $versionObject->tempMainNode() ) {

            $this->mailAvailability = true;
            $this->subject = $newsletterData->Name;

            // Setting up newsletter class data_map
            $this->newsletterDataMap = $newsletterData->dataMap();

            // Fetching sender id from node
            $senderContent = $this->newsletterDataMap[$this->SenderFieldIdentifier]->content();
            $senderID      = $senderContent['selected'];
            $senderData    = nvNewsletterSender::fetch( $senderID );

            if ( $senderData ) {
            
                if (!empty($senderData->sender_name)) {
                    $this->senderName   = $senderData->sender_name;
                }
                if (!empty($senderData->sender_email)) {
                    $this->senderEmail  = $senderData->sender_email;
                }
                if (!empty($senderData->reply_to)) {
                    $this->replyToEmail = $senderData->reply_to;
                }
            }

            $this->createNewsletter();

            // Setting up basic maildata
            $this->mail = new ezcMail();
            $this->mail->from = new ezcMailAddress( $this->senderEmail, $this->senderName, $this->charset );
            $this->mail->subject = $this->subject;
            $this->mail->subjectCharset = $this->charset; 

            // If Reply-To is set
            if($this->replyToEmail){ $this->mail->setHeader( 'Reply-To', $this->replyToEmail ); }

            // Building mail body
            $this->setMailBody();
        }
    }

    /**
     * Populate receivers temp table
     *
     * @return boolean
     */
    function populateMailReceiverTable() {

        $newsletterQuery = new nvNewsletterMailerQueries( $this->objectID, $this->objectVersion );
        $groupsContent   = $this->newsletterDataMap[$this->GroupsFieldIdentifier]->content();

        if ( is_array( $groupsContent['selected'] ) ) {

            $groupsArray = false;
            foreach ( $groupsContent['selected'] as $key => $value ) {
                if ( is_numeric( $key ) ) {
                    $groupsArray[] = $key;
                }
            }
            
            $receivers = $newsletterQuery->getReceivers( $groupsArray );

            $newsletterQuery->db->begin();

            foreach ( $receivers as $receiver ) {
                $newsletterQuery->insertReceiverIntoTempTable( $receiver );
            }

            $newsletterQuery->db->commit();

            $receiverCount = count($receivers);
            $newsletterQuery->updateMailReceiverCount( $receiverCount );
            
            unset( $receivers );
            
            return true;
        }
        
        return false;
    }

    /**
     * Generate newsletter
     */
    function createNewsletter(){

        if( nvNewsletter::createNewsletter( $this->objectID, $this->objectVersion, $this->locale ) ) {

            $this->mailHtmlContent = nvNewsletterTools::getContent( $this->objectID, $this->objectVersion, 'html', false, $this->locale );
            $this->mailTextContent = nvNewsletterTools::getContent( $this->objectID, $this->objectVersion, 'text', false, $this->locale );

            $this->pregeneratedDataAvailability = true;
        }
    }

    /**
     * Get receiver email address
     *
     * @return string
     */
    function getReceiverEmail() {
        return $this->mail->to[0]->email;
    }

    /**
     * Handle personalization
     *
     * @todo user field replacements
     */
    function personalize($userID=false) {

        $tags   = array();
        $values = array();

        foreach( $this->personalTags as $index => $value ) {
            switch( $index ) {
                case 'NVN_USER_CODE':
                    $tags[] = "<$index>";
                    $userID == 0 ? $values[] = self::UserCodeReplacement : $values[] = $userID.'/'.nvNewsletterTools::getUserHash( $this->getReceiverEmail() );
                    break;
                case 'NVN_TRACKER_CODE':
                    $tags[] = "<$index>";
                    $userID == 0 ? $values[] = self::TrackerCodeReplacement : $values[] = $this->objectID.'_'.$userID.'_'.nvNewsletterTools::getUserHash( $this->getReceiverEmail() );
                    break;
            }
        }

        $this->mailTextContentPersonal = str_replace( $tags, $values, $this->mailTextContent );
        $this->mailHtmlContentPersonal = str_replace( $tags, $values, $this->mailHtmlContent );

        $this->setMailBody();
    }

    /**
     * Set mail body. Checks if newsletter is personalized
     */
    function setMailBody() {

        // Building html-mail
        if ( $this->mailTextContentPersonal && $this->personalization ) {
            $plainText = new ezcMailText( $this->mailTextContentPersonal, $this->charset );
        } else {
            $plainText = new ezcMailText( $this->mailTextContent, $this->charset );
        }
        $plainText->subType = 'plain';

        if ( $this->mailHtmlContentPersonal && $this->personalization ) {
            $htmlText = new ezcMailText( $this->mailHtmlContentPersonal, $this->charset );
        } else {
            $htmlText = new ezcMailText( $this->mailHtmlContent, $this->charset );
        }
        $htmlText->subType = 'html';

        $this->bothParts = new ezcMailMultipartAlternative( $plainText, $htmlText );

        // Building text-mail
        if ( $this->mailTextContentPersonal && $this->personalization ) {
            $this->plainTextOnly = new ezcMailText( $this->mailTextContentPersonal, $this->charset );
        } else {
            $this->plainTextOnly = new ezcMailText( $this->mailTextContent, $this->charset );
        }

        $this->plainTextOnly->subType = 'plain';
    }

    /**
     * Send mail
     *
     * @param int $userID Set 0 for test emails
     * @param string $emailAddress
     * @param int $emailType
     */
    function sendMail( $userID, $emailAddress, $emailType ) {

        $this->mail->to = array( new ezcMailAddress( $emailAddress, '', $this->charset ) );

        if ( $this->personalization ) {
            $this->personalize( $userID );
        }

        if($emailType == '0'){
            $this->mail->body = $this->plainTextOnly;
        } else{
            $this->mail->body = $this->bothParts;
        }

        $this->transport->send( $this->mail );

        if ( $this->logEveryReceiver ) {
            eZLog::write( "nvNewsletterMailer (nvnewslettermailer.php): mail sent to ".$this->getReceiverEmail(), "nvnewsletter_mail.log" );
        }
    }

    /**
     * Get mail availability
     *
     * @return boolean
     */
    function getMailAvailability() {
        return $this->mailAvailability;
    }

    /**
     * Get pregenerated data availability
     *
     * @return boolean
     */
    function getPregeneratedDataAvailability() {
        return $this->pregeneratedDataAvailability;
    }
}
?>
