var classapproveLocationCollaborationHandler =
[
    [ "activateApproval", "classapproveLocationCollaborationHandler.html#a757da36264a6111a45591cb525554eed", null ],
    [ "approveLocationCollaborationHandler", "classapproveLocationCollaborationHandler.html#a5c67a94f7deb03ba9aa57aa9b206e18e", null ],
    [ "checkApproval", "classapproveLocationCollaborationHandler.html#abf4c62e8751d7e56452a605c953f4572", null ],
    [ "content", "classapproveLocationCollaborationHandler.html#a53a3cb5a1a195c216e27f583416fd5f9", null ],
    [ "contentObject", "classapproveLocationCollaborationHandler.html#a70bc23fb2792bc6839b98d76407ed55a", null ],
    [ "contentObjectVersion", "classapproveLocationCollaborationHandler.html#a948cf66fc692056f71b180bbedfad6e8", null ],
    [ "createApproval", "classapproveLocationCollaborationHandler.html#a09eb52d9755756af380d388189154352", null ],
    [ "handleCustomAction", "classapproveLocationCollaborationHandler.html#a4730439042f8fb1d7f0697fb0e8ab942", null ],
    [ "messageCount", "classapproveLocationCollaborationHandler.html#a5a90e51c969b9a4db12503eeea22b639", null ],
    [ "notificationParticipantTemplate", "classapproveLocationCollaborationHandler.html#a4bc020b7655308ec7bd4016f474e976f", null ],
    [ "readItem", "classapproveLocationCollaborationHandler.html#acc69451319c2d2559a1d2c89b0a1319e", null ],
    [ "title", "classapproveLocationCollaborationHandler.html#a6c592dedb9c16f7871a3b2f8a3fde070", null ],
    [ "unreadMessageCount", "classapproveLocationCollaborationHandler.html#a870beb7ad62ca374f0158ab4e23ff15c", null ],
    [ "MESSAGE_TYPE_APPROVE", "classapproveLocationCollaborationHandler.html#a693d7d7c77891f19dca6159ef30ae4e0", null ],
    [ "STATUS_ACCEPTED", "classapproveLocationCollaborationHandler.html#ab005e80cd461b0cf75d1dfa78b1e8703", null ],
    [ "STATUS_DEFERRED", "classapproveLocationCollaborationHandler.html#a441a90c9e3aa2187746cb7eb47c8aa7e", null ],
    [ "STATUS_DENIED", "classapproveLocationCollaborationHandler.html#adee61d74ba36e2a492d5d373b424bec8", null ],
    [ "STATUS_WAITING", "classapproveLocationCollaborationHandler.html#a740fe4db895d600b42ed667dcad2a4a5", null ]
];