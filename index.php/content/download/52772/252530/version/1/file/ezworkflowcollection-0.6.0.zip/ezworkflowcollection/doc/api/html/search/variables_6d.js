var searchData=
[
  ['message_5ftype_5fapprove',['MESSAGE_TYPE_APPROVE',['../classapproveLocationCollaborationHandler.html#a693d7d7c77891f19dca6159ef30ae4e0',1,'approveLocationCollaborationHandler']]]
];
