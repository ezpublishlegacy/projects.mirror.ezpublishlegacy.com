var searchData=
[
  ['readitem',['readItem',['../classapproveLocationCollaborationHandler.html#acc69451319c2d2559a1d2c89b0a1319e',1,'approveLocationCollaborationHandler']]]
];
