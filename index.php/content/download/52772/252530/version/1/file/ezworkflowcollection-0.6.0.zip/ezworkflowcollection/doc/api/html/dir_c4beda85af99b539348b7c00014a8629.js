var dir_c4beda85af99b539348b7c00014a8629 =
[
    [ "addurlaliastype.php", "addurlaliastype_8php.html", [
      [ "addUrlAliasType", "classaddUrlAliasType.html", "classaddUrlAliasType" ]
    ] ]
];