var searchData=
[
  ['unreadmessagecount',['unreadMessageCount',['../classapproveLocationCollaborationHandler.html#a870beb7ad62ca374f0158ab4e23ff15c',1,'approveLocationCollaborationHandler']]]
];
