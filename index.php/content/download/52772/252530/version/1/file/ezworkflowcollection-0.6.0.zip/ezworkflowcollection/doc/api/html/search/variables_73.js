var searchData=
[
  ['status_5faccepted',['STATUS_ACCEPTED',['../classapproveLocationCollaborationHandler.html#ab005e80cd461b0cf75d1dfa78b1e8703',1,'approveLocationCollaborationHandler']]],
  ['status_5fdeferred',['STATUS_DEFERRED',['../classapproveLocationCollaborationHandler.html#a441a90c9e3aa2187746cb7eb47c8aa7e',1,'approveLocationCollaborationHandler']]],
  ['status_5fdenied',['STATUS_DENIED',['../classapproveLocationCollaborationHandler.html#adee61d74ba36e2a492d5d373b424bec8',1,'approveLocationCollaborationHandler']]],
  ['status_5fwaiting',['STATUS_WAITING',['../classapproveLocationCollaborationHandler.html#a740fe4db895d600b42ed667dcad2a4a5',1,'approveLocationCollaborationHandler']]]
];
