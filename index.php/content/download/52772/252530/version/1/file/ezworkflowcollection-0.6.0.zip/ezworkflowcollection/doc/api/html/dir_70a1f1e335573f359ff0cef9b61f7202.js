var dir_70a1f1e335573f359ff0cef9b61f7202 =
[
    [ "publish.php", "publish_8php.html", "publish_8php" ],
    [ "updateobjectstate.php", "updateobjectstate_8php.html", "updateobjectstate_8php" ],
    [ "workflow2.php", "workflow2_8php.html", "workflow2_8php" ]
];