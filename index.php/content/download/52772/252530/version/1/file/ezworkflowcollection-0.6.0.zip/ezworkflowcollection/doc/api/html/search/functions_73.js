var searchData=
[
  ['storedefinedeventdata',['storeDefinedEventData',['../classmultiPublishType.html#a497a5ae06071c536e328110088d211fb',1,'multiPublishType']]],
  ['storeeventdata',['storeEventData',['../classmultiPublishType.html#a9b99e8529b36da87de2df474b57db46f',1,'multiPublishType']]]
];
