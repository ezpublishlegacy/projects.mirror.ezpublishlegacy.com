<?php

class ezworkflowcollectionInfo
{
    static function info()
    {
        return array( 'Name' => "ezworkflowcollection",
                      'Version' => "0.6.0",
                      'Copyright' => "Copyright (C) 2010-2012 G. Giunta - O. Portier",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>