var hierarchy =
[
    [ "eZApproveType", null, [
      [ "approveLocationType", "classapproveLocationType.html", null ]
    ] ],
    [ "eZCollaborationItemHandler", null, [
      [ "approveLocationCollaborationHandler", "classapproveLocationCollaborationHandler.html", null ]
    ] ],
    [ "ezworkflowcollectionInfo", "classezworkflowcollectionInfo.html", null ],
    [ "eZWorkflowEventType", null, [
      [ "addUrlAliasType", "classaddUrlAliasType.html", null ],
      [ "copyChildrenOnAddLocationType", "classcopyChildrenOnAddLocationType.html", null ],
      [ "copyNodeToAllParentLocationsType", "classcopyNodeToAllParentLocationsType.html", null ],
      [ "expireremotecacheflowType", "classexpireremotecacheflowType.html", null ],
      [ "multiPublishType", "classmultiPublishType.html", null ],
      [ "objectStateUpdateType", "classobjectStateUpdateType.html", null ],
      [ "SubTreeMultiplexerType", "classSubTreeMultiplexerType.html", null ]
    ] ]
];