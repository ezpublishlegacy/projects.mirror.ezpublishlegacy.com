var annotated =
[
    [ "addUrlAliasType", "classaddUrlAliasType.html", "classaddUrlAliasType" ],
    [ "approveLocationCollaborationHandler", "classapproveLocationCollaborationHandler.html", "classapproveLocationCollaborationHandler" ],
    [ "approveLocationType", "classapproveLocationType.html", "classapproveLocationType" ],
    [ "copyChildrenOnAddLocationType", "classcopyChildrenOnAddLocationType.html", "classcopyChildrenOnAddLocationType" ],
    [ "copyNodeToAllParentLocationsType", "classcopyNodeToAllParentLocationsType.html", "classcopyNodeToAllParentLocationsType" ],
    [ "expireremotecacheflowType", "classexpireremotecacheflowType.html", "classexpireremotecacheflowType" ],
    [ "ezworkflowcollectionInfo", "classezworkflowcollectionInfo.html", "classezworkflowcollectionInfo" ],
    [ "multiPublishType", "classmultiPublishType.html", "classmultiPublishType" ],
    [ "objectStateUpdateType", "classobjectStateUpdateType.html", "classobjectStateUpdateType" ],
    [ "SubTreeMultiplexerType", "classSubTreeMultiplexerType.html", "classSubTreeMultiplexerType" ]
];