<?php /*

[HandlerSettings]
Extensions[]=ezworkflowcollection
Repositories[]=extension/ezworkflowcollection/collaborationhandlers
Active[]=approvelocation


*/ ?>