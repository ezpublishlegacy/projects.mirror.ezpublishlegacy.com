var files =
[
    [ "collaborationhandlers", "dir_d7b355a8d9e0f84d3ba0504fab535490.html", "dir_d7b355a8d9e0f84d3ba0504fab535490" ],
    [ "cronjobs", "dir_70a1f1e335573f359ff0cef9b61f7202.html", "dir_70a1f1e335573f359ff0cef9b61f7202" ],
    [ "eventtypes", "dir_78bfc1ad40c9c2a2a8bf339d9743c1c5.html", "dir_78bfc1ad40c9c2a2a8bf339d9743c1c5" ],
    [ "modules", "dir_e05d7e2b1ecd646af5bb94391405f3b5.html", "dir_e05d7e2b1ecd646af5bb94391405f3b5" ],
    [ "ezinfo.php", "ezinfo_8php.html", [
      [ "ezworkflowcollectionInfo", "classezworkflowcollectionInfo.html", "classezworkflowcollectionInfo" ]
    ] ]
];