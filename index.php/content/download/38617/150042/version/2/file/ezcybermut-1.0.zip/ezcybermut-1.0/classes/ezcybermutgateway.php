<?php

// Activate validation function to register
ext_activate('ezcybermut','classes/ezcybermutchecker.php');

include_once('kernel/shop/classes/ezpaymentgateway.php');

require_once('extension/ezcybermut/classes/ezcybermuthelper.php');


// Define different variables
define("EZ_PAYMENT_GATEWAY_TYPE_EZCyberMut", "eZCyberMut");

define("EZ_PAYMENT_GATEWAY_CYBERMUT_NOT_ACCEPTED", 1);
define("EZ_PAYMENT_GATEWAY_CYBERMUT_ACCEPTED", 2);


class eZCyberMutGateway extends eZPaymentGateway
{
	/*!
	 Constructor.
	*/
	function eZCyberMutGateway()
	{
		// Load ini
		$this->ini =& eZINI::instance('ezcybermut.ini');

		// Load var dir
		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");

		//__DEBUG__
		$this->logger = eZPaymentLogger::CreateForAdd($iniVarDir."/log/eZCyberMutGateway.log");
		$this->logger->writeTimedString('eZCyberMutGateway::eZCyberMutGateway()');
		//___end____
	}

	/*!
	    Creates new eZCyberMutGateway object.
	*/
	function execute(&$process, $event)
	{
		//__DEBUG__
		$this->logger->writeTimedString("eZCyberMut : execute");
		//___end____


		// Must declare checker to handle a response to shop/checkout
		$checker =& new eZCyberMutChecker();

		// If data was posted to shop/checkout then change state
		if($checker->handleResponse())
		{
			// Put workflow in result mode
			$process->setAttribute('event_state', EZ_PAYMENT_GATEWAY_ACCEPTED);
		}

		// Switch between two state of workflow process
		switch ($process->attribute('event_state'))
		{
			// Load the request
			case EZ_PAYMENT_GATEWAY_CYBERMUT_NOT_ACCEPTED :
			{
				//__DEBUG__
				$this->logger->writeTimedString("eZCyberMut : eZCyberMut Request");
				//___end____

				return $this->handleRequest($process);
			}
			break;

			// This order has been treated
			case EZ_PAYMENT_GATEWAY_CYBERMUT_ACCEPTED :
			{
				return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
			}
			break;
		}
	}

	/*!
	    Handle request
	*/
	function handleRequest(&$process, $errors = 0)
	{
		// Get process params
		$processParams =& $process->attribute('parameter_list');
		$orderID = $processParams['order_id'];

		// Get order
		$order =& eZOrder::fetch($orderID);

		// Get total including tax
		$amount = sprintf("%01.2lf",$order->attribute('total_inc_vat'));

		// Request CGI

		$cmcic_helper = new eZCyberMutHelper( $this->ini );

		$CMCIC_Tpe = $cmcic_helper->CMCIC_getMyTpe();               // TPE init variables
		$CtlHmac   = $cmcic_helper->CMCIC_CtlHmac($CMCIC_Tpe);      // TPE ok feedback

		// R�f�rence: unique, alphaNum (A-Z a-z 0-9), longueur maxi 12 caract�res

		$session_id = eZHTTPTool::getSessionKey();
		$Reference_Cde = urlencode(substr($orderID, 0, 12));

		// Langue: page de paiement "FR","EN","DE","IT","ES" selon options souscrites
		$Language_2   = $cmcic_helper->getLanguage()."FR";   
		$Code_Langue   = urlencode(substr($Language_2 , 0, 2));

		// Code soci�t�: fourni par CM-CIC
		$Code_Societe     = $CMCIC_Tpe['soc'];

		// Montant: format  "xxxxx.yy" (pas de blancs))
		$Montant          = $amount;

		// Devise: norme ISO 4217 
		$Devise           = "EUR";

		// texte libre: une r�f�rence longue, des contextes de session pour le retour .
		$Texte_Libre      = $session_id;

		// Texte du bouton pour acc�der au serveur CM-CIC
		$Texte_Bouton     = $CMCIC_Tpe['submit']; 


		$Formulaire_Paiement = $cmcic_helper->CreerFormulaireHmac($CMCIC_Tpe,
											$Montant,
                                             $Devise,
                                             $Reference_Cde,
                                             $Texte_Libre,
                                             $Code_Langue,
                                             $Code_Societe,
                                             $Texte_Bouton);

		$cybermut = eregi_replace("<br>","",$Formulaire_Paiement);

		$process->Template = array('templateName' => 'design:requestCyberMut.tpl',
					'templateVars' => array('page_title' => $cmcic_helper->getPageTitle(),
					'page_text' => $cmcic_helper->getPageText(),
					'page_logo' => $cmcic_helper->getLogoFilename(),
					'CyberMut' => $cybermut,
					),
				);

		// Return the workflow status - I don't know why
		return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
	}
}

eZPaymentGatewayType::registerGateway(EZ_PAYMENT_GATEWAY_TYPE_EZCyberMut, "ezcybermutgateway", "eZCyberMut");

?>

