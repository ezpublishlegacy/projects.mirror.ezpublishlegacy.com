<?php

// functions below have been copied from Cybermut example files and adapted to the needs.

$rp = realpath(dirname(__FILE__));

require_once( "extension/ezcybermut/lib/CMCIC_HMAC.inc.php");

if ( !function_exists('CMCIC_hmac') ) { 
	echo ('cant require hmac function.'); 
	die ('cant require hmac function.'); 
}

// unfortunately, the CMCIC_hmac function provided by the include above needs to be modified
// through a source code modification. I don't like this idea, as I prefer having all
// configuration done through the config file of the eZ extension.
// Therefore, I redefine it here as a method, but with the 'pass' parameter
// defined through the ini file... 

class eZCyberMutHelper {

	function eZCyberMutHelper( $ini )
	{
		if ( $ini ) {
			$this->ini = $ini; 
		} else {
			$this->ini =& eZINI::instance('ezcybermut.ini');
		}
	}


	// ----------------------------------------------------------------------------
	// function CMCIC_getMyTpe
	//
	// IN:  Code société / Company code
	//      Code langue / Language code
	// OUT: Tableau contenant les champs suivants (paramètres du tpe):
	//       tpe: Numéro de tpe / TPE number
	//       soc: Code société / Company code
	//       key: Clé / Key
	//       251retourok: Url retour ok / Return url ok
	//       retourko: Url retour non ok / Return url non ok
	//       submit: Texte du bouton pour accéder à la page de paiement /
	//       Text button to access payment page
	//
	// Description: Get TPE Number, 2nd part of Key and other Merchant
	//              Configuration. Datas from Merchant DataBase
	//                           ********************
	//              Rechercher le numéro de TPE, la 2nde partie de clef et autres
	//              infos de configuration Marchand
	// ----------------------------------------------------------------------------
	function CMCIC_getMyTpe($soc="mysoc",$lang="")
	{

		$MyTpe = array ( 
			"tpe" => $this->ini->variable('eZCyberMutSettings', 'tpe'), 
			"soc" => $this->ini->variable('eZCyberMutSettings', 'soc'),
			"key" => $this->ini->variable('eZCyberMutSettings', 'key')
		);
		$MyTpe["submit"] = $this->ini->variable('eZCyberMutSettings', 'submit');
		$MyTpe["cgi2"] = $this->ini->variable('eZCyberMutSettings', 'cgi2');
		$MyTpe["retourok"] = $this->ini->variable('eZCyberMutSettings', 'retourok'); 
		$MyTpe["retourko"]   = $this->ini->variable('eZCyberMutSettings', 'retourko'); 

		return $MyTpe;
	}


	function getLanguage( )
	{
		$lang   = $this->ini->variable('eZCyberMutSettings', 'lang'); 
		return $lang;
	}

	function getPageTitle( )
	{
		$title   = $this->ini->variable('eZCyberMutSettings', 'tpl_title'); 
		return $title;
	}

	function getPageText( )
	{
		$text   = $this->ini->variable('eZCyberMutSettings', 'tpl_text'); 
		return utf8_encode($text);
	}

	function getLogoFilename( )
	{
		$filename   = $this->ini->variable('eZCyberMutSettings', 'tpl_logo'); 
		return $filename;
	}

	function CMCIC_CtlHmac($CMCIC_Tpe) 
	{
		return CMCIC_CtlHmac($CMCIC_Tpe);
	}

	// this function should be identic to the one provided by the kit,
	// but it uses the INI file to get the $pass parameter, instead of
	// hard-wiring it. This way, we can use the ini file. 

	function CMCIC_hmac($CMCIC_Tpe, $data="")
	{
		$pass = $this->ini->variable('eZCyberMutSettings', 'pass');


		$k1 = pack("H*",sha1($pass));
		$l1 = strlen($k1);
		$k2 = pack("H*",$CMCIC_Tpe['key']);
		$l2 = strlen($k2);
		if ($l1 > $l2):
			$k2 = str_pad($k2, $l1, chr(0x00));
		elseif ($l2 > $l1):
			$k1 = str_pad($k1, $l2, chr(0x00));
		endif;

		if ($data==""):
			$d = "CtlHmac".CMCIC_VERSION.$CMCIC_Tpe['tpe'];
		else:
			$d = $data;
		endif;

		return strtolower(hmac_sha1($k1 ^ $k2, $d));
	}

	// ----------------------------------------------------------------------------
	// function TesterHmac
	//
	// IN: Paramètres du Tpe / Tpe parameters
	//     Champs du formulaire / Form fields
	// OUT: Résultat vérification / Verification result
	// description: Vérifier le MAC et préparer la Reponse
	//              Perform MAC verification and create Receipt
	// ----------------------------------------------------------------------------
	function TesterHmac($CMCIC_Tpe, $CMCIC_bruteVars )
	{
	   @$php2_fields = sprintf(CMCIC_PHP2_FIELDS, $CMCIC_bruteVars['retourPLUS'], 
												  $CMCIC_Tpe["tpe"], 
												  $CMCIC_bruteVars["date"],
												  $CMCIC_bruteVars['montant'],
												  $CMCIC_bruteVars['reference'],
												  $CMCIC_bruteVars['texte-libre'],
												   CMCIC_VERSION,
												  $CMCIC_bruteVars['code-retour']);

		if ( strtolower($CMCIC_bruteVars['MAC'] ) == $this->CMCIC_hmac($CMCIC_Tpe, $php2_fields) ):
			$result  = $CMCIC_bruteVars['code-retour'].$CMCIC_bruteVars['retourPLUS'];
			$receipt = CMCIC_PHP2_MACOK;
		else: 
			$result  = 'None';
			$receipt = CMCIC_PHP2_MACNOTOK.$php2_fields;
		endif;

		$mnt_lth = strlen($CMCIC_bruteVars['montant'] ) - 3;
		if ($mnt_lth > 0):
			$currency = substr($CMCIC_bruteVars['montant'], $mnt_lth, 3 );
			$amount   = substr($CMCIC_bruteVars['montant'], 0, $mnt_lth );
		else:
			$currency = "";
			$amount   = $CMCIC_bruteVars['montant'];
		endif;

		return array( "resultatVerifie" => $result ,
					  "accuseReception" => $receipt ,
					  "tpe"             => $CMCIC_bruteVars['TPE'],
					  "reference"       => $CMCIC_bruteVars['reference'],
					  "texteLibre"      => $CMCIC_bruteVars['texte-libre'],
					  "devise"          => $currency,
					  "montant"         => $amount);
	}

	// ----------------------------------------------------------------------------
	// function HtmlEncode
	//
	// IN:  chaine a encoder / String to encode
	// OUT: Chaine encodée / Encoded string
	//
	// Description: Encode special characters under HTML format
	//                           ********************
	//              Encodage des caractères speciaux au format HTML
	// ----------------------------------------------------------------------------
	function HtmlEncode ($data)
	{
		$SAFE_OUT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890._-";
		$encoded_data = "";
		$result = "";
		for ($i=0; $i<strlen($data); $i++)
		{
			if (strchr($SAFE_OUT_CHARS, $data{$i})) {
				$result .= $data{$i};
			}
			else if (($var = bin2hex(substr($data,$i,1))) <= "7F"){
				$result .= "&#x" . $var . ";";
			}
			else
				$result .= $data{$i};
				
		}
		return $result;
	}

	// ----------------------------------------------------------------------------
	// function CreerFormulaireHmac
	//
	// IN: Numéro de TPE / TPE number
	//     Référence commande/ Order reference
	//     Code langue / Language code
	//     Code société / Company code
	//     Montant / Amount
	//     Devise / Currency
	//     Texte libre / Order Comment
	//     Texte du bouton / Button Text
	// OUT: Formulaire de paiement / Payment form
	//
	// Description: Génération du formulaire / Format CMCIC Payment Form
	// ----------------------------------------------------------------------------
	function CreerFormulaireHmac(  $CMCIC_Tpe,
								   $Amount,
								   $Currency,
								   $Order_Reference,
								   $Order_Comment,
								   $Language_Code,
								   $Merchant_Code,
								   $Button_Text)
	{
		// Prepare the return link. Context will be added to return Url
		// Préparation du lien de retour. Un contexte est ajouté au lien.
		$Return_Context = "?order_ref=".$Order_Reference;

		if ($Order_Comment == "") { $Order_Comment .= "-"; }

		$Order_Date = date("d/m/Y:H:i:s");
		$Language_2 = substr($Language_Code, 0, 2);

		$PHP1_FIELDS = sprintf(CMCIC_PHP1_FIELDS, "",
												  $CMCIC_Tpe["tpe"],
												  $Order_Date,
												  $Amount,
												  $Currency,
												  $Order_Reference,
												  $Order_Comment,
												  CMCIC_VERSION,
												  $Language_2,
												  $Merchant_Code);

		$keyedMAC = $this->CMCIC_hmac($CMCIC_Tpe, $PHP1_FIELDS);

		// the CMC API defines these two variables:
		// we override them through our INI settings.
		// 
		//define("CMCIC_DIR", "/test/");
		//define("CMCIC_SERVER", "undefined.bank.server");

		$ourCMCIC_DIR = $this->ini->variable('eZCyberMutSettings', 'cmcic_dir');
		$ourCMCIC_SERVER = $this->ini->variable('eZCyberMutSettings', 'cmcic_server'); 

		return sprintf(CMCIC_PHP1_FORM, $this->HtmlEncode( $ourCMCIC_SERVER ),
										$this->HtmlEncode( $ourCMCIC_DIR ),
										$this->HtmlEncode( CMCIC_VERSION ), 
										$this->HtmlEncode( $CMCIC_Tpe["tpe"] ),
										$this->HtmlEncode( $Order_Date ),
										$this->HtmlEncode( $Amount ),
										$this->HtmlEncode( $Currency ),
										$this->HtmlEncode( $Order_Reference ),
										$this->HtmlEncode( $keyedMAC ),
										$this->HtmlEncode( $CMCIC_Tpe["retourko"] ),
										$this->HtmlEncode( $Return_Context ),
										$this->HtmlEncode( $CMCIC_Tpe["retourok"] ),
										$this->HtmlEncode( $Return_Context ),
										$this->HtmlEncode( $CMCIC_Tpe["retourko"] ),
										$this->HtmlEncode( $Return_Context ),
										$this->HtmlEncode( $Language_2 ),
										$this->HtmlEncode( $Merchant_Code ),
										$this->HtmlEncode($Order_Comment),
										$this->HtmlEncode( $Button_Text ));
	}
}
?>
