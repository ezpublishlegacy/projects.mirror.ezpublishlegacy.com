<?php

include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once('kernel/shop/ezshopoperationcollection.php');
include_once('kernel/classes/ezbasket.php');

// include helper class
require_once('extension/ezcybermut/classes/ezcybermuthelper.php');

class eZCyberMutChecker extends eZPaymentCallbackChecker
{
	
	//    C'tor
	function eZCyberMutChecker()
	{
		$this->eZPaymentCallbackChecker('ezcybermut.ini');

		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");

		$this->logger =& eZPaymentLogger::CreateForAdd($iniVarDir."/log/eZCyberMutGateway.log");
		$this->logger->writeTimedString('eZCyberMutChecker::eZCyberMutChecker()');
	}

	/*!
	    Parses 'POST' response and create array with received data.
	*/
	function createDataFromPOST()
	{
		//__DEBUG__
		$this->logger->writeTimedString('eZCyberMut : createDataFromPOST');
		//___end____

		eZSys::removeMagicQuotes();

		$CMCIC_reqMethod  = $_SERVER["REQUEST_METHOD"];
		
		if ( $CMCIC_reqMethod == "GET") {
			$CMCIC_bruteVars  = $_GET;		// should only happen during tests... handy for debugging
		} else if ( $CMCIC_reqMethod == "POST") {
			$CMCIC_bruteVars  = $_POST;
		}
		else
			die ('Invalid REQUEST_METHOD (not GET, not POST).');

		// TPE variables
		$cmcic_helper = new eZCyberMutHelper( null );

		$CMCIC_Tpe = $cmcic_helper->CMCIC_getMyTpe();               // TPE init variables

		// Message Authentication
		@$CMCIC_authVars   = $cmcic_helper->TesterHmac($CMCIC_Tpe, $CMCIC_bruteVars );

		@$Verified_Result  = $CMCIC_authVars['resultatVerifie'];

		// if this is different to None, we certified that the data
		// comes from the bank and has not been altered.
		//
		// <<<--- code <<<--- 
		// (Cas / Case : "None" , "Annulation" , "Payetest", "Paiement")
		//-----------------------------------------------------------------------------

		$ourCMCIC_DIR = $this->ini->variable('eZCyberMutSettings', 'cmcic_dir');

		$this->checkerData = array();

		// make sure we get one of the four lowercase result codes 
		$responseLine = strtolower($Verified_Result);
		if (strpos($responseLine,"payetest")!== false) $response="payetest";
		else if (strpos($responseLine,"paiement")!== false) $response="paiement";
		else if (strpos($responseLine,"annulation")!== false) $response="annulation";
		else $response="none";

		
		if ( $response == "none" ) {
				$this->logger->writeTimedString('eZCyberMut : Unable to decode Result');
				$this->logger->writeTimedString('eZCyberMut : Post parameters were: '.$responseLine);
				return false;
		}

		// we got valid data in the CMCIC_authVars array:

		$this->checkerData['order_id'] = $CMCIC_authVars["reference"];
		$this->checkerData['return_context'] = $CMCIC_authVars["texteLibre"];
		$this->checkerData['result_code'] = $Verified_Result;
		
		// CANCELLED

		if ( $response == "annulation")
		{
				$this->logger->writeTimedString('eZCyberMut : CANCELLED');
				$this->logger->writeTimedString('eZCyberMut : Post parameters were: '.$var1);
				//-----------------------------------------------------------------------------
				@printf (CMCIC_PHP2_RECEIPT, $CMCIC_authVars['accuseReception']);
				return false;
		} 
		
		// APPROVED (TEST OR PRODUCTION )

		else if ( ( $response == "paiement" )
			|| (  ( $response == "payetest" ) && ( strpos( $ourCMCIC_DIR , "test" )!== false ) ) )
		{
			$this->logger->writeTimedString("eZCyberMut : Payment accepted");
			//-----------------------------------------------------------------------------
			@printf (CMCIC_PHP2_RECEIPT, $CMCIC_authVars['accuseReception']);
			return true;
		}
	}


	/*!
	    Parses 'POST' response and create array with received data.
	*/
	function ajustStock($order)
	{
		//__DEBUG__
		$this->logger->writeTimedString('eZCyberMut : Ajust Stock');
		//___end____

		$productCollection = $order->productCollection();

		$orderedItems = $productCollection->itemList();

		// List order products
		foreach ($orderedItems as $item)
		{
			$contentObject = $item->contentObject();

			$contentObjectVersion =& $contentObject->version($contentObject->attribute('current_version'));
			$contentObjectAttributes =& $contentObjectVersion->contentObjectAttributes();

			// List attributes
			foreach (array_keys($contentObjectAttributes) as $key)
			{
				$contentObjectAttribute =& $contentObjectAttributes[$key];
				$contentClassAttribute =& $contentObjectAttribute->contentClassAttribute();
				$attributeIdentifier = $contentClassAttribute->attribute("identifier");

				// Each attribute has an attribute identifier called 'quantity' that identifies it.
				if ($attributeIdentifier == "quantity")
				{
					$newQuantite = $contentObjectAttribute->attribute("value") - $item->ItemCount;

					$contentObjectAttribute->fromString($newQuantite);
					$contentObjectAttribute->store();
				}
			}
		}
	}

	/*!
	    Convinces of completion of the payment.
	*/
	function &handleResponse()
	{
		//__DEBUG__
		$this->logger->writeTimedString("eZCyberMut : handleResponse");
		//___end____

		// If data was posted to shop/checkout then change state
		if($this->createDataFromPOST())
		{
			// Retrieve received data for validation
			$orderID = $this->checkerData['order_id'];
 			$sessionID = $this->checkerData['return_context'];
 
			// Get order
			$order =& eZOrder::fetch($orderID);

			// Not accepted so accept it and ajust stocks
			if($order->attribute("is_temporary"))
			{
				// Will activate order but doesnt clean basket as it should
				//eZShopOperationCollection::activateOrder($orderID);

				// Fetch basket with session_id
				$basket = eZBasket::fetch($sessionID);

				// If there is a basket with this sessionID then activate order and remove basket
				if($basket) $basket->remove();

				// Validate order
				$order->activate();

				// Ajust stock
				//$this->ajustStock($order);

				// Payment infos
				
				$paymentInfos  = "Order ID : ".$orderID;
				$paymentInfos .= " - Session ID : ".$sessionID;
				$paymentInfos .= " - bank response : ".$this->checkerData['result_code'];

				// I'm attaching this info to the order inside its XML storage.

				$xml = new eZXML();
				$xmlDoc =& $order->attribute( 'data_text_1' );
				$serializedXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?><shop_account><transaction>".
					$paymentInfos."</transaction></shop_account>";
				if( $xmlDoc != null )
				{
					$dom =& $xml->domTree( $xmlDoc );
					if ($dom) 
					{
						$items =& $dom->elementsByName( "transaction" );
						for( $i = 0, $c = count( $items ); $c > $i ; $i++)
						{
							$element = $items[$i];
							if ( count( $element->Children ) > 0 )
							{
								 foreach( array_keys( $element->Children ) as $key )
								 {
									 $child =& $element->Children[$key];
									 $child->setContent($paymentInfos);
								 }
							}
						}
						$serializedXML = $dom->toString();

					}
				}
				$order->setAttribute( 'data_text_1', $serializedXML );
				$order->store();

				eZShopOperationCollection::sendOrderEmails($orderID);
			}
			return true;
		}
		return false;
	}
}

?>
