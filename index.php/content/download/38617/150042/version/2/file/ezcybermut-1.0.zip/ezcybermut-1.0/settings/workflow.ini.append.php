[EventSettings]
ExtensionDirectories[]=ezcybermut
AvailableEventTypes[]=event_ezcybermut
