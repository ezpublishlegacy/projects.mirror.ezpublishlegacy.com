<?php

// Definition
$Module = array("name" => "eZCyberMut",
                "variable_params" => true,
                "function" => array("script" => "autoresponse.php"));

$ViewList = array();

// Automatic response view
$ViewList['autoresponse'] = array('script' => 'autoresponse.php',
				  'params' => array(),
				 );
?>
