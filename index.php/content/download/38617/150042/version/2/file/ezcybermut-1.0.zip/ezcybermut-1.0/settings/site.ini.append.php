[ExtensionSettings]
ActiveExtensions[]
ActiveExtensions[]=ezcybermut

[RoleSettings]
PolicyOmitList[]=ezcybermut/autoresponse
