<?php

// Simple include once
ext_activate('ezcybermut','classes/ezcybermutchecker.php');

// Start checker
$checker =& new eZCyberMutChecker();

// Checks & Approve | Reject
$checker->handleResponse();

echo "\r\n";

?>
