<?php /*

[RegionalSettings]
TranslationExtensions[]=imageeditor

[TemplateSettings]
ExtensionAutoloadPath[]=ezie

# TODO: remove this before publication
DevelopmentMode=enabled
#Debug=disabled

[DebugSettings]
AlwaysLog[]=1

*/ ?>
