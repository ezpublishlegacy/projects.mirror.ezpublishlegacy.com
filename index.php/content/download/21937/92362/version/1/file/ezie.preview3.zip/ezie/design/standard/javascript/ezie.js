$(document).ready(function() {
    $(".ezieEditButton").ezie();
})
