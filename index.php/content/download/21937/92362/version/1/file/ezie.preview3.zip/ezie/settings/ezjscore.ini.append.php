<?php /* #?ini charset="utf-8"?

[eZJSCore]
PreferredLibrary=jquery

[ezjscServer_imageeditor]
# Url to test this server function(return current time):
# <root>/ezjscore/call/imageeditor::imageReference::<AttributeID>::<ContentObjectVersion>::<ContentObjectID>
Class=ImageEditorServerFunctions

*/
