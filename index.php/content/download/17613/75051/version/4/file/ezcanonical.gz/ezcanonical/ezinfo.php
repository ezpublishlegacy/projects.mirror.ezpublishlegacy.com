<?php
class ezcanonicalInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/ezcanonical">eZ Canonical</a>',
            'Version' => "1.0",
            'Copyright' => "Copyright (C) 2009 Jani Tarvainen",
            'Author' => "Jani Tarvainen",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>