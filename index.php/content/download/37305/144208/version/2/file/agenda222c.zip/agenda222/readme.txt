  Agenda v2.2.2
  		(C) 2006 by Andr� R.
  
	Based on Agenda v1.0:
		(C) 2004 by Stefano Guandalini - nizan
		sg@nizan.net
		http://www.nizan.net
  
	And Agenda "v1.1":
		Modified 04 January 2006 by Per-Espen Kindblad

  This file may be distributed and/or modified under the terms of the
  "GNU General Public License" version 2 as published by the Free
  Software Foundation and appearing in the file LICENSE included in
  the packaging of this file.



*************************************************************************
Index:
*************************************************************************

	1. About
		1.1 File comment
		1.2 Code Comment
	2. Install
		2.1 Creating Agenda event data type
		2.2 Config Template override
		2.3 Installing files
	3. Help

*************************************************************************
1. About:
*************************************************************************

	Agenda 2 is a web Calendar for eZ Publish sites based on the work of
	Stefano Guandalini and Per-Espen Kindblad. But it's kind of a rewrite.
	Insted of producing one fetch for each day in a month, Agenda 2 only 
	fetches the data for the whole month one time. 
	And also with some new features up its sleeve as well.
	!! Agenda is NOT an extension, just some templates, example stylesheet
	   and a guide on how  to set it all up. So don't copy this files to
	   your extension folder.

	!! From now on Agenda(2) is the whole packages, calendar is the specific
	 template view(agenda2.tpl) and Agenda Events is the individual agenda 
	 data entries.



   1.1 File comment:

	 agenda2.tpl	   override for full view of agenda folder
			   as an calendar instead of a long list of events
         agenda2full.tpl   override for full view of Agenda events
	 agenda2.css	   Exampel Styles for Agenda2
	/toolbar	   Folder with two examples of use in pagelayout.tpl
			   directly or as toolbars (see elsewhere on ez.no
			   for how to do this if you don't know !!)


   1.2 Code Comment (agenda2.tpl)
	
	$event_node=$node.node_id:  change $node.node_id to specific agenda
		node if you want to use this calendar in your pagelayout.tpl
		file(or use the toolbar examples)
	$day_array  String with all days that contain something in this
		 manner:  "13, 17, 22, 22, 26, "
	$day_events  array of todays events, filled in first loop, same
		loop as $day_array is being built.




*************************************************************************
2. Install:
*************************************************************************
	2.1 Data type(this is how I set it up, you could do it in a 
			different way. But then you probably have to
			make changes to the templates)
	     !! important: you can change all 'Name' occurences to something
		in your language. As long as the id stays the same, you don't 
		have to change the templates.

		* login to ez Admin
		* go to setup -> classes -> content -> new class

		* Name: 		Agenda Event
		* Identifier: 		event
		* Object name pattern: 	<title>


		* Add attribute:	Text line
		  Name / id:		Title / title
		  check: Req Search
		  Max String: 19  (in my case i display a list of these on my 
				frontpage so I'm width constrained, you can set
				this to whatever suits your self)


		* Add attribute:	Selection
		  Name / id:		Category / category
		  check: Req Search
		  style: Singel choice
			Political
			Sosial
			Meeting
			Educational


		* Add attribute:	Date and time
		  Name / id:		From Time / from_time
		  check: Req disableTranslation
		  def value: current datetime


		* Add attribute:	Date and time
		  Name / id:		To Time / to_time
		  check: Req disableTranslation
		  def value: current datetime


		* Add attribute:	Text block
		  Name / id:		Text / text
		  check: Search
		  rows: 15	(This attribute is easily changable to xmlblock if you
				want to be able to have pictures and formating in your
				text. The downside is that you can't preview some part
				of the text in the calendar view if you choose xmlblock.
				If you still choose to use xmlblock, you should not
				add the URL and Image attribute as they are no longer
				needed. And you also have to change the templates
				to  reflect the changes.)

		* Add attribute:	URL
		  Name / id:		Link / url
		  check: disableTranslation


		* Add attribute:	Image
		  Name / id:		Image / image
		  check: disableTranslation
		  max filesize:  1 MB



	2.2 Override
		1.Put these overrides in your
		  settings/siteaccess/<your siteaccess name>/override.ini.append.php
		  !!! put it in the top of the document
		      (!but beneath the '<?php /* #?ini charset="iso-8859-1"?')
		      because ez reads override.ini from bottom to top
	
		
			[Agenda_Calendar]
			Source=node/view/full.tpl
			MatchFile=full/agenda2.tpl
			Subdir=templates
			Match[node]=131

			[full_Agenda]
			Source=node/view/full.tpl
			MatchFile=full/agenda2full.tpl
			Subdir=templates
			Match[class_identifier]=event
		
		2.Change 131 to the node/folder you are planning to fill with events.



	2.3 Template Files

		*copy agenda2.tpl and agenda2full.tpl to 
		design/<your siteaccess choosen design>/override/full/

		*copy agenda2.css to
		design/<your siteaccess choosen design>/stylesheets/


		*insert this line in your pagelayout file
		<link rel="stylesheet" href={"stylesheets/agenda2.css"|ezdesign} type="text/css" />
	



*************************************************************************
3. Help:
*************************************************************************


	known Stylesheet bugs:
	  css related: Ie does not obey height of calendar (agenda2.tpl)
	  css related: Ie + Opera does not obey height(100%) of Agenda(agenda2.tpl)

	The code is made for eZ Publish 3.6 and higher, so if you want
	this to run on ez 3.5 / 3.4 you'll have to change the following:
		1. Every 'if' to 'section show='
		2. The 'between' filter in the fetching must be changed to one with
		   a 'or + And' logical fetch. (see agenda 1 or "1.1" for how)
		3. For + foreach loops must be changed to section loops
		4. Change from def / undef to let



	For more on HTML and CSS, I recommend
		www.w3schools.com

	For more on eZ publish template coding: 
		ez.no/doc/ez_publish/technical_manual/3_6/reference

	Also see the old ez documentation for more step by step guides:
		ez.no/products/ez_publish_open_source_enterprise_cms/documentation/toc/(from)/29257


	Contact Forum about any bug fixes you have, additions to this readme or general improvements:
		http://ez.no/community/forum/developer/about_agenda_2_contribution

		
		