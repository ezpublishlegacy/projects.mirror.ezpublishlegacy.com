CREATE TABLE ezfedexshippinginfo (
    productcollection_id  int          NOT NULL PRIMARY KEY,
    delivered_by          varchar(100) NOT NULL,
    urgently              int          NOT NULL,
    cost                  float        NOT NULL
);

DROP TABLE ezfedexshipping_courier_prices;
CREATE TABLE ezfedexshipping_courier_prices (
	`id`  INT	NOT NULL auto_increment PRIMARY KEY,
	`courier` INT DEFAULT 0,
	`weight` FLOAT DEFAULT 0,
	`zone_1` FLOAT DEFAULT 0,
	`zone_2` FLOAT DEFAULT 0,
	`zone_3` FLOAT DEFAULT 0,
	`zone_4` FLOAT DEFAULT 0,
	`zone_5` FLOAT DEFAULT 0,
	`zone_6` FLOAT DEFAULT 0,
	`zone_7` FLOAT DEFAULT 0,
	`zone_8` FLOAT DEFAULT 0,
	`zone_9` FLOAT DEFAULT 0,
	`zone_10` FLOAT DEFAULT 0,
	`zone_11` FLOAT DEFAULT 0,
	`zone_12` FLOAT DEFAULT 0,
	`zone_13` FLOAT DEFAULT 0,
	`zone_14` FLOAT DEFAULT 0,
	`zone_15` FLOAT DEFAULT 0
);

DROP TABLE ezfedexshipping_courier_zones;
CREATE TABLE ezfedexshipping_courier_zones (
    `id`  int NOT NULL auto_increment PRIMARY KEY,
    `zone` varchar(300) NOT NULL,
    `zone_id` int NOT NULL
);

DROP TABLE ezfedexshipping_couriers;
CREATE TABLE ezfedexshipping_couriers (
    `id`  int NOT NULL auto_increment PRIMARY KEY,
    `courier_name` varchar(300) NOT NULL
);

