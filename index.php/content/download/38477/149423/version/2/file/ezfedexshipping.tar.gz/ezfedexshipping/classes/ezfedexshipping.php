<?php
//
// Definition of ezfedexshipping class
//
// A FedEx Shipping Class using the destination country and the 
// combined weight of the products to calculate the shipping cost.
//
// Created on: <19-Sep-2006 12:00:00 sf>
// Last Updated: September 19, 2006
// Version: 1.0.b1
//
// Copyright (C) 2006-2006 Grandmore Ltd. All rights reserved.
//
// This source file is part of an extension for the eZ publish (tm)
// Open Source Content Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 (or greater) as published by
// the Free Software Foundation and appearing in the file LICENSE
// included in the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact stuart@grandmore.com if any conditions
// of this licencing isn't clear to you.
//

require_once( 'kernel/classes/ezproductcollection.php' );
require_once( 'kernel/classes/ezproductcollectionitem.php' );
require_once( 'kernel/classes/ezcontentobject.php' );
require_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );

//Define the ID number of the country attribute in the array of user atrributes
define( "COUNTRY_ID_NUMBER", 11);

/*
shipping info = shipping options + shipping cost
*/

class eZFedexShipping
{
    /*!
     Determine shipping cost according to the chosen shipping options.

     \public
     \static
     */
    function calculateCost( $productCollectionID, $shippingOptions )
    {
		//Get product collection
		$collection = eZProductCollection::fetch( $productCollectionID );
        $items = $collection->itemList();

        // Determine total weight.
        $totalWeight = 0;
        foreach ( $items as $item )
        {
            $productID = $item->attribute( 'contentobject_id' );
            if ( !$productID )
                continue;
            $product = eZContentObject::fetch( $item->attribute( 'contentobject_id' ) );
            if ( !is_object( $product ) )
                continue;

            $productWeight = eZFedexShipping::_getProductWeight( $product );
            $productCount  = $item->attribute( 'item_count' );

            $totalWeight += ( $productCount * $productWeight );
        }

		// Get The user details
		$user = &eZUser::currentUser();	
		$user_id = $user->attribute( "contentobject_id" );

		// test for Anonymous user
		if ( ($user_id == 10) and ($shippingOptions['use_alternative_address'] == 0) )	
		{
			$deliveryCost = 0;
		}
		else 
		{
			// test if the customer is using an alternative address.
			if ( $shippingOptions['use_alternative_address'] == 1 )
			{
				$country = $shippingOptions['country'];
			}
			else 
			{
				// Get user obj and attributes
				$contentobject =& eZContentObject::fetch( $user_id );
				$contentobjectAttributes =& $contentobject->attribute( 'contentobject_attributes' );
				$countryArray =  $contentobjectAttributes[COUNTRY_ID_NUMBER]->attribute( "content");
				$country = $countryArray[ 'value' ];
			}
			
			
	        // Determine cost of delivery.
	        switch ( $shippingOptions['delivered_by'] )
	        {
	            case 'FedEx':
	            	//Get the zone of the destination country
					$zone = eZFedexShipping::getZone( $country );
					$costList = eZFedexShipping::getCostList( $totalWeight );
					if ( $costList !== false )
					{
						//find the matching zone for this weight.
						//row one should always be the closest match to the weight
						$zoneText = "zone_" . $zone['zone_id'];
						$deliveryCost = $costList[ $zoneText ];
						
					}
	                break;

	            case 'Self Shipping':
	                $deliveryCost = 0;
	                break;
				
	            // SF Note to self: No code written for mutiple couriers. The database is in place for this and it's all the same 
	            // code apart for searching based on the courier.
	            // so for now we set it to zero
	            case 'UPS':
	                $deliveryCost = 0;
	                break;
	            default:
	                $deliveryCost = 0;
	        }
		}
    	
		

        // Determine urgency cost.
        if ( $shippingOptions['urgently'] )
            $urgencyCost = 10;
        else
            $urgencyCost = 0;

        // Calculate total cost.
        $totalCost = $deliveryCost;


        eZDebug::writeDebug( "Calculated shipping cost = $deliveryCost = $totalCost",
                             'eZFedexShipping::calculateCost()' );

        return $totalCost;
    }

    /*!
     Save shipping options for the given product collection.

     \public
     \static
     */
    function setOptions( $productCollectionID, $shippingOptions )
    {
		$shippingInfo = eZFedexShipping::_fetch( $productCollectionID );
		
        $db = eZDB::instance();

        $deliveredBy 				=       $db->escapeString( $shippingOptions['delivered_by'] );
        $urgently    				= (int) $db->escapeString( $shippingOptions['urgently'] );
        $cost        				=       eZFedexShipping::calculateCost( $productCollectionID, $shippingOptions );
		$shipping_code				=  		$db->escapeString( $shippingOptions['self_shipping_code'] );
	    $company  		 	 		=  		$db->escapeString( $shippingOptions['company' ] );
	    $address_line_1  	 		=  		$db->escapeString( $shippingOptions['address_line_1'] );
	    $address_line_2  	 		=  		$db->escapeString( $shippingOptions['address_line_2'] );
	    $address_line_3  	 		=  		$db->escapeString( $shippingOptions['address_line_3'] );
	    $city  			 	 		=  		$db->escapeString( $shippingOptions['city'] );
	    $postcode  		 	 		=  		$db->escapeString( $shippingOptions['postcode'] );
	    $country  		 	 		=  		$db->escapeString( $shippingOptions['country'] );
	    $use_alternative_address  	= (int) $db->escapeString( $shippingOptions['use_alternative_address'] );
        
        
        if ( $shippingInfo  )
            $query = "UPDATE ezfedexshippinginfo " .
                     "SET delivered_by='$deliveredBy', urgently=$urgently, cost=$cost, self_shipping_code='$shipping_code' " .
                     ", company='$company', address_line_1='$address_line_1', address_line_2='$address_line_2', address_line_3='$address_line_3'" .
                     ", city='$city', postcode='$postcode', country='$country', use_alternative_address=$use_alternative_address " .
                     "WHERE productcollection_id='$productCollectionID' AND completed_productcollection_id = '0' ";
        else
            $query = "INSERT INTO ezfedexshippinginfo (productcollection_id, delivered_by, urgently, cost, self_shipping_code, " .
            		 "company, address_line_1, address_line_2, address_line_3, city, postcode, country, use_alternative_address ) " .
                     "VALUES( '$productCollectionID', '$deliveredBy', $urgently, $cost, '$shipping_code', " .
                     "'$company', '$address_line_1', '$address_line_2', '$address_line_3', '$city', '$postcode', '$country', $use_alternative_address )";

        $result = $db->query( $query );

        return $cost;
    }

    /*!
     Return shipping information (options, calculated cost) for the given
     product collection.

     \public
     \static
     */
    function getInfo( $productCollectionID )
    {
        $shippingInfo = eZFedexShipping::_fetch( $productCollectionID );

        /* If there's no info stored for the given product collection yet
         * then store default shipping options
         * and calculate shipping cost according to them.
         */
        if ( !$shippingInfo )
        {
			$defaultShippingOptions = array(  'delivered_by' 			=> 'FedEx',
                                              'urgently'     			=> false,
			                                  'self_shipping_code'		=> '', 
				                              'company'					=> '',
				                              'address_line_1'			=> '',
				                              'address_line_2'			=> '',
				                              'address_line_3'			=> '',
				                              'city'					=> '',
				                              'postcode'				=> '',
				                              'country'					=> '',
				                              'use_alternative_address'	=> false
			                                 );
			                                 
            $cost = eZFedexShipping::setOptions( $productCollectionID, $defaultShippingOptions );
			
            $shippingInfo = $defaultShippingOptions;
            $shippingInfo['cost'] = $cost;
        }
		else 
		{
			// get current settings then calculate the cost
			$delivered_by 				= $shippingInfo['delivered_by'];
			$urgently 					= $shippingInfo['urgently'];
			$self_shipping_code  		= $shippingInfo['self_shipping_code'];
		    $company  		 	 		= $shippingInfo['company' ] ;
		    $address_line_1  	 		= $shippingInfo['address_line_1'] ;
		    $address_line_2  	 		= $shippingInfo['address_line_2'] ;
		    $address_line_3  	 		= $shippingInfo['address_line_3'] ;
		    $city  			 	 		= $shippingInfo['city'] ;
		    $postcode  		 	 		= $shippingInfo['postcode'] ;
		    $country  		 	 		= $shippingInfo['country'] ;
		    $use_alternative_address	= $shippingInfo['use_alternative_address'] ;
				
			$defaultShippingOptions = array(  'delivered_by' 		=> $delivered_by,
                                              'urgently'     		=> $urgently,
			                                  'self_shipping_code'	=> $self_shipping_code,
				                              'company'				=> $company,
				                              'address_line_1'		=> $address_line_1,
				                              'address_line_2'		=> $address_line_2,
				                              'address_line_3'		=> $address_line_3,
				                              'city'				=> $city,
				                              'postcode'			=> $postcode,
				                              'country'				=> $country,
				                              'use_alternative_address'	=> $use_alternative_address
			                                 );
			                                                                              
			$cost = eZFedexShipping::setOptions( $productCollectionID, $defaultShippingOptions );
			
            $shippingInfo = $defaultShippingOptions;
            $shippingInfo['cost'] = $cost;                                 
		}
        return $shippingInfo;
    }

    /*!
     Purge shipping info for the given product collection.

     This method is usually called when a product collection is removed.

     \public
     \static
     */
    function purgeInfo( $productCollectionID )
    {
        eZDebug::writeDebug( "Purging shipping info for product collection $productCollectionID",
                             'eZFedexShippingInfo::purgeInfo()' );

        $db = eZDB::instance();
        $query = "DELETE FROM ezfedexshippinginfo WHERE productcollection_id='$productCollectionID' AND completed_productcollection_id = '0' ";
        $db->query( $query );
    }

    /*!
     Update shipping cost for the specified product collection.

     This method is usually called when shopping basket is modified
     (e.g. more products are added to it).

     \public
     \static
     */
    function updateCost( $productCollectionID )
    {
        $shippingInfo = eZFedexShipping::_fetch( $productCollectionID );

        if ( !$shippingInfo )
            return;

        eZDebug::writeDebug( "Updating shipping cost for product collection $productCollectionID",
                             'eZFedexShipping::updateCost()' );

        $cost = eZFedexShipping::calculateCost( $productCollectionID, $shippingInfo );
		
		$query = "UPDATE ezfedexshippinginfo SET cost=$cost " .
                 "WHERE productcollection_id='$productCollectionID'  AND completed_productcollection_id = '0' ";
        $db = eZDB::instance();
        $result = $db->query( $query );
        
        
    }

    
    
    
    /*!
     Fetches shipping information for the specified product collection from database.

     \return false if no information found.
     \private
     \static
     */
    function _fetch( $productCollectionID )
    {
        require_once( 'lib/ezdb/classes/ezdb.php' );
        $db = eZDB::instance();
        $rslt = $db->arrayQuery( "SELECT * FROM ezfedexshippinginfo WHERE productcollection_id='$productCollectionID'  AND completed_productcollection_id = '0' ");

        if ( count( $rslt ) > 0 )
            return $rslt[0];
        else
            return false;
    }

    
    
    
    
    
    
    
    /*!
     Returns weight of the specified product.

     \return weight of the specified product, or null on error.
     \private
     \static
     */
    function _getProductWeight( $product )
    {
        $productDataMap  = $product->attribute( 'data_map' );
        if ( !isset( $productDataMap['weight'] ) )
        {
            eZDebug::writeError( "Cannot find attribute 'weight' in the product '" . $product->attribute( 'name' ) . "'" );
            return null;
        }

        $weightAttribute = $productDataMap['weight'];
        $productWeight   = $weightAttribute->attribute( 'content' );

        return $productWeight;
    }


    /*!
	  Get The Zone of the destination country
	   
     \return false if no information found.
     \private
     \static
     */
    function getZone( $country )
    {
        require_once( 'lib/ezdb/classes/ezdb.php' );
        $db = eZDB::instance();
        $query = "SELECT zone_id FROM ezfedexshipping_courier_zones WHERE zone='$country'";
        $rslt = $db->arrayQuery( $query );

        if ( count( $rslt ) > 0 )
            return $rslt[0];
        else
        {
            eZDebug::writeError( "Cannot find Country " . $country . " in table ezfedexshipping_courier_zones" );
            return false;
        }
    }


    /*!
	  Get the Cost based on the zone and the weight
	   
     \return false if no information found.
     \private
     \static
     */
    function getCostList( $weight )
    {
        require_once( 'lib/ezdb/classes/ezdb.php' );
        $db = eZDB::instance();
		$query = "SELECT * FROM `ezfedexshipping_courier_prices` WHERE `weight` >= $weight ORDER BY `weight` ASC LIMIT 0 , 2";
        $rslt = $db->arrayQuery( $query );

        if ( count( $rslt ) > 0 )
            return $rslt[0];
        else
        {
			eZDebug::writeError( "Cannot find Weight " . $weight . " in table ezfedexshipping_courier_prices" );
			return false;
        }
    }












}
?>
