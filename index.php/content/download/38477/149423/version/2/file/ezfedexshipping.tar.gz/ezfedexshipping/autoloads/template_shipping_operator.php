<?php 
//
// Definition of ezfedexshipping class
//
// A FedEx Shipping Class using the destination country and the 
// combined weight of the products to calculate the shipping cost.
//
// Created on: <19-Sep-2006 12:00:00 sf>
// Last Updated: September 19, 2006
// Version: 1.0.b1
//
// Copyright (C) 2006-2006 Grandmore Ltd. All rights reserved.
//
// This source file is part of an extension for the eZ publish (tm)
// Open Source Content Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 (or greater) as published by
// the Free Software Foundation and appearing in the file LICENSE
// included in the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact stuart@grandmore.com if any conditions
// of this licencing isn't clear to you.
//

	class MyShippingOperators
	{   
		/*!    Constructor   */   
		
		function MyShippingOperators()   
		{       
			$this->Operators = array( 'getshippingdetails' );   
		}    
		
		/*!    Returns the operators in this class.   */   
		function &operatorList()   
		{       
			return $this->Operators;   
		}    
		
		/*!   	Return true to tell the template engine that the parameter list   
				exists per operator type, this is needed for operator classes   
				that have multiple operators.   
		*/   
		function namedParameterPerOperator()   
		{       
			return true;   
		}    
		
		/*!    	The first operator has two parameters, the other has none.    
				See eZTemplateOperator::namedParameterList()   */   
		
		function namedParameterList()
		{       
			return array( 'getshippingdetails' => array( 'productCollectionID' => array( 'type' => 'string','required' => true,'default' => ''),
														 'completedID' => array( 'type' => 'string','required' => true,'default' => '') 
														 ) 
						);   
		}    
		
		/*!		Executes the needed operator(s).    
				Checks operator names, and calls the appropriate functions.   */   
		function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )   
		{
			switch ( $operatorName )       
			{           
				case 'getshippingdetails':	
					{ 
						$operatorValue = $this->getShippingDetails( $namedParameters['productCollectionID'] ,
																	$namedParameters['completedID'] );
					}
					break;
			}
		}
		
		
		/*!    Return a famous string.   */   
		function getShippingDetails( $productCollectionID , $completedID )
		{       
			if ( $productCollectionID != NULL)
				return MyShippingOperators::_fetch( $productCollectionID );
			else 	
				return null;
		}    
		/// privatesection   var $Operators;

	
	    /*!
	     Fetches shipping information for the order from database.
	
	     \return false if no information found.
	     \private
	     \static
	     */
	    function _fetch( $productCollectionID )
	    {	    	
	        require_once( 'lib/ezdb/classes/ezdb.php' );
	        $db = eZDB::instance();
	        $rslt = $db->arrayQuery( "SELECT * FROM ezfedexshippinginfo WHERE productcollection_id=$productCollectionID" );
	
	        if ( count( $rslt ) > 0 )
	            return $rslt[0];
	        else
	            return false;
	    }
	
	} 	
?>
			