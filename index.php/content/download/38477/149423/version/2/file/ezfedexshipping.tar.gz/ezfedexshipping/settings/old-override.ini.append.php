<?php /* #?ini charset="iso-8859-1"?

[shipping_basket_full]
Source=node/view/full.tpl
MatchFile=ezfedexshipping/design/standard/template/shop/basket.tpl
Subdir=templates

[shipping_confirmorder_full]
Source=node/view/full.tpl
MatchFile=ezfedexshipping/design/standard/template/shop/confirmorder.tpl
Subdir=templates

[shipping_orderview_full]
Source=node/view/full.tpl
MatchFile=ezfedexshipping/design/standard/template/shop/orderview.tpl
Subdir=templates


*/ ?>