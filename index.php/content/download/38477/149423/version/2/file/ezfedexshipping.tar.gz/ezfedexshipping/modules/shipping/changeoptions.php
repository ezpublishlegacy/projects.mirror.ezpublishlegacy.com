<?php
//
// Definition of ezfedexshipping class
//
// A FedEx Shipping Class using the destination country and the 
// combined weight of the products to calculate the shipping cost.
//
// Created on: <19-Sep-2006 12:00:00 sf>
// Last Updated: September 19, 2006
// Version: 1.0.b1
//
// Copyright (C) 2006-2006 Grandmore Ltd. All rights reserved.
//
// This source file is part of an extension for the eZ publish (tm)
// Open Source Content Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 (or greater) as published by
// the Free Software Foundation and appearing in the file LICENSE
// included in the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact stuart@grandmore.com if any conditions
// of this licencing isn't clear to you.
//

$module =& $Params['Module'];

include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'kernel/classes/ezproductcollection.php' );
ext_activate( 'ezfedexshipping', 'classes/ezfedexshipping.php' );

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

if ( $module->isCurrentAction( 'Cancel' ) )
{
    $module->redirectTo( '/shop/basket/' );
    return;
}
elseif ( $module->isCurrentAction( 'Store' ) )
{
    $productCollectionID 		= (int) $module->actionParameter( 'ProductCollectionID' );
    $deliveredBy         		=       $module->actionParameter( 'DeliveredBy' );
    $urgently            		=       $module->hasActionParameter( 'Urgently' );
    $self_shipping_code  		=       $module->actionParameter( 'self_shipping_code' );
    $company  		 	 		=       $module->actionParameter( 'company' );
    $address_line_1  	 		=       $module->actionParameter( 'address_line_1' );
    $address_line_2  	 		=       $module->actionParameter( 'address_line_2' );
    $address_line_3  	 		=       $module->actionParameter( 'address_line_3' );
    $city  			 	 		=       $module->actionParameter( 'city' );
    $postcode  		 	 		=       $module->actionParameter( 'postcode' );
    $country  		 	 		=       $module->actionParameter( 'country' );
    $use_alternative_address  	=       $module->hasActionParameter( 'use_alternative_address' );


    $shippingOptions = array( 'delivered_by' 				=> $deliveredBy,
                              'urgently'     				=> $urgently, 
                              'self_shipping_code'			=> $self_shipping_code,
                              'company'						=> $company,
                              'address_line_1'				=> $address_line_1,
                              'address_line_2'				=> $address_line_2,
                              'address_line_3'				=> $address_line_3,
                              'city'						=> $city,
                              'postcode'					=> $postcode,
                              'country'						=> $country,
                              'use_alternative_address'		=> $use_alternative_address
                              );

    $cost = eZFedexShipping::setOptions( $productCollectionID, $shippingOptions );

    $module->redirectTo( '/shop/basket/' );
    return;
}
elseif ( $module->isCurrentAction( 'Calculate' ) )
{
	    $productCollectionID 		= (int) $module->actionParameter( 'ProductCollectionID' );
	    $deliveredBy         		=       $module->actionParameter( 'DeliveredBy' );
	    $urgently            		=       $module->hasActionParameter( 'Urgently' );
	    $self_shipping_code  		=       $module->actionParameter( 'self_shipping_code' );
	    $company  		 	 		=       $module->actionParameter( 'company' );
	    $address_line_1  	 		=       $module->actionParameter( 'address_line_1' );
	    $address_line_2  	 		=       $module->actionParameter( 'address_line_2' );
	    $address_line_3  	 		=       $module->actionParameter( 'address_line_3' );
	    $city  			 	 		=       $module->actionParameter( 'city' );
	    $postcode  		 	 		=       $module->actionParameter( 'postcode' );
	    $country  		 	 		=       $module->actionParameter( 'country' );
	    $use_alternative_address  	=       $module->hasActionParameter( 'use_alternative_address' );
	
	    $shippingOptions = array( 'delivered_by' 				=> $deliveredBy,
	                              'urgently'     				=> $urgently, 
	                              'self_shipping_code'			=> $self_shipping_code,
	                              'company'						=> $company,
	                              'address_line_1'				=> $address_line_1,
	                              'address_line_2'				=> $address_line_2,
	                              'address_line_3'				=> $address_line_3,
	                              'city'						=> $city,
	                              'postcode'					=> $postcode,
	                              'country'						=> $country,
	                              'use_alternative_address'		=> $use_alternative_address
	                              );
	
	    $cost = eZFedexShipping::calculateCost( $productCollectionID, $shippingOptions );
	
	    $tpl->setVariable( 'shipping_options', $shippingOptions );
	    $tpl->setVariable( 'cost', $cost );
	    
	}
	else // action: show current shipping options
	{
	    $productCollectionID = $Params['ProductCollectionID'];
	
	    $shippingInfo = eZFedexShipping::getInfo( $productCollectionID );
	
	    $tpl->setVariable( 'shipping_options', $shippingInfo );
	    $tpl->setVariable( 'cost', $shippingInfo['cost'] );
	}
	
	
	// We need to access product collection from template
	// to format currency correctly.
	$productCollection = eZProductCollection::fetch( $productCollectionID );
	
	$tpl->setVariable( 'product_collection', $productCollection );
	$text =& $tpl->fetch( "design:shipping/changeoptions.tpl" );
	
	// Build module result array
	$Result = array();
	$Result['content'] = $text;
	$Result['path'] = array( array( 'url' => false,
	                                'text' => "Shipping options" ) );
?>
