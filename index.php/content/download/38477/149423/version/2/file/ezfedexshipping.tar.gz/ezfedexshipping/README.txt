Description
===========

This is a sample shipping handler that determines shipping cost based on
products' total weight, delivery type and urgency flag with the following formula:

 cost = total_products_weight * delivery_cost_factor + urgency_cost


Setup
=====

1. Unpack the extension under "extension" directory of your eZ publish installation.
2. Execute extension/ezfedexshipping/sql/create.sql on your database.
3. Add new attribute "weight" of type "float" to your Product class.
4. Set weight for your products.
5. Go to "Setup -> Extensions" and activate the extension.

Voila. Now in the shopping basket you can adjust your shipping
options by choosing delivery type and/or setting urgency flag.


Requirements
============

eZ publish 3.8+.
