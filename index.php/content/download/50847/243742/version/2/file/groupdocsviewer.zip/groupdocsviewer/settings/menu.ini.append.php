<?php /*
[NavigationPart]
Part[groupdocsnavigationpart]=GD Viewer
[TopAdminMenu]
Tabs[]=groupdocs
[Topmenu_groupdocs]
NavigationPartIdentifier=groupdocsnavigationpart
Name=Groupdocs Viewer
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsviewer/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>