<?php
 
// Which operators will load automatically? 
$eZTemplateOperatorArray = array();
 
// Operator: gvddata 
$eZTemplateOperatorArray[] = array( 'class' => 'GVDOperator',
                                    'operator_names' => array( 'gvd' ) ); 
?>