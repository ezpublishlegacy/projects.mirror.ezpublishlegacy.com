<?php /*
 
[CronjobSettings]
ExtensionDirectories[]=cscomment
Scripts[]
Scripts[]=cleancomment.php
Scripts[]=addsharding.php


[CronjobPart-cscomment]
ExtensionDirectories[]=cscomment
Scripts[]
Scripts[]=cleancomment.php

[CronjobPart-cssharding]
ExtensionDirectories[]=cscomment
Scripts[]
Scripts[]=addsharding.php


*/ ?>
