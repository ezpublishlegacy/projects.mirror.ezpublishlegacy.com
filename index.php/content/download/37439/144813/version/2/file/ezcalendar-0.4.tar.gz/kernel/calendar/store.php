<?php
//
// Created on: <27-Aug-2002 15:42:43 bf>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

include_once( "kernel/classes/ezcalendar.php" );
//include_once( "kernel/common/template.php" );

$http =& eZHTTPTool::instance();
$Module =& $Params["Module"];


$eventid=$http->Variable('eventid');

$start_time=mktime((int) $http->Variable('start_hour'), (int) $http->Variable('start_min'),0,(int) $http->Variable('start_month'),(int) $http->Variable('start_day'), (int) $http->Variable('start_year'));
$end_time=mktime((int) $http->Variable('end_hour'), (int) $http->Variable('end_min'),0,(int) $http->Variable('end_month'),(int) $http->Variable('end_day'), (int) $http->Variable('end_year'));

$db =& eZDB::instance();
$db->query( "UPDATE ezcalendarevents SET start_time='$start_time', end_time='$end_time', description='".$http->Variable('description')."', frequency='".$http->Variable('frequency')."', number_of_times='".$http->Variable('number_of_times'). "' WHERE (eventid='$eventid' AND userid='". eZUser::currentUserID() ."')");
// commit the transaction
$db->commit(); //won't return id if commit is called with MySQL (not sure about Postgre)

if ($start_time > $end_time)
{
    $Module->redirectTo( $Module->functionURI( "edit" ) . "?eventid=$eventid&message=End Time may not be before Start Time" );
    return;
}

if (($http->Variable('frequency')!='once') AND ($http->Variable('number_of_times')==0))
{
    $Module->redirectTo( $Module->functionURI( "edit" ) . "?eventid=$eventid&message=You may not set number of times to 0" );
    return;
}

$Module->redirectTo( $Module->functionURI( "week" ) . "?timestamp=$start_time" );
return;

?>
