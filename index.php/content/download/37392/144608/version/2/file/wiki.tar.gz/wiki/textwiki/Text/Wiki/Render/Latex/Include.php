<?php
class Text_Wiki_Render_Latex_Include extends Text_Wiki_Render {    
    function token()
    {
        return '';
    }
}
?>