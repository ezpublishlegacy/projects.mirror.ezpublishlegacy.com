[TemplateSettings]
ExtensionAutoloadPath[]=wiki

[ExtensionSettings]
ActiveExtensions[]=wiki

[RoleSettings]
PolicyOmitList[]=wiki


