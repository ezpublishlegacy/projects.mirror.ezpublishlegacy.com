<?php

$Module = array( 'name' => 'wiki' );

$ViewList = array();
$ViewList['create'] = array(
    'script' => 'create.php',
    "unordered_params" => array( "parentnodeid" => "parentNodeID", 
                                 "newnodename" => "newNodeName",
                                 "redirecturiafterpublish" => "RedirectURIAfterPublish" ) 
     );

$ViewList['diff'] = array(
    'script' => 'diff.php',
    "unordered_params" => array( "nodeid" => "nodeID", 
                                 "fromversion" => "fromVersion",
                                 "toversion" => "toVersion",
                                 "attributeid" => "attributeID" ) 
     );
     
     
$ViewList['redirecttomainnode'] = array(
    'script' => 'redirecttomainnode.php',
    "unordered_params" => array( "contentobjectid" => "contentObjectID", )) ;
?>