<?php
/* maybe not all of them are needed, I just copied the whole bunch from kernel/content/action.php */
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/common/template.php' );

$fromVersion = false;
$toVersion = false;
$attributeID = false;
$nodeID = false;
$http =& eZHTTPTool::instance();
$module =& $Params["Module"];


$ini = eZINI::instance( "wiki.ini" );

// get the id of the wiki class from the ini file.
$contentClassID = $ini->variable( "Wiki", "ContentClassID" );


$originalParameters=$module->OriginalUnorderedParameters;


if (in_array('nodeID', $originalParameters) ) {
    $nodeID = $originalParameters['nodeID'];
}
else  if( $http->hasPostVariable('nodeid') ) {
    $nodeID=$http->postVariable('nodeid');
}
if ( !is_numeric( $nodeID) ) {
    eZDebug::writeError( "nodeid not set as param");
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}


if (in_array('fromVersion', $originalParameters) ) {
    $fromVersion = $originalParameters['fromVersion'];
}
else if( $http->hasPostVariable('fromversion') ) {
    $fromVersion=$http->postVariable('fromversion');
}
if ( !is_numeric( $fromVersion) ) {
    eZDebug::writeError( "fromversion not set as param");
    //TODO figure out how this actually works
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}

if (in_array('toVersion', $originalParameters) ) {
    $toVersion = $originalParameters['toVersion'];
}
else if ( $http->hasPostVariable('toversion') ) {
    $toVersion = $http->postVariable('toversion');
}
if ( !is_numeric( $toVersion) ) {
    eZDebug::writeError( "toversion not set as param");
    //TODO figure out how this actually works
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}


if (in_array('attributeID', $originalParameters) ) {
    $attributeID = $originalParameters['attributeID'];
}
else if( $http->hasPostVariable('attributeid') ) {
    $attributeID = $http->postVariable('attributeid');
}
if ( !is_numeric( $attributeID) ) {
    eZDebug::writeError( "attributeid not set as param");
    //TODO figure out how this actually works
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}


$node =& eZContentObjectTreeNode::fetch( $nodeID);
if ( is_object( $node ) )
        {
            if( !$node->canRead() ); 
            {
                 eZDebug::writeError('insufficient permissions');
                 //return $module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
            }
            
            $contentObject= & eZContentObject::fetchByNodeID($nodeID);

            
            $fromVersionObject= $contentObject->version($fromVersion);
            
            if (!$fromVersionObject) {
                eZDebug::writeError( "fromVersion doesnt exist");
                return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
            }
            
            $toVersionObject= $contentObject->version($toVersion);
            
            if (!$toVersionObject) {
                eZDebug::writeError( "toVersion doesnt exist");
                return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
            }

            $fromAttributes= & $fromVersionObject->contentObjectAttributes();

            $fromText = false;
            //eZDebug::writeNotice($attributeID);
            foreach ($fromAttributes as $fromAttribute) {
                
                if ($fromAttribute->ContentClassAttributeID== $attributeID) {
                    if ($fromAttribute->DataTypeString=='ezxmltext' || $fromAttribute->DataTypeString=='ezstring' || $fromAttribute->DataTypeString=='eztext') {
                        $fromText = $fromAttribute->content();
                    }
                }
            }
                    
            $toAttributes= & $toVersionObject->contentObjectAttributes();
            $toText = false;
            foreach ($toAttributes as $toAttribute) {
                if ($toAttribute->ContentClassAttributeID== $attributeID) {
                    if ($toAttribute->DataTypeString=='ezxmltext' || $toAttribute->DataTypeString=='ezstring'  || $toAttribute->DataTypeString=='eztext') {
                        $toText = $toAttribute->content();
                    }
                }
            }
            
            if (! ($fromText && $toText)) {
                eZDebug::writeError( "failed to extract texts");
                return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
            }
            
            $tpl =& templateInit();
            $tpl->setVariable( 'attributeID', $attributeID);
            
            $tpl->setVariable( 'fromText', $fromText );
            $tpl->setVariable( 'fromVersion', $fromVersion );
            $tpl->setVariable( 'fromVersionObject', $fromVersionObject );

            $tpl->setVariable( 'toText', $toText );
            $tpl->setVariable( 'toVersion', $toVersion );
            $tpl->setVariable( 'toVersionObject', $toVersionObject );
            
            $tpl->setVariable( 'currentVersionObject', $contentObject );


            $Result = array();
            $Result['content'] = $tpl->fetch( "design:wiki/diff.tpl" );
            $Result['path'] = array( array( 'url' => false,
                                    'text' => 'Wiki' ),
                                    array( 'url' => false,
                                    'text' => 'Diff' ) );
            return;
        }
else {
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}

?>
