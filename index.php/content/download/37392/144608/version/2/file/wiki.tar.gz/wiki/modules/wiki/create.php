<?php
/* maybe not all of them are needed, I just copied the whole bunch from kernel/content/action.php */
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentbrowse.php' );
include_once( 'kernel/classes/ezcontentbrowsebookmark.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( "lib/ezdb/classes/ezdb.php" );
include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'lib/ezutils/classes/ezuri.php');

/*this is, again, copied from content/action.php*/

$hasClassInformation = false;
$contentClassID = false;
$contentClassIdentifier = false;
$parentNodeID = false;
$newNodeName = false;
$class = false;
$http =& eZHTTPTool::instance();
$module =& $Params["Module"];

$contentModule=$module->findModule('content', $module);

$ini = eZINI::instance( "wiki.ini" );

// get the id of the wiki class from the ini file.
$contentClassIdentifier = $ini->variable( "Wiki", "ContentClassIdentifier" );

//eZDebug::writeNotice($Params);

if (!$contentClassIdentifier) {
    eZDebug::writeError( "ContentClassID not set in wiki.ini" );
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}

$nameAttributeIdentifier=$ini->variable( "Wiki", "NameAttributeIdentifier" );

if (!$nameAttributeIdentifier) {
    eZDebug::writeError( "NameAttributeID not set in wiki.ini" );
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}

$originalParameters=$module->OriginalUnorderedParameters;


$newNodeName= $originalParameters['newNodeName'];
if ( !is_string( $newNodeName) ) {
    eZDebug::writeNotice( "newnodename not set as param, using 'Unnamed' as default");
    $newNodeName = 'Unnamed';
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}



$parentNodeID = $Params['parentNodeID'];
if ( !is_numeric( $parentNodeID) ) {
    eZDebug::writeError( "parentnodeid not set as param");
    //TODO figure out how this actually works
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );

}


$node =& eZContentObjectTreeNode::fetch( $parentNodeID );

if ( is_object( $node ) )
{
    $parentContentObject =& $node->attribute( 'object' );
    if ( $parentContentObject->checkAccess( 'create', $contentClassID,  $parentContentObject->attribute( 'contentclass_id' ) ) == '1' )
    {
        $user =& eZUser::currentUser();
        $userID =& $user->attribute( 'contentobject_id' );
        $sectionID = $parentContentObject->attribute( 'section_id' );

        if ( !is_object( $class ) )
            $class =& eZContentClass::fetchByIdentifier( $contentClassIdentifier  );
        if ( is_object( $class ) )
        {
            $db =& eZDB::instance();
            $db->begin();
            $contentObject =& $class->instantiate( $userID, $sectionID );
            $nodeAssignment =& eZNodeAssignment::create( array(
                                                            'contentobject_id' => $contentObject->attribute( 'id' ),
                                                            'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                            'parent_node' => $node->attribute( 'node_id' ),
                                                            'is_main' => 1
                                                            )
                                                        );
            if ( $http->hasPostVariable( 'AssignmentRemoteID' ) )
            {
                $nodeAssignment->setAttribute( 'remote_id', $http->postVariable( 'AssignmentRemoteID' ) );
            }
;           $attributes=$contentObject->contentObjectAttributes();

            
            foreach($attributes as $attribute) {
                if ( $attribute->ContentClassAttributeIdentifier == $nameAttributeIdentifier ) {
                    $attribute->setContent($newNodeName);
                    $attribute->setAttribute( 'data_text', $newNodeName );
                    $attribute->store();
                }
            }
            $nodeAssignment->store();
            
            
            $db->commit();

                
            if ( in_array('RedirectURIAfterPublish',$originalParameters ) )
            {
                $http->setSessionVariable( 'RedirectURIAfterPublish', $originalParameters['RedirectURIAfterPublish'] );
            }
            else {
               
                $urlstring="/wiki/redirecttomainnode/contentobjectid/".$contentObject->ID;
                //eZURI::transformURI($urlstring);
                $http->setSessionVariable( 'RedirectURIAfterPublish', $urlstring);
            }
            
            //how to do the redirect to the content module?
            $module->redirectTo( $contentModule->functionURI( 'edit' ) . '/' . $contentObject->attribute( 'id' ) . '/' . $contentObject->attribute( 'current_version' ) );
            return;
        }
        else
        {
            return $module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
        }
    }
    else
    {
        return $module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
    }
}
else
{
    return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
}


?>