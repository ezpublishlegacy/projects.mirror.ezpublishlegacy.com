<?
include_once( 'kernel/classes/ezcontentobject.php' );


$module =& $Params["Module"];
$originalParameters=$module->OriginalUnorderedParameters;

$contentObjectID=$originalParameters['contentObjectID'];

$contentObject=eZContentObject::fetch($contentObjectID);
$contentModule=$module->findModule('content', $module);

$module->redirectTo( $contentModule->functionURI( 'view' ) . '/full/' . $contentObject->mainNodeId());

?>
