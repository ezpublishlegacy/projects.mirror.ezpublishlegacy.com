<?

/*!
  \class   TemplateWikisyntaxOperator templatewikisyntaxoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator wikisyntax. By using wikisyntax you can transform Wiki like  syntax to proper XHTML.
  \version 1.0
  \date    Friday 09 September 2005 8:03:56 pm
  \author  Administrator User

  

  Example:
\code
{$value|wikisyntax|wash}
\endcode
*/
//evil:
ini_set('include_path',  ini_get('include_path') . ":". getcwd() . "/extension/wiki/textwiki");

require_once 'Text/Wiki.php';

include_once( 'lib/ezutils/classes/ezuri.php');

class TemplateWikisyntaxOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TemplateWikisyntaxOperator()
    {
    }

    /*!
        return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'wikisyntax' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'wikisyntax' => array( 'wikientry_node' => array( 'type' => 'object',
                                                                         'required' => false,
                                                                         'default' => null )) ) ;
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        // instantiate a Text_Wiki object with the default rule set
        $wiki =& new Text_Wiki();
        
        // when rendering XHTML, make sure wiki links point to a
        // specific base URL
        $wikientry_node = $namedParameters['wikientry_node'];
        if ($wikientry_node) {
            $parent_node=$wikientry_node->fetchParent();
            $wiki->setRenderConf('xhtml', 'wikilink', 'view_url',"/".$parent_node->pathWithNames() ."/%s");
            $children=$parent_node->children();
            $pages=array();
            foreach ($children as $child) {
                //eZDebug::writeNotice($child->Name);
                array_push($pages,$child->Name);
            }
            $new_url="/wiki/create/parentnodeid/" . $parent_node->NodeID ."/newnodename/%s";
            eZURI::transformURI($new_url);
            eZDebug::writeNotice($new_url);
            $wiki->setRenderConf('xhtml', 'wikilink', 'new_url', $new_url);
        }
        else {
            $wiki->setRenderConf('xhtml', 'wikilink', 'view_url','');
            $pages = array();
        }
        
        
        
        // set an array of pages that exist in the wiki
        // and tell the XHTML renderer about them
        
        $wiki->setRenderConf('xhtml', 'wikilink', 'pages', $pages);
        
        
        // transform the wiki text into XHTML
        $operatorValue = $wiki->transform($operatorValue, 'Xhtml');

    }

}


?>