<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script'           =>     'extension/wiki/autoloads/wikisyntax.php',
         'class'            =>     'TemplateWikisyntaxOperator',
         'operator_names'   =>     array( 'wikisyntax' ) );

$eZTemplateOperatorArray[] =
  array( 'script'           =>     'extension/wiki/autoloads/diffoperator.php',
         'class'            =>     'TemplateDiffOperator',
         'operator_names'   =>     array( 'diff' ) );



?>