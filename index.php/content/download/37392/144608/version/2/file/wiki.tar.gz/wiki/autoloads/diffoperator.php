<?
/*!
  \class   TemplateDiffOperator templatediffoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles diffs between two strings
  \version 1.0
  \date    Friday 09 September 2005 8:03:56 pm
  \author  Gabriel Ambuehl

  

  Example:
\code
For wiki style inline diffs: {diff($fromText,$toText, ['inline'])}

For unified diffs: {diff($fromText,$toText, 'unified')}

or possibly
{diff($fromText,$toText)|wash}
\endcode
*/

//evil:
ini_set('include_path',  ini_get('include_path') . ":". getcwd() . "/extension/wiki/textdiff/");

include_once 'Diff.php';
include_once 'Diff/Renderer.php';
include_once 'Diff/Renderer/inline.php';
include_once 'Diff/Renderer/unified.php';

class TemplateDiffOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TemplateDiffOperator()
    {
    }

    /*!
        return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'diff' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    
    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'diff' => array(        'from_string'     =>  array( 'type' => 'string',
                                                                          'required' => true,
                                                                          'default' => null ),
                                              'to_string'       =>  array('type' => 'string',
                                                                          'required' => true,
                                                                          'default' => null ),
                                              'diff_type'       =>  array('type' => 'string',
                                                                          'required' => false,
                                                                          'default' => 'inline' )
                                     )
                       
                    );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        /* fetch params */
        $fromString = $namedParameters['from_string'];
        $toString = $namedParameters['to_string'];
        $diffType = $namedParameters['diff_type'];


        /* Create the Diff object. */
        
        eZDebug::writeNotice($fromString);
        eZDebug::writeError(explode("\n",$fromString));
        $diff = &new Text_Diff(explode("\n",$fromString), explode("\n",$toString));

        /* return result*/
        if ($diffType=='unified') {
            $renderer = &new Text_Diff_Renderer_unified();
        }
        else {
            $renderer = &new Text_Diff_Renderer_inline();
        }
        
        $operatorValue = $renderer->render($diff);
    }
}


?>