[ModuleSettings]
ExtensionRepositories[]=wiki