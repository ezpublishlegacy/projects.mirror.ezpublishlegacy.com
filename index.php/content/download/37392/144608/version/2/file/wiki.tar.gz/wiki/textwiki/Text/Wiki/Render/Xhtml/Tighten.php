<?php
class Text_Wiki_Render_Xhtml_Tighten extends Text_Wiki_Render {
    
    
    function token()
    {
        return '';
    }
}
?>