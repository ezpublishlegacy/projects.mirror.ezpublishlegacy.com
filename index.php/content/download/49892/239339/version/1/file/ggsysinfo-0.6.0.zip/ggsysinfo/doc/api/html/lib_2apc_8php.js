var lib_2apc_8php =
[
    [ "defaults", "lib_2apc_8php.html#a8989c99d750c3d9959e55bcda06e5d2f", null ],
    [ "$cache_mode", "lib_2apc_8php.html#a7597abf82803e7fe3d7131d787a76f5e", null ],
    [ "$host", "lib_2apc_8php.html#a711797613cb863ca0756df789c396bf2", null ],
    [ "$MY_SELF", "lib_2apc_8php.html#aed5246b981c902f6818ec5970bb544cc", null ],
    [ "$MY_SELF_WO_SORT", "lib_2apc_8php.html#a30c707f8c1cba9eaac1a6bdb545714d7", null ],
    [ "$PHP_SELF", "lib_2apc_8php.html#a437087dc97412d2ff08eb6af84b3146a", null ],
    [ "$scope_list", "lib_2apc_8php.html#a01d0434634cbc472caa48debd9777336", null ],
    [ "$time", "lib_2apc_8php.html#a78db1a0602e3b6ac1d9a1b5ec103c160", null ],
    [ "$vardom", "lib_2apc_8php.html#a328b51485fe668ca94bc29f07344e8d2", null ],
    [ "$VERSION", "lib_2apc_8php.html#aef5a2efb341306b1b027ab3e775bbf4e", null ],
    [ "OB_HOST_STATS", "lib_2apc_8php.html#a53ed4a78530198d0c3aecd74500b9f83", null ],
    [ "OB_SYS_CACHE", "lib_2apc_8php.html#aa2d7a79918470b2c485dc6f62dd453a1", null ],
    [ "OB_SYS_CACHE_DIR", "lib_2apc_8php.html#acccfd8ce60dd7c9fb42c6be852cd3b5f", null ],
    [ "OB_USER_CACHE", "lib_2apc_8php.html#a6272b2e171df20ccaa4be342b271fc28", null ],
    [ "OB_VERSION_CHECK", "lib_2apc_8php.html#a19973dde67ed4acf66e9d12735ff02ef", null ],
    [ "USE_AUTHENTICATION", "lib_2apc_8php.html#af152018d53713c0bfa171c3ef998b50d", null ]
];