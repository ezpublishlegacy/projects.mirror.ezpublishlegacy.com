var searchData=
[
  ['ob_5fhost_5fstats',['OB_HOST_STATS',['../lib_2apc_8php.html#a53ed4a78530198d0c3aecd74500b9f83',1,'apc.php']]],
  ['ob_5fsys_5fcache',['OB_SYS_CACHE',['../lib_2apc_8php.html#aa2d7a79918470b2c485dc6f62dd453a1',1,'apc.php']]],
  ['ob_5fsys_5fcache_5fdir',['OB_SYS_CACHE_DIR',['../lib_2apc_8php.html#acccfd8ce60dd7c9fb42c6be852cd3b5f',1,'apc.php']]],
  ['ob_5fuser_5fcache',['OB_USER_CACHE',['../lib_2apc_8php.html#a6272b2e171df20ccaa4be342b271fc28',1,'apc.php']]],
  ['ob_5fversion_5fcheck',['OB_VERSION_CHECK',['../lib_2apc_8php.html#a19973dde67ed4acf66e9d12735ff02ef',1,'apc.php']]],
  ['ocache_5fdata',['OCACHE_DATA',['../lib_2wincache_8php.html#a5a0d568d7237ca56ee94fafd3ad05739',1,'wincache.php']]],
  ['open_5fbasedir_2ephp',['open_basedir.php',['../open__basedir_8php.html',1,'']]],
  ['operationlist_2ephp',['operationlist.php',['../operationlist_8php.html',1,'']]],
  ['operatordocfolders',['operatorDocFolders',['../classsysInfoTools.html#ac27233fa815bba7abe0ccbb4aa6de9c3',1,'sysInfoTools']]],
  ['operatorlist',['operatorList',['../classggSysinfoTemplateOperators.html#a44345af724661996f0a5298da1a8b4c5',1,'ggSysinfoTemplateOperators']]],
  ['operatorlist_2ephp',['operatorlist.php',['../operatorlist_8php.html',1,'']]],
  ['osiswindows',['osIsWindows',['../classPhpSecInfo__Test.html#a32e1eddd70990a19ebf7fc4a88c2868c',1,'PhpSecInfo_Test']]]
];
