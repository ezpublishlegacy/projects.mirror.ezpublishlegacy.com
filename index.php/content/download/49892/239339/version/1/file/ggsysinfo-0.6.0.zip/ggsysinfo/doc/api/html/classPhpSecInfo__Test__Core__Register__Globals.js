var classPhpSecInfo__Test__Core__Register__Globals =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Register__Globals.html#a31fca999fa002c7e6b5529770c1873ee", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Register__Globals.html#ad22d91850861735663cb33842aefa6e3", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Register__Globals.html#acd27c7edb82362a6e93c285ccaf1cdff", null ],
    [ "isTestable", "classPhpSecInfo__Test__Core__Register__Globals.html#a3dbc609daece8f4793f5c36fd49c00c2", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Register__Globals.html#ad962caab1585282cb3832d4fb73bb141", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Register__Globals.html#a52335bd17e1b7880f262fbf9ddaccf3e", null ]
];