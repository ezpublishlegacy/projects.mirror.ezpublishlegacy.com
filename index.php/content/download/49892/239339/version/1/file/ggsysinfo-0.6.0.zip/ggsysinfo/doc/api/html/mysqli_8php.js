var mysqli_8php =
[
    [ "$mysqlnd_available", "mysqli_8php.html#a595b258dcf4ccce5b9a478c8a6f29381", null ]
];