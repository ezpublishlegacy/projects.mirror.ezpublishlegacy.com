var logstats_8php =
[
    [ "$cachedir", "logstats_8php.html#a01f61437be9e9a04ee228f5d455265db", null ],
    [ "$debug", "logstats_8php.html#a85ae3e64cd40e9564adceb010085e9dd", null ],
    [ "$errormsg", "logstats_8php.html#a83574f02617bcbd33ccea0debd1f7f68", null ],
    [ "$extraLogFilesList", "logstats_8php.html#a7b771f675c37245793d4decd090758b3", null ],
    [ "$logdir", "logstats_8php.html#a88a5e1357a777590063915ccfcf147c9", null ],
    [ "$logfiles", "logstats_8php.html#a6c8f5bb2a5b327e231c5cf7e75ecb4ca", null ],
    [ "$logFilesList", "logstats_8php.html#a6cddb3da9180ba209766510fea966354", null ],
    [ "$tpl", "logstats_8php.html#a7375e86be7912662c56b178a1437d72a", null ]
];