var searchData=
[
  ['wincache_2ephp',['wincache.php',['../lib_2wincache_8php.html',1,'']]],
  ['wincache_2ephp',['wincache.php',['../wincache_8php.html',1,'']]]
];
