var operatorlist_8php =
[
    [ "$extensions", "operatorlist_8php.html#a78dd0f5a8f983099dc6499a2d7cdf7aa", null ],
    [ "$ezgeshi_available", "operatorlist_8php.html#a8664cf6bcc2b5b1d3ffc3cdfbe9ba8e6", null ],
    [ "$operatorList", "operatorlist_8php.html#ad5f7616bc0c8c24321105472b546565f", null ]
];