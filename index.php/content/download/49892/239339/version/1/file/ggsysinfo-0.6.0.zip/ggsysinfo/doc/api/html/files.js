var files =
[
    [ "autoloads", "dir_647e64d812b3cad7656c888f07f2c523.html", "dir_647e64d812b3cad7656c888f07f2c523" ],
    [ "classes", "dir_b02e4219757ae4e3a0f1714873865bbf.html", "dir_b02e4219757ae4e3a0f1714873865bbf" ],
    [ "modules", "dir_e05d7e2b1ecd646af5bb94391405f3b5.html", "dir_e05d7e2b1ecd646af5bb94391405f3b5" ],
    [ "ezinfo.php", "ezinfo_8php.html", [
      [ "ggsysinfoInfo", "classggsysinfoInfo.html", "classggsysinfoInfo" ]
    ] ]
];