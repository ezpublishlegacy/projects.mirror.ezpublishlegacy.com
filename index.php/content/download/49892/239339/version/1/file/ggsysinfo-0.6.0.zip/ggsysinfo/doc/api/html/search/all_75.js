var searchData=
[
  ['ucache_5fdata',['UCACHE_DATA',['../lib_2wincache_8php.html#a9e65acf108f31b2e6926795d6b3dfc20',1,'wincache.php']]],
  ['uid_2ephp',['uid.php',['../uid_8php.html',1,'']]],
  ['upload_5fmax_5ffilesize_2ephp',['upload_max_filesize.php',['../upload__max__filesize_8php.html',1,'']]],
  ['upload_5ftmp_5fdir_2ephp',['upload_tmp_dir.php',['../upload__tmp__dir_8php.html',1,'']]],
  ['use_5fauthentication',['USE_AUTHENTICATION',['../lib_2apc_8php.html#af152018d53713c0bfa171c3ef998b50d',1,'USE_AUTHENTICATION():&#160;apc.php'],['../lib_2wincache_8php.html#a201a2def6091ff4349d2688b4f2aa3ef',1,'USE_AUTHENTICATION():&#160;wincache.php']]],
  ['use_5ftrans_5fsid_2ephp',['use_trans_sid.php',['../use__trans__sid_8php.html',1,'']]],
  ['username',['USERNAME',['../lib_2wincache_8php.html#a74aeb024c560ee70f79b2c2b039bc113',1,'wincache.php']]]
];
