var searchData=
[
  ['if',['if',['../common_8php.html#a8a5553f0ca8fb3cd4604ad06da4a46ba',1,'if():&#160;common.php'],['../xcache_8tpl_8php.html#abd7ae7a59fb30afb92a268446d30108a',1,'if():&#160;xcache.tpl.php']]],
  ['img_5fheight',['IMG_HEIGHT',['../lib_2wincache_8php.html#a395187b662d904036b155f1deabe1903',1,'wincache.php']]],
  ['img_5fwidth',['IMG_WIDTH',['../lib_2wincache_8php.html#a31d67a07604c9ee0e3e1de6dc45430ac',1,'wincache.php']]],
  ['index_2ephp',['index.php',['../index_8php.html',1,'']]],
  ['index_2ephp',['index.php',['../lib_2xcache__admin_2index_8php.html',1,'']]],
  ['info',['info',['../classggsysinfoInfo.html#a38ef7f54293cf3a246a6e6b395b4f29b',1,'ggsysinfoInfo']]],
  ['ini_5fmax_5flength',['INI_MAX_LENGTH',['../lib_2wincache_8php.html#a16f9949f2d0e8c2256e570800ddfc495',1,'wincache.php']]],
  ['inichecker',['iniChecker',['../classiniChecker.html',1,'']]],
  ['inichecker_2ephp',['inichecker.php',['../inichecker_8php.html',1,'']]],
  ['inifilesqa_2ephp',['inifilesqa.php',['../inifilesqa_8php.html',1,'']]],
  ['inisettingsqa_2ephp',['inisettingsqa.php',['../inisettingsqa_8php.html',1,'']]],
  ['init_5fcache_5finfo',['init_cache_info',['../lib_2wincache_8php.html#ac05b9420accaf67df101b0c91d4ecc4f',1,'wincache.php']]],
  ['initialize',['initialize',['../classiniChecker.html#a809405e10b2860eafc9af16691cc1471',1,'iniChecker\initialize()'],['../classphpChecker.html#a9df320013dd73110bda4568f4f5f8ca2',1,'phpChecker\initialize()'],['../classsysinfoModule.html#acb2a60dfcdb4379e5f9698b62ed1c96f',1,'sysinfoModule\initialize()'],['../classtplChecker.html#abaaf931bca639d35ef61b101d5715392',1,'tplChecker\initialize()']]],
  ['ishttp200',['isHTTP200',['../classsysInfoTools.html#aefce5d9c186b958a0e26e815f82e4673',1,'sysInfoTools']]],
  ['istestable',['isTestable',['../classPhpSecInfo__Test__Core__Allow__Url__Include.html#aa81f196619520c13980a533d09b46d86',1,'PhpSecInfo_Test_Core_Allow_Url_Include\isTestable()'],['../classPhpSecInfo__Test__Core__Gid.html#a6ee4436a65b76f54b6f34597b5e1b0af',1,'PhpSecInfo_Test_Core_Gid\isTestable()'],['../classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#aaab385e633b03d7ecc98a3f915395966',1,'PhpSecInfo_Test_Core_Magic_Quotes_GPC\isTestable()'],['../classPhpSecInfo__Test__Core__Register__Globals.html#a3dbc609daece8f4793f5c36fd49c00c2',1,'PhpSecInfo_Test_Core_Register_Globals\isTestable()'],['../classPhpSecInfo__Test__Core__Uid.html#ae02f4b5f2bd4a94ffb047f673735caf4',1,'PhpSecInfo_Test_Core_Uid\isTestable()'],['../classPhpSecInfo__Test__Core__Upload__Tmp__Dir.html#ac10b4c8e6b71a97ef27deff6f9b62413',1,'PhpSecInfo_Test_Core_Upload_Tmp_Dir\isTestable()'],['../classPhpSecInfo__Test__Session__Save__Path.html#ae5181b468ae818452f0ba068fd1d7249',1,'PhpSecInfo_Test_Session_Save_Path\isTestable()'],['../classPhpSecInfo__Test.html#ae72c58c3612b8c28ad8e02878064b0b1',1,'PhpSecInfo_Test\isTestable()'],['../classPhpSecInfo__Test__Application.html#ab916dab272e83c3f8416c8aa0df4b78f',1,'PhpSecInfo_Test_Application\isTestable()'],['../classPhpSecInfo__Test__Cgi.html#a8eb01ce532f7ab6a1cab4c02a29ceb2c',1,'PhpSecInfo_Test_Cgi\isTestable()'],['../classPhpSecInfo__Test__Core.html#ad8fe0ddb954e92b33e56bcae646d9291',1,'PhpSecInfo_Test_Core\isTestable()'],['../classPhpSecInfo__Test__Curl.html#af16efae6809f8dbe975a6100fe27e8c5',1,'PhpSecInfo_Test_Curl\isTestable()'],['../classPhpSecInfo__Test__Session.html#aa04862858a347611ad4ad9d7df882d74',1,'PhpSecInfo_Test_Session\isTestable()'],['../classPhpSecInfo__Test__Suhosin.html#acee133c9d0d26afc288beb05887da9f6',1,'PhpSecInfo_Test_Suhosin\isTestable()']]]
];
