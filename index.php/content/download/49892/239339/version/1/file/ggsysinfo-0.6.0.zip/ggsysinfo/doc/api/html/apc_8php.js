var apc_8php =
[
    [ "$_SERVER", "apc_8php.html#a17d3697c47b74420c4e61249b6662544", null ],
    [ "$extdir", "apc_8php.html#a08e8dda0b59aec85f754927ad2686289", null ],
    [ "$output", "apc_8php.html#a6b8b7f6ba02559c5e13c95fccda1e473", null ],
    [ "$self", "apc_8php.html#a55583faec9072fb2917b0c3645b11280", null ],
    [ "$url", "apc_8php.html#acf215f34a917d014776ce684a9ee8909", null ]
];