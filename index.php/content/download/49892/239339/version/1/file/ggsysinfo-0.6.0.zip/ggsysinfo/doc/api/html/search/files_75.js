var searchData=
[
  ['uid_2ephp',['uid.php',['../uid_8php.html',1,'']]],
  ['upload_5fmax_5ffilesize_2ephp',['upload_max_filesize.php',['../upload__max__filesize_8php.html',1,'']]],
  ['upload_5ftmp_5fdir_2ephp',['upload_tmp_dir.php',['../upload__tmp__dir_8php.html',1,'']]],
  ['use_5ftrans_5fsid_2ephp',['use_trans_sid.php',['../use__trans__sid_8php.html',1,'']]]
];
