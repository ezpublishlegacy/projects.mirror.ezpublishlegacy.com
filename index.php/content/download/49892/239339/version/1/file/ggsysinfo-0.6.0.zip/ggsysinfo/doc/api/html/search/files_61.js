var searchData=
[
  ['allow_5furl_5ffopen_2ephp',['allow_url_fopen.php',['../allow__url__fopen_8php.html',1,'']]],
  ['allow_5furl_5finclude_2ephp',['allow_url_include.php',['../allow__url__include_8php.html',1,'']]],
  ['apc_2ephp',['apc.php',['../apc_8php.html',1,'']]],
  ['apc_2ephp',['apc.php',['../lib_2apc_8php.html',1,'']]]
];
