var dir_4bd0f22a4b5e50f2b690db5c00ee99e7 =
[
    [ "allow_url_fopen.php", "allow__url__fopen_8php.html", [
      [ "PhpSecInfo_Test_Core_Allow_Url_Fopen", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html", "classPhpSecInfo__Test__Core__Allow__Url__Fopen" ]
    ] ],
    [ "allow_url_include.php", "allow__url__include_8php.html", [
      [ "PhpSecInfo_Test_Core_Allow_Url_Include", "classPhpSecInfo__Test__Core__Allow__Url__Include.html", "classPhpSecInfo__Test__Core__Allow__Url__Include" ]
    ] ],
    [ "display_errors.php", "display__errors_8php.html", [
      [ "PhpSecInfo_Test_Core_Display_Errors", "classPhpSecInfo__Test__Core__Display__Errors.html", "classPhpSecInfo__Test__Core__Display__Errors" ]
    ] ],
    [ "expose_php.php", "expose__php_8php.html", [
      [ "PhpSecInfo_Test_Core_Expose_Php", "classPhpSecInfo__Test__Core__Expose__Php.html", "classPhpSecInfo__Test__Core__Expose__Php" ]
    ] ],
    [ "file_uploads.php", "file__uploads_8php.html", [
      [ "PhpSecInfo_Test_Core_File_Uploads", "classPhpSecInfo__Test__Core__File__Uploads.html", "classPhpSecInfo__Test__Core__File__Uploads" ]
    ] ],
    [ "gid.php", "gid_8php.html", "gid_8php" ],
    [ "magic_quotes_gpc.php", "magic__quotes__gpc_8php.html", [
      [ "PhpSecInfo_Test_Core_Magic_Quotes_GPC", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC" ]
    ] ],
    [ "memory_limit.php", "memory__limit_8php.html", "memory__limit_8php" ],
    [ "open_basedir.php", "open__basedir_8php.html", [
      [ "PhpSecInfo_Test_Core_Open_Basedir", "classPhpSecInfo__Test__Core__Open__Basedir.html", "classPhpSecInfo__Test__Core__Open__Basedir" ]
    ] ],
    [ "php_version.php", "php__version_8php.html", [
      [ "PhpSecInfo_Test_Core_Php_Version", "classPhpSecInfo__Test__Core__Php__Version.html", "classPhpSecInfo__Test__Core__Php__Version" ]
    ] ],
    [ "post_max_size.php", "post__max__size_8php.html", "post__max__size_8php" ],
    [ "register_globals.php", "register__globals_8php.html", [
      [ "PhpSecInfo_Test_Core_Register_Globals", "classPhpSecInfo__Test__Core__Register__Globals.html", "classPhpSecInfo__Test__Core__Register__Globals" ]
    ] ],
    [ "uid.php", "uid_8php.html", "uid_8php" ],
    [ "upload_max_filesize.php", "upload__max__filesize_8php.html", "upload__max__filesize_8php" ],
    [ "upload_tmp_dir.php", "upload__tmp__dir_8php.html", [
      [ "PhpSecInfo_Test_Core_Upload_Tmp_Dir", "classPhpSecInfo__Test__Core__Upload__Tmp__Dir.html", "classPhpSecInfo__Test__Core__Upload__Tmp__Dir" ]
    ] ]
];