var classPhpSecInfo__Test__Core__Allow__Url__Fopen =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html#a2f9f4f9e7756d461fe60c4631b133cf2", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html#a45faa6f88c31cf195ab1f26bd1c94550", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html#aa6ac3a5b4a95d3f3228b73cbf3f4a360", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html#a7fc23efade79206d9bc5cfceba609986", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Allow__Url__Fopen.html#a57309d9b0c08a739e11a731e614e2ca6", null ]
];