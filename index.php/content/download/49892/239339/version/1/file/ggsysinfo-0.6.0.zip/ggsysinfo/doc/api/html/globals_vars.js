var globals_vars =
[
    [ "$", "globals_vars.html", null ],
    [ "b", "globals_vars_0x62.html", null ],
    [ "c", "globals_vars_0x63.html", null ],
    [ "f", "globals_vars_0x66.html", null ],
    [ "i", "globals_vars_0x69.html", null ],
    [ "o", "globals_vars_0x6f.html", null ],
    [ "p", "globals_vars_0x70.html", null ],
    [ "r", "globals_vars_0x72.html", null ],
    [ "s", "globals_vars_0x73.html", null ],
    [ "u", "globals_vars_0x75.html", null ]
];