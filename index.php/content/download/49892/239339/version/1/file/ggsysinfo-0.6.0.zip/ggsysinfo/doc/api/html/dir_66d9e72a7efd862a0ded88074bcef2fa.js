var dir_66d9e72a7efd862a0ded88074bcef2fa =
[
    [ "save_path.php", "save__path_8php.html", [
      [ "PhpSecInfo_Test_Session_Save_Path", "classPhpSecInfo__Test__Session__Save__Path.html", "classPhpSecInfo__Test__Session__Save__Path" ]
    ] ],
    [ "use_trans_sid.php", "use__trans__sid_8php.html", [
      [ "PhpSecInfo_Test_Session_Use_Trans_Sid", "classPhpSecInfo__Test__Session__Use__Trans__Sid.html", "classPhpSecInfo__Test__Session__Use__Trans__Sid" ]
    ] ]
];