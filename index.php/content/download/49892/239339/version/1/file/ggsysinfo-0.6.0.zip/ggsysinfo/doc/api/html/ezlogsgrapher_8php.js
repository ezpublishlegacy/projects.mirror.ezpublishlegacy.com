var ezlogsgrapher_8php =
[
    [ "ezLogsGrapher", "classezLogsGrapher.html", "classezLogsGrapher" ],
    [ "calcChurnLabel", "ezlogsgrapher_8php.html#a4efee3e5ceb0d7ada436b193b469b540", null ]
];