var classPhpSecInfo__Test__Suhosin =
[
    [ "getMoreInfoURL", "classPhpSecInfo__Test__Suhosin.html#a7cdd73d34f0a4245b5c1330efa36cf62", null ],
    [ "isTestable", "classPhpSecInfo__Test__Suhosin.html#acee133c9d0d26afc288beb05887da9f6", null ],
    [ "$test_group", "classPhpSecInfo__Test__Suhosin.html#a01e33cb3021ea1bc318d83c9a5acefd2", null ]
];