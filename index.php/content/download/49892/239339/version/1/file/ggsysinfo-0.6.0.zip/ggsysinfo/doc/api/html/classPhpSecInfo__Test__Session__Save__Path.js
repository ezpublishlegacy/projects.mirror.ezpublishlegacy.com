var classPhpSecInfo__Test__Session__Save__Path =
[
    [ "_execTest", "classPhpSecInfo__Test__Session__Save__Path.html#a2a7ca5ada07f4332e4e7087d6556aa89", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Session__Save__Path.html#a1434ab2b3578030a664a12c3e4a3c351", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Session__Save__Path.html#a3f30314c830d82bcb250a1d8d2f9c51c", null ],
    [ "isTestable", "classPhpSecInfo__Test__Session__Save__Path.html#ae5181b468ae818452f0ba068fd1d7249", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Session__Save__Path.html#a78334ceaab94ba6779d6e19df0cd37e8", null ],
    [ "$test_name", "classPhpSecInfo__Test__Session__Save__Path.html#a9dea1fdc9d861ffe2cb28f2d49143c74", null ]
];