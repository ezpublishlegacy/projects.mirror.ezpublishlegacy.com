var post__max__size_8php =
[
    [ "PhpSecInfo_Test_Core_Post_Max_Size", "classPhpSecInfo__Test__Core__Post__Max__Size.html", "classPhpSecInfo__Test__Core__Post__Max__Size" ],
    [ "PHPSECINFO_POST_MAXLIMIT", "post__max__size_8php.html#a6d7248d4db03d950957c68be035529af", null ]
];