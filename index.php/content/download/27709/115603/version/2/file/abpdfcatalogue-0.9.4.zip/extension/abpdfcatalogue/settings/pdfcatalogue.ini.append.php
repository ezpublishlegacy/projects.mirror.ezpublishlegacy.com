<?php /*

[CommonSettings]
# Relative to [FileSettings] VarDir CacheDir
# e.g. var/cache/pdfcatalogue
# PDFCacheDirectory=pdfcatalogue

[CommonCatalogueSettings]
# Absolute path to the java executable (either JDK
# or JRE). Windows users should put the path into
# double quotes.
#JavaExecutablePath=/usr/bin/java

# Extra parameters that should be passed to the
# java executable when converting HTML files to
# PDF files.
#JavaExtraParameters[]
#JavaExtraParameters[]=-Djava.awt.headless=true

# Relative path (from the eZ Publish root directory)
# to the Paradox PDF .jar file that contains the
# executable which is used to convert HTML files
# to PDF files.
#JarFilePath=extension/abpdfcatalogue/lib/paradox/paradoxpdf.jar

# The target file name that shows up if a user
# creates a personalized common PDF catalogue.
#TargetFileName=websitearticles.pdf

# Meta data that will be written into the created
# common PDF catalogue and will be visible for example
# when using the Adobe Acrobat reader to view the
#PDF file.
#PDFSubject=Website Articles
#PDFTitle=Articles
#PDFAuthor=Alexander Block
#PDFKeywords=Alexander Block, http://www.alexander-block.net/

# Control wether to use PDF compression for the
# common PDF catalogue (enabled) or not (disabled).
#PDFCompression=disabled

# Title of the common PDF catalogue table of contents
# which will be created automatically.
#TOCTitle=Content

# Left, top and right margins of the common PDF catalogue
# table of contents in mm.
#TOCMargins=15;15;15

# Relative path  (from the eZ Publish root directory)
# to a PDF file that will be used as a background for
# the common PDF catalogue table of contents.
#TOCBackgroundFileName=

# Relative path  (from the eZ Publish root directory)
# to a PDF file that will be used as an Introduction
# in the common PDF catalogue.
#IntroductionFileName=

# Relative path  (from the eZ Publish root directory)
# to a PDF file that will be used as an Appendix
# in the common PDF catalogue.
#AppendixFileName=

*/ ?>