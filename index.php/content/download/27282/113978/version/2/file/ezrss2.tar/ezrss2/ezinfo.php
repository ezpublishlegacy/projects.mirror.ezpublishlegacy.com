<?php

class ezrss2Info
{
    static function info()
    {
        return array( 'Name' => "eZ RSS 2",
                      'Version' => "0.1",
                      'Copyright' => "Philippe VINCENT-ROYOL",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
