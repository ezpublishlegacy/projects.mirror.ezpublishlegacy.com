<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=ezrss2

[CronjobPart-ezrss2import]
Scripts[]=rss2import.php

*/ ?>
