<?php /* #?ini charset="utf-8"?

[DebugSettings]
ConditionDebug=enabled

[GeneralCondition]
eZFluxBBDB=enabled

[ErrorCondition]
eZFluxBBDB=disabled

*/ ?>