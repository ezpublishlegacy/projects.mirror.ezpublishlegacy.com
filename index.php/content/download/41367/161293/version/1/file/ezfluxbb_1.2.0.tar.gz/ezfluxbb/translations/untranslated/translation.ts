<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">

<context>
    <name>design/ezfluxbb/stats</name>
    <message>
        <source>subjects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last member</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile of %user</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/online</name>
    <message>
        <source>guests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>members</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/topics</name>
    <message>
        <source>Published %date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forums</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discussions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>go to last discussion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>by</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/login_box</name>
    <message>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/loginbox/annonymous</name>
    <message>
        <source>No account yet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifiant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remember ?</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/loginbox/guest_full</name>
    <message>
        <source>Connected (e) under the identity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last seen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New posts since last visit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent posts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark all topics as read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My account</source>
        <translation type="unfinished"></translation>
    </message>
</context>

</TS>
