<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezfluxbb

[ezjscServer_ezfluxbb]
Class=ezjscoreFluxBBServerCallFunctions
File=extension/ezfluxbb/classes/ezjscorefluxbbservercallfunctions.php

*/ ?>