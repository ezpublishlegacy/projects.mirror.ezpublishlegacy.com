<?php
//
// Definition of eZLayoutFunctionCollection class
//
// Created on: <21-Nov-2002 12:36:51 amos>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.4
// BUILD VERSION: 16840
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezlayoutfunctioncollection.php
*/

/*!
  \class eZLayoutFunctionCollection ezlayoutfunctioncollection.php
  \brief The class eZLayoutFunctionCollection does

*/
include_once( 'kernel/error/errors.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
require_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'kernel/content/ezcontentfunctioncollection.php' );

class eZScheduleFunctionCollection
{
    /*!
     Constructor
    */
    function eZScheduleFunctionCollection()
    {
    }

    function fetchZones()
    {
        $scheduleINI =& eZINI::instance( 'googlescheduled.ini' );
        $zoneArray = $scheduleINI->variable( 'Schedule', 'ZoneList' );
        
        $result = array( 'result' => array_keys( $zoneArray ) );
        return $result;
    }

    function fetchScheduledContent( $zone_identifier, $timestamp )
    {
        $scheduleINI =& eZINI::instance( 'googlescheduled.ini' );
        $zoneArray = $scheduleINI->variable( 'Schedule', 'ZoneList' );

        if (isset( $zoneArray[ $zone_identifier ] ) )
		{
			$timestamp     = $timestamp ? $timestamp : time();
			$current_date  = date( 'Y-m-d\TH:i:s', $timestamp ) . '.000-07:00';

			$feed          = $zoneArray[ $zone_identifier ];
			$feed         .= '?start-min='.$current_date;
			$feed         .= '&orderby=starttime&sortorder=ascending&max-results=1';

			$handle = fopen($feed, 'r');
			$xml_response = '';
			while (!feof($handle))
			{
				$xml_response .= fread($handle, 1024);
			}

			$nodeID = $this->get_node_id( $xml_response );
			if( !$nodeID )
			{
				$fallbacks = $scheduleINI->variable( 'Schedule', 'FallBack' );
				$nodeID = $fallbacks[ $zone_identifier ];
				$nodeID = $nodeID ? $nodeID : $scheduleINI->variable( 'Schedule', 'DefaultFallBack' );
			}
			
	        // Use contentfunctioncollection to fetch node, this gives error-message
	        // if the user does not have access or it cannot fetch node.
	        $result = eZContentFunctionCollection::fetchContentNode( $nodeID, false );
		}
		else
        {
            eZDebug::writeError("Unknown zone $zone_identifier", "fetchSheduledContent");
            $result = array( 'error' => array( 'error_type' => 'kernel',
                                               'error_code' => EZ_ERROR_KERNEL_NOT_FOUND ) );
        }

        return $result;
    }

	//private
	function get_node_id( $xml )
	{
		$eZxml = new eZXML();

		$domDoc = $eZxml->domTree( $xml );
		$feed = $domDoc->root();
		
		foreach( $feed->children() as $child )
		{
			if( $child->name() == 'entry' )
			{
				foreach( $child->children() as $eventdetail )
				{
					if( $eventdetail->name() == 'title' )
					{
						return $eventdetail->textContent();
					}
				}
			}
		}
	}

}

?>
