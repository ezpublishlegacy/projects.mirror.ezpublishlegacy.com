<?php /*

[ExtensionSettings]
DesignExtensions[]=googlescheduled

*/ ?>