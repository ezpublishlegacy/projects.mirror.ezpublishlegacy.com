<?php
// Recup�rer le nom du siteaccess courant:
// Cette fonctionnalit� sera utilis�e notamment pour l'edition in-site qui ne sera valable que
class SiteAccessNameOperator
{
    function SiteAccessNameOperator()
    {
    }

    function operatorList()
    {
        return array( 'currentsiteaccessname' );
    }

    function namedParameterPerOperator()
    {
        return false;
    }    
    
    function namedParameterList()
    {
        return false;
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'currentsiteaccessname' :
            {
                $operatorValue =$GLOBALS['eZCurrentAccess']['name'];
            } break;
        }
    }
}

?>