function addClassAttribute(){
	//alert('addClassAttribute. id = '+classId);
	//alert($("#DataTypeString").val());
	
	$.ajax({
		type:"POST",
		url:"/"+siteaccess+"/ajaxclassedit/add-attribute",
		data:"classId="+classId+"&datatype="+$("#DataTypeString").val()+"&language="+editLanguage+"&attributeNumber="+attributeNumber,
		success:displayNewAttribute
	});
}

function displayNewAttribute(ret){
	// dans le cas o� c'est le premier attribut ajout� a la classe
	if($("#list-attribute").length == 0){
		$("#list-attribute-container").empty();
		$("#list-attribute-container").append('<table class="list" id="list-attribute" cellspacing="0"></table>');
	}
	
	attributeNumber++;
	$("#list-attribute").append(ret);
	
}

function delClassAttribute(attributeId){
	if(confirm('Etes-vous sur de vouloir supprimer cet attribut ?')){
		$.ajax({
			type:"POST",
			url:"/"+siteaccess+"/ajaxclassedit/del-attribute",
			data:"attributeId="+attributeId,
			success:function(ret){
				$("#attribute_header_"+attributeId).remove();
				$("#attribute_content_"+attributeId).remove();
				attributeNumber--;	
			}
		});		
	}
}

function moveUpAttribute(attributeId){
	var attPosition = getAttributePosition("attribute_header_"+attributeId);
	
	if(attPosition > 1){
		$.ajax({
			type:"POST",
			url:"/"+siteaccess+"/ajaxclassedit/move-attribute",
			data:"attributeId="+attributeId+"&moveDown=0",
			success:function(ret){
				var previousAttId = getPreviousAttribute(parseInt(attPosition));
				previousAttId = getAttributeId(previousAttId);
				swapAttribute(previousAttId, attributeId);
			}
		});	
	}
}

function moveDownAttribute(attributeId){
	var attPosition = getAttributePosition("attribute_header_"+attributeId);
	
	if(attPosition < attributeNumber){
		$.ajax({
			type:"POST",
			url:"/"+siteaccess+"/ajaxclassedit/move-attribute",
			data:"attributeId="+attributeId+"&moveDown=1",
			success:function(ret){
				var nextAttId = getNextAttribute(parseInt(attPosition));
				nextAttId = getAttributeId(nextAttId);
				swapAttribute(attributeId, nextAttId);
			}
		});	
	}
}

function getAttributePosition(attributeId){
	if($("#"+attributeId+" > th > div > :text").length > 0){
		var position = $("#"+attributeId+" > th > div > :text").get(0).value;
		return position;
	}
	
	return -1;
}

function setAttributePosition(attributeId, position){
	if($("#attribute_header_"+attributeId+" > th > div > :text").length > 0){
		$("#attribute_header_"+attributeId+" > th > div > :text").get(0).value = position;
	}
	
	if($("#attribute_content_"+attributeId+" td :hidden[name^='ContentAttribute_position']").length > 0){
		$("#attribute_content_"+attributeId+" td :hidden[name^='ContentAttribute_position']").get(0).value = position;
	}
	
	return false;
}

function getNextAttribute(originAttributePosition){
	var currentPosition = 0;
	var ret = '';
	$("tr[id^='attribute_header_']").each(function(idx){
		currentPosition = getAttributePosition(this.id);
		if(currentPosition == (originAttributePosition+1)){
			ret = this.id;
		}
	});
	
	return ret;
}

function getPreviousAttribute(originAttributePosition){
	var currentPosition = 0;
	var ret = '';
	$("tr[id^='attribute_header_']").each(function(idx){
		currentPosition = getAttributePosition(this.id);
		if(currentPosition == (originAttributePosition-1)){
			ret = this.id;
		}
	});
	
	return ret;
}

function getAttributeId(attributeIdentifier){
	var attIdentifier = attributeIdentifier.split('_');
	return attIdentifier[attIdentifier.length - 1];
}

function swapAttribute(fromAttributeId, toAttributeId){
	// on recupere les position
	var positionFrom = getAttributePosition("attribute_header_"+fromAttributeId);
	var positionTo = getAttributePosition("attribute_header_"+toAttributeId);
	
	
	// on deplace l'attribut du dessus en dessous de celui du dessous
	var headerFrom = $("#attribute_header_"+fromAttributeId).clone();
	var contentFrom = $("#attribute_content_"+fromAttributeId).clone();
	$("#attribute_header_"+fromAttributeId).remove();
	$("#attribute_content_"+fromAttributeId).remove();
	$("#attribute_content_"+toAttributeId).after(headerFrom);
	$("#attribute_header_"+fromAttributeId).after(contentFrom);
	
	// on echange les valeurs des positions
	setAttributePosition(fromAttributeId, positionTo);
	setAttributePosition(toAttributeId, positionFrom);
}