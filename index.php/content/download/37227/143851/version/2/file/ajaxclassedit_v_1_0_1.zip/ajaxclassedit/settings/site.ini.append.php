<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ajaxclassedit

*/ ?>