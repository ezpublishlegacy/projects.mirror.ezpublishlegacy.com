<?php
/*
 * Permet l'ajout en AJAX d'un attribut pour une classe 
 *
 * @since 10/10/2008
 * @author Arnaud Georgin
 */
 include_once( "kernel/common/template.php" );

// suppression du debug pour ne pas polluer la reponse AJAX
eZDebug::updateSettings(array(
	"debug-enabled" => false,
	"debug-by-ip" => false,
	"debug-ip-list" => array()
));

// initialisation des variables
$tpl = templateInit();		// template handler


if(isset($_POST['classId']) && $_POST['classId'] != ''
	&& isset($_POST['datatype']) && $_POST['datatype'] != ''
	&& isset($_POST['language']) && $_POST['language'] != ''
	){
	
	$new_attribute = eZContentClassAttribute::create( $_POST['classId'], $_POST['datatype'], array(), $_POST['language'] );
    /*$attrcnt = count( $attributes ) + 1;
    $new_attribute->setName( ezi18n( 'kernel/class/edit', 'new attribute' ) . $attrcnt, $_POST['language'] );*/
    $new_attribute->setName( ezi18n( 'kernel/class/edit', 'new attribute' ), $_POST['language'] );
    $dataType = $new_attribute->dataType();
    $dataType->initializeClassAttribute( $new_attribute );
    $new_attribute->store();

    $tpl->setVariable('Attributes', $new_attribute);
    $tpl->setVariable('language_code', $_POST['language']);
    $tpl->setVariable('attribute_number', ($_POST['attributeNumber']+1));
    
    echo $tpl->fetch('design:attribute_edit.tpl');
}
$Result = array();
$Result['pagelayout'] = '';
?>
