<?php
$Module = array( "name" => "ajaxclassedit",
                 "variable_params" => true);
                 
$ViewList = array();
$ViewList["add-attribute"]= array(
							'script' => 'addClassAttribute.php'
						);
						
$ViewList["del-attribute"]= array(
							'script' => 'delClassAttribute.php'
						);
						
$ViewList["move-attribute"]= array(
							'script' => 'moveClassAttribute.php'
						);
?>
