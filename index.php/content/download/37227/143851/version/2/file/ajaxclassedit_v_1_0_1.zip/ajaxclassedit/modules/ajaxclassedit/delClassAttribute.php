<?php
/*
 * Permet la suppression en AJAX d'un attribut pour une classe 
 *
 * @since 10/10/2008
 * @author Arnaud Georgin
 */
 
// suppression du debug pour ne pas polluer la reponse AJAX
eZDebug::updateSettings(array(
	"debug-enabled" => false,
	"debug-by-ip" => false,
	"debug-ip-list" => array()
));

if(isset($_POST['attributeId']) && $_POST['attributeId'] != ''){
	$attribute = eZContentClassAttribute::fetch($_POST['attributeId'], true, eZContentClass::VERSION_STATUS_TEMPORARY);
	if(!is_object( $attribute ) or $attribute->attribute( 'id' ) == null){
		$attribute = eZContentClassAttribute::fetch($_POST['attributeId'], true, eZContentClass::VERSION_STATUS_DEFINED);
	}
	
	if(!is_null($attribute)){
		$attribute->removeThis(true);
	}else{
		echo 'O';
	}
}else{
	echo 'O';
}

$Result = array();
$Result['pagelayout'] = '';
?>
