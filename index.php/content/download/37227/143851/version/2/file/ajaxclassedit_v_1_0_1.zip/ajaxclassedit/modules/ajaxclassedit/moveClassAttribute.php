<?php
/*
 * Permet de deplacer en AJAX d'un attribut pour une classe 
 *
 * @since 14/10/2008
 * @author Arnaud Georgin
 */
 
// suppression du debug pour ne pas polluer la reponse AJAX
eZDebug::updateSettings(array(
	"debug-enabled" => false,
	"debug-by-ip" => false,
	"debug-ip-list" => array()
));

if(isset($_POST['attributeId']) && $_POST['attributeId'] != ''
	&& isset($_POST['moveDown']) && $_POST['moveDown'] != ''){
	$attribute = eZContentClassAttribute::fetch($_POST['attributeId'], true, eZContentClass::VERSION_STATUS_TEMPORARY);
	if(!is_object( $attribute ) or $attribute->attribute( 'id' ) == null){
		$attribute = eZContentClassAttribute::fetch($_POST['attributeId'], true, eZContentClass::VERSION_STATUS_DEFINED);
	}
	
	if(!is_null($attribute)){
		if($_POST['moveDown'] == 1){
			$attribute->move(true);
		}else{
			$attribute->move(false);
		}
	}else{
		echo 'O';
	}
}else{
	echo 'O';
}

$Result = array();
$Result['pagelayout'] = '';
?>
