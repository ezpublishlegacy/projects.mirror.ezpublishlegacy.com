<?php /* #?ini charset="utf-8"?

[ajaxedit_class]
Source=class/edit.tpl
MatchFile=edit_class.tpl
Subdir=templates


*/?>