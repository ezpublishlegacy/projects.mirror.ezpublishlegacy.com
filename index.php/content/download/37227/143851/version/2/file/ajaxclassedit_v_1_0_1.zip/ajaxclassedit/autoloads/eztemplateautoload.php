<?php 
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ajaxclassedit/autoloads/siteaccessnameoperator.php',
                                    'class' => 'SiteAccessNameOperator',
                                    'operator_names' => array( 'currentsiteaccessname' ) );
?>