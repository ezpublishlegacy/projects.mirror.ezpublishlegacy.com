<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=opengraph

[opengraph]
Reference=
Filters[]
Filters[]=geometry/scale=200;200
*/ ?>
