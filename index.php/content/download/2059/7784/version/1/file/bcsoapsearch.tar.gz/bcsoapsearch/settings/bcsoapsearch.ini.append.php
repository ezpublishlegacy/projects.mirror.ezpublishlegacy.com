<?php /* #?ini charset="utf8"?

[BcSoapSearchSettings]
DocumentUrlPrefix=http://ezpedia.org/wiki/en/

*/ ?>