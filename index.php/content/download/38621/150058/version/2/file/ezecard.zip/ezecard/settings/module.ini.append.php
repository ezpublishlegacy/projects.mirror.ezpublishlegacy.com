<? /* #?ini charset="iso-8859-2"?

[ModuleSettings]
ExtensionRepositories[]=ezecard

*/ ?>