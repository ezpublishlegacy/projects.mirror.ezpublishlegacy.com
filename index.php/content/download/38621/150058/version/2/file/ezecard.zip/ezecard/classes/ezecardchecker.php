<?php
//
// Definition of eZPaypalChecker class
//
// Created on: <18-Jul-2004 14:18:58 dl>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.6
// BUILD VERSION: 17337
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezecardchecker.php
*/

/*!
  \class eZEcardChecker ezecardchecker.php
  \brief The class eZEcardChecker implements
  functions to perform verification of the
  paypal's callback.
*/

include_once( 'kernel/shop/classes/ezpaymentcallbackchecker.php' );

class eZEcardChecker extends eZPaymentCallbackChecker
{
    /*!
        Constructor.
    */
    function eZECardChecker( $iniFile )
    {
        $this->eZPaymentCallbackChecker( $iniFile );
        $this->logger =& eZPaymentLogger::CreateForAdd( 'var/log/eZEcardChecker.log' );    
    }

    /*!
        Sprawdzenie, czy poprawny callback
        dla eCard zawsze poprawny
    */
    function requestValidation()
    {
    	return checkServerIP();
    }

    /*!
        True, je�li p�atno�� lub transfer poprawnie zako�czone
    */
    function checkPaymentStatus()
    {
        $prev_state = $this->callbackData["PREVIOUSSTATE"];
        $curr_state = $this->callbackData["CURRENTSTATE"];

        if ($prev_state == "payment_pending" && ($curr_state == "payment_approved" || $curr_state == "payment_deposited"))
        {
            return true;
        }

        if ($prev_state == "payment_pending" && ($curr_state == "payment_approved" || $curr_state == "payment_deposited"))
            return true;

        if ($curr_state == "transfer_closed")
            return true ;
        
        $this->logger->writeTimedString( 'checkPaymentStatus prev=' . $prev_state . " curr=" . $curr_state );
        return false;
    }
}

?>
