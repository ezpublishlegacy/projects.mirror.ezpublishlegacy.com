<? /* #?ini charset="iso-8859-2"?

[PaymentSettings]
MerchantId=1234567890
Password=XXXXXXXXXXX
HSServlet=https://pay.ecard.pl/servlet/HS
PSServlet=https://pay.ecard.pl/payment/PS
PaymentType=CARDS
AutoDeposit = 1

[ServerSettings]
ServerIP[]=193.178.213.69

*/ ?>