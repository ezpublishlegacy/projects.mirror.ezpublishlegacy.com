<?php
//
// Definition of eZEcardGateway class
//
// Created on: <18-Jul-2004 14:18:58 dl>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.6
// BUILD VERSION: 17337
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezecardgateway.php
*/

/*!
  \class eZEcardGateway ezecardgateway.php
  \brief The class eZEcardGateway implements
  functions to perform redirection to the eCard
  payment server.
*/


// TODO - na b��dzie zam�wienia nie mo�na wprowadzi�

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezredirectgateway.php' );
include_once( 'extension/solaris/modules/solaris/transport.php' );

//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_ECARD", "ezecard" );

class eZEcardGateway extends eZRedirectGateway
{
    /*!
        Constructor.
    */
    function eZEcardGateway()
    {
        //__DEBUG__
            $this->logger = eZPaymentLogger::CreateForAdd( "var/log/eZEcardType.log" );
            $this->logger->writeTimedString( 'eZEcardGateway::eZEcardGateway()' );
        //___end____
    }

    /*!
        Creates new eZeCardGateway object.
    */
    function &createPaymentObject( &$processID, &$orderID )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createPaymentObject");
        //___end____

        return eZPaymentObject::createNew( $processID, $orderID, 'eCard' );
    }

	/*!
        Creates redirectional url to eCard server.
    */
    function &createRedirectionUrl( &$process )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createRedirectionUrl");
        //___end____

        // Pobranie danych do p�atno�ci
		$eCardINI =& eZINI::instance( 'ecard.ini' );
		$merchantID = $eCardINI->variable( 'PaymentSettings', 'MerchantId' ) ;
		$password = $eCardINI->variable( 'PaymentSettings', 'Password' ) ;
		$HSServlet = $eCardINI->variable( 'PaymentSettings', 'HSServlet' ) ;
		$PSServlet = $eCardINI->variable( 'PaymentSettings', 'PSServlet' ) ;
		$paymentType = $eCardINI->variable( 'PaymentSettings', 'PaymentType' ) ;
        $autoDeposit = $eCardINI->variable( 'PaymentSettings', 'AutoDeposit' ) ;
         
        // pobranie kwoty p�atno�ci
        $processParams  =& $process->attribute( 'parameter_list' );
        $orderID        = $processParams['order_id'];
        $order          =& eZOrder::fetch( $orderID );
        $amount         =  100 * $order->attribute( 'total_inc_vat' ) ;
        	
       	// Pobranie hasha z serwera eCard
        $this->logger->writeTimedString('Pobieranie hash z ' . $HSServlet);
       	$hstable="orderDescription="		.
       			 "&amount=$amount"			.
       			 "&currency=985"			.
       			 "&merchantId=$merchantID"	.
       			 "&password=$password"		.
       			 "&orderNumber=$orderID" ;

        //__DEBUG__
        $this->logger->writeTimedString("orderDescription=");
        $this->logger->writeTimedString("amount=$amount");
        $this->logger->writeTimedString("currency=985");
        $this->logger->writeTimedString("merchantId=$merchantID");
        $this->logger->writeTimedString("password=$password");
        $this->logger->writeTimedString("orderNumber=$orderID");
        //___end____

        $localHost      = eZSys::hostname();
        $indexDir       = eZSys::indexDir();

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $HSServlet);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_SSLVERSION, 2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $hstable); 
		$result=curl_exec ($ch);
		if (!$result) 
		{
			$this->logger->writeTimedString('Brak hash z eCard');
			return "http://$localHost" . $indexDir. "/shop/basket/" ; 
		}
		$this->logger->writeTimedString('Rezultat=' . $result );
		$result=trim($result);
	  	if($result=="zlyHash" or $result=="wrongPassword") 
		{
			$this->logger->writeTimedString('B��dny hash');
			return "http://$localHost" . $indexDir. "/shop/basket/" ; 
		}
		
		// Przygotowanie danych do zam�wienia
		$accountInfo    = $order->attribute( 'account_information' );
        $first_name     = urlencode( $accountInfo['first_name'] );
        $last_name      = urlencode( $accountInfo['last_name'] );

		$url = $PSServlet 					.	
			"?ORDERNUMBER=$orderID"			.
			"&MERCHANTID=$merchantID"		.
			"&PASSWORD=$password"			.
			"&ORDERDESCRIPTION=Zam�wienie Ksi�garnia SOLARIS"	. 
			"&AMOUNT=$amount"				.
			"&CURRENCY=985"					.
			"&SESSIONID=null"				.
			"&NAME=$first_name"				. 
			"&SURNAME=$last_name"			. 
			"&AUTODEPOSIT=$autoDeposit"		. 
			"&LANGUAGE=PL"					. 
			"&CHARSET=ISO-8859-2"			.
			"&HASH=$result"					.
			"&PAYMENTTYPE=$paymentType"		. 
			"&LINKOK=http://$localHost" . $indexDir . "/shop/checkout/" .
			"&LINKFAIL=http://$localHost" . $indexDir. "/shop/basket/" ;
			
        //__DEBUG__
            $this->logger->writeTimedString("ORDERNUMBER=$orderID");
            $this->logger->writeTimedString("MERCHANTID=$merchantID");
            $this->logger->writeTimedString("PASSWORD=$password");
            $this->logger->writeTimedString("ORDERDESCRIPTION=Zam�wienie Ksi�garnia SOLARIS");
            $this->logger->writeTimedString("AMOUNT=$amount");
            $this->logger->writeTimedString("CURRENCY=985");
            $this->logger->writeTimedString("SESSIONID=null");
            $this->logger->writeTimedString("NAME=$first_name");
            $this->logger->writeTimedString("SURNAME=$last_name" );
            $this->logger->writeTimedString("AUTODEPOSIT=$autoDeposit"); 
            $this->logger->writeTimedString("LANGUAGE=PL"); 
            $this->logger->writeTimedString("CHARSET=ISO-8859-2"); 
            $this->logger->writeTimedString("HASH=$result"); 
            $this->logger->writeTimedString("PAYMENTTYPE=$paymentType");  
            $this->logger->writeTimedString("LINKOK=http://$localHost" . $indexDir . "/shop/checkout/"); 
            $this->logger->writeTimedString("LINKFAIL=http://$localHost" . $indexDir. "/shop/basket/"); 
        //___end____

        return $url;
    }
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_ECARD, "ezecardgateway", "eCard" );

?>
