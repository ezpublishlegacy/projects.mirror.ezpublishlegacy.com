<? /* #?ini charset="iso-8859-2"?

[RoleSettings]
PolicyOmitList[]=ecard/notify_url

*/
?>