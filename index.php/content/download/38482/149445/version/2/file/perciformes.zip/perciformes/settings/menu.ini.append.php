<?php /* #?ini charset="iso-8859-1"?

[SelectedMenu]
CurrentMenu=LeftOnly
TopMenu=
LeftMenu=flat_left

*/ ?>