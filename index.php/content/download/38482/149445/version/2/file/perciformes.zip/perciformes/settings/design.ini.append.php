<?php
/*
[ExtensionSettings]
DesignExtensions[]=perciformes

[StylesheetSettings]
CSSFileList[]=dropdown.css

[JavaScriptSettings]
JavaScriptList[]=script_suckerfish.js
*/
?>