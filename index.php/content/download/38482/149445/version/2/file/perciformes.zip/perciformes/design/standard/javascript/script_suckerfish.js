sfHover = function() {
          var sfEls = document.getElementById("nav").getElementsByTagName("LI");
          for (var i=0; i<sfEls.length; i++) {
             		sfEls[i].onmouseover=function() {
                this.className+=" sfhover";
             }
             sfEls[i].onmouseout=function() {
                this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
             }
          }
       }
       if (window.attachEvent) window.attachEvent("onload", sfHover);
        

       sfHover = function() {
          var sfEls = document.getElementById("tache_menu").getElementsByTagName("LI");
          for (var i=0; i<sfEls.length; i++) {
             		sfEls[i].onmouseover=function() {
                this.className+=" sfhover";
             }
             sfEls[i].onmouseout=function() {
                this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
             }
          }
       }
       if (window.attachEvent) window.attachEvent("onload", sfHover);




function AffMenu(Div) {
   if (document.getElementById(Div).style.display=='none') {
     document.getElementById(Div).style.display='InLine';
    }
    else {
     document.getElementById(Div).style.display='none';
    }
  }
  
  function controle()
      {
      	if (document.getElementById("tmp_from_realise").value != ""){
      		document.getElementById("from_realise").value=convert_date_bottom(document.getElementById("tmp_from_realise").value);
      	}else
      		document.getElementById("from_realise").value="";
      		
      	if (document.getElementById("tmp_to_realise").value != ""){
      		document.getElementById("to_realise").value=convert_date_top(document.getElementById("tmp_to_realise").value);
      	}else
      		document.getElementById("to_realise").value="";
      		
      	if (document.getElementById("tmp_from_echeance").value != ""){
      		document.getElementById("from_echeance").value=convert_date_bottom(document.getElementById("tmp_from_echeance").value);
      	}else
      		document.getElementById("from_echeance").value="";
      		
      	if (document.getElementById("tmp_to_echeance").value != ""){
      		document.getElementById("to_echeance").value=convert_date_top(document.getElementById("tmp_to_echeance").value);
      	}else
      		document.getElementById("to_echeance").value="";
      		
      	
      	
      	document.search_form.submit();
      }
      
      
 function convert_date_bottom(date_str){
 	tab_date_str=date_str.split("/");
 	var thisDate = new Date();
	thisDate.setYear(tab_date_str[2]);
	thisDate.setMonth(tab_date_str[1]-1);
	thisDate.setDate(tab_date_str[0]);
	thisDate.setHours(0);
	thisDate.setMinutes(0);
	
	var timestamp=Math.floor((thisDate.getTime()/1000.0)-60);
	return timestamp;
 }
 
  function convert_date_top(date_str){
 	tab_date_str=date_str.split("/");
 	var thisDate = new Date();
	thisDate.setYear(tab_date_str[2]);
	thisDate.setMonth(tab_date_str[1]-1);
	thisDate.setDate(tab_date_str[0]);
	thisDate.setHours(23);
	thisDate.setMinutes(59);
	
	var timestamp=Math.floor(thisDate.getTime()/1000.0);
	return timestamp;
 }