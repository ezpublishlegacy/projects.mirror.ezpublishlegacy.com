<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_GB">
<context>
    <name>design/abpdfcatalogue/view</name>
    <message>
        <source>Create catalogue</source>
        <translation>Katalog erstellen</translation>
    </message>
    <message>
        <source>Loading</source>
        <translation>Lade</translation>
    </message>
    <message>
        <source>You do not have the permission to generate a personal PDF catalogue</source>
        <translation>Sie haben keine Berechtigung, um einen personalisierten PDF Katalog zu erstellen</translation>
    </message>
    <message>
        <source>Remove document</source>
        <translation>Dokument entfernen</translation>
    </message>
    <message>
        <source>Download document</source>
        <translation>Dokument herunterladen</translation>
    </message>
    <message>
        <source>show</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>No documents selected</source>
        <translation>Keine Dokumente ausgewählt</translation>
    </message>
    <message>
        <source>Use the mouse to drag catalogue documents and drop them in the target zone</source>
        <translation>Nehmen Sie Katalog Dokumente mit der Maus auf und lassen Sie sie im Zielbereich wieder los</translation>
    </message>
</context>
<context>
    <name>pdfcatalogue</name>
    <message>
        <source>Page %1 of %2</source>
        <translation>Seite %1 von %2</translation>
    </message>
    <message>
        <source>Page %1</source>
        <translation>Seite %1</translation>
    </message>
</context>
</TS>
