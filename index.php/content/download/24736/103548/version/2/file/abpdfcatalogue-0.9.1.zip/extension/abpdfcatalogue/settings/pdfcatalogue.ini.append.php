<?php /*

[CommonSettings]
# Relative to [FileSettings] VarDir CacheDir
# e.g. var/cache/pdfcatalogue
PDFCacheDirectory=pdfcatalogue

*/ ?>