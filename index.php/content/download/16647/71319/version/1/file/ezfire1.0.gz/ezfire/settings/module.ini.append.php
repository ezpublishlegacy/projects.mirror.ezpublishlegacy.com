<?php /* #?ini charset="iso-8859-1"?
[ModuleSettings]
#If this isn't set, then nothing is sent to the FireBug interface
FireDebug=enabled

DebugLevel=INFO
#This goes to the Display
DumpToScreen=disabled
#Debug output to a file 
DumpToFile=disabled
#This goes to a File
DebugFile=/tmp/fire.txt
*/ ?>
