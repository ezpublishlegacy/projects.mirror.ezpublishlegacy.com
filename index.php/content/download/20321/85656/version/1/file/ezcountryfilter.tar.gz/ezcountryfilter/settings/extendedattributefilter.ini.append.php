<?php
/*

[CountryFilter]
ExtensionName=ezcountryfilter

ClassName=eZCountryFilter

MethodName=createSqlParts

FileName=classes/ezcountryfilter.php
*/
?>




