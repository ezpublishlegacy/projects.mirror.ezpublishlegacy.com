<?php
class eZCountryFilter
{

    function eZCountryFilter(){
    }
    function createSqlParts($params){
	
	$Alpha2 = isset( $params['name'] ) ? $params['name'] : '';
	
	$countryAlpha2 = eZCountryType::fetchCountry($Alpha2);
        
	$sqlTables= ', ezcontentobject_attribute as country_filter ';
        $sqlJoins = 'country_filter.data_text = "'.$countryAlpha2['Alpha2'].'" AND ezcontentobject_tree.contentobject_id = country_filter.contentobject_id AND ezcontentobject_tree.contentobject_version = country_filter.version AND country_filter.data_type_string = "ezcountry" AND';
    	return array( 'tables' => $sqlTables, 'joins' => $sqlJoins );
                                                                   
  }
}


?>
