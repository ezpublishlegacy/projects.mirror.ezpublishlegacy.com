eZ Publish Translation Transformation Toolset

USAGE

1. copy your old localized translation file into the current directory
2. copy the brand new untranslated (share/translations/untranslated/translation.ts) translation file into the current directory
3. edit translate.xsl so that it references your files, instead of the default (hr-3.5... and en-3.6...) values
4. run the following commmand:
$ python xslrun.py translate.xsl > mynewtranslationfile.xml
5. check to see if everything is OK
6. see notes below

KNOWN BUGS

"Source" keys in translation files can change from version to version (e.g. there are differences between version 3.5 and 3.6): in such cases, your translation will unconditionally be skipped.

KNOWN ISSUES

I haven't taken care of the missing <!DOCTYPE TS> statement. Insert it by hand.

The python script really should be reworked so that the dummy.xml file isn't needed. I'm considering using a java (xalan?) command line tool call instead of python as java is more likely to be available on Microsoft platforms, but will probably not do it unless the community shows interest.

The name of the translation files should be edited directly in the translate.xsl file: oneday this might be parametrized.

DESIRED FUNCTIONALITY

The following stylesheets would be very welcome:
1. An .xsl to printout all the unaffected translations in the new translation file version
2. An .xsl to printout all the unused keys in the old localized translation file
(as far as I know, separate .xsls are needed because a single .xsl cannot output multiple files...though I can think of a few workarounds)

Authors:
Tomislav Nakic-Alfirevic (tomislav_/at\_netgen.hr), Netgen Ltd. (http://www.netgen.hr)

This code is released under the LGPL Licence, version 2.1 (see the lgpl.txt file).