# xsltprocs.py: send an XML source document through a
# pipeline of multiple XSLT stylesheets. 

import sys
import libxml2
import libxslt

args = len(sys.argv)

if args <>  2:
    print "Pipeline an XML document through a series "
    print "of XSLT stylesheets. Usage:\n"
    print "python xsltprocs.py translate.xsl"
    print ""
    print "You should edit translate.xsl so that it references your translation files: this may be parametrized in future versions."
    sys.exit(0)

sourceXMLFile = "dummy.xml"
sourceDoc = libxml2.parseFile(sourceXMLFile)

styleDoc = libxml2.parseFile(sys.argv[1])
style = libxslt.parseStylesheetDoc(styleDoc)
result = style.applyStylesheet(sourceDoc, None)

print result

style.freeStylesheet()
sourceDoc.freeDoc()
