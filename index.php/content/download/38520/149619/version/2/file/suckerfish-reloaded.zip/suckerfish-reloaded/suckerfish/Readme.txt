SuckerFish-Reloaded Extension Read Me

What is the SuckerFish-Reloaded extension?
================================================

A dynamic menu, which show the childs when you pass over an element of the menu.
It is based on the suckefish but packed as a real ezpublish extension which means 
that you can download it and activate it through the admin interface.
Plus is solves a conflict between the original suckerfish stylesheet and the eZpublish stylsheet
causing margins in the menu.


Installation
============
Please read the INSTALL file for installation instructions.


Content
==================================
   
   You have seven files in this extension :
   	- /settings/design.ini.append.php   : include the design extension
   	- /settings/menu.ini.append.php     : switch the menu positioning to Double top menu
   	- /design/standard/images/arrow.gif : image which indicate a level for third and forth level
   	- /design/standard/javascript/script_suckerfish.js : script useful for Internet Explorer to load the menu
   	- /design/standard/stylesheet/dropdown.css : stylesheet of the menu
   	- /design/standard/templates/menu/double_top.tpl : generate the ul/li hierarchy of the menu
   	
   Of course, these files can be modified to personalise your own menu.
   Change the colors, the width, height of the cells, etc... in the style sheet.
   Add class id to the fetch functions used in double_top.tpl to add class elements.