<?php
/*
[ExtensionSettings]
DesignExtensions[]=suckerfish

[StylesheetSettings]
CSSFileList[]=dropdown.css

[JavaScriptSettings]
JavaScriptList[]=script_suckerfish.js
*/
?>