<?php

// we're lazy bastards
include( '../xmlrpc/initialize.php' );

?>
