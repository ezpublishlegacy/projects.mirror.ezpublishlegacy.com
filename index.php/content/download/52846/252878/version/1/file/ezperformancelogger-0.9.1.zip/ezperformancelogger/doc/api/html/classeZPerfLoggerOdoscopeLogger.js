var classeZPerfLoggerOdoscopeLogger =
[
    [ "doLog", "classeZPerfLoggerOdoscopeLogger.html#abc3223070a593156f023874d14292bd0", null ],
    [ "generateJSEventsFunctionCalls", "classeZPerfLoggerOdoscopeLogger.html#a86c686dc8cc43ea4f4a16ad56eb11f0c", null ],
    [ "logByJSEvents", "classeZPerfLoggerOdoscopeLogger.html#a1de0f4a9f18f818df9d13dee9e8ade51", null ],
    [ "logByRewrite", "classeZPerfLoggerOdoscopeLogger.html#a949c010c0949624639ab2401189ceeff", null ],
    [ "supportedLogMethods", "classeZPerfLoggerOdoscopeLogger.html#a706eecae5db778d462925249077c2057", null ]
];