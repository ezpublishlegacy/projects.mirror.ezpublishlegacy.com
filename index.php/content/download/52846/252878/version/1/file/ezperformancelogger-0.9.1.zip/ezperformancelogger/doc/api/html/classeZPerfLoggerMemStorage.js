var classeZPerfLoggerMemStorage =
[
    [ "getStats", "classeZPerfLoggerMemStorage.html#af9ef1cf09a2f379f995bf5b33daee49a", null ],
    [ "getStatsCount", "classeZPerfLoggerMemStorage.html#a2dd01fe3c31bd8770551acac990ff21e", null ],
    [ "insertStats", "classeZPerfLoggerMemStorage.html#aab82bd19054bc6baf3dc233f1fe1bdff", null ],
    [ "resetStats", "classeZPerfLoggerMemStorage.html#a4fdcf5f71805f49bc2435e121076f145", null ],
    [ "$stats", "classeZPerfLoggerMemStorage.html#ae7fbad5800a04b8d08fa0a1d089b70e0", null ],
    [ "$statsCount", "classeZPerfLoggerMemStorage.html#a6a4ada1f6b7a30a31aa1881a8aac32e4", null ]
];