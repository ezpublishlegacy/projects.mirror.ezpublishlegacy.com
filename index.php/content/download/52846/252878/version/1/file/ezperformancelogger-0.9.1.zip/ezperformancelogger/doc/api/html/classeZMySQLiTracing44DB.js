var classeZMySQLiTracing44DB =
[
    [ "accumulatorStart", "classeZMySQLiTracing44DB.html#a14bf3a9c4b4f8283de53058ccf2437d3", null ],
    [ "accumulatorStop", "classeZMySQLiTracing44DB.html#a052c9cee96255a6c8020d48e6e2e2724", null ],
    [ "arrayQuery", "classeZMySQLiTracing44DB.html#a77f391bbfef0e79a736688d031e7d2ad", null ],
    [ "connect", "classeZMySQLiTracing44DB.html#a4bdadc575d5aa089405b32b6e5c1386c", null ],
    [ "measure", "classeZMySQLiTracing44DB.html#acd31065c97ab6c10acc14b98dc16b91f", null ],
    [ "query", "classeZMySQLiTracing44DB.html#ac553dd4d27ec657e1ae02ed8c5edead4", null ],
    [ "timeAccumulators", "classeZMySQLiTracing44DB.html#a93f81791ae07941fa8ce0e6c75a23af1", null ],
    [ "$timeAccumulatorList", "classeZMySQLiTracing44DB.html#ac08c18bd2e4b0920fb74ca59af068e6e", null ]
];