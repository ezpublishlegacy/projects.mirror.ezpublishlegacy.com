var interfaceeZPerfLoggerFilter =
[
    [ "shouldLog", "interfaceeZPerfLoggerFilter.html#a1b3a98c6d27c31b37506a1a8cfcfa2c1", null ]
];