var interfaceeZPerfLoggerLogger =
[
    [ "doLog", "interfaceeZPerfLoggerLogger.html#ae1de4e5a0cb00799bd94985a372313c2", null ],
    [ "supportedLogMethods", "interfaceeZPerfLoggerLogger.html#aecf6f4402d8a624f014b885b01e7966c", null ]
];