** OVERVIEW **

This patch allows EzPublish to be used with the Single Sign On server CAS (Central Authentication Service).

Thanks to SSO with CAS, users can log only once on several applications, as long as these applications are using CAS. CAS supports many types of clients (Java, PHP, Perl, Apache HTTPD) and some applications have a built-in support (ex.: Liferay Portal). The CAS server can be plugged to various user repository (LDAP, database, file...). 

This contribution has been tested in real world projects and has been made possible thanks to the SITIV (a french public organism).


** INSTALLATION **

Create (in EZpublish) admin user that is also in the user repository used by CAS (ex.: LDAP), otherwise you won't be able to log in when the patch is installed!

Save the ezuser.php file.

Copy the patch directories in the EZpublish directory.

The CAS configuration can be made in the file settings/cas.ini


** VERSIONS **
(modified by JB.Arnoux)
EZpublish: 4.0.1 
esup-casgeneric version=2.1.2
PHP-CAS: 5.2.6-5


** WEBSITES **

CAS Server: http://www.ja-sig.org/products/cas/index.html
PHP CAS: http://www.ja-sig.org/wiki/display/CASC/phpCAS
SITIV: http://www.sitiv.fr/
SQLI: http://www.sqli.com/

** LICENSE **

This patch is distributed under the LGPL license 
(http://www.gnu.org/licenses/lgpl.html) and comes without any warranty.

JBA what i made exactly:
I've just integrated code made by Arnaud Cogoluegnes in ezuser.php file from Ezpublish 4.0.1.
I modified control in _checkCASAuthentication() function.
I integrated php-cas patch to avoid loop in login page with "user not found" lines in log file.
I replaced client.php file by this made by Pascal Aubry, and published with the pack EZPublish-CAS\EZ 3.8.6\.
It's not an important work, but i just though it would be helpfull.