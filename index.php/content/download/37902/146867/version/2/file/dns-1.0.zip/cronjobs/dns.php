<?php
/**
Author: Bjoern Dieding <bjoern@xrow.de>, xrow GbR Hannover Germany

run "php -C cronjobs/dns.php" to execute from ez root

Setup:
append this line to the named.conf (/etc/named.conf)
include "/home/www/web1/html/ez.xrow.de/var/named.append";

add this to the cronjob.ini if you want to use the ezcron handler
[CronjobSettings]
Scripts[]=dns.php

It might be wise todo like this instead: edit crontab and add this command
su web1 -c "cd ~/html/ez.xrow.de && php -C cronjobs/dns.php" && rcnamed restart

following content classes need to be created

Class domain with
    name (FQDN)
    server (Related Object)
    mailserver (Alternate Mailserver)

Class server with
    name (comment to identify the server)
    ip
    mailserver
*/
include_once("lib/ezutils/classes/ezdebug.php");
include_once("lib/ezutils/classes/ezini.php");
include_once("lib/ezutils/classes/ezfile.php");
include_once( 'kernel/classes/ezcontentobject.php' );
$zoneDir='dns';
$domainclassid = '17';
$namedFile = 'named.append';
#default settings
# zoneofauthority is the first nameserver
$nameserver[]='ns.xrow.net';
#backup dns
$nameserver[]='ns.schlund.de';
#default mailserver
$mailserver["10"]='mail.xrow.net';
#backup mailserver
$mailserver["20"]='mx01.schlund.de';
$db =& eZDB::instance();
$sys = & eZSys::instance();

#This functoin only works if you call your shell script from the ez root dir
function absolutePath()
{
    if ( !isset( $this ) or get_class( $this ) != "ezsys" )
    $this =& eZSys::instance();
    //get current working dir
    $cwd  = posix_getcwd();
    //get self
    $self  = $this->serverVariable( 'PHP_SELF' );
    if ($this->absolutePath){
        return $this->absolutePath ;
    }elseif (file_exists($cwd.$this->FileSeparator.$self)){
        $this->absolutePath = $cwd;
        return $this->absolutePath; 
    }else{
        return null;
    }
}
$absolutePath = absolutePath();

$domains =& eZContentObject::fetchObjectList( eZContentObject::definition($domainclassid),
                                                       null,
                                                       array ('contentclass_id' => $domainclassid,  'status' => EZ_CONTENT_OBJECT_STATUS_PUBLISHED),
                                                       null,
                                                       null,
                                                       true
                                                       );
foreach ($domains as $domain){
    $dataMap = $domain->dataMap();
    
    $data[name] = $dataMap[name]->content();
    $serverdata = $dataMap[server]->content();
    $data[server] = $serverdata->dataMap();
    $data[mailserver] = $dataMap[mailserver]->content();

    $zonefile = '$TTL 1W'.$sys->LineSeparator;
    $zonefile .= '@               IN SOA       '.$nameserver[0].'.'.'   root.'.$data[name].". (".$sys->LineSeparator;
    $zonefile .= '2003052601      ; serial'.$sys->LineSeparator;
    $zonefile .= '3H              ; refresh'.$sys->LineSeparator;
    $zonefile .= '1H              ; retry'.$sys->LineSeparator;
    $zonefile .= '1W              ; expiry'.$sys->LineSeparator;
    $zonefile .= '11h)            ; minimum'.$sys->LineSeparator;
    foreach ($nameserver as $dns){
        $zonefile .= '    IN NS           '.$dns.'.'.$sys->LineSeparator;
    }   
    if (empty($data[mailserver])){
        
        foreach ($mailserver as $key => $mailer){
            if ($data[server][mailserver]->content() && $key == '10'){
                $mailer = $data[server][mailserver]->content();
            }
            $zonefile .= '    IN MX          '.$key.' '.$mailer.'.'.$sys->LineSeparator;
        }
    }else{
        $zonefile .= '    IN MX          10 '.$data[mailserver].'.'.$sys->LineSeparator;
    }

    $zonefile .= '                IN A            '.$data[server][ip]->content().$sys->LineSeparator;
    $zonefile .= '*               IN A            '.$data[server][ip]->content().$sys->LineSeparator;
    $file = eZFile::create  (  $data[name], $sys->varDirectory().$sys->FileSeparator.$zoneDir, $zonefile );

$nameddata .= 'zone "'.$data[name].'" {'.$sys->LineSeparator;
$nameddata .= '        type master;'.$sys->LineSeparator;
$nameddata .= '        file "'.$absolutePath.$sys->FileSeparator.$sys->varDirectory().$sys->FileSeparator.$zoneDir.$sys->FileSeparator.$data[name].'";'.$sys->LineSeparator;
$nameddata .= '        allow-query { any; };'.$sys->LineSeparator;
$nameddata .= '};'.$sys->LineSeparator;
}//end zone

$file = eZFile::create  (  $namedFile, $sys->varDirectory(), $nameddata );
print eZDebug::printReportInternal(false);

?>