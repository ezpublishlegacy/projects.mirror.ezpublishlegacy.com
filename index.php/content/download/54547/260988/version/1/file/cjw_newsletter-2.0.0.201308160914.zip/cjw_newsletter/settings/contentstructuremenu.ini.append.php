<?php /* #?ini charset="utf-8"? */

/**
 * File containing the contentstructurmenu ini
 *
 * @copyright Copyright (C) 2007-2012 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */

/*
[TreeMenu]
ShowClasses[]=cjw_newsletter_root
#ShowClasses[]=cjw_newsletter_system
#ShowClasses[]=cjw_newsletter_list

* */ ?>