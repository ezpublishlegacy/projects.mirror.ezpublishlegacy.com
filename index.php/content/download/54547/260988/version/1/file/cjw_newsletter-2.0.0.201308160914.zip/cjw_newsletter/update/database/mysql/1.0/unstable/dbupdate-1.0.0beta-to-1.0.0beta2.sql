
ALTER TABLE cjwnl_edition_send CHANGE output_xml output_xml LONGTEXT NOT NULL COMMENT 'xml with newsletter version of html, text';