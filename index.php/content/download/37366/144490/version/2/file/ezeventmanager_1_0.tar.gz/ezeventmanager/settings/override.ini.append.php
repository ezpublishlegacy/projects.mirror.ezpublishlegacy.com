<?php /*

[full_folder_ezeventmanager]
Source=node/view/full.tpl
MatchFile=full/full_folder.tpl
Subdir=templates
Match[class_identifier]=folder
Match[section]=11

[line_event_ezeventmanager]
Source=node/view/line.tpl
MatchFile=line/line_event.tpl
Subdir=templates
Match[class_identifier]=event

[full_event_ezeventmanager]
Source=node/view/full.tpl
MatchFile=full/full_event.tpl
Subdir=templates
Match[class_identifier]=event

[full_event_subscription_ezeventmanager]
Source=node/view/full.tpl
MatchFile=full/full_event_subscription.tpl
Subdir=templates
Match[class_identifier]=event_subscription

[edit_event_subscribtion_ezeventmanager]
Source=content/edit.tpl
MatchFile=edit/edit_event_subscribtion.tpl
Subdir=templates
Match[class_identifier]=event_subscription

[edit_event_sub_subscribtion_ezeventmanager]
Source=content/edit.tpl
MatchFile=edit/edit_event_sub_subscribtion.tpl
Subdir=templates
Match[class_identifier]=event_sub_subscription

[edit_event_subscribtion_user_ezeventmanager]
Source=content/edit_attribute.tpl
MatchFile=edit/edit_event_subscribtion_user.tpl
Subdir=templates
Match[class_identifier]=event_subscription

[edit_event_sub_subscribtion_user_ezeventmanager]
Source=content/edit_attribute.tpl
MatchFile=edit/edit_event_sub_subscribtion_user.tpl
Subdir=templates
Match[class_identifier]=event_sub_subscription

[view_user_ezeventmanager]
Source=user/edit.tpl
MatchFile=user/edit_user_account.tpl
Subdir=templates

[create_user_ezeventmanager]
Source=user/register.tpl
MatchFile=user/create_user_account.tpl
Subdir=templates

[edit_user_ezeventmanager]
Source=content/edit.tpl
MatchFile=edit/edit_user_account.tpl
Subdir=templates
Match[class_identifier]=user

*/ ?>