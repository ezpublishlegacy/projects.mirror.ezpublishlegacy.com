<?php /*

[ClassSettings]
EventId=34
EventSubscriptionId=35
EventSubSubscriptionId=36
EventName=event
EventSubscriptionName=event_subscription
EventSubSubscriptionName=event_sub_subscription

*/ ?>