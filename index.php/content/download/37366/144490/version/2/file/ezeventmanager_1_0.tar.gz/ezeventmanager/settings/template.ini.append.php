<?php /*

[WashSettings]
EmailAtText=_at_

*/ ?>