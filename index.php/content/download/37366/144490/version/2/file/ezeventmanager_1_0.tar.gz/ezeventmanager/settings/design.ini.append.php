<?php /*

[ExtensionSettings]
DesignExtensions[]=ezeventmanager

*/ ?>