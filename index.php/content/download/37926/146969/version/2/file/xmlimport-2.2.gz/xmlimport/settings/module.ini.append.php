<?php
/*
[ModuleSettings]
ExtensionRepositories[]=xmlimport

[XMLImportDefaults]

ParentNodeID=2598
Remove=false
MoveToTrash=false
XMLRoot=/*
SkipWhite=true
ReportFields=true
TestRun=false






*/
?>
