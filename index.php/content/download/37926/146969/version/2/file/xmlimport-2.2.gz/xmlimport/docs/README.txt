README XMLImport
--------------------------

This module extension allows the user to load an xml file containing data for a
serie of objects in the system. For each object described in the xml file a
content object is created and published. 

This module works for a number of datatypes, like ezuser, ezxmltext, ezimage,
etc. Your help is needed to add  support for more datatypes. 

The XML structure should match the content class structure quite semantically,
using attribute-identifiers as tagnames. There are some examples in the "docs"
folder. The ini file allows you to set some defaults on the import form.

The biggest issue is the memory limit. See 'known issues' below.

XMLImport1.9 was a complete rewrite from 
ImportXMLData 1.4.2 from Olivier Pierret:
http://ez.no/community/forum/developer/import_xml_data_topic 


------------
To import a file: 

After installation, you have a import interface
in the admin module. You can select a xml file
to import there. Press import et voila.

Your XML structure should mimic the objects you are
trying to import. An example XML file would be
 
 <whatever>
	<person>
		<person_first_name>john</person_first_name>
		<person_last_name>kerry</person_last_name>
	</person>
	<person>
		<person_first_name>adam</person_first_name>
		<person_last_name>curry</person_last_name>
	</person>
</whatever>

Where "person" is the actual class_identifier of a 
existing Content Class and "person_first_name" and 
"person_last_name" are actual attribute_identifiers
of existing Content Class Attributes.

In the xml, tagnames with prefix ezp_ are reserved; 
hence, you can not import attributes named "ezp_bla".

------------
To use the fetch: 

This module implements one fetch:
	
	{let result=fetch('xmlimport','xmlimport',
		hash(	xmldata,		$xmldata,
				parentnodeid, 	$parentnodeid,
				xmlroot, 		$xmlroot,
				settings, 		hash(
						"remove",$emove, 
						"movetotrash",$movetotrash, 
						"skipwhite",$skipwhite, 
						"reportfields",$reportfields, 
						"testrun",false()
				) 
					
			)
	}
	
the fetch returns a hash, containing:
	
	"result"
		["keys"]
			[0] => "field1"
			[1] => "field2"
			..
		["data"]
			[0]
				"field1"=>"value01"
				"field2"=>"value02"
				..
			[1]
				"field1"=>"value11"
				"field2"=>"value12"
				..
			..
		["status"]
			"ok"
		["message"]
			"all is fine"

		
if $reportfields==false, the $result.keys contains 5 fields:
ezp_cid, ezp_oid, ezp_nid, ezp_err and ezp_msg.  

if $reportfields==true, it also contains all found fields, which
may give you out of mem on large imports.

------------
Implementing new datatypes

Your help is neede to implement the leftover datatypes. If you know how a datatype works from php, it's probably very simple. Just put the right code in place:

Open the XMLImportFunctionCollection.php.

Search for the "set" function of the datatype at
the end of the file. Implement it.

Save the XMLImportFunctionCollection.php. Test it.
Mail it to me :-)

------------
Dependencies: 

- your phpserver needs XSL support.
- this module includes a modified version of 
  the PHPXPath PHP library (http://sourceforge.net/projects/phpxpath/);
  In which UTF-8 is enabled (and the memory footprint is made smaller).

-----------
Tested datatypes (ezp3.7.6):
 - ezauthor,
 - ezbinaryfile,
 - ezinteger, 
 - ezimage,
 - ezstring, 
 - eztext, 
 - ezemail, 
 - ezisbn, 
 - ezprice, 
 - ezfloat, 
 - ezboolean, 
 - ezdate, 
 - ezdatetime, 
 - ezurl, 
 - ezxmltext, 
 - ezobjectrelationbrowse
 - ezuser
 
Untested datatypes (y.m.m.v):
 - ezobjectrelation
 - ezobjectrelationlist
 
Unimplemented datatypes (y.h.i.n.):
 - ezenum
 - ezinisettings
 - ezkeyword
 - ezmatrix
 - ezmedia
 - ezmultioption
 - ezoption
 - ezpackage
 - ezrangeoption
 - ezselection
 - ezsubtreesubscription
 - eztime
 
Impossible datatypes:
 - ezidentifier
 
------------
Known issues: 

 - Importing objects eats memory. The more objects you import, the more memory
   is eaten per object. I have *not* been able to import more then 200 objects
   at a time. I have now implemented a memorylimit that should stop
   importing objects just before php would throw an out-of-memory error at you.
   However, I suggest you stay on the safe side and import only 'small'
   xml files :-|

 - UTF-8 is not supported out of the box.
	If you want to import UTF-8 xml files, add UTF-8 argument to 
	xml_parser_create function in line 1680 of XPatth.class.php file like this:
		$parser = xml_parser_create('UTF-8');

 - ezurl data type is only partially supported: the text of the link cannot be 
	set separately: it is set to the url value found in the xml file
 
 - when importing more than 50 users in one xml files, it seems that *some* 
	users may be duplicated - this problem triggered using Oracle with ezpublish 
	3.6.0 (ezOracle extension 1.2) and importXMLData.
	any help regarding this would be valuable...

-------------
Status:  

When used with caution and on small files, 
this is usefull and tested in 3.7.6





