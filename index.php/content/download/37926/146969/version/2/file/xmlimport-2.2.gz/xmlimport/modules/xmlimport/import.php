<?php
	//
	// Created on: <16-Feb-2005>
	// Edited: 		20061025*pike
	// Copyright (C) 2005-2004 Olivier Pierret & NSI-SA. All rights reserved.
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//
	
	define( "MODULE_INI_FILE", "module.ini" );
	include_once( "lib/ezutils/classes/ezhttptool.php" );
	//include_once( "lib/ezutils/classes/ezhttpfile.php" );
	
	$http =& eZHTTPTool::instance();
	
	$Module =& $Params['Module'];
	
	if ($http->postVariable('action')) {
		// have post, must read
		
		$parentnodeid 	= $http->postVariable('parentnodeid');
		$xmlroot 		= $http->postVariable('xmlroot');
		$barebones 		= ($http->postVariable('barebones')=='on');
		$settings 		= array(
				"remove" 		=> ($http->postVariable('remove')=='on'),
				"movetotrash" 	=> ($http->postVariable('movetotrash')=='on'),
				"reportfields" 	=> ($http->postVariable('reportfields')=='on'),
				"skipwhite" 	=> ($http->postVariable('skipwhite')=='on'),
				"testrun" 		=> ($http->postVariable('testrun')=='on')
		);
				
			
		if ($http->postVariable('action')=="import") {
			if ($http->hasPostVariable( 'submitXMLData' ) && isset($_FILES['xmldata'])) {
				$xmldata 	= file_get_contents($_FILES['xmldata']['tmp_name']);
			} else { 
				$xmldata = "";
			}
		} else { 
			$xmldata = "";
		}
			
	
	} else {
		// no post, read ini
	
		$importXMLDataINI =& eZINI::instance( MODULE_INI_FILE,"extension/mymodule/settings" );
		$ImportParamIniSection = 'XMLImportDefaults';
		$parentnodeid	= $importXMLDataINI->variable( $ImportParamIniSection, 'ParentNodeID' );
		$xmlroot		= $importXMLDataINI->variable( $ImportParamIniSection, 'XMLRoot' );
		$barebones		= false; // need template to display form
		$settings 		= array(
				"remove" 		=> ($importXMLDataINI->variable( $ImportParamIniSection, 'Remove')		=="true"),
				"movetotrash" 	=> ($importXMLDataINI->variable( $ImportParamIniSection, 'MoveToTrash')	=="true"),
				"reportfields" 	=> ($importXMLDataINI->variable( $ImportParamIniSection, 'ReportFields')=="true"),
				"skipwhite" 	=> ($importXMLDataINI->variable( $ImportParamIniSection, 'SkipWhite')	=="true"),
				"testrun" 		=> ($importXMLDataINI->variable( $ImportParamIniSection, 'TestRun')		=="true")
		);
		$xmldata 		= "";
		
	}
	
			
	if (!$barebones) {

		$view = array( 
			'action'			=> $http->PostVariable( 'action' ), 
			'xmldata'			=> $xmldata,
			'parentnodeid'		=> $parentnodeid,
			'xmlroot'			=> $xmlroot,
			'barebones'			=> $barebones,
			'settings'			=> $settings
		);
		include_once( 'kernel/common/template.php' );
		$tpl =& templateInit();
		$tpl->setVariable( 'view', $view );
		
		$Result = array();
		$Result['content'] = $tpl->fetch( 'design:xmlimport/import.tpl' );
		$Result['path'] = array( 
							array( 'url' => $Module->Functions["menu"]["uri"],	'text' => $Module->Name ),
							array( 'url' => $Module->Functions["import"]["uri"],	'text' => 'import' )
						);
	} else {
	
		
		header("Content-type:text/plain");
		include_once( 'XMLImportfunctioncollection.php' );
		$importer = new XMLImportFunctionCollection();
		var_dump($importer->import($xmldata,$parentnodeid,$xmlroot,$settings));
		eZExecution::cleanExit();
	
	}
					
					
?>