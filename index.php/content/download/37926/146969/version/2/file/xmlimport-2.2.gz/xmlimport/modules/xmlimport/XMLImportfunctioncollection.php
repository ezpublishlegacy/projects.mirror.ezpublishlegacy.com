<?php
//
// Created on: <16-Feb-2005>
// Edited on: 20061029*pike 1.9
//
// Copyright (C) 2005-2004 Olivier Pierret & NSI-SA. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
/* 

	This is a rewrite of the ImportXMLData extension by "Olivier Pierret"
		
	In the xml, tagnames with prefix ezp_ are strictly prohibited.
	This thing requires XSL support in your php.
	If you need UTF-8 (yes you do), enable it in XPath.class.php
	
	This version contains a "bwc user hack", for backwards compatibility
	with ImportXMLData

	
	In the code below, the xml elements are refered to as  "list","item","field", etc
	The ezp objects are refered to as "node", "object", "attribute", etc
	
	
*/

/* pike todo:
	-	testrun
	v	skipwhite ?
	v 	multiple tags
	-  	import ezmatrix (col=x)
	v	import image
	v	import file
	v	import objectrelation
	
*/
	
//define( "MODULE_INI_FILE", "module.ini" );
	
include_once( 'kernel/classes/ezdatatype.php' );
include_once( 'kernel/classes/datatypes/ezimage/ezimage.php' );
include_once( 'kernel/classes/datatypes/ezauthor/ezauthor.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezsearch.php' );
include_once( 'lib/ezlocale/classes/ezdate.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( 'lib/ezutils/classes/ezmimetype.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'lib/ezutils/classes/ezdir.php' );
include_once( 'ezXMLTextConverter.php' );
//include_once( 'lib/phpxpath/XPath.class.php' );
include_once( 'XPath.class-nc.php' );

class XMLImportFunctionCollection {

	var $debug 		= true;
	var $use_ob 	= true;
	var $memmargin	= 524288; // 512 kB
	
	function XMLImportFunctionCollection() {
	}

	function &import( $xmldata, $parentnodeid, $xmlroot, $settings=false) 	{
		
		if ($this->use_ob)  ob_start();
		eZDebug::writeDebug(print_r(array_keys($GLOBALS),true), 'XMLImport' );
		
		// check settings 
		if (!$settings) $settings = array();
		$remove 		= $settings["remove"];
		$movetotrash 	= $settings["movetotrash"];
		$reportfields 	= $settings["reportfields"];
		$testrun 		= $settings["testrun"]; // unused
		$skipwhite 		= $settings["skipwhite"];
		
		// read types
		eZDataType::loadAndRegisterAllTypes();


		// fetch parent node
 		$parentnode =& eZContentObjectTreeNode::fetch($parentnodeid);
		if ( !is_object( $parentnode ) ) {
			$msg = "Import folder node id ($parentnodeid) doesn't seem to be a valid node id";
			eZDebug::writeDebug( $msg, 'XMLImport' );
			return array( 'result' => array('status' => "error", 'message' => $msg ));
		}
		$parentnodeid = $parentnode->attribute( 'node_id' );
		$parentobject =& $parentnode->attribute( 'object' );
		$sectionID = $parentobject->attribute( 'section_id' );
		
		// who are you ?
		$user =& eZUser::currentUser();
		$userID =& $user->attribute( 'contentobject_id' );

		// clean the folder if requested
		if ($remove) {
			$children =& $parentnode->subTree( array( 'Limitation' => array() ) );
			$deleteIDArray = array();
			foreach ($children as $child) {
				array_push ($deleteIDArray, $child->attribute( 'node_id' ));
			}
			eZContentObjectTreeNode::removeSubtrees( $deleteIDArray, $movetotrash );
			// free some mem
			unset($children);
		}

		// free some mem
		unset($parentnode);
		unset($parentobject);
		
		// calculate memmax. 
		$iml = ini_get("memory_limit"); // in human shorthand
		if (preg_match('/^([\d\.]+)([gmk])?$/i', $iml, $imlparts)) {
			$memmax = $imlparts[1];
			if (isset($imlparts[2])) {
				switch(strtolower($imlparts[2])) {
					case 'g': $memmax *= 1024; // fallthrough
					case 'm': $memmax *= 1024; // fallthrough
					case 'k': $memmax *= 1024; break;
					default: eZDebug::writeError("Can't parse ini value '$iml' ", 'XMLImport' );
				}
			}
			$memmax-=$this->memmargin;
			eZDebug::writeDebug('max memory set to '.$memmax, 'XMLImport' );
		 } else {
			eZDebug::writeError("Can't parse ini value '$iml' ", 'XMLImport' );
		 }
 
		// start gathering result
		$result = array();
		$result["status"] 	= "started";
		$result['data']		= array(); 
		$result['keys']= array("ezp_cid","ezp_oid","ezp_nid","ezp_err","ezp_msg");
		
	
		// start parsing. find all paths //$listtag/$itemtag
		$xPath = new XPath();
		$xPath->setXmlOption(XML_OPTION_SKIP_WHITE, ($skipwhite)?1:0);
		$xPath->importFromString($xmldata);
		
		// free some mem
		unset($xmldata);
		$nodepaths = $xPath->match("$xmlroot/*");
		foreach ($nodepaths as $nodepath) {
	

			$this->importNode($result,$xPath,$nodepath,$parentnodeid,$sectionID,$userID,$reportfields,$testrun);
			
			//print serialize($vars);
			//ob_flush();flush();
			
			if (memory_get_usage()>=$memmax) {
				print "Reaching memory limit $memmax (".memory_get_usage()."). Stopping import! Sorry!";
				break;
			}

		} // next item
		
		$result["status"] 	= "finished";
		if ($this->use_ob) {
			$result["message"] 	= ob_get_contents();
			ob_end_clean();
		} else $result["message"] = "";
		
		eZDebug::writeDebug(print_r(array_keys($GLOBALS),true), 'XMLImport' );
		
		return array( 'result' => &$result);
		
	}
	
	function importNode(&$result,&$xPath,$nodepath,$parentnodeid,$sectionID,$userID,$reportfields,$testrun) {

		eZDebug::writeDebug("node path: $nodepath", 'XMLImport' );
			
		$objresult = array("ezp_cid"=>"","ezp_oid"=>0,"ezp_nid"=>0,"ezp_err"=>0,"ezp_msg"=>"");
		
		// fetch class
		$classid = $xPath->nodeName($nodepath);
		$class =& eZContentClass::fetchByIdentifier( $classid );
		if ( !is_object( $class ) ) {
			eZDebug::writeDebug( "'$classid' doesn't seem to be a valid class identifier", 'XMLImport' );
			return false;
		}
	
		
		//create a new object for this item
		$contentObject =& $class->instantiate( $userID, $sectionID );

		//assign new object to parent node
		$nodeAssignment =& eZNodeAssignment::create( array(
				 'contentobject_id' => $contentObject->attribute( 'id' ),
				 'contentobject_version' => $contentObject->attribute( 'current_version' ),
				 'parent_node' => $parentnodeid,
				 'is_main' => 1 ));
		$nodeAssignment->store();


		// Set a status for the content object version
		$contentObjectVersion =& $contentObject->version($contentObject->attribute( 'current_version' ) );
		$contentObjectVersion->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT);
		$contentObjectVersion->store();
		
		// remember the attributes for this content class
		$attributes =& $contentObjectVersion->contentObjectAttributes();
				
				
		//$xPath->setVerbose(false);
		
		// continue parsing. find all fields in this item
		$fieldpaths = $xPath->match("$nodepath/*");
		foreach($fieldpaths as $fieldpath) {
		
			eZDebug::writeDebug("field path: $fieldpath", 'XMLImport' );
			$fieldname = $xPath->nodeName($fieldpath);
			
			if ($fieldname=="account-login") { // the users bwc hack ...
				$this->createUser(
					$contentObject->attribute('id'),
					$xPath->wholeText("$nodepath/account-login[1]"),
					$xPath->wholeText("$nodepath/account-email[1]"),
					$xPath->wholeText("$nodepath/account-password[1]")
				);
			
			} else {
				
				
				if ($reportfields) {
					$fieldvalue = $xPath->getData("$fieldpath");
					eZDebug::writeDebug("field value: $fieldvalue", 'XMLImport' );
					if (!in_array($fieldname,$result["keys"])) $result["keys"][]=$fieldname;
					$shortfieldvalue = substr($fieldvalue,0,64);
					if ($shortfieldvalue!=$fieldvalue)$shortfieldvalue.="...";
					if (isset($objresult["$fieldname"])) $sep = ";";
					else { $objresult["$fieldname"] = "";$sep = ""; }
					$objresult["$fieldname"].="$sep$shortfieldvalue";
				}
				
				
				// search for the attribute matching this field, and set it
				$foundattr = false;
				foreach ($attributes as $attribute) {
					
					// Each attribute has an attribute called 'identifier' that identifies it, doh
					if ($fieldname == $attribute->attribute("contentclass_attribute_identifier")) {
						$foundattr = true;
						$data_type_string = $attribute->attribute('data_type_string');
						$success = false; $message = "";
						switch( $data_type_string ) {
						
							// note: when adding support for new datatypes, we now have
							// $nodepath , $classid, $fieldpath, $fieldname  
							
							// ---------- standard datatypes ----------  //
							
							case "ezauthor":
																
								$success = $this->setAuthors($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezbinaryfile":

								$success = $this->setBinaryFile($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezboolean":
								$success = $this->setBoolean($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezdate":
								$success = $this->setDate($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezdatetime":
								$success = $this->setDateTime($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezemail":
								$success = $this->setTextAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezenum":
								$success = $this->setEnum($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezfloat":
								$success = $this->setFloatAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezidentifier":
								$success = $this->setIdentifier($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezimage":
								$success = $this->setImage($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezinisetting":
								$success = $this->setIniSetting($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezinteger":
								$success = $this->setIntegerAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezisbn":
								$success = $this->setTextAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezkeyword":
								$success = $this->setKeyword($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezmatrix":
							
								$success = $this->setMatrix($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezmedia":
								$success = $this->setMedia($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezmultioption":
								$success = $this->setMultiOption($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezobjectrelation":
								$success = $this->setObjectRelation($attribute,$xPath,$fieldpath,$message);
								break;

							case "ezobjectrelationbrowse":
								$success = $this->setObjectRelationBrowse($attribute,$xPath,$fieldpath,$message);
								break;
															
							case "ezobjectrelationlist":
								$success = $this->setObjectRelationList($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezoption":
								$success = $this->setOption($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezpackage":
								$success = $this->setPackage($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezprice":
								$success = $this->setFloatAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezrangeoption":
								$success = $this->setRangeOption($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezselection":
								$success = $this->setSelection($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezstring":
								$success = $this->setTextAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezsubtreesubscription":
								$success = $this->setSubTreeSubscription($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "eztext":
								$success = $this->setTextAttribute($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "eztime":
								$success = $this->setTime($attribute,$xPath,$fieldpath,$message);
								break;
							
							case "ezurl":	
								$success = $this->setURL($attribute,$xPath,$fieldpath,$message);
								break;
								
							case "ezuser":	
								$success = $this->setUser($attribute,$xPath,$fieldpath,$message);
								break;
								
							case "ezxmltext":	
								$success = $this->setXMLText($attribute,$xPath,$fieldpath,$message);
								break;
								
								
							// ---------- default ----------  //
							
							default :
							
								$success = false;
								eZDebug::writeError( "Datatype \"$data_type_string\" not supported", 'XMLImport' );
								$message = "Datatype \"$data_type_string\" not supported";
						
						}
						
						
							
						if ($success) $attribute->store(); // catch errors ?
						else $objresult["ezp_err"]++;
						if ($message) $objresult["ezp_msg"] .= "$message;\n";
						
						break; // we found the attribute matching the field, stop looping.
					
					} // end if

				} // next attribute
				
				if (!$foundattr) {
					$succes = false;
					eZDebug::writeError( "Class \"$classid\" has no attribute named \"$fieldname\"", 'XMLImport' );
					$objresult["ezp_msg"] .= "Class \"$classid\" has no attribute named \"$fieldname\";\n";
					$objresult["ezp_err"]++;
				}
				
			} //bwc users hack
			
			eZDebug::writeDebug( $data_type_string." ".$fieldname."\t: ".memory_get_usage(),"XMLImportfunctioncollection::import");

		} // next field path
		
		// $xPath->setVerbose(true);
		

		//publish the newly created node
		eZDebug::writeDebug( "pre publish\t: ".memory_get_usage(),"XMLImportfunctioncollection::import");
		$operationResult = eZOperationHandler::execute( 'content',
														'publish', array( 'object_id' => $contentObject->attribute( 'id' ),
														'version' => $contentObject->attribute( 'current_version' ) ) );
		eZDebug::writeDebug( 'execute content publish: '.$operationResult['status'], 'XMLImport' );
		eZDebug::writeDebug( "post publish\t: ".memory_get_usage(),"XMLImportfunctioncollection::import");
		
		// store the results
		$objresult["ezp_cid"]=$classid;//identifier; string
		$objresult["ezp_oid"]=$contentObject->attribute( 'id' );
		$objresult["ezp_nid"]=$contentObject->attribute( 'main_node_id' );
		$result['data'][] = $objresult; 
		$objresult = array("ezp_cid"=>"","ezp_oid"=>0,"ezp_nid"=>0,"ezp_err"=>0,"ezp_msg"=>"");
		

		// .. and forget about everything.
		unset($class);
		unset($contentObject);
		unset($nodeAssignment);
		unset($contentObjectVersion);
		unset($attributes);
		
		// this doesnt help
		// http://ez.no/community/forum/developer/memory_leak_on_content_publish

		eZContentObject::clearCache();
		eZDebug::writeDebug( "post clear cache \t: ".memory_get_usage(),"XMLImportfunctioncollection::import");
		
		return true;
	
	}
	
	/* -------------
		additional tools
	-------------- */
		
	function findUniqueObjectID(&$specs,&$message) {
		/*  
			This tries to do a 'unique find' where the result
			should match a number of requirements. It returns a
			single object ID. If there are more matches it uses
			the most recently published one.
			
			This can be extremely heavy if you use 'ordinary'
			attributes, where one requirement can have 100s of
			matches. The idea is to use one ore more functional
			attributes that together form a unique index, like
			author name and email, or a specially added "import id"
			
			specs looks like 
		
			$specs["ezp_cid"] = $classid;
			$specs[$attrname1] = $attrvalue1;
			$specs[$attrname2] = $attrvalue2;
		
			code taken from kernel/content/ezcontentfunctioncollection#fetchContentSearch
			which is the code for the search fetch as described on
			http://ez.no/doc/ez_publish/technical_manual/3_8/reference/modules/content/fetch_functions/search
			
		*/
		
		$classname = $specs["ezp_cid"];
		// search class id from name 
		$class =& eZContentClass::fetchByIdentifier( $classname );
		if ( !is_object( $class ) ) {
			$message = "'$classname' is not a valid class identifier";
			eZDebug::writeError( $message, 'XMLImport' );
			
			return 0;
		}
		$classid = $class->attribute("id");
		eZDebug::writeDebug( "'$classname' = Class $classid", 'XMLImport' );
		//remember the attributes of this class
		$attributes = $class->fetchAttributes();
		
		$objectids = array();
        foreach ($specs as $attrname=>$attrvalue) {
        	if ($attrname!="ezp_cid") {
 
				// search attribute id from name 
				$attrid=0;
				foreach ($attributes as $attribute) {
					if ($attribute->attribute("identifier")==$attrname) {
						$attrid = $attribute->attribute("id");
						break;
					}
				}
				eZDebug::writeDebug( "'$classname.$attrname' = Attribute $attrid", 'XMLImport' );
				if ( $attrid==0 ) {
					$message = "Class '$classname' has no attribute named '$attrname'";
					eZDebug::writeError( $message, 'XMLImport' );
					
					return 0;
				}
				
				// search for object of this class with value in that attribute
				$searchArray =& eZSearch::buildSearchArray();
				$parameters = array();
				if ($classid) $parameters['SearchContentClassID'] = $classid; 
				$parameters['SearchContentClassAttributeID'] = $attrid;//numeric?
				$parameters['SortArray'] = array("published",false);
				eZDebug::writeDebug( 'searching for '.$attrvalue, 'XMLImport' );
				$searchResult = eZSearch::search( $attrvalue, $parameters, $searchArray );
				$resnodes = $searchResult['SearchResult'];
				
				// diff on all results arrays until 1 option left
				if (count($resnodes)) {
					eZDebug::writeDebug( count($resnodes).' results for this spec', 'XMLImport' );
					if (count($objectids)) {
						// use existing results as an exclude on new results 
						eZDebug::writeDebug( 'filtering previous results', 'XMLImport' );
						$newobjectids = array();
						for ($rnc=0;$rnc<count($resnodes) && count($newobjectids) < count($objectids); $rnc++) {
							if (in_array($resnodes[$rnc]->attribute("contentobject_id"),$objectids)) {
								$newobjectids[] = $resnodes[$rnc]->attribute("contentobject_id");
							}
						}
						$objectids = $newobjectids;
					} else {
						// all results are new and valid
						eZDebug::writeDebug( 'no previous results; all are fine', 'XMLImport' );
						for ($rnc=0;$rnc<count($resnodes);$rnc++) {
							$objectids[] = $resnodes[$rnc]->attribute("contentobject_id");
						}
					}
				} else {
					// no results for this spec; 
					// no matching objects, exit loop
					eZDebug::writeDebug( 'no results for this spec; no match ', 'XMLImport' );
					$objectids = array();
					break;
				}
			}
		}
		
        if (count($objectids)) {
        	if (count($objectids)>1) {
				$message = "Found ".count($objectids)." results for  '".implode($specs,",")."': using most recent";
				eZDebug::writeDebug( $message, 'XMLImport' );
			} else {
				eZDebug::writeDebug( "Found related object id ".$objectids[0], 'XMLImport' );
			}
        	return $objectids[0];
        } else {
        	$message = "Can't find related nodes with specs '".implode($specs,",")."'";
        	eZDebug::writeError( $message, 'XMLImport' );
        	
        	return 0;
        }
	}
	
	function createUser($contentobjectid,$login,$email,$pass,&$message) {
		
		if ($contentobjectid>0) {
			$user =& new eZUser( $contentobjectid ); // catch error ?

			$user->setAttribute('login', $login );
			$user->setAttribute('email', $email );

			$hashType = eZUser::hashType() . "";
			$newHash = $user->createHash( $login, $password, eZUser::site(), $hashType );

			$user->setAttribute( "password_hash_type", $hashType );
			$user->setAttribute( "password_hash", $newHash );

			$user->store();
			
			return true;
			
		} else {
		
			eZDebug::writeError("error: invalid \$contentobjectid : $contentobjectid","XMLImport");
			$message = "invalid \$contentobjectid : $contentobjectid";
			return false;
			
		}
	}
	
	/* -------------
		attribute datatype setters
	-------------- */
	
	
	// generic datatypes //
	
		
	function setTextAttribute(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$attribute->setAttribute("data_text",$string);
		return true;
	}
	


	function setFloatAttribute(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$attribute->setAttribute("data_float",floatval($string));
		return true;
	}
	
	function setIntegerAttribute(&$attribute,&$xPath,$fieldpath,$message) {
		$string = $xPath->getData($fieldpath);
		$attribute->setAttribute("data_int",intval($string)); // catch errors ?
		return true;
	}		
	
	// specific datatypes //
	
	function setAuthors(&$attribute,&$xPath,$fieldpath,&$message) {
		
		//<article>
		//	<*editors>
		//		<author>
		//			<name>pike</name>
		//			<email>pike@kw.nl</email>
		//		</author>
		//		<author>
		//			<email>john@ez.no</email>
		//			<name>john</name>
		//		</author>
		//	</editors>
		//</article>
		
		$authors = array();
		$rowpaths = $xPath->match("$fieldpath/author");
		if (!count($rowpaths)) {
			// no <authors>, just one author
			$rowpaths = array($fieldpath); 
		}
		for($rowidx=0;$rowidx<count($rowpaths);$rowidx++) {
			$rowpath = $rowpaths[$rowidx];
			$authors[$rowidx] = array();
			if (@$xPath->getNodePath("$rowpath/name[1]")) {
				$authors[$rowidx]["name"]	= $xPath->wholeText("$rowpath/name[1]");
			
				if (@$xPath->getNodePath("$rowpath/email[1]")) {
					$authors[$rowidx]["email"]	= $xPath->wholeText("$rowpath/email[1]");
				}
			} else {
				// no <name> and <email>, just the name
				$authors[$rowidx]["name"]	= $xPath->wholeText("$rowpath");
				$authors[$rowidx]["email"] = "";
			}
			
		}

		// internally in ezp, authors is stored as xml again
		// kernel/classes/datatypes/ezauthor says
		// <authors>
		//		<author id="bla" name="bla" email="bla"/>
		//		<author id="bla" name="bla" email="bla"/>
		// </authors>
		// apparently, name is required, email is not
		// email is removed if invalid
		
		
		$xml ="<authors>\n";
		for ($ac=0;$ac<count($authors);$ac++) {
			if (!$authors[$ac]["name"]) {
				if (!$authors[$ac]["email"]) {
					$message .= "setAuthors: missing author name and email $ac\n";
					next;
				} else {
					$authors[$ac]["name"]=$authors[$ac]["email"];
				}
			}
			if (!eZMail::validate( $authors[$ac]["email"] )) {
				$message .= "setAuthors: invalid email $ac\n";
				$authors[$ac]["email"] = "";
			}
			$xml .= "\t<author id=\"$ac\" name=\"".$authors[$ac]["name"]."\" ";
			$xml .= "email=\"".$authors[$ac]["email"]."\" />\n";
		}
		$xml .= "</authors>";
		
		$author = new eZAuthor();
		$author->decodeXML($xml);
		$attribute->setAttribute( "data_text", $author->xmlString() );
		return true;
		
	}
	
	function setBinaryFile(&$attribute,&$xPath,$fieldpath,&$message) {
		
		// partial code from 
		// http://ez.no/community/forum/developer/creating_a_simple_content_object_via_php/
		//			re_creating_a_simple_content_object_via_php__13
		

		$url = $xPath->getData($fieldpath);;
		
		$chunksize = 8192; // how many bytes per chunk 
		$orgdir = "/original"; // subdir of storagedir
		
		eZDebug::writeDebug( "setBinaryFile: downloading $url", 'XMLImport' );

		// try to download the file. chunk it because 
		// it may be too big to fit in mem
		
		
		$ini = &eZINI::instance();
		$sys = &eZSys::instance();
		
		$storage_dir 	= $sys->rootDir().$sys->storageDirectory();
		$tempdir 		= $storage_dir.$ini->variable( 'FileSettings', 'TemporaryDir' );
		if ( !file_exists( $tempdir ) ) eZDir::mkdir( $tempdir, 0777, true);
		$temppath = tempnam($tempdir, "xmlimport-");
		$temphandle = fopen($temppath,"w");
		if ($temphandle === false) { 
			$message = "setBinaryFile: could not open tempfile '$temppath' for writing";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		}
		
		$buffer = ''; 
		$urlhandle = fopen($url, 'rb'); 
		if ($urlhandle === false) { 
			$message = "setBinaryFile: could not open url '$url' for reading";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		} 
		while (!feof($urlhandle)) { 
		 	fwrite($temphandle, fread($urlhandle, $chunksize)); 
		} 
		fclose($urlhandle);
		fclose($temphandle);
		eZDebug::writeDebug( "setBinaryFile: downloaded $url:".filesize($temppath), 'XMLImport' );
		
		// get file name, ext
		$urlarr = parse_url($url);
		$orgname = basename($urlarr["path"]);
		$ext = array_pop( explode( '.', $orgname) );
		
		// get mime, orgdir
		$mimeObj = new eZMimeType();
		$mime = $mimeObj->mimeTypeFor( false, $orgname );
		list( $subdir, $dummy )= split ("/", $mime );
		
		// get destination
		
		$dstdir = $storage_dir . $orgdir . "/" . $subdir;
		if ( !file_exists( $dstdir ) ) eZDir::mkdir( $dstdir, 0777, true); // catch ?
		
		//$uniquePath = tempnam( $dstdir, "xmlimport-");
		//$uniquePath .= '.'.$ext;
		//unlink( $uniquePath );
		//$separator = ( substr( php_uname(), 0, 7 ) == "Windows" )?'\\':'/';
		//$uniquePathArray = explode( $separator, $uniquePath );
		//$uniquename = $uniquePathArray[ count( $uniquePathArray ) - 1 ];
		//$targetpath = $dstdir."/".$uniquename;
		$targetpath = tempnam( $dstdir, "xmlimport-");
		$targetpath .= '.'.$ext;
		$targetname = basename($targetpath);
		
		// move the tempfile to its destination
		if (!rename($temppath, $targetpath )) {
			$message = "setBinaryFile: could not move temp file '$temppath' to target '$targetpath'";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		
		}
		eZDebug::writeDebug( "setBinaryFile: moved '$temppath' to '$targetpath'", 'XMLImport' );
		
		// all happy. create the attribute
		$file =& eZBinaryFile::create( $attribute->attribute( "id" ) , $attribute->attribute( "version" ) ); 
		$file->setAttribute( "contentobject_attribute_id", $attribute->attribute( "id" ) ); 
		$file->setAttribute( "version", $attribute->attribute( "version" ) ); 
		$file->setAttribute( "filename", $targetname ); 
		$file->setAttribute( "original_filename", $orgname ); 
		$file->setAttribute( "mime_type", $mime );
		$file->store();
		
		eZDebug::writeDebug( "setBinaryFile: attribute created" , 'XMLImport' );
	

		return true;
		
	}
	
	function setBoolean(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		if ($string == "true" || $string == "1") $attribute->setAttribute("data_int",1);
		else $attribute->setAttribute("data_int",0);
		return true;
	}
	
	function setDate(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$date = new eZDate(strtotime($string));//catch error?
		$attribute->setAttribute("data_int",$date->timeStamp());
		return true;
	}
	
	function setDateTime(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$date = new eZDateTime(strtotime($string));//catch error?
		$attribute->setAttribute("data_int",$date->timeStamp());
		return true;
	}
	

	function setEnum(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$message = "setEnum: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setIdentifier(&$attribute,&$xPath,$fieldpath,&$message) {
		//$string = $xPath->getData($fieldpath);
		$message = "Attributetype 'ezidentifier' will be generated, and should not be set.";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setImage(&$attribute,&$xPath,$fieldpath,&$message) {
	
		// partial code from uploadmultiplefiles extension
		// by Patrizio Bekerle (patrizio@bekerle.com)
		// www.bekerle.com
		
		//	<magazine>
		//		<preview_image>
		//			<url>http:www.basename.com/joy.gif</url>
		//			<caption>JOY</caption>
		//		</preview_image>
		//		<preview_image2>
		//			http:www.basename.com/joy.gif
		//		</preview_image2>
		//	</magazine>
		
		$chunksize = 8192; // how many bytes per chunk 
		$imagedir = "/original/image"; // subdir of storagedir

		//$xPath->setVerbose(false); 
		if (count($xPath->match("$fieldpath/url[1]"))) {
			$url = $xPath->wholeText("$fieldpath/url[1]");
			if (count($xPath->match("$fieldpath/caption[1]"))) {
				$caption = $xPath->wholeText("$fieldpath/caption[1]");
			} else $caption = "";
		} else {
			$url = $xPath->getData("$fieldpath");
		}
		
		eZDebug::writeDebug( "setImage: downloading $url", 'XMLImport' );

		// try to download the file. chunk it because 
		// it may be too big to fit in mem
		
		
		$ini = &eZINI::instance();
		$sys = &eZSys::instance();
		
		$storage_dir 	= $sys->rootDir().$sys->storageDirectory();
		$tempdir 		= $storage_dir.$ini->variable( 'FileSettings', 'TemporaryDir' );
		if ( !file_exists( $tempdir ) ) eZDir::mkdir( $tempdir, 0777, true);
		$temppath = tempnam($tempdir, "xmlimport-");
		$temphandle = fopen($temppath,"w");
		if ($temphandle === false) { 
			$message = "setImage: could not open tempfile '$temppath' for writing";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		}
		
		$buffer = ''; 
		$urlhandle = fopen($url, 'rb'); 
		if ($urlhandle === false) { 
			$message = "setImage: could not open url '$url' for reading";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		} 
		while (!feof($urlhandle)) { 
		 	fwrite($temphandle, fread($urlhandle, $chunksize)); 
		} 
		fclose($urlhandle);
		fclose($temphandle);
		eZDebug::writeDebug( "setImage: downloaded $url:".filesize($temppath), 'XMLImport' );
		
		// get file name, ext
		$urlarr = parse_url($url);
		$orgname = basename($urlarr["path"]);
		$ext = array_pop( explode( '.', $orgname) );
		
		// get mime
		$mimeObj = new eZMimeType();
		$mime = $mimeObj->mimeTypeFor( false, $orgname );
		
		// get destination
		
		$dstdir = $storage_dir . $imagedir;
		if ( !file_exists( $dstdir ) ) eZDir::mkdir( $dstdir, 0777, true);
		
		//$uniquePath = tempnam( $dstdir, "xmlimport-");
		//$uniquePath .= '.'.$ext;
		//unlink( $uniquePath );
		//$separator = ( substr( php_uname(), 0, 7 ) == "Windows" )?'\\':'/';
		//$uniquePathArray = explode( $separator, $uniquePath );
		//$uniquename = $uniquePathArray[ count( $uniquePathArray ) - 1 ];
		//$targetpath = $dstdir."/".$uniquename;
		$targetpath = tempnam( $dstdir, "xmlimport-");
		$targetpath .= '.'.$ext;
		$targetname = basename($targetpath);
				
		// move the tempfile to its destination
		if (!rename($temppath, $targetpath )) {
			$message = "setImage: could not move temp file '$temppath' to target '$targetpath'";
			eZDebug::writeDebug( $message, 'XMLImport' );
			return false; 
		
		}
		eZDebug::writeDebug( "setImage: moved '$temppath' to '$targetpath'", 'XMLImport' );
		
		// all happy. create the attribute
		$image =& eZImage::create( $attribute->attribute( "id" ) , $attribute->attribute( "version" ) );
		$image->setAttribute( "contentobject_attribute_id", $attribute->attribute( "id" ) );
		$image->setAttribute( "version", $attribute->attribute( "version" ) );
		$image->setAttribute( "filename", $targetname );
		$image->setAttribute( "original_filename", $orgname );
		$image->setAttribute( "mime_type", $mime );
		$image->setAttribute( "alternative_text", $caption );
		$image->store();
	
		eZDebug::writeDebug( "setImage: attribute created" , 'XMLImport' );
	

		return true;
	}
	
	function setIniSetting(&$attribute,&$xPath,$fieldpath,&$message) {		
		$message = "setIniSetting: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}

	
	function setKeyword(&$attribute,&$xPath,$fieldpath,&$message) {	
		$message = "setKeyword: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setMatrix(&$attribute,&$xPath,$fieldpath,&$message) {	
		
		$message = "setMatrix: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;

		// matrix be a nested xmltree. tagnames match col id's.
		// <editors>
		//		<row>
		//			<nick_name>pike</nick_name>
		//			<email>pike@kw.nl</email>
		//		</row>
		//		<row>
		//			<email>john@ez.no</email>
		//			<nick_name>john</nick_name>
		//		</row>
		// </editors>
		
		/*
			$matrix = array();
			$rowpaths = $xPath->match("$fieldpath/row");
			for($rowidx=0;$rowidx<count($rowpaths);$rowidx++) {
				$rowpath = $rowpaths[$rowidx];
				if ($xPath->hasChildNodes($rowpath)) {
					$matrix[$rowidx] = array();
					$cellpaths = $xPath->match("$rowpath/*");
					foreach($cellpaths as $cellpath) {
						$colid = $xPath->nodeName("$cellpath");
						$cellvalue = $xPath->wholeText("$cellpath");
						$matrix[$rowidx][$colid] = $cellvalue;
					}
				} 
			}
		*/
							
	}
	
	function setMedia(&$attribute,&$xPath,$fieldpath,&$message) {	
		$message = "setMedia: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setMultiOption(&$attribute,&$xPath,$fieldpath,&$message) {	
		$message = "setMultiOption: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setObjectRelation(&$attribute,&$xPath,$fieldpath,&$message) {	
		// untested
		// @ http://ez.no/community/forum/developer/add_object_relation_attribute_type_within_a_php_script

		// ezobjectrelationlist be a nested xmltree. tagnames match attrname's
		// will perform a search for a unique matching object.
		//
		// <editor>
		//		<person>
		//			<nick_name>pike</nick_name>
		//			<email>pike@kw.nl</email>
		//		</person>
		// </editor>
		//
		//  $requirements["ezp_cid"] 	= "editor"
		//  $requirements["nickname"] 	= "pike"
		//  $requirements["email"] 		= "pike@kw.nl"
	
		// see which class the rel object should be 
		$relnodepath = $xPath->match("$fieldpath/*[1]");
		$relclassname = $xPath->nodeName("$relnodepath");
		$requirements = array("ezp_cid"=>$relclassname);
		
		// see which fields should have which values
		$relattrpaths = $xPath->match("$relnodepath/*");
		foreach($relattrpaths as $relattrpath) {
			$relattrname = $xPath->nodeName("$relattrpath");
			$relattrvalue = $xPath->getData("$relattrpath");
			$requirements[$relattrname]= "$relattrvalue";
		}
		
		// search for such a node and relate it
		$reloid = $this->findUniqueObjectID($requirements,$message);
		if ($reloid) {
			$attribute->setAttribute( 'data_int', $reloid );
			return true;
		} else {
			return false;
		}
	}
	
	function setObjectRelationBrowse(&$attribute,&$xPath,$fieldpath,&$message) {
		// @ http://ez.no/community/forum/developer/add_object_relation_attribute_type_within_a_php_script
	
		// ezobjectrelationbrowse be a nested xmltree. tagnames match attrname's
		// will perform a search for a matching object.
		//
		// <editors>
		//		<translator>
		//			<nick_name>pike</nick_name>
		//			<email>pike@kw.nl</email>
		//		</translator>
		//		<author>
		//			<email>john@ez.no</email>
		//			<nick_name>john</nick_name>
		//		</author>
		// </editors>
		//
		//  $requirements["ezp_cid"] 	= "translator"
		//  $requirements["nickname"] 	= "pike"
		//  $requirements["email"] 		= "pike@kw.nl"
		// and 
		//  $requirements["ezp_cid"] 	= "author"
		//  $requirements["email"] 		= "john@ez.no"
		//  $requirements["nickname"] 	= "john"
	
		$success=true;		
		$relnodepaths = $xPath->match("$fieldpath/*");
		for ($rnc=0;$rnc<count($relnodepaths); $rnc++) {
			
			// see which class the rel object should be 
			$relnodepath = $relnodepaths[$rnc];
			$relclassname = $xPath->nodeName("$relnodepath");
			$requirements = array("ezp_cid"=>$relclassname);
			
			// see which fields should have which values
			$relattrpaths = $xPath->match("$relnodepath/*");
			foreach($relattrpaths as $relattrpath) {
				$relattrname = $xPath->nodeName("$relattrpath");
				$relattrvalue = $xPath->getData("$relattrpath");
				$requirements[$relattrname]= "$relattrvalue";
			}
			
			// search for such a node and relate it
			$reloid = $this->findUniqueObjectID($requirements,$message);
			if ($reloid) {
			
				eZDebug::writeDebug( "appendObjectRelationBrowse $relobjectid", 'XMLImport' );
				$content = $attribute->content(); 

				//if (!$content['relation_list']) $content['relation_list'] = array();
				$priority = count($content['relation_browse'])*10;  
				$content['relation_browse'][] = eZObjectRelationBrowseType::appendObject($reloid, $priority, $attribute );    
				$attribute->setContent( $content );   

				eZDebug::writeDebug( "appendObjectRelationBrowse: storing relation", 'XMLImport' );
				$attribute->store(); // catch errors ?

			} else {
				$success=false;
			}

		}
		return $success;
	}
	
	function setObjectRelationList(&$attribute,&$xPath,$fieldpath,&$message) {
		// ezobjectrelationlist be a nested xmltree. tagnames match attrname's
		// will perform a search for unique matching objects.
		//
		// <editors>
		//		<translator>
		//			<nick_name>pike</nick_name>
		//			<email>pike@kw.nl</email>
		//		</translator>
		//		<author>
		//			<email>john@ez.no</email>
		//			<nick_name>john</nick_name>
		//		</author>
		// </editors>
		//
		//  $requirements["ezp_cid"] 	= "translator"
		//  $requirements["nickname"] 	= "pike"
		//  $requirements["email"] 		= "pike@kw.nl"
		// and 
		//  $requirements["ezp_cid"] 	= "author"
		//  $requirements["email"] 		= "john@ez.no"
		//  $requirements["nickname"] 	= "john"
	
		$success=true; //optimist

		$relnodepaths = $xPath->match("$fieldpath/*");
		for ($rnc=0;$rnc<count($relnodepaths); $rnc++) {
			
			// see which class the rel object should be 
			$relnodepath = $relnodepaths[$rnc];
			$relclassname = $xPath->nodeName("$relnodepath");
			$requirements = array("ezp_cid"=>$relclassname);
			
			// see which fields should have which values
			$relattrpaths = $xPath->match("$relnodepath/*");
			foreach($relattrpaths as $relattrpath) {
				$relattrname = $xPath->nodeName("$relattrpath");
				$relattrvalue = $xPath->getData("$relattrpath");
				$requirements[$relattrname]= "$relattrvalue";
			}
			
			// search for such a node and relate it
			$reloid = $this->findUniqueObjectID($requirements,$message);
			if ($reloid) {
					
				// append
				// @ http://ez.no/community/forum/developer/add_object_relation_attribute_type_within_a_php_script

				eZDebug::writeDebug( "appendObjectRelationList $relobjectid", 'XMLImport' );
				$content = $attribute->content(); 
			
				//if (!$content['relation_list']) $content['relation_list'] = array();
				$priority = count($content['relation_list'])*10;  
				$content['relation_list'][] = eZObjectRelationListType::appendObject($reloid, $priority, $attribute );    
				$attribute->setContent( $content );   
		
				eZDebug::writeDebug( "appendObjectRelationList: storing relation", 'XMLImport' );
				$attribute->store(); // catch errors ?


			} else {
				$success = false;
			}
			
		}

		return $success;
	
	}
	
	function setOption(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setOption: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setPackage(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setPackage: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setRangeOption(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setRangeOption: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setSelection(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setSelection: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setSubTreeSubscription(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setSubTreeSubscription: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setTime(&$attribute,&$xPath,$fieldpath,&$message) {
		$message = "setTime: not implemented";
		eZDebug::writeDebug( $message, 'XMLImport' );
		return false;
	}
	
	function setURL(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$urlID =& eZURL::registerURL( $string ); // ? catch error 
		$attribute->setAttribute( 'data_text', $string );
		// store ezurl id in data_int
		eZDebug::writeDebug( "\$urlID = $urlID", 'XMLImport' );
		$attribute->setAttribute( 'data_int', $urlID );
		return true;
	}
	
	function setUser(&$attribute,&$xPath,$fieldpath,&$message) {
	
		// new ezuser should be a nested xmltree:
		// <groupie>
		//		<nick_name>pike</nickname>
		//		<user_account>
		//			<login>pike67</login>
		//			<email>....</email>
		//			<password>....</password>
		//		</user_account>
		// </groupie>
		
		// apparently, you dont have to set the attribute ?
		// there can only  be one user attribute per object ?

		return $this->createUser(
			$contentObject->attribute('id'),
			$xPath->wholeText("$fieldpath/login[1]"),
			$xPath->wholeText("$fieldpath/email[1]"),
			$xPath->wholeText("$fieldpath/password[1]"),
			$message
		);
					
	}
	
	function setXMLText(&$attribute,&$xPath,$fieldpath,&$message) {
		$string = $xPath->getData($fieldpath);
		$dummy = "";
		$converter = new ezXMLTextConverter( $dummy, $attribute ); // catch error ?
		$converter->validateText( $string, $attribute ); // catch error ?
		$attribute->SetAttribute( 'data_int', EZ_XMLTEXT_VERSION_TIMESTAMP );
		return true;
	}

	
}
?>