<?php
/*
[ExtensionSettings]
DesignExtensions[]=xmlimport
*/
?>