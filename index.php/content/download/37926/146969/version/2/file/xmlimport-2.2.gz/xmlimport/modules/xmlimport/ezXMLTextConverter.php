<?php

/* pike 200607, stolen from
	http://ez.no/products/ez_publish/documentation/development/importing_attribute_data
*/

include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );

class ezXMLTextConverter extends eZSimplifiedXMLInput
{
	function ezXMLTextConverter( &$xmlData, $contentObjectAttribute )
	{
		$this->eZSimplifiedXMLInput( $xmlData, 0, $contentObjectAttribute );
	}

 	function &validateText( &$data, &$contentObjectAttribute )
	{
		$contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
		// Below is same as in the function validateInput(...) in class eZSimplifiedXMLInput
		eZDebug::writeDebug($data, "input data");
		// Set original input to a global variable
		$originalInput = "originalInput_" . $contentObjectAttributeID;
		$GLOBALS[$originalInput] = $data;

		// Set input valid true to a global variable
		$isInputValid = "isInputValid_" . $contentObjectAttributeID;
		$GLOBALS[$isInputValid] = true;

		$inputData = "<section xmlns:image='http://ez.no/namespaces/ezpublish3/image/' xmlns:xhtml='http://ez.no/namespaces/ezpublish3/xhtml/'>";
		$inputData .= "<paragraph>";
		$inputData .= $data;
		$inputData .= "</paragraph>";
		$inputData .= "</section>";

		$data =& $this->convertInput( $inputData );
		$message = $data[1];
		if ( $this->IsInputValid == false )
		{
			$GLOBALS[$isInputValid] = false;
			$errorMessage = null;
			foreach ( $message as $line )
			{
				$errorMessage .= $line .";";
			}
			$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
																$errorMessage,
																'ezXMLTextType' ) );
			return EZ_INPUT_VALIDATOR_STATE_INVALID;
		}
		else
		{
			$dom = $data[0];
			$objects =& $dom->elementsByName( 'object' );
			if ( $objects !== null )
			{
				foreach ( array_keys( $objects ) as $objectKey )
				{
					$object =& $objects[$objectKey];
					$objectID = $object->attributeValue( 'id' );
					$currentObject =& eZContentObject::fetch( $objectID );
					$editVersion = $contentObjectAttribute->attribute('version');
					$editObjectID = $contentObjectAttribute->attribute('contentobject_id');
					$editObject =& eZContentObject::fetch( $editObjectID );
					if ( $currentObject == null )
					{
						$GLOBALS[$isInputValid] = false;
						$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
								'Object '. $objectID .' does not exist.', 'ezXMLTextType' ) );
						return EZ_INPUT_VALIDATOR_STATE_INVALID;
					}
					else
					{
						$relatedObjects =& $editObject->relatedContentObjectArray( $editVersion );
						$relatedObjectIDArray = array();
						foreach ( $relatedObjects as $relatedObject )
						{
							$relatedObjectID = $relatedObject->attribute( 'id' );
							$relatedObjectIDArray[] = $relatedObjectID;
						}
						if ( !in_array( $objectID, $relatedObjectIDArray ) )
						{
							$editObject->addContentObjectRelation( $objectID, $editVersion );
						}
					}

					// If there are any image object with links.
					$href = $object->attributeValueNS( 'ezurl_href',
								'http://ez.no/namespaces/ezpublish3/image/' );
					$urlID = $object->attributeValueNS( 'ezurl_id',
								'http://ez.no/namespaces/ezpublish3/image/' );

					if ( $href != null )
					{
						$linkID =& eZURL::registerURL( $href );
						$object->appendAttribute( $dom->createAttributeNodeNS(
								'http://ez.no/namespaces/ezpublish3/image/', 'image:ezurl_id', $linkID ) );
						$object->removeNamedAttribute( 'ezurl_href' );
					}

					if ( $urlID != null )
					{
						$url =& eZURL::url( $urlID );
						if ( $url == null )
						{
							$GLOBALS[$isInputValid] = false;
							$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
									'Link '. $urlID .' does not exist.', 'ezXMLTextType' ) );
							return EZ_INPUT_VALIDATOR_STATE_INVALID;
						}
					}
				}
			}
			$links =& $dom->elementsByName( 'link' );

			if ( $links !== null )
			{
				foreach ( array_keys( $links ) as $linkKey )
				{
					$link =& $links[$linkKey];
					if ( $link->attributeValue( 'id' ) != null )
					{
						$linkID = $link->attributeValue( 'id' );
						$url =& eZURL::url( $linkID );
						if ( $url == null )
						{
							$GLOBALS[$isInputValid] = false;
							$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
									'Link '. $linkID .' does not exist.', 'ezXMLTextType' ) );
							return EZ_INPUT_VALIDATOR_STATE_INVALID;
						}
					}
					if ( $link->attributeValue( 'href' ) != null )
					{
						$url = $link->attributeValue( 'href' );
						$linkID =& eZURL::registerURL( $url );
						$link->appendAttribute( $dom->createAttributeNode( 'id', $linkID ) );
						$link->removeNamedAttribute( 'href' );
					}
				}
			}

			$domString = $dom->toString();

eZDebug::writeDebug($domString, "unprocessed xml");
$domString = preg_replace( "#<paragraph> </paragraph>#", "<paragraph> </paragraph>", $domString );
$domString = str_replace ( "<paragraph />" , "", $domString );
$domString = str_replace ( "<line />" , "", $domString );
$domString = str_replace ( "<paragraph></paragraph>" , "", $domString );
//$domString = preg_replace( "#>[W]+<#", "><", $domString );
$domString = preg_replace( "#<paragraph> </paragraph>#", "<paragraph />", $domString );
$domString = preg_replace( "#<paragraph></paragraph>#", "", $domString );

$domString = preg_replace( "#[
]+#", "", $domString );
$domString = preg_replace( "#</LINE>#", "
", $domString );
$domString = preg_replace( "#<PARAGRAPH>#", "

", $domString );
eZDebug::writeDebug($domString, "domstring");

			$xml = new eZXML();
			$tmpDom =& $xml->domTree( $domString, array( 'CharsetConversion' => false ) );
//				$domString = $tmpDom->toString();
			$domString = eZXMLTextType::domString( $tmpDom );

			eZDebug::writeDebug($domString, "stored xml");
			$contentObjectAttribute->setAttribute( "data_text", $domString );
			$contentObjectAttribute->setValidationLog( $message );

			$paragraphs = $tmpDom->elementsByName( 'paragraph' );

			$classAttribute =& $contentObjectAttribute->contentClassAttribute();
			if ( $classAttribute->attribute( "is_required" ) == true )
			{
				if ( count( $paragraphs ) == 0 )
					return EZ_INPUT_VALIDATOR_STATE_INVALID;
				else
					return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
			}
			else
				return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
		}
		return EZ_INPUT_VALIDATOR_STATE_INVALID;
	}
}

?>