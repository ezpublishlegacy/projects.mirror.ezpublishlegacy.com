<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=jvlogout/logout

[UserSettings]
LogoutRedirect=/jvlogout/logout
RedirectOnLogoutWithLastAccessURI=disabled

*/