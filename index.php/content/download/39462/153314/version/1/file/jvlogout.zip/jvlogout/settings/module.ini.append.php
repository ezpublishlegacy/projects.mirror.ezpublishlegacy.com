<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=jvlogout
ModuleList[]=jvlogout

*/ ?>