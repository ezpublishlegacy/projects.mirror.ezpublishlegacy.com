[TemplateSettings]
ExtensionAutoloadPath[]=collectexport

[RegionalSettings]
TranslationExtensions[]=collectexport


