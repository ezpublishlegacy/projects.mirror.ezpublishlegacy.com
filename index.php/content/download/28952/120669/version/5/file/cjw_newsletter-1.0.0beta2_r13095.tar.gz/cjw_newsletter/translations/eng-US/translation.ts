<!DOCTYPE TS><TS>
<context>
    <name>cjw_newsletter</name>
    <message>
        <source>Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/blacklist_item_add</name>
    <message>
        <source>Edit &lt;%mailbox.email&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a new Blacklist item </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklist add item</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfully adding newsletter user %nl_user_id with email %email to blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfully adding email address %email to blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklist add</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/blacklist_item_list</name>
    <message>
        <source>Add an email to blacklist</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Create a new blacklist entry.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklist items [%children_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select items for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklist item list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Blacklist overview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>If you want that a user with a special email do not get any newsletter from this newsletter system you can blacklist him!</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Manage blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By adding an user to the blacklist, you can make sure that he will never get a newsletter again from this system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add email address to blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter UID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklists</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_edition_preview</name>
    <message>
        <source>Do you really want to send out this newsletter to all recipients of this Newsletterlist?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_edition_send_statistic</name>
    <message>
        <source>Current Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter Edition send out statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail not send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort cronjob</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emails count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emails sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emails opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emails not sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emails bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter processing info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cronjob status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_edition_status</name>
    <message>
        <source>Edition State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in the dispatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uncompletedly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter edition preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter edition preview archive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_list</name>
    <message>
        <source>Create newsletter here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter editions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current selection has no result.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_list_children</name>
    <message>
        <source>Up one level.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub items [%children_count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 10 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display sub items using a detailed list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current item does not contain any sub items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to remove any of the items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply changes to the priorities of the items in the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You cannot update the priorities because you do not have permission to edit the current item or because a non-priority sorting method is used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the type of item you want to create then click the &quot;Create here&quot; button. The item will be created in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the language you want to use for the creation then click the &quot;Create here&quot; button. The item will be created in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new item in the current location. Use the menu on the left to select the type of  item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to create new items in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You cannot set the sorting method for the current location because you do not have permission to edit the current item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use these controls to set the sorting method for the sub items of the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_list_children_list</name>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(disabled)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(locked)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the priority fields to control the order in which the items appear. You can use both positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not allowed to update the priorities because you do not have permission to edit &lt;%node_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The edition %child_name is already in sending process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to edit &quot;%child_name&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjw_newsletter_list_window_controls</name>
    <message>
        <source>Hide preview of content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show preview of content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide available translations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show available translations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide location overview.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show location overview.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide object relation overview.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show object relation overview.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjwnewsletteredition_preview</name>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archived</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/cjwnewsletteredition_preview_archive</name>
    <message>
        <source>Archive view</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/configure</name>
    <message>
        <source>Configure newsletter settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter confirmation successfull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No newsletters available for configure now.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salutation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can edit your attitutes for newsletter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select the newsletter for subscribe or unselect the newsletter for unsubsucribe.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can also edit the small boxes &quot;first name&quot; and &quot;last name&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can not edit your email address. Please, announce yourselves once more to newsletter to use another email address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>* mandatory fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Changes saved</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/contentstructuremenu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Archive</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Archived</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sending</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/datatype/cjwnewsletteredition</name>
    <message>
        <source>The current edition is already in sending process - to create a new version please stop it first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current edition is already in sending process - you have to create a new copy of this object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current edition was already send and is in archive!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/datatype/cjwnewsletterlist</name>
    <message>
        <source>Main Siteaccess must be set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to choose an output format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to set a valid email adress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to set a valid semder email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to set a valid semder email adress &gt;&gt; $reciever</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Render output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can subscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Available newsletter output formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve subscription after user registration?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter sender email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter sender name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter default test receiver email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter skin name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personalize newsletter if data are available?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter output formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show in siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main siteaccess site url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main siteaccess locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email sender name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email receiver test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personalize content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/datatype/cjwnewslettersubcription/validation_error</name>
    <message>
        <source>Datatype can not be used here - user_account required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No user account found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/datatype/cjwnewslettersubscription</name>
    <message>
        <source>No newsletters available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No newsletters available for configure now.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/datatypes</name>
    <message>
        <source>CJW Newsletter Edition</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CJW Newsletter List</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CJW Newsletter Subscription</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/design/admin/node/view/full</name>
    <message>
        <source>The edition %child_name is already in sending process.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/editionsenditem/status</name>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/import_list</name>
    <message>
        <source>Import overview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Here you find a list of all data imports!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import items [%children_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select items for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Imported subscription count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription count after import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved subscriptions in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage imports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imports</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/import_view</name>
    <message>
        <source>Import details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imported subscription count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imported user count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions created by import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n/a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Live count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Live count approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription count after import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved subscriptions in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Live count confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user count after import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed Newsletter user in current system with import id %importId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove %count_active_subscriptions active subscriptions by admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to set status removed by admin to all active subscriptions (%count_active_subscriptions)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imports</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/index</name>
    <message>
        <source>Structure</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>SYSTEM</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>SYSTEM is parent of LIST</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>LIST is parent of OUTPUT</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>OUTPUT is parent of SEND OUTPUT</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter SYSTEM</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter LIST</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>OUTPUT</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter Drafts</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Mails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create newsletter here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mail/subscription_confirmation</name>
    <message>
        <source>Hello %name

Thank you for subscribing to the following newsletter:
%subscriptionList

To activate or edit your subscription, please visit this link:

%configureLink
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mail/subscription_information</name>
    <message>
        <source>Hello %name

Thank you for using our newsletter.
To edit your newsletter settings please visit the following link:

%configureLink
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mailbox_edit</name>
    <message>
        <source>Edit &lt;%mailbox.email&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new Mailbox </source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deleted Mails from Server</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Activated</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Store Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add new mail account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete mails from server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mailbox_item_list</name>
    <message>
        <source>Mailbox collect mail result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collection result for mailbox %mailbox_id.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox item parse result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%parsed_mails_count mails parsed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collect all mails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parse mails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox items [%children_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MSize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bouncecode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IsBounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nl user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email send date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n/a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox item list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Mailbox item list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select mailbox item for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you will find all collected emails and you can try to dectect bounce mails.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Manage bounces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collect Emails from bounce accounts and parse them. You may then accept the detected bounce status or manually adjust it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mailbox_item_view</name>
    <message>
        <source>Mailbox Item Database Infos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LIVE mailbox item parse infos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raw mail content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show raw mail content inline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show inline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide raw mail content inline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide inline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox item list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox item view</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/mailbox_list</name>
    <message>
        <source>Mailbox list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Here you can set up mailboxes which will collect mails for bouncehandling.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>email</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>server</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>port</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>user</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>password</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>type</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>is_activated</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>is_ssl</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>delete_mails_from_server</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>last_server_connect</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n/a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit mailbox.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Mailbox</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add new mailbox.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage mail accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Define mail accounts that will collect mails for bounce handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add mail account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last connect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/menu</name>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Registration form</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>User list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Mailbox item list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Mailbox list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Blacklist</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Systems</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Import list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Administer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter systems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INI Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/newsletter_list_subscription</name>
    <message>
        <source>Import contact from CSV file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export to CSV file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/newsletter_menu</name>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/outputformat</name>
    <message>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/path</name>
    <message>
        <source>Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/preview</name>
    <message>
        <source>Newsletter preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview of the newsletter output formats in iframe?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email subject</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/send</name>
    <message>
        <source>Send Test Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Test Newsletter at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Result of the test sending of the newsletter</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subjekt</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Already in the sending process!</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Send Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Draft</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Archive</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter Details</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit Newsletter</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Send out Newsletter</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Send out Newsletter to this Users - Count:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter - Sent out Emails</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Sent out Emails</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Not Sent out Emails</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter Preview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email Receiver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter send objects</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter overview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Last ten actions</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Content Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send out newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test newsletter sent result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send test newsletter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/send.tpl</name>
    <message>
        <source>Do you really want to send out this newsletter?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/send_abort</name>
    <message>
        <source>Abort newsletter send out process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort send out process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send out process is finished, can not abort anymore!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send out process was already aborted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort successfull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort not successfull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort sent out process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/send_abort.tpl</name>
    <message>
        <source>Do you really want to abort the send out process?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/skin/default</name>
    <message>
        <source>unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To unsubscribe your newsletter please visit the following link</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>To unsubscribe from this newsletter please visit the following link</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe</name>
    <message>
        <source>Salutation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter subscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No newsletters available for subscribe.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can subscribe to one of our newsletters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please fill in the boxes &quot;first name&quot; and &quot;last name&quot; and enter your e-mail address in the corresponding field. Then, select the newsletter you are interested in and the format you prefer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data Protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your e-mail address will under no circumstances be passed on to unauthorized third parties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Further Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You want to %unsubscribelink or %changesubscribelink your profile?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>* mandatory fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscribe to newsletter</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscription form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe_info</name>
    <message>
        <source>Get subscribe information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe_infomail</name>
    <message>
        <source>Newsletter - Edit profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the e-mail address you originally used to subscribe and you will be sent a link to edit you data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>* mandatory fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please input a valid e-mail address!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe_infomail_success</name>
    <message>
        <source>Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail has been sent!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you are a valid newsletter user, an e-mail has been sent to you with all information required!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe_success</name>
    <message>
        <source>Newsletter - subscribe success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are registered for our newsletter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An email was sent to your address %email.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please note that your subscription is only active if you clicked confirmation link in these email.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have the possibility of changing your personal profile at any time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscribe_success_not</name>
    <message>
        <source>Newsletter - subscribe unsuccessfull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contact the system administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription</name>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must choose a list for subsription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter a first name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter a last name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must provide a valid email address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email is already used by an other newsletter user.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription/status</name>
    <message>
        <source>Pending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed by user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed by admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_confirmation</name>
    <message>
        <source>Subscription verification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_information</name>
    <message>
        <source>Subscription information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_list</name>
    <message>
        <source>Subscription list &lt;%subscription_list_name&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short description</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscriped user statistic</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Import CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriber list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n/a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List Subscription List</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>eZ ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NL user import id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create new Subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscribers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_list_csvexport</name>
    <message>
        <source>Subscription CSV export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV field delimiter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel subscription export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription list CSV export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_list_csvimport</name>
    <message>
        <source>Subscription list CSV import</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscription import with CSV</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First row is label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV field delimiter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Csv File Uploaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import   Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel subscription import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import subscriptions</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salutation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nl user created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created / modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription CSV import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imported items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV import</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/subscription_view</name>
    <message>
        <source>Newsletter subscription view</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscription Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputformat</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve subscription by admin</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove subscription by admin</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subscription successfully approved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription successfully removed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter Subscription view</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Newsletter subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove subscription</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/unsubscribe</name>
    <message>
        <source>Unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hi %name

        You unsubscribe successfully from List &quot;%listName&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscribe from list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscription already done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hi %name

        You already unsubscribed from List &quot;%listName&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscribe success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hi %name

If you want to unsubscribe from from List &quot;%listName&quot;
you have to confirm this page.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user/salutation</name>
    <message>
        <source>Mr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mrs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ms</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user/status</name>
    <message>
        <source>Pending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed by user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed by admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pending eZ User Register</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user_create</name>
    <message>
        <source>Create a new newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create and edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create new newsletter user</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user_edit</name>
    <message>
        <source>First name of newsletter user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name of newsletter user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit newsletter user</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Creating new newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit existing newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can not edit newsletter user because he is blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user_list</name>
    <message>
        <source>User list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>search</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit current subscription list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub items [%children_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ User</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter User Id</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Manage users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for existing user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ user id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user_remove</name>
    <message>
        <source>Remove newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cjw_newsletter/user_view</name>
    <message>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salutation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ez user</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklisted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data xml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription items [%subscription_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edition send items [%edition_send_item_count]</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Send item Id</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edition send id</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Outputformat</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Processed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add this user to blacklist</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ez user with id %ez_user_id does not exist anymore!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit by admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove from database</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Delete newsletter user and all subscriptions from database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ user id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edition sent id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="obsolete"></translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>View and manage (copy, delete, etc.) the versions of this object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Another language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to edit this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to  remove the selected items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 10 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up one level.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub items (%children_count)</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display sub items using a detailed list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current item does not contain any sub items.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to remove any of the items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move the selected items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to move any of the items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply changes to the priorities of the items in the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You cannot update the priorities because you do not have permission to edit the current item or because a non-priority sorting method is used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the type of item you want to create then click the &quot;Create here&quot; button. The item will be created in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the language you want to use for the creation then click the &quot;Create here&quot; button. The item will be created in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new item in the current location. Use the menu on the left to select the type of  item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to create new items in the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You cannot set the sorting method for the current location because you do not have permission to edit the current item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use these controls to set the sorting method for the sub items of the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List of sub items of current node, with controlls to edit, remove and move them directly.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>(disabled)</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>(locked)</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Use the priority fields to control the order in which the items appear. You can use both positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>You are not allowed to update the priorities because you do not have permission to edit &lt;%node_name&gt;.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to edit %child_name.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a copy of &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show preview of content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab is disabled, enable on dashboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show available translations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations (%count)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show location overview.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations (%count)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show object relation overview.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relations (%count)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/line</name>
    <message>
        <source>Click on the icon to get a context sensitive menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %node_visibility</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The same location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>CJW Newsletter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
