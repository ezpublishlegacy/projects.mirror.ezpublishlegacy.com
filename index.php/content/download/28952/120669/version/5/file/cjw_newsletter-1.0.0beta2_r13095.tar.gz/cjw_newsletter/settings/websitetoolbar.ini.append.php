<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=cjw_newsletter
IncludeInView[cjw_newsletter]=full

*/ ?>