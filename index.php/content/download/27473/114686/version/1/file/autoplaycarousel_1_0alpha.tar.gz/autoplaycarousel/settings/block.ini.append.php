<?php /*

[General]
AllowedTypes[]=AutoPlayCarousel

[AutoPlayCarousel]
Name=Auto Play Carousel
NumberOfValidItems=9
NumberOfArchivedItems=5
ManualAddingOfItems=disabled
FetchClass=eZFlowMCFetch
FetchParameters[Source]=NodeID
FetchParametersSelectionType[Source]=single
FetchParametersIsRequired[Source]=true
FetchParameters[Classes]=string
ViewList[]=autoplaycarousel1
ViewList[]=autoplaycarousel2
ViewList[]=autoplaycarousel3
ViewName[autoplaycarousel1]=Auto Play Carousel (1)
ViewName[autoplaycarousel2]=Auto Play Carousel (2)
ViewName[autoplaycarousel3]=Auto Play Carousel (3)


*/ ?>
