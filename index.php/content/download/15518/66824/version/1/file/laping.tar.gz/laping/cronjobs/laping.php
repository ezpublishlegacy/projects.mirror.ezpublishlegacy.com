<?php
include_once("extension/laping/lib/xmlrpc-2.2.2/lib/xmlrpc.inc");
include_once("lib/ezfile/classes/ezlog.php");


$oPing=new laPing();
$oPing->pingAll();


?>