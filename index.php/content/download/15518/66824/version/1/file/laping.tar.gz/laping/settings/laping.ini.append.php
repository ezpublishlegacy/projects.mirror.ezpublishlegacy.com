<?php /* #?ini charset="utf-8"?


[Configuration]
#List of server to ping
#support only XML RPC ping system
#will do other later
ServerList[]
ServerList[]=http://api.moreover.com/RPC2
ServerList[]=http://blogsearch.google.com/ping/RPC2
ServerList[]=http://ping.feedburner.com
ServerList[]=http://ping.syndic8.com/xmlrpc.php
ServerList[]=http://rpc.technorati.com/rpc/ping
ServerList[]=http://www.wasalive.com/ping/
ServerList[]=http://rpc.weblogs.com/RPC2
ServerList[]=http://rpc.pingomatic.com/
ServerList[]=http://pinger.blogflux.com/
ServerList[]=http://api.moreover.com/RPC2

#The ext will ping only when objects of specific class are publish 
IncludeClass[]
IncludeClass[]=recette_wordpress
IncludeClass[]=article

#Some class can use a specific date attribute
#if not, published date will be use   
[recette_wordpress]
dateAttribute=date_publication

*/ ?>