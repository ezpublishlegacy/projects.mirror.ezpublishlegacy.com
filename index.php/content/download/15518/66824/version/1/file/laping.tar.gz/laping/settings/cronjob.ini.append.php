<?php /*

[CronjobSettings]
ExtensionDirectories[]=laping

[CronjobPart-frequent]
Scripts[]=laping.php

*/ ?>
