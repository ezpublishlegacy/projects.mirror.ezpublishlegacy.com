<?php
class laPing{
	private $siteUrl;
	private $siteName;

	function laPing(){
		$ini = eZINI::instance( 'site.ini' );
		$this->siteName=$ini->variable( 'SiteSettings','SiteName' );
		$this->siteUrl="http://".$ini->variable( 'SiteSettings','SiteURL' );
	}

	function pingAll(){
		$db  = eZDB::instance();
		$laini = eZINI::instance( 'laping.ini' );
		$currenttime=time();

		/*check if we need to ping 
		we need to ping if new content is  publish and if the last ping wasn't made in the last 10 min
		*/	
		$arLastPing=$db->arrayQuery("select * from ezpending_actions where action='last_ping'");
		if(!isset($arLastPing[0])){
			/*first launch, create last ping time in ezpending*/
			$db->arrayQuery("insert into ezpending_actions set action='last_ping',param='".$currenttime."'");
		}elseif($currenttime-$arLastPing[0]['param'] > 600 ){
		 	$rootNode = eZContentObjectTreeNode::fetch( 2);
			$ClassList=$laini->variable( 'Configuration','IncludeClass' );	

			/*check if new content has been publish since last time*/
			foreach($ClassList as $class){
				/*modified date will be use if not other attribute date is set*/

				$attributeDate="published";
				if($laini->hasVariable($class,'dateAttribute')){
					$attributeDate=$laini->variable($class,'dateAttribute');
				}
				$nbUpdate = $rootNode->subTreeCount( array( 'ClassFilterType' => 'include',
                                                'ClassFilterArray' => array($class),
							'AttributeFilter'=> array(array($class."/".$attributeDate,'>',$arLastPing[0]['param']))
                                                ) );
				if ($nbUpdate>0)
					break;
			}
			if($nbUpdate>0)
				$db->arrayQuery("update ezpending_actions set param='".$currenttime."' where action='last_ping'");
			else
				return false;

		}else
			return false;


		$pathList=$laini->variable( 'Configuration','ServerList' );
		$return=array();
		foreach($pathList as $path){
			eZlog::write( "run","laping.log" );
			
			$arComp=parse_url($path);
			if($this->doPing($arComp['host'],$arComp['path'],$arComp['port'])==false){
				echo  $this->Error."\n";
				eZlog::write( $this->Error,"laping.log" );


			}
				
		}
		return true;

	}
	function doPing($server,$url,$port=80){
		
		
  		$rpcClient = new xmlrpc_client($url,$server, $port);
        	$message = new xmlrpcmsg("weblogUpdates.ping", 
		array( new xmlrpcval($this->siteName),
         		new xmlrpcval($this->siteUrl)));
		$result = $rpcClient->send($message,10);
		if (!$result ) 
		{
		     $this->Error= "Ping $server FAILED : Could not connect to HTTP server.\n";
			return false;
		}
		elseif ($result->faultCode())
		{
		   	$this->Error="Ping $server FAILED : " . $result->faultCode() . ": " .  $result->faultString()."\n";
			return false;
		}else{ 
		    	$this->Error="Ping $server return ". $result->value()->me['struct'][message]->me['string'] ."\n";
			return true;
		}

	}
	
}
?>