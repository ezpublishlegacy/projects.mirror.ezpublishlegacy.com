<?php
class laPingInfo
{
    function info()
    {
        return array( 'Name' => "Ping generator",
                      'Version' => "0.3",
                      'Copyright' => "Copyright (C) 2009 Lagardere Active France",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
