<?php /*
[RoleSettings]
PolicyOmitList[]=quickpay
*/ ?>
