<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 * This file is called by Quickpay when the customer submits his/hers card information to Quickpay
 */
$logger  = eZPaymentLogger::CreateForAdd('var/log/eZQuickpay_callback_url.log');
$checker = new eZQuickpayChecker( 'quickpay.ini' );
$module =& $Params["Module"];

if( $checker->createDataFromPOST() )
{
  unset ($_POST);
  if(  $checker->checkPaymentStatus() && $checker->requestValidation() )
  {
    $orderID = $checker->getFieldValue( 'ordernumber' );
    $orderID = $orderID;

    if( $checker->setupOrderAndPaymentObject( $orderID ) )
    {
      if ($checker->updateOrderInfo() )
      {
        $logger->writeTimedString( 'Order was not updated with information from quickpay, dumping: ', print_r($checkter->callbackData,1) );
      }

      $checker->approvePayment();
    }
  }
}
else
{
  $logger->writeTimedString( 'Could not create data from post, redirecting back to shop' );
  $module->redirectTo('shop/checkout');
}

$logger->writeTimedString( __FILE__.' done' );

?>
