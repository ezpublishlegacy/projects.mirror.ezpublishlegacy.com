<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */
define( "EZ_PAYMENT_GATEWAY_TYPE_QUICKPAY", "bc_ezquickpay" );

class eZQuickpayGateway extends eZRedirectGateway
{
  function __construct()
  {
    $this->logger = eZPaymentLogger::CreateForAdd( "var/log/eZQuickpayType.log" );
    $this->logger->writeTimedString( __CLASS__.'::'.__FUNCTION__ );
  }

  function createPaymentObject( $processID, $orderID )
  {
    $this->logger->writeTimedString("createPaymentObject");

    return eZPaymentObject::createNew( $processID, $orderID, 'Quickpay' );
  }

  function createRedirectionUrl( $process )
  {
    $url = '/quickpay/post'; // the post view on the modules redirects the customer to quickpays payment page
    eZURI::transformURI( $url, 'false', 'full' );
    return $url;
  }
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_QUICKPAY, "ezquickpaygateway", "Quickpay" );

?>
