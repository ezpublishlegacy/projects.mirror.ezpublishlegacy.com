<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */
class eZQuickpayChecker extends eZPaymentCallbackChecker
{
  private $qpstatText = array(
    "000" => "Godkendt",
    "001" => "Afvist af PBS",
    "002" => "Kommunikations fejl",
    "003" => "Kort udløbet",
    "004" => "Status er forkert (Ikke autoriseret)",
    "005" => "Autorisation er forældet",
    "006" => "Fejl hos PBS",
    "007" => "Fejl hos QuickPay",
    "008" => "Fejl i parameter sendt til QuickPay"
  );

  function __construct( $iniFile )
  {
    $this->eZPaymentCallbackChecker( $iniFile );
    $this->logger = eZPaymentLogger::CreateForAdd( 'var/log/eZQuickpayChecker.log' );    
  }

  function requestValidation()
  {
    $responseArray = $this->callbackData;
    unset( $responseArray['md5check'] );

    $response = implode('', $responseArray);
    $response .= $this->ini->variable( 'QuickpaySettings', 'Md5Word');
    $calculated = md5($response);

    if ( $calculated === $this->callbackData['md5check'] )
    {
      return true;
    }

    $this->logger->writeTimedString( 'requestValidation failed, md5sum did not match, calculated: "'. $calculated .'" recived: "'. $this->callbackData['md5check'] .'"' );
    return false;

  }

  function checkPaymentStatus()
  {
    if( $this->checkDataField( 'qpstat', '000' ) )
    {
      return true;
    }

    $this->logger->writeTimedString( 'checkPaymentStatus failed: "'. $this->callbackData['qpstatmsg'] .'"' );
    return false;
  }

  /**
   * Response recived from Quickpay is stored in the data_text_2 field on the order. 
   * To display this information on the order in the admin interface of eZ Publish you have to modify some templates
   *
   */
  function updateOrderInfo()
  {
    if ( $this->order instanceof eZOrder )
    {
      $extraOrderInfo = '';
      foreach ( $this->callbackData as $key => $value )
      {
        $extraOrderInfo .= $key .': '. $value ."\n";
      }

      $this->order->setAttribute('data_text_2', $extraOrderInfo);
      $this->order->store();
    }
    else
    {
      $this->logger->writeTimedString( 'updateOrderInfo failed, this->order is not an instance of eZOrder ' );
      return false;
    }
  }
}

?>
