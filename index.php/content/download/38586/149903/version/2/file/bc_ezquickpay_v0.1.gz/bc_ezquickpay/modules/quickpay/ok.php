<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */

// TODO: if there is no order redirect to another page
$module =& $Params["Module"];
$module->redirectTo('shop/checkout');

?>
