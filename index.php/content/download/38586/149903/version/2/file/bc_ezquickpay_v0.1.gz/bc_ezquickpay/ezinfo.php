<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */
class ezquickpayInfo
{
    function info()
    {
        return array( 'Name' => "eZ Quickpay Payment Gateway",
                      'Version' => '0.1',
                      'Copyright' => "Copyright (C) 2010 Bellcom Open Source ApS",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
