<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 * This generates the form that is submitted to Quickpay
 */

$http = eZHTTPTool::instance();
$orderID = $http->sessionVariable( 'MyTemporaryOrderID' );
$order = eZOrder::fetch( $orderID );
$module =& $Params["Module"];

if ( $order instanceof eZOrder )
{
  if ( $order->attribute( 'is_temporary' ) )
  {
    $total = $order->totalIncVAT();
    $locale = eZLocale::instance();
    $ini = eZINI::instance('quickpay.ini');

    /* firstly format number and shorten any extra decimal places */
    /* Note this will round off the number pre-format $str if you don't want this functionality */
    $str =  number_format( $total, 2, '.', '');    // will return 12345.67
    $number = explode( '.', $str );
    $number[1] = ( isset( $number[1] ) )?$number[1]:''; // to fix the PHP Notice error if str does not contain a decimal placing.
    $decimal = str_pad( $number[1], 2, 0);
    $total =  $number[0].$decimal;

    $protocol          = '3';
    $msgtype           = 'authorize';
    $merchant_id       = $ini->variable( 'QuickpaySettings', 'MerchantID');
    $quickpay_language = substr( $locale->httpLocaleCode(), 0, 2 );
    $qp_order_id       = $orderID;
    $order_amount      = $total;
    $currency_code     = $order->currencyCode();
    $ok_page           = '/quickpay/ok';
    $error_page        = '/quickpay/error';
    $result_page       = '/quickpay/callback';
    $autocapture       = '0';
    $cardtypelock      = $ini->variable( 'QuickpaySettings', 'CardtypeLock');
    $testmode          = $ini->variable( 'QuickpaySettings', 'TestMode');
    $md5word           = $ini->variable( 'QuickpaySettings', 'Md5Word');

    eZURI::transformURI( $ok_page, 'false', 'full' );
    eZURI::transformURI( $error_page, 'false', 'full' );
    eZURI::transformURI( $result_page, 'false', 'full' );

    $md5check = md5($protocol.$msgtype.$merchant_id.$quickpay_language.$qp_order_id.$order_amount.$currency_code.$ok_page.$error_page.$result_page.$autocapture.$cardtypelock.$testmode.$md5word);

    // Todo: this should be a template
echo '<html>
<head>
<title>Videresender til Quickpay betalingsside</title>
</head>
<body onload="return document.quickpay_payment_info.submit();">
<form action="https://secure.quickpay.dk/form/" method="post" id="quickpay_payment_info" name="quickpay_payment_info">
<input type="hidden" name="protocol" value="'. $protocol .'"/>
<input type="hidden" name="msgtype" value="'. $msgtype .'"/>
<input type="hidden" name="merchant" value="'. $merchant_id .'"/>
<input type="hidden" name="language" value="'. $quickpay_language .'"/>
<input type="hidden" name="ordernumber" value="'. $qp_order_id .'"/>
<input type="hidden" name="amount" value="'. $order_amount .'"/>
<input type="hidden" name="currency" value="'. $currency_code .'"/>
<input type="hidden" name="continueurl" value="'. $ok_page .'"/>
<input type="hidden" name="cancelurl" value="'. $error_page .'"/>
<input type="hidden" name="callbackurl" value="'. $result_page .'"/>
<input type="hidden" name="autocapture" value="'. $autocapture .'"/>
<input type="hidden" name="cardtypelock" value="'. $cardtypelock .'"/>
<input type="hidden" name="testmode" value="'. $testmode .'"/>
<input type="hidden" name="md5check" value="'. $md5check .'"/>
<input type="submit" value="Fortsæt til betaling" />
</form>
Vent venligst mens betalingssiden forberedes...
</body>
</html>';

      eZExecution::cleanExit();
    }
}
else
{
  $module->redirectTo('shop/checkout');
}


?>
