<?php /*
[ExtensionSettings] 
DesignExtensions[]=bc_ezquickpay
 */ ?>
