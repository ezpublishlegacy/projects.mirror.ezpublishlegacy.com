<?php /*
[ModuleSettings]
ExtensionRepositories[]=bc_ezquickpay
ModuleList[]=quickpay
*/ ?>
