<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */

require_once 'kernel/common/template.php';
$tpl = templateInit();

$Result = array();
$Result['content'] = $tpl->fetch( "design:error.tpl" );

?>
