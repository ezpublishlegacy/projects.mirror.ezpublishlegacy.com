<?php
/**
 *
 * @author Henrik Farre <hf@bellcom.dk>
 * @copyright Copyright (C) 2010, Bellcom Open Source Aps
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU Public License version 2
 *
 */
$Module = array( "name" => "eZQuickpay" );

$ViewList = array();
$ViewList["callback"] = array( "script" => "callback_url.php" );
$ViewList["post"]     = array( "script" => "post.php" );
$ViewList["ok"]       = array( "script" => "ok.php" );
$ViewList["error"]    = array( "script" => "error.php" );
?>
