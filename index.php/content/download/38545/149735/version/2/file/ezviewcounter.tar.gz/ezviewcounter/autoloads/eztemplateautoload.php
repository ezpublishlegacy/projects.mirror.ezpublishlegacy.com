<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezviewcounter/autoloads/ezviewcounteroperator.php',
                                    'class' => 'eZViewCounterOperator',
                                    'operator_names' => array( 'ezviewcounter' ) );
?>
