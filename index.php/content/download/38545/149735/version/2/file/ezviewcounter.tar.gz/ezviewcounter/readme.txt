eZViewCounter

Written by:
Lukasz Serwatka <ls_at_ez.no>

Installation
------------
1. Extract the ezviewcounter.tar.gz in your eZ publish 3 extension directory. 

2. Activate the extension. 
   Either in adminitration interface:
     Go to "Setup"
     Go to "Extensions"
     Check the checkbox beside "ezviewcounter"
     Click "Activate"
   OR in ini-files:
     Add the following to your settings/override/site.ini.append.php file
     [ExtensionSettings]
     ActiveExtensions[]=ezviewcounter

Usage
-----

{ezviewcounter( 12, true() )} this operator updates and return view count for node with ID 12.

The available parameters are:
node_id: 
  The node_id is ID of node for view count we want to display.
  This parameter is required.
 
update:
  Update view counter?
  Default value: flase


Note
----

For templates viewed by {$module_result.content} you have to disable ViewCache by adding in first line of template code {set-block scope=root variable=cache_ttl}0{/set-block}
With disabled ViewCache in site.ini.append.php you can use {cache-block} for whole template code except for {ezviewcounter( )}

{cache-block}
// template code
{/cache-block}

View count is: {ezviewcounter( )}

{cache-block}
// template code
{/cache-block}