<?php

include_once( 'lib/ezdb/classes/ezdb.php' );

class eZViewCounterOperator
{
    /*!
      Constructor
    */
    function eZViewCounterOperator()
    {
		$this->db =& eZDB::instance();
	}

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'ezviewcounter' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    
	/*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'ezviewcounter' => array( 'node_id' => array( 'type' => 'integer',
                                                                      'required' => true,
                                                                      'default' => 0 ),
												'update' => array( 'type' => 'boolean',
                                                                      'required' => false,
                                                                      'default' => false ) )
					);
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $node_id = $namedParameters['node_id'];
		$update = $namedParameters['update'];

        switch ( $operatorName )
        {
            case 'ezviewcounter':
            {
                $operatorValue = $this->ezViewCounter( $node_id, $update );
            } break;
        }
    }
	/*!
     Update and return view count
    */
	function ezViewCounter( $node_id, $update )
	{
		if( $update == true )
		{
			if( !isset( $_COOKIE['unique'] ) || $_COOKIE['unique'] != $node_id )
			{
				setcookie( 'unique', $node_id, time()+3600 );
					
				$row =& $this->db->arrayQuery( "SELECT count FROM ezview_counter WHERE node_id='" . (int)$node_id . "'" );
		
				if( !$row  )
				{
					$this->db->query( "INSERT INTO ezview_counter ( count, node_id ) VALUES ( '1', '" . (int)$node_id . "' )" );
				}
				else
				{
					$this->db->query( "UPDATE ezview_counter SET count=count+1 WHERE node_id='" . (int)$node_id . "'" );
				}				
			}
				
		}
		
		$row =& $this->db->arrayQuery( "SELECT count FROM ezview_counter WHERE node_id='" . (int)$node_id . "'" );
		
		if( !$row )
		{
			return 0;
		}
		else
		{
			return $row[0]['count'];
		}
	}
	
	var $db;
}
?>