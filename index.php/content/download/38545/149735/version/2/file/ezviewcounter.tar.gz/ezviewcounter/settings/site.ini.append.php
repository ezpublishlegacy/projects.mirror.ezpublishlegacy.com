<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezviewcounter

*/ ?>