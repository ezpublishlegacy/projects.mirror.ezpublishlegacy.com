<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=tn3gallerylite

[JavaScriptSettings]
FrontendJavaScriptList[]=jquery.min.js
FrontendJavaScriptList[]=jquery.tn3lite.min.js





[StylesheetSettings]
CSSFileList[]=tn3.css
FrontendCSSFileList[]=tn3.css

*/
?>
