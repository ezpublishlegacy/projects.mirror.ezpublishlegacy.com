<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=tn3gallerylite

[ExtensionSettings]
ActiveExtensions[]=tn3gallerylite

[RegionalSettings]
TranslationExtensions[]=tn3gallerylite

*/?>