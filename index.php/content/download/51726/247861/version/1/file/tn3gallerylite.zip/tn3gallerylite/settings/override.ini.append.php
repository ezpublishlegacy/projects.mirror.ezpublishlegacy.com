<?php /* #?ini charset="utf-8"?

[embed_tn3gallerylite]
Source=content/view/embed.tpl
MatchFile=embed/tn3gallerylite.tpl
Subdir=templates
Match[class_identifier]=tn3gallerylite



*/ ?>