<?php
$Module = array( "name" => "sydesy" );

$ViewList = array();
$ViewList["browse"] = array( "script" => "browse.php",
                             "params" => array ('objectid'),  
                            "unordered_params" => array( "groupid" => "GroupID" ) );

$ViewList["set"] = array( 
               "script" => "set.php",
               "params" => array ('objectid','ownerid'),  
               ); 
?>
