<?php
/* 
Two usages : 
1) objectid and ownerid as post params (from browse)
 2) /owner/set/{objectid}/{ownerid} (can't resist when Gabriel wants something ;)
*/

include_once( 'kernel/common/template.php' );

function error ($message)
{
  // how do I display an error message ?
  die ($message);
}

$tpl =& templateInit();
$http =& eZHTTPTool::instance();
$objectid=null;
$ownerid=null;

if ($http->hasPostVariable("SelectButton")) {
// usage 1)
  $objectid = $http->variable('objectid');
  $ownerid = $http->variable('ownerid');
}
else
// usage 2)
{
  if (isset ($Params['Parameters'][0]) && isset ($Params['Parameters'][1]))
  {
    $objectid=$Params['Parameters'][0];
    $ownerid=$Params['Parameters'][1];
  }
  else
    error ("syntax: /owner/set/{objectid}/{ownerid}");
}

$db =& eZDB::instance();
$db->query( "UPDATE ezcontentobject SET owner_id='$ownerid' WHERE id='$objectid'" );


$tpl->setVariable('objectid',$objectid);
$tpl->setVariable('ownerid',$ownerid);

$Result = array();
$Result['content'] = $tpl->fetch( "design:owner/set.tpl" );
$Result['path'] = array( array( 'url_alias' => '/owner/set',
                                'text' => "change the owner") );

// FIX: url_alias isn't displayed properly
?>
