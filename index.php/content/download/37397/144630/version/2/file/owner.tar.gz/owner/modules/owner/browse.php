<?php
// Module return value,
// normally fetched from template

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$tpl = & templateInit();
$http = & eZHTTPTool::instance();

eZDebug::writeWarning($http);
foreach ($Params[UserParameters] as $param => $value) 
    $tpl->setVariable( $param, $value );
//check if we were called as owner/browse/nodeid
if (isset ($Params['Parameters'][0])) 
{
    $tpl->setVariable('nodeid',$Params['Parameters'][0]);
}
//check if we got it as a NodeID variable as post parameter.
else if ($http->hasVariable('NodeID') )
{
    $tpl->setVariable('nodeid', $http->variable('NodeID'));
}

$Result = array();
$Result['content'] = $tpl->fetch( "design:owner/browse.tpl" );

$Result['path'] = array( array( 'url_alias' => '/owner/browse',
                                'text' => "select an owner") );

// FIX: url_alias isn't displayed properly
?>
