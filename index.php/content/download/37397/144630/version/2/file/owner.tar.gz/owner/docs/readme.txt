Owner
---------------------------

/*
    owner extension for eZ publish 3.x
    Copyright (C) 2005  Sydesy ltd

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    Gabriel Ambuehl specifically grants BSDL rights to his part of the code.

*/

Introduction
------------
this extension allows to change the owner of an object

1. Grant access to this extension
---------------------------------
Obviously, you don't want everyone to be able to access to this function.

Go to the admin part and modify the rules: you have to grant owner * * to the group(s) you want to be able to access this extension.

I'd suggest you to grant it only to the admins, but do whatever you want, that's your site after all ;)

2. Straight forward use: Context Menu in admin
----------------------------------------------
Right click on the node you want to change and hit "Change Owner". Doesn't
get any easier, really.

3. Browse
-----------

The url /owner/browse/<nodeid> allows to choose a new owner for the object


4. Direct setting of the owner
-------------------------------
The url /owner/set/<objectid>/<ownerobjectid> set the owner of the object

You have to provide the id of the object (not the node id) and the id of the object owner.

If you don't know the difference between the objectid and the nodeid, please don't use this method, use the browse method described above.

5. Known bugs and limitations
-----------------------------

* The url isn't properly displayed (cosmetic problem)
* The existing owner isn't checked by default when browsing (checked="checked" is set but without any result).
* User gets redirected to frontend site which causes troubles (doesn't seem to actually work) with set function

Both these bugs are probably very stupid mistakes on my side. Please ashame me and tell me how to fix them.
 
6. TO DO and possible evolutions
--------------------------------
Well, it does what we need so far, but if you have a nice idea we might implement it... and be more than happy to add your patches ;). 


Fix the bugs creeping here and there and proof read the doc and comments on the code.


6. Disclaimer & Copyright
-------------------------
/*
    Owner for eZ publish 3.x
    Copyright (C) 2005  Sydesy ltd

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
This extension is tailored to fit our needs, and is shared with the community as is.

Thanks for your attention

Xavier DUTOIT
