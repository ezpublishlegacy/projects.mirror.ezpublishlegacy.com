
[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/ownercontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/ownersubitemscontextmenu.tpl

