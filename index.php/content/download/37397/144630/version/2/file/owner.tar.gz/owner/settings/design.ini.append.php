<?php
/*
[ExtensionSettings]
DesignExtensions[]=owner
*/
?>
