var dir_f22ae342685db2a55da996d10a47cfe8 =
[
    [ "initialize.php", "rest_2initialize_8php.html", null ]
];