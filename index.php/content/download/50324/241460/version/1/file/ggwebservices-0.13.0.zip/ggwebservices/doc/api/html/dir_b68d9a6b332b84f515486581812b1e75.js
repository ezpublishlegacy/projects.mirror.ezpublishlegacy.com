var dir_b68d9a6b332b84f515486581812b1e75 =
[
    [ "initialize.php", "jsonrpc_2initialize_8php.html", null ]
];