var dir_70fefc226727fb5a312ef4b175bbb569 =
[
    [ "action.php", "action_8php.html", null ],
    [ "common.php", "modules_2webservices_2debugger_2common_8php.html", "modules_2webservices_2debugger_2common_8php" ],
    [ "controller.php", "controller_8php.html", "controller_8php" ],
    [ "frame.php", "frame_8php.html", "frame_8php" ],
    [ "visualeditor.php", "visualeditor_8php.html", "visualeditor_8php" ]
];