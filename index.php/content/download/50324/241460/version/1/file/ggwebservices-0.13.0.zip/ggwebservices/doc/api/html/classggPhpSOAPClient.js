var classggPhpSOAPClient =
[
    [ "__construct", "classggPhpSOAPClient.html#a38ac9f5c92e884fda5f49a6f8f00bd39", null ],
    [ "_send", "classggPhpSOAPClient.html#a995d15f0102cd8ea92298a77fb1a3c73", null ],
    [ "send", "classggPhpSOAPClient.html#a2530e6ab5844e74f199e4d8f8f0319cd", null ],
    [ "setOption", "classggPhpSOAPClient.html#a60fb17544fb84faf933c3ffde41dd722", null ],
    [ "setSoapVersion", "classggPhpSOAPClient.html#aad67d0b455b2d50cb80bec6a442e164c", null ],
    [ "toArray", "classggPhpSOAPClient.html#acb2f022b2d0b52df4fe09de08393d459", null ],
    [ "$CacheWSDL", "classggPhpSOAPClient.html#a962e72499e50ed13d2a65668837c71d1", null ],
    [ "$ResponseClass", "classggPhpSOAPClient.html#a5ca57238595c34c34861d9006325ba8e", null ],
    [ "$returnArrays", "classggPhpSOAPClient.html#a9f8435a6f16d60e5905a474506baaa76", null ],
    [ "$SoapVersion", "classggPhpSOAPClient.html#ae9a8fcaf1a95b85115f155a753147aa8", null ],
    [ "$UserAgent", "classggPhpSOAPClient.html#a6d461a7ccff648b521a597a028579751", null ],
    [ "$Wsdl", "classggPhpSOAPClient.html#a352004f8750a737f797ee0332438a0d7", null ]
];