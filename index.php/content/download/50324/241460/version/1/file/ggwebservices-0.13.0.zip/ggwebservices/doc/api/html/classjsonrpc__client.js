var classjsonrpc__client =
[
    [ "$no_multicall", "classjsonrpc__client.html#a280b07247f1ae23db58c7982d9a16095", null ],
    [ "$return_type", "classjsonrpc__client.html#afea8af99e687de069a872947a9fcb86c", null ]
];