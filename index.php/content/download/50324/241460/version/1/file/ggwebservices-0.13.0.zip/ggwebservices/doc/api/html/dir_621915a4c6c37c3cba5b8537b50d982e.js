var dir_621915a4c6c37c3cba5b8537b50d982e =
[
    [ "wsproviders.ini.append.php", "twitter__client_2wsproviders_8ini_8append_8php.html", null ]
];