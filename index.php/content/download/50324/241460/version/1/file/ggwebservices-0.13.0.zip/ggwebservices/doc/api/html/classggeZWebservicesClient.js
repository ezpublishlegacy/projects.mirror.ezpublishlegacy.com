var classggeZWebservicesClient =
[
    [ "_call", "classggeZWebservicesClient.html#aa520897e7b8551259a75cf2e970d696d", null ],
    [ "call", "classggeZWebservicesClient.html#ac4270d11ccd362a49f00f2f481948ae3", null ],
    [ "send", "classggeZWebservicesClient.html#a11e28c9945207209886a51bbc5210e45", null ]
];