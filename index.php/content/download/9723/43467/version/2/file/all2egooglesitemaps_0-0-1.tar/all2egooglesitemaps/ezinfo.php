<?php
class all2eGoogleSitemapsInfo
{
    function info()
    {
        return array( 'Name' => "Google Sitemaps generator",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 all2e GmbH",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
