<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=qhjsiniloader

[ezjscServer_qhjsiniloader]
Class=qhJSINILoaderServerFunctions
Functions[]=qhjsiniloader
File=extension/qhjsiniloader/classes/qhjsiniloaderserverfunctions.php

*/ ?>
