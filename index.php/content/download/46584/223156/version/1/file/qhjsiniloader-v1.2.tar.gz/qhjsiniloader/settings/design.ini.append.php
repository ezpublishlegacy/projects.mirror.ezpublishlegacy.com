<?php /*

[ExtensionSettings]
DesignExtensions[]=qhjsiniloader

[JavaScriptSettings]
FrontendJavaScriptList[]=qhjsiniloader.js
BackendJavaScriptList[]=qhjsiniloader.js

*/ ?>
