<?php /* #?ini charset="iso-8859-1"?

[Keys]
# Visit http://recaptcha.net/api/getkey to signup and get your own API keys
PublicKey=Enter your Public Key here
PrivateKey=Enter your Private Key here

[Display]
# Possible themes 'red' | 'white' | 'blackglass' | 'clean' | 'custom'
# see http://recaptcha.net/apidocs/captcha/client.html#look-n-feel
#
# If you choose a value that is not supported the captcha will default to the
# red theme
Theme=white

# The templates currently attempt to work out the language to present the
# capture in based on the language_code attribute. This is currently not
# perfect (Will work on this) and you may want to override the automated
# language chosing and set a default value.
#
# If OverrideLang is set (not empty) then it will be used as the display
# language of the reCAPTCHA widget
#  Current possible values are:
#   English     en 
#   Dutch       nl
#   French      fr
#   German      de
#   Portuguese  pt
#   Russian     ru
#   Spanish     es
#   Turkish     tr
OverrideLang=

*/ ?>
