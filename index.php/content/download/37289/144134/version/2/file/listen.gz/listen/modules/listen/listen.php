<?php 
//
// Created on: <20070420> pike@labforculture.org
// Commissioned by LabforCulture
// 
// 
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

//set_time_limit(300); // 5 minutes

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( 'kernel/common/template.php' );

$Result = array();


$module 	= &$Params['Module'];
$http		= &eZHTTPTool::instance();
$classname 		= $http->variable('classname');
$attributes 	= $http->variable('attributes');
$offset 		= $http->variable('offset');
$limit	 		= $http->variable('limit');

if (!$classname) 	$classname='';
if (!$attributes) 	$attributes=array();
if (!$offset) 		$offset=0;
if (!$limit)		$limit = 50;

//header('Content-Type: text/plain');
//set_time_limit(300);

$tpl =& templateInit();
$tpl->setVariable( 'view', array(
	"classname" 	=> $classname,
	"attributes" 	=> $attributes,
	"offset"		=> $offset,
	"limit"			=> $limit
));
$Result['content'] 	 = $tpl->fetch( 'design:listen/listen.tpl' );


$Result['path'] 	= array(
                        array( 'url' => '/listen/listen',	'text' => 'Listen' )
                     );
if ($classname) {
	$Result['path'][] = array( 'url' => '/listen/listen?classname='.$classname,	'text' => 'Class '.$classname );
	if ($attributes) {
		$Result['path'][] = array( 'url' => false,	'text' => 'view attributes' );
	}
} else {
	$Result['path'][] = array( 'url' => false,	'text' => 'view classes' );
}
?>