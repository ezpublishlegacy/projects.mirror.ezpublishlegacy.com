
// ListGen  for ezPublish
// Created: <2007/08> pike@labforculture.org

=============
LISTEN
=============

Listen is a very simple (1 template) admin extension 
that generates lists of nodes, ignoring the hierarchic
folder structure of ezpublish, showing one or more 
selected attributes in the list view. 

Tested on 3.7.6. 

It shows, in 3 steps
1) a list of classes with some properties
2) a list of all attributes of one class with some properties
3) a list of all nodes of one class with one or more selected attributes.
That's all. But very handy.

=============
HOW TO INSTALL
=============

- Copy the extensiondir to your /extension/ folder
- Go to the admin - setup / extensions
- Enable the extension
- Clear all caches
- Goto http://youradminurl/listen/listen

and have fun.


=============
FIELDS
=============
		
You can shortcut all the menu stuff by going to
http://youradminurl/listen/listen?
	classname=[yourclassidentifier]
	&attributes[]=[aclassattributeidentifier]
	&attributes[]=[anotherclassattributeidentifier]
	&offset=[offset]
	&limit=[limit]

.. Yes, you can specify multiple attributes to
list. One day, I will enable the gui to
do that too .. if I need that feature :-)

$2c!
*-pike


