<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=antispam

*/
?>
