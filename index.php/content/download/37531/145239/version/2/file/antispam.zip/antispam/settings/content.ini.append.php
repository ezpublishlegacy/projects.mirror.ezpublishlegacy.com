<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=antispam
AvailableDataTypes[]=sckantispam


*/
?>
