<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/antispam/autoloads/sckantispamtemplateoperator.php',
                                    'class' => 'SckAntispamTemplateOperator',
                                    'operator_names' => array( 'antispam', 'challenge' ) );
?>
