<?php
/*

[ExtensionSettings]
DesignExtensions[]=antispam

*/
?>
