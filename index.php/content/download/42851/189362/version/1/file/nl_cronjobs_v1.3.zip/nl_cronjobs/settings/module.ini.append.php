<?php /*

[ModuleSettings]
ExtensionRepositories[]=nl_cronjobs
ModuleList[]=nl_cronjobs

*/ ?>
