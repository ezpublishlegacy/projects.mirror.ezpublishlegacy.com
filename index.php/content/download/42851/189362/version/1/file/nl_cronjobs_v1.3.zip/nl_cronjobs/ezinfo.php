<?php

class nl_cronjobsInfo
{
    static function info()
    {
        return array( 'Name' => "NL Cronjobs",
                      'Version' => "1.4",
                      'Copyright' => "Nicolas Lecure",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
