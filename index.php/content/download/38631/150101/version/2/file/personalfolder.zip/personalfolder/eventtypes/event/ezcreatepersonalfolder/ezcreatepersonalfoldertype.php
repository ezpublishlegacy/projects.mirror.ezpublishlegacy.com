<?php

// INCLUDE EZ PUBLISH CLASSES
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( "kernel/classes/ezcontentclassattribute.php" );
include_once( 'kernel/classes/ezrole.php' );
include_once( "kernel/classes/ezworkflowtype.php" );

define( "EZ_WORKFLOW_TYPE_CREATEPERSONALFOLDER_ID", "ezcreatepersonalfolder" );

class eZCreatePersonalFolderType extends eZWorkflowEventType
{

    function eZCreatePersonalFolderType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_CREATEPERSONALFOLDER_ID, "Create Personal Folder" );
    }

    function execute( &$process, &$event )
    {
        // Get the parameters from the ini files
        $eZINI                  =& eZINI::instance( 'personal_folder.ini' );
        $Debug                  = $eZINI->variable( 'General', 'Debug' );
        $FolderClassId          = $eZINI->variable( 'General', 'FolderClassId' );
        $sectionId              = $eZINI->variable( 'General', 'SectionId' );
        $PersonnalFoldersNodeId = $eZINI->variable( 'General', 'PersonnalFoldersNodeId' );
        $RodeId                 = $eZINI->variable( 'General', 'RoleId' );
    
        // Get workflow parameters
        $processParameters = $process->attribute( 'parameter_list' );        
        $UserObjectID      = $processParameters['object_id'];
        
        /* some code just in case you want to run the workflow based on node_id, not object_id
        $UserNodeID = $processParameters['node_id'];
        if ($UserNodeID)
        {
        $node =& eZContentObjectTreeNode::fetch( $UserNodeID );
        $userContentObject =& eZContentObject::fetch( $node->attribute( 'contentobject_id' ) );
        }*/
        if ($UserObjectID)
        {
            // Get the user's name
            $userContentObject = &eZContentObject::fetch( $UserObjectID );
            $userName          = $userContentObject->attribute('name');
    
            // Create the folder
            $folderNodeID = $this->createFolderObject($UserObjectID,$sectionId,$PersonnalFoldersNodeId,$userName,$FolderClassId);
            
            // Assign the appropriate role to the user on this folder
            $role =& eZRole::fetch( $RodeId );
            $role->assignToUser( $UserObjectID, 'subtree',  $folderNodeID );

            if ($Debug) eZDebug::writeDebug("Created Personal Folder for user name=".$userName);
        }

        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }
    
    // ***************************************************************************************************************
    // FUNCTION createFolderObject
    // ***************************************************************************************************************
    function createFolderObject($CreatorUserID=12, $sectionId=1, $parentNodeID=2, $folderTitle="No title", $FolderClassId=1)
    {
     
      $class =& eZContentClass::fetch( $FolderClassId );
      $folderContentObject =& $class->instantiate( $CreatorUserID, $sectionId );
      
      // Create a node for the object in the tree.
      $nodeAssignment =& eZNodeAssignment::create( array(
                             'contentobject_id' => $folderContentObject->attribute( 'id' ),
                             'contentobject_version' => 1,
                             'parent_node' => $parentNodeID,
                             'sort_field' => 2, // Published
                             'sort_order' => 1, // Descending
                             'is_main' => 1));
      $nodeAssignment->store();
        
      // Set a status for the content object version
      $folderContentObjectVersion =& $folderContentObject->version($folderContentObject->attribute( 'current_version' ) );
      $folderContentObjectVersion->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT);
      $folderContentObjectVersion->store();
    
      // Set the title of the folder
      $DataMap = $folderContentObjectVersion->dataMap();
      $DataMap['name']->setAttribute("data_text",$folderTitle);
      $DataMap['name']->store();
          
      // Now publish the object.
      $operationResult = eZOperationHandler::execute( 'content', 'publish',
                              array( 'object_id' => $folderContentObject->attribute( 'id' ),
                                     'version' => $folderContentObject->attribute('current_version' ) ) );
      
      return $folderContentObject->attribute('main_node_id');
    }
    // END FUNCTION createFolderObject
    
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_CREATEPERSONALFOLDER_ID, "ezcreatepersonalfoldertype" );

?>