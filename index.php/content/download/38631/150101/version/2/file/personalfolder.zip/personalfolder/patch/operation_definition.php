<?
$OperationList = array();
$OperationList['activate'] = array( 'name' => 'activate',
                                        'default_call_method' => array( 'include_file' => 'kernel/user/ezuseroperationcollection.php',
                                                                        'class' => 'eZUserOperationCollection' ),
                                        'parameter_type' => 'standard',
                                        'parameters' => array( array( 'name' => 'object_id',
                                                                      'type' => 'integer',
                                                                      'required' => true ),
                                                               ),
                                        'keys' => array( 'object_id' ),
                                        'body' => array( array( 'type' => 'trigger',
                                                                'name' => 'post_activate',
                                                                'keys' => array( 'object_id' ) )));
?>