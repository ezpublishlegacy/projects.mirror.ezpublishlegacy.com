<?php

[EventSettings]
ExtensionDirectories[]=personalfolder
AvailableEventTypes[]=event_ezcreatepersonalfolder

[OperationSettings]
AvailableOperations=content_publish;content_read;user_activate

?>