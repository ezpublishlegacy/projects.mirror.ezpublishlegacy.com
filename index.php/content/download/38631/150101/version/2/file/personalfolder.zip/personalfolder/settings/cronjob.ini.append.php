#?ini charset="iso-8859-1"?
# eZ publish configuration file for cronjobs.

[CronjobSettings]
ScriptDirectories[]=extension/personal_folder/cronjobs

[CronjobPart-create_personal_folder]
Scripts[]=create_personal_folder.php