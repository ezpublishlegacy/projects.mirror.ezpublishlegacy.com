<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ngcomments/comment</name>
    <message>
        <source>Loading ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading comments ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Some fields are missing input!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total comment count</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ngcomments/comment/ezjsc</name>
    <message>
        <source>Error loading comment list!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your comment has been added!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error adding comment!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading comment edit interface!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment was successfully edited!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error editing the comment!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment was successfully deleted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error deleting the comment!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
