<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=ngcomments
*/ ?>