<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ngcomments/comment</name>
    <message>
        <source>Loading ...</source>
        <translation>Učitavanje ...</translation>
    </message>
    <message>
        <source>Loading comments ...</source>
        <translation>Učitavanje komentara ...</translation>
    </message>
    <message>
        <source>Some fields are missing input!</source>
        <translation>Nedostaje unos u nekim poljima!</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Stranice</translation>
    </message>
    <message>
        <source>Total comment count</source>
        <translation>Ukupno komentara</translation>
    </message>
</context>
<context>
    <name>ngcomments/comment/ezjsc</name>
    <message>
        <source>Error loading comment list!</source>
        <translation>Greška pri dohvatu liste komentara!</translation>
    </message>
    <message>
        <source>Your comment has been added!</source>
        <translation>Vaš komentar je uspješno dodan!</translation>
    </message>
    <message>
        <source>Error adding comment!</source>
        <translation>Greška pri dodavanju komentara!</translation>
    </message>
    <message>
        <source>Error loading comment edit interface!</source>
        <translation>Greška pri učitavanju prozora za uređivanje komentara!</translation>
    </message>
    <message>
        <source>Comment was successfully edited!</source>
        <translation>Komentar je uspješno izmijenjen!</translation>
    </message>
    <message>
        <source>Error editing the comment!</source>
        <translation>Greška pri izmjeni komentara!</translation>
    </message>
    <message>
        <source>Comment was successfully deleted!</source>
        <translation>Komentar je uspješno obrisan!</translation>
    </message>
    <message>
        <source>Error deleting the comment!</source>
        <translation>Greška pri brisanju komentara!</translation>
    </message>
</context>
</TS>
