<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezjscNgComments

[ezjscServer_ezjscNgComments]
Class=ezjscNgComments
TemplateFunction=false
File=extension/ngcomments/classes/ezjscngcomments.php
*/ ?>