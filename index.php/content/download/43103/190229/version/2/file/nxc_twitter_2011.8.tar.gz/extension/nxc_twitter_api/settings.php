<?php
/**
 * @package nxcTwitter
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    18 Jan 2010
 **/

class nxc_twitter_apiSettings extends nxcExtensionSettings
{
	public $defaultOrder = 10;
	public $dependencies = array();

	public function activate() {}

	public function deactivate() {}
}
?>
