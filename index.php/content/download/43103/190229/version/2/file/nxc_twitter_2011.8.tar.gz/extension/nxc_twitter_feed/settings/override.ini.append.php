<?php /* #?ini charset="utf-8"?

[block_twitterfeed_list]
Source=block/view/view.tpl
MatchFile=block/twitterfeed.tpl
Subdir=templates
Match[type]=TwitterFeed
Match[view]=list
*/ ?>
