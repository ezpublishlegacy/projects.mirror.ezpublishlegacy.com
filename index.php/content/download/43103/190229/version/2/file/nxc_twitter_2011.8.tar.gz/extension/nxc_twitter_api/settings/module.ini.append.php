<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=nxc_twitter_api
ModuleList[]=nxc_twitter_api
*/ ?>
