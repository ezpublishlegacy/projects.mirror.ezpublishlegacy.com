<?php /* #?ini charset="utf8"?

[ModuleSettings]
ExtensionRepositories[]=nxc_twitter_feed
ModuleList[]=twitter_feed
*/ ?>

