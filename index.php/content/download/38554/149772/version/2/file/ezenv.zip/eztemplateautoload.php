<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/kernel/common/templateezenvoperator.php',
                                    'class' => 'TemplateEzenvOperator',
                                    'operator_names' => array( 'ezenv' ) );
?>