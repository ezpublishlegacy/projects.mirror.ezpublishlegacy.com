ezenv: an operator which can be used to pass variables between templates.

DISCLAIMER: use at your own risk!!


Quick installation instructions: 

1) If it not exists, create the folder "extension/kernel/common" in the base ezpublish directory

2) put the file "templateezenvoperator.php" in "extension/kernel/common"

3) If you have already a file "eztemplateautoload.php" in "extension/kernel/common",add the following lines
 
$eZTemplateOperatorArray[] = array( 'script' => 'extension/kernel/common/templateezenvoperator.php',
                                    'class' => 'TemplateEzenvOperator',
                                    'operator_names' => array( 'ezenv' ) );

If you do not have this file, copy "eztemplateautoload.php" from the zip archive there

4) Make sure you have the settings from in your settings/override/site.ini.append[.php] for the AutoloadPath in
[TemplateSettings]

eg,: 

AutoloadPath=lib/eztemplate/classes/;kernel/common/;extension/kernel/common/

Note: do not put spaces between the semicolons

Also DISABLE View aching in the [ContentSettings]:
ViewCaching=disabled

5) Clear the caches (including the ini caches)

6) Now you can define additional variables (form elements) in your templates, for example:

.....

<form method="post">
<input type="text" name="myfield" />
    <input class="button" type="submit" value="Do-it!" />
</form>

.....

My field contains: {"myfield"|ezenv|wash}

.....


7) You can also use GET style variables (append them to the current URL)

8) Be careful not to nest <form> constructs, especially for the admin templates or user-side edit templates

9) As allways: Clear your caches before trying your edited templates

PS: apparently, you do not have to define these as "ActiveExtensions" (which is the case with full modules)

Enjoy!

--paul

