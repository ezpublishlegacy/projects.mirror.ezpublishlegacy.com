<?php
/*!
  \class   TemplateEzenvOperator templateezenvoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator ezenv
  \version 1.0
  \date    Sunday 27 July 2003 12:52:19 pm
  \author  Administrator User

  By using ezenv you can use custom variables to pass values between templates. 
  This is useful if you want to do things like user side sorting with passing form variables.

  Very Simple Example:
\code

.....
<form method="post">
<input type="text" name="myfield" />
    <input class="button" type="submit" value="Do-it!" />
</form>

.....

My field contains: {"myfield"|ezenv|wash}

.....

\endcode

You can also use "GET"-style variables by appending them to the current URL in your templates

*/

/*
If you want to have autoloading of this operator you should create
a eztemplateautoload.php file and add the following code to it.
The autoload file must be placed somewhere specified in AutoloadPath
under the group TemplateSettings in settings/site.ini

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'templateezenvoperator.php',
                                    'class' => 'TemplateEzenvOperator',
                                    'operator_names' => array( 'ezenv' ) );

*/


class TemplateEzenvOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TemplateEzenvOperator($name = "ezenv" )
    {
	  $this->Operators = array( $name );
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'ezenv' );
    }
    
	   /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array();
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $operatorValue = eZHTTPTool::variable($operatorValue);
        
    }
	var $Operators;
}
?>