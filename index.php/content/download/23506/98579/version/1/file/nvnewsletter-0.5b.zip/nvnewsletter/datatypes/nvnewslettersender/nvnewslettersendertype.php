<?php
include_once( "kernel/classes/ezdatatype.php" );

define( "EZ_DATATYPESTRING_NVNEWSLETTERSENDER", "nvnewslettersender" );

class nvnewslettersendertype extends eZDataType
{
    /*!
      Constructor
    */
    function nvnewslettersendertype()
    {
        $this->eZDataType( EZ_DATATYPESTRING_NVNEWSLETTERSENDER, "nvNewsletter: Sender information" );
    }

    /*!
    Validates all variables given on content class level
     \return EZ_INPUT_VALIDATOR_STATE_ACCEPTED or
     EZ_INPUT_VALIDATOR_STATE_INVALID if
             the values are accepted or not
    */
    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
      return eZInputValidator::STATE_ACCEPTED;
    }

    /*!
     Fetches all variables inputed on content class level
     \return true if fetching of class attributes are successfull,
     false if not
    */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
		  $classAttribute->setAttribute( 'data_text1', $http->postVariable( 'ContentClass_nvnewslettersender_table_'. $classAttribute->attribute( 'id' ) ) );
      $classAttribute->sync();	
      return true;
    }
    /*!
     Validates input on content object level
     \return EZ_INPUT_VALIDATOR_STATE_ACCEPTED or
     EZ_INPUT_VALIDATOR_STATE_INVALID if
             the values are accepted or not
    */
    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
      return  eZInputValidator::STATE_ACCEPTED;
    }

    /*!
     Fetches all variables from the object
     \return true if fetching of class attributes are successfull,
     false if not
    */
    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
			$contentObjectAttribute->setAttribute( 'data_text', $http->postVariable( 'Attribute_' . $contentObjectAttribute->attribute( 'id' ) ) );
			$contentObjectAttribute->sync();
      return true;
    }

    /*!
     Returns the content.
    */
    function objectAttributeContent( $contentObjectAttribute )
    {
		  //$db = eZDB::instance();
        //$senders = $db->arrayQuery( "SELECT id, sender_name, sender_email, reply_to FROM nvnewsletter_senders ORDER BY sender_name ASC;" );
		  $senders = nvNewsletterSender::fetchList();
          
		  foreach ($senders as $sender){
            $endparam = '-'; 
            if (trim($sender->reply_to) != ''){ 
                $endparam = trim($sender->reply_to); 
            }
            $options[$sender->id] = trim($sender->sender_name).' &lt;'.trim($sender->sender_email).'&gt;, Reply-To: '.$endparam;
		  }
		  //unset($tmp);
		  
		  return array( 'options' => $options, 'selected' => $contentObjectAttribute->attribute( 'data_text' ) );
    }

    /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( $contentObjectAttribute )
    {
      return $contentObjectAttribute->attribute( 'data_text' );
    }

    /*!
     Returns the value as it will be shown if this attribute is used
     in the object name pattern.
    */
    function title( $contentObjectAttribute, $name = null )
    {
      return "";
    }

    /*!
     \return true if the datatype can be indexed
    */
    function isIndexable()
    {
      return false;
    }
    
    public function hasObjectAttributeContent($attribute) {
        return $attribute->attribute( 'data_text' ) != '';
    }
}

eZDataType::register( EZ_DATATYPESTRING_NVNEWSLETTERSENDER, "nvnewslettersendertype" );
?>