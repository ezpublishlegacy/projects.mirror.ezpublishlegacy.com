<?php /*

## Default overrides

[nvnewsletter_image]
Source=content/datatype/view/ezimage.tpl
MatchFile=newsletteritems/ezimage.tpl
Subdir=templates
Match[viewmode]=nvnewsletterhtml

[nvnewsletter_edit]
Source=content/edit.tpl
MatchFile=edit/newsletter.tpl
Subdir=templates
Match[section]=6

[nvnewsletter_versionview]
Source=content/view/versionview.tpl
MatchFile=versionview/newsletter.tpl
Subdir=templates
Match[section]=6

*/ ?>
