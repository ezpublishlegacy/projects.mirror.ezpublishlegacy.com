<?php
/**
 * File containing the nvNewsletterReceiver class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.5
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterReceiver handles newsletter receivers
 */
class nvNewsletterReceiver extends eZPersistentObject {
    const StatusDraft = 0;
    const StatusPublished = 1;

    function __construct($row) {
        parent::__construct($row);
    }

    static function definition() {
        return array(
                'fields' => array(
                    'id' => array(
                        'name' => 'id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'email_address' => array(
                        'name' => 'email_address',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => true),
                    'user_node_id' => array(
                        'name' => 'user_node_id',
                        'datatype' => 'integer',
                        'default' => null,
                        'required' => false),
                    'status' => array(
                        'name' => 'status',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true)),
                'keys'          => array('id', 'status'),
                'increment_key' => 'id',
                'sort'          => array('id' => 'asc'),
                'function_attributes' => array(
                    'groups' => 'groups',
                    'group_ids' => 'groupIDs',
                    'fields' => 'fields',
                    'groups_unsubscribed' => 'groupsUnsubscribed'),
                'class_name'    => 'nvNewsletterReceiver',
                'name'          => 'nvnewsletter_receivers');
    }

    function attribute($attr, $noFunction = false) {
        $retVal = eZPersistentObject::attribute($attr);
        return $retVal;
    }

    static function fetchByOffset($status = nvNewsletterReceiver::StatusPublished, $limit = false, $sorts = false, $asObject = true ) {
        if (!$sorts) {
            $sorts = array('id' => 'asc');
        }
        if (!$limit) {
            $limit = null;
        }
        $receiverList = eZPersistentObject::fetchObjectList(
                nvNewsletterReceiver::definition(), null, array('status' => $status),
                $sorts, $limit, $asObject);

        return $receiverList;
    }

    static function fetchByEmail($email, $asObject = true) {
        return eZPersistentObject::fetchObject(
                nvNewsletterReceiver::definition(), null,
                array('email_address' => $email), $asObject);
    }

    static function fetchList($status = nvNewsletterReceiver::StatusPublished, $asObject = true) {
        return eZPersistentObject::fetchObjectList(
                nvNewsletterReceiver::definition(), null, array('status' => $status), null, null, $asObject);
    }

    static function fetch($receiverID, $status = nvNewsletterReceiver::StatusPublished, $asObject= true) {
        return eZPersistentObject::fetchObject(
                nvNewsletterReceiver::definition(), null,
                array('id' => $receiverID, 'status' => $status), $asObject);
    }

    static function fetchDraft($id, $asObject = true) {
        $receiver = nvNewsletterReceiver::fetch($id, nvNewsletterReceiver::StatusDraft, $asObject);
        if (!$receiver) {
            $receiver = nvNewsletterReceiver::fetch($id, nvNewsletterReceiver::StatusPublished, $asObject);
            if ($receiver) {
                $receiver->setAttribute('status', nvNewsletterReceiver::StatusDraft);
                $receiver->store();
            }
        }

        if (!$receiver) {
            return false;
        }

        return $receiver;
    }
    
    static function getUnsubscribedCount() {
        $db = eZDB::instance();
        $result = $db->arrayQuery("SELECT COUNT(rhg.receiver_id) AS count
                    FROM nvnewsletter_receivergroups g, nvnewsletter_receivers_has_groups_unsub rhg
                    WHERE g.id = rhg.receivergroup_id AND g.status = ".nvNewsletterReceiver::StatusPublished);
        return $result[0]['count'];
    }
    
    function groupsUnsubscribed($asObject = false) {
        $db = eZDB::instance();

        if ($asObject == true) {
            // TODO Implement me
        } else {
            $receiverID = $this->attribute('id');
            $receiverGroups = $db->arrayQuery("SELECT g.*, rhg.mail_type, rhg.unsub_date
                    FROM nvnewsletter_receivergroups g, nvnewsletter_receivers_has_groups_unsub rhg
                    WHERE g.id = rhg.receivergroup_id AND rhg.receiver_id = $receiverID
                    AND g.status = ".nvNewsletterReceiverGroup::StatusPublished);

            return $receiverGroups;
        }
    }

    function groups($groupIDs = false, $asObject = false) {
    
        $db = eZDB::instance();
        
        $groupIDSQL = '';
        if ( is_array( $groupIDs ) ) {
            $tempIDs = array();
            foreach ( $groupIDs as $groupID ) {
                if (is_numeric( $groupID )) {
                    $tempIDs[] = $groupID;
                }
            }
            if ( count( $tempIDs ) > 0  ) {
                $groupIDSQL = " AND g.id IN (".implode( ', ', $tempIDs ).")";
            }
        }

        if ($asObject == true) {
            // TODO Implement me
        } else {
            $receiverID = $this->attribute('id');
            $receiverGroups = $db->arrayQuery("SELECT g.*, rhg.mail_type, rhg.pub_date 
                    FROM nvnewsletter_receivergroups g, nvnewsletter_receivers_has_groups rhg
                    WHERE g.id = rhg.receivergroup_id AND rhg.receiver_id = $receiverID
                    AND g.status = ".nvNewsletterReceiverGroup::StatusPublished.$groupIDSQL);

            return $receiverGroups;
        }
    }

    function groupIDs() {
        $db = eZDB::instance();

        $receiverID = $this->attribute('id');
        $receiverGroupIDs = $db->arrayQuery("SELECT g.id FROM nvnewsletter_receivergroups g
                WHERE g.id IN (SELECT receivergroup_id
                    FROM nvnewsletter_receivers_has_groups WHERE receiver_id = $receiverID)
                AND g.status = ".nvNewsletterReceiverGroup::StatusPublished);
        $groupIDs = array();
        foreach ($receiverGroupIDs as $groupID) {
            $groupIDs[] = $groupID['id'];
        }

        return $groupIDs;
    }

    /**
     * Update receiver groups. In admin interface we want to replace all groups.
     *
     * @param array $receiverGroupIDs
     * @param array $receiverGroupFormats
     */
    function setReceiverGroups($receiverGroupIDs, $receiverGroupFormats = array()) {
    
        $db = eZDB::instance();
        $db->begin();
        
        $receiverID = $this->attribute('id');
        
        $groupUnsub = false;
        $groupIDs   = false;
        $groups     = $this->groups();
        
        // Check if there is unsub groups
        if ($groups) {
        
            foreach ( $groups as $group ) {
                if ( !in_array( $group['id'], $receiverGroupIDs ) ) {
                    $groupUnsub[] = $group;
                }
            }
            
            if ($groupUnsub) {
                foreach ( $groupUnsub as $group ) {
                    $db->query("INSERT INTO nvnewsletter_receivers_has_groups_unsub ( receiver_id, receivergroup_id, mail_type, unsub_date ) 
                                                                             VALUES ( $receiverID, ".$group["id"].", ".$group["mail_type"].", NOW() )");
                }
            }
        }
        
        // Sanitize group IDs
        foreach ( $receiverGroupIDs as $groupID ) {
            if ( is_numeric($groupID) ) {
                $groupIDs[] = $groupID;
            }            
        }

        // Delete all group relations
        $db->query("DELETE FROM nvnewsletter_receivers_has_groups WHERE receiver_id = $receiverID");
        
        if ($groupIDs) {  
            // Insert selected groups
            foreach ( $groupIDs as $groupID ) {
                $format = (int)(array_key_exists($groupID, $receiverGroupFormats)) ? $receiverGroupFormats[$groupID] : 1;
                $db->query("INSERT INTO nvnewsletter_receivers_has_groups (receiver_id, receivergroup_id, mail_type, pub_date) VALUES ($receiverID, $groupID, $format, now())");
            }
            
            // Delete unsub groups
            if ( $groupIDs ) {
                $db->query("DELETE FROM nvnewsletter_receivers_has_groups_unsub WHERE receiver_id = $receiverID AND receivergroup_id IN ( ".implode(', ', $groupIDs )." )");
            }
        }

        $db->commit();
    }
    
    /**
     * Update receiver groups. Used for subscribe form or new user creation. 
     * We don't want to delete existing group subscriptions.
     *
     * @param array $receiverGroupIDs
     * @param array $receiverGroupFormats
     */
    function updateReceiverGroups($receiverGroupIDs, $receiverGroupFormats = array()) {
    
        $db = eZDB::instance();
        $db->begin();
        $receiverID = $this->attribute('id');
        $groupIDs = false;
        
        foreach ( $receiverGroupIDs as $groupID ) {
            if ( is_numeric($groupID) ) {
                $groupIDs[] = $groupID;
            }            
        }
        
        if ($groupIDs) {
            foreach ( $groupIDs as $groupID ) {
                $format = (int)(array_key_exists($groupID, $receiverGroupFormats)) ? $receiverGroupFormats[$groupID] : 1;
                $db->query("REPLACE INTO nvnewsletter_receivers_has_groups (receiver_id, receivergroup_id, mail_type, pub_date) VALUES ($receiverID, $groupID, $format, now())");
            }
            
            if ( $groupIDs ) {
                $db->query("DELETE FROM nvnewsletter_receivers_has_groups_unsub WHERE receiver_id = $receiverID AND receivergroup_id IN ( ".implode(', ', $groupIDs )." )");
            }
        }
        
        $db->commit();
    }

    /**
     * Get fields
     */
    function fields($asObject = false) {
        $db = eZDB::instance();

        if ($asObject == true) {
            // TODO Implement me
        } else {
            $receiverID = $this->attribute('id');
            $receiverFields = $db->arrayQuery("SELECT f.*
                    FROM nvnewsletter_receiverfields f
                    WHERE f.status = ".nvNewsletterReceiverField::StatusPublished." ORDER BY f.field_order");

            $receiverFieldValues = $db->arrayQuery("SELECT rhf.receiverfield_id, rhf.data
                    FROM nvnewsletter_receivers_has_fields rhf
                    WHERE rhf.receiver_id = $receiverID");

            foreach ($receiverFields as $idx => $field) {
                foreach ($receiverFieldValues as $value) {
                    if ($field['id'] == $value['receiverfield_id']) {
                        $receiverFields[$idx]['value'] = $value['data'];
                    }
                }
            }

            return $receiverFields;
        }
    }

    /**
     * Set receiver fields
     *
     * @param array $receiverFields
     */
    function setReceiverFields($receiverFields) {
        $db = eZDB::instance();

        $receiverID = $this->attribute('id');
        $db->query("DELETE FROM nvnewsletter_receivers_has_fields WHERE receiver_id = $receiverID");
        foreach ($receiverFields as $key => $field) {
            $db->query("INSERT INTO nvnewsletter_receivers_has_fields (receiver_id, receiverfield_id, data) VALUES ($receiverID, $key, '".$db->escapeString($field)."')");
        }
    }

    function publish() {
        $this->setAttribute('status', nvNewsletterReceiver::StatusPublished);
        $this->store();
        $this->removeDraft();
    }

    function removeDraft() {
        $receiverDraft = nvNewsletterReceiver::fetchDraft($this->attribute('id'));
        $receiverDraft->remove();
    }

    static function removeAll($id) {
        eZPersistentObject::removeObject(nvNewsletterReceiver::definition(),
                array('id' => $id));
        $db = eZDB::instance();
        $db->query("DELETE FROM nvnewsletter_receivers_has_fields WHERE receiver_id = $id");
        $db->query("DELETE FROM nvnewsletter_receivers_has_groups WHERE receiver_id = $id");
        $db->query("DELETE FROM nvnewsletter_receivers_has_groups_unsub WHERE receiver_id = $id");
    }

    static function create($email = '', $user_node_id = null) {
        $receiver = new nvNewsletterReceiver(array(
                    'email_address' => $email,
                    'user_node_id' => $user_node_id,
                    'status' => nvNewsletterReceiver::StatusDraft));
        $receiver->store();

        return $receiver;
    }
    
    /** 
     * Unsubscribe all user groups. Insert receivers to unsub table.
     *
     * @param array $groupIDs
     * @return boolean
     */
    function unsubscribeGroups ( $groupIDs=false ) {
        
        if ( !$groupIDs ) {
            $groups = $this->groups();
        } else {
            $groups = $this->groups( $groupIDs );
        }
        
        if ( is_array( $groups ) && count( $groups ) > 0 ) {
        
            $db = eZDB::instance();
            $db->begin();
        
            $receiverID = $this->attribute('id');
            
            foreach ( $groups as $group ) {
                $groupIDs[] = $group["id"];
                $db->query("INSERT INTO nvnewsletter_receivers_has_groups_unsub ( receiver_id, receivergroup_id, mail_type, unsub_date ) 
                                                                         VALUES ( $receiverID, ".$group["id"].", ".$group["mail_type"].", NOW() )");
            }
            
            $db->query("DELETE FROM nvnewsletter_receivers_has_groups WHERE receiver_id = $receiverID AND receivergroup_id IN ( ".implode(', ', $groupIDs )." )");
            $db->commit();
            return true;
        }
        
        return false;
    }
    
    /**
     * Unsubscribe
     */
    function unsubscribe() {
        return $this->unsubscribeGroups();
    }
    
    /**
     * Subscribe newsletter
     *
     * @param string $email
     * @param array $receiverGroupIDs
     * @param array $receiverGroupFormats
     * @return mixed false or receiver object
     */
    static function subscribe( $email, $receiverGroupIDs, $receiverGroupFormats ) {

        if ( !$receiver = self::fetchByEmail( $email ) ) {
            $receiver = self::create( $email, eZUser::currentUserID() );
            $receiver->publish();
        }
        
        if ( $receiver ) {
            $receiver->updateReceiverGroups( $receiverGroupIDs, $receiverGroupFormats );
            return $receiver;
        }
        
        return false;
    }
}
?>