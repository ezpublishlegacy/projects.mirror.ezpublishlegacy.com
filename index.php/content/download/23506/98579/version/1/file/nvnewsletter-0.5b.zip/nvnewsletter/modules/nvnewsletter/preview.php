<?php
/**
 * Module preview
 * @package nvNewsletter
 */
require_once('kernel/common/template.php');
//require_once('extension/nvnewsletter/classes/nvnewsletter.php');
//require_once('extension/nvnewsletter/classes/nvnewslettertools.php');

$objectID      = (int)$Params['ObjectID'];
$objectVersion = (int)$Params['ObjectVersion'];
$languageCode  = (string)$Params['Language'];
$format        = (string)$Params['Format'];
$titleArray    = array();
$content       = false;

if ($format != 'html' && $format != 'text') {
    $format = 'html';
}

/**
 * Create HTML and text files
 */
$object = eZContentObject::fetch( $objectID );

if ( $object ) {

    if ( nvNewsletter::createNewsletter( $objectID, $objectVersion, $languageCode ) ) {
        $content = nvNewsletterTools::getContent( $objectID, $objectVersion, $format, false, $languageCode );
        $content = nvNewsletterTools::replaceUserCode( $content );
    }
}

if ( !$content ) {
    eZLog::write( "nvNewsletter (preview.php): generated mail not found with objectID $objectID, objectVersion $objectVersion and languageCode $languageCode", "nvnewsletter.log" );
    $titleArray = array( array('url' => false, 'text' => 'Newsletter not generated' ) );
    $content = 'Newsletter not generated';
}

$tpl = templateInit();
$tpl->setVariable('result', array('content' => $content));

$Result['path'] = $titleArray;
$Result['content'] = $tpl->fetch('design:viewmail.tpl');
$Result['pagelayout'] = false;
?>