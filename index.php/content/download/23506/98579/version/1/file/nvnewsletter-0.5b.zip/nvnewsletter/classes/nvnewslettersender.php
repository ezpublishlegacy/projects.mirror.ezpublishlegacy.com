<?php
/**
 * File containing the nvNewsletterSender class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.5
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterSender handles newsletter sender details
 */
class nvNewsletterSender extends eZPersistentObject {
    const StatusDraft = 0;
    const StatusPublished = 1;

    function __construct($row) {
        parent::__construct($row);
    }

    static function definition() {
        return array(
                'fields' => array(
                    'id' => array(
                        'name' => 'id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'sender_name' => array(
                        'name' => 'sender_name',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'sender_email' => array(
                        'name' => 'sender_email',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => true),
                    'reply_to' => array(
                        'name' => 'reply_to',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'status' => array(
                        'name' => 'status',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true)),
                'keys'          => array('id', 'status'),
                'increment_key' => 'id',
                'sort'          => array('id' => 'asc'),
                'class_name'    => 'nvNewsletterSender',
                'name'          => 'nvnewsletter_senders');
    }

    function attribute($attr, $noFunction = false) {
        $retVal = eZPersistentObject::attribute($attr);

        return $retVal;
    }

    static function fetchByOffset($status = nvNewsletterSender::StatusPublished, $limit = false, $sorts = false, $asObject = true) {
        if (!$sorts) {
            $sorts = array('id' => 'asc');
        }
        if (!$limit) {
            $limit = null;
        }
        $senderList = eZPersistentObject::fetchObjectList(
                nvNewsletterSender::definition(), null, array('status' => $status),
                $sorts, $limit, $asObject);

        return $senderList;
    }

    static function fetchList($status = nvNewsletterSender::StatusPublished, $asObject = true) {
        return eZPersistentObject::fetchObjectList(
                nvNewsletterSender::definition(), null, array('status' => $status), null, null, $asObject);
    }

    static function fetch($senderID, $status = nvNewsletterSender::StatusPublished, $asObject= true) {
        return eZPersistentObject::fetchObject(
                nvNewsletterSender::definition(), null,
                array('id' => $senderID, 'status' => $status), $asObject);
    }

    static function fetchDraft($id, $asObject = true) {
        $sender = nvNewsletterSender::fetch($id, nvNewsletterSender::StatusDraft, $asObject);
        if (!$sender) {
            $sender = nvNewsletterSender::fetch($id, nvNewsletterSender::StatusPublished, $asObject);
            if ($sender) {
                $sender->setAttribute('status', nvNewsletterSender::StatusDraft);
                $sender->store();
            }
        }

        if (!$sender) {
            return false;
        }

        return $sender;
    }

    function publish() {
        $this->setAttribute('status', nvNewsletterSender::StatusPublished);
        $this->store();
        $this->removeDraft();
    }

    function removeDraft() {
        $senderDraft = nvNewsletterSender::fetchDraft($this->attribute('id'));
        $senderDraft->remove();
    }

    static function removeAll($id) {
        eZPersistentObject::removeObject(nvNewsletterSender::definition(),
                array('id' => $id));
    }

    static function create($name = '', $email = '', $replyto = '') {
        $sender = new nvNewsletterSender(array(
                    'sender_name' => $name,
                    'sender_email' => $email,
                    'reply_to' => $replyto,
                    'status' => nvNewsletterSender::StatusDraft));
        $sender->store();

        return $sender;
    }
}
