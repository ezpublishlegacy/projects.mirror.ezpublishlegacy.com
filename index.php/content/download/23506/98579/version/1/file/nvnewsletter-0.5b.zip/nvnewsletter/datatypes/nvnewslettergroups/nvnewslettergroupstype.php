<?php
include_once( "kernel/classes/ezdatatype.php" );

define( "EZ_DATATYPESTRING_NVNEWSLETTERGROUPS", "nvnewslettergroups" );

class nvnewslettergroupstype extends eZDataType
{
    /*!
      Constructor
    */
    function nvnewslettergroupstype()
    {
        $this->eZDataType( EZ_DATATYPESTRING_NVNEWSLETTERGROUPS, "nvNewsletter: Group selection" );
    }

    /*!
    Validates all variables given on content class level
     \return EZ_INPUT_VALIDATOR_STATE_ACCEPTED or
     EZ_INPUT_VALIDATOR_STATE_INVALID if
             the values are accepted or not
    */
    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
      return eZInputValidator::STATE_ACCEPTED;
    }

    /*!
     Fetches all variables inputed on content class level
     \return true if fetching of class attributes are successfull,
     false if not
    */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
		  $classAttribute->setAttribute( 'data_text1', $http->postVariable( 'ContentClass_nvnewslettergroups_table_'. $classAttribute->attribute( 'id' ) ) );
        $classAttribute->sync();	
        return true;
    }
    /*!
     Validates input on content object level
     \return EZ_INPUT_VALIDATOR_STATE_ACCEPTED or
     EZ_INPUT_VALIDATOR_STATE_INVALID if
             the values are accepted or not
    */
    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute ) {
      if ( $http->hasPostVariable( 'Attribute_array_' . $contentObjectAttribute->attribute( 'id' ) ) ){
        $selectOptions = $http->postVariable( 'Attribute_array_' . $contentObjectAttribute->attribute( 'id' ) );
        if(!@is_array($selectOptions) || count($selectOptions) == 0){
          if( $contentObjectAttribute->validateIsRequired() ) {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Selection required.' ) );
            return eZInputValidator::STATE_INVALID;
          } else {
            return eZInputValidator::STATE_ACCEPTED;
          }
        }
      }
      return  eZInputValidator::STATE_ACCEPTED;
    }

    /*!
     Fetches all variables from the object
     \return true if fetching of class attributes are successfull,
     false if not
    */
    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute ) {
      if ( $http->hasPostVariable( 'Attribute_array_' . $contentObjectAttribute->attribute( 'id' ) ) ){
        $selectOptions = $http->postVariable( 'Attribute_array_' . $contentObjectAttribute->attribute( 'id' ) );
        $idString = ( is_array( $selectOptions ) ? implode( '-', $selectOptions ) : "" );
        $contentObjectAttribute->setAttribute( 'data_text', $idString );
        return true;
      }
      return false;
    }

    /*!
     Returns the content.
    */
    function objectAttributeContent( $contentObjectAttribute ) {
    
        $groups   = nvNewsletterReceiverGroup::fetchList();
        $idString = explode( '-', $contentObjectAttribute->attribute( 'data_text' ) );
        
        foreach ( $groups as $group ) {
        
            $options[$group->id] = trim($group->group_name);
            
            if( in_array($group->id, $idString )){
                $optionsSelected[$group->id] = 1;
            }
        }

        return array( 'options' => $options, 'selected' => $optionsSelected );
    }

    /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( $contentObjectAttribute )
    {
      return $contentObjectAttribute->attribute( 'data_text' );
    }

    /*!
     Returns the value as it will be shown if this attribute is used
     in the object name pattern.
    */
    function title( $contentObjectAttribute, $name = null )
    {
      return "";
    }

    /*!
     \return true if the datatype can be indexed
    */
    function isIndexable()
    {
      return false;
    }
    
    public function hasObjectAttributeContent($attribute) {
        return $attribute->attribute( 'data_text' ) != '';
    }
}

eZDataType::register( EZ_DATATYPESTRING_NVNEWSLETTERGROUPS, "nvnewslettergroupstype" );
?>