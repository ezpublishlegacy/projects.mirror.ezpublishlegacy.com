<?php
/**
 * File containing the nvNewsletterStatistics class
 *
 * @copyright Copyright (c) 2009 Naviatech Solutions. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License V2
 * @author Naviatech Solutions <http://www.naviatech.fi>
 * @version 0.5
 * @package nvNewsletter
 */
/**
 * Class nvNewsletterStatistics contains statistics stuff
 */
class nvNewsletterStatistics extends eZPersistentObject {
    const NewsletterRead = 1;
    const NewsletterUnsubscribe = 2;
    const NewsletterLinkClick = 3;
    const NewsletterBounceHard = 4;
    const NewsletterBounceSoft = 5;

    function __construct($row) {
        parent::__construct($row);
    }

    static function definition() {
        return array(
                'fields' => array(
                    'id' => array(
                        'name' => 'id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'newsletter_id' => array(
                        'name' => 'newsletter_id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'receiver_id' => array(
                        'name' => 'receiver_id',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'action' => array(
                        'name' => 'action',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => true),
                    'action_date' => array(
                        'name' => 'action_date',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => true),
                    'data_text' => array(
                        'name' => 'data_text',
                        'datatype' => 'string',
                        'default' => '',
                        'required' => false),
                    'data_int' => array(
                        'name' => 'data_int',
                        'datatype' => 'integer',
                        'default' => 0,
                        'required' => false)),
                'keys'          => array('id'),
                'increment_key' => 'id',
                'sort'          => array('action_date' => 'asc'),
                'function_attributes' => array(
                    'receiver' => 'receiver',
                    'newsletter' => 'newsletter'),
                'class_name'    => 'nvNewsletterStatistics',
                'name'          => 'nvnewsletter_statistics');
    }

    function attribute($attr, $noFunction = false) {
        $retVal = eZPersistentObject::attribute($attr);
        return $retVal;
    }

    static function fetchByReceiverAction($newsletter_id, $receiver_id, $action, $asObject = true) {
        return eZPersistentObject::fetchObject(
                nvNewsletterStatistics::definition(), null,
                array('newsletter_id' => $newsletter_id,
                    'receiver_id' => $receiver_id,
                    'action' => $action), $asObject);
    }

    static function fetchByNewsletterAction($newsletter_id, $action, $asObject = true) {
        return eZPersistentObject::fetchObjectList(
                nvNewsletterStatistics::definition(), null,
                array('newsletter_id' => $newsletter_id,
                    'action' => $action), $asObject);
    }

    static function create($newsletter_id = 0, $receiver_id = 0, $action = 0, $data_text = null, $data_int = 1) {
        $now = date('Y-m-d H:i:00');
        $statistics = new nvNewsletterStatistics(array(
                    'newsletter_id' => $newsletter_id,
                    'receiver_id' => $receiver_id,
                    'action' => $action,
                    'action_date' => $now,
                    'data_text' => $data_text,
                    'data_int' => $data_int
                    ));
        $statistics->store();

        return $statistics;
    }
}
?>
