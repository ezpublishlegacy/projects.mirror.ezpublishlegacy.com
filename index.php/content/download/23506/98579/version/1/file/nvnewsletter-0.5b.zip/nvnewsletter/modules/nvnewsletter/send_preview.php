<?php
/**
 * Module send preview
 * @package nvNewsletter
 */
require_once('kernel/common/template.php');

$extension = 'nvnewsletter';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

$Module = $Params['Module'];

$http   = eZHTTPTool::instance();
$format = $http->postVariable('PreviewFormat');
$email  = $http->postVariable('PreviewEmail');
$redirectURIAfterPreview = $http->postVariable('RedirectURIAfterPreview');

$objectID      = (int)$Params['ObjectID'];
$objectVersion = (int)$Params['ObjectVersion'];
$languageCode  = (string)$Params['Language'];

$object = eZContentObject::fetch( $objectID );

$redirectURIAfterPreview = nvNewsletterTools::formatURLPath( $redirectURIAfterPreview );

if ( $object ) 
{
    if ( eZMail::validate( $email ) ) 
    {
        nvNewsletter::sendPreview( $email, $format, $objectID, $objectVersion, $languageCode );
    }
    
    $Module->redirectTo( $redirectURIAfterPreview );
    //header("Location: $redirectURIAfterPreview");
    //eZExecution::cleanExit();
} 
else 
{
    eZLog::write( "nvNewsletter (send_preview.php): sending preview failed with $objectID, objectVersion $objectVersion and languageCode $languageCode", "nvnewsletter.log" );
    return $Module->handleError(eZError::KERNEL_NOT_AVAILABLE, 'kernel');
}

?>