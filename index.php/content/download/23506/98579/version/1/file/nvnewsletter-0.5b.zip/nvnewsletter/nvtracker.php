<?php
$emptyImage = 'extension/nvnewsletter/design/standard/images/empty.gif';

header('Content-Type: image/gif');
header("Content-Length: ".(string) ( filesize( $emptyImage ) ) );

require 'autoload.php';

$http = eZHTTPTool::instance();
$code = $http->getVariable( 'code' );

if ( $code != nvNewsletterMailer::TrackerCodeReplacement )
{
    $arr = explode( '_', $code );
    
    if ( is_array( $arr ) && count( $arr ) == 3 )
    {
        $objectID   = $arr[0];
        $receiverID = $arr[1];
        $hash       = $arr[2];
        
        $receiver = nvNewsletterReceiver::fetch( $receiverID );
        $userHash = nvNewsletterTools::getUserHash( $receiver->attribute( 'email_address' ) );
        
        if ( $userHash == $hash && !empty( $hash ) )
        {
            $newsletter = nvNewsletter::fetchByContentObjectID( $objectID );
            
            if ($newsletter)
            {
                $statistics = nvNewsletterStatistics::fetchByReceiverAction( $newsletter->attribute('id'),
                                                                             $receiverID, 
                                                                             nvNewsletterStatistics::NewsletterRead );
                if (!$statistics) 
                {
                    $statistics = nvNewsletterStatistics::create( $newsletter->attribute('id'),
                                                                  $receiverID, 
                                                                  nvNewsletterStatistics::NewsletterRead, 
                                                                  $hash );
                } 
                else 
                {
                    $statistics->setAttribute('data_int', $statistics->attribute('data_int')+1);
                    $statistics->store();
                }
            }
        }
    }
}

readfile( $emptyImage );
?>