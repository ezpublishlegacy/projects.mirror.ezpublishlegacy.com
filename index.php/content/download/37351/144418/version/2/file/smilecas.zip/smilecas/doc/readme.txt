The following lines have to be appended at the end of the site.ini.append.php:

[UserSettings]
LoginHandler[]=cas
ExtensionDirectory[]=smilecas
