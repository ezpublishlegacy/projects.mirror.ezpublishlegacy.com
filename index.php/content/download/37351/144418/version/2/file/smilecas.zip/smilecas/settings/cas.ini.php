<?php /* #?ini charset="iso-8859-1"?

[CasSettings]
# Hostname of the CAS server
CasHost=ird.intranet
# SSL Port to use to connect to the server
CasPort=8443
# If set, CAS client debug message are written to the specified file
CasDebugLogFile=

*/ ?>
