SmileCas - Extension qui encapsule le client CAS
Par Beno�t JACQUEMONT <benoit.jacquemont@smile.fr>- � 2006 Smile

Description
-----------
Cette extension permet � un utilisateur authentifi� sous CAS d'�tre automatiquement identifi� sous ezPublish 
pour les sections n�cessitant un acc�s identifi�.

Pr�-requis
----------
php4-domxml

Contraintes
-----------
Les utilisateurs doivent obligatoirement exister sous ezPublish (cependant le mot de passe n'�tant pas utilis� 
par ezPublish, celui n'a pas besoin d'�tre renseign�).

Installation
------------
1 - Copier l'extension SmileCAS dans le r�pertoire extension.
2 - Ajouter les lignes suivantes au fichier settings/override/site.ini.append.php:

[UserSettings]
LoginHandler[]=cas
ExtensionDirectory[]=smilecas

3 - Configurer l'extension � partir du fichier smilecas/settings/cas.ini.php.
4 - Activer l'extension dans le back office eZpublish dans Administration > Extensions.
5 - Vider les caches.

Configuration
-------------
L'extension est param�trable � partir du fichier smilecas/settings/cas.ini.php :

CasHost
Nom du serveur qui supporte le serveur CAS.

CasPort
Num�ro du port utilis� pour se connecter au serveur.

CasDebugLogFile
Nom du fichier utilis� pour stocker la log.
