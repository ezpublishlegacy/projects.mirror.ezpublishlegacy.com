<?php

/*
CAS Login Handler for ezPublish

*/

include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );

// LIB CAS
include_once( 'extension/smilecas/lib/CAS/CAS.php' );

class eZCASUser extends eZUser {
    function eZCASUser() {
    }

    // Override the original checkUser to add a check on the 
    // CAS user
    function checkUser( &$siteBasics,&$url ) {
      // Get Settings

      $ini =& eZINI::instance ('cas.ini.php', "extension/smilecas/settings");
      $casHost =& $ini->variable('CasSettings','CasHost');
      $casPort =& intval($ini->variable('CasSettings','CasPort'));
      $casDebugLogFile =& $ini->variable('CasSettings','CasDebugLogFile'); 

      phpCAS::setDebug($casDebugLogFile);

      // initialize phpCAS
      if (!isset($PHPCAS_CLIENT) || !is_object($PHPCAS_CLIENT)) {
        phpCAS::client(CAS_VERSION_2_0,$casHost,$casPort,'');
      }

      // check CAS authentication
      if (phpCAS::checkAuthentication()) {

        // get the username
        $login = phpCAS::getUser();

        $user =& eZUser::fetchByName( $login );

        if ( $user and $user->isEnabled( ) ) {
          $userID = $user->attribute( 'contentobject_id' );

          eZUser::setCurrentlyLoggedInUser( $user, $userID );
        }
      }

      return parent::checkUser($siteBasics,$url);
    }
}

?>
