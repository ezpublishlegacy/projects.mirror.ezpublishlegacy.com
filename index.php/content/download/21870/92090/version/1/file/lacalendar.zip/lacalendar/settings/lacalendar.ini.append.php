<?php /* #?ini charset="UTF-8"?

[LAcalendar]
#It just support 3 format for now : 
#DateFormat=mm/dd/yyyy
#DateFormat=yyyy-mm-dd
#DateFormat=dd/mm/yyyy
DateFormat=dd/mm/yyyy

*/ ?>