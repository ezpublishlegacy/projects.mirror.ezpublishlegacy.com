<?php /* #?ini charset="UTF-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=lacalendar

*/ ?>