<?php /*
[ExtensionSettings]
DesignExtensions[]=lacalendar

#you can add this in your own admin siteaccess
[JavaScriptSettings]
#JavaScriptList[]=javascript/jquery-1.2.6.min.js
#JavaScriptList[]=javascript/jquery.bgiframe.min.js
#JavaScriptList[]=javascript/jquery.date.js
#JavaScriptList[]=javascript/jquery.datePicker.js

#you can add this in your own admin siteaccess
[StylesheetSettings]
#CSSFileList[]=datePicker.css


*/ ?>