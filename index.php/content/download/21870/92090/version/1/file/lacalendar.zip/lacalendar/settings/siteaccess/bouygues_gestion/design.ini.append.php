<?php /*
[ExtensionSettings]
DesignExtensions[]=lacalendar

#you can add this in your own admin siteaccess
[JavaScriptSettings]
#JavaScriptList[]=jquery-1.2.6.min.js
#JavaScriptList[]=jquery.bgiframe.min.js
#JavaScriptList[]=jquery.date.js
#JavaScriptList[]=jquery.datePicker.js

#you can add this in your own admin siteaccess
[StylesheetSettings]
#CSSFileList[]=datePicker.css


*/ ?>