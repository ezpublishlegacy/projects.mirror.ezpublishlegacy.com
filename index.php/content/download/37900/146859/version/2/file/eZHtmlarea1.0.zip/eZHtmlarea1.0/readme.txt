eZhtmlArea 1.0 License
Copyright (c) 2003, EniGMistA
emailanonima@libero.it
All rights reserved.

This is an implementation of htmlarea http://www.interactivetools.com/ with eZ3 http://developer.ez.no . It is free. Use it!
This is a primitive editor, use Online Editor http://ez.no/products/power_tools/online_editor for best results.

READ BUG.TXT