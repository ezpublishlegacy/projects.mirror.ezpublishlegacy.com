<?php
 
$Module = array( 'name' => 'eZ URL Jump' ); 
$ViewList = array();

$ViewList['in'] = array( 'script' => 'in.php',
                           'functions' => array( 'read' ),
                          );
 
$ViewList['out'] = array( 'script' => 'out.php', 
                           'functions' => array( 'read' ), 
			   'params' => array('redirID'), 
                          );

$FunctionList = array(); 
$FunctionList['read'] = array(); 
$FunctionList['edit'] = array();
 
?>
