<?php
include_once ('kernel/common/template.php');

$user_id = eZUser::currentUserID();

function createObject($userID, $parentID, $name, $remoteID, $classIdentifier, $objectAttributes = array()) {

    $itemClass = &eZContentClass::fetchByIdentifier($classIdentifier);
    $remoteobject = eZContentObject::fetchByRemoteID($remoteID);

    if (!$remoteobject || $remoteobject->attribute('status') == 0) {
//        echo "Creating object: {$name} in {$parentID}<br/>";

        $contentObject = &$itemClass->instantiate($userID, 1);
        $contentObject->setAttribute('name', $name);
        $contentObject->setAttribute('modified', time());
        $contentObject->setAttribute('published', time());
        $contentObject->setAttribute('is_published', 1);
        $contentObject->setAttribute('remote_id', $remoteID);
        
	$version = &$contentObject->version(1);
        $version->setAttribute('status', EZ_VERSION_STATUS_DRAFT);
        $version->store();
        
	$contentObjectAttributes = &$version->contentObjectAttributes();
        
	$index = 0;
	foreach($objectAttributes as $attribute) {
            foreach($attribute as $key => $value) {
		switch($key) {
		    case 'ezurl':
			$contentObjectAttributes[$index]->setContent($value[0]);
			$contentObjectAttributes[$index]->setAttribute('data_text', $value[1]);
		    break;
		    
		    case 'ezstring':
			$contentObjectAttributes[$index]->setAttribute('data_text', $value);
		    break;
		    
		    case 'ezidentifier':
		    break;
		}
		
                $contentObjectAttributes[$index]->store();
                $index++;
            } 
        } 
        
	$contentObject->store();
        $nodeAssignment = eZNodeAssignment::create(array('contentobject_id' => $contentObject->attribute('id'),
                'contentobject_version' => $contentObject->attribute('current_version'),
                'parent_node' => $parentID,
                'is_main' => 1,
                ));
        $nodeAssignment->store();
        // var_export($contentObject);
        $operationResult = eZOperationHandler::execute('content', 'publish', array('object_id' => $contentObject->attribute('id'),
                'version' => $contentObject->attribute('current_version')
                ));
        $remoteobject = eZContentObject::fetchByRemoteID($remoteID);
        $datamap = $contentObject->dataMap();

        return $datamap['id']->attribute('data_text');
    } else {
//        echo "Using existing object: {$name}<br/>";
        $existingobject = eZContentObjectTreeNode::fetchByContentObjectID($remoteobject->ID);
        $object_nodeID = $existingobject[0]->MainNodeID;
	$datamap = $existingobject[0]->dataMap();

        return $datamap['id']->attribute('data_text');
    } 
    return false;
} 

$Module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();

$Result = array();
$Result['pagelayout'] = false;

$url = $http->variable('url');
$url = eregi_replace("/$", "", $url);

if(!empty($url)) {
    if(!eregi("^http://", $url)) $url = "http://".$url;
    $iniFile = eZINI::instance('ezurljump.ini');                                                                                                                                                                                                    
    $codeset = $iniFile->variable('URLJumpSettings', 'CodeSet');
    $containerNodeID = $iniFile->variable('NodeSettings', 'URLJumpsContainerNodeID');
    $shortURLMode = $iniFile->variable('URLJumpSettings', 'ShortURLMode');

    $base = strlen($codeset);
    
    $path[] = array( 'url'       => false,
                 'url_alias' => false,
                 'node_id'   => 0,
                 'text'      => 'eZ URL Jump');

    $ezurljumpID = createObject($user_id, $containerNodeID, $url, md5($url), 'url_jump', array(
											array('ezidentifier' => ''),
											array('ezstring' => $url),
											array('ezurl' => array($url, $url)),
											));
																						
    $n = $ezurljumpID + $base;
    $converted = "";

    while ($n > 0) {                                                                                                                                                                                                                                                           
      $converted = substr($codeset, ($n % $base), 1) . $converted;                                                                                                                                                                                                             
      $n = floor($n/$base);                                                                                                                                                                                                                                                    
    }

    switch($shortURLMode) {
        case 'rewrite':
    	$tpl->setVariable('shortURL', "http://{$_SERVER['HTTP_HOST']}/{$converted}");
        break;
        
        default:
    	echo $tpl->setVariable('shortURL', "http://{$_SERVER['HTTP_HOST']}/ezurljump/out?id={$converted}");
        break;
    }
}
$Result['content'] = $tpl->fetch("design:ezurljump/in.tpl");
?>
