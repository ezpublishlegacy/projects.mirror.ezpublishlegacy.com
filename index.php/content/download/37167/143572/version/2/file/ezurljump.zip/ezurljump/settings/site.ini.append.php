[RoleSettings] 
PolicyOmitList[]=ezurljump/in
PolicyOmitList[]=ezurljump/out
