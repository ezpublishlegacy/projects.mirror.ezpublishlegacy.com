<?php
include_once ('kernel/common/template.php');

$Module = $Params['Module'];
$redirID = $Params['redirID'];
$http = eZHTTPTool::instance();
$tpl = templateInit();

$iniFile = eZINI::instance('ezurljump.ini');                                                                                                                                                                                                    
$codeset = $iniFile->variable('URLJumpSettings', 'CodeSet');
$containerNodeID = $iniFile->variable('NodeSettings', 'URLJumpsContainerNodeID');

$base = strlen($codeset);
    
$path[] = array( 'url'       => false,
                 'url_alias' => false,
                 'node_id'   => 0,
                 'text'      => 'eZ URL Jump');

$Result = array();
$Result['pagelayout'] = false;

$c = 0;
$converted = $http->variable('id');
if(empty($converted)) $converted = $redirID;

for ($i = strlen($converted); $i; $i--) {                                                                                                                                                                                                                                  
  $c += strpos($codeset, substr($converted, (-1 * ( $i - strlen($converted) )),1))                                                                                                                                                                                         
          * pow($base,$i-1);                                                                                                                                                                                                                                                 
}
$URLJumpID = $c - $base;

$objectList = eZFunctionHandler::execute('content', 'list', array('parent_node_id' => $containerNodeID,                                                                                                                                                                                
        'class_filter_type' => 'include',
        'class_filter_array' => array('url_jump'),                                                                                                                                                                                                                 
        'attribute_filter' => array('or',
		                array('url_jump/id', '=', $URLJumpID)
		              )                                                                                                                                                                                                                                                              
	)); 

if($objectList) {
    $object = $objectList[0]->object();
    $datamap = $object->dataMap();
    $counter = $datamap['hits'];
    $counter->setAttribute('data_int', $counter->attribute('data_int') + 1);
    $db = eZDB::instance();                                                                                                                                                                                                                                            
    $db->begin();
    $counter->store();
    $db->commit();

    header("Location: ". $datamap['url']->content());
}
?>
