Extended filter on EOR fields
=============================

Author
------
Bertrand Dunogier <bd at ez dot no>

Synopsis
--------
Allows filtering of enhanced object relation attributes based on related object
id or ids.

Installation
------------
Activate the extension.

Usage
-----
This filter is used like any extended attribute filter, as explained on the
documentation for the content/list fetch function:
http://ez.no/doc/ez_publish/technical_manual/3_8/reference/modules/content/fetch_functions/list

The extended attribute filter fetch parameter must be provided with the filter name,
as well as with the list of the filtering parameters as an array:

fetch(content, list, hash(parent_node_id, XX,
                          extended_attribute_filter, hash(
                              'id', 'eorfilter',
                              'params', array(
                                array('eor_filtering_test/multiple_relation', 61)
                              )
                          )))
The function will return every instance of the eor_filtering_test with an attribute
called multiple_relation that has a relation to the object with object id 62. This
will work with single relations as well as multiple.

Limits of the current implementation
------------------------------------
With this implementation, it is not possible to filter using an OR boolean filtering.
It is possible to implement that feature if needed.