<?php /* #?ini charset="iso-8859-1"?

[eorfilter]
ExtensionName=eorfiltering
ClassName=EORExtendedFilter
MethodName=CreateSqlParts
FileName=classes/eorfilter.php

*/ ?>