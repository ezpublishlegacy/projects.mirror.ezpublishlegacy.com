<?php

class ezonrailsInfo
{
    static function info()
    {
        return array( 'Name' => 'eZ On Rails extension',
                      'Version' => '0.2,
                      'Copyright' => 'Copyright (C) 2010-2011 G. Giunta',
                      'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
