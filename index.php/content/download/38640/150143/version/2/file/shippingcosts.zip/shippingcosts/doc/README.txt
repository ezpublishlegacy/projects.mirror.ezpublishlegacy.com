Workflow for adding different simple shipping cost depending on the total product sum.
If the product sum ist less that 100, no shipping cost will be added.

Shipping cost and free limit can be defined within the /shippingcosts/settings/workflow.ini.append

[ShippingCostWorkflow]
Freelimit=100
Cost=5.00
Description=Versandkosten


Author:
Norman Leutner <n.leutner@all2e.com>, all2e GmbH Germany

Setup:
Install extension. 
Edit  /shippingcosts/settings/workflow.ini.append
Create a new workflow
Use confirmorder / before