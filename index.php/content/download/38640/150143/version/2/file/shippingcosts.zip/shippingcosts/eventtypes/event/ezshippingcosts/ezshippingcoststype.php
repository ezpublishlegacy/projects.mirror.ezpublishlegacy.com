<?php
//
// Definition of shippingcosts class
//
// Created on: <2006-03-28 N. Leutner>
//
// Copyright (C) 2006 all2e GmbH. All rights reserved.
//

/*! \file ezshippingcosts.php
*/
include_once( 'kernel/classes/ezorderitem.php' );
include_once( "kernel/classes/ezorder.php" );

define( 'EZ_WORKFLOW_TYPE_SHIPPINGCOSTS_ID', 'ezshippingcosts' );

class eZShippingCostsType extends eZWorkflowEventType
{
    /*!
     Constructor
    */
    function eZShippingCostsType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_SHIPPINGCOSTS_ID, ezi18n( 'kernel/workflow/event', "Shipping Costs" ) );
    }

    function execute( &$process, &$event )
    {
        $ini =& eZINI::instance( 'workflow.ini' );

        $freelimit = $ini->variable( "ShippingCostWorkflow", "Freelimit" );
        $cost = $ini->variable( "ShippingCostWorkflow", "Cost" );
        $description = $ini->variable( "ShippingCostWorkflow", "Description" );

        $parameters = $process->attribute( 'parameter_list' );
        $orderID = $parameters['order_id'];

        $order = eZOrder::fetch( $orderID );
        $orderItems = $order->attribute( 'order_items' );
        $addShipping = true;


        if($order->attribute( 'product_total_ex_vat' ) <= $freelimit)
        {

          foreach ( array_keys( $orderItems ) as $key )
          {
              $orderItem =& $orderItems[$key];
              if ( $orderItem->attribute( 'description' ) == $description )
              {
                  $addShipping = false;
                  break;
              }
          }
          if ( $addShipping )
          {
              $orderItem = new eZOrderItem( array( 'order_id' => $orderID,
                                                   'description' => $description,
                                                   'price' => $cost,
                                                   'vat_is_included' => false,
                                                   'vat_type_id' => 1 )
                                            );
              $orderItem->store();
          }

        }


        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_SHIPPINGCOSTS_ID, "ezshippingcoststype" );

?>
