[TemplateSettings]
ExtensionAutoloadPath[]=collectexport

[RegionalSettings]
TranslationExtensions[]=collectexport

[RoleSettings]
PolicyOmitList[]=collectexport/overview
PolicyOmitList[]=collectexport/export
PolicyOmitList[]=collectexport/doexport