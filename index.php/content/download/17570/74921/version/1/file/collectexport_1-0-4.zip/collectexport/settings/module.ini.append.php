[ModuleSettings]
ExtensionRepositories[]=collectexport
