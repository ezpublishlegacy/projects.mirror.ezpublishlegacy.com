<!DOCTYPE TS><TS>
<context>
    <name>design/collectexport/overview</name>
    <message>
        <source>Collected informations</source>
        <translation>Zebrane informacje</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Export</translation>
    </message>
</context>
<context>
    <name>design/admin/infocollector/overview</name>
    <message>
        <source>There are no objects that have collected any information.</source>
	<translation>Nie ma żadnych obiektów, które posiadają jakiekolwiek zebrane informacje.</translation>
    </message>
</context>
<context>
    <name>extension/collectexport</name>
    <message>
        <source>Collected information export</source>
        <translation>Zebrane informacje export</translation>
    </message>
</context>
<context>
    <name>design/collectexport/export</name>    
    <message>
        <source>Field #%counter</source>
        <translation>Pole #%counter</translation>
    </message>
    <message>
        <source>Content object id</source>
        <translation>ID obiektu przechowującego</translation>
    </message>
    <message>
        <source>Leave empty (note: field still gets created)</source>
        <translation>Pozostaw pustą kolumną</translation>
    </message>
    <message>
        <source>Ignore (note: field doesn't get created at all)</source>
        <translation>Ignoruj kolumnę (uwaga: pole nie zostanie utworzone)</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Typ exportu</translation>
    </message>
    <message>
        <source>Separation char for CSV export</source>
        <translation>Znak separacji dla exportu do CSV</translation>
    </message>
    <message>
        <source>Semicolon</source>
        <translation>Średnik</translation>
    </message>
    <message>
        <source>Comma</source>
        <translation>Przecinek</translation>
    </message>
    <message>
        <source>Colon</source>
        <translation>Dwukropek</translation>
    </message>
    <message>
        <source>Pipe</source>
        <translation>Pionowa kreska</translation>
    </message>
    <message>
        <source>Hash</source>
        <translation>Krzyżyk</translation>
    </message>
    <message>
        <source>Do export</source>
        <translation>Wykonaj export</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Początkowa data</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Dzień</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Miesiąc</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Rok</translation>
    </message>
    <message>
        <source>End Date</source>
        <translation>Końcowa data</translation>
    </message>
</context>
</TS>
