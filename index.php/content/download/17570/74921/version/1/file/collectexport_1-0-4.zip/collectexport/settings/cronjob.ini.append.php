<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=collectexport

[CronjobPart-exportcsv]
Scripts[]
Scripts[]=exportcsv.php

[CronjobPart-exportsylk]
Scripts[]
Scripts[]=exportsylk.php

*/ ?>