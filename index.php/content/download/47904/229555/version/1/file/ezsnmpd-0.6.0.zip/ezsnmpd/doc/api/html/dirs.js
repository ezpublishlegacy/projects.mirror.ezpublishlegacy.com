var dirs =
[
    [ "bin", "dir_9293f2e834caa6130cf79637e18afc26.html", "dir_9293f2e834caa6130cf79637e18afc26" ],
    [ "classes", "dir_5e773a089199521db463eb7aadce0e8a.html", null ],
    [ "interfaces", "dir_5a39fbe0c377ff96ee239c857a12b414.html", null ],
    [ "modules", "dir_6395d16142dfc1dbc9a31202cad0bf6d.html", "dir_6395d16142dfc1dbc9a31202cad0bf6d" ]
];