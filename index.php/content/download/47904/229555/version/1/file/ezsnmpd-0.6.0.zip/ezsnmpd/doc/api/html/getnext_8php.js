var getnext_8php =
[
    [ "$oid", "getnext_8php.html#a0e103adb6e19b5bb07021935b3a7383c", null ],
    [ "$response", "getnext_8php.html#af4b6fb1bbc77ccc05f10da3b16935b99", null ]
];