<?php
class ezsnmpdInfo
{
    static function info()
    {
        return array( 'Name' => "ezsnmpd",
                      'Version' => eZSNMPd::VERSION,
                      'Copyright' => "Copyright (C) 2009-2012 G. Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>