<?php /*

[Leftmenu_setup]
Links[snmp]=snmp/mib/html
LinkNames[snmp]=SNMP Monitoring

*/ ?>
