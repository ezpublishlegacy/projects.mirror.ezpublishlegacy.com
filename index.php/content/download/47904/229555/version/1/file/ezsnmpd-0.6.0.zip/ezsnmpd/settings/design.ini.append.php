<?php /*

[ExtensionSettings]
DesignExtensions[]=ezsnmpd

*/ ?>
