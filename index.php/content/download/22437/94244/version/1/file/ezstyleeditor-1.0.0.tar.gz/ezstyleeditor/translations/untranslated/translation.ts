<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/datatype/edit/ezcssstyle</name>
    <message>
        <source>New CSS rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alias:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selector:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move up.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JSON</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/datatype/edit/ezcssstyle_images</name>
    <message>
        <source>Current image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No image selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Available images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload new image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
