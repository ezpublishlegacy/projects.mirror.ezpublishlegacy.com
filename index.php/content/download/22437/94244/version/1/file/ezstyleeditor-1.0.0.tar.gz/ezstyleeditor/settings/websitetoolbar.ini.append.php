<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=styleeditor

IncludeInView[styleeditor]=full

*/ ?>