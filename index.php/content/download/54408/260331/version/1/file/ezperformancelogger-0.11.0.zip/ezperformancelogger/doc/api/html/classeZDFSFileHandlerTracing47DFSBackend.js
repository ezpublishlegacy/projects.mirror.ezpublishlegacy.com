var classeZDFSFileHandlerTracing47DFSBackend =
[
    [ "accumulatorStart", "classeZDFSFileHandlerTracing47DFSBackend.html#aafe64b311b56f31fe96b0d411bbfd493", null ],
    [ "accumulatorStop", "classeZDFSFileHandlerTracing47DFSBackend.html#ac402997931e4c2ce4571b5fb3ecbaeec", null ],
    [ "measure", "classeZDFSFileHandlerTracing47DFSBackend.html#aa6d1003960442f7baffe61639c2474a1", null ],
    [ "supportedVariables", "classeZDFSFileHandlerTracing47DFSBackend.html#aefc8e604c42afb2ba0675eb42905e63d", null ]
];