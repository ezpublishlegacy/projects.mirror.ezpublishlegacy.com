var classeZMySQLiTracing47DB =
[
    [ "__construct", "classeZMySQLiTracing47DB.html#a7feadcb8d45454e5ced9d2dc15f49b5a", null ],
    [ "arrayQuery", "classeZMySQLiTracing47DB.html#ae7dced7ac14ae482b2e26a176689c9aa", null ],
    [ "connect", "classeZMySQLiTracing47DB.html#aaeba0c50a2b9b369dff267e258dc194c", null ],
    [ "measure", "classeZMySQLiTracing47DB.html#a2ceaf41117f38f288f8f410ce8337747", null ],
    [ "query", "classeZMySQLiTracing47DB.html#add60e8dd6e565ec10bbc45ae76632f70", null ],
    [ "supportedVariables", "classeZMySQLiTracing47DB.html#ac19e5a5b0b2ae0f2fb8a38a5f195927f", null ]
];