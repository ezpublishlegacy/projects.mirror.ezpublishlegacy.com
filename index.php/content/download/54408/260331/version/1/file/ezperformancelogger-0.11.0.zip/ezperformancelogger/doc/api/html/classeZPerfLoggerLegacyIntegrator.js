var classeZPerfLoggerLegacyIntegrator =
[
    [ "getContainer", "classeZPerfLoggerLegacyIntegrator.html#af839a8bca1263f68669523effcccfbde", null ],
    [ "init", "classeZPerfLoggerLegacyIntegrator.html#a88e0bca2165df30340d8a9b36369d4ad", null ],
    [ "isLegacyContext", "classeZPerfLoggerLegacyIntegrator.html#afa92ceb49450748be6d78d4381eb1447", null ],
    [ "$kernel", "classeZPerfLoggerLegacyIntegrator.html#afd7729c08e2b6b826bef5c1b8c0e112b", null ]
];