var classeZDFSTracing47FileHandler =
[
    [ "measure", "classeZDFSTracing47FileHandler.html#acb728e199052bc7d1a7c845c757123f9", null ],
    [ "processCache", "classeZDFSTracing47FileHandler.html#ac016ddf9133588263f1ddb5a43ccc9dc", null ],
    [ "supportedVariables", "classeZDFSTracing47FileHandler.html#a956975daf1c9c3be24edee52f6943854", null ]
];