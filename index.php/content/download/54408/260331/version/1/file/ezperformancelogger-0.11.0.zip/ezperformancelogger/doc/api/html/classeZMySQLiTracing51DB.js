var classeZMySQLiTracing51DB =
[
    [ "__construct", "classeZMySQLiTracing51DB.html#a44975cdd1cb851405ca85f682635c80a", null ],
    [ "arrayQuery", "classeZMySQLiTracing51DB.html#aca762e721b44c2f32336be3cae2af36d", null ],
    [ "connect", "classeZMySQLiTracing51DB.html#af02d8fb591653ad89de23d05b164d202", null ],
    [ "measure", "classeZMySQLiTracing51DB.html#a7d98da521ea03dce3c822c1dd4f4ec43", null ],
    [ "query", "classeZMySQLiTracing51DB.html#a689aec44ef4f6485e72ea3342f72a6e6", null ],
    [ "supportedVariables", "classeZMySQLiTracing51DB.html#a31bba5a57b6bac0303bcc9319d84ece6", null ]
];