var classeZDFSFileHandlerTracing45DFSBackend =
[
    [ "accumulatorStart", "classeZDFSFileHandlerTracing45DFSBackend.html#adcb4d755dd7b72ecdcc6002143fdc5ce", null ],
    [ "accumulatorStop", "classeZDFSFileHandlerTracing45DFSBackend.html#a73b40efab8aeaed49a5c4199835627db", null ],
    [ "measure", "classeZDFSFileHandlerTracing45DFSBackend.html#a2ca2c931adea52449700610787ab602b", null ],
    [ "supportedVariables", "classeZDFSFileHandlerTracing45DFSBackend.html#a0f3f3f269d44301c1fbd8cfc2361bf19", null ]
];