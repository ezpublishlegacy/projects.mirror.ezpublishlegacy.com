var classeZDFSTracing46FileHandler =
[
    [ "measure", "classeZDFSTracing46FileHandler.html#a70b27d41bfae95672261d173b733fbaa", null ],
    [ "processCache", "classeZDFSTracing46FileHandler.html#a142fca9abd22b0109977a4d2b20c84cf", null ],
    [ "supportedVariables", "classeZDFSTracing46FileHandler.html#a31fb216b45c2e858c37d2eee51046b18", null ]
];