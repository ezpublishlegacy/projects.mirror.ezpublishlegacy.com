var classeZPerfLoggerDebug =
[
    [ "isDebugEnabled", "classeZPerfLoggerDebug.html#ad037edbff1cb0cbca60de0b611bc8233", null ],
    [ "writeDebug", "classeZPerfLoggerDebug.html#ab84b8573abf823c2c5b61b3570f7e959", null ],
    [ "writeError", "classeZPerfLoggerDebug.html#a99509c8db3b6799b262d580b86d58b54", null ],
    [ "writeWarning", "classeZPerfLoggerDebug.html#aad9817e8b4b9eb0ac7f15b39e9cb6aaa", null ]
];