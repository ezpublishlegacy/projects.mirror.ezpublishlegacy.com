var dir_bf4a7340bf97bbf1924e7c2c515068c7 =
[
    [ "extractdatafromaccesslog.php", "extractdatafromaccesslog_8php.html", "extractdatafromaccesslog_8php" ],
    [ "muninplugin.php", "muninplugin_8php.html", "muninplugin_8php" ],
    [ "rotateperflogs.php", "bin_2php_2rotateperflogs_8php.html", "bin_2php_2rotateperflogs_8php" ],
    [ "updateperfstats.php", "bin_2php_2updateperfstats_8php.html", "bin_2php_2updateperfstats_8php" ]
];