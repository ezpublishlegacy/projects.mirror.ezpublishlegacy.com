var dir_54fc5754beecd7afa4fe33ae69670f62 =
[
    [ "ezperfLoggermemoryhungrypagesfilter.php", "ezperfLoggermemoryhungrypagesfilter_8php.html", [
      [ "eZPerfLoggerMemoryhungrypagesFilter", "classeZPerfLoggerMemoryhungrypagesFilter.html", "classeZPerfLoggerMemoryhungrypagesFilter" ]
    ] ],
    [ "ezperfloggerrandomfilter.php", "ezperfloggerrandomfilter_8php.html", [
      [ "eZPerfLoggerRandomFilter", "classeZPerfLoggerRandomFilter.html", "classeZPerfLoggerRandomFilter" ]
    ] ],
    [ "ezperfLoggerslowpagesfilter.php", "ezperfLoggerslowpagesfilter_8php.html", [
      [ "eZPerfLoggerSlowpagesFilter", "classeZPerfLoggerSlowpagesFilter.html", "classeZPerfLoggerSlowpagesFilter" ]
    ] ]
];