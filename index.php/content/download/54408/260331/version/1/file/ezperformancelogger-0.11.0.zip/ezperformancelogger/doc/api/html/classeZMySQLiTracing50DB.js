var classeZMySQLiTracing50DB =
[
    [ "__construct", "classeZMySQLiTracing50DB.html#a15f7c49534ecb965a403e2b83f4f9d7c", null ],
    [ "arrayQuery", "classeZMySQLiTracing50DB.html#aaa2c148cf3aac3639a302ac4c0cd654d", null ],
    [ "connect", "classeZMySQLiTracing50DB.html#a5006432c5293dedca1c52ec86e2f426d", null ],
    [ "measure", "classeZMySQLiTracing50DB.html#a5f63af9f4fb1dffb68a0d8ca0f9ee549", null ],
    [ "query", "classeZMySQLiTracing50DB.html#a55238d8834a04a25d842766b1cfe4f78", null ],
    [ "supportedVariables", "classeZMySQLiTracing50DB.html#a01b4c6a3a07f3ccfceeb629eb06fbaec", null ]
];