var classeZMySQLiTracing45DB =
[
    [ "__construct", "classeZMySQLiTracing45DB.html#a6c7e601f4170561a80e7b48ebec56b6d", null ],
    [ "arrayQuery", "classeZMySQLiTracing45DB.html#ac3713c3352efd2498c777eb273a04f64", null ],
    [ "connect", "classeZMySQLiTracing45DB.html#a0b1503e22af7d5032670f51530dcc465", null ],
    [ "measure", "classeZMySQLiTracing45DB.html#a0e864a86637b426e7eedec6d8e520fff", null ],
    [ "query", "classeZMySQLiTracing45DB.html#af0402a81dddd48daa91e509a944f8667", null ],
    [ "supportedVariables", "classeZMySQLiTracing45DB.html#a6efd85157ad14c6a44ab25606f612d6a", null ]
];