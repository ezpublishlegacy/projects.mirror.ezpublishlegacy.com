var classeZImageTracing50ShellHandler =
[
    [ "convert", "classeZImageTracing50ShellHandler.html#ada91829f819ca90923aee6fcc8c42560", null ],
    [ "createFromINI", "classeZImageTracing50ShellHandler.html#a4bd76b7b4f4dfd06f00c13bbea3287b3", null ],
    [ "measure", "classeZImageTracing50ShellHandler.html#a0f4c423dbc565b7dd61ac02a52983b4b", null ],
    [ "supportedVariables", "classeZImageTracing50ShellHandler.html#aea8f7556a8dd4ad6d1827fb4f48b3afc", null ]
];