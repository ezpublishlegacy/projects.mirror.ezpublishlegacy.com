var classeZDFSTracing45FileHandler =
[
    [ "measure", "classeZDFSTracing45FileHandler.html#a1f16fc5a26bd90118d26e1d7e6a0604a", null ],
    [ "processCache", "classeZDFSTracing45FileHandler.html#ad51ac202fc6b024f86fc5e2882191b37", null ],
    [ "supportedVariables", "classeZDFSTracing45FileHandler.html#ac5e91d076ef3097d0758a67a5eec1ecc", null ]
];