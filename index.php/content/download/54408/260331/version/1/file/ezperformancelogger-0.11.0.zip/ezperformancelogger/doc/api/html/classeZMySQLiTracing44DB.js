var classeZMySQLiTracing44DB =
[
    [ "__construct", "classeZMySQLiTracing44DB.html#a8b32248a66f97c385cb544edbe6561ff", null ],
    [ "arrayQuery", "classeZMySQLiTracing44DB.html#a77f391bbfef0e79a736688d031e7d2ad", null ],
    [ "connect", "classeZMySQLiTracing44DB.html#a4bdadc575d5aa089405b32b6e5c1386c", null ],
    [ "measure", "classeZMySQLiTracing44DB.html#acd31065c97ab6c10acc14b98dc16b91f", null ],
    [ "query", "classeZMySQLiTracing44DB.html#ac553dd4d27ec657e1ae02ed8c5edead4", null ],
    [ "supportedVariables", "classeZMySQLiTracing44DB.html#a6c5272cb092e1edecae02194d40b8ac6", null ]
];