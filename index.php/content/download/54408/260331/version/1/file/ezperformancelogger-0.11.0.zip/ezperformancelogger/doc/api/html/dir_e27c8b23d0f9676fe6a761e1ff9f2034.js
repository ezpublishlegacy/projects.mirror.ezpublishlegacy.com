var dir_e27c8b23d0f9676fe6a761e1ff9f2034 =
[
    [ "removexhprofdata.php", "removexhprofdata_8php.html", null ],
    [ "rotateperflogs.php", "cronjobs_2rotateperflogs_8php.html", "cronjobs_2rotateperflogs_8php" ],
    [ "updateperfstats.php", "cronjobs_2updateperfstats_8php.html", "cronjobs_2updateperfstats_8php" ]
];