var classeZDFSTracing50FileHandler =
[
    [ "measure", "classeZDFSTracing50FileHandler.html#a3765fbc59154c0f539727f0f421ce0ad", null ],
    [ "processCache", "classeZDFSTracing50FileHandler.html#aad0c7a4dae8803fd84c02e8221a48d7f", null ],
    [ "supportedVariables", "classeZDFSTracing50FileHandler.html#ad000c159d4e84932ffe7715efdd3c0a6", null ]
];