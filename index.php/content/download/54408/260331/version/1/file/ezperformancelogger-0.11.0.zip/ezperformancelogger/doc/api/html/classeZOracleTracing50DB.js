var classeZOracleTracing50DB =
[
    [ "analyseQuery", "classeZOracleTracing50DB.html#a263f59fe2b2f708d15b6836e9ba28f6a", null ],
    [ "arrayQuery", "classeZOracleTracing50DB.html#a61efe2502f32f03be5f141614f1a7380", null ],
    [ "close", "classeZOracleTracing50DB.html#a419dcc5dfa7a4196c40a7b722417c422", null ],
    [ "commitQuery", "classeZOracleTracing50DB.html#a644cfd7bf86b8eeadfbb7bf7deca66da", null ],
    [ "eZOracleTracing50DB", "classeZOracleTracing50DB.html#aa5bc684b6564173fdd7a1533fdefaa07", null ],
    [ "measure", "classeZOracleTracing50DB.html#a0db72bd9f03c79a86972c90711bb9f5e", null ],
    [ "query", "classeZOracleTracing50DB.html#ab758e96f4f153e939c7833c40bdfad4a", null ],
    [ "rollbackQuery", "classeZOracleTracing50DB.html#a33cfe53cb41014fc54cd85e089e9b634", null ],
    [ "supportedVariables", "classeZOracleTracing50DB.html#a3a20e85478fb1d4e49f69f0292a8fe19", null ]
];