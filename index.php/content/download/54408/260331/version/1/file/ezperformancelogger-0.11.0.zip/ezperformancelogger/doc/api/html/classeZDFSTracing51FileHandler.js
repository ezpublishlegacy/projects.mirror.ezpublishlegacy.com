var classeZDFSTracing51FileHandler =
[
    [ "measure", "classeZDFSTracing51FileHandler.html#aa85261cf46a10d6fd43f6c9e800a3a8d", null ],
    [ "processCache", "classeZDFSTracing51FileHandler.html#a25b8d52eacf04b47f15a8ed62e946937", null ],
    [ "supportedVariables", "classeZDFSTracing51FileHandler.html#a38fd6cdf519fc07d0a5027be29e360a5", null ]
];