var classeZPerfLoggerSlowpagesFilter =
[
    [ "shouldLog", "classeZPerfLoggerSlowpagesFilter.html#a95470eb16a1f4fe09206f0b373942df4", null ]
];