var classeZDFSFileHandlerTracing44DFSBackend =
[
    [ "accumulatorStart", "classeZDFSFileHandlerTracing44DFSBackend.html#aab14365d2f97d619ccc2c1b3a0c92061", null ],
    [ "accumulatorStop", "classeZDFSFileHandlerTracing44DFSBackend.html#a96bcdae9cd3abbe492f0dbf94dfb7efd", null ],
    [ "measure", "classeZDFSFileHandlerTracing44DFSBackend.html#a994843aa9c278d664f3c8bd144fdaa6b", null ],
    [ "supportedVariables", "classeZDFSFileHandlerTracing44DFSBackend.html#aef95eef87b8ae56eea0dc9fbef71c3ea", null ]
];