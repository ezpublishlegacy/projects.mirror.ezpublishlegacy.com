var classeZDFSTracing44FileHandler =
[
    [ "measure", "classeZDFSTracing44FileHandler.html#ac9286fb80a71df955abf435e7680bd35", null ],
    [ "processCache", "classeZDFSTracing44FileHandler.html#aceff19befa74f2a86092a37814d149ec", null ],
    [ "supportedVariables", "classeZDFSTracing44FileHandler.html#a098f8178c62147210dea1985d27e5198", null ]
];