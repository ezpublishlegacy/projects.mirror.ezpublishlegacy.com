var classeZImageTracing47ShellHandler =
[
    [ "convert", "classeZImageTracing47ShellHandler.html#a337d6661f98cb91d5b834b9b18bef18c", null ],
    [ "createFromINI", "classeZImageTracing47ShellHandler.html#ac7f77454472401e6342bb8e0bc5b52a4", null ],
    [ "measure", "classeZImageTracing47ShellHandler.html#a72488e2c7cc25805df273cd0a1b8811e", null ],
    [ "supportedVariables", "classeZImageTracing47ShellHandler.html#a614749ceb3c8a9e6a46a73b7d6d65357", null ]
];