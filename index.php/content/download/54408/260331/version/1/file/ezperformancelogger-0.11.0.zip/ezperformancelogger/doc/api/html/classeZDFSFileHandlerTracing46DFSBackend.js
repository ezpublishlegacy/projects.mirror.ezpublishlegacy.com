var classeZDFSFileHandlerTracing46DFSBackend =
[
    [ "accumulatorStart", "classeZDFSFileHandlerTracing46DFSBackend.html#a12c800a6d46f544534499d6c36fb6a80", null ],
    [ "accumulatorStop", "classeZDFSFileHandlerTracing46DFSBackend.html#ac1211b019fd0144cb0c084f21996e7c3", null ],
    [ "measure", "classeZDFSFileHandlerTracing46DFSBackend.html#a239f0ae7e6816513cd4b84c62df2cac7", null ],
    [ "supportedVariables", "classeZDFSFileHandlerTracing46DFSBackend.html#a234514ad29f68177cd20306a523f637f", null ]
];