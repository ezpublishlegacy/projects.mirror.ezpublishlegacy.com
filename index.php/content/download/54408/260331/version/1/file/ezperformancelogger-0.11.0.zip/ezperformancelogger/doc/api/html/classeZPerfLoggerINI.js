var classeZPerfLoggerINI =
[
    [ "getConfigResolver", "classeZPerfLoggerINI.html#a27af5d48d00266d4da3afb632278e270", null ],
    [ "hasVariable", "classeZPerfLoggerINI.html#a561352c87620b4e8184644767d54a127", null ],
    [ "init", "classeZPerfLoggerINI.html#a7dfa69afd8cb1001b109e81d9367c147", null ],
    [ "setConfigResolver", "classeZPerfLoggerINI.html#a67dbb8dff8001bb76c4067e2f03ebaaf", null ],
    [ "variable", "classeZPerfLoggerINI.html#a9932e16105e92a0b3684f593b1dafa3e", null ],
    [ "variableMulti", "classeZPerfLoggerINI.html#ab083a605f7c561bb611bcf5f3bbc055c", null ],
    [ "$configResolver", "classeZPerfLoggerINI.html#a18137b600652db8936dc6f9d7275e259", null ]
];