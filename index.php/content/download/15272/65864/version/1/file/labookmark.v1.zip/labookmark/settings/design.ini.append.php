<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=labookmark

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
JavaScriptList[]=jquery-1.2.6.js
JavaScriptList[]=jquery.menu.min.js
JavaScriptList[]=jquery.autocomplete.min.js
JavaScriptList[]=labookmark.js

[StylesheetSettings]
CSSFileList[]=labookmark.css
CSSFileList[]=jquery.autocomplete.css

*/
?>