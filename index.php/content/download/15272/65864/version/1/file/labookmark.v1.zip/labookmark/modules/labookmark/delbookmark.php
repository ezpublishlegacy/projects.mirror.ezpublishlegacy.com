<?php
$http = eZHTTPTool::instance();
$nodeID = $http->postVariable( 'node_id' );
        
$userId = eZUser::currentUserID();
LABookmark::removeByNodeIDForUser( $userId, $nodeID );
$cache_file = "var/cache/cache-bookmark-" . $userId . ".cache";
unlink($cache_file);
eZExecution::cleanExit();

?>