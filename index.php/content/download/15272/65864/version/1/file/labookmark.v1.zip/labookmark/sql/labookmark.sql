ALTER TABLE `ezcontentbrowsebookmark` ADD `category` VARCHAR( 100 ) NOT NULL AFTER `user_id` ;
ALTER TABLE `ezcontentbrowsebookmark` ADD INDEX ( `category` ) ;