<?php
$http = eZHTTPTool::instance();
$nodeID = $http->postVariable( 'node_id' );
$category = $http->postVariable( 'category' );
$nodeName = $http->postVariable( 'node_name' );
        
$userId = eZUser::currentUserID();
LABookmark::createNew( $userId, $nodeID, $nodeName, $category );
$cache_file = "var/cache/cache-bookmark-" . $userId . ".cache";
unlink($cache_file);
eZExecution::cleanExit();

?>