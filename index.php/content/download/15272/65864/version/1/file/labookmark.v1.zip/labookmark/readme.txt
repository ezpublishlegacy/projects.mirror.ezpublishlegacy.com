/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
 * 
 /

Requirement
Ez4.x 

Description
Manage customer bookmark by category for editors in BackOffice

Install
1. excute sql/labookmark.sql in mysql
2. active the extension in Backoffice
3. clear override cache
4. add policy to editor group