<?php
/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
 */
$Module = array( "name" => "labookmark" ,
                 "variable_params" => true );
                 

$ViewList = array();
$ViewList["getbookmark"] = array("script" => "getbookmark.php" , 
							"params" => array( "") );
$ViewList["addbookmark"] = array("script" => "addbookmark.php" , 
							"params" => array( "") );              
$ViewList["delbookmark"] = array("script" => "delbookmark.php" , 
							"params" => array( "") );   							
?>