<?php
/**
// Created on: <2009-03-20 by LIU Bin bin.liu@lagardere-active.com>
 *
 */
$FunctionList = array();

$FunctionList['bookmark'] = array( 'name' => 'bookmark',
                                    'operation_types' => array( 'read' ),
                                    'call_method' => array( 'class' => 'labookmarkFunctionCollection',
                                                            'method' => 'fetchBookmarks' ),
                                    'parameter_type' => 'standard',
                                    'parameters' => array( array( 'name' => 'offset',
                                                                  'type' => 'integer',
                                                                  'required' => false,
                                                                  'default' => false ),
                                                           array( 'name' => 'limit',
                                                                  'type' => 'integer',
                                                                  'required' => false,
                                                                  'default' => false ) ) );
                                                               

$FunctionList['category'] = array( 'name' => 'category',
                                    'operation_types' => array( 'read' ),
                                    'call_method' => array( 'class' => 'labookmarkFunctionCollection',
                                                            'method' => 'fetchBookmarksCategory' ),
                                    'parameter_type' => 'standard',
                                    'parameters' => array( array( 'name' => 'offset',
                                                                  'type' => 'integer',
                                                                  'required' => false,
                                                                  'default' => false ),
                                                           array( 'name' => 'limit',
                                                                  'type' => 'integer',
                                                                  'required' => false,
                                                                  'default' => false ) ) );                                                                  
?>