<?php
include_once( 'kernel/common/template.php' );
$cache_file = "var/cache/cache-bookmark-" . eZUser::currentUserID() . ".cache";
if(file_exists($cache_file))
{
	echo file_get_contents($cache_file);
}
else 
{
	$tpl = templateInit();
	$content = $tpl->fetch( 'design:labookmark/listbookmark.tpl' );
	$fp = fopen($cache_file, 'w');
	fwrite($fp, $content);
	fclose($fp);
	echo $content;
}
eZExecution::cleanExit();
?>