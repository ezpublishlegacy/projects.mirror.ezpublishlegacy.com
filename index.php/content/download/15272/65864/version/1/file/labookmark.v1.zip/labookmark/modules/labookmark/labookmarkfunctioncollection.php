<?php
/**
// Created on: <2007-12-20 by LIU Bin bin.liu@lagardere-active.com>
 *
 */
class labookmarkFunctionCollection extends eZContentFunctionCollection
{
    /*!
     Constructor
    */
     function fetchBookmarks( $offset, $limit )
    {
        $user = eZUser::currentUser();
        return array( 'result' => LABookmark::fetchListForUser( $user->id(), $offset, $limit ) );
    }
    
    function fetchBookmarksCategory( $offset, $limit )
    {
        $user = eZUser::currentUser();
        return array( 'result' => LABookmark::fetchCategoryForUser( $user->id(), $offset, $limit ) );    	
    }

}
?>