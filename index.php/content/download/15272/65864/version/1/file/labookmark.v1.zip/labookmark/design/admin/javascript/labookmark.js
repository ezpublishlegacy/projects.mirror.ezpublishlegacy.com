var labookmark = {
	getbookmark : function(url)
	{
		$.ajax( {
					 url: url,
					 success: function(html)
					   {
					 	$('#menuone').html(html);
					 	$('#menuone').menu(); 
					   }
					 });
	},
	addbookmark : function(url,url2,node_id,node_name)
	{
		if(!$("#category").attr("value")){alert("Please entry a category.");return false;}
		var tmp = $("#img-add-bookmark").html();

		$("#img-add-bookmark").html('<a href="javascript:void(0);"><img src="/extension/labookmark/design/admin/images/ajax-loader.gif" alt="Loading" title="Loading" /></a>');
		var param = "category=" + encodeURIComponent($("#category").attr("value")) + "&node_id=" + node_id + "&node_name=" + encodeURIComponent(node_name);
		$.ajax( {
			async : false,
			 url: url, 
			 type:'post',
			 data: param,
			 success: function(){$("#img-add-bookmark").html(tmp);labookmark.getbookmark(url2);}
			 });
	},
	delbookmark : function (url,url2,node_id)
	{
		$(".menu-item").hide();
		$(".menu-div").hide();
		
		var param = "node_id=" + node_id;
		$.ajax( {
			async : false,
			 url: url, 
			 type:'post',
			 data: param,
			 success: function(){labookmark.getbookmark(url2);}
			 });		
	}
}