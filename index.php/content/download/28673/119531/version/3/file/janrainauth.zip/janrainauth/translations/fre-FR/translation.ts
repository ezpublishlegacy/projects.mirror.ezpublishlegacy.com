<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR" sourcelanguage="en_GB">
<context>
    <name>extension/janrainauth/login</name>
    <message>
        <source>Login from external service</source>
        <translation>Connexion depuis un service externe</translation>
    </message>
</context>
</TS>
