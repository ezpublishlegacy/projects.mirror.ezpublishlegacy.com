<?php
/**
 * JanrainAuthException
 * @copyright Copyright (C) 2010 - Jerome Vieilledent. All rights reserved
 * @licence http://www.gnu.org/licenses/gpl-2.0.txt GNU GPLv2
 * @author Jerome Vieilledent
 * @version 1.0
 * @package janrainauth
 */
class JanrainAuthException extends ezcBaseException
{
    
}