<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=janrainauth
ModuleList[]=janrain

*/ ?>