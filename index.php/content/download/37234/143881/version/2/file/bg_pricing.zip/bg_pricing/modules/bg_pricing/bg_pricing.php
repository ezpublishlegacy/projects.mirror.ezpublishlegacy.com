<?php

include_once( "lib/ezdb/classes/ezdb.php" );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezusersetting.php' );

include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( "kernel/classes/ezrole.php" );


class BG_Pricing 
{
	/*!
		Constructor
	*/

	function BG_Pricing()
	{
		$this->pncache = null;
	}

	/* returns an array with the contentnodes of user groups */
	function getUsergroupNodes( )
	{
		$result = array();
		$db =& eZDB::instance();

		$groupQuery = "SELECT ezcontentobject_tree.node_id FROM ezcontentobject, ezcontentobject_tree
				WHERE ezcontentobject.id=ezcontentobject_tree.contentobject_id
				  AND ezcontentobject.contentclass_id=3";
		$groupObject = $db->arrayQuery( $groupQuery );

		foreach ( $groupObject as $group ) 
		{
			$node = eZContentObjectTreeNode::fetch( $group['node_id'] );
			$result[]=$node;
		    // $nodename = $node->attribute('name');
		}
		return $result;
	}

	
	/* for a given array of user or group contentobject_id, 
	return an array of the Section IDs this user or group has access to.
	TBD: does not take class-level access restrictions per sections into account */

	function getSectionsByUserIDArray( $userID_array )
	{
		$accessPolicies = eZRole::accessArrayByUserID( $userID_array );

		$sectionsByUserID = array();
		foreach ( $accessPolicies['content']['read'] as $key => $ap ) {
			foreach( $ap as $k => $sections ) {
				if ( strtolower($k)=="section") {
					foreach ( $sections as $s) {
						$sectionsByUserID[]=$s;
					}
				}
			}
		}
		$sectionsByUserID=array_unique($sectionsByUserID);
		return $sectionsByUserID;
	}



	/* returns an array with the product contentnodes: the result is cached */
	function getProductNodes( )
	{
		if ( $this->pncache == null ) $this->pncache = eZContentObjectTreeNode::subTree( array( 'Depth' => 100,
											 'ClassFilterType' => 'include',
											 'ClassFilterArray' => array('product') ), 2 );
		return $this->pncache;
	}

	/* returns an array with the languages translations used by all products: the result is cached */

	function getProductLanguages( )
	{
		if ( $this->plcache == null )
		{
			$productnodeList = $this->getProductNodes( );

			$languagesUsed = array();
			foreach ( $productnodeList as $productnode ) 
			{
				$contentobjectID = $productnode->attribute( 'contentobject_id' );
				$contentobject =& eZContentObject::fetch( $contentobjectID );
				foreach ( $contentobject->availableLanguages() as $lang)
					$languagesUsed[]=$lang;
			}
			$languagesUsed = array_unique($languagesUsed);
			$this->plcache = $languagesUsed;
		}
		return $this->plcache;
	}

	/* retrieves the product-number, name and a EZprice object
	for a given product contentobject in a given language (current version) */
	function getProductAttributes_Custom1( $product_contentobject, $language )
	{
		$result = array();
		$allEmpty=true;
		$attributePositions = $this->getClassAttributesPositionArray( $product_contentobject ) ;

		$contentObjectAttributes =&$product_contentobject->contentObjectAttributes( false, false, $language, false );

		/* product-number -----------------------------------------------------------*/
		$pos = array_search('product_number', $attributePositions);

		if ( ($pos !== false) && ($pos >= 0) && isset($contentObjectAttributes[$pos]) ) 
		{
			$result[] = $contentObjectAttributes[$pos]->attribute('data_text');$allEmpty=false;
		} else $result[]=false;

		/* name ---------------------------------------------------------------------*/
		$pos = array_search('name', $attributePositions);

		if ( ($pos !== false) && ($pos >= 0) && isset($contentObjectAttributes[$pos]) ) 
		{
			$result[] = $contentObjectAttributes[$pos]->attribute('data_text');$allEmpty=false;
		} else $result[]=false;

		/* price --------------------------------------------------------------------*/
		$pos = array_search('price', $attributePositions);

		if ( ($pos !== false) && ($pos >= 0) && isset($contentObjectAttributes[$pos]) ) 
		{
			$priceObj = $contentObjectAttributes[$pos]->content();$allEmpty=false;
			$result[]=$priceObj;
		}
		else $result[]=false;

		if ($allEmpty) return false; else return $result;
	}



	/* returns an array like 0:name, 1:product_name, ... */
	function getClassAttributesPositionArray( $contentobject ) 
	{
		$result = array();
		$classAttributes = & eZContentClassAttribute::fetchListByClassID( $contentobject->attribute( 'contentclass_id' ) );
		foreach ( $classAttributes as $classAttribute ) {
			$result[] = $classAttribute->attribute('identifier');
		}
		return $result;
	}




	var $pncache = null;	// product nodes
	var $plcache = null;	// language array


}
	



?>
