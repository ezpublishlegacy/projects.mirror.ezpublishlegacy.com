<?php

// Definition
$Module = array("name" => "bg_pricing",
                "variable_params" => true,
                "function" => array("script" => "general.php"));
 
$ViewList = array();

$ViewList['general'] = array('script' => 'general.php',
				  'params' => array(),
				 );






?>
