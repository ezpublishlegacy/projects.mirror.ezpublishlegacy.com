<?php /* #?ini charset="utf-8"?

Part[visual]=bg_pricing


*/ ?>
