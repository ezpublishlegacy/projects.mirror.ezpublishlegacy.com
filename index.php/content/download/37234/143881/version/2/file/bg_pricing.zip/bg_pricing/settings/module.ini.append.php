<?php /* #?ini charset="utf-8"?

# search for modules in bg_pricing

[ModuleSettings]
ExtensionRepositories[]=bg_pricing

*/ ?>


