<?php /* #?ini charset="utf-8"?

# where to pick icons from?

[Pricing]
# debug=on or off
debug=on


*/ ?>


