<?php

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/classes/ezbasket.php' );
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( "lib/ezdb/classes/ezdb.php" );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezusersetting.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezorder.php' );
include_once( 'kernel/classes/ezorderstatus.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( 'kernel/shop/classes/ezshopfunctions.php' );
include_once( 'kernel/shop/classes/ezcurrencydata.php' );
include_once( 'kernel/classes/ezprice.php' );
include_once( "kernel/classes/ezrole.php" );
include_once( "kernel/classes/ezpolicy.php" );
include_once( "kernel/classes/ezpolicylimitation.php" );
require_once( "kernel/user/ezuserfunctioncollection.php" );
require_once( "kernel/section/ezsectionfunctioncollection.php" );

require_once( "extension/bg_pricing/modules/bg_pricing/bg_pricing.php" );


$http =& eZHTTPTool::instance();
$module =& $Params["Module"];
$pricing = new BG_Pricing() ;

$action="";

$error_reason=""; 
if ( isset ($_POST["action"]) ) {
	$action=$_POST["action"];
  	
} 
//------------------------------------------------------------------------------
// get the selected group from all groups                                      /
//------------------------------------------------------------------------------
$groupnodes = $pricing->getUsergroupNodes();
$groupNames = array("ALL");
$groupIDs = array("0");
foreach ($groupnodes as $node) {
	$groupNames[] = $node->attribute('name');
	$groupIDs[] = $node->attribute('contentobject_id');
}

$currentgroupID = 0;
if ( isset ($_POST["groups"]) ) {
	$currentgroupID=$_POST["groups"][0];
} ; 


//------------------------------------------------------------------------------
// get the selected language                                                   /
//------------------------------------------------------------------------------
$langNames = $pricing->getProductLanguages();

/* do we show all products or only the available ones? */

$currentlang=0;
if ( isset ($_POST["currentlang"]) ) {
	$currentlang=$_POST["currentlang"][0];
} else $currentlang=0;

if ( !isset( $langNames[$currentlang] ) ) $currentlang=0;

//------------------------------------------------------------------------------
// get the viewall (yes/no) option                                             /
//------------------------------------------------------------------------------

$viewallNames=array(0=>"no",1=>"yes");
$viewall=0;
if ( isset ($_POST["viewall"]) ) {
	$viewall=$_POST["viewall"][0];
} else $viewall=0;

if ( !isset( $viewallNames[$viewall] ) ) $viewall=0;


// get all products:

$productnodes = $pricing->getProductNodes();

$sectionsByUserID = $pricing->getSectionsByUserIDArray( array($currentgroupID) ) ;	

$matrix = array();

foreach ($productnodes as $productnode) 
{
	$visibility = $productnode->hiddenInvisibleString();
	$contentobjectID = $productnode->attribute( 'contentobject_id' );
	$contentobject =& eZContentObject::fetch( $contentobjectID );
	$sectionID=$contentobject->attribute( 'section_id' );
	$section =& eZSection::fetch( $sectionID );

	/* check object visibility */

	if ( $currentgroupID==0 || in_array( $sectionID, $sectionsByUserID )) 
	{
		$sectionname = $section->attribute( 'name' );
		$attr = $pricing->getProductAttributes_Custom1( $contentobject, $langNames[$currentlang] );
		$translation = 't';
		// if this lang doesn't exist, get the default one (only if we want to show all items)
		if ( $attr === false && $viewall==1 ) {
			$attr = $pricing->getProductAttributes_Custom1( $contentobject, false );
			$translation = '-';
		}

		if ($attr) 
		{
			if ($attr[2]) // if there's a price 
			{
				$priceObj = $attr[2];
				$price = $priceObj->price();
				$attr[2] = $price;
				$vatincluded = $priceObj->VATIncluded();
				$attr[3] = $vatincluded;
				$discount = $priceObj->discountPercent();
				$attr[4] = $discount;
				$currency = $priceObj->currency();
				$attr[5] = $currency;

				$attr['nt']=$translation;
				$attr[6]=$visibility;
				$attr[7]=$sectionname;
				$matrix[] = $attr ;
			}
		}
	}
}

asort($matrix);

$tpl =& templateInit();

$tpl->setVariable( "action", $action );
$tpl->setVariable( "error_reason", $error_reason );
$tpl->setVariable( "langNames", $langNames );
$tpl->setVariable( "currentlang", $currentlang );
$tpl->setVariable( "groupNames", $groupNames );
$tpl->setVariable( "groupIDs", $groupIDs );
$tpl->setVariable( "currentgroupID", $currentgroupID );
$tpl->setVariable( "viewallNames", $viewallNames );
$tpl->setVariable( "viewall", $viewall );
$tpl->setVariable( "matrix", $matrix );

$Result = array();
$Result['content'] =& $tpl->fetch( "design:pricing.tpl" );
$Result['left_menu'] = 'design:pricing-menu.tpl';

?>
