<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=bg_pricing


[RegionalSettings]
TranslationExtensions[]=bg_pricing


*/ ?>