<?php

/**
 * File containing the eZTube info.
 *
 * @copyright //autogen//
 * @license //autogen//
 * @version //autogen//
 */
 
class eZMollomInfo
{
    static function info()
    {
        return array( 'Name' => 'Fummago eZMollom extension',
                      'Version' => '0.9',
                      'Copyright' => 'Fumaggo Internet Solutions',
                      'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
