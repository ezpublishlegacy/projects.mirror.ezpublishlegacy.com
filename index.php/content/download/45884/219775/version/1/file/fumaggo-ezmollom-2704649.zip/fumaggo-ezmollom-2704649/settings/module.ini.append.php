<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezmollom
ModuleList[]=ezmollom

*/ ?> 
