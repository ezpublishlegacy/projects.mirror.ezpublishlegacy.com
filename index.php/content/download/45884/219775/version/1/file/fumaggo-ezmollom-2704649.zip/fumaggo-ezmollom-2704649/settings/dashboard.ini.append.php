<?php /* #?ini charset="utf8"?

[DashboardSettings]
DashboardBlocks[]=ezmollom

[DashboardBlock_ezmollom]
Priority=60
PolicyList[]=content/read

*/ ?>