<?php /*

[EventSettings]
RepositoryDirectories[]=extension/ezmollom/workflowtypes
ExtensionDirectories[]=ezmollom
AvailableEventTypes[]=event_ezmollom

[OperationSettings]
AvailableOperationList[]=before_ezmollom_ezcomment

*/ ?>