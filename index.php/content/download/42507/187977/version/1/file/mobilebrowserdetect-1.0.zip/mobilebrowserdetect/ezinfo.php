<?php

class mobilebrowserdetectInfo
{
    static function info()
    {
        return array(
            'Name' => 'Mobile browser detect extension',
            'Version' => '1.0',
            'Copyright' => 'Copyright (C) 2011 Alex Kozeka',
            'License' => 'GNU General Public License v2.0',
        );
    }
}

?>