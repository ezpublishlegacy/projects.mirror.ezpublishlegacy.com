<?php /* #?ini charset="utf-8"?

# Example of settings for 'full' version of the site
#[SiteSettings]
# This URL is required if client tries to open current site with mobile browser
# Then redirection is done to specified URL
# Exception is when variable 'full_view_on_mobile' is found in the URL
# In this case client will get 'full' version of the site anyway and store cookie (see next parameter)
#SiteMobileURL=http://m.mysite.com/

# Specifies number of days for 'full_view_on_mobile' cookie
#FullViewOnMobileCookieTimeout=365

*/ ?>