<?php /* #?ini charset="iso-8859-1"?

[CronjobSettings]
ExtensionDirectories[]=ezworkflowcollection

[CronjobPart-archiver]
Scripts[]=updateobjectstate.php

[CronjobPart-frequent]
Scripts[]=updateobjectstate.php

*/ ?>
