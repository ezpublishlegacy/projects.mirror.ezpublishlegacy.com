<?php /*


[Leftmenu_my]
Links[updatestate]=updatestate/list
PolicyList_updatestate[]=updatestate/list

*/ ?>