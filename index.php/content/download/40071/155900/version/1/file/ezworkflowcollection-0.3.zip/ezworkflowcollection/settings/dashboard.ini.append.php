<?php /* #?ini charset="iso-8859-1"?

[DashboardSettings]
#DashboardBlocks[]
#DashboardBlocks[]=example
#DashboardBlocks[]=pending_list
#DashboardBlocks[]=maintenance
#DashboardBlocks[]=drafts
#DashboardBlocks[]=all_latest_content
#DashboardBlocks[]=latest_content
DashboardBlocks[]=updatestate_pending
# DashboardBlocks[]=wishlist

[DashboardBlock_updatestate_pending]
Priority=12
NumberOfItems=10
PolicyList[]=updatestate/list

*/ ?>
