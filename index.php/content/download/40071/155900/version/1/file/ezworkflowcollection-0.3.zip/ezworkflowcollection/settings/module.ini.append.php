<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezworkflowcollection

ModuleList[]=updatestate

*/ ?>