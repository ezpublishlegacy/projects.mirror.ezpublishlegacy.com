HTML in XML for eZ Publish 3

Allows for arbitrary html code inside <html></html> tags in an ezxml text field

Warning: this is experimental code and modifies 2 base php files that come with the distribution. Use at your own risk!

Use:

Copy the files in this archive to their respective locations:


ezxhtmlxmloutput.php should go in kernel/classes/datatypes/ezxmltext/handlers/output/
ezsimplifiedxmlinput.php should go in kernel/classes/datatypes/ezxmltext/handlers/input/
html.tpl should go in design/standard/templates/content/datatype/view/ezxmltags/

