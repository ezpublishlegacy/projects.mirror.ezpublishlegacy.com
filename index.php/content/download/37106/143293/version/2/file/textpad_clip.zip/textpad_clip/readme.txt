
Textpad Clip books for eZ publish 
-------------------------------

/*
    Textpad clip books for eZ publish 3.6/3.7+
    Developed by Contactivity bv, Leiden the Netherlands
    http://www.contactivity.com, info@contactivity.com
    

    This file may be distributed and/or modified under the terms of the
    GNU General Public License" version 2 as published by the Free
    Software Foundation and appearing in the file LICENSE.GPL included in
    the packaging of this file.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    The "GNU General Public License" (GPL) is available at
    http://www.gnu.org/copyleft/gpl.html.
    
    
*/


1. Install
----------
Under Windows, save the .tcl files in the following directory:
\Documents and Settings\[user name]\Application Data\TextPad

2. More info: 
-------------
http://www.textpad.com and http://www.textpad.com/add-ons/cliplibs.html


3. Disclaimer
-------------
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
