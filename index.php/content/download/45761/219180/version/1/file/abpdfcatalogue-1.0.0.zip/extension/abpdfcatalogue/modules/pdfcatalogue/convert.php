<?php

/**

    PDF catalogue extension for eZ Publish - View "convert" of the module "pdfcatalogue"

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

$http = eZHTTPTool::instance();

$type       = 'node';
$target     = false;
$localeCode = false;

if ( array_key_exists( 'type', $Params ) )
{
    $type = trim( $Params['type'] );
    if ( $type != 'html' && $type != 'node' )
    {
        $type = 'node';
    }
}

if ( array_key_exists( 'target', $Params ) )
{
    $target = trim( $Params['target'] );
}

if ( array_key_exists( 'locale_code', $Params ) )
{
    $localeCode = trim( $Params['locale_code'] );
}

$pdfCatalogue = abPDFCatalogue::instance();

switch ( $type )
{
    case 'node':
    {
        $target = (int)$target;
        if ( $target < 2 )
        {
            return $Params['Module']->handleError( eZError::KERNEL_NOT_FOUND, 'kernel' );
        }
        else
        {
            if ( $localeCode === false || $localeCode == '' )
            {
                $localeCode = eZLocale::currentLocaleCode();
            }
            $pdfCatalogue->convertNodeToPDF( $target, $localeCode );
        }
    }
    break;
    case 'html':
    {
        $htmlText = false;
        if ( $http->hasPostVariable( 'convertHTMLText' ) )
        {
            $htmlText = $http->postVariable( 'convertHTMLText' );
        }
        if ( $target == '' )
        {
            $target = 'store';
        }
        $convertFileName = false;
        if ( $http->hasPostVariable( 'convertFileName' ) )
        {
            $convertFileName = $http->postVariable( 'convertFileName' );
        }
        $applyHTMLFrame = false;
        if ( $http->hasPostVariable( 'convertApplyHTMLFrame' ) )
        {
            if ( trim( $http->postVariable( 'convertApplyHTMLFrame' ) ) == '1' )
            {
                $applyHTMLFrame = true;
            }
        }
        if ( !$pdfCatalogue->generatePDFByHTML( $htmlText, $target, $convertFileName, $applyHTMLFrame ) )
        {
            return $Params['Module']->handleError( eZError::KERNEL_NOT_FOUND, 'kernel' );
        }
    }
    break;
}

?>