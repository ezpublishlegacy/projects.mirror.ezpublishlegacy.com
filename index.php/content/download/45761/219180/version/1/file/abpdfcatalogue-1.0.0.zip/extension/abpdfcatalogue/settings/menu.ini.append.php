<?php /* #?ini charset="utf-8"?

#[MenuContentSettings]
#TopIdentifierList[]=ab_pdf_catalogue
#TopIdentifierList[]=ab_pdf_catalogue_chapter

#LeftIdentifierList[]=ab_pdf_catalogue
#LeftIdentifierList[]=ab_pdf_catalogue_chapter

*/ ?>
