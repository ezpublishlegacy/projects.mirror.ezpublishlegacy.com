INSERT INTO `eztags` ( `parent_id`, `main_tag_id`, `keyword`, `depth`, `path_string`, `modified`, `remote_id` ) VALUES( 0, 0, 'People', 1, '/1/', 1287705600, '040a433c5f26a03ee2497d2452ac1b84' );
INSERT INTO `eztags` ( `parent_id`, `main_tag_id`, `keyword`, `depth`, `path_string`, `modified`, `remote_id` ) VALUES( 0, 0, 'Places', 1, '/2/', 1287705600, 'dc96d1ad3f15f8a71220893b37647bcc' );
INSERT INTO `eztags` ( `parent_id`, `main_tag_id`, `keyword`, `depth`, `path_string`, `modified`, `remote_id` ) VALUES( 0, 0, 'Companies', 1, '/3/', 1287705600, 'a4c1ef98a87bf6e2edd2fba845d903a2' );
INSERT INTO `eztags` ( `parent_id`, `main_tag_id`, `keyword`, `depth`, `path_string`, `modified`, `remote_id` ) VALUES( 0, 0, 'Events', 1, '/4/', 1287705600, '91ecadda330b2b3d2b7178607edfef15' );
