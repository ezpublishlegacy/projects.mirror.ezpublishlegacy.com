<?php /* #?ini charset="utf-8"?

[SolrFieldMapSettings]
DatatypeMap[eztags]=lckeyword
*/ ?>
