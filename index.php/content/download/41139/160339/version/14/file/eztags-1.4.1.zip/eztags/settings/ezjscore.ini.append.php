<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezjsctagssuggest

[ezjscServer_ezjsctagssuggest]
Class=ezjscoreTagsSuggest
TemplateFunction=false
File=extension/eztags/classes/ezjscoretagssuggest.php
*/ ?>
