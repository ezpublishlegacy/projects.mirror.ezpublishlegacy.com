<?php /* #?ini charset="utf-8"?

[TagsAttributeFilter]
ExtensionName=eztags
ClassName=eZTagsAttributeFilter
MethodName=createSqlParts
FileName=classes/eztagsattributefilter.php
*/ ?>
