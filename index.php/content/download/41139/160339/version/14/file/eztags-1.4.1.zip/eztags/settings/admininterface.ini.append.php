<?php /* #?ini charset="utf-8"?

[AdditionalMenuSettings]
SubMenuTemplateArray[]=popupmenu/popup_tag_menu.tpl
*/ ?>
