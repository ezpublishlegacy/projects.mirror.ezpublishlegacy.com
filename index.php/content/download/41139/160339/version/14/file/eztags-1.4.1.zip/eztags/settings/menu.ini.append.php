<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[eztagsnavigationpart]=eZTags

[TopAdminMenu]
Tabs[]=eztags

[Topmenu_eztags]
NavigationPartIdentifier=eztagsnavigationpart
Name=eZ Tags
Tooltip=eZ Tags dashboard
URL[]
URL[default]=tags/dashboard
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

PolicyList[]=tags/read
*/ ?>
