<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">

<context>
    <name>design/ezfluxbb/stats</name>
    <message>
        <source>subjects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last member</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile of %user</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/online</name>
    <message>
        <source>guests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>members</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/topics</name>
    <message>
        <source>Published %date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Answers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forums</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discussions</source>
        <translation>Discussions</translation>
    </message>
    <message>
        <source>go to last discussion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>by</source>
        <translation type="unfinished"></translation>
    </message>
</context>

</TS>