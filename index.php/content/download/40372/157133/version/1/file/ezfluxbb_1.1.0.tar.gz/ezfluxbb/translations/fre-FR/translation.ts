<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">

<context>
    <name>design/ezfluxbb/stats</name>
    <message>
        <source>subjects</source>
        <translation>sujets</translation>
    </message>
    <message>
        <source>answers</source>
        <translation>réponses</translation>
    </message>
    <message>
        <source>members</source>
        <translation>membres</translation>
    </message>
    <message>
        <source>Last member</source>
        <translation>Dernier membre</translation>
    </message>
    <message>
        <source>Profile of %user</source>
        <translation>Profil de %user</translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/online</name>
    <message>
        <source>guests</source>
        <translation>invités</translation>
    </message>
    <message>
        <source>members</source>
        <translation>membres</translation>
    </message>
</context>

<context>
    <name>design/ezfluxbb/topics</name>
    <message>
        <source>Published %date</source>
        <translation>Publié le %date</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Lire la suite</translation>
    </message>
    <message>
        <source>answers</source>
        <translation>réponses</translation>
    </message>
    <message>
        <source>Answers</source>
        <translation>Réponses</translation>
    </message>
    <message>
        <source>Forums</source>
        <translation>Forums</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Forum :</translation>
    </message>
    <message>
        <source>Discussions</source>
        <translation>Discussions</translation>
    </message>
    <message>
        <source>go to last discussion</source>
        <translation>aller à la dernière discussion</translation>
    </message>
    <message>
        <source>Last message</source>
        <translation>Dernier message</translation>
    </message>
    <message>
        <source>by</source>
        <translation>par</translation>
    </message>
</context>

</TS>