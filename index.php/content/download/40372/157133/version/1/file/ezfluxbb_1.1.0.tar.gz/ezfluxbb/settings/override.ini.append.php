<?php /*

[block_ezFluxBBStats_ezFluxBBStats]
Source=block/view/view.tpl
MatchFile=block/ezfluxbb_stats.tpl
Subdir=templates
Match[type]=ezFluxBBStats
Match[view]=ezfluxbb_stats

[block_ezFluxBBOnline_ezFluxBBOnline]
Source=block/view/view.tpl
MatchFile=block/ezfluxbb_online.tpl
Subdir=templates
Match[type]=ezFluxBBOnline
Match[view]=ezfluxbb_online

[block_ezFluxBBTopics_list_description]
Source=block/view/view.tpl
MatchFile=block/ezfluxbb_listtopic_description.tpl
Subdir=templates
Match[type]=ezFluxBBTopics
Match[view]=list_description

[block_ezFluxBBTopics_list]
Source=block/view/view.tpl
MatchFile=block/ezfluxbb_listtopic.tpl
Subdir=templates
Match[type]=ezFluxBBTopics
Match[view]=list

[block_ezFluxBBTopics_list_compact]
Source=block/view/view.tpl
MatchFile=block/ezfluxbb_listtopic_compact.tpl
Subdir=templates
Match[type]=ezFluxBBTopics
Match[view]=list_compact

*/ ?>