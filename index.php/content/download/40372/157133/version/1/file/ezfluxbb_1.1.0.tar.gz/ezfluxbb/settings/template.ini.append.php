<?php /* #?ini charset="utf-8"?

[PHP]
PHPOperatorList[strip_tags]=strip_tags

*/ ?>
