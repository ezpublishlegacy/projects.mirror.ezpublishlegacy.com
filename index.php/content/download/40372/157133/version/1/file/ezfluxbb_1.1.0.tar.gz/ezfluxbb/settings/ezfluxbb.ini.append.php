<?php /* #?ini charset="utf-8"?

[FluxBBInfo]
# FluxBB / PunBB version
Version=1.4

# Path to your FluxBB board
Path=./path_to/fluxBB

# Board's url
BoardURL=http://www.exemple.com


[DataBase]
# DB's Charset.
Charset=iso-8859-1

*/ ?>