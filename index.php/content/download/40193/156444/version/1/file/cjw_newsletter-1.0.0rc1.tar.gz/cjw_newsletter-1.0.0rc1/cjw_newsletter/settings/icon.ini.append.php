<?php /* #?ini charset="utf-8"? */

/**
 * File containing the icon ini
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0rc1
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */

/*

#[IconSettings]
#Theme=crystal-admin
#Size=normal

[ClassIcons]
ClassMap[cjw_newsletter_root]=filesystems/folder.png
ClassMap[cjw_newsletter_system]=filesystems/folder_txt.png
ClassMap[cjw_newsletter_list]=actions/view_tree.png
ClassMap[cjw_newsletter_edition]=mimetypes/document.png

*/ ?>
