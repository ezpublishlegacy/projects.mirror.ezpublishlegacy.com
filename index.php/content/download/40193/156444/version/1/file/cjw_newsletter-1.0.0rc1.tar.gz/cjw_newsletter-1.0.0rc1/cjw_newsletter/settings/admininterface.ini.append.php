<?php /* #?ini charset="utf-8"?

[SubItems]
# Column names reflect the attribute names of template variable $node
VisibleColumns[eznewsletternavigationpart]=checkbox;crank;name;creator;published_date;translations

*/ ?>
