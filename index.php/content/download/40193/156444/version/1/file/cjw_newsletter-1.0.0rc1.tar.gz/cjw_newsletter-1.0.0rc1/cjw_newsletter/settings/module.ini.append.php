<?php /* #?ini charset="utf-8"? */

/**
 * File containing the module ini
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0rc1
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */

/*
[ModuleSettings]
ExtensionRepositories[]=cjw_newsletter
ModuleList[]=newsletter

*/ ?>
