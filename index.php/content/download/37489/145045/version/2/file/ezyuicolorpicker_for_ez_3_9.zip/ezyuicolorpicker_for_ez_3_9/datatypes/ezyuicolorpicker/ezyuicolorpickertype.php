<?php
include_once( 'kernel/classes/ezdatatype.php' );
include_once( 'kernel/common/i18n.php' );

define( "EZ_DATATYPESTRING_EZYUICOLORPICKER", "ezyuicolorpicker" );

class eZYuiColorPickerType extends eZDataType{
	
    /**
     * Constructeur
     */
    function eZYuiColorPickerType(){
        $this->eZDataType( EZ_DATATYPESTRING_EZYUICOLORPICKER, ezi18n( 'kernel/classes/datatypes', 'Color Picker', 'Datatype name' ),
                           array( 'serialize_supported' => true,
                                  'object_serialize_map' => array( 'data_text' => 'text' ) ) );
    }
    
    
    function initializeObjectAttribute( &$contentObjectAttribute, $currentVersion, &$originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
        else
        {
            $contentClassAttribute = $contentObjectAttribute->contentClassAttribute();
            $default = $contentClassAttribute->attribute( "data_text1" );
            if ( $default !== "" )
            {
                $contentObjectAttribute->setAttribute( "data_text", $default );
            }
        }
    }
    
    /*!
     Fetches the http post var string input and stores it in the data instance.
    */
    function fetchObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_ezyuicolorpicker_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data = $http->postVariable( $base . '_ezyuicolorpicker_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $contentObjectAttribute->setAttribute( 'data_text', $data );
            return true;
        }
        return false;
    }
    
     /*!
     Does nothing since it uses the data_text field in the content object attribute.
     See fetchObjectAttributeHTTPInput for the actual storing.
    */
    function storeObjectAttribute( $attribute )
    {
    }
    
    /*!
     Returns the content.
    */
    function &objectAttributeContent( &$contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }
    
    /*!
     \reimp
    */
    function isIndexable()
    {
        return true;
    }
    
     /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( &$contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }
    
    /*!
     Returns the content of the string for use as a title
    */
    function title( &$contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }
}

eZDataType::register( EZ_DATATYPESTRING_EZYUICOLORPICKER, 'eZYuiColorPickerType' );
?>
