<?php /*
[DataTypeSettings]
ExtensionDirectories[]=ezyuicolorpicker
AvailableDataTypes[]=ezyuicolorpicker
*/ ?>