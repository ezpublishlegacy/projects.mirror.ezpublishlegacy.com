YAHOO.namespace("ezpublish.yuicolorpicker") ;

function showColorPicker(){
	YAHOO.ezpublish.yuicolorpicker.dialog.show();
}

function clearColor(){
	document.getElementById('colorPickerValue').value = '';
}

function init(){
	// on force la propriete class du body pour que la bibliotheque YAHOO se comporte bien
	document.body.className = ' yui-skin-sam';
	
	YAHOO.ezpublish.yuicolorpicker.dialog = new YAHOO.widget.Dialog("yui-picker-panel", {  
	        width : "350px", 
		visible : false,
		draggable: false,
		close: true,
		constraintoviewport : true
	     }); 
	
	
	YAHOO.ezpublish.yuicolorpicker.dialog.renderEvent.subscribe(function() { 
	    if (!YAHOO.ezpublish.yuicolorpicker.picker) { 
	        YAHOO.log("Instantiating the color picker", "info", "example"); 
	        YAHOO.ezpublish.yuicolorpicker.picker = new YAHOO.widget.ColorPicker("yui-picker", { 
	            container: YAHOO.ezpublish.yuicolorpicker.dialog, 
	            images: { 
	                PICKER_THUMB: "/extension/ezyuicolorpicker/design/admin/javascript/yui/build/colorpicker/assets/picker_thumb.png", 
	                HUE_THUMB: "/extension/ezyuicolorpicker/design/admin/javascript/yui/build/colorpicker/assets/hue_thumb.png" 
	            } 
	        }); 
	 
	        YAHOO.ezpublish.yuicolorpicker.picker.on("rgbChange", function(o) { 
	            //alert(YAHOO.util.Color.rgb2hex(o.newValue[0], o.newValue[1], o.newValue[2])); 
		    document.getElementById('colorPickerValue').value = YAHOO.util.Color.rgb2hex(o.newValue[0], o.newValue[1], o.newValue[2]);
	        }); 
	    } 
	});  
	
	YAHOO.ezpublish.yuicolorpicker.dialog.render(); 
}

YAHOO.util.Event.onDOMReady(init);