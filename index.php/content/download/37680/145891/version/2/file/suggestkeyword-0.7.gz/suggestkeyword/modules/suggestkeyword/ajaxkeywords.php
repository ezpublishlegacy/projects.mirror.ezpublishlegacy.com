<?php

// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.9.x
// BUILD VERSION: Objectrelationbrowse 2.0
// COPYRIGHT NOTICE: Copyright (C) 1999-2007 Contactivity bv (info@contactivity.com)
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
//
// This view is actually not used in this extension,
// it's included for your recreative purposes 
//

include_once( 'kernel/content/ezcontentfunctioncollection.php' );
include_once( "kernel/classes/ezcontentobject.php" );


$Result = array();
$Module = $Params['Module'];

$ini = eZINI::instance();
$request_value 	= array();
$result_value	= array();

include_once( 'lib/ezdb/classes/ezdb.php' );
$db = eZDB::instance();

//GET PARAMETERS
$q 		= $Params['q'];
$offset				= (int) $Params['Offset'];
$limit				= (int) $Params['Limit'];


if (!$returnType )
		$returnType=0;
if (!$q)
	$q="";
if (!$offset)
	$offset	= false;
if (!$limit)
	$limit = false;


$request_value[] = "<request>";
$request_value[] = "<q>".$q."</q>";
$request_value[] = "<offset>".$offset."</offset>";
$request_value[] = "<limit>".$offset."</limit>";
$request_value[] = "</request>";


$result_value[]="<result>";

include_once( 'lib/ezdb/classes/ezdb.php' );
$words = array();
$db = eZDB::instance();
$query = "SELECT DISTINCT keyword as word ";
$query .= "	FROM ezkeyword  ";
$query .= "	WHERE keyword like '%".mysql_escape_string($q)."%'";
$query .= "	ORDER BY word  ";
if ($offset && $limit)
{
	$query .= " LIMIT $offset, $limit ";
}
else
{
	if ($limit) $query .= "LIMIT $limit ";
}
$rows = $db->arrayQuery( $query );
foreach ($rows as $row) {
	$result_value[]="<item>";
	$result_value[]="<keyword><![CDATA[".$row["word"]."]]></keyword>";
	$result_value[]="</item>";
}

$result_value[]="</result>";

$Result["pagelayout"] = false;
header('Content-Type: text/xml');
echo "<"."?xml version=\"1.0\" encoding=\"UTF-8\"?".">";
echo "<response>";
echo implode("\n", $request_value);
echo implode("\n", $result_value);
echo "</response>";

eZExecution::cleanExit();
