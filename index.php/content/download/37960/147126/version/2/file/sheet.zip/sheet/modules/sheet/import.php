<?php
//
// Created on: <15-Mar-2004 09:18:06 bf>
//
// Copyright (C) 1999-2004 Musikverlage Hans Gerig. All rights reserved.
//

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "kernel/classes/ezcontentclassattribute.php" );
include_once( "kernel/classes/ezcontentclass.php" );

include_once( "lib/ezutils/classes/ezoperationhandler.php" );
include_once( "lib/ezutils/classes/ezdir.php" );

include_once( "kernel/common/image.php" );
include_once( "kernel/classes/datatypes/ezimage/ezimage.php" );
include_once( "kernel/classes/datatypes/ezbinaryfile/ezbinaryfile.php" );

include_once( "kernel/common/template.php" );

include_once( "lib/ezutils/classes/ezmail.php" );
include_once( "lib/ezutils/classes/ezmailtransport.php" );

include_once( "text2xml.php" );

include_once( "kernel/classes/ezsearch.php" );

include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );

/**
 * Imports xml with reference to files all uploaded via ftp.
 * Sets  the id xml attribute to product_nr and reads and assignes the node the category specified.
 * @author <a href="Dominik@pich.info">Dominik Pich</a>
 * @version 1.0
 * @todo Strings returned by importXml should be localized.
 * @todo Category - Placement & Instrument - Placement relations shouldn't be hardcoded.
 * @todo Get more detailed information why validation failed.
 * @todo eZMimeType::mimeTypeFor() is deprecated, use eZMimeType::findByURL() instead.
 * @todo Saving the image & the binary file is not correct.
 */
class daijImporter
{
	var $sheetID;
	
	var $http;
	var $ini;
	var $tpl;
	var $sys;
	
	/**
	 *  A constant defining the directory the files are in.
	 */
	var $DIRECTORY_INCOMING;
	/**
	 * A constant defining the storage directory.
	 */
	var $DIRECTORY_STORAGE;

	/**
	 * Constructor setting the id of the sheet to import.
	 * @param sheetID The Id of the sheet to import
	 */
	function daijImporter( $sheetID )
	{
		$this->sheetID = $sheetID;
		$this->http =& eZHTTPTool::instance();
		$this->ini =& eZINI::instance();
		$this->tpl =& templateInit();
		$this->sys =& eZSys::instance();
		
		$this->DIRECTORY_INCOMING = "files/";
		$this->DIRECTORY_STORAGE = $this->sys->storageDirectory();
	}
	
	/**
	 * Import xml into ez
	 * @param The ID of the sheet to be imported
	 * @return Returns a named result Validation which is forwarded to the template.
	 */
	function importXml()
	{	
		//setup return value
		$Validation = array();
		$Validation['succeeded'] = false;
		$Validation['processed'] = true;
		
		//Open xml file
		$xmlfile = $this->DIRECTORY_INCOMING . $this->sheetID . ".xml";
		eZDebug::writeDebug( 'File to read: ' . $xmlfile );
		$xml = domxml_open_file( $xmlfile, DOMXML_LOAD_VALIDATING, $error );
		if( $error or !$xml )
		{
			$Validation['message'] = "Sheet with corresponding ID not found.";
			return $Validation;
		}

		//main placement
		$defaultSheetPlacement = $this->ini->variable( "SheetSettings", "DefaultSheetPlacement" );
		
		//setup class
		$sheetClassID = $this->ini->variable( "SheetSettings", "SheetClassID" );
		$class =& eZContentClass::fetch( $sheetClassID );
		$sheetCreatorID = $this->ini->variable( "SheetSettings", "SheetCreatorID" );
		$defaultSectionID = $this->ini->variable( "SheetSettings", "DefaultSectionID" );
			
		//create object by user 14 in section 1
		$contentObject =& $class->instantiate( $sheetCreatorID, $defaultSectionID );
		$name = $class->attribute( "name" );
		$contentObject->setClassName( $name );
			
		//get contentObject
		$version =& $contentObject->version( 1 );
		$contentObjectAttributes =& $version->contentObjectAttributes();
			
		//enum file nodes in xml
		$nodes = $xml->get_elements_by_tagname( "file" );
		$node = $nodes[0];
			
		if( $node )
		{
			if( !$node->type == XML_ELEMENT_NODE )
				continue;
			if( !$node->has_attributes() )
				continue;
				
			//get add. placements
			$attributes = $node->attributes();
			foreach ( $attributes as $attribute )
			{
				$xmlAttributeName = $attribute->name();
				$xmlAttributeValue = $attribute->value();
				
				//if category, calculate the placement
				if( $xmlAttributeName == "category" )
				{
					$categorySheetPlacement = $this->placementFromCategory( $xmlAttributeValue );
					eZDebug::writeDebug( 'Got add. placement: ' . $categorySheetPlacement );					
				}
				//if instrument, calculate the placement
				if( $xmlAttributeName == "instrument" )
				{
					$instrumentSheetPlacement = $this->placementFromInstrument( $xmlAttributeValue );
					eZDebug::writeDebug( 'Got add. placement: ' . $instrumentSheetPlacement );					
				}
			}
				
			//import the attributes
			$this->importAttributes( $node, $contentObjectAttributes );
		}

		//validate the attributes
		$db =& ezDB::Instance();
		if( $contentObject->validateInput( $contentObjectAttributes, $db->databaseName() ) == false )
		{
			$Validation['message'] = "Uploaded sheet did not validate.";
			return $Validation;
		}
		
		//create main node
		$nodeAssignment =& eZNodeAssignment::create( array(
								 'contentobject_id' => $contentObject->attribute( 'id' ),
								 'contentobject_version' => 1,
								 'parent_node' => $defaultSheetPlacement,
								 'is_main' => 1
								 ) );	

		//create category node
		if( isset( $categorySheetPlacement ) && $categorySheetPlacement > 0 )
		{
			eZDebug::writeDebug( 'Create place in: ' . $categorySheetPlacement );			
			$categoryAssignment =& eZNodeAssignment::create( array(
									 'contentobject_id' => $contentObject->attribute( 'id' ),
									 'contentobject_version' => 1,
									 'parent_node' => $categorySheetPlacement,
									 'is_main' => 0
									 ) );										 
		}

		//create instrument placement
		if( isset( $instrumentSheetPlacement ) && $instrumentSheetPlacement > 0 )
		{
			eZDebug::writeDebug( 'Create place in: ' . $instrumentSheetPlacement );			
			$instrumentAssignment =& eZNodeAssignment::create( array(
									 'contentobject_id' => $contentObject->attribute( 'id' ),
									 'contentobject_version' => 1,
									 'parent_node' => $instrumentSheetPlacement,
									 'is_main' => 0
									 ) );				
		}
		
		//store
		$version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
		$version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
		$version->store();
		
		$nodeAssignment->store();
		if( isset($categoryAssignment) )
		{
			eZDebug::writeDebug( 'Place in: ' . $categorySheetPlacement );
			$categoryAssignment->store();
		}
		if( isset($instrumentAssignment) )
		{
			eZDebug::writeDebug( 'Place in: ' . $instrumentSheetPlacement );
			$instrumentAssignment->store();
		}
		
		//publish
		$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObject->attribute( 'id' ), 'version' => 1 ) );
		//update search
		$this->registerSearchObject( $contentObject );
		
		//setup return value
		$Validation['succeeded'] = true;
		$Validation['message'] = "Successfully imported the sheet.";
		
		//confirm
		if( $Validation['succeeded'] == true )
		{
			$time = time();
			$time -= 60000;
			//$this->confirmImport();
			$this->deleteFiles( $this->DIRECTORY_INCOMING, '*.*', $time );
		}
		
		return $Validation;
	}

	/**
	 * Confirms the import of a sheet by sending an email to the admin.
	 */
	function confirmImport()
	{
		// send verification mail to the admin
		$notifyImport = $ini->variable( 'SheetSettings', 'NotifyImport' );
		if ( $notifyImport == "enabled" )
		{
			$mail = new eZMail();
			
			//template for mail
			$this->tpl->resetVariables();
			$this->tpl->setVariable( 'sheet_id', $this->sheetID );
	
			$templateResult =& $this->tpl->fetch( 'design:sheet/importfeedback.tpl' );
	
			$subject = ezi18n( 'extension/sheet/', 'New sheet imported' );
			if ( $this->tpl->hasVariable( 'subject' ) )
				$subject =& $this->tpl->variable( 'subject' );
	
			//set sender & receiver
			$adminMail = $this->ini->variable( 'MailSettings', 'AdminEmail' );
			$mail->setReceiver( $adminMail );
			$emailSender = $this->ini->variable( 'MailSettings', 'EmailSender' );
			if ( !$emailSender )
				$emailSender = $this->ini->variable( 'MailSettings', 'AdminEmail' );
			$mail->setSender( $emailSender );
			
			//send mail
			$mail->setSubject( $subject );
			$mail->setBody( $templateResult );
			$mailResult = eZMailTransport::send( $mail );
		}
	
		//redirect to show success
		//$module->redirectTo( '/sheet/success/' );
	}
	
	/**
	 * Searches ez's database for a sheet with the id specified to determine if it is already there and therefore shouldn't be imported.
	 * @return Returns true
	 */
	function isFound()
	{
		//BUGBUG: Todo: search for all classes having an attribute id which matches sheetID
		return false;
	}


	/**
	 * Registers the object with the search engine
	 */
    function registerSearchObject( &$contentObject )
    {
        eZDebug::createAccumulatorGroup( 'search_total', 'Search Total' );

        // Register the object in the search engine.
        eZDebug::accumulatorStart( 'remove_object', 'search_total', 'remove object' );
        eZSearch::removeObject( $contentObject );
        eZDebug::accumulatorStop( 'remove_object', 'search_total', 'remove object' );
        eZDebug::accumulatorStart( 'add_object', 'search_total', 'add object' );
        eZSearch::addObject( $contentObject );
        eZDebug::accumulatorStop( 'add_object', 'search_total', 'add object' );
    }
    
	/**
	 * Fills contentObjectAttributes from xml
	 * @param node The node the xml dom to use for filling
	 * @param contentObjectAttributes The object attributes to be filled
	 */
	function importAttributes( $node, &$contentObjectAttributes )
	{
		if( !$node->type == XML_ELEMENT_NODE )
			continue;
		if( !$node->has_attributes() )
			continue;
				
		//enum xml attributes and store them in the corresponding contentObject's attributes.
		$attributes = $node->attributes();
		foreach ( $attributes as $attribute )
		{
			$xmlAttributeName = $attribute->name();
			$xmlAttributeValue = $attribute->value();
				
			//if id, change it
			if( $xmlAttributeName == "id" )
			{
				$xmlAttributeName = "product_nr";
			}
	
			foreach( $contentObjectAttributes as $contentObjectAttribute )
			{
				$ezAttributeName = $contentObjectAttribute->contentClassAttributeIdentifier();
				if( $xmlAttributeName == $ezAttributeName )
				{
					eZDebug::writeDebug( "XML Attribute: " . $xmlAttributeName  . " / " . $xmlAttributeValue );

					//adapt to type expected contentObject in function
					$this->importAttribute( $xmlAttributeValue, $contentObjectAttribute );
					
					$eZAttributeValue = $contentObjectAttribute->content();
					ezDebug::writeDebug( "eZ Attribute " . $ezAttributeName . " / " . $eZAttributeValue );
				}
			}
		}
	}

	/**
	 * Imports a value to an attribute adapting it to the proper type.
	 * Not written by me, downloaded from ez.no! Extended it only!
	 * @param data The value (string/int/float).
	 * @param contentObjectAttribute The attribute to modify.
	 */
	function importAttribute( $data, &$contentObjectAttribute )
	{
		$contentClassAttribute = $contentObjectAttribute->attribute( 'contentclass_attribute' );
		$dataTypeString = $contentClassAttribute->attribute( 'data_type_string' );
		
		ezDebug::writeDebug( "Converting " . $data . " to expected " . $dataTypeString );
		
		switch( $dataTypeString )
		{
		case 'ezfloat' :
		case 'ezprice' :
			$contentObjectAttribute->SetAttribute( 'data_float', $data );
			$contentObjectAttribute->store();
			break;
		case 'ezboolean' :
		case 'ezdate' :
		case 'ezdatetime' :
		case 'ezinteger' :
		case 'ezsubtreesubscription' :
		case 'eztime' :
			$contentObjectAttribute->SetAttribute( 'data_int', $data );
			$contentObjectAttribute->store();
			break;
		case 'ezemail' :
		case 'ezisbn' :
		case 'ezstring' :
		case 'eztext' :
		case 'ezurl' :
			$contentObjectAttribute->SetAttribute( 'data_text', $data );
			$contentObjectAttribute->store();
			break;
		case 'ezxmltext' :
			$dummy = "";
			$converter = new text2xml( $dummy, 0, $contentObjectAttribute );
			$converter->validateText( $data, $contentObjectAttribute );
			$contentObjectAttribute->SetAttribute( 'data_int', EZ_XMLTEXT_VERSION_TIMESTAMP );
			$contentObjectAttribute->store();
			break;
		case 'ezimage':
			$this->SaveImage( $data, $contentObjectAttribute );
			break;
		case 'ezbinaryfile':
			$this->SaveFile( $data, $contentObjectAttribute );
			break;		
		case 'ezenum':
			//removed enum - function can be found at ez.no	
		default :
			die( 'Can not store ' . $data . ' as datatype: ' . $dataTypeString );
		}
	}

	/**
	 * Instantiates the eZImage class and assignes it to the attribute passed.
	 * Not written by me, downloaded from ez.no!
	 * @param fileName File's name.
	 * @param contentObjectAttribute The attribute to modify.
 	 * @todo Replace code!?
// $content is now an instance of eZImageAliasHandler
if ( is_object( $content ) )
{
    $content->initializeFromFile( $imageFile );
    if ( $content->isStorageRequired() )
    {
        $content->store();
    }
}
	 */
	function saveImage( $fileName, &$contentObjectAttribute )
	{
		//get info from contentObjectAttribute
		$contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
		$version = $contentObjectAttribute->attribute( "version" );
	
		//create the new ezImage
		$image =& eZImage::create( $contentObjectAttributeID , $version );
		
		$image->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
		$image->setAttribute( "version", $version );
		$image->setAttribute( "filename", $fileName );
		$image->setAttribute( "original_filename", $fileName );
		
		//set alterative texts
		$mimeObj = new eZMimeType();
		$mime = $mimeObj->mimeTypeFor( false, $fileName );
		$image->setAttribute( "mime_type", $mime );
		$image->setAttribute( "alternative_text", $fileName );
		
		$image->store();
	
		//make dir to copy to
		$ori_dir = $this->DIRECTORY_STORAGE . '/' . "original/image/";
		//$ref_dir = $this->DIRECTORY_STORAGE . '/' . "reference/image/";
		if ( !file_exists( $ori_dir ) )
		{
			eZDir::mkdir( $ori_dir, 0777, true);
		}/*
		if ( !file_exists( $ref_dir ) )
		{
			eZDir::mkdir( $ref_dir, 0777, true);
		}*/
	
		//copy to storage
		$source_file = $this->DIRECTORY_INCOMING . $fileName;
		$target_file = $ori_dir . $fileName;
		//$reference_file = $storage_dir . "/reference/image/" . $fileName;
		eZDebug::writeDebug( 'copy from ' . $source_file . ' to ' . $target_file );
		copy($source_file, $target_file );
	}

	/**
	 * Instantiates the eZBinary class and assignes it to the attribute passed.
	 * @param fileName File's name.
	 * @param contentObjectAttribute The attribute to modify.
	 * @todo Set mime-type correctly
	 */
	function saveFile( $fileName, &$contentObjectAttribute )
	{
		//get info from contentObjectAttribute
		$contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
		$version = $contentObjectAttribute->attribute( "version" );
	
		//create the new ezImage
		$file =& eZBinaryFile::create( $contentObjectAttributeID , $version );
		
		$file->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
		$file->setAttribute( "version", $version );
		$file->setAttribute( "filename", $fileName );
		$file->setAttribute( "original_filename", $fileName );
		
		/*
		//set alterative texts
		$mimeObj = new eZMimeType();
		$mime = $mimeObj->mimeTypeFor( false, $fileName );
		$file->setAttribute( "mime_type", $mime );
		$file->setAttribute( "alternative_text", $fileName );
		*/
		
		$file->store();
	
		//make dir to copy to
		$ori_dir = $this->DIRECTORY_STORAGE . '/' . "original/binary/";
		//$ref_dir = $storage_dir . '/' . "reference/binary/";
		if ( !file_exists( $ori_dir ) )
		{
			eZDir::mkdir( $ori_dir, 0777, true);
		}/*
		if ( !file_exists( $ref_dir ) )
		{
			eZDir::mkdir( $ref_dir, 0777, true);
		}*/
	
		//copy to storage
		$source_file = $this->DIRECTORY_INCOMING . $fileName;
		$target_file = $ori_dir . $fileName;
		//$reference_file = $storage_dir . "/reference/binary/" . $fileName;
		eZDebug::writeDebug( 'copy from ' . $source_file . ' to ' . $target_file );
		copy($source_file, $target_file );
	}

	/**
	 * Translate a genre to the according placement for the ez node.
	 * @param category Is given the category to which to match the placement.
	 * @return Returns the placement of the ez parent node for this category.
	 */
	function placementFromCategory( $category )
	{
		$placement = -1; 
		
		//switch on category
		switch( $category )
		{
		case 1: /*Klassik = 1*/
			$placement = 62;
			break;
			
		case 2: /*Schlager = 2*/
			$placement = 63;
			break;
		
		case 3: /*Karneval = 3*/
			$placement = 64;
			break;
			
		case 4: /*Rock/Pop = 4*/
			$placement = 65;		
			break;
			
		default:
			$placement = -1; 
		}
		
		return $placement;
	}
	
	/**
	 * Translate an instrument id to the according placement for the ez node.
	 * @param instrument Is given the category to which to match the placement.
	 * @return Returns the placement of the ez parent node for this instrument.
	 */
	function placementFromInstrument( $instrument )
	{
		$placement = -1; 
		
		//switch on category
		switch( $instrument )
		{
		case 1: /*Klavierstimme = 1*/
			$placement = 54;
			break;
		
		case 2: /*Blasmusik = 2*/
			$placement = 55;
			break;
			
		case 3: /*S.O.-Salonorchester = 3*/
			$placement = 56;
			break;
			
		case 4: /*Unterhaltungskonzert = 4*/
			$placement = 57;
			break;
			
		case 5: /*Akkordeon = 5*/
			$placement = 61;
			break;
	
		case 6: /*Klavier = 6*/
			$placement = 88;
			break;
		
		case 7: /*Gitarre = 7*/
			$placement = 89;
			break;
				
		default:
			$placement = -1; 
		}
		
		return $placement;
	}
	
	/**
	 * Delete the files
	 * @param dir The directory in which to delete the files specified by the pattern.
	 * @param pattern The pattern to which files to match which are to be deleted.
	 * @time The time files must be older than to be deleted.
	 */
	function deleteFiles( $dir, $pattern = "*.*", $time = 0 )
	{
		$deleted = false;
		$pattern = str_replace(array("\*","\?"), array(".*","."), preg_quote($pattern));
		
		if (substr($dir,-1) != "/") $dir.= "/";
		
		if (is_dir($dir))
		{
			$d = opendir($dir);
			while ($file = readdir($d))
			{
           	    if (is_file($dir.$file) && ereg("^".$pattern."$", $file) )
				{
					$ft = -1;
					if ($time > 0 )
					{
						$ft = fileatime($dir.$file);
						$ft -= time();
					}
						
					if ($ft < 0 && unlink($dir.$file))
						$deleted[] = $file;
				}
			}
			
			closedir($d);
			return $deleted;
		}
		else
		{
			return 0; 
		}
	}
}

//get vars
$http =& eZHTTPTool::instance();
$tpl =& templateInit();

//variables posted
if ( $http->hasPostVariable( 'identifier' ) )
{
	$sheetID =& $http->postVariable( 'identifier' );
}

//import
if( isset($sheetID) )
{
	//login the user
	$user =& eZUser::currentUser();
	if( !isset( $user ) )
	{
		require_once( "login.php" );
	}
	
	if( get_class($user) == "ezuser" )
	{
		$userID = $user->id();
	}

	if( isset($userID) && $userID > 0 )
	{
		eZDebug::writeDebug( $sheetID );
		eZDebug::writeDebug( $userID );

		$daijImporter = new daijImporter( $sheetID );
		$Validation = $daijImporter->importXml();
		
		//logout the user
		require_once( "logout.php" );
	}
}

// Template handling
if( isset($sheetID) )
{
	$tpl->setVariable( "sheet_id", $sheetID );
}
if( isset($Validation) )
{
	$tpl->setVariable( "validation", $Validation );
}

//return
$Result = array();
$Result['content'] =& $tpl->fetch( "design:sheet/import.tpl" );
$Result['path'] = array( array( 'url' => false,
								'text' => ezi18n( 'extension/sheet/', 'Sheet' ) ),
						 array( 'url' => false,
								'text' => ezi18n( 'extension/sheet/', 'Import' ) ) );
?>