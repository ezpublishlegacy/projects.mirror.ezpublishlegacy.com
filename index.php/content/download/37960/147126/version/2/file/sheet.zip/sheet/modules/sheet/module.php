<?php

$Module = array( 'name' => 'sheet' );

$ViewList = array();
$ViewList['import'] = array(
    'script' => 'import.php',
    'params' => array( ),
    'default_navigation_part' => 'ezmynavigationpart',
    'single_post_actions' => array( 'ImportButton' => 'Import',
                                    'CancelButton' => 'Cancel' ) );
$ViewList['success'] = array(
    'script' => 'success.php',
    'params' => array( ),
    'default_navigation_part' => 'ezmynavigationpart' );
?>