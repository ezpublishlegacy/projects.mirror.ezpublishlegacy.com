<?php
//
// Created on: <15-Mar-2004 09:18:06 bf>
//
// Copyright (C) 1999-2004 Musikverlage Hans Gerig. All rights reserved.
//


$Module =& $Params["Module"];
$Module->setTitle( "Successful import" );

// Template handling
include_once( "kernel/common/template.php" );
$tpl =& templateInit();


$Result = array();
$Result['content'] =& $tpl->fetch( "design:sheet/success.tpl" );

?>
