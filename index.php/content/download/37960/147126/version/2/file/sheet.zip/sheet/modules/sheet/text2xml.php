<?php
//
// Created on: <17-Mar-2004 10:11:03 bf>
//
// 1999-2004 eZ systems � 1999-2004 - All rights reserved.
//
include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );

class text2xml extends eZSimplifiedXMLInput
{
    function text2xml( &$xmlData, $contentObjectAttribute )
    {
        $this->eZSimplifiedXMLInput( $xmlData, 0, $contentObjectAttribute );
    }

	function &validateText( &$data, &$contentObjectAttribute )
    {
        $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
        // Below is same as in the function validateInput(...) in class eZSimplifiedXMLInput
        eZDebug::writeDebug($data, "input data");
        // Set original input to a global variable
        $originalInput = "originalInput_" . $contentObjectAttributeID;
        $GLOBALS[$originalInput] = $data;

        // Set input valid true to a global variable
        $isInputValid = "isInputValid_" . $contentObjectAttributeID;
        $GLOBALS[$isInputValid] = true;

		//replace all special characters with entities
		$this->replaceEntities( $data );
		eZDebug::writeDebug($data, "entitied input data");

        $inputData = "<section xmlns:image='http://ez.no/namespaces/ezpublish3/image/' 
                                xmlns:xhtml='http://ez.no/namespaces/ezpublish3/xhtml/' >";
        $inputData .= "<paragraph>";
        $inputData .= $data;
        $inputData .= "</paragraph>";
        $inputData .= "</section>";

        $data =& $this->convertInput( $inputData );
        $message = $data[1];
        if ( $this->IsInputValid == false )
        {
            $GLOBALS[$isInputValid] = false;
            $errorMessage = null;
            foreach ( $message as $line )
            {
                $errorMessage .= $line .";";
            }
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 $errorMessage,
                                                                 'ezXMLTextType' ) );
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        else
        {
            $dom = $data[0];
            $objects =& $dom->elementsByName( 'object' );
            if ( $objects !== null )
            {
                foreach ( array_keys( $objects ) as $objectKey )
                {
                    $object =& $objects[$objectKey];
                    $objectID = $object->attributeValue( 'id' );
                    $currentObject =& eZContentObject::fetch( $objectID );
                    $editVersion = $contentObjectAttribute->attribute('version');
                    $editObjectID = $contentObjectAttribute->attribute('contentobject_id');
                    $editObject =& eZContentObject::fetch( $editObjectID );
                    if ( $currentObject == null )
                    {
                        $GLOBALS[$isInputValid] = false;
                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                'Object '. $objectID .' does not exist.', 'ezXMLTextType' ) );
                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                    }
                    else
                    {
                        $relatedObjects =& $editObject->relatedContentObjectArray( $editVersion );
                        $relatedObjectIDArray = array();
                        foreach ( $relatedObjects as $relatedObject )
                        {
                            $relatedObjectID = $relatedObject->attribute( 'id' );
                            $relatedObjectIDArray[] = $relatedObjectID;
                        }
                        if ( !in_array( $objectID, $relatedObjectIDArray ) )
                        {
                            $editObject->addContentObjectRelation( $objectID, $editVersion );
                        }
                    }

                    // If there are any image object with links.
                    $href = $object->attributeValueNS( 'ezurl_href',
                                'http://ez.no/namespaces/ezpublish3/image/' );
                    $urlID = $object->attributeValueNS( 'ezurl_id', 
                                'http://ez.no/namespaces/ezpublish3/image/' );

                    if ( $href != null )
                    {
                        $linkID =& eZURL::registerURL( $href );
                        $object->appendAttribute( $dom->createAttributeNodeNS(
                                'http://ez.no/namespaces/ezpublish3/image/', 'image:ezurl_id', $linkID ) );
                        $object->removeNamedAttribute( 'ezurl_href' );
                    }

                    if ( $urlID != null )
                    {
                        $url =& eZURL::url( $urlID );
                        if ( $url == null )
                        {
                            $GLOBALS[$isInputValid] = false;
                            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                    'Link '. $urlID .' does not exist.', 'ezXMLTextType' ) );
                            return EZ_INPUT_VALIDATOR_STATE_INVALID;
                        }
                    }
                }
            }
            $links =& $dom->elementsByName( 'link' );

            if ( $links !== null )
            {
                foreach ( array_keys( $links ) as $linkKey )
                {
                    $link =& $links[$linkKey];
                    if ( $link->attributeValue( 'id' ) != null )
                    {
                        $linkID = $link->attributeValue( 'id' );
                        $url =& eZURL::url( $linkID );
                        if ( $url == null )
                        {
                            $GLOBALS[$isInputValid] = false;
                            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                    'Link '. $linkID .' does not exist.', 'ezXMLTextType' ) );
                            return EZ_INPUT_VALIDATOR_STATE_INVALID;
                        }
                    }
                    if ( $link->attributeValue( 'href' ) != null )
                    {
                        $url = $link->attributeValue( 'href' );
                        $linkID =& eZURL::registerURL( $url );
                        $link->appendAttribute( $dom->createAttributeNode( 'id', $linkID ) );
                        $link->removeNamedAttribute( 'href' );
                    }
                }
            }

            $domString = $dom->toString();

   eZDebug::writeDebug($domString, "unprocessed xml");
   $domString = preg_replace( "#<paragraph> </paragraph>#", "<paragraph> </paragraph>", $domString );
   $domString = str_replace ( "<paragraph />" , "", $domString );
   $domString = str_replace ( "<line />" , "", $domString );
   $domString = str_replace ( "<paragraph></paragraph>" , "", $domString );
   //$domString = preg_replace( "#>[W]+<#", "><", $domString );
   $domString = preg_replace( "#<paragraph> </paragraph>#", "<paragraph />", $domString );
   $domString = preg_replace( "#<paragraph></paragraph>#", "", $domString );

   $domString = preg_replace( "#[\n]+#", "", $domString );
   $domString = preg_replace( "#</LINE>#", "\n", $domString );
   $domString = preg_replace( "#<PARAGRAPH>#", "\n\n", $domString );
   eZDebug::writeDebug($domString, "domstring");
            $xml = new eZXML();
            $tmpDom =& $xml->domTree( $domString, array( 'CharsetConversion' => false ) );
//                 $domString = $tmpDom->toString();
            $domString = eZXMLTextType::domString( $tmpDom );

            eZDebug::writeDebug($domString, "stored xml");
            $contentObjectAttribute->setAttribute( "data_text", $domString );
            $contentObjectAttribute->setValidationLog( $message );

            $paragraphs = $tmpDom->elementsByName( 'paragraph' );

            $classAttribute =& $contentObjectAttribute->contentClassAttribute();
            if ( $classAttribute->attribute( "is_required" ) == true )
            {
                if ( count( $paragraphs ) == 0 )
                    return EZ_INPUT_VALIDATOR_STATE_INVALID;
                else
                    return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
            }
            else
                return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
        }
        return EZ_INPUT_VALIDATOR_STATE_INVALID;
    }    
    
	function replaceEntities( &$data )
	{
      $entitiesArray = array(
"&lt;"      =>  "<",
"&gt;"      =>  ">",
"&amp;"     =>  "&",
"&quot;"    =>  "\"",
"&AElig;"   =>  "�",
"&Aacute;"  =>  "�",
"&Acirc;"   =>  "�",
"&Agrave;"  =>  "�",
"&Aring;"   =>  "�",
"&Atilde;"  =>  "�",
"&Auml;"    =>  "�",
"&Ccedil;"  =>  "�",
"&ETH;"     =>  "�",
"&Eacute;"  =>  "�",
"&Ecirc;"   =>  "�",
"&Egrave;"  =>  "�",
"&Euml;"    =>  "�",
"&Iacute;"  =>  "�",
"&Icirc;"   =>  "�",
"&Igrave;"  =>  "�",
"&Iuml;"    =>  "�",
"&Ntilde;"  =>  "�",
"&Oacute;"  =>  "�",
"&Ocirc;"   =>  "�",
"&Ograve;"  =>  "�",
"&Oslash;"  =>  "�",
"&Otilde;"  =>  "�",
"&Ouml;"    =>  "�",
"&THORN;"   =>  "�",
"&Uacute;"  =>  "�",
"&Ucirc;"   =>  "�",
"&Ugrave;"  =>  "�",
"&Uuml;"    =>  "�",
"&Yacute;"  =>  "�",
"&aacute;"  =>  "�",
"&acirc;"   =>  "�",
"&aelig;"   =>  "�",
"&agrave;"  =>  "�",
"&aring;"   =>  "�",
"&atilde;"  =>  "�",
"&auml;"    =>  "�",
"&ccedil;"  =>  "�",
"&eacute;"  =>  "�",
"&ecirc;"   =>  "�",
"&egrave;"  =>  "�",
"&eth;"     =>  "�",
"&euml;"    =>  "�",
"&iacute;"  =>  "�",
"&icirc;"   =>  "�",
"&igrave;"  =>  "�",
"&iuml;"    =>  "�",
"&ntilde;"  =>  "�",
"&oacute;"  =>  "�",
"&ocirc;"   =>  "�",
"&ograve;"  =>  "�",
"&oslash;"  =>  "�",
"&otilde;"  =>  "�",
"&ouml;"    =>  "�",
"&szlig;"   =>  "�",
"&thorn;"   =>  "�",
"&uacute;"  =>  "�",
"&ucirc;"   =>  "�",
"&ugrave;"  =>  "�",
"&uuml;"    =>  "�",
"&yacute;"  =>  "�",
"&yuml;"    =>  "�",     
  
"&nbsp;"    =>  "",
"&iexcl;"   =>  "�",
"&pound;"   =>  "�",
"&curren;"  =>  "�",
"&yen;"     =>  "�",
"&brvbar;"  =>  "�",
"&sect;"    =>  "�",
"&uml;"     =>  "�",
"&copy;"    =>  "�",
"&ordf;"    =>  "�",
"&laquo;"   =>  "�",
"&not;"     =>  "�",
"&shy;"     =>  "�",
"&reg;"     =>  "�",
"&macr;"    =>  "�",
"&deg;"     =>  "�",
"&plusmn;"  =>  "�",
"&sup2;"    =>  "�",
"&sup3;"    =>  "�",
"&acute;"   =>  "�",
"&micro;"   =>  "�",
"&para;"    =>  "�",
"&middot;"  =>  "�",
"&cedil;"   =>  "�",
"&sup1;"    =>  "�",
"&ordm;"    =>  "�",
"&raquo;"   =>  "�",
"&frac14;"  =>  "�",
"&frac12;"  =>  "�",
"&frac34;"  =>  "�",
"&iquest;"  =>  "�",
  
"&times;"   =>  "�",
"&divide;"  =>  "�",
"&cent;"    =>  "�",
"&apos;"    =>  "'"
);
		
		str_replace( array_values( $entitiesArray ), array_keys( $entitiesArray ), $data );
	}
}
?>