<?

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezheadutils/autoloads/ezheadutilsoperator.php',
                                    'class' => 'eZHeadUtilsOperator',
                                    'operator_names' => array( 'ezheadregister', 'ezheadwrite')
                                    );
?>