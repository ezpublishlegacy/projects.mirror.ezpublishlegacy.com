eZHeadUtils

Written by:
Fernando Palma (fpalma@uevora.pt)

--------------------
About
--------------------

This extension allow the fine use of CSS and JS in ezpublish.

The aim of the extension is to allow the use of javascript and css in
only some parts of an ezpublish site in an unobstrusive way 
(without need to "hack" the pagelayout with lots of if's conditions).

The principle is that the js an css files needed at some site section are
registered with the "ezheadregister" operator, the registered files
are pushed into a session varible and the are written in the page
layout with the "ezheadwrite" operator.

Every time the ezheadwrite operator is called the session variable is
cleaned and the built in next execution cycle.

--------------------
Installation
--------------------

1. Extract the ezheadutils.tar.gz in your eZ publish 3 extension
directory.

2. Activate the extension. 
   Either in adminitration interface:
     Go to "Setup"
     Go to "Extensions"
     Check the checkbox beside "ezheadutils"
     Click "Activate"
   OR in ini-files:
     Add the following to your settings/override/site.ini.append.php file
     [ExtensionSettings]
     ActiveExtensions[]=ezheadutils

--------------------
Usage
--------------------

There are two operators on this extension:

 - ezheadregister (register files to be added to page head)
 - ezheadwrite (writes all files in page head)

* {ezheadregister(filename, options)}
  - filename is the path to the filename relative to site "design" dir.
  - options is an array of options like (name => value) that is
    "copied" to the generated html.

  sample: 
    {ezheadregister('stylesheets/gallery.css', hash('media', 'print'))}
    {ezheadregister('javascript/gallery.js)}


This operator should be used in any template, but to avoid overload,
should be used on container classes views (like folders) and not in
"line" or "full" views.


* {ezheadwrite()}
  In the above example, the result output will be:

  <link rel="stylesheet" type="text/css" href="/design/plain_site/stylesheets/informacoes.css"  media="print"  />
  <script type="text/javascript" src="/design/plain_site/javascript/gallery.js" ></script>



-------------
NOTES
-------------

* I developped for ezp3.10 version, but should work in ezp4 series two
  (didn't tried that yet).

* Didn't check the cache effects yet...

* I'm not an ezpublish guru, so any improvements are good wellcome

