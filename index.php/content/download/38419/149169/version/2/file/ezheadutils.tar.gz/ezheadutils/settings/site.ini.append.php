<?php  /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezheadutils

*/ ?>