<?php

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezdebug.php" );
include_once( 'lib/ezutils/classes/ezuri.php' );


class eZHeadUtilsOperator
{
    /*!
     Constructor
    */
    function eZHeadUtilsOperator()
    {
    }
    
    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'ezheadregister', 'ezheadwrite');
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    
        /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'ezheadregister' => array( 'file' => array( 'type' => 'string',
                                                                  'required' => false,
                                                                  'default' => '' ),
                                                 'options' => array( 'type' => 'array',
                                                                     'required' => false,
                                                                     'default' => array() ) 
                                                 ) 
                      );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {

        switch($operatorName) {
            
        case 'ezheadregister' :
            $operatorValue = $this->ezHeadRegister($namedParameters);
            break;
            
        case 'ezheadwrite' :
            $operatorValue = $this->ezHeadWrite();
            break;
        }
    }


    /*|
     Register a file to SESSION variable with headers
     */
    function ezHeadRegister(&$params) 
    {
        $file = $params['file'];
        $opts = $params['options'];
        
        if ( !preg_match('/\.css$/', $file) && !preg_match('/\.js$/', $file) ) {
            eZDebug::writeWarning( "Couldn't load header file $file, the file extension must be: (.css|.js)", 'ezHeadRegister' );
            return null;
        }

        $http =& eZHTTPTool::instance();
        
        if ( $http->hasSessionVariable('eZHeaderParts') && $http->hasSessionVariable('eZHeaderParts')!=null ) {
            $headers = $http->sessionVariable('eZHeaderParts');
        }
        else {
            $headers = array( 'css' => array(), 'js' => array() );
        }
        
        $ini =& eZINI::instance( 'site.ini' );

        // find design locals
        $iniDesign = $ini->variable( 'DesignSettings', 'SiteDesign' );
        $iniDesignAdditional = $ini->variable( 'DesignSettings', 'AdditionalSiteDesignList' );
        $allDesigns = array_merge( array($iniDesign), $iniDesignAdditional );
        
        foreach ($allDesigns as $dir) {
            $file = 'design'.DIRECTORY_SEPARATOR.$dir.DIRECTORY_SEPARATOR.$file;

            if ( file_exists($file) ) {
                $filePart = preg_split('/\./', $file, -1, PREG_SPLIT_OFFSET_CAPTURE);
                $extension = $filePart[sizeof($filePart)-1][0];
                eZURI::transformURI( $file, false, 'relative' );
                $el = array('file' => $file, 'options' => $opts);
                if ( !in_array($el, $headers[$extension]) ) {
                    $headers[$extension][] = $el;
                    break;
                }
                break;
            }
        }


        $http->setSessionVariable( 'eZHeaderParts' , $headers);
        return null;
    }


    /*|
     Outputs HTML for the headers
     */
    function ezHeadWrite() 
    {
        $http =& eZHTTPTool::instance();
        $headers = $http->sessionVariable( "eZHeaderParts");
        $html = "";

        foreach ($headers as $k => $hs) {
            if ( !empty($hs) ) {
                if ( $k == 'css' ) {
                    foreach ($hs as $d) {
                        $htmlOptions = '';
                        if ( !empty($d['options']) ) {
                            foreach ( $d['options'] as $name => $value ) {
                                $htmlOptions .= sprintf(' %s="%s" ', $name, $value);
                            }
                        }
                        $html .= sprintf('<link rel="stylesheet" type="text/css" href="%s" %s />', $d['file'], $htmlOptions);
                    }
                }
                
                if ( $k == 'js' ) {
                    foreach ($hs as $d) {
                        $htmlOptions = '';
                        if ( !empty($d['options']) ) {
                            foreach ( $d['options'] as $name => $value ) {
                                $htmlOptions .= sprintf(' $name="$value" ', $name, $value);
                            }
                        }
                        $html .= sprintf('<script type="text/javascript" src="%s" %s></script>', $d['file'], $htmlOptions);
                    }
                }
            }
        }
        
        // cleanUp session and return 
        $http->setSessionVariable( 'eZHeaderParts' , null);

        return $html;

    }


    // <link rel="stylesheet" type="text/css" href="demo_link.css" />
    //      // find extension designs
    //             $ini =& eZINI::instance( 'design.ini' );
    //             $extensionDesigns = $ini->variable( 'ExtensionSettings', 'DesignExtensions' );
    //             $extensionBaseDirectory = eZExtension::baseDirectory();
            

}
?>