<?php /* #?ini charset="iso-8859-1"?

[FacebookConnect]
APIKey=<Your API Key>
Secret=<Your Secret>
TemplateBundleID=<Your TemplateBundleID>
FBUID=<Your FBUID Attribute ID in Userclass>

*/ ?>