<?php

//
// Created on: <02-March-2009 14:23:00 ymc-sise>
//
// Copyright (C) 2009 YMC AG. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// If you wish to use this extension under conditions others than the
// GPL you need to contact Young MediaConcepts first (licence@ymc.ch).
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ymc.ch if any conditions of this licencing isn't clear to
// you.
//

//include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
//include_once( 'kernel/classes/ezpersistentobject.php' );

class eZFacebookUser extends eZUser
{
    function eZFacebookUser()
    {
    }

    // Override the original checkUser to add a check on the Facebook user
    function checkUser( &$siteBasics,$url )
    {
        // get user Facebook UID
        if ( file_exists('extension/facebook_connect/lib/facebook-platform/php/facebook.php') )
        {
            //include Facebook PHP API
            include_once('extension/facebook_connect/lib/facebook-platform/php/facebook.php');
            $contentINI = eZINI::instance( 'content.ini' );
            $apiKey = $contentINI->variable( 'FacebookConnect', 'APIKey' );
            $secret = $contentINI->variable( 'FacebookConnect', 'Secret' );
            $attributeID = $contentINI->variable( 'FacebookConnect', 'FBUID' );
            //instantiate Facebook
            $fb = new Facebook($apiKey, $secret);
            //check if Facebook User is logged in
            if ( $fb->get_loggedin_user()>0 )
            {
                $userUID = $fb->get_loggedin_user();
                if ( $userUID )
                {
                    $params = array(
                        'AttributeFilter'=>array(array($attributeID,'=',$userUID)),
                        'ClassFilterType'=>'include',
                        'ClassFilterArray'=>array('user'),
                        'Limitation'=>array());
                    //NodeID of user root
                    $nodeID = 5;
                    $userSubTree = eZContentObjectTreeNode::subTreeByNodeID( $params, $nodeID );
                    $userContentObjectID = $userSubTree[0]->attribute('contentobject_id');
                    $user =eZUser::fetch($userContentObjectID, true);
                    if ( $user and $user->isEnabled( ) )
                    {
                        $userID = $user->attribute( 'contentobject_id' );
                        eZUser::setCurrentlyLoggedInUser( $user, $userID );
                    }
                }
            }
        }
        return parent::checkUser(&$siteBasics,$url);
    }
}

?>