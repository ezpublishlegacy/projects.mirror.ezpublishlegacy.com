
Facebook Connect extension for eZ publish


 0. Features
************
The Facebook Connect extension integrates Facebook Connect API (http://wiki.developers.facebook.com/index.php/Client_Libraries) 
into eZ publish. It allows you to connect your website with Facebook.


 1. Usage
************
The Facebook Connect extension contains base files and the PHP API to make your eZ publish installation ready for Facebook Connect.

1. Build a Facebook Application http://www.facebook.com/developers/createapp.php. Complete your API Key and Secret in content.ini.append
2. To make FBML syntax workable add xmlns:fb="http://www.facebook.com/2008/fbml" in your <head> tag.
3. Add the following line in the <body> tag.
   <script src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php" type="text/javascript"></script>
4. Create the login button with <fb:login-button></fb:login-button>
5. Add some Javascript:

<script type="text/javascript">
  {def $apikey = ezini('FacebookConnect', 'APIKey', 'content.ini')
       $templateBundleID = ezini('FacebookConnect', 'TemplateBundleID', 'content.ini')}
  FB.init("{$apikey}", "{'xd_receiver'|ezurl(no)}");
</script>

6. Set a rewrite rule for the static xd_receiver.html which should be placed in root


For further informations have a look at:
http://wiki.developers.facebook.com/index.php/Trying_Out_Facebook_Connect or
http://www.devtacular.com/articles/bkonrad/how-to-integrate-with-facebook-connect/


 2. Login
************
If there is a fbuid attribute stored in user class, user will be fetched by fbuid and logged in automatically.
Add FBUID attribute ID in content.ini.append

The following lines have to be appended at the end of the site.ini.append.php:

[UserSettings]
LoginHandler[]=Facebook
ExtensionDirectory[]=facebook_connect


 3. Some Examples
************

Get the username:

Javascript:

<script type="text/javascript">
  var api = FB.Facebook.apiClient;
  // require user to login 
  FB.Connect.requireSession( function( exception )
  {
      var myQuery = 'SELECT name FROM user WHERE uid='+api.get_session().uid;
      api.fql_query(myQuery, getFQLResponse);
  });
  
  function getFQLResponse( result, exeption )
  {
    alert(result[0]['name']);
  }
</script>

PHP4:

<?
  include_once('extension/facebook_connect/lib/facebook-platform/php4/facebook.php');
  $contentINI =& eZINI::instance( 'content.ini' );
  $api_key = $contentINI->variable( 'FacebookConnect', 'APIKey' );
  $secret = $contentINI->variable( 'FacebookConnect', 'Secret' );
  $fb = new Facebook($api_key, $secret);
  if( $fb->get_loggedin_user()>0 )
  {
      $user = $fb->user;
      $userData = $fb->api_client->users_getInfo($user, array('first_name','last_name'));
      echo utf8_decode($userInfoFB[0]['first_name']) . utf8_decode($userInfoFB[0]['last_name']);
  }
?>