<?php /* #?ini charset="iso-8859-1"?

[RoleSettings]
PolicyOmitList[]=facebook/xd_receiver

*/ ?>