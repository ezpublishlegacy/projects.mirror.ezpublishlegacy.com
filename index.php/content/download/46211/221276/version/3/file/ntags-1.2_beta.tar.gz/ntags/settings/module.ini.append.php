<?php /* vim:set syntax=dosini:
[ModuleSettings]
ExtensionRepositories[]=ntags
ModuleList[]=ntags
*/
?>
