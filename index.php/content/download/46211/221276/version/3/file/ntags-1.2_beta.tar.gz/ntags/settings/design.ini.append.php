<?php /* vim:set syntax=dosini:
[ExtensionSettings]
DesignExtensions[]=ntags

[JavaScriptSettings]
JavaScriptList[]=namespace.js
JavaScriptList[]=ntags.js
JavaScriptList[]=labs_json.js
BackendJavaScriptList[]=namespace.js
BackendJavaScriptList[]=ntags.js
BackendJavaScriptList[]=labs_json.js
*/ ?>
