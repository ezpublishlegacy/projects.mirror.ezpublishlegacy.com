<?php /* vim:set syntax=dosini:
[RegionalSettings]
TranslationExtensions[]=ntags

[TemplateSettings]
ExtensionAutoloadPath[]=ntags
*/ ?>
