<?php /* vim:set syntax=dosini:
[NavigationPart]
Part[ntags]=Tags

[TopAdminMenu]
Tabs[]=ntags

[Topmenu_ntags]
Name=Tags
NavigationPartIdentifier=ntags
URL[]
URL[default]=ntags/multitag
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
