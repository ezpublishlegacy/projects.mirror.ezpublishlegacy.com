UPDATE ezsite_data SET value='3.8.2' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='8' WHERE name='ezpublish-release';
