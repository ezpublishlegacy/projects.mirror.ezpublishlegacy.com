<?php /*
[DatabaseSettings]
ImplementationAlias[ezoracle]=eZOracleDB
*/ ?>
