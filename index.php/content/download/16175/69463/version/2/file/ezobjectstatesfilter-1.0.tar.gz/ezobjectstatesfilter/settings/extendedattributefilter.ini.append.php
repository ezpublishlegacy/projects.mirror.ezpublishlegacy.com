<?php /*

[ObjectStateFilter]
ExtensionName=ezobjectstatesfilter
ClassName=eZObjectStatesFilter
MethodName=createSQLParts
FileName=classes/ezobjectstatesfilter.php



*/ ?>
