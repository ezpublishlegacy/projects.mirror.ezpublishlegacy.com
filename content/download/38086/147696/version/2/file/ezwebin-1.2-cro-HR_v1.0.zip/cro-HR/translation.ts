<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/article/article_index</name>
    <message>
        <source>Article index</source>
        <translation>Indeks članka</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/article/comments</name>
    <message>
        <source>Comments</source>
        <translation>Komentari</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Novi komentar</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/calendar</name>
    <message>
        <source>Previous month</source>
        <translation>Prethodni mjesec</translation>
    </message>
    <message>
        <source>Next month</source>
        <translation>Sljedeći mjesec</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Kalendar</translation>
    </message>
    <message>
        <source>Mon</source>
        <translation>Pon</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>Uto</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>Sri</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>Čet</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>Pet</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>Sub</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>Ned</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/extra_info</name>
    <message>
        <source>Tags</source>
        <translation>Tagovi</translation>
    </message>
    <message>
        <source>Archive</source>
        <translation>Arhiva</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Obrazac %formname</translation>
    </message>
    <message>
        <source>Thank you for your feedback.</source>
        <translation>Hvala Vam na povratnoj informaciji.</translation>
    </message>
    <message>
        <source>You have already submitted this form. The data you entered was:</source>
        <translation>Već ste ispunili ovaj obrazac. Podatke koje ste poslali su:</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Povratak na stranicu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Anketa %pollname</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Rezultati</translation>
    </message>
    <message>
        <source>Please log in to vote on this poll.</source>
        <translation>Molimo prijavite se na stranice da bi glasovali u ovoj anketi.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Već ste glasovali u ovoj anketi.</translation>
    </message>
    <message>
        <source>Votes</source>
        <translation>Glasovi</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>Ukupno glasova: %count</translation>
    </message>
    <message>
        <source>Back to poll</source>
        <translation>Povratak na anketu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/feedback</name>
    <message>
        <source>Feedback from %1</source>
        <translation>Povratne informacije od %1</translation>
    </message>
    <message>
        <source>The following feedback was collected</source>
        <translation>Prikupljene su sljedeće povratne informacije</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/form</name>
    <message>
        <source>Collected information from %1</source>
        <translation>Prikupljeni podaci sa %1</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>Prikupljene su sljedeće informacije</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearch</name>
    <message>
        <source>Advanced search</source>
        <translation>Napredno pretraživanje</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Traži sve riječi</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Traži točnu frazu</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Traži  barem jednu od unesenih riječi</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Objavljeno</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Bilo koje vrijeme</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>prethodni dan</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>prošli tjedan</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>posljednja tri mjeseca</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>prošle godine</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Broj rezultata po stranici</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 rezultata</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 rezultata</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 rezultata</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 rezultata</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 rezultata</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Ništa nije pronađeno za upit &apos;&apos;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Pronađeno je %2 rezultata koji su zadovoljili kriterije pretraživanja &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearchh</name>
    <message>
        <source>Last month</source>
        <translation>prošli mjesec</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Listaj</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
        <translation>Za odabir objekata koristite odgovarajuće radio gumbe ili polja za označavanje te pritisnite gumb &quot;Odaberi&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the parent object name to display a list of its children.</source>
        <translation>Za odabir objekta koji je dijete jednog od prikazanih objekata kliknite na naziv objekta i prikazat će vam se lista sve djece koja pripada objektu.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Natrag</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Glavna razina</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Odaberi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse_mode_list</name>
    <message>
        <source>Invert selection</source>
        <translation>Obrnuti odabir</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/diff</name>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Verzije za objekt &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verzija</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Prijevodi</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Kreirao</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Promijenjeno</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Skica</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Objavljeno</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Na čekanju</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Arhivirano</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Odbijeno</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Nepromijenjena skica</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Objekt nema niti jednu verziju.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Prikaz razlika</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Razlike između verzija %oldVersion i %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Stara verzija</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Inline promjene</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Blok promjene</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nova verzija</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/draft</name>
    <message>
        <source>Select all</source>
        <translation>Označi sve</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznači sve</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Moje skice</translation>
    </message>
    <message>
        <source>Empty draft</source>
        <translation>Prazna skica</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Ovo su trenutni objekti na kojima radite. Skice su u Vašem vlasništvu i samo ih Vi možete vidjeti.
      Možete mijenjati skice ili ih ukloniti ukoliko Vam više nisu potrebne.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcija</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verzija</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jezik</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Zadnja promjena</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Nemate skica</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Uređivanje %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Spremi skicu</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Odbaci skicu</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Upravljanje verzijama</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Spremi i izađi</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Pregled</translation>
    </message>
    <message>
        <source>Translate from</source>
        <translation>Prevedi iz</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Prevedi</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>dokumentacija</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <source>Not translatable</source>
        <translation>neprevodljiv</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Potreban</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Kolektor podataka</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_draft</name>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>Trenutačno objavljena verzija je %version, koja je objavljena u %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>Posljednja promjena unesena je u %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Objekt je vlaništvo %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by yourself and others.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Ovaj objekt već uređuje još netko osim Vas.
Možete nastaviti uređivati neku od svojih skica ili kreirati novu skicu.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Ovaj objekt vi već uređujete.
       Možete nastaviti uređivati jednu od svojih skica ili kreirati novu skicu.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about their draft or create a new draft for your own use.</source>
        <translation>Ovaj objekt već uređuje netko drugi.
      Trebali biste kontaktirati tu osobu u vezi skice ili kreirati novu skicu za vaše uređivanje.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Tekuće skice</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verzija</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Vlasnik</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Kreirano</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Zadnja promjena</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nova skica</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_languages</name>
    <message>
        <source>Existing languages</source>
        <translation>Postojeći jezici</translation>
    </message>
    <message>
        <source>Select the language you want to use when editing the object.</source>
        <translation>Odaberite jezik koji želite koristiti prilikom izmjene objekta.</translation>
    </message>
    <message>
        <source>New languages</source>
        <translation>Novi jezici</translation>
    </message>
    <message>
        <source>Select the language you want to add to the object.</source>
        <translation>Odaberite jezik koji želite dodati objektu.</translation>
    </message>
    <message>
        <source>Select the language the new translation will be based on.</source>
        <translation>Odaberite jezik na koji se odnosi novi prijevod.</translation>
    </message>
    <message>
        <source>Use an empty, untranslated draft</source>
        <translation>koristite praznu, neprevedenu skicu</translation>
    </message>
    <message>
        <source>You do not have permission to create a translation in another language.</source>
        <translation>Nemate dozvolu kreirati prijevod u drugom jeziku.</translation>
    </message>
    <message>
        <source>However, you can select one of the following languages for editing.</source>
        <translation>No, možete odabrati jedan od sljedećih jezika za uređivanje.</translation>
    </message>
    <message>
        <source>You do not have permission to edit the object in any available languages.</source>
        <translation>Nemate ovlasti za uređivanje objekta na bilo kojem dostupnom jeziku.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/history</name>
    <message>
        <source>Version not a draft</source>
        <translation>Verzija nije skica</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore. Only drafts can be edited.</source>
        <translation>Verziju %1 nije više moguće uređivati. Moguće je uređivati samo skice.</translation>
    </message>
    <message>
        <source>To edit this version, first create a copy of it.</source>
        <translation>Da bi mogli uređivati ovu verziju kreirajte kopiju.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Verzija nije vaša</translation>
    </message>
    <message>
        <source>Version %1 was not created by you. Only your own drafts can be edited.</source>
        <translation>Vi niste kreirali verziju %1. Možete uređivati samo vlastite skice.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Nije moguće kreirati novu verziju</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Prekoračeno je ograničenje povijesti pojedine verzije te niti jedna pohranjena verzija ne može biti uklonjena iz sustava.</translation>
    </message>
    <message>
        <source>You can either change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Možete promijeniti svoje postavke povijesti verzija u content.ini, ukloni skice ili uredi postojeće skice. </translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Verzije za objekt &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Obrni selekciju</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verzija</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Edited language</source>
        <translation>Dodaj jezik</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Kreirao</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Kreirano</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Promijenjeno</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Odaberite verziju #%version_number za brisanje.</translation>
    </message>
    <message>
        <source>Version #%version_number cannot be removed because it is either the published version of the object or because you do not have permission to remove it.</source>
        <translation>Verzija #%version_number ne može biti obrisana, jer je ili objavljena ili nemate dozvolu za brisanje.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Prikaži sadržaj verzije #%version_number. Prijevod: %translation.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Skica</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Objavljeno</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Na čekanju</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Arhivirano</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Odbijeno</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Nepromijenjena skica</translation>
    </message>
    <message>
        <source>There is no need to do a copies of untouched drafts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Napravi kopiju verzije #%version_number.</translation>
    </message>
    <message>
        <source>You cannot make copies of versions because you do not have permission to edit the object.</source>
        <translation>Ne možete napraviti kopiju verzije zato što nemate dozvole za uređivanje objekta.</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Uredi sadržaj verzije #%version_number.</translation>
    </message>
    <message>
        <source>You cannot edit the contents of version #%version_number either because it is not a draft or because you do not have permission to edit the object.</source>
        <translation>Ne možete uređivati sadržaj verzije #%version_number zato što nije skica ili nemate dozvolu uređivanja  za taj objekt.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Objekt nema niti jednu verziju.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Ukloni odabrano</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Ukloni odabrane verzije iz objekta.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Prikaži razliku</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Natrag</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Objavljena verzija</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Prijevodi</translation>
    </message>
    <message>
        <source>New drafts [%newerDraftCount]</source>
        <translation>Nove skice [%newerDraftCount]</translation>
    </message>
    <message>
        <source>This object does not have any drafts.</source>
        <translation>Objekt nema niti jednu skicu.</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Razlike između verzija %oldVersion i %newVersion</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Stara verzija</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Inline promjene</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Blok promjene</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Nova verzija</translation>
    </message>
    <message>
        <source>Back to history</source>
        <translation>Nazad na povijesne podatke</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/keyword</name>
    <message>
        <source>Keyword: %keyword</source>
        <translation>Ključna riječ: %keyword</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Za više opcija kod pretrage koristite %1Napredno pretraživanje%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Sljedeće riječi isključene su iz pretraživanja:</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;.</source>
        <translation>Ništa nije pronađeno za upit &apos;&apos;%1&quot;.</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Savjeti za pretraživanje</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Provjerite jeste li ispravno napisali ključne riječi.</translation>
    </message>
    <message>
        <source>Try changing some keywords (eg, &quot;car&quot; instead of &quot;cars&quot;).</source>
        <translation>Pokušajte promijeniti neke od ključnih riječi npr. automobil umjesto automobili.</translation>
    </message>
    <message>
        <source>Try searching with less specific keywords.</source>
        <translation>Probajte pretraživati sa manje specifičnim riječima.</translation>
    </message>
    <message>
        <source>Reduce number of keywords to get more results.</source>
        <translation>Smanjite broj riječi da bi dobili više rezultata.</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Pronađeno je %2 rezultata koji su zadovoljili kriterije pretraživanja &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Pošaljite na mail</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Poruka je poslana.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Pritisni ovdje za povratak na početnu stranicu.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Ova poruka nije poslana.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Ova poruka nije poslana zbog nepoznate greške. Molimo Vas da o greški obavijestite administratora. </translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Molimo ispravite sljedeće greške:</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Vaše ime</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Vaša adresa elektronske pošte</translation>
    </message>
    <message>
        <source>Recipient&apos;s email address</source>
        <translation>E-mail adresa primatelja</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentar</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Pošalji</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/view/versionview</name>
    <message>
        <source>Manage versions</source>
        <translation>Upravljanje verzijama</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Objavi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/comment</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Uređivanje %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odbaci</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/file</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Uređivanje %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odbaci</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_reply</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Uređivanje %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odbaci</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_topic</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Uređivanje %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odbaci</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/forum</name>
    <message>
        <source>Latest from</source>
        <translation>Zadnje od</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/poll</name>
    <message>
        <source>Vote</source>
        <translation>Glasuj</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezinfo/about</name>
    <message>
        <source>eZ Publish information: %version</source>
        <translation>eZ Publish info: %version</translation>
    </message>
    <message>
        <source>What is eZ Publish?</source>
        <translation>Što je eZ Publish?</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Doprinositelji</translation>
    </message>
    <message>
        <source>Copyright Notice</source>
        <translation>Obavijest o autorskim pravima</translation>
    </message>
    <message>
        <source>Third-Party Software</source>
        <translation>Softver trećih strana</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Ekstenzije</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation>Komentari</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Novi komentar</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>%login_link_startPrijavite se%login_link_end ili %create_link_startregistrirajte%create_link_end da bi mogli komentirati.</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Pošaljite na mail</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_mainpage</name>
    <message>
        <source>Tip a friend</source>
        <translation>Pošaljite na mail</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_subpage</name>
    <message>
        <source>Tip a friend</source>
        <translation>Pošaljite na mail</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/blog_post</name>
    <message>
        <source>Tags:</source>
        <translation>Tagovi:</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Komentari</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>%login_link_startPrijavite se%login_link_end se ili %create_link_startregistrirajte%create_link_end da bi mogli komentirati.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/documentation_page</name>
    <message>
        <source>Table of contents</source>
        <translation>Sadržak</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation>Kreirano:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Promijenjeno:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event</name>
    <message>
        <source>Category</source>
        <translation>Kategorija</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_calendar</name>
    <message>
        <source>Mon</source>
        <translation>Pon</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>Uto</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>Sri</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>Čet</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>Pet</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>Sub</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>Ned</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Danas</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategorija</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_program</name>
    <message>
        <source>Past events</source>
        <translation>Prethodna događanja</translation>
    </message>
    <message>
        <source>Future events</source>
        <translation>Sljedeća događanja</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/feedback_form</name>
    <message>
        <source>Send form</source>
        <translation>Pošalji</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <source>New topic</source>
        <translation>Nova tema</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Obavještavaj me o novim porukama</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Morate biti prijavljeni kako bi imali pristup forumu. Prijaviti se možete na sljedeći način: %login_link_start%ovdje%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Odgovori</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Posljednji odgovor</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Stranice</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_reply</name>
    <message>
        <source>Message preview</source>
        <translation>Pregled poruke</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lokacija</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Promijenio</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_topic</name>
    <message>
        <source>Previous topic</source>
        <translation>Prethodna tema</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Sljedeća tema</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Novi odgovor</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Obavještavaj me o novim porukama</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Morate biti prijavljeni kako bi imali pristup forumu. Prijaviti se možete na sljedeći način: %login_link_start%ovdje%login_link_end%</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Poruka</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lokacija</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Promijenio</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Ukloni ovaj element.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forums</name>
    <message>
        <source>Topics</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Posts</source>
        <translation>Pošalji</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Posljednji odgovor</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/gallery</name>
    <message>
        <source>View as slideshow</source>
        <translation>Pregledaj u nizu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/image</name>
    <message>
        <source>Previous image</source>
        <translation>Prethodna slika</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Sljedeća slika</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/multicalendar</name>
    <message>
        <source>Event</source>
        <translation>Događanje</translation>
    </message>
    <message>
        <source>Start date</source>
        <translation>Datum početka</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategorija</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/poll</name>
    <message>
        <source>Vote</source>
        <translation>Glasuj</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Rezultat</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to basket</source>
        <translation>Dodaj u košaricu</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Dodaj na listu želja</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Osobe koje su kupile ovaj proizvod također su kupile</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event</name>
    <message>
        <source>Category</source>
        <translation>Kategorija</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event_calendar</name>
    <message>
        <source>Next events</source>
        <translation>Sljedeća događanja</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/flash</name>
    <message>
        <source>View flash</source>
        <translation>Pregledaj Flash</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum</name>
    <message>
        <source>Number of topics</source>
        <translation>Broj tema</translation>
    </message>
    <message>
        <source>Number of posts</source>
        <translation>Broj poruka</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Posljednji odgovor</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Uključi se u forum</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum_reply</name>
    <message>
        <source>Reply to:</source>
        <translation>Odgovor na:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/poll</name>
    <message>
        <source>%count votes</source>
        <translation>%count glasova</translation>
    </message>
    <message>
        <source>Vote</source>
        <translation>Glasuj</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/quicktime</name>
    <message>
        <source>View movie</source>
        <translation>Pregledaj film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/real_video</name>
    <message>
        <source>View movie</source>
        <translation>Pregledaj film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/windows_media</name>
    <message>
        <source>View movie</source>
        <translation>Pregledaj film</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/link</name>
    <message>
        <source>%sitetitle front page</source>
        <translation>%sitetitle početna stranica</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Traži %sitetitle</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Verzija za ispis</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/node/removeobject</name>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Jeste li sigurni da želite ukloniti navedene elemente?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename i njegovu %childcount djecu. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Premjesti u smeće</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Napomena</translation>
    </message>
    <message>
        <source>If %trashname is checked, removed items can be found in the trash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/addingresult</name>
    <message>
        <source>Add to my notifications</source>
        <translation>Dodaj u moje obavijesti</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>Obavijest za čvor &lt;%node_name&gt; već postoji.</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>Obavijest za čvor &lt;%node_name&gt; je uspješno dodana..</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>U redu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/settings</name>
    <message>
        <source>Notification settings</source>
        <translation>Postavke obavijesti</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Spremi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/parts/website_toolbar</name>
    <message>
        <source>About</source>
        <translation>O</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Kreiraj ovdje</translation>
    </message>
    <message>
        <source>Edit: %node_name [%class_name]</source>
        <translation>Uredi klasu [%class_name]</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Premjesti</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Dodaj lokacije</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>dokumentacija</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Zamijeni</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Izvezi</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Uvezi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/settings/edit</name>
    <message>
        <source>Node notification</source>
        <translation>Obavijest čvora</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcija</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Odaberi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <source>Shopping basket</source>
        <translation>Košarica za kupovinu</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Podaci o računu</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Potvrdi narudžbu</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Košarica</translation>
    </message>
    <message>
        <source>The following items were removed from your basket because the products were changed.</source>
        <translation>Slijedeći artikli su uklonjeni iz Vaše košarice, jer su proizvodi izmijenjeni.</translation>
    </message>
    <message>
        <source>VAT is unknown</source>
        <translation>PDV je nepoznat</translation>
    </message>
    <message>
        <source>VAT percentage is not yet known for some of the items being purchased.</source>
        <translation>Postotak PDV-a je nepoznat za pojedine odabrane proizvode.</translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation>Ovo vjerovatno znači da su pojedine kontaktne ili osobne informacije o Vama još nepoznate i biti će dobivene prilikom kupnje.</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Pokušaj stavljanja proizvoda bez cijene u košaricu.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Plaćanje je prekinuto.</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Zbroj</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>PDV</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cijena s PDV-om</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Popust</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Ukupna cijena bez PDV-a</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Ukupna cijena sa PDV-om</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nepoznato</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Ažuriraj</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Odabrane opcije</translation>
    </message>
    <message>
        <source>Subtotal ex. VAT</source>
        <translation>Međuzbroj bez PDV-a(</translation>
    </message>
    <message>
        <source>Subtotal inc. VAT</source>
        <translation>Međuzbroj sa PDV-om</translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation>Dostava</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Ukupno narudžbe</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Nastavi kupovinu</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Narudžba</translation>
    </message>
    <message>
        <source>You have no products in your basket.</source>
        <translation>Vaša košarica je prazna.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/confirmorder</name>
    <message>
        <source>Shopping basket</source>
        <translation>Košarica za kupovinu</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Podaci o računu</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Potvrdi narudžbu</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Proizvodi</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Zbroj</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>PDV</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cijena s PDV-om</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Popust</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Ukupna cijena bez PDV-a</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Ukupna cijena sa PDV-om</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Odabrane opcije</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sažetak narudžbe</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Međuzbroj proizvoda</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Ukupno narudžbe</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/customerorderview</name>
    <message>
        <source>Customer information</source>
        <translation>Podaci o kupcu</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista narudžbi</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Ukupno bez PDV-a</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Ukupno sa PDV-om</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Kupovna lista</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Proizvod</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Iznos</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderlist</name>
    <message>
        <source>Order list</source>
        <translation>Lista narudžbi</translation>
    </message>
    <message>
        <source>Sort result by</source>
        <translation>Poredaj rezultate po</translation>
    </message>
    <message>
        <source>Order time</source>
        <translation>Vrijeme narudžbe</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Ime korisnika</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>ID broj narudžbe</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Uzlazno</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>Poredaj uzlazno</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Silazno</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>Poredaj silazno</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Poredaj</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Kupac</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Ukupno bez PDV-a</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Ukupno sa PDV-om</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Lista narudžbi je prazna</translation>
    </message>
    <message>
        <source>Archive</source>
        <translation>Arhiva</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderview</name>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Narudžba %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Proizvodi</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Proizvod</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Zbroj</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>PDV</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cijena s PDV-om</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Popust</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Ukupna cijena bez PDV-a</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Ukupna cijena sa PDV-om</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sažetak narudžbe</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sažetak</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Međuzbroj proizvoda</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Ukupno narudžbe</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>Povijest narudžbi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/userregister</name>
    <message>
        <source>Shopping basket</source>
        <translation>Košarica za kupovinu</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Podaci o računu</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Potvrdi narudžbu</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Podaci o Vašem računu</translation>
    </message>
    <message>
        <source>Input did not validate. All fields marked with * must be filled in.</source>
        <translation>Unos nije ispravan. Ava polja označena sa * moraju biti popunjena.</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Prezime</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Elektronska pošta</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Tvrtka</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Ulica</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>Poštanski broj</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Mjesto</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Regija</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Zemlja</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Nastavi</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Sva polja označena sa * moraju biti popunjena.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/wishlist</name>
    <message>
        <source>Wish list</source>
        <translation>Lista želja</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Proizvod</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Zbroj</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Odabrane opcije</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Spremi</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Ukloni elemente</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Lista želja je prazna</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/simplified_treemenu/show_simplified_menu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Zatvori/otvori</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>Čvor ID: %node_id Vidljivost: %visibility</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/activate</name>
    <message>
        <source>Activate account</source>
        <translation>Aktivirajte račun</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Vaš je račun aktiviran.</translation>
    </message>
    <message>
        <source>Your account is already active.</source>
        <translation>Vaš račun je već aktiviran.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Nažalost, uneseni ključ nije odgovarajući ključ. Račun nije aktiviran.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <source>User profile</source>
        <translation>Profil korisnika</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Korisničko ime</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Elektronska pošta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Moje skice</translation>
    </message>
    <message>
        <source>My orders</source>
        <translation>Moje narudžbe</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Postavke za moje obavijesti</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation>Moja lista želja</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Uredi profil</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Izmjena lozinke</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/forgotpassword</name>
    <message>
        <source>An email has been sent to the following address: %1. It contains a link you need to click so that we can confirm that the correct user has received the new password.</source>
        <translation>Poslana je email poruka na sljedeću adresu: %1. Poruka sadržava link na koji trebate kliknuti kako bi znali da je pravi korisnik primio novu lozinku.</translation>
    </message>
    <message>
        <source>There is no registered user with that email address.</source>
        <translation>Nije registriran korisnik sa tom email adresom.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Lozinka je uspješno kreirana i poslana na: %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>Ključ nije valjan ili je već bio korišten.</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Zaboravili ste svoju lozinku?</translation>
    </message>
    <message>
        <source>If you have forgotten your password, enter your email address and we will create a new password and send it to you.</source>
        <translation>Ako ste zaboravili svoju lozinku, unesite vašu email adresu na koju ćemo vam poslati novu lozinku.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Elektronska pošta</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Kreiraj novu lozinku</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/login</name>
    <message>
        <source>Login</source>
        <translation>Prijava</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Prijava nije bila moguća</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Unesite valjano korisničko ime i lozinku.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Nije dozvoljen pristup</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Nije vam dozvoljen pristup na %1.</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation>Korisničko ime</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Lozinka</translation>
    </message>
    <message>
        <source>Log in to the eZ Publish Administration Interface</source>
        <translation>Prijavite se na administracijsko sučelje</translation>
    </message>
    <message>
        <source>Remember me</source>
        <translation>Zapamti me</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Prijava</translation>
    </message>
    <message>
        <source>Sign up</source>
        <comment>Button</comment>
        <translation>Registrirajte se</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Zaboravili ste lozinku?</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <source>Register user</source>
        <translation>Registracija korisnika</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Unos nije valjan</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Unos je uspješno pohranjen</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registriraj se</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odbaci</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Nije moguće kreirati novog korisnika</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Natrag</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/success</name>
    <message>
        <source>User registered</source>
        <translation>Korisnik registriran</translation>
    </message>
    <message>
        <source>Your account was successfully created. An email will be sent to the specified address. Follow the instructions in that email to activate your account.</source>
        <translation>Vaš korisnički račun je uspješno kreiran. Poslana vam je email poruka na adresu koju ste naveli. Slijedite upute u toj poruci da bi aktivirali vaš korisnički račun.</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Vaš je račun uspješno otvoren.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <source>The file could not be found.</source>
        <translation>Datoteka ne može biti pronađena.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezprice</name>
    <message>
        <source>Price</source>
        <translation>Cijena</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Vaša cijena</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Vaša ušteda</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/sitemap</name>
    <message>
        <source>Site map</source>
        <translation>Mapa weba</translation>
    </message>
</context>
</TS>
