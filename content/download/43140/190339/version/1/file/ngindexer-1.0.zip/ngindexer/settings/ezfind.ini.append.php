<?php /* #?ini charset="utf-8"?

[SolrFieldMapSettings]
CustomMap[ngindexer]=ezfSolrDocumentFieldNgIndexer
*/ ?>
