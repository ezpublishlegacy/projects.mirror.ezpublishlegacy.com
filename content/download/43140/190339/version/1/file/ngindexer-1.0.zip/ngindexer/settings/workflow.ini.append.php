<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=ngindexer
AvailableEventTypes[]=event_ngindexer
*/ ?>
