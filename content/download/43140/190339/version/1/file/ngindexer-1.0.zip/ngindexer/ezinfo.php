<?php

class ngIndexerInfo
{
    static function info()
    {
        return array( 'Name'      => '<a href="http://projects.ez.no/ngindexer">Netgen Indexer</a> extension',
                      'Version'   => '1.0',
                      'Copyright' => 'Copyright (C) 2011 Netgen d.o.o.',
                      'License'   => 'GNU General Public License v2.0' );
    }
}

?>
