<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_IT">
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Survey</source>
        <translation>Indagine</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Id nodo</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>Id oggetto</translation>
    </message>
    <message>
        <source>Another language</source>
        <translation>Altra lingua</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Modifica i contenuti di questo elemento.</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Non disponibile</translation>
    </message>
    <message>
        <source>You do not have permission to edit this item.</source>
        <translation>Non sei abilitato a modificare questo elemento.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Sposta</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Sposta questo elemento in un&apos;altra collocazione.</translation>
    </message>
    <message>
        <source>You do not have permission to move this item to another location.</source>
        <translation>Non sei abilitato a spostare questo elemento in un&apos;altra collocazione.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Elimina questo elemento.</translation>
    </message>
    <message>
        <source>You do not have permission to remove this item.</source>
        <translation>Non sei abilitato ad eliminare questo elemento.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/survey/menu</name>
    <message>
        <source>Survey</source>
        <translation>Indagine</translation>
    </message>
    <message>
        <source>Survey list</source>
        <translation>Elenco questionari</translation>
    </message>
    <message>
        <source>Related object configuration</source>
        <translation>Configurazione oggetti correlati</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation>Commenti</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Nuovo commento</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>%login_link_startLog in%login_link_end o %create_link_startcreate un account utente%create_link_end per commentare.</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Segnala ad un amico</translation>
    </message>
</context>
<context>
    <name>ezsurvey/datatypes</name>
    <message>
        <source>Survey</source>
        <comment>Datatype name</comment>
        <translation>Indagine</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Missing survey input.</source>
        <translation>Inserimento questionario mancante.</translation>
    </message>
</context>
<context>
    <name>survey</name>
    <message>
        <source>Email entry</source>
        <translation>Inserimento e-mail</translation>
    </message>
    <message>
        <source>Text of question</source>
        <translation>Testo della domanda</translation>
    </message>
    <message>
        <source>Mandatory answer</source>
        <translation>Risposta obbligatoria</translation>
    </message>
    <message>
        <source>Default answer</source>
        <translation>Risposta predefinita</translation>
    </message>
    <message>
        <source>Formatted Paragraph</source>
        <translation>Paragrafo formattato</translation>
    </message>
    <message>
        <source>Text of paragraph</source>
        <translation>Testo del paragrafo</translation>
    </message>
    <message>
        <source>Single/Multiple choice</source>
        <translation>Scelta singola/multipla</translation>
    </message>
    <message>
        <source>Rendering style</source>
        <translation>Stile visualizzazione</translation>
    </message>
    <message>
        <source>Radio buttons in a row</source>
        <translation>Pulsanti radio in una riga</translation>
    </message>
    <message>
        <source>Radio buttons in a column</source>
        <translation>Pulsanti radio in una colonna</translation>
    </message>
    <message>
        <source>Checkboxes in a row</source>
        <translation>Checkboxes in una riga</translation>
    </message>
    <message>
        <source>Checkboxes in a column</source>
        <translation>Checkboxes in una colonna</translation>
    </message>
    <message>
        <source>Selector</source>
        <translation>Selettore</translation>
    </message>
    <message>
        <source>Option label</source>
        <translation>Etichetta opzione</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Selezionato</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Ordine</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Selezionato</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nuova opzione</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Elimina selezionati</translation>
    </message>
    <message>
        <source>Number entry</source>
        <translation>Inserimento numerico</translation>
    </message>
    <message>
        <source>Integer values only</source>
        <translation>Solo valori interi</translation>
    </message>
    <message>
        <source>Minimum value</source>
        <translation>Valore minimo</translation>
    </message>
    <message>
        <source>Maximum value</source>
        <translation>Valore massimo</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>Paragrafo</translation>
    </message>
    <message>
        <source>Receiver</source>
        <translation>Ricevente</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Section header</source>
        <translation>Intestazione sezione</translation>
    </message>
    <message>
        <source>Text of header</source>
        <translation>Testo intestazione</translation>
    </message>
    <message>
        <source>Text entry</source>
        <translation>Inserimento testo</translation>
    </message>
    <message>
        <source>Number of columns for an answer textarea</source>
        <translation>Numero delle colonne per un&apos;area testuale</translation>
    </message>
    <message>
        <source>Number of rows</source>
        <translation>Numero righe</translation>
    </message>
    <message>
        <source>Survey title</source>
        <translation>Titolo questionario</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Abilitato</translation>
    </message>
    <message>
        <source>Valid from</source>
        <translation>Valido da</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Anno</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mese</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Giorno</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Ora</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuti</translation>
    </message>
    <message>
        <source>No limitation</source>
        <translation>Nessuna limitazione</translation>
    </message>
    <message>
        <source>Valid to</source>
        <translation>Valido fino al</translation>
    </message>
    <message>
        <source>After &quot;Cancel&quot; redirect to URL</source>
        <translation>Dopo &quot;Annulla&quot; reindirizza alla URL</translation>
    </message>
    <message>
        <source>After &quot;Submit&quot; redirect to URL</source>
        <translation>Dopo &quot;Invia&quot; reindirizza alla URL</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Copy question</source>
        <translation>Copia domanda</translation>
    </message>
    <message>
        <source>Add question</source>
        <translation>Aggiungi domanda</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Pubblica</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <source>Apply and Preview</source>
        <translation>Applica e Visualizza</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Avviso</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Risultati</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Last answers</source>
        <translation>Ultime risposte</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Conteggio</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Percentuale</translation>
    </message>
    <message>
        <source>No results yet.</source>
        <translation>Ancora nessun risultato.</translation>
    </message>
    <message>
        <source>Participiant:</source>
        <translation>Partecipante:</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Invia</translation>
    </message>
    <message>
        <source>Please answer the question %number as well!</source>
        <translation>Sei pregato di rispondere anche alla domanda %number !</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not a valid email address!</source>
        <translation>Il testo inserito nella domanda %number non è un indirizzo email valido!</translation>
    </message>
    <message>
        <source>You must enter the value for an option in the question with id %question!</source>
        <translation>Devi inserire il valore per una opzione nella domanda con id %question!</translation>
    </message>
    <message>
        <source>Options in the question with id %question must have unique values!</source>
        <translation>Le opzioni nella domanda con id %question devono avere un valore unico!</translation>
    </message>
    <message>
        <source>Single/Multiple Choice</source>
        <translation>Scelta singola/multipla</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not an integer number!</source>
        <translation>Il testo inserito nella domanda %number non è un numero intero!</translation>
    </message>
    <message>
        <source>Entered text in the question %number is not a number!</source>
        <translation>Il testo inserito nella domanda %number non è un numero!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not lower than or equal to %max!</source>
        <translation>Il testo inserito nella domanda %number non è un numero intero o non è minore di o uguale a %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be lower than or equal to %max!</source>
        <translation>Il testo inserito nella domanda %number deve essere minore di o uguale a %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not greater than or equal to %min!</source>
        <translation>Il testo inserito nella domanda %number non è un numero intero o non è maggiore di o uguale a %min!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be greater than or equal to %min!</source>
        <translation>Il testo inserito nella domanda %number deve essere maggiore di o uguale a %min!</translation>
    </message>
    <message>
        <source>Entered number in the question %number is not integer or is not between %min and %max!</source>
        <translation>Il testo inserito nella domanda %number non è un numero intero o non è compreso tra %min e %max!</translation>
    </message>
    <message>
        <source>Entered number in the question %number must be between %min and %max!</source>
        <translation>Il testo inserito nella domanda %number deve essere compreso tra %min e %max!</translation>
    </message>
    <message>
        <source>Entered text in the question with id %number is not an integer number!</source>
        <translation>Il testo inserito nella domanda con id %number non è un numero intero!</translation>
    </message>
    <message>
        <source>Entered text in the question with id %number is not an number!</source>
        <translation>Il testo inserito nella domanda con id %number non è un numero!</translation>
    </message>
    <message>
        <source>Entered text &apos;%text&apos; in the question with id %number is not an email address!</source>
        <translation>Il testo &apos;%text&apos; inserito nella domanda con id %number non è un indirizzo!</translation>
    </message>
    <message>
        <source>Survey</source>
        <translation>Questionario</translation>
    </message>
    <message>
        <source>No results</source>
        <translation>Nessun risultato</translation>
    </message>
    <message>
        <source>Survey Preview</source>
        <translation>Anteprima questionario</translation>
    </message>
    <message>
        <source>Result overview</source>
        <translation>Anteprima Risultati</translation>
    </message>
    <message>
        <source>N. B. If you enter just one email address, user will not see this question. Instead the posting
will be directly sent to the address.</source>
        <translation>NB: Se inserisci soltanto un indirizzo email, l&apos;utente non vedrà questa domanda. Invece l&apos;invio verrà direttamente inviato all&apos;indirizzo indicato.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>id</source>
        <translation>id</translation>
    </message>
    <message>
        <source>Persistent user input. ( Users will be able to edit survey later. )</source>
        <translation>Inserimento dell&apos;utente persistente. (Gli utenti potranno modificare il questionario successivamente.)</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Visibile</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the survey &apos;%1&apos; with all evaluations?</source>
        <translation>Sei sicuro di voler cancellare il questionario &apos;%1&apos; con tutte le valutazioni?</translation>
    </message>
    <message>
        <source>Participant</source>
        <translation>Partecipante</translation>
    </message>
    <message>
        <source>Evaluated</source>
        <translation>Valutato</translation>
    </message>
    <message>
        <source>Questions marked with %mark% are required.</source>
        <translation>Le domande segnate con %mark% sono obbligatorie.</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>Embedded form</source>
        <translation>Modulo incluso</translation>
    </message>
    <message>
        <source>Only one answer allowed.</source>
        <translation>Puoi dare solo un&apos;unica risposta.</translation>
    </message>
    <message>
        <source>Active from</source>
        <translation>Attivo da</translation>
    </message>
    <message>
        <source>Active to</source>
        <translation>Attivo fino a</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Nuovo attributo</translation>
    </message>
    <message>
        <source>You need to log in in order to answer this survey</source>
        <translation>Devi essere loggato per rispondere al questionario</translation>
    </message>
    <message>
        <source>The survey is not active</source>
        <translation>Il questionario non è attivo</translation>
    </message>
    <message>
        <source>The survey does already have an answer from you</source>
        <translation>Il questionario è già stato compilato da te</translation>
    </message>
    <message>
        <source>Default settings</source>
        <translation>Impostazioni predefinite</translation>
    </message>
    <message>
        <source>User email</source>
        <translation>Email utente</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Add extra option</source>
        <translation>Aggiungi opzione extra</translation>
    </message>
    <message>
        <source>Presel.</source>
        <translation>Presel.</translation>
    </message>
    <message>
        <source>Related object entry</source>
        <translation>Inserimento oggetti correlati</translation>
    </message>
    <message>
        <source>Edit survey</source>
        <translation>Modifica questionario</translation>
    </message>
    <message>
        <source>Survey list</source>
        <translation>Elenco questionari</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Persistent</source>
        <translation>Persisente</translation>
    </message>
    <message>
        <source>Activity</source>
        <translation>Attività</translation>
    </message>
    <message>
        <source>Answers</source>
        <translation>Risposte</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <source>Not started</source>
        <translation>Non iniziato</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Aperto</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>Chiuso</translation>
    </message>
    <message>
        <source>Filled Survey</source>
        <translation>Questionario completato</translation>
    </message>
    <message>
        <source>The following information was collected as the result of the survey:</source>
        <translation>Sono state raccolte le seguenti informazioni come risultato dell&apos;indagine:</translation>
    </message>
    <message>
        <source>Related object configuration</source>
        <translation>Configurazione oggetti correlati</translation>
    </message>
    <message>
        <source>Set the parent node for the survey attributes, which are of the type Related Object</source>
        <translation>Imposta il nodo padre degli attributi del questionario, che sono del tipo Oggetti Correlati</translation>
    </message>
    <message>
        <source>Content class.</source>
        <translation>Classe contenuto.</translation>
    </message>
    <message>
        <source>Set the parent folder for the survey attributes.</source>
        <translation>Imposta la cartella padre degli attributi del questionario.</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <source>Browse for the parent node for the related survey attributes.</source>
        <translation>Sfoglia il nodo padre degli attributi correlati del questionario.</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Aggiorna tutti</translation>
    </message>
    <message>
        <source>Update the configuration.</source>
        <translation>Aggiorna la configurazione.</translation>
    </message>
    <message>
        <source>Survey result overview</source>
        <translation>Panoramica dei risultati dell&apos;indagine</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sommario</translation>
    </message>
    <message>
        <source>has %count answers.</source>
        <translation>ha %count risposte.</translation>
    </message>
    <message>
        <source>Edit survey results for: %result</source>
        <translation>Modifica i risultati dell&apos;indagine per: %result</translation>
    </message>
    <message>
        <source>Survey result</source>
        <translation>Risultati indagine</translation>
    </message>
    <message>
        <source>Survey results for %results</source>
        <translation>Risultati dell&apos;indagine per %results</translation>
    </message>
    <message>
        <source>All evaluations</source>
        <translation>Tutte le valutazioni</translation>
    </message>
    <message>
        <source>Evaluated:</source>
        <translation>Valutato:</translation>
    </message>
    <message>
        <source>The survey is not valid. Survey ID is missing</source>
        <translation>Il questionario non è valido. Manca l&apos;ID del questionario</translation>
    </message>
    <message>
        <source>All values in Valid from need to be numeric.</source>
        <translation>Tutti i valori devono essere numerici.</translation>
    </message>
    <message>
        <source>Email addresses in the question with id %number must have unique values!</source>
        <translation>Gli indirizzi email nella domanda con id %number devono essere valori unici!</translation>
    </message>
    <message>
        <source>Uncheck options</source>
        <translation>Opzioni deselezionate</translation>
    </message>
    <message>
        <source>Uncheck option</source>
        <translation>Opzione deselezionata</translation>
    </message>
    <message>
        <source>Add new</source>
        <translation>Aggiungi nuovo</translation>
    </message>
    <message>
        <source>Enter the button &apos;Add existing&apos; or &apos;Add new&apos; to create a new related object to the survey.</source>
        <translation>Premi il pulsante &quot;Aggiungi esestente&quot; o &quot;Aggiungi nuovo&quot; per creare un nuovo oggetto correlato al questionario.</translation>
    </message>
</context>
</TS>
