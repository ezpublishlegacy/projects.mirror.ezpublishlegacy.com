<?php
//
// Definition of EnhancedeZBinaryFileType class
//
// Created on: <30-Apr-2002 13:06:21 bf>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*!
  \class EnhancedeZBinaryFileType ezbinaryfiletype.php
  \ingroup eZDatatype
  \brief The class EnhancedeZBinaryFileType handles files and association with content objects

*/

include_once( "kernel/classes/ezdatatype.php" );
include_once( "kernel/classes/datatypes/ezbinaryfile/ezbinaryfile.php" );
include_once( "kernel/classes/ezbinaryfilehandler.php" );
include_once( "lib/ezfile/classes/ezfile.php" );
include_once( "lib/ezfile/classes/ezfilehandler.php");
include_once( "lib/ezutils/classes/ezsys.php" );
include_once( "lib/ezutils/classes/ezmimetype.php" );
include_once( "lib/ezutils/classes/ezhttpfile.php" );
include_once( 'lib/ezxml/classes/ezxml.php' );

define( 'EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD', 'data_int1' );
define( 'EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_VARIABLE', '_enhancedezbinaryfile_max_filesize_' );
define( "EZ_DATATYPESTRING_ENHANCEDBINARYFILE", "enhancedezbinaryfile" );

class EnhancedeZBinaryFileType extends eZDataType
{

    function EnhancedeZBinaryFileType()
    {
        $this->eZDataType( EZ_DATATYPESTRING_ENHANCEDBINARYFILE, ezi18n( 'kernel/classes/datatypes', "Enhanced File", 'Datatype name' ),
                           array( 'serialize_supported' => true,
                           'object_serialize_map' => array( 'data_text' => 'filename' )) );
    }

    /*!
     \return the binary file handler.
    */
    function &fileHandler()
    {
        return eZBinaryFileHandler::instance();
    }

    /*!
     \reimp
     \return the template name which the handler decides upon.
    */
    function &viewTemplate( &$contentobjectAttribute )
    {
        $handler =& $this->fileHandler();
        $handlerTemplate = $handler->viewTemplate( $contentobjectAttribute );
        $template = $this->DataTypeString;
        if ( $handlerTemplate !== false )
            $template .= '_' . $handlerTemplate;
        return $template;
    }

    /*!
     \return the template name to use for editing the attribute.
     \note Default is to return the datatype string which is OK
           for most datatypes, if you want dynamic templates
           reimplement this function and return a template name.
     \note The returned template name does not include the .tpl extension.
     \sa viewTemplate, informationTemplate
    */
    function &editTemplate( &$contentobjectAttribute )
    {
        $handler =& $this->fileHandler();
        $handlerTemplate = $handler->editTemplate( $contentobjectAttribute );
        $template = $this->DataTypeString;
        if ( $handlerTemplate !== false )
            $template .= '_' . $handlerTemplate;
        return $template;
    }

    /*!
     \return the template name to use for information collection for the attribute.
     \note Default is to return the datatype string which is OK
           for most datatypes, if you want dynamic templates
           reimplement this function and return a template name.
     \note The returned template name does not include the .tpl extension.
     \sa viewTemplate, editTemplate
    */
    function &informationTemplate( &$contentobjectAttribute )
    {
        $handler =& $this->fileHandler();
        $handlerTemplate = $handler->informationTemplate( $contentobjectAttribute );
        $template = $this->DataTypeString;
        if ( $handlerTemplate !== false )
            $template .= '_' . $handlerTemplate;
        return $template;
    }

    /*!
     Sets value according to current version
    */
    function initializeObjectAttribute( &$contentObjectAttribute, $currentVersion, &$originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $contentObjectAttributeID = $originalContentObjectAttribute->attribute( "id" );
            $version = $contentObjectAttribute->attribute( "version" );
            $oldfile =& eZBinaryFile::fetch( $contentObjectAttributeID, $currentVersion );
            if ( $oldfile != null )
            {
                $oldfile->setAttribute( 'contentobject_attribute_id', $contentObjectAttribute->attribute( 'id' ) );
                $oldfile->setAttribute( "version",  $version );
                $oldfile->store();
            }
        }
    }

    /*!
     Delete stored attribute
    */
    function deleteStoredObjectAttribute( &$contentObjectAttribute, $version = null )
    {
        $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
        $binaryFiles =& eZBinaryFile::fetch( $contentObjectAttributeID );
        $sys =& eZSys::instance();
        $storage_dir = $sys->storageDirectory();

        if ( $version == null )
        {
            foreach ( array_keys( $binaryFiles ) as $key )
            {
                $binaryFile =& $binaryFiles[$key];
                $mimeType =  $binaryFile->attribute( "mime_type" );
                list( $prefix, $suffix ) = split ('[/]', $mimeType );
                $orig_dir = $storage_dir . '/original/' . $prefix;
                $fileName = $binaryFile->attribute( "filename" );
                if ( file_exists( $orig_dir . "/" .$fileName ) )
                    unlink( $orig_dir . "/" . $fileName );
            }
        }
        else
        {
            $count = 0;
            $currentBinaryFile =& eZBinaryFile::fetch( $contentObjectAttributeID, $version );
            if ( $currentBinaryFile != null )
            {
                $mimeType =  $currentBinaryFile->attribute( "mime_type" );
                $currentFileName = $currentBinaryFile->attribute( "filename" );
                list( $prefix, $suffix ) = split ('[/]', $mimeType );
                $orig_dir = $storage_dir . "/original/" . $prefix;

                foreach ( array_keys ( $binaryFiles ) as $key )
                {
                    $binaryFile =& $binaryFiles[$key];
                    $fileName = $binaryFile->attribute( "filename" );
                    if ( $currentFileName == $fileName )
                        $count += 1;
                }
                if ( $count == 1 )
                {
                    if ( file_exists( $orig_dir . "/" . $currentFileName ) )
                        unlink( $orig_dir . "/" .  $currentFileName );
                }
            }
        }
        eZBinaryFile::remove( $contentObjectAttributeID, $version );
    }

    /*!
     Checks if file uploads are enabled, if not it gives a warning.
    */
    function checkFileUploads()
    {
        $isFileUploadsEnabled = ini_get( 'file_uploads' );
        if ( !$isFileUploadsEnabled )
        {
            $isFileWarningAdded =& $GLOBALS['EnhancedeZBinaryFileTypeWarningAdded'];
            if ( !isset( $isFileWarningAdded ) or
                 !$isFileWarningAdded )
            {
                eZAppendWarningItem( array( 'error' => array( 'type' => 'kernel',
                                                              'number' => EZ_ERROR_KERNEL_NOT_AVAILABLE ),
                                            'text' => ezi18n( 'kernel/classes/datatypes',
                                                              'File uploading is not enabled. Please contact the site administrator to enable it.' ) ) );
                $isFileWarningAdded = true;
            }
        }
    }

    /*!
     Validates the input and returns true if the input was
     valid for this datatype.
    */
    function validateObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        EnhancedeZBinaryFileType::checkFileUploads();
        $classAttribute =& $contentObjectAttribute->contentClassAttribute();
        $mustUpload = false;
        $httpFileName = $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" );
        $maxSize = 1024 * 1024 * $classAttribute->attribute( EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD );

        if ( $contentObjectAttribute->validateIsRequired() )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
            $version = $contentObjectAttribute->attribute( "version" );
            $binary =& eZBinaryFile::fetch( $contentObjectAttributeID, $version );
            if ( $binary === null )
            {
                $mustUpload = true;
            }
        }

        $canFetchResult = eZHTTPFile::canFetch( $httpFileName, $maxSize );
        if ( $mustUpload && $canFetchResult == EZ_UPLOADEDFILE_DOES_NOT_EXIST )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'A valid file is required.' ) );
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        if ( $canFetchResult == EZ_UPLOADEDFILE_EXCEEDS_PHP_LIMIT )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                'The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.' ) );
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        if ( $canFetchResult == EZ_UPLOADEDFILE_EXCEEDS_MAX_SIZE )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'The size of the uploaded file exceeds the maximum upload size: %1 bytes.' ), $maxSize );
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
    }

    /*!
     Fetches the http post var integer input and stores it in the data instance.
    */
    function fetchObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        EnhancedeZBinaryFileType::checkFileUploads();
        if ( !eZHTTPFile::canFetch( $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" ) ) )
            return false;

        $binaryFile =& eZHTTPFile::fetch( $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" ) );

        $contentObjectAttribute->setContent( $binaryFile );

        if ( get_class( $binaryFile ) == "ezhttpfile" )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
            $version = $contentObjectAttribute->attribute( "version" );

            /*
            $mimeObj = new  eZMimeType();
            $mimeData = $mimeObj->findByURL( $binaryFile->attribute( "original_filename" ), true );
            $mime = $mimeData['name'];
            */

            $mimeData =& eZMimeType::findByFileContents( $binaryFile->attribute( "original_filename" ) );
            $mime = $mimeData['name'];

            if ( $mime == '' )
            {
                $mime = $binaryFile->attribute( "mime_type" );
            }
            $extension = preg_replace('/.*\.(.+?)$/', '\\1', $binaryFile->attribute( "original_filename" ) );
            $binaryFile->setMimeType( $mime );
            if ( !$binaryFile->store( "original", $extension ) )
            {
                eZDebug::writeError( "Failed to store http-file: " . $binaryFile->attribute( "original_filename" ),
                                     "EnhancedeZBinaryFileType" );
                return false;
            }

            $binary =& eZBinaryFile::fetch( $contentObjectAttributeID, $version );
            if ( $binary === null )
                $binary =& eZBinaryFile::create( $contentObjectAttributeID, $version );

            $orig_dir = $binaryFile->storageDir( "original" );

            $binary->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
            $binary->setAttribute( "version", $version );
            $binary->setAttribute( "filename", basename( $binaryFile->attribute( "filename" ) ) );
            $binary->setAttribute( "original_filename", $binaryFile->attribute( "original_filename" ) );
            $binary->setAttribute( "mime_type", $mime );

            $binary->store();


            $contentObjectAttribute->setContent( $binary );
        }
        return true;
    }

    /*!
     Does nothing, since the file has been stored. See fetchObjectAttributeHTTPInput for the actual storing.
    */
    function storeObjectAttribute( &$contentObjectAttribute )
    {
    }

    function customObjectAttributeHTTPAction( $http, $action, &$contentObjectAttribute )
    {
        EnhancedeZBinaryFileType::checkFileUploads();
        if( $action == "delete_enhancedbinary" )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
            $version = $contentObjectAttribute->attribute( "version" );
            $this->deleteStoredObjectAttribute( $contentObjectAttribute, $version );
        }
    }

    /*!
     \reimp
     HTTP file insertion is supported.
    */
    function isHTTPFileInsertionSupported()
    {
        return true;
    }

    /*!
     \reimp
     HTTP file insertion is supported.
    */
    function isRegularFileInsertionSupported()
    {
        return true;
    }

    /*!
     \reimp
     Inserts the file using the eZBinaryFile class.
    */
    function insertHTTPFile( &$object, $objectVersion, $objectLanguage,
                             &$objectAttribute, &$httpFile, $mimeData,
                             &$result )
    {
        $result = array( 'errors' => array(),
                         'require_storage' => false );
        $errors =& $result['errors'];
        $attributeID = $objectAttribute->attribute( 'id' );

        $binary =& eZBinaryFile::fetch( $attributeID, $objectVersion );
        if ( $binary === null )
            $binary =& eZBinaryFile::create( $attributeID, $objectVersion );

        $httpFile->setMimeType( $mimeData['name'] );

        $db =& eZDB::instance();
        $db->begin();

        if ( !$httpFile->store( "original", false, false ) )
        {
            $errors[] = array( 'description' => ezi18n( 'kernel/classe/datatypes/ezbinaryfile',
                                                        'Failed to store file %filename. Please contact the site administrator.', null,
                                                        array( '%filename' => $httpFile->attribute( "original_filename" ) ) ) );
            return false;
        }

        $binary->setAttribute( "contentobject_attribute_id", $attributeID );
        $binary->setAttribute( "version", $objectVersion );
        $binary->setAttribute( "filename", basename( $httpFile->attribute( "filename" ) ) );
        $binary->setAttribute( "original_filename", $httpFile->attribute( "original_filename" ) );
        $binary->setAttribute( "mime_type", $mimeData['name'] );

        $binary->store();
        $db->commit();

        $objectAttribute->setContent( $binary );

        return true;
    }

    /*!
     \reimp
     Inserts the file using the eZBinaryFile class.
    */
    function insertRegularFile( &$object, $objectVersion, $objectLanguage,
                                &$objectAttribute, $filePath,
                                &$result )
    {
        $result = array( 'errors' => array(),
                         'require_storage' => false );
        $errors =& $result['errors'];
        $attributeID = $objectAttribute->attribute( 'id' );

        $binary =& eZBinaryFile::fetch( $attributeID, $objectVersion );
        if ( $binary === null )
            $binary =& eZBinaryFile::create( $attributeID, $objectVersion );

        $fileName = basename( $filePath );
        $mimeData = eZMimeType::findByFileContents( $filePath );
        $storageDir = eZSys::storageDirectory();
        list( $group, $type ) = explode( '/', $mimeData['name'] );
        $destination = $storageDir . '/original/' . $group;
        $oldumask = umask( 0 );
        if ( !eZDir::mkdir( $destination, false, true ) )
        {
            umask( $oldumask );
            return false;
        }
        umask( $oldumask );
        $destination = $destination . '/' . $fileName;
        copy( $filePath, $destination );

        $binary->setAttribute( "contentobject_attribute_id", $attributeID );
        $binary->setAttribute( "version", $objectVersion );
        $binary->setAttribute( "filename", $fileName );
        $binary->setAttribute( "original_filename", $fileName );
        $binary->setAttribute( "mime_type", $mimeData['name'] );

        $binary->store();

        $objectAttribute->setContent( $binary );
        return true;
    }

    /*!
      \reimp
      We support file information
    */
    function hasStoredFileInformation( &$object, $objectVersion, $objectLanguage,
                                       &$objectAttribute )
    {
       return true;
    }

    /*!
      \reimp
      Extracts file information for the binaryfile entry.
    */
    function storedFileInformation( &$object, $objectVersion, $objectLanguage,
                                    &$objectAttribute )
    {
        $binaryFile =& eZBinaryFile::fetch( $objectAttribute->attribute( "id" ),
                                            $objectAttribute->attribute( "version" ) );
        if ( $binaryFile )
        {
            return $binaryFile->storedFileInfo();
        }
        return false;
    }
    /*!
      \reimp
      Updates download count for binary file.
    */
    function handleDownload( &$object, $objectVersion, $objectLanguage,
                             &$objectAttribute )
    {
        $binaryFile =& eZBinaryFile::fetch( $objectAttribute->attribute( "id" ),
                                            $objectAttribute->attribute( "version" ) );

        $contentObjectAttributeID = $objectAttribute->attribute( 'id' );
        $version =  $objectAttribute->attribute( "version" );

        if ( $binaryFile )
        {
            $db =& eZDB::instance();
            $db->query( "UPDATE ezbinaryfile SET download_count=(download_count+1)
                         WHERE
                         contentobject_attribute_id=$contentObjectAttributeID AND version=$version" );
            return true;
        }
        return false;
    }

    function fetchClassAttributeHTTPInput( &$http, $base, &$classAttribute )
    {
        $filesizeName = $base . EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $filesizeName ) )
        {
            $filesizeValue = $http->postVariable( $filesizeName );
            $classAttribute->setAttribute( EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD, $filesizeValue );
        }
    }
    /*!
     Returns the object title.
    */
    function title( &$contentObjectAttribute,  $name = "original_filename" )
    {
        $binaryFile =& eZBinaryFile::fetch( $contentObjectAttribute->attribute( "id" ),
                                            $contentObjectAttribute->attribute( "version" ) );
        $value = $binaryFile->attribute( $name );

        return $value;
    }

    function hasObjectAttributeContent( &$contentObjectAttribute )
    {
        $binaryFile =& eZBinaryFile::fetch( $contentObjectAttribute->attribute( "id" ),
                                            $contentObjectAttribute->attribute( "version" ) );
        if ( !$binaryFile )
            return false;
        return true;
    }

    function &objectAttributeContent( $contentObjectAttribute )
    {
        $binaryFile =& eZBinaryFile::fetch( $contentObjectAttribute->attribute( "id" ),
                                            $contentObjectAttribute->attribute( "version" ) );
        if ( !$binaryFile )
            return false;
        return $binaryFile;
    }

    /*!
     \reimp
    */
    function isIndexable()
    {
        return true;
    }

     /*!
	 \reimp
	*/
	function isInformationCollector()
	{
		return true;
    }


    function validateCollectionAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {

    	EnhancedeZBinaryFileType::checkFileUploads();
    	$classAttribute =& $contentObjectAttribute->contentClassAttribute();
    	$httpFileName = $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" );
    	$maxSize = 1024 * 1024 * $classAttribute->attribute( EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD );
    	$canFetchResult = eZHTTPFile::canFetch( $httpFileName, $maxSize );



    	if ( $http->hasPostVariable( $httpFileName ) )
    	{
    		if ( file_exists(  $http->postVariable( $httpFileName ) ) )
    			return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
    	}

    	if ( $contentObjectAttribute->validateIsRequired() && $canFetchResult == EZ_UPLOADEDFILE_DOES_NOT_EXIST )
    	{
    		$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'A valid file is required.' ) );
			return EZ_INPUT_VALIDATOR_STATE_INVALID;
		}
		else
		{
			return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
		}

		if ( $canFetchResult == EZ_UPLOADEDFILE_EXCEEDS_PHP_LIMIT )
		{
			$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
				'The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.' ) );
			return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        if ( $canFetchResult == EZ_UPLOADEDFILE_EXCEEDS_MAX_SIZE )
		{
			$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
																 'The size of the uploaded file exceeds the maximum upload size: %1 bytes.' ), $maxSize );
			return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }

        //bit of an ugly hack...
        $postFiles =& $GLOBALS["HTTP_POST_FILES"];
        $extension = preg_replace('/.*\.(.+?)$/', '\\1', $postFiles[$httpFileName]["name"] );
		$moduleINI =& eZINI::instance( 'module.ini.append.php', 'settings');
		$allowed = $moduleINI->variable('AllowedFileTypes', 'AllowedFileTypeList');

		if (!in_array(strtolower($extension),$allowed))
		{
			$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
																 'Failed to store file. Only the following file types are allowed: %1.' ), implode(", ",$allowed) );
			return EZ_INPUT_VALIDATOR_STATE_INVALID;
		}
		else
		{
			return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
		}
		$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'The file could not be uploaded.' ) );
    	return EZ_INPUT_VALIDATOR_STATE_INVALID;
    }


    function fetchCollectionAttributeHTTPInput( &$collection, &$collectionAttribute, &$http, $base, &$contentObjectAttribute )
	{


		$moduleINI =& eZINI::instance( 'module.ini.append.php', 'settings');
		$maxFiles=$moduleINI->variable('RemoveFiles', 'MaxFiles');

		//clean up older files.
		if ( $maxFiles>0 )
		{
			$Files = array();
			$storageDir=eZSys::storageDirectory();
			$fileCollection=eZDir::recursiveFindRelative( $storageDir, '/original/collected', '.*' );
			if ( count($fileCollection)>$maxFiles )
			{
				foreach ( $fileCollection as $fileItem )
                {
					$lastModified = filemtime( $storageDir . $fileItem);
					$Files[$fileItem] = filemtime($storageDir . $fileItem);
                }
            	asort($Files, SORT_NUMERIC);
            	$removeFile=key($Files);
            	 if ( file_exists( $storageDir . $removeFile ) )
            	 {
                    if (!unlink( $storageDir . $removeFile ) )
                    {
                    	eZDebug::writeError( "Failed to delete file: " . $storageDir . $removeFile, "EnhancedeZBinaryFileType" );
                    	return false;
                    }
                 }
			}
		}

		$binaryFile =& eZHTTPFile::fetch( $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" ) );

		if ( get_class( $binaryFile ) == "ezhttpfile" )
		{
			$mimeData =& eZMimeType::findByFileContents( $binaryFile->attribute( "original_filename" ) );
			$mime = $mimeData['name'];

			if ( $mime == '' )
			{
				$mime = $binaryFile->attribute( "mime_type" );
			}

			$extension = preg_replace('/.*\.(.+?)$/', '\\1', $binaryFile->attribute( "original_filename" ) );

			$binaryFile->setMimeType( $mime );

			if ( !$binaryFile->store( "original/collected", $extension ) )
			{
				eZDebug::writeError( "Failed to store http-file: " . $binaryFile->attribute( "original_filename" ), "EnhancedeZBinaryFileType" );
				return false;
			}

			$fileLocation=$binaryFile->attribute( "filename" );

			$doc = new eZDOMDocument( 'FileInfo' );
			$root =& $doc->createElementNode( 'binaryfile-info' );
			$binaryFileList =& $doc->createElementNode( 'binaryfile-attributes' );
			foreach ( $binaryFile as $key => $binaryFileItem )
			{
				$binaryFileElement[$key] =& $doc->createElementNode( $key, array( 'value' => $binaryFileItem ) );
				$binaryFileList->appendChild( $binaryFileElement[$key] );
			}
			$root->appendChild( $binaryFileList );
        	$doc->setRoot( $root );
        	$docText = EnhancedeZBinaryFileType::domString( $doc );
			$collectionAttribute->setAttribute( 'data_text', $docText );
			return true;
		}
		else
		{
			if ( $http->hasPostVariable( $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" ) ) )
			{
				$fileLocation = $http->postVariable( $base . "_data_enhancedbinaryfilename_" . $contentObjectAttribute->attribute( "id" ) );
				$mimeData =  eZMimeType::findByFileContents( $fileLocation );
				$doc = new eZDOMDocument( 'FileInfo' );
				$root =& $doc->createElementNode( 'binaryfile-info' );
				$binaryFileList =& $doc->createElementNode( 'binaryfile-attributes' );
				$binaryFileElement1 =& $doc->createElementNode( 'OriginalFilename', array( 'value' => $mimeData[filename] ) );
				$binaryFileList->appendChild( $binaryFileElement1 );
				$binaryFileElement2 =& $doc->createElementNode( 'Filename', array( 'value' => $mimeData[url] ) );
				$binaryFileList->appendChild( $binaryFileElement2 );
				$binaryFileElement3 =& $doc->createElementNode( 'Type', array( 'value' => $mimeData['name'] ) );
				$binaryFileList->appendChild( $binaryFileElement3 );
				$root->appendChild( $binaryFileList );
				$doc->setRoot( $root );
				$docText = EnhancedeZBinaryFileType::domString( $doc );
				$collectionAttribute->setAttribute( 'data_text', $docText );
				return true;
			}
		}
		return false;
	}

	function domString( &$domDocument )
	{
		$ini =& eZINI::instance();
		$xmlCharset = $ini->variable( 'RegionalSettings', 'ContentXMLCharset' );
		if ( $xmlCharset == 'enabled' )
		{
			include_once( 'lib/ezi18n/classes/eztextcodec.php' );
			$charset = eZTextCodec::internalCharset();
		}
		else if ( $xmlCharset == 'disabled' )
			$charset = true;
		else
			$charset = $xmlCharset;
		if ( $charset !== true )
		{
			include_once( 'lib/ezi18n/classes/ezcharsetinfo.php' );
			$charset = eZCharsetInfo::realCharsetCode( $charset );
		}
		$domString = $domDocument->toString( $charset );
		return $domString;
    }


    function &metaData( &$contentObjectAttribute )
    {
        $binaryFile =& $contentObjectAttribute->content();

        $metaData = "";
        if ( get_class( $binaryFile ) == "ezbinaryfile" )
        {
            $metaData = $binaryFile->metaData();
        }
        return $metaData;
    }

    /*!
     \reimp
    */
    function &serializeContentClassAttribute( &$classAttribute, &$attributeNode, &$attributeParametersNode )
    {
        $maxSize = $classAttribute->attribute( EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD );
        $attributeParametersNode->appendChild( eZDOMDocument::createElementTextNode( 'max-size', $maxSize,
                                                                                     array( 'unit-size' => 'mega' ) ) );
    }

    /*!
     \reimp
    */
    function &unserializeContentClassAttribute( &$classAttribute, &$attributeNode, &$attributeParametersNode )
    {
        $maxSize = $attributeParametersNode->elementTextContentByName( 'max-size' );
        $sizeNode = $attributeParametersNode->elementByName( 'max-size' );
        $unitSize = $sizeNode->attributeValue( 'unit-size' );
        $classAttribute->setAttribute( EZ_DATATYPESTRING_MAX_ENHANCEDBINARY_FILESIZE_FIELD, $maxSize );
    }

    /*!
     \param package
     \param content attribute

     \return a DOM representation of the content object attribute
    */
    function &serializeContentObjectAttribute( &$package, &$objectAttribute )
    {
        $node = new eZDOMNode();

        $node->setPrefix( 'ezobject' );
        $node->setName( 'attribute' );
        $node->appendAttribute( eZDOMDocument::createAttributeNode( 'id', $objectAttribute->attribute( 'id' ), 'ezremote' ) );
        $node->appendAttribute( eZDOMDocument::createAttributeNode( 'identifier', $objectAttribute->contentClassAttributeIdentifier(), 'ezremote' ) );
        $node->appendAttribute( eZDOMDocument::createAttributeNode( 'name', $objectAttribute->contentClassAttributeName() ) );
        $node->appendAttribute( eZDOMDocument::createAttributeNode( 'type', $this->isA() ) );

        $binaryFile =& $objectAttribute->attribute( 'content' );
        if ( is_object( $binaryFile ) )
        {
            $fileKey = md5( mt_rand() );
            $package->appendSimpleFile( $fileKey, $binaryFile->attribute( 'filepath' ) );

            $fileNode =& eZDOMDocument::createElementNode( 'binary-file' );
            $fileNode->appendAttribute( eZDOMDocument::createAttributeNode( 'filesize', $binaryFile->attribute( 'filesize' ) ) );
            $fileNode->appendAttribute( eZDOMDocument::createAttributeNode( 'filename', $binaryFile->attribute( 'filename' ) ) );
            $fileNode->appendAttribute( eZDOMDocument::createAttributeNode( 'original-filename', $binaryFile->attribute( 'original_filename' ) ) );
            $fileNode->appendAttribute( eZDOMDocument::createAttributeNode( 'mime-type', $binaryFile->attribute( 'mime_type' ) ) );
            $fileNode->appendAttribute( eZDOMDocument::createAttributeNode( 'filekey', $fileKey ) );
            $node->appendChild( $fileNode );
        }

        return $node;
    }

    /*!
     \reimp
     \param package
     \param contentobject attribute object
     \param ezdomnode object
    */
    function unserializeContentObjectAttribute( &$package, &$objectAttribute, $attributeNode )
    {
        $fileNode = $attributeNode->elementByName( 'binary-file' );
        if ( !is_object( $fileNode ) or !$fileNode->hasAttributes() )
        {
            return;
        }

        $binaryFile =& eZBinaryFile::create( $objectAttribute->attribute( 'id' ), $objectAttribute->attribute( 'version' ) );

        $sourcePath = $package->simpleFilePath( $fileNode->attributeValue( 'filekey' ) );

        include_once( 'lib/ezfile/classes/ezdir.php' );
        $ini =& eZINI::instance();
        $mimeType = $fileNode->attributeValue( 'mime-type' );
        list( $mimeTypeCategory, $mimeTypeName ) = explode( '/', $mimeType );
        $destinationPath = eZSys::storageDirectory() . '/original/' . $mimeTypeCategory . '/';
        if ( !file_exists( $destinationPath ) )
        {
            $oldumask = umask( 0 );
            if ( !eZDir::mkdir( $destinationPath, eZDir::directoryPermission(), true ) )
            {
                umask( $oldumask );
                return false;
            }
            umask( $oldumask );
        }

        $basename = basename( $fileNode->attributeValue( 'filename' ) );
        while ( file_exists( $destinationPath . $basename ) )
        {
            $basename = substr( md5( mt_rand() ), 0, 8 ) . '.' . eZFile::suffix( $fileNode->attributeValue( 'filename' ) );
        }

        include_once( 'lib/ezfile/classes/ezfilehandler.php' );
        eZFileHandler::copy( $sourcePath, $destinationPath . $basename );
        eZDebug::writeNotice( 'Copied: ' . $sourcePath . ' to: ' . $destinationPath . $basename,
                              'EnhancedeZBinaryFileType::unserializeContentObjectAttribute()' );

        $binaryFile->setAttribute( 'contentobject_attribute_id', $objectAttribute->attribute( 'id' ) );
        $binaryFile->setAttribute( 'filename', $basename );
        $binaryFile->setAttribute( 'original_filename', $fileNode->attributeValue( 'original-filename' ) );
        $binaryFile->setAttribute( 'mime_type', $fileNode->attributeValue( 'mime-type' ) );

        $binaryFile->store();
    }

}

eZDataType::register( EZ_DATATYPESTRING_ENHANCEDBINARYFILE, "enhancedezbinaryfiletype" );
?>
