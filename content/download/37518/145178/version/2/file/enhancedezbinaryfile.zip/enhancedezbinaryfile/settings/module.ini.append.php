<?php /* #?ini charset="iso-8859-1"?

[AllowedFileTypes]
AllowedFileTypeList[]
AllowedFileTypeList[]=gif
AllowedFileTypeList[]=jpg
AllowedFileTypeList[]=jpeg
AllowedFileTypeList[]=jpe
AllowedFileTypeList[]=txt
AllowedFileTypeList[]=doc
AllowedFileTypeList[]=pdf
AllowedFileTypeList[]=sxw

[RemoveFiles]
#Maximum number of files allowed in the folder, 25 files is standard.
#0 means there is no limit to the number of files
MaxFiles=25

*/ ?>



