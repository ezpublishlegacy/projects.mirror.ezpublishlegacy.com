<?php /*

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=popupmenu/classcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=popupmenu/classsubitemscontextmenu.tpl

*/ ?>
