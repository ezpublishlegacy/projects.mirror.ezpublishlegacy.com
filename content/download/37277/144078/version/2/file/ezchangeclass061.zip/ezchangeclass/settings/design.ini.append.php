<?php /* 

[ExtensionSettings]
DesignExtensions[]=ezchangeclass

*/ ?>
