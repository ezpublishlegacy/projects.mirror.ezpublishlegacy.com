<?php
class xl_operators{
    function xl_operators(){	
		$this->Operators = array( 	'xl_hello', 
									'xl_print_array',
									'xl_objects_by_owner_count',
									'xl_getpostvar',
									'xl_setsessionvar',
									'xl_getsessionvar',
									'xl_showdate');	
	}
    function &operatorList(){	
		return $this->Operators;	
	}
    function namedParameterPerOperator(){	
		return true;	
	}
	function namedParameterList(){	
		return array(	
						'xl_hello'					=> array( 	'pstr'		=>array('type'=>'string'	,'required'	=> true		,'default'=> '' )),
						
						'xl_print_array'			=> array( 	'parray'	=>array('type'=>'array'		,'required'	=> true		,'default'=> '' ),
																'pbool'		=>array('type'=>'bool'		,'required'	=> false	,'default'=> false )),
																
						'xl_objects_by_owner_count'	=> array( 	'class_id'	=>array('type'=>'int'		,'required'	=> true		,'default'=> '1' )),
						
						'xl_getpostvar' 			=> array( 	'pstr' 		=>array('type'=>'string'	,'required' => true		,'default'=> '' )),
						
						'xl_setsessionvar' 			=> array( 	'pstr1' 		=>array('type'=>'string'	,'required' => true		,'default'=> '' ),
																'pstr2' 		=>array('type'=>'string'	,'required' => true		,'default'=> '' )),
																
						'xl_getsessionvar' 			=> array( 	'pstr' 		=>array('type'=>'string'	,'required' => true		,'default'=> '' )),
						
						'xl_showdate' 				=> array( 	'pstr' 		=>array('type'=>'string'	,'required' => true		,'default'=> '' ))
					);	
	}
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters ){
        switch ( $operatorName ){
			case 'xl_hello':	
				$operatorValue = $this->xl_hello($namedParameters['pstr']);
			break;	
			case 'xl_print_array':	
				$operatorValue = $this->xl_print_array($namedParameters['parray'], $namedParameters['pbool']);
			break;
			case 'xl_objects_by_owner_count':	
				$operatorValue = $this->xl_objects_by_owner_count($namedParameters['class_id']);
			break;
			case 'xl_getpostvar':{
                $operatorValue = $this->xl_getpostvar($namedParameters['pstr']);
            } break;
			case 'xl_setsessionvar':{
                $operatorValue = $this->xl_setsessionvar($namedParameters['pstr1'],$namedParameters['pstr2']);
            } break;
			case 'xl_getsessionvar':{
                $operatorValue = $this->xl_getsessionvar($namedParameters['pstr']);
            } break;
			case 'xl_showdate':{
                $operatorValue = $this->xl_showdate($namedParameters['pstr']);
            } break;
		}
    }
	
    function xl_hello($p){
		return "Hello ".$p;
    }
	
	function xl_print_array($p, $flag){
		if ($flag){
			$msg = '<pre>'.var_dump($p).'</pre>';
		}else{
			$msg = '<pre>'.print_r($p,true).'</pre>';
		}
		return $msg;
    }
	
	function xl_objects_by_owner_count($class_id){
		$db =& eZDB::instance();                
		$query="SELECT `owner_id` AS user_id, count( `owner_id` ) AS count
				FROM `ezcontentobject` 
				WHERE `contentclass_id` = '".(int)$class_id."'
				AND `status` = '1'
				GROUP BY `user_id`";
		$ResultArray =& $db->arrayQuery( $query );
		$owner_list = array();
		foreach($ResultArray  as $row){
			$owner_list[$row['user_id']] = $row['count'];
		}
		return $owner_list;
    }
	
	function xl_getpostvar($p){
		if(array_key_exists($p,$_POST)){
			$msg = $_POST[$p];
		}else{
			$msg = '';
		}
		return $msg;
    }
	
	function xl_setsessionvar($p1,$p2){
		$_SESSION['xl'][$p1] = $p2;
		//debug //$msg = "<p>_SESSION = <pre>".print_r($_SESSION,true)."<pre></p>";
		//$msg = 'xlsetsessionvar => $_SESSION['.$p1.'] = '.$p2.'; enregistr�';
		return $msg;
	}
	
	function xl_getsessionvar($p){
		if( array_key_exists('xl',$_SESSION) && array_key_exists($p,$_SESSION['xl']) ){
			$msg = $_SESSION['xl'][$p];
		}else{
			$msg = '';
		}
		//$msg = "<p>_SESSION = <pre>".print_r($_SESSION,true)."<pre></p>";
		return $msg;
	}
	
	//afficher la date de demain ou bien dans n mois
	function xl_showdate($n){
		
		$msg = "";
		
		$date = date("d/m/Y");
		$elts 	= explode("/", $date);
		$jour 	= $elts[0];
		$mois 	= $elts[1];
		$an 	= $elts[2];
		
		if($n == ""){
			$newDate = mktime(0, 0, 0, $mois, $jour + 1, $an);
			$msg .= date("d/m/Y", $newDate);
		}else{
			$newDate = mktime(0, 0, 0, $mois + $n, $jour + 1, $an);
			$msg .= date("d/m/Y", $newDate);
		}
		return $msg;
	}	
    /// \privatesection
    var $Operators;
}

?>