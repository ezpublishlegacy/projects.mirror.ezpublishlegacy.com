function popup(nomFichier,largeur,hauteur)
{   var top=(screen.height-hauteur)/2;
   	var left=(screen.width-largeur)/2;
    window.open(nomFichier,"","top="+top+",left="+left+",width="+largeur+",height="+hauteur+",resizable=yes,menubar=no,scrollbars=yes,statusbar=no");
}

function insertAfter(parent, node, referenceNode) {
	parent.insertBefore(node, referenceNode.nextSibling);
}

function create_newInput(moduleName){

	moduleListNode = document.getElementById("moduleList");
	
	label=document.createElement('label');
	label.innerHTML = "The module <b>\""+moduleName+"\"</b> will handle this/these view(s) : ";
	moduleListNode.appendChild(label);
	
	newInput=document.createElement('input');		
	newInput.className="newInput";
	newInput.name="modules["+moduleName+"]";
	newInput.value='view_1 ; view_2';	//newInput.setAttribute("prix"," ");
	newInput.size="80";
	moduleListNode.appendChild(newInput);
	
	br=document.createElement('br');
	moduleListNode.appendChild(br);
	
	br=document.createElement('br');
	moduleListNode.appendChild(br);
	
}