<?php	$text = $error = $text_error = "";


if(!array_key_exists("extension_manager_utf8",$_SESSION)){
	$_SESSION["extension_manager_utf8"] = "non";
}

if($_POST && array_key_exists("extension_manager_utf8",$_POST)){
	$_SESSION["extension_manager_utf8"] = $_POST["extension_manager_utf8"];
}



$_SESSION["base_site_url"] = (( array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"]=="on") ? "https://" : "http://").$_SERVER['HTTP_HOST'].eZSys::indexFile();

$_SESSION["extension"] = array();

$extension_name = $_SESSION["extension"]["folder_name"] =& $Params['folder_name'];

// $text .= '<br>modules_dir = '.$modules_dir;

$html_extensions_list = '<select value="" onchange="changeExtension(this.value);">';
if($dir=opendir("extension")){
	while($file_name = readdir($dir)){
		if( $file_name!='.' && $file_name!='..' ){	
			if($extension_name == $file_name){
				$html_extensions_list .= '<option value="'.$file_name.'" selected="selected">'.$file_name.'</option>';
			}else{
				$html_extensions_list .= '<option value="'.$file_name.'">'.$file_name.'</option>';
			}
		}
	}
	closedir($dir);
}
$html_extensions_list .= '</select><a href="'.$_SESSION["base_site_url"].'/extension_builder/generator">Extension builder</a><br />';

$html_modules_list = '<select onchange="changeModule(this.value);"><option value="" selected="selected">Select module</option>';
$modules_dir = 'extension/'.$extension_name.'/modules';
if($dir=opendir($modules_dir)){
	while($module_name = readdir($dir)){
		
		if( $module_name!='.' && $module_name!='..' ){
			
			$module_php_file = $modules_dir.'/'.$module_name.'/module.php';
			
			if( file_exists($module_php_file) ){
				
				$html_modules_list .= '<option value="'.$module_name.'">'.$module_name.'</option>';
				
				/*
				include($module_php_file);//$res .= '<hr><pre>$Module = '.print_r($Module,true).'</pre><pre>$ViewList = '.print_r($ViewList,true).'</pre></ul>';
				foreach($ViewList as $view_name=>$item){//$res .= '<pre>$item = '.print_r($item,true).'</pre>';
					$html_modules_list .= '<option value="'.$view_name.'">'.$view_name.'</option>';
				}
				*/
				
				
			}else{
				$text .= '<br>module_php_file is not a valid path';
			}
			
		}
		
	}
	closedir($dir);
}else{
	$error = 1;
	$text_error = "<br>extension/".$folder_name." is not a valid path.";
}
$html_modules_list .= '</select>
<!--input type="button" value="Rename" onclick="renameModule()" /-->
<input type="button" value="Add a module" onclick="addModule()" />
<input type="button" id="viewTpl" onclick="wo(\''.$_SESSION["base_site_url"].'/extension_manager/view_module_php\')" value="View module.php" /><br />';



/*
//eZExecution::cleanExit();
/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'title', "Contenu de l'extension" );
$tpl->setVariable( 'text', $text );
$tpl->setVariable( 'error', $error );
$tpl->setVariable( 'text_error', $text_error );

$tpl->setVariable( 'extension_manager_utf8', $_SESSION["extension_manager_utf8"] );
$tpl->setVariable( 'extension_manager_utf8_action', $_SESSION["base_site_url"]."/extension_manager/show/".$_SESSION["extension"]["folder_name"] );


$tpl->setVariable( 'base_site_url', $_SESSION["base_site_url"] );

if($_SESSION["extension_manager_utf8"] == "oui"){
	$tpl->setVariable( 'html_modules_list', utf8_encode($html_modules_list));
	$tpl->setVariable( 'html_extensions_list', utf8_encode($html_extensions_list));
}else{
	$tpl->setVariable( 'html_modules_list', $html_modules_list);
	$tpl->setVariable( 'html_extensions_list', $html_extensions_list);
}

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:extension_manager/show.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "Extension manager") );
//$Result['pagelayout'] = 'popup_pagelayout.tpl';

?>