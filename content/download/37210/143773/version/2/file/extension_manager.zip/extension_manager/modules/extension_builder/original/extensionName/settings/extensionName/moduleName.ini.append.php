<?php /* #?ini charset="iso-8859-1"?

[client]
contentClassId=39
parentNodeID=237

*/ ?>