<?php
$module =& $Params["Module"];
$my_params = $module->UserParameters;

function copyFile($filename, $newfilename, $arraybad, $arraygood){
	//echo "<br>filename = $filename";echo "<br>newfilename = $newfilename";echo "<br>arraybad = ".print_r($arraybad);echo "<br>arraygood = ".print_r($arraygood);
	if(!file_exists($filename)){
		die("File not found : $filename");
	}
	$fd=fopen($filename,"r");
	$content=fread($fd,filesize($filename));
	fclose($fd);
	$content=str_replace($arraybad,$arraygood,$content);
	$fp=fopen($newfilename,"w+");
	fwrite($fp,$content);
	fclose($fp);
	//eZExecution::cleanExit();
}


function getHtmlModulesList($folder_name){
	unset($_SESSION["extension"]["view_name"]);
	unset($_SESSION["extension"]["module_name"]);
	$_SESSION["extension"]["folder_name"] = $folder_name;
	$html_modules_list = '<select onchange="changeModule(this.value);"><option value="" selected="selected">Select module</option>';
	$modules_dir = 'extension/'.$folder_name.'/modules';
	if($dir=opendir($modules_dir)){
		while($module_name = readdir($dir)){
			if( $module_name!='.' && $module_name!='..' ){
				$module_php_file = $modules_dir.'/'.$module_name.'/module.php';
				if( file_exists($module_php_file) ){
					$html_modules_list .= '<option value="'.$module_name.'">'.$module_name.'</option>';
				}else{
					$text .= '<br>module_php_file is not a valid path';
				}
			}
		}
		closedir($dir);
	}else{
		$error = 1;
		$text_error = "<br>extension/".$folder_name." is not a valid path.";
	}
	$html_modules_list .= '</select>
	<!--input type="button" value="Rename" onclick="renameModule()" /-->
	<input type="button" value="Add a module" onclick="addModule()" />
	<input type="button" id="viewTpl" onclick="wo(\''.$_SESSION["base_site_url"].'/extension_manager/view_module_php\')" value="View module.php" />
	<br />';
	if($_SESSION["extension_manager_utf8"] == "oui"){
		echo utf8_encode($html_modules_list);
	}else{
		echo $html_modules_list;
	}
}

function getHtmlViewsList($module_name){
	unset($_SESSION["extension"]["view_name"]);
	$_SESSION["extension"]["module_name"] = $module_name;
	$modules_dir = 'extension/'.$_SESSION["extension"]["folder_name"].'/modules';
	$module_php_file = $modules_dir.'/'.$module_name.'/module.php';
	$html_views_list = '<select onchange="setViewOptions(this.value);"><option value="" selected="selected">Select view</option>';
	if( file_exists($module_php_file) ){
		include($module_php_file);//$res .= '<hr><pre>$Module = '.print_r($Module,true).'</pre><pre>$ViewList = '.print_r($ViewList,true).'</pre></ul>';
		foreach($ViewList as $view_name=>$item){//$res .= '<pre>$item = '.print_r($item,true).'</pre>';
			$html_views_list .= '<option value="'.$view_name.'">'.$view_name.'</option>';
		}
	}else{
		$text .= '<br>module_php_file is not a valid path';
	}
	$html_views_list .= '</select>
	<!--input type="button" value="Rename" onclick="renameView()" /-->
	<input type="button" value="Add a view" onclick="addView()" />';
	
	if($_SESSION["extension_manager_utf8"] == "oui"){
		echo utf8_encode($html_views_list);
	}else{
		echo $html_views_list;
	}
}

function getHtmlViewOptions($view_name){
	$_SESSION["extension"]["view_name"] = $view_name;
	
	$res = '<fieldset id="fieldset_2"><legend>Action for : '.$view_name.'</legend>';
	
	// php
	$res.='<input type="button" id="viewPhp" onclick="wo(\''.$_SESSION["base_site_url"].'/extension_manager/view_php\')" value="View php" />';
	
	// tpl
	$tpl_file = 'extension/'.$_SESSION["extension"]["folder_name"].'/design/standard/templates/'.$_SESSION["extension"]["module_name"].'/'.$_SESSION["extension"]["view_name"].'.tpl';
	
	if(file_exists($tpl_file)){
		$res.='<input type="button" id="addTpl" onclick="addTpl()" value="Add tpl" disabled="disabled" />
		<input type="button" id="viewTpl" onclick="wo(\''.$_SESSION["base_site_url"].'/extension_manager/view_tpl\')" value="View tpl" />
		<input type="button" id="delTpl" onclick="alert(\'Not yet !\')" value="Dell tpl" />';
	}else{
		$res.='<input type="button" id="addTpl" onclick="addTpl()"  value="Add tpl" />
		<input type="button" id="viewTpl" onclick="viewTpl()" value="View tpl" disabled="disabled" />
		<input type="button" id="delTpl" onclick="delTpl()" value="Dell tpl" disabled="disabled" />';
	}


	$res.='<input type="button" id="addJs" onclick="addJs()" value="Add js" disabled="disabled" />
	<input type="button" id="viewJs" onclick="viewJs()" value="View js" disabled="disabled" />
	<input type="button" id="delJs" onclick="delJs()" value="Dell js" disabled="disabled" />
	<input type="button" id="addCss" onclick="addCss()" value="Add css" disabled="disabled" />
	<input type="button" id="viewCss" onclick="viewCss()" value="View css" disabled="disabled" />
	<input type="button" id="delCss" onclick="delCss()" value="Dell css" disabled="disabled" />
	</fieldset>';
	
	
	if($_SESSION["extension_manager_utf8"] = "oui"){
		echo utf8_encode($res);
	}else{
		echo $res;
	}
}

function addView($view_name){
	$modules_dir = 'extension/'.$_SESSION["extension"]["folder_name"].'/modules';
	$module_php_file = $modules_dir.'/'.$_SESSION["extension"]["module_name"].'/module.php';
	if( file_exists($module_php_file) ){
		include($module_php_file);//$res .= '<hr><pre>$Module = '.print_r($Module,true).'</pre><pre>$ViewList = '.print_r($ViewList,true).'</pre></ul>';
		if(!array_key_exists($view_name,$ViewList)){
			
			/**** view creation ****/
			
			// adding to module.php
			$handle = fopen ($module_php_file, "r");
			$file_content = fread ($handle, filesize ($module_php_file));
			fclose ($handle);
			$replacement = "\n".'$ViewList[\''.$view_name.'\'] = array('."\n".'\'functions\' => array( \''.$view_name.'\' ),'."\r".'\'script\' => \''.$view_name.'.php\','."\r".'\'default_navigation_part\' => \'ezcontentnavigationpart\','."\r".'\'params\' => array(),'."\r".'\'unordered_params\' => array() );'."\n";
			$replacement .= "\n".'$FunctionList[\''.$view_name.'\'] = array();'."\n\n";
			$replacement .= '?>';
			$file_content = str_replace('?>',$replacement,$file_content);
			if (is_writable($module_php_file)) {
				if (!$handle = fopen($module_php_file, 'w+')) {
					exit('Unable to open file');
				}
				if (fwrite($handle, $file_content) === FALSE) {
					exit('Unable to write in the file');
				}
				fclose($handle);				
			}else{
				exit('Read only file');
			}
			
			// creation of sriptName.php
			copyFile(
				"extension/extension_manager/modules/extension_builder/original/extensionName/modules/moduleName/scriptName.php", 
				"extension/".$_SESSION["extension"]["folder_name"]."/modules/".$_SESSION["extension"]["module_name"]."/".$view_name.".php", 
				array("extensionName","moduleName","scriptName"), 
				array($_SESSION["extension"]["folder_name"],$_SESSION["extension"]["module_name"],$view_name)
			);
			
			// on refait la liste des modules
			getHtmlViewsList($_SESSION["extension"]["module_name"]);
			
		}else{
			exit('View already existing');
		}
	}else{
		exit('module_php_file is not a valid path');
	}

	if($_SESSION["extension_manager_utf8"] == "oui"){
		echo utf8_encode($res);
	}else{
		echo $res;
	}
}

function addTpl(){

	$tpl_dir = 'extension/'.$_SESSION["extension"]["folder_name"].'/design/standard/templates/'.$_SESSION["extension"]["module_name"];
	if(!is_dir($tpl_dir)) mkdir ($tpl_dir, 0777);
	
	copyFile(
		"extension/extension_manager/modules/extension_builder/original/extensionName/design/standard/templates/moduleName/scriptName.tpl", 
		"extension/".$_SESSION["extension"]["folder_name"]."/design/standard/templates/".$_SESSION["extension"]["module_name"]."/".$_SESSION["extension"]["view_name"].".tpl", 
		array("extensionName","moduleName","scriptName"), 
		array($_SESSION["extension"]["folder_name"],$_SESSION["extension"]["module_name"],$_SESSION["extension"]["view_name"])	
	);
	
	$settings_dir = "extension/".$_SESSION["extension"]["folder_name"]."/settings";
	if(!is_dir($settings_dir)) mkdir ($settings_dir, 0777);
	$design_ini = $settings_dir."/design.ini.append.php";
	if(!is_file($design_ini)){
		copyFile(
			"extension/extension_manager/modules/extension_builder/original/extensionName/settings/design.ini.append.php", 
			"extension/".$_SESSION["extension"]["folder_name"]."/settings/design.ini.append.php", 
			array("extensionName"), 
			array($_SESSION["extension"]["folder_name"])
		);
	}				
	/*
	mkdir ("$new/".$extensionName."/design/standard/javascripts/".$key, 0777);
	mkdir ("$new/".$extensionName."/design/standard/stylesheets/".$key, 0777);
	mkdir ("$new/".$extensionName."/design/standard/images/".$key, 0777);
	*/
	// on refait la liste des modules
	getHtmlViewOptions($_SESSION["extension"]["view_name"]);
	
}

function addModule($module_name){
	// module.ini
	$module_ini = 'extension/'.$_SESSION["extension"]["folder_name"].'/settings/module.ini.append.php';
	if(!is_file($module_ini)){
		// cr�ation de module.ini.append.php avec le module dedans
		copyFile(
			"extension/extension_manager/modules/extension_builder/original/extensionName/settings/module.ini.append.php", 
			$module_ini,
			array("extensionName","ModuleList[]=moduleName"),
			array($_SESSION["extension"]["folder_name"],"ModuleList[]=".$module_name)
		);
	}else{
		// ajout du module dans le fichier existant
		if(!$handle=fopen($module_ini,"r")) exit('Unable to open file');
		if(!$file_content=fread($handle, filesize ($module_ini))) exit('Unable to read file');
		fclose($handle);
		$replacement = 'ModuleList[]'."\r".'ModuleList[]='.$module_name;
		$file_content = preg_replace('/ModuleList\[\]/', $replacement, $file_content, 1);
		if (is_writable($module_ini)) {
			if (!$handle = fopen($module_ini, 'w+')) exit('Unable to open file');
			if (fwrite($handle, $file_content) === FALSE) exit('Unable to write in the file');
			fclose($handle);				
		}else{
			exit('Read only file');
		}
	}
	
	// modules
	
	$module_dir = 'extension/'.$_SESSION["extension"]["folder_name"].'/modules/'.$module_name;
	if(!is_dir($module_dir)) mkdir ($module_dir, 0777);
	
	$module_php = $module_dir.'/module.php';
	if(!is_file($module_php )){
		$module_php_content = 	"<?php\n\n".'$Module = array( "name" => "'.$module_name.'","variable_params" => false );'."\n".'$ViewList = array();'."\n\n?>";
		if (!$handle = fopen($module_php, 'w+')) exit('Unable to open file');
		if (fwrite($handle, $module_php_content) === FALSE) exit('Unable to write in the file');
		fclose($handle);
	}
	
	// on raffiche tous les modules
	getHtmlModulesList($_SESSION["extension"]["folder_name"]);
}


switch($my_params['f']){
	case 'getHtmlModulesList':
		getHtmlModulesList($my_params['folder_name']);
	break;
	case 'getHtmlViewsList':
		getHtmlViewsList($my_params['module_name']);
	break;
	case 'getHtmlViewOptions':
		getHtmlViewOptions($my_params['view_name']);
	break;
	case 'addView':
		addView($my_params['view_name']);
	break;
	case 'addTpl':
		addTpl();
	break;
	case 'addModule':
		addModule($my_params['module_name']);
	break;
}
eZExecution::cleanExit();
?>



