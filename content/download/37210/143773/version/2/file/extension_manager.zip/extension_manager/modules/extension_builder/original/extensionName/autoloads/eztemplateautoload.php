<?php
// Operator autoloading
$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/extensionName/autoloads/extensionName_operators.php',
         'class' => 'extensionName_operators',
         'operator_names' => array( 'hello'));

?>