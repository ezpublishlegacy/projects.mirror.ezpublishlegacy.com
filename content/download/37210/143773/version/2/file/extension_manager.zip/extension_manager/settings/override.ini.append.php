<?php /* #?ini charset="iso-8859-1"?

[rad]
Source=setup/rad.tpl
MatchFile=setup/rad.tpl
Subdir=templates

[extensions]
Source=setup/extensions.tpl
MatchFile=setup/extensions.tpl
Subdir=templates



*/ ?>
