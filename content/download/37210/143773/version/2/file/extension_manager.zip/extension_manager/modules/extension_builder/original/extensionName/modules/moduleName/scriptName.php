<?php	$text = $error = $text_error = "";

$text .= "<br>On est dans moduleName/scriptName.php";
/*

get sent variables
---------
$node_id =& $Params['node_id']; // ---> to be defined in module.php
----
include_once( 'lib/ezutils/classes/ezhttptool.php' );
$http =& eZHTTPTool::instance();
$node_id =& $http->postVariable( 'node_id' );
*/




/*
//echo "<pre>";var_dump($var);echo "</pre>";eZExecution::cleanExit();
*/








/*

the way out
---------
eZExecution::cleanExit();
----
include_once( "lib/ezutils/classes/ezhttptool.php" );
$myHTTPTool =& eZHTTPTool::instance();
$base_site_url = (( array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"]=="on") ? "https://" : "http://").$_SERVER['HTTP_HOST'];
$myHTTPTool->redirect( $base_site_url.eZSys::indexFile().'/module/view' );
return;
---
/******************** TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'title', "scriptName" );
$tpl->setVariable( 'text', $text );
$tpl->setVariable( 'error', $error );
$tpl->setVariable( 'text_error', $text_error );




$Result = array();
$Result['content'] =& $tpl->fetch( 'design:moduleName/scriptName.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "scriptName") );
//$Result['pagelayout'] = 'popup_pagelayout.tpl';

?>