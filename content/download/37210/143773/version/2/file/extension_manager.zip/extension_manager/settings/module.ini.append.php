<?php  /*#?ini charset="iso-8859-1"?
[ModuleSettings]
ExtensionRepositories[]=extension_manager
ModuleList[]
ModuleList[]=extension_builder
ModuleList[]=extension_manager

*/?>