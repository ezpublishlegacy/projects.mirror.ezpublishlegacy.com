<!DOCTYPE TS>
<TS>
	<context>
		<name>extensionName</name>
		<message>
			<source>English text</source>
			<translation>Texte en français</translation>
		</message>
	</context>
</TS>
