function popup(nomFichier,largeur,hauteur)
{   var top=(screen.height-hauteur)/2;
   	var left=(screen.width-largeur)/2;
    window.open(nomFichier,"","top="+top+",left="+left+",width="+largeur+",height="+hauteur+",resizable=yes,menubar=no,scrollbars=yes,statusbar=no");
}