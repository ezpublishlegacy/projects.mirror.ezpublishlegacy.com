<?php
$Module = array( 'name' => 'moduleName',
                 'variable_params' => false );

$ViewList = array();

$ViewList['scriptName'] = array(
	'functions' => array( 'scriptName' ),
	'script' => 'scriptName.php',
    'default_navigation_part' => 'ezcontentnavigationpart',
    'params' => array(  ),
    'unordered_params' => array( 'offset' => 'Offset' ) );
?>
