<?php	$text = $erreur = $text_erreur = "";
function deltree($dossier){
	if(($dir=opendir($dossier))===false){return;}
	while($name=readdir($dir)){
		if($name==='.' or $name==='..')
		continue;
		$full_name=$dossier.'/'.$name;
		if(is_dir($full_name)){
			deltree($full_name);
		}else{
			if(unlink($full_name)){
			}else{$text_erreur .= "<br>deltree() :( suppression de ".$full_name;}			
		}
	}
	closedir($dir);
	if(rmdir($dossier)){
	}else{$text_erreur .= "<br>deltree() :( suppression de ".$dossier;}
}
$folder_name =& $Params['folder_name'];

if(is_dir("extension/$folder_name")){
	//deltree("extension/$folder_name");
	include_once( 'lib/ezfile/classes/ezdir.php' );
	eZDir::recursiveDelete( "extension/$folder_name" );
	$text .= "<br>The <b>$folder_name</b> extension folder and all its content has been deleted.";
}else{
	$erreur = 1;
	$text_erreur .= "<br>extension/$folder_name is not a directory.";
}



/*
eZExecution::cleanExit();
/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'titre', "Deleting an extension folder" );
$tpl->setVariable( 'text', $text );
$tpl->setVariable( 'erreur', $erreur );
$tpl->setVariable( 'text_erreur', $text_erreur );




$Result = array();
$Result['content'] =& $tpl->fetch( 'design:extension_manager/delete_folder.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "Deleting an extension folder") );
//$Result['pagelayout'] = 'popup_pagelayout.tpl';

?>