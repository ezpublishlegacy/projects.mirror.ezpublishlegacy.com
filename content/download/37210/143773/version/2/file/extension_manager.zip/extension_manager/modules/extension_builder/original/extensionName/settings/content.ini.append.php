[ActionSettings]
ExtensionDirectories[]=extensionName