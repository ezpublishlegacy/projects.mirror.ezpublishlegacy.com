<?php
$Module = array( "name" => "Extension builder","variable_params" => false );
$ViewList = array();

$ViewList["generator"] = array(
	"functions" => array( "generator" ),
	"script" => "generator.php",
	"default_navigation_part" => "ezsetupnavigationpart",
	"params" => array(),
	"unordered_params" => array()
);

$FunctionList['generator'] = array();

?>