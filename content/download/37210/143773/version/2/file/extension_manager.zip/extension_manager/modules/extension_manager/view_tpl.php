<?php	$text = $error = $text_error = "";

$_SESSION["base_site_url"] = (( array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"]=="on") ? "https://" : "http://").$_SERVER['HTTP_HOST'].eZSys::indexFile();

$enregistre = "";

$tpl_file = 'extension/'.$_SESSION["extension"]["folder_name"].'/design/standard/templates/'.$_SESSION["extension"]["module_name"].'/'.$_SESSION["extension"]["view_name"].'.tpl';
$text .= 'Editing '.$tpl_file;

if(!file_exists($tpl_file)){
	$error = 1;
	$text_error .= '<br>script_file is not a valid path';
}



if($_POST){
	if (array_key_exists("file_content",$_POST)){
	
		// Assurons nous que le fichier est accessible en �criture
		if (is_writable($tpl_file)) {
		
			// Dans notre exemple, nous ouvrons le fichier $filename en mode d'ajout
			// Le pointeur de fichier est plac� � la fin du fichier
			// c'est l� que $somecontent sera plac�
			if (!$handle = fopen($tpl_file, 'w+')) {
				$error = 2;
				$text_error .= '<br>Unable to open file';
			}
		
			// Ecrivons quelque chose dans notre fichier.
			if (fwrite($handle, $_POST["file_content"]) === FALSE) {
				$error = 2;
				$text_error .= '<br>Unable to write in the file';
			}else{
				$enregistre = 'Last save time > '.date("H:i:s");
			}
			
			fclose($handle);
							
		} else {
			$error = 2;
			$text_error .= '<br>Read only file';
		}
	}
}



	
if (file_exists($tpl_file)) { 
	$handle = fopen ($tpl_file, "r");
	$file_content = fread ($handle, filesize ($tpl_file));
	fclose ($handle);
}else{
	$error = 1;
	$text_error .= '<br>script_file is not a valid path';
}



/*
//  ---> � d�finir dans module.php
//eZExecution::cleanExit();
/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'title', "PHP" );
$tpl->setVariable( 'error', $error );
$tpl->setVariable( 'session', $_SESSION );


if($_SESSION["extension_manager_utf8"] == "oui"){
	$tpl->setVariable( 'text', utf8_encode($text) );
	$tpl->setVariable( 'text_error', utf8_encode($text_error) );
	$tpl->setVariable( 'file_content', utf8_encode($file_content) );
	$tpl->setVariable( 'enregistre', utf8_encode($enregistre) );
}else{
	$tpl->setVariable( 'text', $text );
	$tpl->setVariable( 'text_error', $text_error );
	$tpl->setVariable( 'file_content', $file_content );
	$tpl->setVariable( 'enregistre', $enregistre );
}


$Result = array();
$Result['content'] =& $tpl->fetch( 'design:extension_manager/view_tpl.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "View / edit tpl") );
$Result['pagelayout'] = 'extension_manager/empty_pagelayout.tpl';