[NavigationPart]
Part[ezextensionNamenavigationpart]=moduleName

[TopAdminMenu]
Tabs[]=extensionName

[Topmenu_extensionName]
NavigationPartIdentifier=ezextensionNamenavigationpart
Name=tabValue
Tooltip=tabToolTip

URL[]
URL[default]=tabUrl

Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false

Shown[]
Shown[default]=true
Shown[edit]=false
Shown[navigation]=true
Shown[browse]=false
