<?php	$text = $erreur = $text_erreur = "";
/*
//$node_id =& $Params['node_id'];  ---> � d�finir dans module.php
//eZExecution::cleanExit();
/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'titre', "Liste de mes scripts disponible en ligne" );
$tpl->setVariable( 'text', $text );
$tpl->setVariable( 'erreur', $erreur );
$tpl->setVariable( 'text_erreur', $text_erreur );




$Result = array();
$Result['content'] =& $tpl->fetch( 'design:extension_manager/liste.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "Liste de mes scripts disponible en ligne") );
//$Result['pagelayout'] = 'popup_pagelayout.tpl';

?>