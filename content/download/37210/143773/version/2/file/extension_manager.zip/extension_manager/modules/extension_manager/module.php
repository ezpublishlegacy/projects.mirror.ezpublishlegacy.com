<?php
$Module = array( "name" => "Extension manager","variable_params" => false );
$ViewList = array();

$ViewList["liste"] = array(
"functions" => array( "admin" ),
"script" => "liste.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array(  ),
"unordered_params" => array( "offset" => "Offset" ) );

$ViewList["delete_folder"] = array(
"functions" => array( "admin" ),
"script" => "delete_folder.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array( "folder_name" ),
"unordered_params" => array( "offset" => "Offset" ) );

$ViewList["show"] = array(
"functions" => array( "admin" ),
"script" => "show.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array( "folder_name" ),
"unordered_params" => array( "offset" => "Offset" ) );

$ViewList["ajax_functions"] = array(
"functions" => array( "admin" ),
"script" => "ajax_functions.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array(),
"unordered_params" => array('f','folder_name') );

$ViewList["view_php"] = array(
"functions" => array( "admin" ),
"script" => "view_php.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array(),
"unordered_params" => array() );

$ViewList["view_tpl"] = array(
"functions" => array( "admin" ),
"script" => "view_tpl.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array(),
"unordered_params" => array() );

$ViewList["view_module_php"] = array(
"functions" => array( "admin" ),
"script" => "view_module_php.php",
"default_navigation_part" => "ezsetupnavigationpart",
"params" => array(),
"unordered_params" => array() );

$FunctionList['admin'] = array();

?>