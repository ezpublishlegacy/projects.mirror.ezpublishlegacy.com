<?php	$text = $error = $text_error = "";

$_SESSION["base_site_url"] = (( array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"]=="on") ? "https://" : "http://").$_SERVER['HTTP_HOST'].eZSys::indexFile();

$enregistre = "";

$modules_dir = 'extension/'.$_SESSION["extension"]["folder_name"].'/modules';
$module_php_file = $modules_dir.'/'.$_SESSION["extension"]["module_name"].'/module.php';

$script_file = $module_php_file;

if( file_exists($script_file)){
	$text .= 'Editing '.$module_php_file;
}else{
	$error = 1;
	$text_error .= '<br>script_file is not a valid path';
}


if($_POST){
	if (array_key_exists("file_content",$_POST)){
		if (is_writable($script_file)) {
			if (!$handle = fopen($script_file, 'w+')) {
				$error = 2;
				$text_error .= '<br>Unable to open file';
			}
			if (fwrite($handle, $_POST["file_content"]) === FALSE) {
				$error = 2;
				$text_error .= '<br>Unable to write in the file';
			}else{
				$enregistre = 'Last save time > '.date("H:i:s");
			}
			fclose($handle);				
		} else {
			$error = 2;
			$text_error .= '<br>Read only file';
		}
	}
}



	
if (file_exists($script_file)) { 
	$handle = fopen ($script_file, "r");
	$file_content = fread ($handle, filesize ($script_file));
	fclose ($handle);
}else{
	$error = 1;
	$text_error .= '<br>script_file is not a valid path';
}



/*
//  ---> � d�finir dans module.php
//eZExecution::cleanExit();
/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'title', "PHP" );
$tpl->setVariable( 'error', $error );
$tpl->setVariable( 'session', $_SESSION );

if($_SESSION["extension_manager_utf8"] == "oui"){
	$tpl->setVariable( 'text', utf8_encode($text) );
	$tpl->setVariable( 'text_error', utf8_encode($text_error));
	$tpl->setVariable( 'file_content', utf8_encode($file_content) );
	$tpl->setVariable( 'enregistre', utf8_encode($enregistre) );
}else{
	$tpl->setVariable( 'text', $text );
	$tpl->setVariable( 'text_error', $text_error );
	$tpl->setVariable( 'file_content', $file_content );
	$tpl->setVariable( 'enregistre', $enregistre );
}

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:extension_manager/view_module_php.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "Liste de mes scripts disponible en ligne") );
$Result['pagelayout'] = 'extension_manager/empty_pagelayout.tpl';
