<?php	$text = $erreur = $text_erreur = "";

$base_site_url = (( array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"]=="on") ? "https://" : "http://").$_SERVER['HTTP_HOST']."/";

$original='extension/extension_manager/modules/extension_builder/original';
$new='extension/extension_manager/modules/extension_builder/new';

//eZExecution::cleanExit();

function deltree($dossier){
	if(($dir=opendir($dossier))===false){return;}
	while($name=readdir($dir)){
		if($name==='.' or $name==='..')
		continue;
		$full_name=$dossier.'/'.$name;
		if(is_dir($full_name)){
			deltree($full_name);
		}else{
			if(unlink($full_name)){//echo "<br>deltree() :) deleting de ".$full_name;
			}else{echo "<br>deltree() :( suppression de ".$full_name;}			
		}
	}
	closedir($dir);
	if(rmdir($dossier)){//echo "<br>deltree() :) deleting ".$dossier;
	}else{echo "<br>deltree() :( suppression de ".$dossier;}
}

function copyFile($filename, $newfilename, $arraybad, $arraygood){
	//echo "<br>filename = $filename";echo "<br>newfilename = $newfilename";echo "<br>arraybad = ".print_r($arraybad);echo "<br>arraygood = ".print_r($arraygood);
	if(!file_exists($filename)){
		die("Fichier inexistant : $filename");
	}
	$fd=fopen($filename,"r");
	$content=fread($fd,filesize($filename));
	fclose($fd);
	$content=str_replace($arraybad,$arraygood,$content);
	$fp=fopen($newfilename,"w+");
	fwrite($fp,$content);
	fclose($fp);
	//eZExecution::cleanExit();
}


if(is_dir($new)){
	//deltree("$new");
	include_once( 'lib/ezfile/classes/ezdir.php' );
	eZDir::recursiveDelete( $new );
}
if(is_file("extension/extension_manager/modules/extension_builder/myNewExtension.zip")){
	unlink("extension/extension_manager/modules/extension_builder/myNewExtension.zip");
}

if($_POST){

//// echo "<pre>".print_r($_POST,true)."</pre>";
$create_action=isset($_POST["create_action"])?$_POST["create_action"]:"";
$extensionName=isset($_POST["extensionName"])?trim($_POST["extensionName"]):"";
$add_to_my_extensions=isset($_POST["add_to_my_extensions"])?trim($_POST["add_to_my_extensions"]):"";
$create_dir_autoloads=isset($_POST["create_dir_autoloads"])?$_POST["create_dir_autoloads"]:"";
$create_dir_translations=isset($_POST["create_dir_translations"])?$_POST["create_dir_translations"]:"";
$create_dir_design=isset($_POST["create_dir_design"])?$_POST["create_dir_design"]:"";
$create_admin_top_menu_tab=isset($_POST["create_admin_top_menu_tab"])?$_POST["create_admin_top_menu_tab"]:"";
$modules=isset($_POST["modules"])?$_POST["modules"]:"";

mkdir ("$new", 0777);// echo "<br> creation of new dir";
mkdir ("$new/".$extensionName, 0777);// echo "<br> creation of new extension dir";

//******************** SETTINGS *****************
mkdir ("$new/".$extensionName."/settings", 0777);
//mkdir ("$new/".$extensionName."/settings/".$extensionName, 0777);

copyFile("$original/extensionName/settings/site.ini.append.php", "$new/".$extensionName."/settings/site.ini.append.php", array("extensionName"), array($extensionName)	);

// settings / menu.ini.append.php
if(!empty($create_admin_top_menu_tab)){
	copyFile(	"$original/extensionName/settings/menu.ini.append.php", 
				"$new/".$extensionName."/settings/menu.ini.append.php", 
				array("extensionName", "tabValue", "tabToolTip", "tabUrl", "moduleName"), 
				array($extensionName, $_POST["tabValue"], $_POST["tabToolTip"], $_POST["tabUrl"], $_POST["moduleName"])	);
}

// settings / module.ini.append.php
if(!empty($modules)){
	$strModuleList .= "";
	foreach($modules as $key=>$value){
		$strModuleList .= "ModuleList[]=".$key."\n";
	}
	copyFile(	"$original/extensionName/settings/module.ini.append.php", 
				"$new/".$extensionName."/settings/module.ini.append.php", 
				array("extensionName","ModuleList[]=moduleName"),
				array($extensionName,$strModuleList)	);
}

if(!empty($create_dir_autoloads)){
	mkdir ("$new/".$extensionName."/autoloads", 0777);	
	copyFile(	"$original/extensionName/autoloads/extensionName_operators.php", 
				"$new/".$extensionName."/autoloads/".$extensionName."_operators.php", 
				array("extensionName"), 
				array($extensionName)	);
	copyFile(	"$original/extensionName/autoloads/eztemplateautoload.php", 
				"$new/".$extensionName."/autoloads/eztemplateautoload.php", 
				array("extensionName"), 
				array($extensionName)	);
}


if(!empty($create_action)){
	copyFile("$original/extensionName/settings/content.ini.append.php","$new/".$extensionName."/settings/content.ini.append.php",array("extensionName"),array($extensionName)	);
	mkdir ("$new/".$extensionName."/actions", 0777);
	copyFile("$original/extensionName/actions/content_actionhandler.php","$new/".$extensionName."/actions/content_actionhandler.php",array("extensionName","customActionName"),array($extensionName, trim($_POST["customActionName"]) ));
}
// creation of translation dir
if(!empty($create_dir_translations)){
	mkdir ("$new/".$extensionName."/translations", 0777);
	mkdir ("$new/".$extensionName."/translations/fre-FR", 0777);
	copyFile(	"$original/extensionName/translations/fre-FR/translation.ts", 
				"$new/".$extensionName."/translations/fre-FR/translation.ts", 
				array("extensionName"), 
				array($extensionName)	);
}

// creation of design dir
if(!empty($create_dir_design)){
	mkdir ("$new/".$extensionName."/design", 0777);
	mkdir ("$new/".$extensionName."/design/standard", 0777);
	mkdir ("$new/".$extensionName."/design/standard/images", 0777);
	mkdir ("$new/".$extensionName."/design/standard/javascripts", 0777);
	mkdir ("$new/".$extensionName."/design/standard/stylesheets", 0777);
	mkdir ("$new/".$extensionName."/design/standard/templates", 0777);
	copyFile("$original/extensionName/settings/design.ini.append.php", "$new/".$extensionName."/settings/design.ini.append.php", array("extensionName"), array($extensionName)	);
}

// LES MODULES
if(!empty($modules)){
	mkdir ("$new/".$extensionName."/modules", 0777);
	$strFunctionList = '';
	foreach($modules as $key=>$value){
		$key = trim($key);
		$module_php = 	"<?php\n".
						'$Module = array( \'name\' => \''.$key.'\',\'variable_params\' => false );'."\n".
						'$ViewList = array();'."\n";
		
		mkdir ("$new/".$extensionName."/modules/".$key, 0777);
		mkdir ("$new/".$extensionName."/design/standard/templates/".$key, 0777);
		mkdir ("$new/".$extensionName."/design/standard/javascripts/".$key, 0777);
		mkdir ("$new/".$extensionName."/design/standard/stylesheets/".$key, 0777);
		mkdir ("$new/".$extensionName."/design/standard/images/".$key, 0777);
		$scripts = explode(";", $value);
		foreach($scripts as $scriptName){
			$scriptName = trim($scriptName);
			copyFile("$original/extensionName/modules/moduleName/scriptName.php", "$new/".$extensionName."/modules/".$key."/".$scriptName.".php", array("extensionName","moduleName","scriptName"), array($extensionName,$key,$scriptName)	);
			if(!empty($create_dir_design)){
				copyFile("$original/extensionName/design/standard/templates/moduleName/scriptName.tpl", "$new/".$extensionName."/design/standard/templates/".$key."/".$scriptName.".tpl", array("extensionName","moduleName","scriptName"), array($extensionName,$key,$scriptName)	);
				copyFile("$original/extensionName/design/standard/javascripts/moduleName/scriptName.js", "$new/".$extensionName."/design/standard/javascripts/".$key."/".$scriptName.".js", array(), array()	);	
				copyFile("$original/extensionName/design/standard/stylesheets/moduleName/scriptName.css", "$new/".$extensionName."/design/standard/stylesheets/".$key."/".$scriptName.".css", array(), array()	);	
			}
			$module_php .= "\n".'$ViewList[\''.$scriptName.'\'] = array('."\n".'\'functions\' => array( \''.$scriptName.'\' ),'."\n".'\'script\' => \''.$scriptName.'.php\','."\n".'\'default_navigation_part\' => \'ezcontentnavigationpart\','."\n".'\'params\' => array(  ),'."\n".'\'unordered_params\' => array( \'offset\' => \'Offset\' )'."\n".');'."\n";
			$strFunctionList .= '$FunctionList[\''.$scriptName.'\'] = array();'."\n";
		}
		$module_php .= $strFunctionList."\n?>";
		$fp = fopen("$new/".$extensionName."/modules/".$key."/module.php", "w+");
		fwrite ($fp, $module_php);
		fclose($fp);
	}
}


include_once( 'pclzip.lib.php' );
$filename = "extension/extension_manager/modules/extension_builder/myNewExtension.zip";
$archive = new PclZip($filename);
$archive->create("$new/".$extensionName."/",PCLZIP_OPT_REMOVE_PATH, "$new");

$text .= '<br>1/ <a href="'.$base_site_url.$filename.'">Download your new extension (.zip)</a><br>' ;
$text .= "<br>2/ Extract this in your extension folder (Extract here)";
$text .= "<br>3/ Upload your new extension";
$text .= "<br>4/ Activate it in the back office";
$text .= "<br>5/ Clear all cache";

if(!empty($add_to_my_extensions)){
	// copy a directory and all subdirectories and files (recursive)
	// void dircpy( str 'source directory', str 'destination directory' [, bool 'overwrite existing files'] )
	function dircpy($basePath, $source, $dest, $overwrite = false){
		if(!is_dir($basePath . $dest)) //Lets just make sure our new folder is already created. Alright so its not efficient to check each time... bite me
		mkdir($basePath . $dest);
		if($handle = opendir($basePath . $source)){        // if the folder exploration is sucsessful, continue
			while(false !== ($file = readdir($handle))){ // as long as storing the next file to $file is successful, continue
				if($file != '.' && $file != '..'){
					$path = $source . '/' . $file;
					if(is_file($basePath . $path)){
						if(!is_file($basePath . $dest . '/' . $file) || $overwrite)
						if(!@copy($basePath . $path, $basePath . $dest . '/' . $file)){
							echo 'File ('.$path.') could not be copied, likely a permissions problem.';
						}
					} elseif(is_dir($basePath . $path)){
						if(!is_dir($basePath . $dest . '/' . $file))
						mkdir($basePath . $dest . '/' . $file); // make subdirectory before subdirectory is copied
						dircpy($basePath, $path, $dest . '/' . $file, $overwrite); //recurse!
					}
				}
			}
			closedir($handle);
		}
	}
	dircpy("", $new, "extension", true);
	
	$text .= "<br><hr><br>It's also been added in your extension directory : ";
}

}// fin de if($_POST){



//eZExecution::cleanExit();


/******************** APPEL DU TEMPLATE *********************/
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'titre', "Ezpublish extension and module builder" );
$tpl->setVariable( 'text', $text );
$tpl->setVariable( 'erreur', $erreur );
$tpl->setVariable( 'text_erreur', $text_erreur );




$Result = array();
$Result['content'] =& $tpl->fetch( 'extension/extension_manager/design/standard/templates/extension_builder/generator.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => "Ezpublish extension and module builder") );
//$Result['pagelayout'] = 'popup_pagelayout.tpl';

?>