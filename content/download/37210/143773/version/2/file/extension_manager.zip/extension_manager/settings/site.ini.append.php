<?php /* #?ini charset="iso-8859-1"?

[TemplateSettings]
ExtensionAutoloadPath[]=extension_manager

*/ ?>
