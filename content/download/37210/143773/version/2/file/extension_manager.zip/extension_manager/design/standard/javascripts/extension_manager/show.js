function wo(nomFichier)
{    
	h=screen.height;
	w=screen.width;
	top=0;
	left=0;
	window.open(nomFichier,nomFichier,"top="+top+",left="+left+",width="+w+",height="+h+",resizable=yes,menubar=no,scrollbars=yes,statusbar=no");
}