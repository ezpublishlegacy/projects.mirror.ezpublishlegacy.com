<?php
// Operator autoloading
$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/extension_manager/autoloads/xl_operators.php',
         'class' => 'xl_operators',
         'operator_names' => array( 'xl_hello', 
									'xl_print_array',
									'xl_objects_by_owner_count',
									'xl_getpostvar',
									'xl_setsessionvar',
									'xl_getsessionvar',
									'xl_showdate'));

?>