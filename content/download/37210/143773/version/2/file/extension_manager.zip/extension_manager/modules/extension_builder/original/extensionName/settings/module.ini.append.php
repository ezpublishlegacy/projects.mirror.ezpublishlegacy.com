<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=extensionName
ModuleList[]
ModuleList[]=moduleName

*/?>

