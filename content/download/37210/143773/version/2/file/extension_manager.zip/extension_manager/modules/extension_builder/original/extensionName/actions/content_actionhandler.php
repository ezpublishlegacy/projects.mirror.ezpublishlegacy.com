<?php

//include_once( 'lib/ezutils/classes/ezoperationhandler.php' );

function extensionName_ContentActionHandler( &$module, &$http, &$objectID ) 
{ 
	if( $http->hasPostVariable("customActionName") ) 
	{ 
       //your custom action goes here 
	   
	   //$module->redirectTo( '/content/view/full/' .$nodeID );
	} 
} 
?>