<?php
class extensionName_operators{
    function extensionName_operators(){	
		$this->Operators = array( 'hello');	
	}
    function &operatorList(){	
		return $this->Operators;	
	}
    function namedParameterPerOperator(){	
		return true;	
	}
	function namedParameterList(){	
		return array('hello'=>array('hello'=>array(	'type'=>'string',
													'required'	=> true,
													'default'	=> '' 		)));	
	}
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters ){
        switch ( $operatorName ){
			case 'hello':	
				$operatorValue = $this->hello($namedParameters['hello']);
			break;	
		}
    }
	
    function hello($p){
		//return '<pre>'.print_r($p,true).'</pre>';
		return "Hello ".$p;
    }
		
    /// \privatesection
    var $Operators;
}

?>