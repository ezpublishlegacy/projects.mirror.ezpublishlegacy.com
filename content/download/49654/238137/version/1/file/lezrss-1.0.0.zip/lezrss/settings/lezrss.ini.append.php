<?php /* #?ini charset="UTF-8"?

[RSSSettings]

# This parameter allow to prefix rss2/feed call.
# You can use http://example.com/rss2/feed instead of  http://example.com/rss2/feed/news
#DefaultRSS=news

*/ ?>