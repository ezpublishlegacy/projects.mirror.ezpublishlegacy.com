<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=lezrss

ModuleList[]=rss2

*/ ?>