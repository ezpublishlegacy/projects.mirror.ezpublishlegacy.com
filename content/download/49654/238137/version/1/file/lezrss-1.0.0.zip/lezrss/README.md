__Project hosted on eZ Projects Forge: [http://projects.ez.no/lezrss](http://projects.ez.no/lezrss)__

Introduction
============
leZRSS is an improvement of eZRSS native function :

* Adds fetch for get all RSS feed defined
* Adds module rss2 for use template system in RSS

Continuous integration
======================
leZRSS is under continuous integration: [http://ci.llaumgui.com/job/leZRSS/](http://ci.llaumgui.com/job/leZRSS/)

![eZ Publish Certified Developer](http://www.llaumgui.com/images/ezcertdev.png)
