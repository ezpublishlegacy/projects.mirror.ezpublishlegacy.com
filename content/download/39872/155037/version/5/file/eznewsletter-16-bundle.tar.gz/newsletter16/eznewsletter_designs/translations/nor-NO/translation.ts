<!DOCTYPE TS><TS>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout</name>
    <message>
        <source>Interested? Learn more ...</source>
        <translation>Interessert? Lær mer...</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Beklager, fant ikke artikkelen!</translation>
    </message>
    <message>
        <source>Topics</source>
        <translation>Emner</translation>
    </message>
    <message>
        <source>back</source>
        <translation>tilbake</translation>
    </message>
    <message>
        <source>Upcoming Events</source>
        <translation>Kommende arrangementer</translation>
    </message>
    <message>
        <source>Legal Information</source>
        <translation>Rettslig informasjon</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Avmelding</translation>
    </message>
    <message>
        <source>Upcoming events</source>
        <translation>Kommende arrangementer</translation>
    </message>
    <message>
        <source>Legal information</source>
        <translation>Rettslig informasjon</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>EMNER denne uken</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>EMNER</translation>
    </message>
    <message>
        <source>EVENTS THIS MONTH</source>
        <translation>EMNER DENNE MÅNEDEN</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Hei, vi har en nyhet til deg. Gå til %url_to_newsletter for å se vårt nye nyhetsbrev.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite</name>
    <message>
        <source>back</source>
        <translation>tilbake</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Beklager, fant ikke artikkelen!</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Les hele historien...</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Forside</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Avmelding</translation>
    </message>
    <message>
        <source>Also today</source>
        <translation>Også idag</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Kontakt oss</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>EMNER denne uken</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>EMNER</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Les mer</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Hei, vi har en nyhet til deg. Gå til %url_to_newsletter for å se vårt nye nyhetsbrev.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/node/view/newsletter</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Les hele historien...</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout</name>
    <message>
        <source>Read more</source>
        <translation>Les mer</translation>
    </message>
    <message>
        <source>Only</source>
        <translation>Bare</translation>
    </message>
    <message>
        <source>Buy this product now</source>
        <translation>Kjøp dette produktet nå</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Kontakt oss</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Avmelding</translation>
    </message>
    <message>
        <source>ONLY</source>
        <translation>BARE</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout/sms</name>
    <message>
        <source>Hello, we have some products available which might interrest you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Hei, vi har noen produkter som kanskje interesserer deg. Gå til %url_to_newsletter for å se vårt nye nyhetsbrev.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Pris:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Din pris:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Du sparer:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Pris</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Brukerinformasjon</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>Bruker-ID</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Logg inn</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
</context>
</TS>
