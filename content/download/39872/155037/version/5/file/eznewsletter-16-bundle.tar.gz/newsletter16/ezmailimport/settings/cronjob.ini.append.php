<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezmailimport

[CronjobPart-importmail]
Scripts[]
Scripts[]=importmail.php

*/ ?>
