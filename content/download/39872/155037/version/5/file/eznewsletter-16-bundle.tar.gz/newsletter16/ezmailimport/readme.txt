eZMailimport
============

Version: 1.1
 PHP5 Port of ezmailimport
 
 WARNING:
  ezmailimport 1.1 is not tested in detail 


============

Version: 0.2.0 *Beta*

Extension for importing e-mails with imap & pop3 support.

Description
-----------
Importing e-mails as content objects with the following features:
- Imap & Pop3 support
- Freely chooseable content class for generated objects
- Mapping of message elements (from, messagesource...) to contentclass attributes

Installation
============
- Setup the mailboxes & e-mail addresses in your mailserver
- Copy the extension to ezpublish/extension
- Customize the ini settings to your needs
- Activate the extension

Changelog 0.1.0 > 0.2.0
=======================
- Changed XML parser handling for body import (changed XML API in >3.8)
- fixed not deleting emails on imap error

Known Bugs
==========
-- none --
