<?php
//
// Created on: <30-Oct-2005 11:11:11 dis>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
class eZMultiselectFilter
{
    function createSqlParts( $params )
    {
        $sqlTables = '';
        $sqlJoins = '';
        $sqlCond = '';
        
        foreach( $params as $subparams )
        {
            if( isset($subparams['value']) && isset($subparams['class_attribute_id']) )
            {
                $aliasTableName = "ezmsfilter_".$subparams['class_attribute_id'];
                $sqlTables  .= ", ezcontentobject_attribute {$aliasTableName} ";
                $sqlJoins   .= " {$aliasTableName}.contentclassattribute_id = ".$subparams['class_attribute_id']." AND \n";
                $sqlJoins   .= " ezcontentobject.id = {$aliasTableName}.contentobject_id AND \n";
                $sqlJoins   .= " {$aliasTableName}.version = ezcontentobject_name.content_version AND \n";
                $sqlJoins   .= " {$aliasTableName}.language_code = ezcontentobject_name.real_translation AND \n";
                $sqlCond    .= " 0 < instr( {$aliasTableName}.data_text, '".$subparams['value']."' ) AND \n";
                $sqlCond    .= $sqlJoins." ";
            }
            else
            {
                return false;
            }
        }
        //var_dump(array( 'tables' => $sqlTables, 'joins'  => $sqlCond ));
        //exit();
        return array( 'tables' => $sqlTables, 'joins'  => $sqlCond );   
    }
}

?>
