<?php /* #?ini charset="iso-8859-1"?

[TemplateSettings]
AutoloadPathList[]=extension/eznewsletter/autoloads

[RegionalSettings]
TranslationExtensions[]=eznewsletter

*/ ?>
