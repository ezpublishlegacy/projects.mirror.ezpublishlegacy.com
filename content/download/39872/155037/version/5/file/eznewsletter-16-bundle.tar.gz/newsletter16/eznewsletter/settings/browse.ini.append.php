<?php /*

[ArticlePoolBrowse]
StartNode=content
SelectionType=single
ReturnType=ObjectID
TopLevelNodes[]
TopLevelNodes[]=content

[BrowseInbox]
StartNode=content
SelectionType=single
ReturnType=ObjectID
TopLevelNodes[]
TopLevelNodes[]=content

*/ ?>