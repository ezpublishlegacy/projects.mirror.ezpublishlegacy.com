<?php/*
[RegionalSettings]
TranslationExtensions[]=ezmailimport
*/
?>
