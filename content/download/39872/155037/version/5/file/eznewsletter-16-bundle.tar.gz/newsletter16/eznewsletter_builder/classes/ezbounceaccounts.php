<?php
//
// Created on: <15-Mar-2007 11:11:11 tos>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
/*
include_once( 'lib/ezutils/classes/ezini.php' );
*/
class eZBounceAccounts
{
    var $iniInstance;
    var $accounts;

    function __construct()
    {
        $this->iniInstance = eZINI::instance(  'bounce.ini', 'settings', null, null, true );
        if( $this->iniInstance->hasVariable( 'MailAccountSettings', 'AccountList' ) )
        {
            foreach( $this->iniInstance->variable( 'MailAccountSettings', 'AccountList' ) as $accountName )
            {
                $this->accounts[$accountName] = $this->iniInstance->group( $accountName );
            }
        }
        else
        {
            $this->accounts = array();
        }
    }

    function fetch( $accountName )
    {
        return isset( $this->accounts[$accountName] ) ? $this->accounts[$accountName] : false;
    }

    function fetchList( )
    {
        return $this->accounts;
    }

    function storeAccount( $accountName, $accountData )
    {
        $this->accounts[$accountName] = $accountData;

        $this->iniInstance->setVariables( array( $accountName => $accountData ) );

        $accountList = array();
        foreach( $this->accounts as $accountName => $account )
        {
            $accountList[] = $accountName;
        }
        $this->iniInstance->setVariables( array( 'MailAccountSettings' => array( 'AccountList' => $accountList ) ) );
        $this->store();
    }

    function removeAccount( $accountName )
    {
        $this->iniInstance->removeGroup( $accountName );
        unset( $this->accounts[$accountName] );

        $accountList = $this->iniInstance->variable( 'MailAccountSettings', 'AccountList' );
        $cleanedAccountList = array();

        foreach( $accountList as $account )
        {
            if( $accountName !== $account )
            {
                $cleanedAccountList[] = $account;
            }
        }
        $this->iniInstance->setVariables( array( 'MailAccountSettings' => array( 'AccountList' => $cleanedAccountList ) ) );
        $this->store();
    }

    function store()
    {
        $this->iniInstance->save( false , false, "append" );
    }
}

?>
