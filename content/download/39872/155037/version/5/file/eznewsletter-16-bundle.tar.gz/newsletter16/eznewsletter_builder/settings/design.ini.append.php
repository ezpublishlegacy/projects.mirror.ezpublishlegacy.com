<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=eznewsletter_builder

[StylesheetSettings]
BackendCSSFileList[]
BackendCSSFileList[]=filterbox.css
BackendCSSFileList[]=head.css

*/ ?>
