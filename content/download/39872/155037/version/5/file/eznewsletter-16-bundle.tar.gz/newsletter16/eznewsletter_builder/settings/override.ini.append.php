<?php /* #?ini charset="utf-8"?

[edit_lookandfeel]
Source=content/edit.tpl
MatchFile=edit/lookandfeel.tpl
Subdir=templates
Match[object]=54

[smstext]
Source=content/datatype/edit/eztext.tpl
MatchFile=datatype_edit/ezsmstext.tpl
Subdir=templates
Match[attribute_identifier]=shorttext
Match[class_identifier]=newsletter_issue

# Activate for inboxes
#[idea_list_topics]
#Source=node/view/full.tpl
#MatchFile=editor_view/idea_list.tpl
#Subdir=templates
#Match[class_identifier]=folder
#Match[section]=8

[list_categories]
Source=node/view/full.tpl
MatchFile=editor_view/category_list.tpl
Subdir=templates
Match[class_identifier]=folder
#Match[url_alias]=newsletter/categories
Match[node]=70

# Use to activate filtering and newsletter_article listing
#[article_list]
#Source=node/view/full.tpl
#MatchFile=editor_view/article_list.tpl
#Subdir=templates

# Use to activate filtering and newsletter_article listing during browse
#[browseArticles]
#Source=content/browse_mode_list.tpl
#MatchFile=editor_view/article_list_browse.tpl
#Subdir=templates

[article_view]
Source=node/view/full.tpl
MatchFile=editor_view/article_view.tpl
Subdir=templates
Match[class_identifier]=newsletter_article

[edit_newsletterissue]
Source=eznewsletter/edit_article.tpl
MatchFile=edit_article.tpl
Subdir=templates
Match[class_identifier]=newsletter_issue

*/ ?>
