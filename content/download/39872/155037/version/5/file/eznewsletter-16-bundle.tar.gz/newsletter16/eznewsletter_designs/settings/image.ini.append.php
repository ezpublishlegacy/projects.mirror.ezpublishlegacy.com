<?php /* #?ini charset="iso-8859-1"?

[AliasSettings]
AliasList[]=rotate
AliasList[]=shop_header_image
AliasList[]=companynewsletter_top_article_image
AliasList[]=newssite_top_article_image

# eZ Publish 4.0 does not support this currently.
#[ImageMagick]
#Filters[]=image_magick_rotate=-rotate 270

[rotate]
Filters[]
Filters[]=image_magick_rotate

[shop_header_image]
Filters[]
Filters[]=geometry/scaledownonly=555;

[companynewsletter_top_article_image]
Filters[]
Filters[]=geometry/scaledownonly=150;150

[newssite_top_article_image]
Filters[]
Filters[]=geometry/scaledownonly=200;200

*/ ?>
