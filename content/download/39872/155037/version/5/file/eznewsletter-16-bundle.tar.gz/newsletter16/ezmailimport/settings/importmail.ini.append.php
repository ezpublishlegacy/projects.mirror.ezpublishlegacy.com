<?php /*

[ImportSettings]
# For each account you want to fetch make an entry
AccountList[]
AccountList[]=TestAccount

# Detailed configuration for the account added to the AccountList
[TestAccount]
# Hostname
ServerName=mta.example.com
# Port
ServerPort=110
# Username for logging into mailbox
LoginName=login
# Passwort for mailbox
Password=pass
# Protocol to use
Protocol=pop3
# Identifier of contentclass used for generation of the content object
Flags[]=notls
# List of optional flags you can to add to the connection
# see Reference at http://php.net/manual/en/function.imap-open.php
Identifier=article
# Section to use while generating objects
Section=1

[InboxMap]
MailMap[mail@example.com]=130
# Note the number on the right side above, should denote object id of the folder where the new 
# objects are generated. You can define a location for each incoming e-mailaddress

[ContentclassMap]
# Define the mapping of mailitems to contentclass attributes
ContentMap[]
ContentMap[subject]=title
ContentMap[content]=body
# Set to "storeaschild" if you want to store the attachments below 
# the new mail node
AttachmentHandling=storeaschild
*/ ?>
