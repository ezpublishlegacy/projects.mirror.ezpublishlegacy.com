<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ModuleList[]=label
ExtensionRepositories[]=ezlabel

*/ ?>
