<!DOCTYPE TS><TS>
<context>
    <name>&lt;th&gt;{</name>
    <message>
        <source>Title</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Reads</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="obsolete"></translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The same location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/editor_view/article_list</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/bounce</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/edit_bounceaccount</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/datatype_view</name>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list</name>
    <message>
        <source>Topics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of articles in the current view</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New article</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new article.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Category name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list_browse</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_stats_box</name>
    <message>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_view</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit this article.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy this article to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy this article to the same location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply filters to view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset filters for view.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/category_list</name>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of categories in the current view</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/filter_box</name>
    <message>
        <source>Filter options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target audience:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From (Y/M/D):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To (Y/M/D):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introducion date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expire Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/idea_list</name>
    <message>
        <source>Ideas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proposer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/eznewsletter_setup/edit_bounceaccount</name>
    <message>
        <source>Comma separated flags ( visit http://php.net/imap_open for more information )</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_setup/bounce</name>
    <message>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/bounce</name>
    <message>
        <source>Bounce settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Softbounce limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The softbounce limit defines the amount of soft bounces, that will be allowed until sending to the subscriber will be suspended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the &lt;%account_name&gt; account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounce account [%account]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New accountname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password verification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/general</name>
    <message>
        <source>General setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter sendout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sendout transport method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview transport method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/menu</name>
    <message>
        <source>Newsletter setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP Cluster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email registration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Newsletter article class not found, creating newsletter articles not possible!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder</name>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup</name>
    <message>
        <source>eZ Newsletter setup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/bounce</name>
    <message>
        <source>You have to enter a valid limit for softbounces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to define an accountname.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The passwords must be equal.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/general</name>
    <message>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sendmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File (for SMTP cluster)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
