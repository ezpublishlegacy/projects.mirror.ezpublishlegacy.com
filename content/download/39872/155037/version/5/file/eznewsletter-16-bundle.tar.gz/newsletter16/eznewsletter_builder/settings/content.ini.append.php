<?php /* #?ini charset="iso-8859-1"?

[ObjectRelationDataTypeSettings]
ClassAttributeStartNode[]

#newsletter article main image
ClassAttributeStartNode[]=334;AddRelatedImages

#newsletter article small image
ClassAttributeStartNode[]=192;AddRelatedImages

#newsletter article middle image
ClassAttributeStartNode[]=193;AddRelatedImages

#newsletter article big image
ClassAttributeStartNode[]=194;AddRelatedImages

#newsletter issue header image
ClassAttributeStartNode[]=204;AddRelatedImages


#newsletter issue topics
ClassAttributeStartNode[]=340;AddRelatedTopics

                                               
#newsletter article file
ClassAttributeStartNode[]=335;AddRelatedFiles 
 
#newsletter issue image
ClassAttributeStartNode[]=345;AddRelatedImages 

#newsletter issue main topics
ClassAttributeStartNode[]=346;AddRelatedTopics 

#newsletter issue other topics
ClassAttributeStartNode[]=347;AddRelatedTopics  



*/ ?>
