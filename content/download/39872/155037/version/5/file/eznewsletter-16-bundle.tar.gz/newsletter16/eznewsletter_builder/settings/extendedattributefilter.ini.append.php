<?php /* #?ini charset="iso-8859-1"?

[eZMultiselectFilter]
ExtensionName=eznewsletter_builder
ClassName=eZMultiselectFilter
MethodName=createSqlParts
FileName=classes/ezmultiselectfilter.php

*/ ?> 
