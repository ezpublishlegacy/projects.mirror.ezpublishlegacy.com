<?php /*

[NavigationPart]
Part[eznewsletter_setup]=Newsletter setup

[Topmenu_eznewsletter_setup]
NavigationPartIdentifier=eznewsletter_setup
Name=Newsletter setup
Tooltip=eZ Newsletter setup
URL[]
URL[default]=newsletter_setup/general
Enabled[]
Enabled[default]=true
Enabled[browse]=true
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

[Topmenu_content]
URL[]
URL[default]=content/view/full/2
URL[browse]=content/browse/2
NavigationPartIdentifier=ezcontentnavigationpart
Name=Topics
Tooltip=Manage the newsletter topics
Enabled[]
Enabled[default]=true
Enabled[browse]=true
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true
*/ ?>
