<?php
//
// Created on: <16-Dec-2005 14:39:14 oms>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file importmail.php
*/
//Based on CRM mail system by BR.
$extension = 'ezmailimport';

$cli = eZCLI::instance();

if( !extension_loaded( 'imap' ) )
{
    $cli->error( "The php imap-extension is required for the import mail script" );
    return;
}

//The types as used by imap_fetchstructure, used to create a MIME-type string
$partTypes = array ( 0 => "text",
                     1 => "multipart",
                     2 => "message",
                     3 => "application",
                     4 => "audio",
                     5 => "image",
                     6 => "video",
                     7 => "other" );

//Read in the e-mail account settings
$mailsettings = eZINI::instance( 'importmail.ini' );

$mailAccountArray = $mailsettings->variable( 'ImportSettings', 'AccountList' );

$map = $mailsettings->variable( 'InboxMap', 'MailMap' );
$contentmap = $mailsettings->variable( 'ContentclassMap', 'ContentMap' );

foreach( $mailAccountArray as $account )
{
    $ServerName = $mailsettings->variable( $account, 'ServerName' );
    $ServerPort = $mailsettings->variable( $account, 'ServerPort' );
    $LoginName = $mailsettings->variable( $account, 'LoginName' );
    $Password = $mailsettings->variable( $account, 'Password' );
    $Protocol = $mailsettings->variable( $account, 'Protocol' );
    $Flags = $mailsettings->variable( $account, 'Flags' );
    if ( is_array( $Flags ) and count( $Flags ) > 0 )
    {
        $Flags = '/' . join( '/', array_unique( $Flags ) );
    }
    else
    {
        $Flags = '';
    }

    $contentclass_identifier = $mailsettings->variable( $account, 'Identifier' );
    $section = ( $mailsettings->variable( $account, 'Section' ) ?
                 $mailsettings->variable( $account, 'Section' ) : 1 );

    $cli->output( "Connecting to: " . $ServerName . ":" . $ServerPort );
    
    $server = "{" . $ServerName . ":" . $ServerPort . "/". $Protocol . $Flags . "}INBOX";

    $mailbox = imap_open( $server, $LoginName, $Password );
    if ( $mailbox == false )
    {
        $cli->output( "Error: " . imap_last_error() );
        continue;
    }
    $ret_array = array();

    // fetch numbers of all new mails

    $num = imap_num_msg( $mailbox );
    $cli->output( "Fetching $num messages" );

    $params = array();
    $params['part_types'] = $partTypes;
    $params['mail_box'] = $mailbox;

// check each mail in inbox
    for ( $i = 1; $i <= $num; $i++ )
    {
        $cli->output( "." );
        $params['mail_id'] = $i;

        // fetch mail headers to get the structure.
        $headerinfo = imap_header( $mailbox, $i );
        $mailstructure = imap_fetchstructure( $mailbox, $i );

        printDebug_r( $mailstructure );

        // fetch the message.
        $partArray = buildparts ( $mailstructure, "", $params );
        printDebug( "\nPART ARRAY:\n\n\n\n" );
        printDebug_r( $partArray );

        // fetch the mail headers.
        $headerInfo = imap_headerinfo( $mailbox, $i );
        
        $to = $headerInfo->toaddress;

        // define owner of that mail
        $fromaddress = $headerInfo->fromaddress;
        $name = null;
        $from = null;
        #include_once( 'lib/ezutils/classes/ezmail.php' );
        eZMail::extractEmail( $fromaddress, $from, $name );
        $user = eZUser::fetchByEmail( $from );
        if ( $user )
        {
            $oldUserID = eZUser::currentUserID();
            eZUser::setCurrentlyLoggedInUser( $user, $user->id() );
        }

        //Create contentobject of this data, for the inboxes defined in the ini file
        if ( in_array( $to, array_keys( $map ) ) )
        {
            $mailitems = array();
            $files = array();
            getMailPartValues( $headerInfo, $partArray, $contentmap, $mailitems, $files );
            createInboxEntry( $to, $map, $section, $contentclass_identifier, $mailitems, $files );
        }
        
        //make sure that logged in user logs out again
        if ( isset( $oldUserID ) )
        {
            $user = eZUser::fetch( $oldUserID );
            eZUser::setCurrentlyLoggedInUser( $user, $user->id() );
            unset( $oldUserID );
        }
        $imapErrors = imap_errors();
        $imapAlerts = imap_alerts();

        //delete emails after fetch
        $ifdelete = true;

        if ( $imapErrors )
        {
            print( "\nMAIL ID: $mailID\n" );
            print_r( $imapErrors );
            $ifdelete = false;
        }
        if ( $imapAlerts )
        {
            print( "\nMAIL ID: $mailID\n" );
            print_r( $imapAlerts );
        }
        
        if ($ifdelete)
        {
            imap_delete( $mailbox, $i );
        }
    }
    $cli->output( "" );
}

/*!
  Fetches the the plain/text message body of a structured email message array and wanted header fields as denoted in \c contentmap.
 */
function getMailPartValues( $headers, $partArray, $contentmap, &$mappedFields, &$fileNames )
{
    if ( is_array( $partArray ) )
    {
        foreach( $partArray as $partKey => $subPart )
        {
            //Check if we have sub parts or not
            if ( is_numeric( $partKey ) )
            {
                getMailPartValues( $headers, $subPart, $contentmap, $mappedFields, $fileNames );
            }
            else
            {
                //Check if we have mail content here
                if ( $partKey == 'content' && isset( $partArray[$partKey] ) && isset( $partArray['type'] )&& $partArray['type']=='text/plain' )
                {
                    $contentAttr = $contentmap[$partKey];
                    $mappedFields[$contentAttr] = $partArray[$partKey];
                }
                else if ( $partKey == 'ifattachment' && isset( $partArray[$partKey] ) && $partArray[$partKey] == '1' )
                {
                    $fileEntry = array();
                    $fileEntry['attachment_filename'] = $partArray['filename'];
                    $fileEntry['original_filename'] = $partArray['original_name'];
                    $fileNames[] = $fileEntry;
                }
                else if ( $partKey == 'headers' || ( isset( $headers) && $headers != null ) )
                {
                    foreach( $contentmap as $mailHeader => $contentAttribute )
                    {

                        switch( $mailHeader )
                        {
                            case 'subject':
                            case 'in_reply_to':
                            case 'toaddress':
                            case 'fromaddress':
                            case 'ccaddress':
                            case 'bccaddress':
                            case 'reply_toaddress':
                            case 'senderaddress':
                            case 'return_path':
                            case 'fetchfrom':
                            case 'fetchsubject':
                            {
                                if ( isset( $subPart->$mailHeader ) )
                                {
                                    $mappedFields[$contentAttribute] = generateFromMimeHeader( $subPart->$mailHeader );
                                }
                                else if ( isset( $headers->$mailHeader ) )
                                {
                                    $mappedFields[$contentAttribute] = generateFromMimeHeader( $headers->$mailHeader );
                                }
                            }break;
                        }
                    }
                }
            }
        }
    }
}

/*!
  Creates a content object with where attributes are completed with values form \c mailFields.
  The keys in \c mailFields correspond to attribute names in the content class denoted by
  \c classIdentifier.

  Each entry is assigned to a node on the basis of \c to, which signifies the address of the inbox.
 */
function createInboxEntry( $to, $articlePoolMapping, $section, $classIdentifier, $mailFields, $fileNames )
{
    $messageClass = eZContentClass::fetchByIdentifier( $classIdentifier );

    if ( $messageClass )
    {
        $db = eZDB::instance();
        $db->begin();
        $messageObject = $messageClass->instantiate( false, $section );
        if ( !$messageObject )
        {
            $db->rollbackQuery();
            return;
        }
        $messageObject->store();
        $db->commit();

        $destContentObjectID =  $articlePoolMapping[$to];
        $parentNode = eZContentObjectTreeNode::findMainNode( $destContentObjectID );

        $nodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $messageObject->attribute( 'id' ),
                                                           'contentobject_version' => $messageObject->attribute( 'current_version' ),
                                                           'is_main' => 1,
                                                           'parent_node' => $parentNode ) );
        $nodeAssignment->store();
        $version = $messageObject->version( 1 );
        $version->setAttribute( 'status', eZContentObjectVersion::STATUS_DRAFT );
        $version->store();

        //Set attributes according to mapping from ini file, also checks whether the target atribute is of the xml type or not.
        $dataMap = $messageObject->dataMap();

        foreach ( $mailFields as $field => $value )
        {
            $attributeLink = $dataMap[$field];
            if ( $attributeLink != null )
            {
                $datatype = $attributeLink->attribute( 'data_type_string' );
                if ( $datatype == 'ezxmltext' )
                {
                    setEZXMLAttribute( $attributeLink, $value );
                }
                else
                {
                    $attributeLink->setAttribute( 'data_text', $value );
                }
                $attributeLink->store();
                unset( $datatype );
            }
        }

        $messageObject->store();
        $operationResult = eZOperationHandler::execute( 'content', 'publish',
                                                        array( 'object_id' => $messageObject->attribute( 'id' ),
                                                               'version' => 1 ) );

        $mailsettings = eZINI::instance( 'importmail.ini' );

        $attachmentHandling = $mailsettings->variable( 'ContentclassMap', 'AttachmentHandling' );
        $messageNode = eZContentObjectTreeNode::findMainNode( $messageObject->attribute( 'id' ) );
        if( $attachmentHandling == 'storeaschild' and is_array( $fileNames ) && count( $fileNames ) > 0 )
        {
            #include_once( 'kernel/classes/ezcontentupload.php' );
            $db = eZDB::instance();
            $db->begin();
            foreach ( $fileNames as $file )
            {
                $result = array();
                $upload = new eZContentUpload();
                $upload->handleLocalFile( $result, $file['attachment_filename'], $messageNode, null, $file['original_filename'] );
                unlink( $file['attachment_filename'] );
            }
            $db->commit();
        }
    }
}

/*!
  Stores the value of \c attributeValue in \c attribute, if the attribute field in a content class is an XML field.
 */
function setEZXMLAttribute( &$attribute, $attributeValue )
{
    /* 3.7 compatible
    include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php" );
    $inputData = "<?xml version=\"1.0\" ?".">";
    $inputData .= "<section>";
    $inputData .= "<paragraph>";
    $inputData .= $attributeValue;
    $inputData .= "</paragraph>";
    $inputData .= "</section>";

    $dumpdata = "";
    $simplifiedXMLInput = new eZSimplifiedXMLInput( $dumpdata, null, null );
    $inputData = $simplifiedXMLInput->convertInput( $inputData );

    $domString = eZXMLTextType::domString( $inputData[0] );

    $domString = str_replace( "<paragraph> </paragraph>", "", $domString );
    $domString = str_replace ( "<paragraph />" , "", $domString );
    $domString = str_replace ( "<line />" , "", $domString );
    $domString = str_replace ( "<paragraph></paragraph>" , "", $domString );
    $domString = str_replace( "<paragraph>&nbsp;</paragraph>", "", $domString );
    $domString = str_replace( "<paragraph></paragraph>", "", $domString );

    $domString = preg_replace( "#[\n]+#", "", $domString );
    $domString = preg_replace( "#&lt;/line&gt;#", "\n", $domString );
    $domString = preg_replace( "#&lt;paragraph&gt;#", "\n\n", $domString );

    $xml = new eZXML();
    $tmpDom = $xml->domTree( $domString, array( 'CharsetConversion' => true ) );
    $description = eZXMLTextType::domString( $tmpDom );

    $attribute->setAttribute( 'data_text', $description );
    $attribute->store();
    */

    // 3.8 compatibility
    #include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinputparser.php" );
    
    $inputData = $attributeValue;
    $parser = new eZSimplifiedXMLInputParser( $attribute );
    $parser->setParseLineBreaks( true );
    $document = $parser->process( $inputData );

    $description = $document->toString();

    //$description = clean_up_dom_string( $description );
    //echo $description;
    
    $attribute->setAttribute( 'data_text', $description );
    $attribute->store();
    // 3.8 compatibility end
}

function clean_up_dom_string( $string )
{
    $domString = eZXMLTextType::domString( $string );

    $domString = str_replace( "<paragraph> </paragraph>", "", $domString );
    $domString = str_replace ( "<paragraph />" , "", $domString );
    $domString = str_replace ( "<line />" , "", $domString );
    $domString = str_replace ( "<paragraph></paragraph>" , "", $domString );
    $domString = str_replace( "<paragraph>&nbsp;</paragraph>", "", $domString );
    $domString = str_replace( "<paragraph></paragraph>", "", $domString );

    $domString = preg_replace( "#[\n]+#", "", $domString );
    $domString = preg_replace( "#&lt;/line&gt;#", "\n", $domString );
    $domString = preg_replace( "#&lt;paragraph&gt;#", "\n\n", $domString );

    $xml = new eZXML();
    $tmpDom = $xml->domTree( $domString, array( 'CharsetConversion' => true ) );
    
    return eZXMLTextType::domString( $tmpDom );
}

/*!
  For use with certain fields like from, and subject, which can contain encoded words.
  Encoded words can appear in headers with a text element. See RFC 2047 for more detail.
*/
function generateFromMimeHeader( $string )
{
    $stringArray = imap_mime_header_decode( $string );
    if ( is_array( $stringArray ) )
    {
        $retValue = "";
        foreach( $stringArray as $stringObject )
        {
            $retValue .= $stringObject->text;
        }
    }
    else
    {
        $retValue = $string;
    }
    return $retValue;
}


// ************** Build the mail structure **************
/*!
  Build the partstructure we want, to be able to store the different parts of the mail.
*/
function buildparts ( $struct, $partNumber = "", $params = array() )
{
    $partTypes = $params['part_types'];
    $mailbox = $params['mail_box'];
    $mailID = $params['mail_id'];

    $subPartArray = array();
    $subPartArray = setStructParameters( $struct, $subPartArray );
    // dparameters should override the code above.
    $subPartArray = setStructDParameters( $struct, $subPartArray );
    if ( isSet( $subPartArray['charset'] ) )
    {
        $params['charset'] = $subPartArray['charset'];
    }

    switch ( $struct->type )
    {
        case 1: // multipart
        {
            $count = 1;
            if ( $partNumber != "" )
                $partNumber .= ".";
            foreach ( $struct->parts as $part )
            {
                $subPartArray[] = buildparts( $part, $partNumber . $count, $params );
                $count++;
            }
            $subPartArray['headers'] = imap_rfc822_parse_headers( imap_fetchbody( $mailbox, $mailID, $partNumber ) );

            if ( $struct->ifparameters == 1 )
            {
                $parameters = $struct->parameters;
            }
        }break;

        case 2: // message
        {
            $count = 1;
            if ( isset( $struct->parts ) && count( $struct->parts ) > 0 )
            {
                foreach ( $struct->parts as $part )
                {
                    if ( $part->type == 0 )
                    {
                        $subPartArray = buildparts( $part, $partNumber . "." . $count, $params );
                    }
                    else
                    {
                        $subPartArray = buildparts( $part, $partNumber, $params );
                    }
                    $count++;
                }
            }

            if ( $struct->ifdescription == 1 )
            {
                $subPartArray['description'] = generateFromMimeHeader( $struct->description );
                $subPartArray['part_id'] = $partNumber;
            }
            $subPartArray['headers'] = imap_rfc822_parse_headers( imap_fetchbody( $mailbox, $mailID, $partNumber ) );
        }break;

        case 3: // application
        case 4: // audio
        case 5: // image
        case 6: // video
        {
            $subPartArray = storeAttachment( $mailbox, $mailID, $partNumber, $struct, $partTypes, $subPartArray, $params );
        }break;

        default: // other: (store the content inside this part)
        {
            // if the partnumber don't exist, default should be 1.
            if ( $partNumber == "" )
            {
                $partNumber = 1;
            }

            $disp = isset( $struct->disposition ) ? $struct->disposition : null;
            switch ( $disp )
            {
                case 'ATTACHMENT':
                {
                    $subPartArray = storeAttachment( $mailbox, $mailID, $partNumber, $struct, $partTypes, $subPartArray, $params );
                }break;

                case 'INLINE':
                {
                    $subPartArray = storeInline( $mailbox, $mailID, $partNumber, $struct, $partTypes, $subPartArray, $params );
                }break;

                default:
                {
                    $subPartArray = storeDefault( $mailbox, $mailID, $partNumber, $struct, $partTypes, $subPartArray, $params );
                }break;
            }

        }break;
    }
    return $subPartArray;
}

/*!
  Set the struct parameters.
*/
function setStructParameters( $struct, $subPartArray )
{
    // we want the filename:
    if ( $struct->ifparameters == 1 )
    {
        $parameters = $struct->parameters;
        foreach ( $parameters as $parameter )
        {
            switch ( $parameter->attribute )
            {
                case "NAME":
                {
                    $subPartArray['original_name'] = generateFromMimeHeader( $parameter->value );
                }break;

                case "CHARSET":
                {
                    $subPartArray['charset'] = $parameter->value;
                }break;
            }
        }
    }
    return $subPartArray;
}

function setStructDParameters( $struct, $subPartArray )
{
    if ( $struct->ifdparameters == 1 )
    {
        $dparameters = $struct->dparameters;
        foreach ( $dparameters as $dparameter )
        {
            switch ( $dparameter->attribute )
            {
                case "FILENAME":
                {
                    $subPartArray['original_name'] = generateFromMimeHeader( $dparameter->value );
                }break;

                case "CHARSET":
                {
                    $subPartArray['charset'] = $dparameter->value;
                }break;
            }
        }
    }
    return $subPartArray;
}


/*!
  Store a attachment from a mail. Attachment are not stored in the database, but directly on disk.
*/
function storeAttachment( $mailbox, $messageNumber, $partNumber, $struct, $partTypes, $subPartArray, $params )
{

    $subPartArray = array_merge( array( 'type' => buildTypeString( $partTypes, $struct ),
                                        'type_id' => $struct->type,
                                        'part_id' => $partNumber,
                                        'disposition' => $struct->disposition,
                                        'ifattachment' => 1,
                                        'messagenumber' => $messageNumber,
                                        'content' => '' ), $subPartArray );


    // create a file of the mail part.
    $storageDirectory = eZSys::storageDirectory() . "/ezmailimport/mail/attachment/";
    foreach ( $struct->parameters as $param )
    {
        if ( $param->attribute == "name" )
        {
            $fileName = $param->value;
            break;
        }
    }
    if ( !isset( $fileName) )
    {
        $fileName =  md5( $partNumber . eZDateTime::currentTimeStamp() );
    }
    eZFile::create( $fileName, $storageDirectory ,
                    decodeMessage( imap_fetchbody( $mailbox, $messageNumber, $partNumber ),
                                   $struct->encoding, $params ) );

    $subPartArray['filename'] = $storageDirectory . '/' . $fileName;
    return $subPartArray;
}


function storeInline( $mailbox, $messageNumber, $partNumber, $struct, $partTypes, $subPartArray, $params )
{
    $subPartArray = array_merge( array( 'type' => buildTypeString( $partTypes, $struct ),
                                        'type_id' => $struct->type,
                                        'part_id' => $partNumber,
                                        'disposition' => $struct->disposition,
                                        'content' => decodeMessage( imap_fetchbody( $mailbox, $messageNumber, $partNumber ),
                                                                    $struct->encoding, $params )
                                        ), $subPartArray );
    return $subPartArray;
}

function storeDefault( $mailbox, $messageNumber, $partNumber, $struct, $partTypes, $subPartArray, $params )
{
    $subPartArray = array_merge( array( 'type' => buildTypeString( $partTypes, $struct ),
                                        'type_id' => $struct->type,
                                        'part_id' => $partNumber,
                                        'disposition' => ( isset( $struct->disposition ) ? $struct->disposition : null ),
                                        'content' => decodeMessage( imap_fetchbody( $mailbox, $messageNumber, $partNumber ),
                                                                    $struct->encoding, $params )
                                        ), $subPartArray );
    return $subPartArray;
}


function buildTypeString( $partTypes, $struct )
{
    return strtolower( $partTypes[$struct->type] . '/' . $struct->subtype );
}

function decodeMessage( $message, $encodingType, $params )
{
    switch ( $encodingType )
    {
        case 1: // 8BIT
        {
            //$message = imap_8bit( $message ); No need to change this.
        }break;

        case 2: // BINARY
        {
            //$message = imap_binary( $message ); No need to change this.
        }break;

        case 3: // BASE64
        {
            $message = base64_decode( $message );
        }break;

        case 4: // QUOTED-PRINTABLE
        {
            $message = quoted_printable_decode( $message );
        }break;
    }

    if ( isset( $params['charset'] ) )
    {
        $charset = strtolower( $params['charset'] );
        #include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $codec = eZTextCodec::instance( $charset, false, false );
        if ( $codec )
        {
            $message = $codec->convertString( $message );
        }
    }
    return $message;
}


function printDebug( $content )
{
    //print( $content );
}

function printDebug_r( $content )
{
    //print_r( $content );
}

imap_close( $mailbox, CL_EXPUNGE );
?>
