<?php /*

[EventSettings]
ExtensionDirectories[]=eznewsletter
AvailableEventTypes[]=event_eznewsletterread

[OperationSettings]
# AvailableOperations=content_publish;before_shop_confirmorder;shop_checkout;content_read
# AvailableOperationList[]=content_read
*/ ?>
