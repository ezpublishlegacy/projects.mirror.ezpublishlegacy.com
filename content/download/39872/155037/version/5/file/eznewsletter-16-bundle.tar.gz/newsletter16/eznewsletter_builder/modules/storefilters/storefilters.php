<?php
//
// Created on: <17-Jan-2003 12:47:11 tos>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
/*
include_once( 'kernel/classes/ezpreferences.php' );
*/
$Module = $Params['Module'];
$http   = eZHTTPTool::instance();

switch( $Module->currentaction() ) 
{
    case 'Store':
        foreach( $_POST as $variableName => $variableValue ) 
        {
            if( 0 === strpos( $variableName, 'filter_' )
                && $http->hasPostVariable( $variableName ) ) 
            {
                if( is_array( $http->postVariable( $variableName ) ) ) 
                {
                    $variableArray = $http->postVariable( $variableName );
                    foreach( $variableArray as $variableElement ) 
                    {
                        eZPreferences::setValue( $variableName.'_'.$variableElement, 1);
                    }
                }
                else
                {
                    eZPreferences::setValue( $variableName, $http->postVariable( $variableName ));
                }
            }
        }
        break;

    case 'Reset':
        foreach( $_POST as $variableName => $variableValue )
        {
            if( 0 === strpos( $variableName, 'filter_' )
                && $http->hasPostVariable( $variableName ) ) 
            {
                if( is_array( $http->postVariable( $variableName ) ) ) 
                {
                    $variableArray = $http->postVariable( $variableName );
                    foreach( $variableArray as $variableElement ) {
                        eZPreferences::setValue( $variableName.'_'.$variableElement, "");
                    }
                }
                else
                {
                    eZPreferences::setValue( $variableName, "" );
                }
            }
        }
        break;
}
$Module->redirectTo( $http->postVariable( 'returnUrl' ) );
?>
