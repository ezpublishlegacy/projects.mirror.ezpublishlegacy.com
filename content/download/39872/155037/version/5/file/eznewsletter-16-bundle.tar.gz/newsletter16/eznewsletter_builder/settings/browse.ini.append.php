<?php /* #?ini charset="iso-8859-1"?

[AddRelatedImages]
StartNode=51
SelectionType=single
ReturnType=ObjectID

[AddRelatedFiles]
StartNode=52
SelectionType=single
ReturnType=ObjectID

[AddRelatedTopics]
StartNode=63
SelectionType=multiple
ReturnType=ObjectID

*/?>
