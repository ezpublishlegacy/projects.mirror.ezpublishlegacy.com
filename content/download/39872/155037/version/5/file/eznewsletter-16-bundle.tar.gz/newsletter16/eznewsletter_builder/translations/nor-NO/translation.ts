<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Rediger &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Oversett innhold fra %from_lang til %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Send til publisering</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Publiser innholdet av utkastet du redigerer. Utkastet blir dermed den publiserte versjonen av objektet.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Lagre utkast</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Lagre innholdet av utkastet du redigerer, og fortsett redigering. Bruk denne knappen for å lagre innholdet ditt med jevne mellomrom.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Forkast utkast</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Er du sikker på at du vil forkaste utkastet?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Forkast utkastet du redigerer. Dette vil også fjerne alle oversettelser som hører til utkastet (hvis noen).</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation>Sist endret</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Node-ID</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>Objekt-ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Rediger innholdet av denne enheten.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation>Du har ikke tilgang til å redigere denne enheten.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Flytt</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Flytt til en annen plassering.</translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation>Du har ikke tilgang til å flytte denne enheten.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Fjern denne enheten.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation>Du har ikke tilgang til å fjerne denne enheten.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Rediger &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Du har ikke tilgang til å redigere &lt;%child_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Søk i alt innhold.</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Alt innhold</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Søk bare under gjeldende plassering.</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>Gjeldende plassering</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>Samme plassering</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Avansert søk.</translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation>Logg ut av systemet.</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logg ut</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/editor_view/article_list</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Fant ikke artikkelklasse for nyhetsbrev, kan ikke filtrere nyhetsbrevsartikler!</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Godkjent</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/bounce</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>Valideringen av dataene dine feilet.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/edit_bounceaccount</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>Valideringen av dataene dine feilet.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/datatype_view</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list</name>
    <message>
        <source>Topics</source>
        <translation>Emner</translation>
    </message>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of articles in the current view</comment>
        <translation>%from - %to av %total_count</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Motsatt valg</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Stedsinformasjon</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Målgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Utløpsdato</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gyldighetsdato</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Opprettet av</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Utsendelser</translation>
    </message>
    <message>
        <source>Reads</source>
        <translation>Lest</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Beklager, det er ingen artikler i denne kategorien</translation>
    </message>
    <message>
        <source>New article</source>
        <translation>Ny artikkel</translation>
    </message>
    <message>
        <source>Create a new article.</source>
        <translation>Opprett en ny artikkel.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Fjern valgte</translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation>Fjern de valgte enhetene fra listen over.</translation>
    </message>
    <message>
        <source>Category name</source>
        <translation>Kategorinavn</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list_browse</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Fant ikke artikkelklasse for nyhetsbrev, kan ikke filtrere nyhetsbrevsartikler!</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Motsatt valg.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Beklager, det er ingen artikler i denne kategorien</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Stedsinformasjon</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Målgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Utløpsdato</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gyldighetsdato</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Opprettet av</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Utsendelser</translation>
    </message>
    <message>
        <source>Reads</source>
        <translation>Lest</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_stats_box</name>
    <message>
        <source>Statistics</source>
        <translation>Statistikk</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_view</name>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Edit this article.</source>
        <translation>Rediger denne artikkelen.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Fjern denne enheten.</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Flytt til en annen plassering.</translation>
    </message>
    <message>
        <source>Copy to</source>
        <translation>Kopier til</translation>
    </message>
    <message>
        <source>Copy this article to another location.</source>
        <translation>Kopier denne artikkelen til en annen plassering.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>Copy this article to the same location.</source>
        <translation>Kopier denne artikkelen til den samme plasseringen.</translation>
    </message>
    <message>
        <source>Newsletter categories</source>
        <translation>Nyhetsbrevskategorier</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Motsatt valg</translation>
    </message>
    <message>
        <source>New category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Create a new category.</source>
        <translation>Opprett en ny kategori.</translation>
    </message>
    <message>
        <source>Apply filters to view.</source>
        <translation>Aktiver filtre for visningen.</translation>
    </message>
    <message>
        <source>Reset filters for view.</source>
        <translation>Nullstill filtre for visningen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/category_list</name>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of categories in the current view</comment>
        <translation>%from - %to av %total_count</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/filter_box</name>
    <message>
        <source>Filter options</source>
        <translation>Filtervalg</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Target audience:</source>
        <translation>Målgruppe:</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation>Stedsinformasjon:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiketter:</translation>
    </message>
    <message>
        <source>From (Y/M/D):</source>
        <translation>Fra (Y/M/D):</translation>
    </message>
    <message>
        <source>To (Y/M/D):</source>
        <translation>Til (Y/M/D):</translation>
    </message>
    <message>
        <source>Apply filters</source>
        <translation>Aktiver filtre</translation>
    </message>
    <message>
        <source>Reset filters</source>
        <translation>Nullstill filtre</translation>
    </message>
    <message>
        <source>Introducion date</source>
        <translation>Introduksjonsdato</translation>
    </message>
    <message>
        <source>Expire Date</source>
        <translation>Utløpsdato</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/idea_list</name>
    <message>
        <source>Ideas</source>
        <translation>Ideer</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Motsatt valg</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Stedsinformasjon</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Målgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Utløpsdato</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gyldighetsdato</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Opprettet av</translation>
    </message>
    <message>
        <source>Proposer</source>
        <translation>Foreslått av</translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation>Innkommende</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/eznewsletter_setup/edit_bounceaccount</name>
    <message>
        <source>Comma separated flags ( visit http://php.net/imap_open for more information )</source>
        <translation>Kommaseparerte flagg (gå til http://php.net/imap_open for mer informasjon)</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_setup/bounce</name>
    <message>
        <source>Invert selection</source>
        <translation>Motsatt valg</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/bounce</name>
    <message>
        <source>Bounce settings</source>
        <translation>Bounce-innstillinger</translation>
    </message>
    <message>
        <source>Softbounce limit</source>
        <translation>Grense for softbounce</translation>
    </message>
    <message>
        <source>The softbounce limit defines the amount of soft bounces, that will be allowed until sending to the subscriber will be suspended.</source>
        <translation>Grensen for softbounce definerer antall softbounces som er tillatt for utsendelse til abonnenten blir stoppet.</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nullstill</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Kontoer</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifikator</translation>
    </message>
    <message>
        <source>Host</source>
        <translation>Server</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation>Protokoll</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Logg inn</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Flagg</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Edit the &lt;%account_name&gt; account.</source>
        <translation>Rediger kontoen &lt;%account_name&gt;.</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation>Slett valgte</translation>
    </message>
    <message>
        <source>Create account</source>
        <translation>Opprett konto</translation>
    </message>
    <message>
        <source>Bounce account [%account]</source>
        <translation>Bounce-konto [%account]</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Servernavn</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>New accountname</source>
        <translation>Nytt kontonavn</translation>
    </message>
    <message>
        <source>Password verification</source>
        <translation>Passordkontroll</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/general</name>
    <message>
        <source>General setup</source>
        <translation>Generelle innstillinger</translation>
    </message>
    <message>
        <source>Newsletter sendout</source>
        <translation>Utsendelse av nyhetsbrev</translation>
    </message>
    <message>
        <source>Sendout transport method</source>
        <translation>Transportmetode for utsendelse</translation>
    </message>
    <message>
        <source>Preview transport method</source>
        <translation>Forhåndsvis transportmetode</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nullstill</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/menu</name>
    <message>
        <source>Newsletter setup</source>
        <translation>Nyhetsbrevsinnstillinger</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Bounce</source>
        <translation>Bounce</translation>
    </message>
    <message>
        <source>SMTP Cluster</source>
        <translation>SMTP cluster</translation>
    </message>
    <message>
        <source>Email registration</source>
        <translation>E-postregistrering</translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Newsletter article class not found, creating newsletter articles not possible!</source>
        <translation>Fant ikke artikkelklasse for nyhetsbrev, kan ikke opprette nyhetsbrevsartikler!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder</name>
    <message>
        <source>Approved</source>
        <translation>Godkjent</translation>
    </message>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Fant ikke artikkelklasse for nyhetsbrev, kan ikke filtrere nyhetsbrevsartikler!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup</name>
    <message>
        <source>eZ Newsletter setup</source>
        <translation>eZ Newsletter innstillinger</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/bounce</name>
    <message>
        <source>You have to enter a valid limit for softbounces.</source>
        <translation>Du må oppgi en gyldig grense for softbounces.</translation>
    </message>
    <message>
        <source>You have to define an accountname.</source>
        <translation>Du må oppgi et kontonavn.</translation>
    </message>
    <message>
        <source>The passwords must be equal.</source>
        <translation>Passordene må være like.</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/general</name>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>File (for SMTP cluster)</source>
        <translation>Fil (for SMTP cluster)</translation>
    </message>
</context>
</TS>
