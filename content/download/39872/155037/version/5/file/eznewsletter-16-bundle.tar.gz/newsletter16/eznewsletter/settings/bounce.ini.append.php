<?php /*

#[MailAccountSettings]
#AccountList[]
#AccountList[]=MyAccount

#[MyAccount]
#ServerName=mail.example.com
#ServerPort=143
#LoginName=username
#Password=password
#Protocol can be either pop3 or imap
#Protocol=imap
#Flags[]
#Flags[]=notls
# List of optional flags you can to add to the connection
# see Reference at http://php.net/manual/en/function.imap-open.php

[BounceSettings]
BounceCount=2

*/ ?>
