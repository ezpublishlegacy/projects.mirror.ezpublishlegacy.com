<?/*

[provider]
Username=username
Password=password
Originator=Newsletter

*/
?>
