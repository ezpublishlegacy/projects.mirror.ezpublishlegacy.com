<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Bearbeiten &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Inhalt übersetzen von %from_lang nach %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Zur Veröffentlichung senden</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Den Inhalt des momentan bearbeiteten Enwurfs veröffentlichen. Dieser Entwurf wird daraufhin zur veröffentlichten Version des Obektes.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Entwurf speichern</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Den Inhalt des momentan bearbeiteten Entwurfs speichern und die Bearbeitung fortsetzen.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Entwurf verwerfen</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Sind Sie sicher, dass Sie diese Entwurf verwerfen möchten?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Den aktuell bearbeiteten Entwurf verwerfen. Zu diesem Entwurf gehörende Übersetzungen werde ebenfalls entfernt.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation>Zuletzt geändert</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Knoten ID</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>Objekt ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Den Inhalt dieses Objekts bearbeiten.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation>Sie haben keine Berechtigung dieses Objekt zu bearbeiten.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Verschieben</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>An einen anden Ort verschieben.</translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation>Sie haben keine Berechtigung dieses Objekt an einen anderen Ort zu verschieben.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Dieses Objekt entfernen.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation>Sie haben keine Berechtigung dieses Objekt zu entfernen.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>&lt;%child_name&gt; bearbeiten.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Sie haben keine Berechtigung das Objekt &lt;%child_name&gt; zu bearbeiten.</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Alle Inhalte durchsuchen.</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Alle Inhalte</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Nur vom aktuellem Ort aus suchen.</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>Aktueller Ort</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>Am selben Ort</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Erweitert</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Erweiterte Suche.</translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation>Vom System abmelden.</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Abmelden</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/editor_view/article_list</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Inhaltsklasse &quot;Newsletterartikel&quot; nicht gefunden, filtern ist nicht möglich!</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Freigegeben</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/bounce</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>Die Validierung Ihrer Eingaben ist fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/edit_bounceaccount</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>Die Validierung Ihrer Eingaben ist fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/datatype_view</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list</name>
    <message>
        <source>Topics</source>
        <translation>Themen</translation>
    </message>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of articles in the current view</comment>
        <translation>%from - %to von %total_count</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Auswahl umkehren</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Zielgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Verfallsdatum</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gültigkeitsdatum</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Ersteller</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Aussendungen</translation>
    </message>
    <message>
        <source>Reads</source>
        <translation>Gelesen</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Erstellt</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Keine Artikel in dieser Kategorie</translation>
    </message>
    <message>
        <source>New article</source>
        <translation>Neuer Artikel</translation>
    </message>
    <message>
        <source>Create a new article.</source>
        <translation>Einen neuen Artikel erstellen.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Ausgewählte entfernen</translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation>Ausgewählte einträge entfernen.</translation>
    </message>
    <message>
        <source>Category name</source>
        <translation>Kategorie</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list_browse</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Inhaltsklasse &quot;Newsletterartikel&quot; nicht gefunden, filtern ist nicht möglich!</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Auswahl umkehren.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Keine Artikel in dieser Kategorie</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Zielgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Verfallsdatum</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gültigkeitsdatum</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Ersteller</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Aussendungen</translation>
    </message>
    <message>
        <source>Reads</source>
        <translation>Gelesen</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Erstellt</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_stats_box</name>
    <message>
        <source>Statistics</source>
        <translation>Statistiken</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_view</name>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Edit this article.</source>
        <translation>Diesen Artikel bearbeiten.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Dieses Objekt entfernen.</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Diesen Artikel an einen anden Ort verschieben.</translation>
    </message>
    <message>
        <source>Copy to</source>
        <translation>Kopieren nach</translation>
    </message>
    <message>
        <source>Copy this article to another location.</source>
        <translation>Diesen Artikel an einen anderen Ort kopieren.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>Copy this article to the same location.</source>
        <translation>Diesen Aritkel an einen anderen Ort kopieren.</translation>
    </message>
    <message>
        <source>Newsletter categories</source>
        <translation>Newsletter Kategorien</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Auswahl umkehren</translation>
    </message>
    <message>
        <source>New category</source>
        <translation>Neue Kategorie</translation>
    </message>
    <message>
        <source>Create a new category.</source>
        <translation>Neue Kategorie erstellen.</translation>
    </message>
    <message>
        <source>Apply filters to view.</source>
        <translation>Filter anwenden.</translation>
    </message>
    <message>
        <source>Reset filters for view.</source>
        <translation>Filter zurücksetzen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/category_list</name>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of categories in the current view</comment>
        <translation>%from - %to von %total_count</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/filter_box</name>
    <message>
        <source>Filter options</source>
        <translation>Filter optionen</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Target audience:</source>
        <translation>Zielgruppe:</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation>Sprache:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <source>From (Y/M/D):</source>
        <translation>Von (J/M/T):</translation>
    </message>
    <message>
        <source>To (Y/M/D):</source>
        <translation>Bis (J/M/T):</translation>
    </message>
    <message>
        <source>Apply filters</source>
        <translation>Filter anwenden</translation>
    </message>
    <message>
        <source>Reset filters</source>
        <translation>Filter zurücksetzen</translation>
    </message>
    <message>
        <source>Introducion date</source>
        <translation>Gültigkeitsdatum</translation>
    </message>
    <message>
        <source>Expire Date</source>
        <translation>Ablaufdatum</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/idea_list</name>
    <message>
        <source>Ideas</source>
        <translation>Ideen</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Auswahl umkehren</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Zielgruppe</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Verfallsdatum</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Gültigkeitsdatum</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Ersteller</translation>
    </message>
    <message>
        <source>Proposer</source>
        <translation>Ideengeber</translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation>Eingehend</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/eznewsletter_setup/edit_bounceaccount</name>
    <message>
        <source>Comma separated flags ( visit http://php.net/imap_open for more information )</source>
        <translation>Komma separierte Schalter ( besuchen Sie http://php.net/imap_open für mehr Informationen )</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_setup/bounce</name>
    <message>
        <source>Invert selection</source>
        <translation>Auswahl umkehren</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/bounce</name>
    <message>
        <source>Bounce settings</source>
        <translation>Bounceeinstellungen</translation>
    </message>
    <message>
        <source>Softbounce limit</source>
        <translation>Softbouncegrenze</translation>
    </message>
    <message>
        <source>The softbounce limit defines the amount of soft bounces, that will be allowed until sending to the subscriber will be suspended.</source>
        <translation>Die Softbouncegrenze definiert die Anzahl Softbounces ab der das senden an den Empfänger pausiert wird.</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Konten</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Kennung</translation>
    </message>
    <message>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation>Protokoll</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Verbindungsparameter</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Edit the &lt;%account_name&gt; account.</source>
        <translation>Das Konto &lt;%account_name&gt; bearbeiten.</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation>Ausgewählte löschen</translation>
    </message>
    <message>
        <source>Create account</source>
        <translation>Konto erstellen</translation>
    </message>
    <message>
        <source>Bounce account [%account]</source>
        <translation>Bouncekonto [%account]</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Hostname</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>New accountname</source>
        <translation>Neuer Kontoname</translation>
    </message>
    <message>
        <source>Password verification</source>
        <translation>Passwort verifikation</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/general</name>
    <message>
        <source>General setup</source>
        <translation>Allgemeine Einstellungen</translation>
    </message>
    <message>
        <source>Newsletter sendout</source>
        <translation>Sendeeinstellungen</translation>
    </message>
    <message>
        <source>Sendout transport method</source>
        <translation>Transportmethode Sendevorgang</translation>
    </message>
    <message>
        <source>Preview transport method</source>
        <translation>Transportmethode Vorschau</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/menu</name>
    <message>
        <source>Newsletter setup</source>
        <translation>Newslettersetup</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Bounce</source>
        <translation>Bounce</translation>
    </message>
    <message>
        <source>SMTP Cluster</source>
        <translation>SMTP Cluster</translation>
    </message>
    <message>
        <source>Email registration</source>
        <translation>E-Mail Registrierung</translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Newsletter article class not found, creating newsletter articles not possible!</source>
        <translation>Inhaltsklasse &quot;Newsletterartikel&quot; nicht gefunden, filtern ist nicht möglich!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder</name>
    <message>
        <source>Approved</source>
        <translation>Freigegeben</translation>
    </message>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Inhaltsklasse &quot;Newsletterartikel&quot; nicht gefunden, filtern ist nicht möglich!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup</name>
    <message>
        <source>eZ Newsletter setup</source>
        <translation>eZ Newsletter setup</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/bounce</name>
    <message>
        <source>You have to enter a valid limit for softbounces.</source>
        <translation>Sie müssen eine gültige Softbouncegrenze angeben.</translation>
    </message>
    <message>
        <source>You have to define an accountname.</source>
        <translation>Sie müssen einen Kontonamen definieren.</translation>
    </message>
    <message>
        <source>The passwords must be equal.</source>
        <translation>Die Passwörter müssen identisch sein.</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/general</name>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>File (for SMTP cluster)</source>
        <translation>Datei (Für SMTP Cluster)</translation>
    </message>
</context>
</TS>
