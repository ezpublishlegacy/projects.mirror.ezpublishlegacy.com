<?php
/*
[RegionalSettings]
TranslationExtensions[]=ezlabel
*/
?>
