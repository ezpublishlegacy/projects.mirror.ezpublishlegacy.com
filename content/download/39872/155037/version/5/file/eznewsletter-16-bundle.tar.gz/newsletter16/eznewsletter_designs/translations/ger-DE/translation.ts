<!DOCTYPE TS><TS>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout</name>
    <message>
        <source>Interested? Learn more ...</source>
        <translation>Interessiert? Erfahren Sie mehr ...</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Entschuldigung, der Artikel existiert nicht!</translation>
    </message>
    <message>
        <source>Topics</source>
        <translation>Themen</translation>
    </message>
    <message>
        <source>back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Upcoming Events</source>
        <translation>Kommende Termine</translation>
    </message>
    <message>
        <source>Legal Information</source>
        <translation>Impressum</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Upcoming events</source>
        <translation>Kommende Termine</translation>
    </message>
    <message>
        <source>Legal information</source>
        <translation>Impressum</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>Themen diese Woche</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>Themen</translation>
    </message>
    <message>
        <source>EVENTS THIS MONTH</source>
        <translation>Termine diesen Monat</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Guten Tag, wir haben Neuigkeiten für Sie. Besuchen Sie %url_to_newsletter um unseren neuen Newsletter zu lesen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite</name>
    <message>
        <source>back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Entschuldigung, der Artikel existiert nicht!</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Ganzen Artikel lesen ...</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Also today</source>
        <translation>Weitere Themen</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>Themen diese Woche</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>Themen</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Weiterlesen</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Guten Tag, wir haben Neuigkeiten für Sie. Besuchen Sie %url_to_newsletter um unseren neuen Newsletter zu lesen.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/node/view/newsletter</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Ganzen Artikel lesen ...</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout</name>
    <message>
        <source>Read more</source>
        <translation>Weiterlesen</translation>
    </message>
    <message>
        <source>Only</source>
        <translation>Nur</translation>
    </message>
    <message>
        <source>Buy this product now</source>
        <translation>Jetzt kaufen</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>ONLY</source>
        <translation>NUR</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profil</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout/sms</name>
    <message>
        <source>Hello, we have some products available which might interrest you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Guten Tag, wir einige neue Produkte die Sie interessieren könnten. Besuchen Sie %url_to_newsletter um unseren neuen Newsletter zu lesen.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Preis:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Ihr Preis:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Sie sparen:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Preis</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Benutzerkonto informationen</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>Benutzer ID</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
</context>
</TS>
