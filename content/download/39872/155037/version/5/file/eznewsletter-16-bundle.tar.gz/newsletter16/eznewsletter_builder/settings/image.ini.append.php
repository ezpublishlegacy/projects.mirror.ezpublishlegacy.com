<?php /* #?ini charset="iso-8859-1"?

[MIMETypeSettings]
Quality[]=image/jpeg;70

[AliasSettings]
AliasList[]=main_image
AliasList[]=image_small
AliasList[]=image_middle
AliasList[]=image_big

[main_image]
Filters[]
Filters[]=geometry/scaledownonly=130;100

[image_small]
Filters[]
Filters[]=geometry/scaledownonly=;55

[image_middle]
Filters[]
Filters[]=geometry/scaledownonly=130;100

[image_big]
Filters[]
Filters[]=geometry/scaledownonly=407;374

*/ ?>
