<?php /*
[SMTPClusterSettings]
PersistentConnection=enabled

[SMTPAccountSettings]
AccountList[]
AccountList[]=zap

[zap]
ServerName=zap.ez.no
ServerPort=25
LoginName=
Password=

[RoundRobinSettings]
PackageSize=500
MaximumRetry=2

*/ ?>