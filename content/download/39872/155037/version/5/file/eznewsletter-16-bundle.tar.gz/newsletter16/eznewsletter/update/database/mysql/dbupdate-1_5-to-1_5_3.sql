ALTER TABLE eznewsletter ADD recurrence_last_sent int(11);
ALTER TABLE `eznewsletter` ADD `recurrence_condition` VARCHAR( 255 ) NOT NULL;
