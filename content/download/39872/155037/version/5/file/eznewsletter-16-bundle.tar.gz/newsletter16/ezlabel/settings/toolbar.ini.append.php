<?php /*

[Tool]
AvailableToolArray[]=ezlabel

#[Tool_label]

*/ ?>
