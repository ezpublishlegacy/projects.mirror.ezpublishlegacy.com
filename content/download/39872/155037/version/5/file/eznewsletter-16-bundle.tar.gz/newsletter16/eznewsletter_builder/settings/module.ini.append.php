<?php /*

[ModuleSettings] 

ModuleList[]=newsletter_setup
ExtensionRepositories[]=eznewsletter_builder

*/ ?>
