<?php
//
// Created on:
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file bounce.php
*/

/*
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter_builder/classes/ezbounceaccounts.php' );
*/
$Module      = $Params['Module'];
$accountName = $Params['account'];
$http        = eZHTTPTool::instance();
$warnings    = array();

$bounceAccounts = new eZBounceAccounts();

if( ( $http->hasPostVariable( 'StoreGeneral' )
    && $http->hasPostVariable( 'bouncecount' ) )
    && ( !is_numeric( $http->postVariable( 'bouncecount' ) )
      || 0 > ( int )$http->postVariable( 'bouncecount' ) ) )
{
    $warnings[] = ezi18n( 'eznewsletter_builder/newsletter_setup/bounce', 'You have to enter a valid limit for softbounces.' );
}

if( $http->hasPostVariable( 'StoreGeneral' )
    && 0 === count( $warnings ) )
{
    $bounceAccounts->iniInstance->setVariable( 'BounceSettings', 'BounceCount', ( int )$http->postVariable( 'bouncecount' ) );
    $bounceAccounts->store();
}

if( $http->hasPostVariable( 'DeleteAccounts' )
    && $http->hasPostVariable( 'DeleteArray' ) )
{
    // Delete marked accounts
    $deleteAccounts = $http->postVariable( 'DeleteArray' );
    foreach( $deleteAccounts as $deleteAccount )
    {
        $bounceAccounts->removeAccount( $deleteAccount );
    }
}
if( $http->hasPostVariable( 'CreateAccount')
    && $http->hasPostVariable( 'NewAccountName' )
    && 0 < strlen( $http->postVariable( 'NewAccountName' ) ) )
{
    $Module->redirect( 'newsletter_setup', 'bounce',
        array(
            'edit',
            $http->postVariable( 'NewAccountName' )
        )
    );
}
elseif( $http->hasPostVariable( 'CreateAccount' )
        && $http->hasPostVariable( 'NewAccountName' )
        && 0 >= strlen( $http->postVariable( 'NewAccountName' ) )  )
{
    $warnings[] = ezi18n( 'eznewsletter_builder/newsletter_setup/bounce', 'You have to define an accountname.' );

}

$tpl = eZNewsletterTemplateWrapper::templateInit();

if( isset( $Params['action'] )
    && 'edit' === $Params['action'] )
{
    //Edit action
    if( $http->hasPostVariable( 'Discard' ) )
    {
        $Module->redirect( 'newsletter_setup', 'bounce' );
    }

    if( $http->postVariable( 'Password' ) !== $http->postVariable(  'Password2' ) )
    {
        $warnings[] = ezi18n( 'eznewsletter_builder/newsletter_setup/bounce', 'The passwords must be equal.' );
    }

    if( $http->hasPostVariable( 'StoreAccount' )
        && 0 === count( $warnings ) )
    {
        // Store new account settings
        $accountData = array(
            "ServerName" => $http->postVariable( 'ServerName' ),
            "ServerPort" => $http->postVariable( 'ServerPort' ),
            "LoginName" => $http->postVariable( 'LoginName' ),
            "Password" => $http->postVariable( 'Password' ),
            "Protocol" => $http->postVariable( 'Protocol' ),
            "Flags" => explode( ',', $http->postVariable( 'Flags' ) )
        );
        $bounceAccounts->storeAccount( $account, $accountData );
        $Module->redirect( 'newsletter_setup', 'bounce' );
    }

    $editAccount = $bounceAccounts->fetch( $accountName );
    $editAccount['name'] = $accountName;
    $tpl->setVariable( 'account', $editAccount );
    $tpl->setVariable( 'warnings', $warnings );
    $tpl->setVariable( 'protocols', array( 'imap', 'pop3' ) );
    $template = $tpl->fetch(  "design:newsletter_setup/edit_bounceaccount.tpl" );
}
else
{
    //Listing
    $accountList = $bounceAccounts->fetchList();
    $bounceINI = $bounceAccounts->iniInstance;
    $bounceCount = $bounceINI->variable( 'BounceSettings', 'BounceCount' );
    $tpl->setVariable( 'account_list', $accountList );
    $tpl->setVariable( 'warnings', $warnings );
    $tpl->setVariable( 'bounce_count', $bounceCount );
    $template = $tpl->fetch(  "design:newsletter_setup/bounce.tpl" );
}

$Result = array();
$Result['left_menu'] = 'design:newsletter_setup/menu.tpl';
$Result['content'] = $template;
$Result['path'] = array(
    array( 
        'url' => false,
        'text' => ezi18n( 'eznewsletter_builder/newsletter_setup', 'eZ Newsletter setup' )
    )
);

?>
