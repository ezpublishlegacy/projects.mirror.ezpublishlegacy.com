<?php
/*
[RegionalSettings]
TranslationExtensions[]=eznewsletter_builder
*/
?>
