<?php /*

[ModuleSettings]
ModuleList[]=ezapprove2
ExtensionRepositories[]=ezapprove2

*/ ?>
