--
-- Table structure for table `ezmailimport`
--

DROP TABLE IF EXISTS `ezmailimport`;
CREATE TABLE `ezmailimport` (
  `id` int(11) NOT NULL auto_increment,
  `mail_id` int(11) NOT NULL default '0',
  `attachment_filename` text,
  `original_filename` text,
  PRIMARY KEY  (`id`)
);
