<?php
//
// Created on:
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file general.php
*/

/*
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
*/
$Module = $Params['Module'];
$http   = eZHTTPTool::instance();

$availableTransports = array(
    'SMTP' => array(
        'name' => ezi18n( 'eznewsletter_builder/newsletter_setup/general', 'SMTP' ),
        'value' => 'SMTP'
    ),
    'Sendmail' => array(
        'name' => ezi18n( 'eznewsletter_builder/newsletter_setup/general', 'Sendmail'),
        'value' => 'Sendmail'
    ),
    'File' => array(
        'name' => ezi18n( 'eznewsletter_builder/newsletter_setup/general', 'File (for SMTP cluster)'),
        'value' => 'File'
    )
);

$eZNewsletterINI = eZINI::instance( 'eznewsletter.ini', 'settings', null, null, true );

$currentSiteAccess = $GLOBALS['eZCurrentAccess']['name']; // Retrieve current siteaccess

if( $http->hasPostVariable( 'StoreGeneral' ) )
{
    if( $http->hasPostVariable( 'eznewsletter_transport' )
        && isset( $availableTransports[$http->postVariable( 'eznewsletter_transport' )] ) )
    {
        $newTransport = $availableTransports[$http->postVariable( 'eznewsletter_transport' )]['value'];
        $eZNewsletterINI->setVariable( 'NewsletterSendout', 'Transport', $newTransport );
    }
    if( $http->hasPostVariable( 'eznewsletter_preview_transport' )
        && isset( $availableTransports[$http->postVariable( 'eznewsletter_preview_transport' )] ) )
    {
        $newPreviewTransport = $availableTransports[$http->postVariable( 'eznewsletter_preview_transport' )]['value'];
        $eZNewsletterINI->setVariable( 'NewsletterSendout', 'PreviewTransport', $newPreviewTransport );
    }
    //$eZNewsletterINI->save( '/siteaccess/' . $currentSiteAccess . '/eznewsletter.ini', false, "override" );
    $eZNewsletterINI->save( false , false, "append" );
}

$currentTransport = $eZNewsletterINI->variable( 'NewsletterSendout', 'Transport' );
$currentPreviewTransport = $eZNewsletterINI->variable( 'NewsletterSendout', 'PreviewTransport' );

$tpl = eZNewsletterTemplateWrapper::templateInit();
$tpl->setVariable( 'available_transports', $availableTransports );
$tpl->setVariable( 'eznewsletter_transport', $currentTransport );
$tpl->setVariable( 'eznewsletter_preview_transport', $currentPreviewTransport );

$Result = array();
$Result['left_menu'] = 'design:newsletter_setup/menu.tpl';
$Result['content'] = $tpl->fetch( "design:newsletter_setup/general.tpl" );
$Result['path'] = array(
    array( 
        'url' => false,
        'text' => ezi18n( 'eznewsletter_builder/newsletter_setup', 'eZ Newsletter setup' )

	) 
);

?>

