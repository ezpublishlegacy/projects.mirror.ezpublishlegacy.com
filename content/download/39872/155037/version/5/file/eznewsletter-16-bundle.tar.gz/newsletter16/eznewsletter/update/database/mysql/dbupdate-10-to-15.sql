-- Renaming of tablenames to match with the new naming
RENAME TABLE `ezxnewsletter`  TO `eznewsletter`;
RENAME TABLE `ezxnewslettertype`  TO `eznewslettertype`;
RENAME TABLE `ezxrobinsonlist`  TO `ezrobinsonlist`;
RENAME TABLE `ezxsendnewsletteritem`  TO `ezsendnewsletteritem`;
RENAME TABLE `ezxsubscription`  TO `ezsubscription`;
RENAME TABLE `ezxsubscriptionuserdata`  TO `ezsubscriptionuserdata`;
RENAME TABLE `ezxsubscription_group`  TO `ezsubscription_group`;
RENAME TABLE `ezxsubscription_list`  TO `ezsubscription_list`;
RENAME TABLE `ezx_bouncedata`  TO `ez_bouncedata`;
RENAME TABLE `ezx_newsletter_subscription`  TO `ez_newsletter_subscription`;
