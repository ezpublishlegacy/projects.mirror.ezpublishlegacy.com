<? /*

[ModuleSettings]
ModuleList[]=mailimport
ExtensionRepositories[]=ezmailimport

*/ ?>

