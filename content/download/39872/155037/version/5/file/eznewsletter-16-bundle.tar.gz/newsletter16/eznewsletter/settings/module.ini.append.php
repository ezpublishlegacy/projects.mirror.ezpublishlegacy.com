<? /*

[ModuleSettings]
ModuleList[]=newsletter
ExtensionRepositories[]=eznewsletter

*/ ?>
