<?php /*

[HandlerSettings]
# A list of extensions which have collaboration code
# It's common to create a settings/collaboration.ini.append file
# in your extension and add the extension name to automatically
# get code from the extension when it's turned on.
Extensions[]=ezapprove2
Repositories[]=kernel/classes/collaborationhandlers
Active[]=ezapprove2

*/ ?>
