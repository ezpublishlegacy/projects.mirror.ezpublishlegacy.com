<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=ezlabel

[StylesheetSettings]
CSSFileList[]=ezlabel.css

*/ ?>
