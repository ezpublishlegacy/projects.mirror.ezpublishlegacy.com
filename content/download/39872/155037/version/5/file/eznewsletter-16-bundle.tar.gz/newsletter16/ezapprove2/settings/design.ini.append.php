<?php /*

[ExtensionSettings]
DesignExtensions[]=ezapprove2

*/ ?>
