UPDATE ezsite_data SET value = '1.6.0beta' WHERE name = 'eznewsletter-version';
UPDATE ezsite_data SET value = '0' WHERE name = 'eznewsletter-release';