<?php

$Module = array( 'name' => 'Eurofxref' );

$ViewList = array();
$ViewList['overview'] = array( 
    'script' => 'overview.php',
    'params' => array ( ) );

?>