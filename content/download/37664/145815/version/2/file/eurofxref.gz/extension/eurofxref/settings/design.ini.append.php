[ExtensionSettings]
DesignExtensions[]=eurofxref
