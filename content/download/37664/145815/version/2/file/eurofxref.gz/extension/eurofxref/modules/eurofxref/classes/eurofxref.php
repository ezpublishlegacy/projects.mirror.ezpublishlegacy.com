<?php

include_once( 'lib/ezxml/classes/ezxml.php' );

class EuroFxRef
{
    // static
    function fetchFX()
    {
        $result = array( 'date' => false, 'fx' => array() );

        $fxXML = file_get_contents("http://www.ecb.int/stats/eurofxref/eurofxref-daily.xml");

        $xml = new eZXML();
        $dom =& $xml->domTree( $fxXML );
        $fxArray =& $dom->elementsByName( 'Cube' );
        foreach ( $fxArray as $fxRate )
	    {
            if ( !$fxRate->hasAttributes() )
                continue;
            $currency = $fxRate->attributeValue( 'currency' );
            if ( $currency === false )
            {
                if ( $fxRate->attributeValue( 'time' ) != false )
                {
                    $datePieces = explode( '-', $fxRate->attributeValue( 'time' ) );
                    $result['date'] = mktime( 0, 0, 0, $datePieces[1], $datePieces[2], $datePieces[0] );
                }
            }
            else
            {
                $value = $fxRate->attributeValue( 'rate' );
                $result['fx'][$currency] = $value;
            }
        }
        return array( 'result' => $result );
    }
}

?>