[ModuleSettings]
ExtensionRepositories[]=eurofxref
