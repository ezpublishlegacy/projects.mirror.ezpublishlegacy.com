<?php

$FunctionList = array();

$FunctionList['fxref'] = array( 'name' => 'fxref',
                                'call_method' => array( 'include_file' => 'extension/eurofxref/modules/eurofxref/classes/eurofxref.php',
                                                        'class' => 'EuroFxRef',
                                                        'method' => 'fetchFX' ),
                                'parameter_type' => 'standard',
                                'parameters' => array() );

?>
