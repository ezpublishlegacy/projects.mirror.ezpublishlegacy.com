<?php

include_once( 'kernel/common/template.php' );

$tpl =& templateInit();

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:eurofxref/overview.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Euro Exchange Rates' ) );

?>
