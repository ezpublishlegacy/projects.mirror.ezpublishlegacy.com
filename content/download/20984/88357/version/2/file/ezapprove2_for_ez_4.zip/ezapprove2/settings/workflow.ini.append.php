<?php /*

[EventSettings]
ExtensionDirectories[]=ezapprove2
AvailableEventTypes[]=event_ezapprove2

*/ ?>
