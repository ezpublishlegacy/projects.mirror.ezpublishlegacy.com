<?php /*

[ApproveFilter]
ExtensionName=ezapprove2
ClassName=eZApproveExtendedFilter
MethodName=createSqlParts
FileName=classes/ezapproveextendedfilter.php

*/ ?>
