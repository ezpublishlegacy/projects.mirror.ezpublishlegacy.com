<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezapprove2
ModuleList[]=ezapprove2
*/ ?>
