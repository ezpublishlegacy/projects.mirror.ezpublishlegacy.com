<?php /*

[ApproveSettings]
# Append custom user classes here.
UserClassIdentifierList[]
UserClassIdentifierList[]=user
UserClassIdentifierList[]=ezdms_staff

# Append custom user group classes here.
UserGroupClassIdentifierList[]
UserGroupClassIdentifierList[]=user_group

# Set if object locking, and node creation should on draft creation
# should be enabled. ( It's recommended not to touch this setting )
ObjectLockOnEdit=false
NodeCreationOnDraft=false

*/ ?>
