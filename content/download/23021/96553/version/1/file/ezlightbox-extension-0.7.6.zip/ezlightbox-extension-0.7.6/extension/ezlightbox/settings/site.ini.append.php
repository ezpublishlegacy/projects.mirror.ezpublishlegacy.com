<?php /*

[RegionalSettings]
TranslationExtensions[]=ezlightbox

*/ ?>
