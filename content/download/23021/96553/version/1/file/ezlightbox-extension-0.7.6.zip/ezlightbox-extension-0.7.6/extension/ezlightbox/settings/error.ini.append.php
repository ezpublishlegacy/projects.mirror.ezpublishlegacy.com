<?php /*

[ErrorSettings-lightbox]
# ErrorHandler[20]=displayerror
ErrorHandler[]
RedirectURL[]
RerunURL[]
EmbedURL[]
HTTPError[2]=404
HTTPError[3]=404
# 301 = moved permanently
HTTPError[4]=301
HTTPError[20]=404
HTTPError[21]=404
HTTPError[22]=404
HTTPName=Not Found

*/ ?>