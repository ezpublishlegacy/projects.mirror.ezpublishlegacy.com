<?php /*

[ActionSettings]
ExtensionDirectories[]=ezlightbox

[DataTypeSettings]
ExtensionDirectories[]=ezlightbox
AvailableDataTypes[]=ezlightboxwrapper

*/ ?>
