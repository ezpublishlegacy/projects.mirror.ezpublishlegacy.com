<?
// Operator autoloading
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
 array( 'script' => 'extension/smileCookie/autoloads/cookieoperators.php',
        'class' => 'CookieOperators',
        'operator_names' => array( 'getCookie' ) 
      );

?>