<?php
//
// Created on: <09-Dec-2003 14:09:23 gl>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

// Subscribe a user to the newsletter
// Confirmation via email is optional and configurable


include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( 'lib/ezutils/classes/ezextension.php' );
ext_activate( 'newsletter', 'thirdparty/classes/htmlMimeMail.php' );

include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );


$http =& eZHTTPTool::instance();
$db =& eZDB::instance();

$module =& $Params['Module'];

$newsletterINI =& eZINI::instance( 'newsletter.ini' );
$requireUserLogin = false;
if ( $newsletterINI->variable( 'GeneralSettings', 'RequireUserLogin' ) == 'true' )
    $requireUserLogin = true;
$requireUnsubscriptionConfirmation = false;
if ( $newsletterINI->variable( 'GeneralSettings', 'RequireUnsubscriptionConfirmation' ) == 'true' )
    $requireUnsubscriptionConfirmation = true;

$user =& eZUser::currentUser();
$userID = $user->attribute( 'contentobject_id' );
$userObject = $user->attribute( 'contentobject' );
$userName = $userObject->name();

// We require login, show error message
if ( $requireUserLogin && !$user->isLoggedIn() )
{
    $tpl =& templateInit();
    $Result = array();
    $Result['content'] =& $tpl->fetch( 'design:error/kernel/1.tpl' );
}
// We have just clicked the unsubscribe button
else if ( $module->isCurrentAction( 'UnsubscribeAction' ) )
{
    $newsletter = $http->variable( 'Newsletter' );
    $newsletterName = $http->variable( 'NewsletterName' );
    $email = $http->variable( 'Email' );

    // Validate email
    $ezmail = new eZMail();
    if ( $ezmail->validate( $email ) )  // Valid email address
    {
        if ( $requireUserLogin )
            $userSQL = "user_id = '$userID'";
        else
            $userSQL = "email = '$email'";

        // Generate time hash, add db entry
        $hash = md5( time() );
        $rows =& $db->arrayQuery( 'SELECT * FROM eznewsletter_subscription ' .
                                  "WHERE $userSQL AND newsletter = '$newsletter'" );

        if ( count( $rows ) > 0 ) // There is an existing entry
        {
            if ( $rows[0]['is_active'] == 0 )  // Not subscribed
            {
                $not_subscribed = true;
            }
            else  // Subscribed
            {
                if ( $requireUnsubscriptionConfirmation )
                {
                    $db->query( 'UPDATE eznewsletter_subscription ' .
                                "SET hash = '$hash' WHERE $userSQL AND newsletter = '$newsletter'" );
                }
                else
                {
                    $db->query( 'UPDATE eznewsletter_subscription ' .
                                "SET hash = '', is_active = 0 WHERE $userSQL AND newsletter = '$newsletter'" );
                }
            }
        }
        else
        {
            $not_subscribed = true;
        }

        if ( $not_subscribed )
        {
            // Redirect to 'not subscribed' page
            $tpl =& templateInit();
            $tpl->setVariable( 'action', 'not_subscribed' );
            $tpl->setVariable( 'show_form', false );
            $tpl->setVariable( 'newsletter', $newsletter );
            $tpl->setVariable( 'newsletter_name', $newsletterName );
            $tpl->setVariable( 'email', $email );

            $Result = array();
            $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
            $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                            'url' => false ),
                                     array( 'text' => ezi18n( 'newsletter', 'Confirmation required' ),
                                            'url' => false ) );
            return;
        }

        if ( $requireUnsubscriptionConfirmation )
        {
            // Send confirmation email
            $mailtpl =& templateInit();
            $mailtpl->setVariable( 'action', 'unsubscribe' );
            $mailtpl->setVariable( 'newsletter', $newsletter );
            $mailtpl->setVariable( 'newsletter_name', $newsletterName );
            $mailtpl->setVariable( 'email', $email );
            $mailtpl->setVariable( 'hash', $hash );
            $mailtpl->setVariable( 'user_name', $userName );

            $html = $mailtpl->fetch( 'design:newsletter/confirmation_mail_html.tpl' );
            $plain = $mailtpl->fetch( 'design:newsletter/confirmation_mail_plain.tpl' );
            $subject = $mailtpl->variable( 'subject' );

            $htmlmimemail = new htmlMimeMail();
            $htmlmimemail->setHtmlEncoding( 'quoted-printable' );
            $htmlmimemail->setTextEncoding( '7bit' );

            $ini =& eZINI::instance();
            $notificationINI =& eZINI::instance( 'notification.ini' );
            $emailSender = $notificationINI->variable( 'MailSettings', 'EmailSender' );
            if ( !$emailSender )
                $emailSender = $ini->variable( 'MailSettings', 'EmailSender' );
            if ( !$emailSender )
                $emailSender = $ini->variable( 'MailSettings', 'AdminEmail' );

            $htmlmimemail->setHtml( $html, $plain );
            $htmlmimemail->setReturnPath( $emailSender );
            $htmlmimemail->setSubject( $subject );
            $htmlmimemail->setHeader( 'X-Mailer', 'HTML Mime mail class (http://www.phpguru.org)' );
            $result = $htmlmimemail->send( array( $email ) );

            // Redirect to wait for mail page
            $tpl =& templateInit();
            $tpl->setVariable( 'action', 'wait_for_email' );
            $tpl->setVariable( 'show_form', false );
            $tpl->setVariable( 'newsletter', $newsletter );
            $tpl->setVariable( 'newsletter_name', $newsletterName );

            $Result = array();
            $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
            $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                            'url' => false ),
                                     array( 'text' => ezi18n( 'newsletter', 'Confirmation required' ),
                                            'url' => false ) );
        }
        else  // Show unsubscription confirmed page
        {
            $tpl =& templateInit();
            $tpl->setVariable( 'action', 'confirmed' );
            $tpl->setVariable( 'show_form', false );
            $tpl->setVariable( 'newsletter', $newsletter );
            $tpl->setVariable( 'newsletter_name', $newsletterName );
            $tpl->setVariable( 'email', $email );
            $tpl->setVariable( 'user_name', $userName );
            $tpl->setVariable( 'user_id', $userID );

            $Result = array();
            $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
            $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                            'url' => false ),
                                     array( 'text' => ezi18n( 'newsletter', 'Confirmation' ),
                                            'url' => false ) );
        }
    }
    else  // Bad email address
    {
        $tpl =& templateInit();
        $tpl->setVariable( 'newsletter', $newsletter );
        $tpl->setVariable( 'newsletter_name', $newsletterName );
        $tpl->setVariable( 'email', $email );
        $tpl->setVariable( 'action', 'bad_email' );
        $tpl->setVariable( 'show_form', true );

        $Result = array();
        $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
        $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                        'url' => false ),
                                 array( 'text' => ezi18n( 'newsletter', 'Unsubscribe' ),
                                        'url' => false ) );
    }
}
// We have just clicked the mail confirmation link
else if ( $module->isCurrentAction( 'ConfirmUnsubscriptionAction' ) )
{
    $newsletter = $Params['Newsletter'];
    $hash = $Params['Hash'];
    $email = false;
    if ( !$requireUserLogin )
    {
        $email = $Params['Email'];
    }
    // if current user is logged in, fetch email
    if ( $user->isLoggedIn() )
    {
        $email = $user->attribute( 'email' );
    }

    $newsletterName = $newsletterINI->variable( $newsletter, 'Name' );

    if ( $requireUserLogin )
        $userSQL = "user_id = '$userID'";
    else
        $userSQL = "email = '$email'";
    $rows =& $db->arrayQuery( 'SELECT COUNT(*) FROM eznewsletter_subscription ' .
                              "WHERE $userSQL AND newsletter = '$newsletter' AND hash = '$hash'" );

    $tpl =& templateInit();
    if ( $rows[0]['COUNT(*)'] > 0 )  // valid email/hash
    {
        $db->query( "UPDATE eznewsletter_subscription SET hash = '', is_active = 0 " .
                    "WHERE $userSQL AND newsletter = '$newsletter'" );
        $tpl->setVariable( 'action', 'confirmed' );
    }
    else  // invalid email/hash
    {
        $tpl->setVariable( 'action', 'unconfirmed' );
    }
    $tpl->setVariable( 'show_form', false );
    $tpl->setVariable( 'newsletter', $newsletter );
    $tpl->setVariable( 'newsletter_name', $newsletterName );
    $tpl->setVariable( 'email', $email );
    $tpl->setVariable( 'user_name', $userName );
    $tpl->setVariable( 'user_id', $userID );

    $Result = array();
    $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
    $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                    'url' => false ),
                             array( 'text' => ezi18n( 'newsletter', 'Confirmation' ),
                                    'url' => false ) );
}
// We have just clicked the cancel button
else if ( $module->isCurrentAction( 'CancelAction' ) )
{
    $module->redirectToView( 'list' );
}
// We have requested the unsubscription form
else
{
    $newsletter = $Params['Newsletter'];
    $email = false;
    $editEmail = false;
    if ( !$requireUserLogin )
    {
        $editEmail = true;
        $email = $Params['Email'];
    }
    // if current user is logged in, fetch email
    if ( $user->isLoggedIn() )
    {
        $email = $user->attribute( 'email' );
    }

    $newsletterName = $newsletterINI->variable( $newsletter, 'Name' );

    $tpl =& templateInit();
    $tpl->setVariable( 'newsletter', $newsletter );
    $tpl->setVariable( 'newsletter_name', $newsletterName );
    $tpl->setVariable( 'email', $email );
    $tpl->setVariable( 'action', false );
    $tpl->setVariable( 'show_form', true );
    $tpl->setVariable( 'edit_email', $editEmail );

    $Result = array();
    $Result['content'] =& $tpl->fetch( 'design:newsletter/unsubscribe.tpl' );
    $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                    'url' => false ),
                             array( 'text' => ezi18n( 'newsletter', 'Unsubscribe' ),
                                    'url' => false ) );
}

?>
