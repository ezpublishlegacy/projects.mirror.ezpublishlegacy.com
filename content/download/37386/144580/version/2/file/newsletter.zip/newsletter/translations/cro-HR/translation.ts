<!DOCTYPE TS><TS>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Nema relacije</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Cijena:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Vaša cijena:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Vaša ušteda:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Cijena</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Informacije o korisničkom računu</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID korisnika</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Prijava</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
</context>
<context>
    <name>newsletter</name>
    <message>
        <source>Confirmation required</source>
        <translation>Potrebna je potvrda</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Prijavi se</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Potvrda</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Odjavi se</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your subscription.</source>
        <translation>Uskoro ćete dobiti email sa linkom za potvrdu. Molimo kliknite na link kako bi potvrdili vašu prijavu.</translation>
    </message>
    <message>
        <source>Your email address is not valid</source>
        <translation>Vaš email nije ispravan</translation>
    </message>
    <message>
        <source>The address you have entered is not a valid email address. Please enter a valid address.</source>
        <translation>Unešena email adresa nije u valjanom formatu. Molimo unesite ispravnu adresu.</translation>
    </message>
    <message>
        <source>Subscription confirmed</source>
        <translation>Potvrdili ste prijavu</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed</source>
        <translation>Vašu prijavu nije moguće potvrditi</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Vašu prijavu nije moguće potvrditi, vjerojatno zbog krive URL adrese. Provjerite je li unešena URL adresa promjenjena.</translation>
    </message>
    <message>
        <source>Already subscribed</source>
        <translation>Već ste prijavljeni</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Vaša email adresa</translation>
    </message>
    <message>
        <source>Your preferred language</source>
        <translation>Željeni jezik</translation>
    </message>
    <message>
        <source>Unsubscribe from the %1 newsletter</source>
        <translation>Odjava sa %1 newslettera</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your unsubscription.</source>
        <translation>Uskoro ćete dobiti email sa linkom za potvrdu. Molimo kliknite na link kako bi potvrdili vašu odjavu.</translation>
    </message>
    <message>
        <source>Unsubscription confirmed</source>
        <translation>Potvrdili ste odjavu</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed</source>
        <translation>Vašu odjavu nije moguće potvrditi</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Vašu odjavu nije moguće potvrditi, vjerojatno zbog krive URL adrese. Provjerite je li unešena URL adresa promjenjena.</translation>
    </message>
    <message>
        <source>Not subscribed</source>
        <translation>Niste prijavljeni</translation>
    </message>
    <message>
        <source>Newsletter list</source>
        <translation>Lista newslettera</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stanje</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Akcija</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Pošalji</translation>
    </message>
    <message>
        <source>Subscribed</source>
        <translation>Prijavljeni ste</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>U tijeku</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Send now</source>
        <translation>Pošalji sad</translation>
    </message>
    <message>
        <source>Send test now</source>
        <translation>Pošalji test</translation>
    </message>
    <message>
        <source>There are no available newsletters</source>
        <translation>Nema dostupnih newslettera</translation>
    </message>
    <message>
        <source>Subscribe to the &apos;%1&apos; newsletter</source>
        <translation>Prijavi se na &apos;%1&apos; newsletter</translation>
    </message>
    <message>
        <source>Back to the newsletter list</source>
        <translation>Povratak na listu newslettera</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully subscribed to the %2 newsletter. This will be sent to your email address &apos;%3&apos;, make sure that it is valid.</source>
        <translation>Poštovani %1, uspješno ste se prijavili na newsletter %2. Ova poruka je poslana na vašu email adresu &apos;%3&apos;, kako bi utvrdili njezinu ispravnost.</translation>
    </message>
    <message>
        <source>If necessary, you can %1change your e-mail address.%2</source>
        <translation>Ukoliko je potrebno, možete %1promijeniti vašu email adresu.%2</translation>
    </message>
    <message>
        <source>To the newsletter list</source>
        <translation>Povratak na listu newslettera</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is already subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>Email adresa &apos;%1&apos; je već prijavljena na newsletter &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully unsubscribed to the %2 newsletter.</source>
        <translation>Poštovani %1, uspješno ste se odjavili aa newslettera %2.</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is not subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>Email adresa &apos;%1&apos; nije prijavljena na newsletter &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
</context>
<context>
    <name>subscription</name>
    <message>
        <source>Sent at</source>
        <translation>Pošalji na</translation>
    </message>
    <message>
        <source>Click here to unsubscribe</source>
        <translation>Kliknite ovdje za odjavu</translation>
    </message>
    <message>
        <source>Confirmation required</source>
        <translation>Potrebna potvrda</translation>
    </message>
    <message>
        <source>Hi %1, you have requested to be subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>Poštovani %1, zatražili ste prijavu na newsletter &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Click the following link to confirm your subscription:</source>
        <translation>Kliknite na sljedeći link kako bi potvrdili vašu prijavu:</translation>
    </message>
    <message>
        <source>Confirm subscription</source>
        <translation>Potvrdite prijavu</translation>
    </message>
    <message>
        <source>You have requested to be unsubscribed from the newsletter &apos;%1&apos;.</source>
        <translation>Zatražili ste odjavu sa newsettera &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Click the following link to confirm your unsubscription:</source>
        <translation>Kliknite na sljedeći link kako bi potvrdili odjavu:</translation>
    </message>
    <message>
        <source>Confirm unsubscription</source>
        <translation>Potvrda odjave</translation>
    </message>
</context>
</TS>
