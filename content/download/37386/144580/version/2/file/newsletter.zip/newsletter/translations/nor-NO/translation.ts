<!DOCTYPE TS><TS>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Ingen relasjon</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Pris:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Din pris:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Du sparer:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Pris</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Informasjon om brukerkonto</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>Bruker-ID</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
</context>
<context>
    <name>newsletter</name>
    <message>
        <source>Confirmation required</source>
        <translation>Bekreftelse</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Påmelding</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Bekreftelse</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Avmelding</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your subscription.</source>
        <translation>Du vil snart få en e-post med en lenke for bekreftelse. Klikk denne lenken for å bekrefte påmeldingen din.</translation>
    </message>
    <message>
        <source>Your email address is not valid</source>
        <translation>E-postadressen er ugyldig</translation>
    </message>
    <message>
        <source>The address you have entered is not a valid email address. Please enter a valid address.</source>
        <translation>Adressen du har skrevet inn er ugyldig. Vennligst oppgi en gyldig adresse.</translation>
    </message>
    <message>
        <source>Subscription confirmed</source>
        <translation>Påmelding bekreftet</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed</source>
        <translation>Påmeldingen din kunne ikke bekreftes</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Påmeldingen din kunne ikke bekreftes, kanskje på grunn av en feil i lenken. Kontroller at du ikke endret lenken.</translation>
    </message>
    <message>
        <source>Already subscribed</source>
        <translation>Allerede påmeldt</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Din e-postadresse</translation>
    </message>
    <message>
        <source>Your preferred language</source>
        <translation>Foretrukket språk</translation>
    </message>
    <message>
        <source>Unsubscribe from the %1 newsletter</source>
        <translation>Avmelding fra nyhetsbrevet på %1</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your unsubscription.</source>
        <translation>Du vil snart få en e-post med en lenke for bekreftelse. Klikk denne lenken for å bekrefte avmeldingen din.</translation>
    </message>
    <message>
        <source>Unsubscription confirmed</source>
        <translation>Avmelding bekreftet</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed</source>
        <translation>Avmeldingen din kunne ikke bekreftes</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Avmeldingen din kunne ikke bekreftes, kanskje på grunn av en feil i lenken. Kontroller at du ikke endret lenken.</translation>
    </message>
    <message>
        <source>Not subscribed</source>
        <translation>Ikke påmeldt</translation>
    </message>
    <message>
        <source>Newsletter list</source>
        <translation>Liste over nyhetsbrev</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Nyhetsbrev</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Handling</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Send</translation>
    </message>
    <message>
        <source>Subscribed</source>
        <translation>Påmeldt</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Under behandling</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Send now</source>
        <translation>Send nå</translation>
    </message>
    <message>
        <source>Send test now</source>
        <translation>Send test nå</translation>
    </message>
    <message>
        <source>There are no available newsletters</source>
        <translation>Det er ingen tilgjengelige nyhetsbrev</translation>
    </message>
    <message>
        <source>Subscribe to the &apos;%1&apos; newsletter</source>
        <translation>Påmelding til nyhetsbrevet &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Back to the newsletter list</source>
        <translation>Tilbake til listen over nyhetsbrev</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully subscribed to the %2 newsletter. This will be sent to your email address &apos;%3&apos;, make sure that it is valid.</source>
        <translation>Hei %1, du har blitt påmeldt til nyhetsbrevet %2. Det vil bli sendt til din e-postadresse &apos;%3&apos;, kontroller at adressen er riktig.</translation>
    </message>
    <message>
        <source>If necessary, you can %1change your e-mail address.%2</source>
        <translation>Hvis nødvendig kan du %1endre e-postadressen din.%2</translation>
    </message>
    <message>
        <source>To the newsletter list</source>
        <translation>Til listen over nyhetsbrev</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is already subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>E-postadressen &apos;%1&apos; er allerede påmeldt til nyhetsbrevet &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully unsubscribed to the %2 newsletter.</source>
        <translation>Hei %1, du har blitt påmeldt til nyhetsbrevet %2.</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is not subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>E-postadressen &apos;%1&apos; er ikke påmeldt til nyhetsbrevet &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>subscription</name>
    <message>
        <source>Sent at</source>
        <translation>Sendt</translation>
    </message>
    <message>
        <source>Click here to unsubscribe</source>
        <translation>Klikk her for å melde deg av nyhetsbrevet</translation>
    </message>
    <message>
        <source>Confirmation required</source>
        <translation>Bekreftelse er påkrevd</translation>
    </message>
    <message>
        <source>Hi %1, you have requested to be subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>Hei %1, du har bedt om å bli påmeldt til nyhetsbrevet &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Click the following link to confirm your subscription:</source>
        <translation>Klikk denne lenken for å bekrefte påmeldingen din:</translation>
    </message>
    <message>
        <source>Confirm subscription</source>
        <translation>Bekreft påmelding</translation>
    </message>
    <message>
        <source>You have requested to be unsubscribed from the newsletter &apos;%1&apos;.</source>
        <translation>Du har bedt om å bli avmeldt fra nyhetsbrevet &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Click the following link to confirm your unsubscription:</source>
        <translation>Klikk denne lenken for å bekrefte avmeldingen din:</translation>
    </message>
    <message>
        <source>Confirm unsubscription</source>
        <translation>Bekreft avmelding</translation>
    </message>
</context>
</TS>
