These stylesheets are here because we have to include them into the mail template when sending mail.
