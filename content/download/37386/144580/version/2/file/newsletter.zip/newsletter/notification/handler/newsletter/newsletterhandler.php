<?php
//
// Definition of eZBarnimagenDigestHandler class
//
// Created on: <05-���-2003 11:58:19 sp>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file newsletterhandler.php
*/

/*!
  \class newsLetterHandler newsletterhandler.php
  \brief Handler for newsletter functionality
*/

define( 'NEWSLETTER_NOTIFICATION_HANDLER_ID', 'newsletter' );

include_once( 'lib/ezlocale/classes/ezdatetime.php' );
include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'lib/ezutils/classes/ezfunctionhandler.php' );
include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
ext_activate( 'newsletter', 'thirdparty/classes/htmlMimeMail.php' );

include_once( 'kernel/classes/notification/eznotificationeventhandler.php' );
include_once( 'kernel/classes/notification/eznotificationcollection.php' );
include_once( 'kernel/classes/notification/eznotificationcollectionitem.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/common/template.php' );


class newsLetterHandler extends eZNotificationEventHandler
{
    /*!
     Constructor
    */
    function newsLetterHandler()
    {
        //print( "newsLetterHandler\n" );
        $this->eZNotificationEventHandler( NEWSLETTER_NOTIFICATION_HANDLER_ID, 'Newsletter' );
        $this->SendNow = false;
    }

    function handle( &$event )
    {
        //print( "handle\n" );
        eZDebugSetting::writeDebug( 'kernel-notification',
                                    'Newsletter module trying to handle event' );

        if ( $event->attribute( 'event_type_string' ) == 'ezcurrenttime' )
        {
            eZDebugSetting::writeDebug( 'kernel-notification',
                                        'Newsletter module handling current time event' );

            $this->CurrentDate =& $event->content();
            $this->handleNewsletters();
        }
        else
        {
            eZDebugSetting::writeDebug( 'kernel-notification',
                                        'Newsletter module will not handle this event type' );
        }

        return true;
    }

    function handleNow( $newsletterConfig = false, $testerEmails = false )
    {
        //print( "handleNow $newsletterConfig\n" );
        $this->CurrentDate =& eZDateTime::create();
        $this->SendNow = true;
        $this->handleNewsletters( $newsletterConfig, $testerEmails );
    }

    function handleNewsletters( $newsletterConfig = false, $testerEmails = false )
    {
        //print( "handleNewsletters $newsletterConfig\n" );
        $this->CurrentTimeStamp = $this->CurrentDate->attribute( 'timestamp' );

        $newsletterINI =& eZINI::instance( 'newsletter.ini' );
        $this->ClassID = $newsletterINI->variable( 'GeneralSettings', 'NewsletterClassID' );
        $this->IsSentIdentifier = $newsletterINI->variable( 'GeneralSettings', 'IsSentIdentifier' );
        $this->DateIdentifier = $newsletterINI->variable( 'GeneralSettings', 'SendDateIdentifier' );
        $this->AttachFileClassIDs = $newsletterINI->variable( 'GeneralSettings', 'AttachFileClassIDs' );
        $this->AttachFileIdentifiers = $newsletterINI->variable( 'GeneralSettings', 'AttachFileIdentifiers' );
        $this->RequireUserLogin = false;
        if ( $newsletterINI->variable( 'GeneralSettings', 'RequireUserLogin' ) == 'true' )
            $this->RequireUserLogin = true;

        if ( $newsletterConfig )
        {
            $this->handleNewsletterConfig( $newsletterConfig, $testerEmails );
        }
        else
        {
            $newsletterConfigs = $newsletterINI->variable( 'GeneralSettings', 'AvailableNewsletters' );
            if ( !is_array( $newsletterConfigs ) )
            {
                return true;
            }
            foreach ( $newsletterConfigs as $newsletterConfig )
            {
                $this->handleNewsletterConfig( $newsletterConfig, $testerEmails );
            }
        }
    }

    function handleNewsletterConfig( $newsletterConfig, $testerEmails = false )
    {
        //print( "handleNewsletterConfig $newsletterConfig\n" );
        $newsletterINI =& eZINI::instance( 'newsletter.ini' );
        $nodeID = $newsletterINI->variable( $newsletterConfig, 'NodeID' );
        $checkSubtree = false;
        if ( $newsletterINI->variable( $newsletterConfig, 'Subtree' ) == 'enabled' )
            $checkSubtree = true;
        $setIsSent = false;
        if ( $newsletterINI->variable( $newsletterConfig, 'SetIsSent' ) == 'enabled' )
            $setIsSent = true;
        $newsletterName = $newsletterINI->variable( $newsletterConfig, 'Name' );

        $rootNode =& eZContentObjectTreeNode::fetch( $nodeID );
        if ( !$rootNode )
        {
            eZDebugSetting::writeDebug( 'kernel-notification',
                                        'Newsletter module: No node with ID: ' . $nodeID );
            return;
        }

        $newsletters = array();
        if ( $checkSubtree )
        {
            // Fetch all newsletters under the root node
            $newsletters = eZFunctionHandler::execute( 'content', 'list',
                                                       array( 'parent_node_id' => $nodeID,
                                                              'depth' => 100,
                                                              'class_filter_type' => 'include',
                                                              'class_filter_array' => array( $this->ClassID ),
                                                              'as_object' => true ) );
        }
        else
        {
            $newsletters[] = $rootNode;
        }

        foreach ( $newsletters as $newsletterNode )
        {
            eZDebugSetting::writeDebug( 'kernel-notification',$newsletterNode,'Newsletter module: newsletterNode - ' . $this->ClassID  );
            if ( $newsletterNode->ClassIdentifier == 'newsletter' )
            {
                $this->handleNewsletterNode( $newsletterNode, $setIsSent, $newsletterName,
                                             $newsletterConfig, $testerEmails );
            }
        }
    }

    function handleNewsletterNode( $newsletterNode, $setIsSent, $newsletterName, $newsletterConfig,
                                   $testerEmails = false )
    {
        //print( "handleNewsletterNode $newsletterName\n" );
        $newsletterObject =& $newsletterNode->object();
        $newsletterID = $newsletterObject->attribute( 'id' );
        $newsletterNodeID = $newsletterNode->attribute( 'node_id' );

        $newsletterDataMap =& $newsletterObject->dataMap();
        $isSentAttribute =& $newsletterDataMap[$this->IsSentIdentifier];
        eZDebugSetting::writeDebug( 'kernel-notification', $this->IsSentIdentifier,'Newsletter module: IsSentIdentifier' );
        eZDebugSetting::writeDebug( 'kernel-notification', $newsletterDataMap,'Newsletter module: newsletterDataMap' );
        $isSent = $isSentAttribute->attribute( 'data_int' );
        $sendDateAttribute =& $newsletterDataMap[$this->DateIdentifier];
        $sendDate = $sendDateAttribute->attribute( 'content' );
        if ( !$this->SendNow )
        {
            // Check the 'Send time' attribute, to see if this newsletter should be sent now
            if ( $isSent ||
                 $this->CurrentTimeStamp < $sendDate->timeStamp() ||
                 $sendDate->timeStamp() == 0 )
            {
                eZDebugSetting::writeDebug( 'kernel-notification',
                                            'Newsletter module: This newsletter will not be sent now: '.
                                            $newsletterID );
                return;
            }
        }
        eZDebugSetting::writeDebug( 'kernel-notification',
                                    'Newsletter module: This newsletter will be sent now: ' .
                                    $newsletterID );

        // Avoid generating the mail over and over again. Generate only one for each language.
        $cache = array();
        if ( is_array( $testerEmails ) )  // Send only to tester emails
        {
            $rows = array();
            $this->RequireUserLogin = false;  // This needs to be email-based
            $ini =& eZINI::instance();
            $contentObjectLocale = $ini->variable( 'RegionalSettings', 'ContentObjectLocale' );
            foreach ( $testerEmails as $testerEmail )
            {
                $rows[] = array( 'user_id' => 0,
                                 'email' => $testerEmail,
                                 'newsletter' => $newsletterConfig,
                                 'language' => $contentObjectLocale,
                                 'hash' => '',
                                 'is_active' => 1 );
            }
        }
        else  // Normal, send to subscribed users
        {
            $db =& eZDB::instance();
            $rows =& $db->arrayQuery( 'SELECT * FROM eznewsletter_subscription WHERE is_active = 1 ' .
                                      "AND newsletter = '$newsletterConfig'" );
        }
        if ( !is_array( $rows ) )
        {
            // No subscriptions to this newsletter
            return;
        }

        // Loop through subscriptions, send mails
        $sentToArray = array();
        foreach ( $rows as $subscription )
        {
            $sentToEmail = $this->handleNewsletterSubscription( $subscription, $newsletterName,
                                                                $newsletterObject, $newsletterID,
                                                                $newsletterNodeID, $cache, $newsletterConfig,
                                                                $sentToArray );
            if ( $sentToEmail )
            {
                $sentToArray[] = $sentToEmail;
            }
        }

        if ( $setIsSent )
        {
            // Set the is sent checkbox, so the newsletter is not sent again
            $isSentAttribute->setAttribute( 'data_int', true );
            $isSentAttribute->store();

            $version = $newsletterObject->currentVersion();
            $version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
            $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
            $version->store();

            // Republish object
            $newVersion =& $newsletterObject->createNewVersion();
            $operationResult = eZOperationHandler::execute( 'content', 'publish',
                                                    array( 'object_id' => $newsletterID,
                                                           'version' => $newVersion->attribute( 'version' ) ) );
        }
    }

    function handleNewsletterSubscription( $subscription, $newsletterName, $newsletterObject,
                                           $newsletterID, $newsletterNodeID, $cache, $newsletterConfig,
                                           $sentToArray )
    {
        //print( "handleNewsletterSubscription $newsletterName\n" );
        if ( $this->RequireUserLogin )
        {
            $user =& eZUser::fetch( $subscription['user_id'], true );
            if ( is_object( $user ) )
            {
                $email = $user->attribute( 'email' );
                $userObject = $user->attribute( 'contentobject' );
                $userDataMap = $userObject->dataMap();
                $firstName = $userDataMap['first_name']->content();
                $lastName = $userDataMap['last_name']->content();
            }
        }
        else
        {
            $email = $subscription['email'];
        }
        // If bad email, return
        $isEmailValid = eZMail::validate( $email );
        if ( !$isEmailValid )
        {
            eZDebug::writeDebug( "Bad email: '$email' in Newsletter subscription" );
            return false;
        }

        // If this mail is already sent to this person, don't send it again
        if ( in_array( $email, $sentToArray ) )
        {
            eZDebug::writeDebug( "This email has been sent to '$email' before, will not send again" );
            return false;
        }

        $language = $subscription['language'];
        if ( !isSet( $cache[$language] ) )  // Not cached, let's create the cache
        {
            // Make sure we fetch html in the correct language
            $ini =& eZINI::instance();
            $originalLocale = $ini->variable( 'RegionalSettings', 'Locale' );
            $originalContentObjectLocale = $ini->variable( 'RegionalSettings', 'ContentObjectLocale' );
            if ( $ini->variable( 'RegionalSettings', 'ContentObjectLocale' ) != $language )
                $ini->setVariable( 'RegionalSettings', 'ContentObjectLocale', $language );
            if ( $ini->variable( 'RegionalSettings', 'Locale' ) != $language )
                $ini->setVariable( 'RegionalSettings', 'Locale', $language );
            $newsletterDataMapTranslated =& $newsletterObject->fetchDataMap( false, $language );

            $tpl =& templateInit();
            $tpl->setVariable( 'name', $newsletterName );
            $tpl->setVariable( 'date', time() );
            $tpl->setVariable( 'object', $newsletterObject );
            $tpl->setVariable( 'data_map', $newsletterDataMapTranslated );
            $tpl->setVariable( 'htmlmail_image_list', array() );
            $tpl->setVariable( 'attach_file_class_ids', $this->AttachFileClassIDs );
            $tpl->setVariable( 'newsletter', $newsletterConfig );

            $plain = $tpl->fetch( 'design:newsletter_mail_plain.tpl' );
            $html = $tpl->fetch( 'design:newsletter_mail_html.tpl' );
            $subject = $tpl->variable( 'subject' );
            $images = $tpl->variable( 'htmlmail_image_list' );

            $ini =& eZINI::instance();
            $notificationINI =& eZINI::instance( 'notification.ini' );
            $sender = $notificationINI->variable( 'MailSettings', 'EmailSender' );
            if ( !$sender )
                $sender = $ini->variable( 'MailSettings', 'EmailSender' );
            if ( !$sender )
                $sender = $ini->variable( 'MailSettings', 'AdminEmail' );

            // Create cache
            $cache[$language] = array( 'plain' => $plain,
                                       'html' => $html,
                                       'subject' => $subject,
                                       'images' => $images,
                                       'sender' => $sender );

            // Reset locale to original value
            if ( $ini->variable( 'RegionalSettings', 'Locale' ) != $originalLocale )
                $ini->setVariable( 'RegionalSettings', 'Locale', $originalLocale );
            if ( $ini->variable( 'RegionalSettings', 'ContentObjectLocale' ) != $originalContentObjectLocale )
                $ini->setVariable( 'RegionalSettings', 'ContentObjectLocale', $originalContentObjectLocale );
        }

        // Replace personal content
        if ( $this->RequireUserLogin )
            $replaceText = '';  // We don't need the email address
        else
            $replaceText = $email;
        $cache[$language]['html'] = str_replace( '[EMAIL]', $replaceText, $cache[$language]['html'] );
        $cache[$language]['plain'] = str_replace( '[EMAIL]', $replaceText, $cache[$language]['plain'] );
        if ( $this->RequireUserLogin )
        {
            $cache[$language]['html'] = str_replace( '[FIRST_NAME]', $firstName, $cache[$language]['html'] );
            $cache[$language]['plain'] = str_replace( '[FIRST_NAME]', $firstName, $cache[$language]['plain'] );
            $cache[$language]['html'] = str_replace( '[LAST_NAME]', $lastName, $cache[$language]['html'] );
            $cache[$language]['plain'] = str_replace( '[LAST_NAME]', $lastName, $cache[$language]['plain'] );
        }

        // Create email
        $mail = new htmlMimeMail();
        $mail->setHtmlEncoding( 'quoted-printable' );
        $mail->setTextEncoding( '7bit' );
        $mail->setHtml( $cache[$language]['html'], $cache[$language]['plain'] );
        $mail->setReturnPath( $cache[$language]['sender'] );
        $mail->setSubject( $cache[$language]['subject'] );
        $mail->setHeader( 'X-Mailer', 'HTML Mime mail class (http://www.phpguru.org)' );

        // Attach files to email
        $files = eZFunctionHandler::execute( 'content', 'list',
                                             array( 'parent_node_id' => $newsletterNodeID,
                                                    'class_filter_type' => 'include',
                                                    'class_filter_array' => $this->AttachFileClassIDs,
                                                    'as_object' => true ) );
        foreach ( $files as $fileNode )
        {
            $file =& $fileNode->object();
            $fileClassID = $file->attribute( 'contentclass_id' );
            $fileDataMap =& $file->dataMap();
            $fileAttribute =& $fileDataMap[$this->AttachFileIdentifiers[$fileClassID]];
            $fileAttributeContent = $fileAttribute->attribute( 'content' );
            $fileWithPath = $fileAttributeContent->attribute( 'filepath' );
            $fileName = $fileAttributeContent->attribute( 'original_filename' );
            $mimeType = $fileAttributeContent->attribute( 'mime_type' );
            $mail->addAttachment( $mail->getFile( $fileWithPath ), $fileName, $mimeType );
        }

        // Send email
        $result = $mail->send( array( $email ) );

        // Log the result
        if ( $result )
        {
            print( "Sent newsletter to $email\n" );
            eZDebug::writeDebug( "Newsletter '$newsletterID' was sent to '$email' at " .
                                 $this->CurrentDate->toString( true ) );
            return $email;
        }
        else
        {
            eZDebug::writeDebug( "Newsletter '$newsletterID' was not sent to '$email' at " .
                                 $this->CurrentDate->toString( true ) .
                                 ' due to an unknown error.' );
            return false;
        }
    }

    var $CurrentDate;
    var $CurrentTimeStamp;
    var $SendNow;
    var $ClassID;
    var $IsSentIdentifier;
    var $DateIdentifier;
    var $AttachFileClassIDs;
    var $AttachFileIdentifiers;
    var $RequireUserLogin;

}

?>
