<?php
//
// Created on: <04-Dec-2003 15:32:36 gl>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

$Module = array( 'name' => 'Newsletter subscription management',
                 'variable_params' => true );

$ViewList = array();

$ViewList['list'] = array(
    'functions' => array( 'user' ),
    'script' => 'list.php',
    'single_post_actions' => array( 'SendNowButton' => 'SendNowAction',
                                    'SendTestNowButton' => 'SendTestNowAction',
                                    'SubscribeMultipleButton' => 'SubscribeMultipleAction' ),
    'post_action_parameters' => array( 'SendNowAction' => array( 'Newsletter' => 'Newsletter' ),
                                       'SendTestNowAction' => array( 'Newsletter' => 'Newsletter' ) ),
    'params' => array() );

$ViewList['subscribe'] = array(
    'functions' => array( 'user' ),
    'script' => 'subscribe.php',
    'single_post_actions' => array( 'SubscribeButton' => 'SubscribeAction',
                                    'CancelButton' => 'CancelAction' ),
    'post_action_parameters' => array( 'SubscribeAction' => array( 'Email' => 'Email',
                                                                   'Language' => 'Language' ) ),
    'params' => array( 'Newsletter', 'Email' ) );

$ViewList['unsubscribe'] = array(
    'functions' => array( 'user' ),
    'script' => 'unsubscribe.php',
    'single_post_actions' => array( 'UnsubscribeButton' => 'UnsubscribeAction',
                                    'CancelButton' => 'CancelAction' ),
    'post_action_parameters' => array( 'UnsubscribeAction' => array( 'Email' => 'Email' ) ),
    'params' => array( 'Newsletter', 'Email' ) );

$ViewList['confirm_subscription'] = array(
    'functions' => array( 'user' ),
    'script' => 'subscribe.php',
    'default_action' => array( array( 'name' => 'ConfirmSubscriptionAction',
                                      'type' => 'post' ) ),
    'params' => array( 'Newsletter', 'Hash', 'Email' ) );

$ViewList['confirm_unsubscription'] = array(
    'functions' => array( 'user' ),
    'script' => 'unsubscribe.php',
    'default_action' => array( array( 'name' => 'ConfirmUnsubscriptionAction',
                                      'type' => 'post' ) ),
    'params' => array( 'Newsletter', 'Hash', 'Email' ) );

$ViewList['cancel_pending'] = array(
    'functions' => array( 'user' ),
    'script' => 'cancel.php',
    'params' => array( 'Newsletter', 'Email' ) );


$FunctionList['user'] = array();
$FunctionList['admin'] = array();

?>
