create table eznewsletter_subscription (
       user_id int(11) NOT NULL default '0',
       email varchar(100) NOT NULL,
       newsletter varchar(100) NOT NULL default '',
       language varchar(32) NOT NULL default '',
       hash varchar(32) NOT NULL default '',
       is_active int(11) NOT NULL default '0',
       PRIMARY KEY (user_id,email,newsletter)
     ) TYPE=MyISAM;
