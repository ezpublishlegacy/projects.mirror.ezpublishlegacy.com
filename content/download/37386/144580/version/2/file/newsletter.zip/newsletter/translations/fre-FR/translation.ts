﻿<!DOCTYPE TS><TS>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Pas de relation</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Prix:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Votre prix:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Vous gagnez:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Prix</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Informations de comtpe utilisateur</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID utilisateur</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Courriel</translation>
    </message>
</context>
<context>
    <name>newsletter</name>
    <message>
        <source>Confirmation required</source>
        <translation>Confirmation requise</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>S&apos;abonner</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Confirmation</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Se d&eacute;sabonner</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your subscription.</source>
        <translation>Vous allez bient&ocirc;t recevoir un courriel avec un lien de confirmation. Cliquez ce lien pour confirmer votre abonnement.</translation>
    </message>
    <message>
        <source>Your email address is not valid</source>
        <translation>Votre adresse courriel n&apos;est pas valide</translation>
    </message>
    <message>
        <source>The address you have entered is not a valid email address. Please enter a valid address.</source>
        <translation>L&apos;adresse que vous avez entr&eacute; n&apos;est pas une adresse courriel valide. Entrez une adresse valide.</translation>
    </message>
    <message>
        <source>Subscription confirmed</source>
        <translation>Abonnement confirm&eacute;</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed</source>
        <translation>Votre abonnement n&apos;a pu &ecirc;tre confirm&eacute;</translation>
    </message>
    <message>
        <source>Your subscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Votre abonnement n&apos;a pas pu &ecirc;tre confirm&eacute;, la cause possible est une adresse URL mal form&eacute;e. Assurez-vous que vous n&apos;avez pas chang&eacute; l&apos;adresse.</translation>
    </message>
    <message>
        <source>Already subscribed</source>
        <translation>D&eacute;j&agrave; abonn&eacute;</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Votre adresse courriel</translation>
    </message>
    <message>
        <source>Your preferred language</source>
        <translation>Votre langue pr&eacute;f&eacute;r&eacute;e</translation>
    </message>
    <message>
        <source>Unsubscribe from the %1 newsletter</source>
        <translation>Se d&eacute;sabonner de la liste de diffusion %1</translation>
    </message>
    <message>
        <source>You will shortly receive an email message with a confirmation link. Click that link to confirm your unsubscription.</source>
        <translation>Vous allez bient&ocirc;t recevoir un message courriel avec un lien de confirmation. Cliquez sur ce lien pour confirmer votre d&eacute;sabonnement</translation>
    </message>
    <message>
        <source>Unsubscription confirmed</source>
        <translation>D&eacute;sabonnement confirm&eacute;</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed</source>
        <translation>Votre d&eacute;sabonnement n&apos;a pas pu &ecirc;tre confirm&eacute;</translation>
    </message>
    <message>
        <source>Your unsubscription could not be confirmed, possibly due to a malformed URL address. Make sure that you didn&apos;t change the address.</source>
        <translation>Votre d&eacute;sabonnement n&apos;a pas pu &ecirc;tre confirm&eacute;, la cause possible est une adresse mal form&eacute;e. Assurez-vous que vous n&apos;avez pas chang&eacute; l&apos;adresse.</translation>
    </message>
    <message>
        <source>Not subscribed</source>
        <translation>Pas abonn&eacute;</translation>
    </message>
    <message>
        <source>Newsletter list</source>
        <translation>Listes de diffusion</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Liste de diffusion</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Envoyer</translation>
    </message>
    <message>
        <source>Subscribed</source>
        <translation>Abonn&eacute;</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Send now</source>
        <translation>Envoyer maintenant</translation>
    </message>
    <message>
        <source>Send test now</source>
        <translation>Envoyer un test maintenant</translation>
    </message>
    <message>
        <source>There are no available newsletters</source>
        <translation>Il n&apos;y a pas de listes de diffusion disponibles</translation>
    </message>
    <message>
        <source>Subscribe to the &apos;%1&apos; newsletter</source>
        <translation>S&apos;abonner &agrave; la liste de diffusion &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Back to the newsletter list</source>
        <translation>Revenir aux listes de diffusion</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully subscribed to the %2 newsletter. This will be sent to your email address &apos;%3&apos;, make sure that it is valid.</source>
        <translation>Bonjour %1, vous avez &eacute;t&eacute; abonn&eacute; &agrave; la liste de diffusion %1 avec succ&egrave;s. Cel&agrave; va vous &ecirc;tre envoy&eacute; &agrave; votre adresse de courriel &apos;%3&apos;, assurez vous que cel&agrave; est valide.</translation>
    </message>
    <message>
        <source>If necessary, you can %1change your e-mail address.%2</source>
        <translation>Si n&eacute;cessaire, vous pouvez %1 changer votre adresse courriel.%2</translation>
    </message>
    <message>
        <source>To the newsletter list</source>
        <translation>Vers les listes de diffusion</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is already subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>L&apos;adresse courriel &apos;%1&apos; est d&eacute;j&agrave; abonn&eacute;e &agrave; la liste de diffusion &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Hi %1, you have been succesfully unsubscribed to the %2 newsletter.</source>
        <translation>Bonjour %1, vous avez &eacute;t&eacute; abonn&eacute; &agrave; la liste de diffusion %2 avec succ&egrave;s.</translation>
    </message>
    <message>
        <source>The email address &apos;%1&apos; is not subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>L&apos;adresse courrier &apos;%1&apos; n&apos;est pas abonn&eacute;e &agrave; la liste de diffusion &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>subscription</name>
    <message>
        <source>Sent at</source>
        <translation>Envoy&eacute; &agrave;</translation>
    </message>
    <message>
        <source>Click here to unsubscribe</source>
        <translation>Cliquez ici pour vous d&eacute;sabonner</translation>
    </message>
    <message>
        <source>Confirmation required</source>
        <translation>Confirmation requise</translation>
    </message>
    <message>
        <source>Hi %1, you have requested to be subscribed to the newsletter &apos;%2&apos;.</source>
        <translation>Bonjour %1 vous avez demand&eacute; &agrave; &ecirc;tre abonn&eacute; &agrave; la liste de diffusion &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Click the following link to confirm your subscription:</source>
        <translation>Cliquez le lien suivant pour confirmer votre abonnement</translation>
    </message>
    <message>
        <source>Confirm subscription</source>
        <translation>Confirmer l&apos;abonnement</translation>
    </message>
    <message>
        <source>You have requested to be unsubscribed from the newsletter &apos;%1&apos;.</source>
        <translation>Vous avez demand&eacute; &agrave; &ecirc;tre abonn&eacute; &agrave; la liste de diffusion &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Click the following link to confirm your unsubscription:</source>
        <translation>Cliquez sur le lien suivant pour confirmer votre d&eacute;sabonnement</translation>
    </message>
    <message>
        <source>Confirm unsubscription</source>
        <translation>Confirmer le d&eacute;sabonnement</translation>
    </message>
</context>
</TS>
