<?php
//
// Created on: <22-Jan-2004 14:24:32 gl>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

// Lists all available newsletters, and allows you to subscribe or unsubscribe


include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );


$http =& eZHTTPTool::instance();
$db =& eZDB::instance();
$module =& $Params['Module'];
$newsletterINI =& eZINI::instance( 'newsletter.ini' );
$requireUserLogin = false;
if ( $newsletterINI->variable( 'GeneralSettings', 'RequireUserLogin' ) == 'true' )
    $requireUserLogin = true;

$user =& eZUser::currentUser();
if ( $requireUserLogin && !$user->isLoggedIn() )
{
    // We require login, show error message
    $tpl =& templateInit();
    $Result = array();
    $Result['content'] =& $tpl->fetch( 'design:error/kernel/1.tpl' );
}

// Send this newsletter to all subscribers now
else if ( $module->isCurrentAction( 'SendNowAction' ) )
{
    $newsletterConfig = $http->variable( 'Newsletter' );

    include_once( 'kernel/classes/notification/eznotificationeventfilter.php' );
    $handlers = eZNotificationEventFilter::availableHandlers();
    $newsletterHandler = $handlers['newsletter'];

    // Change to cronjobs site access
    changeAccess( array( 'name' => 'cronjobs',
                         'type' => EZ_ACCESS_TYPE_DEFAULT ) );

    $newsletterHandler->handleNow( $newsletterConfig );

    $module->redirectToView( 'list' );
}

// Send this newsletter to the testers now
else if ( $module->isCurrentAction( 'SendTestNowAction' ) )
{

    $GLOBALSCopy = $GLOBALS;
    foreach( array_keys( $GLOBALS ) as $key )
    {
        if ( strpos( $key,'eZINI' ) === 0 or  in_array( $key, array( 'siteDesignOverride', 'eZCurrentAccess', 'access' ) ) )
        {
//            eZDebug::writeDebug( $key, 'removing global variable' );
            $GLOBALS[$key] = null;
        }
    }
    // Change to cronjobs site access
    changeAccess( array( 'name' => 'cronjobs',
                         'type' => EZ_ACCESS_TYPE_DEFAULT ) );
    eZDebug::writeDebug( array_keys( $GLOBALS ), "values in global" );
    eZExtension::activateExtensions( 'default' );

    $ini =& eZINI::instance();
//    eZDebug::writeDebug( $ini->LocalOverrideDirArray, '$ini->LocalOverrideDirArray' );
//    eZDebug::writeDebug( $ini->variable( 'Foo', 'Boo' ), "ini in cronjob siteaccess" );

    $http =& eZHTTPTool::instance();
    $newsletterINI =& eZINI::instance( 'newsletter.ini' );


    $newsletterConfig = $http->variable( 'Newsletter' );
    $newsletterTesters = $newsletterINI->variable( $newsletterConfig, 'TesterAddresses' );

    include_once( 'kernel/classes/notification/eznotificationeventfilter.php' );
    $handlers = eZNotificationEventFilter::availableHandlers();
    $newsletterHandler = $handlers['newsletter'];


    $newsletterHandler->handleNow( $newsletterConfig, $newsletterTesters );

    $GLOBALS = $GLOBALSCopy;

    $module->redirectToView( 'list' );
}

// Show the list
else
{
    // Multiple subscripe and/or unsubscribe
    // We have just selected some newsletters and clicked the subscribe multiple button in the newsletter list
    // This method only works with userid-based subscription and without confirmation. Also no language choice.
    if ( $module->isCurrentAction( 'SubscribeMultipleAction' ) )
    {
        $userID = $user->attribute( 'contentobject_id' );
        $language = $http->variable( 'Language' );
        $selectedNewsletterList = $http->variable( 'SelectedNewsletterList' );

        // Subscribe all in the list
        foreach ( $selectedNewsletterList as $newsletter )
        {
            $rows =& $db->arrayQuery( 'SELECT * FROM eznewsletter_subscription ' .
                                      "WHERE user_id = '$userID' AND newsletter = '$newsletter'" );
            if ( count( $rows ) > 0 ) // There is an existing entry
            {
                if ( $rows[0]['is_active'] != 1 )  // Not subscribed
                {
                    $db->query( 'UPDATE eznewsletter_subscription ' .
                                "SET language = '$language', is_active = 1 " .
                                "WHERE user_id = '$userID' AND newsletter = '$newsletter'" );
                }
            }
            else  // There is no entry
            {
                $db->query( 'INSERT INTO eznewsletter_subscription VALUES ' .
                            "( $userID, '', '$newsletter', '$language', '', 1 )" );
            }
        }

        // Unsubscribe all that is not in the list of selected newsletters
        $newsletterSQL = implode( "','", $selectedNewsletterList );
        $db->query( 'UPDATE eznewsletter_subscription ' .
                    "SET is_active = 0 " .
                    "WHERE user_id = '$userID' AND newsletter NOT IN ( '$newsletterSQL' )" );
    }

    // Check newsletter_admin policy function
    $roles = $user->roles();
    $isAdmin = false;
    foreach ( $roles as $role )
    {
        foreach ( $role->policyList() as $policy )
        {
            if ( ( $policy->attribute( 'module_name' ) == '*' and
                   $policy->attribute( 'function_name' ) == '*' ) or
                 ( $policy->attribute( 'module_name' ) == 'newsletter' and
                   ( $policy->attribute( 'function_name' ) == '*' or
                     $policy->attribute( 'function_name' ) == 'admin' ) ) )
            {
                $isAdmin = true;
                break 2;
            }
        }
    }

    // If current user is logged in, fetch his subscriptions
    if ( $user->isLoggedIn() )
    {
        $email = $user->attribute( 'email' );
        if ( $requireUserLogin )
        {
            $userID = $user->attribute( 'contentobject_id' );
            $mySubscriptions =& $db->arrayQuery( 'SELECT * FROM eznewsletter_subscription ' .
                                                 "WHERE user_id = '$userID'" );
            $email = '';
        }
        else
        {
            $mySubscriptions =& $db->arrayQuery( 'SELECT * FROM eznewsletter_subscription ' .
                                                 "WHERE email = '$email'" );
        }
    }

    if ( !is_array( $mySubscriptions ) )
    {
        $mySubscriptions = array();
    }

    // Create name/description hashes for subscribed, pending and not subscribed, and for everything
    $newsletterConfigs = $newsletterINI->variable( 'GeneralSettings', 'AvailableNewsletters' );
    $newsletterList = array();
    $subscribedNewsletterList = array();
    $pendingNewsletterList = array();
    $notSubscribedNewsletterList = array();
    if ( !is_array( $newsletterConfigs ) )
    {
        $newsletterConfigs = array();
    }
    foreach ( $newsletterConfigs as $newsletterConfig )
    {
        $isSubscribed = false;
        $isPending = false;
        foreach ( $mySubscriptions as $mySubscription )
        {
            if ( $mySubscription['newsletter'] == $newsletterConfig )
            {
                if ( $mySubscription['is_active'] == 1 )
                {
                    $isSubscribed = true;
                }
                else if ( $mySubscription['hash'] != '' )
                {
                    $isPending = true;
                }
            }
        }

        if ( $isSubscribed )
        {
            $newsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ),
                'status' => 'subscribed' );
            $subscribedNewsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ) );
        }
        else if ( $isPending )
        {
            $newsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ),
                'status' => 'pending' );
            $pendingNewsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ) );
        }
        else
        {
            $newsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ),
                'status' => 'not_subscribed' );
            $notSubscribedNewsletterList[$newsletterConfig] = array(
                'name' => $newsletterINI->variable( $newsletterConfig, 'Name' ),
                'description' => $newsletterINI->variable( $newsletterConfig, 'Description' ) );
        }
    }

    $tpl =& templateInit();
    $tpl->setVariable( 'newsletter_list', $newsletterList );
    $tpl->setVariable( 'subscribed_newsletter_list', $subscribedNewsletterList );
    $tpl->setVariable( 'pending_newsletter_list', $pendingNewsletterList );
    $tpl->setVariable( 'not_subscribed_newsletter_list', $notSubscribedNewsletterList );
    $tpl->setVariable( 'email', $email );
    $tpl->setVariable( 'is_admin', $isAdmin );

    $Result = array();
    $Result['content'] =& $tpl->fetch( 'design:newsletter/list.tpl' );
    $Result['path'] = array( array( 'text' => ezi18n( 'newsletter', 'Newsletter' ),
                                    'url' => false ),
                             array( 'text' => ezi18n( 'newsletter', 'List' ),
                                    'url' => false ) );
}

?>
