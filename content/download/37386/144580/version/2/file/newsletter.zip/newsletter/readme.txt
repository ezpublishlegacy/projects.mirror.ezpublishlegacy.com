Newsletter module
-----------------

A multilingual newsletter system. Allows subscription and unsubscription, listing of newsletters
and subscriptions, and sending of newsletters via cron.
Change: From SVN revision 30 it requires login.
Change: From SVN revision 34, login is optional and configurable.


1. Installation:

Insert these files and folders, with the parent folder "newsletter", into your "extension" folder.
(Create it if it is not there.)
Edit your site.ini(.append), add this:

[ExtensionSettings]
ExtensionDirectory=extension
ActiveExtensions[]=newsletter

[RegionalSettings]
TranslationExtensions[]=newsletter


Create the subscription table in your database by using the
sql/*/newsletter.sql file.

Create a newsletter class with at least a date or datetime attribute, and a "is sent" check box.
Edit settings/newsletter.ini to suit your class.

Create a "cronjobs" site access, by copying the "admin" site access. Change the
"SiteDesign" in "[DesignSettings]" in site.ini(.append) to be "cronjobs".

Setup the cronjob so that the runcronjobs script uses the "cronjobs" site access,
by using the "-s" option. This is an example, to be inserted into /etc/crontab:
# This must be set to the directory where eZ publish is installed.
EZPUBLISHROOT=/var/www/ezpublish
# Location of the PHP Command Line Interface binary.
PHP=/usr/bin/php
# Executes the runcronjobs.php script every 15th minute.
#*/15 * * * * wwwrun  cd $EZPUBLISHROOT; $PHP -C runcronjobs.php -s cronjobs -q 2>&1

Change roles:
All users who should be able to use the system must have the "newsletter user *" policy.
All users who should be able to use the "Send now" and "Send test now" buttons, must
have the "newsletter admin *" policy. (The policy "* * *" will also work, of course.)

Edit settings/newsletter.ini, make sure you have the right settings for your needs.


2. Usage:

Create a newsletter object, and set the send date. Create objects (articles)
under it. The articles will be part of the newsletter.

You will find your newsletters here:
http://[your host]/newsletter/list

To send the newsletter right now, click the "Send now" button.
To send the newsletter right now to your defined list of testers, click the "Send test now" button.
