<?php /*

[ClassSettings]
Formats[iso8601]=%Y-%m-%dT%H:%i:%s

*/ ?>