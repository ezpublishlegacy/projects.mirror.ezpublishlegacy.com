<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ggwebservices

[RegionalSettings]
TranslationExtensions[]=ggwebservices

[RoleSettings]
# The following view does permissions checking on its own, based on the executed webservice
PolicyOmitList[]=webservices/execute

*/ ?>