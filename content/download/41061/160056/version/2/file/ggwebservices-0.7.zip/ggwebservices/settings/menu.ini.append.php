<?php /*

[NavigationPart]
Part[wsdebuggerhubpart]=Webservices Debugger

[TopAdminMenu]
Tabs[]=wsdebugger

[Topmenu_wsdebugger]
Name=WS Debugger
Tooltip=Debug calls to jsonrpc and xmlrpc servers
URL[default]=webservices/debugger
NavigationPartIdentifier=wsdebuggerhubpart

Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false

Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>