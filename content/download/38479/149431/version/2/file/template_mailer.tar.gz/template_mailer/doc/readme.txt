**************************************************

Template Mail Operator

**************************************************

Author : Philip Kahlen
Date : September 2006

1/ Unzip file in your extension directory

2/ Activate the extension in the admin interface

3/ To use operator in a template :

{template_mail($recipient,$sender,$subject,$text)}