<?php

class MyTemplateMailer
{
	
	/*! Constructor */
	function MyTemplateMailer()
	{
		$this->Operators = array( 'template_mail' );
	}


	/*! Returns the operators in this class. */
	function &operatorList()
	{
		return $this->Operators;
	}

	/*! Return true to tell the template engine that the parameter list
			exists per operator type, this is needed for operator classes
			that have multiple operators.
	*/
	function namedParameterPerOperator()
	{
		return true;
	}
	
	/*! The first operator has two parameters, the other has none.
			See eZTemplateOperator::namedParameterList()
	*/
	function namedParameterList()
	{
		return array( 'template_mail' => array( 'recipient' => array( 'type' => 'string',
																																	'required' => true,
																																	'default' => '' ),
																						'sender' => 	array( 	'type' => 'string',
																																	'required' => true,
																																	'default' => '' ),
																						'subject' => 		array('type' => 'string',
																																	'required' => true,
																																	'default' => '' ),
																						'text' => 			array('type' => 'string',
																																	'required' => true,
																																	'default' => '' ) ) );
	}

	/*! Executes the needed operator(s).
			Checks operator names, and calls the appropriate functions.
	*/
	function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
										&$currentNamespace, &$operatorValue, &$namedParameters )
	{
		switch ( $operatorName )
		{
			case 'template_mail':
			{
				$operatorValue = $this->template_mail( $namedParameters['recipient'],
																							 $namedParameters['sender'],
																            	 $namedParameters['subject'],
																            	 $namedParameters['text'] );
			}break;
		}
	}

	/*! Return the sum of two strings. */
	function template_mail( $recipient, $sender, $subject, $text )
	{
		mail($recipient, $subject, $text,
     			"From: " .$sender. "\r\n" .
			    "Reply-To: " .$sender. "\r\n" .
					"X-Mailer: PHP/" . phpversion());

	}

	/// privatesection
	var $Operators;
}

?>