<?php
//
// Copyright (C) 2005 Lukasz Serwatka <lukasz@serwatka.net>.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezsearchstats/autoloads/ezsearchstatsoperator.php',
                                    'class' => 'eZSearchStatsOperator',
                                    'operator_names' => array( 'ezsearchstats' ) );
?>
