<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezsearchstats

*/ ?>