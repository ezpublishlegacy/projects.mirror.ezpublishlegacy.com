var classeZStageUpdatePriorityType =
[
    [ "__construct", "classeZStageUpdatePriorityType.html#a70c9ef9b4f525d0c4acdf8d7774e656e", null ],
    [ "execute", "classeZStageUpdatePriorityType.html#a4537a3b44827dbc61bcc3a256288496d", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageUpdatePriorityType.html#a442bebebdac7497486c880a95e8c7ed8", null ]
];