var searchData=
[
  ['initsync_2ephp',['initsync.php',['../initsync_8php.html',1,'']]]
];
