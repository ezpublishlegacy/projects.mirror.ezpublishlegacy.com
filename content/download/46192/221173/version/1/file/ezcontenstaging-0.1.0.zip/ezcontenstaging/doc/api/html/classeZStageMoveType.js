var classeZStageMoveType =
[
    [ "__construct", "classeZStageMoveType.html#a7e5c569f2cf4df420ad06dcd4a17b310", null ],
    [ "execute", "classeZStageMoveType.html#accb2c283a589da11a777d79f3cbb07c5", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageMoveType.html#a47573f15a307c235d74180d59e1f998e", null ]
];