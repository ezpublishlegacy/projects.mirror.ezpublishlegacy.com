<?php
/**
*  Cronjob used (optionally) to sync al items to a given target host
*
* @package ezcontentstaging
*
* @version $Id$;
*
* @author
* @copyright
* @license http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License v2
*/

/// @todo add parsing of a cli option to get target host name (or no option for all of them)


?>
