var classeZStageUpdateSectionType =
[
    [ "__construct", "classeZStageUpdateSectionType.html#a1a558e284861b50cd0e50159a1707b71", null ],
    [ "execute", "classeZStageUpdateSectionType.html#af94f40aa59782fe3ebcbdcf93c3262a2", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageUpdateSectionType.html#a39b6bdb0b5c9cde556f20ff59b11dcbb", null ]
];