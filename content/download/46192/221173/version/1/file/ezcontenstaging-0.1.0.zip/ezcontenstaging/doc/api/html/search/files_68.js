var searchData=
[
  ['http_5fparser_2ephp',['http_parser.php',['../4_85_2kernel_2private_2rest_2classes_2request_2http__parser_8php.html',1,'']]],
  ['http_5fparser_2ephp',['http_parser.php',['../4_86_2kernel_2private_2rest_2classes_2request_2http__parser_8php.html',1,'']]]
];
