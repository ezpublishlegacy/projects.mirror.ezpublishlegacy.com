var searchData=
[
  ['base_2ephp',['base.php',['../controllers_2base_8php.html',1,'']]],
  ['base_2ephp',['base.php',['../models_2base_8php.html',1,'']]]
];
