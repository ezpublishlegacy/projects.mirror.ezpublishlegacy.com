var classeZStageUpdateObjectStateType =
[
    [ "__construct", "classeZStageUpdateObjectStateType.html#a1c8a22c7ad975071c7edb8b731b40774", null ],
    [ "execute", "classeZStageUpdateObjectStateType.html#a33154da0fed00ff961f7b75010ff69bc", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageUpdateObjectStateType.html#aa98f34ab8713087dbd68c431fc3c7105", null ]
];