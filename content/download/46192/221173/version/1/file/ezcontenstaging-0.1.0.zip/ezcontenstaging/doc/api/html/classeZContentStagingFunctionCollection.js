var classeZContentStagingFunctionCollection =
[
    [ "fetchFeedsByNodeId", "classeZContentStagingFunctionCollection.html#aa09958068ce40442da9dad17292adadd", null ],
    [ "fetchSyncEvents", "classeZContentStagingFunctionCollection.html#af8f1dfc80da755a2f47a9e94c503f765", null ],
    [ "fetchSyncEventsByNodeGroupedByTarget", "classeZContentStagingFunctionCollection.html#a5a23fef3b0a4572727088fff688beeef", null ],
    [ "fetchSyncEventsByObject", "classeZContentStagingFunctionCollection.html#ae285f3b40c7f5b9a29fd554e150e1c62", null ],
    [ "fetchSyncEventsCount", "classeZContentStagingFunctionCollection.html#a5b41bd7e9e4bbf1b30314e420146c302", null ],
    [ "fetchSynctarget", "classeZContentStagingFunctionCollection.html#a8434cc941097f52c0d69c9e46c6d4e9c", null ]
];