var dirs =
[
    [ "bin", "dir_96960fa04b2cf5f2908156fa941018c3.html", "dir_96960fa04b2cf5f2908156fa941018c3" ],
    [ "classes", "dir_06a926f1048208efe9b62fc227fc9600.html", "dir_06a926f1048208efe9b62fc227fc9600" ],
    [ "cronjobs", "dir_975458ef4965a520c3b9022bcfb91dfe.html", null ],
    [ "eventtypes", "dir_4376ae6815aaf4e83945369a4e5f417c.html", "dir_4376ae6815aaf4e83945369a4e5f417c" ],
    [ "interfaces", "dir_2fbf16f1d0dca5f5ba894504ebe9cade.html", null ],
    [ "modules", "dir_e7b8138674e449d4aa0dc370733b292c.html", "dir_e7b8138674e449d4aa0dc370733b292c" ],
    [ "patches", "dir_fe7a219f55221840708bf4f76cb97433.html", "dir_fe7a219f55221840708bf4f76cb97433" ]
];