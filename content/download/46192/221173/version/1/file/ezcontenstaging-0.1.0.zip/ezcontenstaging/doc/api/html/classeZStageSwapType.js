var classeZStageSwapType =
[
    [ "__construct", "classeZStageSwapType.html#a59ff4e5974ba4148a088e7a190e259be", null ],
    [ "execute", "classeZStageSwapType.html#a25a317f78d1104f859cbbda8b9e81ed7", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageSwapType.html#a94913870493801e381d1053b1cc1fb87", null ]
];