var classeZStageDeleteType =
[
    [ "__construct", "classeZStageDeleteType.html#a50f9a68bda75ff323937e6e56f4d02e5", null ],
    [ "execute", "classeZStageDeleteType.html#acd073c47f49c417bb885d81768c88e31", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageDeleteType.html#a26034200cb31ccf739fd0f22c79d5f44", null ]
];