var feeds_8php =
[
    [ "$http", "feeds_8php.html#a775fc1707a7fa92aaa1c663c289dbbbc", null ],
    [ "$module", "feeds_8php.html#ac531301c55a8d8b6c7613597218ff482", null ],
    [ "$Result", "feeds_8php.html#a0d32c70e3cf8c7b3fe5e4a499e9cd58f", null ],
    [ "$Result", "feeds_8php.html#a94a2cc5784adee982dec0235638f6251", null ],
    [ "$tpl", "feeds_8php.html#a04b1944cdb09f9a4e290cde7a12499e6", null ]
];