var classeZBaseStagingTransport =
[
    [ "diffmask2array", "classeZBaseStagingTransport.html#aea1ff7437f991ae610e4cc2d160f4256", null ],
    [ "$diff_descriptions", "classeZBaseStagingTransport.html#a105efe0a3bf76efa81f02c5b83b0b581", null ],
    [ "DIFF_NODE_MISSING", "classeZBaseStagingTransport.html#ae8c788dc09e95b9eb6023d3446adbf41", null ],
    [ "DIFF_NODE_PARENT", "classeZBaseStagingTransport.html#a550a036f3c37d1d241226077c02dbc47", null ],
    [ "DIFF_NODE_SORTFIELD", "classeZBaseStagingTransport.html#aa9a7dd0cdd6fcd69182060c9f59e6236", null ],
    [ "DIFF_NODE_SORTORDER", "classeZBaseStagingTransport.html#a15b106313bad13390126295da75eac84", null ],
    [ "DIFF_NODE_VISIBILITY", "classeZBaseStagingTransport.html#ad8a91c03e943e849f5d990d2dae8349d", null ],
    [ "DIFF_OBJECT_ALWAYSAVAILABLE", "classeZBaseStagingTransport.html#a97d33e6a88bf2cf0d9ec0b447ef431cf", null ],
    [ "DIFF_OBJECT_MISSING", "classeZBaseStagingTransport.html#ace303c5c2741bad581de9a27f59cafca", null ],
    [ "DIFF_OBJECT_SECTION", "classeZBaseStagingTransport.html#a13eaf734472547bf6ed177827f23a290", null ],
    [ "DIFF_OBJECT_STATE", "classeZBaseStagingTransport.html#aa74110a8ea93115b5b177fbcea57db1b", null ],
    [ "DIFF_TRANSPORTERROR", "classeZBaseStagingTransport.html#a39856d2f6d1177ca96dec161a6f6283b", null ]
];