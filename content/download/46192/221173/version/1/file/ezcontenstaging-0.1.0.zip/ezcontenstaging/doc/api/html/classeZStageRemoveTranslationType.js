var classeZStageRemoveTranslationType =
[
    [ "__construct", "classeZStageRemoveTranslationType.html#a116eb491a46ac7d19acf14db4f4bad78", null ],
    [ "execute", "classeZStageRemoveTranslationType.html#a2c42d9202ec247db6c412c7f076e769a", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageRemoveTranslationType.html#a33cca8025c8944d6e82a5cffcc4ff8d1", null ]
];