var classeZStageUpdateInitialLanguageType =
[
    [ "__construct", "classeZStageUpdateInitialLanguageType.html#a8a9233e9db670d1ffa5e44164ae438ce", null ],
    [ "execute", "classeZStageUpdateInitialLanguageType.html#af3b2417014a6bb2d64f8dd84cc9d03ba", null ],
    [ "WORKFLOW_TYPE_STRING", "classeZStageUpdateInitialLanguageType.html#a5310f87efb74c36b39b90e2ae984df37", null ]
];