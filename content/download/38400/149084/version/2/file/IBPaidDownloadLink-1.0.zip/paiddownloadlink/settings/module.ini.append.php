[ModuleSettings]
ExtensionRepositories[]=paiddownloadlink