<?php
//
// Created on: <3-Mar-2009>
//
// SOFTWARE NAME: IB Paid Download Link
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
class PaidDownloadLink {
    public function __construct() {
        $this->settings = eZINI::instance( 'paiddownloadlink.ini', 'extension/paiddownloadlink/settings' );
    }

    public function getCurrentUserValidLink( $productID ) {
        $class            = eZContentClass::fetchByIdentifier( $this->settings->variable( 'General', 'LinkClassIdentifier' ) );
        $allDownloadLinks = $class->objectList();

        $currentUser      = eZUser::currentUser();
        $userID           = $currentUser->ContentObjectID;
        $timeTo           = time(); 

        foreach( $allDownloadLinks as $key => $downloadLink ) {
            $attributes         = $downloadLink->DataMap();
            $productAttribute   = $attributes['product_id'];
            $userAttribute      = $attributes['user_id'];
            $validDateAttribute = $attributes['valid_date'];
            if( ( $productAttribute->content()                 == $productID ) &&
                ( $userAttribute->content()                    == $userID    ) &&
                ( $validDateAttribute->attribute( 'data_int' ) >= $timeTo    )   ) {
                return $downloadLink;
            }  
        }
        return false;  
    }

    public function downloadProduct( $productID ) {
    	$fileAttributeIdentifier = $this->settings->variable( 'General', 'ProductFileAttributeIdentifier' );
    	
        $product              = eZContentObject::fetch( $productID );
        $productAttributes    = $product->DataMap();
        $productFileAttribute = $productAttributes[ $fileAttributeIdentifier ];
        if( is_object( $productFileAttribute ) && $productFileAttribute->DataTypeString == 'ezbinaryfile' ) {
	        $productFile          = $productFileAttribute->content();	    
			if( is_object( $productFile ) ) {
				eZFile::download( $productFile->filePath() );	
			}	                	
        } else {
        	eZDebug::writeError( 'Class "' . $product->ClassIdentifier . '" hasn`t attribute "' . $fileAttributeIdentifier . '". Or this attribute isn`t ezBinaryFile datatype',  'Paid download link' );
        }
    }

    public function getLinkByProductAndUser( $productID, $userID ) {
        $params = array(
        	'Depth'            => 1,
            'ClassFilterType'  => 'include',
            'ClassFilterArray' => array( $this->settings->variable( 'General', 'LinkClassIdentifier' ) ),
            'LoadDataMap'      => false,
            'Limitation'       => array()
        );        
		$linkNodes = eZContentObjectTreeNode::subTreeByNodeId( 
			$params, 
			$this->settings->variable( 'General', 'PaidDownloadLinksFolderNodeID' ) 
		);
		
        foreach( $linkNodes as $linkNode ) {
            $attributes = $linkNode->ContentObject->dataMap();
            if( $attributes['product_id']->content() == $productID &&
                $attributes['user_id']->content()    == $userID      ) {
                return $linkNode->ContentObject;
            }
        }
        return false;
    }
 
    public function updateValidDate( $paidDownloadLink ) {
        $attributes = $paidDownloadLink->dataMap(); 
        $validDate  = $attributes['valid_date'];
        $validDate->fromString( time() + $this->settings->variable( 'General', 'LinkValidDuration' ) );  
        $validDate->store();
        
		eZOperationHandler::execute( 
			'content', 
			'publish', 
			array( 
				'object_id' => $paidDownloadLink->attribute( 'id' ),
				'version'   => $paidDownloadLink->attribute( 'current_version' )
			)
		);        
    }
    
    public function add( $productID, $userID ) {
        $product   = eZContentObject::fetch( $productID );
        $user      = eZContentObject::fetch( $userID );
        $name      = $product->Name . ' - ' . $user->Name;

        $validDate = time() + $this->settings->variable( 'General', 'LinkValidDuration' );

        $params = array(
            'classIdentifier' => $this->settings->variable( 'General', 'LinkClassIdentifier' ),
            'parentNodeID'    => $this->settings->variable( 'General', 'PaidDownloadLinksFolderNodeID' ),
			'name'            => $name,
            'attributes'      => array(
            	'product_id' => $productID,
                'user_id'    => $userID,
                'valid_date' => $validDate
            ),
            'sectionID'       => 1,
        	'owner'           => $userID
        );
        $powerContent = new IBPowerContent();
        $powerContent->createObject( $params );         
    }
    
    public function getPaidLinkClasses() {
    	return $this->settings->variable( 'General', 'PaidLinkClasses' );    	
    }
}
?>
