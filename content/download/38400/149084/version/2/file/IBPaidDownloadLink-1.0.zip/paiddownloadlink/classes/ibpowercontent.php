<?php
//
// Created on: <3-Mar-2009>
//
// SOFTWARE NAME: IB Paid Download Link
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
/**
 * 
 * @author Dolgushev Sergey (l0rdJ@i-b.com.ua)
 * @copyright 2008
 *
 */
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentobjectattribute.php' );
include_once( 'kernel/classes/ezcontentobjectversion.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentclass.php' );

class IBPowerContent {
	
	public function __construct () {
	}

    /**
     * Create new content object and store it
     *      
	 * @param array( 
	 *  'classIdentifier' => string classIdentifier, Content object`s class identifier
	 *  'parentNodeID'    => int    parentNodeID,    Content object`s parent node ID	 
	 *  'name'            => string name,            Content object`s name
	 *  'attributes'      => array(                  Content object`s attributes
	 *    string identifier => string stringValue    
	 *  ),  
	 *  'sectionID'       => int    sectionID,       Section ID
	 *  'owner'           => int    owner            Owner`s content object ID
	 * )
     * @return eZContentObject $contentObject created content object
     */ 
	public function createObject( $params ) {
		if( $params['owner'] === false ) {
			$params['owner'] = $this->getCurrenUserID();	
		}

    	$db = eZDB::instance();
    	$db->begin();    
				
		$this->getClass( $params['classIdentifier'] );
		if( !is_object( $this->class ) ) {
			eZDebug::writeError( 'Cant fetch class by Identifier: ' . $params['classIdentifier'], 'IBPowerContent' );
			return false;
		}
		
		$parentNode = eZContentObjectTreeNode::fetch( $params['parentNodeID'] );
		if( !is_object( $parentNode ) ) {
			eZDebug::writeError( 'Cant fetch parent node by ID: ' . $params['parentNodeID'], ' PowerContent' );
			return false;
		}
				 
		$this->createContentObject( $params['owner'], $params['sectionID'] );
		$this->createNodeAssigment( $this->contentObject, $params['parentNodeID'] );
		$this->addVersion();
		$this->setAttributes( $params['attributes'] );
		eZOperationHandler::execute( 
			'content', 
			'publish', 
			array( 
				'object_id' => $this->contentObject->attribute( 'id' ),
				'version'   => 1
			)
		);		
		$this->node = eZContentObjectTreeNode::fetch( $this->contentObject->attribute('main_node_id') );				
		$this->setName( $params['name'] );
		$this->updateNodeURLAlias();
		
		$db->commit();
		
		return $this->contentObject;
	}
	
    /**
     * Return current user`s content object ID
     *
     * @return int User`s content object ID
     */
	private function getCurrenUserID() {
		$user = eZUser::currentUser();
		return $user->ContentObjectID;
	}

    /**
     * Load class by identifier
     *
     * @return void
     */
	private function getClass( $identifier ) {
		$this->class = eZContentClass::fetchByIdentifier( $identifier );
	}

    /**
     * Create and store content object
     *
     * @param int $owner owner`s content object ID
     * @param int $sectionID section`s ID
     * @return void
     */    
	private function createContentObject( $ownerID, $sectionID = 1 ) {   	
		$this->contentObject = $this->class->instantiate( $ownerID, $sectionID );
		$this->contentObject->store();
	}

    /**
     * Create and store node assigment
     *     
     * @param eZContentObject $object content object
     * @param int $parentNodeID parent node ID
     * @return void
     */ 
	private function createNodeAssigment( $object, $parentNodeID ) {
		$nodeAssignment = eZNodeAssignment::create( 
			array(
				'contentobject_id'      => $object->attribute( 'id' ),
				'contentobject_version' => $object->attribute( 'current_version' ),
				'parent_node'           => $parentNodeID,
				'is_main'               => 1
			)
		);
		$nodeAssignment->store();
	}

    /**
     * Create and store first content object`s version
     *     
     * @return void
     */ 
	private function addVersion() {
		$version = $this->contentObject->version( 1 );
		$version->setAttribute( 'modified', time() );
		$version->setAttribute( 'status', eZContentObjectVersion::STATUS_PUBLISHED );
		$version->store();
	}

    /**
     * Set content object attributes
     *     
     * @param array( attributeIdentifier => attributeStringValue ) $attributesValues content object attributes
     * @return void
     */
	private function setAttributes( $attributesValues ) {
		$attributes = $this->contentObject->dataMap();
		foreach( $attributesValues as $identifier => $value ) {
			if( isset( $attributes[ $identifier ] ) ) {
				$attribute = $attributes[ $identifier ];
				$attribute->fromString( $value );
				$attribute->store();
			}
		}
	}
	
    /**
     * Set content object`s and its node name
     *     
     * @param string $name name of content object
     * @return void
     */ 
	private function setName( $name ) {
		$this->contentObject->setName( $name );
		$this->contentObject->store();
		
		$this->node->setName( $name );
		$this->node->store(); 
	}

    /**
     * Update node`s URL alias
     *         
     * @return void
     */ 
	private function updateNodeURLAlias() {
		$this->node->updateSubTreePath();
	}

    /**
     * Create and store content object class with its attributes
     * 
	 * @param array(	 
	 *  'owner'           => int    owner,           Owner`s content object ID 
	 *  'name'            => string name,            Class name
	 *  'identifier'      => string identifier,      Class identifier  
	 *  'groupID'         => int groupID,            Group ID, in wich will be created class 
	 *  'attributes'      => array(                  Content object`s attributes
	 *    array(
	 *      'name'           => string name,
	 *      'identifier'     => string identifier,
	 *      'dataTypeString' => string dataTypeString
	 *    ) 
	 *  )
	 * )              
     * @return eZContentObjectClass content object class
     */ 
	public function createClass( $params ) {
		if( $params['owner'] === false ) {
			$params['owner'] = $this->getCurrenUserID();	
		}
		
    	$db = eZDB::instance();
    	$db->begin();
    	
		$this->createContentObjectClass( $params['owner'], $params['name'], $params['identifier'] );		
		$this->setClassGroup( $params['groupID'] );
		$this->setClassAttributes( $params['attributes'] );

		$db->commit();
		
		return $this->class;
	}
	
    /**
     * Create and store content object class
     *         
     * @param int $ownerID class owner`s content object ID
     * @param string $name class name 
     * @param string $identifier class identifier
     * @return void
     */ 
	private function createContentObjectClass( $ownerID, $name, $identifier ) {				
        $this->class = eZContentClass::create( $ownerID );
        $this->class->setName( $name );
        $this->class->setVersion( eZContentClass::VERSION_STATUS_DEFINED );
        
        $this->class->Identifier = $identifier;
        $this->class->store();
	}

    /**
     * Add content object class to group 
     *         
     * @param int $groupID classes group ID
     * @return void
     */ 	
	private function setClassGroup( $groupID ) {
		$GroupName = 'Content';
		
        $groupRelation = eZContentClassClassGroup::create( 
			$this->class->attribute( 'id' ), 
			$this->class->attribute( 'version' ), 
			$groupID, 
			$GroupName
		);
        $groupRelation->store();		
	}

    /**
     * Set content class attributes
     *     
     * @param array( 
     *   array(
	 *     'name'           => string name,
	 *     'identifier'     => string identifier,
	 *     'dataTypeString' => string dataTypeString
	 *   )
	 * ) $attributes content class attributes
     * @return void
     */	
	private function setClassAttributes( $attributes ) {
		foreach( $attributes as $attributeInfo ) {
			$attribute = eZContentClassAttribute::create(
				$this->class->ID,
				$attributeInfo['dataTypeString']
			);
			$attribute->setName( $attributeInfo['name'] );			
			$attribute->Identifier = $attributeInfo['identifier'];
			$attribute->version    = eZContentClass::VERSION_STATUS_DEFINED;
			$attribute->store();			
		}
	}		

    /**
     * Create a copy of existing content object
     * 
	 * @param eZContentObject $object object wich will be copied
	 * @param int $parentNodeID node where will be placed copied object
	 * @param int $sectionID section ID              
     * @return eZContentObject content object copy
     */ 
	public function copyObject( $object, $parentNodeID ) {	
    	$db = eZDB::instance();
    	$db->begin();
    	
    	$this->createObjectCopy( $object );
		$this->removeOldNodeAssigments( $this->contentObjectCopy );
		$this->createNodeAssigment( $this->contentObjectCopy, $parentNodeID );
		eZOperationHandler::execute( 
			'content', 
			'publish', 
			array( 
				'object_id' => $this->contentObjectCopy->attribute( 'id' ),
				'version'   => $this->contentObjectCopy->attribute( 'current_version' )
			)
		);
	
	    $db->commit();
		
		return $this->contentObjectCopy; 		
	}
	
    /**
     * Create objects copy and reset section ID for it 
     *         
     * @param eZContentObject $object object wich will be copied
     * @return void
     */ 	
	private function createObjectCopy( $object ) {
    	$this->contentObjectCopy = $object->copy( true );
    	// We should reset section that will be updated in updateSectionID().
    	// If sectionID is 0 than the object has been newly created
    	$this->contentObjectCopy->setAttribute( 'section_id', 0 );
    	$this->contentObjectCopy->store();		
	}	

    /**
     * Remove old node assigments 
     *         
     * @param eZContentObject $object Content object
     * @return void
     */ 	
	private function removeOldNodeAssigments( $object ) {
    	$oldObjAssignments = $object->attribute( 'current' )->attribute( 'node_assignments' );
	    foreach( $oldObjAssignments as $assignment ){
	        $assignment->purge();
	    }			
	}
}
?>