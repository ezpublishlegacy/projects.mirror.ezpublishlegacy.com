<?php
[RoleSettings]
PolicyOmitList[]=paiddownloadlink/download
?>