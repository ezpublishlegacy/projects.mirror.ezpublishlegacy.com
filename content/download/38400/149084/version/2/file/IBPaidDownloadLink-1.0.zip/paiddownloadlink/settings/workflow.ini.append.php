<?php
[EventSettings]
ExtensionDirectories[]=paiddownloadlink
AvailableEventTypes[]=event_addpaiddownloadlink
?>