<?php
//
// Created on: <3-Mar-2009>
//
// SOFTWARE NAME: IB Paid Download Link
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
include_once( 'kernel/classes/ezworkflowtype.php' );
define( 'EZ_WORKFLOW_TYPE_ADDPAIDDOWNLOADLINK_ID', 'addpaiddownloadlink' );

class addPaidDownloadLinkType extends eZWorkflowEventType {

    function addPaidDownloadLinkType() {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_ADDPAIDDOWNLOADLINK_ID, 'Add paid download link' );
    }

    function execute( $process, $event ) {
        $processParams    = $process->attribute( 'parameter_list' );
        $orderID          = $processParams['order_id'];
        $order            = eZOrder::fetch( $orderID );
        $productItems     = $order->productItems();
        
        $userID           = $order->attribute( 'user_id' );
        $paidDownloadLink = new PaidDownloadLink;
		$paidLinkClasses  = $paidDownloadLink->getPaidLinkClasses();

        foreach( $productItems as $productItem ) {
			$itemNodeID = $productItem['node_id'];
            $itemObject = $productItem['item_object']->attribute( 'contentobject' );
            
            if( in_array( $itemObject->ClassIdentifier, $paidLinkClasses ) ) {
            	$link = $paidDownloadLink->getLinkByProductAndUser( $itemObject->ID, $userID );
	            if( is_object( $link ) ) {
	                $paidDownloadLink->updateValidDate( $link );   
	            } else {
	                $paidDownloadLink->add( $itemObject->ID, $userID );
	            }              	
            }            
        }
        return eZWorkflowType::STATUS_ACCEPTED;
    }
}
eZWorkflowEventType::registerEventType( EZ_WORKFLOW_TYPE_ADDPAIDDOWNLOADLINK_ID, 'addPaidDownloadLinkType' );
?>