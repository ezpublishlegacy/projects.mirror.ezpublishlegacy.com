<?php /*
[DatabaseSettings]
ImplementationAlias[oracle]=eZOracleDB
ImplementationAlias[ezoracle]=eZOracleDB
*/ ?>
