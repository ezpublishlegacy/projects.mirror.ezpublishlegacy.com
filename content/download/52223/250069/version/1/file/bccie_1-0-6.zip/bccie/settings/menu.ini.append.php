<?php /* #?ini charset="utf-8"?                                                                                         

[NavigationPart]
Part[ezbccienavigationpart]=BC CIE Export

[TopAdminMenu]
Tabs[]=bccie_overview

[Topmenu_bccie_overview]
NavigationPartIdentifier=ezbccienavigationpart
Name=BC CIE Export
Tooltip=Collected Information Export Menu
URL[]
URL[default]=bccie/overview
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

[Leftmenu_bccie_overview]
Name=BC CIE
Links[]
LinkNames[]
Links[Export]=bccie/overview
Links[Extension project]=http://projects.ez.no/bccie

*/ ?>
