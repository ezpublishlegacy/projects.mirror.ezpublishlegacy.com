<?php
$fetchdesc = array (
  'return' => 'A three-character currency code or FALSE.',
  'desc' => 'Fetches the current user\'s preferred currency.',
);
?>