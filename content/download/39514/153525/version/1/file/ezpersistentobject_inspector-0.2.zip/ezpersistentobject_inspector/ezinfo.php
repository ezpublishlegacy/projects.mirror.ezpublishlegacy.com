<?php

class ezpersistentobject_inspectorInfo
{
    static function info()
    {
        return array(
            'Name' => "<a href=\"http://projects.ez.no/ezpersistentobject_inspector\">eZPersistentObject Inspector</a>",
            'Version' => "0.2",
            'Copyright' => "Copyright (C) 2010 Gaetano Giunta",
            'License' => "GNU General Public License v2.0"
        );
    }
}

?>