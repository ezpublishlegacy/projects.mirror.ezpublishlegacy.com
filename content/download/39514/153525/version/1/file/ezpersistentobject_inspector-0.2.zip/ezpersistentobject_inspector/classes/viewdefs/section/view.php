<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing a section.',
);
?>