<?php
$viewdesc = array (
  'desc' => 'Provides an interface for removing node assignments.',
);
?>