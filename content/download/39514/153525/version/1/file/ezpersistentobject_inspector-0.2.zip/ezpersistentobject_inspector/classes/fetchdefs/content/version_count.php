<?php
$fetchdesc = array (
  'params' => 
  array (
    'contentobject' => 
    array (
      'type' => 'object',
      'required' => true,
      'desc' => 'The target object.',
    ),
  ),
  'return' => 'The number of versions of an object (as an integer).',
  'desc' => 'Fetches the number of versions of a content object.',
);
?>