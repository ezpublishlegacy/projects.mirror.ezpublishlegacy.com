<?php
$fetchdesc = array (
  'return' => 'An array of ezproductcategory objects or FALSE.',
  'desc' => 'Fetches the available product categories.',
);
?>