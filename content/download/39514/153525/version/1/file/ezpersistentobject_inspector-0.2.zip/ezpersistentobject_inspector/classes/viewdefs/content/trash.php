<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing the trash.',
);
?>