<?php
$fetchdesc = array (
  'return' => 'An array of ezsection objects.',
  'desc' => 'Fetches the available sections.',
);
?>