<?php
$viewdesc = array (
  'desc' => 'Provides the advanced search interface.',
);
?>