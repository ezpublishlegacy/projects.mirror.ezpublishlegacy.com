<?php
$fetchdesc = array (
  'params' => 
  array (
    'class_id' => 
    array (
      'type' => 'integer',
      'required' => true,
      'desc' => 'The ID number of the target class.',
    ),
  ),
  'return' => 'Array of ezcontentclassattribute objects or FALSE.',
  'desc' => 'Fetches the attributes of a class.',
);
?>