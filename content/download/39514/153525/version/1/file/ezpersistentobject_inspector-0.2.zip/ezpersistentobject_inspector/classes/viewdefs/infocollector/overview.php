<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing objects that have collected information.',
);
?>