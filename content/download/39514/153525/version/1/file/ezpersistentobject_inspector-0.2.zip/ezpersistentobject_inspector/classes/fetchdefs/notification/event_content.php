<?php
$fetchdesc = array (
  'desc' => 'Fetches the contents of the notification event.',
);
?>