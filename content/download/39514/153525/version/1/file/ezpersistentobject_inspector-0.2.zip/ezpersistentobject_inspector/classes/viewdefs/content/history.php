<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing the versions of an object and comparing two different versions of an object.',
);
?>