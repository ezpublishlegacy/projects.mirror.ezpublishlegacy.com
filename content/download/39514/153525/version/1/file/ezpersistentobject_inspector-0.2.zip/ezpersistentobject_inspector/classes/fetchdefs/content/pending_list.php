<?php
$fetchdesc = array (
  'return' => 'An array of  objects or FALSE.',
  'desc' => 'Fetches the pending objects for the current user.',
);
?>