<?php
$fetchdesc = array (
  'return' => 'The number of anonymous users as an integer.',
  'desc' => 'Fetches the number of anonymous users.',
);
?>