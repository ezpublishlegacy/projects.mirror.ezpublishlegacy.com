<?php
$fetchdesc = array (
  'params' => 
  array (
    'locale_code' => 
    array (
      'type' => 'string',
      'required' => false,
      'desc' => 'The code of the locale to be fetched.',
    ),
  ),
  'return' => 'An ezlocale object.',
  'desc' => 'Fetches the current or a specified locale.',
);
?>