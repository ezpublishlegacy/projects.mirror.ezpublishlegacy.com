<?php
$fetchdesc = array (
  'return' => 'An array of ezlocale objects.',
  'desc' => 'Fetches the locales that can be used to translate objects.',
);
?>