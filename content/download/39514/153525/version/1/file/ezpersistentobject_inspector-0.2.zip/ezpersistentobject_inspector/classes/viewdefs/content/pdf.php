<?php
$viewdesc = array (
  'desc' => 'Provides on-the-fly PDF generation of a node (DEPRECATED).',
);
?>