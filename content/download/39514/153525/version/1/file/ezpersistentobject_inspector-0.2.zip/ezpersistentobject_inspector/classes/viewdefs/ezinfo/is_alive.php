<?php
$viewdesc = array (
  'desc' => 'Provides information about the database connection.',
);
?>