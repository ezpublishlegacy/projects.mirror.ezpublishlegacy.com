<?php
$fetchdesc = array (
  'params' => 
  array (
    'code' => 
    array (
      'type' => 'string',
      'required' => true,
      'desc' => 'The three-character code of the target currency.',
    ),
  ),
  'return' => 'An ezcurrencydata object or FALSE.',
  'desc' => 'Fetches a currency object.',
);
?>