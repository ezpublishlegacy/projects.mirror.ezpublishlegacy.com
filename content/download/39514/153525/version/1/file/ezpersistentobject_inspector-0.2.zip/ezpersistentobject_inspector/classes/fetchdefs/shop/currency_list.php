<?php
$fetchdesc = array (
  'params' => 
  array (
    'status' => 
    array (
      'type' => 'string',
      'required' => false,
      'desc' => 'The status of the target currencies.',
    ),
  ),
  'return' => 'An array of ezcurrencydata objects or FALSE.',
  'desc' => 'Fetches the available currencies.',
);
?>