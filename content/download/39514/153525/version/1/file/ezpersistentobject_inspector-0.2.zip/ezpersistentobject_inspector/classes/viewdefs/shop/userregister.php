<?php
$viewdesc = array (
  'desc' => 'Provides an interface for registering a user.',
);
?>