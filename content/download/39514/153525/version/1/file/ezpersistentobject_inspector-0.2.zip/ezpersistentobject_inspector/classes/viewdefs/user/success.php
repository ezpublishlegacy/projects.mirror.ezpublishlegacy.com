<?php
$viewdesc = array (
  'desc' => 'Provides an interface that is called upon a successful user registration.',
);
?>