<?php
$viewdesc = array (
  'desc' => 'Provides an interface for uploading a file which will become a node.',
);
?>