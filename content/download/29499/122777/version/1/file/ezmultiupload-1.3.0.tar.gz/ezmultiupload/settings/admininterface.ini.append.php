<?php /*

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/ezmucontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/ezmusubitemscontextmenu.tpl
*/ ?>
