<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezmultiupload

ModuleList[]=ezmultiupload

*/ ?>
