<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en">
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation>Multi Upload</translation>
    </message>
</context>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multi Upload</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Erfolgreicher Upload der Dateien nach</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Dateien auswählen</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation type="obsolete">Flash-Content konnte nicht geladen werden. Sie können die neueste Flash-Player-Version downloaden über</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation type="obsolete">Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alle Dateien empfangen.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Bildvorschau erstellt.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation type="obsolete">Starte ...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation>Der Upload wurde abgebrochen.</translation>
    </message>
</context>
</TS>
