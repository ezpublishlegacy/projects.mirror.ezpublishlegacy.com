<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multiupload</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>De bestanden werden geüpload naar</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Bestanden selecteren</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Laden van Flashinhoud niet mogelijk. U kunt de laatste versie van Flash Player downloaden van</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alle bestanden ontvangen.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Miniatuur aangemaakt.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Begonnen...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
