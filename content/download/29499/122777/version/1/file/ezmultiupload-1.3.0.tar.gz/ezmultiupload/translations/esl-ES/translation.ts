<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multicarga</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Los archivos se van a cargar a </translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Seleccionar archivos</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>No se puede cargar el contenido Flash. Descargue la última versiónde Flash Player desde</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Centro de descargas de Adobe Flash Player</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Se han recibido todos los archivos.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Miniatura creada.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Iniciando...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
