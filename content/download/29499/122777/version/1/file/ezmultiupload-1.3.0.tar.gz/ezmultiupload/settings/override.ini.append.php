<?php /*

[line_thumbnail_image]
Source=node/view/line_thumbnail.tpl
MatchFile=line_thumbnail/image.tpl
Subdir=templates
Match[class_identifier]=image

[line_thumbnail_article]
Source=node/view/line_thumbnail.tpl
MatchFile=line_thumbnail/article.tpl
Subdir=templates
Match[class_identifier]=article

[line_thumbnail_flash_player]
Source=node/view/line_thumbnail.tpl
MatchFile=line_thumbnail/flash_player.tpl
Subdir=templates
Match[class_identifier]=flash_player

[line_thumbnail_file]
Source=node/view/line_thumbnail.tpl
MatchFile=line_thumbnail/file.tpl
Subdir=templates
Match[class_identifier]=file

*/ ?>