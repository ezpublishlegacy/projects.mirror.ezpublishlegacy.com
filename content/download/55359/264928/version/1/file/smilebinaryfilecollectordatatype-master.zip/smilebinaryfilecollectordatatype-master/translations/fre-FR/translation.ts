<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
  <name>kernel/classes/datatypes</name>
  
  <message>
    <source>Failed to store file. Only the following file types are allowed: %1.</source>
    <translation>Seuls les types de fichiers suivants sont autorisés: %1.</translation>
  </message>
  
</context>
</TS>
