<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=smilebinaryfilecollectordatatype
AvailableDataTypes[]=smilebinaryfile
*/ ?>
