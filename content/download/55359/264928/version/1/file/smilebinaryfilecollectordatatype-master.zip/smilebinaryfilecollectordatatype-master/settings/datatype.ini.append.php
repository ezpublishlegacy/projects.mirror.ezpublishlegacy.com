<?php /* #?ini charset="utf-8"?

[EditSettings]
GroupedInput[]=smilebinaryfile

[ViewSettings]
CustomActionMap[ActionDeleteSmileBinaryFile]=smilebinaryfile/deletebinary

*/ ?>