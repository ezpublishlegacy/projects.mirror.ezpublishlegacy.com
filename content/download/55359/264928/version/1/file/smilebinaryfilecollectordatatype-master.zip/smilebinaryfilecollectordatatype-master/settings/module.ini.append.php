<?php /* #?ini charset="utf-8"?


[ModuleSettings]
ExtensionRepositories[]=smilebinaryfilecollectordatatype
ModuleList[]=smilebinaryfile


*/ ?>

