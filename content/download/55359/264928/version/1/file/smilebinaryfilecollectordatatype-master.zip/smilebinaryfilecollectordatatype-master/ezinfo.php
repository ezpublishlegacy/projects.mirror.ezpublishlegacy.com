<?php
/**
 * ez_network info for copyright and version meta information
 *
 * @package smilematrix
 */
class smilematrixInfo
{
    static function info()
    {
        return array( 'Name' => 'smile binaryFile collector datatype',
                      'Version' => '0.1',
                      'Copyright' => 'Smile',
                      'License'   => '',
                     );
    }
}

?>
