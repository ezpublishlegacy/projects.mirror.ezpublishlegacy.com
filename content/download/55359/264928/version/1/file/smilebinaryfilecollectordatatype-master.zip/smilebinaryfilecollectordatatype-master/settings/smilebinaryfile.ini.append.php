<?php /* #?ini charset="utf-8"?

[AllowedFileTypes]
AllowedFileTypeList[]
AllowedFileTypeList[]=gif
AllowedFileTypeList[]=jpg
AllowedFileTypeList[]=jpeg
AllowedFileTypeList[]=jpe
AllowedFileTypeList[]=png
AllowedFileTypeList[]=txt
AllowedFileTypeList[]=doc
AllowedFileTypeList[]=pdf
AllowedFileTypeList[]=rar
AllowedFileTypeList[]=zip
AllowedFileTypeList[]=tgz
AllowedFileTypeList[]=bz2

AllowedFileMimeTypeList[]=image/gif
AllowedFileMimeTypeList[]=image/jpeg
AllowedFileMimeTypeList[]=image/png
AllowedFileMimeTypeList[]=text/plain
AllowedFileMimeTypeList[]=application/msword
AllowedFileMimeTypeList[]=application/pdf
AllowedFileMimeTypeList[]=application/x-rar
AllowedFileMimeTypeList[]=application/x-rar-compressed
AllowedFileMimeTypeList[]=application/zip
AllowedFileMimeTypeList[]=application/x-compressed-tar
AllowedFileMimeTypeList[]=application/x-bzip2
*/ ?>