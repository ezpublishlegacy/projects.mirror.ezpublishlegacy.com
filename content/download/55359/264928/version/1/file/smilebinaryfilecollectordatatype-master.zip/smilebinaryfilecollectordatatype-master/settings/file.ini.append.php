<?php /* #?ini charset="utf-8"?

# eZ Publish configuration file for file handling
#
# NOTE: It is not recommended to edit this files directly, instead
#       a file in override should be created for setting the
#       values that is required for your site. Either create
#       a file called settings/override/file.ini.append or
#       settings/override/file.ini.append.php for more security
#       in non-virtualhost modes (the .php file may already be present
#       and can be used for this purpose).

[smileBinaryFileSettings]
Handler=smileFilePassthroughHandler

*/ ?>