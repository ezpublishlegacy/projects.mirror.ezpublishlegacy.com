[ExtensionSettings]
DesignExtensions[]=easyadmin
