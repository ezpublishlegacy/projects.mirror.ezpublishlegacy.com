[ModuleSettings]
ExtensionRepositories[]=easyadmin
