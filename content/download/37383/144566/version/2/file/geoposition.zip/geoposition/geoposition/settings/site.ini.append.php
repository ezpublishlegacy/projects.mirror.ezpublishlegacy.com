<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=geoposition

*/
?>