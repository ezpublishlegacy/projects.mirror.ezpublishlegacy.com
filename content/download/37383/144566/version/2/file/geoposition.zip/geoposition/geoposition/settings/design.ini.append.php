<?php
/*

[ExtensionSettings]
DesignExtensions[]=geoposition
*/
?>
