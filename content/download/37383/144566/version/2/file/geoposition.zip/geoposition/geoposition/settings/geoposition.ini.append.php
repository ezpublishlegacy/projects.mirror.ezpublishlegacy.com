<?php /* #?ini charset="iso-8859-1"?

[vars]
#typeicon=.swf
typeicon=.jpg
*/ ?>
