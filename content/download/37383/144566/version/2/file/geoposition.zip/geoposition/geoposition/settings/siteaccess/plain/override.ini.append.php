<?php /* #?ini charset="iso-8859-1"?

[line_geopositionnement]
Source=node/view/line.tpl
MatchFile=line/map.tpl
Subdir=templates
Match[class_identifier]=geoposition

[full_geopositionnement]
Source=node/view/full.tpl
MatchFile=full/map.tpl
Subdir=templates
Match[class_identifier]=geoposition

[full_spot]
Source=node/view/full.tpl
MatchFile=full/spot.tpl
Subdir=templates
Match[class_identifier]=spot

[line_spot]
Source=node/view/line.tpl
MatchFile=line/spot.tpl
Subdir=templates
Match[class_identifier]=spot





*/ ?>