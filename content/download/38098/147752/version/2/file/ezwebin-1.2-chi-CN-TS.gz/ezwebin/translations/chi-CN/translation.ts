<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<context>
    <name>design/ezwebin/article/article_index</name>
    <message>
        <location filename="" line="0"/>
        <source>Article index</source>
<translation>文章索引</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/article/comments</name>
    <message>
        <location filename="" line="0"/>
        <source>Comments</source>
<translation>评论</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New comment</source>
<translation>新建评论</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
<translation>评论之前先%login_link_start登录%login_link_end或%create_link_start创建一个新的用户%create_link_end</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/calendar</name>
    <message>
        <location filename="" line="0"/>
        <source>Previous month</source>
<translation>上个月</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Next month</source>
<translation>下个月</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Calendar</source>
<translation>日历</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Mon</source>
<translation>星期一</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Tue</source>
<translation>星期二</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Wed</source>
<translation>星期三</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Thu</source>
<translation>星期四</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Fri</source>
<translation>星期五</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sat</source>
<translation>星期六</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sun</source>
<translation>星期日</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/extra_info</name>
    <message>
        <location filename="" line="0"/>
        <source>Tags</source>
<translation>标签</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Archive</source>
<translation>存档</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <location filename="" line="0"/>
        <source>Form %formname</source>
<translation>表单%formname</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Thank you for your feedback.</source>
<translation>谢谢您的反馈。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have already submitted this form. The data you entered was:</source>
<translation>您已经提交了表单。您输入的数据是：</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Return to site</source>
<translation>返回站点</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/poll</name>
    <message>
        <location filename="" line="0"/>
        <source>Poll %pollname</source>
<translation>投票%pollname</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Results</source>
<translation>结果</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please log in to vote on this poll.</source>
<translation>投票之前请先登录。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have already voted for this poll.</source>
<translation>您已经投过票了。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Votes</source>
<translation>票数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%count total votes</source>
<translation>总票数%count</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back to poll</source>
<translation>返回投票</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/feedback</name>
    <message>
        <location filename="" line="0"/>
        <source>Feedback from %1</source>
<translation>反馈表单%1</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following feedback was collected</source>
<translation>以下反馈已被收录</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/form</name>
    <message>
        <location filename="" line="0"/>
        <source>Collected information from %1</source>
<translation>已被收录的信息表%1</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following information was collected</source>
<translation>以下信息已被收录</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearch</name>
    <message>
        <location filename="" line="0"/>
        <source>Advanced search</source>
<translation>高级搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search all the words</source>
<translation>全文搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search the exact phrase</source>
<translation>关键字搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search with at least one of the words</source>
<translation>模糊搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Published</source>
<translation>已发布的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Any time</source>
<translation>任一时间</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last day</source>
<translation>最近一天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last week</source>
<translation>最近一周</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last three months</source>
<translation>最近三个月</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last year</source>
<translation>最近一年</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Display per page</source>
<translation>每页显示</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>5 items</source>
<translation>5条</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>10 items</source>
<translation>10条</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>20 items</source>
<translation>20条</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>30 items</source>
<translation>30条</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>50 items</source>
<translation>50条</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search</source>
<translation>搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No results were found when searching for &quot;%1&quot;</source>
<translation>没有找到与&quot;%1&quot;匹配的结果</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
<translation>搜索&quot;%1&quot;找到%2个结果</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearchh</name>
    <message>
        <location filename="" line="0"/>
        <source>Last month</source>
<translation>最近一个月</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse</name>
    <message>
        <location filename="" line="0"/>
        <source>Browse</source>
<translation>浏览</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
<translation>选择对象，要选择适当的单选按钮或复选框，并点击&quot;选择&quot;按钮。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>To select an object that is a child of one of the displayed objects, click the parent object name to display a list of its children.</source>
<translation>要选择一个对象的子对象，点击父对象的名称来显示它的孩子列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back</source>
<translation>返回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Top level</source>
<translation>上一级</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select</source>
<translation>选择</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse_mode_list</name>
    <message>
        <location filename="" line="0"/>
        <source>Invert selection</source>
<translation>反选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
<translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type</source>
<translation>类型</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/diff</name>
    <message>
        <location filename="" line="0"/>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
<translation>&lt;%object_name&gt;的版本数［%version_count］</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version</source>
<translation>版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
<translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Translations</source>
<translation>翻译</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
<translation>创建者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Modified</source>
<translation>修改者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Draft</source>
<translation>草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Published</source>
<translation>已发布的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Pending</source>
<translation>处理中</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Archived</source>
<translation>已存档的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Rejected</source>
<translation>被拒绝的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Untouched draft</source>
<translation>未处理的草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object does not have any versions.</source>
<translation>该对象没有任何版本。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show differences</source>
<translation>显示差异</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Differences between versions %oldVersion and %newVersion</source>
<translation>版本%oldVersion和%newVersion的差异</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Old version</source>
<translation>旧版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Inline changes</source>
<translation>行内更改</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Block changes</source>
<translation>块级更改</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New version</source>
<translation>新版本</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/draft</name>
    <message>
        <location filename="" line="0"/>
        <source>Select all</source>
<translation>选定所有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Deselect all</source>
<translation>取消选定所有</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My drafts</source>
<translation>我的草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Empty draft</source>
<translation>清空草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
<translation>这些是您现在处理的对象。这些草稿归您所有并且只被您所见。你可以编辑这些草稿，如果您不再需要这些草稿您也可以删除它们。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
<translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Class</source>
<translation>类</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Section</source>
<translation>分区</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version</source>
<translation>版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Language</source>
<translation>语言</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last modified</source>
<translation>最后修改于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
<translation>删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have no drafts</source>
<translation>您没有任何草稿</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit %1 - %2</source>
<translation>编辑%1-%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
<translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store draft</source>
<translation>保存草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard draft</source>
<translation>放弃草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Manage versions</source>
<translation>管理版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store and exit</source>
<translation>保存并退出</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Preview</source>
<translation>预览</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Translate from</source>
<translation>翻译</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Translate</source>
<translation>翻译</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Documentation</source>
<translation>文档</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <location filename="" line="0"/>
        <source>Not translatable</source>
<translation>不能翻译</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Required</source>
<translation>必需的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Information collector</source>
<translation>信息收集器</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_draft</name>
    <message>
        <location filename="" line="0"/>
        <source>The currently published version is %version and was published at %time.</source>
<translation>当前的版本是%version已经在%time时被发布了。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The last modification was done at %modified.</source>
<translation>最后修改于%modified。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The object is owned by %owner.</source>
<translation>该对象归%owner所有。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object is already being edited by yourself and others.
    You can either continue editing one of your drafts or you can create a new draft.</source>
<translation>该对象正在被您或其他人编辑。你可以继续编辑您的草稿或创建一个新的草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
<translation>该对象正在被您编辑。你可以继续编辑您的草稿或创建一个新的草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object is already being edited by someone else.
        You should either contact the person about their draft or create a new draft for your own use.</source>
<translation>该对象正在被其他人编辑。您可以联系此人或创建一个您自己的草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Current drafts</source>
<translation>当前草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version</source>
<translation>版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
<translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Owner</source>
<translation>所有者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
<translation>创建于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last modified</source>
<translation>最后修改于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New draft</source>
<translation>新建草稿</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_languages</name>
    <message>
        <location filename="" line="0"/>
        <source>Existing languages</source>
<translation>当前语言</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select the language you want to use when editing the object.</source>
<translation>选择您编辑对象时要使用的语言。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New languages</source>
<translation>新建语言</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select the language you want to add to the object.</source>
<translation>选择您要添加到对象中的语言。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select the language the new translation will be based on.</source>
<translation>选择翻译对照的语言。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Use an empty, untranslated draft</source>
<translation>使用空的，未翻译的草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have permission to create a translation in another language.</source>
<translation>您没有权限创建其他语言的翻译。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>However, you can select one of the following languages for editing.</source>
<translation>但是您可以选择以下的语言来编辑。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You do not have permission to edit the object in any available languages.</source>
<translation>您没有权限用任何的语言来编辑对象。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/history</name>
    <message>
        <location filename="" line="0"/>
        <source>Version not a draft</source>
<translation>该版本不是草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version %1 is not available for editing anymore. Only drafts can be edited.</source>
<translation>版本%1不能被任何人编辑，只有草稿可以被编辑。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>To edit this version, first create a copy of it.</source>
<translation>要编辑这个版本，先要创建一个该版本的拷贝。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version not yours</source>
<translation>不是您的版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version %1 was not created by you. Only your own drafts can be edited.</source>
<translation>您不能编辑版本%1。您只能编辑您自己的草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unable to create new version</source>
<translation>不能创建新的版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
<translation>版本历史记录已超出，系统中没有可删除的存档。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You can either change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
<translation>您可以在content.ini中更改您的版本历史记录，删除草稿或编辑现有草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
<translation>&lt;%object_name&gt;的版本数［%version_count］</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Toggle selection</source>
<translation>反向选择</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version</source>
<translation>版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Status</source>
<translation>状态</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edited language</source>
<translation>已编辑的语言</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Creator</source>
<translation>创建者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created</source>
<translation>创建于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Modified</source>
<translation>修改于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select version #%version_number for removal.</source>
<translation>选择要删除的版本#%version_number。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Version #%version_number cannot be removed because it is either the published version of the object or because you do not have permission to remove it.</source>
<translation>版本#%version_number不能被删除，因为它是对象的发布版本或您没有权限删除该版本。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>View the contents of version #%version_number. Translation? %translation.</source>
<translation type="obsolete">查看版本#%version_number的内容。翻译：%translation。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Draft</source>
<translation>草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Published</source>
<translation>已发布的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Pending</source>
<translation>处理中的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Archived</source>
<translation>已存档的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Rejected</source>
<translation>被拒绝的</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Untouched draft</source>
<translation>未处理的草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There is no need to do a copies of untouched drafts.</source>
<translation>没有必要创建一个未处理草稿的拷贝。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create a copy of version #%version_number.</source>
<translation>创建版本#%version_number的一个拷贝。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You cannot make copies of versions because you do not have permission to edit the object.</source>
<translation>您不能创建该版本的任何拷贝，因为您没有权限编辑这个对象。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit the contents of version #%version_number.</source>
<translation>编辑版本#%version_number的内容。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You cannot edit the contents of version #%version_number either because it is not a draft or because you do not have permission to edit the object.</source>
<translation>您不能编辑版本#%version_number的内容，因为这不是一个草稿或您没有编辑该对象的权限。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object does not have any versions.</source>
<translation>该对象没有任何版本。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove selected</source>
<translation>删除所选</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove the selected versions from the object.</source>
<translation>从对象中删除选定的版本。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Show differences</source>
<translation>显示差别</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back</source>
<translation>返回</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Published version</source>
<translation>已发布的版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Translations</source>
<translation>翻译</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New drafts [%newerDraftCount]</source>
<translation>新建草稿［%newerDraftCount］</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This object does not have any drafts.</source>
<translation>该对象没有任何草稿。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Differences between versions %oldVersion and %newVersion</source>
<translation>版本%oldVersion和%newVersion之间的差别</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Old version</source>
<translation>旧版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Inline changes</source>
<translation>行内更改</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Block changes</source>
<translation>块级更改</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New version</source>
<translation>新版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back to history</source>
<translation>返回到历史记录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
<translation>查看内容。版本#%version_number。翻译：%translation。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/keyword</name>
    <message>
        <location filename="" line="0"/>
        <source>Keyword: %keyword</source>
<translation>关键字：%keyword</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Link</source>
<translation>链接</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Type</source>
<translation>类型</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <location filename="" line="0"/>
        <source>Search</source>
<translation>搜索</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
<translation>更多选项请选择%1高级搜索%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following words were excluded from the search:</source>
<translation>下列单词不在搜索中：</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>No results were found when searching for &quot;%1&quot;.</source>
<translation>搜索&quot;%1&quot;找不到结果。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search tips</source>
<translation>搜索技巧</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Check spelling of keywords.</source>
<translation>检查关键字的拼写。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Try changing some keywords (eg, &quot;car&quot; instead of &quot;cars&quot;).</source>
<translation>试着更改一些关键字（例如，用&quot;car&quot;代替&quot;cars&quot;）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Try searching with less specific keywords.</source>
<translation>尽量使用较少的指定的关键字搜索。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Reduce number of keywords to get more results.</source>
<translation>要得到更多的结果要减少关键字的数量。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
<translation>搜索&quot;%1&quot;返回%2个结果。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/tipafriend</name>
    <message>
        <location filename="" line="0"/>
        <source>Tip a friend</source>
<translation>推荐给朋友</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The message was sent.</source>
<translation>信息已经发送。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Click here to return to the original page.</source>
<translation>点击这里返回原始的页面。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The message was not sent.</source>
<translation>信息没有发送。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
<translation>信息没有发送因为一个未知错误。请通知给站点的管理员关于这个错误的信息。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please correct the following errors:</source>
<translation>请纠正以下错误：</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your name</source>
<translation>您的名字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your email address</source>
<translation>您的email地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Recipient&apos;s email address</source>
<translation>收件人的email地址</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Comment</source>
<translation>注释</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send</source>
<translation>发送</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/view/versionview</name>
    <message>
        <location filename="" line="0"/>
        <source>Manage versions</source>
<translation>管理版本</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Publish</source>
<translation>发布</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/comment</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit %1 - %2</source>
<translation>编辑%1-%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
<translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
<translation>放弃</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/file</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit %1 - %2</source>
<translation>编辑%1-%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
<translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
<translation>放弃</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_reply</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit %1 - %2</source>
<translation>编辑%1-%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
<translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
<translation>放弃</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_topic</name>
    <message>
        <location filename="" line="0"/>
        <source>Edit %1 - %2</source>
<translation>编辑%1-%2</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Send for publishing</source>
<translation>发布</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
<translation>放弃</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/forum</name>
    <message>
        <location filename="" line="0"/>
        <source>Latest from</source>
<translation>最后回复</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/poll</name>
    <message>
        <location filename="" line="0"/>
        <source>Vote</source>
<translation>投票</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezinfo/about</name>
    <message>
        <location filename="" line="0"/>
        <source>eZ Publish information: %version</source>
<translation>eZ Publish的信息：%version</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>What is eZ Publish?</source>
<translation>什么是eZ Publish？</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Licence</source>
<translation>许可</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Contributors</source>
<translation>贡献者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Copyright Notice</source>
<translation>版权信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Third-Party Software</source>
<translation>第三方软件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Extensions</source>
<translation>扩展</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <location filename="" line="0"/>
        <source>Comments</source>
<translation>评论</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New comment</source>
<translation>新建评论</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
<translation>评论之前请先%login_link_start登录%login_link_end或%create_link_start创建一个用户%create_link_end。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Tip a friend</source>
<translation>推荐给朋友</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_mainpage</name>
    <message>
        <location filename="" line="0"/>
        <source>Tip a friend</source>
<translation>推荐给朋友</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_subpage</name>
    <message>
        <location filename="" line="0"/>
        <source>Tip a friend</source>
<translation>推荐给朋友</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/blog_post</name>
    <message>
        <location filename="" line="0"/>
        <source>Tags:</source>
<translation>标签：</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Comments</source>
<translation>评论</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
<translation>评论之前请先%login_link_start登录%login_link_end或%create_link_start创建一个用户%create_link_end。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/documentation_page</name>
    <message>
        <location filename="" line="0"/>
        <source>Table of contents</source>
<translation>内容表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Created:</source>
<translation>创建于：</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Modified:</source>
<translation>修改于：</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event</name>
    <message>
        <location filename="" line="0"/>
        <source>Category</source>
<translation>类别</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_calendar</name>
    <message>
        <location filename="" line="0"/>
        <source>Mon</source>
<translation>星期一</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Tue</source>
<translation>星期二</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Wed</source>
<translation>星期三</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Thu</source>
<translation>星期四</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Fri</source>
<translation>星期五</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sat</source>
<translation>星期六</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sun</source>
<translation>星期日</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Today</source>
<translation>今天</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Category</source>
<translation>类别</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_program</name>
    <message>
        <location filename="" line="0"/>
        <source>Past events</source>
<translation>过去的事件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Future events</source>
<translation>将来的事件</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/feedback_form</name>
    <message>
        <location filename="" line="0"/>
        <source>Send form</source>
<translation>发送表格</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <location filename="" line="0"/>
        <source>New topic</source>
<translation>新建主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Keep me updated</source>
<translation>订阅更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
<translation>访问论坛前请先登录。您可以点击%login_link_start%这里%login_link_end%登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Topic</source>
<translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Replies</source>
<translation>回复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Author</source>
<translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last reply</source>
<translation>最后回复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Pages</source>
<translation>页数</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_reply</name>
    <message>
        <location filename="" line="0"/>
        <source>Message preview</source>
<translation>信息预览</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Author</source>
<translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Topic</source>
<translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Location</source>
<translation>位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Moderated by</source>
<translation>版主</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_topic</name>
    <message>
        <location filename="" line="0"/>
        <source>Previous topic</source>
<translation>上一个主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Next topic</source>
<translation>下一个主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New reply</source>
<translation>新建回复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Keep me updated</source>
<translation>订阅更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
<translation>访问论坛前请先登录。您可以点击%login_link_start%这里%login_link_end%登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Author</source>
<translation>作者</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Message</source>
<translation>信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Location</source>
<translation>位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Moderated by</source>
<translation>版主</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit</source>
<translation>编辑</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
<translation>删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove this item.</source>
<translation>删除该条</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forums</name>
    <message>
        <location filename="" line="0"/>
        <source>Topics</source>
<translation>主题</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Posts</source>
<translation>帖子</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last reply</source>
<translation>最后回复</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/gallery</name>
    <message>
        <location filename="" line="0"/>
        <source>View as slideshow</source>
<translation>以幻灯片的方式查看</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/image</name>
    <message>
        <location filename="" line="0"/>
        <source>Previous image</source>
<translation>上一张图片</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Next image</source>
<translation>下一张图片</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/multicalendar</name>
    <message>
        <location filename="" line="0"/>
        <source>Event</source>
<translation>事件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Start date</source>
<translation>开始日期</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Category</source>
<translation>类别</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Description</source>
<translation>描述</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/poll</name>
    <message>
        <location filename="" line="0"/>
        <source>Vote</source>
<translation>投票</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Result</source>
<translation>结果</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <location filename="" line="0"/>
        <source>Add to basket</source>
<translation>添加到购物车</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add to wish list</source>
<translation>添加到希望列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>People who bought this also bought</source>
<translation>购买此商品的用户还购买了</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event</name>
    <message>
        <location filename="" line="0"/>
        <source>Category</source>
<translation>类别</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event_calendar</name>
    <message>
        <location filename="" line="0"/>
        <source>Next events</source>
<translation>下一个事件</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/flash</name>
    <message>
        <location filename="" line="0"/>
        <source>View flash</source>
<translation>观看flash</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum</name>
    <message>
        <location filename="" line="0"/>
        <source>Number of topics</source>
<translation>主题数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Number of posts</source>
<translation>帖子数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last reply</source>
<translation>最后回复</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Enter forum</source>
<translation>进入论坛</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum_reply</name>
    <message>
        <location filename="" line="0"/>
        <source>Reply to:</source>
<translation>回复：</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/poll</name>
    <message>
        <location filename="" line="0"/>
        <source>%count votes</source>
<translation>%count票</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Vote</source>
<translation>投票</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/quicktime</name>
    <message>
        <location filename="" line="0"/>
        <source>View movie</source>
<translation>观看影片</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/real_video</name>
    <message>
        <location filename="" line="0"/>
        <source>View movie</source>
<translation>观看影片</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/windows_media</name>
    <message>
        <location filename="" line="0"/>
        <source>View movie</source>
<translation>观看影片</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/link</name>
    <message>
        <location filename="" line="0"/>
        <source>%sitetitle front page</source>
<translation>%sitetitle首页</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Search %sitetitle</source>
<translation>搜索%sitetitle</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Printable version</source>
<translation>可打印的版本</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/node/removeobject</name>
    <message>
        <location filename="" line="0"/>
        <source>Are you sure you want to remove these items?</source>
<translation>您确定要删除这些项目吗？</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%nodename and its %childcount children. %additionalwarning</source>
<translation>%nodename和它的孩子%childcount。%additionalwarning</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>%nodename %additionalwarning</source>
<translation>%nodename%additionalwarning</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Move to trash</source>
<translation>移动到回收站</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Note</source>
<translation>注意</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>If %trashname is checked, removed items can be found in the trash.</source>
<translation>如果确认%trashname，删除的项目可以在回收站中找到。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm</source>
<translation>确认</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/addingresult</name>
    <message>
        <location filename="" line="0"/>
        <source>Add to my notifications</source>
<translation>添加到我的通告中</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
<translation>节点&lt;%node_name&gt;的通告已经存在。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
<translation>成功添加节点&lt;%node_name&gt;的通告。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
<translation>确认</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/settings</name>
    <message>
        <location filename="" line="0"/>
        <source>Notification settings</source>
<translation>通告设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store</source>
<translation>保存</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/pagelayout</name>
    <message>
        <location filename="" line="0"/>
        <source>Search</source>
<translation>搜索</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/parts/website_toolbar</name>
    <message>
        <location filename="" line="0"/>
        <source>About</source>
<translation>关于</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Create here</source>
<translation>在此创建</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit: %node_name [%class_name]</source>
<translation>编辑：%node_name［%class_name］</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Move</source>
<translation>移动</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
<translation>删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Add locations</source>
<translation>添加位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Documentation</source>
<translation>文档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Replace</source>
<translation>替换</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Export</source>
<translation>导出</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import</source>
<translation>导入</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/settings/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>Node notification</source>
<translation>节点通告</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
<translation>名称</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Class</source>
<translation>类</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Section</source>
<translation>分区</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select</source>
<translation>选择</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
<translation>删除</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <location filename="" line="0"/>
        <source>Shopping basket</source>
<translation>购物车</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Account information</source>
<translation>帐户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm order</source>
<translation>确认定单</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Basket</source>
<translation>购物车</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The following items were removed from your basket because the products were changed.</source>
<translation>因为商品已经更改，以下商品将从您的购物车中删除。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VAT is unknown</source>
<translation>增值税未知</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VAT percentage is not yet known for some of the items being purchased.</source>
<translation>正在购买的商品中有些增值税未知。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
<translation>这可能意味着不能获得商品的一些信息，这些信息将在付款后获得。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Attempted to add object without price to basket.</source>
<translation>试图添加没有单价的商品到购物车。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your payment was aborted.</source>
<translation>您付款失败。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Count</source>
<translation>数量</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VAT</source>
<translation>增值税</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Price inc. VAT</source>
<translation>单价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discount</source>
<translation>折扣</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price ex. VAT</source>
<translation>总价（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price inc. VAT</source>
<translation>总价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unknown</source>
<translation>未知</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Update</source>
<translation>更新</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove</source>
<translation>删除</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Selected options</source>
<translation>选定的项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subtotal ex. VAT</source>
<translation>小计（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subtotal inc. VAT</source>
<translation>小计（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Shipping</source>
<translation>购物</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order total</source>
<translation>订单总数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Continue shopping</source>
<translation>继续购物</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Checkout</source>
<translation>结帐</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You have no products in your basket.</source>
<translation>您的购物车中没有商品。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/confirmorder</name>
    <message>
        <location filename="" line="0"/>
        <source>Shopping basket</source>
<translation>购物车</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Account information</source>
<translation>帐户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm order</source>
<translation>确认订单</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Product items</source>
<translation>商品条目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Count</source>
<translation>数量</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VAT</source>
<translation>增值税</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Price inc. VAT</source>
<translation>单价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discount</source>
<translation>折扣</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price ex. VAT</source>
<translation>总价（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price inc. VAT</source>
<translation>总价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Selected options</source>
<translation>选定的项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order summary</source>
<translation>订单概要</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subtotal of items</source>
<translation>商品小计</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order total</source>
<translation>订单总数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm</source>
<translation>确认</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/customerorderview</name>
    <message>
        <location filename="" line="0"/>
        <source>Customer information</source>
<translation>顾客信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order list</source>
<translation>订单列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
<translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Date</source>
<translation>日期</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total ex. VAT</source>
<translation>总价（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total inc. VAT</source>
<translation>总价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Purchase list</source>
<translation>购买列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Product</source>
<translation>商品</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Amount</source>
<translation>数量</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderlist</name>
    <message>
        <location filename="" line="0"/>
        <source>Order list</source>
<translation>订单列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sort result by</source>
<translation>结果排序按</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order time</source>
<translation>订购时间</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>User name</source>
<translation>用户名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order ID</source>
<translation>订单ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Ascending</source>
<translation>升序</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sort ascending</source>
<translation>升序排列</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Descending</source>
<translation>降序</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sort descending</source>
<translation>降序排列</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sort</source>
<translation>排序</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>ID</source>
<translation>ID</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Date</source>
<translation>日期</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Customer</source>
<translation>顾客</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total ex. VAT</source>
<translation>总价（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total inc. VAT</source>
<translation>总价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The order list is empty</source>
<translation>订单列表为空</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Archive</source>
<translation>存档</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderview</name>
    <message>
        <location filename="" line="0"/>
        <source>Order %order_id [%order_status]</source>
<translation>订单%order_id［%order_status］</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Product items</source>
<translation>商品条目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Product</source>
<translation>商品</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Count</source>
<translation>数量</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>VAT</source>
<translation>增值税</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Price inc. VAT</source>
<translation>单价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discount</source>
<translation>折扣</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price ex. VAT</source>
<translation>总价（税前）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Total price inc. VAT</source>
<translation>总价（税后）</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order summary</source>
<translation>订单概要</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Summary</source>
<translation>概要</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Subtotal of items</source>
<translation>商品小计</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order total</source>
<translation>订单总数</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Order history</source>
<translation>订单历史记录</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/userregister</name>
    <message>
        <location filename="" line="0"/>
        <source>Shopping basket</source>
<translation>购物车</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Account information</source>
<translation>帐户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Confirm order</source>
<translation>确认订单</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your account information</source>
<translation>您的帐户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Input did not validate. All fields marked with * must be filled in.</source>
<translation>输入非法。所有标有*的字段必须填写。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>First name</source>
<translation>名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Last name</source>
<translation>姓</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
<translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Company</source>
<translation>公司</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Street</source>
<translation>街道</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Zip</source>
<translation>邮编</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Place</source>
<translation>位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>State</source>
<translation>州</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Country</source>
<translation>国家</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Comment</source>
<translation>注释</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Continue</source>
<translation>继续</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>All fields marked with * must be filled in.</source>
<translation>所有标有*的字段必须填写。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/wishlist</name>
    <message>
        <location filename="" line="0"/>
        <source>Wish list</source>
<translation>希望列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Product</source>
<translation>商品</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Count</source>
<translation>数量</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Selected options</source>
<translation>选定的项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Store</source>
<translation>保存</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remove items</source>
<translation>删除项目</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Empty wish list</source>
<translation>清空希望列表</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/simplified_treemenu/show_simplified_menu</name>
    <message>
        <location filename="" line="0"/>
        <source>Fold/Unfold</source>
<translation>折叠／展开</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Node ID: %node_id Visibility: %visibility</source>
<translation>节点ID：%node_id可见性：%visibility</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/activate</name>
    <message>
        <location filename="" line="0"/>
        <source>Activate account</source>
<translation>激活帐户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your account is now activated.</source>
<translation>您的帐户现在已被激活。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your account is already active.</source>
<translation>您的帐户已经激活。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
<translation>对不起，您提交的答案不是一个有效的答案。帐户没有被激活。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
<translation>确认</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <location filename="" line="0"/>
        <source>User profile</source>
<translation>用户信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Username</source>
<translation>用户名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
<translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Name</source>
<translation>名字</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My drafts</source>
<translation>我的草稿</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My orders</source>
<translation>我的订单</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My notification settings</source>
<translation>我的通告设置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>My wish list</source>
<translation>我的希望列表</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Edit profile</source>
<translation>编辑个人信息</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Change password</source>
<translation>更改密码</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/forgotpassword</name>
    <message>
        <location filename="" line="0"/>
        <source>An email has been sent to the following address: %1. It contains a link you need to click so that we can confirm that the correct user has received the new password.</source>
<translation>已经向下列地址：%1发送了一封邮件。里面包含一个链接，您可以点击该链接，这样我们可以确认用户收到了新的密码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>There is no registered user with that email address.</source>
<translation>该电子邮件地址没有被注册。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password was successfully generated and sent to: %1</source>
<translation>成功生成密码并发送到：%1</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The key is invalid or has been used. </source>
<translation>该答案非法或已经被使用。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Have you forgotten your password?</source>
<translation>忘记密码？</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>If you have forgotten your password, enter your email address and we will create a new password and send it to you.</source>
<translation>如果忘记密码，输入您的电子邮件地址，我们将为您创建一个新的密码并发送给您。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Email</source>
<translation>电子邮件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Generate new password</source>
<translation>生成新的密码</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/login</name>
    <message>
        <location filename="" line="0"/>
        <source>Login</source>
<translation>登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Could not login</source>
<translation>不能登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>A valid username and password is required to login.</source>
<translation>登录需要有效的用户名和密码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Access not allowed</source>
<translation>访问被拒绝</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You are not allowed to access %1.</source>
<translation>您不能访问%1。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Username</source>
        <comment>User name</comment>
<translation>用户名</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password</source>
<translation>密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Log in to the eZ Publish Administration Interface</source>
<translation>登录到eZ Publish的管理员界面</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Remember me</source>
<translation>记住密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Login</source>
        <comment>Button</comment>
<translation>登录</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Sign up</source>
        <comment>Button</comment>
<translation>注册</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Forgot your password?</source>
<translation>忘记密码？</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/password</name>
    <message>
        <location filename="" line="0"/>
        <source>Change password for user</source>
<translation>修改用户密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please retype your old password.</source>
<translation>请重复输入您的旧密码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password didn&apos;t match, please retype your new password.</source>
<translation>密码不匹配。请重新输入您的新密码。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Password successfully updated.</source>
<translation>密码更新成功。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Old password</source>
<translation>旧密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>New password</source>
<translation>新密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Retype password</source>
<translation>重复输入密码</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OK</source>
<translation>确认</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Cancel</source>
<translation>取消</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <location filename="" line="0"/>
        <source>Register user</source>
<translation>注册用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Input did not validate</source>
<translation>输入非法</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Input was stored successfully</source>
<translation>输入成功保存</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Register</source>
<translation>注册</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Discard</source>
<translation>放弃</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Unable to register new user</source>
<translation>不能注册新用户</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Back</source>
<translation>返回</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/success</name>
    <message>
        <location filename="" line="0"/>
        <source>User registered</source>
<translation>用户已注册</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your account was successfully created. An email will be sent to the specified address. Follow the instructions in that email to activate your account.</source>
<translation>您的帐户已被成功创建。将有一封电子邮件发送到指定地址。按照邮件中的指令来激活您的帐户。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your account was successfully created.</source>
<translation>您的帐户已成功创建。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <location filename="" line="0"/>
        <source>The file could not be found.</source>
<translation>找不到文件。</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezprice</name>
    <message>
        <location filename="" line="0"/>
        <source>Price</source>
<translation>单价</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Your price</source>
<translation>您的单价</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You save</source>
<translation>您保存</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/sitemap</name>
    <message>
        <location filename="" line="0"/>
        <source>Site map</source>
<translation>站点地图</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <location filename="" line="0"/>
        <source>No media file is available.</source>
<translation>没有可用的媒体文件。</translation>
    </message>
</context>
<context>
    <name>extension/ezodf</name>
    <message>
        <location filename="" line="0"/>
        <source>OpenOffice.org export</source>
<translation>OpenOffice.org导出</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Export eZ publish content to OpenOffice.org</source>
<translation>将eZ Publish内容导出为OpenOffice.org</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Error</source>
<translation>错误</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Here you can export any eZ publish content object to an OpenOffice.org Writer document format.</source>
<translation>您可以把eZ Publish内容导出为OpenOffice.org字处理文档。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Export Object</source>
<translation>导出对象</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Document is now imported</source>
<translation>文档导入成功</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>OpenOffice.org import</source>
<translation>OpenOffice.org导入</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The object was imported as: %class_name</source>
<translation>该对象被导入为：%class_name</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Document imported as</source>
<translation>文档导入为</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>The images are placed in the media and can be re-used.</source>
<translation>图片被保存在媒体库并且可以重用。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import another document</source>
<translation>导入另一个文档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Upload file</source>
<translation>上传文件</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import OpenOffice.org document</source>
<translation>导入OpenOffice.org文档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Replace document</source>
<translation>替换文档</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Import to</source>
<translation>导入到</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>You can import OpenOffice.org Writer documents directly into eZ publish from this page. You are
asked where to place the document and eZ publish does the rest. The document is converted into
the appropriate class during the import, you get a notice about this after the import is done.
Images are placed in the media library so you can re-use them in other articles.</source>
<translation>您可以在这个页面直接将OpenOffice字处理文档导入eZ Publish。您只需要选择导入的位置，eZ Publish会完成剩下的工作。在导入的过程中，文档会被转换为适当的类。导入成功后，系统将会通知您转换的细节。图片会被保存在媒体库，以方便您在其它内容中重用。</translation>
    </message>
</context>
<context>
    <name>extension/ezodf/browse</name>
    <message>
        <location filename="" line="0"/>
        <source>Choose document placement</source>
<translation>选择文档位置</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Please choose the placement for the OpenOffice.org object.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>请选择OpenOffice.org对象的保存位置。选择位置并点击%buttonname按钮。您也可以使用最近使用项目和书签。点击位置名称以改变浏览列表。</translation>
    </message>
    <message>
        <location filename="" line="0"/>
        <source>Select</source>
<translation>选择</translation>
    </message>
</context>
</TS>
