<?

class SerialOperator
{
    /*!
      Constructeur, par d�faut ne fait rien.
    */
    function SerialOperator()
    {
    }

    /*!
     eturn an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'getUnserialized' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'getUnserialized' => array( 'value' => array( 'type' => 'string',
                                                                           'required' => false,
                                                                           'default' => 'default text' ) 
                                                ) );
    }
    /*!
     Ex�cute la fonction PHP correspondant � l'op�rateur "cleanup" et modifie \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'getUnserialized':
            {
            	//eZDebug::writeDebug($operatorParameters);
                $operatorValue = $this->getUnserialized($namedParameters['value']);
            } break;
        }
    }
    
    
    function getUnserialized($value)
    {
    	return unserialize($value);
    }
    
}
?>