<?php

  $Module = array (
    'name' => 'smileworkflowboard',
    'variable_params' => true
  );
  
  $ViewList = array ();
  
  $ViewList['action'] = array (
    'script' => 'action.php',
    'params' => array( 'action', 'param'),
    'default_navigation_part' => 'smileworkflowboardnavigationpart'
  );
  $ViewList['message'] = array (
    'script' => 'message.php',
    'params' => array('message', 'string' ),
    'default_navigation_part' => 'smileworkflowboardnavigationpart'
  );
  $ViewList['list'] = array (
    'script' => 'list.php',
    'params' => array(  ),
    'functions'=> array('read'),
    'default_navigation_part' => 'smileworkflowboardnavigationpart'
  );
  $ViewList['view'] = array (
    'script' => 'view.php',
    'params' => array( 'process_id' ),
    'functions'=> array('read'),
    'default_navigation_part' => 'smileworkflowboardnavigationpart'
  );
	$ViewList['remove'] = array (
    'script' => 'remove.php',
    'params' => array('process_id', 'accept' ),
    'functions'=> array('remove'),
    'default_navigation_part' => 'smileworkflowboardnavigationpart'
  );
	
  $FunctionList = array();
  $FunctionList['read'] = array();
  $FunctionList['remove'] = array();

?>