<?php

include_once( 'kernel/common/template.php' );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "kernel/classes/ezworkflow.php" );
include_once( "kernel/classes/ezworkflowgrouplink.php" );
include_once( "kernel/classes/ezworkflowprocess.php" );

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation()
{
	include_once('lib/ezdb/classes/ezdb.php');
	$db=eZDb::instance();
	$query="SELECT wp.id as wp_id, w.id as wf_id " .
			"FROM ezworkflow_process wp, ezworkflow w " .
			"WHERE wp.workflow_id = w.id " .
			" AND  w.version = 0 " .
			"ORDER BY wp.created DESC";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else 
	{
		return false;
	}
}
/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
$tpl =& templateInit();
$wi =getWorkflowsInformation();
$result=array();
if ($wi !== false)
{
	foreach ($wi as $w)
	{
		$real_workflow_process = eZWorkflowProcess::fetch($w['wp_id']);
		$real_workflow = eZWorkflow::fetch($w['wf_id']);
		$result[]=array("process"=>$real_workflow_process, "workflow"=>$real_workflow);
	}
}
$view_parameters=array('workflows'=>$result);
$tpl->setVariable('view_parameters', $view_parameters);

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:smileworkflowboard/list.tpl' );
$Result['path'] = array( array( 'url' => false,
								'text' => ezi18n('smileworkflowboard/translations','Workflow Board')),
						 array( 'url' => false,
                                'text' => ezi18n('smileworkflowboard/translations','Current workflow list') ) 
                       );
?>