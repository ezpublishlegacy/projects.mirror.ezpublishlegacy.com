<?php
include_once ('kernel/common/template.php');
include_once ("lib/ezutils/classes/ezini.php");
include_once ("kernel/classes/ezworkflow.php");
include_once ("kernel/classes/ezworkflowgrouplink.php");
include_once ("kernel/classes/ezworkflowprocess.php");
include_once ("kernel/classes/eztrigger.php");
include_once ("lib/ezutils/classes/ezoperationmemento.php");
include_once ("kernel/classes/ezpersistentobject.php");
include_once ("kernel/classes/ezcollaborationitem.php");
include_once ("kernel/classes/ezcollaborationitemhandler.php");

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation($id)
{
	include_once ('lib/ezdb/classes/ezdb.php');
	$db = eZDb :: instance();
	$query = "SELECT wp.id as wp_id, w.id as wf_id "."FROM ezworkflow_process wp, ezworkflow w "."WHERE wp.workflow_id = w.id "."AND wp.id=$id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else
	{
		return false;
	}
}

function getCollaborationInformation($id)
{
	include_once ('lib/ezdb/classes/ezdb.php');
	$db = eZDb :: instance();
	$query = "select workflow_process_id, collaboration_id "."from ezapprove_items "."where workflow_process_id = $id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else
	{
		return false;
	}

}

/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
$tpl = & templateInit();
$p_id = $Params['process_id'];
$accept = $Params['accept'];

if (!is_numeric($p_id))
{
	return $Module->redirectToView('message', array ('error', 'null'));
}

$wi = getWorkflowsInformation($p_id);
if (!$wi)
{
	return $Module->redirectToView('message', array ('error', 'null'));
}

$result = array ();

if ($accept == 1)
{
	if ($p_id != 0)
	{
		$db = & eZDb :: instance();
		if (!$db)
		{
			return $Module->redirectToView('message', array ('error', 'db'));
		}
		$db->begin();
		$real_workflow_process = eZWorkflowProcess :: fetch($wi[0]['wp_id']);

		$parameters = unserialize($real_workflow_process->attribute('parameters'));
		$object_id = $parameters['object_id'];
		$version_id = $parameters['version'];
		$object = & eZContentObject :: fetch($object_id);
		$version = & eZContentObjectVersion :: fetchVersion($version_id, $object_id);
		if (is_object($version))
		{
			$status = $version->attribute('status');
			if ($status == EZ_VERSION_STATUS_PENDING)
			{
				$version->setAttribute('status', EZ_VERSION_STATUS_DRAFT);
				$version->store();
			}
			$object->sync();
		}
		else
		{
			eZDebug :: writeError('No Version found for object '.$object_id.' - ('.$version_id.')', 'Workflow Board::Remove');
			eZDebug :: writeError($version, 'Workflow Board::Remove');
		}
		eZPersistentObject :: removeObject(eZOperationMemento :: definition(), array ('memento_key' => $real_workflow_process->attribute('memento_key')));
		$real_workflow_process->remove();

		/* "Suppression" de la collaboration*/
		$real_collaboration_item = getCollaborationInformation($wi[0]['wp_id']);
		eZDebug :: writeDebug($real_collaboration_item, "Collaboration items");
		foreach ($real_collaboration_item as $collab)
		{
			$collaboration_item = & eZCollaborationItem :: fetch($collab['collaboration_id']);
			if (is_object($collaboration_item))
			{
				eZDebug :: writeDebug($collaboration_item, "Collaboration item");
				$db->query('UPDATE ezcollab_item_status set is_active=0 WHERE collaboration_id = '.$collaboration_item->attribute('id'));
				$db->query('DELETE FROM ezapprove_items WHERE workflow_process_id = '.$p_id);
				$collaboration_item->sync();
			}
		}
		$db->commit();
		return $Module->redirectToView('message', array ('success'));

	}
}
else
{
	if ($p_id != 0)
	{
		foreach ($wi as $w)
		{
			$real_workflow_process = eZWorkflowProcess :: fetch($w['wp_id']);
			$real_workflow = eZWorkflow :: fetch($w['wf_id']);
			$result[] = array ("process" => $real_workflow_process, "workflow" => $real_workflow);
		}
	}

	$view_parameters = array ('workflows' => $result);
	$tpl->setVariable('view_parameters', $view_parameters);

	$Result = array ();
	$Result['content'] = & $tpl->fetch('design:smileworkflowboard/remove.tpl');
	$Result['path'] = array (array ('url' => false, 'text' => ezi18n('smileworkflowboard/translations', 'Workflow Board')), array ('url' => false, 'text' => ezi18n('smileworkflowboard/translations', 'Stop process')));
}
?>