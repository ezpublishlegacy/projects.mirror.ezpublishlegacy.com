<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=smileworkflowboard

[RegionalSettings]
TranslationExtensions[]=smileworkflowboard

*/ ?>
