<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
array( 'script' => 'extension/smileworkflowboard/autoloads/serialoperator.php',
        'class' => 'SerialOperator',
        'operator_names' => array( 'getUnserialized' ) );

 


?>
