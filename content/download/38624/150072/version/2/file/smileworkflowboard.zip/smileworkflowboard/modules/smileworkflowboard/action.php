<?php
//
// Copyright (C) 2005 Smile. All rights reserved.
//
// Authors:
//  Maxime THOMAS <maxime.thomas@smile.fr>
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

include_once( 'kernel/common/template.php' );
include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
include_once( 'kernel/classes/eztrigger.php' );
include_once( "lib/ezdb/classes/ezdb.php" );
include_once( "lib/ezutils/classes/ezini.php" );
/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation($id)
{
	include_once('lib/ezdb/classes/ezdb.php');
	$db=eZDb::instance();
	$query="SELECT wp.id as wp_id, w.id as wf_id " .
			"FROM ezworkflow_process wp, ezworkflow w " .
			"WHERE wp.workflow_id = w.id " .
			"AND wp.id=$id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else 
	{
		return false;
	}
}
/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
$Module =& $Params["Module"];
$http =& eZHTTPTool::instance();
$tpl =& templateInit();

$action = $Params['action'];

switch ( $action ) 
{	
	case "list":
		return $Module->redirectToView( 'list' );
	break;
	
	case "view":
		$param = $Params['param'];
		if ( !is_numeric( $param ) )
		{	
			
			return $Module->redirectToView( 'message', array('error','null') );
		}
		$p = getWorkflowsInformation($param);
		if (!$p)
		{
			return $Module->redirectToView( 'message', array('error','null') );
		}
		return $Module->redirectToView( 'view', array($param) );
	break;
	
	case "accept" :
		$param = $Params['param'];
		$accept = $http->postVariable( 'AcceptButton' );
		if ($accept != null)
		{
			return $Module->redirectToView( 'remove', array($param, 1) );
		}
		else
		{
			return $Module->redirectToView( 'view', array($param) );
		}
		
	break;
	case "remove" :
		$param = $Params['param'];
		
		if ( !is_numeric( $param ) )
		{	
			return $Module->redirectToView( 'message', array('error','null') );
		}
		$p = getWorkflowsInformation($param);
		if (!$p)
		{
			return $Module->redirectToView( 'message', array('error','null') );
		}
		else
		{
			return $Module->redirectToView( 'remove', array($param) );
		}
	break;
	
	case "message" :
		$param = $Params['param'];
		$string= $Parmas['string'];
		return $Module->redirectToView( 'message', array($param, $string) );
	break;
	
}

?>