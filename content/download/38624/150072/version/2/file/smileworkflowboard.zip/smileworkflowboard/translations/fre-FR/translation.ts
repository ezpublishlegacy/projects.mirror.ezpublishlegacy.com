<!DOCTYPE TS><TS>
<context>
    <name>design/admin/navigator</name>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Précédent</translation>
    </message>
    <message>
        <source>previous</source>
        <translation type="obsolete">précédent</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">suivant</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Show 10 items per page.</source>
        <translation type="obsolete">Afficher 10 items par page.</translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation type="obsolete">Afficher 50 items par page.</translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation type="obsolete">Afficher 25 items par page.</translation>
    </message>
    <message>
        <source>Step</source>
        <translation>Etape</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Rechercher tous le contenu.</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Tous les contenus</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Cherche uniquement à partit de cet endroit.</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>A partir d&apos;ici</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>Le même endroit</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancée</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Recherche avancée.</translation>
    </message>
</context>
<context>
    <name>smileworkflowboard/translations</name>
    <message>
        <source>Current workflow list</source>
        <translation>Process de workflow en cours</translation>
    </message>
    <message>
        <source>Id</source>
        <translation>Id</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Détails</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Arrêter</translation>
    </message>
    <message>
        <source>The workflow process has been stopped.</source>
        <translation>Le process de workflow a été arrêté.</translation>
    </message>
    <message>
        <source>Stopping the workflow process will cancel the publishing of the object version and will bring back it to draft status in the creator drafts.</source>
        <translation>L&apos;arrêt du process de workflow annulera la publication de la version de l&apos;objet et la renverra à l&apos;état de brouillon dans les brouillons du créateur.</translation>
    </message>
    <message>
        <source>Back to workflow process list</source>
        <translation>Retour à la liste des process de workflow</translation>
    </message>
    <message>
        <source>An error occured : the workflow process has not been stopped.</source>
        <translation>Une erreur s&apos;est produite : le process de workflow n&apos;a pas été arrêté.</translation>
    </message>
    <message>
        <source>Are you sure you want to stop this workflow process ?</source>
        <translation>Etes vous sûrs de vouloir arrêter ce process de workflow ?</translation>
    </message>
    <message>
        <source>Accept</source>
        <translation>Accepter</translation>
    </message>
    <message>
        <source>Accept to stop the workflow process.</source>
        <translation>Accepter d&apos;arrêter le process de workflow.</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Refuser</translation>
    </message>
    <message>
        <source>Deny to stop the workflow process.</source>
        <translation>Refuser d&apos;arrêter le process de workflow.</translation>
    </message>
    <message>
        <source>Workflow process number</source>
        <translation>Process de workflow numéro</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objet</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Visualisation</source>
        <translation type="obsolete">Visualisation</translation>
    </message>
    <message>
        <source>Classe de l&amp;rsquo;objet</source>
        <translation type="obsolete">Classe de l&amp;rsquo;objet</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Workflow</translation>
    </message>
    <message>
        <source>Workflow details</source>
        <translation>Détails du workflow</translation>
    </message>
    <message>
        <source>Current step</source>
        <translation>Etape courante</translation>
    </message>
    <message>
        <source>Stop the workflow process.</source>
        <translation>Arrêter le process de workflow.</translation>
    </message>
    <message>
        <source>Workflow Board</source>
        <translation>Workflow Board</translation>
    </message>
    <message>
        <source>Result of operation</source>
        <translation>Résultat de l&apos;opération</translation>
    </message>
    <message>
        <source>Stop process</source>
        <translation>Arrêter le process</translation>
    </message>
    <message>
        <source>View details</source>
        <translation>Voir les détails</translation>
    </message>
    <message>
        <source>Visualization</source>
        <translation>Visualisation</translation>
    </message>
    <message>
        <source>Object class</source>
        <translation>Classe de l&apos;objet</translation>
    </message>
    <message>
        <source>Database is not available.</source>
        <translation>La base de données n&apos;est pas disponible.</translation>
    </message>
    <message>
        <source>The workflow process id does not exist.</source>
        <translation>L&apos;identifiant du process de workflow n&apos;existe pas.</translation>
    </message>
    <message>
        <source>Workflow setup</source>
        <translation>Administration des workflows</translation>
    </message>
    <message>
        <source>Workflow process list</source>
        <translation>Liste des process de workflows</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Déclencheurs</translation>
    </message>
    <message>
        <source>No workflow process in progress.</source>
        <translation>Pas de process de workflow en cours.</translation>
    </message>
</context>
</TS>
