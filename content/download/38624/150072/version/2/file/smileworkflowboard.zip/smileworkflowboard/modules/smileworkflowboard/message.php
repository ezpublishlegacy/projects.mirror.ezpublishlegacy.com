<?php

include_once( 'kernel/common/template.php' );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "kernel/classes/ezworkflow.php" );
include_once( "kernel/classes/ezworkflowgrouplink.php" );
include_once( "kernel/classes/ezworkflowprocess.php" );

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/


/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
$tpl =& templateInit();
$message=$Params['message'];
$string=$Params['string'];

if ($message=='error' and $string=='db')
{
	$view_parameters=array('message'=>$message, 'string'=>ezi18n('smileworkflowboard/translations', 'Database is not available.'));
}
elseif ($message=='error' and $string=='null')
{
	$view_parameters=array('message'=>$message, 'string'=>ezi18n('smileworkflowboard/translations', 'The workflow process id does not exist.'));
}
else
{
	$view_parameters=array('message'=>$message, 'string'=>$string);	
}

$tpl->setVariable('view_parameters', $view_parameters);

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:smileworkflowboard/message.tpl' );
$Result['path'] = array( array( 'url' => false,
								'text' => ezi18n('smileworkflowboard/translations','Workflow Board')),
						 array( 'url' => false,
                                'text' => ezi18n('smileworkflowboard/translations','Result of operation') ) 
                        );
?>