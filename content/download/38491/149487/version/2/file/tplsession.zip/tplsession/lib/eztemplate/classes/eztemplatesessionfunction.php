<?php
//
// Definition of eZTemplateSessionFunction class
//
// Created on: <15-Aug-2006 16:03:02 me>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.6.8
// BUILD VERSION: 16022
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*!
  \class eZTemplateSessionFunction eztemplatesessionfunction.php
  \ingroup eZTemplateFunctions
  \brief Allows to save and load session variables from templates

  Syntax:
\code
    {session_save sesname=<name of session variable> sesvalue=<value to save>}
    {session_load var=<name of template variable> sesname=<name of session variable>}
\endcode

  Example:
\code
	...
    {session_save sesname="sessionvar" sesvalue="A duck crossed the pond"}
    {def $myvar='A chicken jumped over the fence'}
    {$myvar}
    {session_load var="myvar" sesname="sessionvar"}
    {$myvar}
    ...
\endcode

\output
	A chicken jumped over the fence
	A duck crossed the pond
\endoutput
*/

define ( 'EZ_TEMPLATE_SESSIONSAVE_FUNCTION_NAME',   'session_save'   );
define ( 'EZ_TEMPLATE_SESSIONLOAD_FUNCTION_NAME',   'session_load' );
class eZTemplateSessionFunction
{
    /*!
     * Returns an array of the function names, required for eZTemplate::registerFunctions.
     */
    function &functionList()
    {
        return array( EZ_TEMPLATE_SESSIONSAVE_FUNCTION_NAME, EZ_TEMPLATE_SESSIONLOAD_FUNCTION_NAME );
    }

    /*!
     * Returns the attribute list which is 'delimiter', 'elseif' and 'else'.
     * key:   parameter name
     * value: can have children
     */
    function attributeList()
    {
        return array();
    }


    /*!
     * Returns the array with hits for the template compiler.
     */
    function functionTemplateHints()
    {
        return array( EZ_TEMPLATE_SESSIONSAVE_FUNCTION_NAME   => array( 'parameters' => true,
                                                                'static' => false,
                                                                'transform-parameters' => true,
                                                                'tree-transformation' => true ),
                      EZ_TEMPLATE_SESSIONLOAD_FUNCTION_NAME => array( 'parameters' => true,
                                                                'static' => false,
                                                                'transform-parameters' => true,
                                                                'tree-transformation' => true ) );
    }

     /*!
     * Actually executes the function (in processed mode).
     */
    function process( &$tpl, &$textElements, $functionName, $functionChildren, $functionParameters, $functionPlacement, $rootNamespace, $currentNamespace )
    {
		include_once( 'lib/ezutils/classes/ezhttptool.php');
    	$http =& eZHTTPTool::instance();
				
        $session_save = ( $functionName == EZ_TEMPLATE_SESSIONSAVE_FUNCTION_NAME ) ? true : false;

		$param = array();
		$value = array();
		
	    if ( $session_save ) // {session_save}
	    {	
			$varName = 'sesname';
			$param['name'] = $functionParameters[$varName];
			$value['name'] = $tpl->elementValue( $param['name'], $rootNamespace, $currentNamespace, $functionPlacement );
			$varName = 'sesvalue';
			$param['value'] = $functionParameters[$varName];
			$value['value'] = $tpl->elementValue( $param['value'], $rootNamespace, $currentNamespace, $functionPlacement );

			$http->setSessionVariable( 'tpl_'.$value['name'], $value['value'] );
	    }
	    else // {session_load}
	    {
	    	$varName = 'var';
			$param['var'] = $functionParameters[$varName];
			$value['var'] = $tpl->elementValue( $param['var'], $rootNamespace, $currentNamespace, $functionPlacement );
	    	$varName = 'sesname';
	    	$param['name'] = $functionParameters[$varName];
			$value['name'] = $tpl->elementValue( $param['name'], $rootNamespace, $currentNamespace, $functionPlacement );
			
			if($http->hasSessionVariable('tpl_'.$value['name'])) {
				$sesValue = $http->sessionVariable('tpl_'.$value['name']);
			}
			else {
				$sesValue = '';	
			}

			$tpl->setVariable( $value['var'], $sesValue, $rootNamespace );
	    }
	    
    }

    /*!
     * Returns false, telling the template parser that the function cannot have children.
     */
    function hasChildren()
    {
        return false;
    }
}

?>
