<?php /* #?ini charset="utf-8"? 

[block_openlayers_content]
Source=block/view/view.tpl
MatchFile=block/openlayers_content.tpl
Subdir=templates
Match[type]=OpenLayersItems
Match[view]=openlayers_content

*/ ?>
