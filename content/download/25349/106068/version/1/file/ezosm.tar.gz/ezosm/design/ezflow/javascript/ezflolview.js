function eZFLOLView( blockId, data )
{
    var zoom=13;
    var map;

    map = new OpenLayers.Map ( document.getElementById( 'ezflb-map-' + blockId ), {
        controls:[
            new OpenLayers.Control.Navigation(),
            new OpenLayers.Control.PanZoom(),
            new OpenLayers.Control.LayerSwitcher()],
        maxExtent: new OpenLayers.Bounds(-20037508.34,-20037508.34,20037508.34,20037508.34),
        maxResolution: 156543.0399,
        numZoomLevels: 19,
        units: 'm',
        projection: new OpenLayers.Projection("EPSG:900913"),
        displayProjection: new OpenLayers.Projection("EPSG:4326")
    } );

    var layerMapnik = new OpenLayers.Layer.OSM.Mapnik("Mapnik");
    map.addLayer(layerMapnik);

    var layerMarkers = new OpenLayers.Layer.Markers("Markers");
    map.addLayer(layerMarkers);

    var size = new OpenLayers.Size(21,25);
    var offset = new OpenLayers.Pixel(-(size.w/2), -size.h);
    var icon = new OpenLayers.Icon('http://www.openstreetmap.org/openlayers/img/marker.png',size,offset);

    if( ! map.getCenter() ){
        for( var i = 0; i < data.length; i++ )
        {
            var locationData = data[i];
            var lon = locationData.point.lon;
            var lat = locationData.point.lat;
            var lonLat = new OpenLayers.LonLat(lon, lat).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject());
            var marker = new OpenLayers.Marker(lonLat,icon.clone());
            layerMarkers.addMarker(marker);
            marker.address = locationData.address;
            marker.events.register("mousedown", marker, function(e) {
                map.panTo(this.lonlat);
                map.setCenter(this.lonlat);
                popup = new OpenLayers.Popup("chicken",
                   this.lonlat,
                   new OpenLayers.Size(1,1));
                popup.panMapIfOutOfView = true;
                popup.setContentHTML("<div style='background-color:#FFFFF2; width:auto;height:auto;'>"+this.address+"</div>");
                popup.setBackgroundColor("#FFFFF2");
                popup.setBorder("2px");
                popup.addCloseBox(function() {
                   map.panTo(this.lonlat);
                   popup.destroy();
                });
                popup.updateSize();
                map.addPopup(popup);
                if ( e.preventDefault )
                    e.preventDefault();
                else
                    e.returnValue = false;
            });
            map.setCenter(lonLat, zoom);
        }
    }
    map.zoomToExtent(layerMarkers.getDataExtent());
}

function eZFLOLAddListener( element, type, expression, bubbling )
{
    bubbling = bubbling || false;

    if( window.addEventListener )
    {
        element.addEventListener( type, expression, bubbling );
        return true;
    } 
    else if ( window.attachEvent ) 
    {
        element.attachEvent( 'on' + type, expression );
        return true;
    } 
    else
    {
        return false;
    }
}

