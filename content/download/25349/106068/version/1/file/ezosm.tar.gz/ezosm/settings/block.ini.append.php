<?php /* #?ini charset="utf-8"? 

[General]
AllowedTypes[]=OpenLayersItems

[OpenLayersItems]
Name=OpenLayers Items
ManualAddingOfItems=disabled
CustomAttributes[]=parent_node_id
CustomAttributes[]=class
CustomAttributes[]=attribute
CustomAttributes[]=limit
CustomAttributes[]=width
CustomAttributes[]=height
UseBrowseMode[parent_node_id]=true
ViewList[]=openlayers_content
ViewName[openlayers_content]=OpenLayers Content

*/ ?>
