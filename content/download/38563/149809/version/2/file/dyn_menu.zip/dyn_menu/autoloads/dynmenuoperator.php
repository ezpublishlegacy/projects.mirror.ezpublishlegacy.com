<?php
/*!
  \class   DynMenuOperator dynmenuoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator dyn_menu
  \version 1.0
  \date    Tuesday 21 October 2003 3:46:55 pm
  \author  Mark Kruse, Siemen Business Services Paderborn, Germany, mark.kruse@siemens.com

  By using dyn_menu you can create dynamic menus with n-levels.
  This operator returns the depth, the node and a flag for the active node.
  
  If we give the depth of 0, then we want only the children of the current Node.

  As parameter, the operator gets an assoziative array with the following parameters:
  StartNodeID
  CurrentNodeID
  Depth
  ClassIDs
  
  Example:
\code
{dyn_menu(hash(start_node,2,current_node,20,depth,3,classes,array(1,2)))}
\endcode
  
  Copyright by eZ systems and Siemens Business Services, 2003
*/




class DynMenuOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function DynMenuOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'dyn_menu' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'dyn_menu' => array( 'params' => array( 'type' => 'array',
                                                             'required' => false,
                                                             'default' => array( ) ) ) );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
    	$params = & $namedParameters['params'];
    	if ( count( $params ) == 0 )
    	{
		    $params = array( 'start_node' => 2,
			                 'current_node' => 0,
							 'depth' => 2,
 							 'classes' => array( 1 ) );

    	}
    	
        $rootNodeID = 2;
        $currentNodeID = 0;
        $givenDepth = 2;
        $Classes = array( 1 );
		if ( isset( $params['start_node'] ) && is_numeric( $params['start_node'] ) )
		{
		    $rootNodeID = $params['start_node'];
		}
		if ( isset( $params['current_node'] ) && is_numeric( $params['current_node'] ) )
		{
		    $currentNodeID = $params['current_node'];
		}
		if ( isset( $params['depth'] ) && is_numeric( $params['depth'] ) )
		{
		    $givenDepth = $params['depth'];
		}
		if ( isset( $params['classes'] ) && is_array( $params['classes'] ) && count( $params['classes'] ) > 0 )
		{
		    $Classes = $params['classes'];
		}
        
        //var_dump($namedParameters);
        switch ( $operatorName )
        {
            case 'dyn_menu':
            {
				$http =& eZHTTPTool::instance();
				
				if ( !is_numeric( $rootNodeID ) )
				{
					$operatorValue = "";
					return;
				}
				
				if ( is_numeric( $currentNodeID ) && $currentNodeID != 0 )
				{
					$currentNode = eZContentObjectTreeNode::fetch( $currentNodeID );
					if ( is_object( $currentNode ) )
					{
					    $http->setSessionVariable( "menu_node_id", $currentNodeID );
					}
					else 
					{
						$operatorValue = "";
						return;
					}
				}
				else 
				{
				    if ( $http->hasSessionVariable( "menu_node_id" ) )
				    {
				        $currentNodeID = & $http->sessionVariable( "menu_node_id" );
						$currentNode = eZContentObjectTreeNode::fetch( $currentNodeID );
				    }
				    else 
				    {
						$operatorValue = "";
						return;
				    }
				}
		        //MK, 2003-10-24
		        //If depth==0, then we want the currentNode as StartNode and only the children of the currentNode.
		        if ( $givenDepth == 0 )
		        {
		        	$givenDepth = 1;
		        	$rootNodeID = $currentNodeID;
		        }
				$rootNode = eZContentObjectTreeNode::fetch( $rootNodeID );
				if ( !is_object( $rootNode ) )
				{
					$operatorValue = "";
					return;
				}
				
				$params = array();
				$params['Depth'] = $givenDepth;
				$params['ClassFilterType'] = 'include';
				//MK, 2003-10-23
				//The Classes are read from the ini-file and sometimes PHP treats them as strings.
				//Then the subtree-function doesn't work.
				$keys = array_keys( $Classes );
				foreach ( $keys as $key )
				{
					settype( $Classes[$key], "integer" );
				}
 				
				$params['ClassFilterArray'] = $Classes;
				
				//MK, 2003-12-05
				//reorganized the whole menu
				//We use now a recursive function to ensure to use the correct sorting.
				
				$params['Depth'] = 1;
				$params['SortBy'] = $rootNode->attribute( "sort_array" );
				$rootNodeChildren = $rootNode->subTree( $params );
				$pathlist = $currentNode->pathArray();
				$rootDepth = $rootNode->attribute( "depth" );
				$currentDepth = $currentNode->attribute( "depth" );
				$menuList = array();
				
				$this->fillMenuItems( $rootNodeChildren, $pathlist, $rootDepth, $givenDepth, $currentNodeID, $params, $menuList );
				unset( $rootNodeChildren );
				$operatorValue = $menuList;
				
				
            } break;
        }
    }
    
    /**
    * @return void
    * @param $NodeArray array
    * @param $pathlist array
    * @param $rootDepth integer
    * @param $givenDepth integer
    * @param $currentNodeID integer
    * @param $SubTreeParams array
    * @param $resultArray array
    * @desc This function fills the ResultArray with Menu-Entries.
    *       It works recursive.
    *
    * MK, 2003-12-05
 */
    function fillMenuItems( & $NodeArray, $pathlist, $rootDepth, $givenDepth, $currentNodeID, $SubTreeParams, & $resultArray )
    {
    	$keys = array_keys( $NodeArray );
    	foreach ( $keys as $key )
    	{
			if ( in_array( $NodeArray[$key]->attribute( "parent_node_id" ), $pathlist ) ||
				 in_array( $NodeArray[$key]->attribute( "node_id" ), $pathlist ) )
			{
				$depth = $NodeArray[$key]->attribute( "depth" );
				$menuItem["depth"] = $depth - $rootDepth;
				$menuItem["node"] = $NodeArray[$key];
				$menuItem["active"] = 0;
				if ( $NodeArray[$key]->attribute( "node_id" ) == $currentNodeID )
				{
					$menuItem["active"] = 1;
				}
				$resultArray[] = $menuItem;
				unset ( $menuItem );
			}
			if ( in_array( $NodeArray[$key]->attribute( "node_id" ), $pathlist ) &&
			 	 ( $depth - $rootDepth ) < $givenDepth )
			{
				$SubTreeParams['SortBy'] = $NodeArray[$key]->attribute( "sort_array" );
				$SubNodeArray = $NodeArray[$key]->subTree( $SubTreeParams );
				$this->fillMenuItems( $SubNodeArray, $pathlist, $rootDepth, $givenDepth, $currentNodeID, $SubTreeParams, $resultArray );
				unset( $SubNodeArray );
				unset( $SubTreeParams );
			}
    	}

    }
}

?>