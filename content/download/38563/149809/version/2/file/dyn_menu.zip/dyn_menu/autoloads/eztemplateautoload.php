<?php
//
// Created on: <05-Oct-2002 21:27:11 amos>
//
//

/*! \file eztemplateautoload.php
*/

// Operator autoloading

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extensions/dyn_menu/autoloads/dynmenuoperator.php',
                                    'class' => 'DynMenuOperator',
                                    'operator_names' => array( 'dyn_menu' ) );




?>
