<?php

$Module = array( 'name' => 'Changeattribvalue' );

$ViewList = array();
$ViewList['set'] = array( 
    'script' => 'set.php',
    'params' => array () );

?>