[ModuleSettings]
ExtensionRepositories[]=changeattribvalue
