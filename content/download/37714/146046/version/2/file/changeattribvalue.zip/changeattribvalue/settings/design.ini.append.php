[ExtensionSettings]
DesignExtensions[]=changeattribvalue
