<?php /* #?ini charset="utf-8"?


[GeneralSettings]

# A list of custom identifiers that will mask class identifiers in the URLs.
# This is partly a security precausion, and also for better flexibility.
# The order of this array will decide the order in the browse view's menu.
# Each of these elements requires a dedicated block below, "ClassSettings-xxx".
ClassCustomIdentifierArray[]
ClassCustomIdentifierArray[]=test
ClassCustomIdentifierArray[]=test2
ClassCustomIdentifierArray[]=comment

# Whether the system should try to locate the main node of the object and
# create a link to it.
# Possible values: enabled|disabled
LinkToTheObjectMainNode=enabled


# Example block for "test" custom identifier.
# [ClassSettings-test]
#
# Real class identifier of the masked class.
# ClassIdentifier=collector_class
#
# A handle/source that will be used for translations. 
# Remember to provide a translation for this source in the translation files.
# TranslationSource=Test type
#
# Whether user will be allowed to delete his collections or not.
# Note: For user to be able to delete collections, (s)he also must have 
# access to delete function of the module.
# Possible values: true|false
# AllowDelete=true
#
# Whether the system should look for custom template for this class' collection.
# For this block, if set to true, it will look for the template in the 
# mycollectedinfo/dedicated/test.tpl (mycollectedinfo/dedicated/*.tpl)
# Possible values: true|false
# DedicatedTemplate=true
#
# Whether it display who created a collection.
# Possible values: true|false
# DisplayAuthorName=true
#
# A general block look:
#
# [ClassSettings-test]
# ClassIdentifier=collector_class
# TranslationSource=Test type
# AllowDelete=true
# DedicatedTemplate=true
# DisplayAuthorName=true


[ClassSettings-test]
ClassIdentifier=collector_class
TranslationSource=Test type
AllowDelete=true
DedicatedTemplate=false
DisplayAuthorName=true

[ClassSettings-test2]
ClassIdentifier=collector_class_2
TranslationSource=Test type 2
AllowDelete=false
DedicatedTemplate=false
DisplayAuthorName=false

[ClassSettings-comment]
ClassIdentifier=comment
TranslationSource=Comments
AllowDelete=true
DedicatedTemplate=false
DisplayAuthorName=true


*/ ?>
