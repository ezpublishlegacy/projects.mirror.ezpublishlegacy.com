eZ My Collected Info extension for eZ Publish 4.0
version 0.3 beta

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ez.ryba.eu



eZ My Collected Info extension gives front-end access to one's collected info.
The ownership of the collections is determined based on the ownership of the
content object that collected the information. In other words, it is not who 
sent the information, but whose object it was sent to, that is considered the
owner, and thus can browse/read, and optionally delete.

The extension makes it possible to browse though the collections by class and
then by object (a tree-like menu is provided for easy access). A detailed
class-level configuration is possible to allow/disallow collection deletion,
custom identifiers, and custom/default templates.

The extension comes with two module views and two access functions for 
a flexible management. The standard browsing view can be accessed through:
/index.php/siteaccess/mycollectedinfo/browse

Read the settings/mycollectedinfo.ini file's comments for more information.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------

- eZ Publish 4.0.0+
- eZ Publish Components: Base, File



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezmycollectedinfo/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezmycollectedinfo

3. Clear cache.



Changelog
---------

# Suggestions and plans:
- Add debugger messages.
- Portion collection list (limit/offset).
- Link to author.
- Improve default XHTML/CSS layer.


# v0.3 beta, local, 2008.02.04
+ Display collection's author. 
+ Minor fixes and improvements.

# v0.2 beta, local, 2008.02.03
+ First fully functional version, fully validated delete included.
+ Browse by classes and objects.
+ Configure delete ability per class.
+ Dedicated/default attributes per class.

# v0.1 alpha, local, 2008.02.02
+ Display functionality, first working draft.

# v0.0 alpha, local, 2008.02.01
+ Start.


/+/ complete
/-/ plan or in progress
