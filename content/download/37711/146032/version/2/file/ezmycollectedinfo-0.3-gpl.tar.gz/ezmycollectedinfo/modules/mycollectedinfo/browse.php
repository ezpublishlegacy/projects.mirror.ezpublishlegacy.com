<?php

/**
 * eZ My Collected Info extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



require_once( 'kernel/common/template.php' );

$tpl = templateInit();
$Module = $Params['Module'];
$http = eZHTTPTool::instance();
$Result = array();


// Save current URI for delete redirection
$http->setSessionVariable( 'eZMyCollectedInfoLastURI', $GLOBALS['GLOBALS']['eZRequestedURI']->URI );


// Get global current user information
global $currentUser;
$deleteAccess = $currentUser->hasAccessTo( 'mycollectedinfo', 'delete' );

$ini = eZINI::instance( 'mycollectedinfo.ini' );
$generalINI = $ini->group( 'GeneralSettings' );

// Process configuration data for creating config class map
$customClassIdentifiers = $generalINI['ClassCustomIdentifierArray'];
$classMap = array();
foreach( $customClassIdentifiers as $customClassIdentifier )
{
    $classINI = $ini->group( 'ClassSettings-' . $customClassIdentifier );
    $classMap[$customClassIdentifier] = array(
    	'class_identifier' => trim( $classINI['ClassIdentifier'] ),
    	'translation_source' => trim( $classINI['TranslationSource'] ),
        'allow_delete' => ( $classINI['AllowDelete'] == 'true' and ( ( $deleteAccess['accessWord'] == 'yes' or $deleteAccess['accessWord'] == 'limited' ) ) ),
        'dedicated_template' => ( $classINI['DedicatedTemplate'] == 'true' ),
        'display_author_name' => ( $classINI['DisplayAuthorName'] == 'true' ),
        'object_array' => array(),
    );
}

$customClassIdentifier = $Module->NamedParameters['CustomClassIdentifier'];
$contentObjectID = $Module->NamedParameters['ContentObjectID'];

// This variable will hold all the collection data
$collectionData = array();

$currentIdentifier = false;
$currentObjectID = false;

$currentPathIdentifierName = false;
$currentPathObjectIDName = false;
$mainNode = false;

// If a class was set
if( $customClassIdentifier != '' )
{
    // Deny access if the identifier is not preconfigured
    if( !in_array( $customClassIdentifier, array_keys( $classMap ) ) )
    {
        return $Module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
    }

    $currentIdentifier = $customClassIdentifier;
    $currentPathIdentifierName = array(
    	'url' => 'mycollectedinfo/browse/' . $currentIdentifier, 
    	'text' => ezi18n( 'extension/ezmycollectedinfo/type', $classMap[$customClassIdentifier]['translation_source'] ), 
    );

    // Get content class object by class identifier
    $contentClassIdentifier = $classMap[$customClassIdentifier]['class_identifier'];
    $contentClassObject = eZContentClass::fetchByIdentifier( $contentClassIdentifier );

    // Fetch all content objects matching current user and beloning to current
    // content class
    $usersClassObjects = eZContentObject::fetchFilteredList( array(
        'owner_id' => eZUser::currentUserID(),
        'contentclass_id' => $contentClassObject->ID,
    ) );

    // Get objects' ids and names (extend class map information)
    foreach( $usersClassObjects as $usersClassObject )
    {
        array_push( $classMap[$currentIdentifier]['object_array'], array(
            'id' => $usersClassObject->ID,
        	'name' => $usersClassObject->Name,
        ) );
    }

    if( is_numeric( $contentObjectID ) )
    {
        // Get the content object. If it's not a valid object, throw error.
        $contentObject = eZContentObject::fetch( $contentObjectID );
        if( !is_object( $contentObject ) )
        {
            return $Module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
        }

        if( $generalINI['LinkToTheObjectMainNode'] == 'enabled' )
        {
            $mainNode = $contentObject->mainNode();
        }

        $currentObjectID = $contentObjectID;
        $currentPathObjectIDName = array(
        	'url' => 'mycollectedinfo/browse/' . $currentIdentifier . '/' . $currentObjectID, 
        	'text' => $contentObject->Name, 
        );

        // Supply result array with data
        $collectionData['object'] = $contentObject;
        $collectionData['collections'] = array();

        // Store user objects for reuse
        $userObjectArray = array();

        $myCollectionFunctionCollection = new eZInfocollectorFunctionCollection();
        $collectionList = $myCollectionFunctionCollection->fetchCollectionsList( $contentObjectID );
        foreach( $collectionList['result'] as $collectionItem )
        {
            // If should display collection's author's name
            if( $classMap[$currentIdentifier]['display_author_name'] )
            {
                if( !isset( $userObjectArray[$collectionItem->CreatorID] ) )
                {
                    $userObjectArray[$collectionItem->CreatorID] = eZContentObject::fetch( $collectionItem->CreatorID );
                }
                $collectionData['collections'][$collectionItem->ID]['author_object'] = $userObjectArray[$collectionItem->CreatorID];
            }
            $collectionData['collections'][$collectionItem->ID]['data'] = $collectionItem;
        }
    }
}


// Variables for the template
$tpl->setVariable( 'collectionData', $collectionData );
$tpl->setVariable( 'currentIdentifier', $currentIdentifier );
$tpl->setVariable( 'currentObjectID', $currentObjectID );
$tpl->setVariable( 'classMap', $classMap );
$tpl->setVariable( 'mainNode', $mainNode );

$currentPath = array(
array( 'url' => 'mycollectedinfo/browse', 'text' => ezi18n( 'extension/ezmycollectedinfo/module', 'My collected info' ) ),
array( 'url' => 'mycollectedinfo/browse', 'text' => ezi18n( 'extension/ezmycollectedinfo/module', 'Browse' ) ),
);

if( $currentPathIdentifierName )
{
    array_push( $Result['path'], array( 'url' => 'mycollectedinfo/browse/' . $currentIdentifier, 'text' => $currentPathIdentifierName ) );
}

if( $currentPathObjectIDName )
{
    array_push( $Result['path'], array( 'url' => 'mycollectedinfo/browse/' . $currentIdentifier . '/' .$currentObjectID, 'text' => $currentPathObjectIDName ) );
}

$Result['path'] = $currentPath;
$Result['content'] = $tpl->fetch( "design:mycollectedinfo/browse.tpl" );

?>