<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmycollectedinfo/module</name>
    <message>
        <source>My collected info</source>
        <translation>Moje zgromadzone informacje</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
</context>
<context>
    <name>extension/ezmycollectedinfo/type</name>
    <message>
        <source>Test type</source>
        <translation>Typ testowy</translation>
    </message>
    <message>
        <source>Test type 2</source>
        <translation>Typ testowy 2</translation>
    </message>
</context>
<context>
    <name>extension/ezmycollectedinfo/tpl</name>
    <message>
        <source>You are not allowed to access collections of any type!</source>
        <translation>Nie posiadasz uprawnień do kolekcji żadnego typu!</translation>
    </message>
    <message>
        <source>Select the type of objects.</source>
        <translation>Wybierz typ obiektu.</translation>
    </message>
    <message>
        <source>Select the object.</source>
        <translation>Wybierz obiekt.</translation>
    </message>
    <message>
        <source>No collections found.</source>
        <translation>Nie znaleziono żadnych kolekcji.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Dodano</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
</context>
</TS>
