<?php

/**
 * eZ My Collected Info extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



$Module = $Params['Module'];
$http = eZHTTPTool::instance();
$Result = array();


// If action remove
if( $http->hasPostVariable( 'eZMyCollectedInfoRemove' ) )
{
    // If has all required fields and at least one element for removal
    if( $http->hasPostVariable( 'eZMyCollectedInfoRemoveID' )
    && $http->hasPostVariable( 'eZMyCollectedInfoRemoveIdentifier' )
    && $http->hasPostVariable( 'eZMyCollectedInfoRemoveObjectID' ) )
    {
        $identifier = $http->postVariable( 'eZMyCollectedInfoRemoveIdentifier' );
        $objectID = $http->postVariable( 'eZMyCollectedInfoRemoveObjectID' );
        
        // If object ID is valid
        if( is_numeric( $objectID ) )
        {
            $contentObject = eZContentObject::fetch( $objectID );

            // If object is valid
            if( is_object( $contentObject ) )
            {
                // If current user is owner of the object
                if( $contentObject->OwnerID == eZUser::currentUserID() )
                {
                    // Get ini settings
                    $ini = eZINI::instance( 'mycollectedinfo.ini' );
                    $typeINI = $ini->group( 'ClassSettings-' . $identifier );

                    // If the content object matches the class in the configuration
                    if( $contentObject->ClassIdentifier == $typeINI['ClassIdentifier'] )
                    {
                        
                        // If delete action is allowed for this class of collections
                        if( $typeINI['AllowDelete'] == 'true' )
                        {

                            // Get list of collections
                            $collectionList = eZInfocollectorFunctionCollection::fetchCollectionsList( $objectID );
                            // Get an array of collection IDs for removal
                            $collectionIDRemoveArray = array_keys( $http->postVariable( 'eZMyCollectedInfoRemoveID' ) );

                            // Go through the collection list
                            foreach( $collectionList['result'] as $collectionItem )
                            {
                                // If collection ID is in the array of IDs for removal, do remove
                                if( in_array( $collectionItem->ID, $collectionIDRemoveArray ) )
                                {
                                    eZInformationCollection::removeCollection( $collectionItem->ID );
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// If previous URI memorized, go there, if not, go to the view start
if( $http->hasSessionVariable( 'eZMyCollectedInfoLastURI' ) )
{
    $Module->redirectTo( $http->sessionVariable( 'eZMyCollectedInfoLastURI' ) );
}
else
{
    $Module->redirectToView( 'browse' );
}


?>