<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezmycollectedinfo

[RegionalSettings]
TranslationExtensions[]=ezmycollectedinfo

*/ ?>
