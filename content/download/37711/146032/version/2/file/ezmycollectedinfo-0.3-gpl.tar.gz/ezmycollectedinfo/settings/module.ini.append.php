<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezmycollectedinfo

*/ ?>
