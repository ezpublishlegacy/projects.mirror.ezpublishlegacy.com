<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmycollectedinfo/module</name>
    <message>
        <source>My collected info</source>
        <translation>My collected info</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Browse</translation>
    </message>
</context>
<context>
    <name>extension/ezmycollectedinfo/type</name>
    <message>
        <source>Test type</source>
        <translation>Test type</translation>
    </message>
    <message>
        <source>Test type 2</source>
        <translation>Test type 2</translation>
    </message>
</context>
<context>
    <name>extension/ezmycollectedinfo/tpl</name>
    <message>
        <source>You are not allowed to access collections of any type!</source>
        <translation>You are not allowed to access collections of any type!</translation>
    </message>
    <message>
        <source>Select the type of objects.</source>
        <translation>Select the type of objects.</translation>
    </message>
    <message>
        <source>Select the object.</source>
        <translation>Select the object.</translation>
    </message>
    <message>
        <source>No collections found.</source>
        <translation>No collections found.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Remove selected</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Created</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Author</translation>
    </message>
</context>
</TS>
