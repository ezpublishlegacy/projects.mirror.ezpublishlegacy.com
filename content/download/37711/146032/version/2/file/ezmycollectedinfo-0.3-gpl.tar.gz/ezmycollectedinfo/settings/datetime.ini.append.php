<?php /* #?ini charset="utf-8"?

[ClassSettings]
Formats[ezmycollectedinfo_date]=%l, %j %F %Y, %H:%i:%s

*/ ?>