<?php /* #?ini charset="utf-8"?

[GeneralSettings]
ScriptSiteAccess=ezwebin_site_admin
PhpCliCommand=/usr/local/php5/bin/php

*/ ?>
