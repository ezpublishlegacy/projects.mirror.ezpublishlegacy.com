<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezcrop

*/ ?>