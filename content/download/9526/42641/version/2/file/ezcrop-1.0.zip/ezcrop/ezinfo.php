<?php

class ezcropInfo
{
    static function info()
    {
        return array( 'Name' => "eZCrop extension",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 Maxime THOMAS",
                      'License' => "GNU General Public License v2.0",
                      'Includes the following third-party software' => array( 'Name' => 'Cropper',
                                                                              'Version' => '2.4',
                                                                              'License' => 'Copyright (c) 2006, David Spurr - BSD License',
                                                                              'For more information' => 'http://www.defusion.org.uk' )
                      );
    }
}
?>
