<?php
$Module = array( 'name' => 'eZCrop' );

$ViewList = array();
$ViewList['crop'] = array('script' => 'crop.php',
						  'ui_context' => 'navigation',
						  'default_navigation_part' => 'ezcroppart',
						  'params' => array( 'node_id', 'version_id')
						 );



?>
