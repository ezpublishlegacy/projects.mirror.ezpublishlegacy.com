<?php

include_once( "kernel/common/template.php" );
include_once( "extension/ezcrop/modules/crop/classes/imagemanipulationhandler.php");

$http = eZHTTPTool::instance();
$module = $Params["Module"];
$tpl = templateInit();
$errors = array();

$node_id=0;
$x1=0;
$y1=0;
$width=0;
$height=0;

//Checking errors
if (!isset($Params['node_id']) or $Params['node_id']=='')
{
	$errors[]='All information has not been provided, the url must be crop/crop/node_id/version_id';
	$errors[]='The node_id is not correct, please modify it.';
}
else
{
	$node_id = $Params['node_id'];
}

if (!isset($Params['version_id']) or $Params['version_id']=='')
{
	$errors[]='All information has not been provided, the url must be crop/crop/node_id/version_id';
	$errors[]='The version_id is not correct, please modify it.';
}
else
{
	$version_id = $Params['version_id'];
}


//If no error
if (count($errors)==0)
{
	$node = eZContentObjectTreeNode::fetch($node_id);
		
	if ($http->hasVariable('SaveButton'))
	{
		$tpl->setVariable('node', $node);
		if ($http->hasVariable('x1') and $http->variable('x1')!='')
		{
			$x1=$http->variable('x1');
		}
		else
		{
			$errors[]='You must provide a valid x1.';
		}
		
		if ($http->hasVariable('y1') and $http->variable('y1')!='')
		{
			$y1=$http->variable('y1');
		}
		else
		{
			$errors[]='You must provide a valid y1.';
		}
		
		if ($http->hasVariable('width') and $http->variable('width')!='')
		{
			$width=$http->variable('width');
		}
		else
		{
			$errors[]='You must provide a valid width.';
		}
		
		if ($http->hasVariable('height') and $http->variable('height')!='')
		{
			$height=$http->variable('height');
		}
		else
		{
			$errors[]='You must provide a valid height.';
		}
		
		if (count($errors)==0 and $height != 0 and $width != 0)
		{
			$imh = new ImageManipulationHandler($node);
			$version_id = $imh->crop($x1, $y1, $width, $height);
		}
		
	}
	elseif ($http->hasVariable('CancelButton'))
	{
		$params=array('full', $node_id);
		$module->redirect("content", "view", $params);
	}

	$contentObject = $node->object();
	$version=$contentObject->currentVersion();
	$current_version_id = $version->attribute('version');
	
	if ($version_id != $current_version_id)
	{
		$version = eZContentObjectVersion::fetchVersion( $version_id, $contentObject->attribute('id'), true);
	}

	$tpl->setVariable('version', $version);
	
	$node = eZContentObjectTreeNode::fetch($node_id);
	$tpl->setVariable('node', $node);
	

}

//Add the error array
$tpl->setVariable('errors', $errors);

$Result = array();
$Result['content'] = $tpl->fetch( "design:ezcrop/crop.tpl" );
$Result['left_menu'] = "design:ezcrop/crop_menu.tpl";
$Result['path'] = array( array( 'url' => false, 'text' => 'eZCrop' ) );


?>