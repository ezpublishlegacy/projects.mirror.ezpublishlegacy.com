<?php
/*
#?ini charset="iso-8859-1"?
# eZ publish configuration file for content
[image_crop]
Source=node/view/full.tpl
MatchFile=crop/image.tpl
Subdir=templates
Match[class_identifier]=image
*/
?>