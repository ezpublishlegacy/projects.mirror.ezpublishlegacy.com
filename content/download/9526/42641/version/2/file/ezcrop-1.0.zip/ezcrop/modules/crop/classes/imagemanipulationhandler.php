<?php

class ImageManipulationHandler
{
	function ImageManipulationHandler($node)
	{
		$this->node=$node;
	}
	
	function crop($x1, $y1, $width, $height)
	{
		$contentObject = $this->node->object();
		$contentObjectVersion = $contentObject->createNewVersion();

		$datamap = $contentObject->fetchDataMap($contentObjectVersion->attribute('version'));
		
		foreach ($datamap as $name => $attribute)
		{
			if ($name == "image")
			{
				$iah = $attribute->content();				
				$attributeData = $iah->attribute('original');
				
				$dir_path = $attributeData["dirpath"];
				$base_name = $attributeData["basename"];
				$suffix = $attributeData["suffix"];
				
				$source_name = $dir_path.eZSys::fileSeparator().$base_name.".".$suffix;
				$destination_name = $dir_path.eZSys::fileSeparator().$base_name."_cropped.".$suffix; 
				
				
				$crop = ' -crop "'.$width.'x'.$height.' +'.$x1.'+'.$y1.'"';
				$im = "convert $source_name $crop $destination_name";
				
				exec($im);
				$iah->initializeFromFile($destination_name);
				$attribute->store();
				
				unlink($destination_name);
			}
		}
		
		$contentObjectVersion->store();
		$contentObject->store();
		
		eZOperationHandler::execute("content","publish",array("object_id" => $contentObject->attribute("id"),"version" => $contentObjectVersion->attribute("version")));
		return $contentObjectVersion->attribute('version');	
	}
	
	public $node;
}

?>