<?php

function ezcrop_ContentActionHandler( $module, $http, $objectID )
{
	if ($http->hasPostVariable('CropAction'))
	{
		$object = eZContentObject::fetch($objectID);
		$version = $object->currentVersion();
		$version_id = $version->attribute("version");
		$node_id = $object->attribute('main_node_id');
		
		$module->redirectTo("crop/crop/$node_id/$version_id");
	}
	
}

?>