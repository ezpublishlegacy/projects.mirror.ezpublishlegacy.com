<?php /*

#[TemplateSettings]
#ExtensionAutoloadPath[]=ezcrop

[RegionalSettings]
TranslationExtensions[]=ezcrop

*/ ?>