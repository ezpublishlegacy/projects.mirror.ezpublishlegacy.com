ezColorPicker Datatype
----------------------


0. Intro
--------
This datatype extends the data_text type and gives a userfriendly way of choosing a color.


1. Installation
---------------
Follow these steps to add the ezColorPicker datatype to your ezp installation:

  1) Upload the mycolorpicker folder to the extension folder of your ez publish installation
  
  2) Activate it in the admin interface


2. Features
-----------
- Adds ezColorPicker datatype when creating/editing a class


3. Problems
-----------
- Position of the colorpicker in FireFox


Developed by Felix Laate (www.enternett.no)
