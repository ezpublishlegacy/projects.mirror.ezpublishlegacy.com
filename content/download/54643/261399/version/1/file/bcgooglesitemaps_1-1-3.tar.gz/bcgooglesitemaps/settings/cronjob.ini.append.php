<?php /* #?ini charset="utf-8"?

[CronjobPart-googlesitemaps]
Scripts[]
Scripts[]=generate.php

[CronjobPart-googlesitemapsmultilingual]
Scripts[]
Scripts[]=generatemultilingual.php

[CronjobSettings]
Scripts[]=generate.php
Scripts[]=ggeneratemultilingual.php
ExtensionDirectories[]=bcgooglesitemaps

*/ ?>