<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/wordtoimage/kernel/common/ezwordtoimageoperator.php',
                                    'class' => 'eZWordToImageOperator',
                                    'operator_names' => array( 'wordtoimage' ) );
