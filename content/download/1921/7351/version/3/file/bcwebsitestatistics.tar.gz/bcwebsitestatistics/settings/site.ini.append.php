<?php /* #?ini charset="utf-8"?

[TemplateSettings]
AutoloadPathList[]=extension/bcwebsitestatistics/autoloads

*/ ?>