<?php
class bcwebsitestatisticsInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/bcwebsitestatistics'>BC Website Statistics</a>",
            'Version' => "1.0.2",
            'Copyright' => "Copyright (C) 2001 - 2007 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Brookins Consulting",
            'License' => "GNU General Public License"
        );
    }
}
?>