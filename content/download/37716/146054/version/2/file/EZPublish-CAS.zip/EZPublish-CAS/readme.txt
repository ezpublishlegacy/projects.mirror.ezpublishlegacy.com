** OVERVIEW **

This patch allows EzPublish to be used with the Single Sign On server CAS (Central Authentication Service).

Thanks to SSO with CAS, users can log only once on several applications, as long as these applications are using CAS. CAS supports many types of clients (Java, PHP, Perl, Apache HTTPD) and some applications have a built-in support (ex.: Liferay Portal). The CAS server can be plugged to various user repository (LDAP, database, file...). 

This contribution has been tested in real world projects and has been made possible thanks to the SITIV (a french public organism).


** INSTALLATION **

Create (in EZpublish) admin user that is also in the user repository used by CAS (ex.: LDAP), otherwise you won't be able to log in when the patch is installed!

Save the ezuser.php file.

Copy the patch directories in the EZpublish directory.

The CAS configuration can be made in the file settings/cas.ini


** VERSIONS **

EZpublish: 3.7.1 and 3.8.6
CAS Server: 3.0.6
PHP-CAS: 0.5.0-RC4


** WEBSITES **

CAS Server: http://www.ja-sig.org/products/cas/index.html
PHP CAS: http://www.ja-sig.org/wiki/display/CASC/phpCAS
SITIV: http://www.sitiv.fr/
SQLI: http://www.sqli.com/

** LICENSE **

This patch is distributed under the LGPL license (http://www.gnu.org/licenses/lgpl.html) and comes without any warranty.

