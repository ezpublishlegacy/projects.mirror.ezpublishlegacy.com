var callgraph_8php =
[
    [ "$GLOBALS", "callgraph_8php.html#afd45803ab7ab0c0f29d337ecfc43e5bf", null ],
    [ "$GLOBALS", "callgraph_8php.html#a14111e48d5768845bd9184269880ec8f", null ],
    [ "$ini", "callgraph_8php.html#a8f5f30fbe4092bf20ba2fcae8197ab09", null ],
    [ "$params", "callgraph_8php.html#afe68e6fbe7acfbffc0af0c84a1996466", null ],
    [ "$xhprof_runs_impl", "callgraph_8php.html#a53bb2639e9192f4e2238a383863cdc04", null ]
];