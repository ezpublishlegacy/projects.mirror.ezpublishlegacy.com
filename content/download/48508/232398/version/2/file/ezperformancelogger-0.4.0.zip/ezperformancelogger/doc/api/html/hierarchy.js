var hierarchy =
[
    [ "eZPerfLogger", "classeZPerfLogger.html", null ],
    [ "eZPerfLoggerProvider", "interfaceeZPerfLoggerProvider.html", null ],
    [ "eZPerfLoggerStorage", "interfaceeZPerfLoggerStorage.html", [
      [ "eZPerfLoggerCSVStorage", "classeZPerfLoggerCSVStorage.html", null ]
    ] ],
    [ "eZperformanceloggerInfo", "classeZperformanceloggerInfo.html", null ],
    [ "eZPerformanceLoggerOperators", "classeZPerformanceLoggerOperators.html", null ],
    [ "eZXHProfLogger", "classeZXHProfLogger.html", null ],
    [ "iXHProfRuns", "interfaceiXHProfRuns.html", [
      [ "XHProfRuns_Default", "classXHProfRuns__Default.html", null ]
    ] ]
];