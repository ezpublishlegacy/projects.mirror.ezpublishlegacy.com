var searchData=
[
  ['gen_5frun_5fid',['gen_run_id',['../classXHProfRuns__Default.html#af760c2d84a6194a5cdff65369d1b3ab7',1,'XHProfRuns_Default']]],
  ['get_5fprint_5fclass',['get_print_class',['../xhprof_8php.html#a4189eb71e97434ee4a28d7c3ae0b0d92',1,'xhprof.php']]],
  ['get_5frun',['get_run',['../interfaceiXHProfRuns.html#a18cf4b6e2152e2139f0542be06d16283',1,'iXHProfRuns\get_run()'],['../classXHProfRuns__Default.html#af96022620953357ee599aaf3b23b89ce',1,'XHProfRuns_Default\get_run()']]],
  ['get_5ftooltip_5fattributes',['get_tooltip_attributes',['../xhprof_8php.html#a468f9f85fd02172f88c05d5b0374ecf8',1,'xhprof.php']]]
];
