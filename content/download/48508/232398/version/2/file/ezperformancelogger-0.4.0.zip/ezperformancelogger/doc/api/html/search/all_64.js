var searchData=
[
  ['displayxhprofreport',['displayXHProfReport',['../xhprof_8php.html#a5e787738f41ae3f516367b9234c522fa',1,'xhprof.php']]]
];
