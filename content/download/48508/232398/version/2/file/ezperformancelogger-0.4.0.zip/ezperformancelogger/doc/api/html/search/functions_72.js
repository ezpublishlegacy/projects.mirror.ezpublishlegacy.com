var searchData=
[
  ['recordvalue',['recordValue',['../classeZPerfLogger.html#a26375ce3a77d6cbdafb106c351aa6961',1,'eZPerfLogger']]],
  ['removesavedruns',['removeSavedRuns',['../classeZXHProfLogger.html#ad93053d75df80d41f14557bee9e97c37',1,'eZXHProfLogger']]],
  ['runs',['runs',['../classeZXHProfLogger.html#a9fb17d2010fa0b9ea638cd15aefc53e2',1,'eZXHProfLogger']]]
];
