var searchData=
[
  ['info',['info',['../classeZperformanceloggerInfo.html#a58a9b0ad80ed28ec99e6c910996fc6e7',1,'eZperformanceloggerInfo']]],
  ['init_5fmetrics',['init_metrics',['../xhprof_8php.html#ac0a56fe454d451714e26cacf7c6a007b',1,'xhprof.php']]],
  ['insertstats',['insertStats',['../classeZPerfLoggerCSVStorage.html#a224bc5b9b7e4e68efd1b97ad28ac87ed',1,'eZPerfLoggerCSVStorage\insertStats()'],['../interfaceeZPerfLoggerStorage.html#ae9d081fbe8ea531a67c713ae23bef307',1,'eZPerfLoggerStorage\insertStats()']]],
  ['isrunning',['isRunning',['../classeZXHProfLogger.html#a80dbdea0e69c9f740ef13d86e8754207',1,'eZXHProfLogger']]]
];
