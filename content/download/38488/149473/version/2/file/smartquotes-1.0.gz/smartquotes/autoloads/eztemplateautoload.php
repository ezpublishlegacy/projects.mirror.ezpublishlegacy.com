<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/smartquotes/autoloads/smartquotes_operator.php',
         'class' => 'SmartQuotesOperator',
         'operator_names' => array( 'ezsmartquotes', 'smartquotes', 'smartq' ) );

?>