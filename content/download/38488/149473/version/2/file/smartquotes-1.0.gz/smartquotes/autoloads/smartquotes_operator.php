<?php

# SmartyPants operator for eZ publish
# (c) 2005-2006 Peter Putzer <pputzer@user.sourceforge.net>

global $iniSQ;
$iniSQ = eZINI::instance("smartquotes.ini");
 
if ( $iniSQ->hasVariable( "General", "SmartyPantsAttributes" ) ) {
	define( 'SMARTYPANTS_ATTR', $iniSQ->variable( "General", "SmartyPantsAttributes" ) );
} else {
	define( 'SMARTYPANTS_ATTR', "3" );
}

# Opening and closing smart double-quotes.
if ( $iniSQ->hasVariable( "Characters", "DoubleQuoteOpen" ) ) {
	define( 'SMARTYPANTS_SMART_DOUBLEQUOTE_OPEN', $iniSQ->variable( "Characters", "DoubleQuoteOpen" ) );
} else {
	define( 'SMARTYPANTS_SMART_DOUBLEQUOTE_OPEN',  "&ldquo;" );
}
if ( $iniSQ->hasVariable( "Characters", "DoubleQuoteClose" ) ) {
	define( 'SMARTYPANTS_SMART_DOUBLEQUOTE_CLOSE', $iniSQ->variable( "Characters", "DoubleQuoteClose" ) );
} else {
	define( 'SMARTYPANTS_SMART_DOUBLEQUOTE_CLOSE', "&rdquo;" );
}

# Opening and closing smart single-quotes.
if ( $iniSQ->hasVariable( "Characters", "SingleQuoteOpen" ) ) {
	define( 'SMARTYPANTS_SMART_SINGLEQUOTE_OPEN', $iniSQ->variable( "Characters", "SingleQuoteOpen" ) );
} else {
	define( 'SMARTYPANTS_SMART_SINGLEQUOTE_OPEN',  "&lsquo;" );
}
if ( $iniSQ->hasVariable( "Characters", "SingleQuoteClose" ) ) {
	define( 'SMARTYPANTS_SMART_SINGLEQUOTE_CLOSE', $iniSQ->variable( "Characters", "SingleQuoteClose" ) );
} else {
	define( 'SMARTYPANTS_SMART_SINGLEQUOTE_CLOSE', "&rsquo;" );
}

# Smart apostrophe.
if ( $iniSQ->hasVariable( "Characters", "Apostrophe" ) ) {
	define( 'SMARTYPANTS_SMART_APOSTROPHE', $iniSQ->variable( "Characters", "Apostrophe" ) );
} else {
	define( 'SMARTYPANTS_SMART_APOSTROPHE', "&rsquo;" );
}

# Space around em-dashes.  "He_�_or she_�_should change that."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceEmDash" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceEmDash" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_EMDASH', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_EMDASH', $iniSQ->variable( "Whitespace", "SpaceEmDash" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_EMDASH', " " );
}

# Space around en-dashes.  "He_�_or she_�_should change that."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceEnDash" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceEnDash" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_ENDASH', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_ENDASH', $iniSQ->variable( "Whitespace", "SpaceEnDash" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_ENDASH', " " );
}

# Space before a colon. "He said_: here it is."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceColon" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceColon" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_COLON', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_COLON', $iniSQ->variable( "Whitespace", "SpaceColon" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_COLON', "&#160;" );
}

# Space before a semicolon. "That's what I said_; that's what he said."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceSemiColon" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceSemiColon" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_SEMICOLON', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_SEMICOLON', $iniSQ->variable( "Whitespace", "SpaceSemiColon" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_SEMICOLON', "&#160;" );
}

# Space before a question mark and an exclamation mark: "�_Hol�_! What_?"
if ( $iniSQ->hasVariable( "Whitespace", "SpaceMarks" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceMarks" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_MARKS', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_MARKS', $iniSQ->variable( "Whitespace", "SpaceMarks" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_MARKS', "&#160;" );
}

# Space inside french quotes. "Voici la �_chose_� qui m'a attaqu�."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceFrenchQuote" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceFrenchQuote" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_FRENCHQUOTE', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_FRENCHQUOTE', $iniSQ->variable( "Whitespace", "SpaceFrenchQuote" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_FRENCHQUOTE', "&#160;" );
}

# Space as thousand separator. "On compte 10_000 maisons sur cette liste."
if ( $iniSQ->hasVariable( "Whitespace", "ThousandSeparator" ) ) {
	if ( $iniSQ->variable( "Whitespace", "ThousandSeparator" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_THOUSAND', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_THOUSAND', $iniSQ->variable( "Whitespace", "ThousandSeparator" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_THOUSAND', "&#160;" );
}

# Space before a unit abreviation. "This 12_kg of matter costs 10_$."
if ( $iniSQ->hasVariable( "Whitespace", "SpaceUnit" ) ) {
	if ( $iniSQ->variable( "Whitespace", "SpaceUnit" ) == "<plain>" ) {
		define( 'SMARTYPANTS_SPACE_UNIT', " " );
	} else {
		define( 'SMARTYPANTS_SPACE_UNIT', $iniSQ->variable( "Whitespace", "SpaceUnit" ) );
	}
} else {
	define( 'SMARTYPANTS_SPACE_UNIT', "&#160;" );
}

# SmartyPants will not alter the content of these tags:
if ( $iniSQ->hasVariable( "General", "TagSkipList" ) ) {
	define( 'SMARTYPANTS_TAGS_TO_SKIP', implode( "|", $iniSQ->variable( "General", "TagSkipList" ) ) );
} else {
	define( 'SMARTYPANTS_TAGS_TO_SKIP', 'pre|code|kbd|script|math' );
}

# The characters that may appear in single quotes
if ( $iniSQ->hasVariable( "General", "LegalCharsInSingleQuotesList" ) ) {
	define( 'SMARTYPANTS_LEGAL_CHARS_IN_SINGLEQUOTES', implode( "|", $iniSQ->variable( "General", "LegalCharsInSingleQuotesList" ) ) );
} else {
	define( 'SMARTYPANTS_LEGAL_CHARS_IN_SINGLEQUOTES', '\\w|,|:|\.|-|&\#8211;|&\#8212;' );
}

# The year endings
# The characters that may appear in single quotes
if ( $iniSQ->hasVariable( "General", "YearEndingList" ) ) {
	define( 'SMARTYPANTS_YEAR_ENDINGS', implode( "|", $iniSQ->variable( "General", "YearEndingList" ) ) );
} else {
	define( 'SMARTYPANTS_YEAR_ENDINGS', 's' );
}

include_once "smartypants.php";

class SmartQuotesOperator
{
    /*!
     Constructor
    */
    function SmartQuotesOperator()
    {
        $this->Operators = array( 'ezsmartquotes', 'smartquotes', 'smartq' );
    }

    /*!
     Returns the operators in this class.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     \return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array();                      
    }

    /*!
     Executes the needed operator(s).
     Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                     &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'ezsmartquotes':
			case 'smartquotes':
			case 'smartq':
            {
                $operatorValue = $this->ezsmartquotes( $operatorValue );
            } break;
        }
    }

    function ezsmartquotes( &$operatorValue )
    { 
        return SmartyPants( $operatorValue );
    }

    /// \privatesection
    var $Operators;
}

?>