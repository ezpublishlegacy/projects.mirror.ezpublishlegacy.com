<?php

[TemplateSettings]
ExtensionAutoloadPath[]=smartquotes

?>