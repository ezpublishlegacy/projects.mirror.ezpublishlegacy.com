Croatian translation for eZ publish 3.10, v1.0
=============================================

Place included files into these eZ publish directories:

/share/locale/cro-HR.ini
/share/translations/cro-HR/translation.ts

If you have comments or suggestions regarding croatian translation, please contact us at support _at_ netgen.hr
