UPDATE ezsite_data SET value='3.8.8' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='14' WHERE name='ezpublish-release';
