UPDATE ezsite_data SET value='3.10.0' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='4' WHERE name='ezpublish-release';
