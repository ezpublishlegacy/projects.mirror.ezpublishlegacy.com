#!/bin/sh

echo "WARNING! This script is deprecated. Please use ora-drop-schema.php instead."
exit 1
