<?php
/*
[ExtensionSettings]
DesignExtensions[]=ezclasslists

[StylesheetSettings]
CSSFileList[]=classlists.css


*/
?>
