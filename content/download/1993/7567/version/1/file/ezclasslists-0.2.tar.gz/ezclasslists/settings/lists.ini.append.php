<?php /*

[Delete]
ConfirmJavascript=enabled
DefaultMoveToTrash=enabled


*/ ?>
