<?php
/*
[ModuleSettings]
ExtensionRepositories[]=ezclasslists
ModuleList[]=classlists


*/
?>
