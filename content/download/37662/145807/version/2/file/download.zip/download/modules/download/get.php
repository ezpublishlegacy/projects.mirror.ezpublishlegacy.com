<?php
//
// Created on: <21-Apr-2004 09:18:06 bf>
//
// Copyright (C) 1999-2004 Musikverlage Hans Gerig. All rights reserved.
//
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( "lib/ezutils/classes/ezsys.php" );
include_once( "lib/ezutils/classes/ezdir.php" );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );  
include_once( "wizPDFTagger.php" );  

$Module =& $Params['Module'];

/**
 * Loads a file from store, adding it from eZStorage if necessary
 * @author <a href="Dominik@pich.info">Dominik Pich</a>
 * @version 1.0
 * @todo heavy testing, testing, testing
 */
class daijBinaryStore
{
	var $storageDir;
	
	function daijBinaryStore( $storageDir = false )
	{
		if( !$storageDir )
		{
			$storage = eZSys::storageDirectory();
			$storageDir = $storage . "/modified/binary";
			if ( !file_exists( $storageDir ) )
			{
				eZDir::mkdir( $storageDir, 0777, true);
			}			
		}
		$this->storageDir = $storageDir;
	}

	function &getFile( $fileName = false )
	{
		$file = array();

		if( $fileName )
		{
			$storage = eZSys::storageDirectory();
			$base = eZSys::wwwDir();
			
			//build paths
			$fileOrig = $storage . '/original/binary/' . $fileName;
			$fileNow = $this->storageDir .'/' . $fileName;
			eZDebug::writeDebug( 'copying "' . $fileOrig . '" to "' . $fileNow . '"' );
			
			//copy file into storage
			if( !file_exists( $fileNow ) && file_exists( $fileOrig ) )
			{
				//BUGBUG: switch mime type
				
				//construct tag
				$id = 1;
				$email = "nobody@gerig.de";
				$date = date("l dS of F Y H:i:s");
				
				TagAndSavePdf( $id . ' ' . $email . ' - ' . $date, $fileNow ); 
								
				$errors = $tagger->getErrors();
				if( count( $errors ) )
				{
					eZDebug::writeDebug( 'PDF generation errors: ' );
					eZDebug::writeDebug( $errors );
				}				
			}
			
			//return info		
			$file[ "link" ]	= $base . '/';
			if( file_exists( $fileNow ) )
			{	
				$file[ "name" ] = $fileName;
				$file[ "link" ] = $base . '/' . $fileNow;
				$file[ "valid" ] = true;
			}
		}
		
		return $file;
	}
	
	function clearStorage()
	{
		$time = time();
		$time -= 60000;
		$this->deleteFiles( $this->storageDir, '*.*', $time );
	}

	/**
	 * Delete the files
	 * @param dir The directory in which to delete the files specified by the pattern.
	 * @param pattern The pattern to which files to match which are to be deleted.
	 * @time The time files must be older than to be deleted.
	 */
	function deleteFiles( $dir, $pattern = "*.*", $time = 0 )
	{
		$deleted = false;
		$pattern = str_replace(array("\*","\?"), array(".*","."), preg_quote($pattern));
		if (substr($dir,-1) != "/") $dir.= "/";
		if (is_dir($dir))
		{
			$d = opendir($dir);
			while ($file = readdir($d))
			{
				if (is_file($dir.$file) && ereg("^".$pattern."$", $file) )
				{
					$ft = -1;
					if ($time > 0 )
					{
						$ft = fileatime($dir.$file);
						$ft -= time();
					}
					
					if ($ft < 0 && unlink($dir.$file))
						$deleted[] = $file;
				}
			}
			closedir($d);
			return $deleted;
		}
		else
		{
			return 0;
		}
	}
}	

//get posted var
$fileName = false;
if ( eZHTTPTool::hasVariable( "fileName" ) )
	$fileName = eZHTTPTool::variable( "fileName" );
eZDebug::writeDebug( $fileName );	

//invoke store
$daijBinary = new daijBinaryStore();
$file = $daijBinary->getFile( $fileName );
eZDebug::writeNotice( $file );
$daijBinary->clearStorage();

//ready template
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'file', $file );

$Result = array();
$Result['content'] = $tpl->fetch( "design:download/get.tpl" );
$Result['path'] = array( array( 'url' => false,
                        'text' => 'download' ),
                        array( 'url' => false,
                        'text' => 'get' ) );
?>