<?php
//
// Created on: <21-Apr-2004 09:18:06 bf>
//
// Copyright (C) 1999-2004 Musikverlage Hans Gerig. All rights reserved.
//
$Module = array( 'name' => 'download' );

$ViewList['get'] = array(
    'script' => 'get.php',
    'params' => array( ),
    'default_navigation_part' => 'ezmynavigationpart' );
?>