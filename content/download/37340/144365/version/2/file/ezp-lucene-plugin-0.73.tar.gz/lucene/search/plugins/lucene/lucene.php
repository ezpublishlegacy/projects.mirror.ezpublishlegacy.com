<?php
//
// Definition of Lucene
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: Lucene search plugin for eZ publish
// SOFTWARE RELEASE: 0.x
// COPYRIGHT NOTICE: Copyright (C) 2006 Paul Borgermans <paul[dot]borgermans[at]gmail[dot]com> and Kristof Coomans <kristof[dot]coomans[at]telenet[dot]be>
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

class Lucene
{
    var $indexDir;
    var $analyzer;
    var $writer;
    var $searchLogDir;
    var $searchLogWriter;
    var $reader;
    var $searcher;

    //the following function was copied from php.net for php4 compatibility adn to provide search timing
    function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }
    //axiliary function for field array filtering
    function isNotMetaField( $element )
    {
        return ( !(strpos( $element, 'm_' ) === 0 ) );
    }

    function Lucene()
    {
        include_once( 'lib/ezutils/classes/ezsys.php' );
        $varDirPath = realpath( eZSys::varDirectory() );
        $indexDirPath = $varDirPath . eZSys::fileSeparator() . 'lucene' . eZSys::fileSeparator() . 'main';
        $searchLogDirPath = $varDirPath . eZSys::fileSeparator() . 'lucene' . eZSys::fileSeparator() . 'searchlog';
        eZDebug::writeDebug( $indexDirPath . ';' . $searchLogDirPath , 'Lucene::setup lucene index dir; searchlog dir' );

        //PATH MADNESS: different results when when scripts using this classrun from commandline or through the web backend!! A bug in ezSYS? PHP settings?
        //Nevertheless, the construct below works
        $luceneExtensionDir = realpath( 'extension' . eZSys::fileSeparator() . 'lucene' . eZSys::fileSeparator() . 'java' . eZSys::fileSeparator() );

        eZDebug::writeDebug( $luceneExtensionDir, 'Lucene::setup lucene extension dir' );
        $requireJar = (string)($luceneExtensionDir . '/lucene-core-1.9.1.jar' . ';' . $luceneExtensionDir . '/contrib/similarity/lucene-similarity-1.9.1.jar');
        java_require( $requireJar );

        $this->indexDir = new Java( 'java.io.File', $indexDirPath );
        $this->searchLogDir = new Java( 'java.io.File', $searchLogDirPath );
        $this->analyzer = new Java( 'org.apache.lucene.analysis.standard.StandardAnalyzer' );
    }

    function initWriter( $createNewIndex = false )
    {
        
        //close this writer if it exists
        if ( $this->writer )
            $this->writer->close();
        // should check for locked dir in fact but closing should remove a writer lock if called in the same session
        
        
        $this->writer = new Java( 'org.apache.lucene.index.IndexWriter', $this->indexDir, $this->analyzer, $createNewIndex );
        eZDebug::writeDebug( $this->writer, 'Lucene::init tried opening writer on ' . ($createNewIndex ? 'new' : 'old') .' index' );
  
        
        if ( $this->writer  )
        {
            return true;
        }
        else
        {
            eZDebug::writeDebug( $this->writer, 'Lucene::initWriter failed trying opening writer on ' . ($createNewIndex ? 'new' : 'old') .' index' );
            return false;
        }
    }

    function initSearchLogWriter( $createNewIndex = false )
    {
        if ( $this->searchLogWriter )
            $this->searchLogWriter->close();
        
        $this->searchLogWriter = new Java( 'org.apache.lucene.index.IndexWriter', $this->searchLogDir, $this->analyzer, $createNewIndex );
            // check if the writer is valid, if not, clear search log and start a new one
            // better: throw an exception?
        if ( $this->searchLogWriter )
        {
            return true;
        }
        else
        {
            eZDebug::writeDebug( $this->searchLogWriter, 'Lucene::init failed trying opening search log writer on ' . ($createNewIndex ? 'new' : 'old') .' index' );
            return false;
        }


    }

    function cleanup()
    {
        if ( !$this->writer )
        {
             $this->writer = new Java( 'org.apache.lucene.index.IndexWriter', $this->indexDir, $this->analyzer, true );
             //$exception = java_last_exception_get();
             //print ( $exception->getMessage() );
        }
        if ( is_object( $this->writer ) )
        {
            $this->writer->optimize();
            $this->writer->close();
        } 
        else
        {
            print("Must have a valid writer object!\n");
        }
    }

    function optimize()
    {
        if ( !$this->writer )
            $this->writer = new Java( 'org.apache.lucene.index.IndexWriter', $this->indexDir, $this->analyzer, false );
        if ( !$this->writer )
            print ("Cannot open writer to optimize index!!");
        $this->writer->optimize();
        $this->writer->close();
    }

    function removeObject( $contentObject, $keepReaderOpen = false )
    {
        if ( !$this->reader )
        {
            $IndexReader = new JavaClass( 'org.apache.lucene.index.IndexReader' );
            $this->reader = $IndexReader->open( $this->indexDir );
        }
        //safety measure to avoid inconsistencies
        if ( !is_object( $this->reader ) )
        {
             eZDebug::writeDebug( $contentObject->attribute( 'id' ), "cannot open reader, probably locked by concurrent index update process" );
             return false;
        }

        $term = new Java( 'org.apache.lucene.index.Term', 'm_id', (string)$contentObject->attribute( 'id' ) );
        if (is_object( $term ))
        {
             $this->reader->delete( $term );
        }
        if ( !$keepReaderOpen )
            $this->reader->close();
        return true;
    }
    
    function metaKeywordAttributes()
    {
    
    }

    //this lucene implementation has an extra parameter $doInitWriter for efficiency in batch updates
    function addObject( &$contentObject, $uri, $doInitWriter = true )
    {
        if ($doInitWriter)
        {
             $this->initWriter( false );
        }
        //safety measure to avoid inconsistencies
        if ( !is_object( $this->writer ) )
        {
            eZDebug::writeDebug( $contentObject->attribute( 'id' ), "cannot open writer, probably locked by concurrent index update process or an initial index has not been made (run the lucene index script)" );
            return;
        }


        $doc = new Java( 'org.apache.lucene.document.Document' );
        //$Field = new JavaClass( 'org.apache.lucene.document.Field' );
        $FieldStore = new JavaClass( 'org.apache.lucene.document.Field$Store' );
        $FieldIndex = new JavaClass( 'org.apache.lucene.document.Field$Index' );
        $FieldTermVector = new JavaClass( 'org.apache.lucene.document.Field$TermVector' );
        $iniLucene = eZINI::instance( "lucene.ini" );
        $useTermVectors = $FieldTermVector->NO;
        if ( $iniLucene->hasVariable( "General", "EnableTermVectors" ) && $iniLucene->variable( "General", "EnableTermVectors" ) == 'yes' )
        {
            $useTermVectors = $FieldTermVector->WITH_POSITIONS_OFFSETS;
        }
        $boostMetaFields = $iniLucene->hasVariable( "Boost", "MetaField" ) ? $iniLucene->variable( "Boost", "MetaField" ) : array();
        $boostClasses = $iniLucene->hasVariable( "Boost", "Class" ) ? $iniLucene->variable( "Boost", "Class" ) : array();
        $boostAttributesIni = $iniLucene->hasVariable( "Boost", "Attribute" ) ? $iniLucene->variable( "Boost", "Attribute" ) : array();
        //prepare attribute boost factors
        $boostAttributes = array();

        foreach ( $boostAttributesIni as $boostAttributeKey => $boostAttributeValue )
        {
            $attributeConditions = array();
            $attributeConditions = split( '/', $boostAttributeKey );
            if ( count( $attributeConditions ) == 2 )
            {
                $boostAttributes[$attributeConditions[1]]=array( $boostAttributeValue, $attributeConditions[0] );
            } else if ( count( $attributeConditions ) == 1 )
            {
                $boostAttributes[$attributeConditions[0]]=array( $boostAttributeValue, false );
            } else
            {
                eZDebug::writeDebug( $boostAttributeKey, 'Lucene::index cannot parse $boostAttributeKey' );
            }
        }

        $boostDatatypes = $iniLucene->hasVariable( "Boost", "Datatype" ) ? $iniLucene->variable( "Boost", "Datatype" ) : array();
        $reverseRelatedScale = $iniLucene->hasVariable( "Boost", "ReverseRelatedScale" ) ? $iniLucene->variable( "Boost", "ReverseRelatedScale" ) : 0.5;

        //Class level boost if applicable
        //we do the boost here before boosting fields as the default boost factor is defined here
        $objectClassIdentifier = $contentObject->attribute( 'class_identifier' );
        if ( in_array( $objectClassIdentifier, array_keys( $boostClasses ) ) && is_numeric( $boostClasses[$objectClassIdentifier] ) )
        {
            $doc->setBoost( $doc->getBoost() + $boostClasses[$objectClassIdentifier] );
            //print ('boosting ' . $objectClassIdentifier . ' with factor ' . $doc->getBoost() . "\n");
        }
        
        //Document boosting heuristic based on reverse related object count.
        //Actually the term vectors should be compared too for a real measure of importance,
        //but let's assume it makes sense now even without this measure
        $reverseRelatedObjectCount = $contentObject->reverseRelatedObjectCount();
        //store a 10 position padded string representation of the integer value
        //$doc->add( $Field->Keyword( 'm_reverse_related_count', sprintf( "%010s", $reverseRelatedObjectCount ) ) );
        $doc->setBoost( $doc->getBoost() + ( $reverseRelatedScale * $reverseRelatedObjectCount ) );

        //list of meta-fields which will be stored as keywords (untokenized)
        $keywordAttributes = array(
            'id',
            'section_id',
            'owner_id',
            'contentclass_id',
            'current_version',
            'remote_id',
            'class_identifier',
            'main_node_id',
            'modified',
            'published',
            //added after 0.2 release, need recreate of index
            'main_parent_node_id',
            'related_contentobject_count',
            'reverse_related_contentobject_count'
            );
            
        //list of meta-fields which will be indexed (tokenized and parsed) 
        $textAttributes = array(
            'name',
            'class_name'
        );
        //enable sorting by storing these fields untokenized and unstored (save a bit place)
        $sortAttributes = array(
            'name',
            'class_name'
        );
        

        $codec = $this->getCodecToLucene();

        foreach ( $keywordAttributes as $keywordAttribute )
        {
            //add a prefix to avoid Analyzer issues that throw away our fields like 'name'
            $fieldName = 'm_' . $keywordAttribute;
            $field = new Java( 'org.apache.lucene.document.Field', (string)$fieldName, $codec->convertString((string)$contentObject->attribute( $keywordAttribute )), $FieldStore->YES, $FieldIndex->UN_TOKENIZED   );
            if ( is_object($field) )
            {
                //the comparison below would be faster with is_numeric( $boostMetaFields[$keywordAttribute] ) alone
                if ( in_array( $keywordAttribute, array_keys( $boostMetaFields ) ) && is_numeric( $boostMetaFields[$keywordAttribute] ) )
                {
                    $field->setBoost( $boostMetaFields[$keywordAttribute] );
                }
                $doc->add( $field );
            }
            else {print ('trouble, no object for keywordattribute ' . $fieldName . " "); print_r ($contentObject->attribute('name')); print("\n");}
        }

        foreach ( $textAttributes as $textAttribute )
        {
            //add a prefix to avoid Analyzer issues that throw away our fields like 'name'
            $fieldName = 'm_' . $textAttribute;
            $field = new Java( 'org.apache.lucene.document.Field', (string)$fieldName, $codec->convertString((string)$contentObject->attribute( $textAttribute )), $FieldStore->YES, $FieldIndex->TOKENIZED, $useTermVectors );
            if ( is_object($field) )
            {
                //the comparison below would be faster with is_numeric( $boostMetaFields[$keywordAttribute] ) alone
                if ( in_array( $textAttribute, array_keys( $boostMetaFields ) ) && is_numeric( $boostMetaFields[$textAttribute] ) )
                {
                    $field->setBoost( $boostMetaFields[$textAttribute] );
                }

                $doc->add( $field );
            }
            else {print ('trouble, no object for text attribute ' . $fieldName . " "); print_r ($contentObject->attribute('name')); print("\n");}
        }
                
        foreach ( $sortAttributes as $sortAttribute )
        {
            $fieldName = 'sort_' . $sortAttribute;
            //lucene 2.0 syntax!!
            $field = new Java( 'org.apache.lucene.document.Field', (string)$fieldName, $codec->convertString((string)$contentObject->attribute( $sortAttribute )), $FieldStore->NO, $FieldIndex->UN_TOKENIZED  );
            if ( is_object($field) )
            {
                $doc->add( $field );
            }
            else 
                {print ('trouble, no object for sort attribute ' . $fieldName . " "); print_r ($contentObject->attribute('name')); print("\n");}
         
        }

        //add owner name to search index, something the standard search plugin does not
        $owner = $contentObject->attribute( 'owner' );
        if ( $owner )
        {
            $field = new Java( 'org.apache.lucene.document.Field', 'm_owner_name', $codec->convertString($owner->attribute( 'name' )), $FieldStore->YES, $FieldIndex->TOKENIZED, $useTermVectors );
            //add field for sorting too

            if ( in_array( 'owner_name' , array_keys( $boostMetaFields ) ) && is_numeric( $boostMetaFields['owner_name'] ) )
            {
                $field->setBoost( $boostMetaFields['owner_name'] );
            }

            if ( is_object($field) )
            {
                $doc->add( $field );
            }
            else 
                {print ('trouble, no object for owner attribute '); print_r ($contentObject->attribute('name')); print("\n");}
            
            $sortField = new Java( 'org.apache.lucene.document.Field', 'sort_owner_name', $codec->convertString($owner->attribute( 'name' )), $FieldStore->NO, $FieldIndex->UN_TOKENIZED );
            if ( is_object($sortField) )
            {
                $doc->add( $sortField );
            }
            else 
                {print ('trouble, no object for owner attribute sort '); print_r ($contentObject->attribute('name')); print("\n");}


        }
        else
        {
            {print ('trouble, no owner attribute' . " "); print_r ($contentObject->attribute('name')); print("\n");}

        }

        //no boost for path string
        $mainNode = $contentObject->attribute( 'main_node' );
        if ( $mainNode )
        {
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_path_string', $mainNode->attribute( 'path_string' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_url_alias', $mainNode->attribute( 'url_alias' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_children_count', $mainNode->attribute( 'children_count' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_priority', $mainNode->attribute( 'priority' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_sort_field', $mainNode->attribute( 'sort_field' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_sort_order', $mainNode->attribute( 'sort_order' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_main_depth', $mainNode->attribute( 'depth' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );

        }

        $nodes = &$contentObject->assignedNodes();
        foreach ( $nodes as $node )
        {
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_path_string', $node->attribute( 'path_string' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_url_alias', $node->attribute( 'url_alias' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_children_count', $node->attribute( 'children_count' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_priority', $mainNode->attribute( 'priority' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_sort_field', $mainNode->attribute( 'sort_field' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_sort_order', $mainNode->attribute( 'sort_order' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'm_depth', $mainNode->attribute( 'depth' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
        }

        $currentVersion =& $contentObject->currentVersion();
        eZContentObject::recursionProtectionStart();

        foreach ( $currentVersion->contentObjectAttributes() as $attribute )
        {
            $metaData = array();
            $classAttribute =& $attribute->contentClassAttribute();
            if ( $classAttribute->attribute( 'is_searchable' ) == 1 )
            {
                // Fetch attribute translations
                // This should be changed, certainly with 3.8 multiple language model
                // We may change this by adding th elanguage in the field name
                // like attr_title@en_GB
                // or store each translation as a new lucene doc with a language meta field
                $attributeTranslations = $attribute->fetchAttributeTranslations();

                foreach ( $attributeTranslations as $translation )
                {
                    $tmpMetaData = $translation->metaData();
                    if( ! is_array( $tmpMetaData ) )
                    {
                        $tmpMetaData = array( array( 'id' => '',
                                                     'text' => $tmpMetaData ) );
                    }
                    $metaData = array_merge( $metaData, $tmpMetaData );
                }

                foreach( $metaData as $metaDataPart )
                {
                    $text_maxlength=150000; //should switch to a reader class object with the output dumped in a temp file which is passed to lucene

                    if ( strlen( $metaDataPart['text']) > $text_maxlength)
                    {
                        $metaDataPart['text'] = substr( $metaDataPart['text'], 0, $text_maxlength );
                    }

                    $metaDataPart['text'] = strip_tags( $metaDataPart['text'] );
                    //add a prefix to avoid Analyzer issues that throw away our fields like 'name'
                    //here we delibertaely allow duplicates, as we have class ids in another field .. might be interesting after all
                    $fieldName = 'attr_' . $classAttribute->attribute( 'identifier' );
                    $attributeField = new Java( 'org.apache.lucene.document.Field', (string)$fieldName, $codec->convertString((string)$metaDataPart['text']), $FieldStore->YES, $FieldIndex->TOKENIZED, $useTermVectors );
                    $attributeIdentifier = $classAttribute->attribute( 'identifier' );
                    $contentClassAttributeIdentifier = $attribute->contentClassAttributeIdentifier();
                    if ( in_array( $attributeIdentifier, array_keys( $boostAttributes ) ) &&
                         ( ($objectClassIdentifier == $boostAttributes[$attributeIdentifier][1]) || !$boostAttributes[$attributeIdentifier][1] ) )
                    {
                        $attributeField->setBoost( $boostAttributes[$attributeIdentifier][0] );
                    }

                    if ( in_array( $contentClassAttributeIdentifier, array_keys( $boostDatatypes ) ) )
                    {
                        $attributeField->setBoost( $boostDatatypes[$contentClassAttributeIdentifier] );
                    }

                    if ( is_object($attributeField) )
                    {
                        $doc->add( $attributeField );
                    }
                    else 
                   {print ('trouble, no object for sort attribute' . $fieldName . " "); print_r ($contentObject->attribute('name')); print("\n");}
                }
            }
        }
        eZContentObject::recursionProtectionEnd();

        $this->writer->addDocument( $doc );

        if ($doInitWriter)
        {
            $this->writer->close();
        }
    }

    function buildAccessQuery ( $start_time = 0 )
    {
        $limitationQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
        $Occur = new JavaClass( 'org.apache.lucene.search.BooleanClause$Occur' );


        include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
        $currentUser =& eZUser::currentUser();
        $accessResult = $currentUser->hasAccessTo( 'content', 'read' );

        if ( $accessResult['accessWord'] == 'no' )
        {
            $limitationList = false;
            // shouldn't we return an empty array if the user does not have access to read anything?
            // return array();
        }
        else if ( $accessResult['accessWord'] == 'limited' )
        {
            $limitationList =& $accessResult['policies'];
        }
        else if ( $accessResult['accessWord'] == 'yes' )
        {
            $limitationList = false;
        }

        eZDebug::writeDebug( $limitationList, 'Lucene::search limitationlist generated by ezcontentobjecttreenode' );
        $sqlPermissionCheckingString = eZContentObjectTreeNode::createPermissionCheckingSQLString( $limitationList );
        eZDebug::writeDebug( $sqlPermissionCheckingString, 'Lucene::search permissoin SQL generated by ezcontentobjecttreenode' );

        // the limitation list is the most interesting: it should be straight forward to convert this into another boolean query
        // lets assemble a lucene query for this

        // lets map limitation items to the lucene fields
        $limitationHash = array(
            'Class'        => 'm_contentclass_id',
            'Section'      => 'm_section_id',
            'User_Section' => 'm_section_id',
            'Subtree'      => 'm_path_string',
            'User_Subtree' => 'm_path_string',
            'Node'         => 'm_main_node_id',
            'Owner'        => 'm_owner_id' );
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, going to loop over limitation list' );
        //the following loop is expensive, so try to opimize a bit
        //java_begin_document();
        if ( $limitationList )
        {
            $limitationSetCount = 1;
            foreach ( $limitationList as $limitationItemSet )
            {
                $limitationItemSetQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
                
                // Add special query to combine subtree and node limitations
                $limitationPlacementQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );

                foreach ( $limitationItemSet as $limitationItemType => $limitationItemArray )
                {
                    eZDebug::writeDebug( $limitationItemArray, 'Lucene::search limitation item [' . $limitationSetCount .']: ' .$limitationItemType );

                    // lets go for multiphrase queries except for path/node trees
                    switch ( $limitationItemType )
                    {
                        case 'User_Subtree':
                            {
                                $pathStrings = $limitationItemArray;

                                if ( count( $pathStrings ) > 1 )
                                {
                                    $limitSubtreeQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
                                    foreach ( $pathStrings as $pathString )
                                    {
                                        $subtreeTerm = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $pathString );
                                        $prefixQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
                                        $limitSubtreeQuery->add( $prefixQuery, $Occur->SHOULD );
                                    }
                                }
                                else
                                {
                                    eZDebug::writeDebug( 'only using prefix query' );
                                    $subtreeTerm = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $pathStrings[0] );
                                    $limitSubtreeQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
                                }

                                $limitSubtreeQuery = $limitSubtreeQuery->rewrite( $this->reader ); //hack, should not be necessary
                                $limitationItemSetQuery->add( $limitSubtreeQuery, $Occur->MUST );
                            } break;

                        case 'Class':
                        case 'Section':
                        case 'User_Section':
			    {
                                $termArray = array();
                                foreach ($limitationItemArray as $limitationItem)
                                {
                                     $termArray[] = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $limitationItem );
                                }
                                $limitItemQuery = new Java( 'org.apache.lucene.search.MultiPhraseQuery' );
                                $limitItemQuery->add( $termArray );
                                $limitItemQuery = $limitItemQuery->rewrite( $this->reader ); // try a hack since MultiPhraseQuery is behaving weird
                                $limitationItemSetQuery->add( $limitItemQuery, $Occur->MUST );
                            } break;
                        case 'Subtree':
                            {
                                $pathStrings = $limitationItemArray;

                                if ( count( $pathStrings ) > 1 )
                                {
                                    $limitSubtreeQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
                                    foreach ( $pathStrings as $pathString )
                                    {
                                        $subtreeTerm = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $pathString );
                                        $prefixQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
                                        $limitSubtreeQuery->add( $prefixQuery, $Occur->SHOULD );
                                    }
                                }
                                else
                                {
                                    eZDebug::writeDebug( 'only using prefix query' );
                                    $subtreeTerm = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $pathStrings[0] );
                                    $limitSubtreeQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
                                }

                                $limitSubtreeQuery = $limitSubtreeQuery->rewrite( $this->reader ); //hack, should not be necessary
                                $limitationPlacementQuery->add( $limitSubtreeQuery, $Occur->SHOULD );
                            } break;
                        case 'Node':
                            {
                                $termArray = array();
                                foreach ($limitationItemArray as $limitationItem)
                                {
                                     $termArray[] = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $limitationItem );
                                }
                                $limitItemQuery = new Java( 'org.apache.lucene.search.MultiPhraseQuery' );
                                $limitItemQuery->add( $termArray );
                                $limitItemQuery = $limitItemQuery->rewrite( $this->reader ); // try a hack since MultiPhraseQuery is behaving weird
                                $limitationPlacementQuery->add( $limitItemQuery, $Occur->SHOULD );

                            } break;

                        case 'Owner':
                            {
                                $termArray = array();
                                foreach ($limitationItemArray as $limitationItem)
                                {
                                     $termArray[] = new Java( 'org.apache.lucene.index.Term', $limitationHash[$limitationItemType], $currentUser->attribute ( 'contentobject_id' ) );
                                }
                                $limitItemQuery = new Java( 'org.apache.lucene.search.MultiPhraseQuery' );
                                $limitItemQuery->add( $termArray );
                                $limitItemQuery = $limitItemQuery->rewrite( $this->reader ); // try a hack
                                $limitationItemSetQuery->add( $limitItemQuery, $Occur->MUST );
                            } break;

                        default :
                            {
                                eZDebug::writeDebug( $limitationItemType, 'Lucene::search unknown limitation type' );
                            }
                    }
                } //foreach limitationItemSet
                $placementClauses = $limitationPlacementQuery->getClauses();
                if ( count( $placementClauses ) > 0 )
                {
                    $limitationPlacementQuery = $limitationPlacementQuery->rewrite( $this->reader ); //hack, should not be necessary
                    $limitationItemSetQuery->add( $limitationPlacementQuery, $Occur->MUST );
                    eZDebug::writeDebug( $limitationPlacementQuery->toString(), 'limitation item [' . $limitationSetCount . '] has placements, string version:' );
                }
                

                $clauses = $limitationItemSetQuery->getClauses();
                if ( count( $clauses ) > 0 )
                {
                    $limitationQuery->add( $limitationItemSetQuery, $Occur->SHOULD );
                    eZDebug::writeDebug( $limitationItemSetQuery->toString(), 'limitation item [' . $limitationSetCount . '] string' );
                }

                $limitationSetCount++;
            }

        
        }
        else
        {
            eZDebug::writeDebug( 'no limitation list' );
        }
        //java_end_document();
        eZDebug::writeDebug( $limitationQuery->toString(), 'final limitation query string' );
        return $limitationQuery;
    }
    
    function buildLuceneSortArray( $sortArray = array() )
    {
        if ( count( $sortArray ) > 0 )
        {
           
           
           $luceneSortArray = array();
           foreach ($sortArray as $sortElement)
           {
              $sortField = $sortElement[0];
              $sortReverse = false; // sort is ascending by default except for relevance
              if ( isset( $sortElement[1] ) )
                 $sortReverse = !$sortElement[1]; //negate the ascending/descending sorting boolean value
              $sortFieldClass = new JavaClass( 'org.apache.lucene.search.SortField' );
              switch ( $sortField )
                    {
                        case 'path':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_main_path_string' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'path_string':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_main_url_alias' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'published':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_published' , $sortFieldClass->INT, $sortReverse );
                        } break;
                        case 'modified':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_modified' , $sortFieldClass->INT, $sortReverse );
                        } break;
                        case 'section':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_section_id' , $sortFieldClass->INT, $sortReverse );
                        } break;
                        case 'depth':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_main_depth' , $sortFieldClass->INT, $sortReverse );
                        } break;
                        case 'class_identifier':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_class_identifier' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'class_name':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'sort_class_name' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'priority':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'm_main_priority' , $sortFieldClass->INT, $sortReverse );
                        } break;
                        case 'name':
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'sort_name' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'owner_name': // Only for lucene implementation!!
                        {
                            $luceneSortArray[] = new Java( 'org.apache.lucene.search.SortField', 'sort_owner_name' , $sortFieldClass->STRING, $sortReverse );
                        } break;
                        case 'attribute':
                        {
                            eZDebug::writeDebug( $sortField, 'Lucene::search sorting by attribute not yet implemented' );
                        }break;
                        default:
                            eZDebug::writeDebug( $sortField, 'Lucene::search unknown sort field' );

                     } //switch
           } //foreach
           return $luceneSortArray;

        } //if
        else
           return false();
    } //function


    function search( $searchText, $params = array(), $searchTypes = array() )
    {
        //generate timing info
        $start_time = $this->microtime_float();

        
        //the variable $beCarefulWithHiddenFilter is used to avoid situations where hidden nodes are the only limitation (such as for the admin)
        //in that case, lucene search would not return any hits. 
        //when constructing the hidden query filter, a wildcard query on section id will be added to avoid this "deadlock"
        $beCarefulWithHiddenFilter = true;

        //empty searches should be avoided unless $searchTypes is set
        if ( strlen( $searchText ) < 2 && count( $searchTypes ) == 0 )
            return false;

        if ( isset( $params['SearchOffset'] ) && $params['SearchOffset'] )
            $offset = $params['SearchOffset'];
        else
            $offset = 0;

        if ( isset( $params['SearchLimit']  ) && $params['SearchLimit'] )
            $limit = $params['SearchLimit'];
        else
            $limit = 20;

        if ( isset( $params['SearchContentClassID'] ) && $params['SearchContentClassID'] <> -1 )
        {
            $searchContentClassID = $params['SearchContentClassID'];
            $beCarefulWithHiddenFilter = false;
        }
        else
            $searchContentClassID = -1;

        if ( isset( $params['SearchSectionID'] ) &&  $params['SearchSectionID'] <> -1)
        {
            $searchSectionID = $params['SearchSectionID'];
            $beCarefulWithHiddenFilter = false;
        }
        else
            $searchSectionID = -1;
        $searchContentAttributeIdentifier = array();
        if ( isset( $params['SearchContentClassAttributeID'] ) && $params['SearchContentClassAttributeID'] > 0 )
        {
            $searchContentAttributeID = $params['SearchContentClassAttributeID'];
            $searchContentAttribute = eZContentClassAttribute::fetch( $searchContentAttributeID ,true, 0 );
            $searchContentAttributeIdentifier[] =  $searchContentAttribute->attribute( 'identifier' );
            eZDebug::writeDebug( $searchContentAttributeIdentifier, 'Lucene::search attribute identifier for attribute ID ' . $searchContentAttributeID );
            $beCarefulWithHiddenFilter = false;

        }
        //support searching for more than one attribute
        else if ( isset( $params['SearchContentClassAttributeID'] ) && is_array( $params['SearchContentClassAttributeID'] ) )
        {
            foreach ( $params['SearchContentClassAttributeID'] as $AttributeID )
            {
                  $searchContentAttribute = eZContentClassAttribute::fetch( $AttributeID ,true, 0 );
                  $searchContentAttributeIdentifier[] = $searchContentAttribute->attribute( 'identifier' );
                  eZDebug::writeDebug( $searchContentAttributeIdentifier, 'Lucene::search attribute identifier for attribute ID ' . $AttributeID );

            }
            $beCarefulWithHiddenFilter = false;
        }
        else
            $searchContentAttributeID = -1;
            
        if ( isset( $params['SearchDate'] ) && $params['SearchDate'] <> -1 )
        {
            $searchDate = $params['SearchDate'];
            $beCarefulWithHiddenFilter = false;
        }
        else
            $searchDate = -1;
            
        if ( isset( $params['SearchTimestamp'] ) && $params['SearchTimestamp'] <> false  )
        {
            $searchTimestamp = $params['SearchTimestamp'];
            $beCarefulWithHiddenFilter = false;
        }
        else
            $searchTimestamp = false;
            
        if ( isset( $params['SortArray'] ) )
        {
                $sortArray = $params['SortArray'];
                //make sure we have array of sort arrays
                if (! is_array($sortArray[0]) )
                     $sortArray = array($sortArray);
        }
        else
                $sortArray = array();
                    
        if ( isset( $params['SearchSubTreeArray'] ) )
               $subtrees = $params['SearchSubTreeArray'];
        else
               $subtrees = array();

        $BooleanQuery = new JavaClass( 'org.apache.lucene.search.BooleanQuery' );
        //$Integer = new JavaClass( 'java.lang.Integer' );
        //$BooleanQuery->setMaxClauseCount( $Integer->MAX_VALUE );
        //the above triggers a bug in fuzzy query
        //so we use the heuristic below: a lot larger than the default=1024 to accomodate some wild queries
        //in the future, we'll patch fuzzy search to set its own limit
        //see http://issues.apache.org/jira/browse/LUCENE-504
        $BooleanQuery->setMaxClauseCount( 100000 );

        eZDebug::writeDebug( $params, 'Lucene::search params' );
        eZDebug::writeDebug( $searchTypes, 'Lucene::search searchTypes' );

        //trials on ini settings
        $iniLucene = eZINI::instance( "lucene.ini" );
        $doSimilarDocs = ( $iniLucene->hasVariable( "General", "EnablePrefetchMoreLikeThisInSearch" ) && $iniLucene->variable( "General", "EnablePrefetchMoreLikeThisInSearch" ) == 'yes' );
        $searchAllMetaFields = ( $iniLucene->hasVariable( "Search", "SearchAllMetaFields" ) && $iniLucene->variable( "Search", "SearchAllMetaFields" ) == 'yes' );
        
        if ( !$searchAllMetaFields )
        {
            $metaAttributes = $iniLucene->hasVariable( "Search", "SearchMetaFields" ) ? $iniLucene->variable( "Search", "SearchMetaFields" ) : array();

        }
        else
        {
            //a not all-inclusive list, if you want more than this specify these and more in lucene.ini 
            $metaAttributes = array(
                'id',
                'section_id',
                'owner_id',
                'contentclass_id',
                'current_version',
                'remote_id',
                'class_identifier',
                'main_node_id',
                'name',
                'class_name',
                'owner_name',
                'modified',
                'published',
                'depth'
            );

        }
        eZDebug::writeDebug( $metaAttributes, 'Lucene::search meta fields selected' );
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, did initial argument and config processing' );

        if ( !$this->searcher )
            $this->searcher = new Java( 'org.apache.lucene.search.IndexSearcher', $this->indexDir );

        $globalLimitationQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
        $Occur = new JavaClass( 'org.apache.lucene.search.BooleanClause$Occur' );
        if ( !is_object( $this->reader ) )
        {
            $indexReader = new JavaClass( 'org.apache.lucene.index.IndexReader' );
            $this->reader = $indexReader->open( $this->indexDir );
            if ( !is_object( $this->reader ) )
            {
                eZDebug::writeDebug( 'Could not open index dir. Are you sure you already made an index?', 'Lucene::search' );
                return array(
                    "SearchResult" => array(),
                    "SearchCount" => 0,
                    "StopWordArray" => array(),
                    "SearchExtras" => array('LuceneError' => 'Could not open index dir. Are you sure you already created a search index?')
                );
            }
        }
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, opened searcher and reader objects' );

        // be smart: if searching on a specific class(es) or attribute(s), only get the fields of that class or the single attribute
        $fieldArray = array();
        if ( ( is_numeric( $searchContentClassID ) and  $searchContentClassID > 0 ) or ( is_array( $searchContentClassID ) ) )
        {
            if ( is_array( $searchContentClassID ) )
            {
                $multiClassQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
                foreach ( $searchContentClassID as $scID )
                {
			$classTerm = new Java( 'org.apache.lucene.index.Term', 'm_contentclass_id', $scID );
			$classQuery = new Java( 'org.apache.lucene.search.TermQuery', $classTerm );
			$multiClassQuery->add( $classQuery, $Occur->SHOULD );
                }
                $globalLimitationQuery->add( $multiClassQuery, $Occur->MUST );
            }
            else
            {
		$classTerm = new Java( 'org.apache.lucene.index.Term', 'm_contentclass_id', $searchContentClassID );
		$classQuery = new Java( 'org.apache.lucene.search.TermQuery', $classTerm );
		$globalLimitationQuery->add( $classQuery, $Occur->MUST );
            }

          

            foreach ( $metaAttributes as $attributeName )
            {
                $fieldArray[] = 'm_' . $attributeName;
            }

            include_once( 'kernel/classes/ezcontentclass.php' );
            $classArray = array(); 
            if ( is_numeric( $searchContentClassID ) and  $searchContentClassID > 0 )
            {
                 $classArray[] =& eZContentClass::fetch( $searchContentClassID );
            }
            else if ( is_array( $searchContentClassID ) )
            {
                foreach ( $searchContentClassID as $sccID )
                {
                    $classArray[] =& eZContentClass::fetch( $sccID );
                }
            }
            foreach ( $classArray as $class )
            {
		if ( is_object( $class ) )
		{
			$attribs =& $class->fetchSearchableAttributes();
			foreach( $attribs as $attrib )
			{
			$fieldArray[] = 'attr_' . $attrib->attribute( 'identifier' );
			}
		}
            }
        }
        // search only attribute fields specified
        if ( count( $searchContentAttributeIdentifier ) > 0 )
        {
            $fieldArray = array();
            foreach ( $searchContentAttributeIdentifier as $scaIdentifier)
            $fieldArray[] = 'attr_' . $scaIdentifier;
        }
        else // search all fields, use lucene index to collect indexed field names, but shortened if not all meta fields are to be searched
        {
            //beware of syntax for innerclass, see http://php-java-bridge.sourceforge.net
            $fieldOption = new JavaClass( 'org.apache.lucene.index.IndexReader$FieldOption' );

            $fieldCollection = $this->reader->getFieldNames( $fieldOption->INDEXED );
            $fieldArray = $fieldCollection->toArray();
            if ( !$searchAllMetaFields )
            {
                $fieldArray = array_filter ( $fieldArray, array( $this, "isNotMetaField" ) );
                foreach ( $metaAttributes as $attributeName )
                {
                    $fieldArray[] = 'm_' . $attributeName;
                }
                
            }
        }
        //make the array clean (no gaps in keys), otherwise Java chokes !!!!
        sort($fieldArray);
        //eZDebug::writeDebug( $fieldArray, 'Lucene fields to search' );
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, determined fields to search' );


        $queryParser = new Java( 'org.apache.lucene.queryParser.MultiFieldQueryParser', $fieldArray, $this->analyzer );

        $pathStrings = array();
        foreach( $subtrees as $subtree )
        {
            $topNode = eZContentObjectTreeNode::fetch( $subtree );
            if ( $topNode )
            {
                $pathStrings[] = $topNode->attribute( 'path_string' );
            }
        }

        eZDebug::writeDebug( $pathStrings, 'Lucene subtrees to search on' );

        // support for section filtering in advanced search
        if ( is_numeric( $searchSectionID ) and  $searchSectionID > 0 )
        {
            $sectionTerm = new Java( 'org.apache.lucene.index.Term', 'm_section_id', $searchSectionID );
            $sectionQuery = new Java( 'org.apache.lucene.search.TermQuery', $sectionTerm );
            $globalLimitationQuery->add( $sectionQuery, $Occur->MUST );
        }
        else if ( is_array ($searchSectionID ) )
        {
                $multiSectionQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );
                foreach ( $searchSectionID as $ssID )
                {
			$sectionTerm = new Java( 'org.apache.lucene.index.Term', 'm_section_id', $ssID );
			$sectionQuery = new Java( 'org.apache.lucene.search.TermQuery', $sectionTerm );
			$multiSectionQuery->add( $classQuery, $Occur->SHOULD );
                }
                $globalLimitationQuery->add( $multiSectionQuery, $Occur->MUST );
        }
        
        if ( ( is_numeric( $searchDate ) and  $searchDate > 0 ) or
                 $searchTimestamp )
        {
		include_once( "lib/ezlocale/classes/ezdatetime.php" );
		$date = new eZDateTime();
		$timestamp = $date->timeStamp();
		$day = $date->attribute('day');
		$month = $date->attribute('month');
		$year = $date->attribute('year');
		$publishedDateStop = false;
		if ( $searchTimestamp )
		{
			if ( is_array( $searchTimestamp ) )
			{
			$publishedDate = $searchTimestamp[0];
			$publishedDateStop = $searchTimestamp[1];
			}
			else
			$publishedDate = $searchTimestamp;
		}
		else
		{
			switch ( $searchDate )
				{
				case 1:
				{
					$adjustment = 24*60*60; //seconds for one day
					$publishedDate = $timestamp - $adjustment;
				} break;
				case 2:
				{
					$adjustment = 7*24*60*60; //seconds for one week
					$publishedDate = $timestamp - $adjustment;
				} break;
				case 3:
				{
					$adjustment = 31*24*60*60; //seconds for one month
					$publishedDate = $timestamp - $adjustment;
				} break;
				case 4:
				{
					$adjustment = 3*31*24*60*60; //seconds for three months
					$publishedDate = $timestamp - $adjustment;
				} break;
				case 5:
				{
					$adjustment = 365*24*60*60; //seconds for one year
					$publishedDate = $timestamp - $adjustment;
				} break;
				default:
				{
					$publishedDate = $date->timeStamp();
				}
			}
		}
		$lowRangeTerm = new Java( 'org.apache.lucene.index.Term', 'm_published', (string)$publishedDate );
		if ( $publishedDateStop )
		{
		    $highRangeTerm = new Java( 'org.apache.lucene.index.Term', 'm_published', (string)$publishedDateStop );
		    $rangeQuery = new Java( 'org.apache.lucene.search.RangeQuery', $lowRangeTerm, $highRangeTerm, true );
		}
		else // an open ended query
		{
		    $rangeQuery = new Java( 'org.apache.lucene.search.RangeQuery', $lowRangeTerm, null, true );
		}
		
	     $globalLimitationQuery->add( $rangeQuery, $Occur->MUST ); 
           
       }
        
        

        if ( count( $pathStrings ) > 0 )
        {
            if ( count( $pathStrings ) > 1 )
            {
                $locationQuery = new Java( 'org.apache.lucene.search.BooleanQuery' );

                foreach( $pathStrings as $pathString )
                {
                    $subtreeTerm = new Java( 'org.apache.lucene.index.Term', 'm_path_string', $pathString );
                    $subtreeQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
                    $locationQuery->add( $subtreeQuery, $Occur->SHOULD );
                }
            }
            else
            {
                $subtreeTerm = new Java( 'org.apache.lucene.index.Term', 'm_path_string', $pathStrings[0] );
                $locationQuery = new Java( 'org.apache.lucene.search.PrefixQuery', $subtreeTerm );
            }

            eZDebug::writeDebug( $locationQuery->toString(), 'Lucene::search subtree query' );
            $globalLimitationQuery->add( $locationQuery, $Occur->MUST );
            $beCarefulWithHiddenFilter = false;
        }
        
        //support for special attribute searches: not finished yet
        //implementation: simply add it to the searchtext according to lucene syntax rules
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, just before analyzing search types' );

        if ( count( $searchTypes ) > 0 )
        {
		$extraSearchString = '';
		foreach ( $searchTypes['and'] as $searchType )
		{
		if ( $searchType['type'] == 'attribute' )
		{
			switch ( $searchType['subtype'] )
			{
			case 'fulltext':
			case 'patterntext':
			case 'integer':
				$searchContentAttribute = eZContentClassAttribute::fetch( $searchType['classattribute_id'] ,true, 0 );
				$searchContentAttributeIdentifier =  'attr_' . $searchContentAttribute->attribute( 'identifier' );
				$extraSearchString = $extraSearchString . ' +' . $searchContentAttributeIdentifier . ':(' . $searchType['value'] . ')';
				break;
			case 'integers':
				$searchContentAttribute = eZContentClassAttribute::fetch( $searchType['classattribute_id'] ,true, 0 );
				$searchContentAttributeIdentifier =  'attr_' . $searchContentAttribute->attribute( 'identifier' );
				$extraSearchString = $extraSearchString . ' +' . $searchContentAttributeIdentifier . ':(' . implode( " ", $searchType['value'] ) . ')';
				break;
			case 'byrange':
				$searchContentAttribute = eZContentClassAttribute::fetch( $searchType['classattribute_id'] ,true, 0 );
				$searchContentAttributeIdentifier =  'attr_' . $searchContentAttribute->attribute( 'identifier' );
				$extraSearchString = $extraSearchString . ' +' . $searchContentAttributeIdentifier . ':[' . implode( " TO ", $searchType['value'] ) . ']';
				break;
			case 'byidentifier':
				$extraSearchString = $extraSearchString . ' +attr_' . $searchType['identifier'] . ':(' . $searchType['value'] . ')';
				break;
			case 'byidentifierrange':
				$extraSearchString = $extraSearchString . ' +attr_' . $searchType['identifier']  . ':[' . implode( " TO ", $searchType['value'] ) . ']';
				break;
			case 'integersbyidentifier':
				$extraSearchString = $extraSearchString . ' +attr_' . $searchType['identifier'] . ':(' . implode( " ", $searchType['value'] ) . ')';
				break;
			default:
				eZDebug::writeDebug( $searchType['subtype'], 'Lucene::search unknown sub type for attribute search' );
			}
			
			
		}
		}
		$searchText = $searchText . $extraSearchString;
	}
	
	//Take into account visibility status, going to do a "live" lookup in the ezp database
	$hiddenNodesQueryText = '';
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, going to build show hidden nodes query with careful=' . ($beCarefulWithHiddenFilter ? 'yes' : 'no') );
	
	
	if ( ! eZcontentObjectTreenode::showInvisibleNodes() )
	{
	    $db =& eZDB::instance();
	    $invisibleNodeIDArray = $db->arrayQuery( 'SELECT node_id FROM ezcontentobject_tree WHERE ezcontentobject_tree.is_invisible = 1', array( 'column' => 0) );
	    //eZDebug::writeDebug( $invisibleNodeIDArray, 'Lucene::search invisible array' );
	    $hiddenNodesQueryText = 'm_main_node_id:(';
	    foreach ( $invisibleNodeIDArray as $element )
	    {
	        $hiddenNodesQueryText =  $hiddenNodesQueryText . $element['node_id'] . ' ';
	    }
	    $hiddenNodesQueryText = $hiddenNodesQueryText . ')';
	    
	    //a trick to avoid a deadlock with only one NOT filter which would not return any results
	    if ( $beCarefulWithHiddenFilter )
	    {
	       $matchAllDocsQuery = new Java( 'org.apache.lucene.search.MatchAllDocsQuery' );
	       $globalLimitationQuery->add( $matchAllDocsQuery, $Occur->MUST );
	    }
	    eZDebug::writeDebug( $hiddenNodesQueryText, 'Lucene::search invisible array' );
	    $hiddenNodesQuery = $queryParser->parse( $hiddenNodesQueryText );
	    if ( is_object( $hiddenNodesQuery ) )
	       $globalLimitationQuery->add( $hiddenNodesQuery, $Occur->MUST_NOT );
	    
	    

	}
	
	
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, going to build access query' );

        $limitationQuery = $this->buildAccessQuery( $start_time ); 
        $clauses = $globalLimitationQuery->getClauses();
        $limitationQuery->setMinimumNumberShouldMatch( 1 );

        $thisClauses = $limitationQuery->getClauses();
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, got limitation query clauses' );

        if ( count( $thisClauses ) > 0 )
        {
            $globalLimitationQuery->add( $limitationQuery, $Occur->MUST );
        }
        /*else
        {
            $globalLimitationQuery = $limitationQuery;
        } */
    
        $clauses = $globalLimitationQuery->getClauses();
        $clauseCount = count( $clauses );
        eZDebug::writeDebug( $clauseCount, 'count of clauses' );
        eZDebug::writeDebug( $searchText, 'final search text' );
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, calling query parser is next' );

        $codecTo = $this->getCodecToLucene();
        $query = $queryParser->parse( $codecTo->convertString( $searchText ) );
        //check if we get a valid query object, if not return here with an error message
        if ( !is_object( $query ) )
        {
		$this->searcher->close();
		$this->reader->close();
		return array(
			"SearchResult" => array(),
			"SearchCount" => 0,
			"StopWordArray" => array(),
			"SearchExtras" => array('LuceneError' => 'Invalid query')
		);
	
        }
        
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, parsed search query' );

        $sortCount = count( $sortArray );
        if (  $sortCount > 0 )
        {
            $luceneSort = new Java( 'org.apache.lucene.search.Sort', $this->buildLuceneSortArray ( $sortArray ) );
        }
        
        if ( $clauseCount > 0 )
        {
            eZDebug::writeDebug( $globalLimitationQuery->toString(), 'Lucene::search final filter query used' );
            $queryFilter = new Java( 'org.apache.lucene.search.QueryFilter', $globalLimitationQuery );
            eZDebug::writeDebug( $globalLimitationQuery->getMaxClauseCount(), 'Lucene::search max clause count on globalLimitationQuery' );        
        }
        
        //core search timing start
        $lucene_start_time = $this->microtime_float();

        if ( $clauseCount > 0 && $sortCount > 0 )
        {
            $hits = $this->searcher->search( $query, $queryFilter, $luceneSort );
        }
        else if ( $sortCount > 0 )
        {
            $hits = $this->searcher->search( $query, $luceneSort );
        }
        else if ( $clauseCount > 0 )
        {
            $hits = $this->searcher->search( $query, $queryFilter );
        }
        else
        {
            $hits = $this->searcher->search( $query );
        }

        $searchCount = $hits->length();
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, finished searching' );

        $lucene_end_time = $this->microtime_float();
        eZDebug::writeDebug( $searchCount, 'Lucene::search total count, search limit: ' . $limit . ' and offset: ' . $offset);
        $javaException = java_last_exception_get();
        if ( is_object($javaException) )
        {
            eZDebug::writeDebug( $javaException->toString(), 'Lucene::search last java exception' );
        }

        $objectRes = array();
        $lucene = array();

        $i = $offset;
        $mainNodeIdArray = array();
        $fromCodec = $this->getCodecFromLucene();
        while ( $i < $searchCount && $i < ( $offset + $limit ) )
        {
            $d = $hits->doc( $i );
            $similarDocs = false;
            if ( $doSimilarDocs )
            {
                $dID = $hits->id ( $i );
                $similarDocs = $this->findSimilar( $dID, 'lucene_id', false, $this->reader, $this->searcher );
                eZDebug::writeDebug( $similarDocs, ' similar docs for item  ' . $i );
            }

            eZDebug::writeDebug( $hits->score( $i ), 'score of item ' . $i );
            eZDebug::writeDebug( $fromCodec->convertString( $d->get( 'm_name' ) ), 'm_name field of item ' . $i );
            $hitMainNodeID = $d->get( 'm_main_node_id' );
            $mainNodeIdArray[] = $hitMainNodeID;
            $objectRes[] = eZContentObjectTreeNode::fetch( $hitMainNodeID );
            $luceneExtras['hits'][$hitMainNodeID]=array (
                  'score' => $hits->score( $i ),
                  'score_percent' => sprintf("%6.2f%%",($hits->score( $i ) * 100)),
                  'similar_docs' => $similarDocs
                  );
            $i++;
        }
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::search timing point, finished result set generation' );

        //Add search entry to search log
        
        include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
        $currentUser =& eZUser::currentUser();

        if ( ( $offset == 0 ) && $iniLucene->hasVariable( "General", "EnableSearchLog" ) && ( $iniLucene->variable( "General", "EnableSearchLog" ) == 'yes' ) )
        {
            $this->initSearchLogWriter();
            //check if it should be created
            if ( !is_object($this->searchLogWriter) )
            {
                 //Does not exist yet or is corrupt, create a new one
                 $this->searchLogWriter = new Java( 'org.apache.lucene.index.IndexWriter', $this->searchLogDir, $this->analyzer, true );
            }
            $doc = new Java( 'org.apache.lucene.document.Document' );
            //$Field = new JavaClass( 'org.apache.lucene.document.Field' );
            $FieldStore = new JavaClass( 'org.apache.lucene.document.Field$Store' );
            $FieldIndex = new JavaClass( 'org.apache.lucene.document.Field$Index' );
            $doc->add( new Java('org.apache.lucene.document.Field', 'current_user_id', $currentUser->attribute( 'contentobject_id' ), $FieldStore->YES, $FieldIndex->UN_TOKENIZED  ) );
            //ok, raw dumping is not ideal, but for now we will do it like this
            $doc->add( new Java( 'org.apache.lucene.document.Field',  'search_text', $searchText, $FieldStore->YES, $FieldIndex->TOKENIZED ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'search_count', $searchCount, $FieldStore->YES, $FieldIndex->UN_TOKENIZED ) );
            $doc->add( new Java( 'org.apache.lucene.document.Field', 'search_timestamp', date("Ymdhi") , $FieldStore->YES, $FieldIndex->UN_TOKENIZED ) );


            foreach ( $mainNodeIdArray as $hitMainNodeID )
            {
                $doc->add( new Java( 'org.apache.lucene.document.Field', 'node_id', $hitMainNodeID, $FieldStore->YES, $FieldIndex->UN_TOKENIZED ) );
            }

            $this->searchLogWriter->addDocument( $doc );

            $this->searchLogWriter->optimize(); //?? now, we need performance, defer optimize to cron-job would be better
            $this->searchLogWriter->close();
        }

        $stopWordArray = array();
        $end_time = $this->microtime_float();
        $search_time = $end_time - $start_time;
        eZDebug::writeDebug( $search_time, 'Lucene::search total time spent' );
        $lucene_search_time = $lucene_end_time - $lucene_start_time;
        eZDebug::writeDebug( $lucene_search_time, 'Lucene::search core query time spent' );
        $luceneExtras['engine_name']='Lucene (Java) based search plugin &copy; 2006 Paul Borgermans and Kristof Coomans';
        $luceneExtras['timing']['core']=$lucene_search_time;
        $luceneExtras['timing']['total']=$search_time;

        //do clean, we're dealing with Java huh
        $this->searcher->close();
        $this->reader->close();
        return array(
            "SearchResult" => $objectRes,
            "SearchCount" => $searchCount,
            "StopWordArray" => $stopWordArray,
            "SearchExtras" => $luceneExtras

        );
    }

    
    // find similar documents based on tokens or TermVectors if enabled
    // using the contribution to lucene, called org.apache.lucene.search.similar.MoreLikeThis
    // returns an arrayobjects
    //WARNING API is experimental and subject to change!!
    function findSimilar( $ID, $idType = 'node_id', $fields = false, $searchParams = array(), $simReader, $simSearcher, $simLimitationQuery)
    {
        $iniLucene = eZINI::instance( "lucene.ini" );
        //initialisation
        $start_time = $this->microtime_float();

        
        if ( isset( $searchParams['SearchOffset'] ) )
            $offset = $searchParams['SearchOffset'];
        else
            $offset = 0;

        if ( isset( $searchParams['SearchLimit'] ) )
            $limit = $searchParams['SearchLimit'];
        else
            $limit = 10;
        
        $luceneID = 0;
        $cleanupReaderOnExit = false;
        if (! is_object( $simReader ) )
        {
            $IndexReader = new JavaClass( 'org.apache.lucene.index.IndexReader' );
            $simReader = $IndexReader->open( $this->indexDir );
            $cleanupReaderOnExit = true;
            eZDebug::writeDebug( $simReader, 'created simReader, was not defined' );

        }
        $cleanupSearcherOnExit = false;

        if (! is_object( $simSearcher ) )
        {
            $simSearcher = new Java( 'org.apache.lucene.search.IndexSearcher', $this->indexDir );
            $cleanupSearcherOnExit = true;
            eZDebug::writeDebug( $simSearcher, 'created simSearcher, was not defined' );


        }
        if (! is_object( $simLimitationQuery ) )
        {
            $simLimitationQuery = $this->buildAccessQuery(); 
        }

        $moreLikeThis = new Java( 'org.apache.lucene.search.similar.MoreLikeThis', $simReader );
        if ( $fields ) 
        {
               $moreLikeThis->setFieldNames( $fields );
        }
        else
        {
               $moreLikeThis->setFieldNames( null );
        }
        eZDebug::writeDebug( $moreLikeThis->toString(), 'more like this object' );
        eZDebug::writeDebug( $moreLikeThis->getFieldNames(), 'more like this fieldnames' );

        if (! is_object( $moreLikeThis ) ) { print("Must have a valid More Like This object!\n");};
        switch( $idType ) 
        {
             case 'lucene_id':
             //$exception = java_last_exception_get();
             //print ( $exception->getMessage() );

             //$mltQyery->rewrite( $simReader );
             
             $luceneID = $ID;
             break;
             
             case 'object_id':
             $objectIDTerm = new Java( 'org.apache.lucene.index.Term', 'm_id', $ID );
             $docs = $simReader->termDocs( $objectIDTerm );
             $docs->next();
             $luceneID = $docs->doc(); // just get the first match, should be only one
             $docs->close(); // free mem
             eZDebug::writeDebug( $luceneID, 'more like this called with object id ' . $ID );
             break;
             
             case 'node_id':
             $nodeIDTerm = new Java( 'org.apache.lucene.index.Term', 'm_main_node_id', $ID );
             $docs = $simReader->termDocs( $nodeIDTerm );
             eZDebug::writeDebug( $docs, 'more like this docs structure for ' . $ID );
             $docs->next();
             $luceneID = $docs->doc(); // just get the first match, should be only one
             $docs->close(); //free mem
             eZDebug::writeDebug( $luceneID, 'more like this called with node id ' . $ID );
             break;


        

             default:
             print("Not implemented yet: more like this with id type $idType !\n");
        }
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::MLT timing point, before ini readings' );

        #Control more like this heuristics based on ini settings
        if (  $iniLucene->variable( "MoreLikeThis", "MinWordLength" ) )
             $moreLikeThis->setMinWordLen( (int)$iniLucene->variable( "MoreLikeThis", "MinWordLength" ) );
        else
             $moreLikeThis->setMinWordLen( 5 ); //lucene default is 0, it has a large impact
        if ( $iniLucene->variable( "MoreLikeThis", "MaxWordLength" ) )
             $moreLikeThis->setMaxWordLen( (int)$iniLucene->variable( "MoreLikeThis", "MaxWordLength" ) );
        else
             $moreLikeThis->setMaxWordLen( 30 );  //lucene default is 0
        if ( $iniLucene->variable( "MoreLikeThis", "MaxQueryTerms" ) )
             $moreLikeThis->setMaxQueryTerms( (int)$iniLucene->variable( "MoreLikeThis", "MaxQueryTerms" ) );
        else
             $moreLikeThis->setMaxQueryTerms( 10000 ); //lucene default is 25
        if ( $iniLucene->variable( "MoreLikeThis", "TermBoost" ) && $iniLucene->variable( "MoreLikeThis", "TermBoost" ) == "true")
             $moreLikeThis->setBoost( true );
        else
             $moreLikeThis->setBoost( false ); // same as lucene default
        if ( $iniLucene->variable( "MoreLikeThis", "MinDocFreq" ) )
             $moreLikeThis->setMinDocFreq( (int)$iniLucene->variable( "MoreLikeThis", "MinDocFreq" ) );
        else
             $moreLikeThis->setMinDocFreq( 10 ); //lucene default is 5
        if ( $iniLucene->variable( "MoreLikeThis", "MinTermFreq" ) )
             $moreLikeThis->setMinTermFreq( (int)$iniLucene->variable( "MoreLikeThis", "MinTermFreq" ) );
        else
             $moreLikeThis->setMinTermFreq( 2 ); //same as lucene default
        if ( $iniLucene->variable( "MoreLikeThis", "MaxNumTokensParsed" ) )
             $moreLikeThis->setMaxNumTokensParsed( (int)$iniLucene->variable( "MoreLikeThis", "MaxNumTokensParsed" ) );
        else
             $moreLikeThis->setMaxNumTokensParsed( 5000 ); //same as lucene default 
             
        eZDebug::writeDebug( $luceneID, 'more like this lucene ID ');
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::MLT timing point, right ini readings, before mltQuery construct' );
        
        $mltQuery = $moreLikeThis->like( (int)$luceneID );
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::MLT timing point, after mltQuery construct' );

        eZDebug::writeDebug( $moreLikeThis->describeParams(), 'more like this parameters used ');
        //$mltQuery->rewrite();
        eZDebug::writeDebug( $mltQuery->toString(), 'more like this query used ');
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::MLT timing point, starting search' );

        $lucene_start_time = $this->microtime_float();

        $thisClauses = $simLimitationQuery->getClauses();
        if (  count( $thisClauses ) > 0 )
        {
            $mltHits = $simSearcher->search( $mltQuery, $simLimitationQuery );
        }
        else
        {
            $mltHits = $simSearcher->search( $mltQuery );
        }
        $lucene_end_time = $this->microtime_float();

        
        
        
        
        //return similar objects
        $searchCount = $mltHits->length();
        $j = $offset;
        $nodeArray = array();
        eZDebug::writeDebug( $searchCount, 'more like this search count for lucene id  ' . $luceneID );

        //$searchCount = 0;
        
        eZDebug::writeDebug( $this->microtime_float() - $start_time, 'Lucene::MLT timing point, looping over search results' );

        if ( $searchCount > 0 )
        {
            while ( $j < $searchCount && $j < ( $offset + $limit ) )
            {
              eZDebug::writeDebug( $j, 'more like this search iterator for lucene id  ' . $luceneID );
              eZDebug::writeDebug( $mltHits, 'more like this hits construct' );
              
              //avoid self hits
              $currentDocID = $mltHits->id( (int)$j );
              eZDebug::writeDebug( $currentDocID, 'more like this current id for ' . $luceneID );

              if ( $currentDocID != $luceneID )
              {
		$sd = $mltHits->doc( (int)$j );
		$hitMainNodeID = $sd->get( 'm_main_node_id' ) ;
		$nodeArray[] = eZContentObjectTreeNode::fetch( $hitMainNodeID );
		$luceneExtras['hits'][$hitMainNodeID]=array (
			'score' => $mltHits->score( $j ),
			'score_percent' => sprintf("%6.2f%%",($mltHits->score( $j ) * 100)),
			);
		$j++;
	      }
	      else
	      {
	         $limit++;
	         $j++;
	      }
            
            }
            
        }
        $end_time = $this->microtime_float();
        $search_time = $end_time - $start_time;
        $lucene_search_time = $lucene_end_time - $lucene_start_time;

        $luceneExtras['engine_name']='Lucene (Java) based search plugin provided by Paul Borgermans and Kristof Coomans';
        $luceneExtras['timing']['core']=$lucene_search_time;
        $luceneExtras['timing']['total']=$search_time;
        
        //cleanup before returning

        if ( $cleanupReaderOnExit )
        {
             $simReader->close();
        }
        if ( $cleanupSearcherOnExit )
        {
             $simSearcher->close();
        }
        return array(
               'SearchResults' => $nodeArray,
               'SearchCount' => $searchCount,
               'SearchExtras' => $luceneExtras
        );
   


    }
    
    function normalizeText( $text, $isMetaData = false )
    {

    }

    function supportedSearchTypes()
    {
        $searchTypes = array( array( 'type' => 'attribute',
                                     'subtype' =>  'fulltext',
                                     'params' => array( 'classattribute_id', 'value' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' =>  'patterntext',
                                     'params' => array( 'classattribute_id', 'value' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' =>  'integer',
                                     'params' => array( 'classattribute_id', 'value' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' =>  'integers',
                                     'params' => array( 'classattribute_id', 'values' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' =>  'byrange',
                                     'params' => array( 'classattribute_id' , 'from' , 'to'  ) ),
                              array( 'type' => 'attribute',
                                     'subtype' => 'byidentifier',
                                     'params' => array( 'classattribute_id', 'identifier', 'value' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' => 'byidentifierrange',
                                     'params' => array( 'classattribute_id', 'identifier', 'from', 'to' ) ),
                              array( 'type' => 'attribute',
                                     'subtype' => 'integersbyidentifier',
                                     'params' => array( 'classattribute_id', 'identifier', 'values' ) ),
                              array( 'type' => 'fulltext',
                                     'subtype' => 'text',
                                     'params' => array( 'value' ) ) );
        $generalSearchFilter = array( array( 'type' => 'general',
                                             'subtype' => 'class',
                                             'params' => array( array( 'type' => 'array',
                                                                       'value' => 'value'),
                                                                'operator' ) ),
                                      array( 'type' => 'general',
                                             'subtype' => 'publishdate',
                                             'params'  => array( 'value', 'operator' ) ),
                                      array( 'type' => 'general',
                                             'subtype' => 'subtree',
                                             'params'  => array( array( 'type' => 'array',
                                                                        'value' => 'value'),
                                                                 'operator' ) ) );
        return array( 'types' => $searchTypes,
                      'general_filter' => $generalSearchFilter );
    }

    function getCodecToLucene()
    {
        include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $charset = eZTextCodec::internalCharset();

        include_once( 'lib/ezi18n/classes/ezcharsetinfo.php' );
        $charset = eZCharsetInfo::realCharsetCode( $charset );

        eZDebug::writeDebug( 'internal charset: ' . $charset, 'Lucene::search' );

        $luceneCharset = 'utf-8';
        $luceneCharset = eZCharsetInfo::realCharsetCode( $luceneCharset );

        eZDebug::writeDebug( 'lucene charset: ' . $luceneCharset, 'Lucene::search' );

        include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $codec =& eZTextCodec::instance( $charset, $luceneCharset, false );

        return $codec;
    }

    function getCodecFromLucene()
    {
        include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $charset = eZTextCodec::internalCharset();

        include_once( 'lib/ezi18n/classes/ezcharsetinfo.php' );
        $charset = eZCharsetInfo::realCharsetCode( $charset );

        eZDebug::writeDebug( 'internal charset: ' . $charset, 'Lucene::search' );

        $luceneCharset = 'utf-8';
        $luceneCharset = eZCharsetInfo::realCharsetCode( $luceneCharset );

        eZDebug::writeDebug( 'lucene charset: ' . $luceneCharset, 'Lucene::search' );

        include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $codec =& eZTextCodec::instance( $luceneCharset, $charset, false );

        return $codec;
    }
}

?>
