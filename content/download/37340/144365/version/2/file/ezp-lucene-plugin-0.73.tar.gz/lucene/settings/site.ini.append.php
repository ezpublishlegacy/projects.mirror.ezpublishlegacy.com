<?php /*

[SearchSettings]
ExtensionDirectories[]=lucene
#probably already set for use with ez search engine
#EnableWildcard=true
#DelayedIndexing=enabled
SearchEngine=lucene


*/ ?>