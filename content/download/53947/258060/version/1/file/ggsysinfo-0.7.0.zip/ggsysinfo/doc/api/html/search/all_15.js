var searchData=
[
  ['weight',['weight',['../lib_2apc_8php.html#a9b9780cce21a0de7f2a4efdab697bc39',1,'apc.php']]],
  ['wincache_2ephp',['wincache.php',['../lib_2wincache_8php.html',1,'']]],
  ['wincache_2ephp',['wincache.php',['../wincache_8php.html',1,'']]]
];
