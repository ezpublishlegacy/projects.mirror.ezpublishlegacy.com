var classPhpSecInfo__Test__Core__Upload__Max__Filesize =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Upload__Max__Filesize.html#a251b26b4c664ff17c63ed250d428f05d", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Upload__Max__Filesize.html#ad6764176e3e2679d993fa43981c7758a", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Upload__Max__Filesize.html#af50fd5576473fd69582e730ce07b100a", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Upload__Max__Filesize.html#a2529a8961cc27c0988a923c9385fa020", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Upload__Max__Filesize.html#aa199187e62af7bfd503c681c0321962e", null ]
];