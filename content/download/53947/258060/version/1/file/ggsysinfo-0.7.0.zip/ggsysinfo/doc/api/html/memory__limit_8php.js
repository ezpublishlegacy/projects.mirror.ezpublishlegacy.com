var memory__limit_8php =
[
    [ "PhpSecInfo_Test_Core_Memory_Limit", "classPhpSecInfo__Test__Core__Memory__Limit.html", "classPhpSecInfo__Test__Core__Memory__Limit" ],
    [ "PHPSECINFO_MEMORY_LIMIT", "memory__limit_8php.html#a57d58fa4c7ddef3f52cde4b555941da4", null ]
];