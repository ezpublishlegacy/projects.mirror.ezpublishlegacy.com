var classiniChecker =
[
    [ "checkFileContents", "classiniChecker.html#a307ba6d894a01459419570a4c0622596", null ],
    [ "checkFileNames", "classiniChecker.html#ac18d2eaec4778e2093edee64d8507950", null ],
    [ "initialize", "classiniChecker.html#a809405e10b2860eafc9af16691cc1471", null ],
    [ "scanDirForInis", "classiniChecker.html#ac1c084960530ccdd8b95ad6f15421f50", null ],
    [ "$extensioninis", "classiniChecker.html#a569f0a34004ad53e84e025c0c9802120", null ],
    [ "$initialized", "classiniChecker.html#abfbebfb7332ca89b3dcee68d50dd91cd", null ],
    [ "$originalinis", "classiniChecker.html#a3ff58b3129e388549877f0e5bae61db1", null ],
    [ "$overrideinis", "classiniChecker.html#ace63eb6165bb92bac2a5f64a285ff90d", null ],
    [ "$siteaccesinis", "classiniChecker.html#a949032804c54915ba7f3f886b00246eb", null ],
    [ "$userinis", "classiniChecker.html#ae57fa48e6d87b414938c5b850cfd9c54", null ]
];