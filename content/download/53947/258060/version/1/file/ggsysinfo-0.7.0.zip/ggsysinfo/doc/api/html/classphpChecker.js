var classphpChecker =
[
    [ "checkFileContents", "classphpChecker.html#ab0e0eec921669c8a242a852ed8d0f84b", null ],
    [ "initialize", "classphpChecker.html#a9df320013dd73110bda4568f4f5f8ca2", null ],
    [ "parsePhpFile", "classphpChecker.html#af0b35549529a3d4b047a061fd77e7a5b", null ],
    [ "scanDirForphps", "classphpChecker.html#aa9a6044808884f71014a7addf3efd599", null ],
    [ "$extensionphps", "classphpChecker.html#a610d90de55a4a7de379f644824b12c58", null ],
    [ "$initialized", "classphpChecker.html#afc8bbb33b5ca53bb8f062e4a3544f211", null ],
    [ "$originalphps", "classphpChecker.html#a7e59c267c0a923d64eb0c0d6aab8ea26", null ],
    [ "$php", "classphpChecker.html#a7d4517575768e8fbc0c86c3dc6e49c62", null ]
];