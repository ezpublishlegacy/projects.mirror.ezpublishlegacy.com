var classPhpSecInfo__Test__Cgi =
[
    [ "_setMessages", "classPhpSecInfo__Test__Cgi.html#a71e69f7a77cee636fc888e90d4ab9418", null ],
    [ "isTestable", "classPhpSecInfo__Test__Cgi.html#a8eb01ce532f7ab6a1cab4c02a29ceb2c", null ],
    [ "$test_group", "classPhpSecInfo__Test__Cgi.html#a3f42f5d339b13780da2b9d461f5fdf96", null ]
];