var operationlist_8php =
[
    [ "$ezgeshi_available", "operationlist_8php.html#adb0058b3a729ccb2ebffe1c32663cb56", null ],
    [ "$modules", "operationlist_8php.html#a19e625c76c6796e995f33d323ee3aa84", null ],
    [ "$operationList", "operationlist_8php.html#aefb4b6fc056019f5feef09759b2a18a5", null ],
    [ "$title", "operationlist_8php.html#ada57e7bb7c152edad18fe2f166188691", null ],
    [ "else", "operationlist_8php.html#a223f15ca942eacbd8b10792a6afb68dc", null ]
];