var gid_8php =
[
    [ "PhpSecInfo_Test_Core_Gid", "classPhpSecInfo__Test__Core__Gid.html", "classPhpSecInfo__Test__Core__Gid" ],
    [ "PHPSECINFO_MIN_SAFE_GID", "gid_8php.html#a01c055a9f5c2ad9a523253b6cfe0d802", null ]
];