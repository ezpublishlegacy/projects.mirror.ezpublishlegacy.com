var lib_2xcache__admin_2xcache_8php =
[
    [ "Cycle", "classCycle.html", "classCycle" ],
    [ "age", "lib_2xcache__admin_2xcache_8php.html#aa003d55f74898cd456cdc89fe98eb40a", null ],
    [ "number_formats", "lib_2xcache__admin_2xcache_8php.html#a580755d645b7efc4b1e1537690e03c46", null ],
    [ "processClear", "lib_2xcache__admin_2xcache_8php.html#acac0da866aa3b56705e65aad2474a73c", null ],
    [ "size", "lib_2xcache__admin_2xcache_8php.html#af4f70018d6b4006715881088cdb3b7f3", null ],
    [ "switcher", "lib_2xcache__admin_2xcache_8php.html#abeeb5336e230b1e2c0b3ca3b8d8315bb", null ],
    [ "$_GET", "lib_2xcache__admin_2xcache_8php.html#aca6341aaac1262a7d724722db8297857", null ],
    [ "$cacheinfos", "lib_2xcache__admin_2xcache_8php.html#af22f5ba4aa278e1a0873ced3025b6be5", null ],
    [ "$moduleinfo", "lib_2xcache__admin_2xcache_8php.html#a5116c4a255bdc18ce406dbec47cbf579", null ],
    [ "$type_none", "lib_2xcache__admin_2xcache_8php.html#ade2accaaef7c161c5b59ef8ec1b1ece0", null ],
    [ "$type_php", "lib_2xcache__admin_2xcache_8php.html#a49d7874f8b73ffab5e3a68cd5102ce5a", null ],
    [ "$type_var", "lib_2xcache__admin_2xcache_8php.html#ab1aa4d6020dcd089942f727b308d52cc", null ],
    [ "$types", "lib_2xcache__admin_2xcache_8php.html#a92d70a97331cc6fc0a79d9da50895be8", null ],
    [ "$vcnt", "lib_2xcache__admin_2xcache_8php.html#a61ab7ec1bb9afc658cabbd9ba7c7b98e", null ],
    [ "$xcache_modules", "lib_2xcache__admin_2xcache_8php.html#a441867a570add575970c24b682ef48dd", null ],
    [ "$xcache_version", "lib_2xcache__admin_2xcache_8php.html#a6d27bd54b983808eaa348c6be658ccee", null ],
    [ "else", "lib_2xcache__admin_2xcache_8php.html#a2516aba3f50576dd0455a8b6a8764bdb", null ]
];