var inireport_8php =
[
    [ "$currentSiteAccess", "inireport_8php.html#a5d673e34fc18d319c4ba5efbe4662a61", null ],
    [ "$iniFiles", "inireport_8php.html#ab6f043462a24b5b1c65a875023a8a75c", null ],
    [ "$rootDir", "inireport_8php.html#a68ccc223df2708efe11893f675abdacf", null ],
    [ "$siteIni", "inireport_8php.html#af64a5a75d35a44d8a81daaa1a2277793", null ]
];