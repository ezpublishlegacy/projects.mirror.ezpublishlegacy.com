var ocp_8php =
[
    [ "files_display", "ocp_8php.html#ad2acff2e8b09de68d8d4931bff9068f7", null ],
    [ "graphs_display", "ocp_8php.html#a5108163a3b53b17b08edd7cdc83ea5f3", null ],
    [ "meta_display", "ocp_8php.html#a0a700ff87f860621a4c73c34fbae0f00", null ],
    [ "print_table", "ocp_8php.html#af470aceb9ed7f4faab5468bd9bf3b4d1", null ],
    [ "time_since", "ocp_8php.html#a76001f5b1f749ea57aaf6980cca5d8fd", null ],
    [ "$functions", "ocp_8php.html#aa75daea491817f3b64daa2f51128bcdf", null ],
    [ "$host", "ocp_8php.html#a6d1008cd705f9603d836a40ef453d9f3", null ],
    [ "$level", "ocp_8php.html#abd32cc82c6a3f79491987de36ad580ca", null ],
    [ "$name", "ocp_8php.html#ad828261b2fb2ce73f0707b0adf8f12a0", null ],
    [ "$phpinfo", "ocp_8php.html#ac2d03fe7d96bde1a68055de418de357e", null ],
    [ "$time", "ocp_8php.html#a7e304254d099aab9bf7c3808b05d9eae", null ],
    [ "$version", "ocp_8php.html#a5a1b5e9208205bb9bd08e4f2fa48f0d1", null ],
    [ "$version", "ocp_8php.html#a8619abeedafee0758cb9c77fc95634ac", null ],
    [ "$version", "ocp_8php.html#aca59ff51e73ab88c79c88e7866865d38", null ],
    [ "CACHEPREFIX", "ocp_8php.html#ab51ef0aea342858a823ffd526e52ef2e", null ],
    [ "else", "ocp_8php.html#a8a024beafc505ab4bdcfb8be8ef3166b", null ],
    [ "if", "ocp_8php.html#a8e4a7464b137c2bfcc63015cf11baaf6", null ],
    [ "return", "ocp_8php.html#a9717e7bbecb906637e86cef6da3d83c2", null ]
];