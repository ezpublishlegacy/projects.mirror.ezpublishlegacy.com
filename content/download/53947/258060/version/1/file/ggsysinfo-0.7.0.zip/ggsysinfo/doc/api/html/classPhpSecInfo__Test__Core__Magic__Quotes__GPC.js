var classPhpSecInfo__Test__Core__Magic__Quotes__GPC =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#a6cbcbc62a1526d441e1056ef0bba9c50", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#a4e7d063a3e9ffc0d623e4078ef812e0c", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#a0d0f8cf9a2befa34b108cf0296b4f8a4", null ],
    [ "isTestable", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#aaab385e633b03d7ecc98a3f915395966", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#adbd76d306eee0e65671ac2fc73ac516a", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__Magic__Quotes__GPC.html#ab317e8c991ca1a3ceb3f5174b212a7b1", null ]
];