var edit_8php =
[
    [ "$name", "edit_8php.html#a221a581c5edd92e36306a53707675526", null ],
    [ "$value", "edit_8php.html#a6373f9f6f3fd81309a0f72d177b9f0bf", null ],
    [ "$vcnt", "edit_8php.html#a61ab7ec1bb9afc658cabbd9ba7c7b98e", null ],
    [ "$xcache_modules", "edit_8php.html#a441867a570add575970c24b682ef48dd", null ],
    [ "$xcache_version", "edit_8php.html#a6d27bd54b983808eaa348c6be658ccee", null ]
];