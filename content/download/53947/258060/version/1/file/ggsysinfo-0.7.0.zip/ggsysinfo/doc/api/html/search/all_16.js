var searchData=
[
  ['xcache_2ephp',['xcache.php',['../lib_2xcache__admin_2xcache_8php.html',1,'']]],
  ['xcache_2ephp',['xcache.php',['../xcache_8php.html',1,'']]],
  ['xcache_2etpl_2ephp',['xcache.tpl.php',['../xcache_8tpl_8php.html',1,'']]]
];
