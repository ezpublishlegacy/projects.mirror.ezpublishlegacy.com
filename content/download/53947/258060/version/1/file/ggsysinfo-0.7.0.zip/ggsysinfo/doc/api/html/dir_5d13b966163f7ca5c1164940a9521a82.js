var dir_5d13b966163f7ca5c1164940a9521a82 =
[
    [ "extension.php", "extension_8php.html", [
      [ "PhpSecInfo_Test_Suhosin_Extension", "classPhpSecInfo__Test__Suhosin__Extension.html", "classPhpSecInfo__Test__Suhosin__Extension" ]
    ] ],
    [ "patch.php", "patch_8php.html", [
      [ "PhpSecInfo_Test_Suhosin_Patch", "classPhpSecInfo__Test__Suhosin__Patch.html", "classPhpSecInfo__Test__Suhosin__Patch" ]
    ] ]
];