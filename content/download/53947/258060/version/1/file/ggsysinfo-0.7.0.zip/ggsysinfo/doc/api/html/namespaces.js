var namespaces =
[
    [ "PhpSecInfo", "namespacePhpSecInfo.html", null ]
];