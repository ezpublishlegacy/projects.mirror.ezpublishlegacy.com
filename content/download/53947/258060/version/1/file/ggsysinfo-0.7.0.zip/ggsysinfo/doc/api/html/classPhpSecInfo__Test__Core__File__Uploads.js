var classPhpSecInfo__Test__Core__File__Uploads =
[
    [ "_execTest", "classPhpSecInfo__Test__Core__File__Uploads.html#a2640aad50d97c6e3a3407f0e14fb9616", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Core__File__Uploads.html#a4cefad6900db52076dd30cadfd9c13c1", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Core__File__Uploads.html#a0b32505172166c15f52ab8fd2bcbccf9", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Core__File__Uploads.html#adc00560a9dadfc2ef2b82872fce9036a", null ],
    [ "$test_name", "classPhpSecInfo__Test__Core__File__Uploads.html#a0f85b97472397f1ce2e8061f6df62a05", null ]
];