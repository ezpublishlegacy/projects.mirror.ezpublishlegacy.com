var classPhpSecInfo__Test__Suhosin__Patch =
[
    [ "_execTest", "classPhpSecInfo__Test__Suhosin__Patch.html#a0574589bd24714aa4d15de55d658dd6c", null ],
    [ "_retrieveCurrentValue", "classPhpSecInfo__Test__Suhosin__Patch.html#a0ef23b2ce35c53e798dea3bf4a807b3d", null ],
    [ "_setMessages", "classPhpSecInfo__Test__Suhosin__Patch.html#a4e63a207d4b134e248dbddbfa567fdae", null ],
    [ "$recommended_value", "classPhpSecInfo__Test__Suhosin__Patch.html#a5e04163e847c6701ada21adf29111ea6", null ],
    [ "$test_name", "classPhpSecInfo__Test__Suhosin__Patch.html#a264c5b90ec29bc3c47895c51e481117a", null ]
];