<?php /* #?ini charset="iso-8859-1"?

[Tool]
AvailableToolArray[]=related
AvailableToolArray[]=reverse_related
AvailableToolArray[]=action

[Tool_action]
print_check=yes
pdf_check=yes
title=Actions
class=

[Tool_action_description]
print_check=View Print
pdf_check=View Pdf
title=Title
class=Css Class

[Tool_related]
allegati_classidentifiers=article,file
section=
show_section=
parent_node=
show_subtree=
title=Related Objects
title_contest=toolbar/related
class=
view=listitem

[Tool_related_description]
allegati_classidentifiers=Class Filter
section=Published on section
show_section=View on section
parent_node=Published on subtree
show_subtree=View on Subtree
title=Title
title_contest=Contest Label Title
class=Css Class
view=Template view

[Tool_reverse_related]
allegati_classidentifiers=article,file
section=
show_section=
parent_node=
show_subtree=
title=Related Objects
title_contest=toolbar/related
class=
view=listitem

[Tool_reverse_related_description]
allegati_classidentifiers=Class Filter
section=Published on section
show_section=View on section
parent_node=Published on subtree
show_subtree=View on Subtree
title=Title
title_contest=Contest Label Title
class=Css Class
view=Template view

*/ ?>
