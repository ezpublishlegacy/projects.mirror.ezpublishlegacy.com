<?php
/*
[ExtensionSettings]
DesignExtensions[]=addicted
*/
?>