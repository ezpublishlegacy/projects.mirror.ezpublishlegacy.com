<?php
define( "EZ_WORKFLOW_TYPE_RIGHTNOW_USER_ID", "rightnowuser" );
include_once( eZExtension::baseDirectory() . '/' . nameFromPath(__FILE__) . '/classes/rightnow.php' );

class RightNowUserType extends eZWorkflowEventType
{
    function RightNowUserType()
    {
    	$this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_RIGHTNOW_USER_ID, ezi18n( 'rightnow/event', 'RightNow CRM Customer Connector' ));
    	$this->setTriggerTypes( array( 'content' => array( 'publish' => array( 'after' ) ) ) );
    }
    function execute( &$process, &$event )
    {
        if ( $GLOBALS['RIGHTNOW_NO_UPDATE'] )
        {
            return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
        }
        else 
        {
            // Wenn RightNow nicht verfügbar ist per cron wiederholen.
            // Cronjob für workflow prüfen.
            $uID=$_POST["UserID"];
    
    
            if ( RightNow::storeCustomer( $uID ) )
            {
                return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
            }
            else 
            {
                return EZ_WORKFLOW_TYPE_STATUS_DEFERRED_TO_CRON_REPEAT;
            }
    
            return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
        }
        
    }
    
}
eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_RIGHTNOW_USER_ID, 'rightnowusertype' );
?>