[ModuleSettings]
ExtensionRepositories[]=rightnow
