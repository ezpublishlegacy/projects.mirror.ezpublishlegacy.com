[RightNowSettings]
APIInterface=http://<your_domain>/cgi-bin/<your_interface>.cfg/php/xml_api/parse.php
# Choose from http or email
APIInterfaceType=http
SecretString=secret

