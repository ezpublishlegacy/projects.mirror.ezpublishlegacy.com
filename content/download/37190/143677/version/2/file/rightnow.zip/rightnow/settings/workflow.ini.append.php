[EventSettings]
ExtensionDirectories[]=rightnow
AvailableEventTypes[]=event_rightnowuser