<?php
$Module = array( "name" => "RightNow",
                 "variable_params" => true,
                 "function" => array(
                 "script" => "test.php",
                 "params" => array( ) ) );

$ViewList = array();
$ViewList['test'] = array(
	'script' => 'test.php',
	'default_navigation_part' => 'ezrightnow',
	'single_post_actions' => array( 'Cancel' => 'Cancel' ),
	'post_action_parameters' => array( 'Cancel' => array(  ) ),
	"params" => array( ),
	"unordered_params" => array(  ) );



?>
