[RoleSettings]
PolicyOmitList[]=rightnow/test

[UserSettings]
LoginHandler[]=rightnow
ExtensionDirectory[]=rightnow
