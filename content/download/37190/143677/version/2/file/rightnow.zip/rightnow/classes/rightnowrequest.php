<?php

include_once("extension/ezpowerlib/ezpowerlib.php");
include_once("HTTP/Request.php");
include_once( eZExtension::baseDirectory() . '/' . nameFromPath(__FILE__) . '/classes/rightnowparameter.php' );
include_once( 'lib/ezxml/classes/ezxml.php' );

define( 'RIGHTNOW_RESPONSE_DOM_ROOT_NAME', 'connector_ret' );

class RightNowRequest 
{
    var $parameters = array();
    var $function = null;
    var $id = null;
	function RightNowRequest( $functionname, $id = null )
	{
		$this->function = $functionname;
		$this->id = $id;
	}
	function addParameter( $name, $type, $value )
	{
	    $this->parameters[] = new RightNowParameter( $name, $type, $value );
	}

	function call()
	{
	    if ( !$this->function )
	       return false;
	    $doc = new eZDOMDocument();
        $doc->setName( "connector" );
        $root = $doc->createElementNode( "connector" );
        $doc->setRoot( $root );
        
        $function = $doc->createElementNode( "function" );
        $function->appendAttribute( eZDOMDocument::createAttributeNode( 'name', $this->function ) );
        
        if ( $this->id !== null )
            $function->appendAttribute( eZDOMDocument::createAttributeNode( 'id', $this->id ) );
        
        $root->appendChild( $function );
  
	    $rightnowini = eZINI::instance( 'rightnow.ini' );
	    foreach ( $this->parameters as $parameter )
	    {
            $function->appendChild( $parameter->domNode() );
	    }
	    $req =& new HTTP_Request( $rightnowini->variable( 'RightNowSettings', 'APIInterface' ) );
        $req->setMethod( HTTP_REQUEST_METHOD_POST );
        $xmlstr = $doc->toString(); 
        
        eZDebug::writeDebug( $xmlstr, 'RightNow::call() - Request to ' . $rightnowini->variable( 'RightNowSettings', 'APIInterface' ) );
        
        $req->addPostData( "xml_doc", $xmlstr );
        $req->addPostData( "sec_string", $rightnowini->variable( 'RightNowSettings', 'SecretString' ) );
        
        if ( !PEAR::isError( $req->sendRequest() ) )
        {
            $response = $req->getResponseBody();
        }
        else
        {
            return false;
        }
        
        /**
         * SAMPLE return from a request

           <connector_ret>
                <function name="acct_create">
                    <ret_val name="rv" type="integer">89</ret_val>
                </function>
           </connector_ret>
         */
        eZDebug::writeDebug( $response, 'RightNow::call() - Response');
        $xml = new eZXML();
        $dom = $xml->domTree( $response );
        if ( !is_object( $dom ) )
        {
            eZDebug::writeError( 'Parser error', 'RightNowRequest::call()' );
            return false;
        }
        $root =& $dom->get_root();
        if ( $root->name() != RIGHTNOW_RESPONSE_DOM_ROOT_NAME )
        {
            eZDebug::writeError( 'Wrong doctype', 'RightNowRequest::call()' );
            return false;
        }

        
        # function part
        $function = $root->firstChild();
        
        #ret_val part
        $ret_val = $function->firstChild();

        
        if ( $ret_val->getAttribute( "type" ) == RIGHTNOW_DATATYPE_PAIR )
        {
            $return = $this->parsePair( $ret_val );
            eZDebug::writeDebug( $return, 'RightNow::call() - Parsed response');
            return $return;
        }
        else
        {
            $ret_val = $ret_val->firstChild();
            eZDebug::writeDebug( $ret_val->Content, 'RightNow::call() - Parsed response');
            return $ret_val->Content;
        }
	}
	function parsePair( &$domnode )
	{
	    $return = array();
		foreach ( $domnode->children() as $child )
		{
		    if ( $child->getAttribute( "type" ) == RIGHTNOW_DATATYPE_PAIR )
		      $return[$child->getAttribute( "name" )] = RightNowRequest::parsePair( $child );
		    else
		    {
		        $ret_val = $child->firstChild();
		        $return[$child->getAttribute( "name" )] = $ret_val->Content;
		    }
		}
		return $return;
	}
}
?>