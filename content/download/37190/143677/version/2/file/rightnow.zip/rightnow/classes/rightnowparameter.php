<?php

define( "RIGHTNOW_DATATYPE_PAIR", 'pair' );
define( "RIGHTNOW_DATATYPE_INTEGER", 'integer' );
define( "RIGHTNOW_DATATYPE_STRING", 'string' );

class RightNowParameter 
{
    var $type;
    var $name;
    var $value;
	function RightNowParameter( $name, $type, $value )
	{
	   $this->name = $name;
	   $this->type = $type;
	   $this->value = $value;	
	}
	function domNode()
	{
		$doc = new eZDOMDocument();
		$parameter = $doc->createElementNode( "parameter" );
        $parameter->appendAttribute( eZDOMDocument::createAttributeNode( 'name', $this->name ) );
        $parameter->appendAttribute( eZDOMDocument::createAttributeNode( 'type', $this->type ) );
		
        if ( $this->type != RIGHTNOW_DATATYPE_PAIR )
		{
		    $parameter->appendChild( $doc->createTextNode( $this->value ) );
		}
		else
		{
		    foreach ( $this->value as $key => $content )
		    {
		        
    		    $pair = $doc->createElementNode( "pair" );
                $pair->appendAttribute( eZDOMDocument::createAttributeNode( 'name', $key ) );
                $pair->appendAttribute( eZDOMDocument::createAttributeNode( 'type', gettype( $content ) ) );
                $pair->appendChild( $doc->createTextNode( $content ) );
                $parameter->appendChild( $pair );
                unset( $pair );
		    }

		}
		return $parameter;
	}
}