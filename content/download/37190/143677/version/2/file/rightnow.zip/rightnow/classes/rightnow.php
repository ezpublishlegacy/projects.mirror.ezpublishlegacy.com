<?php
include_once( eZExtension::baseDirectory() . '/' . nameFromPath(__FILE__) . '/classes/rightnowrequest.php' );
/*
RightNow class with static function API calls
*/
class RightNow
{

	function RightNow()
	{
		
	}
	/*
	
	    $contact['sa_state']=(int)0;
		$contact['ma_state']=(int)0;
		$contact['css_state']=(int)1;
		$contact['login']=(string)'xrow';
		$contact['first_name']=(string)'Björn';
		$contact['last_name']=(string)'Dieding';
	
	*/
	function createCustomer( $contact )
	{
		$req = new RightNowRequest( 'contact_create' );
		$req->addParameter( "args", RIGHTNOW_DATATYPE_PAIR, $contact );
		$req->addParameter( "flags", RIGHTNOW_DATATYPE_INTEGER, '0x00002' );
	    return $req->call();
	}
	
	function updateCustomer( $contact, $c_id )
	{
		$req = new RightNowRequest( 'contact_update' );
		$req->addParameter( "args", RIGHTNOW_DATATYPE_PAIR, $contact );
		$req->addParameter( "flags", RIGHTNOW_DATATYPE_INTEGER, '0x00002' );
		$req->addParameter( "c_id", RIGHTNOW_DATATYPE_INTEGER, $c_id );
	    return $req->call();
	}
	
	function getCustomer( $c_id )
	{
		$req = new RightNowRequest( 'contact_get' );
		$req->addParameter( "c_id", RIGHTNOW_DATATYPE_INTEGER, $c_id );
	    return $req->call();
	}
	
	function storeCustomer( $contentObjectID )
	{
		$c_user = eZUser::fetch( $contentObjectID, true );
        $co = eZContentObject::fetch( $contentObjectID );
        $c_user_dm = $co->dataMap();
        $remoteID=$co->RemoteID;
        $login=&$c_user->attribute("login");
        $email=&$c_user->attribute("email");
        $password=&$c_user->attribute("password_hash");
        
        $firstname=$c_user_dm["first_name"]->DataText;
        $lastname=$c_user_dm["last_name"]->DataText;
        $street=$c_user_dm["street"]->DataText;
        $phone=$c_user_dm["phone"]->DataText;
        $optin=$c_user_dm["optin"]->DataInt;
        $organisation=$c_user_dm["organisation"]->DataText;
        $title=$c_user_dm["title"]->DataText;
        $postal_code=$c_user_dm["postal_code"]->DataText;
        
        if ( $rn_cust_ID = RightNow::getCustomerByLogin($login) )
        {
            $rn_cust = RightNow::getCustomer($rn_cust_ID);
            $rightnowcust=true;
            #var_dump($rn_cust);

        }
        else 
        {
            $rightnowcust=false;
        }
        
        
        $remoteexp=explode(":", $remoteID);
        
        if ( $remoteexp[0]=="RightNow" AND $remoteexp[1]=="customers" AND $remoteexp[2]==$rn_cust_ID )
            $remoteidcheck=true;
        else 
            $remoteidcheck=false;
            
        $contact['sa_state']=(int)0;
        $contact['ma_state']=(int)0;
        $contact['css_state']=(int)1;
        $contact['login']=(string)$login;
        $contact['first_name']=(string)$firstname;
        $contact['last_name']=(string)$lastname;
        $contact['ma_opt_in']=(int)$optin;
        $contact['ph_office']=(string)$phone;
        $contact['ma_org_name']=(string)trim($organisation);
        $contact['street']=(string)$street;
        $contact['email']=(string)$email;
        $contact['password']=(string)trim($password);
        $contact['title']=(string)$title;
        $contact['postal_code']=(string)$postal_code;
        #var_dump($contact);
        
        
        if ( $remoteidcheck and $rightnowcust)
        {
            $returnvalue=RightNow::updateCustomer($contact, (int)$rn_cust_ID);
            if ( $returnvalue=="1" )
                eZDebug::writeDebug( 'RightNow::createCustomer -  USER UPDATED ', 'RightNow' );
            else
                eZDebug::writeDebug( 'RightNow::createCustomer -  USER UPDATE FAILED FOR UNKNOWN REASON'.$returnvalue, 'RightNow' );
        }
        elseif ( !$rightnowcust ) 
        {
            
            $returnvalue=RightNow::createCustomer( $contact );
            if ( $returnvalue >= "1" )
                eZDebug::writeDebug( 'RightNow::createCustomer -  NEW USER AT RIGHTNOW REGISTERED ', 'RightNow' );
            elseif ( $returnvalue >= "-2" )
                eZDebug::writeDebug( 'RightNow::createCustomer -  NEW USER  REGISTRATION AT RIGHTNOW FAILED - E-MAIL ADDRESS ALREADY EXISTS', 'RightNow' );
            else
                eZDebug::writeDebug( 'RightNow::createCustomer -  NEW USER  REGISTRATION AT RIGHTNOW FAILED FOR UNKNOWN REASON '.$returnvalue, 'RightNow' );

           
            /*
                RemoteID updaten
            */
            
            
            include_once("kernel/classes/ezconobject.php");
                            $contentObject =& eZContentObject::fetch( $contentObjectID );
                            $remoteID = "RightNow:customers:" . $returnvalue;
                            $contentObject->setAttribute( 'remote_id', $remoteID );
                            $contentObject->store();
        }
        else 
        {
            eZDebug::writeDebug( 'RightNow::createCustomer -  NEW USER  REGISTRATION AT RIGHTNOW FAILED - Username already exists in Rightnow - eZUser created'.$returnvalue, 'RightNow' );
        }
        
        if ( $contentObjectID >= 2 )
        {
            include_once("kernel/classes/ezcontentcachemanager.php");
            eZContentCacheManager::clearContentCache($contentObjectID);
        }
        
	}
	
	function getCustomerByLogin( $loginname )
	{
	    $db = eZDB::instance();
	    $sql = "SELECT c_id FROM contacts WHERE login = '" . $db->escapeString( $loginname ) . "'";
		return RightNow::sql( $sql );
	}
	function sql( $sql, $returntype = RIGHTNOW_DATATYPE_INTEGER )
	{
	    if ( $returntype = RIGHTNOW_DATATYPE_INTEGER )
		  $req = new RightNowRequest( 'sql_get_int', 'sql_str' );
		else
		  $req = new RightNowRequest( 'sql_get_str', 'sql_str' );
		$req->addParameter( "sql", RIGHTNOW_DATATYPE_STRING, $sql );
	    return $req->call();
	}
}
?>