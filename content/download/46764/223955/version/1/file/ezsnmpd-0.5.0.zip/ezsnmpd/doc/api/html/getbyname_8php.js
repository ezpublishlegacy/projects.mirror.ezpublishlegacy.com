var getbyname_8php =
[
    [ "$name", "getbyname_8php.html#ab2fc40d43824ea3e1ce5d86dee0d763b", null ],
    [ "$response", "getbyname_8php.html#af4b6fb1bbc77ccc05f10da3b16935b99", null ]
];