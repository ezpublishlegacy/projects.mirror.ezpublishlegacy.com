var searchData=
[
  ['get_2ephp',['get.php',['../get_8php.html',1,'']]],
  ['getbyname_2ephp',['getbyname.php',['../getbyname_8php.html',1,'']]],
  ['getnext_2ephp',['getnext.php',['../getnext_8php.html',1,'']]]
];
