var dirs =
[
    [ "bin", "dir_b15b55275d7a45fcdf7945b5988479d4.html", "dir_b15b55275d7a45fcdf7945b5988479d4" ],
    [ "classes", "dir_e32cf9a3138e25e94cbfa6756d68ca46.html", null ],
    [ "interfaces", "dir_bbe09bd6e94ac80d785088169cdc5439.html", null ],
    [ "modules", "dir_dc481d5b73a0e1ac053266c78dbeed5f.html", "dir_dc481d5b73a0e1ac053266c78dbeed5f" ]
];