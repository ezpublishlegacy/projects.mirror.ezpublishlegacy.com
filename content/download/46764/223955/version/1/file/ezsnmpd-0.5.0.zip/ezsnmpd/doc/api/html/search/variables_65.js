var searchData=
[
  ['error_5finconsistent_5fvalue',['ERROR_INCONSISTENT_VALUE',['../interfaceeZsnmpdHandlerInterface.html#a10646324355d25a9acb94d48a753c4a5',1,'eZsnmpdHandlerInterface']]],
  ['error_5fnot_5fwriteable',['ERROR_NOT_WRITEABLE',['../interfaceeZsnmpdHandlerInterface.html#a029b77b2bea0747d8b1f3c4aae07388b',1,'eZsnmpdHandlerInterface']]],
  ['error_5fwrong_5flenght',['ERROR_WRONG_LENGHT',['../interfaceeZsnmpdHandlerInterface.html#a9a1024ba7130ef1af2638e52666d461b',1,'eZsnmpdHandlerInterface']]],
  ['error_5fwrong_5ftype',['ERROR_WRONG_TYPE',['../interfaceeZsnmpdHandlerInterface.html#af4f5f0289550cd95ff56970dceeae56b',1,'eZsnmpdHandlerInterface']]],
  ['error_5fwrong_5fvalue',['ERROR_WRONG_VALUE',['../interfaceeZsnmpdHandlerInterface.html#a2981fe1449ae46dff1f7e0e36b639fca',1,'eZsnmpdHandlerInterface']]]
];
