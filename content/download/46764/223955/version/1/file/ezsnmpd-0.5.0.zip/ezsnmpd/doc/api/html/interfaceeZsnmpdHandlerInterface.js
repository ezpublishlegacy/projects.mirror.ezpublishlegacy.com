var interfaceeZsnmpdHandlerInterface =
[
    [ "get", "interfaceeZsnmpdHandlerInterface.html#a21ed88bca9a3f3d9e07e9ce9d60baeed", null ],
    [ "getMIB", "interfaceeZsnmpdHandlerInterface.html#a1a2a3f48488f95dce7650a1b410dfb40", null ],
    [ "getnext", "interfaceeZsnmpdHandlerInterface.html#a40c7a94812fe2a5a1781f4eaa259a55e", null ],
    [ "oidRoot", "interfaceeZsnmpdHandlerInterface.html#ac4c2efdfdcb7cec9ff48d6abdf507f7b", null ],
    [ "set", "interfaceeZsnmpdHandlerInterface.html#ad91a6a330f6185e266012a7c78b3e9ec", null ],
    [ "ERROR_INCONSISTENT_VALUE", "interfaceeZsnmpdHandlerInterface.html#a10646324355d25a9acb94d48a753c4a5", null ],
    [ "ERROR_NOT_WRITEABLE", "interfaceeZsnmpdHandlerInterface.html#a029b77b2bea0747d8b1f3c4aae07388b", null ],
    [ "ERROR_WRONG_LENGHT", "interfaceeZsnmpdHandlerInterface.html#a9a1024ba7130ef1af2638e52666d461b", null ],
    [ "ERROR_WRONG_TYPE", "interfaceeZsnmpdHandlerInterface.html#af4f5f0289550cd95ff56970dceeae56b", null ],
    [ "ERROR_WRONG_VALUE", "interfaceeZsnmpdHandlerInterface.html#a2981fe1449ae46dff1f7e0e36b639fca", null ],
    [ "LAST_OID", "interfaceeZsnmpdHandlerInterface.html#a6685214d9bc90c2aef602d77a2991ae6", null ],
    [ "NO_SUCH_OID", "interfaceeZsnmpdHandlerInterface.html#aca79e88d39d78ebf1e468c6dbda0cfbd", null ],
    [ "SET_SUCCESFUL", "interfaceeZsnmpdHandlerInterface.html#abfd0342599b76b0577333a60e84f11a4", null ]
];