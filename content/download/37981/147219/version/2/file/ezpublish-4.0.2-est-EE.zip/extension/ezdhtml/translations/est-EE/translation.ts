<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Failitüüp</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Suurus</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Disable editor</source>
        <translation>Lülita redaktor välja</translation>
    </message>
    <message>
        <source>Enable editor</source>
        <translation>Lülita redaktor sisse</translation>
    </message>
</context>
<context>
    <name>design/standard/ezdhtml</name>
    <message>
        <source>Insert object</source>
        <translation>Manusta objekt</translation>
    </message>
    <message>
        <source>Insert link</source>
        <translation>Manusta link</translation>
    </message>
    <message>
        <source>Insert table</source>
        <translation>Manusta tabel</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Tegevuse tagasivõtmine</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Tegevuse taaskordamine</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Paks</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Kursiiv</translation>
    </message>
    <message>
        <source>Numbered list</source>
        <translation>Nummerdatud loend</translation>
    </message>
    <message>
        <source>Bullet list</source>
        <translation>Nummerdamata loend</translation>
    </message>
    <message>
        <source>Insert special character</source>
        <translation>Manusta spetsiaalmärk</translation>
    </message>
    <message>
        <source>Insert literal text</source>
        <translation>Manusta täht-täheline tekst</translation>
    </message>
    <message>
        <source>Insert anchor</source>
        <translation>Lisa ankur</translation>
    </message>
    <message>
        <source>Insert custom tag</source>
        <translation>Manusta kohandatud märgend</translation>
    </message>
    <message>
        <source>Insert row</source>
        <translation>Lisa rida</translation>
    </message>
    <message>
        <source>Insert column</source>
        <translation>Lisa veerg</translation>
    </message>
    <message>
        <source>Delete row</source>
        <translation>Kustuta rida</translation>
    </message>
    <message>
        <source>Delete column</source>
        <translation>Kustuta veerg</translation>
    </message>
    <message>
        <source>Split cell</source>
        <translation>Poolita lahter</translation>
    </message>
    <message>
        <source>Merge cell</source>
        <translation>Ühenda lahtrid</translation>
    </message>
    <message>
        <source>Decrease list indent</source>
        <translation>Vähenda loendi taanet</translation>
    </message>
    <message>
        <source>Increase list indent</source>
        <translation>Suurenda loendi taanet</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Otsi</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Abi</translation>
    </message>
    <message>
        <source>Heading 1</source>
        <translation>Pealkiri 1</translation>
    </message>
    <message>
        <source>Heading 2</source>
        <translation>Pealkiri 2</translation>
    </message>
    <message>
        <source>Heading 3</source>
        <translation>Pealkiri 3</translation>
    </message>
    <message>
        <source>Heading 4</source>
        <translation>Pealkiri 4</translation>
    </message>
    <message>
        <source>Heading 5</source>
        <translation>Pealkiri 5</translation>
    </message>
    <message>
        <source>Heading 6</source>
        <translation>Pealkiri 6</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Harilik</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Omadused</translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation>Lingi Omadused</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Lõika</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopeeri</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Kustuta</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Kleebi</translation>
    </message>
    <message>
        <source>Merge Cells</source>
        <translation>Ühenda Lahtrid</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Vali kõik</translation>
    </message>
    <message>
        <source>Split Cell</source>
        <translation>Poolita Lahter</translation>
    </message>
    <message>
        <source>Selected image type is not an anchor</source>
        <translation>Valitud pilditüüp ei ole ankur</translation>
    </message>
    <message>
        <source>Class: </source>
        <translation>Klass: </translation>
    </message>
    <message>
        <source>Class: [none]</source>
        <translation>Klass: [puudub]</translation>
    </message>
    <message>
        <source>Make link</source>
        <translation>Loo link</translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>Eraldaja</translation>
    </message>
    <message>
        <source>Table Properties</source>
        <translation>Tabeli Omadused</translation>
    </message>
    <message>
        <source>Change To TH</source>
        <translation>Muuda TH-ks</translation>
    </message>
    <message>
        <source>Change To TD</source>
        <translation>Muuda TD-ks</translation>
    </message>
    <message>
        <source>Headings are not allowed inside a list.</source>
        <translation>Pealkirjad ei ole loendis lubatud.</translation>
    </message>
    <message>
        <source>Error: The number of rows is required and has to be at least 1!</source>
        <translation>Viga: ridade arv on kohustuslik ja peab olema vähemalt 1!</translation>
    </message>
    <message>
        <source>Error: The number of columns is required and has to be at least 1!</source>
        <translation>Viga: veergude arv on kohustuslik ja peab olema vähemalt 1!</translation>
    </message>
    <message>
        <source>Choose node</source>
        <translation>Vali tipp</translation>
    </message>
    <message>
        <source>Select a node and click the %buttonname button.
    Using bookmark items for quick selection is also possible.
    Click on node names to change the browse listing.</source>
        <translation>Vali tipp ning vajuta nuppu %buttonname .
    Kiireks valikuks saab kasutada ka järjehoidjaid.
    Sirvimiseks vajuta tipunimedele.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Choose object</source>
        <translation>Vali objekt</translation>
    </message>
    <message>
        <source>Select an object and click the %buttonname button.
    Click on object names to change the browse listing.
    Using bookmark items for quick selection is also possible.</source>
        <translation>Vali objekt ning vajuta nuppu %buttonname .
    Kiireks valikuks saab kasutada ka järjehoidjaid.
    Sirvimiseks vajuta tipunimedele.</translation>
    </message>
    <message>
        <source>Choose objects</source>
        <translation>Vali objektid</translation>
    </message>
    <message>
        <source>Use the checkboxes to choose the objects that you wish to relate to
    and click the %buttonname button. Click on object names to change the browse listing.
    Using bookmark items for quick selection is also possible.</source>
        <translation>Seostatavate objektide valikuks kasuta märkeruute ning vajuta nuppu %buttonname.
    Sirvimiseks vajuta objektinimedele.
    Kiireks valikuks saab kasutada järjehoidjaid.
    </translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
    <message>
        <source>Select from available classes</source>
        <translation>Vali kättesaadavate klasside hulgast</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klass</translation>
    </message>
    <message>
        <source>none</source>
        <translation>puudub</translation>
    </message>
    <message>
        <source>Select from available custom tags</source>
        <translation>Vali kättesaadavate kohandatud märgendite hulgast</translation>
    </message>
    <message>
        <source>Custom tag</source>
        <translation>Kohandatud märgend</translation>
    </message>
    <message>
        <source>Inline</source>
        <translation>Reas</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Attribute name</source>
        <translation>Atribuudi nimi</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Väärtus</translation>
    </message>
    <message>
        <source>There are no attributes defined</source>
        <translation>Ühtegi atribuuti pole defineeritud</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Kõrvalda valitud</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Uus atribuut</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
    <message>
        <source>other</source>
        <translation>muu</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Lehitse</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Open in new window</source>
        <translation>Ava uues aknas</translation>
    </message>
    <message>
        <source>Title ( optional )</source>
        <translation>Pealkiri ( mittekohustuslik )</translation>
    </message>
    <message>
        <source>ID ( optional )</source>
        <translation>ID ( mittekohustuslik )</translation>
    </message>
    <message>
        <source>Upload local file</source>
        <translation>Lokaalse faili üles laadimine</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Asukoht</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaatne</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fail</translation>
    </message>
    <message>
        <source>Upload is in progress, it may take a few seconds ...</source>
        <translation>Üles laadimine on käsil, see võib võtta mõne hetke ...</translation>
    </message>
    <message>
        <source>Select from related objects or upload local files</source>
        <translation>Vali seotud objektide hulgast või lae üles kohalik fail</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Seotud objektid</translation>
    </message>
    <message>
        <source>Related images</source>
        <translation>Seotud pildid</translation>
    </message>
    <message>
        <source>Related files</source>
        <translation>Seotud failid</translation>
    </message>
    <message>
        <source>Related content</source>
        <translation>Seotud sisu</translation>
    </message>
    <message>
        <source>There are no related objects.</source>
        <translation>Seotud objekte ei ole.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Laadi üles uus</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Lisa olemasolev</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Keskel</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Vasakul</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Paremal</translation>
    </message>
    <message>
        <source>Rows</source>
        <translation>Ridu</translation>
    </message>
    <message>
        <source>Columns</source>
        <translation>Veerge</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Suurus</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Piirjoon</translation>
    </message>
    <message>
        <source>Edit Cell properties</source>
        <translation>Lahtri omaduste redigeerimine</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Laius</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Rakenda</translation>
    </message>
    <message>
        <source>Cell</source>
        <translation>Lahter</translation>
    </message>
    <message>
        <source>Row</source>
        <translation>Rida</translation>
    </message>
    <message>
        <source>Column</source>
        <translation>Veerg</translation>
    </message>
    <message>
        <source>Cell Properties</source>
        <translation>Lahtri Omadused</translation>
    </message>
    <message>
        <source>No classes are available for the element: </source>
        <translation>Elemendi jaoks puuduvad saadaolevad klassid: </translation>
    </message>
    <message>
        <source>Remove link</source>
        <translation>Kõrvalda link</translation>
    </message>
    <message>
        <source>Merge down</source>
        <translation>Ühenda alla</translation>
    </message>
    <message>
        <source>Custom tag properties</source>
        <translation>Kohandatud märgendi omadused</translation>
    </message>
    <message>
        <source>Link properties</source>
        <translation>Lingi Omadused</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vaata</translation>
    </message>
    <message>
        <source>default</source>
        <translation>vaikeväärtus</translation>
    </message>
    <message>
        <source>Property name</source>
        <translation>Omaduse nimi</translation>
    </message>
    <message>
        <source>You&apos;re running Internet Explorer on Windows Vista. The Online Editor is currently not compatible with this configuration. Please disable the editor or use Firefox/Mozilla browser.</source>
        <translation>Sa kasutad Internet Explorerit Windows Vistal. Sisseehitatud redaktor (Online Editor) ei ole selle keskkonnaga ühilduv. Lülita redaktor välja või kasuta Firefox/Mozilla brauserit.</translation>
    </message>
</context>
<context>
    <name>design/standard/ezdhtml/help</name>
    <message>
        <source>Online editor help</source>
        <translation>Sisseehitatud tekstiredaktori abi</translation>
    </message>
    <message>
        <source>Using the toolbar</source>
        <translation>Tööriistariba kasutamine</translation>
    </message>
    <message>
        <source>Undo the last operation in the editor. To undo more than one operation, keep clicking the button.</source>
        <translation>Viimase redaktori toimingu tagasivõtmine. Mitme toimingu tagasivõtmiseks vajuta nuppu korduvalt.</translation>
    </message>
    <message>
        <source>Reverse the &quot;Undo&quot; command.</source>
        <translation>Tagasivõtmise käsu tühistamine.</translation>
    </message>
    <message>
        <source>Make the selected text &lt;b&gt;bold&lt;/b&gt;. If the selected text is &lt;b&gt;bold&lt;/b&gt; already, this button will remove the formating.</source>
        <translation>Valitud teksti &lt;b&gt;paksuks&lt;/b&gt; muutmine. Kui tekst juba on &lt;b&gt;paks&lt;/b&gt; siis see nupp eemaldab paksu stiili.</translation>
    </message>
    <message>
        <source>Make the selected text &lt;i&gt;italic&lt;/i&gt;. If the selected text is &lt;i&gt;italic&lt;/i&gt; already, this button will remove the formating.</source>
        <translation>Valitud teksti &lt;i&gt;kursiivi&lt;/i&gt; muutmine. Kui tekst juba on &lt;i&gt;kursiivis&lt;/i&gt; siis see nupp eemaldab selle stiili.</translation>
    </message>
    <message>
        <source>Decrease list indent. Use this button to change the level of a list item in a nested list.</source>
        <translation>Loendi taande vähendamine. Kasuta seda nuppu mitmetasemelise loendi elemendi pesastustaseme vähendamiseks.</translation>
    </message>
    <message>
        <source>Increase list indent. Use this button to change the level of a list item in a nested list.</source>
        <translation>Loendi taande suurendamine. Kasuta seda nuppu mitmetasemelise loendi elemendi pesastustaseme suurendamiseks.</translation>
    </message>
    <message>
        <source>Create a hyperlink. You can select text first and then click this button to make the text a link. If the checkbox &quot;Open in new window&quot; is checked, the link will be displayed in a new browser window.</source>
        <translation>Hüperlingi loomine. Märgista kõigepealt tekst ja siis vajuta teksti lingiks muutmiseks seda nuppu. Kui märkeruut &quot;Ava uues aknas&quot; on märgitud, siis kuvatakse lingitud lehekülg uues brauseri aknas.</translation>
    </message>
    <message>
        <source>Insert literal text. Click the &quot;Insert literal&quot; button to insert a single column and single row table with purple background into the editor field. Text written in this field will be rendered literally in the final output.</source>
        <translation>Sisesta täht-täheline tekst. &quot;Manusta täht-täheline tekst&quot; nupu vajutamine lisab redaktorisse ühelahtrilise, punase taustaga tabeli, millesse sisestatud tekst kuvatakse algkujul.</translation>
    </message>
    <message>
        <source>Insert a special character. Click the button to open the special character window. Click on a character to insert it.</source>
        <translation>Erimärgi manustamine. Erimärkide akna avamiseks vajuta seda nuppu. Vajuta märgil selle manustamiseks.</translation>
    </message>
    <message>
        <source>Insert a table at the selected position. Tables with their border set to 0 are displayed with a red border color in the editor.</source>
        <translation>Valitud positsioonile tabeli manustamine. Kui tabeli piirjoone laius on seatud 0, siis kuvatakse piirjoon punaselt.</translation>
    </message>
    <message>
        <source>Open the search window.</source>
        <translation>Otsinguakna avamine.</translation>
    </message>
    <message>
        <source>Open the help window.</source>
        <translation>Abiinfo akna avamine.</translation>
    </message>
    <message>
        <source>Using the context menu</source>
        <translation>Kontekstimenüü kasutamine</translation>
    </message>
    <message>
        <source>Right click using the mouse and choose one of the insert commands from context menu.</source>
        <translation>Kasuta kontekstimenüü saamiseks paremat hiirenuppu ja vali menüüst manustamiskäsk.</translation>
    </message>
    <message>
        <source>Edit table</source>
        <translation>Redigeeri tabelit</translation>
    </message>
    <message>
        <source>Edit link</source>
        <translation>Redigeeri linki</translation>
    </message>
    <message>
        <source>Edit the class attribute of the tags header, paragraph, bold, italic, ol, ul</source>
        <translation>Redigeeri märgendi klassiatribuuti. Märgendid: päis, lõik, paks, kursiiv, nummerdatud loend, nummerdamata loend</translation>
    </message>
    <message>
        <source>Tips</source>
        <translation>Vihjed</translation>
    </message>
    <message>
        <source>The status bar will show the current tag name, all its parent tags and class information of the tag.</source>
        <translation>Olekuriba näitab käesoleva märgendi nime, kõiki selle emamärgendeid ning märgendi klassiinfot.</translation>
    </message>
    <message>
        <source>You can change the looks of the editor by editing editor.css in the extension/ezdhtml/design/standard/stylesheets/ezdhtml/ directory.</source>
        <translation>Redaktori väljanägemise muutmiseks võib redigeerida faili editor.css , kataloogis extension/ezdhtml/design/standard/stylesheets/ezdhtml/ .</translation>
    </message>
    <message>
        <source>You can edit wordmatch.ini under directory extension/ezdhtml/settings/ to make text copied from MS Word directly assigned to a desired class.</source>
        <translation>MS Wordist kopeeritud teksti soovitud klassi lisamiseks saab redigeerida faili wordmatch.ini , kataloogis extension/ezdhtml/design/standard/stylesheets/ezdhtml/ .</translation>
    </message>
    <message>
        <source>Close Window</source>
        <translation>Sulge aken</translation>
    </message>
    <message>
        <source>Insert object, link, anchor, literal, custom tag, table</source>
        <translation>Objekti, lingi, ankru, täht-tähelise teksti, kohandatud märgendi või tabeli lisamine</translation>
    </message>
    <message>
        <source>Create a numbered list. To create a new list item, press &quot;Enter&quot;. To end a list, press &quot;Enter&quot; key on an empty list item. If you click this button when the cursor is on a list item, the formatting will be removed.</source>
        <translation>Nummerdatud loendi loomine. Uue loendi elemendi loomiseks vajuta &quot;Enter&quot;. Loendi lõpetamiseks vajuta &quot;Enter&quot; tühjal loendi elemendil. Kui selle nupu vajutamisel on kursor loendi elemendil, siis kõrvaldatakse loendiformaat.</translation>
    </message>
    <message>
        <source>Create a bullet list. To create a new list item, press &quot;Enter&quot;. To end a list, press &quot;Enter&quot; key on an empty list item. If you click this button when the cursor is on a list item, the formatting will be removed.</source>
        <translation>Nummerdamata loendi loomine. Uue loendi elemendi loomiseks vajuta &quot;Enter&quot;. Loendi lõpetamiseks vajuta &quot;Enter&quot; tühjal loendi elemendil. Kui selle nupu vajutamisel on kursor loendi elemendil, siis kõrvaldatakse loendiformaat.</translation>
    </message>
    <message>
        <source>Insert an image or any other object from the related objects list. For images you can specify size and/or alignment. You can add custom attributes by clicking the &quot;New attribute&quot; button. To upload local images/files, click &quot;Upload new&quot; button. In the upload local file window, choose the local file, specify the name of the new object, choose placement from list and then click &quot;Upload&quot; button. Note that embedded object will begin on a new line when displayed in the resulting XHTML.</source>
        <translation>Seotud objektide loendist pildi või mõne muu objekti manustamine. Piltide jaoks saab määrata suurust ja/või joondamist. &quot;Uus atribuut&quot; nupu abil on võimalik lisada kohandatud atribuute. Lokaalsete piltide üles laadimiseks kasuta &quot;Lae üles uus&quot; nuppu. Lokaalfaili üles laadimise aknas vali fail, määra uue objekti nimi, vali loendist paigutus ning vajuta &quot;Lae üles&quot; nuppu. Arvesta, et manustatud objekt kuvatakse leheküljel uuelt realt algavana.</translation>
    </message>
    <message>
        <source>Create an anchor. An anchor-like icon will appear in the editor.</source>
        <translation>Ankru loomine. Redaktoris kuvatakse ankrukujuline ikoon.</translation>
    </message>
    <message>
        <source>Create a custom tag. Click the button to open the insert custom tag window with a list of available custom tags. Select the name of the custom tag you want to insert, write the tag contents in the textfield &quot;Text&quot; and click the &quot;OK&quot; button. You can add custom attributes by clicking the &quot;InsertAttribute&quot; button. Block custom tags are inserted as a single row and single column table. &quot;Text&quot; field is inactive for block custom tags. You can write text inside the table.</source>
        <translation>Kohandatud märgendi loomine. Saadaolevate märgenditega akna avamiseks vajuta seda nuppu. Vali lisatav märgend, kirjuta selle sisu välja &quot;Tekst&quot; ning vajuta nuppu &quot;OK&quot;. &quot;Lisa atribuut&quot; nupu abil on võimalik lisada kohandatud atribuute. Blokitüüpi kohandatud märgendid kuvatakse ühelahtrilise tabelina ning &quot;Tekst&quot; nupp on nende jaoks keelatud.</translation>
    </message>
    <message>
        <source>Insert a row above the current row.</source>
        <translation>Lisa uus rida käesoleva rea kohale.</translation>
    </message>
    <message>
        <source>Insert a column to the left of the current cell.</source>
        <translation>Lisa uus veerg käesolevast lahtrist vasakule.</translation>
    </message>
    <message>
        <source>Delete the current row.</source>
        <translation>Kustuta käesolev rida.</translation>
    </message>
    <message>
        <source>Delete the current column.</source>
        <translation>Kustuta käesolev veerg.</translation>
    </message>
    <message>
        <source>Split the current cell into two cells.</source>
        <translation>Jaga käesolev lahter kaheks lahtriks.</translation>
    </message>
    <message>
        <source>Merge the selected cells in the same row (adding the attribute &quot;rowspan&quot; to the table cell). To merge cells in different rows (adding the attribute &quot;colspan&quot; to the table cell), right click the table cell and choose the command &quot;Merge down&quot;.</source>
        <translation>Valitud sama rea lahtrite ühendamine üheks (html &quot;rowspan&quot; lisamine tabeli lahtrile). Erinevate ridade lahtrite ühendamiseks (html &quot;colspan&quot;) tee lahtril paremklõps ja vali &quot;Ühenda allapoole&quot;.</translation>
    </message>
    <message>
        <source>Move the pointer to a table cell, right click it and choose a command from the context menu. You can insert rows, insert columns,
delete rows, delete columns, split cells or insert objects, tables, links, anchors, custom tags and literal tags.
To set a table cell as the table header, choose &quot;TH&quot; from the context menu. To merge cells in different rows choose the command &quot;Merge down&quot;.
To edit table properties, choose &quot;Table Properties&quot;. To edit table cell properties, choose &quot;Cell Properties&quot;. A window will pop up where you can set cell width and cell class. You can set width and class either for the current cell, for all the cells in the current row or for all the cells in the current column by choosing Cell, Row, Column, respectively using the radiobuttons.</source>
        <translation>Aseta kursor tabeli lahtrisse ja vali tegevus paremklõpsu abil avanevast menüüst. Nii saab lisada ridasid ja veerge,
kustutada ridasid ja veerge, lahtreid mitmeks jagada ning lisada objekte, tabeleid, linke, ankruid,
kohandatud märgendeid ning täht-tähelisi märgendeid.
Tabeli lahtri määramiseks tabeli päisena vali kontekstimenüüst &quot;TH&quot;. Eri ridade lahtrite ühendamiseks vali
&quot;Ühenda allapoole&quot;
Tabeli omaduste redigeerimiseks vali &quot;Tabeli Omadused&quot;. Lahtri omaduste redigeerimiseks vali &quot;Lahtri Omadused&quot;.
Avaneb aken, kus saab seada lahtri laiust ja klassi.  Seadeid saab määrata korraga mitme lahtri jaoks, kasutades
vastavalt raadionuppe &quot;Lahter&quot;, &quot;Rida&quot; ning &quot;Veerg&quot;.</translation>
    </message>
    <message>
        <source>Edit the properties of object, anchor, custom tag</source>
        <translation>Objekti, ankru või kohandatud märgendi omaduste redigeerimine</translation>
    </message>
    <message>
        <source>Right click the object and choose &quot;Properties&quot; from the context menu, the object properties window will pop up. Edit properties of the object and click &quot;OK&quot;. If no changes need to be done, simply click the &quot;Cancel&quot; button.</source>
        <translation>Vali objektil paremklõpsu abil avanevast menüüst &quot;Omadused&quot; ning avaneb objekti omaduste aken. Peale muudatuste tegemist vajuta &quot;OK&quot;. Muudatustest loobumiseks kasuta nuppu &quot;Loobu&quot;.</translation>
    </message>
    <message>
        <source>Move the pointer to the link text and right click it. Select &quot;Link properties&quot; from the context menu if you want
to edit link properties. Select &quot;Remove Link&quot; if you just want to remove the link.</source>
        <translation>Vii kursor lingi tekstile ning paremklõpsa seda. Lingi omaduste muutmiseks vali avanevast kontekstimenüüst &quot;Lingi omadused&quot;. Lingi kõrvaldamiseks vali &quot;Lingi kõrvaldamine&quot;.</translation>
    </message>
    <message>
        <source>Move the pointer to the text and right click it. Do not make any text selection before right clicking. Choose the command &quot;Properties&quot; from the context menu. A window will pop up where you can assign a class to this tag (You need to define available classes for this tag in content.ini).</source>
        <translation>Vii kursor teksti kohale ning paremklõpsa seda ilma teksti märgistamata. Vali kontekstimenüüst käsk &quot;Omadused&quot;. Avaneb aken, milles saab sellele märgendile määrata klassi (saadaolevad klassid on määratud failis content.ini).</translation>
    </message>
    <message>
        <source>You can create a new line by holding the Shift key down and type Enter.</source>
        <translation>Uue rea lisamiseks hoia all Shift klahvi ja vajuta Enter.</translation>
    </message>
    <message>
        <source>You can create a new paragraph by pressing the Enter key.</source>
        <translation>Uue lõigu loomiseks vajuta Enterit.</translation>
    </message>
    <message>
        <source>You can make an image-link by selecting the image first and then either clicking the link button in the toolbar or choosing command &quot;Insert Link&quot; from context menu.</source>
        <translation>Pildilingi loomiseks märgista pilt ning siis kas vajuta lingi nuppu tööriistaribal või vali &quot;Lisa Link&quot; kontekstimenüüst.</translation>
    </message>
    <message>
        <source>Merge the selected cells into one cell. The cells must be empty.</source>
        <translation>Valitud lahtrite üheks lahtriks ühendamine. Lahtrid peavad olema tühjad.</translation>
    </message>
    <message>
        <source>Move the pointer to a table cell, right click it and choose a command from the context menu. You can insert rows, insert columns,
delete rows, delete columns, split cells or insert objects, tables, links, anchors, custom tags and literal tags.
To set a table cell as the table header, choose &quot;Change to TH&quot; from the context menu.
To edit table properties, choose &quot;Table Properties&quot;. To edit table cell properties, choose &quot;Cell Properties&quot;. A window will pop up where you can set cell width and cell class. You can set width and class either for the current cell, for all the cells in the current row or for all the cells in the current column by choosing Cell, Row, Column, respectively using the radiobuttons.</source>
        <translation>Aseta kursor tabeli lahtrisse ja vali tegevus paremklõpsu abil avanevast menüüst. Nii saab lisada ridasid ja veerge,
kustutada ridasid ja veerge, lahtreid mitmeks jagada ning lisada objekte, tabeleid, linke, ankruid,
kohandatud märgendeid ning täht-tähelisi märgendeid.
Tabeli lahtri määramiseks tabeli päisena vali kontekstimenüüst &quot;TH&quot;. Eri ridade lahtrite ühendamiseks vali
&quot;Ühenda allapoole&quot;
Tabeli omaduste redigeerimiseks vali &quot;Tabeli Omadused&quot;. Lahtri omaduste redigeerimiseks vali &quot;Lahtri Omadused&quot;.
Avaneb aken, kus saab seada lahtri laiust ja klassi.  Seadeid saab määrata korraga mitme lahtri jaoks, kasutades
vastavalt raadionuppe &quot;Lahter&quot;, &quot;Rida&quot; ning &quot;Veerg&quot;.</translation>
    </message>
</context>
<context>
    <name>ezdhtml</name>
    <message>
        <source>Name</source>
        <comment>design/standard/ezdhtml
</comment>
        <translation>Nimi</translation>
    </message>
</context>
<context>
    <name>handlers/input</name>
    <message>
        <source>Node %1 does not exist.</source>
        <translation>Tippu %1 ei eksisteeri.</translation>
    </message>
    <message>
        <source>Node &apos;%1&apos; does not exist.</source>
        <translation>Tippu &apos;%1&apos; ei ole olemas.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Content required</source>
        <translation>Sisu on kohustuslik</translation>
    </message>
    <message>
        <source>Invalid e-mail address: &apos;%1&apos;</source>
        <translation>Vigane e-kirja aadress: &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes/ezxmltext</name>
    <message>
        <source>Wrong closing tag</source>
        <translation>Vigane sulgev märgend</translation>
    </message>
    <message>
        <source>Wrong closing tag : &amp;lt;/%1&amp;gt;.</source>
        <translation>Vigane sulgev märgend : &amp;lt;/%1&amp;gt;.</translation>
    </message>
    <message>
        <source>Wrong opening tag</source>
        <translation>Vigane avav märgend</translation>
    </message>
    <message>
        <source>Unknown tag: &amp;lt;%1&amp;gt;.</source>
        <translation>Tundmatu märgend: &amp;lt;%1&amp;gt;.</translation>
    </message>
    <message>
        <source>Can&apos;t convert tag&apos;s name: &amp;lt;%1&amp;gt;.</source>
        <translation>Märgendi nime ei saa muuta: &amp;lt;%1&amp;gt;.</translation>
    </message>
    <message>
        <source>Class &apos;%1&apos; is not allowed for element &amp;lt;%2&amp;gt; (check content.ini).</source>
        <translation>Klass &apos;%1&apos; ei ole elemendi &amp;lt;%2&amp;gt; jaoks lubatud (vaata faili content.ini).</translation>
    </message>
    <message>
        <source>Required attribute &apos;%1&apos; is not presented in tag &amp;lt;%2&amp;gt;.</source>
        <translation>Märgendis &amp;lt;%2&amp;gt; puudub nõutud atribuut &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Custom tag &apos;%1&apos; is not allowed.</source>
        <translation>Kohandatud märgend &apos;%1&apos; ei ole lubatud.</translation>
    </message>
    <message>
        <source>%1 is not allowed to be a child of &amp;lt;%2&amp;gt;.</source>
        <translation>%1 ei saa olla &amp;lt;%2&amp;gt; tütarobjektiks.</translation>
    </message>
    <message>
        <source>Attribute &apos;%1&apos; is not allowed in &amp;lt;%2&amp;gt; element.</source>
        <translation>Attribuut &apos;%1&apos; ei ole elemendis &amp;lt;%2&amp;gt; lubatud.</translation>
    </message>
</context>
</TS>
