<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/article/article_index</name>
    <message>
        <source>Article index</source>
        <translation>Artikli indeks</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/article/comments</name>
    <message>
        <source>Comments</source>
        <translation>Kommentaarid</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Uus kommentaar</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>Kommenteerimiseks %login_link_startLogi sisse%login_link_end või %create_link_startloo kasutajakonto%create_link_end .</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/calendar</name>
    <message>
        <source>Previous month</source>
        <translation>Eelmine kuu</translation>
    </message>
    <message>
        <source>Next month</source>
        <translation>Järgmine kuu</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Kalender</translation>
    </message>
    <message>
        <source>Mon</source>
        <translation>E</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>T</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>K</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>N</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>R</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>L</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>P</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/blog/extra_info</name>
    <message>
        <source>Tags</source>
        <translation>Märgendid</translation>
    </message>
    <message>
        <source>Archive</source>
        <translation>Arhiiv</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Vorm %formname</translation>
    </message>
    <message>
        <source>Thank you for your feedback.</source>
        <translation>Täname tagasiside eest.</translation>
    </message>
    <message>
        <source>You have already submitted this form. The data you entered was:</source>
        <translation>Oled selle vormi juba täitnud. Sisestatud andmed on:</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Saidile tagasi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Küsitlus %pollname</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Tulemused</translation>
    </message>
    <message>
        <source>Please log in to vote on this poll.</source>
        <translation>Sellel küsitlusel hääletamiseks pead sisse logima.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Oled selles küsitluses juba hääletanud.</translation>
    </message>
    <message>
        <source>Votes</source>
        <translation>Hääled</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>Kokku %count häält</translation>
    </message>
    <message>
        <source>Back to poll</source>
        <translation>Tagasi küsitluse juurde</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/feedback</name>
    <message>
        <source>Feedback from %1</source>
        <translation>Tagasiside, allikas: %1</translation>
    </message>
    <message>
        <source>The following feedback was collected</source>
        <translation>Koguti järgmine tagasiside</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfomail/form</name>
    <message>
        <source>Collected information from %1</source>
        <translation>Kogutud andmed, allikas: %1</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>Koguti järgmised andmed</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/advancedsearch</name>
    <message>
        <source>Advanced search</source>
        <translation>Keerukam otsing</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Otsi kõiki sõnu</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Otsi täpset väljendit</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Avaldatud</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Suvalisel ajal</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Eile</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Eelmisel nädalal</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Eelmisel kolmel kuul</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Eelmisel aastal</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Leheküljel kuvatakse</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5  nimetust</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10  nimetust</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20  nimetust</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30  nimetust</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50  nimetust</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Otsing</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>&quot;%1&quot; otsimine ei andnud tulemusi</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>&quot;%1&quot; otsimine andis %2 vastet</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Eelmisel kuul</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Lehitse</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Select&quot; button.</source>
        <translation>Objektide valikuks kasuta vastavat raadionuppu või märkeruute ning vajuta nuppu &quot;Vali&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the parent object name to display a list of its children.</source>
        <translation>Mõne kuvatud objekti tütarobjekti valimiseks vajuta tütarde loendi nägemiseks emaobjekti nimele.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Tagasi</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Ülatase</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Vali</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/browse_mode_list</name>
    <message>
        <source>Invert selection</source>
        <translation>Valiku vastupidiseks muutmine</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/diff</name>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Objekti &lt;%object_name&gt; versioonid [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versioon</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Olek</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tõlked</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Looja</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Muudetud</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Mustand</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Avaldatud</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Ootel</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Arhiveeritud</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Tagasi lükatud</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Puutumata mustand</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Sellel objektil ei ole ühtegi versiooni.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Näita erinevusi</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Versioonide %oldVersion ja %newVersion vahelised erinevused</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Vana versioon</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Muudatused reas</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Muudatused blokis</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Uus versioon</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/draft</name>
    <message>
        <source>Select all</source>
        <translation>Vali kõik</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Tühista kõik valikud</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Minu mustandid</translation>
    </message>
    <message>
        <source>Empty draft</source>
        <translation>Tühi mustand</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Need on objektid, millega hetkel töötad.  Mustandid kuuluvad sulle ja on nähtavad ainult sulle.
    Võid neid mustandeid kas redigeerida või siis kõrvaldada, kui neid enam vaja ei ole.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klass</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektsioon</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versioon</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Keel</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Viimati muudetud</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kõrvalda</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Sul ei ole mustandeid</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Muuda %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Saada avaldamiseks</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Salvesta mustand</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Tühista mustand</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Versioonihaldus</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Salvesta ja välju</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Eelvaade</translation>
    </message>
    <message>
        <source>Translate from</source>
        <translation>Lähtekeel</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Tõlgi</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentatsioon</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Sisu tõlkimine keelest %from_lang keelde %from_lang</translation>
    </message>
    <message>
        <source>Content in %language</source>
        <translation>Sisu %language keeles</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <source>Not translatable</source>
        <translation>Tõlkimatu</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Kohustuslik</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Andmekogumisvorm</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_draft</name>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>Praegu on avaldatud versioon %version, avaldamisaeg: %time. </translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>Viimati muudetud: %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Objekti omanikuks on %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by yourself and others.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>See objekt on juba muutmisel kas sinu või mõne teise kasutaja poolt.
    Võid kas jätkata mõne oma mustandi redigeerimist või luua selleks uue mustandi.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Sa juba muudad seda objekti.
       Sa võid jätkata mõne oma mustandi muutmist või luua uue mustandi.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about their draft or create a new draft for your own use.</source>
        <translation>Seda objekti muudab juba keegi teine.
      Sa peaksid kas võtma ühendust muutjaga või siis looma enda jaoks uue mustandi.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Praegused mustandid</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versioon</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Omanik</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Loodud</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Viimati muudetud</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Uus mustand</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/edit_languages</name>
    <message>
        <source>Existing languages</source>
        <translation>Olemasolevad keeled</translation>
    </message>
    <message>
        <source>Select the language you want to use when editing the object.</source>
        <translation>Vali keel, milles soovid objekti redigeerida.</translation>
    </message>
    <message>
        <source>New languages</source>
        <translation>Uued keeled</translation>
    </message>
    <message>
        <source>Select the language you want to add to the object.</source>
        <translation>Vali keel, mille soovid objektile lisada.</translation>
    </message>
    <message>
        <source>Select the language the new translation will be based on.</source>
        <translation>Vali keel, millel uus tõlge baseerub.</translation>
    </message>
    <message>
        <source>Use an empty, untranslated draft</source>
        <translation>Kasuta tühja, ilma tõlketa mustandit</translation>
    </message>
    <message>
        <source>You do not have permission to create a translation in another language.</source>
        <translation>Sul pole luba muukeelset tõlget luua.</translation>
    </message>
    <message>
        <source>However, you can select one of the following languages for editing.</source>
        <translation>Sa võid aga valida muutmiseks ühe järgnevatest keeltest.</translation>
    </message>
    <message>
        <source>You do not have permission to edit the object in any available languages.</source>
        <translation>Sul pole üheski olemasolevas keeles luba objekti muuta.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/history</name>
    <message>
        <source>Version not a draft</source>
        <translation>Versioon pole mustand</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore. Only drafts can be edited.</source>
        <translation>Versioon %1 ei ole enam muutmiseks kättesaadav, muuta saab ainult mustandeid.</translation>
    </message>
    <message>
        <source>To edit this version, first create a copy of it.</source>
        <translation>Versiooni muutmiseks tee sellest esmalt koopia.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Versioon ei kuulu sulle</translation>
    </message>
    <message>
        <source>Version %1 was not created by you. Only your own drafts can be edited.</source>
        <translation>Versioon %1 ei kuulu sulle. Redigeerida saab ainult oma mustandeid.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Uut versiooni pole võimalik luua</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Versiooniajaloo piir on ületatud ja süsteem ei saa ühtegi arhiveeritud versiooni kõrvaldada.</translation>
    </message>
    <message>
        <source>You can either change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Sa võid kas muuta versiooniajaloo sätteid failis content.ini, kõrvaldada mustandversioone või redigeerida mõnd eksisteerivat mustandit.</translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Objekti &lt;%object_name&gt; versioonid [%version_count]</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Vaheta valikut</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versioon</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Olek</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Looja</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Loodud</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Muudetud</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Versiooni #%version_number valimine kõrvaldamiseks.</translation>
    </message>
    <message>
        <source>Version #%version_number cannot be removed because it is either the published version of the object or because you do not have permission to remove it.</source>
        <translation>Versiooni #%version_number ei saa kõrvaldada, sest see on kas objekti avaldatud versioon või sul pole selle kõrvaldamiseks piisavalt õigusi.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Versiooni #%version_number sisu vaatamine. Tõlge: %translation.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Mustand</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Avaldatud</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Ootel</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Arhiveeritud</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Tagasi lükatud</translation>
    </message>
    <message>
        <source>Untouched draft</source>
        <translation>Puutumata mustand</translation>
    </message>
    <message>
        <source>There is no need to do a copies of untouched drafts.</source>
        <translation>Puutumata mustandit kopeerida ei ole mõtet.</translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Koopia tegemine versioonist #%version_number.</translation>
    </message>
    <message>
        <source>You cannot make copies of versions because you do not have permission to edit the object.</source>
        <translation>Sa ei saa versioonidest koopiaid teha, sest sul puuduvad objekti muutmiseks vajalikud õigused.</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Versiooni #%version_number sisu muutmine.</translation>
    </message>
    <message>
        <source>You cannot edit the contents of version #%version_number either because it is not a draft or because you do not have permission to edit the object.</source>
        <translation>Sa ei saa versiooni #%version_number sisu muuta, sest see kas pole mustand või sul puuduvad objekti muutmiseks vajalikud õigused.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Sellel objektil ei ole ühtegi versiooni.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Kõrvalda valitud</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Valitud versioonide kõrvaldamine objektist.</translation>
    </message>
    <message>
        <source>Show differences</source>
        <translation>Näita erinevusi</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Tagasi</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Avaldatud versioon</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tõlked</translation>
    </message>
    <message>
        <source>New drafts [%newerDraftCount]</source>
        <translation>Uued mustandid [%newerDraftCount]</translation>
    </message>
    <message>
        <source>This object does not have any drafts.</source>
        <translation>Sellel objektil ei ole ühtegi mustandit.</translation>
    </message>
    <message>
        <source>Differences between versions %oldVersion and %newVersion</source>
        <translation>Versioonide %oldVersion ja %newVersion vahelised erinevused</translation>
    </message>
    <message>
        <source>Old version</source>
        <translation>Vana versioon</translation>
    </message>
    <message>
        <source>Inline changes</source>
        <translation>Muudatused reas</translation>
    </message>
    <message>
        <source>Block changes</source>
        <translation>Muudatused blokis</translation>
    </message>
    <message>
        <source>New version</source>
        <translation>Uus versioon</translation>
    </message>
    <message>
        <source>Back to history</source>
        <translation>Tagasi ajaloo juurde</translation>
    </message>
    <message>
        <source>Modified translation</source>
        <translation>Muudetud tõlge</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/keyword</name>
    <message>
        <source>Keyword: %keyword</source>
        <translation>Märksõna: %keyword</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <source>Search</source>
        <translation>Otsing</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.
</comment>
        <translation>Kui soovid rohkem valikuvariante, proovi %1keerukamat otsingut%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Järgnevad sõnad jäeti otsingust välja:</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;.</source>
        <translation>&quot;%1&quot; otsimine ei andnud tulemusi.</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Otsivihjed</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Kontrolli märksõnade õigekirja.</translation>
    </message>
    <message>
        <source>Try changing some keywords (eg, &quot;car&quot; instead of &quot;cars&quot;).</source>
        <translation>Proovi märksõnu üldisemaks muuta (näiteks proovi &quot;autod&quot; asemel &quot;auto&quot;).</translation>
    </message>
    <message>
        <source>Try searching with less specific keywords.</source>
        <translation>Proovi otsida vähem spetsiifilisi võtmesõnu.</translation>
    </message>
    <message>
        <source>Reduce number of keywords to get more results.</source>
        <translation>Rohkemate tulemuste saamiseks vähenda märksõnade arvu.</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>&quot;%1&quot; otsimine andis %2 vastet</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Vihje sõbrale</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Sõnum on saadetud.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Algsele leheküljele tagasipöördumiseks klõpsa siin.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Sõnumit ei saadetud.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Sõnumit ei saadetud tundmatu vea tõttu. Palun teata sellest veast saidi administraatorile.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Palun paranda järgmised vead:</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Sinu nimi</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Sinu e-posti aadress</translation>
    </message>
    <message>
        <source>Recipient&apos;s email address</source>
        <translation>Adressaadi e-posti aadress</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentaar</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Saada</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/view/versionview</name>
    <message>
        <source>Manage versions</source>
        <translation>Versioonihaldus</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Avalda</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/comment</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Muuda %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Saada avaldamiseks</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tühista</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/file</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Muuda %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Saada avaldamiseks</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tühista</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_reply</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Muuda %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Saada avaldamiseks</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tühista</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/edit/forum_topic</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Muuda %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Saada avaldamiseks</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tühista</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/forum</name>
    <message>
        <source>Latest from</source>
        <translation>Viimane saatjalt</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/embed/poll</name>
    <message>
        <source>Vote</source>
        <translation>Hääleta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezinfo/about</name>
    <message>
        <source>eZ Publish information: %version</source>
        <translation>eZ Publishi teave: %version</translation>
    </message>
    <message>
        <source>What is eZ Publish?</source>
        <translation>Mis on eZ Publish?</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Litsents</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Kaastöölised</translation>
    </message>
    <message>
        <source>Copyright Notice</source>
        <translation>Autoriõiguse teade</translation>
    </message>
    <message>
        <source>Third-Party Software</source>
        <translation>Kolmandate tootjate tarkvara</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Laiendused</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezodf/browse_place</name>
    <message>
        <source>Choose document placement</source>
        <translation>Vali dokumendi asukoht</translation>
    </message>
    <message>
        <source>Please choose the placement for the OpenOffice.org object.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Vali OpenOffice.org dokumendi jaoks asukoht.

    Vali asukoht ja vajuta nuppu %buttonname.
    Valiku kiirendamiseks saad kasutada viimaste asukohtade ning järjehoidjate tööriista.
    Sirvimiseks vajuta asukohtade nimedele.</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Vali</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezodf/export</name>
    <message>
        <source>OpenOffice.org export</source>
        <translation>OpenOffice.org eksport</translation>
    </message>
    <message>
        <source>Export eZ publish content to OpenOffice.org</source>
        <translation>eZ Publish&apos;i sisu OpenOffice.org&apos;i eksportimine</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Viga</translation>
    </message>
    <message>
        <source>Here you can export any eZ publish content object to an OpenOffice.org Writer document format.</source>
        <translation>Siin saad suvalist eZ Publish&apos;i sisuobjekti OpenOffice.org Writer dokumendiformaati eksportida.</translation>
    </message>
    <message>
        <source>Export Object</source>
        <translation>Ekspordi objekt</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/ezodf/import</name>
    <message>
        <source>Document is now imported</source>
        <translation>Dokument on nüüd imporditud</translation>
    </message>
    <message>
        <source>OpenOffice.org import</source>
        <translation>OpenOffice.org import</translation>
    </message>
    <message>
        <source>The object was imported as: %class_name</source>
        <translation>Objekt imporditi klassi: %class_name</translation>
    </message>
    <message>
        <source>Document imported as</source>
        <translation>Dokument imporditi kui</translation>
    </message>
    <message>
        <source>The images are placed in the media and can be re-used.</source>
        <translation>Pildid paigutatakse Meediumiteeki ja neid saab taaskasutada.</translation>
    </message>
    <message>
        <source>Import another document</source>
        <translation>Impordi järgmine dokument</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Laadi fail üles</translation>
    </message>
    <message>
        <source>Import OpenOffice.org document</source>
        <translation>Impordi OpenOffice.org dokument</translation>
    </message>
    <message>
        <source>Replace document</source>
        <translation>Asenda dokument</translation>
    </message>
    <message>
        <source>Import to</source>
        <translation>Impordi asukohta</translation>
    </message>
    <message>
        <source>You can import OpenOffice.org Writer documents directly into eZ publish from this page. You are
asked where to place the document and eZ publish does the rest. The document is converted into
the appropriate class during the import, you get a notice about this after the import is done.
Images are placed in the media library so you can re-use them in other articles.</source>
        <translation>Sellelt leheküljelt saad OpenOffice.org dokumente otse eZ Publishisse importida.  Sult küsitakse
dokumendi jaoks asukoht ja eZ Publish teeb kõik ülejäänu. Dokument muudetakse impordi käigus
vastava klassi objektiks, selle kohta kuvatakse peale impordi lõppu teade.
Pildid paihutatakse meediumiteeki, et neid saaks hiljem uuesti kasutada.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Comments</source>
        <translation>Kommentaarid</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Uus kommentaar</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>Kommenteerimiseks %login_link_startLogi sisse%login_link_end või %create_link_startloo kasutajakonto%create_link_end .</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Vihje sõbrale</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_mainpage</name>
    <message>
        <source>Tip a friend</source>
        <translation>Vihje sõbrale</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article_subpage</name>
    <message>
        <source>Tip a friend</source>
        <translation>Vihje sõbrale</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/blog_post</name>
    <message>
        <source>Tags:</source>
        <translation>Märgendid:</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentaarid</translation>
    </message>
    <message>
        <source>%login_link_startLog in%login_link_end or %create_link_startcreate a user account%create_link_end to comment.</source>
        <translation>Kommenteerimiseks %login_link_startLogi sisse%login_link_end või %create_link_startloo kasutajakonto%create_link_end .</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/documentation_page</name>
    <message>
        <source>Table of contents</source>
        <translation>Sisukord</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation>Loodud:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Muudetud:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event</name>
    <message>
        <source>Category</source>
        <translation>Kategooria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_calendar</name>
    <message>
        <source>Mon</source>
        <translation>E</translation>
    </message>
    <message>
        <source>Tue</source>
        <translation>T</translation>
    </message>
    <message>
        <source>Wed</source>
        <translation>K</translation>
    </message>
    <message>
        <source>Thu</source>
        <translation>N</translation>
    </message>
    <message>
        <source>Fri</source>
        <translation>R</translation>
    </message>
    <message>
        <source>Sat</source>
        <translation>L</translation>
    </message>
    <message>
        <source>Sun</source>
        <translation>P</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Täna</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategooria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/event_view_program</name>
    <message>
        <source>Past events</source>
        <translation>Möödunud sündmused</translation>
    </message>
    <message>
        <source>Future events</source>
        <translation>Tuleviku sündmused</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/feedback_form</name>
    <message>
        <source>Send form</source>
        <translation>Saada vorm</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <source>New topic</source>
        <translation>Uus teema</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Hoia mind kursis</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Foorumite kasutamiseks pead olema sisse loginud. Seda saad teha %login_link_start%siin%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Teema</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Vastuseid</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Viimane vastus</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Leheküljed</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_reply</name>
    <message>
        <source>Message preview</source>
        <translation>Sõnumi eelvaade</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Teema</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Asukoht</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Moderaator</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum_topic</name>
    <message>
        <source>Previous topic</source>
        <translation>Eelmine teema</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Järgmine teema</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Uus vastus</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Hoia mind kursis</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Foorumite kasutamiseks pead olema sisse loginud. Seda saad teha %login_link_start%siin%login_link_end%</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Sõnum</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Asukoht</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Moderaator</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kõrvalda</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Selle elemendi kõrvaldamine.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forums</name>
    <message>
        <source>Topics</source>
        <translation>Teemad</translation>
    </message>
    <message>
        <source>Posts</source>
        <translation>Postitusi</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Viimane vastus</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/gallery</name>
    <message>
        <source>View as slideshow</source>
        <translation>Vaata slaidiseansina</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/image</name>
    <message>
        <source>Previous image</source>
        <translation>Eelmine pilt</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Järgmine pilt</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/multicalendar</name>
    <message>
        <source>Event</source>
        <translation>Sündmused</translation>
    </message>
    <message>
        <source>Start date</source>
        <translation>Alguskuupäev</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategooria</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Kirjeldus</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/poll</name>
    <message>
        <source>Vote</source>
        <translation>Hääleta</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Tulemus</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to basket</source>
        <translation>Lisa ostukorvi</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Lisa soovinimekirja</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Inimesed, kes ostsid selle toote, ostsid ka</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event</name>
    <message>
        <source>Category</source>
        <translation>Kategooria</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/event_calendar</name>
    <message>
        <source>Next events</source>
        <translation>Järgnevad sündmused</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/flash</name>
    <message>
        <source>View flash</source>
        <translation>Vaata Flash-animatsiooni</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum</name>
    <message>
        <source>Number of topics</source>
        <translation>Teemade arv</translation>
    </message>
    <message>
        <source>Number of posts</source>
        <translation>Postituste arv</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Viimane vastus</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Sisene foorumisse</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/forum_reply</name>
    <message>
        <source>Reply to:</source>
        <translation>Vastuse aadress:</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/poll</name>
    <message>
        <source>%count votes</source>
        <translation>%count häält</translation>
    </message>
    <message>
        <source>Vote</source>
        <translation>Hääleta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/quicktime</name>
    <message>
        <source>View movie</source>
        <translation>Vaata filmi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/real_video</name>
    <message>
        <source>View movie</source>
        <translation>Vaata filmi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/line/windows_media</name>
    <message>
        <source>View movie</source>
        <translation>Vaata filmi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/link</name>
    <message>
        <source>%sitetitle front page</source>
        <translation>Saidi %sitetitle esileht</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Otsi saidilt %sitetitle</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Prindiversioon</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/node/removeobject</name>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Kas soovid kindlasti need objektid kõrvaldada?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>tipu %nodename ja selle %childcount tütarobjekti. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Tõsta prügikasti</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Märkus</translation>
    </message>
    <message>
        <source>If %trashname is checked, removed items can be found in the trash.</source>
        <translation>Kui %trashname on märgitud siis säilitatakse kõrvaldatud objekte prügikastis.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Kinnita</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/addingresult</name>
    <message>
        <source>Add to my notifications</source>
        <translation>Lisa minu teavituste alla</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>Tipu &lt;%node_name&gt; jaoks on teavitus juba olemas.</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>Lisati tipu &lt;%node_name&gt; teavitus.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/notification/settings</name>
    <message>
        <source>Notification settings</source>
        <translation>Teavituse seaded</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Salvesta</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Otsing</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/parts/website_toolbar</name>
    <message>
        <source>About</source>
        <translation>Teave</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Loo siia</translation>
    </message>
    <message>
        <source>Edit: %node_name [%class_name]</source>
        <translation>Redigeeri: %node_name [%class_name]</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Teisalda</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kõrvalda</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Lisa asukohad</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentatsioon</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Asenda</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Ekspordi</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Impordi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/settings/edit</name>
    <message>
        <source>Node notification</source>
        <translation>Tipu teavitus</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klass</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektsioon</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Vali</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kõrvalda</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <source>Shopping basket</source>
        <translation>Ostukorv</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Konto andmed</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Kinnita tellimus</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Ostukorv</translation>
    </message>
    <message>
        <source>The following items were removed from your basket because the products were changed.</source>
        <translation>Järgnevad tooted eemaldati teie ostukorvist kuna neis on toimunud muudatused.</translation>
    </message>
    <message>
        <source>VAT is unknown</source>
        <translation>käibemaks ei ole teada</translation>
    </message>
    <message>
        <source>VAT percentage is not yet known for some of the items being purchased.</source>
        <translation>Mõnede ostetavate kaupade jaoks ei ole käibemaks veel teada.</translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation>Tõenäoliselt tähendab see, et mingi info sinu kohta ei ole veel teada ja seda küsitakse kassa läbimise käigus.</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Ostukorvi prooviti lisada ilma hinnata objekti.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Sinu makse katkestati.</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Üldarv</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>KM</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Hind koos käibemaksuga</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Soodustus</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Kogusumma km-ta</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Kogusumma km-ga</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Tundmatu</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Värskenda</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kõrvalda</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Valitud suvandid</translation>
    </message>
    <message>
        <source>Subtotal ex. VAT</source>
        <translation>Vahesumma km-ta</translation>
    </message>
    <message>
        <source>Subtotal inc. VAT</source>
        <translation>Vahesumma km-ga</translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation>Tarne</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Tellimuse kogusumma</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Jätka ostmist</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Kassa</translation>
    </message>
    <message>
        <source>You have no products in your basket.</source>
        <translation>Ostukorvis ei ole tooteid.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/confirmorder</name>
    <message>
        <source>Shopping basket</source>
        <translation>Ostukorv</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Konto andmed</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Kinnita tellimus</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Tooteartiklid</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Üldarv</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>KM</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Hind koos käibemaksuga</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Soodustus</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Kogusumma km-ta</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Kogusumma km-ga</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Valitud suvandid</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Tellimuse kokkuvõte</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Artiklite vahesumma</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Tellimuse kogusumma</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Kinnita</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/customerorderview</name>
    <message>
        <source>Customer information</source>
        <translation>Kliendi andmed</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Tellimisnimekiri</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Summa ilma käibemaksuta</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Summa koos käibemaksuga</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Ostunimekiri</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Toode</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Summa</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderlist</name>
    <message>
        <source>Order list</source>
        <translation>Tellimisnimekiri</translation>
    </message>
    <message>
        <source>Sort result by</source>
        <translation>Sordi tulemused:</translation>
    </message>
    <message>
        <source>Order time</source>
        <translation>Tellimisaeg</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Kasutajanimi</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>Tellimuse ID</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Tõusev</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>Sordi tõusvas järjestuses</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Laskuv</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>Sordi laskuvas järjestuses</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Sordi</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Summa ilma käibemaksuta</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Summa koos käibemaksuga</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Tellimisnimekiri on tühi</translation>
    </message>
    <message>
        <source>Archive</source>
        <translation>Arhiveerimine</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/orderview</name>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Tellimus %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Tooteartiklid</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Toode</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Üldarv</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>KM</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Hind koos käibemaksuga</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Soodustus</translation>
    </message>
    <message>
        <source>Total price ex. VAT</source>
        <translation>Kogusumma km-ta</translation>
    </message>
    <message>
        <source>Total price inc. VAT</source>
        <translation>Kogusumma km-ga</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Tellimuse kokkuvõte</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Kokkuvõte</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Artiklite vahesumma</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Tellimuse kogusumma</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>Tellimisajalugu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/userregister</name>
    <message>
        <source>Shopping basket</source>
        <translation>Ostukorv</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Konto andmed</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Kinnita tellimus</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Sinu konto andmed</translation>
    </message>
    <message>
        <source>Input did not validate. All fields marked with * must be filled in.</source>
        <translation>Sisendandmete õigsuse kontroll ebaõnnestus. Kõik tärniga tähistatud väljad tuleb täita.</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Eesnimi</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Perekonnanimi</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Ettevõte</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Tänav</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>Sihtnumber</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Koht</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Osariik</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Riik</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentaar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Jätka</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Kõik tärniga tähistatud väljad tuleb täita.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/wishlist</name>
    <message>
        <source>Wish list</source>
        <translation>Soovinimekiri</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Toode</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Üldarv</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Valitud suvandid</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Salvesta</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Kõrvalda artiklid</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Tühi soovinimekiri</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/simplified_treemenu/show_simplified_menu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Voldi kinni/lahti</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>Tipu ID: %node_id Nähtavus: %visibility</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/activate</name>
    <message>
        <source>Activate account</source>
        <translation>Aktiveeri konto</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Sinu konto on nüüd aktiveeritud.</translation>
    </message>
    <message>
        <source>Your account is already active.</source>
        <translation>Sinu konto on juba aktiveeritud.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Vabandust, esitatud võti ei kehti. Kontot ei aktiveeritud.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <source>User profile</source>
        <translation>Kasutaja profiil</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Kasutajanimi</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Minu mustandid</translation>
    </message>
    <message>
        <source>My orders</source>
        <translation>Minu tellimused</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Minu teavituse seaded</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation>Minu soovinimekiri</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Muuda profiili</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Vaheta parool</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/forgotpassword</name>
    <message>
        <source>An email has been sent to the following address: %1. It contains a link you need to click so that we can confirm that the correct user has received the new password.</source>
        <translation>Aadressile %1 on saadetud e-kiri.  Selles sisaldub link, mida peab parooli vahetuse kinnitamiseks kasutama.</translation>
    </message>
    <message>
        <source>There is no registered user with that email address.</source>
        <translation>Sellise e-posti aadressiga registreeritud kasutajat ei ole.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Parool genereeritit ja saadeti aadressile: %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>Võti on kas kehtetu või juba kasutatud. </translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Kas oled parooli unustanud?</translation>
    </message>
    <message>
        <source>If you have forgotten your password, enter your email address and we will create a new password and send it to you.</source>
        <translation>Kui oled parooli unustanud siis sisesta oma e-posti aadress ning me genereerime uue parooli ja saadame selle sulle.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Genereeri uus parool</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/login</name>
    <message>
        <source>Login</source>
        <translation>Logi sisse</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Sisselogimine ebaõnnestus</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Sisselogimiseks on vaja kehtivat kasutajanime ja parooli.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Ligipääs on keelatud</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Ligipääs aadressile %1 on sulle keelatud.</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name
</comment>
        <translation>Kasutajanimi</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Parool</translation>
    </message>
    <message>
        <source>Log in to the eZ Publish Administration Interface</source>
        <translation>Logi sisse eZ Publishi administreerimisliidesesse</translation>
    </message>
    <message>
        <source>Remember me</source>
        <translation>Jäta mind meelde</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button
</comment>
        <translation>Logi sisse</translation>
    </message>
    <message>
        <source>Sign up</source>
        <comment>Button</comment>
        <translation>Registreeru</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Unustasid parooli?</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/password</name>
    <message>
        <source>Change password for user</source>
        <translation>Parooli muutmine, kasutaja:</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>Palun sisesta uuesti oma vana parool.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>Paroolid ei ole ühesugused, trüki uus parool uuesti.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>Parool on edukalt värskendatud.</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Vana parool</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Uus parool</translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation>Sisesta veel kord parool</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <source>Register user</source>
        <translation>Registreeri kasutaja</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Sisendandmete õigsuse kontroll ebaõnnestus</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Sisendandmed on salvestatud</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registreeru</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tühista</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Uut kasutajat ei õnnestunud registreerida</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Tagasi</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/success</name>
    <message>
        <source>User registered</source>
        <translation>Kasutaja on registreeritud</translation>
    </message>
    <message>
        <source>Your account was successfully created. An email will be sent to the specified address. Follow the instructions in that email to activate your account.</source>
        <translation>Sinu konto on loodud. Sinu sisestatud e-posti aadressile saadetakse e-kiri instruktsioonidega konto aktiveerimiseks.</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Sinu konto on loodud.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <source>The file could not be found.</source>
        <translation>Faili ei õnnestunud leida.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezmedia</name>
    <message>
        <source>No %link_startFlash player%link_end avaliable!</source>
        <translation>%link_startFlash meedia mängijat%link_end ei leitud!</translation>
    </message>
    <message>
        <source>No media file is available.</source>
        <translation>Ühtegi meediumifaili ei ole.</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/ezprice</name>
    <message>
        <source>Price</source>
        <translation>Hind</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Sinu hind</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Sinu kokkuhoid</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/view/sitemap</name>
    <message>
        <source>Site map</source>
        <translation>Saidi kaart</translation>
    </message>
</context>
</TS>
