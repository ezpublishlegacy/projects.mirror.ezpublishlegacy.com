<!DOCTYPE TS><TS>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Inhalte</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Shop</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Setup</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Persönliches</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Sitemap</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Mülleimer</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Ihre Entwürfe</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Kollaboration</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Passwort ändern</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Klassen</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sektionen</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Triggers</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Übersetzungen</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Suchstatistiken</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Bestellliste</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Mehrwertsteuertypen</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Ermäßigung</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Rollen</translation>
    </message>
</context>
<context>
    <name>design/shop</name>
    <message>
        <source>Payment was canceled. Try to buy again.</source>
        <translation>Die Zahlung wurde abgebrochen. Bitte versuchen Sie erneut einzukaufen.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size:</source>
        <translation type="obsolete">Max. Dateigröße:</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Mehrfachauswahl</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation>Optionsstil</translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation>Checkbox-Stil</translation>
    </message>
    <message>
        <source>Enum Element:</source>
        <translation type="obsolete">Nummerierungselement:</translation>
    </message>
    <message>
        <source>Enum Value:</source>
        <translation type="obsolete">Nummerierungswert:</translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation>Neues Nummerierungselement</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Entferne Auswahl</translation>
    </message>
    <message>
        <source>Default value:</source>
        <translation type="obsolete">Vorgabe-Wert:</translation>
    </message>
    <message>
        <source>Min float value:</source>
        <translation type="obsolete">min. Fließkommawert (float):</translation>
    </message>
    <message>
        <source>Max float value:</source>
        <translation type="obsolete">max. Fließkommawert (float):</translation>
    </message>
    <message>
        <source>Min integer value:</source>
        <translation type="obsolete">min. Integer-Wert:</translation>
    </message>
    <message>
        <source>Max integer value:</source>
        <translation type="obsolete">max. Integer-Wert:</translation>
    </message>
    <message>
        <source>Media player type:</source>
        <translation type="obsolete">MediaPlayer-Typ:</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>RealPlayer</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows MediaPlayer</translation>
    </message>
    <message>
        <source>VAT type:</source>
        <translation type="obsolete">Mehrwertsteuertyp:</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Preis inkl. Mwst</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Preis exklusive MwSt</translation>
    </message>
    <message>
        <source>Max string length:</source>
        <translation type="obsolete">max. Zeichenkettenlänge:</translation>
    </message>
    <message>
        <source>Prefered columns</source>
        <translation type="obsolete">Bevorzugte Spalten</translation>
    </message>
    <message>
        <source>Prefered columns:</source>
        <translation type="obsolete">Bevorzugte Spalten:</translation>
    </message>
    <message>
        <source>Max file size</source>
        <translation>Maximale Dateigröße</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Standardwert</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Leer</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Aktuelles Datum</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Aktuelle Zeit</translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation>Aufzählungselement</translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation>Aufzählungswert</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Minimaler Fließkomma-Wert</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Maximaler Fließkomma-Wert</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Minimale Ganzzahl</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Maximale Ganzzahl</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Mediaplayertyp</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Standardname</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>MwSt-Typ</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Maximale Zeichenlänge</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Bevorzugte Anzahl von Reihen</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Aktuelle Zeit</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class type</source>
        <translation type="obsolete">Klassentyp bearbeiten</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="obsolete">Erstellt von</translation>
    </message>
    <message>
        <source>on</source>
        <translation>am</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Bearbeitet von</translation>
    </message>
    <message>
        <source>Object name:</source>
        <translation type="obsolete">Objekt-Name:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Identifikator:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>In group:</source>
        <translation type="obsolete">In Gruppe:</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation type="obsolete">Gruppe hinzufügen</translation>
    </message>
    <message>
        <source>Remove group</source>
        <translation type="obsolete">Gruppe entfernen</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Eingabe konnte nicht validiert werden</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attribute</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Erforderich</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Durchsuchbar</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Informationssammler</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Runter</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Rauf</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>Editing class group</source>
        <translation type="obsolete">Klassenbearbeitungsgruppe</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) class(es)?</source>
        <translation type="obsolete">Sind Sie sicher, dass Sie diese Klasse(n) löschen wollen?</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation type="obsolete">Lösche Klasse</translation>
    </message>
    <message>
        <source>will remove</source>
        <translation type="obsolete">wird löschen</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) group(s)?</source>
        <translation type="obsolete">Sind Sie sich sicher, dass Sie diese Gruppe(n) löschen wollen?</translation>
    </message>
    <message>
        <source>Editing class</source>
        <translation type="obsolete">Ändere Klasse</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation>Zuletzt geändert von</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifizierer</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Objektnamens Schema </translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Mitglied von Gruppen</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>füge zur Gruppe hinzu</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Lösche von Gruppen</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Datentypen</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Verwerfe Änderungen</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Sind Sie sicher, dass Sie diese Klassen entfernen wollen?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Entfernen von Klasse %1 wird auch %2 entfernen!</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Sind Sie sicher, dass Sie diese Klassengruppen entfernen wollen?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Entfernen con Klassengruppe %1 wird auch %2 entfernen!</translation>
    </message>
    <message>
        <source>Editing class - %1</source>
        <translation>Bearbeite Klasse - %1</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Bearbeite Klasse Gruppe - %1</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Defined class groups</source>
        <translation type="obsolete">Definierte Klassengruppen</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Bearbeiter:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Bearbeitet:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Klassengruppe</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Veränderer</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Verändert</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Neue Gruppe</translation>
    </message>
    <message>
        <source>help</source>
        <translation>Hilfe</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes have been defined for </source>
        <translation type="obsolete">Keine Klassen wurden definiert für</translation>
    </message>
    <message>
        <source>Defined class types for</source>
        <translation type="obsolete">Definierte Klassentypen für</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Indentifikator:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Bearbeiter:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Bearbeitet:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>No classes in </source>
        <translation>Keine Klassen in</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Klassen in</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifizierer</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Veränderer</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Verändert
</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Neue Klasse</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Gruppenliste für &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Keine Positionen in Gruppe.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Gruppen</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Bestätigung</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 wartet auf Bestätigung vom Bearbeiter</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 wurde bestätigt zum veröffentlichen</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 wurde nicht bestätigt zum veröffentlichen</translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation>%1 wurde zurückgewiesen zum erneuten bearbeiten</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 wartet auf Ihre Bestätigung</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Thema</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Ungelesen</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactive</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Verschickt: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Keine neuen Positionen zum Verarbeiten.</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Bestätigung</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Das Content-Objekt  %1 wartet auf Bestätigung bevor es veröffentlicht werden kann.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Möchten Sie eine Nachricht an die bearbeitende Person schicken?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Das Content-Objekt  %1 braucht Ihre Bestätigung, bevor es veröffentlicht werden kann.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Bestätigen Sie die Veröffentlichung des Content-Objekts?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Das Content Objekt %1 wurde bestätigt und wird veröffentlicht, sobald der Veröffentlichungs-Workflow fortgesetz wird.</translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived.</source>
        <translation type="obsolete">Das Content-Objekt %1 wurde nicht bestätigt und wird nun archiviert.</translation>
    </message>
    <message>
        <source>The content object %1 was deferred and is available as a draft.</source>
        <translation type="obsolete">Das Content-Objekt %1 wurde zwischen gespeichert und seht nun als Entwurf zur Verfügung.</translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation>Sie müssen den Entwurf wieder bearbeiten und veröffentlichen, damit die Bestätigung forgesetzt werden kann.</translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation>Falls die zu bestätigende Person den neuen Änderungen zustimmt, wird das Objekt veröffentlicht.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bearbeiten</translation>
    </message>
    <message>
        <source>The content object %1 was deferred and will be available as a draft.</source>
        <translation type="obsolete">Das Content-Objekt %1 wurde zwischen gespeichert und seht nun als Entwurf zur Verfügung.Das Content-Objekt %1 wurde zwischen gespeichert und seht nun als Entwurf zur Verfügung.</translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation>Der Author muss den Entwurf wieder bearbeiten und veröffentlichen, damit die Bestätigung forgesetzt werden kann.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Kommentar hinzufügen</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Verbieten</translation>
    </message>
    <message>
        <source>Defer</source>
        <translation type="obsolete">Zwischenspeichern</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Teilhaber</translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation>Content Objekt Klasse - %1</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Nachrichten</translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived. If you wish you may publish a new version of the object by clicking the edit link.</source>
        <translation>Das Content Objekt %1 wurde nicht bestätigt und wird archiviert. Wenn Sie möchten, können Sie eine neue version des Objektes durch klicken des ändern Links anlegen.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Ändere das Objekt</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Das Content Objekt %1 wurde nicht acceptiert und ist nun steht wieder als Entwurf zur Verfügung.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Das Content Objekt %1 wurde nicht acceptiert und ist nun steht wieder als Entwurf für den Author zur Verfügung.</translation>
    </message>
    <message>
        <source>Pushback</source>
        <translation>Zurück geschickt</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Sind Sie sicher, dass Sie die Übersetzung entfernen wollen?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Ändere die Übersetzung des Inhalts</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Wähle eine der Übersetzungen aus der Liste zum Ändern oder gebe eine Individuelle in das Eingabefeld ein.  </translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Neue Übersetzung für den Inhalt</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Wähle eine der Übersetzungen aus der Liste zum Hinzufügen oder gebe eine Individuelle in das Eingabefeld ein.  </translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Übersetzungen</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Individuell</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Name der Übersetzung</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Örtlichkeit</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Erstellen</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Übersezungen des Inhalts</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Unten finden Sie eine Liste von aktiven Übersetzungen, in die Content Objkte übersetzt werden können. </translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Land</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Kopiere %1</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation type="obsolete">Versionen</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Kopiere alle Versionen</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Kopiere die aktuelle Version</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>%1 Versionen sind verfügbar und die aktuelle Version ist %2.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Erzeuge neu</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="obsolete">E-Mail:</translation>
    </message>
    <message>
        <source>New author</source>
        <translation>Neuer Autor</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Lösche ausgewählte</translation>
    </message>
    <message>
        <source>Filename:</source>
        <translation type="obsolete">Dateiname:</translation>
    </message>
    <message>
        <source>Existing filename:</source>
        <translation type="obsolete">Bestehender Dateiname:</translation>
    </message>
    <message>
        <source>Existing orignal filename:</source>
        <translation type="obsolete">Bestehender Originaldateiname:</translation>
    </message>
    <message>
        <source>Existing mime/type:</source>
        <translation type="obsolete">Bestehender mime/type:</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Löschen</translation>
    </message>
    <message>
        <source>Year:</source>
        <translation type="obsolete">Jahr:</translation>
    </message>
    <message>
        <source>Month:</source>
        <translation type="obsolete">Monat:</translation>
    </message>
    <message>
        <source>Day:</source>
        <translation type="obsolete">Tag:</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation type="obsolete">Stunde:</translation>
    </message>
    <message>
        <source>Minute:</source>
        <translation type="obsolete">Minute:</translation>
    </message>
    <message>
        <source>Image filename:</source>
        <translation type="obsolete">Bild-Dateiname:</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Entferne Bild</translation>
    </message>
    <message>
        <source>ISBN:</source>
        <translation type="obsolete">ISBN:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="obsolete">Breite:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="obsolete">Höhe:</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="obsolete">Qualität:</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Beste</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Gering</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Automat. Auflösung hoch</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Automat. Auflösung niedrig</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Auto-Wiedergabe</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Schleife</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Controller</translation>
    </message>
    <message>
        <source>Controls:</source>
        <translation type="obsolete">Kontrollen:</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Bildfenster</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Bedienfeld</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>Bedienfeld Info-Lautstärke</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Bedienfeld Info</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Finde Objekt</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="obsolete">Eigenschaften:</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Neue Eigenschaft</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation type="obsolete">URL:</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation type="obsolete">Text:</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation type="obsolete">Login:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation type="obsolete">E-Mail:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete">Passwort:</translation>
    </message>
    <message>
        <source>Password confirmation:</source>
        <translation type="obsolete">Passwortbestätigung:</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Preis:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Ihr Preis:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Sie sparen:</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Benutzerdateninformationen</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation type="obsolete">E-Mail:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Dateiname</translation>
    </message>
    <message>
        <source>MIME Type</source>
        <translation>MIME Typ</translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation>Dateigröße</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Jahr</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Monat</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Tag</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Stunde</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minute</translation>
    </message>
    <message>
        <source>Image filename</source>
        <translation>Dateiname des Bildes</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Alternativer Bildtext</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Breite</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Qualität</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Kontrolen</translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation>Existierende Dateinamen</translation>
    </message>
    <message>
        <source>Existing orignal filename</source>
        <translation>Existierender original Dateiname</translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation>Existierender MIME/Typ</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Keine Relation</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Startwert</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Stopwert</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Schrittweite</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>User ID</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Bestätige Passwort</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Preis</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Replace object</source>
        <translation>Ersetze Objekt</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Entferne Objekt</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from:</source>
        <translation type="obsolete">Gesammelte Informationen von:</translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation>Folgende Informationen wurden gesammelt:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Eingabe war nicht validierbar</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ort</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Sortiert durch</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Reihenfolge</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Main</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Verschieben</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="obsolete">Pfad</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Veröffentlicht</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Verändert</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektion</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Tiefe</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Klassen-Identifikator</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Klassenname</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Add location(s)</source>
        <translation type="obsolete">Orte hinzufügen</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <source>Store Draft</source>
        <translation type="obsolete">Entwurf speichern</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Zur Veröffentlichung freigeben</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Objekt-Information</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation type="obsolete">Erstellt:</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Noch nicht veröffentlicht</translation>
    </message>
    <message>
        <source>Version info</source>
        <translation type="obsolete">Versions-Info</translation>
    </message>
    <message>
        <source>Editing:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Aktuell</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Manage</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Übersetzungen</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Verwandte Objekte</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Finde</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entferne</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Sind Sie sicher, dass Sie den Entwurf verwerfen wollen?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Gesammlete Informationen von %1</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Speichere Entwurf</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Ort hinzufügen</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Erstellt</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versionen</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Keine lokalen Informationen verfügbar)</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>nicht gültig</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Ort war nicht gültig</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Ändere %1 - %2</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Erweiterte Suche</translation>
    </message>
    <message>
        <source>No results were found when searching for:</source>
        <translation type="obsolete">Kein Ergebnis. Ihr(e) Suchbegriff(e):</translation>
    </message>
    <message>
        <source>Search for:</source>
        <translation type="obsolete">Suche nach:</translation>
    </message>
    <message>
        <source>returned</source>
        <translation type="obsolete">ergab</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">Treffer</translation>
    </message>
    <message>
        <source>Search all the words:</source>
        <translation type="obsolete">Suche mit allen Worten:</translation>
    </message>
    <message>
        <source>Search the exact phrase:</source>
        <translation type="obsolete">Mit der genauen Wortgruppe suchen:</translation>
    </message>
    <message>
        <source>Search with at least one of the words:</source>
        <translation type="obsolete">Suche mit irgendeinem der Wörter:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete">Klasse:</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Alle Klassen</translation>
    </message>
    <message>
        <source>Class attribute:</source>
        <translation type="obsolete">Klassen-Eigenschaften:</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Eigenschaften aktualisieren</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="obsolete">In:</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>alle Sektionen</translation>
    </message>
    <message>
        <source>Published:</source>
        <translation type="obsolete">Veröffentlicht:</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Jedes Datum</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Letzter Tag</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Letzte Woche</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Letzter Monat</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Letzten drei Monate</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Letztes Jahr</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <source>No results were found for searching:</source>
        <translation type="obsolete">Keine Ergebnisse. Suchbegriff(e):</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Suche alle Wörter</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Suche exakten Ausdruck</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Suche mit mindestens einem dieser Wörter</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Klasseneigenschaft</translation>
    </message>
    <message>
        <source>In</source>
        <translation>In</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Veröffentlicht</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Keine Ergebnisse wurden gefunden, als nach &apos;%1&apos; gesucht wurde</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Suche nach &quot;%1&quot; ergab %2 Ergebnisse</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <translation>Für mehr optionen die %1erweiterte Suche%2 probieren</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Die folgenden Wörter wurden von der Suche ausgeschlossen:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Tipp an Freund</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Die Nachricht wurde versandt.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Hier klicken um zur originalen Seite zurückzukehren.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Die Nachricht wurde nicht versandt.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>The Nachricht wurde aufgrund eines unbekannten Fehlers nicht versandt. Bitte benachrichten SIe den Administrator über diesen Fehler.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Bitte berichtigen Sie die folgenden Fehler:</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Ihr Name</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Ihre E-Mail Adresse</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Name des Empfängers</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>E-Mail adresse des Emfängers</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Thema</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Senden</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Diese Nachricht wurde an Sie gesand, weil &quot;%1 &lt;%2&gt;&quot; dachte Sie fänden deise Seite &quot;%3&quot; auf %4 interessant.</translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation>Dies ist der Link zu Seite:</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation>Kommentar von &quot;%1 &lt;%2&gt;&quot;:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating</source>
        <translation type="obsolete">Übersetzen</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="obsolete">Eingabe war nicht korrekt</translation>
    </message>
    <message>
        <source>input was stored successfully</source>
        <translation type="obsolete">Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Remove the following translations from</source>
        <translation type="obsolete">Entfernen der folgenden Übersetzungen von</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation type="obsolete">Lokalisierung:</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Sprache:</translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Keine Lokalisierungsinformationen verfügbar)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Translate into:</source>
        <translation type="obsolete">Übersetze nach:</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Hinzufügen</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Übersetzungen</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Übersetzen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="obsolete">Entfernen</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Edit Object</source>
        <translation type="obsolete">Objekt bearbeiten</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Örtlichkeit</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Übersetz nach</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Übersetze &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Entferne die folgenden Übersetzungen von &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Müll</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektion</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Aktuelle Version</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Müll ist leer</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for:</source>
        <translation type="obsolete">Versionen für:</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Version ist kein Entwurf</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="obsolete">Version</translation>
    </message>
    <message>
        <source>is not available for editing anymore, only drafts can be edited.</source>
        <translation type="obsolete">ist nicht mehr bearbeitbar, nur Entwürfe können bearbeitet werden.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Um diese Version zu bearbeiten erstellen Sie eine Kopie.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Diese Version gehört Ihnen nicht</translation>
    </message>
    <message>
        <source>was not created by you, only your own drafts can be edited.</source>
        <translation type="obsolete">wurde nicht von Ihnen erstellt. Sie können nur Ihre eigenen Entwürfe bearbeiten.</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Übersetzungen:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Ersteller:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Bearbeitet:</translation>
    </message>
    <message>
        <source>Object Edit</source>
        <translation type="obsolete">Objekt bearbeiten</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopieren</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Kopieren und bearbeiten</translation>
    </message>
    <message>
        <source>Versions for: %1</source>
        <translation>Versionen für: %1</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Version %1 ist nicht mehr verfügbar zum editieren, nur Entwürfe können geändert werden.</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Version %1 wurde nicht von Ihnen erstellt. Sie können nur Ihre eigenen Entwürfe bearbeiten.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation>Durchsuchen</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Select:</source>
        <translation type="obsolete">Auswählen:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Auswählen</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Ihre Entwürfe</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Version:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Sie haben keine Entwürfe</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation type="obsolete">Aktuelle Version:</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Verwandte Objekte</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Keine</translation>
    </message>
    <message>
        <source>Translation:</source>
        <translation type="obsolete">Übersetzung:</translation>
    </message>
    <message>
        <source>Placement:</source>
        <translation type="obsolete">Platzierung:</translation>
    </message>
    <message>
        <source>Site Design:</source>
        <translation type="obsolete">Site-Design:</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Veröffentlichen</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versionen</translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Um Objekte zu selektieren, wählen Sie den/die entsprechenden Radiobutton oder Checkbox(en) und klicken sie den &quot;Wähle&quot; Button.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Um ein Objekt auszuwählen, dass ein Kind eines der dargestellten Obejkte ist, klicken Sie den Objekt namen und Sie werden eine Liste der Kinder dieses Obejktes bekommen.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektion</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Aktuelle Version</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Übersetzung</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Anordnung</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Seitendesign</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Zugriff verweigert</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>Sie haben nicht die erforderliche Berechtigung diesen Bereich einzusehen.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Modul nicht gefunden</translation>
    </message>
    <message>
        <source>The requested module</source>
        <translation type="obsolete">Das gewählte Modul</translation>
    </message>
    <message>
        <source>could not be found.</source>
        <translation type="obsolete">konnte nicht gefunden werden.</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Sicht nicht gefunden</translation>
    </message>
    <message>
        <source>The requested view</source>
        <translation type="obsolete">Die gewählte Sicht</translation>
    </message>
    <message>
        <source>could not be found in module:</source>
        <translation type="obsolete">konnte nicht gefunden werden in Modul:</translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation>Nicht verfügbar</translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation>Das Objekt ist nicht verfügbar.</translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation>Anmelden für zutreffende Rechte.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Den Anmelde Button klicken für den login.</translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation>Das angeforderte Modul &apos;%1&apos; wurde nciht gefunden.</translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation>Die angeforderte Sicht &apos;%1&apos; wurde nicht gefunden im Modul: &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Content</source>
        <translation type="obsolete">Inhalte</translation>
    </message>
    <message>
        <source>List</source>
        <translation type="obsolete">Liste</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Sitemap</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation type="obsolete">Ihre Entwürfe</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation type="obsolete">Setup</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation type="obsolete">Klassen</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation type="obsolete">Sektionen</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation type="obsolete">Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="obsolete">Triggers</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation type="obsolete">Suchstatistiken</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation type="obsolete">Shop</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="obsolete">Bestellliste</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="obsolete">Mehrwertsteuertypen</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="obsolete">Ermäßigung</translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="obsolete">Benutzer</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="obsolete">Rollen</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation type="obsolete">Ihre Nachrichten</translation>
    </message>
    <message>
        <source>My Tasks</source>
        <translation type="obsolete">Ihre Tasks</translation>
    </message>
    <message>
        <source>New article</source>
        <translation type="obsolete">Neuer Artikel</translation>
    </message>
    <message>
        <source>New link</source>
        <translation type="obsolete">Neuer Link</translation>
    </message>
    <message>
        <source>New product</source>
        <translation type="obsolete">Neues Produkt</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Willkommen in der eZPublish-Verwaltung</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Um Sich einzuloggen bitte Login-Namen und Passwort angeben.</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Erweiterte Suche</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Passwort ändern</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login-Name</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Beenden (Logout)</translation>
    </message>
    <message>
        <source>About eZ publish</source>
        <translation type="obsolete">Über eZPublish</translation>
    </message>
    <message>
        <source>About eZ publish 3</source>
        <translation type="obsolete">Über eZPublish 3</translation>
    </message>
    <message>
        <source>Installation &amp; configuration</source>
        <translation type="obsolete">Installation &amp; Konfiguration</translation>
    </message>
    <message>
        <source>Install using installers</source>
        <translation type="obsolete">Installieren mit Installationsprogramm</translation>
    </message>
    <message>
        <source>Install manually</source>
        <translation type="obsolete">Manuell installieren</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation type="obsolete">Deinstallieren</translation>
    </message>
    <message>
        <source>SDK &amp; Technical references</source>
        <translation type="obsolete">SDK &amp; Technical references</translation>
    </message>
    <message>
        <source>eZ publish SDK</source>
        <translation type="obsolete">eZ publish SDK</translation>
    </message>
    <message>
        <source>Redirecting to:</source>
        <translation type="obsolete">Redirecting to:</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Redirect</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Restart</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Module load failed</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Undefined module: </translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Site:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation>%1 Startseite</translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation>Suche %1</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Druckversion</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Persönliches</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Müll</translation>
    </message>
    <message>
        <source>Redirecting to %1</source>
        <translation>Weiterleiten zu %1</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Weiter</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove</source>
        <translation type="obsolete">Sind Sie Sicher, dass Sie</translation>
    </message>
    <message>
        <source>from node</source>
        <translation type="obsolete">vom Node entfernen wollen</translation>
    </message>
    <message>
        <source>?</source>
        <translation type="obsolete">?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s</source>
        <translation type="obsolete">Wenn Sie diesen Eintrag entfernen entfernen Sie gleichzeitig auch seine</translation>
    </message>
    <message>
        <source>!</source>
        <translation type="obsolete">!</translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation>Entferne Verknüpfungen von Node</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) node(s)?</source>
        <translation type="obsolete">Sind Sie sicher, dass Sie diese(n) Node(s) entfernen möchten?</translation>
    </message>
    <message>
        <source>Removing</source>
        <translation type="obsolete">Enttfernen</translation>
    </message>
    <message>
        <source>will remove the node itself and it&apos;s</source>
        <translation type="obsolete">wird den Node selbst entfernen und seine</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Sind sie sicher, dass Sie %1 von Knoten %2 entfernen wollen?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation>Bei Entfernung dieser Zuweisung werden auch seine %1 entfernt!</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Notiz:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Die entfernten Koten können auch später zurückgeholt werden. Sie finden diese im Abfalleimer.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation>Sie sie sicher, dass Sie diese Knoten entfernen wollen? </translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2! %3</source>
        <translation>Entfernen von %1 wird den Koten selbst und seine %2! %3</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Die folgenden Positionen wurden von Ihrem Warenkorb entfernt, weil die Produkte geändert wurden</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>m.nam</source>
        <translation type="obsolete">m.nam</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete">Klasse:</translation>
    </message>
    <message>
        <source>Sorting:</source>
        <translation type="obsolete">Sortieren:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Entfernen:</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>SiteMap</translation>
    </message>
    <message>
        <source>Object:</source>
        <translation type="obsolete">Objekt:</translation>
    </message>
    <message>
        <source>Section ID:</source>
        <translation type="obsolete">Sektions-ID:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>You are not allowed to create child objects</source>
        <translation type="obsolete">Sie sind nicht berechtigt Tochter-Elemente zu erstellen</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Benutzergruppe</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Hier erstellen</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektion</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Notification registration form</source>
        <translation type="obsolete">Benachrichtigung Registrierungsformular</translation>
    </message>
    <message>
        <source>Send Method:</source>
        <translation type="obsolete">Versandmethode:</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="obsolete">E-Mail</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation type="obsolete">SMS</translation>
    </message>
    <message>
        <source>Internal message</source>
        <translation type="obsolete">Interne Nachricht</translation>
    </message>
    <message>
        <source>Send day:</source>
        <translation type="obsolete">Versanddatum:</translation>
    </message>
    <message>
        <source>Immediately</source>
        <translation type="obsolete">Sofort</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation type="obsolete">Montag</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation type="obsolete">Dienstag</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation type="obsolete">Mittwoch</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation type="obsolete">Donnerstag</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation type="obsolete">Freitag</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation type="obsolete">Sonnabend</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation type="obsolete">Sonntag</translation>
    </message>
    <message>
        <source>Send time:</source>
        <translation type="obsolete">Versandzeit:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="obsolete">Registrieren</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">Verwerfen</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Rule Type:</source>
        <translation type="obsolete">Regel-Typ:</translation>
    </message>
    <message>
        <source>Class Name:</source>
        <translation type="obsolete">Klassen-Name:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="obsolete">Pfad:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation type="obsolete">Schlüsselwort:</translation>
    </message>
    <message>
        <source>Additional constraint:</source>
        <translation type="obsolete">Zusätzlicher constraint:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Entfernen:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bearbeiten</translation>
    </message>
    <message>
        <source>New Rule</source>
        <translation type="obsolete">Neue Regel</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="obsolete">Entfernen</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="obsolete">Sende Nachricht</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/rules</name>
    <message>
        <source>Content Class Name:</source>
        <translation type="obsolete">Content-Klassenname:</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="obsolete">Alle</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="obsolete">Pfad:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation type="obsolete">Schlüsselwort:</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Erzeuge Richtlinien für</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Schritt 1</translation>
    </message>
    <message>
        <source>Give access to module:</source>
        <translation type="obsolete">Zugriff auf das Modul geben:</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Alle Module</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Alle erlauben</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Erlaube eingeschränkt</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Module:</source>
        <translation type="obsolete">Modul:</translation>
    </message>
    <message>
        <source>Access:</source>
        <translation type="obsolete">Zugriff:</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Beschränkt</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Zurück zu Schritt 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Es ist Ihnen nicht möglich den Zugriff freizugeben auf beschränkte Modulfunktionen des Moduls</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>da die Funktionenliste hierfür nicht definiert ist.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Schritt 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Spezifiziere Funktionen in Modul</translation>
    </message>
    <message>
        <source>Function:</source>
        <translation type="obsolete">Funktion:</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Zurück zu Schritt 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Schritt 3</translation>
    </message>
    <message>
        <source>Specify limitations in function</source>
        <translation>Spezifizieren Sie Einschränkungen für die Funktion</translation>
    </message>
    <message>
        <source>in module</source>
        <translation>in Modul</translation>
    </message>
    <message>
        <source>&apos;Any&apos; means no limitation by this parameter.</source>
        <translation>&apos;Alle&apos; bedeutet keine Einschränkungen durch diesen Parameter.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation>Rolle ändern</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Current policies:</source>
        <translation type="obsolete">Aktuelle Richtlinien:</translation>
    </message>
    <message>
        <source>Limitation list:</source>
        <translation type="obsolete">Liste der Beschränkungen:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Entfernen:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Anwenden</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">Verwerfen</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Rollen-Liste</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete">Verknüpfen:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Rollensicht</translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete">bearbeiten</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Rollen-Richtlinien</translation>
    </message>
    <message>
        <source>Limitation:</source>
        <translation type="obsolete">Beschränkungen:</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Benutzer und Gruppen mit dieser Rolle verknüpft</translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="obsolete">Benutzer:</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Verknüpfen</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Zugang zum Modul geben</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Module</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Zugang</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Funktion</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Aktuelle Pläne</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Limitierungen</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Änderungen verwerfen</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limitierung</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Benutzer</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Suchstatistiken</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Häufigste Suchphrasen</translation>
    </message>
    <message>
        <source>Phrase:</source>
        <translation type="obsolete">Phrase:</translation>
    </message>
    <message>
        <source>Number of phrases:</source>
        <translation type="obsolete">Anzahl der Phrasen:</translation>
    </message>
    <message>
        <source>Average result returned:</source>
        <translation type="obsolete">Durchschnittlich zurückgemeldete Ergebnisanzahl:</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Ausdruck</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Anzahl der Ausdrücke</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Durchschnittliches Ergebnis</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section</source>
        <translation>Sektion verknüpfen</translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation>Sektion mit Node verknüpfen</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Sektion bearbeiten</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Sektionen-Liste</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete">Verknüpfen:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Entfernen:</translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete">bearbeiten</translation>
    </message>
    <message>
        <source>assign</source>
        <translation type="obsolete">verknüpfen</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Sind Sie sicher, dass Sie deise Sektionen entfernen wollen?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Das entfernen deiser Sektionen kann Rechte, Seitendesign und andere Sachen des Systems zerstören. Machen SIe nichts so lang Sie nicht genau wissen, was Sie machen.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Navigationsteil</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Inhalt</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Shop</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Setup</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Persönliches</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>Über Navigationsteile</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>Die eZ publish Administrations Oberfläche is geteilt in Navigationsteile. Auf diese Weise kann man verschiedene Bereiche der Seiten Administration gruppieren. Selectieren Sie den Navigationsteil, der aktiv seinen sollte, wenn diese Sektion aufgerufen wird.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Verknüpfen</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>site registration</source>
        <translation>Site registrieren</translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation>Site Informationen:</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation>PHP-Info:</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation>Betriebssystem-Info:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation>Datenbank-Info:</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Treiber</translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <source>Supported</source>
        <translation>Unterstützt</translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation>Nicht unterstützt</translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation>Demo data:</translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation>Demo -Daten wurden installiert.</translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation>Demo-Daten wurden nicht installiert.</translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation>E-Mail-Info:</translation>
    </message>
    <message>
        <source>Transport</source>
        <translation>Transport</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation>Bild-Umwandlung:</translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation>ImageMagick wurde gefunden und wird verwendet.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Pfad</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Ausführbare Datei</translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation>ImageGD-Erweiterung wurde gefunden und wird verwendet.</translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation>Regional-Informationen:</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Einsprachig</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Mehrsprachig</translation>
    </message>
    <message>
        <source>Primary</source>
        <translation>Primär</translation>
    </message>
    <message>
        <source>Additional</source>
        <translation>Zusätzlich</translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation>Kritische Tests:</translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Misserfolg</translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation>Weitere Tests:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Kommentare:</translation>
    </message>
    <message>
        <source>setup</source>
        <translation>Setup</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Sollten Sie Probleme bei der Verbindung mit Ihrer Datenbank haben sollten Sie hier nachschauen</translation>
    </message>
    <message>
        <source>at</source>
        <translation>bei</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Einführung</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL ist ein DatenbankManagementSystem, welches von MySQL AB entwickelt wurde.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>MySQL ist eine der am weitesten verwendeten OpenSource-Datenbanken und häufig in PHP voreingestellt.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>Auf der Homepage:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>More information can be found on</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Details</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Installation</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>By using the</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>More information on the MySQL extension can be found at</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>In order to enable PostgreSQL support,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>is required when you compile PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>More information on the PostgreSQL extension can be found at</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the</source>
        <translation type="obsolete">The database is ready for initialization, click the</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="obsolete">Create Database</translation>
    </message>
    <message>
        <source>button when ready.</source>
        <translation type="obsolete">button when ready.</translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation>First time users are adviced to install the demo data.</translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation>Install demo data?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>Cannot install demo data, the zlib extension is missing from your PHP installation.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>does not support installing demo data at this point.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Demo data failure</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Could not unpack the demo data.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>You should try to install without demo data.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Initialization failed</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>The database could not be properly initialized.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Your database already contains data.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>The setup can continue with the initialization but may damage the present data.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>What do you want the setup to do?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Continue but leave the data as it is.</translation>
    </message>
    <message>
        <source>Continue and remove the data.</source>
        <translation type="obsolete">Continue and remove the data.</translation>
    </message>
    <message>
        <source>Continue and skip database initialization.</source>
        <translation type="obsolete">Continue and skip database initialization.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Let me choose a new database.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note:</translation>
    </message>
    <message>
        <source>It can take some time creating the database so please be patient and wait until the new page is finished.</source>
        <translation type="obsolete">It can take some time creating the database so please be patient and wait until the new page is finished.</translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Language Options</translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation>to continue the setup.</translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation>Your system has support for one database only, it is</translation>
    </message>
    <message>
        <source>, click</source>
        <translation>, click</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Type:</translation>
    </message>
    <message>
        <source>Driver:</source>
        <translation type="obsolete">Driver:</translation>
    </message>
    <message>
        <source>Unicode support:</source>
        <translation type="obsolete">Unicode support:</translation>
    </message>
    <message>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>yes</translation>
    </message>
    <message>
        <source>The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</source>
        <translation type="obsolete">The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Configure</translation>
    </message>
    <message>
        <source>button to start the configuration process.</source>
        <translation type="obsolete">button to start the configuration process.</translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation>No database connection</translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation>Could not connect to database.</translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation>The database would not accept the connection , please review your settings and try again.</translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation>Connect To Database</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>button.</translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation>If you have an already existing eZ publish database enter the information and the setup will use that as database.</translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation>Empty password</translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation>You must supply a password for the database.</translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation>Password does not match</translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation>The password and confirmation password must match.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Unknown error</translation>
    </message>
    <message>
        <source>Servername:</source>
        <translation type="obsolete">Servername:</translation>
    </message>
    <message>
        <source>Databasename:</source>
        <translation type="obsolete">Databasename:</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation type="obsolete">Username:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete">Password:</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation type="obsolete">Confirm password:</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>No finetuning is required on your system, you can continue by clicking the</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>After you have fixed the problems click the</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Rerun System Check</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Check Again</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Issues</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Failed writing</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>The setup could not write to the file.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>The setup could not get write access to the</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>directory. This is required to disable the initialization. Following the instructions found in</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>to enable write access and click the</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Try Again</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Change the second line from</translation>
    </message>
    <message>
        <source>to</source>
        <translation>to</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>The setup is now disabled, click</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>to get back to the site.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>You can choose from either</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>sendmail</translation>
    </message>
    <message>
        <source>which must available on the server or</source>
        <translation>which must available on the server or</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation>Configuration of sendmail is done on the server, consult your webhost.</translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</translation>
    </message>
    <message>
        <source>Server name</source>
        <translation>Server name</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>User name</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation>Site Details</translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation>Email sending failed</translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation>Failed sending registration email using</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Congratulations, eZ publish should now run on your system.</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to the</source>
        <translation type="obsolete">If you need help with eZ publish, you can go to the</translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>eZ publish website</translation>
    </message>
    <message>
        <source>If you find a bug (error), please go to</source>
        <translation>If you find a bug (error), please go to</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>eZ publish bug reports</translation>
    </message>
    <message>
        <source>and report it.</source>
        <translation>and report it.</translation>
    </message>
    <message>
        <source>With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>With your help we can fix the errors eZ publish might have and implement new features.</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file</source>
        <translation>If you ever want to restart this setup, edit the file</translation>
    </message>
    <message>
        <source>and look for a line that says:</source>
        <translation>and look for a line that says:</translation>
    </message>
    <message>
        <source>Click on the URL to access your new</source>
        <translation>Click on the URL to access your new</translation>
    </message>
    <message>
        <source>or click the</source>
        <translation>or click the</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Done</translation>
    </message>
    <message>
        <source>button. Enjoy one of the most successful web content management systems!</source>
        <translation>button. Enjoy one of the most successful web content management systems!</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>It&apos;s time to select the language this site should support.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Select your language and click the</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Summary</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>button, or the</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Language Details</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>button to select language variations.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Once you&apos;re done click the</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>The languages you choose will help determine the charset to use on the site.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Language name</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selection</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Default</translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation>The following data will be sent to eZ systems:</translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation>Details of your system, like OS type etc.</translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation>The test results for your system</translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation>The database type you are using</translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation>The name of your site</translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation>The url of your site</translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation>The languages you chose</translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation>If you wish you can also add some comments which will be included in the registration.</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comments</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Send Registration</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Skip Registration</translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</source>
        <translation>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</translation>
    </message>
    <message>
        <source>Title of your site:</source>
        <translation type="obsolete">Title of your site:</translation>
    </message>
    <message>
        <source>URL to your site:</source>
        <translation type="obsolete">URL to your site:</translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation>Register Site</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>What kind of language support should this site have. The type of support determines the language selection and charset.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Monolingual (one language)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Multilingual (multiple languages with one charset)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Multilingual (Unicode, no limit)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Regional Options</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Setup Database</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>However if you want to change your settings click the</translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Start Over</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation>button which will restart the collecting of information (Existing settings are kept).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Database settings</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Database</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Unicode support</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Language settings</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Language type</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Monolingual</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Multilingual</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Languages</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>No problems was found with your system, you can continue by clicking the</translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation>However if you wish to finetune your system you should click the</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Finetune System</translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation>The system check found some issues that needs to be resolve before the setup can continue.</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Please have a look through the results below for more information on what the problems are.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>Each problem will give you instructions on how to fix the problem.</translation>
    </message>
    <message>
        <source>button to re-run the system checking.</source>
        <translation type="obsolete">button to re-run the system checking.</translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish</source>
        <translation type="obsolete">Welcome to the setup program for eZ publish</translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation>Click the button below to proceed to the next step which will start the system check.</translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation>However if you wish to setup the site manually press the</translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation>Disable Setup</translation>
    </message>
    <message>
        <source>System Check</source>
        <translation>System Check</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to loose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>Dieser Setup wird keinen upgrade von älteren eZ publish versionen (wie zum Beispiel 2.2.7) durchführen, wenn Sie die Daten so belassen wie sie sind. Dieser Setup ist nur für Personen, die existierende Daten haben, die Sie nicht verlieren wollen. Wenn Sie existierende eZ publish 3.0 Daten ( wie zum Beispiel von einem RC Release ) haben, sollten sie die DB inizializierung übersprigen. Sie werden diese manuelle upgraden müssen.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Servername</source>
        <translation>Servername</translation>
    </message>
    <message>
        <source>Socket</source>
        <translation>Socket</translation>
    </message>
    <message>
        <source>Databasename</source>
        <translation>Datenbankname</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Bestätige Passwort</translation>
    </message>
    <message>
        <source>Title of your site</source>
        <translation>Titel ihrer Seite</translation>
    </message>
    <message>
        <source>URL to your site</source>
        <translation>Url zu ihrer Seite</translation>
    </message>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>Die Datenbank ist bereit zur Initialisierung, klicken Sie den %1 Button, wenn Sie bereit sind.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Fortfahren</translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Fortfahren, aber zuerst die Daten entfernen. </translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Behalte die Daten und überspringe die Datenbankinitialisierung.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>Es kann einige Zeit dauern die Datenbank zu initialisieren. Bitte haben Sie Gedult, bis die neue Seite aufgerufen ist.</translation>
    </message>
    <message>
        <source>The database was succesfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>Die Datenbank wurde erfolgreich initialisiert.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Klicken Sie den %1 Button um den Konfigurationsprocess zu starten.</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to</source>
        <translation>Wenn Sie Hilfe mit eZ publish brauchen, gehen Sie zu   </translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>Der Standard Benutzername für den Administrator ist %1 und das Standard Passwort ist %2.</translation>
    </message>
    <message>
        <source>Sending out the email might take a couple of seconds so please wait until the next page loads. Clicking the button again will only send out duplicate emails.</source>
        <translation>Das Senden dieser E-Mail mag einige Sekunden dauern, also waren Sie bitte bis die nächste Seite geladen ist.</translation>
    </message>
    <message>
        <source>You&apos;re site is running in virtualhost mode and is considered secure. You may safely continue.</source>
        <translation>Ihre Seite läuft im Virtualhost modus und ist sicher. Sie können nun beruhigt fortfahren.</translation>
    </message>
    <message>
        <source>Your site is running in non-virtualhost mode which is considered an unsecure mode. It&apos;s recommended to run eZ publish in virtualhost mode.
If you do not have the possiblity to use virtualhost mode you should follow the instructions below on howto install a .htaccess file, the file tells the webserver to only give access to certain files.</source>
        <translation>Ihre Seite läuft nicht im Virtualhost modus und ist nicht sicher. Es wird geraten Sie Seite im Virtualhost modus auszuführen, falls dies möglich ist.</translation>
    </message>
    <message>
        <source>Securing Site</source>
        <translation>Sichere Seite</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the checkboxes.</source>
        <translation>Nachdem Sie die Probleme bereinigt haben klicken Sie den %1 Button und die Überprüfung erneut auszuführen. Sie können auch spezifische Tests ignorieren durch das Anklicken der Checkboxen. </translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish %1.</source>
        <translation>Willkommen beim Setup-Programm von eZ publish %1.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Missing database handlers</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Your PHP does not have support for all databases that eZ publish support.</translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>Allthough eZ publish will work without it, it might be that you want to have support for this database.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Also some databases has more advanced features, such as charset, than others.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Missing database handler</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Insufficient directory permissions</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>It&apos;s recommended that you fix this by running the commands below.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Shell commands</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Missing image conversion support</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation>Missing imagegd extension</translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>template operator will not be available.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Missing ImageMagick program</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>If you known where the program is installed (the executable is called</translation>
    </message>
    <message>
        <source>or</source>
        <translation>or</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>colon</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>semicolon</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Installation</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagick may be downloaded from</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Missing MBString extension</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation>The complete list of charsets mbstring supports are:</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>Installation of the mbstring extension is done by compiling PHP with the</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>option.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>More information on enabling the extension can be found at</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>PHP option</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>is enabled</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your</source>
        <translation type="obsolete">It&apos;s recommended that the option is turned off. To turn it off edit your</translation>
    </message>
    <message>
        <source>configuration and set</source>
        <translation type="obsolete">configuration and set</translation>
    </message>
    <message>
        <source>and</source>
        <translation type="obsolete">and</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="obsolete">to</translation>
    </message>
    <message>
        <source>More information on the subject can be found at</source>
        <translation type="obsolete">More information on the subject can be found at</translation>
    </message>
    <message>
        <source>Configuration example:</source>
        <translation type="obsolete">Configuration example:</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Insufficient PHP version</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Your PHP version, which is </translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>, does not meet the minimum requirements of</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>A newer version of PHP can be download at</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>You must upgrade to at least version </translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation>, but an even newer version, such as 4.2.3, is highly recommended.</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish cannot write to the</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>directory, without this the setup cannot disable itself.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>Missing zlib extension</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>More information on that subject is available at</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Datei upload ist deaktiviert</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>File upload ist nicht aktiviert, das heißt, dass es unmöglich ist für ezZ publish file uploads durchzuführen. Alle anderen Teile von eZ publish werden weiterhin richtig arbeiten, aber es wird empfohlen Datei uploads zu aktivieren.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Das Aktivieren des Datei-Uploads wird erreicht durch die Einstellung %1 ind er php.ini. Lesen Sie bitte auch die entsprechenden Teile im PHP manual </translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Mehr Informationen zum Aktivieren dieser Erweiterung können durch lesen von %1 und %2 gefunden werden</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 and %3 to %4.</source>
        <translation>Es wird empfohlen das diese option ausgeschlatet ist. Um diese aus zu schalten änderen Sie ihre %1 Konfiguration und setzen Sie %2 and %3 zu %4.</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Mehr Informationen zu diesen Thema können gefunden werden bei %1. </translation>
    </message>
    <message>
        <source>php.ini example:</source>
        <translation>php.ini Beispiel:</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following:</source>
        <translation>Alternative können Sie eine Datei mit dem Namen %1 in Ihrem eZ publish root ordner erstellen und das folgende hinzufügen:</translation>
    </message>
    <message>
        <source>.htaccess example:</source>
        <translation>.htaccess Beispiel:</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>PH Option %1 ist aktiviert</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish wird mit dieser funktionieren. Wie auch immer wird dies zu kleinen Performance-Einbusen führen, da alle Eingabevariablen global verfügbar gemacht werden.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>Es wird empfohlen diese Option auszuschalten. Um diese auszuschalten beärbeiten Sie ihre %1 Konfiguration und setzen Sie %2 zu %3. </translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>PHP safe mode ist aktiviert</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are:</source>
        <translation>eZ publish mag mit Safe mode on arbeiten, es mag dennoch einige Funktionalitäten die nicht verfügbar sind. Einige dieser Sachen die auftreten können sind:</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Einkaufskorb</translation>
    </message>
    <message>
        <source>Product:</source>
        <translation type="obsolete">Produkt:</translation>
    </message>
    <message>
        <source>Count:</source>
        <translation type="obsolete">Zähler:</translation>
    </message>
    <message>
        <source>VAT:</source>
        <translation type="obsolete">Mehrwertsteuer:</translation>
    </message>
    <message>
        <source>Price ex. VAT:</source>
        <translation type="obsolete">Preis ohne Mwst.:</translation>
    </message>
    <message>
        <source>Price inc. VAT:</source>
        <translation type="obsolete">Preis mit Mwst.:</translation>
    </message>
    <message>
        <source>Discount:</source>
        <translation type="obsolete">Preisnachlass:</translation>
    </message>
    <message>
        <source>Total Price ex. VAT:</source>
        <translation type="obsolete">Gesamtpreis ohne Mwst.:</translation>
    </message>
    <message>
        <source>Total Price inc. VAT:</source>
        <translation type="obsolete">Preis inkl. Mwst.:</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation>Zwischensumme ohne Mwst.:</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Zwischensumme inkl. Mwst.:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Weiter einkaufen</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Zur Kasse</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Sie haben keine Produkte im Einkaufskorb</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Bestellung bestätigen</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Produkte</translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation>Zusammenfassung der Bestellung:</translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation>Zwischensumme der Teile:</translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation>Gesamtbestellung:</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Defined discount groups</source>
        <translation type="obsolete">Definierte Preisnachlassgruppen</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Editing discount group</source>
        <translation type="obsolete">Preisnachlassgruppe bearbeiten</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Anwenden</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Gruppen-Übersicht</translation>
    </message>
    <message>
        <source>Group Name:</source>
        <translation type="obsolete">Gruppenname:</translation>
    </message>
    <message>
        <source>Defined rules:</source>
        <translation type="obsolete">Definierte Richtlinien:</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Prozent</translation>
    </message>
    <message>
        <source>Apply to:</source>
        <translation type="obsolete">Anwenden auf:</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Richtlinie hinzufügen</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Richtlinie entfernen</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Kunden</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Kunde hinzufügen</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Kunden entfernen</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Richtlinie bearbeiten</translation>
    </message>
    <message>
        <source>Discount percent:</source>
        <translation type="obsolete">Prozent Preisnachlass:</translation>
    </message>
    <message>
        <source>Choose which classes or sections applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Wählen Sie welche Klassen oder Sektionen mit dieser Unter-Richtlinien verknüpft werden sollen. &apos;Alle&apos; meint dass die Richtlinien mit allen verknüpft wird.</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete">Klasse:</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Section:</source>
        <translation type="obsolete">Sektion:</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Bestellliste</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Kunde</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Gesamtsumme ohne Mehrwertsteuer</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Gesamtsumme inkl. Mehrwertsteuer</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Bestellung</translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation>Kunde:</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Mehrwertsteuertypen</translation>
    </message>
    <message>
        <source>Percentage:</source>
        <translation type="obsolete">Prozentzahl:</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Wunschzettel</translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation>Entferne ausgewählte(s) Produkt(e)</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Wunschzettel leeren</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produkt</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Zählen</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>MwSt</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Preis exklusive MwSt</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Preis inkl. MwSt</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Ermäßigung</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Gesamt Preis exklusive MwSt</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Gesamt Preis inkl. MwSt</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Ermäßigungsgruppen</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Ändere Ermäßigunggruppe - %1</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Gruppenname</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Definierte Rollen</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Anwenden auf</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Ermäßigungs Prozentsatz</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sektion</translation>
    </message>
    <message>
        <source>Order:</source>
        <translation>Bestellung:</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Zwischensumme der Positionen</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Die Bestellliste ist leer</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Komplette Bestellsumme</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Registriere Kontoinformationen</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Eingabe war nicht richtg, füllen Sie alle Felder aus</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Prozentsatz</translation>
    </message>
</context>
<context>
    <name>design/standard/task</name>
    <message>
        <source>Creating new task</source>
        <translation type="obsolete">Neuen Task erstellen</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="obsolete">Task</translation>
    </message>
    <message>
        <source>Assignment</source>
        <translation type="obsolete">Verknüpfung</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation type="obsolete">Datum:</translation>
    </message>
    <message>
        <source>From:</source>
        <translation type="obsolete">Von:</translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="obsolete">An:</translation>
    </message>
    <message>
        <source>Please select receiver</source>
        <translation type="obsolete">Bitte wählen Sie einen Empfänger aus</translation>
    </message>
    <message>
        <source>Parent type:</source>
        <translation type="obsolete">Eltern-Typ:</translation>
    </message>
    <message>
        <source>Parent ID:</source>
        <translation type="obsolete">Eltern-ID:</translation>
    </message>
    <message>
        <source>Access Type:</source>
        <translation type="obsolete">Zugangs-Typ:</translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="obsolete">Lesen</translation>
    </message>
    <message>
        <source>Read/Write</source>
        <translation type="obsolete">Lesen/Schreiben</translation>
    </message>
    <message>
        <source>Object Type:</source>
        <translation type="obsolete">Objekt-Typ:</translation>
    </message>
    <message>
        <source>Content Object</source>
        <translation type="obsolete">Content-Objekt</translation>
    </message>
    <message>
        <source>Content Class</source>
        <translation type="obsolete">Content-Klasse</translation>
    </message>
    <message>
        <source>Work Flow</source>
        <translation type="obsolete">WorkFlow</translation>
    </message>
    <message>
        <source>Role</source>
        <translation type="obsolete">Rolle</translation>
    </message>
    <message>
        <source>Assignment for object:</source>
        <translation type="obsolete">Verknüpfung für Objekt:</translation>
    </message>
    <message>
        <source>Choose Object</source>
        <translation type="obsolete">Objekt wählen</translation>
    </message>
    <message>
        <source>Convert To Assignment</source>
        <translation type="obsolete">Zu Verknüpfung umwandeln</translation>
    </message>
    <message>
        <source>Convert To Task</source>
        <translation type="obsolete">Zu Task umwandeln</translation>
    </message>
    <message>
        <source>Change Receiver</source>
        <translation type="obsolete">Empfänger bearbeiten</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="obsolete">Aktivieren</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">Verwerfen</translation>
    </message>
    <message>
        <source>Edit task message</source>
        <translation type="obsolete">Bearbeite Task-Nachricht</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="obsolete">Eingabe konnte nicht validiert werden</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="obsolete">Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="obsolete">Vorschau</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Anwenden</translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="obsolete">Senden</translation>
    </message>
    <message>
        <source>Object list</source>
        <translation type="obsolete">Objekt-Liste</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation type="obsolete">Finde Objekt</translation>
    </message>
    <message>
        <source>Task message</source>
        <translation type="obsolete">Task-Nachricht</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bearbeiten</translation>
    </message>
    <message>
        <source>Task view</source>
        <translation type="obsolete">Task-Ansicht</translation>
    </message>
    <message>
        <source>Task list</source>
        <translation type="obsolete">Task-Liste</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="obsolete">Status:</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="obsolete">Nachricht</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="obsolete">Nachrichten</translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation type="obsolete">Eingehende</translation>
    </message>
    <message>
        <source>Title:</source>
        <translation type="obsolete">Titel:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation type="obsolete">Ersteller:</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation type="obsolete">Erstellt am:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Verändert am:</translation>
    </message>
    <message>
        <source>Outgoing</source>
        <translation type="obsolete">Ausgehende</translation>
    </message>
    <message>
        <source>Sub tasks</source>
        <translation type="obsolete">Unter-Task</translation>
    </message>
    <message>
        <source>Receiver:</source>
        <translation type="obsolete">Empfänger:</translation>
    </message>
    <message>
        <source>New Task</source>
        <translation type="obsolete">Neuer Task</translation>
    </message>
    <message>
        <source>New Assignment</source>
        <translation type="obsolete">Neue Verknüpfung</translation>
    </message>
    <message>
        <source>New Message</source>
        <translation type="obsolete">Neue Nachricht</translation>
    </message>
    <message>
        <source>Close Task</source>
        <translation type="obsolete">Task schließen</translation>
    </message>
    <message>
        <source>Cancel Task</source>
        <translation type="obsolete">Task abbrechen</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Triggers list</source>
        <translation type="obsolete">Trigger-Liste</translation>
    </message>
    <message>
        <source>Triggers editing</source>
        <translation type="obsolete">Trigger bearbeiten</translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation>Modulname</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Funktionsname</translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation>Verbindungstyp</translation>
    </message>
    <message>
        <source>Workflow ID</source>
        <translation type="obsolete">Workflow ID</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Kein Workflow</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Trigger list</source>
        <translation>Trigger-Liste</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Workflow</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Gültig</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Ungültig</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>Die URL ist nicht mehr gültig.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>Das heißt, dass die URL nicht mehr länger verfügbar ist oder verschoben worden ist.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>Die URL zeigt auf %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Zuletzt geändert am %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>Die URL hat kein Änderungsdatum</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Zuletzt überprüft am %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>Die URL wurde noch nicht überprüft </translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Activate account</source>
        <translation>Konto (Account) aktivieren</translation>
    </message>
    <message>
        <source>Login ID:</source>
        <translation type="obsolete">Login ID:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete">Passwort:</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="obsolete">Aktivieren</translation>
    </message>
    <message>
        <source>Registed user profile</source>
        <translation>Registrierte Nutzerprofile</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation type="obsolete">Login:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation type="obsolete">E-Mail:</translation>
    </message>
    <message>
        <source>Update Profile</source>
        <translation>Profil aktualisieren</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Passwort ändern</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation>Einstellungen ändern</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Konnte Sie nicht anmelden</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Gültiger Nutzername und Passwort sind erforderlich.</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation>Anmelden</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Benutzerpasswort ändern</translation>
    </message>
    <message>
        <source>Old Password:</source>
        <translation type="obsolete">Altes Passwort:</translation>
    </message>
    <message>
        <source>New Password:</source>
        <translation type="obsolete">Neues Passwort:</translation>
    </message>
    <message>
        <source>Retype Password:</source>
        <translation type="obsolete">Passwort wiederholen:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Benutzer registrieren</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Eingabe konnte nicht validiert werden</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Eingabe wurde erfolgreich gespeichert</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrieren</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Benutzereinstellungen</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Max. Logins</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Is aktiviert</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Registrierter Nutzer</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Ihr Benutzerkonto wurde erfolgreich erstellt.</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation type="obsolete">Generieren</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Zugang nicht erlaubt</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Zugang zu %1 ist nicht erlaubt.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <source>Old Password</source>
        <translation>Altes Passwort</translation>
    </message>
    <message>
        <source>New Password</source>
        <translation>Neues Passwort</translation>
    </message>
    <message>
        <source>Retype Password</source>
        <translation>Erneute Eingabe des Passwortes</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>A mail has been send to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Eine E-Mail wurde an die folgende Adresse versand: %1. Diese E-Mail enthält einen Link, der aufgerufen werden muss, damit wir sichergehen können, dass der richtige Benutzer das neue Password bekommt.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Es gibt keinen registierten Benutzer mit dieser E-Mail Adresse.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to:</source>
        <translation>Das Password wurde erfolgreich generiert und versand an:</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Haben Sie ihr Passwort vergessen?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Wenn Sie ihr Passwort vergessen haben können wir Ihnen ein neues generieren. Alles was Sie machen müssen ist ihre E-Mail Adresse einzugeben und wir werden ein neues Passwort für Sie generieren.</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Generiere neues Passwort</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation>%1 neues Passwort</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Ihre account Informationen</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation>Hier klicken, um ein neues Passwort zu erhalten:</translation>
    </message>
    <message>
        <source>New password:</source>
        <translation>Neues Passwort:</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>Confirm user registration at %1</source>
        <translation>Bestätige Benutzerregistration bei %1</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation type="obsolete">%1 neues Passwort</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation type="obsolete">Hier klicken, um ein neues Passwort zu erhalten:</translation>
    </message>
    <message>
        <source>New user registered at %1</source>
        <translation>Neuer Benutzer registiert bei %1</translation>
    </message>
    <message>
        <source>%1 registration info</source>
        <translation>%1 Registrationsinformationen</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Editing workflow</source>
        <translation>Workflow bearbeiten</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Workflow gespeichert</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Daten benötigen Anpassung</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Gruppen</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Ereignisse</translation>
    </message>
    <message>
        <source>Pos:</source>
        <translation type="obsolete">Pos:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Beschreibung:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation>Workflow-Gruppe bearbeiten</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="obsolete">Erstellt von</translation>
    </message>
    <message>
        <source>on</source>
        <translation>am</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Bearbeitet von</translation>
    </message>
    <message>
        <source>Defined workflow groups</source>
        <translation type="obsolete">Definierte Workflow-Gruppen</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>WorkFlow-Prozess</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>WorkFlow-Prozess wurde erstellt am</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>und verändert am</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Workflow</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Workflow benutzen</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>zur Verarbeitung.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Dieser Workflow wird verwendet für Benutzer</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Content-Objekt</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>Workflow wurde erstellt für Content</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>verwendet Version</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>in Eltern</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Workflow-Ereignis</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>Workflow wurde bisher noch nicht gestartet, Anzahl der Haupt-Ereignisse im Workflow ist</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>Aktuelle Ereignis-Position ist</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>Ereignis, das gestartet wird ist</translation>
    </message>
    <message>
        <source>event</source>
        <translation>Ereignis</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>Status des letzten gestarteten Ereignisses</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Worlflow-Ereignisliste</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Nächster Schritt</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Workflow-Ereignis-Log</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Defined workflows for</source>
        <translation type="obsolete">Definierte Workflows für</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Bearbeiter:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Bearbeitet:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Bearbeiten:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Entfernen:</translation>
    </message>
    <message>
        <source>Temporary workflows for</source>
        <translation type="obsolete">Temporäre Workflows für</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Pos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Workflowgruppen</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Neue Gruppe</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <translation>Workflow in %1</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Veränderer</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Verändert</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Neuer Workflow</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor:</source>
        <translation type="obsolete">Editor:</translation>
    </message>
    <message>
        <source>Sections:</source>
        <translation type="obsolete">Sektionen:</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Users without approval:</source>
        <translation type="obsolete">Benutzer ohne Bestätigung:</translation>
    </message>
    <message>
        <source>Checkout text:</source>
        <translation type="obsolete">Text beim Verlassen:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="obsolete">Nachricht:</translation>
    </message>
    <message>
        <source>Section IDs:</source>
        <translation type="obsolete">Sektionen-IDs:</translation>
    </message>
    <message>
        <source>Users without workflow IDs:</source>
        <translation type="obsolete">Benutzer ohne Workflow-IDs:</translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation>Unveröffentlichtes Objekt</translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation>Objekt veröffentlichen</translation>
    </message>
    <message>
        <source>Days:</source>
        <translation type="obsolete">Tage:</translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="obsolete">Stunden:</translation>
    </message>
    <message>
        <source>Minutes:</source>
        <translation type="obsolete">Minuten:</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Bearbeiter</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sektionen</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Benutzer ohne Bestätigung</translation>
    </message>
    <message>
        <source>Checkout text</source>
        <translation>Abmeldetext</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Section IDs</source>
        <translation>Sektions IDs</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Benutzer ohne Workflow IDs</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>Tage</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>Stunden</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>Minuten</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>Neuer Eintrag</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Entferne Ausgewähltes</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation>Lade Eigenschaften</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasse</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>Klasseneigenschaft:</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/result</name>
    <message>
        <source>Checkout</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <source>Hello</source>
        <translation>Hallo</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation>Verpacken</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Klassenliste von Gruppe</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Klassengruppenliste</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Entferne Klasse</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Klasse bearbeiten</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Klassen</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Klassenliste</translation>
    </message>
    <message>
        <source> object</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>Objekte</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Entferne Klassen</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(keine Klassen)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Entferne Klassen Gruppen</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Bestätigung</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Observer</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Besitzer</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Bestätiger</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Author</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Posteingang</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Noch kein Status</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Workflow läuft</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Workflow abgeschlossen</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Workflow schlug bei einem Vorgang fehl</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Workflowvorgang verlegt zum cron job</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>Workflow wurde abgebrochen</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Workflow wurde zurückgesetzt zur Wiederverwendung</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Angenommenes Ereignis</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Zurückgewiesenes Ereignis</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Ereignis verlegt zum cron job</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Ereignis verlegt zum cron job, Event wird erneut durchlaufen</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>Ereignis startet ein Unter-Ereignis</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Abbruch des gesamten Workflows</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatype/ezbinaryfiletype</name>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Datei upload ist nicht aktiviert, keine Bearbeitung der Datei kann durchgeführt werden.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is requied.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete">Mindestens die Angabe eines Autoren ist erforlderlich.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation>Autorenname sollte eingetragen werden.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation>E-Mail-Adresse ist nicht gültig.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation>Eine gültige Datei ist notwendig.</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation>Ein gültiges E-Mail-Konto ist erforderlich.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation>E-Mail-Adresse ist nicht gültig.</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation>Mindestens ein Feld sollte ausgewählt werden.</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation>Eingabe ist kein Fließkommawert.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation>Eingabe muss größer als %1 sein</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation>Eingabe muss kleiner sein als %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation>Eingabe ist nicht im vorgegebenen Intervall von %1 - %2</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation>Ein gültiges Bildformat ist notwendig.</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation>Eingabe ist kein Integerwert.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Eingabe muss größer sein als %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Eingabe muss kleiner sein als %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation>Eingabe ist nicht im vorgegebenen Intervall von %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation>Die ISBN-Nummer ist nicht korrekt. Bitte überprüfen Sie Ihre Eingabe</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation>Das ISBN-Format ist nicht gültig.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation>Eine gültige Datei ist erforderlich.</translation>
    </message>
    <message>
        <source>At least one option is requied.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete">Mindestens eine Eingabe ist erforderlich.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation>Eigenschaftenwert muss angegeben werden.</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Textzeile ist leer, Inhalt ist notwendig.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation>Textzeile ist zu lang, maximal erlaubt ist eine Länge von %1.</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Text-Feld ist leer, Inhalt ist notwendig.</translation>
    </message>
    <message>
        <source>An user account must be filled up</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Ein Benutzerkonto muss eingetragen werden</translation>
    </message>
    <message>
        <source>Login name exist, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Login-Name besteht bereits, bitte wählen Sie einen anderen Namen aus.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">E-Mail-Adresse ist nicht gültig.</translation>
    </message>
    <message>
        <source>Please confirm your password.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Bitte bestätigen Sie Ihr Passwort.</translation>
    </message>
    <message>
        <source>The minimum length of password should be 3.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Die Minimallänge des Passwortes sollte drei Zeichen sein.</translation>
    </message>
    <message>
        <source>Object </source>
        <translation>Objekt</translation>
    </message>
    <message>
        <source>Link </source>
        <translation>Link</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <comment>eZAuthorType</comment>
        <translation>Mindestens ein Author wird benötigt.</translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation>Fehlende Datumseingabe.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Fehlende Zeiteingabe.</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <comment>eZOptionType</comment>
        <translation>Mindestens eine Option wird benötigt.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation>Zusetzlicher Preis für Optionwert wir benötigt.</translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Fehlende Zeiteingabe.</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation>Der Login muss angegeben werden</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation>Der Loginname existiert bereits, bitte wählen Sie einen anderen.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation>Die E-Mailadresse ist nicht richtig.</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <comment>eZUserType</comment>
        <translation>Ein Benutzer mit dieser E-Mail existiert bereits.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>Das Bestätigungspasswort stimme nicht überein.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation>Das Passwort muss mindestens 3 Zeichenhaben.</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Kollaboration angepasste Aktion</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Kollaboration</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Fortgeschritten</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Keine Hauptknoten selectiert, bitte wähle eine aus.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Inhalt</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Ihre Entwürfe</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Entferne bearbeitete Version</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Entferne Object</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Tipp from %1: %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Die E-Mailadresse des Senders ist nicht gültig</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Die E-Mailadresse des Empfängers ist nicht gültig</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Tipp an einen Freund</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Übersetzen</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Übersetzung</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Übersetzungen des Inhalts</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Abfalleimer</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versionen</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Kind</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>Kinder</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Und außerdem werden diese Knoten entfernt:</translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Kind</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>Kinder</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation>Erschaffe Regel - Schritt 2 - Spezifiziere Funktion</translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation>Erschaffe Regel - Schritt 3 - Spezifiziere Funktion</translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation>Erschaffe Regel - Schritt 1 - Spezifiziere Funktion</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Rollen-Liste</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Suchstatistiken</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Ändere Sektion</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sektionen</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Einkaufskorb</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Kasse</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Bestellung bestätigen</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Ermäßigungsgruppe</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>Gruppen Sicht auf Ermäßigungsregeln</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Richtlinie bearbeiten</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Bestellliste</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Bestellungsansicht</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Eingabe der Kontoinformationen</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>MwSt Typen</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Trigger</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Sicht</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Ändere Passwort</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrieren</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Passwort vergessen</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Registrationsinformationen</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Neuer Benutzer registiert</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Bearbeite Workflow</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Workflow</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Bearbeite Workflowgruppe</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Gruppe bearbeiten</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Workflowgruppenliste</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Gruppenliste</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Workflowliste</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Workflowliste der Gruppe</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Einige Template Fehler sind aufgetreten, siehe die Bugliste für mehr Informationen.</translation>
    </message>
</context>
<context>
    <name>workflow/eventtype/result/event_ezcheckout</name>
    <message>
        <source>Wrapping</source>
        <translation type="obsolete">Umschlagen</translation>
    </message>
</context>
</TS>
