<?php /* #?ini charset="utf-8"?

[XmlSettings]
XmlContent=extension/noveniniupdate/source/sample.xml


*/
