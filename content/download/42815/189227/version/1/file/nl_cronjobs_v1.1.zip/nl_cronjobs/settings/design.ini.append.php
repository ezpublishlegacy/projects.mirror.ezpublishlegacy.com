<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nl_cronjobs

[StylesheetSettings]
BackendCSSFileList=cronjobs.css


*/ ?>
