<?php /*

[ExtensionSettings]
DesignExtensions[]=ezclasslists

[JavaScriptSettings]
JavaScriptList[]=yui/2.5.2/build/utilities/utilities.js
JavaScriptList[]=classlists.js

*/ ?>
