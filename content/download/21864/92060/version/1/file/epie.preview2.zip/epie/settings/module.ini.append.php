<?php /*

[ModuleSettings]
ExtensionRepositories[]=epie
ModuleList[]=epie

*/ ?>
