<!DOCTYPE TS>
<TS version="2.0" language="fr_FR" sourcelanguage="en">
<context>
    <name>extension/imageeditor</name>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
</context>
<context>
    <name>extension/imageeditor/error</name>
    <message>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
</context>
</TS>