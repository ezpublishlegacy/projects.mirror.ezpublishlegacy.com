<?php /*

[RegionalSettings]
TranslationExtensions[]=imageeditor

[TemplateSettings]
ExtensionAutoloadPath[]=epie

# TODO: remove this before publication
DevelopmentMode=enabled
#Debug=disabled

[DebugSettings]
AlwaysLog[]=1

*/ ?>
