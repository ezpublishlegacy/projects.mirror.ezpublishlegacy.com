<?php /*

[EventSettings]
ExtensionDirectories[]=autonotifications
AvailableEventTypes[]=event_autonotifications

*/ ?>