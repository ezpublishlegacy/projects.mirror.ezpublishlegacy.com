<?php /*

[ExtensionSettings]
DesignExtensions[]=autonotifications

*/ ?>