<?php

// Load autoloader functionality
require_once 'Base/base.php';
function __autoload( $className )
{
  ezcBase::autoload( $className );
}

// Define which handler to use for the image manipulation.
$settings = new ezcImageConverterSettings(
    array(
        new ezcImageHandlerSettings( 'ImageMagick', 'ezcImageImagemagickHandler' ),
        )
    );

// Create the converter object.
$converter = new ezcImageConverter( $settings );

$filters = array(
    new ezcImageFilter(
        'crop',
        array( 'x' => 740,
               'width' => 1300,
               'y' => 720,
               'height' => 900
               )
        ),
    new ezcImageFilter(
        'colorspace',
        array(
            'space' => ezcImageColorspaceFilters::COLORSPACE_GREY
            )
        ),
    new ezcImageFilter(
        'scale',
        array( 'width'    => 500,
               'height'   => 350,
               'direction' => ezcImageGeometryFilters::SCALE_DOWN
               )
        )
    );

// Create the transformation inside the manager
$converter->createTransformation( 'crop', $filters, array( 'image/jpeg' ) );

// Transform an image.
$converter->transform( 'crop', "vulcher.jpg", "vulcher_converted.jpg" );

print( "<p><img src='vulcher_converted.jpg' /></p>" );

?>



