<?php

// Load autoloader functionality
require_once 'Base/base.php';
function __autoload( $className )
{
  ezcBase::autoload( $className );
}

// Print image information
$image = new ezcImageAnalyzer( 'boat.jpg' );

$mime = $image->mime;

// Check if it's a photo format
if ( $mime == 'image/tiff' || $mime == 'image/jpeg' )
{
    $date = date( 'd.m.Y', $image->data->date );

    // Calculate shutter speed in seconds
    $shutterSpeedArray = split( '/', $image->data->exif['EXIF']['ExposureTime'] );

    $shutterSpeed = "1/" . $shutterSpeedArray[1] / $shutterSpeedArray[0]  . " sec";

    $aperatureArray = split( '/', $image->data->exif['EXIF']['FNumber'] );
    $aperature = "F" . round( $aperatureArray[0] / $aperatureArray[1], 1 );

    $focalLengthArray = split( "/", $image->data->exif['EXIF']['FocalLength'] );
    $focalLength = round( $focalLengthArray[0] / $focalLengthArray[1], 2 ) . " mm";

    // Print information about the photo
    print( "<dl>
             <di>Photo taken on:</di><dd>$date</dd>
             <di>Shutter speed:</di><dd>$shutterSpeed</dd>
             <di>Aperature:</di><dd>$aperature</dd>
             <di>Focal:</di><dd>$focalLength</dd>
            </dl>" );
}

?>
