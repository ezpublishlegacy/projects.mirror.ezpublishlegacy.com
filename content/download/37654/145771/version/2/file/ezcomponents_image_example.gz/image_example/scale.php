<?php

// Load autoloader functionality
require_once 'Base/base.php';
function __autoload( $className )
{
  ezcBase::autoload( $className );
}

// Define which handler to use for the image manipulation.
$settings = new ezcImageConverterSettings(
    array(
        new ezcImageHandlerSettings( 'ImageMagick', 'ezcImageImagemagickHandler' ),
        )
    );

// Create the converter object.
$converter = new ezcImageConverter( $settings );

$scaleFilters = array(
    new ezcImageFilter(
        'scale',
        array( 'width'    => 500,
               'height'   => 350,
               'direction' => ezcImageGeometryFilters::SCALE_DOWN
               )
        )
    );

// Which MIME types the conversion may output
$mimeTypes = array( 'image/jpeg' );

// Create the transformation inside the manager
$converter->createTransformation( 'thumbnail', $scaleFilters, $mimeTypes );

// Transform an image.
$converter->transform( 'thumbnail', "boathouse.jpg", "boathouse_tumbnail.jpg" );
print( "<p><img src='boathouse_tumbnail.jpg' /></p>" );
?>
