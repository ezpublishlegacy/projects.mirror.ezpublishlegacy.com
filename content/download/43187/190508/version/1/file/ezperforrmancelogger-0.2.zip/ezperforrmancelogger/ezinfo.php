<?php
class ezapacheperflogInfo
{
    static function info()
    {
        return array( 'Name' => "<a href=\"http://projects.ez.no/ezperformancelogger\">ezperformancelogger</a>",
                      'Version' => "0.2-dev",
                      'Copyright' => "Copyright (C) 2010-2011 Gaetano Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>