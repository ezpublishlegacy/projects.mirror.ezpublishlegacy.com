<?php /*

[OutputSettings]
OutputFilterName=ezPerfLogger

*/ ?>