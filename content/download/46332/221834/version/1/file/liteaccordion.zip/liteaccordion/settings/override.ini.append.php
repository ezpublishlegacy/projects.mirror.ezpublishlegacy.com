<?php /* #?ini charset="utf-8"?

[embed_liteaccordion]
Source=content/view/embed.tpl
MatchFile=embed/liteaccordion.tpl
Subdir=templates
Match[class_identifier]=liteaccordion

*/ ?>