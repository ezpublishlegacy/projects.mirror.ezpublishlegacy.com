<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=liteaccordion

[JavaScriptSettings]
FrontendJavaScriptList[]=jquery.min.js
FrontendJavaScriptList[]=liteaccordion.jquery.js



[StylesheetSettings]
CSSFileList[]=liteaccordion.css
FrontendCSSFileList[]=liteaccordion.css
*/
?>
