<?php /* #?ini charset="utf8"?

[AliasSettings]
AliasList[]=liteaccordion

[liteaccordion]
Reference=
Filters[]
Filters[]=geometry/scaleexact=700;300
*/ ?>