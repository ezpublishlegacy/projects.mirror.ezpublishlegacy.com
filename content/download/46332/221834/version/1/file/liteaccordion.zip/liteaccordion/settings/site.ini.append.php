<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=liteaccordion

[ExtensionSettings]
ActiveExtensions[]=liteaccordion

[RegionalSettings]
TranslationExtensions[]=liteaccordion

*/?>