<?php /* #?ini charset="iso-8859-1"?

[Tool]
AvailableToolArray[]=admin_collaboration

*/ ?>
