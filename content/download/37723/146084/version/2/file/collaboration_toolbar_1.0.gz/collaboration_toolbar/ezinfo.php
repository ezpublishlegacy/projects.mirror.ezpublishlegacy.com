<?php
class collaboration_toolbarInfo
{
    function info()
    {
        return array(
            'Name' => "Collaboration Toolbar",
            'Version' => "1.0",
            'Author' => "<a href='http://www.stuffandcontent.com'>Bruce Morrison</a>",
            'Copyright' => "Copyright (C) 2004-2007 designIT",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
