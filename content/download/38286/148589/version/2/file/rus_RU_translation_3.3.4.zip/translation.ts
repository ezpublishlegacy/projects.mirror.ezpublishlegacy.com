<!DOCTYPE TS><TS>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Магазин</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Пользователи</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Установки</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личные</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Главная страница</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Совместная работа</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Классы</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Процессы</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Триггеры</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Статистика поиска</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типы НДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Скидки</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Роли</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Медиа</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Закладки</translation>
    </message>
    <message>
        <source>History</source>
        <translation>История</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Мой список ожидания</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Установки уведомлений</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои закладки</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Шаблоны</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>Транслятор URL</translation>
    </message>
    <message>
        <source>URL management</source>
        <translation>Управление URL</translation>
    </message>
    <message>
        <source>RAD</source>
        <comment>Rapid Application Development</comment>
        <translation>RAD</translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Настройка расширений</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Кеш</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Пакеты</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Уведомление</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Информация о системе</translation>
    </message>
    <message>
        <source>RSS</source>
        <comment>Really Simple Syndication</comment>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <source>PDF export</source>
        <comment>PDF export</comment>
        <translation>Экспорт в PDF</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view</name>
    <message>
        <source>Article</source>
        <translation>Статья</translation>
    </message>
    <message>
        <source>Placed in</source>
        <translation>Помещена в</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Папка</translation>
    </message>
    <message>
        <source>Forum</source>
        <translation>Форум</translation>
    </message>
    <message>
        <source>Forum message</source>
        <translation>Сообщение в форуме</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Info page</source>
        <translation>Информационная страница</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Ссылка</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Товар</translation>
    </message>
    <message>
        <source>Product review</source>
        <translation>Информация о товаре</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>Also part of these groups</source>
        <translation>Также член следящих групп</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Группа пользователя</translation>
    </message>
</context>
<context>
    <name>design/blog/layout</name>
    <message>
        <source>Log entries</source>
        <translation>Журнальные записи</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Описание:</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Категории</translation>
    </message>
    <message>
        <source>Create new blog entry</source>
        <translation>Создать новую запись в блоге</translation>
    </message>
    <message>
        <source>Latest blogs</source>
        <translation>Последний блог</translation>
    </message>
    <message>
        <source>Log Archive by Entry</source>
        <translation>Архив журнала по записям</translation>
    </message>
    <message>
        <source>Comments disabled</source>
        <translation>Комментарии отключены</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>Poll</source>
        <translation>Голосование</translation>
    </message>
    <message>
        <source>Recent links</source>
        <translation>Часто используемые ссылки</translation>
    </message>
</context>
<context>
    <name>design/corporate/layout</name>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Отправить</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
</context>
<context>
    <name>design/forum/layout</name>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Ответы</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Последний ответ</translation>
    </message>
    <message>
        <source>Latest posts</source>
        <translation>Список последних сообщений</translation>
    </message>
    <message>
        <source>Number of Topics:</source>
        <translation>Число тем:</translation>
    </message>
    <message>
        <source>Number of Posts:</source>
        <translation>Количество сообщений:</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Уведомление</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Отредактировать учетную запись</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
</context>
<context>
    <name>design/gallery/layout</name>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Galleries</source>
        <translation>Галереи</translation>
    </message>
    <message>
        <source>Latest images</source>
        <translation>Новые изображения</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
    <message>
        <source>Latest comments</source>
        <translation>Последние комментарии</translation>
    </message>
    <message>
        <source>Edit gallery</source>
        <translation>Редактировать галерею</translation>
    </message>
    <message>
        <source>Create a new gallery</source>
        <translation>Создать новую галерею</translation>
    </message>
    <message>
        <source>Name of your album</source>
        <translation>Название вашего альбома</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Number of columns</source>
        <translation>Число колонок</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <source>Gallery list</source>
        <translation>Список галерей</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
</context>
<context>
    <name>design/intranet/layout</name>
    <message>
        <source>Comment this article!</source>
        <translation>Прокомментировать статью!</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
    <message>
        <source>Contact information</source>
        <translation>Контактная информация</translation>
    </message>
</context>
<context>
    <name>design/news/content/poll</name>
    <message>
        <source>Results</source>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Анонимные пользователи не имеют права голосовать, пожалуйста, зарегистрируйтесь.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Вы уже голосовали.</translation>
    </message>
</context>
<context>
    <name>design/news/layout</name>
    <message>
        <source>Related stories</source>
        <translation>Связанные истории</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Послать другу</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>Comment this article!</source>
        <translation>Прокомментировать статью!</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>View all polls</source>
        <translation>Просмотреть все голосования</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Новости</translation>
    </message>
    <message>
        <source>Most popular</source>
        <translation>Самые популярные</translation>
    </message>
    <message>
        <source>Poll</source>
        <translation>Голосование</translation>
    </message>
</context>
<context>
    <name>design/shop/layout</name>
    <message>
        <source>login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Подробнее</translation>
    </message>
    <message>
        <source>Write your own review</source>
        <translation>Написать собственный обзор</translation>
    </message>
    <message>
        <source>Write a review and share your opinion. Please make sure your comments are devoted to the product.</source>
        <translation>Здесь вы можете написать собственный обзор и поделиться своим мнением с остальными. Убедитесь, что тема вашего обзора касается обсуждаемого продукта.</translation>
    </message>
    <message>
        <source>How do you rate the product?</source>
        <translation>Как вы оцениваете данный продукт?</translation>
    </message>
    <message>
        <source>Title of your review:</source>
        <translation>Заголовок вашего обзора:</translation>
    </message>
    <message>
        <source>Your review:</source>
        <translation>Текст обзора:</translation>
    </message>
    <message>
        <source>Related products</source>
        <translation>Похожие продукты</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Добавить в корзину</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Уведомляйте меня об изменениях</translation>
    </message>
    <message>
        <source>Printerfriendly version</source>
        <translation>Версия для печати</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Люди купившие данный продукт, также покупают</translation>
    </message>
    <message>
        <source>Reviews</source>
        <translation>Обзоры</translation>
    </message>
    <message>
        <source>Write a review</source>
        <translation>Написать обзор продукта</translation>
    </message>
    <message>
        <source>No rating</source>
        <translation>Нет рейтинга</translation>
    </message>
    <message>
        <source>Main menu</source>
        <translation>Главное меню</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Уведомление</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Отредактировать учетную запись</translation>
    </message>
    <message>
        <source>View basket</source>
        <translation>Просмотр корзины</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>Register new customer</source>
        <translation>Зарегистрировать нового пользователя</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Продукты</translation>
    </message>
    <message>
        <source>Latest products</source>
        <translation>Последние поступления</translation>
    </message>
    <message>
        <source>Shopping basket</source>
        <translation>Корзинка для товаров</translation>
    </message>
    <message>
        <source>View all details</source>
        <translation>Просмотреть все детали</translation>
    </message>
    <message>
        <source>Your basket is empty</source>
        <translation>Ваша корзинка пуста</translation>
    </message>
    <message>
        <source>Best sellers</source>
        <translation>Бестселлеры</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Последние новости</translation>
    </message>
</context>
<context>
    <name>design/standard/class</name>
    <message>
        <source>Class is locked</source>
        <translation>Класс заблокирован</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Multiple choice</source>
        <translation>Множественный выбор</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation>Стиль элемента списка</translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation>Стиль флажка</translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation>Новый элемент множества</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Удалить выбранные</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows медиа проигрыватель</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с НДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без НДС</translation>
    </message>
    <message>
        <source>Max file size</source>
        <translation>Макс. размер файла</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Значение по умолчанию</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Пустое значение</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Текущая дата</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Текущее время и дата</translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation>Элемент множества</translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation>Значение элемента множества</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Мин. значение вещественного числа</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Макс. значение вещественного числа</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Мин. значение целого числа</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Макс. значение целого числа</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Тип медиа проигрывателя</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Имя по умолчанию</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Тип НДС</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Макс. длина строки</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Предпочитаемое количество строк</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Текущее время</translation>
    </message>
    <message>
        <source>Default number of rows</source>
        <translation>Количество строк по умолчанию</translation>
    </message>
    <message>
        <source>Matrix Column</source>
        <translation>Столбец матрицы</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>New Column</source>
        <translation>Новая колонка</translation>
    </message>
    <message>
        <source>Allowed classes</source>
        <translation>Разрешенные классы</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Default placement for objects</source>
        <translation>Расположение объектов по умолчанию</translation>
    </message>
    <message>
        <source>New objects will be placed in %nodename</source>
        <translation>Новые объекты будут помещены в %nodename</translation>
    </message>
    <message>
        <source>New objects will not be placed in the content tree</source>
        <translation>Новые объекты не будут помещены в дерево сайта</translation>
    </message>
    <message>
        <source>Select placement</source>
        <translation>Выберите размещение</translation>
    </message>
    <message>
        <source>Disable placement</source>
        <translation>Отключить размещение</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Новая опция</translation>
    </message>
    <message>
        <source>Pretext</source>
        <translation>Префикс</translation>
    </message>
    <message>
        <source>Posttext</source>
        <translation>Постфикс</translation>
    </message>
    <message>
        <source>Digits</source>
        <translation>Цифры</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Начальное значение</translation>
    </message>
    <message>
        <source>Update identifier</source>
        <translation>Обновить идентификатор</translation>
    </message>
    <message>
        <source>Ini file</source>
        <translation>INI файл</translation>
    </message>
    <message>
        <source>Ini Section</source>
        <translation>Секция INI файла</translation>
    </message>
    <message>
        <source>Ini Parameter</source>
        <translation>Параметр в INI файле</translation>
    </message>
    <message>
        <source>Ini file location</source>
        <translation>Расположение INI файла</translation>
    </message>
    <message>
        <source>Ini setting type</source>
        <translation>Тип настройки INI файла</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <source>Enable/Disable</source>
        <translation>Включить/Отключить</translation>
    </message>
    <message>
        <source>True/False</source>
        <translation>Истина/Ложь</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Целое число</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Дробное число</translation>
    </message>
    <message>
        <source>Array</source>
        <translation>Массив</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Create or browse objects</source>
        <translation>Создать или выбрать объекты</translation>
    </message>
    <message>
        <source>New and existing objects</source>
        <translation>Новые и существующие объекты</translation>
    </message>
    <message>
        <source>Only new objects</source>
        <translation>Только новые объекты</translation>
    </message>
    <message>
        <source>Only existing objects</source>
        <translation>Только существующие объекты</translation>
    </message>
    <message>
        <source>Select which classes user can create</source>
        <translation>Выберите, какие классы может создавать пользователь</translation>
    </message>
    <message>
        <source>Package Type</source>
        <translation>Тип пакета</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Проверено</translation>
    </message>
    <message>
        <source>Unchecked</source>
        <translation>Непроверенно</translation>
    </message>
    <message>
        <source>Single choice</source>
        <translation>Одиночный выбор</translation>
    </message>
    <message>
        <source>Warning, the ini file settings value and object value does not match.</source>
        <translation>Предупреждение, значение настроек в INI файле и значение объекта не совпадают.</translation>
    </message>
    <message>
        <source>The ini file has probably been modified manually since last time.</source>
        <translation>Возможно, INI файл был недавно изменен вручную.</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Выключено</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Истина</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Ложь</translation>
    </message>
    <message>
        <source>Current value: </source>
        <translation>Текущее значение:</translation>
    </message>
    <message>
        <source> (This value are the current identifier)</source>
        <translation>(Данное значение - это текущий идентификатор)</translation>
    </message>
    <message>
        <source>Current temporary value: </source>
        <translation>Текущее временное значение:</translation>
    </message>
    <message>
        <source> (This value is a copy of the original identifier)</source>
        <translation>(Данное значение - это копия оригинального идентификатора)</translation>
    </message>
    <message>
        <source>Ini File : </source>
        <translation>INI файл:</translation>
    </message>
    <message>
        <source>Ini Value: </source>
        <translation>Значение в INI файле:</translation>
    </message>
    <message>
        <source>Make empty array</source>
        <translation>Создать пустой массив</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибуты</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Обязателен</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Инд. в поиске</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Информационное хранилище</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Шаблон имени объекта</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>В группе</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Добавить в группу</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Исключить из групп</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Тип данных</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Отменить изменения</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Вы уверенны, что хотите удалить эти классы?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Удаление класса %1 приведет к удалению %2!</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Вы уверенны, что хотите удалить эти группы классов?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Удаление группы классов %1 приведет к удалению классов %2!</translation>
    </message>
    <message>
        <source>Editing class - %1</source>
        <translation>Редактирование класса %1</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Последний раз было отредактирован %username в %time</translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Отключить перевод</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Редактирование группы классов %1</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Изменен %username в %time</translation>
    </message>
    <message>
        <source>URL</source>
        <translation></translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Повторить</translation>
    </message>
    <message>
        <source>Class - %1</source>
        <translation>Класс - %1</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Обязательно</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>Не обязательно</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Учитывать при поиске</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>Не учитывать при поиске</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Собирать информацию</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>Не собирать информацию</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>Перевод отключен</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>Перевод включен</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Группы классов</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Новая группа</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Последние измененные классы</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Меню установки</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Классы в</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Новый класс</translation>
    </message>
    <message>
        <source>Click on the &apos;New&apos; button to create a class.</source>
        <translation>Нажмите кнопку &apos;Новый&apos; чтобы создать класс.</translation>
    </message>
    <message>
        <source>No classes in </source>
        <translation>Нет классов в</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Список групп для &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>В группе нет элементов.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Группы</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 ожидает подтверждения от редактора</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>Публикация %1 была подтверждена</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>Публикация %1 не была подтверждена</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 ожидает подтверждения</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Просмотрен</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Не прочтенный</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивный</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Отправлен: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Нет новых элементов для обработки.</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Итоги</translation>
    </message>
    <message>
        <source>[more]</source>
        <translation>[подробнее]</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Необходимо подтверждение, прежде чем объект %1 может быть опубликован.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Если вы хотите, вы можете послать сообщение человеку, подтверждающему публикацию?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Необходимо подтверждение, прежде чем объект %1 может быть опубликован.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Подтверждаете ли вы публикацию объекта?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Публикация объекта % была подтверждена. Объект будет опубликован, когда продолжится контроль потока.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Редактировать объект</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Объект %1 не был принят, но доступен как черновик.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Объект %1 не был принят, но будет доступен, как черновик, для автора.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Добавить комментарий</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Отказать</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Участник</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Сообщения</translation>
    </message>
    <message>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>Вы можете отредактировать  черновик и опубликовать еще раз, в этом случае необходимо еще одно подтверждение.</translation>
    </message>
    <message>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>Автор может отредактировать черновик снова,  в таком случае будет создан новый запрос на подтверждение.</translation>
    </message>
    <message>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] Подтверждение &quot;%objectname&quot; требует вашего внимания</translation>
    </message>
    <message>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot;  ждет подтверждения</translation>
    </message>
    <message>
        <source>This email is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>Данное письмо предназначено для уведомления вас о том, что &quot;%objectname&quot; ожидает вашего утверждения на сайте %sitename.
Процесс публикации был приостановлен, до тех пор пока вы не примете решение о продолжении процесса или его остановке.
Получить доступ к объекту вы можете загрузив нижеследующую сслыку.</translation>
    </message>
    <message>
        <source>This email is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>Данное письмо предназначено для уведоления вас о том, что &quot;%objectname&quot; ожидает утверждения перед публикацией на сайте %sitename.
Если вы хотите отправить комментарии цензору или же просмотреть статус документа, загрузите нижеследующую ссылку.</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Вы уверенны, что хотите удалить этот перевод?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Изменить перевод для содержимого</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Выберите один из переводов из списка для изменения или введите новый в поля для ввода.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Новый перевод для содержимого</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Выберите один из переводов из списка для изменения или введите новый в поля для ввода.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Специализированный</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Имя перевода</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Регион</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Создать</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Переводы содержимого</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Ниже вы найдете список активных языков, на которые может быть переведен объект.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Removing &apos;%1&apos; will remove the translation itself and %2 translated versions!</source>
        <translation>Удаление &apos;%1&apos; приведет к удалению самого перевода и %2 переведенных версий!</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL транслятор</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>Экспорт в PDF</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Краткое описание</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Подтекст</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Исходный узел</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Пролистать</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Экспортировать структуру</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Дерево</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Узел</translation>
    </message>
    <message>
        <source>Export classes</source>
        <translation>Экспортировать классы</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Доступ к сайту</translation>
    </message>
    <message>
        <source>Export destination</source>
        <translation>Назначение для экспорта</translation>
    </message>
    <message>
        <source>Export to URL</source>
        <translation>Экспортировать по адресу</translation>
    </message>
    <message>
        <source>Export for direct download</source>
        <translation>Экспортировать для прямой загрузки</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
</context>
<context>
    <name>design/standard/content/browse</name>
    <message>
        <source>Create new</source>
        <translation>Создать новый</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Копирование %1</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>Количество версий %1, текущая версия %2.</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Копировать все версии</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Копировать текущую версию</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Создать</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>New author</source>
        <translation>Новый автор</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Удалить выбранные</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Удалить изображение</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Высокое</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Лучшее</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Низкое</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Автом. высокое</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Автом. низкое</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Автом. проигрывание</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Цикл</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Контролер</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Окно изображения</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>InfoVolumePanel</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Информационная панель</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Найти объект</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Новая опция</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Цена:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Ваша цена:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Вы экономите:</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Информация о пользователе</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation>Размер файла</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Год</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Месяц</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>День</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Час</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Минута</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Альтернативный текст изображения</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Качество</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Средства управления</translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation>Имя существующего  файла</translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation>mime/type существующего файла</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Нет отношения</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Начальное значение</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Конечное значение</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Значение шага</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID пользователя</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Подтвердите пароль</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Цена</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>MIME-Type</source>
        <translation>Тип MIME</translation>
    </message>
    <message>
        <source>New row</source>
        <translation>Новая строка</translation>
    </message>
    <message>
        <source>Replace object</source>
        <translation>Заменить объект</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Удалить объект</translation>
    </message>
    <message>
        <source>Remove objects</source>
        <translation>Удалить объекты</translation>
    </message>
    <message>
        <source>View Mode</source>
        <translation>Режим Просмотра</translation>
    </message>
    <message>
        <source>Local image file for upload</source>
        <translation>Загрузка изображения на сервер</translation>
    </message>
    <message>
        <source>Image preview</source>
        <translation>Предвар. просмотр изображения</translation>
    </message>
    <message>
        <source>Original filename for image</source>
        <translation>Оригинальное имя файла изображения</translation>
    </message>
    <message>
        <source>Existing original filename</source>
        <translation>Существующее имя файла</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Open objects for edit</source>
        <translation>Открыть объекты для редактирования</translation>
    </message>
    <message>
        <source>Browse for objects</source>
        <translation>Обзор объектов</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>Value (optional)</source>
        <translation>Значение (не обязательное)</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>The following information was collected:</source>
        <translation>Следующая информация была собрана:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Сортировать по</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Сортировка</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Главный</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Переместить</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Опубликовано</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Глубина</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Идентификатор класса</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Имя класса</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Предвар. просмотр</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Отправить для публикации</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Информация об объекте</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Еще не опубликовано</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Править</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Родственные объекты</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Собранная информация с %1</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Сохранить черновик</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Добавить расположение</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Создан</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Редактирование</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Нет информации о регионе)</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>Проверка правильности не удалась</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Неправильное расположение объекта</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Редактировать %1 - %2</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Новый черновик</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Feedback from %1</source>
        <translation>Сообщение обратной связи от %1</translation>
    </message>
    <message>
        <source>The following feedback was collected:</source>
        <translation>Следующие сообщения были собраны:</translation>
    </message>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>Текущая опубликованная версия %version была опубликована %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>Последние изменения были внесены %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Владельцем объекта являться %owner.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Текущие черновики</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Владелец</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последний раз изменен</translation>
    </message>
    <message>
        <source>Input was partially stored</source>
        <translation>Введенные данные были частично сохранены</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft %versionname?</source>
        <translation>Вы уверены, что хотите выбросить черновик %versionname?</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Данный объект уже был отредактирован кем-либо еще (включая вас).
Вы можете легко продолжить редактирование одного из ваших черновиков, или же создать новый черновик.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Данный объект уже был отредактирован вами.
Вы можете легко продолжить редактирование одного из ваших черновиков, или же создать новый черновик.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Данный объект уже был отредактирован кем-либо еще.
Вы можете легко продолжить редактирование одного из ваших черновиков, или же создать новый черновик.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/ezoption</name>
    <message>
        <source>No value chosen</source>
        <translation>Не выбрано значение</translation>
    </message>
</context>
<context>
    <name>design/standard/content/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Обратная связь для %feedbackname</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Вы уже отправляли сообщение обратной связи. Предыдущее сообщение находится ниже.</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Спасибо за участия, нам важно знать ваше мнение. Ваше сообщение обратной связи.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Вернуться на сайт</translation>
    </message>
</context>
<context>
    <name>design/standard/content/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Форма %formname</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Вы уже отправляли данные в этой форме. Отправленные вами данные следуют ниже.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Вернуться на сайт</translation>
    </message>
</context>
<context>
    <name>design/standard/content/pdf</name>
    <message>
        <source>eZ publish PDF export</source>
        <translation>Экспорт в PDF (eZ publish)</translation>
    </message>
    <message>
        <source>#page of #total</source>
        <translation>#page из #total</translation>
    </message>
    <message>
        <source>#level1 - #level2</source>
        <translation>#level1 - #level2</translation>
    </message>
    <message>
        <source>#levelIndex1:#levelIndex2</source>
        <translation>#levelIndex1:#levelIndex2</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Versionview not supported in PDF yet</source>
        <translation>Просмотр версий объектов пока не поддерживается</translation>
    </message>
</context>
<context>
    <name>design/standard/content/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Голосование %pollname</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Анонимные пользователи не имеют права голосовать, пожалуйста, зарегистрируйтесь.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Вы уже голосовали.</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>Всего проголосовало: %count</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Результаты голосования</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Расширенный поиск</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Любой класс</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Обновить атрибуты</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Любая секция</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Любое время</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>За последний день</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>За последнюю неделю</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>За последний месяц</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>За последние три месяца</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>За последний год</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Искать все слова</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Искать точное совпадение фразы</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>По крайней мере одно из слов</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Атрибут класса</translation>
    </message>
    <message>
        <source>In</source>
        <translation>В</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Опубликовано</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Не было найдено результатов при поиске &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Поиск по &quot;%1&quot; вернул %2 совпадений</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Следующие слова были исключены из поиска:</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Показывать на страницу</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 совпадений</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 совпадений</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 совпадений</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 совпадений</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 совпадений</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Для большего количества опций попробуйте %1Расширенный поиск%2</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Подсказки к поиску</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Проверьте написание ключевых слов.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Попробуйте изменить некоторые слова, например: машина вместо машины.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Попробуйте поискать с более мягкими условиями.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Меньшее количество ключевых слов дает большее количество совпадений, попытайтесь уменьшить количество ключевых слов.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Послать другу</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Сообщение послано.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Нажмите здесь, чтобы возвратиться к первоначальной странице.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Сообщение не было послано.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Сообщение не было послано из-за неизвестной ошибки. Пожалуйста, известите администратора сайта об этой ошибке.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Пожалуйста, исправьте следующие ошибки:</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Ваше имя</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Ваш E-mail</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Имена получателей</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>E-mail адреса получателей</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Послать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Это сообщение было послано вам потому что &quot;%1 &lt;%2&gt;&quot;  считает, что вам будет интересна страница &quot;%3&quot; на %4.</translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation>Это ссылка на страницу:</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation>Комментарий от &quot;%1 &lt;%2&gt;&quot;:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>(No locale information available)</source>
        <translation>(Нет информации о регионе)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Перевести</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 данные успешно сохранены</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Регион</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Перевести на</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Перевод &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Удалить следующий перевод из &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текущая версия</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Восстановить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Корзина пустая</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Убрать выделение</translation>
    </message>
    <message>
        <source>Empty Trash</source>
        <translation>Очистить корзину</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Version not a draft</source>
        <translation>Версия не черновик</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Для редактирования данной версии создайте ее копию.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Версия вам не принадлежит</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Версия:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Статус:</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Переводы:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Создатель:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Изменено:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Копировать и редактировать</translation>
    </message>
    <message>
        <source>Versions for: %1</source>
        <translation>Версии %1</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Версия %1 недоступна для редактирования, только черновики могут быть отредактированы.</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Версия %1 была создана не вами, только собственные черновики могут быть изменены.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Невозможно создать новую версию</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Был достигнут предел размера истории версий, и невозможно удалить заархивированные версии.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Вы можете изменить установки истории версий в content.ini, удалите черновики или редактируйте существующий черновик.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation>Пролистать</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>У вас нет черновиков</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Родственные объекты</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Пусто</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Опубликовать</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Для выбора объектов, выберите подходящий(ие) переключатель(ли), и нажмите кнопку &quot;Выбрать&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Для выбора дочернего объекта одного из отображенных объектов, нажмите на имя объекта, чтобы просмотреть  список с дочерними элементами.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текущая версия</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Дизайн сайта</translation>
    </message>
    <message>
        <source>Choose initial placement</source>
        <translation>Выберите первоначальное расположение</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои закладки</translation>
    </message>
    <message>
        <source>Add bookmarks</source>
        <translation>Добавить закладки</translation>
    </message>
    <message>
        <source>You have no bookmarks</source>
        <translation>У вас нет закладок</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Вверх на один уровень</translation>
    </message>
    <message>
        <source>Top levels</source>
        <translation>Объекты верхнего уровня</translation>
    </message>
    <message>
        <source>Switch top levels by clicking one of these items.</source>
        <translation>Переключите верхние элементы, кликнув на один из этих.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Закладки</translation>
    </message>
    <message>
        <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
        <translation>Закладки могут быть отредактированы посредством %bookmarkname в разделе %personalname.</translation>
    </message>
    <message>
        <source>Recent items</source>
        <translation>Недавно использованные</translation>
    </message>
    <message>
        <source>Recent items are added on publishing.</source>
        <translation>Недавно использованные объекты добавлены при публикации.</translation>
    </message>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Выберите элементы для закладок</translation>
    </message>
    <message>
        <source>Choose new placement</source>
        <translation>Выберите новое расположение</translation>
    </message>
    <message>
        <source>Choose placements</source>
        <translation>Выберите расположение</translation>
    </message>
    <message>
        <source>Choose related objects</source>
        <translation>Выберите родственные объекты</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Убрать выделение</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Очистить черновики</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последний раз изменен</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Мой список ожидания</translation>
    </message>
    <message>
        <source>Your pending list is empty</source>
        <translation>Ваш список ожидания пуст</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Для того чтобы выбрать объект, выберите соответствующий переключатель(и), и нажмите кнопку &quot;Выбрать&quot;.</translation>
    </message>
    <message>
        <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста, укажите где вы хотите расположить новый %classname.

Выберите нужное месторасположение и щелкните на кнопке %buttonname .
Вы можете также использовать список часто используемых ссылок и закладки.
Щелкните на ссылке чтобы изменить ваше текущее месторасположение.</translation>
    </message>
    <message>
        <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
        <translation>Здесь находится  список элементов на которые вами были установлены закладки. Нажмите на объекте для просмотра, если у вас достаточно прав, вы можете отредактировать его нажав кнопку &apos;Изменить&apos;.
Если вы хотите добавить дополнительные элементы в этот список, нажмите на кнопку &quot;Добавить закладки&quot;.
Удаление объектов из списка подразумевает удаление только закладок, но не самих объектов.</translation>
    </message>
    <message>
        <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
        <translation>Пожалуйста, выберите объекты которые вы хотите добавить в ваши закладки.

Выберите нужное месторасположение и щелкните на кнопке %buttonname .
Вы можете также использовать список часто используемых ссылок и закладки.
Щелкните на ссылке, чтобы изменить ваше текущее месторасположение.</translation>
    </message>
    <message>
        <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста, выберите новое месторасположение для %name.
Предыдущее месторасположение объекта было здесь: %placementname.

Выберите нужное месторасположение и щелкните на кнопке %buttonname .
Вы можете также использовать список часто используемых ссылок и закладки.
Щелкните на ссылке чтобы изменить ваше текущее месторасположение.</translation>
    </message>
    <message>
        <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста, выберите месторасположение для %name.

Выберите нужное месторасположение и щелкните на кнопке %buttonname .
Вы можете также использовать список часто используемых ссылок и закладки.
Щелкните на ссылке чтобы изменить ваше текущее месторасположение.</translation>
    </message>
    <message>
        <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Пожалуйста, выберите объекты которые вы хотите связать с %name.

Выберите нужные объекты и щелкните на кнопке %buttonname .
Вы можете также использовать список часто используемых ссылок и закладки.
Щелкните на ссылке чтобы изменить ваше текущее месторасположение.</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them anymore.</source>
        <translation>Здесь представлены текущие объекты, с которыми вы работаете. Вы являетесь владельцем черновиков, и только вы имеете право их просматривать.
Вы также можете редактировать или удалять ваши черновики, когда вы в них уже больше не нуждаетесь.</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Доступ запрещен</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>У вас нет разрешения на доступ в этот раздел.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не найдено</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Модуль не найден</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Вид не найден</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Нажмите на кнопку &quot;Войти&quot; для того, чтобы войти в систему.</translation>
    </message>
    <message>
        <source>Possible reasons for this is.</source>
        <translation>Возможные причины для этого.</translation>
    </message>
    <message>
        <source>Your current user does not have the proper privileges to access this page.</source>
        <translation>Ваш пользователь не обладает необходимыми привилегиями для доступа к этой странице.</translation>
    </message>
    <message>
        <source>You misspelled some parts of your url, try changing it.</source>
        <translation>Вы допустили ошибку в части адреса, попробуйте изменить его.</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>Запрашиваемый вами ресурс не может быть найден.</translation>
    </message>
    <message>
        <source>The the id or name of the resource was misspelled, try changing it.</source>
        <translation>Неправильное имя или идентификатор ресурса, попробуйте изменить его.</translation>
    </message>
    <message>
        <source>The resource longer exists on the site.</source>
        <translation>Ресурс более не доступен на сайте.</translation>
    </message>
    <message>
        <source>The requested module %module could not be found.</source>
        <translation>Запрашиваемый модуль %module не может быть найден.</translation>
    </message>
    <message>
        <source>The module name was misspelled, try changing the url.</source>
        <translation>Неправильное имя модуля, попробуйте изменить адрес.</translation>
    </message>
    <message>
        <source>The module does not exist on this site.</source>
        <translation>Указанный модуль на сайте отсутствует.</translation>
    </message>
    <message>
        <source>This site uses siteaccess matching in the url and you didn&apos;t supply one, try inserting a siteaccess name before the module in the url .</source>
        <translation>Этот сайт использует совпадение типа доступа к сайту (siteaccess matching) в URL, и вы не указали его. Попробуйте указать имя типа доступа перед названием модуля в адресной строке.</translation>
    </message>
    <message>
        <source>The requested view %view could not be found in module %module</source>
        <translation>Запрашиваемый вид %view  не может быть найден в модуле %module</translation>
    </message>
    <message>
        <source>The view name was misspelled, try changing the url.</source>
        <translation>Неправильное имя вида, попробуйте изменить адрес.</translation>
    </message>
    <message>
        <source>The view does not exist for the module %module.</source>
        <translation>Вид не существует в модуле %module.</translation>
    </message>
    <message>
        <source>View is disabled</source>
        <translation>Вид отключен</translation>
    </message>
    <message>
        <source>The view %module/%view is disabled and cannot be accessed.</source>
        <translation>Вид %module/%view отключен и не доступен.</translation>
    </message>
    <message>
        <source>Module is disabled</source>
        <translation>Модуль отключен</translation>
    </message>
    <message>
        <source>The module %module is disabled and cannot be accessed.</source>
        <translation>Модуль %module отключен и недоступен.</translation>
    </message>
    <message>
        <source>Object is unavailable</source>
        <translation>Объект недоступен</translation>
    </message>
    <message>
        <source>The object you requested is not currently available.</source>
        <translation>Объект, который вы запросили, в данный момент недоступен.</translation>
    </message>
    <message>
        <source>The id or name of the object was misspelled, try changing it.</source>
        <translation>Идентификатор или имя объекта было написано неправильно, попробуйте изменить их.</translation>
    </message>
    <message>
        <source>The object is no longer available on the site.</source>
        <translation>Объект удален и/или не существует на данном сайте.</translation>
    </message>
    <message>
        <source>Object moved</source>
        <translation>Объект перемещен</translation>
    </message>
    <message>
        <source>The object is no longer available at this URL.</source>
        <translation>Объект более недоступен по данному URL.</translation>
    </message>
    <message>
        <source>You should automatically be redirected to the new location. If not click %url.</source>
        <translation>Вы должны били быть автоматически перенаправлены в новое местоположение. Если этого не произошло, то кликните на этой ссылке: %url.</translation>
    </message>
    <message>
        <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
        <translation>Для того чтобы создавать новые учетные записи и/или входить с использованием уже существующей учетной записи, необходимо пройти процедуру авторизации на сайте.</translation>
    </message>
</context>
<context>
    <name>design/standard/form</name>
    <message>
        <source>Thank you for your feedback</source>
        <translation>Спасибо за ваш отзыв</translation>
    </message>
    <message>
        <source>Your information was successfully received.</source>
        <translation>Ваша информация была успешно получена.</translation>
    </message>
</context>
<context>
    <name>design/standard/gui</name>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Sitemap</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Добро пожаловать в систему администрирования  eZ publish</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Для входа введите действительное имя пользователя и пароль.</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Расширенный поиск</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Изменить Пароль</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Перенаправление</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Загрузка модуля не удалась</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Версия для печати</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Главная страница</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личные</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>%sitetitle front page</source>
        <translation>Главная страница %sitetitle</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Поиск %sitetitle</translation>
    </message>
    <message>
        <source>eZ publish redirection - %url</source>
        <translation>eZ publish перенаправление  %url</translation>
    </message>
    <message>
        <source>Redirecting to %url</source>
        <translation>Перенаправление на %url</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Неопределенный модуль:</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Предыдущая</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следующая</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Следующие товары были удалены из вашей корзины, так как свойства этих товаров были изменены</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Вы уверены, что хотите удалить %1 из узла %2?</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Примечание:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Удаленные узлы могут быть восстановлены позднее. Вы можете найти их в корзине.</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Удаление привязки к узлу %1</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Удаление данной связи повлечет за собой удаление %1 его дочерних элементов.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Вы уверены, что хотите удалить эти элементы?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename и  %childcount его дочерних элементов. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Переместить в корзину</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Если галочка %trashname отмечена, вы сможете найти удаленные вами элементы в корзине.</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Документ</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Группа пользователя</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Создать здесь</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Предвар. просмотр</translation>
    </message>
    <message>
        <source>Bookmark</source>
        <translation>Закладка</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Уведомляйте меня об изменениях</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Убрать выделение</translation>
    </message>
    <message>
        <source>Click to create a custom template</source>
        <translation>Кликните для создания шаблона</translation>
    </message>
    <message>
        <source>Add to Bookmarks</source>
        <translation>Добавить в закладки</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Уведомляйте меня об изменениях</translation>
    </message>
    <message>
        <source>New log</source>
        <translation>Новый журнал</translation>
    </message>
    <message>
        <source>New image</source>
        <translation>Новое изображение</translation>
    </message>
    <message>
        <source>New gallery</source>
        <translation>Новая галерея</translation>
    </message>
    <message>
        <source>New album</source>
        <translation>Новый альбом</translation>
    </message>
    <message>
        <source>New file</source>
        <translation>Новый файл</translation>
    </message>
    <message>
        <source>New article</source>
        <translation>Новая статья</translation>
    </message>
    <message>
        <source>New person</source>
        <translation>Новая персона</translation>
    </message>
    <message>
        <source>New company</source>
        <translation>Новая компания</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID узла</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID объекта</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Default object view.</source>
        <translation>Вид объекта по умолчанию.</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation>Система рассылки %sitename</translation>
    </message>
    <message>
        <source>[%sitename] New collaboration item</source>
        <translation>[%sitename] Новое сообщение</translation>
    </message>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Получать сообщения, объединенные в одно обзорное сообщение (дайджест)</translation>
    </message>
    <message>
        <source>Send out</source>
        <translation>Посылка</translation>
    </message>
    <message>
        <source>[%sitename] Digest for %date</source>
        <translation>[%sitename] Дайджест на %date</translation>
    </message>
    <message>
        <source>This digest email is to inform you on new items at %sitename.</source>
        <translation>Это сообщения для того, чтобы информировать про новые элементы на %sitename.</translation>
    </message>
    <message>
        <source>Do you want to receive messages combined in digest</source>
        <translation>Вы хотите получать сообщения, объединенные в одно сообщение (дайджест)</translation>
    </message>
    <message>
        <source>Digest settings</source>
        <translation>Настройки дайджеста</translation>
    </message>
    <message>
        <source>Day of the week</source>
        <translation>День недели</translation>
    </message>
    <message>
        <source>This email is to inform you on news at %sitename.</source>
        <translation>Это сообщения предназначено для того, чтобы информировать вас о новостях на %sitename.</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Создать</translation>
    </message>
    <message>
        <source>Notification admin</source>
        <translation>Администрирование уведомлений</translation>
    </message>
    <message>
        <source>Notification filter proccessed all available notification events</source>
        <translation>Фильтр уведомлений обработал все доступные события</translation>
    </message>
    <message>
        <source>Time event was spawned</source>
        <translation>Событие было запущено</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Запуск фильтра уведомлений</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Запуск временного события</translation>
    </message>
    <message>
        <source>Spawn</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation>Установки уведомлений</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Если вы не хотите больше получать данные уведомления, измените настройки рассылки здесь:</translation>
    </message>
    <message>
        <source>This email is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
        <translation>Данный e-mail адрес призван сообщить вам о том, что на сайте %sitename появился новый объект совместной работы, который требует вашего внимания.
Просмотреть данный объект можно загрузив нижеследующую ссылку.</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Уведомления</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Выберите типы элементов для совместной работы, по которым вы хотите получать уведомления.</translation>
    </message>
</context>
<context>
    <name>design/standard/package</name>
    <message>
        <source>Packages</source>
        <translation>Пакеты</translation>
    </message>
    <message>
        <source>The following packages are available on this system</source>
        <translation>Следующие пакеты доступны в системе</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Итоги</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Загрузить пакет</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Выберите файл, содержащий ваш пакет, и нажмите на кнопку загрузки</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Установить пакет</translation>
    </message>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Пожалуйста введите информацию об изменениях.</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Изменения</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Пожалуйста, введите общую информацию о вашем пакете.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Имя пакета</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Узел пакета</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Упаковщик</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Пожалуйста, введите информацию о поставщике пакета.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Роль</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Создать пакет</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Доступные мастера</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Выберите один из следующих мастеров для создания пакета</translation>
    </message>
    <message>
        <source>Please choose the content classes you wish to be included in the package.</source>
        <translation>Пожалуйста, выберите контент-классы, которые вы хотите включить в пакет.</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Список классов</translation>
    </message>
    <message>
        <source>Please select a CSS file to be included in the package.</source>
        <translation>Пожалуйста, выберите CSS файлы, которые вы хотите добавить в пакет.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Список добавленных изображений</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Мастер пакета: %wizardname</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Установить элементы</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Пропустить установку</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Удаление пакетов</translation>
    </message>
    <message>
        <source>Confirm removal</source>
        <translation>Подтвердите удаление</translation>
    </message>
    <message>
        <source>Keep packages</source>
        <translation>Оставить пакеты</translation>
    </message>
    <message>
        <source>Package removal was cancelled.</source>
        <translation>Удаление пакетов было отменено.</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Выбор</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Установлен</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>Не установлен</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Импортирован</translation>
    </message>
    <message>
        <source>Remove package</source>
        <translation>Удалить пакет</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Импортировать пакет</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Далее %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Завершить</translation>
    </message>
    <message>
        <source>Uninstall package</source>
        <translation>Деинсталлировать пакет</translation>
    </message>
    <message>
        <source>Uninstall items</source>
        <translation>Деинсталлировать элементы</translation>
    </message>
    <message>
        <source>Skip uninstallation</source>
        <translation>Пропустить деинсталляцию</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Файлы [%collectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталлировать</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Экспортировать в файл</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Состояние</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Поставщики</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>О пакете eZ publish &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send E-Mail to the maintainer</source>
        <translation>Отправить письмо поставщику пакета</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Документы</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Журнал изменений</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Список файлов</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
        <translation>Любое вхождение начинайте с маркера ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) в начале строки.
Запись продолжается до следующего маркера.</translation>
    </message>
    <message>
        <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
        <translation>Пожалуйста выберите пиктограмму для включения ее в пакет.
Если вы не хотите указывать пиктограмму, просто нажмите кнопку &quot;Далее&quot;.</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
        <translation>Пожалуйста выберите файл с изображением для включения его в пакет.
Когда вы закончит, нажмите кнопку &quot;Далее&quot; не указывая изображение в поле.</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>Данный пакет может быть проинсталлирован в вашей системе. Установка пакета предполагает копирование файлов на локальный диск, создание новых контент классов и т.п. - т.е. всего содержимого пакета.
Если вы не хотите устанавливать этот пакет в данный момент, вы можете сделать это позже на странице просмотра данного пакета.</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>Вы уверены, что хотите удалить данный пакет?
Пакет будет утерян навсегда.
Замечание: При удалении пакеты не деинсталлируются.</translation>
    </message>
    <message>
        <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
        <translation>Данный пакет можно деинсталлировать из вашей системы. Деинсталляция пакета подразумевает удаление всех установленных файлов, созданных контент классов и т.д. - т.е. всего, что входит в данный пакет. Если вы не хотите деинсталлировать данный пакет сейчас - вы можете сделать это позже на странице просмотра этого пакета.
Вы можете также удалить пакет без его деинсталляции из набора пакетов.</translation>
    </message>
</context>
<context>
    <name>design/standard/pdf/list</name>
    <message>
        <source>PDF Exports</source>
        <translation>Экспорт в PDF</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Создатель</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Создан</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Экспортировать новый объект</translation>
    </message>
</context>
<context>
    <name>design/standard/reference/ez</name>
    <message>
        <source>No generated documentation found</source>
        <translation>Не найдена сгенерированная документация</translation>
    </message>
    <message>
        <source>To create the reference documentation you must do the following step</source>
        <translation>Для создания документации вам необходимо сделать следующие шаги</translation>
    </message>
    <message>
        <source>Download and install doxygen</source>
        <translation>Скачать и установить doxygen</translation>
    </message>
    <message>
        <source>Generate the documentation by running the following command</source>
        <translation>Сгенерировать документацию, запустив следующую команду</translation>
    </message>
    <message>
        <source>Download doxygen from %doxygenurl.</source>
        <translation>Загрузить doxygen по адресу %doxygenurl.</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Главный</translation>
    </message>
    <message>
        <source>Modules</source>
        <translation>Модули</translation>
    </message>
    <message>
        <source>Class hierarchy</source>
        <translation>Иерархия классов</translation>
    </message>
    <message>
        <source>Compound list</source>
        <translation>Составной список</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Список файлов</translation>
    </message>
    <message>
        <source>Compound members</source>
        <translation>Составные члены</translation>
    </message>
    <message>
        <source>File members</source>
        <translation>Файловые члены</translation>
    </message>
    <message>
        <source>Related pages</source>
        <translation>Родственные страницы</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Вступление</translation>
    </message>
    <message>
        <source>The documentation will give an overview of the API of eZ publish.</source>
        <translation>Документация дает обзор API eZ publish.</translation>
    </message>
    <message>
        <source>All reference documentation has been made with %doxygenurl</source>
        <translation>Не найдена сгенерированная документация</translation>
    </message>
    <message>
        <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
        <translation>Официальная документация eZ publish содержит несколько секций, каждая из которых имеет несколько представлений.  Получить доступ  к данным разделам документации вы можете посредством меню расположенного вверху страницы.</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Создать правило для</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Шаг 1</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Все модули</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Разрешить всё</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Разрешить с ограничениями</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ограниченный</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Вернуться к шагу 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Вы не можете разрешить ограниченный доступ к функциям модуля</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>потому что список функций не определен.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Шаг 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Укажите функцию в модуле</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Вернуться к шагу 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Шаг 3</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Список ролей</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Просмотр роли</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Правила роли</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Пользователи и группы пользователей, которым назначена эта роль</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Назначить</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Дать доступ к модулю</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модуль</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Доступ</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Текущие правила</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Отменить изменения</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>Specify limitations for function %functionname in module %modulename. &apos;Any&apos; means no limitation by this parameter</source>
        <translation>Укажите ограничения для функции %functionname в модуле %modulename. &apos;Любой&apos;  значит отсутствие ограничений по данному параметру</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Не указанно.</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <source>Role edit %1</source>
        <translation>Редактирование роли %1</translation>
    </message>
    <message>
        <source>Edit policy</source>
        <translation>Редактировать правило</translation>
    </message>
    <message>
        <source>Remove selected policies</source>
        <translation>Удалить выбранные правила</translation>
    </message>
    <message>
        <source>Edit role</source>
        <translation>Редактировать роль</translation>
    </message>
    <message>
        <source>Assign role to user or group</source>
        <translation>Назначьте роль пользователю или группе</translation>
    </message>
    <message>
        <source>Remove selected roles</source>
        <translation>Удалить выбранные роли</translation>
    </message>
    <message>
        <source>Policy</source>
        <translation>Правило</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Узел</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Поддерево</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роль</translation>
    </message>
    <message>
        <source>Edit current role</source>
        <translation>Редактировать текущую роль</translation>
    </message>
    <message>
        <source>Remove selected assignments</source>
        <translation>Удалить выбранные назначения</translation>
    </message>
</context>
<context>
    <name>design/standard/rss</name>
    <message>
        <source>Choose export node</source>
        <translation>Выберите узел для экспорта</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <source>Choose import destination</source>
        <translation>Выбор места назначения для импорта</translation>
    </message>
    <message>
        <source>Choose RSS image</source>
        <translation>Выберите изображение RSS</translation>
    </message>
    <message>
        <source>Choose export source</source>
        <translation>Укажите источник для экспорта</translation>
    </message>
    <message>
        <source>Choose owner of imported objects</source>
        <translation>Укажите владельца импортируемых объектов</translation>
    </message>
    <message>
        <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста, выберите, откуда надо начать экспорт. 

Выберите месторасположение и нажмите кнопку %buttonname. 
Вы также можете использовать закладки и список часто используемых элементов. 
Нажмите на имени элемента, чтобы увидеть его содержимое.</translation>
    </message>
    <message>
        <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожайлуста, выберите, куда необходимо сохранять импортируемые элементы.

Выберите месторасположение и нажмите кнопку %buttonname. 
Вы также можете использовать закладки и список часто используемых элементов. 
Нажмите на имени элемента, чтобы увидеть его содержимое.</translation>
    </message>
    <message>
        <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожайлуста, выберите изображение для использования в процедуре RSS экспорта.

Выберите месторасположение и нажмите кнопку %buttonname. 
Вы также можете использовать закладки и список часто используемых элементов. 
Нажмите на имени элемента, чтобы увидеть его содержимое.</translation>
    </message>
    <message>
        <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста укажите владельца импортируемых объектов.

Выберите месторасположение и нажмите кнопку %buttonname. 
Вы также можете использовать закладки и список часто используемых элементов. 
Нажмите на имени элемента, чтобы увидеть его содержимое.
</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/edit</name>
    <message>
        <source>Display frontpage</source>
        <translation>Показывать главную страницу</translation>
    </message>
    <message>
        <source>RSS Export</source>
        <translation>Экспорт RSS</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>Ссылка на сайт</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <source>Site Access</source>
        <translation>Доступ к сайту</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>Версия RSS</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активный</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>URL доступа</translation>
    </message>
    <message>
        <source>Note. Each source only fetch 5 objects from 1 level below.</source>
        <translation>Замечание: Каждый источник извлекает только 5 объектов из нижеследующего уровня.</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Путь источника</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Add Source</source>
        <translation>Добавить источник</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>RSS Import</source>
        <translation>Импорт RSS</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Путь назначения</translation>
    </message>
    <message>
        <source>Imported objects owner</source>
        <translation>Владелец импортированных объектов</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Игнорировать</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/list</name>
    <message>
        <source>RSS Feeds</source>
        <translation>RSS новостная лента</translation>
    </message>
    <message>
        <source>RSS Exports</source>
        <translation>Экспорт RSS</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активный</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Экспортировать новый объект</translation>
    </message>
    <message>
        <source>RSS Imports</source>
        <translation>Импорт RSS</translation>
    </message>
    <message>
        <source>New Import</source>
        <translation>Импортировать новый объект</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/view</name>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Статистика поиска</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Наиболее частые поисковые фразы</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Фраза</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Количество фраз</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Средний результат</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Сбросить статистику</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section to node</source>
        <translation>Назначить секцию узлу</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Редактирование секции</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Список секций</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новая</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Вы уверены, что хотите удалить эти секции?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Удаление этих секций может привести к повреждению прав доступа, дизайна сайта, и других участков системы. Не делайте этого, если вы не уверены в правильности своих действий.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Часть навигации</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Магазин</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Пользователи</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Установить</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личное</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>Про части навигации</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>Административный интерфейс eZ publish разделен на навигационные части. Это способ сгруппировать различные области администрирования сайта. Выберите навигационную часть, которая должна быть активной, когда просматривается эта секция.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation></translation>
    </message>
    <message>
        <source>Node notification</source>
        <translation>Уведомление об элементах</translation>
    </message>
    <message>
        <source>Assign section - %section</source>
        <translation>Назначить секцию - %section</translation>
    </message>
    <message>
        <source>Choose section assignment</source>
        <translation>Выберите назначение секции</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Медиа</translation>
    </message>
    <message>
        <source>Remove selected sections</source>
        <translation>Удалить выбранные секции</translation>
    </message>
    <message>
        <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Пожалуйста, выберите, где вы хотите начать привязку секции %sectionname.  

Выберите месторасположение и нажмите кнопку %buttonname. 
Вы также можете использовать закладки и список часто используемых элементов. 
Нажмите на имени элемента, чтобы увидеть его содержимое.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Путь</translation>
    </message>
    <message>
        <source>Cache admin</source>
        <translation>Управление кэшем</translation>
    </message>
    <message>
        <source>Content view cache was cleared.</source>
        <translation>Кэш содержимого был успешно очищен.</translation>
    </message>
    <message>
        <source>Ini file cache was cleared.</source>
        <translation>Кэш INI файлов был успешно очищен.</translation>
    </message>
    <message>
        <source>Template cache was cleared.</source>
        <translation>Кэш шаблонов был успешно очищен.</translation>
    </message>
    <message>
        <source>View cache is enabled.</source>
        <translation>Кэш для просмотра включен.</translation>
    </message>
    <message>
        <source>View cache is disabled.</source>
        <translation>Кэш для просмотра отключен.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <source>Ini cache</source>
        <translation>Кэш INI файлов</translation>
    </message>
    <message>
        <source>Ini cache is always enabled.</source>
        <translation>Кэш INI файлов всегда включен.</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Кеш шаблонов</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Мастер создания типов данных</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Datatype start</comment>
        <translation>Начать</translation>
    </message>
    <message>
        <source>Basic information</source>
        <translation>Базовая информация</translation>
    </message>
    <message>
        <source>Name of datatype</source>
        <comment>Datatype</comment>
        <translation>Имя типа данных</translation>
    </message>
    <message>
        <source>Descriptive name of datatype</source>
        <comment>Datatype</comment>
        <translation>Описательное имя типа данных</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Datatype</comment>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <comment>Datatype</comment>
        <translation>Обработка ввода на уровне класса</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Datatype next</comment>
        <translation>Далее</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Datatype restart</comment>
        <translation>Перезапуск</translation>
    </message>
    <message>
        <source>Optional information</source>
        <translation>Дополнительная информация</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Datatype</comment>
        <translation>Имя класса</translation>
    </message>
    <message>
        <source>Constant name</source>
        <comment>Datatype</comment>
        <translation>Имя константы</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <comment>Datatype</comment>
        <translation>Создатель типа данных</translation>
    </message>
    <message>
        <source>Description of your datatype</source>
        <comment>Datatype</comment>
        <translation>Описание вашего типа данных</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Datatype</comment>
        <translation>Первая строка будет использована как краткое описание, а остальные строки войдут в документацию для пользователей.</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Datatype</comment>
        <translation>После нажатия кнопки &apos;Загрузить&apos;, система сгенерирует необходимый код и браузер предложит вам сохранить созданный файл.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Datatype download</comment>
        <translation>Загрузить</translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Расширения</translation>
    </message>
    <message>
        <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access spesific extensions, modify these configuration files.</source>
        <translation>Здесь вы можете подключить/отключить расширения. Только общие системные расширения могут быть активированы, для расширений уровня доступа к сайту необходима настройка следующих конфигурационных файлов.</translation>
    </message>
    <message>
        <source>Available extensions</source>
        <translation>Доступные расширения</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Информация о системе</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Сайт:</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>версия SVN</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Расширения</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Расширения</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>Безопасный режим включен.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>Безопасный режим выключен.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>Режим ограничения базового каталога включен и имеет значение %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>Ограничение базового каталога отключено.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>Регистрация глобальных переменных разрешена.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>Регистрация глобальных переменных запрещена.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>Загрузка файлов на сервер разрешена.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>Загрузка файлов на сервер запрещена.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>Максимальный размер данных (текст и файлы) для отправки на сервер равен %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>Лимит памяти для скриптов равен %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>Максимальное время исполнения равно %1 сек.</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>There is no known PHP accelerator active.</source>
        <translation>Ни один из известных PHP акселераторов не установлен.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>База данных</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Charset</source>
        <comment>Database charset</comment>
        <translation>Кодировка</translation>
    </message>
    <message>
        <source>&amp;percent% completed</source>
        <translation>&amp;percent% завершено</translation>
    </message>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Средства быстрой разработки приложений (RAD)</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
        <translation>Средства для быстрой разработки приложений (RAD) позволят вам быстро начать разрабатывать новые функции для eZ publish.</translation>
    </message>
    <message>
        <source>Tools</source>
        <comment>RAD Tools</comment>
        <translation>Средства разработки</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Мастер операторов шаблонов</translation>
    </message>
    <message>
        <source>Create new template override for</source>
        <translation>Создать новый шаблон с перекрытием</translation>
    </message>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Невозможно создать шаблон, нет прав доступа.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Введено неправильное имя. Можно использовать только буквы латинского алфавита (a-z), цифры и знак  &apos;_&apos;.</translation>
    </message>
    <message>
        <source>Template will be placed in</source>
        <translation>Шаблон будет расположен в</translation>
    </message>
    <message>
        <source>Template name</source>
        <translation>Имя шаблона</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Ключи перекрытия</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Узел</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Основан на шаблоне</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Пустой файл</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Копия шаблона по умолчанию</translation>
    </message>
    <message>
        <source>Container ( with children )</source>
        <translation>Контейнер (с вложенными элементами)</translation>
    </message>
    <message>
        <source>View ( without children )</source>
        <translation>Вид (без вложенных элементов)</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Объект</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Список шаблонов</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Общедоступные шаблоны</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Design Resource</source>
        <translation>Дизайн ресурс</translation>
    </message>
    <message>
        <source>Complete template list</source>
        <translation>Полный список шаблонов</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Template operator start</comment>
        <translation>Начать</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <comment>Template operator</comment>
        <translation>Имя оператора</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Template operator</comment>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <comment>Template operator</comment>
        <translation>Один оператор в классе</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <comment>Template operator</comment>
        <translation>Обрабатывает ввод оператора</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <comment>Template operator</comment>
        <translation>Генерирует выходной поток оператора</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <comment>Template operator</comment>
        <translation>Обработка параметров</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Template operator next</comment>
        <translation>Далее</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Template operator restart</comment>
        <translation>Перезапуск</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Template operator</comment>
        <translation>Имя класса</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <comment>Template operator</comment>
        <translation>Создатель оператора</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <comment>Template operator</comment>
        <translation>Описание вашего оператора</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Template operator</comment>
        <translation>Первая строка будет использована как краткое описание, а остальные строки войдут в документацию для пользователей.</translation>
    </message>
    <message>
        <source>Example code</source>
        <comment>Template operator</comment>
        <translation>Пример использования</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Template operator</comment>
        <translation>После нажатия кнопки &apos;Загрузить&apos;, система сгенерирует необходимый код и браузер предложит вам сохранить созданный файл.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Template operator download</comment>
        <translation>Загрузить</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Просмотр шаблона</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Ресурс шаблона по умолчанию</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Набор</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Перекрывает</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Условия совпадения</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Создать новый</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Итоги</translation>
    </message>
    <message>
        <source>System:</source>
        <translation>Система:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Image system:</source>
        <translation>Система работы с изображениями:</translation>
    </message>
    <message>
        <source>Mail:</source>
        <translation>Почтовая служба:</translation>
    </message>
    <message>
        <source>Database:</source>
        <translation>База данных:</translation>
    </message>
    <message>
        <source>All caches were cleared.</source>
        <translation>Все виды кэша были очищены успешно.</translation>
    </message>
    <message>
        <source>Cache collections</source>
        <translation>Набор кэшей</translation>
    </message>
    <message>
        <source>Click a button to clear a collection of caches.</source>
        <translation>Нажмите кнопку, чтобы очистить весь набор кэшей.</translation>
    </message>
    <message>
        <source>All caches.</source>
        <translation>Все кэши.</translation>
    </message>
    <message>
        <source>All caches</source>
        <translation>Все кэши</translation>
    </message>
    <message>
        <source>All caches are disabled</source>
        <translation>Все кэши отключены</translation>
    </message>
    <message>
        <source>Content views and template blocks.</source>
        <translation>Виды контента и шаблонные блоки.</translation>
    </message>
    <message>
        <source>Content caches</source>
        <translation>Кэши содержимого</translation>
    </message>
    <message>
        <source>Content caches is disabled</source>
        <translation>Кэши содержимого отключены</translation>
    </message>
    <message>
        <source>Template overrides and template compiling.</source>
        <translation>Перекрытие и компиляция шаблонов.</translation>
    </message>
    <message>
        <source>Template caches</source>
        <translation>Кеши шаблонов</translation>
    </message>
    <message>
        <source>Template caches are disabled</source>
        <translation>Кэши шаблонов отключены</translation>
    </message>
    <message>
        <source>INI caches.</source>
        <translation>Кэши INI файлов.</translation>
    </message>
    <message>
        <source>INI caches</source>
        <translation>Кэши INI файлов</translation>
    </message>
    <message>
        <source>INI cache is disabled</source>
        <translation>Кэши INI файлов отключены</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Выбор</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Отключен</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Очистить выделенные</translation>
    </message>
    <message>
        <source>Content view cache</source>
        <translation>Кэш видов контента</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Could not detect version</source>
        <translation>Невозможно определить версию</translation>
    </message>
    <message>
        <source>The PHP Accelerator is enabled.</source>
        <translation>PHP акселератор подключен.</translation>
    </message>
    <message>
        <source>The PHP Accelerator is disabled.</source>
        <translation>PHP акселератор отключен.</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Сервер</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Сокет БД</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>База данных</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Количество попыток соединения</translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Внутренний</translation>
    </message>
    <message>
        <source>Current read-only database (Slave)</source>
        <translation>Текущая БД только для чтения (Slave)</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Язык:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
        <comment>Datatype default description</comment>
        <translation>Реализация типа данных %datatypename.
Используя %datatypename вы можете ...</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <comment>Template operator default description</comment>
        <translation>Реализация оператора шаблонов %operatorname.
Используя %operatorname вы можете ...</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <comment>Template operator</comment>
        <translation>Если вы хотите вы можете добавить пример использования вашего оператора, который поясняет как ваш оператор должен работать.
Код по умолчаню был создан на основе базовых параметров, указанных вами.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Конструктор</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Если вы не можете установить соединение с базой данных, вам следует посмотреть на</translation>
    </message>
    <message>
        <source>at</source>
        <translation>на</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Вступление</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL это СУБД созданная  MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>В данный момент это одна из самых популярных баз данных в секции Свободного программного обеспечения и наиболее часто ее поддержка включена в PHP по умолчанию.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>С сайта производителя:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL самая популярная в мире СУБД с открытым исходным кодом, разработана для решения критически важных, ответственных задач. Её преимущества это скорость, мощность и точность, даже при очень высокой загрузке.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Более подробная информация может быть найдена по адресу</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL – это хороший выбор при необходимости поддержки только западных языков, однако, в данный момент это не самый лучший выбор для решений требующих поддержки Unicode или языков не романской группы.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Инсталляция</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>С использованием</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>опцию конфигурации вы позволяете PHP получать доступ к БД MySQL. Если вы используете эту опцию без указания пути к MySQL, PHP  будет использовать встроенные библиотеки клиента MySQL.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Дополнительная информация о расширении MySQL может быть найдена </translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL это СУБД  разработанная в университете Калифорнии  в департаменте компьютерных наук Беркли.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>Это очень популярная СУБД в сообществе открытого программного обеспечения, она предоставляет расширенную функциональность.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL сложная объектно-реляционная СУБД, поддерживающая почти все конструкции языка SQL, включая подзапросы, транзакции, пользовательские типы данных и функции. Это одна из самых мощных СУБД с открытым исходным кодом.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL - это хороший выбор для поддержки большинства языков, включая языки, требующие поддержки Unicode кодировки, но требует настройки для получения хорошей скорости работы.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Для включения поддержки PostgreSQL,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>необходимо при компиляции PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Дополнительная информация о PostgreSQL может быть найдена здесь</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation>Если хотите, вы  можете позволить программе установки добавить демонстрационные данные в вашу БД. Эти данные будут наглядной демонстрацией возможностей eZ publish</translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation>Пользователям, устанавливающим данную систему в первый раз, рекомендуется установить демо-данные.</translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation>Установить демонстрационные данные?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>Невозможно установить демо-данные, расширение PHP - zlib отсутствует.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>не поддерживает установку демо-данных в данной ситуации.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Ошибка в структуре демонстрационных данных</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Невозможно распаковать демо-данные.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Попробуйте установить систему без демо-данных.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Ошибка инициализации</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>Невозможно корректно проинициализировать базу данных.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>База данных уже содержит данные.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>Установка может быть продолжена, но это может повредить существующие данные в БД.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Что должна сделать программа установки?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Продолжить и оставить данные &apos;как есть&apos;.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Я хочу выбрать другую базу данных.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Примечание:</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Языковые настройки</translation>
    </message>
    <message>
        <source>no</source>
        <translation>нет</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>да</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Настроить</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>Ваша система не нуждается в дополнительной настройке, вы можете продолжить, нажав кнопку</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>При проверке системы возникло несколько замечаний, разрешив которые вы улучшите производительность системы или получите доступ к дополнительным возможностям. Пожалуйста, просмотрите нижеследующие результаты проверки, для получения более подробной информации о том, что требуется для этого сделать. Каждое замечание содержит инструкции по устранению проблемы.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>После того как вы устраните все проблемы, нажмите на кнопку</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Перезапуск Проверки Системы</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>для перезапуска процедуры проверки системы. . Это рекомендуется делать после изменения системных настроек, для выявления критических ошибок. Также вы можете нажать кнопку</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Проверить снова</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>для перезапуска процедуры точной настройки системы. Конечно, если вы желаете, вы можете пропустить этот шаг и перейти к следующему шагу, нажав кнопку</translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Разрешение вопросов</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Ошибка при записи</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>Программа установки не может сохранить данные в файл.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>Программа установки не может получить право записи в каталог</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>. Это необходимо для отключения запуска программы установки при следующей загрузке. Инструкции по устранению проблемы можно прочитать здесь</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>чтобы разрешить доступ к нужным файлам. После их устранения нажмите кнопку</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Попробовать снова</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation>Другой способ - ручное отключение, путем редактирования в файле &lt;i&gt;settings/site.ini&lt;/i&gt; следующих строк:</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Заменить вторую строку</translation>
    </message>
    <message>
        <source>to</source>
        <translation>на</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>Программа установки теперь отключена, щелкните</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>чтобы вернуться обратно к сайту.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Вы можете выбрать любой из указанных вариантов</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>sendmail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation>Отправка e-mail письма не удалась</translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation>Ошибка при отправке регистрационного письма с использованием</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Поздравляем, eZ publish успешно установлен на вашем компьютере.</translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>Официальный сайт eZ publish</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>Отчеты об ошибках eZ publish</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>Теперь вы должны выбрать языки, которые будут поддерживаться на вашем сайте.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Выберите язык и нажмите на кнопку</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Итоги</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>, или же кнопку</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Детальная настройка языков</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>для настройки дополнительных языковых параметров.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>Пришло время выбрать языки, которые должен поддерживать ваш сайт. Выберите основной язык и отметьте любые дополнительные языки.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Когда вы закончите, нажмите на кнопку</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>Указанные вами языки, позволят определить, какие кодировки будут использоваться на вашем сайте.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Название языка</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Выбор</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>Теперь вы можете настроить дополнительные параметры языков. Дополнительные параметры предоставляют возможность более точно настроить параметры выбранных языков, например, добавить поддержку символа евровалюты или же настроить форматов даты и времени. Настройка дополнительных параметров необязательна, и вы можете спокойно пропустить это шаг. Когда вы закончите, нажмите на кнопку</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>Теперь вы можете настроить дополнительные параметры языков. Дополнительные параметры предоставляют возможность более точно настроить параметры выбранных языков, например, добавить поддержку символа евровалюты или же настроить форматов даты и времени. Настройка дополнительных параметров необязательна, и вы можете спокойно пропустить это шаг. Когда вы закончите, нажмите на кнопку</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Зарегистрироваться</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Пропустить регистрацию</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>Какой тип поддержки языковых опций должен быть на вашем сайте. Выбор типа поддержки определяется выбором языка и кодировки.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Одноязычный (один язык)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Многоязычный (несколько языков в одной кодировке)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Многоязычный (с использованием Unicode, без ограничений)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Региональные настройки</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Здесь собрана итоговая информация о всех базовых настройках вашего сайта. Если они вас устраивают, то нажмите на кнопку</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Настройка Базы Данных</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>Если вы хотите что-то изменить, нажмите на кнопку</translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Начать заново</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation>которая перезапустит процедуру сбора информации (текущие настройки сохраняются).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Настройки базы данных</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>База данных</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Драйвер</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Поддержка Unicode</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Языковые настройки</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Тип языка</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Одноязычный</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Многоязычный</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Языки</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>При проверке системы, никаких проблем обнаружено не было. Вы можете продолжить нажав кнопку</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Дополнительные настройки</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Пожалуйста, внимательно просмотрите результаты, для получения дополнительной информации по возникшим проблемам.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>Каждая проблема содержит инструкции по ее устранению.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>Database choice</source>
        <translation>Выбор Базы Данных</translation>
    </message>
    <message>
        <source>The database would not accept the connection, please review your settings and try again.</source>
        <translation>Не удается соединиться с  СУБД, проверьте настройки соединения и попробуйте еще раз.</translation>
    </message>
    <message>
        <source>Password entries did not match.</source>
        <translation>Пароли не совпадают.</translation>
    </message>
    <message>
        <source>The selected database was not empty, please choose from the alternatives below.</source>
        <translation>Выбранная вами БД не пуста, пожалуйста, выберите один из нижеследующих вариантов действий.</translation>
    </message>
    <message>
        <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
        <translation>Указанный вами пользователь не имеет доступа ни к одной из баз данных. Смените пользователя или создайте для него отдельную БД.</translation>
    </message>
    <message>
        <source>Database initalization</source>
        <translation>Инициализация базы данных</translation>
    </message>
    <message>
        <source>Email settings</source>
        <translation>Настройки электронной почты</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Language options</source>
        <translation>Языковые настройки</translation>
    </message>
    <message>
        <source>Registration</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Securing site</source>
        <translation>Настройки безопасности</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Доступ к сайту</translation>
    </message>
    <message>
        <source>Site details</source>
        <translation>Детальные настройки сайта</translation>
    </message>
    <message>
        <source>No templates choosen.</source>
        <translation>Шаблон не выбран.</translation>
    </message>
    <message>
        <source>Site template selection</source>
        <translation>Выбор шаблона для сайта</translation>
    </message>
    <message>
        <source>System check</source>
        <translation>Проверка системы</translation>
    </message>
    <message>
        <source>Welcome to eZ publish</source>
        <translation>Добро пожаловать в систему eZ publish</translation>
    </message>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>База данных готова к инициализации, нажмите на кнопку %1.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Продолжить</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>Программа установки не осуществляет обновление старых версий eZ publish (например 2.2.7), если вы оставите данные &apos;как есть&apos;. Это важно для тех, кто уже имеет данные в БД и не хочет их потерять. Если у вас есть данные созданные в eZ publish 3.0 (например RC release) вы должны пропустить процедуру инициализации БД и осуществить обновление структуры БД вручную.</translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Продолжить с удалением старых данных.</translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Оставить данные и пропустить процедуру инициализации.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>Подождите, производится инициализация базы данных. Это может занять некоторое время, так что будьте терпеливы и дождитесь завершения загрузки новой страницы.</translation>
    </message>
    <message>
        <source>Choose database system</source>
        <translation>Выберите СУБД</translation>
    </message>
    <message>
        <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
        <translation>Для поддержки Unicode в eZ publish требуется PostgreSQL или MySQL версии не ниже 4.1.</translation>
    </message>
    <message>
        <source>More information about eZ publish and unicode support can be found %1.</source>
        <translation>Дополнительная информация о поддержке Unicode в eZ publish  может быть найдена %1.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>link to unicode info</comment>
        <translation>здесь</translation>
    </message>
    <message>
        <source>The database was succesfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>База данных успешно проинициализирована. Теперь вы можете получить доступ к дополнительным настройкам конфигурации вашего сайта.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Нажмите кнопку %1 для запуска процедуры настройки.</translation>
    </message>
    <message>
        <source>Database initialization</source>
        <translation>Инициализация базы данных</translation>
    </message>
    <message>
        <source>PostgreSQL user name and password is not tested until database names are selected.</source>
        <translation>Имя пользователя и пароль СУБД PostgreSQL не могут быть протестированы, пока вы не выберете имена баз данных.</translation>
    </message>
    <message>
        <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
        <translation>Если вы используете MySQL и не знаете точно, что надо указывать в поле сокета БД, просто оставьте это поле пустым</translation>
    </message>
    <message>
        <source>which must be available on the server or</source>
        <translation>которые должны быть доступны на сервере или</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
        <translation>которые должны отвечать за отправку электронной почты. Если вы неуверенны, проконсультируйтесь у вашего хостинг провайдера. Некоторые провайдеры не поддерживают</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>User site</source>
        <translation>Общедоступный сайт</translation>
    </message>
    <message>
        <source>Admin site</source>
        <translation>Сайт администратора</translation>
    </message>
    <message>
        <source>Admin e-mail</source>
        <translation>E-mail администратора</translation>
    </message>
    <message>
        <source>Make sure to visit the %1 and the %2 web site.</source>
        <translation>Удостоверьтесь посетив %1 и %2.</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <comment>eZ publish 3 link</comment>
        <translation>eZ publish</translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
        <translation>Чтобы получить доступ к вашему новому сайту, щелкните на ссылке %ezlink или нажмите кнопку %donebutton. Наслаждайтесь одной из самых успешных систем управления веб-контентом!</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file %filename and look for a line that says:</source>
        <translation>Если вы хотите перезапустить программу установки, отредактируйте файл %filename в следующих строках:</translation>
    </message>
    <message>
        <source>Change the second line from %false to %true.</source>
        <translation>Замените значение во второй строке %false на %true.</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>Имя пользователя-администратора по умолчанию : %1, пароль по умолчанию %2.</translation>
    </message>
    <message>
        <source>No Unicode support</source>
        <translation>Поддержка Unicode отсутствует</translation>
    </message>
    <message>
        <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won&apos;t work.</source>
        <translation>Выбирайте только те языки, которые используют одинаковые кодовые страницы, например: Английский и Норвежский будет работать вместе, когда Английский и Русский вместе работать не будут.</translation>
    </message>
    <message>
        <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
        <translation>Удостоверьтесь, что СУБД правильно сконфигурирована, для использования Unicode, или же скачайте последнюю версию этой СУБД, которая поддерживает Unicode.</translation>
    </message>
    <message>
        <source>Primary/Additional</source>
        <translation>Основной/Дополнительный</translation>
    </message>
    <message>
        <source>eZ publish supports multiple languages.</source>
        <translation>eZ publish поддерживает широкий диапазон языков.</translation>
    </message>
    <message>
        <source>These and other additional languages can also be installed later.</source>
        <translation>Эти и другие дополнительные языки могут быть установлены позже.</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>language information link</comment>
        <translation>документация</translation>
    </message>
    <message>
        <source>Back</source>
        <comment>back button in installation</comment>
        <translation>Назад</translation>
    </message>
    <message>
        <source>Refresh</source>
        <comment>Refresh button in installation</comment>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>next button in installation</comment>
        <translation>Далее</translation>
    </message>
    <message>
        <source>Site registration</source>
        <translation>Регистрация сайта</translation>
    </message>
    <message>
        <source>The registration email:</source>
        <translation>Адрес электронной почты для регистрации:</translation>
    </message>
    <message>
        <source>By sending registration the following data will be sent to eZ systems</source>
        <translation>eZ publish отправит нижеследующие регистрационные данные в eZ systems</translation>
    </message>
    <message>
        <source>Site access configuration</source>
        <translation>Настройка доступа к сайту</translation>
    </message>
    <message>
        <source>URL (recommended)</source>
        <translation>URL (рекомендуется)</translation>
    </message>
    <message>
        <source>Hostname. Note: Requires DNS setup.</source>
        <translation>По имени узла. Замечание: требует настройки DNS.</translation>
    </message>
    <message>
        <source>The path determines access.</source>
        <translation>Определение доступа по пути.</translation>
    </message>
    <message>
        <source>e.g. %adminsite and %usersite</source>
        <translation>например %adminsite и %usersite</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <source>The port number determines access.*</source>
        <translation>Доступ определяется по номеру порта.*</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Имя узла</translation>
    </message>
    <message>
        <source>The hostname determines access.*</source>
        <translation>Определение доступа по доменному имени узла (hostname) .*</translation>
    </message>
    <message>
        <source>online documentation</source>
        <comment>site access documentation link</comment>
        <translation>онлайновая документация</translation>
    </message>
    <message>
        <source>Do not use &apos;admin&apos;, &apos;user&apos; or equal site access values. Please change site illegal access values on sites indicated by *</source>
        <translation>Не используйте &apos;admin&apos;, &apos;user&apos; или схожие значения доступа к сайту. Пожалуйста, измените неверные значения доступа к сайту, обозначенные символом *</translation>
    </message>
    <message>
        <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
        <translation>Вы выбрали одну БД для двух или более шаблонов сайтов. Пожалуйста, исправьте все вхождения помеченные символом *</translation>
    </message>
    <message>
        <source>One or more of your databases already contain data.</source>
        <translation>Одна или несколько БД уже содержит данные.</translation>
    </message>
    <message>
        <source>Select what to do from the drop down box(es).</source>
        <translation>Выберите, что вы хотите сделать из выпадающего(их) списка(ов).</translation>
    </message>
    <message>
        <source>Site url</source>
        <translation>URL сайта</translation>
    </message>
    <message>
        <source>Leave the data and add new</source>
        <translation>Оставить старые данные и добавить новые</translation>
    </message>
    <message>
        <source>Remove existing data</source>
        <translation>Удалить существующие данные</translation>
    </message>
    <message>
        <source>Leave the data and do nothing</source>
        <translation>Оставить данные и не ничего не трогать</translation>
    </message>
    <message>
        <source>I&apos;ve chosen a new database</source>
        <translation>Выбрать другую БД</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>site access documentation link</comment>
        <translation>документация</translation>
    </message>
    <message>
        <source>Select which sites you would like to install on your system.</source>
        <translation>Укажите, какие сайты вы хотите установить в вашей системе.</translation>
    </message>
    <message>
        <source>The system check found some issues that need to be resolved before the setup can continue.</source>
        <translation>Программа установки обнаружила некоторые проблемы, которые требуют разрешения, перед тем как установка может быть продолжена.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
        <translation>После того как вы устраните проблемы, нажмите на кнопку %1 и перезапустите проверку системы. Вы можете опустить некоторые тесты, убрав выделение у соответствующих галочек.</translation>
    </message>
    <message>
        <source>Ignore this test</source>
        <translation>Игнорировать данный тест</translation>
    </message>
    <message>
        <source>Welcome to eZ publish %1</source>
        <translation>Добро пожаловать в eZ publish %1</translation>
    </message>
    <message>
        <source>This section will contain information/help about each step in the setup wizard.</source>
        <translation>Данный раздел содержит информацию и справку о каждом шаге в программе установки.</translation>
    </message>
    <message>
        <source>The summary section below will contain information about configured settings.</source>
        <translation>Итоговый раздел будет содержать информацию обо всех настройках системы.</translation>
    </message>
    <message>
        <source>Information about how to set up eZ publish manually is available %1.</source>
        <translation>Информация о том, как настроить eZ publish вручную, доступна %1.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>manual installation link</comment>
        <translation>здесь</translation>
    </message>
    <message>
        <source>SMTP is recommended for MS Windows users.</source>
        <translation>Интерфейс SMTP рекомендуется для пользователей Microsoft Windows.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval.</source>
        <translation>Данный e-mail адрес используется для отправки важных замечаний, таких как регистрация нового пользователя или оповещений об изменениях контента.</translation>
    </message>
    <message>
        <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
        <translation>Почти все современные Unix-системы поддерживают sendmail, а пользователи Windows должны выбирать SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP&lt;/b&gt;: If you&apos;re unsure what to enter, take a look at the settings in your e-mail application.</source>
        <translation>&lt;b&gt;SMTP&lt;/b&gt;: Если вы не уверенны, что нужно вводить в это поле, загляните в настройки вашей программы по работе с электронной почтой.</translation>
    </message>
    <message>
        <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
        <translation>Подсказка: Чтобы не забыть адреса новых сайтов - сохраните эту страницу на диске или же выпишите все адреса отдельно.</translation>
    </message>
    <message>
        <source>forums</source>
        <comment>forum link</comment>
        <translation>форумы</translation>
    </message>
    <message>
        <source>Port*</source>
        <translation>Порт*</translation>
    </message>
    <message>
        <source>* Requires web server setup.</source>
        <translation>* Требуется настройка веб сервера.</translation>
    </message>
    <message>
        <source>Hostname*</source>
        <translation>Имя узла*</translation>
    </message>
    <message>
        <source>* Requires DNS setup.</source>
        <translation>* Требуется настройка DNS.</translation>
    </message>
    <message>
        <source>User path</source>
        <translation>Путь для пользовательского сайта</translation>
    </message>
    <message>
        <source>User port</source>
        <translation>Порт для пользовательского сайта</translation>
    </message>
    <message>
        <source>User hostname</source>
        <translation>Имя узла пользовательского сайта</translation>
    </message>
    <message>
        <source>Admin path</source>
        <translation>Путь для сайта администратора</translation>
    </message>
    <message>
        <source>Admin port</source>
        <translation>Порт для сайта администратора</translation>
    </message>
    <message>
        <source>Admin hostname</source>
        <translation>Имя узла сайта для администратора</translation>
    </message>
    <message>
        <source>Next &amp;gt;</source>
        <translation>Далее &amp;gt;</translation>
    </message>
    <message>
        <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the %documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that Postgre 7.2 and 7.4 are not supported.</source>
        <translation>Удостоверьтесь, что вы ввели правильные имя пользователя и пароль. Проверьте настройки СУБД PostgreSQL.&lt;br&gt;%documentation может вам помочь, найдите информацию по этим вопросах:&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that Postgre 7.2 and 7.4 are not supported.</translation>
    </message>
    <message>
        <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
        <translation>В вашей системе найдены сразу две СУБД MySQL и PostgreSQL. Выберите, какую из них вы хотите использовать.</translation>
    </message>
    <message>
        <source>eZ publish supports both MySQL and PostgreSQL.</source>
        <translation>eZ publish поддерживает обе СУБД: MySQL и PostgreSQL.</translation>
    </message>
    <message>
        <source>Please input database access information in the form below.</source>
        <translation>Пожалуйста, введите информацию для доступа к БД в нижеследующую форму.</translation>
    </message>
    <message>
        <source>Servername:</source>
        <translation>Имя сервера:</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Имя пользователя:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>Socket (optional):</source>
        <translation>Сокет (необязателен):</translation>
    </message>
    <message>
        <source>If you don&apos;t have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you&apos;re unsure about how to create a database.</source>
        <translation>Если вы не имеете доступа к БД, вы должны получить его сейчас. eZ publish может держать несколько сайтов, каждому из которых  требуется собственная БД. Это подразумевает, что вы должны создать столько баз, сколько вам потребуется сайтов. Пожалуйста, обратитесь к документации по вашей СУБД, чтобы узнать, как создать новую БД.</translation>
    </message>
    <message>
        <source>Outgoing E-mail</source>
        <translation>Исходящий E-mail</translation>
    </message>
    <message>
        <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
        <translation>Данная секция предназначена для настройки eZ publish по отправке исходящей электронной почты.</translation>
    </message>
    <message>
        <source>There are two options:&lt;br&gt;- Direct delivery through sendmail (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
        <translation>Здесь есть два варианта:  &lt;br&gt; - Прямая отправка с использованием sendmail,  &lt;br&gt; - Непрямая отправка с использованием SMTP почтового сервера.</translation>
    </message>
    <message>
        <source>E-mail delivery</source>
        <translation>Доставка эл. почты</translation>
    </message>
    <message>
        <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
        <translation>Система eZ publish использует e-mail транспорт для отправки сообщений, т.к. регистрация новых пользователей, оповещения для совместной работы. Для Linux/UNIX систем надо использовать sendmail. Для Windows систем необходимо использовать SMTP интерфейс.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the sendmail transfer agent. The sendmail binary is usually available on most Linux/UNIX systems. If sendmail is not available then SMTP should be used.</source>
        <translation>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;Программа для &quot;прямой&quot; отправки почты. Доступна на большинстве Linux/UNIX систем. Если эта программа отсутствует, нужно использовать SMTP интерфейс.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
        <translation>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Почта отправляется посредством SMTP протокола через почтовый сервер. Как минимум, вы должны указать адрес сервера. Подсказка: посмотрите настройки вашей программы для работы с электронной почтой.</translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following sites. You will find the username and password mentioned for each site.</source>
        <translation>eZ publish была установлена вместе с комплектом демонстрационных сайтов. Вы найдете упоминание об именах пользователей и паролях для каждого сайта.</translation>
    </message>
    <message>
        <source>Language support</source>
        <translation>Языковая поддержка</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the primary language, and the checkboxes to choose additional languages. You may choose more than one additional language.</source>
        <translation>Используйте переключатели, чтобы выбрать основной язык, и флажки, чтобы выбрать дополнительные языки. Вы можете выбрать несколько дополнительных языков.</translation>
    </message>
    <message>
        <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
        <translation>Выбранные вами языки будут использованы для определения кодировок, форматов даты и времени и т.д.</translation>
    </message>
    <message>
        <source>For more information about language customization, please refer to the %1.</source>
        <translation>Для дополнительной информации о настройке языковых опций, пожалуйста обратитесь к %1.</translation>
    </message>
    <message>
        <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited emails.</source>
        <translation>Если вы хотите, вы можете зарегистрировать ваш сайт, путем отправки некоторой информации в eZ systems. Никаких конфиденциальных данных передаваться не будет, а ваш e-mail не будет использоваться в незаконных целях.</translation>
    </message>
    <message>
        <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
        <translation>Если вы хотите, вы можете добавить ваши комментарии, которые будут добавлены в регистрационное письмо.</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <source>Sending out the email and generating your site might take a couple of seconds. Please wait until the next page loads. Clicking the button again will only send out duplicate emails, and may corrupt the installation.</source>
        <translation>Для отправки регистрационного письма и создания вашего сайта может потребоваться некоторое время. Пожалуйста дождитесь загрузки следующей страницы. Повторное нажатие кнопки повлечет за собой дублирование писем и может нарушить процесс инсталляции.</translation>
    </message>
    <message>
        <source>Send registration</source>
        <translation>Зарегистрироваться</translation>
    </message>
    <message>
        <source>System details (OS type, etc)</source>
        <translation>Детально о системе (тип ОС и т.д.)</translation>
    </message>
    <message>
        <source>The test results</source>
        <translation>Результаты теста</translation>
    </message>
    <message>
        <source>The database type</source>
        <translation>Тип базы данных</translation>
    </message>
    <message>
        <source>The site name</source>
        <translation>Название сайта</translation>
    </message>
    <message>
        <source>The url of the site</source>
        <translation>URL сайта</translation>
    </message>
    <message>
        <source>Languages chosen</source>
        <translation>Выбранные языки</translation>
    </message>
    <message>
        <source>This data will help to improve future releases of eZ publish.</source>
        <translation>Эти данные помогут улучшить будущие версии eZ publish.</translation>
    </message>
    <message>
        <source>Site security</source>
        <translation>Настройки безопасности сайта</translation>
    </message>
    <message>
        <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
        <translation>Ваш сайт работает не в режиме виртуального хоста, это потенциально небезопасно. Рекомендуем запускать систему eZ publish в режиме виртуального хоста. Если вы не имеете возможности использовать этот режим, вы должны следовать нижеследующим инструкциям по установке и настройке .htaccess файла. Данный файл позволяет ограничить доступ к определенным файлам.</translation>
    </message>
    <message>
        <source>If you have shell access, you can run the following commmands.</source>
        <translation>Если вы имеете доступ к командной консоли, вы можете выполнить следующие команды.</translation>
    </message>
    <message>
        <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
        <translation>Если вы не имеете доступа к командной консоли, вы можете скопировать файл используя FTP клиента или попросить сделать это вашего хостинг провайдера.</translation>
    </message>
    <message>
        <source>This security tweak takes care of protecting configuration files and other important files.</source>
        <translation>Данная дополнительная настройка безопасности позволит защитить ваши конфигурационные файлы а также другую важную информацию.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
        <translation>Пожалуйста выберите метод доступа к сайту, который вы планируете использовать. Метод доступа определяет как пользователи будут получать доступ  к сайту из своих браузеров. Если вы неуверенны, выберите опцию URL.</translation>
    </message>
    <message>
        <source>For more detailed information on site access, please refer to the %1</source>
        <translation>Для более подробной информации о доступе к сайту, читайте здесь: %1</translation>
    </message>
    <message>
        <source>This page lets you modify information about the sites you&apos;ve chosen to install. In addition, it also lets you choose a database for each site.</source>
        <translation>Данная страница позволит вам модифицировать информацию о сайта, которые вы выбрали для установки. Также вы можете выбрать базу данных для каждого сайта.</translation>
    </message>
    <message>
        <source>You may modify the details for each site.</source>
        <translation>Вы можете подкорректировать дополнительную информацию указанных сайтов.</translation>
    </message>
    <message>
        <source>For more information about how to configure site access, please refer to the %1</source>
        <translation>Для более подробной информации о доступе к сайту, читайте здесь: %1</translation>
    </message>
    <message>
        <source>Use the refresh button to update the database listing.</source>
        <translation>Используйте кнопку &quot;Обновить&quot; для того чтобы обновить списки баз данных.</translation>
    </message>
    <message>
        <source>Site packages</source>
        <translation>Пакеты сайтов</translation>
    </message>
    <message>
        <source>Each package will create a unique web site.</source>
        <translation>Каждый пакет создаст уникальный веб-сайт.</translation>
    </message>
    <message>
        <source>Since each web site is unique, each package requires a unique database.</source>
        <translation>Поскольку каждый сайт уникален, каждому пакету необходимо указать свою БД.</translation>
    </message>
    <message>
        <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Здесь указаны несколько важных проблемы, которые необходимо разрешить. Список вопросов/проблем указан ниже. Каждый раздел содержит описание и варианты примерных/рекомендуемых решений.</translation>
    </message>
    <message>
        <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
        <translation>Когда все проблемы/вопросы разрешены, вы можете нажать кнопку &quot;Далее&quot;. Проверка системы запустится еще раз. Если все в порядке, программа установки перейдет к следующему шагу. Если возникнут снова, страница проверки системы появиться снова.</translation>
    </message>
    <message>
        <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
        <translation>Некоторые проблемы можно проигнорировать, установив флажок &lt;i&gt;Игнорировать этот тест&lt;/i&gt; (не рекомендуется).</translation>
    </message>
    <message>
        <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
        <translation>Появилась страница проверки системы. Это подразумевает, что возникло несколько проблем/вопросов.</translation>
    </message>
    <message>
        <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
        <translation>Данные проблемы необходимо устранить/разрешить, иначе  eZ publish не будет функционировать в нормальном режиме.</translation>
    </message>
    <message>
        <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
        <translation>Проблемы связанные с файловой системы могут быть легко исправлены копированием, вставкой и запуском указанных команд, в командной консоли.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
        <translation>Добро пожаловать в систему управления контентом и среда разработки eZ publish. Данный мастер поможет вам установить  eZ publish. Нажмите кнопку &lt;i&gt;Далее&lt;/i&gt; для продолжения.</translation>
    </message>
    <message>
        <source>No data will be stored in the database until the final step of the setup.</source>
        <translation>Никаких данные не будут сохранены в БД, пока программа установки не достигнет финальной стадии.</translation>
    </message>
    <message>
        <source>Server name: </source>
        <translation>Имя сервера:</translation>
    </message>
    <message>
        <source>Username (optional): </source>
        <translation>Имя пользователя (необязательно):</translation>
    </message>
    <message>
        <source>Password (optional): </source>
        <translation>Пароль (необязательно):</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>Если вам нужна помощь или консультации по работе с eZ publish, вы можете загрузить эту ссылку %ezlink и получить помощь на форуме.
Если вы обнаружили ошибку, пожайлуста, сообщите о ней здесь: %buglink.
С вашей помощью мы сможем исправить ошибки в eZ publish и добавить новые возможности.</translation>
    </message>
    <message>
        <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
        <translation>СУБД которую вы указали не поддерживает Unicode, что подразумевает что  вы не можете установить поддержку все те языки которые вы выбрали.
Чтобы устранить данную проблему вы должны проделать следующие шаги:</translation>
    </message>
    <message>
        <source>Port. Note: Requires web server configuration </source>
        <translation>Порт. Замечание: Требует настройки web-сервера</translation>
    </message>
    <message>
        <source>Database not empty: </source>
        <translation>База данных не пуста:</translation>
    </message>
    <message>
        <source>System finetuning</source>
        <translation>Дополнительная настройка системы</translation>
    </message>
    <message>
        <source>Finetune</source>
        <comment>Finetune button in installation</comment>
        <translation>Дополнительная настройка</translation>
    </message>
    <message>
        <source>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</source>
        <translation>Вы можете также  настроить дополнительные параметры вашей системы, нажав кнопку &lt;i&gt;Дополнительные настройки&lt;/i&gt; вместо &lt;i&gt;Далее&lt;/i&gt;, если вы хотите узнать про дополнительные возможности по настройке вашей системы.</translation>
    </message>
    <message>
        <source>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Здесь перечислены некоторые проблемы, которые должны быть разрешены для достижения максимальной производительности и доступа к дополнительным функциям системы. Весь список проблем представлен ниже. Каждая секция содержит описание проблемы и рекомендуемое/предполагаемое ее решение.</translation>
    </message>
    <message>
        <source>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</source>
        <translation>После того как проблемы устранены, вы можете нажать кнопку &lt;i&gt;Дополнительные настройки&lt;/i&gt; для продолжения. Проверка системы будет запущена еще раз. Если все в порядке, программа установки перейдет к следующему шагу. Если какие-то проблемы не были устранены, то вы вернетесь на страницу дополнительных настроек.</translation>
    </message>
    <message>
        <source>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</source>
        <translation>Если вы не желаете устранять данные проблемы сейчас, просто нажмите &lt;i&gt;Далее&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</source>
        <translation>Это страница дополнительных настроек. Появление данной страницы подразумевает что обнаружены некоторые проблемы, устранив которые вы улучшите производительность системы и получите доступ к ее дополнительным функциям.</translation>
    </message>
    <message>
        <source>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</source>
        <translation>Данная проблема не является критичной, т.е. eZ publish будет работать в нормальном режиме и без их устранения.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</source>
        <translation>Добро пожаловать в eZ publish - систему управления контентом и средой разработки. Данный мастер призван что бы помочь вам в установке eZ publish на вашем компьютере.&lt;br/&gt;
Ваша система не является оптимальной для работы eZ publish, если вы желаете настроить систему оптимально, нажмите кнопку &lt;i&gt;Дополнительные настройки&lt;/i&gt; и вам будет показана страничка с описание проблем и вариантами их решения.&lt;br/&gt;Если вы не хотите делать это сейчас, то нажмите кнопку &lt;i&gt;Далее&lt;/i&gt;.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Пример</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Конструктор, по умолчанию ничего не делает.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>возвращает  массив с именем оператора шаблона.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Запускает функцию PHP для оператора очистки и модифицирует $operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Пример кода, данный код должен быть исправлен на реальный код оператора, по умолчанию просто обрезает текст.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Не найден обработчик работы с БД</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Ваша версия PHP не поддерживает все СУБД, которые поддерживает eZ publish.</translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>Не смотря на это, eZ publish будет работать, но это подразумевает что в  этом случае вам потребуется поддержка данной базы данных.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Также некоторые базы данных имеют расширенный функционал, например поддержка дополнительных кодовых страниц и др.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Для поддержки дополнительных СУБД вам понадобиться перекомпиляция PHP из исходных кодов. Ключи для компиляции указаны ниже.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Отсутствует поддержка СУБД</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>Не найдены драйвера ни для одной из поддерживаемых eZ publish СУБД. eZ publish обязательно требуется Система Управления Базами Данных, для хранения данных. Без нее система не запустится.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Для включения поддержки необходимой СУБД, вам необходимо перекомпилировать PHP из исходных кодов. Ключи для компиляции указаны ниже.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Не прав для доступа к папкам</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish не может получить доступ к некоторым важным каталогам, без записи информации в которые программа установки eZ publish не может быть корректно завершена.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Рекомендуется устранить данную проблему, запустив в команды указанные ниже.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Операторы командного процессора</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Отсутствует поддержка средств преобразования растровых изображений</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>Не найдены средства преобразования растровых изображений. Это подразумевает, что eZ publish не сможет масштабировать изображения и определять их тип. Это жизненно важная функция в eZ publish и система должна ее поддерживать.</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>оператор шаблонов будет недоступен.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Примечание:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Последующие реализации eZ publish будут содержать расширенную функциональность по работе с изображениями, с иcпользование расширения PHP - imageGD.</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Отсутствует програма ImageMagick</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>Программа ImageMagick недоступна eZ publish. Без нее eZ publish не сможет работать с изображениями, в случае если расширение PHP imageGD будет недоступно.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Если вы знаете где данная программа проинсталлирована (исполнимый файл называется </translation>
    </message>
    <message>
        <source>or</source>
        <translation>или</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>) - укажите этот каталог в нижеследующем поле и перезапустите проверку (Используйте в качестве разделителя символ</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>двоеточие</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>точка с запятой</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Инсталляция</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>Программу ImageMagick можно скачать здесь</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Отсутствует расширение PHP - MBString</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>По умолчанию eZ publish поставляется  с хорошим списком поддерживаемых кодовых страниц, и конечно в случае реализации такой поддержки на PHP - это может серьезно повлиять на производительность системы в целом. К счастью eZ publish поддерживает расширение PHP - MBString для работы с некоторыми кодировками.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>Включая расширение MBString вы позволите eZ publish работать с большим количеством кодировок (т.к. Unicode и iso-8859-*) и делать это гораздо быстрее чем без него. Это рекомендуется делать для многоязыковых сайтов и сайтов требующим поддержки экзотических кодировок.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation>Полный список поддерживаемых MBString кодировок:</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>Установка расширения MBString может быть сделана перекомпиляцией PHP с опцией</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Дополнительная информация о включении расширений PHP может быть найдена на сайте</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>Не включайте перекрытие функций MBString, eZ publish использует это расширение только в случае прямой необходимости.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>Опция PHP</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>включена</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish будет работать с включенной опцией, но это приведет к некоторому снижению производительности, поскольку все входящие переменные должны будут обратно конвертироваться</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>в нормальное состояние</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Слишком старая версия PHP</translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>, не соответствует минимальным требованиям</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>Более новая версия PHP может быть скачана здесь</translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation>, но все же настоятельно рекомендуем скачать более новую версию, например 4.2.3. </translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish не может осуществить операцию записи в каталог</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>. Это необходимо чтобы программа установки отключила свой повторный запуск при следующей загрузке.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>Отсутствует расширение PHP - zlib</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>eZ publish не может получить доступ к расширению zlib. Без него eZ publish не сможет установить демо-данные. Тем не менее, если вы не хотите устанавливать демо-данные, вы можете спокойно проигнорировать эту проблему.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>Для поддержки расширения zlib вам понадобится перекомпилировать PHP из исходных кодов. Вы должны будете сконфигурировать PHP со следующими опциями</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Дополнительная информация на эту тему, может быть надена здесь</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Загрузка файлов на сервер отключена</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>Загрузка файлов на сервер отключена, что подразумевает что eZ publish не сможет работать с подгружаемыми с компьютера пользователя файлами. Все остальные функции eZ publish будут работать нормально, но настоятельно рекомендуем включить опцию загрузки файлов на сервер в конфигурационном файле PHP.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Конфигурация</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Включить загрузку файлов на сервер можно установив параметр %1 в файле php.ini. Ознакомьтесь с руководством по PHP по установке конфигурационных параметров</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Дополнительная информация по включению расширений PHP может быть найдена здесь %1 и здесь %2</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Дополнительная информация по данной теме можете быть найдена здесь %1.</translation>
    </message>
    <message>
        <source>php.ini example:</source>
        <translation>Пример php.ini:</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following:</source>
        <translation>Альтернативный вариант: вы можете создать файл с именем %1 в  каталоге куда был установлен eZ publish  и добавить в него следующие строки:</translation>
    </message>
    <message>
        <source>.htaccess example:</source>
        <translation>Пример файла .htaccess:</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>Опция PHP %1 включена</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish будет работать с включенной опцией, но это приведет к некоторому снижению производительности, поскольку все входящие переменные будут объявляться глобальными при каждом запуске скрипта.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>Рекомендуем отключить данную опцию. Для ее отключения исправьте в конфигурационном файле %1 и установите %2 в %3.</translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>Безопасный режим в PHP включен</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are:</source>
        <translation>eZ publish может работать в безопасном режиме, но при этом вам будут недоступны некоторые его дополнительные возможности. Это может привести к следующему:</translation>
    </message>
    <message>
        <source>enter the following into your httpd.conf file.</source>
        <translation>введите нижеследующие строки в ваш httpd.conf файл.</translation>
    </message>
    <message>
        <source>Remember to restart your web server afterwards.</source>
        <translation>Не забудьте впоследствии перезагрузить ваш web-сервер.</translation>
    </message>
    <message>
        <source>Insufficient execution time allowed to install eZ publish</source>
        <translation>Установлено слишком маленькое ограничение времени исполнения скриптов для установки eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a execution time limit of %1.</source>
        <translation>eZ publish будет работать некорректно с ограничением времени исполнения скриптов %1.</translation>
    </message>
    <message>
        <source>It&apos;s highly recommended that you fix this.</source>
        <translation>Настоятельно рекомендуем устранить данную проблему.</translation>
    </message>
    <message>
        <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
        <translation>Найдите основной конфигурационный файл PHP - php.ini. В unix системах, он обычно расположен в каталоге /etc/php.ini. Для ОС Windows проверьте каталог где установлен PHP.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
        <translation>Откройте файл php.ini и установите значение параметр  &apos;max_execution_time&apos;  в минимально допустимое - %1,  а зетем нажмите %2 </translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
        <translation>Если вы запускаете eZ publish в распределенной среде хостинг-провайдера, свяжитесь с вашим провайдером для осуществления данных изменений в конфигурации</translation>
    </message>
    <message>
        <source>Missing imagegd2 extension</source>
        <translation>Отсутствует расширение PHP - imageGD2</translation>
    </message>
    <message>
        <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>eZ publish не может получить доступ к расширению imageGD2. Без него eZ publish сможет преобразовывать изображения только при помощи ImageMagick и </translation>
    </message>
    <message>
        <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Для включения поддержки imageGD2 вам необходимо будет перекомпилировать PHP из исходных кодов с соответствующими опциями. Более подробную информацию можно получить здесь </translation>
    </message>
    <message>
        <source>Insufficient memory allocated to install eZ publish</source>
        <translation>Выделено недостаточно оперативной памяти для установки eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a memory limit of %1.</source>
        <translation>eZ publish не будет работать корректно с ограничением памяти в %1.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
        <translation>Откройте конфигурационный файл php.ini и измените значение параметра &apos;memory_limit&apos; на минимально допустимое значение - %1, и затем нажмите %2</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
        <translation>Рекомендуем отключить данную опцию. Для ее отключения, отредактируйте конфигурационный файл %phpini  и установите значения параметров &apos;%magic_quotes_gpc&apos; и &apos;%magic_quotes_runtime&apos; в &apos;%offtext&apos;.</translation>
    </message>
    <message>
        <source>eZ publish will not work properly with this option on.</source>
        <translation>eZ publish не будет работать корректно с когда данная опция включена.</translation>
    </message>
    <message>
        <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
        <translation>Для ее отключения отредактируйте конфигурационный файл %phpini  и установите значение параметра &apos;%magic_quotes_runtime&apos; в &apos;%offtext&apos;.</translation>
    </message>
    <message>
        <source>Unstable PHP version</source>
        <translation>Нестабильная версия PHP</translation>
    </message>
    <message>
        <source>, is known to be unstable</source>
        <translation>, известна как нестабильная</translation>
    </message>
    <message>
        <source>Another version of PHP can be download at</source>
        <translation>Другая версия PHP может быть загружена отсюда</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Ваша версия PHP </translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Вы должны сменить вашу версию на более старую</translation>
    </message>
    <message>
        <source>AcceptPathInfo disabled or running in CGI mode</source>
        <translation>Опция сервера Apache &apos;AcceptPathInfo&apos; отключена или же PHP работает в режиме CGI</translation>
    </message>
    <message>
        <source>You need enable AcceptPathInfo in your Apache config file, if you&apos;re using apache 2.x</source>
        <translation>Вы должны включить опцию &apos;AcceptPathInfo&apos; в конфигурационном файле сервера Apache, в случае если вы используете Apache 2.x</translation>
    </message>
    <message>
        <source>eZ publish will not run in CGI mode, if you&apos;re running apache 1.3.</source>
        <translation>eZ publish не работает в режиме CGI под web-сервером Apache 1.3.</translation>
    </message>
    <message>
        <source>Missing text creation functions</source>
        <translation>Отсутствуют функции для создания текста</translation>
    </message>
    <message>
        <source>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</source>
        <translation>Отсутствуют функции PHP ImageTTFText и ImageTTFBBox. Без этих функций невозможно использование шаблонного оператора &apos;texttoimage&apos;.</translation>
    </message>
    <message>
        <source>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Для включения данных функций вам необходимо перекомпилировать PHP с включением их поддержки. Дополнительную информацию можно прочитать здесь</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation>Всего без НДС:</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Всего с НДС:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Продолжить покупки</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Рассчитаться</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>В вашей корзине нет продуктов</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Подтвердите заказ</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Товары</translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation>Итоговый заказ:</translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation>За товары:</translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation>Всего заказано:</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Просмотр группы</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Добавить правило</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Удалить правило</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Клиенты</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Добавить клиента</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Удалить клиента</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирование правила</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Всего без НДС</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Всего с НДС</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Заказ</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Типы НДС</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Список пожеланий</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Очистить список пожеланий</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Товар</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>НДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без НДС</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с НДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Скидка</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Полная цена без НДС</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Полная цена с НДС</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Группы скидок</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Редактировать группу скидок - %1</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Название группы</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Определенные правила</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Применить к</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Процент скидки</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Сумма за товары</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Список заказов пуст</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Заказ всего</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Зарегистрировать информацию о счете</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Ошибки ввода, заполните все поля</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Фамилия</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
        <translation>Оплата не была совершена из-за неустановленной ошибки. Обратитесь к администрации сайта.</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Итог заказа</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Customer name</comment>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибуты</translation>
    </message>
    <message>
        <source>Rule settings</source>
        <translation>Установки правил</translation>
    </message>
    <message>
        <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Выберите классы, секции, и объекты которые попадают под данное подправило. &apos;Любой&apos; подразумевает, что данное правило подходит ко всем типам элементов.</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Объект</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Не указанно.</translation>
    </message>
    <message>
        <source>Sort Result by</source>
        <translation>Сортировать по</translation>
    </message>
    <message>
        <source>Order Time</source>
        <translation>Время заказа</translation>
    </message>
    <message>
        <source>User Name</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>Ид заказа</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>По возрастанию</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>По возрастанию</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>По убыванию</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>По убыванию</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Сортировать</translation>
    </message>
    <message>
        <source>Order %1</source>
        <translation>Заказ %1</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Ваш бюджет активирован.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Извините, но предоставленный ключ неправильный. Бюджет не был создан.</translation>
    </message>
    <message>
        <source>ez.no: Orderconfirmation %1</source>
        <translation>ez.no: Подтверждение покупки %1</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Удалить элементы</translation>
    </message>
</context>
<context>
    <name>design/standard/shop/view</name>
    <message>
        <source>Choose customers</source>
        <translation>Выберите клиентов</translation>
    </message>
    <message>
        <source>Choose product for discount</source>
        <translation>Выберите товар для скидки</translation>
    </message>
    <message>
        <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Пожалуйста, выберите пользователей, которых вы хотите добавить в группу имеющих скидки %groupname.  

Выберите клиентов и нажмите кнопку %buttonname. 
Вы можете использовать закладки и список часто используемых элементов. 
Щелкните на имени, чтобы увидеть содержимое элемента.</translation>
    </message>
    <message>
        <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
        <translation>Пожалуйста, выберите пользователей, которых вы хотите добавить в группу имеющих скидки %groupname.  

Выберите клиентов и нажмите кнопку %buttonname. 
Вы можете использовать закладки и список часто используемых элементов. 
Щелкните на имени, чтобы увидеть содержимое элемента.</translation>
    </message>
</context>
<context>
    <name>design/standard/templates/</name>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Имя пользователя</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>No workflow</source>
        <translation>Рабочий процесс не указан</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Trigger list</source>
        <translation>Список триггеров</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Рабочий процесс</translation>
    </message>
    <message>
        <source>Module name</source>
        <translation>Имя модуля</translation>
    </message>
    <message>
        <source>Function name</source>
        <translation>Имя функции</translation>
    </message>
    <message>
        <source>Connect type</source>
        <translation>Тип подключения</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Правильный</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Неправильный</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>URL более не является правильным.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>Это значит что данный URL более недоступен или был перемещен.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>URL указывает на %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Последний раз изменен %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>URL не содержит дату изменения</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Последний раз проверен %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>URL не был проверен</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Фильтр</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Последний раз проверен</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменен</translation>
    </message>
    <message>
        <source>Popup</source>
        <translation>Всплывающий</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Новее</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестный</translation>
    </message>
    <message>
        <source>All URLs</source>
        <translation>Все адреса</translation>
    </message>
    <message>
        <source>Invalid URLs</source>
        <translation>Неправильный адрес</translation>
    </message>
    <message>
        <source>Valid URLs</source>
        <translation>Правильные адреса</translation>
    </message>
    <message>
        <source>Information on URL</source>
        <translation>Информация об адресе</translation>
    </message>
    <message>
        <source>Objects which use this link</source>
        <translation>Объект использующий эту ссылку</translation>
    </message>
    <message>
        <source>No object available</source>
        <translation>Нет доступных объектов</translation>
    </message>
    <message>
        <source>version</source>
        <translation>версия</translation>
    </message>
</context>
<context>
    <name>design/standard/url/edit</name>
    <message>
        <source>Editing URL - %1</source>
        <translation>Редактирование адреса %1</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Activate account</source>
        <translation>Активировать счет</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Невозможно зарегистрироваться</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Для регистрации в системе необходимо действительное имя пользователя и пароль.</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Изменить пароль пользователя</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Зарегистрировать пользователя</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Установки пользователя</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Максимальное количество входов в систему</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Действителен</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Пользователь зарегистрирован</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Ваш счет был успешно создан.</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Доступ запрещен</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>У вас нет прав для доступа %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>Зарегистрироваться</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Профайл пользователя</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Редактировать профайл</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Change setting</source>
        <translation>Изменить установки</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>Пожалуйста, введите ваш старый пароль.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>Пароль не совпадает, повторите новый пароль еще раз.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>Пароль успешно обновлен.</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Старый пароль</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Новый пароль</translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation>Повторите пароль</translation>
    </message>
    <message>
        <source>You need to log in to get access to the intranet.</source>
        <translation>Вы должны авторизоваться, чтобы получить доступ к intranet-сайту.</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Ваша учетная запись успешно создана. Н указанный вами адрес, отправлено письмо. Следуйте инструкциям, указанным в письме для активизации вашей учетной записи.</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>A mail has been send to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Почтовое сообщение было послано на следующий адрес: %1. Сообщение содержит ссылку, по которой вам необходимо проследовать, для того чтобы мы убедились, что пароль изменится для правильного пользователя.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Нет зарегистрированного пользователя с таким электронным адресом.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Пароль был успешно создан и послан на адрес: %1</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Забыли ваш пароль?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Если вы забыли пароль, система автоматически сгенерирует для вас новый пароль. Вам необходимо ввести ваш электронный адрес и новый пароль будет автоматически сгенерирован.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Создать новый пароль</translation>
    </message>
    <message>
        <source>%siteurl new password</source>
        <translation>%siteurl новый пароль</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Информация о вашей учетной записи</translation>
    </message>
    <message>
        <source>Click here to get new password</source>
        <translation>Кликните здесь, чтобы получить новый пароль</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Новый пароль</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>Указан неверный ключ или он уже используется кем-либо еще.</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>%1 registration info</source>
        <translation>%1 регистрационная информация</translation>
    </message>
    <message>
        <source>Confirm user registration at %siteurl</source>
        <translation>Подтвердите регистрацию на %siteurl</translation>
    </message>
    <message>
        <source>Your user account at %siteurl has been created</source>
        <translation>Ваш бюджет на %siteurl  был создан</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Информация пользователя</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Click the following URL to confirm your account</source>
        <translation>Кликните на ссылке для подтверждения регистрации</translation>
    </message>
    <message>
        <source>New user registered at %siteurl</source>
        <translation>Новый пользователь зарегистрирован на %siteurl</translation>
    </message>
    <message>
        <source>A new user has registered.</source>
        <translation>Новый пользователь зарегистрирован.</translation>
    </message>
    <message>
        <source>Account information.</source>
        <translation>Информация пользователя.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Login name</comment>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>Link to user information</source>
        <translation>Ссылка на информацию о пользователе</translation>
    </message>
    <message>
        <source>Thank you for registering at %siteurl.</source>
        <translation>Спасибо за регистрацию на %siteurl.</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Информация о вашем бюджете</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Editing workflow</source>
        <translation>Редактирование рабочего процесса</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Рабочий процесс сохранен</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Необходимо исправить данные</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Группы</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>События</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>on</source>
        <translation>на</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Изменен</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>Рабочий процесс</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>Процесс был создан</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>и изменен</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Рабочий процесс</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Используя процесс</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>для обработки.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Этот процесс работает для пользователя</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Контент объект</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>Процесс был создан для содержимого</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>используя версию</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>в узле</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Событие процесса</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>Процесс еще не запущен, количество главных событий в процессе</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>Текущее положение события</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>Событие для запуска</translation>
    </message>
    <message>
        <source>event</source>
        <translation>событие</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>Последнее событие вернуло статус</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Список событий рабочего процесса</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Следующий шаг</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Журнал событий процесса</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Группа процессов</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Новая группа</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Новый процесс</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Добавить группу</translation>
    </message>
    <message>
        <source>Editing workflow group - %1</source>
        <translation>Редактирование группы процессов - %1</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Изменено %username в %time</translation>
    </message>
    <message>
        <source>Edit workflow</source>
        <translation>Редактировать процесс</translation>
    </message>
    <message>
        <source>Remove selected workflows</source>
        <translation>Удалить выбранные процессы</translation>
    </message>
    <message>
        <source>Workflow process was created at %creation and modified at %modification.</source>
        <translation>Процесс был создан в %creation и изменен в %modification.</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <comment>%1 is workflow group</comment>
        <translation>Процессы в %1</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Пользователи без подтверждения</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Пользователи без ID процесса</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>Атрибуты класса:</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Классы для запуска процесса</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Процесс для запуска</translation>
    </message>
    <message>
        <source>New entry</source>
        <translation>Новая ячейка</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Удалить выбранное</translation>
    </message>
    <message>
        <source>Load attributes</source>
        <translation>Загрузить атрибуты</translation>
    </message>
    <message>
        <source>Modify publish date</source>
        <translation>Изменить дату публикации</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Список классов группы</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Список групп классов</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Удалить класс</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Редактировать класс</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Классы</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Список классов</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Удалить классы</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>нет классов</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Удалить группы классов</translation>
    </message>
    <message>
        <source> object</source>
        <translation>объект</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>объекты</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Стандартные</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Наблюдатель</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Владелец</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Входящие</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Еще не определен статус</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Процесс выполняется</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Процесс закончен</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Процесс прервался с ошибкой на событии</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Событие процесса перенаправлено на выполнение cron-демону</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>процесс отменен</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Процесс был возвращен в исходное состояние для повторного использования</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Принятое событие</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Отклоненное событие</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Событие перенаправлено cron-демону</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Событие процесса перенаправлено на выполнение cron-демону, событие будет начато с начала</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>Событие выполняет подсобытие</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Отменен весь процесс</translation>
    </message>
    <message>
        <source>Workflow fetches template</source>
        <translation>Процесс извлекает шаблон</translation>
    </message>
    <message>
        <source>Workflow redirects user view</source>
        <translation>Процесс перенаправляет представление пользователя</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Missing date input.</source>
        <translation>Отсутствует дата.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Не указано время и дата.</translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Не введено время.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>Подтвержденный пароль не совпадает.</translation>
    </message>
    <message>
        <source>Author</source>
        <comment>Datatype name</comment>
        <translation>Автор</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <translation>Необходимо указать хотя бы одного автора.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <translation>Должно присутствовать имя автора.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <translation>Почтовый адрес неправилен.</translation>
    </message>
    <message>
        <source>BinaryFile</source>
        <comment>Datatype name</comment>
        <translation>Бинарный файл</translation>
    </message>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Загрузка файлов не включена. Невозможно обработать файл.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <translation>Необходим правильный файл.</translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>Datatype name</comment>
        <translation>Флажок</translation>
    </message>
    <message>
        <source>Date field</source>
        <comment>Datatype name</comment>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Datetime field</source>
        <comment>Datatype name</comment>
        <translation>Дата и время</translation>
    </message>
    <message>
        <source>Email</source>
        <comment>Datatype name</comment>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <translation>Необходим действительный Email.</translation>
    </message>
    <message>
        <source>Enum</source>
        <comment>Datatype name</comment>
        <translation>Множество</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <translation>Нужно выбрать хотя бы одно поле.</translation>
    </message>
    <message>
        <source>Float</source>
        <comment>Datatype name</comment>
        <translation>Дробное число</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <translation>Введенные данные не являются числом.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <translation>Число должно быть больше %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <translation>Число должно быть меньше %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <translation>Числе вне предопределенного диапазона %1 - %2</translation>
    </message>
    <message>
        <source>Image</source>
        <comment>Datatype name</comment>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Integer</source>
        <comment>Datatype name</comment>
        <translation>Целое число</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <translation>Введенные данные не являются целым числом.</translation>
    </message>
    <message>
        <source>ISBN</source>
        <comment>Datatype name</comment>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <translation>Код ISBN не правилен. Пожалуйста, перепроверьте введенные данные</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <translation>Формат ISBN не правилен.</translation>
    </message>
    <message>
        <source>Keyword</source>
        <comment>Datatype name</comment>
        <translation>Ключевое слово</translation>
    </message>
    <message>
        <source>Matrix</source>
        <comment>Datatype name</comment>
        <translation>Таблица</translation>
    </message>
    <message>
        <source>Media</source>
        <comment>Datatype name</comment>
        <translation>Медиа</translation>
    </message>
    <message>
        <source>Object relation</source>
        <comment>Datatype name</comment>
        <translation>Связь с объектом</translation>
    </message>
    <message>
        <source>Object relation list</source>
        <comment>Datatype name</comment>
        <translation>Список связей с объектами</translation>
    </message>
    <message>
        <source>Option</source>
        <comment>Datatype name</comment>
        <translation>Опция</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <translation>Необходима хотя бы одна опция.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <translation>Должно присутствовать значение опции.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <translation>Неправильная дополнительная цена для значения опции.</translation>
    </message>
    <message>
        <source>Price</source>
        <comment>Datatype name</comment>
        <translation>Цена</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Добавить в корзину</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Добавить в список пожеланий</translation>
    </message>
    <message>
        <source>Range option</source>
        <comment>Datatype name</comment>
        <translation>Интервальная опция</translation>
    </message>
    <message>
        <source>Selection</source>
        <comment>Datatype name</comment>
        <translation>Выбор</translation>
    </message>
    <message>
        <source>Text line</source>
        <comment>Datatype name</comment>
        <translation>Строка текста</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <translation>Пустая строка ввода, необходимо содержимое.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <translation>Длина строки превышает максимально допустимое значение %1.</translation>
    </message>
    <message>
        <source>Subtree subscription</source>
        <comment>Datatype name</comment>
        <translation>Подписка на поддерево</translation>
    </message>
    <message>
        <source>Text field</source>
        <comment>Datatype name</comment>
        <translation>Текстовое поле</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <translation>Пустое поле для текста, необходимо содержимое.</translation>
    </message>
    <message>
        <source>Time field</source>
        <comment>Datatype name</comment>
        <translation>Время</translation>
    </message>
    <message>
        <source>URL</source>
        <comment>Datatype name</comment>
        <translation>URL</translation>
    </message>
    <message>
        <source>User account</source>
        <comment>Datatype name</comment>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <translation>Необходимо указать имя пользователя</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <translation>Данное имя пользователя уже существует, пожалуйста, выберите другое имя.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <translation>Не правильный E-mail адрес.</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <translation>Пользователь с данным e-mail адресом уже существует.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <translation>Пароль должен содержать не меньше 3-х символов.</translation>
    </message>
    <message>
        <source>XML Text field</source>
        <comment>Datatype name</comment>
        <translation>Поле с XML разметкой</translation>
    </message>
    <message>
        <source>Object %1 does not exist.</source>
        <translation>Объект %1 не существует.</translation>
    </message>
    <message>
        <source>Link %1 does not exist.</source>
        <translation>Ссылка %1 не существует.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <comment>Datatype name</comment>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>image</source>
        <comment>Default image name</comment>
        <translation>изображение</translation>
    </message>
    <message>
        <source>Ini Setting</source>
        <comment>Datatype name</comment>
        <translation>Настройка в INI файле</translation>
    </message>
    <message>
        <source>Could not locate ini file</source>
        <translation>Невозможно обнаружить INI файл</translation>
    </message>
    <message>
        <source>Package</source>
        <comment>Datatype name</comment>
        <translation>Пакет</translation>
    </message>
    <message>
        <source>Send</source>
        <comment>Datatype information collector action</comment>
        <translation>Отправить</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Специальное событие совместной работы</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Совместная работа</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Не выбран главный узел, пожалуйста, укажите один.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Удалить редактируемую версию</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Удалить объект</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Закладка от %1: %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Почтовый адрес отправителя неправилен</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Почтовый адрес получателя неправилен</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Отправить другу</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Перевести</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Переводы содержимого</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои закладки</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Мой список обработки</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>Транслятор URL</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Ключевые слова</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Дочерний</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>дочерние</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Также это повлечет удаление следующих узлов:</translation>
    </message>
</context>
<context>
    <name>kernel/contentclass</name>
    <message>
        <source>New %1</source>
        <translation>Новый %1</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Права</translation>
    </message>
</context>
<context>
    <name>kernel/form</name>
    <message>
        <source>Form processing</source>
        <translation>Обработка формы</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification settings</source>
        <translation>Установки уведомления</translation>
    </message>
</context>
<context>
    <name>kernel/package</name>
    <message>
        <source>Packages</source>
        <translation>Пакеты</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <source>Package information</source>
        <translation>Информация о пакете</translation>
    </message>
    <message>
        <source>Package maintainer</source>
        <translation>Поставщик пакета</translation>
    </message>
    <message>
        <source>Package changelog</source>
        <translation>Журнал изменений пакета</translation>
    </message>
    <message>
        <source>Package thumbnail</source>
        <translation>Пиктограмма пакета</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Имя пакета</translation>
    </message>
    <message>
        <source>Package name is missing</source>
        <translation>Имя пакета отсутствует</translation>
    </message>
    <message>
        <source>A package named %packagename already exists, please give another name</source>
        <translation>Пакет с именем %packagename уже существует, пожалуйста, выберите другое имя</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Summary is missing</source>
        <translation>Резюме отсутствует</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>The version must only contain numbers and must be delimited by dots (.), e.g. 1.0</source>
        <translation>Версия может содержать только цифры, которые должны разделяться точками (.), например 1.0</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>You must enter a name for the changelog</source>
        <translation>Вы должны ввести название для журнала изменений</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>You must enter an e-mail for the changelog</source>
        <translation>Вы должны указать e-mail для журнала изменений</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Журнал изменений</translation>
    </message>
    <message>
        <source>You must supply some text for the changelog entry</source>
        <translation>Вы должны ввести текст для записи в журнале изменений</translation>
    </message>
    <message>
        <source>You must enter a name of the maintainer</source>
        <translation>Вы должны ввести имя поставщика пакета</translation>
    </message>
    <message>
        <source>You must enter an e-mail address of the maintainer</source>
        <translation>Вы должны указать e-mail поставщика пакета</translation>
    </message>
    <message>
        <source>Content classes to include</source>
        <translation>Список контент-классов для добавления</translation>
    </message>
    <message>
        <source>Content class export</source>
        <translation>Экспорт контент классов</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Список классов</translation>
    </message>
    <message>
        <source>You must select at least one class for inclusion</source>
        <translation>Вы должны выбрать хотя бы один класс для добавления</translation>
    </message>
    <message>
        <source>CSS file</source>
        <translation>CSS файл</translation>
    </message>
    <message>
        <source>Image files</source>
        <translation>Файлы изображений</translation>
    </message>
    <message>
        <source>Site style</source>
        <translation>Стиль сайта</translation>
    </message>
    <message>
        <source>You must upload a CSS file</source>
        <translation>Вы должны загрузить CSS файл</translation>
    </message>
    <message>
        <source>File did not have a .css suffix, this is most likely not a CSS file</source>
        <translation>Расширение файла не содержит подстроку &apos;.css&apos;. Возможно, вы неверно указали файл для загрузки</translation>
    </message>
    <message>
        <source>Content class %classname (%classidentifier)</source>
        <translation>Контент класс %classname (%classidentifier)</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Создать пакет</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Инсталлировать</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталлировать</translation>
    </message>
    <message>
        <source>Package %packagename already exists, cannot import the package</source>
        <translation>Пакет %packagename уже существует. Невозможно импортировать пакет</translation>
    </message>
</context>
<context>
    <name>kernel/pdf</name>
    <message>
        <source>PDF Export</source>
        <translation>Экспорт в PDF</translation>
    </message>
</context>
<context>
    <name>kernel/reference</name>
    <message>
        <source>Reference documentation</source>
        <translation>Документация</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation>Создать правила - шаг 2 - укажите функцию</translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation>Создать правила - шаг 3 - укажите ограничения</translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation>Создать правила - шаг 1 - укажите модуль</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Список ролей</translation>
    </message>
    <message>
        <source>Editing policy</source>
        <translation>Редактирование правила</translation>
    </message>
</context>
<context>
    <name>kernel/rss</name>
    <message>
        <source>Really Simple Syndication</source>
        <translation>Really Simple Syndication</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Статистика поиска</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Редактировать секцию</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
</context>
<context>
    <name>kernel/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Управление кэшем</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Мастер операторов шаблонов</translation>
    </message>
    <message>
        <source>Extension configuration</source>
        <translation>Конфигурация расширений</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Информация о системе</translation>
    </message>
    <message>
        <source>Rapid Application Development</source>
        <translation>Быстрая разработка приложений (RAD)</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Список шаблонов</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Просмотр шаблонов</translation>
    </message>
    <message>
        <source>Create new template</source>
        <translation>Создать новый шаблон</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Редактирование шаблона</translation>
    </message>
    <message>
        <source>Activate extensions</source>
        <translation>Активные расширения</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Меню установки</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Рассчитаться</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Подтвердите заказ</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Группа скидок</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>просмотр группы правила скидок</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирование правила</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Просмотр заказа</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Введите данные счета</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типы НДС</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Триггер</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>URL edit</source>
        <translation>Редактирование URL</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Забыли пароль</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Зарегистрировать</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Регистрационная информация</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Новый пользователь зарегистрирован</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Редактировать процесс</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Процесс</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Редактировать группу процессов</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Редактировать группу</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Список групп процессов</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Список групп</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Список процессов</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Список процессов в группе</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Event</source>
        <translation>Событие</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Multiplexer</source>
        <translation>Мультиплексор</translation>
    </message>
    <message>
        <source>Simple shipping</source>
        <translation>Простая доставка</translation>
    </message>
    <message>
        <source>Wait until date</source>
        <translation>Ожидание даты</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/group</name>
    <message>
        <source>Group</source>
        <translation>Группа</translation>
    </message>
</context>
<context>
    <name>lib/ezpdf/classes</name>
    <message>
        <source>Contents</source>
        <comment>Table of contents</comment>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Index</source>
        <comment>Keyword index name</comment>
        <translation>Индекс</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Обнаружено несколько ошибок в шаблонах. Просмотрите отладочную информацию для дополнительной информации.</translation>
    </message>
</context>
<context>
    <name>pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>Экспорт в PDF</translation>
    </message>
</context>
<context>
    <name>setup/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Редактирование шаблона</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отменить</translation>
    </message>
</context>
</TS>
