<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=enhancedobjectrelation
AvailableDataTypes[]=ezenhancedobjectrelation


*/
?>
