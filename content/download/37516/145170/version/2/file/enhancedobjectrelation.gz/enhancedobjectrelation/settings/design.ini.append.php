<?php
/*

[ExtensionSettings]
DesignExtensions[]=enhancedobjectrelation

*/
?>
