<?php

class ezworkflowcollectionInfo
{
    static function info()
    {
        return array( 'Name' => "ezworkflowcollection",
                      'Version' => "0.1",
                      'Copyright' => "Copyright (C) 20010 G. Giunta - O. portier",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>