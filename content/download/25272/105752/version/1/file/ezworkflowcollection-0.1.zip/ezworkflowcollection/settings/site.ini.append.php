<?php /*

[RegionalSettings]
TranslationExtensions[]=ezworkflowcollection

*/ ?>
