<?php /*

[ExtensionSettings]
DesignExtensions[]=ezworkflowcollection

*/ ?>