<?php /*

[EventSettings]
ExtensionDirectories[]=ezworkflowcollection

AvailableEventTypes[]=event_multipublish
AvailableEventTypes[]=event_subtreemultiplexer
# the following one needs classes found in ezflow
AvailableEventTypes[]=event_expireremotecacheflow

#AvailableEventTypes[]=event_relatetonode
#AvailableEventTypes[]=event_relatetonodeattribute

*/ ?>