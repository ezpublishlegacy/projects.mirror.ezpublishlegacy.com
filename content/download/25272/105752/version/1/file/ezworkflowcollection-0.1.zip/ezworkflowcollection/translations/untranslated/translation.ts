﻿<!DOCTYPE TS><TS>
<context>
    <name>extension/ezworkflowcollection</name>
    <message>
        <source>Target nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multipublish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ClassAttribute name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter on class attributes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(only booleans supported)</source>
        <translation type="unfinished"></translation>
    </message>

    <message>
        <source>Subtree Multiplexer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Affected subtree</source>
        <translation type="unfinished"></translation>
    </message>

</context>
</TS>
