<?php /*

[DatabaseSettings]
ImplementationAlias[oracle]=ezoracle

# Example configuration for connecting to an oracle db
#DatabaseImplementation=ezoracle
#Server=
#Port=
#User=scott
#Password=tiger
#Database=orcl
#Charset=

*/ ?>
