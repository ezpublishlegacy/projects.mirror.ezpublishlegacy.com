<?php /* #?ini charset="utf-8"?


[full_obj]
Source=node/view/full.tpl
MatchFile=full/unity.tpl
Subdir=templates
Match[class_identifier]=unity

[line_obj]
Source=node/view/line.tpl
MatchFile=line/unity.tpl
Subdir=templates
Match[class_identifier]=unity

[embed_obj]
Source=content/view/embed.tpl
MatchFile=embed/unity.tpl
Subdir=templates
Match[class_identifier]=unity


*/ ?>