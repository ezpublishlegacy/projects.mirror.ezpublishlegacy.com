<?php
 
$FunctionList = array();

$FunctionList['flickr'] = array( 	'name' => 'flickr',
										'operation_types' => array( 'read' ),
										'call_method' => array( 'include_file' => 'extension/socialFetch/modules/socialFetch/socialFetchfunctioncollection.php',
																'class' => 'socialFetch',
																'method' => 'flickr' ),
										'parameter_type' => 'standard',
										'parameters' => array(
												array( 	'name' => 'flickrUsername',
														'type' => 'string',
														'required' => true ),
												array( 	'name' => 'flickrApiKey',
														'type' => 'string',
														'required' => true ),		
												array( 	'name' => 'flickrSecret',
														'type' => 'string',
														'required' => true ),		
												array( 	'name' => 'limit',
														'type' => 'integer',
														'required' => false )
														)
								);									

$FunctionList['twitter'] = array( 	'name' => 'twitter',
										'operation_types' => array( 'read' ),
										'call_method' => array( 'include_file' => 'extension/socialFetch/modules/socialFetch/socialFetchfunctioncollection.php',
																'class' => 'socialFetch',
																'method' => 'twitter' ),
										'parameter_type' => 'standard',
										'parameters' => array(
												array( 	'name' => 'screenName',
														'type' => 'string',
														'required' => true ),	
												array( 	'name' => 'limit',
														'type' => 'integer',
														'required' => false )
														)
								);								
								
?>