<?php
/**
 * Holder alle funksjonene for å hente objekter fra "virituell" objektbase
 */
include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutil/classes/ezini.php' );
 
class socialFetch
{

	
	function socialFetch()
	 {
	 }
	 
	public static function flickr( $flickrUsername, $flickrApiKey, $flickrSecret, $limit )
    {
		
		include_once('extension/socialFetch/lib/phpFlickr.php');
		
		 $f = new phpFlickr($flickrApiKey, $flickrSecret, false );

		 
		 $person = $f->people_findByUsername($flickrUsername);
		 $photos_url = $f->urls_getUserPhotos($person['id']);
		 $photos = $f->people_getPublicPhotos($person['id'], NULL, 1,$totalPhotos);

		 $i = 0;
		 $resArr = array();
		 foreach ( $photos['photos']['photo'] as $photo  ) {
			 array_push($resArr, array ( "link" => $photos_url . $photo['id'], "thumb" => "http://farm" . $photo['farm'] . ".static.flickr.com/" . $photo['server'] . "/" . $photo['id'] . "_" . $photo['secret'] . "_s.jpg" ) );
			 $i++;
			 if($i == $limit) { 
				break; 
			} 
		 }
		
		return array( 'result' => $resArr );
		
		
			
			
	}
	
	public static function twitter( $screenName, $limit )
    {
		
		
		if(!isset($limit)){
			$limit = 3;
		}
			$json = "http://api.twitter.com/1/statuses/user_timeline.json?screen_name=" . $screenName . "&count=" . $limit;
			
			$tweets = json_decode(file_get_contents($json), true);
			//echo "<pre>";
			//print_r($result);
			//echo "</pre>";
			
			//$new = preg_replace("/(http:\/\/[^\s]+)/", "<a href=\"$1\">$1</a>", $result[0]['text']);
			
			$result = array();
			foreach($tweets as $k => $v){
				$v['text'] = preg_replace("/(http:\/\/[^\s]+)/", "<a href=\"$1\">$1</a>", $v['text']);
				$v['created_at'] = strtotime($v['created_at']);
				array_push($result, $v);
			}
			//mail("havard@byte.no", $screenName, $json);
			
			return array( 'result' => $result );
			
			
			
	}

}

?>