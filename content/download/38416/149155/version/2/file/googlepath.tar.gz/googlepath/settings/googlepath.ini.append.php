<?php /* #?ini charset="iso-8859-1"?
[ApiKeys]
GoogleApiKeys[]=domain;key

[MapSettings]
DefaultWidth=550
DefaultHeight=400
DefaultZoom=7
ZoomControl=enabled
TypeControl=enabled
DefaultType=G_HYBRID_MAP
DefaultLatitude=58.4662097
DefaultLongitude=-6.3173318

[PathSettings]
StartText=Start Here
StopText=Stop Here
PathColour=f0ff00

*/ ?>
