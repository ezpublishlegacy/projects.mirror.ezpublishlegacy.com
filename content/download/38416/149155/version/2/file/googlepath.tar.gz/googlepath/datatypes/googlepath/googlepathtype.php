<?php

  /*!
  \class   GooglePathType googlepathtype.php
  \ingroup eZDatatype
  \brief   Handles path data for use with Google Maps.
  \version 1.0
  \date    February 2007 2:51:33 pm
  \author  Jonathan Staines



  */

include_once( "kernel/classes/ezdatatype.php" );

// debug
include_once( "lib/ezutils/classes/ezdebug.php" );


  define( "EZ_DATATYPESTRING_GOOGLE_PATH", "googlepath" );

  class GooglePathType extends eZDataType
  {
    /*!
    Constructor
    */
    function GooglePathType()
    {
      $this->eZDataType( EZ_DATATYPESTRING_GOOGLE_PATH, "Google Path");
    }

    /*!
    Validates input on content object level
    \return EZ_INPUT_VALIDATOR_STATE_ACCEPTED or EZ_INPUT_VALIDATOR_STATE_INVALID if
    the values are accepted or not
    */
    function validateObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
      $debug=true;
      if ( $http->hasPostVariable( $base . '_googlepath_pathpoints_' . $contentObjectAttribute->attribute( 'id' ) ) 
           && $http->hasPostVariable( $base . '_googlepath_zoomlevel_' . $contentObjectAttribute->attribute( "id" ) ) )
      {
        $pathpoints = $http->postVariable( $base . '_googlepath_pathpoints_' . $contentObjectAttribute->attribute( 'id' ) );
        eZDebug::writeNotice("Got path points: " . $pathpoints);
        $zoomlevel = $http->postVariable( $base . '_googlepath_zoomlevel_' . $contentObjectAttribute->attribute( 'id' ) );
        eZDebug::writeNotice("Got zoom level: " . $zoomlevel);


        if ( $pathpoints == "" and $zoomlevel == "" and !$contentObjectAttribute->validateIsRequired() )
        {
                return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
        }

        if ( $zoomlevel < 0 or $zoomlevel > 17  or !is_numeric($zoomlevel) )
        {
          $contentObjectAttribute->setValidationError("Zoom Level is not in the correct range (0 - 17).");
          return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }

        $pathpoints = preg_replace( "/\s+/" , ""  , $pathpoints );
        $pointArray = split( "\),\(" , $pathpoints );
        eZDebug::writeNotice("points:".$pointArray);
        if ( count($pointArray) < 2 )
        {
          $contentObjectAttribute->setValidationError("A path must have at least two points.");
          return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        for( $x=0; $x<count($pointArray); $x++)
        {
          $lnglat = split( "," , $pointArray[$x] );
          $lng = trim( $lnglat[0] , '()' );
          $lat = trim( $lnglat[1] , '()' );
          if ( !is_numeric($lat) or !($lat <= 90) or !( $lat >= -90 ) ) 
          {
            $contentObjectAttribute->setValidationError("A latitude value out of range.");
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
          }
          if ( !is_numeric($lng) or !($lng <= 180) or !( $lng >= -180 ) ) 
          {
            $contentObjectAttribute->setValidationError("A longitude value out of range.");
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
          }
        }
        return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
      }
      $contentObjectAttribute->setValidationError("You didn't fill in all the fields.");
      return EZ_INPUT_VALIDATOR_STATE_INVALID;
    }

    /*!
    Fetches all variables from the object
    \return true if fetching of class attributes are successfull, false if not
    */
    function fetchObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
      if ( $http->hasPostVariable( $base . '_googlepath_pathpoints_' . $contentObjectAttribute->attribute( "id" ) ) 
           && $http->hasPostVariable( $base . '_googlepath_zoomlevel_' . $contentObjectAttribute->attribute( "id" ) ) )
      { 
        $pathpoints = $http->postVariable( $base . '_googlepath_pathpoints_' . $contentObjectAttribute->attribute( 'id' ) );
        $pathData = $pathpoints;
        $contentObjectAttribute->setAttribute( "data_text" , $pathData);
        $zoomlevel = $http->postVariable( $base . '_googlepath_zoomlevel_' . $contentObjectAttribute->attribute( 'id' ) );
        $zoomData = $zoomlevel;
        // Set the zoom data to NULL if nothing is entered to stop the DB entry defaulting to 0
        if ( $zoomData == "" )
        {
          $zoomData = NULL;
        }
        $contentObjectAttribute->setAttribute( "data_int" , $zoomData);
        return true;
      }
      return false;
    }

    /*!
    Returns the content.
    */
    function &objectAttributeContent( &$contentObjectAttribute )
    {
      $zoomlevel = $contentObjectAttribute->attribute( "data_int" );
      eZDebug::writeNotice( "Got zoom = ".$zoomlevel );

      $pathpoints = $contentObjectAttribute->attribute( "data_text" );
      $pathpoints = preg_replace( "/\s+/" , ""  , $pathpoints );
      eZDebug::writeNotice( "Got points = ".$pathpoints );
      $pointArray = split( "\),\(" , $pathpoints );
      $rows = array();
      if ( count($pointArray) < 2 )
      {
        eZDebug::writeNotice( "There are no points yet." );
      }else{
        for( $x=0; $x<count($pointArray); $x++){
          $lnglat = split( "," , $pointArray[$x] );
          $lng = trim( $lnglat[0] , '()' );
          $lat = trim( $lnglat[1] , '()' );
          $rows[]=array('longitude' => $lng,
                        'latitude' => $lat);
        }
        eZDebug::writeNotice( "Got number of points  = ". count($rows) );
      }
      $result = array( 'pathpoints' => $pathpoints,
                       'zoomlevel' => $zoomlevel,
                       'rows' => $rows );
      return $result;
    }

    /*!
    Returns the meta data used for storing search indeces.
    */
    function metaData( $contentObjectAttribute )
    {
      return $contentObjectAttribute->attribute( "data_text" );
    }

    /*!
    Returns the value as it will be shown if this attribute is used in the object name pattern.
    */
    function title( &$contentObjectAttribute )
    {
      return $contentObjectAttribute->attribute( "data_text" );
    }

    /*!
    \return true if the datatype can be indexed
    */
    function isIndexable()
    {
      return true;
    }

  }

  eZDataType::register( EZ_DATATYPESTRING_GOOGLE_PATH, "googlepathtype" );
?>
