<?php /* #?ini charset="utf-8"?

[TemplateSettings]
# ExtensionAutoloadPath[]=bccie

[RegionalSettings]
TranslationExtensions[]=bccie

[RoleSettings]
PolicyOmitList[]=bccie/overview
PolicyOmitList[]=bccie/export
PolicyOmitList[]=bccie/doexport


*/ ?>