<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_GB">
<context>
    <name>design/bccie/overview</name>
    <message>
        <source>Collected informations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BC CIE Export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/bccie/menu</name>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extension project</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>extension/bccie</name>
    <message>
        <source>Collected information export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/bccie/export</name>
    <message>
        <source>Collected informations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Field #%counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content object id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leave empty (note: field still gets created)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore (note: field doesn't get created at all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separation char for CSV export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semicolon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>    
</context>
</TS>
