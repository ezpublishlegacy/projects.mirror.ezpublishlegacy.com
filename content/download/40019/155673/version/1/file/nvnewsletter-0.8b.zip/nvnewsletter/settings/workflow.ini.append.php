<?php /*

[EventSettings]
ExtensionDirectories[]=nvnewsletter
AvailableEventTypes[]=event_nvnewsletterusergroup

[OperationSettings]
#AvailableOperationList[]=content_addlocation

*/ ?>
