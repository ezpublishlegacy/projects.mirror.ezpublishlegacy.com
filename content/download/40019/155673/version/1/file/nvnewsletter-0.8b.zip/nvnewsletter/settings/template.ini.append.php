<?php /*

[PHP]
PHPOperatorList[makeunixtime]=strtotime

*/ ?>
