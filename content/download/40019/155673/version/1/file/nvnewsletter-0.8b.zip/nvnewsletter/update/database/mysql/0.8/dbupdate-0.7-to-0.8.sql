ALTER TABLE `nvnewsletter_clicktrack` MODIFY `action_date` datetime NOT NULL default '0000-00-00 00:00:00';
ALTER TABLE `nvnewsletter_clicktrack` ADD `receiver_id` INT( 11 );
UPDATE `nvnewsletter_statistics` SET `data_int` = 0;
