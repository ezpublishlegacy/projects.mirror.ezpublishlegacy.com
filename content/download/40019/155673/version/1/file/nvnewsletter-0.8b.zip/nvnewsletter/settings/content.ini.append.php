<?php /*

[CustomTagSettings]
AvailableCustomTags[]=nvnewslettersubscribe
AvailableCustomTags[]=arrow
IsInline[nvnewslettersubscribe]=false
IsInline[arrow]=false

[EditSettings]
ExtensionDirectories[]=nvnewsletter

[DataTypeSettings]
ExtensionDirectories[]=nvnewsletter
AvailableDataTypes[]=nvnewslettersender
AvailableDataTypes[]=nvnewslettergroups
AvailableDataTypes[]=nvnewslettersiteselect

[link]
AvailableClasses[]=tracker

*/ ?>
