<?php
/**
 * Module view link stats
 * @package nvNewsletter
 */
$extension = 'nvnewsletter';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

$http = eZHTTPTool::instance();
$newsletterID = $Params['NewsletterID'];
$linkID = $Params['LinkID'];
$Module = $Params['Module'];

$newsletter = nvNewsletter::fetch($newsletterID);
$link       = nvNewsletterClickTrackLink::fetch($linkID);
$linkStats  = nvNewsletterClickTrack::fetchByNewsletterAndLinkID($newsletterID, $linkID);

$tpl = nvNewsletterTemplate::factory();
$tpl->setVariable( 'newsletter', $newsletter );
$tpl->setVariable( 'link', $link );
$tpl->setVariable( 'link_stats', $linkStats );

$Result = array();
$Result['newsletter_menu'] = 'design:parts/content/newsletter_menu.tpl';
$Result['left_menu'] = 'design:parts/content/nvnewsletter_menu.tpl';
$Result['content'] = $tpl->fetch( "design:$extension/view_link_stats.tpl" );
$Result['path'] = array(array(
            'url' => false,
            'text' => ezi18n('nvnewsletter/view_link_stats', 'View link stats')));
?>
