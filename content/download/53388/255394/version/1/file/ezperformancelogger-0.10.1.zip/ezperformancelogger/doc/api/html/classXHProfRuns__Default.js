var classXHProfRuns__Default =
[
    [ "__construct", "classXHProfRuns__Default.html#a47cbeac1869d6f3ff020292c3b09a7ad", null ],
    [ "file_name", "classXHProfRuns__Default.html#a4d1073183fb0a49de43d16eacc9e3f08", null ],
    [ "gen_run_id", "classXHProfRuns__Default.html#af760c2d84a6194a5cdff65369d1b3ab7", null ],
    [ "get_run", "classXHProfRuns__Default.html#af96022620953357ee599aaf3b23b89ce", null ],
    [ "save_run", "classXHProfRuns__Default.html#ae91af6dac754e6f7758afdd1d17ec9fd", null ],
    [ "$dir", "classXHProfRuns__Default.html#afac42b166946370582c36ce17830bf19", null ]
];