<?php /*

[ModuleSettings]
ExtensionRepositories[]=vztcalendar


*/
?>