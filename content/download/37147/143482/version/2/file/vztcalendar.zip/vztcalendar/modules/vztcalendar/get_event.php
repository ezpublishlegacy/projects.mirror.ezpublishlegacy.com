<?php

if( isset( $_GET['nodeid'] ) ){

	include_once("extension/vztcalendar/classes/class.events.php");
	
	$event = new Events($_GET['nodeid'],$start="",$end="");
	$event = $event->get_spec_event();

	echo json_encode($event);

	
	
}

?>
