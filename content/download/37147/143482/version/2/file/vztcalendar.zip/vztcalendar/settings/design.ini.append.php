<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=vztcalendar

[JavaScriptSettings]

JavaScriptList[]=fullcalendar.min.js
JavaScriptList[]=custom_calendar.js


[StylesheetSettings]
CSSFileList[]=fullcalendar.css


*/ ?>