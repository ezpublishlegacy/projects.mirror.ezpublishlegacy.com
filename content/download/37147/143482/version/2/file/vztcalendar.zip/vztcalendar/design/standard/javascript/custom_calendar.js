function view_event(id, from, to, eclass, site){
	
	$.getJSON(site+"/layout/set/json/vztcalendar/event?nodeid="+id,'',
        function(data){
		  $('#span-when').text(from + ' - ' + to);
		  $('#span-title').text(data.title);
		 
		  if(data.category==null){
			  var category = 'Activity';
		  }
		  else{
			  var category = data.category;
		  }
		  $('#span-category').html('<span class="'+eclass+'">'+category+'</span>');
		  $('span.'+eclass).css('padding','2px');
		  $('span.'+eclass).css('color','white');
		  $('span#span-text').html(data.text);
	
		  if(data.recurring_event!='0'){
			  $('#span-recurring').show();
		  }
		  else{
			$('#span-recurring').hide();  
		  }
		  if(data.location!=''){
			  var google = "http://maps.google.no/maps?q="+data.location+"&hl=nor-NO";
			  $('.where').css('display','block');
			  $('#span-where').text(data.location);
			  $('#span-location').attr({ href: google });
		  }
		  else{
			 $('.where').css('display','none');
		  }
		  
		  if($("#event:first").is(":hidden")) {
        	$("#event").slideDown("slow");
     	 } else {
			$("#event").hide();
		  } 
		  
        });
	
	
	 

}
function close_event(){
		
	$('#event').slideUp("slow");
	
	
}

