<?php

/*

eZ Event Calendar

Copyright (C) 2010 VZT 
Written by Morten S�rensen

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

class vztcalendarInfo
{
    function info()
    {
        return array( 'Name' => "VZT calendar",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2010 Morten S�rensen <a href=\"http://www.vzt.no\" target=\"_blank\">VZT</a>",
                      'License' => "GNU General Public License v2.0",
					  'Includes the following third-party software' => array( array('Name' => 'Fullcalendar',
                                                                              'Version' => '1.4.5',
                                                                              'Copyright' => 'Copyright (c) ' . date( 'Y' ) . ' Adam Shaw',
                                                                              'License' => 'MIT and GPL license' ),
																			  array('Name' => 'jQuery',
                                                                              'Version' => '1.4.2',
                                                                              'Copyright' => 'Copyright (c) ' . date( 'Y' ) . ', The jQuery Project. All rights reserved.',
                                                                              'License' => 'GNU General Public License (GPL) Version 2' )) );
                     );
    }
}



?>