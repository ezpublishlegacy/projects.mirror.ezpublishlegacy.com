<?php

$Module = array( 'name' => 'vztcalendar' );

$ViewList = array();

$ViewList['calendar'] = array( 'script' => 'events_to_json.php' );
$ViewList['event'] = array( 'script' => 'get_event.php' );


?>
