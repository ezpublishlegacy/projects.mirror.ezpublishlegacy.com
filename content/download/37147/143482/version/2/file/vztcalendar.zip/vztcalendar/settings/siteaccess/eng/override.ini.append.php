<?php
/*
[vzt_event_calendar]
Source=node/view/full.tpl
MatchFile=full/vzt_event_calendar.tpl
Subdir=templates
Match[class_identifier]=vzt_event_calendar


*/
?>