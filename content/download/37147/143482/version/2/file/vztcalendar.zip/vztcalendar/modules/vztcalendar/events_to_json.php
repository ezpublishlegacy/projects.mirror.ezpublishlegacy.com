<?php

if( isset( $_GET['nodeid'] ) ){

	include_once("extension/vztcalendar/classes/class.events.php");
	
	$start = $_GET['start']/1000;
	$end = $_GET['end']/1000;
	
	$events = new Events($_GET['nodeid'],$start,$end);
	
	if(isset($_GET['depth'])){
		$events->depth = $_GET['depth'];
	}
	
	$events = $events->get_events();

	if(function_exists('json_encode')){
	
		echo json_encode($events);

	}
	else{
	
		include_once("extension/vztcalendar/classes/class.json.php");
		$json = new FastJSON;
		echo $json->encode($events);
		
	}

	
	
}

?>
