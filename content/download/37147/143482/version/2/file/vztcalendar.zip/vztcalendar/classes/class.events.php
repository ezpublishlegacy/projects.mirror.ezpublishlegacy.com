<?php

class Events{

	private $NodeId;
	private $NodeArray;
	private $EventSource;
	private $Events = array();
	private $start;
	private $ends;
	public $depth=3;
	

	public function events($nodeID,$start,$end)
	{
		$this->NodeArray =  eZContentObjectTreeNode::fetch( $nodeID );
		$this->NodeId = $nodeID;
		$this->start = $start;
		$this->ends = $end;

		
	}
	private function initiate_events()
	{
		
		$eventnode = eZContentObjectTreeNode::fetch( $this->NodeId );
		
		$events = $eventnode->subtree( array( 	'Depth' => $this->depth, 
											'ClassFilterType' => 'include', 
											'ClassFilterArray' => array( 'vzt_event' ) ) ) ;
											
											
		$i=0;
		
		$returnArr = array();
	
		foreach ($events as $event){
			$returnArr[$i] = $event->attribute( 'main_node_id' );
			$i++;
		}
		
		
		return $returnArr;
	}
	public function get_events()
	{
	
		
	
		$this->EventSource = $this->initiate_events();
		
		$i=0;
		$eventArray = array();
		
		foreach($this->EventSource as $eventNode)
		{
		
				$year = date('Y');
				$month = date('m');
		
				$ev = eZContentObjectTreeNode::fetch( $eventNode );
				
				$datamap = $ev->attribute( 'data_map' );
				$att = $datamap['short_title'];
				$title = $att->attribute('data_text');
				
				$att = $datamap['from_time'];
				$content = $att->attribute('content');
				$from_timestamp = $content->attribute('timestamp');
				$from_date = date("Y-m-d H:i", $from_timestamp);
				
				$att = $datamap['to_time'];
				$content = $att->attribute('content');
				$to_timestamp = $content->attribute('timestamp');
				$to_date = date("Y-m-d H:i", $to_timestamp);
				
				$att = $datamap['recurring_event'];
				$recurring = $att->attribute('data_text');
				
				$att = $datamap['category'];
				$category = $att->attribute('data_text');
				
				
				if($recurring!='0')
				{				
					 $recurring_events = $this->make_recurring_events($eventNode,$ev,$recurring);
					 
					 $num_events = count($recurring_events);
					 
					 $z = $i;
					 
					 foreach($recurring_events as $re){
					 	$this->Events[$z] = $re;
						$z++;
					 }
					 
					 $i = $i + $num_events;
					 
					 $recurring_events = "";
					 
				} 
				else
				{
					if(($this->start<=$from_timestamp) && ($this->ends>=$to_timestamp)){
					
						$eventArray['id'] = $eventNode;
						$eventArray['title'] = $title;
						$eventArray['start'] = $from_date;
						$eventArray['end'] = $to_date;
						if($category>0){
							$eventArray['className'] = "ev_cat_" . $category;
						}
						else{
							$eventArray['className'] = "default";
						}
						
						$att = $datamap['all_day'];
						$all_day = $att->attribute('data_int');
										  
						if($all_day==1){
							$eventArray['allday'] = true;
						}
						
						$this->Events[$i] = $eventArray;
						
						$i++;
						
					}
					
				}

				$eventArray = array();
				
		}
		
		return $this->Events;
	}
	
	private function make_recurring_events($eventNode,$ev,$recurring){
	
			$datamap = $ev->attribute( 'data_map' );
			$att = $datamap['short_title'];
			$title = $att->attribute('data_text');
			
			$att = $datamap['from_time'];
			$content = $att->attribute('content');
			$from_timestamp = $content->attribute('timestamp');
			$from_date = date("Y-m-d H:i", $from_timestamp);
			
			$att = $datamap['to_time'];
			$content = $att->attribute('content');
			$to_timestamp = $content->attribute('timestamp');
			$to_date = date("Y-m-d H:i", $to_timestamp);
			
			$att = $datamap['all_day'];
			$all_day = $att->attribute('data_int');
			
			$att = $datamap['category'];
			$category = $att->attribute('data_text');
			
			
			
			$eventArray = array();	
			
			switch($recurring){
			
				case '2':
				{
				
					$week_day = date('w',$from_timestamp);
					$week = date('W',$from_timestamp);
					
					$year = date('Y');
					
					$num_weeks = (date("W", mktime(0,0,0,12,31,$year)))*10;
	
					$timestamp = $from_timestamp; 
					
					if(($this->start<=$from_timestamp) && ($this->ends>=$to_timestamp)){
						$eventArray[$week]['id'] = $eventNode;
						$eventArray[$week]['title'] = $title;
						$eventArray[$week]['start'] = $from_date;
						$eventArray[$week]['end'] = $to_date;
						if($category>0){
							$eventArray[$week]['className'] = "ev_cat_" . $category;
						}
						else{
							$eventArray[$week]['className'] = "default";
						}
						$week++;
					}
					
					for($i=$week;$i<$num_weeks;$i++) 
					{ 
					    $timestamp = strtotime('+1 week', $timestamp); 
					  
					  	if(($this->start<=$timestamp) && ($this->ends>=$timestamp)){
							$eventArray[$i]['id'] = $eventNode;
							$eventArray[$i]['title'] = $title;
							$eventArray[$i]['start'] = date('Y-m-d '.date('H:i',$from_timestamp), $timestamp);
							$eventArray[$i]['end'] = date('Y-m-d '.date('H:i',$to_timestamp), $timestamp);
							if($category>0){
								$eventArray[$i]['className'] = "ev_cat_" . $category;
							}	
							else{
								$eventArray[$i]['className'] = "default";
							}
						}	
					  		
					}  	
	
	
					
				} break;
				
				case '3':
				{
				
					$day = date('d',$from_timestamp);
					$month = date('m',$from_timestamp);
					
					$num_months = 24*10;
	
					$timestamp = $from_timestamp; 
					
					$i = 1;
					
					if(($this->start<=$from_timestamp) && ($this->ends>=$to_timestamp)){
						$eventArray[$i]['id'] = $eventNode;
						$eventArray[$i]['title'] = $title;
						$eventArray[$i]['start'] = $from_date;
						$eventArray[$i]['end'] = $to_date;
						if($category>0){
							$eventArray[$i]['className'] = "ev_cat_" . $category;
						}
						else{
							$eventArray[$i]['className'] = "default";
						}
					}
					
					for($i=2;$i<$num_months;$i++) 
					{ 
					    $timestamp = strtotime('+1 month', $timestamp); 
					  
					  	if(($this->start<=$timestamp) && ($this->ends>=$timestamp)){
							$eventArray[$i]['id'] = $eventNode;
							$eventArray[$i]['title'] = $title;
							$eventArray[$i]['start'] = date('Y-m-d '.date('H:i',$from_timestamp), $timestamp);
							$eventArray[$i]['end'] = date('Y-m-d '.date('H:i',$to_timestamp), $timestamp);
							if($category>0){
								$eventArray[$i]['className'] = "ev_cat_" . $category;
							}
							else{
								$eventArray[$i]['className'] = "default";
							}	
					  	}	
					}  	
					
				} break;			
			
			}
			
			return $eventArray;
			
			$eventArray = array();
			
	}	
	
	public function get_spec_event()
	{
	
		$ev = eZContentObjectTreeNode::fetch( $this->NodeId );
		
		$datamap = $ev->attribute( 'data_map' );
		$att = $datamap['title'];
		$title = $att->attribute('data_text');
		
		$att = $datamap['recurring_event'];
		$recurring = $att->attribute('data_text');
		
		$att = $datamap['category'];
		$category = $att->attribute('class_content');
		$options = $category['options'];
		$name = $options[$att->attribute('data_text')];
			
				
		
		$att = $datamap['location'];
		$location = $att->attribute('data_text');
		
		$att = $datamap['text'];
		$text = $att->attribute('data_text');
		
		$eventArray = array();
		
		
		$category = $name['name'];
	
		
		$eventArray['title'] = $title;
		$eventArray['category'] = $category;
		$eventArray['recurring_event'] = $recurring;
		$eventArray['location'] = $location;
		$eventArray['text'] = $text;
		
		
		return $eventArray;
	}

}

?>
