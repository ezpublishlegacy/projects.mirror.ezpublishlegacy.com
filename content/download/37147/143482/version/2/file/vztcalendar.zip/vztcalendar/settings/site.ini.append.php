<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=vztcalendar


[RoleSettings]
PolicyOmitList[]=vztcalendar/calendar
PolicyOmitList[]=vztcalendar/event




*/ ?>