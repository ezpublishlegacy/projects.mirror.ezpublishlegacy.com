<?php /* #?ini charset="utf-8"?

[SiteAccessSettings]
AnonymousAccessList[]=vlogin

[RoleSettings]
PolicyOmitList[]=vlogin

#[UserSettings]
#LogoutRedirect=/vlogin/login

*/
?>
