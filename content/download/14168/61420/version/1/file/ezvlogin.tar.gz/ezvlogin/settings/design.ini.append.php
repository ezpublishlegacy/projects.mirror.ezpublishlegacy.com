<?php /* #?ini charset="utf-8"?

# Copy amd uncomment the following to your own settings
# if you wan to use template based isntead of url
# redirect method


#[ExtensionSettings]
#DesignExtensions[]=ezvlogin

*/
?>
