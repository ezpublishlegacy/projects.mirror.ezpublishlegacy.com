<?php /* #?ini charset="utf-8"?

[googlesitemap_view]
Source=googlesitemapdynamic/sitemap.tpl
MatchFile=googlesitemapdynamic/sitemap.tpl
Subdir=templates

[googlesitemap_node_view]
Source=node/view/googlesitemap.tpl
MatchFile=googlesitemapdynamic/sitemap.tpl
Subdir=templates

*/ ?>