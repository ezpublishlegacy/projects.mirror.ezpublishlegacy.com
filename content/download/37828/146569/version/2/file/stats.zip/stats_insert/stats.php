<?
	$r_addr = getenv("REQUEST_URI");
	
	if (isset($HTTP_GET_VARS["ref"])) {
		$referrer = $HTTP_GET_VARS["ref"];
	} else {
		$referrer = getenv("HTTP_REFERER");
	}
	
	$v_date = date("Y-m-d");
	$v_day = intval(date("d"));
	$v_month = intval(date("m"));
	$v_year = intval(date("Y"));

include_once( "stats.inc.php" );

/* add here a descriptive name and the url */
$arrURLItems = Array (
				array("First Page","first_page"),
				array("Second Page","second_page"),
				array("And so on","and_so_on"),
				);
				
	$ismatched = false;

	foreach($arrURLItems as $key => $value) {
	   if (strpos ($r_addr,$value[1]) && !$ismatched) {
		  $page = $value[0];
		  $ismatched = true;
	   } 
	}

    if ($ismatched) {
		$query = "update tracker_url_items set count = count+1 ";
		$query .= "where page LIKE '".$page."' ";
		$query .= "and day LIKE '".$v_day."'";
		$query .= "and month LIKE '".$v_month."'";
		$query .= "and year LIKE '".$v_year."'";

		mysql_query($query); 
		if (mysql_affected_rows()>0) {
	//		echo "Update ok";
		} else {
			$query = "insert into tracker_url_items (page, date, day, month, year, count) ";
			$query .= "VALUES ('".$page."', '".$v_date ."', '".$v_day ."', '".$v_month ."', '".$v_year ."', 1)";
			$result = mysql_query($query); 	    	
		}
	} 



	if (!empty ($referrer)) {
		$parsed_referrer = parse_url($referrer);

		if (isset($parsed_referrer["host"])) 
			$parsed_referrer_host = $parsed_referrer["host"];
		else 
			$parsed_referrer_host = $referrer;

		echo "<!-- $parsed_referrer_host -->";

	// referrer part
		$query = "update tracker_referrer_items set count = count+1 ";
		$query .= "where referrer LIKE '".$parsed_referrer_host."' ";
		$query .= "and day LIKE '".$v_day."'";
		$query .= "and month LIKE '".$v_month."'";
		$query .= "and year LIKE '".$v_year."'";

		mysql_query($query); 
	//		echo "<hr>".mysql_affected_rows()."<hr>";
		if (mysql_affected_rows()>0) {
	//		echo "Update ok";
		} else {
			$query = "insert into tracker_referrer_items (referrer, date, day, month, year, count) ";
			$query .= "VALUES ('".$parsed_referrer_host."', '".$v_date ."', '".$v_day ."', '".$v_month ."', '".$v_year ."', 1)";
			$result = mysql_query($query); 	  
		}
	}
	mysql_close($link);
?>