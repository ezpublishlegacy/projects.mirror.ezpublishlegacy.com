CREATE TABLE tracker_referrer_items (
   referrer varchar(255) NOT NULL default '',
   date date NOT NULL default '0000-00-00',
   day int(4) NOT NULL default '0',
   month int(4) NOT NULL default '0',
   year int(4) NOT NULL default '0',
   count int(5) NOT NULL default '0',
   PRIMARY KEY  (referrer,day,month,year)
) TYPE=MyISAM;

CREATE TABLE tracker_url_items (
  page varchar(255) NOT NULL default '',
  date date NOT NULL default '0000-00-00',
  day int(4) NOT NULL default '0',
  month int(4) NOT NULL default '0',
  year int(4) NOT NULL default '0',
  count int(5) NOT NULL default '0',
  PRIMARY KEY  (page,day,month,year)
) TYPE=MyISAM;