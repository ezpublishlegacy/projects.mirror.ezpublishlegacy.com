<html><title>Stats View</title>
<style type="text/css">
body {
	font-family:Arial,sans-serif;
	font-size: 12px;
	text-align:center; 
}

table {
  border-width:1px;
  border-style:solid;
  border-color:#006633;

  border-width:1px;
  border-style:solid;
  border-color:#006633;  
  
  padding:1cm;
  text-align:justify; 
  margin:10px;
}
td {	
	border-right-width:1px;
	border-right-color:#006633;
	border-right-style:dotted;
	
	border-bottom-width:1px;
	border-bottom-color:#006633;
	border-bottom-style:dotted;
	
	font-size: 12px;
	padding:2px;
}
</style>

<head></head>
<body>
<p>Evaluation of the website</p>
<?
	$date = date("Y-m-d");

include_once( "stats.inc.php" );

	?>
	<p>Choose the period</p>
	<?
	echo "<form action='".$PHP_SELF."' method='post'>";
	
	$query = "select distinct(year) from tracker_referrer_items ";
	$query .= "ORDER BY year ASC";
	$result = mysql_query($query); 

	echo "<select name='year'>";
	echo "<option value='%'>year</option>";
	echo "<option value='%'>all </option>";
	echo "<option value='%'>....</option>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		if ( (isset($HTTP_POST_VARS['year'])) && ($HTTP_POST_VARS['year'] == $row["year"]) ) {
			echo "<option value='".$row["year"]."' selected>".$row["year"]."</option>";
		} else {
			echo "<option value='".$row["year"]."'>".$row["year"]."</option>";
		}
	}
	echo "</select>";

	$query = "select distinct(month) from tracker_referrer_items ";
	$query .= "ORDER BY month ASC";
	$result = mysql_query($query); 

	echo "<select name='month'>";
	echo "<option value='%'>month</option>";
	echo "<option value='%'>all</option>";
	echo "<option value='%'>....</option>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		if ( (isset($HTTP_POST_VARS['month'])) && ($HTTP_POST_VARS['month'] == $row["month"]) ) {
			echo "<option value='".$row["month"]."' selected>".$row["month"]."</option>";
		} else {
			echo "<option value='".$row["month"]."'>".$row["month"]."</option>";
		}
	}
	echo "</select>";

	$query = "select distinct(day) from tracker_referrer_items ";
	$query .= "ORDER BY day ASC";
	$result = mysql_query($query); 

	echo "<select name='day'>";
	echo "<option value='%'>day</option>";
	echo "<option value='%'>all</option>";
	echo "<option value='%'>....</option>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		if ( (isset($HTTP_POST_VARS['day'])) && ($HTTP_POST_VARS['day'] == $row["day"]) ) {
			echo "<option value='".$row["day"]."' selected>".$row["day"]."</option>";
		} else {
			echo "<option value='".$row["day"]."'>".$row["day"]."</option>";
		}
	}
	echo "</select>";


	echo "<input type='submit' value='select' name='submit'>";
	echo "</form>";
	mysql_free_result($result);
	



	?>
	<p>Count of direct links (referrer)</p>
	<?

	$query = "select * from tracker_referrer_items ";
	if (isset($HTTP_POST_VARS['submit'])) {
		$query .= " WHERE year LIKE '".$HTTP_POST_VARS['year']."' ";
		$query .= " AND month LIKE '".$HTTP_POST_VARS['month']."' ";
		$query .= " AND day LIKE '".$HTTP_POST_VARS['day']."' ";
	} else {
		$query .= " WHERE year LIKE '".$year."' ";
		$query .= " AND month LIKE '".$month."' ";
		$query .= " AND day LIKE '".$day."' ";
	}
	$query .= "ORDER BY year ASC, count DESC";
	$query .= " LIMIT 50";
	
	$result = mysql_query($query); 	
	echo "<table>";
	echo "<tr><td><b>year-month-day</b></td><td><b>Referrer</b></td><td><b>Hits</b></td></tr>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr><td>".$row["year"].'-'.$row["month"].'-'.$row["day"]."</td><td>".$row["referrer"]."</td><td>".$row["count"]."</td></tr>";
	}
	echo "</table>";
	mysql_free_result($result);
	
	
	
	?>
	<p>Most frequent areas</p>
	<?	
	
	$query = "select * from tracker_url_items ";
	if (isset($HTTP_POST_VARS['submit'])) {
		$query .= " WHERE year LIKE '".$HTTP_POST_VARS['year']."' ";
		$query .= " AND month LIKE '".$HTTP_POST_VARS['month']."' ";
		$query .= " AND day LIKE '".$HTTP_POST_VARS['day']."' ";
	} else {
		$query .= " WHERE year LIKE '".$year."' ";
		$query .= " AND month LIKE '".$month."' ";
		$query .= " AND day LIKE '".$day."' ";
	}

	$query .= "ORDER BY date ASC, count DESC";
	$query .= " LIMIT 50";
	
	$result = mysql_query($query); 	
	echo "<table>";
	echo "<tr><td><b>year-month-day</b></td><td><b>Area</b></td><td><b>Hits</b></td></tr>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr><td>".$row["year"].'-'.$row["month"].'-'.$row["day"]."</td><td>".$row["page"]."</td><td>".$row["count"]."</td></tr>";
	}
	echo "</table>";
	mysql_free_result($result);
	

	

	mysql_close($link);
?>