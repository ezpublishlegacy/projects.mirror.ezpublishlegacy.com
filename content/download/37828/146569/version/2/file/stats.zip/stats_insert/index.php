<?php
// Copyright (C) 1999-2004 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//

code ....


eZExecution::setCleanExit();

//xdebug_dump_function_profile( 4 );
include_once( "stats.php" );
?>
