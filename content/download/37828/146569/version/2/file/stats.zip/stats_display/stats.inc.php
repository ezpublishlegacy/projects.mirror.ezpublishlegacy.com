<?
$link = mysql_connect("localhost", "user", "passwd");
mysql_select_db("db") or die("Error");
?>