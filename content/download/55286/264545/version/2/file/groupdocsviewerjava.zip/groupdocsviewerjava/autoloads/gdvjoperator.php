<?php
 
// Which operators will load automatically? 
$eZTemplateOperatorArray = array();
 
// Operator: gvddata 
$eZTemplateOperatorArray[] = array( 'class' => 'GVDJOperator',
                                    'operator_names' => array( 'gdvj' ) ); 
?>