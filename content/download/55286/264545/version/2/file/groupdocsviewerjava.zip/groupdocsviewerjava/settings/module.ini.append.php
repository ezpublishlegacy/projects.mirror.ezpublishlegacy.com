<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsviewerjava
ModuleList[]=groupdocsviewerjava
*/ ?>