<?php /*
[NavigationPart]
Part[groupdocsviewerjavanavigationpart]=GD Viewer Java
[TopAdminMenu]
Tabs[]=groupdocsviewerjava
[Topmenu_groupdocsviewerjava]
NavigationPartIdentifier=groupdocsviewerjavanavigationpart
Name=Groupdocs Viewer for Java
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsviewerjava/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>