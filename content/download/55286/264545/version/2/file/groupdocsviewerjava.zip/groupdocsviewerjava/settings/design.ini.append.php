<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsviewerjava

#[StylesheetSettings]
#BackendCSSFileList[]=gdviewerjava_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdviewerjava.js
*/ ?>