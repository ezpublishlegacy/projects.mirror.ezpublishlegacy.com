<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>extension/ngclasslist/datatypes</name>
    <message>
        <source>Class list</source>
        <translation>Odabir klasa</translation>
    </message>
    <message>
        <source>Class with identifier '%identifier%' does not exist</source>
        <translation>Klasa sa identifikatorom '%identifier%' ne postoji</translation>
    </message>
    <message>
        <source>Classes with '%identifiers%' identifiers do not exist</source>
        <translation>Klase sa '%identifiers%' identifikatorima ne postoje</translation>
    </message>
    <message>
        <source>No classes</source>
        <translation>Nema klasa</translation>
    </message>
</context>
</TS>
