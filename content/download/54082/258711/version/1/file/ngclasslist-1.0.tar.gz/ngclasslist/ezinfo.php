<?php

class ngclasslistInfo
{
    static function info()
    {
        return array(
            "Name" => "<a href=\"http://projects.ez.no/ngclasslist\">Netgen Class List Datatype</a> extension",
            "Version" => "1.0",
            "Copyright" => "Copyright (C) 2014 Netgen d.o.o.",
            "License" => "GNU General Public License v2.0"
        );
    }
}
