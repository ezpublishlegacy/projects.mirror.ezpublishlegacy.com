<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=eztidy

[OutputSettings]
#OutputFilterName=eZTidyFilter

*/ ?>