<?php
//
// Created on: <20-09-2006> pike@labforculture.org
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//




include_once( 'kernel/common/template.php' );
include_once( "lib/ezutils/classes/ezhttptool.php" );

$Module = $Params['Module'];
$suite=$Params['suite'];
$page=$Params['page'];
if (!$page) $page = "01";

$http = eZHTTPTool::instance();


$node_id 			= ($http->hasVariable("node_id"))?$http->variable("node_id"):null;
$versionnr 			= ($http->hasVariable("version"))?$http->variable("version"):null;


$Result = array();

$vars = array();
$vars["node_id"] 		= $node_id;
$vars["version"] 		= $versionnr;
		
$tpl = templateInit();
$tpl->setVariable( 'result', $vars );
	
if ($suite && $page) {
	$Result['content'] = $tpl->fetch( "design:customedit/testsuite/$suite/$page.tpl" );
} else {
	$Result['content'] = $tpl->fetch( "design:customedit/testsuite/index.tpl" );
}



if ($suite) {
	$Result['path'] = array(
					array( 'url' => false,	'text' => "CustomEdit"  ),
					array( 'url' => $Module->Functions["testsuite"]["uri"],	'text' => 'testsuite' ),
					array( 'url' => $Module->Functions["testsuite"]["uri"]."/$suite",	'text' => $suite) 
				);
} else {
	$Result['path'] = array(
					array( 'url' => false,	'text' => "CustomEdit" ),
					array( 'url' => $Module->Functions["testsuite"]["uri"],	'text' => 'testsuite' ),
				);

}
?>