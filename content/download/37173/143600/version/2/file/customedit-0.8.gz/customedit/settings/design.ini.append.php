<?php
/*
[ExtensionSettings]
DesignExtensions[]=customedit
*/
?>