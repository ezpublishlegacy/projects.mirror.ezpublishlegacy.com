<?php
/*
[ModuleSettings]
ExtensionRepositories[]=customedit

[CustomEditSettings]

DefaultSuccessTemplate=customedit/success.tpl
DefaultErrorTemplate=customedit/error.tpl
DefaultClassIdentifier=demo
DefaultParentNodeID=2
DefaultLocale=eng-GB
DefaultMoveToTrash=1

demo_inisetting=scary

*/
?>
