<?php
	//
	// Created on: <2007-04-10> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//

	/*
		This script ...
		
	*/

	include_once( 'kernel/common/template.php' );
	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( "extension/customedit/classes/CustomEditLib.php" );

	define( "MODULE_INI_FILE", "module.ini" );


	$Module = $Params['Module'];
	$modulename = $Module->Name;

	$inifile = eZINI::instance( MODULE_INI_FILE,"extension/customedit/settings" );
	$inisection = 'CustomEditSettings';

	$http = eZHTTPTool::instance();

	// get params from query string or defaults
	$successtpl 		= ($http->hasVariable("successtpl")) ?$http->variable("successtpl"):$inifile->variable( $inisection, 'DefaultSuccessTemplate' );
	$errortpl 			= ($http->hasVariable("errortpl")) ?$http->variable("errortpl"):$inifile->variable( $inisection, 'DefaultErrorTemplate' );
	$successuri 		= ($http->hasVariable("successuri")) ?$http->variable("successuri"):false;
	$erroruri 			= ($http->hasVariable("erroruri")) ?$http->variable("erroruri"):false;
	$node_id 			= ($http->hasVariable("node_id")) ?$http->variable("node_id"):null;
	$movetotrash 		= ($http->hasVariable("do_movetotrash")) ?$http->variable("status"):$inifile->variable( $inisection, 'DefaultMoveToTrash' );

	// perform action, store results in $result
	$success = true; //optimist
	$result = array();
	$report = "";
	
	
	// -- action
	$success = CustomEditLib::deleteNode($report,$node_id,$movetotrash);
	
	if ($success && $successuri) {
		return $Module->redirectTo( $successuri );
	} elseif (!$success && $erroruri) {
		return $Module->redirectTo( $erroruri );
	} else {
	
		// pass request fields
		$version = null;
		$request = CustomEditLib::filterRequest($report,array_merge($_REQUEST,$_FILES),$version);
		
		if (!$success) {
			$result["error"] 		= true;
			$result["message"] 		= $report;
			$result["node_id"] 		= $node_id;
		} else {
			$result["error"] 		= false;
			$result["message"]		= "Node successfully deleted";
		}
	
		$tpl = templateInit();
		$tpl->setVariable( 'request', $request );
		$tpl->setVariable( 'result', $result );
	
		if ($success) {
			
			//print "success";
			//print $successtpl;
			$Result['content'] = $tpl->fetch( "design:$successtpl");
			$Result['path'] = array(
				array( 'url' => false,	'text' => 'CustomEdit' ),
				array( 'url' => false, 	'text' => 'Success' )
			);
	
		} else {
		
			//print $report;
			//print $errortpl;
			$Result['content'] = $tpl->fetch( "design:$errortpl");
			$Result['path'] = array(
				array( 'url' => false,	'text' => 'CustomEdit' ),
				array( 'url' => false, 	'text' => 'Error' )
			);
			
	
		}
	}

?>