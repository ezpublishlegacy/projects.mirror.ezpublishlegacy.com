<?php
	//
	// Created on: <2007-04-10> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//

	/*
		This script locates node with $node_id and $version from the qeurystring,
		loops all its attributes and checks if there are equivalent values in the query string.
		If so, sets these, stores the version. 
		if $publish=true or 1, changes the status and puts the current published to archived
		
	*/

	include_once( 'kernel/common/template.php' );
	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( "extension/customedit/classes/CustomEditLib.php" );
	include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );

	define( "MODULE_INI_FILE", "module.ini" );

	$Module = $Params['Module'];
	$modulename = $Module->Name;

	$inifile = eZINI::instance( MODULE_INI_FILE,"extension/customedit/settings" );
	$inisection = 'CustomEditSettings';

	$http = eZHTTPTool::instance();

	// get params from query string or defaults
	$successtpl 		= ($http->hasVariable("successtpl")) ?$http->variable("successtpl"):$inifile->variable( $inisection, 'DefaultSuccessTemplate' );
	$errortpl 			= ($http->hasVariable("errortpl")) ?$http->variable("errortpl"):$inifile->variable( $inisection, 'DefaultErrorTemplate' );
	$successuri 		= ($http->hasVariable("successuri")) ?$http->variable("successuri"):false;
	$erroruri 			= ($http->hasVariable("erroruri")) ?$http->variable("erroruri"):false;
	$node_id 			= ($http->hasVariable("node_id")) ?$http->variable("node_id"):null;
	$versionnr 			= ($http->hasVariable("version")) ?$http->variable("version"):null;
	$locale 			= ($http->hasVariable("locale")) ?$http->variable("locale"):$inifile->variable( $inisection, 'DefaultLocale' );
	$do_newdraft	 	= ($http->hasVariable("do_newdraft"))?($http->variable("do_newdraft")=="true"||$http->variable("do_newdraft")==1):false;
	$do_publish 		= ($http->hasVariable("do_publish"))?($http->variable("do_publish")=="true"||$http->variable("do_publish")==1):false;
	$set_parentnode_id 	= ($http->hasVariable("set_parentnode_id")) ?$http->variable("set_parentnode_id"):null;
	$add_parentnode_id 	= ($http->hasVariable("add_parentnode_id")) ?$http->variable("add_parentnode_id"):null;
	$set_creator 		= ($http->hasVariable("set_creator")) ?$http->variable("set_creator"):null;
	$set_owner 			= ($http->hasVariable("set_owner")) ?$http->variable("set_owner"):null;
	$set_modified 		= ($http->hasVariable("set_modified")) ?$http->variable("set_modified"):null;
	$set_published 		= ($http->hasVariable("set_published")) ?$http->variable("set_published"):null;

	if ($http->hasVariable("set_hidden")) {
		if ($http->variable("set_hidden")=="true"||$http->variable("set_hidden")==1) $set_hidden=true;
		else $set_hidden = false;
	} else $set_hidden = null;
	
	// perform action, store results in $result
	
	$success = true; //optimist
	$result = array();
	$request = compact(
		"successtpl","errortpl","successuri","erroruri","node_id","versionnr",
		"locale","do_newdraft","do_publish","set_parentnode_id","add_parentnode_id",
		"set_creator","set_owner","set_modified","set_published","set_hidden"
	);
	$hilite = array();
	$report = "";
	
	// -- action
	$version = CustomEditLib::getVersion($report,$node_id,$versionnr,$do_newdraft,$locale);
	
	if ($version) {
		$versionnr = $version->attribute( 'version' );
		// remember if we need to republish the changes on success
		$is_published = ($version->attribute( 'status' )==eZContentObjectVersion::STATUS_PUBLISHED);
		$attresults = CustomEditLib::setAttributes($report,$version,array_merge($_REQUEST,$_FILES),$locale);
		foreach ($attresults as $attrname=>$attresult) {
			if (!$attresult) {
				$success = false;
				$hilite[] = $attrname;
			}
		}

		if ($success && $set_parentnode_id) $success = CustomEditLib::moveNode($report,$node_id,$set_parentnode_id);
		if ($success && $add_parentnode_id) $success = CustomEditLib::addParentNode($report,$node_id,$add_parentnode_id);
		if ($success && ($do_publish||$is_published)) $success = CustomEditLib::publishVersion($report,$version);
		if ($success && $set_creator) $success = CustomEditLib::setCreator($report,$node_id,$set_creator);
		if ($success && $set_owner) $success = CustomEditLib::setOwner($report,$node_id,$set_owner);
		if ($success && $set_modified) $success = CustomEditLib::setModified($report,$node_id,$set_modified);
		if ($success && $set_published) $success = CustomEditLib::setPublished($report,$node_id,$set_published);
		if ($success && $set_hidden===true) $success = CustomEditLib::hideNode($report,$node_id, true);
		if ($success && $set_hidden===false) $success = CustomEditLib::hideNode($report,$node_id,false);

		// pass request fields
		$requested_attrs = CustomEditLib::filterRequest($report,array_merge($_REQUEST,$_FILES),$version);
		$request = array_merge($request,$requested_attrs);
		

	} else {
		$success = $false;
	}
	
	// done. generate result page
	
	if ($success && $successuri) {
		return $Module->redirectTo( $successuri );
	} elseif (!$success && $erroruri) {
		return $Module->redirectTo( $erroruri );
	} else {
	
		if (!$success) {
			$result["error"] 		= true;
			$result["message"] 		= $report;
			$result["node_id"] 		= $node_id;
			$result["version"] 		= $versionnr;
			$result["locale"] 		= $locale;
			$result["hilite"]		= $hilite;
		} else {
			$result["error"] 		= false;
			$result["message"]		= "Node successfully modified";
			$result["node_id"] 		= $node_id;
			$result["version"] 		= $versionnr;
			$result["locale"] 		= $locale;
			$result["hilite"]		= $hilite;
		}
	
		$tpl = templateInit();
		$tpl->setVariable( 'request', $request );
		$tpl->setVariable( 'result', $result );
		
	
		
		if ($success) {
			//print "success";
			//print $successtpl;
			$Result['content'] = $tpl->fetch( "design:$successtpl");
			$Result['path'] = array(
				array( 'url' => false,	'text' => 'CustomEdit' ),
				array( 'url' => false, 	'text' => 'Success' )
			);
	
		} else {
		
			//print $report;
			//print $errortpl;
			$Result['content'] = $tpl->fetch( "design:$errortpl");
			$Result['path'] = array(
				array( 'url' => false,	'text' => 'CustomEdit' ),
				array( 'url' => false, 	'text' => 'Error' )
			);
			
	
		}
	}
	
?>