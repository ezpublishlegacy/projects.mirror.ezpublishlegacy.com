<?php

/* pike 200607, idea stolen from
	http://ez.no/products/ez_publish/documentation/development/importing_attribute_data
	but updated for ezp4.
*/


include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );

class fakeXMLHTTPInput {
	
	/*
		this class pretends to be a ezhttphandler
		object, implementing hasPostVariable and
		postVariable for one specific attribute.
		
		ezpublish input handlers depend on these post variables,
		with these specific names, to do its voodoo. 
		which is a bad idea. nuf ranted.
		
	*/
	
	var $name;
	var $value;
	
	function fakeXMLHTTPInput($data,$base,$contentObjectAttribute) {
		$contentObjectAttributeID = $contentObjectAttribute->attribute('id');
	 	$this->name = $base.'_data_text_'.$contentObjectAttributeID;
	 	$this->value = $data;
	}
	function hasPostVariable($name) { return ($name==$this->name); }
	function postVariable($name) { return ($name==$this->name)?$this->value:null;}
}

class ezXMLTextConverter extends eZSimplifiedXMLInput {

	function ezXMLTextConverter( $xmlData, $contentObjectAttribute ) {
		$this->eZSimplifiedXMLInput( $xmlData, 0, $contentObjectAttribute );
	}

 	function validateText( $data, $contentObjectAttribute ) {
 		$base = "BASE"; // anything
 		$fakehttp = new fakeXMLHTTPInput($data,$base,$contentObjectAttribute);
 		return $this->validateInput($fakehttp,$base,$contentObjectAttribute);
 	
 	}
}
 		
?>
 		