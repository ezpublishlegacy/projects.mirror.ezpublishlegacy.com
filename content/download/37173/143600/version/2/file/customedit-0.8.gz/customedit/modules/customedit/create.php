<?php
	//
	// Created on: <2007-04-10> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//

	// this script creates a new node

	// query string should pass
	//	class_identifier
	//	parentnode_id
	//	status
	//	tplnext	- template to load on success
	//	tplerror - template to load on error

	//

	include_once( 'kernel/common/template.php' );
	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( "extension/customedit/classes/CustomEditLib.php" );

	define( "MODULE_INI_FILE", "module.ini" );
	
	$Module = $Params['Module'];
	$modulename = $Module->Name;

	$inifile = eZINI::instance( MODULE_INI_FILE,"extension/customedit/settings" );
	$inisection = 'CustomEditSettings';

	$http = eZHTTPTool::instance();

	// get params from query string or defaults
	$successtpl 		= ($http->hasVariable("successtpl")) ?$http->variable("successtpl"):$inifile->variable( $inisection, 'DefaultSuccessTemplate' );
	$errortpl 			= ($http->hasVariable("errortpl")) ?$http->variable("errortpl"):$inifile->variable( $inisection, 'DefaultErrorTemplate' );
	$successuri 		= ($http->hasVariable("successuri")) ?$http->variable("successuri"):false;
	$erroruri 			= ($http->hasVariable("erroruri")) ?$http->variable("erroruri"):false;
	$class_identifier 	= ($http->hasVariable("class_identifier")) ?$http->variable("class_identifier"):$inifile->variable( $inisection, 'DefaultClassIdentifier' );
	$parentnode_id 		= ($http->hasVariable("parentnode_id")) ?$http->variable("parentnode_id"):$inifile->variable( $inisection, 'DefaultParentNodeID' );
	$locale 			= ($http->hasVariable("locale")) ?$http->variable("locale"):$inifile->variable( $inisection, 'DefaultLocale' );
	if ($http->hasVariable("set_hidden")) {
		if ($http->variable("set_hidden")=="true"||$http->variable("set_hidden")==1) $set_hidden=true;
		else $set_hidden = false;
	} else $set_hidden = null;
		
	// perform action, store results in $result
	// in this view, the new object always has to be published
	// in order to get a node. 
	
	$success = true; //optimist
	$result = array();
	$request = array();
	$version = null;
	$report = "";

	$node_id = CustomEditLib::newBlankNode($report,$class_identifier,$parentnode_id,$locale);
	if ($node_id) {
		
		$version = CustomEditLib::getVersion($report,$node_id);

		if ($version) {
			
			$attresults = CustomEditLib::setAttributes($report,$version,array_merge($_REQUEST,$_FILES),$locale);
			foreach ($attresults as $attrname=>$attresult) {
				if (!$attresult) {
					$success = false;
					$hilite[] = $attrname;
				}
			}
			// publish changes too
			if ($success && count($attresults)) $success = CustomEditLib::publishVersion($report,$version);
			
			// new node is published/visible by default
			if ($success && $set_hidden) $success = CustomEditLib::hideNode($report,$node_id, true);

			// pass request fields
			$request = CustomEditLib::filterRequest($report,array_merge($_REQUEST,$_FILES),$version);
			
		} else $success = false;
		
	} else $success = false;
	
	// done. generate result page
	
	if ($success && $successuri) return $Module->redirectTo( $successuri );
	if (!$success && $erroruri) return $Module->redirectTo( $erroruri );
	
	if ($success) {
		$result["error"] 		= false;
		$result["message"]		="Node successfully created";
		$result["node_id"] 		= $node_id;
		$result["version"] 		= 1;
		$result["locale"] 		= $locale;
		$result["hilite"]		= array();
	} else {
		$result["error"] 		= true;
		$result["message"]		= $report;
		$result["node_id"] 		= null;
		$result["version"] 		= null;
		$result["locale"] 		= null;
		$result["hilite"]		= array();
	}
	
	$tpl = templateInit();
	$tpl->setVariable( 'request', $request );
	$tpl->setVariable( 'result', $result );
	

	if ($success) {
	
		//print "success";
		//print $successtpl;
		$Result['content'] = $tpl->fetch( "design:$successtpl");
		$Result['path'] = array(
			array( 'url' => false,	'text' => 'CustomEdit' ),
			array( 'url' => false, 	'text' => 'Success' )
		);		

	} else {
		
		//print $report;
		//print $errortpl;
		$Result['content'] = $tpl->fetch( "design:$errortpl");
		$Result['path'] = array(
			array( 'url' => false,	'text' => 'CustomEdit' ),
			array( 'url' => false, 	'text' => 'Error' )
		);

	}

?>