<?php
	//
	// Created on: <2008/04/10>
	// Edited on: 2008/04/10*pike 0.5
	//
	// Copyright (C) 2005-2004 pike@labforculture.org. All rights reserved.
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//
	/*

	*/

	//define( "MODULE_INI_FILE", "module.ini" );

	include_once( 'kernel/classes/ezcontentfunctions.php');
	include_once( 'lib/ezutils/classes/ezstringutils.php');
	include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
	include_once( 'lib/ezlocale/classes/ezdatetime.php' );


	/*

		include_once( 'kernel/classes/ezdatatype.php' );
		include_once( 'kernel/classes/datatypes/ezimage/ezimage.php' );
		include_once( 'kernel/classes/datatypes/ezauthor/ezauthor.php' );
		include_once( 'kernel/classes/ezcontentobject.php' );
		include_once( 'kernel/classes/ezsearch.php' );
		include_once( 'lib/ezlocale/classes/ezdate.php' );
		include_once( 'lib/ezutils/classes/ezmail.php' );
		include_once( 'lib/ezutils/classes/ezmimetype.php' );
		include_once( 'lib/ezutils/classes/ezini.php' );
		include_once( 'lib/ezutils/classes/ezdir.php' );
		include_once( 'ezXMLTextConverter.php' );

	*/

	class CustomEditLib {

		const ATTRIBUTE_OK = 10;
		const ERROR_NODE_CANTCREATE = 100;
		const ERROR_NODE_CANTMODIFY = 110;
		const ERROR_ATTRIBUTE_CANTSET = 200;
		const ERROR_ATTRIBUTE_MISSING = 210;
		const ERROR_ATTRIBUTE_OUTOFRANGE = 220;


		/*
			$report is used internally. yes, you can take it to the
			front end, but its hardly human interface savvy
		*/

		static function report($report,$msg,$error=false) {
			$report .= "$msg\n";
			if ($error) eZDebug::writeError( $msg, 'CustomEditLib' );
			else eZDebug::writeDebug( $msg, 'CustomEditLib' );
		}



		/*
			newNode wrapper method.
			wraps newBlankNode, getVersion, setAttributes, checkAttributes, publishVersion

			the node is published visible by default
			if you want more fine-grained control, use the
			core methods, not this wrapper

			returns hash of results

		*/

		static function newNode($class_identifier,$parentnode_id,$attributes=null,$locale=null) {

			$success = true; //optimist
			$report = "";
			$node_id = self::newBlankNode($report,$class_identifier,$parentnode_id,$locale);
			if ($node_id) {

				$version = self::getVersion($report,$node_id);
				if ($version) {
					if ($attributes) {
						$attresults = self::setAttributes($report,$version,$attributes,$locale);
					}

					$attrvalids = self::checkAttributes($report,$version);

					foreach ($attrvalids as $attrname=>$attrvalid) {
						if (!$attrvalid) $attresults[$attrname]=false;
					}

					foreach ($attresults as $attrname=>$attresult) {
						if (!$attresult) $success=false;
					}

					// publish changes too
					if ($success) $success = self::publishVersion($report,$version);

				} else $success = false;

			} else $success = false;

			return array(
				"node_id"		=> $node_id,
				"report"		=> $report,
				"success"		=> $success,
				"attributes"	=> $attresults
			);

		}

		/*
			updateNode - wrapper method
			wraps getVersion, setAttributes, checkAttributes, publishNode
			implicitly
				takes the current version,
				creates a new draft
				sets the attributes
				publishes it if the current version was published

			if you want more fine-grained control, use the
			core methods, not this wrapper

			returns hash of results
		*/

		static function updateNode($node_id,$attributes,$locale=null) {

			$success = true; // optimist
			$report = "";
			$version = self::getVersion($report,$node_id,null,true,$locale);

			if ($version) {

				//$versionnr = $version->attribute( 'version' );

				$attresults = self::setAttributes($report,$version,$attributes,$locale);

				$attrvalids = self::checkAttributes($report,$version);

				foreach ($attrvalids as $attrname=>$attrvalid) {
					if (!$attrvalid) {
						$attresults[$attrname]=false;
						$success=false;
						//print "not valid $attrname";
					}
				}

				foreach ($attresults as $attrname=>$attresult) {
					if (!$attresult) {
						$success=false;
						//print "neg result $attrname";
					}
				}

				// publish changes if it was published
				if ($success) $success = self::publishVersion($report,$version);

			} else {
				$success = $false;
			}

			//print_r($attresults);
			return array(
				"node_id"		=> $node_id,
				"report"		=> $report,
				"success"		=> $success,
				"attributes"	=> $attresults
			);

		}




		/*static function storeVersion($report,$version) {
			self::report($report,"storeVersion");
			$db = eZDB::instance();
			$db->begin();
			$version->store();
			$db->commit();
		}

		static function storeNode($report,$node) {
			self::report($report,"storeNode");
			$db = eZDB::instance();
			$db->begin();
			$node->store();
			$db->commit();
		}

		*/

		static function newBlankNode($report,$class_identifier,$parent_node_id,$locale=null) {
			/*
				the core of this code is taken
			 	from kernel/classes/ezContentFunctions.php#createAndPublishObject
			*/

			// who are you ?
			$user = eZUser::currentUser();
			$userID = $user->attribute( 'contentobject_id' );

			include_once( 'kernel/classes/ezcontentobject.php' );
			include_once( 'kernel/classes/ezcontentobjecttreenode.php' );


			$contentObject = false;
			$parentNode = eZContentObjectTreeNode::fetch( $parent_node_id );

			if ( $parentNode ) {

				/* 
					refering to object because of issue
					http://issues.ez.no/IssueView.php?Id=14824
					in ezp4.0
				*/
				
				if ($parentNode->object()->canCreate()) {

					$contentClass = eZContentClass::fetchByIdentifier( $class_identifier );
					if ( is_object( $contentClass ) ) {

						$cancreateclass=false;
						$ccclist = $parentNode->canCreateClassList();
						/* [19] => Array([id] => 5, [name] => Image) */
						foreach ($ccclist as $cccentry) {
							if ($cccentry["id"]==$contentClass->ID) $cancreateclass = true;
						}

						if ($cancreateclass) {



							$db = eZDB::instance();
							$db->begin();

							// create and store an object
							if (!$locale) $contentObject = $contentClass->instantiate( $userID );
							else $contentObject = $contentClass->instantiateIn( $locale,$userID );

							if ($contentObject) {
								$contentObject->store();

								// assign a node
								$nodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObject->attribute( 'id' ),
																				   'contentobject_version' => $contentObject->attribute( 'current_version' ),
																				   'parent_node' => $parent_node_id,
																				   'is_main' => 1,
																				   'sort_field' => $contentClass->attribute( 'sort_field' ),
																				   'sort_order' => $contentClass->attribute( 'sort_order' ) ) );
								if ($nodeAssignment) {
									$nodeAssignment->store();

									// initialize and store a first version, draft
									$version = $contentObject->version( 1 );
									if ($version) {
										$version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
										$version->setAttribute( 'status', eZContentObject::STATUS_DRAFT );
										$version->store();



									} else {
										self::report( $report,"Can't retrieve first version of object ".$contentObject->attribute( 'id' ), true );
									}

								} else {
									self::report( $report,"Can't assign node under $parent_node_id", true );
								}


								$db->commit();

								// we HAVE to publish this object in order to assign the node
								include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
								$operationResult = eZOperationHandler::execute( 'content', 'publish', array(
									'object_id' => $contentObject->attribute( 'id' ),
									'version' => 1 )
								);

							} else {
								self::report( $report,"Can't create object from class '$class_identifier' (in locale $locale)", true );
							}
						} else {
							self::report( $report,"User '$userID' has no permissions to create a new node of class '$class_identifier' under node '$parent_node_id'.", true );
						}
					} else {
						self::report( $report,"Content class with identifier '$class_identifier' doesn't exist.", true );
					}
				} else {
					self::report( $report,"User '$userID' has no permissions to create a new node under node '$parent_node_id'.", true );
				}
			} else {
				self::report( $report,"Node with id '$parent_node_id' doesn't exist.", true );
			}

			//var_dump($contentObject);
			if ($contentObject) return $contentObject->attribute( 'main_node_id' );
			else return null;


		}

		static function addParentNode($report,$node_id,$add_parentnode_id) {
			// adds a second nodeassignment to the current
			// version of the node, sets some basic props, clears some caches

			$newparentnode = eZContentObjectTreeNode::fetch( $add_parentnode_id );
			if ($newparentnode) {
				$oldnode = eZContentObjectTreeNode::fetch( $node_id );
				if ($oldnode) {
					$oldobject = $oldnode->object();
					if ($oldobject) {
						include_once( 'kernel/classes/ezcontentobject.php' );
						include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
						include_once( 'kernel/classes/ezcontentclass.php' );
						include_once( 'lib/ezutils/classes/ezoperationhandler.php' );

						$version = $oldobject->currentVersion();
						$versionNumber = $version->attribute('version');
						$newVersion = $oldobject->createNewVersion();

						//assign to node, but not as main
						$newnode = $newVersion->assignToNode( $add_parentnode_id, 0 );
						$newVersionNr = $newVersion->attribute( 'version' );
						include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
						$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $oldnode->attribute('contentobject_id'), 'version' => $newVersionNr ) );
						$checknode = eZContentObjectTreeNode::fetch( $node_id );
						$checkobject = $checknode->object();
						if ( $checkobject->attribute( 'current_version' ) != $newVersionNr ) {
							//All this means is that we tried to change something and it didn't work
							self::report( $report,"cant add new parent_node for $node_id under $add_parentnode_id, permission denied." );
							return false;
						}
						//Have to clear the parent node of the object.  Just the object doesn't work.
						include_once("kernel/classes/ezcontentcachemanager.php");
						eZContentCacheManager::clearContentCache( $newparentnode->attribute( 'contentobject_id' )  );
					} else {
						self::report( $report,"cant add new parent_node for $node_id under $add_parentnode_id" );
						return false;
					}
				} else {
					self::report( $report,"can't retrieve current version for $node_id",true );
					return false;
				}
			} else {
				self::report( $report,"can't retrieve node  $node_id" );
				return false;
			}
			return $newnode->attribute( 'id' );
		}

		static function hideNode($report,$node_id,$hidden=true) {
			self::report( $report,"hideNode $node_id:$hidden" );
			include_once("kernel/classes/ezcontentobjecttreenode.php");
			$node = eZContentObjectTreeNode::fetch( $node_id);
			if ($node) {
				$db = eZDB::instance();
				$db->begin();
				if ($hidden) eZContentObjectTreeNode::hideSubTree($node);
				else eZContentObjectTreeNode::unhideSubTree($node);
				$db->commit();
				// clear caches ?
				return true;
			} else {
				self::report( $report,"Node with id '$node_id' doesn't exist.", true );
				return false;
			}
		}

		static function moveNode($report,$node_id,$newparentnode_id) {
			self::report( $report,"Moving '$node_id' to $newparentnode_id." );

			include_once("kernel/classes/ezcontentobjecttreenodeoperations.php");
			return eZContentObjectTreeNodeOperations::move($node_id, $newparentnode_id);
		}

		static function deleteNode($report,$node_id,$movetotrash=false) {
			include_once("kernel/classes/ezcontentobjecttreenode.php");
			self::report( $report,"Deleting '$node_id' ($movetotrash)" );
			$node = eZContentObjectTreeNode::fetch( $node_id);
			$node->removeNodeFromTree($movetotrash);
			// clear caches ??
			return true;
		}

		static function getVersion($report,$node_id,$versionnr=null,$newversion=false,$locale=null) {
			// get node
			$node = eZContentObjectTreeNode::fetch($node_id);
			if ($node) {
				$obj = $node->object();

				if (!$versionnr) $versionnr = $obj->attribute( 'current_version' );

				if ($newversion) {

					self::report($report, "Creating new version from version $versionnr");

					// seems to give strange errors ?
					$db = eZDB::instance();
					$db->begin();
					$version = $obj->createNewVersion($versionnr);
					$db->commit();

					if (!$version) {
						self::report($report, "Can not create new version from version $versionnr",true);
						return null;
					}

				} else {
					// using an existing version
					$version = $obj->version($versionnr);
				}

				if ($version) {
					if ($locale) {
						if (!in_array($locale,$obj->availableLanguages())) {
							if (!self::translateVersion($report,$version,$locale)) {
								self::report($report ,"Can't translate version $versionnr to $locale", true);
								return null;
							}
							// once the object is translated, it has the
							// required language. you need to specify again
							// what language you want to use when you request
							// its attributes.
						}
					}

					return $version;

				} else {
					self::report($report, "Can not retrieve version '$versionnr' from node '$node_id'",true);
					return null;
				}
			} else {
				self::report($report,  "Can not retrieve node '$node_id'",true);
				return null;
			}
		}

		static function translateVersion($report,$version,$locale) {
			/*
				adds all contentClassAttributes to the given version
				with locale $locale; this effectively means
				'adding a translation'. if the attribute can be
				translated, it is initialized as if it was new,
				otherwise it is cloned from the initialLanguage's version
			*/

			$object = $version->contentObject();
			$objectid = $object->attribute('id');
			$versionnr = $version->attribute('version');
			$currentversion = $object->attribute('current_version'); //whatever that means

			if (in_array($locale,$object->availableLanguages())) {
				self::report($report ,"Translation in $locale already exists - nothing to do.");
				return true;
			}

			// i never get permissions. what is this supposed to check ?
			//if (!in_array($locale,$object->canCreateLanguages())) {
			//	self::report($report ,"Permission denied to translate this version to $locale.");
			//	return false;
			//}

			// code below from contentObject::copyVersion
			// the trick is to copy attributes in the current version
			// with a new locale
			$db = eZDB::instance();
			$db->begin();

			$class = $object->contentClass();
			$classattributes = $class->fetchAttributes();

			foreach ( array_keys($classattributes) as $attributekey ) {

				$classattribute = $classattributes[$attributekey];
				$classattributeid = $classattribute->attribute( 'id' );

				if ($classattribute->attribute('can_translate') == 1 ) {

					// i'm instantiating it in the given version ..
					$classattribute->instantiate( $objectid, $locale, $versionnr );

				} else {

					// If attribute is NOT Translatable we should check isAlwaysAvailable(),
					// For example,
					// if initial_language_id is 4 and the attribute is always available
					// language_id will be 5 in ezcontentobject_version/ezcontentobject_attribute,
					// this means it uses language ID 4 but also has the bit 0 set to 1 (a reservered bit),
					// You can read about this in the document in doc/features/3.8/.

					$initialLangID = !$object->isAlwaysAvailable() ?
											$this->attribute( 'initial_language_id' ) :
											$this->attribute( 'initial_language_id' ) | 1;

					$objectattribute = eZContentObjectAttribute::fetchByClassAttributeID(
											$classattributeid,$objectid,
											$currentversion,$initialLangID
										);

					if ( $objectattribute ) {
						// there was such an attribute in this object, as there should be
						$newattribute = $objectattribute->clone( $versionnr, $versionnr, $objectid, $locale );
						$newattribute->sync();

					} else {
						// eh .. not good - there was no attribute, and it cant be translated ?
						// anyhew, we'll create one then
						$classattribute->instantiate( $objectid, $locale, $versionnr );
					}
				}
			}

			// wash your face now
			$oldmask = $version->attribute('language_mask');
			$version->updateLanguageMask();
			$newmask = $version->attribute( 'language_mask');
			self::report($report ,"version translated from mask ".decbin($oldmask)." to mask ".decbin($newmask));

			// and go home
			$version->store;
			self::report($report ,"version $versionnr stored");

			$db->commit();

			return true;

		}

		static function publishVersion($report,$version) {
			self::report($report ,"publishing version ".$version->attribute( 'version' ));

			// or how about ezContentOperationCollection::setObjectStatusPublished( $objectID, $versionNum ) ?

			//if ($version->attribute('status') != eZContentObject::STATUS_PUBLISHED) {
				$operationResult = eZOperationHandler::execute( 'content','publish',array(
					'object_id' => $version->attribute( 'contentobject_id' ),
					'version' => $version->attribute( 'version' )
				));
				// catch errors ?

				// for sure we have to clear some cache here
				//include_once( 'kernel/classes/ezcontentcachemanager.php' );

				// this was eZContentCacheManager::clearContentCacheIfNeeded
				// and then, it didnt work when needed.
				eZContentCacheManager::clearContentCache(
					$version->attribute('contentobject_id'),
					$version->attribute('version')
				);

				// should you ever mess with user objects, figure out this:
				//if ( in_array( $classID, eZUser::contentClassIDs() ) ) {
					//include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
				//	eZUser::cleanupCache();
				//}

				return true;

			//} else {

			//	self::report($report, "Version '".$version->attribute( 'version' )."' is already published");
			//	return true;
			//}
		}


		static function setCreator($report,$node_id,$set_creator) {
			self::report( $report,"setCreator '$node_id' to $set_creator." );
			// set_creator should be userid
			// set $node.object.current.creator_id. 
			// this returns in $node.creator on the frontend
			$node	= eZContentObjectTreeNode::fetch($node_id);
			if ($node) {
				$object_id 				= $node->attribute("contentobject_id");
				$object 				= eZContentObject::fetch($object_id);
				$current				= $object->currentVersion();
				$current_id				= $current->attribute("id");
				if ($current_id) {
					$db = eZDB::instance();
					$db->query( "UPDATE ezcontentobject_version SET creator_id='$set_creator' WHERE id='$current_id'" );
				} else {
					self::report( $report,"setCreator cant find current version." );
					return false;
				}
			} else {
				self::report( $report,"setCreator cant find node." );
				return false;
			}
			return true;

		}
		static function setOwner($report,$node_id,$set_owner) {
			self::report( $report,"setOwner '$node_id' to $set_owner." );
			// set_owner should be userid
			// set object.owner_id and optionally initial.creator_id
			$node	= eZContentObjectTreeNode::fetch($node_id);
			if ($node) {
				
				$object_id 				= $node->attribute("contentobject_id");
				$object 				= eZContentObject::fetch($object_id);
				$initial				= $object->version(1); // 1 ?
				$initial_id				= ($initial)?$initial->attribute("id"):false;
				
				$db = eZDB::instance();
				$db->query( "UPDATE ezcontentobject SET owner_id='$set_owner' WHERE id='$object_id'" );
				if ($initial) {
					$db->query( "UPDATE ezcontentobject_version SET creator_id='$set_owner' WHERE id='$initial_id'" );
				}
			} else {
				self::report( $report,"setOwner cant find node." );
				return false;
			}
			return true;

		}
		
		static function setModified($report,$node_id,$set_modified) {
			self::report( $report,"setModified '$node_id' to $set_modified." );
			// set_modified should be unix time() or strtotime format
			// sets node.object.modified and node.object.current/modified
			if (!is_numeric($set_modified)) $set_modified=strtotime($set_modified);
			
			$node	= eZContentObjectTreeNode::fetch($node_id);
			if ($node) {
				$object_id 				= $node->attribute("contentobject_id");
				$object 				= eZContentObject::fetch($object_id);
				$current				= $object->currentVersion();
				$current_id				= $current->attribute("id");
				
				if ($current_id) {
					$db = eZDB::instance();
					$db->query( "UPDATE ezcontentobject SET modified='$set_modified' WHERE id='$object_id'" );
					$db->query( "UPDATE ezcontentobject_version SET modified='$set_modified' WHERE id='$current_id'" );
					
				} else {
					self::report( $report,"setModified cant find current version." );
					return false;
				}
			} else {
				self::report( $report,"setModified cant find node." );
				return false;
			}
			return true;
			
			
		}

		static function setPublished($report,$node_id,$set_published) {
			self::report( $report,"setPublished '$node_id' to $set_published." );
			// set_published should be unix time() or strtotime format
			// sets node.object.publish and optionally node.object.versions[0].modified
			if (!is_numeric($set_published)) $set_published=strtotime($set_published);
			$node	= eZContentObjectTreeNode::fetch($node_id);
			if ($node) {
				$object_id 				= $node->attribute("contentobject_id");
				$object 				= eZContentObject::fetch($object_id);
				$initial				= $object->version(1); // 1 ?
				$initial_id				= ($initial)?$initial->attribute("id"):false;
				$db = eZDB::instance();
				$db->query( "UPDATE ezcontentobject SET published='$set_published' WHERE id='$object_id'" );
				if ($initial) {
					$db->query( "UPDATE ezcontentobject_version SET modified='$set_published' WHERE id='$initial_id'" );
				}
			} else {
				self::report( $report,"setOwner cant find node." );
				return false;
			}
			return true;
			
		}
		
		/*
		static function unpublishVersion($report,$version) {

				I'm not sure if this is 'legal'. It *was* used
				to reset the "published" flag on newly created
				nodes. And it worked, but there remained a 'ghost'
				of the version in a published node .. confusing.

				Not used anymore.

			self::report($report,"returning version to draft");
			self::report($report ,"version ".$version->attribute( 'version' ) .":".$version->attribute( 'status' ));
			$db = eZDB::instance();
			$db->begin();
			$version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
			$version->setAttribute( 'status', eZContentObject::STATUS_DRAFT );
			$version->store();
			self::report($report ,"version ".$version->attribute( 'version' ) .":".$version->attribute( 'status' ));
			$db->commit();
			return true;
		}
		*/



		static function setAttributes($report,$version,$request,$locale=null) {

			/*

				loops all nvpairs, parses name:idx:prop into
				an array of matrices,
				tries to set all found attributes,
				returns an array of results [attrname,successorfailure]
				array("title"=>true,"email"=>false);


			*/

			$success = true; // optimist
			$changed=false;
			$results = array();


			$parsedreq=self::parseRequest($report,$request);



			// Do we have permissions to edit in this language ?
			// well.. we never do. i dont know what this check should do
			//if ($locale) {
			//	$object = $version->contentObject();
			//	if (!in_array($locale,$object->canEditLanguages())) {
			//		self::report($report ,"Permission denied to edit version in $locale.");
			//		return $results;
			//	}
			//}

			$attributes =$version->contentObjectAttributes($locale);

			foreach ($attributes as $attribute) {
				$attrname = $attribute->attribute("contentclass_attribute_identifier");
				if (isset($parsedreq[$attrname])) {
					self::report($report ,"Set attribute $attrname");
					if (self::setAttribute($report,$attribute,$parsedreq[$attrname])) {
						$results[$attrname]=true;
						$changed=true;
					} else {
						$results[$attrname]=false;
						$success=false;
					}
				} else {
					// self::report($report ,"no value for $attrname");
				}
			}


			if ($success) {
				if ($changed) {
					//$success = self::storeVersion($report,$version);
					self::report($report,"storing version");
					$db = eZDB::instance();
					$db->begin();

					if ($set_created) 		$version->setAttribute( 'created', $set_created);
					if ($set_creator_id) 	$version->setAttribute( 'creator_id', $set_creator_id);
					if ($set_modified) 		$version->setAttribute( 'modified', $set_modified);
					else $version->setAttribute( 'modified', eZDateTime::currentTimeStamp());
					$version->store();
					if ($set_published) 	{
						$object = $version->contentObject();
						$object->setAttribute( 'published', $set_published);
						$object->store();
					}
					self::report($report ,"version ".$version->attribute( 'version' ) .":".$version->attribute( 'status' )." stored");
					$db->commit();
				} else {
					self::report($report ,"Nothing changed: version not stored.");
				}
			} else {
				self::report($report ,"Error modifying attributes: version not stored.");
			}
			return $results;

		}

		static function setAttribute($report,$attribute,$matrix) {
		 	/*
				the matrix is an array like

				setAttribute($attrobj,0:["value"=>"test"])
				setAttribute($attrobj,[
					0:["name="=>"a3n","email"=>"a3e"],
					1:["name="=>"a4n","email"=>"a4e"]
				])
				setAttribute($attrobj,[
					0:["file"=>[
						"name"=>"test image",
						"tmp_name"=>"/tmp/xghjjjd.56d",
						"type"=>"image/gif",
						"size"=>"image/gif",
						"error"=>""
					]
				]
				setAttribute($attrobj,[
					0:["url"=>"http://www.images.com/test.gif"]
				]

				for images only:
				setAttribute($attrobj,[
					0:["remove"=>1]
				]

				uses fromString:
				http://pubsvn.ez.no/nextgen/trunk/doc/features/3.9/to_from_string_datatype_functionality.txt




			*/
			$data_type_string = $attribute->attribute('data_type_string');

			$success = false;
			switch( $data_type_string ) {


				// ---------- standard datatypes ----------  //

				// single string value
				// with no validation (yet)

				case "ezstring":
				case "ezisbn":
				case "ezkeyword":
				case "eztext":
				case "eztexthtml":
					$str = $matrix[0]["value"];
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				// single string with  validation
				case "ezemail":
					include_once("lib/ezutils/classes/ezmail.php");
					$str = $matrix[0]["value"];
					if (eZMail::validate( $str )) {
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					} else {
						self::report($report ,"'$str' does not seem to be a valid e-mail address.");
						$success=false;
					}
					break;


				// single string with  validation
				case "eztime":
					$str = $matrix[0]["value"];
					$rx = '/^\d\d?:\d\d?$/';
					if (!$str || preg_match($rx,$str)) {
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					} else {
						self::report($report ,"'$str' does not seem to be a valid time.");
						$success=false;
					}
					break;

				// single numeric value
				// with no validation (yet)
				case "ezfloat":
				case "ezinteger":
				case "ezobjectrelation":
					$str = $matrix[0]["value"];
					if (is_numeric($str)) {
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					} else {
						self::report($report ,"'$str' does not seem to be a valid number.");
						$success=false;
					}
					break;

				// boolean
				case "ezboolean":
					// true is 1 or "1" or "true", all else is false
					// $matrix[0]["check"] could be set. we dont care,
					// it just ensures you got here, even if there was 
					// no 'value' from the unchecked checkbox
					$str = ($matrix[0]["value"]==1||$matrix[0]["value"]=="true")?1:0;
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				// file uploads or urls
				case "ezbinaryfile":
				case "ezimage":
				case "ezmedia":

					if ($matrix[0]["url"]) $path = self::downloadBinaryFile($report,$attribute,$matrix[0]["url"]);
					else if ($matrix[0]["file"] && $matrix[0]["file"]["error"]!==UPLOAD_ERR_NO_FILE) {
						$path = self::handleBinaryUpload($report,$attribute,$matrix[0]["file"]);
					}

					if ($path) {
						//$orgname = $matrix[0]['name'];
						//$str = ezStringUtils::implodeStr(array($path,$orgname));

						self::report($report ,"fromString '$path'");
						$attribute->fromString($path);
						$success=true;
					} else if ($matrix[0]["remove"]) {
						self::report($report ,".. removing attribute");
						$attribute->fromString('');
						$success=true;
					} else {
						// if nothing was passed, do nothing
						$success=true;
					}

					break;

				// dates and times
				case "ezdate":
					// value will be parsed with php strtotime
					$str = $matrix[0]["value"];
					$time = strtotime($str);
					if ($time===false || $time==-1) {
						self::report($report ,"'$str' does not seem to be a valid date.");
						$success=false;
					} else {
						$date = new eZDate($time); //let ezp do its magic too
						$str = $date->timeStamp(); // which is probably the same
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					}
					break;

				case "ezdatetime":
					// value will be parsed with php strtotime
					$str = $matrix[0]["value"];
					$time = strtotime($str);
					if ($time===false || $time==-1) {
						self::report($report ,"'$str' does not seem to be a valid date/time.");
						$success=false;
					} else {
						$date = new eZDateTime($time); //let ezp do its magic too
						$str = $date->timeStamp(); // which is probably the same
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					}
					break;
					
				case "ezenum":
					$values = array();
					foreach ($matrix as $row) { $values[]=$row["value"]; }
					self::report($report ,"values ".implode(",",$values));
					return self::setEnumAttribute($report,$attribute,$values);
					break;
					
				// single row with numbers
				case "ezobjectrelationbrowse":
				case "ezobjectrelationlist":

					ksort($matrix[0]);
					$node_ids = array();
					foreach ($matrix as $key=>$fields) {
						if ($fields["value"]) $nodeids[] = $fields["value"];
					}
					$str = implode("-",$nodeids);
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				// single row with strings
				case "ezselection":
					$nodeids = array_values(ksort($matrix[0]));
					$str = implode("-",$nodeids);
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				/* single row with custom subfields */

				case "ezurl":
					$str = $matrix[0]["value"];
					$validate = $matrix[0]["validate"];
					$rx  = '/^(https?|ftps?):\/\/'; 		// protocol
					$rx .= '[\w\-_]+';						// subdomain or domain
					$rx .= '(\.[\w\-_]+)+';					// more (sub)domain(s) and tld
					$rx .= '(:\d+)?';						// opt port number
					$rx .= '([\w\-\.,@?^=%&amp;:\/~\\+#]*)?$/'; // path, query etc
					if (!$str || !$validate || preg_match($rx,$str)) {
						if ($matrix[0]["text"]) $str .= "|".$matrix[0]["text"];
						self::report($report ,"fromString '$str'");
						$attribute->fromString($str);
						$success=true;
					} else {
						self::report($report ,"'$str' does not seem to be a valid url.");
						$success=false;
					}
					break;

				case "ezprice":
					$str = ezStringUtils::implodeStr(array($matrix[0]["price"],$matrix[0]["vat"],$matrix[0]["flag"]));
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				case "ezuser":
					$str = ezStringUtils::implodeStr(array($matrix[0]["login"],$matrix[0]["email"],$matrix[0]["hash"],$matrix[0]["type"]));
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;


				// multiple rows with fixed subfields
				case "ezauthor":
					// can contain multiple authors. props should be "name", "email", row
					//Administrator User|sp@ez.no|0 & Sergiy|bla@fooo.tt|1 & SP|sp@ez.od.ua|2
					$str = "";
					for ($rc=0;$rc<count($matrix);$rc++) {
						$row=$matrix[$rc];
						if ($str) $str .= "&";
						$str .= ezStringUtils::implodeStr(array($row["name"],$row["email"],$rc));
					}
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;

				// multiple rows with free subfields
				case "ezmatrix":
					$str = "";
					for ($rc=0;$rc<count($matrix);$rc++) {
						$row=$matrix[$rc];
						ksort($row);
						if ($str) $str .= "&";
						$str .= ezStringUtils::implodeStr(array_values($row));
					}
					self::report($report ,"fromString '$str'");
					$attribute->fromString($str);
					$success=true;
					break;


				// xmlblock. fromstr not used, as it expects valid xmlblock
				case "ezxmltext":
					//include_once( 'kernel/classes/datatypes/ezxmltext/ezxmltexttype.php');
					include_once( 'extension/customedit/classes/ezXMLTextConverter.php' );
					$dummy = "";
					$converter = new ezXMLTextConverter( $dummy, $attribute ); // catch error ?
					$state = $converter->validateText( $matrix[0]["value"], $attribute ); // catch error ?
					self::report($report ,$attribute->validationError());
					if ($state==ezInputValidator::STATE_ACCEPTED) {
						$attribute->SetAttribute( 'data_int', eZXMLTextType::VERSION_TIMESTAMP );
						$success=true;
					}
					break;

				// not implemented because the docs
				// are unclear to me
				case "ezcountry":
				case "ezinisetting":
				case "ezoption":
				case "ezmultioption":
				case "ezmultiprice":
				case "ezproductcategory":
				case "ezrangeoption":
					self::report($report ,"$data_type_string: not implemented",true);
					$success = false;
					break;

				// not implemented becasue fromString
				// is not implemented
				case "ezpackage":
				case "ezsubtreesubscription":
					self::report($report ,"$data_type_string: not implemented",true);
					$success = false;
					break;

				// not implemented because NA
				case "ezidentifier":
					self::report($report ,"$data_type_string: not implemented",true);
					$success = false;
					break;


				// ---------- default ----------  //

				default :

					$success = false;
					self::report($report ,"Datatype \"$data_type_string\" not supported",true);

			}

			if ($success) {
				$attribute->store(); // catch errors ?
				self::report($report ,"Attribute stored.");
			} else {
				self::report($report ,"Attribute not stored.");
			}
			return $success;

		}

		/*
			will check the attributes
			of the given version in the requested locale

			returns an array of results [attrname,successorfailure]
			eg array("title"=>true,"email"=>false);

			this method will have to grow as time goes by. i'm not
			sure how much checking is done at a deeper level (iow
			in setAttribute()).

		*/

		static function checkAttributes($report,$version,$locale=null) {

			$results = array();
			$attributes =$version->contentObjectAttributes($locale);
			foreach ($attributes as $attribute) {
				$attrname = $attribute->contentClassAttributeIdentifier();
				self::report($report ,"Checking attribute $attrname");

				// validation in ezp is done deeply in the kernel
				// with strong ties to the admin http interface. we can
				// not use any of the calls here
				// http://pubsvn.ez.no/doxygen/4.0/html/classeZContentObjectAttribute.html
				// since they are based on admin specific http input
				// so, we're going to have to reimp all validation.

				if ($attribute->contentClassAttributeIsRequired()) {
					if (!$attribute->hasContent()) {
						self::report($report ,"required $attrname is missing value",true);
						$results[$attrname]=false;
						continue;
					}
				}

				//$classattr = $attribute->contentClassAttribute();
				//if ($classattr->attribute("is_required")) {
				//	if (!$attribute->hasContent()) {
				//		self::report($report ,"required $attrname is missing value",true);
				//		$results[$attrname]=false;
				//		continue;
				//	}
				//}

				// print "OK";
				// all is ok
				$results[$attrname]=true;
			}
			return $results;

		}

		/* --- request parsers ---- */

		static function filterRequest($report,$request,$version=null) {
			/* filters $request for actual att:idx:val fields */


			$frequest = array();


			if ($version) {
				// should pref check for classattributes
				$attributes =$version->contentObjectAttributes();
				foreach ($attributes as $attribute) {
					$attrnames[] = $attribute->attribute("contentclass_attribute_identifier");
				}
				foreach ($request as $name=>$value) {
					if(get_magic_quotes_gpc() && !is_array($value)) {
						$ssvalue=stripslashes($value);
					} else {
						$ssvalue=$value;
					}
					list($attrname,$propname)=explode(":",$name);
					if (in_array($attrname,$attrnames)) {
						$frequest[$name]=$ssvalue;
					} else if ($attrname=="request") {
						$frequest[$propname]=$ssvalue;
					}
				}
			} else {
				foreach ($request as $name=>$value) {
					if(get_magic_quotes_gpc() && !is_array($value)) {
						$ssvalue=stripslashes($value);
					} else {
						$ssvalue=$value;
					}
					list($attrname,$propname)=explode(":",$name);
					if ($attrname=="request") {
						$frequest[$propname]=$ssvalue;
					} else if ($attrname && $propname) {
						// this will let other things thru as well,
						// but thats not so bad
						$frequest[$name]=$ssvalue;
					}
				}
			}
			return $frequest;
		}

		static function parseRequest($report,$request) {
			/*
				parse varname and values out of
				$request. lifecycle of the query:

				$query =
					"?teststring:value=test
					&testimage:file={binary stuff}
					&testrelations:2:value=456
					&testrelations:1:value=123
					&testrelations2:value[]=123
					&testrelations2:value[]=456
					&testauthor:4:name=a4n
					&testauthor:4:email=a4e
					&testauthor:3:name=a3n
					&testauthor:3:email=a3e"

				$request = [
					"teststring:value"=>"test",
					"testimage:file"=>{unknown},
					"testrelations:2:value"=>"456",
					"testrelations:1:value"=>"123",
					"testauthor:4:email"=>"a4e",
					"testauthor:3:name"=>"a3n",
					"testauthor:3:email"=>"a3e"
				]

				$parsedrequest = [
					"teststring" => [
						0:["value"=>"test"]
					], "testimage" => [
						0:["name"=>"test","type"=>"","size"=>"","tmp_name"=>"","error"=>""]
					], "testrelations" => [
						1:["value="=>"123"],
						2:["value="=>"456"]
					], "testrelations2" => [
						1:["value="=>"123"],
						2:["value="=>"456"]
					], "testauthor" => [
						0:["name="=>"a3n","email"=>"a3e"],
						1:["name="=>"a4n","email"=>"a4e"]
					]

				setAttribute($attrobj,0:["value"=>"test"])
				setAttribute($attrobj,[
					0:["name="=>"a3n","email"=>"a3e"],
					1:["name="=>"a4n","email"=>"a4e"]
				])

			*/

			$parsedreq=array();
			ksort($request); // the property indexes are only used for sort order
			foreach ($request as $name=>$value) {
				//self::report($report ,"Found $name:$value");
				if (strpos($name,":")!==false) {

					// split attribute name, row index and property name / col name
					list($attrname,$rowidx,$propname)=explode(":",$name);

					// check if this is a simple array (not a hash)
					if (is_array($value) && !array_diff_key($value,array_keys(array_keys($value)))) {

						self::report($report ,"found array $attrname");

						//if (strpos($attrname,'[]')==strlen($attrname)-2) {
						//	$attrname = substr($attrname,0,-2);
						//	print "attrname set to $attrname";
						//}

						// create arrays for the attribute
						if (!isset($parsedreq[$attrname])) {
							$parsedreq[$attrname] = array();
						}

						// this is an array of values. it contains no
						// rowidx. the order is not garantueed by the http specs.
						$propname=$rowidx;

						foreach ($value as $rowidx=>$rowvalue) {
							if (!isset($parsedreq[$attrname][$rowidx])) {
								$parsedreq[$attrname][$rowidx] = array();
							}
							// Remove those slashes
							if(get_magic_quotes_gpc()) {
								$parsedreq[$attrname][$rowidx][$propname]=stripslashes($rowvalue);
							} else {
								$parsedreq[$attrname][$rowidx][$propname]=$rowvalue;
							}
						}

					} else {

						// either this is a single (numbered) row,
						// or it is a single value

						// row index is optional:
						if (!$propname) {$propname=$rowidx;$rowidx=0; }

						// create arrays for the attribute
						if (!isset($parsedreq[$attrname])) {
							$parsedreq[$attrname] = array();
						}
						if (!isset($parsedreq[$attrname][$rowidx])) {
							$parsedreq[$attrname][$rowidx] = array();
						}


						// add the property to that array

						// usually, rowsidx=0, unless the datatype
						// is a list of things

						// common propnames are "value" or "file",
						// but its free format. what it means
						// is interpreted when actually setting
						// the attribute (the code to interpret
						// this array differs per datatype)

						if(get_magic_quotes_gpc() && !is_array($value)) {
							$parsedreq[$attrname][$rowidx][$propname]=stripslashes($value);
						} else {
							$parsedreq[$attrname][$rowidx][$propname]=$value;
						}

					}

				} else {
					// not formatted correctly, ignoring this tuple
					// self::report($report ,"Ignoring $name:$value");
				}
			}
			// chunk out the rowindexes now
			foreach ($parsedreq as $attrname=>$values) {
				$parsedreq[$attrname] = array_values($values);
			}
			// now check if that went ok !
			// print_r($parsedreq);
			return $parsedreq;
		}


		/* --------- helper methods ---------- */

		
		static function getFileDestination($report,$attribute,$filename,$filemime="application/unknown") {

			// according to the docs, binary uploads should go to
			// [/var/mysite/][storage/]original/[mime]/[md5].[ext]
			// http://ez.no/doc/ez_publish/technical_manual/4_0/reference/datatypes/file

			// however, image uploads should go to
			// [/var/mysite/][storage/]images/[nodepath]/[attrid]-[versionnr]-[translation]/[filename]
			// http://ez.no/doc/ez_publish/technical_manual/4_0/reference/datatypes/image

			// i'm not doing either. i'm uploading all binaries to
			// [/var/mysite/][storage/]original/[mime]/[date]-[attid]-[uniqid]-[filename]
			// and that works, too

			$sys = eZSys::instance();

			$mimes = explode("/",$filemime);
			$majormime	= (count($mimes)==2)?$mimes[0]:"unknown";

			$dstdir = $sys->rootDir()."/".$sys->storageDirectory()."/original/$majormime";
			if ( !file_exists( $dstdir ) ) eZDir::mkdir( $dstdir, 0777, true);
			$dstdir = realpath($dstdir);

			$filename = str_replace("..","--",$filename);
			$filename = ereg_replace('[^A-Za-z0-9.]', '-', $filename);
			// try to strip the extension
			// if ($majormime=="image") $filename = join('.',array_slice(explode( '.', $orgname),0,-1));
			$dstpath = tempnam( $dstdir, date("YmdHis")."-")."-".$filename;
			//This is creating  a temporary file at tempnam( $dstdir, date("YmdHis")."-" ) 
			// which will NOT be overwritten by the move_uploaded_file to 
			// tempnam( $dstdir, date("YmdHis")."-")."-".$filename below
			return $dstpath;
		}

		static function handleBinaryUpload($report,$attribute,$file) {

			// partial code from uploadmultiplefiles extension
			// by Patrizio Bekerle (patrizio@bekerle.com)
			// www.bekerle.com

			//	$file is one array from http://nl2.php.net/features.file-upload
			// $file['name']
			// $file['type']
			// $file['size']
			// $file['tmp_name']
			// $file['error']

			if ($file['error']==UPLOAD_ERR_OK) {

				$dstpath = self::getFileDestination($report,$attribute,$file['name'],$file['type']);

				if (!$dstpath || !move_uploaded_file($file['tmp_name'],$dstpath)) {
					self::report( $report,"Error moving uploaded file ($file[tmp_name]) to $dstpath", true );
					return null;
				}
			} else {
				self::report( $report,"File upload error ".$file['error'], true );
				return null;
			}

			self::report( $report,"Uploaded file to $dstpath" );

			return $dstpath;
		}



		static function downloadBinaryFile($report,$attribute,$url) {

			// partial code from
			// http://ez.no/community/forum/developer/creating_a_simple_content_object_via_php/
			//			re_creating_a_simple_content_object_via_php__13


			$chunksize = 8192; // how many bytes per chunk

			self::report( $report,"downloadBinaryFile: downloading $url" );

			// try to download the file. chunk it because
			// it may be too big to fit in mem

			$ini = eZINI::instance();
			$sys = eZSys::instance();

			$storage_dir 	= $sys->rootDir().$sys->storageDirectory();
			$tempdir 		= $storage_dir.$ini->variable( 'FileSettings', 'TemporaryDir' );
			if ( !file_exists( $tempdir ) ) eZDir::mkdir( $tempdir, 0777, true);
			$temppath = tempnam($tempdir, "customedit-");
			$temphandle = fopen($temppath,"w");
			if ($temphandle === false) {
				self::report( $report,"downloadBinaryFile: could not open tempfile '$temppath' for writing", true );
				return null;
			}

			$buffer = '';
			$urlhandle = fopen($url, 'rb');
			if ($urlhandle === false) {
				self::report( $report,"downloadBinaryFile: could not open url '$url' for reading", true );
				return null;
			}
			while (!feof($urlhandle)) {
				fwrite($temphandle, fread($urlhandle, $chunksize));
			}
			fclose($urlhandle);
			fclose($temphandle);
			self::report( $report,"downloadBinaryFile: downloaded $url:".filesize($temppath) );

			// get file name
			$urlarr = parse_url($url);
			$filename = basename($urlarr["path"]);

			// get mime, orgdir
			$mimeObj = new eZMimeType();
			$filemime = $mimeObj->findByURL( $url,true );

			// get destination
			$dstpath = self::getFileDestination($report,$attribute,$filename,$filemime);


			// move the tempfile to its destination
			if (!rename($temppath, $dstpath )) {
				self::report( $report,"downloadBinaryFile: could not move temp file '$temppath' to target '$dstpath'", true );
				return null;

			}
			self::report( $report,"downloadBinaryFile: moved '$temppath' to '$dstpath'");
			return $dstpath;

		}


		static function setEnumAttribute($report,$attribute,$values) {
			
			$success = false;
			$attrid 		= $attribute->attribute( 'id' );
			$attrversion 	= $attribute->attribute( 'version' );
			self::report($report ,"setEnumAttribute $attrid");
			
			// remove all current values
			eZEnum::removeObjectEnumerations($attrid, $attrversion);
			
			$classattr		= $attribute->contentClassAttribute();
			$classattrid 	= $classattr->attribute('id');
			$classattrversion = $classattr->attribute( 'version' );
			$classenum = new eZEnum( $classattrid, $classattrversion );
			if ($classenum) {
				self::report($report ,"found  enum definition for $classattrid ");
				
				// classenum is a list of allowed ezenumvalues, each 
				// containing basicly id,element,value and some rubbish.
				// the match (from the form) is on the value,
				// but we have to store them all. which is strange indeed.
				
				$classtuples 		= $classenum->attribute('enum_list');
				foreach ($classtuples as $classtuple) {
					
					$enumid 		= $classtuple->attribute( "id" );
					$enumelement 	= $classtuple->attribute( "enumelement" );
					$enumvalue 		= $classtuple->attribute( "enumvalue" );
					self::report($report ,"checking for $enumvalue ..");
					foreach ($values as $inputvalue) {
						if ($enumvalue==$inputvalue) {
							self::report($report ,"found, storing.");
							eZEnum::storeObjectEnumeration( 
								$attrid,$attrversion,$enumid,$enumelement,$enumvalue 
							);
							$success=true;
						}
					}
				}
			} else self::report($report ,"couldnt find  enum definition for $classattrid ");
			return $success;

		}

		/* legacy */

		static function setObjectRelationBrowse($report,$attribute,$nodeids) {
			// @ http://ez.no/community/forum/developer/add_object_relation_attribute_type_within_a_php_script


			$success = true;
			foreach ($nodeids as $nodeid) {
				$node = eZContentObjectTreeNode::fetch($node_id);
				if ($node) {
					eZDebug::writeDebug( "appendObjectRelationBrowse node $node_id", 'CustomEdit' );
					$content = $attribute->content();

					//if (!$content['relation_list']) $content['relation_list'] = array();
					$priority = count($content['relation_browse'])*10;
					$content['relation_browse'][] = eZObjectRelationBrowseType::appendObject($node->attribute( 'contentobject_id' ), $priority, $attribute );
					$attribute->setContent( $content );

					eZDebug::writeDebug( "appendObjectRelationBrowse: storing relation", 'CustomEdit' );
					$attribute->store(); // catch errors ?
				} else {
					$report .= "Failed to fetch node '$node_id'\n";
					$success = false;
				}
			}
			return $success;
		}


	}

?>