<?php
	//
	// Created on: <2007/04> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//


	include_once( 'kernel/common/template.php' );
	$tpl = templateInit();
	$tpl->setVariable( 'result', array() );


	$Result = array();
	//$Result["pagelayout"] 	= "pagelayout_wide.tpl";
	$Result['content'] 		= $tpl->fetch( 'design:customedit/demo1/start.tpl' );
	$Result['path'] = array(
		array( 'url' => false,					'text' => ezi18n( 'extension/customedit','CustomEdit') ),
		array( 'url' => '/customedit/demo1', 	'text' => ezi18n( 'extension/customedit','Start demo') )
	);


?>