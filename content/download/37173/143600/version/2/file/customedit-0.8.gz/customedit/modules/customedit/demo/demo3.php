<?php
	//
	// Created on: <2007/04> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//

	// the output of this script is just plain html
	// it looks like xml. it could have been. but its not.
	
	include_once( 'kernel/common/template.php' );
	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( "extension/customedit/classes/CustomEditLib.php" );
	
	$http	= eZHTTPTool::instance();
	$class_identifier 	= $http->variable('class_identifier');
	$parentnode_id 		= $http->variable('parentnode_id');
	$blank 				= $http->variable('blank');
	
	if ($blank) {
	
		$Result = array();
		$Result["pagelayout"] = false;
		header('Content-type:text/html');
		print "<!--blank-->";
		eZExecution::cleanExit();
		
	} else if (!($class_identifier && $parentnode_id)) {
	
		$tpl = templateInit();
		$tpl->setVariable( 'result', array() );
		$Result = array();
		//$Result["pagelayout"] = "pagelayout_wide.tpl";
		$Result['content'] 		= $tpl->fetch( 'design:customedit/demo3/demo3.tpl' );
		$Result['path'] = array(
			array( 'url' => false,								'text' => ezi18n( 'extension/customedit','CustomEdit') ),
			array( 'url' => '/customedit/demo3', 				'text' => ezi18n( 'extension/customedit','Demo3') )
		);
		
	} else {
	
		// create a new node,
		// set the attributes,
		// and exit with the result template
		
			
		$report = "";
		$node_id = CustomEditLib::newBlankNode($report,$class_identifier,$parentnode_id);
		
		if ($node_id) {
		
			$version = CustomEditLib::getVersion($report,$node_id);
			
			if ($version) {
			
				$attresults = CustomEditLib::setAttributes($report,$version,array_merge($_REQUEST,$_FILES));
				$success=true;
				foreach ($attresults as $name=>$value) {
					if (!$value) $success=false;
				}
				
				if ($success) $success = CustomEditLib::publishVersion($report,$version);
				
				// now figure out the url of the uploaded image
				
				
			} 
		} 
		
		$request = CustomEditLib::filterRequest($report,array_merge($_REQUEST,$_FILES),$version);
		$Result = array();
		$Result["pagelayout"] = false;
		
		if ($success) {
			$result["error"] 		= false;
			$result["message"]		="Node successfully created";
			$result["node_id"] 		= $node_id;
			$result["version"] 		= 1;
			$result["locale"] 		= $locale;
			$result["hilite"]		= array();
		} else {
			$result["error"] 		= true;
			$result["message"]		= $report;
			$result["node_id"] 		= null;
			$result["version"] 		= null;
			$result["locale"] 		= null;
			$result["hilite"]		= array();
		}
		
		$tpl = templateInit();
		$tpl->setVariable( 'request', $request );
		$tpl->setVariable( 'result', $result );
	


		$Result['content'] 		= $tpl->fetch( 'design:customedit/demo3/result.tpl' );
		
	}

?>