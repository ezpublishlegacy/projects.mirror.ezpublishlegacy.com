<?php
//
// Created on: <2008/04/10>
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

$Module = array( 'name' => 'CustomEdit' );

$ViewList = array();
$ViewList['menu'] 			= array('script' => 'menu.php' );
$ViewList['demo1'] 			= array('script' => 'demo/demo1.php');
$ViewList['demo2'] 			= array('script' => 'demo/demo2.php', 'params' => array ( 'template'));
$ViewList['demo3'] 			= array('script' => 'demo/demo3.php');
$ViewList['demo4'] 			= array('script' => 'demo/demo4.php');
$ViewList['testsuite'] 		= array('script' => 'testsuite.php', 'params' => array ( 'suite','page'));

// actual tools
$ViewList['create'] 		= array('script' => 'create.php');
$ViewList['modify'] 		= array('script' => 'modify.php');

// todo
$ViewList['delete'] 		= array('script' => 'delete.php');

// moved
//$ViewList['comment'] 		= array('functions' => array( 'comment' ),'script' => 'create_comment.php');
//$FunctionList['comment'] = array( );


?>