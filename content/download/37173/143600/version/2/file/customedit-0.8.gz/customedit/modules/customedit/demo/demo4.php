<?php
	//
	// Created on: <2009/06> pike@labforculture.org
	//
	// This file may be distributed and/or modified under the terms of the
	// "GNU General Public License" version 2 as published by the Free
	// Software Foundation and appearing in the file LICENSE included in
	// the packaging of this file.
	//
	// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
	// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	// PURPOSE.
	//
	//
	// The "GNU General Public License" (GPL) is available at
	// http://www.gnu.org/copyleft/gpl.html.
	//

	// the output of this script is just plain html
	// it looks like xml. it could have been. but its not.
	
	include_once( 'kernel/common/template.php' );
	include_once( "extension/customedit/classes/CustomEditLib.php" );
	


	$tpl = templateInit();
	$tpl->setVariable( 'result', array() );
	$Result = array();
	//$Result["pagelayout"] = "pagelayout_wide.tpl";
	$Result['content'] 		= $tpl->fetch( 'design:customedit/demo4/meta.tpl' );
	$Result['path'] = array(
		array( 'url' => false,								'text' => ezi18n( 'extension/customedit','CustomEdit') ),
		array( 'url' => '/customedit/demo4', 				'text' => ezi18n( 'extension/customedit','Demo4') )
	);
	


?>