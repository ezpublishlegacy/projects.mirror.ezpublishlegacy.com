<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezcore

[JavaScriptSettings]
JavaScriptList[]=ez_core.js
JavaScriptList[]=animation.js
JavaScriptList[]=accordion.js




*/ ?>