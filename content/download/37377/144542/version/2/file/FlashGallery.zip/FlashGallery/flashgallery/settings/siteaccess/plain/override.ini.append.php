<?php /* #?ini charset="iso-8859-1"?


[full_flashgallery]
Source=node/view/full.tpl
MatchFile=full/flashgallery.tpl
Subdir=templates
Match[class_identifier]=flashgallery


[line_flashgallery]
Source=node/view/line.tpl
MatchFile=line/flashgallery.tpl
Subdir=templates
Match[class_identifier]=flashgallery





*/ ?>