<?php
//
// Definition of FtpImportimport class
//

class FtpImportImport
{
	/*!
	 Constructor
	 */
	function FtpImportImport()
	{
         //import ini values
         include_once( "lib/ezutils/classes/ezini.php" );
         $this->ftpextensionINI =& eZINI::instance( 'ftpimport.ini' );
         }

	/*!
	 Imports images from '$importDir' folder on server and deletes them there.
	 */
	function import( $file, $placeNodeID )
	{
              //set ini values.
              $this->ImportDir=$this->ftpextensionINI->variable('DirectorySettings','ImportDirName');
              $classID=$this->ftpextensionINI->variable('ImageClassSettings','ImageClassID');
              $creatorID=$this->ftpextensionINI->variable('UserSettings','AdminUserID');
              $DeleteAfterImport=$this->ftpextensionINI->variable('FileSettings','DeleteAfterImport');

              $ImportIPTCTitle=$this->ftpextensionINI->variable('CaptionSettings','ImportIPTCTitle');
	     $ImportIPTCCaption=$this->ftpextensionINI->variable('CaptionSettings','ImportIPTCCaption');
	     $ImportIPTCPlace=$this->ftpextensionINI->variable('CaptionSettings','ImportIPTCPlace');
	     $ImportEXIFDateTime=$this->ftpextensionINI->variable('CaptionSettings','ImportEXIFDateTime');
	     $ImportIPTCCredit=$this->ftpextensionINI->variable('CaptionSettings','ImportIPTCCredit');

              $importResult = array();

              include_once( "lib/ezfile/classes/ezdir.php" );

	     $http =& eZHTTPTool::instance();
	     $lalilu = eZDir::findSubitems ($this->ImportDir);

              function AddCommaAndSpaceIfNotEmpty(&$text)
	     {
              	if (strlen($text)>0)
                 {
                         $text = $text . ', ';
                 }
	     }

              function AddParagraphTags(&$text)
	     {
              	if (strlen($text)>0)
                 {
              		$text = '<paragraph>' . $text . '</paragraph>';
                 }
	     }

              function AddItalicTags(&$text)
	     {
              	if (strlen($text)>0)
                 {
              		$text = '<emphasize>' . $text . '</emphasize>';
                 }
	     }

              function AddBoldTags(&$text)
	     {
              	if (strlen($text)>0)
                 {
              		$text = '<strong>' . $text . '</strong>';
                 }
	     }

	     function XML_wrap($text)
	     {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" ."\n".
        		"<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\""."\n".
        		"   xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\""."\n".
        		"   xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\">".
        		$text . "\n</section>\n" ;
	     }


              function saveImage($placeNodeID, $h1Tag, $notesTag, $href, $altTag, $hrefPur, $creatorID, $classID)
              {

                // Import image
                if ( file_exists( $href ) )
	       {
                      $class =& eZContentClass::fetch( $classID );

                      $parentNodeID = $placeNodeID;

	             $contentObject =& $class->instantiate( $creatorID, 1 );

		     $nodeAssignment =& eZNodeAssignment::create( array(
                             'contentobject_id' => $contentObject->attribute( 'id' ),
                             'contentobject_version' => $contentObject->attribute( 'current_version' ),
                             'parent_node' => $parentNodeID,
                             'sort_field' => 2,
		            'sort_order' => 0,
		            'is_main' => 1
                                                                  )
			                                                );
		     $nodeAssignment->store();

		     $version =& $contentObject->version( 1 );
		     $version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
		     $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );

		     $version->store();

		     $contentObjectID = $contentObject->attribute( 'id' );
		     $dataMap =& $contentObject->dataMap();

		     $dataMap['name']->setAttribute( 'data_text', $h1Tag );
		     $dataMap['name']->store();

		     $dataMap['caption']->setAttribute( 'data_text', $notesTag );
                      $dataMap['caption']->store();

		     $imageContent =& $dataMap['image']->attribute( 'content' );
		     $imageContent->initializeFromFile( $href , $altTag , $hrefPur);
		     $dataMap['image']->store();


                      include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
		     $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                                   'version' => 1 ) );

                      $mypriorityID = $contentObjectID;

                      return $mypriorityID;

	        } //if file exist
	     }    //saveImage



	     $myprioritycounter = 0;
	     $level = 1;

	     foreach ( $lalilu as $childNode )
	     {

	             $hrefPur = $childNode;

		     $href = $this->ImportDir . $childNode;
                      $size = getimagesize ($href, $info);

        		     if(is_array($info))
        		     {
                		$iptc = iptcparse($info["APP13"]);

                         /*
                         //use this to show available fields.
                         foreach (array_keys($iptc) as $s)
                		{

                         $c = count ($iptc[$s]);
                		for ($i=0; $i<$c; $i++)
                         	{
                         	echo $s.' = '.$iptc[$s][$i].'<br>';
			 	}
                		}
			*/
                         //here, we return title, caption, and credit. other fields might be added

                      }

		     $exif = array();
		     if (isset($info))
                      {
                         $exif = array();
                         $exif = exif_read_data($href, 'EXIF',True);

                         /*
                         //use this to find available fields
                         echo $href."<br />\n";
                         echo $exif===false ? "No header data found.<br />\n" :
			"Image contains headers<br />\n";

			foreach ($exif as $key => $section)
                         	{
                                 foreach ($section as $name => $val)
                                 	{
                                         echo "$key.$name: $val<br />\n";
                                         }
                                 }
                         */
                      }

                      $notesTag = "";
                      if (strtolower($ImportIPTCTitle)=='true')
                      {
                         $s = "";
                         $s = utf8_encode($iptc["2#005"][0]);

                         AddBoldTags($s);
                         AddParagraphTags($s);
                         $notesTag = $s;
                      }

                      if (strtolower($ImportIPTCCaption)=='true')
                      {
                         $s = "";
                         $s = utf8_encode($iptc["2#120"][0]);
                         AddParagraphTags($s);
                         $notesTag = $notesTag . $s;
                      }

                      if (strtolower($ImportIPTCPlace)=='true')
                      {
                         $s = "";

                         //City
                         $s = $iptc["2#090"][0];
                         AddCommaAndSpaceIfNotEmpty($s);

                         //Location
                         $s = $s . $iptc["2#092"][0];
                         AddCommaAndSpaceIfNotEmpty($s);

                         //State
                         $s = $s . $iptc["2#095"][0];
                         AddCommaAndSpaceIfNotEmpty($s);

                         //Country
                         $s = $s . $iptc["2#101"][0];
                         AddCommaAndSpaceIfNotEmpty($s);

                         $s = rtrim($s, ', ');
                         $s = utf8_encode($s);
                         AddParagraphTags($s);
                         $notesTag = $notesTag . $s;
                      }

                      if (strtolower($ImportEXIFDateTime)=='true')
                      {
                         //TODO: what if there is no data?
                         $xdate = explode(':', str_replace(" ",":",$exif['EXIF']['DateTimeOriginal']));
                         $date = utf8_encode(date('j F Y, G:i', mktime($xdate[3],$xdate[4],$xdate[5],$xdate[1],$xdate[2],$xdate[0])));
                         AddParagraphTags($date);
                         $notesTag = $notesTag . $date;
                      }

                      if (strtolower($ImportIPTCCredit)=='true')
                      {
                         $s = "";
                         $s = utf8_encode('&#169; '.$iptc["2#110"][0]);
                         AddItalicTags($s);
                         AddParagraphTags($s);
                         $notesTag = $notesTag . $s;
                      }

                      $notesTag = XML_wrap($notesTag);
                      $h1Tag = $childNode;
		     $altTag = $childNode;

		     $priorityID[] =	saveImage ($placeNodeID, $h1Tag, $notesTag, $href, $altTag, $hrefPur, $creatorID, $classID);

                      //Delete the file
                      if (strtolower($DeleteAfterImport)=='true')
                      {
                         unlink($href);
                      }

		     $priority[] = $myprioritycounter;
		     $myprioritycounter++;
	     } // end  foreach ( $sectionNodeArray as $sectionNode )

	     include_once( 'kernel/classes/ezcache.php' );
	     eZCache::clearByTag( 'content' );

              return $importResult;

	} // funct import end

         var $ftpextensionINI;
         var $ImportDir;
         var $mypriorityID;
         var $priorityID;

}   //class FtpImportImport end

?>