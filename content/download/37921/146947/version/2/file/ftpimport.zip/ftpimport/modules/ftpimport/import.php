<?php

/*
***************************************************************************************
Imports image files from a directory on the same server as EzPublish into it.

**************************************************************************************
*/


include_once( "kernel/common/template.php" );
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'lib/ezutils/classes/ezhttpfile.php' );

include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'lib/ezlocale/classes/ezdatetime.php' );

include_once( "kernel/classes/ezcontentbrowse.php" );

include_once("extension/ftpimport/modules/ftpimport/ftpimport.php");

$http =& eZHTTPTool::instance();
$module =& $Params["Module"];

$tpl =& templateInit();

if ( $module->isCurrentAction( 'FtpImportPlace' ) )
{
    // We have the file and the placement. Do the actual import.
    $selectedNodeIDArray = eZContentBrowse::result( 'FtpImportPlace' );

    $nodeID = $selectedNodeIDArray[0];

    if ( is_numeric( $nodeID ) )
    {
            $import = new FtpImportImport();
            $result = $import->import( $http->sessionVariable( "ftpimport_import_filename" ), $nodeID );

            $tpl->setVariable( 'class_identifier', $result['ClassIdentifier'] );
            $tpl->setVariable( 'url_alias', $result['URLAlias'] );
            $tpl->setVariable( 'node_name', $result['NodeName'] );

            $http->removeSessionVariable( 'ftpimport_import_step' );
    }
    else
    {
        eZDebug::writeError( "Cannot import document, supplied placement nodeID is not valid." );
    }

    $tpl->setVariable( 'ftpimport_mode', 'imported' );
}
else
{
    $http->setSessionVariable( 'ftpimport_import_step', 'browse' );

    eZContentBrowse::browse( array( 'action_name' => 'FtpImportPlace',
                                    'description_template' => 'design:ftpimport/browse_place.tpl',
                                    'content' => array(),
                                    'from_page' => '/ftpimport/import/',
                                    'cancel_page' => '/ftpimport/import/' ),
                             $module );
    return;

    $tpl->setVariable( 'ftpimport_mode', 'browse' );
}
$Result = array();
$Result['content'] =& $tpl->fetch( "design:ftpimport/import.tpl" );
$Result['path'] = array( array( 'url' => '/ftpimport/import/',
                                'text' => ezi18n( 'extension/ftpimport', 'Import images from folder on server' ) ));

?>