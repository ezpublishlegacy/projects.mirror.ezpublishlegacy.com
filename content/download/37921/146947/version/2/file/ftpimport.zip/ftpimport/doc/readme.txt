/*
***************************************************************************************
FTPImport v. 0.1
----------------

Imports image files from a directory on the same server as EzPublish into it, and
writes some IPTC and EXIF fields into the caption of the EzImage.

To make it work,
1. you may have to adapt some of the parameters (such as the folder you import from)
in /settings/ftpimport.ini
2. Install in the usual way for an extension (see:
http://ez.no/doc/ez_publish/technical_manual/4_0/installation/extensions)

You probably want to adapt the selection of ITPC and EXIF fields as well as the way
they are presented. To do this, edit the ftpimport.php file
(the comments in that file should give you a way to start).

To use:
Browse to http://www.example.com/ezpublish-...n_site_admin/ftpimport/import and follow
the instruction.

adapted from coolzipimport by Tobias B�hrer. Use as you like, at your own risk.
Works with EzPublish 4.0.0, may work with other versions (not tested).

29 March 2008.
***************************************************************************************
*/