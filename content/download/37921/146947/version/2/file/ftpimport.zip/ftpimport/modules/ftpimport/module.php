<?php

$Module = array( 'name' => 'FtpImport',
                 'variable_params' => true );

$ViewList = array();
$ViewList['import'] = array(
    'script' => 'import.php',
    'post_actions' => array( 'BrowseActionName' ) );


?>