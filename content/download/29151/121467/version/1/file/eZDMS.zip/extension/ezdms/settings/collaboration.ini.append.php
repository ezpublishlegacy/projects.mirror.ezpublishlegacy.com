#?ini charset="iso-8859-1"?
# eZ Publish configuration file for collaboration.
#

[HandlerSettings]
# A list of extensions which have collaboration code
# It's common to create a settings/collaboration.ini.append file
# in your extension and add the extension name to automatically
# get code from the extension when it's turned on.
Extensions[]=ezdms
