<?php
/**
 * File containing the eZ Publish upload view implementation.
 *
 * @copyright Copyright (C) 2005-2009 eZ Systems AS. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.1
 * @package ezmultiupload
 * 
 * Original code source modified by cyp@open-net.ch
 * 		- 2009.06.28	completed the response of the upload:
 * 							if uploading a file that corresponds to exactely one eZ DMS File
 * 								then the file is accepted
 * 								else the file is rejected
 * 							in either cases, a status message is displayed        
 */

include_once( 'kernel/common/template.php' );

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";
include_once( $baseDir . "ezdmsmisctools.php" );
include_once( $baseDir . "ezdmsdebugtools.php" );

$http = eZHTTPTool::instance();
$tpl = templateInit();
$ini = eZINI::instance();
$module = $Params['Module'];
$parentNodeID = $Params['ParentNodeID'];
$onsmsg = "";

$current_site_access = false;
if ( $http->hasPostVariable( 'current_site_access' ) ) {
	$val = $http->postVariable( 'current_site_access' );
	if ( $val && $val != "" )
		$current_site_access = "/$val";
}

	$cond_debug = false;
	$label_debug = "ezdms-multiuploads";
	if ( in_array('eZ DMS Stuff', $_SESSION) ) {
		$session_info = print_r( $_SESSION['eZ DMS Stuff'], true );
	}
	else {
		$session_info = "N/A";
	}
	$current_action_info = eZModule::currentAction( );
	if ( ! $current_action_info )				
		$current_action_info = "N/A";
	else
		$current_action_info = print_r( $current_action_info, true );			
	eZDMSDebugTools::writeNotice(	$cond_debug,
									"Entering $label_debug with session=$session_info\nand current action=$current_action_info", 
									$label_debug );

		$upload_count = 0;
		$res = "Current action is ".$module->currentAction()."\n";
		foreach ($_POST as $name => $value) {
			$upload_count++;
			$res .= $name . " => ". nl2br(htmlentities(stripslashes($value)))."\n";
		}
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Upload with $label_debug gave:\n$res", 
										$label_debug );

// Check if current action is an real upload action
// 2010-05-17: changed because of the new upload system
// if( $module->isCurrentAction( 'Upload' ) )
if ( $upload_count > 0 )
{
    $result = array( 'errors' => array(),
                     'notices' => array(),
                     'result' => false,
                     'redirect_url' => false );

			$uploaded_files = array();
			for($i = 0; $i < $upload_count; $i++) {
				$post_index = "browserplus_uploader_".$i;
				if ( $_POST[$post_index."_status"] == 'done' ) {
				
					$tmp_dir = ini_get("upload_tmp_dir") . DIRECTORY_SEPARATOR . "plupload" . DIRECTORY_SEPARATOR;
					$tmp_file_name = $tmp_dir . $_POST[$post_index."_tmpname"];

					$uploaded_name = $_POST[$post_index."_name"];					
					$uploaded_ext  = strtolower( eZFile::suffix( $uploaded_name ) );

					$mimeData = eZMimeType::findByURL( $uploaded_name );
			        $storageDir = eZSys::storageDirectory();
			        list( $group, $type ) = explode( '/', $mimeData['name'] );
			        $mimeData['dirpath'] = $storageDir . '/original/' . $group;
			        $mimeData['url'] = $mimeData['dirpath'] . '/' . md5( basename( $uploaded_name ) . microtime() . mt_rand() ) . '.' . $mimeData['suffix'];
					
					// Store the uploaded file in the destination folder
			        $dest_name = $mimeData['url'];
			        if ( copy( $tmp_file_name, $dest_name ) === false ) {
						$onsmsg .= "<li>The file '$uploaded_name' could not be copied from '$tmp_file_name' to '$dest_name'</li>";
						continue;
					}
		            $perm = $ini->variable( "FileSettings", "StorageFilePermissions" );
		            $oldumask = umask( 0 );
		            chmod( $dest_name, octdec( $perm ) );
		            umask( $oldumask );
		
		            // Write log message to storage.log
		            $storageDir = $mimeData['dirpath'] . "/";
		            eZLog::writeStorageLog( basename( $uploaded_name ), $storageDir );
			        
					$cond_debug = false;
					
					// Check if this file name does not already corresponds to an existing attached file
					$objects_ids_list = eZDMSMiscTools::fetch_object_by_filename( $uploaded_name, 'ezdms_file' );
					switch( count( $objects_ids_list ) ) {
					case 0:
						$onsmsg .= "<li>The file '$uploaded_name' does not correspond at any eZ DMS File - the file is rejected</li>";
/*						
						// Remove any temp./unwanted files
						if ( file_exists( $tmp_file_name ) ) {
							unlink( $tmp_file_name );
						}
						if ( file_exists( $mimeData['url'] ) ) {
							unlink( $mimeData['url'] );
						}
*/
					break;
					
					case 1:
						// If there's a node, then we can show its path...
						$node = eZContentObjectTreeNode::findMainNode( $objects_ids_list[0], true );
						if ( is_object( $node ) ) {
							$node_alias = $node->attribute( 'url_alias' );
							$onsmsg .= "<li>The file '$uploaded_name' corresponds at exactly one eZ DMS File: <a href='$current_site_access/$node_alias'>$node_alias</a> - the file is accepted</li>";
						}
						else {
							// No node, no trouble... let's show the content object ID
							$onsmsg .= "<li>The file '$uploaded_name' corresponds at exactly one eZ DMS File: object ID ".$objects_ids_list[0]." - the file is accepted</li>";
						}
		
						// now that the uploaded file is accepted, let's update the corresponding object 'File' attribute
						$obj = eZContentObject::fetch( $objects_ids_list[0] );
						if ( is_object( $obj ) ) {
							
							if ( $obj->canEdit() ) {
							
								$main_node_id = $obj->attribute( 'main_node_id' );
								if ( eZDMSFileTools::is_locked( $main_node_id ) ) {
									eZDMSFileTools::unlock_it( $main_node_id );
								}
							
								$new = $obj->createNewVersion();
								$dataMap = $obj->fetchDataMap( $new->attribute( 'version' ) );
								foreach( $dataMap as $key => $object_attribute ) {
									if ( $key == 'file' ) {
										
										$temp = explode( "/", $mimeData['url'] );
										$row = array( 'contentobject_attribute_id' => $object_attribute->attribute( 'id' ),
								                      'version' => $object_attribute->attribute( 'version' ),
								                      'filename' => $temp[ count( $temp ) -1 ],
								                      'original_filename' => $uploaded_name,
								                      'mime_type' => $mimeData['name'],
								                      );
								        $file_obj = new eZBinaryFile( $row );
										$file_obj->store();
										eZDMSDebugTools::writeNotice(	$cond_debug,
																		"Content Object Attribute updated", 
																		$label_debug );
										break;
									}
								}
								$new->setAttribute( 'status', eZContentObjectVersion::STATUS_PUBLISHED );
								$new->store();
			
								if ( $uploaded_ext == 'odt' ) {

									$ooToolbox = new eZDMSOOTools();
									$c = $ooToolbox->updateDataMap( $dataMap, $tmp_file_name );
								}

			
					            $contentObjectID = $obj->attribute( 'id' );
								$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
					                                                                                         'version'   => $new->attribute( 'version' ) ) );
								eZDMSDebugTools::writeNotice(	$cond_debug,
																"New version (id=$contentObjectID)".( $operationResult ? "" : "not " )." published (v".$new->attribute( 'version' ).")", 
																$label_debug );
							}
							else {
					        	$msg = ezi18n( 'kernel/content/upload', 'The file you tried to upload is currently locked, please contact the editor.' );
					            $result['errors'][] = array( 'description' => $msg );
					            $onsmsg .= "<li>$msg</li>";
							}
						}
					break;
					
					default:
						$onsmsg .= "<li>The file '$uploaded_name' corresponds at too many eZ DMS Files - the file is rejected:<ul>";
						foreach( $objects_ids_list as $object_id ) {
							$node = eZContentObjectTreeNode::findMainNode( $object_id, true );
							if ( is_object( $node ) ) {
								$node_alias = $node->attribute( 'url_alias' );
								$onsmsg .= "<li><a href='$current_site_access/$node_alias'>$node_alias</a></li>";
							}
						}
						$onsmsg .= "</ul></li>"; 
/*						
						// Remove any temp./unwanted files
						if ( file_exists( $tmp_file_name ) ) {
							unlink( $tmp_file_name );
						}
						if ( file_exists( $mimeData['url'] ) ) {
							unlink( $mimeData['url'] );
						}
*/
					}

					unlink( $tmp_file_name );
				}
			}

	    //}
		$_SESSION['onsmsg'] = $onsmsg;
/*    
    // Exec multiupload handlers postUpload method
    eZMultiuploadHandler::exec( 'postUpload', $result );

    // Pass result to template and process it
    $tpl->setVariable( 'result', $result );
    $templateOutput = $tpl->fetch( 'design:ezdms/thumbnail.tpl' );

    // Strip all new lines from processed template and convert all applicable characters to 
    // HTML entities output. Create upload ID
    $httpCharset = eZTextCodec::httpCharset();
    $data = htmlentities( str_replace( array( "\r\n", "\r", "\n" ), array(""), $templateOutput ) , ENT_QUOTES, $httpCharset );
    $id = md5( (string)mt_rand() . (string)microtime() );
 
    $response = array( 'data' => $data, 'id' => $id, 'allFilesRecived' => $data );

    // Return server response in JSON format
    echo eZAjaxContent::jsonEncode( $response );

    // Stop execution
    eZExecution::cleanExit();
*/
}
//else
//{
    // Check if parent node ID provided in URL exists and is an integer
    if ( !$parentNodeID || !is_numeric( $parentNodeID ) )
        return $module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );

    // Fetch parent node
    $parentNode = eZContentObjectTreeNode::fetch( $parentNodeID );
    
    // Check if parent node object exists
    if( !$parentNode )
        return $module->handleError( eZError::KERNEL_NOT_FOUND, 'kernel' );

    // Check if current user has access to parent node and can create content inside
    if( !$parentNode->attribute( 'can_read' ) || !$parentNode->attribute( 'can_create' ) )
        return $module->handleError( eZError::KERNEL_ACCESS_DENIED, 'kernel' );

    // Get configuration INI settings for ezmultiupload extension
    $uploadINI = eZINI::instance( 'ezmultiupload.ini' );
    $availableClasses = $uploadINI->variable( 'MultiUploadSettings', 'AvailableClasses' );
    $availableSubtreeList = $uploadINI->variable( 'MultiUploadSettings', 'AvailableSubtreeNode' );
    $parentNodeClassIdentifier = $parentNode->attribute( 'class_identifier' );

    // Check if current parent node class identifier and node ID match configuration settings
    if( !in_array( $parentNodeClassIdentifier, $availableClasses )
            && !in_array( $parentNodeID, $availableSubtreeList ) )
        return $module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );

    $availableFileTypes = array();
    $availableFileTypesStr = '';

    // Check if file types setting is available for current subtree
    if( $uploadINI->hasGroup( 'FileTypeSettings_' . $parentNodeID ) )
        $availableFileTypes = $uploadINI->variable( 'FileTypeSettings_' . $parentNodeID, 'FileType' );

    // Check if file types setting is available for current class identifier
    // and merge it with previusly loaded settings
    if( $uploadINI->hasGroup( 'FileTypeSettings_' . $parentNodeClassIdentifier ) )
        $availableFileTypes = array_merge( $availableFileTypes, $uploadINI->variable( 'FileTypeSettings_' . $parentNodeClassIdentifier, 'FileType' ) );

    // Create string with available file types for GUI uploader
    if ( count( $availableFileTypes ) > 0 )
        $availableFileTypesStr = implode( ';', $availableFileTypes );

    // Pass variables to upload.tpl template
    $tpl->setVariable( 'file_types', $availableFileTypesStr );
    $tpl->setVariable( 'session_id', session_id() );
    $tpl->setVariable( 'session_name', session_name() );
    $tpl->setVariable( 'user_session_hash', eZSession::getUserSessionHash() );
    $tpl->setVariable( 'parent_node', $parentNode );
    //$tpl->setVariable( 'current_site_access', $current_site_access );
    
    if ( isset( $_SESSION['onsmsg'] ) && $_SESSION['onsmsg'] != "" ) {
		$onsmsg = '<ul>' . $_SESSION['onsmsg'] . '</ul>';
	}
	$tpl->setVariable( 'onsmsg', $onsmsg );

    // Process template and set path data
    $Result = array();
    $Result['content'] = $tpl->fetch( 'design:ezmultiupload/upload.tpl' );
    $Result['path'] = array( array( 'url' => false,
                                    'text' => ezi18n( 'extension/ezmultiupload', 'Multiupload' ) ) );
                                    
    $_SESSION['onsmsg'] = "";
//}

?>
