<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch
				cyp@open-net.ch

Created on:     09 june 2009
Last change on: 
Version:        1.0
Extension:		eZ DMS
Description:    Tools for eZ DMS Cronjobs management
Installation:	Do not forget to run once:
				php bin/php/ezsqlinsertschema.php --type=mysql --user=dbUser --password=dbPassword extension/ezdms/sql/ezdms.dba mydb
				This scripts should be run from eZ Publish's root directory in command-line
				That way, eZ Publish will know everything about eZDMSCronjob objects
History:		

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
//include_once( $baseDir . "ezdmsfoldertools.php" );
//include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSCronjob extends eZPersistentObject {

	const COND_DEBUG_STRING = 'ezdms-cronjobs';
	const BASE_DEBUG_LABEL = "eZDMSCronjob::";

	// Class constructor	
	function eZDMSCronjob( $row ) {
        $this->eZPersistentObject( $row );
	}
	
	// Class definitions
	static function definition() {
	
		return array(	'fields' => array(	'id' => array(	'name' => 'id',
															'datatype' => 'integer',
															'default' => 0,
															'required' => true ),
											'name' => array('name' => 'Name',
															'datatype' => 'string',
															'default' => '',
															'required' => true ),
											'hash' => array('name' => 'Hash',
															'datatype' => 'string',
															'default' => '',
															'required' => true ),
											'contentobject_id' => array(	'name' => 'contentobject_id',
																			'datatype' => 'integer',
																			'default' => '0',
																			'required' => true ),
											'contentobject_version' => array(	'name' => 'contentobject_version',
																				'datatype' => 'integer',
																				'default' => '0',
																				'required' => true ),
											'what_to_do' => array(	'name' => 'what_to_do',
																	'datatype' => 'string',
																	'default' => 'setup_folder_permissions',
																	'required' => true ),
											'class_identifier' => array(	'name' => 'class_identifier',
																			'datatype' => 'string',
																			'default' => 'ezdms_folder',
																			'required' => true ),
											'node_id' => array(	'name' => 'node_id',
																'datatype' => 'integer',
																'default' => 0,
																'required' => true ),
											'object_id' => array(	'name' => 'object_id',
																	'datatype' => 'integer',
																	'default' => 0,
																	'required' => true ),
											'added_by' => array(	'name' => 'added_by',
																	'datatype' => 'integer',
																	'default' => 0,
																	'required' => true ),
											'timestamp_added' => array(	'name' => 'timestamp_added',
																	'datatype' => 'integer',
																	'default' => 0,
																	'required' => true ),
											'handled_by' => array(	'name' => 'handled_by',
																	'datatype' => 'integer',
																	'default' => 0,
																	'required' => true ),
											'timestamp_handled' => array(	'name' => 'timestamp_handled',
																			'datatype' => 'integer',
																			'default' => 0,
																			'required' => true ),
											'status' => array(	'name' => 'status',
																'datatype' => 'string',
																'default' => 'todo',
																'required' => true ),
										 ),
						'keys' => array( 'id' ),
						'increment_key' => 'id',
						'sort' => array( 'id' => 'asc' ),
						'class_name' => 'eZDMSCronjob',
						'name' => 'ezdms_cronjob'
					);
	
	}

	/*
		Static function that creates a new cronjob object
		Duplicates are ignored. They are identified by analyzing the 'what to do' attribute and its specific attribute(s)
		Returns:	true if everything ran fine
					false: an error happened. Activate the debugging to have the details
	 */
	static public function new_cronjob( $what_to_do, $object_class_identifier, $node_id, $object_id, $name = false ) {

		// Say 'Helo' to the log...
    	$label_debug = eZDMSCronjob::BASE_DEBUG_LABEL."new_cronjob()";
		eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
										"What to do: $what_to_do on: $object_class_identifier, node: $node_id, object id: $object_id", 
										$label_debug );

		// Obvious... nothing to do means return back to the caller immediately
		if ( !$what_to_do || $what_to_do=="" ) {
		
			eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
											"Nothing to do", 
											$label_debug );
			return true;
		}

		// Specific checkings
		switch ( $what_to_do ) {
			case "setup_folder_permissions":
				// The Node ID is mandatory
				if ( !$node_id ) {
				
					eZDMSDebugTools::writeError(	eZDMSCronjob::COND_DEBUG_STRING,
													"For the cronjob '$what_to_do', the object's node ID is mandatory", 
													$label_debug );
					return false;
				}
				
				// Forget if the node is already setup as 'todo' for this operation
				$conds = array(	'what_to_do' => $what_to_do,
								'node_id'    => $node_id,
								'status'     => 'todo',
							 );
				$res = eZDMSCronjob::fetchList( true, $conds );
				if ( $res == null ) break;
				if ( is_array( $res ) ) {
					if ( count( $res ) > 0 ) {
					
						eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
														"The object with the node ID $node_id is already flagged as 'todo' for the cronjob '$what_to_do'", 
														$label_debug );
						return false;
					}
				}
			break;
		}
		
		// Prepare everything to create a new cronjob
		$now = time(); 
		if ( !$name ) {
			$name = $what_to_do . " " . $object_id . " " . date( "Y-m-d H:i:s", $now );
		}
		if ( $object_class_identifier && $object_class_identifier != "" ) {
			$object_class = eZContentClass::fetchByIdentifier( $object_class_identifier );
			if ( !is_object( $object_class ) ) {
			
				eZDMSDebugTools::writeError(	eZDMSCronjob::COND_DEBUG_STRING,
												"Unknown class identifier: $object_class_identifier", 
												$label_debug );
				return false;
			}
		}
		
		// Create the new cronjob, store it to the DB => default date/time values
		$row = array(
			'name' => $name,
			'what_to_do' => $what_to_do,
			'class_identifier' => $object_class_identifier,
			'node_id' => $node_id,
			'object_id' => $object_id,
			'added_by' => eZUser::currentUserID(),
			'timestamp_added' => $now,
			'status' => 'todo',
			'hash' => md5( time() . '-' . mt_rand() ),
			);
		$cronjob = new eZDMSCronjob( $row );
		if ( !is_object( $cronjob ) ) {
		
			eZDMSDebugTools::writeError(	eZDMSCronjob::COND_DEBUG_STRING,
											"Unable to create a new eZ DMS Cronjob", 
											$label_debug );
			return false;
		}
		$cronjob->store();
		
		eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
										"New cronjob created: ".print_r( $cronjob, true ), 
										$label_debug );
		
		return true;
	}

	/*
		Static, overloading function, that returns a list of cronjob objects
	 */
	static function fetchList( $asObject = true, $conditions = null, $offset = false, $limit = false ) {
	
		$limitation = null;
		if ( $offset !== false or $limit !== false ) {
		
			$limitation = array( 'offset' => $offset, 'length' => $limit );
		}

		return eZPersistentObject::fetchObjectList(	eZDMSCronjob::definition(),
													null,
													$conditions, null, $limitation,
													$asObject );
	}

	/*
		This static function loops once one each cronjob and handles it.
		All cronjob with the status='todo' are handled, others are ignored
		An array is updated within the loop and returned afterwards:
		array:
				'done'		= number of items handled correctly
				'skipped'	= number of items skipped because of an invalid 'what to do' attribute
				'canceled'	= number of items skipped because of an error
	 */	
	static function handle_todos() {
	
		// Say 'Helo' to the log...
    	$label_debug = eZDMSCronjob::BASE_DEBUG_LABEL."handle_todos()";
		eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
										"Starting Todo's main loop", 
										$label_debug );

		$conds = array( 'status' => 'todo', );
		$sorts = array( 'timestamp_added' => 'asc', );
		$cronjobs = eZDMSCronjob::fetchList( true, $conds );
		$counts = array( 'done' => 0, 'skipped' => 0, 'canceled' => 0 );
		if ( is_array( $cronjobs ) ) {
			foreach ( $cronjobs as $cronjob  ) {
				$cronjob->setAttribute( 'handled_by', eZUser::currentUserID() );
				$cronjob->setAttribute( 'timestamp_handled', time() );
				$cronjob->setAttribute( 'status', 'busy' );
				$cronjob->store();
				
				$status = 'done';
				switch ( $cronjob->attribute( 'what_to_do' ) ) {
					case 'setup_folder_permissions':
						$res = eZDMSFolderTools::setup_folder_permissions( $cronjob->attribute( 'node_id' ) );
						if ( !$res ) $status = 'canceled';
					break;
					
					default:
						$status = 'skipped';	// in the future, forget this 'todo' because we don't known how to handle it
					break;
				}
				$counts[ $status ] = $counts[ $status ] + 1; 
				
				$cronjob->setAttribute( 'timestamp_handled', time() );
				$cronjob->setAttribute( 'status', $status );
				$cronjob->store();
			}
		}

		// Say 'goodbye' to the log...
		eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
										"Endn of Todo's main loop, Results are: ".print_r( $counts, true ), 
										$label_debug );

	}
	
	/*
		This static function resets the status to 'todo'
		The parameter may be eith a string or an array of strings
	 */
	static function reset_status_for( $status_to_reset ) {
	
		// Say 'Helo' to the log...
    	$label_debug = eZDMSCronjob::BASE_DEBUG_LABEL."handle_todos()";
		eZDMSDebugTools::writeNotice(	eZDMSCronjob::COND_DEBUG_STRING,
										"Resetting the status to 'done' for cronjobs in the state '$status_to_reset'", 
										$label_debug );

		$db = eZDB::instance();
		$def = eZDMSCronjob::definition();
		$table = $def['name'];
		if ( is_array( $status_to_reset ) )
			$end_of_query = " in (" . implode( ",", $status_to_reset ) . ")";
		else
			$end_of_query = " = '$status_to_reset'";
		$query = "UPDATE $table SET status='todo' WHERE status" . $end_of_query;

		$db->begin();
		$db->query( $query );
		$db->commit();
	}

}

