<?php /* #?ini charset="utf8"?

[article]
Attribute[caption]=caption
Attribute[publish_date]=publish_date
Attribute[unpublish_date]=unpublish_date
*/ ?>