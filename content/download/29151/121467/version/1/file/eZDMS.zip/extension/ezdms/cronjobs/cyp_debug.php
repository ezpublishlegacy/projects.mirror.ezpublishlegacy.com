<?php
include_once( "kernel/classes/ezcontentobjecttreenode.php" );
include_once( "kernel/classes/ezcontentobjecttreenodeoperations.php" );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
include_once( "lib/ezutils/classes/ezini.php" );

// Check for extension
include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'kernel/common/ezincludefunctions.php' );
eZExtension::activateExtensions();
// Extension check end

// include_once( 'lib/ezutils/classes/ezdebugsetting.php' );

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsfoldertools.php" );
include_once( $baseDir . "ezdmsfiletools.php" );
include_once( $baseDir . "ezdmsstafftools.php" );
include_once( $baseDir . "ezdmscronjobtools.php" );
include_once( $baseDir . "ezdmsmisctools.php" );

$ini = eZINI::instance( 'override.ini' );
$userID = 14; // $ini->variable( "eZDMSGeneralSettings", "superUserID" );
$current_user_id = eZUser::currentUserID();
$user = eZUser::fetch( $userID );
if ( !$user ) {
	echo "Can't login: super user id invalid: $userID";
}
else {
$user->loginCurrent();
echo "Script running with user ID ".eZUser::currentUserID()."\n";
echo date( "H:i:s" )."\n";
/*
	$funcs = new eZDMSFunctionCollection();
	$node_id = 3155;
	$node = eZContentObjectTreeNode::fetch( $node_id );
	$object = eZContentObject::fetchByNodeID( $node_id );
	$data_map = $object->attribute( 'data_map' );
	$attribute = $data_map['editors'];
	$content = $attribute->content();

	$r = $funcs->groups_users_list( 
									$node_id,
									false,
									'_data_object_relation_list_' . $attribute->attribute('id'),
									$attribute->attribute('contentclass_attribute_identifier'), 
									$content['relation_list'], true, true, 
									1, 
									array(), 
									$node->attribute( 'parent_node_id' ) );
	print_r( $r['result'] );
*/

	$class_name = 'ezdms_file';
	$treeseleclection_class_name = 'eztreeselection';
	$class_id   = eZContentClass::classIDByIdentifier( $class_name );
	$attributes_class_list = eZContentClassAttribute::fetchListByClassID( $class_id );
	$treeselection_class_id = 0;
	foreach( $attributes_class_list as $attribute ) {
		if ( $attribute->attribute( 'data_type_string' ) == $treeseleclection_class_name ) {
			$treeselection_class_id = $attribute->attribute( 'id' );
			break;
		}
	}
	print_r( $treeselection_class_id );
	echo "\n";

echo date( "H:i:s" )."\n";
$user = eZUser::fetch( $current_user_id );
$user->loginCurrent();

}
echo "\n";
?>
