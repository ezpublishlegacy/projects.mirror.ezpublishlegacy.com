<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezdms
ModuleList[]=ezdmstools

*/ ?>
