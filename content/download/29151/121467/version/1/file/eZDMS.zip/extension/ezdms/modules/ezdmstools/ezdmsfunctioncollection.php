<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 29 april 2010
Version:        1.1
Extension:		eZDMS
Description:    functions collection for use in the templating system
				29 april 2010: eZ DMS Staff becomes eZ DMS User

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";
include_once( $baseDir . "ezdmsfiletools.php" );
include_once( $baseDir . "ezdmsdebugtools.php" );

if ( ! class_exists( "eZDMSFunctionCollection" ) ) {
class eZDMSFunctionCollection
{
    /*!
     Constructor
    */
    function eZDMSFunctionCollection() {

    }

    function is_doc_locked( $node_id ) {
    
        return array( 'result' => eZDMSFileTools::is_locked( $node_id ) ? 1 : 0 );
    }
    
    function groups_users_list( $node_id, $ug_sub_node_id, $attr_base_name, $this_attribute_name, $content_relation_list, $include_users_list = 0, $exclude_groups = 0, $depth = 1, $filter_list = array(), $readonly_filter_list = array(), $default_parent_node_id = 0, $depth_counter = 0 ) {
		
		$ret = "";
		$ug_list = array();
		$depth_counter = $depth_counter + 1;

		// Setup the parameters for the search of the sub-nodes
		$class_filter_array = array( 'user_group' );
		if( $include_users_list ) $class_filter_array[] = 'ezdms_user';
		$params = array('ClassFilterType' => 'include', 
						'ClassFilterArray' => $class_filter_array,
						'DepthOperator' => 'eq',
						'Depth' => $depth,
						);

		// Retrieve the current parent node ID
		$parent_node_id = 0;
		if ( $default_parent_node_id != 0 )
			$parent_node_id = $default_parent_node_id;
		elseif( isset( $_SESSION['eZ DMS Stuff'] ) ) {
			$values = $_SESSION['eZ DMS Stuff'];
			if ( isset( $values['module_result'] ) ) {
				$module_result = $values['module_result'];
				if ( isset( $module_result['path'] ) ) {
					$path = $module_result['path'];
					for($i=0; $i<count( $path ); $i++) {
						$item = $path[$i];
						if ( !isset( $item['node_id'] ) )
							break;
						if ( intval( $item['node_id'] == intval( $node_id ) ) )
							break;
						$parent_node_id = intval( $item['node_id'] );
					}
				}
			}
		}

		$ezdmsINI = eZINI::instance( 'ezdms.ini' );
		$skip_main_nodes = strtolower( $ezdmsINI->variable( 'ezobjectrelationlist', 'skip_main_nodes' ) ) == 'yes';

//		$folder_node = eZContentObjectTreeNode::fetch( $node_id );
//		if ( $folder_node ) {
		if ( $parent_node_id > 0 ) {
		
			// @ the 1st call, i.e. from the templating system, the users and groups sub-node ID is null
			// so that we known for sure that we have to build the list of allowed nodes,
			// this list is based on one of the eZ DMS parent folder attributes
			if ( $ug_sub_node_id == false ) {
				// begin from the very first users and groups node of eZ
				$ug_sub_node_id = $ezdmsINI->variable( 'User Nodes', 'node_id_for_validated_users' );
				$parent_node = eZContentObjectTreeNode::fetch( $parent_node_id );
				if ( $parent_node ) {
					// if the parent node is found and is an eZ DMS folder, than we can build a list of filtering nodes
					// else, the list remains empty and all nodes that corresponds to $class_filter_array are candidates
					if ( $parent_node->attribute( 'class_identifier' ) == 'ezdms_folder' ) {
		
						$parent_object = $parent_node->attribute( "object" );
						$parent_dm = $parent_object->attribute( 'data_map' );
						//$dm_attr_name = 'read_perms';	// read the candidates from this attribute only
						if ( isset( $parent_dm[ 'read_perms' ] ) ) {

							$parent_rel_list_attr = $parent_dm[ 'read_perms' ]->content();
							foreach( $parent_rel_list_attr['relation_list'] as $rel_item ) {
								$this_node_id = intval( $rel_item['node_id'] );
								if( !in_array( $this_node_id, $readonly_filter_list ) ) $readonly_filter_list[] = $this_node_id;
								$this_node = eZContentObjectTreeNode::fetch( $this_node_id );
								// each group that is candidate means all of its children are candidates also
								foreach( $this_node->subTree() as $ug_item ) {
									$n = intval( $ug_item->attribute( 'node_id' ) );
									if( !in_array( $n, $readonly_filter_list ) ) $readonly_filter_list[] = $n;
								}
							}
						}
						foreach( array( 'read_perms', 'edit_perms', 'admin_perms' ) as $dm_attr_name ) {
						
							if ( isset( $parent_dm[ $dm_attr_name ] ) ) {

								$parent_rel_list_attr = $parent_dm[ $dm_attr_name ]->content();
								foreach( $parent_rel_list_attr['relation_list'] as $rel_item ) {
									$this_node_id = intval( $rel_item['node_id'] );
									if( !in_array( $this_node_id, $filter_list ) ) {
										$filter_list[] = $this_node_id;
										$i = array_search( $this_node_id, $readonly_filter_list );
										if ( $i !== false ) unset( $readonly_filter_list[$i] ); 										
									}
									$this_node = eZContentObjectTreeNode::fetch( $this_node_id );
									// each group that is candidate means all of its children are candidates also
									foreach( $this_node->subTree() as $ug_item ) {
										$n = intval( $ug_item->attribute( 'node_id' ) );
										if( !in_array( $n, $filter_list ) ) {
											$filter_list[] = $n;
											$i = array_search( $this_node_id, $readonly_filter_list );
											if ( $i !== false ) unset( $readonly_filter_list[$i] ); 										
										}
									}
								}
							}
						}
					}
				}
			}

			$total_items = 0;
			
			/*
				The whole list of candidates is presented hierachically
				Each candidate has a checkbox
					the checkbox is pre-checked if the candidate is already in the relation list that corresponds 
					to the current attribute of the currently edited node in the interface
				A node that is not candidate appears also, but as a simple text line
			*/
			$ub_sub_node_tree = eZContentObjectTreeNode::subTreeByNodeID( $params, $ug_sub_node_id );
			foreach( $ub_sub_node_tree as $child ) {
				
				// Is this child a candidate?
				$valid = false;
				$hide = false;
				if ( count( $filter_list ) == 0 ) {
					$valid = true;
				}
				else {
					if ( in_array( intval( $child->attribute( 'node_id' ) ), $filter_list ) /* &&
						!in_array( intval( $child->attribute( 'node_id' ) ), $readonly_filter_list )*/ ) {
						$valid = true;
					}
				}

				if ( $valid &&  ( $exclude_groups && ( $child->attribute( 'class_identifier' ) == 'user_group' ) ) ) {
					$valid = false;
				}

				// skip the whole line if we must not include the users in the list
				if ( $valid &&  ( !$include_users_list && ( $child->attribute( 'class_identifier' ) == 'ezdms_user' ) ) ) {
					$hide = true;
				}
				
				// skip the whole line if we must skip the main locations of the users
				if (	$valid && 
						$skip_main_nodes  &&
						( $child->attribute( 'class_identifier' ) == 'ezdms_user' ) &&
						( $child->attribute( 'node_id' ) == $child->attribute( 'main_node_id' ) ) ) {
					$hide = true;
				}
				
				//eZDebug::writeNotice( "Node: $node_id, Readonly-list 2: ".print_r($readonly_filter_list,true),
	            //          'Cyp:debug' );

				if ( !$hide ) {
					if ( !$total_items ) {
						$ret .= "<ul>\n";
					}
					
					// Let's build a <li>...</li> tag
					$ret .= "<li>";
					if ( $valid && !isset( $ug_list[ $child->attribute( 'contentobject_id' ) ] ) ) {
						$ug_list[ $child->attribute( 'contentobject_id' ) ] = $child;
						$ret .= "<input type=\"checkbox\" name=\"".$attr_base_name."[".$child->attribute( 'node_id' )."]\" value=\"".$child->attribute( 'contentobject_id' ) ."\"";
						foreach( $content_relation_list as $item ) {
							if( intval( $item['contentobject_id'] ) == intval( $child->attribute( 'contentobject_id' ) ) ) {
								$ret .= " checked=\"checked\"";
								break;
							}
						}
						$ret .= ">";
					}
					$ret .= $child->attribute( 'name' )/*.( $exclude_groups ? " yes" : " no" )*/;
	
					// the <li>...</li> tag is set up, let's see if there's children here before closing it
					$a_ret = $this->groups_users_list( $node_id, $child->attribute( 'node_id' ), $attr_base_name, $this_attribute_name, $content_relation_list, $include_users_list, $exclude_groups, /* depth */ 1, $filter_list, $readonly_filter_list, $default_parent_node_id, $depth_counter );
					if ( count( $a_ret['result'] ) > 0 ) {
						$ret .= $a_ret['result'];
					}
					foreach( $a_ret['ug_list'] as $sub_child ) {
						if ( !isset( $ug_list[ $sub_child->attribute( 'contentobject_id' ) ] ) )
							$ug_list[ $sub_child->attribute( 'contentobject_id' ) ] = $sub_child;
					}
					$ret .= "</li>\n";
					
					$total_items += 1;
				}
			}

			if ( $total_items > 0 ) {
				$ret .= "</ul>";
			}
		}

		return array( 'result' => $ret, 'ug_list' => $ug_list );
	}

	function session_store($key, $value) {
		$values = $_SESSION['eZ DMS Stuff'];
		if ( !$values )
			$values = array();

		$values[ $key ] = $value;
		$_SESSION['eZ DMS Stuff'] = $values;
		
		return array( 'result' => false );
	}
	
    function get_locker( $node_id, $as_array = false, $pre_string = '' ) {
    
        return array( 'result' => eZDMSFileTools::get_locker( $node_id, $as_array, $pre_string ) );
    }
    
    function website_toolbar_accesses( $userID ) {
		$user = eZUser::fetch( $userID );
		$userGroupObjects = $user ? $user->groups( true ) : array();
		$userGroupArray = array();
		foreach ( $userGroupObjects as $userGroupObject ) {
		    $userGroupArray[] = $userGroupObject->attribute( 'id' );
		}
		
		$sql = "SELECT ezpolicy.*, ezpolicy_limitation.*
FROM ezrole, ezuser_role, ezpolicy left join ezpolicy_limitation on (ezpolicy.id=ezpolicy_limitation.policy_id) 
where module_name in ('websitetoolbar','*')
and ezrole.id=ezpolicy.role_id
and ezuser_role.role_id=ezrole.id
and ezuser_role.contentobject_id in ( ".join( ",", $userGroupArray )." )
";
		$db = eZDB::instance();
		$accesses = $db->arrayQuery( $sql );
		for( $i=0; $i < count( $accesses ); $i++ ) {
			$vals = '*';
			if ( $accesses['policy_id'] ) {
				$vals = array();
				$res = $db->arrayQuery( "SELECT ezpolicy_limitation_value.value FROM `ezpolicy_limitation`, ezpolicy,ezpolicy_limitation_value WHERE `policy_id`=ezpolicy.id
and function_name='read'
and limitation_id=ezpolicy_limitation.id
and policy_id=" . $accesses['policy_id'] );
				foreach( $res as $item )
					$vals[] = $item['value'];
			}
			$accesses[$i]['limitation'] = $vals;
		}
	
		return array( 'result' => $accesses );
	}

	function current_site_access( ) {

		$complete_url = $_SERVER['SCRIPT_URL'];
		if ( $complete_url == "" || $complete_url == "/" ) {
			return array( 'result' => 'eng' );
		}
		
		$parts = split( "/", $complete_url );
		return array( 'result' => $parts[1] );
	}

	function ezfind_search_by_filename( $filename ) {

		$time_start = microtime(true);
		$items = eZDMSMiscTools::ezfind_search_by_filename( $filename );
		$time_end = microtime(true);
		$time = intval( ($time_end - $time_start) * 100 );

		$res = array( 'files' => $items, 'QTime' => $time );
		return array( 'result' => $res );
	}
	function log_items( $contentobject_id, $contentobject_version ) {
	
		$ret = array();
		$list = eZDMSLogItem::fetchHistory( $contentobject_id, $contentobject_version );
		if ( $list ) {
		
			foreach( $list as $item ) {
			
				$timestamp = new eZDateTime( $item->attribute( 'entry_timestamp' ) );

				$user_item = eZUser::fetch( $item->attribute( 'who_id' ) );
				$user_object = $user_item->attribute( 'contentobject' );
				$user_name = $user_object->attribute( 'name' );

				$comment = $item->attribute( 'comment' );

				switch( intval( $item->attribute( 'what_object_state' ) ) ) {
				
					case 0:
						$status = ezpI18n::tr( 'ezdms/Approval', 'waiting' );
					break;
					case 1:
						$status = ezpI18n::tr( 'ezdms/Approval', 'accepted' );
					break;
					case 2:
						$status = ezpI18n::tr( 'ezdms/Approval', 'denied' );
					break;
					case 3:
						$status = ezpI18n::tr( 'ezdms/Approval', 'deferred' );
					break;
					default:
						$status = ezpI18n::tr( 'ezdms/Approval', 'unknown (code='.$item->attribute( 'what_object_state' ).')' );
					break;
				}
				
				$row = array(
					'when'    => $timestamp->toString( true ),
					'who'     => $user_name,
					'status'  => $status,
					'comment' => $comment
					);
				$ret[] = $row;
			}
		}
	
		return array( 'result' => $ret );
	}
}
}
?>
