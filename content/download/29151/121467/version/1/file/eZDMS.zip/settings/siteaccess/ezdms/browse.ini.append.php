<?php /* #?ini charset="utf-8"?

[BrowseSettings]
AliasList[banners]=59

[AddRelatedBannerImageToDataType]
StartNode=banners
SelectionType=single
ReturnType=ObjectID
*/ ?>