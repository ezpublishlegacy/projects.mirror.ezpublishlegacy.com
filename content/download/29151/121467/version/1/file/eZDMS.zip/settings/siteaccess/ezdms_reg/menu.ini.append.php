<?php /* #?ini charset="utf-8"?

[MenuContentSettings]
TopIdentifierList[]
TopIdentifierList[]=folder
TopIdentifierList[]=feedback_form
TopIdentifierList[]=ezdms_folder
LeftIdentifierList[]
LeftIdentifierList[]=folder
LeftIdentifierList[]=feedback_form
LeftIdentifierList[]=ezdms_folder

[TopAdminMenu]
# This list contains menuitems of the top menu in admin interface
Tabs[]
Tabs[]=dashboard
Tabs[]=content
# Tabs[]=users
# Hidden by default as of 4.3
#Tabs[]=shop
# Hidden by default as of 4.3
#Tabs[]=design

# HIERARCHICAL TAGS
[NavigationPart]
Part[ezdmshertagsnavigationpart]=Hierarchical tags

[TopAdminMenu]
Tabs[]=ezdmshertags

[Topmenu_ezdmshertags]
URL[]
URL[default]=ezdmstools/tags_search
NavigationPartIdentifier=ezdmshertagsnavigationpart
Name=Hierarchical tags
Tooltip=Search eZ DMS Files that are in relation with one or more hierarchical tags
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

[Leftmenu_ezdmshertags]
Name=ezdmshertags













# [MenuContentSettings]
# LeftIdentifierList[]=article
# LeftIdentifierList[]=article_mainpage

# USERS eZ DMS
[NavigationPart]
Part[ezdmsusersnavigationpart]=eZ DMS Users

[TopAdminMenu]
Tabs[]=ezdmsusers

[Topmenu_ezdmsusers]
URL[]
URL[default]=content/view/full/3174
NavigationPartIdentifier=ezusernavigationpart
Name=ez DMS Users
Tooltip=Manage the users
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

[Leftmenu_ezdmsusers]
Name=ezdmsusers


# UPLOADS
[NavigationPart]
Part[ezdmsuploadsnavigationpart]=Uploads

[TopAdminMenu]
Tabs[]=ezdmsuploads

[Topmenu_ezdmsuploads]
URL[]
URL[default]=ezdmstools/upload/3173
NavigationPartIdentifier=ezdmsuploadsnavigationpart
Name=Uploads
Tooltip=Uploads attached documents updates
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

[Leftmenu_ezdmsuploads]
Name=ezdmsuploads

# ITEMS TO GET APPROVED

[NavigationPart]
Part[pendingitemsnavigationpart]=Pending items

[TopAdminMenu]
Tabs[]=pending

[Topmenu_pending]
URL[]
URL[default]=content/pendinglist
NavigationPartIdentifier=pendingitemsnavigationpart
Name=Pending items
#Tooltip=Manage the main content structure of the site.
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true


# ITEMS TO APPROVE
[NavigationPart]
Part[approvalsnavigationpart]=Approvals

[TopAdminMenu]
Tabs[]=approvals

[Topmenu_approvals]
URL[]
URL[default]=collaboration/view/summary
NavigationPartIdentifier=approvalsnavigationpart
Name=Items to approve
#Tooltip=Manage the main content structure of the site.
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

# TAG SEARCH
[NavigationPart]
Part[tagsearchnavigationpart]=Tag search

# [TopAdminMenu]
# Tabs[]=tagsearch

[Topmenu_tagsearch]
URL[]
URL[default]=ezdmstools/tags_search
NavigationPartIdentifier=tagsearchnavigationpart
Name=Tag search
# Tooltip=Manage my bookmarks
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true


*/ ?>