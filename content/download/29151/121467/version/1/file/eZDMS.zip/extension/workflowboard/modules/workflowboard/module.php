<?php

  $Module = array (
    'name' => 'workflowboard',
    'variable_params' => true,
  );
  
  $ViewList = array ();
  
  $ViewList['action'] = array (
    'script' => 'action.php',
    'params' => array( 'action', 'param'),
    'functions' => array( 'list', 'view', 'accept', 'remove', 'message' ),
    'ui_context' => 'module',
    'default_navigation_part' => 'workflowboard'
  );
  $ViewList['message'] = array (
    'script' => 'message.php',
    'params' => array('message', 'string' ),
    'functions' => array( 'success', 'error' ),
    'ui_context' => 'module',
    'default_navigation_part' => 'workflowboard'
  );
  $ViewList['list'] = array (
    'script' => 'list.php',
    'params' => array(  ),
    'ui_context' => 'view',
    'functions'=> array('read'),
    'default_navigation_part' => 'workflowboard'
  );
  $ViewList['view'] = array (
    'script' => 'view.php',
    'params' => array( 'process_id' ),
    'ui_context' => 'view',
    'functions'=> array('read'),
    'default_navigation_part' => 'workflowboard'
  );
	$ViewList['remove'] = array (
    'script' => 'remove.php',
    'params' => array('process_id', 'accept' ),
    'ui_context' => 'view',
    'functions'=> array('remove'),
    'default_navigation_part' => 'workflowboard'
  );
	
  $FunctionList = array();
  $FunctionList['read'] = array();
  $FunctionList['remove'] = array();
  $FunctionList['list'] = array();
  $FunctionList['view'] = array();
  $FunctionList['accept'] = array();
  $FunctionList['message'] = array();
  $FunctionList['success'] = array();
  $FunctionList['error'] = array();
?>
