<?php /* #?ini charset="utf-8"?

[StylesheetSettings]
CSSFileList[]

[JavaScriptSettings]
JavaScriptList[]=insertmedia.js
*/ ?>