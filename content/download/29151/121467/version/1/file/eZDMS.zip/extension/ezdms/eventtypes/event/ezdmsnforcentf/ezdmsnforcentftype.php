<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     12 february 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    Each time an eZDMS File is published, 
				a mail is sent to each mail address present in the 
				'force_notification' attribute

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsfiletools.php" );
include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSNForceNtfType extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_STRING = "ezdmsnforcentf";

	protected $title;

    function eZDMSNForceNtfType() {
    
        $this->title = "workflow " . eZDMSNForceNtfType::WORKFLOW_TYPE_STRING;
		$this->eZWorkflowEventType( eZDMSNForceNtfType::WORKFLOW_TYPE_STRING, 
									ezi18n( 'extension/ezdms/event', "eZ DMS New File Forced Notification" ) );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( /* 'before', */
                                                                               'after' ) ) ) );
    }

    function execute( $process, $event ) {
    
    	$cond_debug = 'ezdms-workflow-' . eZDMSNForceNtfType::WORKFLOW_TYPE_STRING;
    	$label_debug = "eZDMSNForceNtfType::execute()";
    
        // get object and objectId
        $parameters = $process->attribute( 'parameter_list' );

		eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $process, true ), 
										$label_debug." process info: " );

        $objectId= $parameters['object_id'];
        // This is the actual object begin edited or created
        $object = eZContentObject::fetch( $parameters['object_id'] );

        if ( !$object ) {
        
            eZDMSDebugTools::writeError( $cond_debug,
										'The object with ID '.$parameters['object_id'].' does not exist.', 
										$label_debug.' object is unavailable' );
            return eZWorkflowType::STATUS_WORKFLOW_CANCELLED;
        }
		eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $object, true ), 
										$label_debug." object: ".$object->attribute( 'name' ) );

        $content_class_id = $object->attribute( 'class_identifier' );
        $content_class_name = $object->attribute( 'class_name' );
		eZDMSDebugTools::writeNotice(	$cond_debug,
										$content_class_name, 
										$label_debug." object's content class" );

		$ez_dms_file = false;
		if ( $content_class_name == "ezdms_file" ) {
			eZDMSFileTools::force_notification( $object->attribute( 'main_node_id' ), true );
		}
		
        return eZWorkflowType::STATUS_ACCEPTED;
    }
    
}

eZWorkflowEventType::registerEventType( eZDMSNForceNtfType::WORKFLOW_TYPE_STRING, "eZDMSNForceNtfType" );

?>
