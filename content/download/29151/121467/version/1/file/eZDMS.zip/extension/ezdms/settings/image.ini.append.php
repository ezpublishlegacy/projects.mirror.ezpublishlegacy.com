<?php /*

[AliasSettings]
AliasList[]=multiuploadthumbnail

[multiuploadthumbnail]
Reference=
Filters[]=geometry/scaledownonly=100;80
*/ ?>