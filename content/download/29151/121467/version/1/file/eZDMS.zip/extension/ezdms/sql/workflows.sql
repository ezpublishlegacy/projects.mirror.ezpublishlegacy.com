INSERT INTO `ezworkflow_group` (`created`, `creator_id`, `id`, `modified`, `modifier_id`, `name`) VALUES
(1279368147, 14, 2, 1279368147, 14, 'eZ DMS');

INSERT INTO `ezworkflow` (`created`, `creator_id`, `id`, `is_enabled`, `modified`, `modifier_id`, `name`, `version`, `workflow_type_string`) VALUES
(1279368169, 14, 1, 1, 1279368195, 14, 'Handles uploaded files by attaching them to their corresponding eZ DMS file', 0, 'group_ezserial'),
(1279368207, 14, 2, 1, 1279369352, 14, 'File update and creation', 0, 'group_ezserial'),
(1279368278, 14, 3, 1, 1279369418, 14, 'New File Forced Notification', 0, 'group_ezserial'),
(1279368322, 14, 4, 1, 1279369361, 14, 'File Update Forced Notification ', 0, 'group_ezserial'),
(1279368343, 14, 5, 1, 1279369370, 14, 'Folder permissions inherited at creation', 0, 'group_ezserial'),
(1279368433, 14, 6, 1, 1279368450, 14, 'Refresh eZ DMS Files permissions from their parent ', 0, 'group_ezserial'),
(1279368501, 14, 7, 1, 1279369426, 14, 'Users locations', 0, 'group_ezserial'),
(1279368535, 14, 8, 1, 1279369408, 14, 'Multiplexer', 0, 'group_ezserial');

INSERT INTO `ezworkflow_event` (`data_int1`, `data_int2`, `data_int3`, `data_int4`, `data_text1`, `data_text2`, `data_text3`, `data_text4`, `data_text5`, `description`, `id`, `placement`, `version`, `workflow_id`, `workflow_type_string`) VALUES
(0, 0, 0, 0, '', '', '', '', '', 'Handles uploaded files by attaching them to their ', 1, 1, 0, 1, 'event_ezdmsfileuploaded'),
(0, 0, 0, 0, '', '', '', '', '', 'File update and creation', 2, 1, 0, 2, 'event_ezdmsfileupdnew'),
(0, 0, 0, 0, '', '', '', '', '', 'New File Forced Notification', 3, 1, 0, 3, 'event_ezdmsnforcentf'),
(0, 0, 0, 0, '', '', '', '', '', 'File Update Forced Notification ', 4, 1, 0, 4, 'event_ezdmsuforcentf'),
(0, 0, 0, 0, '', '', '', '', '', 'Folder permissions inherited at creation', 5, 1, 0, 5, 'event_ezdmsfoldernew'),
(0, 0, 0, 0, '', '', '', '', '', 'Refresh eZ DMS Files permissions from their parent', 6, 1, 0, 6, 'event_ezdmsfolderupd'),
(0, 0, 0, 0, '', '', '', '', '', 'Users locations', 7, 1, 0, 7, 'event_ezdmsuserupdnew'),
(2, 0, 0, 0, '-1', '', '52', '', '', 'File update and creation', 8, 1, 0, 8, 'event_ezmultiplexer'),
(5, 0, 1, 0, '-1', '', '51', '', '', 'Folder permissions inherited at creation', 10, 2, 0, 8, 'event_ezmultiplexer'),
(6, 0, 2, 0, '-1', '', '51', '', '', 'Refresh eZ DMS Files permissions from their parent', 11, 3, 0, 8, 'event_ezmultiplexer'),
(3, 0, 1, 0, '-1', '', '52', '', '', 'New File Forced Notification', 12, 5, 0, 8, 'event_ezmultiplexer'),
(1, 0, 2, 0, '-1', '', '52', '', '', 'Handles uploaded files by attaching them', 13, 4, 0, 8, 'event_ezmultiplexer'),
(7, 0, 0, 0, '-1', '', '48', '', '', 'Users locations', 14, 7, 0, 8, 'event_ezmultiplexer'),
(4, 0, 2, 0, '-1', '', '52', '', '', 'File Update Forced Notification', 15, 6, 0, 8, 'event_ezmultiplexer');

INSERT INTO `ezworkflow_group_link` (`group_id`, `group_name`, `workflow_id`, `workflow_version`) VALUES
(2, 'eZ DMS', 1, 0),
(2, 'eZ DMS', 2, 0),
(2, 'eZ DMS', 3, 0),
(2, 'eZ DMS', 4, 0),
(2, 'eZ DMS', 5, 0),
(2, 'eZ DMS', 6, 0),
(2, 'eZ DMS', 7, 0),
(2, 'eZ DMS', 8, 0);