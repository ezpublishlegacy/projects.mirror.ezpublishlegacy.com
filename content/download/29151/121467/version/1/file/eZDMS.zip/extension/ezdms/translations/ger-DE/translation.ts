<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multi-Upload</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Erfolgreicher Upload der Dateien nach</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Dateien auswählen</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Flash-Content konnte nicht geladen werden. Sie können die neueste Flash-Player-Version downloaden über</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alle Dateien erhalten.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Bildvorschau erstellt.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Starte ...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
