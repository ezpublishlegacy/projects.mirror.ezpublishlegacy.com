<?php /* #?ini charset="utf-8"?

[IconSettings]
Theme=crystal-admin
Size=normal
*/ ?>