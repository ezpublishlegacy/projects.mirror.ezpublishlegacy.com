<?php /* #?ini charset="utf-8"?

[ClassIcons]
ClassMap[]
ClassMap[ezdms_file]=mimetypes/binary.png
ClassMap[ezdms_folder]=filesystems/folder.png
ClassMap[ezdms_her_tag]=filesystems/her_tag.png
ClassMap[folder]=filesystems/folder_man.png
ClassMap[article]=mimetypes/document.png
ClassMap[documentation_page]=mimetypes/txt2.png
ClassMap[user]=apps/personal.png
ClassMap[ezdms_user]=apps/personal.png
ClassMap[user_group]=apps/kuser.png

*/ ?>
