<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezdms_design

*/ ?>
