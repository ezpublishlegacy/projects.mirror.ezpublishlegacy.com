CREATE TABLE IF NOT EXISTS `ezdms_cronjob` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `contentobject_id` int(11) NOT NULL default '0',
  `contentobject_version` int(11) NOT NULL default '0',
  `what_to_do` varchar(255) NOT NULL default 'setup_folder_permissions',
  `class_identifier` varchar(255) NOT NULL default 'ezdms_folder',
  `node_id` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  `added_by` int(11) NOT NULL default '0',
  `timestamp_added` int(11) NOT NULL default '0',
  `handled_by` int(11) NOT NULL default '0',
  `timestamp_handled` int(11) NOT NULL default '0',
  `status` varchar(255) NOT NULL default 'todo',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;


--
-- Table structure for table `ezdms_logitem`
--

DROP TABLE IF EXISTS `ezdms_logitem`;
CREATE TABLE IF NOT EXISTS `ezdms_logitem` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `contentobject_id` int(11) NOT NULL default '0',
  `contentobject_version` int(11) NOT NULL default '0',
  `what_node_id` int(11) default NULL,
  `what_object_id` int(11) default NULL,
  `what_object_version` int(11) default NULL,
  `what_object_state` varchar(100) NOT NULL,
  `what_linked_to_id` int(11) default NULL,
  `who_id` int(11) default NULL,
  `entry_timestamp` int(11) default NULL,
  `comment` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

