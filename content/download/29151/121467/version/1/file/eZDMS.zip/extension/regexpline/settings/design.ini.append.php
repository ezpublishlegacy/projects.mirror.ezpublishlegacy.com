<?php
/*

[ExtensionSettings]
DesignExtensions[]=regexpline

*/
?>
