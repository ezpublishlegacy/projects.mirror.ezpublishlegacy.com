<?php /*

# Create a hidden folder and copy below it's Node ID

[MultiUploadSettings]
AvailableClasses[]
AvailableClasses[]=ezdms_folder
AvailableClasses[]=folder
AvailableClasses[]=gallery

AvailableSubtreeNode[]
AvailableSubtreeNode[]=3173

MultiuploadHandlers[]

[FileTypeSettings_3173]
FileType[]
FileType[]=*.rar
FileType[]=*.txt
FileType[]=*.jpg
FileType[]=*.png
FileType[]=*.gif
FileType[]=*.zip
FileType[]=*.xl?
FileType[]=*.doc
FileType[]=*.docx
FileType[]=*.pdf

[ForceNode]
NodeID=3173

*/ ?>
