<?php /* #?ini charset="utf-8"?

[GeneralSettings]
EnableWebDAV=true
Logging=enabled

[GeneralSettings]
FolderClasses[]=ezdms_folder


[DisplaySettings]
FileAttribute[file]=file
FileAttribute[image]=image
FileAttribute[ezdms_file]=ezdms_file
*/ ?>