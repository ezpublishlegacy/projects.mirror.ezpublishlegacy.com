[CronjobSettings]
ExtensionDirectories[]=ezdms
Scripts[]=cleanup-ezsessions.php
Scripts[]=cyp_debug.php
Scripts[]=ezdmsfilereminders.php
Scripts[]=purge_orphans.php
Scripts[]=ezdmscronjobs.php

[CronjobPart-cleanup-ezsessions]
Scripts[]
Scripts[]=cleanup-ezsessions.php

[CronjobPart-cyp_debug]
Scripts[]
Scripts[]=cyp_debug.php

[CronjobPart-ezdmsfilereminders]
Scripts[]
Scripts[]=ezdmsfilereminders.php

[CronjobPart-ezdmscronjobs]
Scripts[]
Scripts[]=ezdmscronjobs.php

[CronjobPart-purge_orphans]
Scripts[]
Scripts[]=purge_orphans.php
