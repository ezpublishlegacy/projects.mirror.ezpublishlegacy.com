<?php /* #?ini charset="utf-8"?
[HierarchicalTagsTreeMenu]

# dynamic menu is: enabled/disabled
Dynamic=enabled

RootNodeID=65

ShowClasses[]
ShowClasses[]=ezdms_her_tag
ShowClasses[]=folder

# If set to enabled, the JSON documents will be also cached on the server.
UseCache=enabled

# max nodes count to fetch
# "0" means unlimited
MaxNodes=150

# the value is a pair of "type/order".
# for example:  published/ascending,  name/descending, ...
# using "array" notation it's possible to sort by multiple sort 
# criteria:
#    SortBy[]
#    SortBy[]=name/ascending
#    SortBy[]=published/descending
# if set to "false" - default sorting will be implemented
# (which is defined for each node)
SortBy=false

# enabled/disabled
ToolTips=enabled

# url to redirect when clicking on menu item
# if empty then default action(viewing of object) will be performed
# example: /content/browse, /content/view/full, etc.
ItemClickAction=

# Size of icons in menu: small, normal, large, etc.
# Check 'Sizes' setting in icon.ini for available sizes
ClassIconsSize=small

# Controls the pre-loading of class-icons, use
# enabled or disabled. When pre-loading is enabled
# icons of all classes will be loaded before
# menu will be shown. If disabled icons will be loaded
# on demand.
PreloadClassIcons=enabled

# Use enabled or disabled. If enabled then current node
# will be unfolded( children will be shown )
# automatically.
AutoopenCurrentNode=enabled

# Use cookies to remember opened paths and keep then
# open until closed by user.
# If disabled only current path will be opened.
MenuPersistence=enabled

#which classes are chapter
ChapterClasses[]
#ChapterClasses[]=chapter
#ChapterClasses[]=lighttoc

# The "Create here" menu when clicking the node icon in the administrator interface.
#   disabled   - Not having the menu.
#   full       - Having the menu with the necessary permission checks - this will most likely slow down the interface.
#   simplified - Having the menu without the necessary permission checks 
#                (in other words: the menu will include all classes regardless 
#                 if the logged in user is allowed to create all those classes at that exact location). 
#                Some users might get ACCESS DENIED, but it might just work for the most typical/usual cases 
#                (where only one admin or a bunch of admins without limitations are using the interface).
CreateHereMenu=simplified
*/ ?>
