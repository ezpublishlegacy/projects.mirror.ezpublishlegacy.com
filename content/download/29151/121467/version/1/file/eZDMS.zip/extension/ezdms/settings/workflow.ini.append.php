<?php /*

[EventSettings]
ExtensionDirectories[]=ezdms
AvailableEventTypes[]=event_ezdmsfileupdnew
AvailableEventTypes[]=event_ezdmsfoldernew
AvailableEventTypes[]=event_ezdmsfolderupd
AvailableEventTypes[]=event_ezdmsnforcentf
AvailableEventTypes[]=event_ezdmsuforcentf
AvailableEventTypes[]=event_ezdmsuserupdnew
AvailableEventTypes[]=event_ezdmsfileuploaded

*/ ?>

