<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    functions definitions for use in the templating system

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/modules/ezdmstools/";

include( 'extension/ezdms/modules/ezdmstools/ezdmsfunctioncollection.php' );
$FunctionList = array();

$FunctionList['is_doc_locked'] = array( 'name' => 'is_doc_locked',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'is_doc_locked' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( array( 'name' => 'node_id',
                                                                     'type' => 'integer',
                                                                     'required' => true ) ) );

$FunctionList['ug_list'] = array( 'name' => 'ug_list',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'groups_users_list' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array(	array( 'name' => 'node_id',
                                                                     'type' => 'integer',
                                                                     'required' => true ),
	                                                    		array( 'name' => 'ug_sub_node_id',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => 0 ),
	                                                    		array( 'name' => 'attr_base_name',
                                                                     'type' => 'string',
                                                                     'required' => true ),
	                                                    		array( 'name' => 'this_attribute_name',
                                                                     'type' => 'string',
                                                                     'required' => true ),
	                                                    		array( 'name' => 'content_relation_list',
	                                                                 'type' => 'mixed',
	                                                                 'required' => false,
	                                                                 'default' => false ),
																array( 'name' => 'include_users_list',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => 0 ),
																array( 'name' => 'exclude_groups',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => 0 ),
																array( 'name' => 'depth',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => 1 ),
																	  ) );

$FunctionList['session_store'] = array( 'name' => 'session_store',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'session_store' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array(	array( 'name' => 'key',
                                                                     'type' => 'string',
                                                                     'required' => true ),
							  	array( 'name' => 'value',
                                                                     'type' => 'string',
                                                                     'required' => true ),
							  ) );
							  
$FunctionList['get_locker'] = array( 'name' => 'get_locker',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'get_locker' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( array( 'name' => 'node_id',
                                                                     'type' => 'integer',
                                                                     'required' => true ), 
															  array( 'name' => 'as_array',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => false ), 
															  array( 'name' => 'pre_string',
                                                                     'type' => 'string',
                                                                     'required' => false,
																	 'default' => '' ), 
															  ) );

$FunctionList['website_toolbar_accesses'] = array( 'name' => 'user_role',
                                    'operation_types' => array( 'read' ),
                                    'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                            'method' => 'website_toolbar_accesses' ),
                                    'parameter_type' => 'standard',
                                    'parameters' => array( array( 'name' => 'user_id',
                                                                  'type' => 'integer',
                                                                  'required' => true ) ) );

$FunctionList['current_site_access'] = array( 'name' => 'currentSiteAccess',
                                              'operation_types' => array( 'read' ),
                                              'call_method' => array(	'class' => 'eZDMSFunctionCollection',
																		'method' => 'current_site_access' ),
                                              'parameter_type' => 'standard',
                                              'parameters' => array() );

$FunctionList['ezfind_search_by_filename'] = array( 'name' => 'ezfind_search_by_filename',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'ezfind_search_by_filename' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( array( 'name' => 'filename',
                                                                     'type' => 'string',
                                                                     'required' => true ) 
															  ) );
$FunctionList['log_items'] = array( 'name' => 'log_items',
	                                   'operation_types' => array( 'read' ), 
                                       'call_method' => array( 'class' => 'eZDMSFunctionCollection',
                                                               'method' => 'log_items' ),
                                       'parameter_type' => 'standard',
                                       'parameters' => array( array( 'name' => 'contentobject_id',
                                                                     'type' => 'integer',
                                                                     'required' => true ),
															  array( 'name' => 'contentobject_version',
                                                                     'type' => 'integer',
                                                                     'required' => false,
																	 'default' => false ),
															  	) );
?>
