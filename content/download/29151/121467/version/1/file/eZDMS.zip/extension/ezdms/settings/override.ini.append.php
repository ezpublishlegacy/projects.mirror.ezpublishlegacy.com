<?php /* #?ini charset="utf-8"?

[eZDMSGeneralSettings]
superUserID=14


*/ ?>

