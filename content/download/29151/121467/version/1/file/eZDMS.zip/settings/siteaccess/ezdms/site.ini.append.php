<?php /* #?ini charset="utf-8"?

[InformationCollectionSettings]
EmailReceiver=jae@open-net.ch

[SiteSettings]
SiteName=eZ DMS Public Interface
SiteURL=ezdms.com
DefaultPage=content/dashboard
LoginPage=custom

[UserSettings]
RegistrationEmail=

[SiteAccessSettings]
RequireUserLogin=true
ShowHiddenNodes=false

[DesignSettings]
SiteDesign=ezdms_design
AdditionalSiteDesignList[]=admin2

[RegionalSettings]
Locale=eng-GB
ContentObjectLocale=eng-GB
ShowUntranslatedObjects=disabled
SiteLanguageList[]
SiteLanguageList[]=eng-GB
SiteLanguageList[]=fre-FR
TextTranslation=disabled

[FileSettings]
VarDir=var/ezwebin_site

[ContentSettings]
CachedViewPreferences[full]=admin_navigation_content=1;admin_children_viewmode=list;admin_list_limit=1

[MailSettings]
AdminEmail=jae@open-net.ch
EmailSender=

[DebugSettings]
DebugOutput=disabled
DebugRedirection=disabled

[TemplateSettings]
Debug=disabled
ShowXHTMLCode=disabled
ShowUsedTemplates=disabled

[DatabaseSettings]
SQLOutput=disabled

[RoleSettings]
ShowAccessDeniedReason=enabled
*/ ?>