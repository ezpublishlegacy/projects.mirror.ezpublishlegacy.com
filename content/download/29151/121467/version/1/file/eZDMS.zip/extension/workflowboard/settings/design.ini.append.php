<?php /*
#?ini charset="iso-8859-1"?
# eZ publish configuration file for designs

[ExtensionSettings]
DesignExtensions[]=workflowboard

*/ ?>
