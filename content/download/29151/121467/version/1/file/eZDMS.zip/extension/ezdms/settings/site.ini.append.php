<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezdms

[RegionalSettings]
TranslationExtensions[]=ezdms

*/ ?>