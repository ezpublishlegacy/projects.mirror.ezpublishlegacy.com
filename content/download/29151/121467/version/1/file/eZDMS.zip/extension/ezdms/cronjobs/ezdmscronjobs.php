<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     04 february 2009
Last change on: 11 june 2009
Version:        1.0
Extension:		eZDMS
Description:    EZDMSCronjobs objects handler

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsmisctools.php" );
include_once( $baseDir . "ezdmscronjobtools.php" );

$cond_debug = 'ezdms-cron-ezdmscronjobs';
$label_debug = "ezdmscronjobs cron";

$pid = eZDMSMiscTools::build_pid_path( 'ezdms-cronjobs' );
if ( eZDMSMiscTools::getPID( $pid ) ) {
	if ( !$isQuiet )
		$cli->error( "Cannot start the eZDMS Cronjob because an instance is already started" );
		$cli->error( "You can either wait for the process to finish or delete the file '$pid' and restart the cronjob." );

	eZDMSDebugTools::writeNotice(	$cond_debug,
									"    Cannot start the eZDMS Cronjob because an instance is already started", 
									$label_debug );

	exit(1);
}

eZDMSMiscTools::setPID( $pid );
eZDMSDebugTools::writeNotice(	$cond_debug,
								"    The cron eZDMSCronjobs starts", 
								$label_debug );

$ini = eZINI::instance( 'override.ini' );
$userID = $ini->variable( "eZDMSGeneralSettings", "superUserID" );
$current_user_id = eZUser::currentUserID();
$user = eZUser::fetch( $userID );
if ( $user ) {
	$user->loginCurrent();
	eZDMSCronjob::handle_todos();
	$user = eZUser::fetch( $current_user_id );
	$user->loginCurrent();
}
else {
	$err_msg = "Could not login with the super user. Please, check the key 'superUserID' in the section [eZDMSGeneralSettings] from the eZDMS override INI file";
	if ( !$isQuiet )
		$cli->error( $err_msg );

	eZDMSDebugTools::writeError(	$cond_debug,
									$err_msg, 
									$label_debug );
}

eZDMSDebugTools::writeNotice(	$cond_debug,
								"    The cron eZDMSCronjobs stops", 
								$label_debug );
eZDMSMiscTools::delPID( $pid );

?>
