<?php

class C_eZDmsTools {

	static function handle_form( $Module, $http, $objectID ) {
	
	    return eZModule::HOOK_STATUS_CANCEL_RUN;
	}

}

?>
