<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2010 Open-net.ch
				cyp@open-net.ch

Created on:     03 august 2010
Last change on: 
Version:        1.0
Extension:		eZ DMS
Description:    Toolbox based on ezodf's eZOOImport class
				It provides: a method to retrieve the 'body' part of an odt file
History:		

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
//include_once( $baseDir . "ezdmsfoldertools.php" );
//include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSOOTools extends eZOOImport {

	const COND_DEBUG_STRING = 'ezdms-ootools';
	const BASE_DEBUG_LABEL = "eZDMSOOTools::";

	function getContentOf( $odtFilename, $cleanupTempDir = true ) {
	
		$uniqueImportDir = $odtFilename . ".d/";
		eZDir::mkdir( $uniqueImportDir, false, true );
		
		//$http = eZHTTPTool::instance();
		
		$archiveOptions = new ezcArchiveOptions( array( 'readOnly' => true ) );
		$archive = ezcArchive::open( $odtFilename, null, $archiveOptions );
		$archive->extract( $uniqueImportDir );
	
		$fileName = $uniqueImportDir . "content.xml";
		$dom = new DOMDocument( '1.0', 'UTF-8' );
		$success = $dom->load( $fileName );
		$sectionNodeHash = array();
		$xmlTextArray = array();
		
		if ( $success ) {
	
	        // Fetch the automatic document styles
	        $automaticStyleArray = $dom->getElementsByTagNameNS( self::NAMESPACE_OFFICE, 'automatic-styles' );
	        if ( $automaticStyleArray->length == 1 )
	        {
	            $this->AutomaticStyles = $automaticStyleArray->item( 0 )->childNodes;
	        }
	
	        // Fetch the body section content
	        $sectionNodeArray = $dom->getElementsByTagNameNS( self::NAMESPACE_TEXT, 'section' );
	
			foreach ( $sectionNodeArray as $sectionNode ) {
			
	            $sectionName = str_replace( " ", "_", strtolower( $sectionNode->getAttributeNS( self::NAMESPACE_TEXT, 'name' ) ) );
	            $xmlText = "";
	            $level = 1;
	            $childArray = $sectionNode->childNodes;
	            $nodeCount = 1;
	            foreach ( $childArray as $childNode ) {
	            
	                if ( $childNode->nodeType === XML_ELEMENT_NODE ) {
	                
	                    $isLastTag = ( $nodeCount == $childArray->length );
	                    $xmlText .= self::handleNode( $childNode, $level, $isLastTag );
	                }
	
	                $nodeCount++;
	            }
	            $endSectionPart = "";
	            $levelDiff = 1 - $level;
	            if ( $levelDiff < 0 ) {
				
					$endSectionPart = str_repeat( "</section>", abs( $levelDiff ) );
				}

	            $charset = eZTextCodec::internalCharset();
	
	            // Store the original XML for each section, since some datatypes needs to handle the XML specially
	            $sectionNodeHash[$sectionName] = $sectionNode;
	
	            $xmlTextArray[$sectionName] = "<?xml version='1.0' encoding='$charset' ?>" .
	                 "<section xmlns:image='http://ez.no/namespaces/ezpublish3/image/' " .
	                 "  xmlns:xhtml='http://ez.no/namespaces/ezpublish3/xhtml/'><section>" . $xmlText . $endSectionPart . "</section></section>";
	        }
		}
		$dom = false;
		
		if ( $cleanupTempDir ) {
		
			$this->deltree(  $odtFilename . ".d" );
		}

		return $xmlTextArray;	
	}
	
	function updateDataMap( &$dataMap, $odtFilename ) {
	
		$xmlTextArray = $this->getContentOf( $odtFilename );
		$count = 0;
		foreach( $dataMap as $attributeIdentifier => $attributeValue ) {
		
			if ( isset( $xmlTextArray[ $attributeIdentifier ] ) ) {
			
                switch( $dataMap[$attributeIdentifier]->DataTypeString )
                {
                    case "ezstring":
                    case "eztext":
                    {
                    	$count += 1;
                        $eztextDom = new DOMDOcument( '1.0', 'UTF-8' );
                        $eztextDom->loadXML( $xmlTextArray[$attributeIdentifier] );
                        $text = $eztextDom->documentElement->textContent;
                        $dataMap[$attributeIdentifier]->setAttribute( 'data_text', trim( $text ) );
                        $dataMap[$attributeIdentifier]->store();
                    }break;

                    case "ezxmltext":
                    {
                    	$count += 1;
                        $dataMap[$attributeIdentifier]->setAttribute( 'data_text', $xmlTextArray[$attributeIdentifier] );
                        $dataMap[$attributeIdentifier]->store();
                    }break;


                    case "ezdate":
                    {
                        // Only support date formats as a single paragraph in a section with the format:
                        // day/month/year
                        $dateString = strip_tags( $xmlTextArray[$attributeIdentifier] );

                        $dateArray = explode( "/", $dateString );

                        if ( count( $dateArray ) == 3 )
                        {
		                    	$count += 1;
                                $year = $dateArray[2];
                                $month = $dateArray[1];
                                $day = $dateArray[0];

                                $date = new eZDate();

                                $contentClassAttribute = $dataMap[$attributeIdentifier];

                                $date->setMDY( $month, $day, $year );
                                $dataMap[$attributeIdentifier]->setAttribute( 'data_int', $date->timeStamp()  );
                                $dataMap[$attributeIdentifier]->store();
                        }
                    }break;

                    case "ezdatetime":
                    {
                        // Only support date formats as a single paragraph in a section with the format:
                        // day/month/year 14:00
                        $dateString = trim( strip_tags( $xmlTextArray[$attributeIdentifier] ) );

                        $dateTimeArray = explode(  " ", $dateString );

                        $dateArray = explode( "/", $dateTimeArray[0] );
                        $timeArray = explode( ":", $dateTimeArray[1] );

                        if ( count( $dateArray ) == 3 and count( $timeArray ) == 2 )
                        {
	                    	$count += 1;
                            $year = $dateArray[2];
                            $month = $dateArray[1];
                            $day = $dateArray[0];

                            $hour = $timeArray[0];
                            $minute = $timeArray[1];

                            $dateTime = new eZDateTime();

                            $contentClassAttribute = $dataMap[$attributeIdentifier];

                            $dateTime->setMDYHMS( $month, $day, $year, $hour, $minute, 0 );
                            $dataMap[$attributeIdentifier]->setAttribute( 'data_int', $dateTime->timeStamp()  );
                            $dataMap[$attributeIdentifier]->store();
                        }
                    }break;

                    case "ezimage":
                    {
                        $hasImage = false;

                        // Images are treated as an image object inside a paragrah.
                        // We fetch the first image object if there are multiple and ignore the rest
                        if ( is_object( $sectionNodeHash[$attributeIdentifier] ) )
                        {
                            // Look for paragraphs in the section
                            foreach ( $sectionNodeHash[$attributeIdentifier]->childNodes as $paragraph )
                            {
                                if( !$paragraph->hasChildNodes() ) 
                                {
                                    continue;
                                }
                                // Look for frame node
                                foreach ( $paragraph->childNodes as $frame )
                                {
                                    // finally look for the image node
                                    $children = $frame->childNodes;

                                    $imageNode = $children->item( 0 );
                                    if ( $imageNode && $imageNode->localName == "image" )
                                    {
                                        $fileName = ltrim( $imageNode->getAttributeNS( self::NAMESPACE_XLINK, 'href' ), '#' );
                                        $filePath = $this->ImportDir . $fileName;

                                        if ( file_exists( $filePath ) )
                                        {
					                    	$count += 1;
                                            $imageContent = $dataMap[$attributeIdentifier]->attribute( 'content' );
                                            $imageContent->initializeFromFile( $filePath, false, basename( $filePath ) );
                                            $imageContent->store( $dataMap[$attributeIdentifier] );
                                            $dataMap[$attributeIdentifier]->store();
                                        }

                                        $hasImage = true;
                                    }
                                }
                            }
                        }

                        if ( !$hasImage )
                        {
                            $imageHandler = $dataMap[$attributeIdentifier]->attribute( 'content' );
                            if ( $imageHandler )
                                $imageHandler->removeAliases( $dataMap[$attributeIdentifier] );
                        }

                    }break;

                    case "ezmatrix":
                    {
                        $matrixHeaderArray = array();
                        // Fetch the current defined columns in the matrix
                        $matrix = $dataMap[$attributeIdentifier]->content();
                        $columns = $matrix->attribute( "columns" );

                        foreach ( $columns['sequential'] as $column )
                        {
                            $matrixHeaderArray[] = $column['name'];
                        }

                        $headersValid = true;
                        $originalHeaderCount = count( $matrixHeaderArray );
                        $headerCount = 0;
                        $rowCount = 0;
                        $cellArray = array();
                        // A matrix is supported as a table inside sections. If multiple tables are present we take the first.
                        if ( is_object( $sectionNodeHash[$attributeIdentifier] ) )
                        {
                            // Look for paragraphs in the section
                            foreach ( $sectionNodeHash[$attributeIdentifier]->childNodes as $table )
                            {
                                if ( $table->localName == "table" )
                                {
                                    // Loop the rows in the table
                                    foreach ( $table->childNodes as $row )
                                    {
                                        // Check the headers and compare with the defined matrix
                                        if ( $row->localName == "table-header-rows" )
                                        {
                                            $rowArray = $row->childNodes;
                                            if ( $rowArray->length == 1  )
                                            {
                                                foreach ( $rowArray->item( 0 )->childNodes as $headerCell )
                                                {
                                                    if ( $headerCell->localName == "table-cell" )
                                                    {
                                                        $paragraphArray = $headerCell->childNodes;

                                                        if ( $paragraphArray->length == 1 )
                                                        {
                                                            $headerName = $paragraphArray->item( 0 )->textContent;
                                                            if ( $matrixHeaderArray[$headerCount] != $headerName )
                                                            {
                                                                $headersValid = false;
                                                            }
                                                            $headerCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // Check the rows
                                        if ( $row->localName == "table-row" )
                                        {
                                            foreach ( $row->childNodes as $cell )
                                            {
                                                if ( $cell->childNodes->length >= 1 )
                                                {
                                                    $firstParagraph = $cell->childNodes->item( 0 );
                                                    $cellArray[] = $firstParagraph->textContent;
                                                }
                                            }
                                            $rowCount++;
                                        }
                                    }
                                }
                            }
                        }

                        if ( $headerCount == $originalHeaderCount and
                             $headersValid == true )
                        {
                            // Remove all existing rows
                            for ( $i=0; $i < $matrix->attribute( "rowCount" ); $i++ )
                            {
                                $matrix->removeRow( $i );
                            }

                            // Insert new rows
                            $matrix->addRow( false, $rowCount );
                            $matrix->Cells = $cellArray;

	                    	$count += 1;
                            $dataMap[$attributeIdentifier]->setAttribute( 'data_text', $matrix->xmlString() );

                            $matrix->decodeXML( $dataMap[$attributeIdentifier]->attribute( 'data_text' ) );
                            $dataMap[$attributeIdentifier]->setContent( $matrix );
                            $dataMap[$attributeIdentifier]->store();
                        }

                    }break;

                    default:
                    {
                        eZDebug::writeError( "Unsupported datatype for OpenOffice.org import: " . $dataMap[$attributeIdentifier]->DataTypeString );
                    }break;
                }

			}
		}
		
		return $count;
	}
	
	function deltree($path) {
	
		if (is_dir($path)) {

			if (version_compare(PHP_VERSION, '5.0.0') < 0) {
			
				$entries = array();
				if ($handle = opendir($path)) {
			
					while (false !== ($file = readdir($handle))) $entries[] = $file;
					closedir($handle);
				}
			}
			else {
				$entries = scandir($path);
				if ($entries === false) $entries = array(); // just in case scandir fail...
			}
			foreach ($entries as $entry) {
				if ($entry != '.' && $entry != '..') {

					$this->deltree($path.'/'.$entry);
				}
			}
			return rmdir($path);
		}
		else {
			return unlink($path);
		}
	}

}
