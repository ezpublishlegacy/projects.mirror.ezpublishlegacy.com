<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=regexpline
AvailableDataTypes[]=hmregexpline


*/
?>
