<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    test module.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
/*
include_once "/var/www/move/extension/eztreeselection/classes/ezcomponents/Tree/src/options/visitor_yui_treeview.php";
include_once "/var/www/move/extension/eztreeselection/classes/ezcomponents/Tree/src/visitors/yui_treeview.php";
*/

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

//include_once( $baseDir . "ezdmsfiletools.php" );

$Module =& $Params['Module'];
$http = eZHTTPTool::instance();

$doc_id = $Params['DocumentID'];
/*
$node_id = 0;
$the_nodes = eZContentObjectTreeNode::fetchByContentObjectID( $doc_id );
if ( count( $the_nodes ) ) {
	$the_node = $the_nodes[0];
	$node_id = $the_node->attribute( 'node_id' );
}

$return_path="";
if ( $http->hasPostVariable( 'return_path' ) ) {
	$return_path=$http->postVariable( 'return_path' );
}

if ( $node_id && $http->hasPostVariable( 'lock_it' ) ) {
	eZDMSFileTools::lock_it( $node_id );
	$http->redirect( $return_path );
}

if ( $node_id && $http->hasPostVariable( 'unlock_it' ) ) {
	eZDMSFileTools::unlock_it( $node_id );
	$http->redirect( $return_path );
}
*/

$store = new ezcTreeXmlInternalDataStore();
$tree = ezcTreeMemoryXml::create( '', $store );


$rootNode = $tree->createNode( 'Elements', 'Elements' );
$tree->setRootNode( $rootNode );

$nonMetal = $tree->createNode( 'NonMetals', 'Non-Metals' );
$rootNode->addChild( $nonMetal );
$nobleGasses = $tree->createNode( 'NobleGasses', 'Noble Gasses' );
$rootNode->addChild( $nobleGasses );

$nonMetal->addChild( $tree->createNode( 'H', 'Hydrogen' ) );
$nonMetal->addChild( $tree->createNode( 'C', 'Carbon' ) );
$nonMetal->addChild( $tree->createNode( 'N', 'Nitrogen' ) );
$nonMetal->addChild( $tree->createNode( 'O', 'Oxygen' ) );
$nonMetal->addChild( $tree->createNode( 'P', 'Phosphorus' ) );
$nonMetal->addChild( $tree->createNode( 'S', 'Sulfur' ) );
$nonMetal->addChild( $tree->createNode( 'Se', 'Selenium' ) );

$miscGases = $tree->createNode( 'Hallogens', 'Hallogen Gases' );
$nonMetal->addChild( $miscGases );
$miscGases->addChild( $tree->createNode( 'Fr', 'Freon' ) );
$miscGases->addChild( $tree->createNode( 'Ne', 'Neon' ) );


$nobleGasses->addChild( $tree->createNode( 'F', 'Fluorine' ) );
$nobleGasses->addChild( $tree->createNode( 'Cl', 'Chlorine' ) );
$nobleGasses->addChild( $tree->createNode( 'Br', 'Bromine' ) );
$nobleGasses->addChild( $tree->createNode( 'I', 'Iodine' ) ); 

$res = $tree->getRootNode()->id; 

$viewOptions = new ezcTreeVisitorYUITreeViewOptions( array( 'displayRootNode' => false,
                                                            'yuiNodeClass' => 'CheckBoxNode',
                                                            'treeSelection' => ezcTreeVisitorDynYUITreeView::SELECTABLE_TREE,
                                                            'checkElementPrefix' => 'options',
                                                            'tree' => $tree ) );                
$visitor = new ezcTreeVisitorDynYUITreeView( 'tree', $viewOptions );
$tree->accept( $visitor );
/*
$res .= '
<script src = "http://yui.yahooapis.com/2.5.2/build/yahoo/yahoo-min.js" ></script>
<script src = "http://yui.yahooapis.com/2.5.2/build/event/event-min.js" ></script>
<script src = "http://yui.yahooapis.com/2.5.2/build/treeview/treeview-min.js" ></script>
<script src = "http://localhost/rba_pc_actual/extension/eztreeselection/design/standard/javascript/eztreeselection.js" ></script>
<script type="text/javascript">
';
*/
/*
$res .= '
<script src = "http://yui.yahooapis.com/2.5.2/build/yahoo/yahoo-min.js" ></script>
<script src = "http://yui.yahooapis.com/2.5.2/build/event/event-min.js" ></script>
<script src = "http://yui.yahooapis.com/2.5.2/build/treeview/treeview-min.js" ></script>
<script type="text/javascript">
';
*/

$ezjscINI = eZINI::instance('design.ini');
$l = $ezjscINI->variable('JavaScriptSettings', 'JavaScriptList');
$res = ezjscPacker::buildJavascriptTag( );

$res .="

<div id='treeView'>".print_r($l,true)."</div>
<link type='text/css' rel='stylesheet' href='http://yui.yahooapis.com/gallery-2010.02.17-20/build/gallery-treeview/assets/skins/sam/gallery-treeview.css' />
<script type='text/javascript'
     src='http://yui.yahooapis.com/combo?3.0.0/build/yui/yui-min.js&gallery-2009.11.02-20/build/gallery-port/gallery-port-min.js&gallery-2009.11.19-20/build/gallery-treeview/gallery-treeview-min.js'>
</script>
<script language='javascript'>

//Create a YUI instance that uses the treeview gallery module
YUI().use('gallery-treeview', function(Y) {

//Associate the YAHOO variable with and instance of Dav Glass's
//Port utility:
var YAHOO = Y.Port();

//Instantiate the Tree using standard YUI 2 syntax:
var tree = new YAHOO.widget.TreeView('treeView', [
	{type:'Text', label:'Cars',expanded:true, checkbox:true, children:[
			'Aston Martin',
			'Bugatti',
			{type: 'Text', label:'GM', href:'http://gm.com', expanded:false, children:[
				'Buick',
				'Cadillac',
				'Chevrolet',
				'GMC'
			]},
			'Renault',
			'Toyota',
			'Volkswagon'
		]
	},
	{type:'Text', label:'Computers', editable:true, children: [
			'Acer',
			'Apple',
			'HP',
			'Dell'
		]
	}
]);

// Render the tree:
tree.render();

});
";
$res .= (string) $visitor; // print the javascript    
$res .= "
</script>
";
$site_access = '/' . join( '/', array_slice( explode( '/', $_SERVER['REQUEST_URI'] ), 2 ) );
//$res .= '</script>
$res .='
<h2>'.$_SERVER['REQUEST_URI'].'</h2>
<form action="' .  $site_access;

$res .= '" method="post">
	<div id="tree"></div>
	<input type="submit" value="submit"/>
</form>
<ul>
<li>Result:</li>
<ul>' . $_SESSION['onsmsg'] . '</ul>
</ul>
';

$res .= '<pre>'; 
$res .= print_r( $_POST, true );
$res .= '</pre>';

$tpl = templateInit();
$tpl->setVariable( 'the_message', $res );

$Result = array();
$Result['content'] = $tpl->fetch( "design:ezdms/test.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'ezdms', 'Test Page' ) ) );

?>
