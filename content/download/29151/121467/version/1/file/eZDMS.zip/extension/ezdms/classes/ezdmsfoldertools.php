<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch
				cyp@open-net.ch

Created on:     18 january 2009
Last change on: 29 april 2010 / Cyp
Version:        1.2
Extension:		eZ DMS
Description:    Tools for eZ DMS Folders management
History:		change in setup_folder_permissions( ):
					does not use anymore the 'admin' login
					returns true if everything ran ok

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsfiletools.php" );

class eZDMSFolderTools
{
	/*
		Sets the permissions of an eZDMS folder by inheriting 
		its parent folder's permissions

	*/
	static public function inherit_permissions( $node_id ) {

    	$cond_debug = 'ezdms-workflow-ezdmsfoldernew';
    	$label_debug = "eZDMSFolderTools::inherit_permissions()";
    
		$ez_dms_folder_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( $ez_dms_folder_node->attribute( 'class_identifier' ) != 'ezdms_folder' ) {

			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Invalid class identifier. Got: ".$ez_dms_folder_node->attribute( 'class_identifier' ) . " for the node $ez_dms_folder_node_id", 
											$label_debug );

			return false;
		}
		
		$base_role_name = "eZ DMS Folder ";

		$parent_role_name = $base_role_name . $ez_dms_folder_node->attribute( 'parent_node_id' );
		$parent_role = eZRole::fetchByName( $parent_role_name );
	
		// Before creating a new role, let's remove the old one if it exists
		$role_name = $base_role_name . $node_id;
		$role = eZRole::fetchByName( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->removePolicies();
			$role->remove();
		}
	
		$db = eZDB::instance();
		$db->begin();
		$role = eZRole::create( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->store();
		}
		$db->commit();
		$role = eZRole::fetchByName( $role_name );
		$parent_role->copyPolicies( $role->attribute( 'id' ) );

		eZDMSDebugTools::writeWarning(	$cond_debug,
										"Job done: permissions inherited", 
										$label_debug );

		eZContentCacheManager::clearAllContentCache();
	}
	
	/*
		Sets the permissions of an eZDMS folder from its attributes

	*/
	static public function setup_folder_permissions( $node_id, $opt_ez_dms_file_node_id = 0 ) {

    	$cond_debug = false;	//'eZDMSFolderTools';
    	$label_debug = "eZDMSFolderTools::setup_folder_permissions()";
    
		$ez_dms_folder_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_folder_node ) ) {

			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Invalid node identifier ($ez_dms_folder_node_id)", 
											$label_debug );

			return false;
		}
		if ( $ez_dms_folder_node->attribute( 'class_identifier' ) != 'ezdms_folder' ) {

			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Invalid class identifier. Got: ".$ez_dms_folder_node->attribute( 'class_identifier' ) . " for the node $ez_dms_folder_node_id", 
											$label_debug );

			return false;
		}
		
		$base_role_name = "eZ DMS Folder ";
		$role_name = $base_role_name . $node_id;

		// Before creating a new role, let's remove the old one if it exists
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"About to setup the role and policies for the node $node_id, under the labels '$role_name [...]'", 
										$label_debug );

    	$ez_dms_folder_object = $ez_dms_folder_node->attribute( 'object' );
    	if ( !is_object( $ez_dms_folder_object ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Can't read object from node, id=$node_id", 
											$label_debug );
											
			return false;
    	}
   		$ez_dms_folder_dm = $ez_dms_folder_object->attribute( 'data_map' );
		
		// Setup the 'Class' policies limitations
		$ezdms_file_class = eZContentClass::fetchByIdentifier( 'ezdms_file' );
		$class_limitations = array(	$ez_dms_folder_object->attribute( 'contentclass_id' ), 
									$ezdms_file_class->attribute( 'id' ), 
									);
									
		// Setup the 'Node' policies limitations
		$nodes_limitations = array(	'read_perms' => array( $node_id ),
									'edit_perms' => array( $node_id ),
									'admin_perms' => array( $node_id ),
								  );
		eZContentCacheManager::clearAllContentCache();
		$sub_node_tree = eZContentObjectTreeNode::subTreeByNodeID(	array(	'ClassFilterType' => 'include', 
																			'ClassFilterArray' => array( 'ezdms_file' ),
																			'DepthOperator' => 'eq',
																			'Depth' => 1,
																		 ),
																	$node_id );
		$locked_nodes = array();
		foreach( $sub_node_tree as $sub_node ) {
			$this_node_id = $sub_node->attribute( 'node_id' );
			$nodes_limitations['read_perms'][] = $this_node_id;
			if ( !eZDMSFileTools::is_locked( $this_node_id ) ) {
				$nodes_limitations['edit_perms'][] = $this_node_id;
			}
			else {
				$locked_nodes[] = $this_node_id;
			}
			$nodes_limitations['admin_perms'][] = $this_node_id;
		}
		if ( $opt_ez_dms_file_node_id ) {
			if ( !eZDMSFileTools::is_locked( $opt_ez_dms_file_node_id ) ) {
				$nodes_limitations['edit_perms'][] = $opt_ez_dms_file_node_id;
			}
			else {
				$locked_nodes[] = $opt_ez_dms_file_node_id;
			}
		}

		// Setup the policies parameters
		$policies_definitions = array(	'read_perms' => array( 'read' ),
										'edit_perms' => array( 'read', 'edit', 'remove', 'create', 'versionread' ),
										'admin_perms' => array( 'read', 'edit', 'remove', 'create', 'versionread' ),
									 );
		
		// Now, let's setup each role and their corresponding policies, one for each [...perms] attribute
		foreach( $policies_definitions as $allowed_group_name => $functions ) {
		
			// Setup the corresponding role
			$full_role_name = $role_name ." [".$allowed_group_name."]";
			$role = eZRole::fetchByName( $full_role_name );
			if ( $role ) {
				$role->turnOffCaching();
				$role->removePolicies();
				$role->remove();
			}
		
			$db = eZDB::instance();
			$db->begin();
			$role = eZRole::create( $full_role_name );
			if ( $role ) {
				$role->turnOffCaching();
				$role->store();
			}
			$db->commit();
			$role = eZRole::fetchByName( $full_role_name );

			eZDMSDebugTools::writeNotice(	$cond_debug,
											"About to add the following policies to the role '$full_role_name':\n".
												"content functions: ".print_r( $functions, true ).
												"classes: ".print_r( $class_limitations, true ).
												"Node-type for: ".print_r( $nodes_limitations[ $allowed_group_name ], true ),
											$label_debug );
			
			// For this role, setup the corresponding policies
			foreach( $functions as $function ) {
				$policy = $role->appendPolicy(	'content', 
												$function, 
												array(	'Class' => $class_limitations,
														'Node' => $nodes_limitations[ $allowed_group_name ],
													 )
											  );
				if( $policy ) {
					$policy->store();
				}
			}

			// Assign this new role to each member of the corresponding attribute
			if ( isset( $ez_dms_folder_dm[ $allowed_group_name ] ) ) {
				$allowed_groups = $ez_dms_folder_dm[ $allowed_group_name ]->content();
				if ( $allowed_groups ) {
					$obj_rel_list = $allowed_groups[ 'relation_list' ];
					foreach( $obj_rel_list as $allowed_group ) {
						$us = eZContentObject::fetchByNodeID( $allowed_group[ 'node_id' ] );
						if ( is_object( $us ) ) {
							$id = $us->attribute( 'id' );
							if( $role->assignToUser( $id ) ) {
								eZCache::clearByTag( 'content' );
							}
						}
					}
				}
			}
		}
		
		// Add to the read policy the read access to the users groups and ez dms users list from the [read_perms] attributes
		$allowed_group_name = 'read_perms';
		$full_role_name = $role_name ." [".$allowed_group_name."]";
		$role = eZRole::fetchByName( $full_role_name );
		if ( $role ) {
		
			if ( isset( $ez_dms_folder_dm[ $allowed_group_name ] ) ) {
				$allowed_groups = $ez_dms_folder_dm[ $allowed_group_name ]->content();
				if ( $allowed_groups ) {
				
					$classes_list = array();
					foreach(  array( 'user_group', 'ezdms_user' ) as $class_identifier ) {
						$class = eZContentClass::fetchByIdentifier( $class_identifier );
						if ( is_object( $class ) ) {
							$classes_list[] = $class->attribute( 'id' );
						}
					}

					$obj_rel_list = $allowed_groups[ 'relation_list' ];
					$subtree_items = array();
					foreach( $obj_rel_list as $allowed_group ) {
						$ug_node = eZContentObjectTreeNode::fetch( $allowed_group[ 'node_id' ] );
						if ( is_object( $ug_node ) ) {
							$subtree_items[] = $ug_node->attribute( 'node_id' );
							$subtree_items[] = $ug_node->attribute( 'path_string' );
						}
					}
					
					eZDMSDebugTools::writeNotice(	$cond_debug,
													"About to add the following complementary policies to the role '$full_role_name':\n".
														"content: read\nclasses: ".print_r( $classes_list, true ).
														"subtree-type for: ".print_r( $subtree_items, true ), 
													$label_debug );

					$policy = $role->appendPolicy(	'content', 
													'read', 
													array(	'Class' => $classes_list,
															'Subtree' => $subtree_items,
														 )
												  );
					if( $policy ) {
						$policy->store();
						eZCache::clearByTag( 'content' );
					}
				}
			}
		}

		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Job done: permissions set for the node $node_id.", 
										$label_debug );

		eZContentCacheManager::clearAllContentCache();
		/* Clean up policy cache */
		eZUser::cleanupCache();
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Content and Policy Caches cleared.", 
										$label_debug );

		return true;
	}
	
	static public function files_inherit_permissions( $ez_dms_folder_node_id, $force_locked_files = false ) {
	
    	$cond_debug = 'ezdms-workflow-ezdmsfoldernew';
    	$label_debug = "eZDMSFolderTools::files_inherit_permissions(): resetting the ez DMS File permissions for the node $ez_dms_folder_node_id";
    
		$ez_dms_folder_node = eZContentObjectTreeNode::fetch( $ez_dms_folder_node_id );
		if ( !$ez_dms_folder_node ) {

			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Could not find the node that corresponds to " . $ez_dms_folder_node_id, 
											$label_debug );

			return -1;
		}
		if ( $ez_dms_folder_node->attribute( 'class_identifier' ) != 'ezdms_folder' ) {

			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Invalid class identifier. Got: ".$ez_dms_folder_node->attribute( 'class_identifier' ) . " for the node $ez_dms_folder_node_id", 
											$label_debug );

			return -2;
		}
		
		$params = array(	'ClassFilterType' => 'include', 
							'ClassFilterArray' => array( 'ezdms_file' ),
						);
		$children = $ez_dms_folder_node->subTree( $params );
		
		$list_ok = array();
		$list_locked = array();
		foreach( $children as $ezdms_file ) {
			$node_id = $ezdms_file->attribute( 'node_id' );
			if( !eZDMSFileTools::is_locked( $node_id ) ) {
	
				eZDMSFileTools::inherit_permissions( $node_id );
				$list_ok[] = $node_id;
			}
			else {
				$list_locked[] = $node_id;
			}
		}
		$sep = "\n  ";
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Nodes handled correctly:$sep".
											implode( $sep, $list_ok ).
										"\nNodes skipped because they are locked:$sep".
											implode( $sep, $list_locked ), 
										$label_debug );

		return $count;
	}
	
	static public function setup_other_locations( $node_id, $locations = false ) {
    	$cond_debug = false;	//'ezdms-workflow-setup-other-locations';
    	$label_debug = "eZDMSFolderTools::setup_other_locations()";
    	
		$user = eZUser::fetch( eZUser::currentUserID() );
		$user_name = $user->attribute( 'login' );

		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Entering the function with node id $node_id, locations: ".print_r($locations, true)." and user: $user_name",
										$label_debug );

		$ez_dms_folder_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_folder_node ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Node couldn't be loaded from id $node_id" ,
											$label_debug );
			return 1;
		}
		if ( $ez_dms_folder_node->attribute( 'class_identifier' ) != 'ezdms_folder' ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Wrong class: ".$ez_dms_folder_node->attribute( 'class_identifier' )." for the node id $node_id" ,
											$label_debug );
			return 2;
		}
		$ez_dms_folder_object = $ez_dms_folder_node->attribute( 'object' );
		if ( !is_object( $ez_dms_folder_object ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Object couldn't be loaded from the node id $node_id" ,
											$label_debug );
			return 3;
		}
		$object_id = $ez_dms_folder_object->attribute( 'id' );
		$ez_dms_folder_dm = $ez_dms_folder_object->attribute( 'data_map' );
		if ( !is_array( $ez_dms_folder_dm ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Data map couldn't be loaded for the object of the node id $node_id" ,
											$label_debug );
			return 4;
		}
		if ( !$ez_dms_folder_object->checkAccess( 'edit' ) &&
			 !$user->hasManageLocations() ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"User $user_name is not allowed to manage locations for the node $node_id" ,
											$label_debug );
			return 5;
		}
		$class = $ez_dms_folder_object->contentClass();
		foreach( $locations as $parentNodeID ) {

			$parentNode = eZContentObjectTreeNode::fetch( $parentNodeID );
			if ( !$parentNode ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to read the location $node_id" ,
												$label_debug );
				return 6;
			}

			$parentNodeObject = $parentNode->attribute( 'object' );
			if ( !$parentNode ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to read the object that corresponds to the node $node_id" ,
												$label_debug );
				return 7;
			}

	        $canCreate = ( ( $parentNode->checkAccess( 'create', $class->attribute( 'id' ), $parentNodeObject->attribute( 'contentclass_id' ) ) == 1 ) ||
	                        ( $parentNode->canAddLocation() && $ez_dms_folder_node->canRead() ) );
			if ( !$canCreate ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to create such objects: '".$class->attribute( 'name' )."' for the node $node_id into the node $parentNodeID" ,
												$label_debug );
				return 8;
			}
	    }
		
		// We have to retrieve all non-main locations of the node
		$removeList = array();
		$hasChildren = false;
		foreach( $ez_dms_folder_object->attribute( 'assigned_nodes' ) as $assigned_node ) {

			if ( $assigned_node->attribute( 'is_main' ) ) {
				continue;
			}

            // Security checks, removal of current node is not allowed
            // and we require removal rights
            if ( !$assigned_node->canRemove() &&
                 !$assigned_node->canRemoveLocation() ) {
                 
				eZDMSDebugTools::writeWarning(	$cond_debug,
												"User $user_name is not allowed to remove assigned node ". $assigned_node->attribute( 'node_id' ) ." from the node $node_id" ,
												$label_debug );
                continue;
            }

            $removeList[$assigned_node->attribute( 'node_id' )] = 1;
            $count = $assigned_node->childrenCount( false );

            if ( $count > 0 )
            {
                $hasChildren = true;
            }
		}
		
		if ( $hasDhildren ) {
			eZDMSDebugTools::writeError(	$cond_debug,
											"Operation canceled because some of the assigned nodes of the node $node_id may have children" ,
											$label_debug );
			return 6;
		}
		
        if ( eZOperationHandler::operationIsAvailable( 'content_removelocation' ) )
        {
            $operationResult = eZOperationHandler::execute( 'content',
                                                            'removelocation', array( 'node_list' => array_keys( $removeList ) ),
                                                            null,
                                                            true );
        }
        else
        {
        	$db = eZDB::instance();
        	$db->begin();
        	foreach( $removeList as $removeItem => $value ) {
				eZContentObjectTreeNode::removeNode( $removeItem );
			}
			$db->commit();
        }
		
		// Then, let's try to add the specified locations
		if ( !$locations ) {
			$locations = array();
		}
			
        if ( eZOperationHandler::operationIsAvailable( 'content_addlocation' ) )
        {
			eZDMSDebugTools::writeNotice(	$cond_debug,
											"Adding the locations through eZOperationHandler::execute()",
											$label_debug );
            $operationResult = eZOperationHandler::execute( 'content',
                                                            'addlocation', array( 'node_id'              => $node_id,
                                                                                  'object_id'            => $object_id,
                                                                                  'select_node_id_array' => $locations ),
                                                            null,
                                                            true );
        }
        else
        {
			eZDMSDebugTools::writeNotice(	$cond_debug,
											"Adding the locations through eZContentOperationCollection::addAssignment()",
											$label_debug );
            eZContentOperationCollection::addAssignment( $node_id, $object_id, $locations );
        }
        
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Resulting assignements for the node id $node_id: ".print_r( $ez_dms_folder_object->attribute( 'assigned_nodes' ), true ) ,
										$label_debug );

		return 0;
	}
}

?>
