<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     04 february 2009
Last change on: 18 april 2009
Version:        1.1
Extension:		eZDMS
Description:    This is an automatic reminder for eZ DMS Files

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/";

include_once( $baseDir . "classes/ezdmsdebugtools.php" );
include_once( $baseDir . "classes/ezdmsfoldertools.php" );
include_once( $baseDir . "modules/ezdmstools/ezdmsfunctioncollection.php" );

$status_list = array( 0 => 'really_too_late', 1 => 'too_late', 2 => 'beware' );
$remindersINI = eZINI::instance( 'reminders.ini' );
	$from_name = $remindersINI->variable( 'eZDMSFileReminders', 'fromName' );
	$from_mail = $remindersINI->variable( 'eZDMSFileReminders', 'fromMail' );
	
	$reminders = array();
	$reminders['header'] = str_replace( "\\n", "\n", $remindersINI->variable( 'eZDMSFileReminders', 'reminder_header' ) );
	$reminders['footer'] = str_replace( "\\n", "\n", $remindersINI->variable( 'eZDMSFileReminders', 'reminder_footer' ) );
	$reminders['root_url'] = str_replace( "\\n", "\n", $remindersINI->variable( 'eZDMSFileReminders', 'reminder_site_root_url' ) );
	$reminders['subject'] = $remindersINI->variable( 'eZDMSFileReminders', 'reminder_subject' );
	foreach( $status_list as $status ) {
		foreach( array( '_header', '_line' ) as $item ) {
			$row = $status . $item;
			$reminders[ $row ] = str_replace( "\\n", "\n", $remindersINI->variable( 'eZDMSFileReminders', $row ) );
		}
	}

$cond_debug = 'ezdms-cron-ezfilereminders';
$label_debug = "ezfilereminders cron";

$now = time();

eZDMSDebugTools::writeNotice(	$cond_debug,
								"    eZ File Reminders starts", 
								$label_debug );

$res = eZDMSFileTools::reminders_lists(	/* $time_ref */ $now, 
										/* $next_reminder_field_identifier */ 'next_reminder', 
										/* $warn_late_field_identifier */ 'last_delay_before_reminder', 
										/* $too_late_field_identifier */ 'doc_is_late_from', 
										/* $recurrence_field_identifier */ 'recurrence', 
										/* $object_class_id */ 43 /* =ezdms_file */, 
										/* $exclude_list = */ array() 
									 );

if ( $res['error_code'] != 0 ) {
	if ( !$isQuiet )
		$cli->output( "Error code ".$res['error_code'].", step 1" );

	eZDMSDebugTools::writeWarning(	$cond_debug,
									"    Error code ".$res['error_code'].", in return of eZDMSFileTools::reminders_lists( )", 
									$label_debug );
}
else {
	eZDMSDebugTools::writeNotice(	$cond_debug,
									"Return of eZDMSFileTools::reminders_lists( ) is: ".print_r( $res, true ), 
									$label_debug );
	if ( !$isQuiet ) {
		$cli->output( "Return of eZDMSFileTools::reminders_lists( ) is: ".print_r( $res, true ) );
	}

	$ezDMSTools = new eZDMSFunctionCollection();
	
	/*
		These imbricated loops contruct an array of users where each appear once
		as an array of attributes.
		Each user may have one to three complementary attributes:
			-> 'really_too_late', 'too_late', 'beware'
		
	 */
	$people = array();
	for( $i = 0; $i < 3; $i++ ) {
		$status = $status_list[$i];			// this way ensures the order for the status!!
		$the_list =& $res['result'][$status];
		// For each status, we loop on all detected nodes, so that we have each 
		// corresponding user once and only once
		foreach( $the_list as $content_object_id ) {
			$obj = eZContentObject::fetch( $content_object_id );
			if ( is_object( $obj ) ) {
				$dm = $obj->attribute( 'data_map' );
				$mgr_list = $dm[ 'managers' ]->content();
				$edt_list = $dm[ 'editors' ]->content();
				
				// Let's loop on the managers
				foreach( $mgr_list[ 'relation_list' ] as $user ) {
					// Add the user if not already there
					if ( !array_key_exists( $user['contentobject_id'], $people ) ) {
						$people[ $user['contentobject_id'] ] = $user;
						$people[ $user['contentobject_id'] ][$status] = array();
					}
					// Add the node only if not already present in the current user's
					// attributes. The check is done for *all* status
					// that's why the status order is important
					$ok = true;
					for( $j = 0; $j < 3; $j++ ) {
						if ( in_array( $content_object_id, $people[ $user['contentobject_id'] ][ $status_list[$j] ] ) ) {
							$ok = false;
							break;
						}
					}
					if ( $ok ) {
						// If the user does not already have the right status array,
						// PHP will gracefully create it
						$people[ $user['contentobject_id'] ][$status][] = $content_object_id;
					}
				}
				
				// Let's loop on the editors
				foreach( $edt_list[ 'relation_list' ] as $user ) {
					if ( !array_key_exists( $user['contentobject_id'], $people ) ) {
						$people[ $user['contentobject_id'] ] = $user;
						$people[ $user['contentobject_id'] ][$status] = array();
					}
					// Add the node only if not already present in the current user's
					// attributes. The check is done for *all* status
					// that's why the status order is important
					$ok = true;
					for( $j = 0; $j < 3; $j++ ) {
						if ( in_array( $content_object_id, $people[ $user['contentobject_id'] ][ $status_list[$j] ] ) ) {
							$ok = false;
							break;
						}
					}
					if ( $ok ) {
						// If the user does not already have the right status array,
						// PHP will gracefully create it
						$people[ $user['contentobject_id'] ][$status][] = $content_object_id;
					}
				}
			}
		}
	}
	
	// Let's send mail to people
	foreach( $people as $child ) {
		$corr_user = eZUser::fetch( $child[ 'contentobject_id' ] );
		$corr_object = eZContentObject::fetch( $child[ 'contentobject_id' ] );
		if ( is_object( $corr_user ) && is_object( $corr_object ) ) {
			$dm_user = $corr_object->attribute( 'data_map' );
			$firstname = $dm_user[ 'firstname' ]->content();
			$lastname = $dm_user[ 'lastname' ]->content();
			if ( !$isQuiet ) {
				$cli->output( "$firstname $lastname [".$corr_user->attribute( 'email' )."]" );
			}
			
			// Each mail is a concatenation of all the corresponding reminders for that user
			$the_text = $reminders['header'];
			$count = 0;
			for( $i = 0; $i < 3; $i++ ) {
				$status = $status_list[$i];			// this way ensures the order for the status!!
				if ( !$isQuiet ) {
					$cli->output( "  Status: $status, values:".print_r( $child[$status], true) );
				}
				$sub_count = 0;
				// This loops on all found documents for the current status
				foreach( $child[$status] as $content_object_id ) {
					$obj = eZContentObject::fetch( $content_object_id );
					if ( is_object( $obj ) ) {
						if ( !$isQuiet ) {
							$cli->output( "  ".$obj->attribute( 'name' ) );
						}
						$dm = $obj->attribute( 'data_map' );
				        $nr = $dm['next_reminder'];
				        $node = $obj->attribute( 'main_node' );
				        if ( is_object( $node ) ) {
				        	if ( $sub_count == 0 ) {
				        		// first document encountered: let's add the current status header
								$the_text .= $reminders[ $status . "_header" ];
							}
							$the_text .= str_replace( "{THE_DOCUMENT}", $reminders['root_url'] . $node->attribute( 'url_alias' ),
											str_replace( "{DATE_HOUR}", date( "Y.m.d H:i:s", $nr->toString() ), 
															$reminders[$status . "_line"] ) );
							$count++;
							$sub_count++;
						}
						else {
							eZDMSDebugTools::writeWarning(	$cond_debug,
															"    Node not found for object with ID $content_object_id", 
															$label_debug );
						}
					}
					else {
						eZDMSDebugTools::writeWarning(	$cond_debug,
														"    Object not found for ID $content_object_id", 
														$label_debug );
					}
				}
			}
			$the_text .= $reminders['footer'];
	
			if ( $count ) {
		        $mail = new eZMail();
		        $mail->setSender( $from_mail, $from_name );
		        $mail->setReceiver( $corr_user->attribute( 'email' ), "$firstname $lastname" );
		        $mail->setSubject( $reminders['subject'] );
		        $mail->setBody( $the_text );
// /*		
		        // If mail was sent ok
		        if ( eZMailTransport::send( $mail ) )
		        {
					$cli->output( "       -> mail sent" );
		        }
		        else // If some error occured
		        {
					$cli->output( "       -> mail *not* sent" );
		        }
// */
				eZDMSDebugTools::writeNotice(	$cond_debug,
												"    mail to $firstname $lastname <".$corr_user->attribute( 'email' )."> from $from_name <$from_mail>:\n$the_text", 
												$label_debug );
		    }
		}
		else {
			if ( !is_object( $corr_user ) ) {
				eZDMSDebugTools::writeWarning(	$cond_debug,
												"    User not found for ID ".$child[ 'contentobject_id' ], 
												$label_debug );
			}
			if ( !is_object( $corr_object ) ) {
				eZDMSDebugTools::writeWarning(	$cond_debug,
												"    User object not found for ID ".$child[ 'contentobject_id' ], 
												$label_debug );
			}
		}
	}
}

eZDMSDebugTools::writeNotice(	$cond_debug,
								"    eZ File Reminders stops", 
								$label_debug );
?>
