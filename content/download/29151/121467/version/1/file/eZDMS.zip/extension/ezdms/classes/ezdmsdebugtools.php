<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     16 january 2009
Last change on: 
Version:        1.0
Extension:		eZ DMS
Description:    Tools for easy eZ debugging in logs files

Usage:			the output is done in a file the name of which is based on the 
				current date, for example: 2009-Jan-16.log
				Log files are located in ezdms/logs/ folder. Write permissions 
				should be set accordingly at install time.
				
				debug is enabled/disabled through site.ini 
				(in override/ or siteaccess/ folders)
				Example:
					[DebugSettings]
					DebugOutput=enabled
					
				Specific settings are in debug.ini (only in override/ folder)
				If the condition is disabled in the GeneralCondition section,
				the code looks further in the specific, corresponding section.
				In the following example (for eZDMSFileUpdNewType class) only 
				the notices will be outputed.
				
					[GeneralCondition]
					ezdms-workflow-ezdmsfileupdnew=disabled
					
					[ErrorCondition]
					ezdms-workflow-ezdmsfileupdnew=disabled
					
					[WarningCondition]
					ezdms-workflow-ezdmsfileupdnew=disabled
					
					[NoticeCondition]
					ezdms-workflow-ezdmsfileupdnew=enabled
					
					[DebugCondition]
					ezdms-workflow-ezdmsfileupdnew=disabled
					
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

require_once( "lib/ezutils/classes/ezdebug.php" );

class eZDMSDebugTools {

	/*
		internal function, used to activate / desactivate the debugging system
	*/
	static protected function updateSettings( $debug_on ) {
	
		eZDebug::updateSettings( array(	'debug-enabled' => $debug_on,
										'debug-by-ip' => false,
										'debug-ip-list' => array(),
										'debug-by-user' => false,
										'debug-user-list' => array() ) );
	}
	
	/*
		Activates the debugging system
	*/
	static public function turnDebugOn() {
		eZDMSDebugTools::updateSettings( true );
	}

	/*
		Desactivates the debugging system
	*/
	static public function turnDebugOff() {
		eZDMSDebugTools::updateSettings( false );
	}

	/*
		Generic debug function.
		This actually writes in ezdms/logs/ folder.
		The name of the file is based on the current date.
	*/
    static public function writeThis( $text, $label = "", $cond = false ) {

    	$log_file = dirname(__FILE__)."/../logs/".date( "Y-M-d" ) . ".log";
		$f = @fopen($log_file, "a");
		if ($f === false) {
			$f = @fopen($log_file, "w");
		}
		if ($f === false) {
			return 0;
		}
		if (0666 != ( 0666 & fileperms( $log_file ) ) )
			chmod( $log_file, 0666 );

		$bytes_written  = 0;
		if ( $label && $label != "" )
			$bytes_written  = fwrite($f, $label."\n" );
		if ( $text && $text != "" )
			$bytes_written += fwrite($f, $text."\n" );
		fclose($f);

		return $bytes_written;
	}

	/*
		Used to write a NOTICE message in the log file.
	*/
    static public function writeNotice( $cond, $text, $label ) {
    	eZDMSDebugTools::turnDebugOn();
    	
		if ( $cond && $cond != "" ) {
	        if ( !eZDebugSetting::isConditionTrue( $cond, eZDebug::LEVEL_NOTICE ) ) {
	            return 0;
	        }
		}

    	$ret = eZDMSDebugTools::writeThis( $text, "***** NOTICE ***** " . $label . " - ".date( "Y-M-d H:i:s" ), $cond );
    	eZDMSDebugTools::turnDebugOff();
    	
    	return $ret;
	}

	/*
		Used to write a WARNING message in the log file.
	*/
    static public function writeWarning( $cond, $text, $label ) {
		eZDMSDebugTools::turnDebugOn();
		
		if ( $cond && $cond != "" ) {
	        if ( !eZDebugSetting::isConditionTrue( $cond, eZDebug::LEVEL_WARNING ) )
	            return 0;
		}

    	$ret = eZDMSDebugTools::writeThis( $text, "***** WARNING ***** " . $label . " - ".date( "Y-M-d H:i:s" ), $cond );
    	eZDMSDebugTools::turnDebugOff();
    	
    	return $ret;
	}

	/*
		Used to write an ERROR message in the log file.
	*/
    static public function writeError( $cond, $text, $label ) {
		eZDMSDebugTools::turnDebugOn();
		
		if ( $cond && $cond != "" ) {
	        if ( !eZDebugSetting::isConditionTrue( $cond, eZDebug::LEVEL_ERROR ) )
	            return 0;
		}

   		$ret = eZDMSDebugTools::writeThis( $text, "***** ERROR ***** " . $label . " - ".date( "Y-M-d H:i:s" ), $cond );
   		eZDMSDebugTools::turnDebugOff();
   		
   		return $ret;
	}

	/*
		Used to write a DEBUG message in the log file.
	*/
    static public function writeDebug( $cond, $text, $label ) {
		eZDMSDebugTools::turnDebugOn();
		
		if ( $cond && $cond != "" ) {
	        if ( !eZDebugSetting::isConditionTrue( $cond, eZDebug::LEVEL_DEBUG ) )
	            return 0;
		}

   		$ret = eZDMSDebugTools::writeThis( $text, "***** DEBUG ***** " . $label . " - ".date( "Y-M-d H:i:s" ), $cond );
   		eZDMSDebugTools::turnDebugOff();
   		
   		return $ret;
	}
}

?>
