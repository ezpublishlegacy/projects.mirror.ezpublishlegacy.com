<?php /* #?ini charset="utf-8"?

[TreeMenu]
Dynamic=enabled
ShowClasses[]
ShowClasses[]=ezdms_folder
ShowClasses[]=ezdms_file
ShowClasses[]=ezdms_user
ShowClasses[]=user_group
ShowClasses[]=frontpage

AutoopenCurrentNode=enabled

ToolTips=disabled

*/ ?>
