<?php /* #?ini charset="utf8"?

[EditorSettings]
SkinVariant=silver
*/ ?>