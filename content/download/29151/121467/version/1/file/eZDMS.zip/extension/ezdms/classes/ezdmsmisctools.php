<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch
				cyp@open-net.ch

Created on:     18 january 2009
Last change on: 11 june 2009 / Cyp
Version:        1.1
Extension:		eZ DMS
Description:    Tools for eZ DMS Folders management
History:		change in setup_folder_permissions( ):
					does not use anymore the 'admin' login
					returns true if everything ran ok

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

//include_once( $baseDir . "ezdmsdebugtools.php" );

class eZDMSMiscTools {

	static public function build_pid_path( $base_name ) {
		return eZDir::cleanPath( eZSys::varDirectory().'/run/'.$base_name.'.pid' ); 
	}

	static public function getPID( $pid_fname ) {
		if ( !file_exists( $pid_fname ) ) return false;
		return file_get_contents( $pid_fname );
	}
	
	static public function setPID( $pid_fname ) {
		if( false == file_exists( dirname( $pid_fname ) ) ) {
			eZDir::mkdir( dirname( $pid_fname ), false, true );
		}
		
		if( !is_writeable( dirname( $pid_fname ) ) ) {
		    return false;
		}
		
		$pidfile = fopen( $pid_fname, 'w' );
		fwrite( $pidfile, getmypid() );
		fclose( $pidfile );
		
		return true;
	}

	static public function delPID( $pid_fname ) {
		// remove pid file to unlock cronjob
		if( file_exists( $pid_fname ) ) {
		    unlink( $pid_fname );
		}
	}

	static public function fetch_object_by_filename( $filename, $container_class_id_filter = false ) {
		$objects = array();
		$ids = array();
		$list = eZPersistentObject::fetchObjectList( eZBinaryFile::definition(),
		                                                         null,
		                                                         array( 'original_filename' => $filename ),
		                                                         null,
		                                                         null,
		                                                         true );
		
		foreach( $list as $ez_bin_file ) {
			$id = $ez_bin_file->attribute('contentobject_attribute_id');
			$version = $ez_bin_file->attribute('version');
			if ( isset( $ids[$id] ) ) {
				$ids[$id] = $version;
			}
			else {
				if ( $version > $ids[$id] ) {
					$ids[$id] = $version;
				}
			}
		}
		
		foreach( $ids as $id => $value ) {
			$attribute = eZContentObjectAttribute::fetch( $id, $version, true );
			if ( is_object( $attribute ) ) {
				$object_id = $attribute->attribute( 'contentobject_id' );
				$container = $attribute->attribute( 'object' );
				
				$valid = false;
				if ( !in_array( $object_id, $objects ) && is_object( $container ) ) {
					$valid = ( $container->attribute( 'status' ) == eZContentObject::STATUS_PUBLISHED );
				}
				if ( $valid ) {
					if ( $container_class_id_filter && $container_class_id_filter != "" ) {
						$valid = false;
						if ( is_object( $container ) ) {
							if ( $container->attribute( 'class_identifier' ) == $container_class_id_filter ) {
								$valid = true;
							}
						}
					}
				}
				if ( $valid ) {
					$objects[] = $object_id;
				}
			}
		}
		
		return $objects;
	}

	static public function ezfind_search_by_filename( $filename ) {
		$current_site_access = eZDMSFunctionCollection::current_site_access();
		if ( $current_site_access && count($current_site_access) > 0 ) {
			$current_site_access = $current_site_access['result'];
			if ( $current_site_access && $current_site_access != "" ) {
				$current_site_access = "/" . $current_site_access['result'] . "/";
			}
		}
		else {
			$current_site_access = "";
		}
		
		$res = array();
		$q = "SELECT distinct `ezcontentobject`.id,`ezbinaryfile`.original_filename " . 
				"FROM `ezcontentobject`, `ezcontentclass`,  `ezcontentobject_attribute`, `ezbinaryfile` " . 
				"where `contentclass_id`=`ezcontentclass`.id " . 
				"and `ezcontentclass`.identifier='ezdms_file' " . 
				"and  `ezcontentobject_attribute`.contentobject_id=`ezcontentobject`.id " . 
				"and  `ezbinaryfile`.contentobject_attribute_id=`ezcontentobject_attribute`.id " . 
				"and ezbinaryfile.original_filename LIKE '%".$filename."%'";
		$db = eZDB::instance();
		$rows = $db->arrayQuery( $q, array() );
		foreach( $rows as $row ) {
			$nodes = eZContentObjectTreeNode::fetchByContentObjectID( $row['id'] );
			foreach( $nodes as $node ) {
				if ( $node->attribute( 'can_read' ) ) {
					$object = $node->attribute( 'object' );
					$item = new eZFindResultNode();
					$item->setAttribute( 'is_local_installation', false );
					$item->setAttribute( 'global_url_alias', $node->attribute( 'url_alias' ) );
					$item->setAttribute( 'name', $node->attribute( 'name' ) );
					$item->setAttribute( 'published', $object->attribute( 'published' ) );
					$item->setAttribute( 'highlight', null );
					$item->setAttribute( 'score_percent', -1.0 );
					$item->setAttribute( 'language_code', $object->attribute( 'current_language' ) );
					
					$res[] = $item;
				}
			}
		}
		
		return $res;
	}
}

?>
