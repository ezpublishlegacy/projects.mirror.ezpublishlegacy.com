<?php /* #?ini charset="utf-8"?

[VersionView]
AvailableSiteDesignList[]
AvailableSiteDesignList[]=ezwebin_site_clean
AvailableSiteDesignList[]=ezflow
AvailableSiteDesignList[]=admin2
AvailableSiteDesignList[]=admin

[ObjectRelationDataTypeSettings]
ClassAttributeStartNode[]=236;AddRelatedBannerImageToDataType
*/ ?>