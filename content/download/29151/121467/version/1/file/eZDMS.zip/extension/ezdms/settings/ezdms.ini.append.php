<?php /*

[User Nodes]
# Node where unvalidated users are placed
node_id_for_unvalidated_users=61

# Node where validated users are placed
node_id_for_validated_users=62

[ezobjectrelationlist]
# If all eZ DMS Users have their main location plus at least one secondary location
# then, it may be userful to lighten the resulting list by removing the main locations
# In that case, just put 'yes' (without quotes)
skip_main_nodes=yes

*/ ?>

