<?php /* #?ini charset="utf8"?

[NavigationPart]
Part[workflowboardnavigationpart]=workflowboard

[TopAdminMenu]
Tabs[]=workflowboard

[Topmenu_workflowboard]
URL[]
URL[default]=workflowboard/list
NavigationPartIdentifier=workflowboardnavigationpart
Name=Workflow board
#Tooltip=Manage the main content structure of the site.
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>