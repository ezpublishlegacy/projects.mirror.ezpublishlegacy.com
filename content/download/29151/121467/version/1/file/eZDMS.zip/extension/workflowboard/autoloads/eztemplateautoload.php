<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
array( 'script' => 'extension/workflowboard/autoloads/serialoperator.php',
        'class' => 'SerialOperator',
        'operator_names' => array( 'getUnserialized' ) );

 


?>
