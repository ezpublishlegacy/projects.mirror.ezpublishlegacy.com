<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    this handles the 'Lock' and the 'Unlock' requests, from the
				interface.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsfiletools.php" );

$Module =& $Params['Module'];
$http = eZHTTPTool::instance();

$doc_id = $Params['DocumentID'];
$node_id = 0;
$the_nodes = eZContentObjectTreeNode::fetchByContentObjectID( $doc_id );
if ( count( $the_nodes ) ) {
	$the_node = $the_nodes[0];
	$node_id = $the_node->attribute( 'node_id' );
}

$return_path="";
if ( $http->hasPostVariable( 'return_path' ) ) {
	$return_path=$http->postVariable( 'return_path' );
}

$tpl = templateInit();
$tpl->setVariable( 'document_node_id', $node_id );
$tpl->setVariable( 'document_path_string', $return_path );

if ( $node_id && $http->hasPostVariable( 'lock_it' ) ) {
	eZDMSFileTools::lock_it( $node_id );	
	$http->redirect( $return_path . '?download=1' );
}

if ( $node_id && $http->hasPostVariable( 'unlock_it' ) ) {
	eZDMSFileTools::unlock_it( $node_id );
	$http->redirect( $return_path );
}

	echo "Post variable is: ";
	print_r($_POST);
$Result = array();
$Result['content'] = $tpl->fetch( "design:$extension/locks_management.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'ezdms', 'Document lock status' ) ) );

?>
