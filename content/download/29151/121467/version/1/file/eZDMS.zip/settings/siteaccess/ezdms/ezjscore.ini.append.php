<?php /* #?ini charset="utf-8"?

[eZJSCore]
Packer=enabled
PreferredLibrary=yui3
*/ ?>