<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     26 april 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSFileUploadedType extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_STRING = "ezdmsfileuploaded";

	protected $title;

    function eZDMSFileUploadedType() {
    
        $this->title = "workflow " . eZDMSFileUploadedType::WORKFLOW_TYPE_STRING;
		$this->eZWorkflowEventType( eZDMSFileUploadedType::WORKFLOW_TYPE_STRING, 
									ezi18n( 'extension/ezdms/event', "Handles uploaded files by attaching them to their corresponding eZ DMS file" ) );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( /* 'before', */
                                                                               'after' ) ) ) );
    }

    function execute( $process, $event ) {
    
    	$cond_debug = 'ezdms-workflow-' . eZDMSFileUploadedType::WORKFLOW_TYPE_STRING;
    	$label_debug = "eZDMSFileUploadedType::execute()";
    
        // get object and objectId
        $parameters = $process->attribute( 'parameter_list' );
        $objectId= $parameters['object_id'];

        // This is the actual object being edited or created
        $object = eZContentObject::fetch( $parameters['object_id'] );

        if ( !$object ) {
        
            eZDMSDebugTools::writeError( $cond_debug,
										'The object with ID '.$parameters['object_id'].' does not exist.', 
										$label_debug.' object is unavailable' );
            return eZWorkflowType::STATUS_WORKFLOW_CANCELLED;
        }
		eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $parameters, true ), 
										$label_debug." Parameters: " );

        $class_identifier = $object->attribute( 'class_identifier' );
		eZDMSDebugTools::writeNotice(	$cond_debug,
										$class_identifier, 
										$label_debug." object's class identifier" );

/*
        eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $object, true ), 
										$label_debug." object's content" );
*/
		$file_obj  = false;
		$file_name = false;
		$data_map  = $object->attribute( 'data_map' );
		$class_identifier = $object->attribute( 'class_identifier' );
		if ( isset( $data_map[ $class_identifier ] ) ) {
			$file_obj = $data_map[ $class_identifier ]->content();
		}
		if ( !is_object( $file_obj ) ) {
			
            eZDMSDebugTools::writeWarning( $cond_debug,
										'The corresponding data_map item is not set, that means that the uploaded object cannoz be handled', 
										$label_debug . 'Class identifier: $class_identifier' );
		}
		else {
			$file_name = $file_obj->attribute( 'original_filename' );
			$objects_ids_list = eZDMSMiscTools::fetch_object_by_filename( $file_name, 'ezdms_file' );
			switch( count( $objects_ids_list ) ) {
			case 0:
				eZDMSDebugTools::writeNotice(	$cond_debug,
												"The file '$file_name' does not correspond at any eZ DMS File - the file is rejected", 
												$label_debug );
			break;
			
			case 1:
				eZDMSDebugTools::writeNotice(	$cond_debug,
												"The file '$file_name' corresponds at exactely one eZ DMS File: object ID ".$objects_ids_list[0]." - the file is accepted. Its content is: ".print_r( $file_obj, true ), 
												$label_debug );
				$obj = eZContentObject::fetch( $objects_ids_list[0] );
				if ( is_object( $obj ) ) {
					
					$new = $obj->createNewVersion();
					$dataMap = $obj->fetchDataMap( $new->attribute( 'version' ) );
					foreach( $dataMap as $key => $object_attribute ) {
						if ( $key == 'file' ) {
							$dataMap[$key]->setContent( $file_obj );
							$dataMap[$key]->storeData();
							eZDMSDebugTools::writeNotice(	$cond_debug,
															"Content Object Attribute updated", 
															$label_debug );
							break;
						}
					}
					$new->setAttribute( 'status', eZContentObjectVersion::STATUS_PUBLISHED );
					$new->store();

		            $contentObjectID = $obj->attribute( 'id' );
					$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
		                                                                                         'version'   => $new->attribute( 'version' ) ) );
					eZDMSDebugTools::writeNotice(	$cond_debug,
													"New version (id=$contentObjectID)".( $operationResult ? "" : "not " )." published (v".$new->attribute( 'version' ).")", 
													$label_debug );
				}
			break;
			
			default:
				eZDMSDebugTools::writeNotice(	$cond_debug,
												"The file '$file_name' corresponds at too many eZ DMS Files - the file is rejected", 
												$label_debug );
			}
		}
		
        return eZWorkflowType::STATUS_ACCEPTED;
    }
    
}

eZWorkflowEventType::registerEventType( eZDMSFileUploadedType::WORKFLOW_TYPE_STRING, "eZDMSFileUploadedType" );

?>
