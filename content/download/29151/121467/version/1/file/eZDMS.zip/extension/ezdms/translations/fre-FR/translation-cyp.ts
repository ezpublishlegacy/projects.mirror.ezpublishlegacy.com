<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en_US">
<defaultcodec></defaultcodec>
<context>
    <name>design/ezwebin/view/ezbinaryfile</name>
    <message>
        <source>Lock</source>
        <translation>Verrouiller</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>D&amp;eacute;verrouiller</translation>
    </message>
    <message>
        <source>Locked by</source>
        <translation>Verrouill&amp;eacute; par</translation>
    </message>
</context>
</TS>
