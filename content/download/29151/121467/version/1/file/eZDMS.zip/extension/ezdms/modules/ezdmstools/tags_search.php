<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    test module.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

//include_once( $baseDir . "ezdmsfiletools.php" );

$Module =& $Params['Module'];
$http = eZHTTPTool::instance();
$db = eZDB::instance();

$result = "";
$res = "";
$result_count = 0;
$result_list = "";

if ( $http->hasPostVariable( 'SearchHerTags' ) ) {
	$search_result = array();
	$key = "node-location-";
	$key_len = strlen( $key );
	$found_nodes = array();
	$conditions = array();
	$cond_count = 0;
	foreach ( $_POST as $posted_item => $posted_value ) {

		if ( substr( $posted_item, 0, $key_len ) == $key ) {

			//$_SESSION[ $posted_item ] = 1;
			$cond_count += 1;
			$node_key = intval( substr( $posted_item, $key_len ) );
			$her_tag_node = eZContentObjectTreeNode::fetch( $node_key );
			if ( $her_tag_node ) {

				$sql = "Select main_node_id From ezcontentobject_tree where contentobject_is_published and path_string like '".$her_tag_node->attribute( 'path_string' )."%'";
				$rows = $db->arrayQuery( $sql );
				foreach( $rows as $row ) {

					$main_node_id = $row['main_node_id'];
					if ( $main_node_id != $node_key ) {

						if ( !array_key_exists( $main_node_id, $found_nodes ) ) {

							$found_nodes[ $main_node_id ] = 0;
						}
						$found_nodes[ $main_node_id ] += 1;
					}
				}
			}
		}
	}

	foreach( $found_nodes as $node_key => $node_count ) {
		
		if ( $node_count >= $cond_count ) {
		
			$node = eZContentObjectTreeNode::fetch( $node_key );
			if ( $node && $node->attribute( 'class_identifier' ) != 'ezdms_her_tag' && $node->attribute( 'can_read' ) ) {
			
				$search_result[] = $node;
				$result_count += 1;
			}
		}
	}
}

$tpl = templateInit();
$tpl->setVariable( 'the_result_list', $res );
$tpl->setVariable( 'result_count', $result_count );
$tpl->setVariable( 'search_result', $search_result );

$Result = array();
$Result['content'] = $tpl->fetch( "design:$extension/tags_search.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'ezdms', 'Tags Search' ) ) );


?>
