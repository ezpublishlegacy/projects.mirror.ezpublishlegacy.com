<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 
Version:        1.0
Extension:		eZDMS
Description:    this handles the 'Lock' and the 'Unlock' requests, from the
				interface.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsfiletools.php" );
include_once( $baseDir . "ezdmsfoldertools.php" );
include_once( $baseDir . "ezdmsdebugtools.php" );

$Module =& $Params['Module'];
$http = eZHTTPTool::instance();

if ( $http->hasPostVariable( 'PublishHerButton' ) ) {

	$label_debug = "her-management: Publish Hierarchical Tags";
	
	$node_id = $http->postVariable( 'ContentNodeID' );
	$node_locations = array();
	$key = "node-location-";
	$key_len = strlen( $key );
	foreach ( $_POST as $posted_item => $posted_value ) {
		if ( substr( $posted_item, 0, $key_len ) == $key ) {
			$node_key = intval( substr( $posted_item, $key_len ) );
			$node_locations[] = $node_key;
		}
	}
	eZDMSDebugTools::writeNotice(	false,
									print_r( $node_locations, true ), 
									$label_debug."Selected node locations for the node $node_id:" );

	$node_obj = eZContentObjectTreeNode::fetch( $node_id );
	$compl = "";
	if ( is_object( $node_obj ) ) {
	
		$node_class = $node_obj->attribute( 'class_identifier' );
		if ( $node_class == 'ezdms_file' ) {
			eZDMSFileTools::setup_other_locations( $node_id, $node_locations );
			$compl = "/(tab)/hertags";
		}
		if ( $node_class == 'ezdms_folder' ) {
			eZDMSFolderTools::setup_other_locations( $node_id, $node_locations );
			$compl = "/(tab)/hertags";
		}
	}
	
	return $Module->redirectTo( 'content/view/full/' . $node_id . $compl );
	
}

if ( $http->hasPostVariable( 'CancelHerButton' ) ) {

	$node_id = $http->postVariable( 'ContentNodeID' );
	return $Module->redirectTo( 'content/view/full/' . $node_id );
	       
}

$node_id  = $Params['NodeID'];
$node_obj = eZContentObjectTreeNode::fetch( $node_id );
$tmpl_name = false;
if ( is_object( $node_obj ) ) {

	$node_class = $node_obj->attribute( 'class_identifier' );
	if ( $node_class == 'ezdms_file' || $node_class == 'ezdms_folder' ) {
		$tmpl_name = $node_class;
	}
}
if ( !$tmpl_name ) {

	return $Module->redirectTo( 'content/view/full/' . $node_id );
}

$tpl = templateInit();

$Result = array();
$tpl->setVariable( 'node', $node_obj );

$Result['content'] = $tpl->fetch( "design:her-mgt/ezdms_file.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'ezdms', 'Setup the Hierarchical Tags of the node ' ) . $node_obj->attribute( 'name' )  ) );

// 
?>