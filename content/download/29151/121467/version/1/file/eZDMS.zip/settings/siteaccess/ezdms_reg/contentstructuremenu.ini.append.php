<?php /* #?ini charset="utf-8"?

[TreeMenu]

ShowClasses[]
ShowClasses[]=ezdms_folder
ShowClasses[]=ezdms_file
ShowClasses[]=ezdms_user
ShowClasses[]=user_group
ShowClasses[]=ezdms_her_tag

# dynamic menu is: enabled/disabled
Dynamic=enabled

AutoopenCurrentNode=enabled

ToolTips=disabled

*/ ?>
