<?php

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );

function ezdms_ContentActionHandler( $Module, $http, $objectID ) {

	$label_debug = "ezdms_ContentActionHandler";

	eZDMSDebugTools::writeWarning(	false,
									"Entering my content action handler.", 
									$label_debug );
    eZDebug::writeNotice( "Entering my content action handler.", 'Cyp:debug' );

    $ret = eZModule::HOOK_STATUS_CANCEL_RUN;
	if( $http->hasPostVariable( "eZDMSPublishButton" ) ) {
        eZDebug::writeNotice( "POST variable detected: eZDMSPublishButton.", 'Cyp:debug' );
		//include_once( realpath(dirname(__FILE__) . "/ezdms_tools.php" ) );
		//$ret = C_eZDmsTools::handle_form( $Module, $http, $objectID );

	    if ( $http->hasPostVariable( 'ContentObjectID' ) )
	    {
	        $parameters = array( $http->postVariable( 'ContentObjectID' ) );
	        if ( $http->hasPostVariable( 'ContentObjectVersion' ) )
	        {
	            $parameters[] = $http->postVariable( 'ContentObjectVersion' );
	            if ( $http->hasPostVariable( 'ContentObjectLanguageCode' ) )
	            {
	                $parameters[] = $http->postVariable( 'ContentObjectLanguageCode' );
	            }
	        }
	        eZDebug::writeNotice( "About to step further", 'Cyp:debug' );
//	        $Module->setCurrentAction( 'Publish', 'edit' );
//	        return $Module->run( 'edit', $parameters );
	    }
	}

    eZDebug::writeNotice( "Exiting my content action handler with: ".print_r($ret, true), 'Cyp:debug' );
	
	return $ret;
}
?>

