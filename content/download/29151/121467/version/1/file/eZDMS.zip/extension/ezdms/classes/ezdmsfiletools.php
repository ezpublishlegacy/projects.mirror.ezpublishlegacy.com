<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     15 january 2009
Last change on: 12 february 2009
Version:        1.0
Extension:		eZ DMS
Description:    Tools for eZ DMS Files management

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSFileTools {
	/*
		Locks an eZDMS file. The assignments refer to the corresponding
		parent's specific attributes.
		The parent must be an 'eZ DMS folder'.

			- the role name is always "eZ DMS File " + the node id
			- current policies and role are deleted
			- a new role is created
			- the folling policy is appended to the role:
				- content edit, by node, from the 'admin_perms' attribute

	*/
	static public function lock_it( $node_id ) {
		$ez_dms_file_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_file_node ) ) {
			return false;
		}
		if ( $ez_dms_file_node->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return false;
		}
	
    	$cond_debug = 'ezdms-workflow-ezdmsfileupdnew';
    	$label_debug = "eZDMSFileTools::lock_it()";

		// Before creating a new role, let's remove the old one if it exists
		$role_name = "eZ DMS File ".$node_id;
		$role = eZRole::fetchByName( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->removePolicies();
			$role->remove();
		}
	
		$role = eZRole::create( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->store();
			if( $role->assignToUser( eZUser::currentUserID() ) ) {
				eZCache::clearByTag( 'content' );
			}
			$policy = $role->appendPolicy( 'content', 'edit', array( 'Node' => array( $node_id ) ) );
			if( $policy ) {
				$policy->store();
	
		    	$parent_node = $ez_dms_file_node->attribute( 'parent' );
		    	$parent_object = $parent_node->attribute( 'object' );
		    	$dm = $parent_object->attribute( 'data_map' );
				
				$allowed_groups = $dm[ 'admin_perms' ]->content();
				$obj_rel_list = $allowed_groups[ 'relation_list' ];
				foreach( $obj_rel_list as $allowed_group ) {
					$us = eZContentObject::fetchByNodeID( $allowed_group[ 'node_id' ] );
					$id = $us->attribute( 'id' );
					if( $role->assignToUser( $id ) ) {
						eZCache::clearByTag( 'content' );
					}
				}
			}
		}
		eZContentCacheManager::clearAllContentCache();
		eZDMSFolderTools::setup_folder_permissions( $ez_dms_file_node->attribute( 'parent_node_id' ) );
		ezCache::clearAll();
		
		return true;
	}

	/*
		Unlocks an eZDMS file. This is done by restoring its default 
		permissions.
		Refer to the function 'inherits_permissions( )' for details.

	*/
	static public function unlock_it( $node_id ) {
		$ez_dms_file_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( $ez_dms_file_node->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return false;
		}
	
		// Let's remove the current file role, if it exists
		$role_name = "eZ DMS File ".$node_id;
		$role = eZRole::fetchByName( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->removePolicies();
			$role->remove();
		}
		
		eZContentCacheManager::clearAllContentCache();
		eZDMSFolderTools::setup_folder_permissions( $ez_dms_file_node->attribute( 'parent_node_id' ) );
		ezCache::clearAll();
		
		return true;
	}
	
	/*
		Checks whether an eZ DMS File is locked or not.
		This is done by checking if the 'Content -> Read' policy exists or not.
		If it exists, the node has its defaults permissions.
		If not, it is locked.
	*/
	static public function is_locked( $node_id ) {
	
		$this_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $this_node ) ) return false;

		// Test if a specific role is defined
		$role = eZRole::fetchByName( "eZ DMS File $node_id" );
		if ( $role ) return true;		
		
		return false;
	}
	
	/*
		Returns the name of the user whick locked the eZ DMS File that 
		corresponds to the node ID.
		Returns an empty string if the file is not locked
	*/
	static public function get_locker( $node_id, $as_array = false, $pre_string = '' ) {
	
		$this_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $this_node ) ) return "";

		// Test if a specific role is defined
		$role = eZRole::fetchByName( "eZ DMS File $node_id" );
		if ( !$role ) return "";
		
		$names = array();
		foreach( $role->fetchUserID() as $users_list ) {
			foreach( $users_list as $user_id ) {
				$user = eZContentObject::fetch( $user_id );
				if ( $user ) $names[] = $user->attribute( 'name' );
			}
		}
		if ( !$pre_string || count( $names ) == 0 ) $pre_string = "";
		return $as_array ? $names : ( $pre_string . implode( ", ", $names ) );
	}
	
	/*
		Sets the permissions of an eZDMS file. The assignments refer to the
		corresponding parent's specific attributes.
		The parent must be an 'eZ DMS folder'.
		
			- the role name is always "eZ DMS File " + the node id
			- current policies and role are deleted
			- a new role is created
			- the following policies are appended to the role and assigned:
				- content read, by node, from the 'read_perms' attribute
				- content edit, by node, from the 'edit_perms' attribute
				- content admin, by node, from the 'admin_perms' attribute

	*/
	static public function inherit_permissions( $node_id ) {
		$ez_dms_file_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_file_node ) ) {
			return false;
		}
		if ( $ez_dms_file_node->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return false;
		}
		
		$role_name = "eZ DMS File ".$node_id;
	
		// Before creating a new role, let's remove the old one if it exists
		$role = eZRole::fetchByName( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->removePolicies();
			$role->remove();
		}
	
		$role = eZRole::create( $role_name );
		if ( $role ) {
			$role->turnOffCaching();
			$role->store();
			
	    	$parent_node = $ez_dms_file_node->attribute( 'parent' );
	    	$parent_object = $parent_node->attribute( 'object' );
	    	$dm = $parent_object->attribute( 'data_map' );
			
			foreach( array( 'read' => 'read_perms', 'edit' => 'edit_perms', 'admin' => 'admin_perms' ) as $function => $allowed_group_name ) {
				$policy = $role->appendPolicy( 'content', $function, array( 'Node' => array( $node_id ) ) );
				if( $policy ) {
					$policy->store();
		
					$allowed_groups = $dm[ $allowed_group_name ]->content();
					if ( $allowed_groups ) {
						$obj_rel_list = $allowed_groups[ 'relation_list' ];
						foreach( $obj_rel_list as $allowed_group ) {
							$us = eZContentObject::fetchByNodeID( $allowed_group[ 'node_id' ] );
							$id = $us->attribute( 'id' );
							if( $role->assignToUser( $id ) ) {
								eZCache::clearByTag( 'content' );
							}
						}
					}
				}
			}
		}
		eZContentCacheManager::clearAllContentCache();
	}
	
	/*
		Updates the "Last delay before reminder" attributes: it equals to "next reminder" - tolerance
	*/
	static public function update_last_delay_before_reminder( $object_id ) {
		$ez_dms_file = eZContentObject::fetch( $object_id );
		if ( $ez_dms_file->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return false;
		}
		
		$dm = $ez_dms_file->attribute( 'data_map' );
		$next_reminder = $dm[ 'next_reminder' ]->value();
		$tolerance = $dm[ 'tolerance' ]->value();
		$recurrence = $dm[ 'recurrence' ]->value();
		$ld =& $dm[ 'last_delay_before_reminder' ];
		if (  is_array( $recurrence ) ) {
			if ( count( $recurrence ) > 0 ) {
				$ld_value = new eZDateTime( $next_reminder->attribute( 'timestamp' ) );
				if ( $recurrence[0] == 0 )	// if daily: the tolerance is in hours
					$ld_value->adjustDateTime( -$tolerance );
				else						// else: the tolerance is in days
					$ld_value->adjustDateTime( 0,0,0,0, -$tolerance );
				$contentClassAttribute = $ld->contentclassAttribute();
				$dataType = $contentClassAttribute->dataType();
				$ld->setAttribute( 'data_int', $ld_value->timeStamp() );
				$ld->store( 'data_int' );
			}
		}
		
	}
	
	/*
		Updates the "Document is late from" attributes: it equals to "next reminder" + tolerance
	*/
	static public function update_doc_is_late_from( $object_id ) {
		$ez_dms_file = eZContentObject::fetch( $object_id );
		if ( !is_object( $ez_dms_file ) ) {
			return false;
		}
		if ( $ez_dms_file->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return false;
		}
		
		$dm = $ez_dms_file->attribute( 'data_map' );
		$next_reminder = $dm[ 'next_reminder' ]->value();
		$tolerance = $dm[ 'tolerance' ]->value();
		$recurrence = $dm[ 'recurrence' ]->value();
		$ld = $dm[ 'doc_is_late_from' ];
		if (  is_array( $recurrence ) ) {
			if ( count( $recurrence ) > 0 ) {
				$ld_value = new eZDateTime( $next_reminder->attribute( 'timestamp' ) );
				if ( $recurrence[0] == 0 )	// if daily: the tolerance is in hours
					$ld_value->adjustDateTime( $tolerance );
				else						// else: the tolerance is in days
					$ld_value->adjustDateTime( 0,0,0,0, $tolerance );
				$contentClassAttribute = $ld->contentclassAttribute();
				$dataType = $contentClassAttribute->dataType();
				$ld->setAttribute( 'data_int', $ld_value->timeStamp() );
				$ld->store( 'data_int' );
			}
		}
		
	}
	
	/*
		This function outputs a double-entries array: one for the searched objects, the other for an error code.
		Example: array( 'result' => array( 173,174), 'error_code' => 0 )
		Values for the error code:
			0:	no error
			1:	could not read the content class atributes list
			2:	field not found
		Parameters:
			$time_ref:			a timestamp, as outputed by time()
			$fields identifiers:	a string, examples: 'doc_is_late_from', 'last_delay_before_reminder'
			$object_class_id: 	an integer: the id of the objects class
	*/
	static public function reminders_lists( $time_ref, $next_reminder_field_identifier, $warn_late_field_identifier, $too_late_field_identifier, $recurrence_field_identifier, $object_class_id, $exclude_list = array() ) {
	
		$h_ref = date("H", $time_ref);
	
		// Retrieve the id of the field, depending on the class of the object
		$fields_list = eZContentClassAttribute::fetchFilteredList( array( 'contentclass_id' => $object_class_id, 'identifier' => $too_late_field_identifier ) );
		if ( !is_array( $fields_list ) ) return array( 'result' => array(), 'error_code' => 1 );
		if ( count( $fields_list ) < 1 ) return array( 'result' => array(), 'error_code' => 2 );
		$field_id = $fields_list[0]->attribute( 'id' );
		
		// Retrieve the objects from the conditions on the attribute
		$params = array( 'contentclassattribute_id' => $field_id );
		$list = eZPersistentObject::fetchObjectList( eZContentObjectAttribute::definition(),
													 null,
													 $params,
													 null,
													 null,
													 true,
													 false,
													 null,
													 null,
													 " AND data_int > 0 AND data_int <= $time_ref "
													);

		// Build the output list
		$really_too_late_result_list = array();
		foreach( $list as $item ) {
			$object = $item->attribute( 'object' );
			$object_id = $object->attribute( 'id' );

			// consider only the current version. The others will be ignored
			if ( $object->attribute( 'current_version' ) == $item->attribute( 'version' ) ) {
				if ( !in_array( $object_id, $result_list ) ) {
					// This test is used to ignore fake objects (never published)
					if ( $object->attribute( 'main_node' ) ) {
						$dm = $object->attribute( 'data_map' );
						$nr = $dm[ $too_late_field_identifier ];
						$timestamp = intval( $nr->toString() );
						$valid = false;
						$recurrence = $dm[ $recurrence_field_identifier ]->value(); 
						if ( $recurrence[0] == 0 )
							$valid = true;
						elseif ( $h_ref == date( "H", $timestamp ) )
							$valid = true;
						if ( $valid ) {
							$really_too_late_result_list[] = $object_id;
						}
					}
				}
			}
		}

		// Retrieve the id of the field, depending on the class of the object
		$fields_list = eZContentClassAttribute::fetchFilteredList( array( 'contentclass_id' => $object_class_id, 'identifier' => $warn_late_field_identifier ) );
		if ( !is_array( $fields_list ) ) return array( 'result' => array(), 'error_code' => 1 );
		if ( count( $fields_list ) < 1 ) return array( 'result' => array(), 'error_code' => 2 );
		$field_id = $fields_list[0]->attribute( 'id' );
		
		// Retrieve the objects from the conditions on the attribute
		$params = array( 'contentclassattribute_id' => $field_id );
		$list = eZPersistentObject::fetchObjectList( eZContentObjectAttribute::definition(),
													 null,
													 $params,
													 null,
													 null,
													 true,
													 false,
													 null,
													 null,
													 " AND data_int > 0 AND data_int <= $time_ref "
													);

		// Build the output list
		$warn_late_result_list = array();
		$too_late_result_list = array();
		foreach( $list as $item ) {
			$object = $item->attribute( 'object' );
			$object_id = $object->attribute( 'id' );

			// consider only the current version. The others will be ignored
			if ( $object->attribute( 'current_version' ) == $item->attribute( 'version' ) ) {
				if ( !in_array( $object_id, $result_list ) ) {
					// This test is used to ignore fake objects (never published)
					if ( $object->attribute( 'main_node' ) ) {
						$dm = $object->attribute( 'data_map' );
						if ( isset( $dm[ $next_reminder_field_identifier ] ) ) {
							$nr = $dm[ $next_reminder_field_identifier ];
							$tl = $dm[ $too_late_field_identifier ];
							$nr_timestamp = intval( $nr->toString() );
							$tl_timestamp = intval( $tl->toString() );
							$valid = false;
							$recurrence = $dm[ $recurrence_field_identifier ]->value(); 
							if ( $recurrence[0] == 0 )
								$valid = true;
							elseif ( $h_ref == date( "H", $nr_timestamp ) )
								$valid = true;
							if ( $valid ) {
								// Check if the current time stamp is between next_reminder - tolerance and next_reminder
								if ( $time_ref < $nr_timestamp ) {
									$warn_late_result_list[] = $object_id;
								}
								// Else if the doc's time stamp is between next_reminder and next_reminder + tolerance
								elseif ( $time_ref < $tl_timestamp ) {
									$too_late_result_list[] = $object_id;
								}
								
							}
						}
					}
				}
			}
		}

		return array( 'result' => array( 'really_too_late' => $really_too_late_result_list, 'too_late' => $too_late_result_list, 'beware' => $warn_late_result_list ), 'error_code' => 0 );
	}
	
	static public function force_notification( $node_id, $doc_just_created = false ) {
		// Retrieve the list of emails
		$ez_dms_file_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_file_node ) ) {
			return 1;
		}
		if ( $ez_dms_file_node->attribute( 'class_identifier' ) != 'ezdms_file' ) {
			return 2;
		}
		$ez_dms_file_object = $ez_dms_file_node->attribute( 'object' );
		if ( !is_object( $ez_dms_file_object ) ) {
			return 3;
		}
		$ez_dms_file_dm = $ez_dms_file_object->attribute( 'data_map' );
		if ( !is_array( $ez_dms_file_dm ) ) {
			return 4;
		}
		
		// Setup the constant part of the emails
		$remindersINI = eZINI::instance( 'reminders.ini' );
		$mail_body = str_replace( "{THE_DOCUMENT}", $ez_dms_file_node->attribute( 'url_alias' ),
						str_replace( "{DATE_HOUR}", date( "Y.m.d H:i" ), 
							str_replace( "\\n", "\n", 
								$remindersINI->variable(	'eZDMSFileForceNotifications', 
															$doc_just_created ? 'creation' : 'update' ) ) ) );
		$from_name = $remindersINI->variable( 'eZDMSFileForceNotifications', 'fromName' );
		$from_mail = $remindersINI->variable( 'eZDMSFileForceNotifications', 'fromMail' );
		
		$force_notification_field = isset( $ez_dms_file_dm[ 'force_notification' ] ) ? $ez_dms_file_dm[ 'force_notification' ]->content() : array();
		foreach( split( ";", $force_notification_field ) as $email ) {
			
			$name = $email;
			$user = eZUser::fetchByEmail( $email );
			if ( $user ) {
				$obj = $user->attribute( 'contentobject' );
				if ( $obj )
					$name = $obj->attribute( 'name' );
			}

	        $mail = new eZMail();
	        $mail->setSender( $from_mail, $from_name );
	        $mail->setReceiver( $email, $name );
	        $mail->setSubject( $ez_dms_file_node->attribute( 'url_alias' ) );
	        $mail->setBody( $mail_body );

	        eZMailTransport::send( $mail ); 
		}
	
		return 0;
	}
	
	static public function setup_other_locations( $node_id, $locations = false ) {
    	$cond_debug = 'ezdms-workflow-ezdmsfileupdnew';
    	$label_debug = "eZDMSFolderTools::setup_other_locations()";
    	
		$user = eZUser::fetch( eZUser::currentUserID() );
		$user_name = $user->attribute( 'login' );

		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Entering the function with node id $node_id, locations: ".print_r($locations, true)." and user: $user_name",
										$label_debug );

		$ez_dms_file_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_file_node ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Node couldn't be loaded from id $node_id" ,
											$label_debug );
			return 1;
		}
		if ( $ez_dms_file_node->attribute( 'class_identifier' ) != 'ezdms_file' ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Wrong class: ".$ez_dms_file_node->attribute( 'class_identifier' )." for the node id $node_id" ,
											$label_debug );
			return 2;
		}
		$ez_dms_file_object = $ez_dms_file_node->attribute( 'object' );
		if ( !is_object( $ez_dms_file_object ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Object couldn't be loaded from the node id $node_id" ,
											$label_debug );
			return 3;
		}
		$object_id = $ez_dms_file_object->attribute( 'id' );
		$ez_dms_file_dm = $ez_dms_file_object->attribute( 'data_map' );
		if ( !is_array( $ez_dms_file_dm ) ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"Data map couldn't be loaded for the object of the node id $node_id" ,
											$label_debug );
			return 4;
		}
		if ( !$ez_dms_file_object->checkAccess( 'edit' ) &&
			 !$user->hasManageLocations() ) {

			eZDMSDebugTools::writeError(	$cond_debug,
											"User $user_name is not allowed to manage locations for the node $node_id" ,
											$label_debug );
			return 5;
		}
		$class = $ez_dms_file_object->contentClass();
		foreach( $locations as $parentNodeID ) {

			$parentNode = eZContentObjectTreeNode::fetch( $parentNodeID );
			if ( !$parentNode ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to read the location $node_id" ,
												$label_debug );
				return 6;
			}

			$parentNodeObject = $parentNode->attribute( 'object' );
			if ( !$parentNode ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to read the object that corresponds to the node $node_id" ,
												$label_debug );
				return 7;
			}

	        $canCreate = ( ( $parentNode->checkAccess( 'create', $class->attribute( 'id' ), $parentNodeObject->attribute( 'contentclass_id' ) ) == 1 ) ||
	                        ( $parentNode->canAddLocation() && $ez_dms_file_node->canRead() ) );
			if ( !$canCreate ) {
				eZDMSDebugTools::writeError(	$cond_debug,
												"User $user_name is not allowed to create such objects: '".$class->attribute( 'name' )."' for the node $node_id into the node $parentNodeID" ,
												$label_debug );
				return 8;
			}
	    }
		
		// We have to retrieve all non-main locations of the node
		$removeList = array();
		$hasChildren = false;
		foreach( $ez_dms_file_object->attribute( 'assigned_nodes' ) as $assigned_node ) {

			if ( $assigned_node->attribute( 'is_main' ) ) {
				continue;
			}

            // Security checks, removal of current node is not allowed
            // and we require removal rights
            if ( !$assigned_node->canRemove() &&
                 !$assigned_node->canRemoveLocation() ) {
                 
				eZDMSDebugTools::writeWarning(	$cond_debug,
												"User $user_name is not allowed to remove assigned node ". $assigned_node->attribute( 'node_id' ) ." from the node $node_id" ,
												$label_debug );
                continue;
            }

            $removeList[$assigned_node->attribute( 'node_id' )] = 1;
            $count = $assigned_node->childrenCount( false );

            if ( $count > 0 )
            {
                $hasChildren = true;
            }
		}
		
		if ( $hasChildren ) {
			eZDMSDebugTools::writeError(	$cond_debug,
											"Operation canceled because some of the assigned nodes of the node $node_id may have children" ,
											$label_debug );
			return 6;
		}
		
        if ( eZOperationHandler::operationIsAvailable( 'content_removelocation' ) )
        {
            $operationResult = eZOperationHandler::execute( 'content',
                                                            'removelocation', array( 'node_list' => array_keys( $removeList ) ),
                                                            null,
                                                            true );
        }
        else
        {
        	$db = eZDB::instance();
        	$db->begin();
        	foreach( $removeList as $removeItem => $value ) {
				eZContentObjectTreeNode::removeNode( $removeItem );
			}
			$db->commit();
        }
		
		// Then, let's try to add the specified locations
		if ( !$locations ) {
			$locations = array();
		}
			
        if ( eZOperationHandler::operationIsAvailable( 'content_addlocation' ) )
        {
			eZDMSDebugTools::writeNotice(	$cond_debug,
											"Adding the locations through eZOperationHandler::execute()",
											$label_debug );
            $operationResult = eZOperationHandler::execute( 'content',
                                                            'addlocation', array( 'node_id'              => $node_id,
                                                                                  'object_id'            => $object_id,
                                                                                  'select_node_id_array' => $locations ),
                                                            null,
                                                            true );
        }
        else
        {
			eZDMSDebugTools::writeNotice(	$cond_debug,
											"Adding the locations through eZContentOperationCollection::addAssignment()",
											$label_debug );
            eZContentOperationCollection::addAssignment( $node_id, $object_id, $locations );
        }
        
		eZDMSDebugTools::writeNotice(	$cond_debug,
										"Resulting assignements for the node id $node_id: ".print_r( $ez_dms_file_object->attribute( 'assigned_nodes' ), true ) ,
										$label_debug );

		return 0;
	}
	
}

?>
