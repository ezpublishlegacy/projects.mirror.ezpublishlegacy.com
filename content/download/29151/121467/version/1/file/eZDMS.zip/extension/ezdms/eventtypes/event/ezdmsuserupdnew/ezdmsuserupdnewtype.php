<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     20 february 2009
Last change on: 29 april 2010
Version:        1.1
Extension:		eZDMS
Description:    Each time an eZDMS staff is either published or updated, its 
				secondary locations are completely reset based upon some of its
				attributes:
					- entities
					- fonctions
				Warning: *all* secondary locations are removed, while the main
				location is untouched
				29 april 2010: eZ DMS Staff becomes eZ DMS User

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsusertools.php" );

class eZDMSUserUpdNewType extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_STRING = "ezdmsuserupdnew";

	protected $title;

    function eZDMSUserUpdNewType() {
    
        $this->title = "workflow " . eZDMSUserUpdNewType::WORKFLOW_TYPE_STRING;
		$this->eZWorkflowEventType( eZDMSUserUpdNewType::WORKFLOW_TYPE_STRING, 
									ezi18n( 'extension/ezdms/event', "eZ DMS Users locations" ) );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( /* 'before', */
                                                                               'after' ) ) ) );
    }

    function execute( $process, $event ) {
    
    	$cond_debug = false;	//'ezdms-workflow-' . eZDMSUserUpdNewType::WORKFLOW_TYPE_STRING;
    	$label_debug = "eZDMSUserUpdNewType::execute()";
    
        // get object and objectId
        $parameters = $process->attribute( 'parameter_list' );

		eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $process, true ), 
										$label_debug." process info: " );

        $objectId= $parameters['object_id'];
        // This is the actual object begin edited or created
        $object = eZContentObject::fetch( $parameters['object_id'] );

        if ( !$object ) {
        
            eZDMSDebugTools::writeError( $cond_debug,
										'The object with ID '.$parameters['object_id'].' does not exist.', 
										$label_debug.' object is unavailable' );
            return eZWorkflowType::STATUS_WORKFLOW_CANCELLED;
        }
		eZDMSDebugTools::writeNotice(	$cond_debug,
										print_r( $object, true ), 
										$label_debug." object: ".$object->attribute( 'name' ) );

        $class_identifier = $object->attribute( 'class_identifier' );
		eZDMSDebugTools::writeNotice(	$cond_debug,
										$class_identifier, 
										$label_debug." object's class identifier" );

		if ( $class_identifier == "ezdms_user" ) {
			$ret_code = eZDMSUserTools::set_locations( $object->attribute( 'main_node_id' ) );
			$msg = "Location not set (unknown error code: $ret_code)";
			switch( $ret_code ) {
			case 0:
				$msg = "Locations set correctly";
				break;
			case 1:
				$msg = "Locations not set: object not found";
				break;
			case 2:
				$msg = "Locations not set: wrong class identifier";
				break;
			case 3:
				$msg = "Locations not set: the user is not allowed to add locations";
				break;
			case 4:
				$msg = "Locations not set: could not find its data_map attribute";
				break;
			}
			eZDMSDebugTools::writeWarning(	$cond_debug,
											$msg, 
											$label_debug." object: ".$object->attribute( 'name' ) );
		}
		else {
			eZDMSDebugTools::writeWarning(	$cond_debug,
											"Invalid class identifier. Got: ".$ez_dms_folder_node->attribute( 'class_identifier' ), 
											$label_debug );
		}
		
        return eZWorkflowType::STATUS_ACCEPTED;
    }
    
}

eZWorkflowEventType::registerEventType( eZDMSUserUpdNewType::WORKFLOW_TYPE_STRING, "eZDMSUserUpdNewType" );

?>
