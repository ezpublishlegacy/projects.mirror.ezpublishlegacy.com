<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multiopplasting</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Filene er lastet opp til</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Velg filer</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Kunne ikke laste Flash-innhold. Du kan laste ned siste versjon av Flash Player fra</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alle filene er lastet opp.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Forhåndsvisning opprettet.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Starter...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
