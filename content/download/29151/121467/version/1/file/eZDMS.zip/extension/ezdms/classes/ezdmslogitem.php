<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2010 Open-net.ch
				cyp@open-net.ch

Created on:     05 july 2010
Last change on: 
Version:        1.0
Extension:		eZ DMS
Description:    This class handles eZDMSLogItem objects
History:		

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );

class eZDMSLogItem extends eZPersistentObject {

	const COND_DEBUG_STRING = 'ezdms-logitem';
	const BASE_DEBUG_LABEL = "eZDMSLogItem::";

	// Class constructor	
	function eZDMSLogItem( $row ) {
        $this->eZPersistentObject( $row );
	}
	
	// Class definitions
	static function definition() {
	
		return array(	'fields' => array(	'id' => array(	'name' => 'id',
															'datatype' => 'integer',
															'default' => 0,
															'required' => false ),
											'name' => array('name' => 'Name',
															'datatype' => 'string',
															'default' => '',
															'required' => false ),
											'hash' => array('name' => 'Hash',
															'datatype' => 'string',
															'default' => '',
															'required' => false ),
											'contentobject_id' => array(	'name' => 'contentobject_id',
																			'datatype' => 'integer',
																			'default' => '0',
																			'required' => false ),
											'contentobject_version' => array(	'name' => 'contentobject_version',
																				'datatype' => 'integer',
																				'default' => '0',
																				'required' => false ),
											'what_node_id' => array('name' => 'what_node_id',
																	'datatype' => 'integer',
																	'default' => 0,
																	'required' => false ),
											'what_object_id' => array(	'name' => 'what_object_id',
																		'datatype' => 'integer',
																		'default' => 0,
																		'required' => false ),
											'what_object_version' => array(	'name' => 'what_object_version',
																			'datatype' => 'integer',
																			'default' => '0',
																			'required' => false ),
											'what_object_state' => array(	'name' => 'Name',
																			'datatype' => 'string',
																			'default' => '',
																			'required' => false ),
											'what_linked_to_id' => array(	'name' => 'what_linked_to_id',
																			'datatype' => 'integer',
																			'default' => 0,
																			'required' => false ),
											'who_id' => array(	'name' => 'who_id',
																'datatype' => 'integer',
																'default' => 0,
																'required' => true ),
											'entry_timestamp' => array(	'name' => 'entry_timestamp',
																		'datatype' => 'integer',
																		'default' => 0,
																		'required' => true ),
											'comment' => array(	'name' => 'comment',
																'datatype' => 'text',
																'default' => '',
																'required' => false),
										 ),
						'keys' => array( 'id' ),
						'increment_key' => 'id',
						'sort' => array( 'id' => 'asc' ),
						'class_name' => 'eZDMSLogItem',
						'name' => 'ezdms_logitem'
					);
	
	}
	
	static public function create( $fields_array ) {

		// Say 'Hello' to the log...
    	$label_debug = eZDMSLogItem::BASE_DEBUG_LABEL."create()";
		eZDMSDebugTools::writeNotice(	eZDMSLogItem::COND_DEBUG_STRING,
										print_r($fields_array, true), 
										$label_debug );

		$myself = eZDMSLogItem::definition();
		$my_fields = $myself['fields'];

		$row = array();
		foreach( $fields_array as $field_name => $field_value ) {
		
			if ( isset( $my_fields[$field_name] ) ) {

				$row[$field_name] = $field_value;
			}
		}

		$logitem = new eZDMSLogItem( $row );
		if ( !is_object( $logitem ) ) {
		
			eZDMSDebugTools::writeError(	eZDMSLogItem::COND_DEBUG_STRING,
											"Unable to create a new eZ DMS Log Item", 
											$label_debug );
			return false;
		}
		$logitem->store();
		
		eZDMSDebugTools::writeNotice(	eZDMSLogItem::COND_DEBUG_STRING,
										"New eZ DMS Log Item created: ".print_r( $logitem, true ), 
										$label_debug );
										
		return true;
	}
	
	static public function fetchHistory( $object_id, $object_version=false, $sorts = null, $asObject=true, $offset = false, $limit = false ) {
	
		if ( $sorts == null ) {
		
			$sorts = array( 'id' => 'desc' );
		}

		$conds = array( 'what_object_id' => $object_id );
		if ( $object_version ) {
		
			$conds['what_object_version'] = array( '<=', $object_version );
			$sorts['what_object_version'] = 'desc';
		}
		
		$limitation = null;
		if ( $offset !== false or $limit !== false ) {
		
			$limitation = array( 'offset' => $offset, 'length' => $limit );
		}

		return eZPersistentObject::fetchObjectList(	eZDMSLogItem::definition(),
													null,
													$conds, $sorts, $limitation,
													$asObject );
	}

}

