<?php

/************************************************************/
/*                   DEBUT DES FONCTIONS                    */
/************************************************************/

function getWorkflowsInformation($id)
{
	$db = eZDb :: instance();
	$query = "SELECT wp.id as wp_id, w.id as wf_id "."FROM ezworkflow_process wp, ezworkflow w "."WHERE wp.workflow_id = w.id "."AND wp.id=$id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else
	{
		return false;
	}
}

function getCollaborationInformation($id)
{
	$db = eZDb :: instance();
	$query = "select workflow_process_id, collaboration_id "."from ezapprove_items "."where workflow_process_id = $id ";
	$result = $db->arrayQuery($query);
	if ($result)
	{
		return $result;
	}
	else
	{
		return false;
	}

}

function get_ezx_approve_status_list( $workflowprocess_id ) {
	$db = eZDb::instance();
	$query = "Select id, contentobject_id From ezx_approve_status Where workflowprocess_id=$workflowprocess_id";
	$result = $db->arrayQuery($query);
	if ( $result ) {
		$ids = array();
		$objs = array();
		foreach( $result as $record ) {
			$ids[]  = $record['id'];
			$objs[] = $record['contentobject_id'];
		}
		$result = array( 'ids' => $ids, 'objs' => $objs );
	}
	return $result; 
}

function get_ezx_approve_status_user_link_list( $workflowprocess_id ) {
	$db = eZDb::instance();
	$query = "SELECT `ezx_approve_status_user_link`.id FROM `ezx_approve_status_user_link`,`ezx_approve_status` 
WHERE `ezx_approve_status_user_link`.approve_id=`ezx_approve_status`.id 
and `ezx_approve_status`.workflowprocess_id=$workflowprocess_id";
	$result = $db->arrayQuery($query);
	if ( $result ) {
		$l = array();
		foreach( $result as $record ) {
			$l[] = $record['id'];
		}
		$result = $l;
	}	
	return $result; 
}

/************************************************************/
/*                   DEBUT DU SCRIPT                        */
/************************************************************/
require_once 'kernel/common/template.php';
$tpl = templateInit();
$p_id = $Params['process_id'];
$accept = $Params['accept'];

$http = eZHTTPTool::instance();
$list = $http->postVariable( 'BackButton' );
if ($list != null)
{
	return $Module->redirectToView( 'list', array( ) );
}

if (!is_numeric($p_id))
{
	return $Module->redirectToView('message', array ('error', 'null'));
}

$wi = getWorkflowsInformation($p_id);
if (!$wi)
{
	return $Module->redirectToView('message', array ('error', 'null'));
}

$result = array ();

if ($accept == 1)
{
	if ($p_id != 0)
	{
		$db = eZDb :: instance();
		if (!$db)
		{
			return $Module->redirectToView('message', array ('error', 'db'));
		}
		$db->begin();
		$real_workflow_process = eZWorkflowProcess :: fetch($wi[0]['wp_id']);

		$parameters = unserialize($real_workflow_process->attribute('parameters'));
		$object_id = $parameters['object_id'];
		$version_id = $parameters['version'];
		$object = eZContentObject :: fetch($object_id);
		$version = eZContentObjectVersion :: fetchVersion($version_id, $object_id);
		if (is_object($version))
		{
			$status = $version->attribute('status');
			if ($status == EZ_VERSION_STATUS_PENDING)
			{
				$version->setAttribute('status', EZ_VERSION_STATUS_DRAFT);
				$version->store();
			}
			$object->sync();
		}
		else
		{
			eZDebug :: writeError('No Version found for object '.$object_id.' - ('.$version_id.')', 'Workflow Board::Remove');
			eZDebug :: writeError($version, 'Workflow Board::Remove');
		}
		eZPersistentObject :: removeObject(eZOperationMemento :: definition(), array ('memento_key' => $real_workflow_process->attribute('memento_key')));
		$real_workflow_process->remove();

		/* "Suppression" de la collaboration*/
		$real_collaboration_item = getCollaborationInformation($wi[0]['wp_id']);
		eZDebug :: writeDebug($real_collaboration_item, "Collaboration items");
		foreach ($real_collaboration_item as $collab)
		{
			$collaboration_item = eZCollaborationItem :: fetch($collab['collaboration_id']);
			if (is_object($collaboration_item))
			{
				eZDebug :: writeDebug($collaboration_item, "Collaboration item");
				//$contentobject_id = $collaboration_item->attribut( 'data_int1' );
				$db->query('UPDATE ezcollab_item_status set is_active=0 WHERE collaboration_id = '.$collaboration_item->attribute('id'));
				$db->query('DELETE FROM ezapprove_items WHERE workflow_process_id = '.$p_id);
				$collaboration_item->sync();
			}
		}

/*	commented by cyp - 2010-05-13

		$list1 = get_ezx_approve_status_list( $p_id );
		$list2 = get_ezx_approve_status_user_link_list( $p_id );
		if ( $list1 ) {
			if ( $list1['ids'] ) {
				$db->query( 'Delete From ezx_approve_status Where id in (' . implode(',',$list1['ids']) . ')' );
			}
			if ( $list1['objs'] ) {
				$db->query( 'Update ezcontentobject_version Set status='.eZContentObjectVersion::STATUS_DRAFT.' Where contentobject_id in (' . implode(',',$list1['objs']) . ')' );
			}
		}
		if ( $list2 ) $db->query( 'Delete From ezx_approve_status_user_link Where id in (' . implode(',',$list2) . ')' );
*/

		$db->commit();
		return $Module->redirectToView('message', array ('success'));

	}
}
else
{
	if ($p_id != 0)
	{
		foreach ($wi as $w)
		{
			$real_workflow_process = eZWorkflowProcess :: fetch($w['wp_id']);
			$real_workflow = eZWorkflow :: fetch($w['wf_id']);
			$result[] = array ("process" => $real_workflow_process, "workflow" => $real_workflow);
		}
	}

	$view_parameters = array ('workflows' => $result);
	$tpl->setVariable('view_parameters', $view_parameters);

	$Result = array ();
	$Result['content'] = $tpl->fetch('design:workflowboard/remove.tpl');
	$Result['path'] = array (array ('url' => false, 'text' => ezi18n('workflowboard/translations', 'Workflow Board')), array ('url' => false, 'text' => ezi18n('workflowboard/translations', 'Stop process')));
}
?>

