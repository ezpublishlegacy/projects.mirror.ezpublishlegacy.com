<?php

$Module = array( 'name' => 'suggestkeyword' );

$ViewList = array();

/*
	in jsonkeywords.php, the q (and type)
	parameters are passed in a http querystring,
	by SuggestFramework
*/
$ViewList['jsonkeywords'] = array(
	'script' => 'jsonkeywords.php',
	'params' => array ( 
		'Offset', 
		'Limit'
	) 
);




/* 
	unused. ajax version of jsonkeywords.php
*/



$ViewList['ajaxkeywords'] = array(
	'script' => 'ajaxkeywords.php',
	'params' => array ( 
		'q',
		'Offset', 
		'Limit'
	) 
);

/*
	unused. ajax request, returning not
	the keywords, but the objects (id and name)
	matched by those keywords
*/

$ViewList['ajaxobjects'] = array(
	'script' => 'ajaxobjects.php',
	'params' => array ( 
		'q',
		'ClassID', 
		'Offset', 
		'Limit', 
		'Owner', 
		'ParentNodeID', 
		'IncludeDuplicates', 
		'StrictMatching' 
	) 
);

// Everything in this module is public
// $FunctionList['xxx'] 	= array( );

?>