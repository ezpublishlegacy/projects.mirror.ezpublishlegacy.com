<?php
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Author:         Yvon-Philippe Crittin
				(C) 2009 Open-net.ch

Created on:     24 march 2009
Last change on: 
Version:        1.0
Extension:		eZ DMS
Description:    Tools for eZ DMS Customer management
History:		

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$extension = 'ezdms';
$base = eZExtension::baseDirectory();
$baseDir = "$base/$extension/classes/";

include_once( $baseDir . "ezdmsdebugtools.php" );
include_once( $baseDir . "ezdmsfoldertools.php" );

class eZDMSCustomersTools {

	// Updates 
	static public function set_locations( $node_id ) {
		$ez_dms_cust_node = eZContentObjectTreeNode::fetch( $node_id );
		if ( !is_object( $ez_dms_cust_node ) ) {
			return 1;
		}
		if ( $ez_dms_cust_node->attribute( 'class_identifier' ) != 'ezdms_customers' ) {
			return 2;
		}
		if ( !$ez_dms_cust_node->canAddLocation() ) {
			return 3;
		}
		$ez_dms_cust_object = $ez_dms_cust_node->attribute( 'object' );
		if ( !is_object( $ez_dms_cust_object ) ) {
			return 3;
		}
		$content_object_id = $ez_dms_cust_object->attribute( 'id' );
		$ez_dms_cust_dm = $ez_dms_cust_object->attribute( 'data_map' );
		if ( !is_array( $ez_dms_cust_dm ) ) {
			return 4;
		}
		
		$db = eZDB::instance();
		$db->begin();
		
		// First, remove all locations except the main
		$main_node_id = $ez_dms_cust_node->attribute( 'main_node_id' );
        $query = "SELECT node_id FROM ezcontentobject_tree WHERE contentobject_id = $content_object_id and node_id <> $main_node_id";
        foreach( $db->arrayQuery( $query ) as $path ) {
			eZContentobjectTreeNode::removeNode( $path['node_id'] );
		}

		foreach( array( 'categories' ) as $attribute_name ) {
			if ( isset( $ez_dms_cust_dm[ $attribute_name ] ) ) {
				$attribute = $ez_dms_cust_dm[ $attribute_name ]->content();
				$list = $attribute[ 'relation_list' ];
				foreach( $list as $item ) {
					$new_loc = $ez_dms_cust_object->addLocation( $item[ 'node_id' ], true );
					$new_loc->updateSubTreePath();
					$new_loc->sync();
					
					eZUser::cleanupCache();
				}
			}
		} 

		$db->commit();
		
		return 0;
		
	}
}

