<!DOCTYPE TS><TS>
<context>
    <name>extension/ezvotecollector/template</name>
    <message>
        <source>Submit vote</source>
        <translation>Oddaj głos</translation>
    </message>
    <message>
        <source>View results</source>
        <translation>Pokaż wyniki</translation>
    </message>
    <message>
        <source>Choose</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Wartość</translation>
    </message>
    <message>
        <source>votes</source>
        <translation>głosów</translation>
    </message>
    <message>
        <source>average</source>
        <translation>średnia</translation>
    </message>
    <message>
        <source>range</source>
        <translation>zakres</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Podsumowanie</translation>
    </message>
    <message>
        <source>Vote count</source>
        <translation>Liczba głosów</translation>
    </message>
    <message>
        <source>Avarage</source>
        <translation>Średnia</translation>
    </message>
</context>
<context>
    <name>extension/ezvotecollector/message</name>
    <message>
        <source>Your vote has been successfully registered.</source>
        <translation>Twój głos został pomyślnie zarejestrowany.</translation>
    </message>
    <message>
        <source>Vote registration failed due to technical difficulties.</source>
        <translation>Rejestracja głosu nie powiodła się z powodów technicznych.</translation>
    </message>
    <message>
        <source>You haven't set any proper value. Try again.</source>
        <translation>Nie wybrano żadnej poprawnej wartości. Spróbuj ponownie.</translation>
    </message>
    <message>
        <source>No object was chosen!</source>
        <translation>Nie wybrano obiektu!</translation>
    </message> 
    <message>
        <source>Your vote has already been registered or this voting is closed at the moment.</source>
        <translation>Twój głos został już zarejestrowany lub to głosowanie jest chwilowo zamknięte.</translation>
    </message>
    <message>
        <source>Your vote has already been registered or failed to submit it.</source>
        <translation>Twój głos został już oddany lub oddanie nie powiodło się.</translation>
    </message>
</context>
</TS>