<?php /* 

[ExtensionSettings]
DesignExtensions[]=ezvotecollector

*/ ?>
