eZ Vote Collector extension for eZ Publish 4.0
version 0.93 stable



Written by Piotr Karaś ( http://www.mediaself.pl, http://ryba.eu )
------------------------------------------------------------------
This is my first extension ever, after only about three days spent with
eZ Publish API, which I love already. I would be grateful for any feedback,
bug reports, comments, suggestions, pointers...
  


What is eZ Vote Collector?
--------------------------

eZ Vote Collector is an eZ Publish extension which provides a collection 
of tools that can facilitate collecting and accessing simple one-dimensional 
user input. It is mostly appropriate for polls, grading, checklists, single
question answers.

In some ways it resembles eZ Publish information collection tools. 
Although it is considerably less complex and universal, it provides 
some useful and flexible options, that eZ mechanisms seem to lack. 
Above all, it makes it possible to define valid value range and user timeouts
based on object class. Also, a built in eZ Human CAPTCHA integration option
is available.
  
eZ Vote Collector is not an out-of-the-box poll or grading solution, although 
some templates and packages are planned to be delivered in the following 
versions. Nevertheless, it should be very easy to implement and use.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



eZ Vote Collector features
--------------------------
- Collect simple numerical values along with user, object, attribute, 
  class, time information
- One module view responsible for collecting data and redirecting
- Dedicated module function for easier access policy management 
- Define default timeout for all types of votes 
  (how long it takes before users can vote again)
- Define class-based timeouts
- Define classes with no timeout (one vote ever can be submitted)
- Define default value range for all types of votes
  (for example: only votes 1-5 will be accepted for poll class)
- Define class-based value range
- Define classes with no value range
  (any unsigned number in integer range will be allowed) 
- Fetch vote lists/counts based on any combination of user, object, 
  attribute and class in templates
- Fetch result collection arrays in templates
- Provide templates with information whether given user may vote, 
  based on vote parameters
- Additional attributeID field for separating multiple vote collections
  belonging to one object
- Fetch valid range array for templates



Template operators
------------------

ezvote_count(
	[$objectID=false] 
	[,$attributeID=false] 
	[,$userID=false]
	[,$classID=false]
)
Returns a number of vote entries matching the criteria (parameters). 
Counts ezvote_list operator results.

ezvote_list(
	[$objectID=false]
	[,$attributeID=false] 
	[,$userID=false]
	[,$classID=false]
)
Returns an array of vote entries matching the criteria (parameters). 
Lists ezvote_count operator count.

ezvote_canvote(
	$objectID 
	[,$attributeID=false]
)
Checks if the current user can vote, based on $objectID or $objectID 
and $attributeID.

ezvote_collection(
	[$objectID=false]
	[,$attributeID=false] 
	[,$orderByValues=true] 
	[,$orderSort=true]
)
Returns an array (value=>count) of results matching given criteria. 
It is possible to sort results by values or value counts.

ezvote_range(
	$objectID
)
Returns an ordered array of valid range values or false on failure. 

ezvote_topcontent(
    $results
    ,$classIDArray 
    [,$timespan=false] 
    [,$identifier=false]
    [,$skipObjectIDArray=false]
    [,$minCount=false]
)
Returns top content list of objects.


ezvote_resultcollection() @TODO


Requirements
------------
- eZ Publish 4.0.0+
- MySQL database 4.1/5.0+ with UTF-8 support
- DB administration access with CREATE permission



Tested with
-----------
4.0.0beta1
4.0.0rc1
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezvotecollector/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezvotecollector

3. Run SQL query from /extension/ezvotecollector/sql/schema.sql 
into the eZ Publish database. New, empty ezvotecollector_data table 
will be created.

4. Configure ezvote.ini file according to your preferences.

5. Log in (anonymous users should not be allowed by default!).

6. Clear cache.



Template example
----------------
In article (or any other) template, simply add:
{include uri='design:ezvote/vote.tpl' eZVoteNode=$node eZVoteIdentifier='grade'}

For details, go to and play with:
/extension/ezvotecollector/design/standard/templates/ezvote/*.tpl



Questions and answers
---------------------

1. Does it support anonymous user votes?
Although it is technically possible to let anonymous users vote, the extension 
does not provide ANY session-based mechanisms to prevent double votes, 
and it will not in the future. UserID is the only piece of information used 
to identify and distinguish users, hence the extension is dedicated for 
environments which favor login requirement.

2. Why eZ Publish 4.0, if it is not stable yet?
Want to be ready for stable ;)


Plans, ideas...
---------------
- Add limit and skip parameters to ezvote_list operator for result portioning
- Use more object persistency in eZVoteData class



Changelog
---------

# Suggestions:
- Requires global rewriting for version 1.0

# v0.93 stable, public, 2008.05.21
+ Fetch top content subtree parameter.

# v0.92 stable, public, 2008.05.16
+ Bug fix: make top content operator object status sensitive.

# v0.91 stable, public, 2008.05.15
+ Additional resultcollection operator.

# v0.9 stable, public, 2008.05.10
+ Additional topcontent operator parameter for skipping results with small
  amount of votes.

# v0.8 stable, public, 2008.05.08
+ Additional operator for getting top content lists.
+ Advanced top content settings.

# v0.7 stable, public, 2008.02.11
+ Session-based vote block for less restrictive collecting methods (in addition
  to user/databased method).

# v0.6 stable, public, 2008.01.31
+ Built-in integration option with eZ Human CAPTCHA extension for standard
  submit view.
+ Minor cleaning up developer's notes ;) 
+ Standard submit view keeps last POST value selected.

# v0.5 beta, public, 2008.01.06
+ Cronjob for synchronization with content class attributes.
+ Move all operators to one operator class.
+ Add Polish translation.
+ Fix bug: range validation missing in the submit view.
+ Integer AttributeID changed to string Identifier for easier management.
+ Security/limiting functionality: only registered combinations of class
  identifier and voting identifier will be allowed.
+ Default templates arranged for popup configuration.
+ Add logging and debugging for critical areas.

# v0.4 beta, public, 2007.12.02
+ Fix bug: Class id/identifier confused, class-based range configuration doesn't
  work properly
+ Change/fix bug: UserID and ClassID parameters removed from ezvote_collection 
  template operator (goal incompatibility ;)
+ Minor corrections in the readme file
+ Improved example template

# v0.3 alpha, public, 2007.11.23
+ Clean up of passing by reference related PHP errors.
+ Clean up of other strict PHP warnings.
+ Review of the entire object model used.
+ Stronger validation of parameters passed to public methods.
+ eZVoteData::create - userID and classID should not be passed, 
  but should be evaluated!
+ Complete basic submit view of the module.
+ Range validation wrong check order - fixed.
+ Add module/view translation.
+ Success/failure redirections.
+ Add ezvote_range template operator.

# v0.2 alpha, local, 2007.11.22
+ Initial working version with a number of issues that need fixing before 
  pushing it public.

# v0.1 alpha, local, 2007.11.21
+ First prototype, almost entirely rethought and rebuilt ;)

# v0.0 alpha, local, 2007.11.20
+ Start.


/+/ complete
/-/ plan or in progress



