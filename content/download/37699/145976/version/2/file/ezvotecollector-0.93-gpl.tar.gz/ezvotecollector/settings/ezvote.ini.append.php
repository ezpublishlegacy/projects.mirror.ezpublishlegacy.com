<?php /* 

[GeneralSettings]

# A list of allowed vote identifier per class.
# Identifiers (string, semicolor-separated, 20 characters max each) 
# need to be used to tell one voting
# within same class from another (for example, if for one content object/node
# you want to grade few features, for example 'quality', 'usability' etc..).
#
# Note: this has also a major security importance - only declared combinations
# of class identifiers and vote identifiers will successfully register votes!
IdentifiersByClassIdentifier[]
IdentifiersByClassIdentifier[recipe_user]=grade;
IdentifiersByClassIdentifier[recipe_redactor]=grade;
IdentifiersByClassIdentifier[photo_item]=grade;
IdentifiersByClassIdentifier[film]=grade;


# Timeout settings.
# It is possible to have based-on-class timeouts, but it is impossible
# to set different timeouts for different identifiers within same class. 

# If any useful combination of the following values
# or variables are missing, the module will use "false" as default value 
# for all classes, which means each user will only be able to vote once
# for any given object ID.
[TimeoutSettings]

# Default method of blocking re-voting
# Possible values: database|session
DefaultBlockMethod=database

# Blocking methods per class.
ClassBlockMethod[recipe_user]=session
ClassBlockMethod[recipe_redactor]=session
ClassBlockMethod[photo_item]=session
ClassBlockMethod[film]=session

# Global default timeout in seconds.
DefaultTimeout=86400

# Timeout per class in seconds, requires class id.
ClassTimeout[]
#ClassTimeout[article]=600


# No timeout per class - semicolon separated IDs of classes for which 
# only one vote ever is allowed.
NoTimeoutClasses=poll;flash

# Value range settings.
# Note: First has to be smaller or equal second!
[ValueSettings]

DefaultValueRange=1,5

# Minimum and maximum values of votes
ClassValueRange[]
ClassValueRange[x]=1,10

# No value range classes
NoValueRangeClasses=poll;flash



# The collector can be used with no synchronization/cronjobs, if it is only 
# supposed to gather and display information. However, if you need some more
# advanced features, such as sorting by the average, then synchronization
# is of much help. 
#
# It simply makes use of the cronjobs to periodically copy
# data collected for a given class' objects to one of its attributes.
# The operation will only be performed on current versions of the object, which
# means that you will be able to see value progress across diffrent object's
# versions.

[SynchronizeSettings]

# An array of class attribute IDs for which synchronization will be performed.
# Format: [identifier;attributeID;type]
# Available types: average (default), sum, count
# Average will be multiplied by 100 and rounded, in order to fit integer.
SynchronizeMap[]
SynchronizeMap[]=grade;511;average
SynchronizeMap[]=grade;513;average
SynchronizeMap[]=grade;510;average
SynchronizeMap[]=grade;509;average

# An array of datatypes that will be allowed to receive data.
# By default, this should only be integer or a custom made integer-like 
# datatype.
SynchronizeDatatypes[]
SynchronizeDatatypes[]=ezinteger



[eZHumanCAPTCHASettings]

# eZ Human CAPTCHA extension integration. Requires the extension installed.

# If set to true, automatic CAPTCHA code will be required in the main submit
# view. 
IntegrationEnabled=false


*/ ?>
