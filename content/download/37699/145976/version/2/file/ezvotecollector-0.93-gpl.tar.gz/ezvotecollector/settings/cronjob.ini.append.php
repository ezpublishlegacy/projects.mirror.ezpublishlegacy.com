<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezvotecollector

[CronjobPart-ezvote]
Scripts[]=ezvotecollector_synchronize.php

*/ ?>
