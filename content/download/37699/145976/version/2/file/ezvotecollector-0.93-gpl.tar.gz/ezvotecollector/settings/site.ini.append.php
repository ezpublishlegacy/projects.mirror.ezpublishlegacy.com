<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezvotecollector

[RegionalSettings]
TranslationExtensions[]=ezvotecollector

*/ ?>
