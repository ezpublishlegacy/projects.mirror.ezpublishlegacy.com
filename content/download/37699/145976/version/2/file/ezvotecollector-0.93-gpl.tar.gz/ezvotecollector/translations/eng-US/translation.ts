<!DOCTYPE TS><TS>
<context>
    <name>extension/ezvotecollector/template</name>
    <message>
        <source>Submit vote</source>
        <translation>Submit vote</translation>
    </message>
    <message>
        <source>View results</source>
        <translation>View results</translation>
    </message>
    <message>
        <source>Choose</source>
        <translation>Choose</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Value</translation>
    </message>
    <message>
        <source>votes</source>
        <translation>votes</translation>
    </message>
    <message>
        <source>average</source>
        <translation>average</translation>
    </message>
    <message>
        <source>range</source>
        <translation>range</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Summary</translation>
    </message>
    <message>
        <source>Vote count</source>
        <translation>Vote count</translation>
    </message>
    <message>
        <source>Avarage</source>
        <translation>Avarage</translation>
    </message>
</context>
<context>
    <name>extension/ezvotecollector/message</name>
    <message>
        <source>Your vote has been successfully registered.</source>
        <translation>Your vote has been successfully registered.</translation>
    </message>
    <message>
        <source>Vote registration failed due to technical difficulties.</source>
        <translation>Vote registration failed due to technical difficulties.</translation>
    </message>
    <message>
        <source>You haven't set any proper value. Try again.</source>
        <translation>You haven't set any proper value. Try again.</translation>
    </message>
    <message>
        <source>No object was chosen!</source>
        <translation>No object was chosen!</translation>
    </message> 
    <message>
        <source>Your vote has already been registered or this voting is closed at the moment.</source>
        <translation>Your vote has already been registered or this voting is closed at the moment.</translation>
    </message> 
</context>
</TS>
