<?php

/**
 * eZ Vote Collector extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class eZVoteCollectorTemplateOperator {


    var $Operators;


    /**
     * Enter description here...
     *
     * @param unknown_type $name
     */
    function __construct()
    {
        $this->Operators = array(
            'ezvote_canvote', 
            'ezvote_count', 
            'ezvote_list', 
            'ezvote_collection', 
            'ezvote_range', 
            'ezvote_getstats',
            'ezvote_topcontent',
            'ezvote_resultcollection'
            );
    }


    /**
     * Enter description here...
     *
     * @return unknown
     */
    function &operatorList()
    {
        return $this->Operators;
    }


    /**
     * Enter description here...
     *
     * @return unknown
     */
    function namedParameterPerOperator()
    {
        return true;
    }


    /**
     * Enter description here...
     *
     * @return unknown
     */
    function namedParameterList()
    {
        return array(
			'ezvote_canvote' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
        ),
				'identifier' => array(  
					'type' => 'string',
					'required' => true,
					'default' => false,
        ),
        ),
			'ezvote_getstats' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
        ),
				'identifier' => array(  
					'type' => 'string',
					'required' => true,
					'default' => false,
        ),
        ),
			'ezvote_count' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
				'identifier' => array(  
					'type' => 'string',
					'required' => false,
					'default' => false,
        ),
				'user_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
				'class_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
        ),
			'ezvote_list' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
				'identifier' => array(  
					'type' => 'string',
					'required' => false,
					'default' => false,
        ),
				'user_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
				'class_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
        ),
			'ezvote_collection' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => false,
					'default' => false,
        ),
				'identifier' => array(  
					'type' => 'string',
					'required' => false,
					'default' => false,
        ),
				'order_by_values' => array(  
					'type' => 'boolean',
					'required' => false,
					'default' => true,
        ),
				'order_desc' => array(  
					'type' => 'boolean',
					'required' => false,
					'default' => true,
        ),
        ),
			'ezvote_range' => array(
				'object_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
        ),
        ),
            'ezvote_resultcollection' => array(
                'object_id_array' => array(  
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
                'identifier' => array(  
                    'type' => 'string',
                    'required' => false,
                    'default' => false,
        ),
                'max_value' => array(  
                    'type' => 'integer',
                    'required' => false,
                    'default' => 1,
        ),
        ),
            'ezvote_topcontent' => array(
                'results' => array(  
                    'type' => 'integer',
                    'required' => true,
                    'default' => 0,
        ),
                'class_id_array' => array(  
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
                'timespan' => array(  
                    'type' => 'integer',
                    'required' => false,
                    'default' => false,
        ),
                'identifier' => array(  
                    'type' => 'string',
                    'required' => false,
                    'default' => false,
        ),
                'skip_object_id_array' => array(  
                    'type' => 'array',
                    'required' => false,
                    'default' => false,
        ),
                'min_count' => array(  
                    'type' => 'integer',
                    'required' => false,
                    'default' => false,
        ),
                'subtree' => array(  
                    'type' => 'string',
                    'required' => false,
                    'default' => false,
        ),
        ),
        );
    }


    /**
     * Enter description here...
     *
     * @param unknown_type $tpl
     * @param unknown_type $operatorName
     * @param unknown_type $operatorParameters
     * @param unknown_type $rootNamespace
     * @param unknown_type $currentNamespace
     * @param unknown_type $operatorValue
     * @param unknown_type $namedParameters
     */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        include_once('extension/ezvotecollector/classes/ezvotedata.php');

        switch( $operatorName )
        {
            case 'ezvote_canvote':
                $objectID = $namedParameters['object_id'];
                $identifier = $namedParameters['identifier'];
                $operatorValue = eZVoteData::canVote( $objectID, $identifier );
                break;

            case 'ezvote_getstats':
                $objectID = $namedParameters['object_id'];
                $identifier = $namedParameters['identifier'];
                $operatorValue = eZVoteData::getStats( $objectID, $identifier );
                break;

            case 'ezvote_count':
                $objectID = $namedParameters['object_id'];
                $identifier = $namedParameters['identifier'];
                $userID = $namedParameters['user_id'];
                $classID = $namedParameters['class_id'];
                $operatorValue = eZVoteData::fetchListCount( $objectID, $identifier, $userID, $classID );
                break;

            case 'ezvote_list':
                $objectID = $namedParameters['object_id'];
                $identifier = $namedParameters['identifier'];
                $userID = $namedParameters['user_id'];
                $classID = $namedParameters['class_id'];
                $operatorValue = eZVoteData::fetchList( $objectID, $identifier, $userID, $classID, true );
                break;

            case 'ezvote_resultcollection':
                $objectIDArray = $namedParameters['object_id_array'];
                $identifier = $namedParameters['identifier'];
                $maxValue = $namedParameters['max_value'];
                $operatorValue = eZVoteData::fetchResultCollection( $objectIDArray, $identifier, $maxValue );
                break;

            case 'ezvote_collection':
                $objectID = $namedParameters['object_id'];
                $identifier = $namedParameters['identifier'];
                $orderByValues = $namedParameters['order_by_values'];
                $orderDesc = $namedParameters['order_desc'];
                $operatorValue = eZVoteData::fetchCollection( $objectID, $identifier, $orderByValues, $orderDesc );
                break;

            case 'ezvote_range':
                $objectID = $namedParameters['object_id'];
                $operatorValue = eZVoteData::getRange( $objectID );
                break;

            case 'ezvote_topcontent':
                $results = $namedParameters['results'];
                $classIDArray = $namedParameters['class_id_array'];
                $timespan = $namedParameters['timespan'];
                $identifier = $namedParameters['identifier'];
                $skipObjectIDArray = $namedParameters['skip_object_id_array'];
                $minCount = $namedParameters['min_count'];
                $subtree = $namedParameters['subtree'];
                $operatorValue = eZVoteData::fetchTopContent( $results, $classIDArray, $timespan, $identifier, $skipObjectIDArray, $minCount, $subtree );
                break;
        }
    }


};

?>
