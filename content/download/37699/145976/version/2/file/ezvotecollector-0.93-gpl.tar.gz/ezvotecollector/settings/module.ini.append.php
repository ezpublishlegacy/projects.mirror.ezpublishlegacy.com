<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezvotecollector

*/ ?>
