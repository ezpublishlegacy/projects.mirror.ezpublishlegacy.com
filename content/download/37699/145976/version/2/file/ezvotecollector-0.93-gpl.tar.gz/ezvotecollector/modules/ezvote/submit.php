<?php

/**
 * eZ Vote Collector extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


include_once( 'kernel/common/template.php' );
include_once( 'extension/ezvotecollector/classes/ezvotedata.php' );

$http = eZHTTPTool::instance();
$ini = eZINI::instance('ezvote.ini');
$tpl = templateInit();

$Module = $Params['Module'];
$Result = array();

$captchaINI = $ini->group( 'eZHumanCAPTCHASettings' );

$currentSelection = false;
$statusMessages = array();
$success = false;
if( $http->hasPostVariable( 'eZVoteCollectorSubmit' ) )
{
    if( $http->hasPostVariable( 'eZVoteCollectorValue' ) )
    {
        $currentSelection = $http->postVariable( 'eZVoteCollectorValue' );
    }
    if( $http->hasPostVariable( 'eZVoteCollectorValue') )
    {
        if( $captchaINI['IntegrationEnabled'] == 'true' )
        {
            $eZHumanCAPTCHAValidation = eZHumanCAPTCHATools::validateHTTPInput();
            if ( count( $eZHumanCAPTCHAValidation ) )
            {
                $statusMessages = $eZHumanCAPTCHAValidation;  //ezi18n( 'extension/ezvotecollector/message', 'Vote registration failed due to technical difficulties.' );
            }
        }
        if( !count( $statusMessages ) )
        {
            if( $http->hasPostVariable( 'eZVoteCollectorObjectID' ) && $http->hasPostVariable( 'eZVoteCollectorValue' ) )
            {
                $identifier = $http->variable( 'eZVoteCollectorIdentifier' );
                $objectID = $http->variable( 'eZVoteCollectorObjectID' );
                if( eZVoteData::canVote( $objectID, $identifier ) )
                {
                    $value = $http->variable( 'eZVoteCollectorValue' );
                    if( eZVoteData::validateValue( $value, $objectID ) )
                    {
                        if( $eZVoteObject = eZVoteData::create($value, $objectID, $identifier ) )
                        {
                            $eZVoteObject->store();
                            eZVoteData::addBlock( $objectID, $identifier );
                            $statusMessages[] = ezi18n( 'extension/ezvotecollector/message', 'Your vote has been successfully registered.' );
                            $success = true;
                        }
                        else
                        {
                            $statusMessages[] = ezi18n( 'extension/ezvotecollector/message', 'Vote registration failed due to technical difficulties.' );
                        }
                    }
                    else
                    {
                        $statusMessages[] = ezi18n( 'extension/ezvotecollector/message', 'You haven\'t set any proper value. Try again.' );
                    }
                }
                else
                {
                    $statusMessages[] = ezi18n( 'extension/ezvotecollector/message', 'Your vote has already been registered or this voting is closed at the moment.' );
                }
            }
            else
            {
                $statusMessages[] = ezi18n( 'extension/ezvotecollector/message', 'No object chosen.' );
            }
        }
    }
}

if( $http->hasPostVariable( 'eZVoteCollectorRedirect' ) )
{
    if( $http->postVariable( 'eZVoteCollectorRedirect' ) == 'true' )
    {
        if( $success )
        {
            if( $http->hasPostVariable( 'eZVoteCollectorRedirectOnSuccess' ) )
            {
                $http->redirect( $http->variable( 'eZVoteCollectorRedirectOnSuccess' ) );
            }
        }
        else
        {
            if( $http->hasPostVariable( 'eZVoteCollectorRedirectOnFailure' ) )
            {
                $http->redirect( $http->variable( 'eZVoteCollectorRedirectOnFailure' ) );
            }
        }
    }
}

$tpl->setVariable( 'eZVoteCurrentSelection', $currentSelection );
$tpl->setVariable( 'eZVoteSubmitSuccess', $success );
$tpl->setVariable( 'eZVoteStatusMessages', $statusMessages );
$tpl->setVariable( 'eZVoteParamsNodeID', $Module->NamedParameters['NodeID'] );
$tpl->setVariable( 'eZVoteParamsIdentifier', $Module->NamedParameters['Identifier'] );
$Result['pagelayout'] = 'design:ezvote/submit_pagelayout.tpl';
$Result['content'] = $tpl->fetch('design:ezvote/submit.tpl');


?>