<?php

/**
 * eZ Vote Collector extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class eZVoteData extends eZPersistentObject
{


    const EZVOTE_DEBUG = 1;


    /**
     * Constructor. Initiates a persistent object with values.
     *
     * @param array $row
     */
    public function __construct( $row )
    {
        $this->eZPersistentObject( $row );
    }


    /**
     * Persistent object definition array
     *
     * @return array
     */
    public static function definition()
    {
        return array(
			'fields' => array(
				'id' => array( 
					'name' => 'ID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true,
        ),
				'value' => array( 
					'name' => 'Value',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true, 
        ),
				'object_id' => array(
					'name' => 'ObjectID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true, 
        ),
				'identifier' => array(
					'name' => 'Identifier',
					'datatype' => 'string',
					'default' => '',
					'required' => true, 
        ),
				'user_id' => array(
					'name' => 'UserID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true,
        ),
				'class_id' => array(
					'name' => 'ClassID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true,
        ),
				'created' => array(
					'name'  => 'Created',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true,
        ),
        ),
			'keys'=> array(
				'id' 
				),
			'increment_key' => 'id',
			'class_name' => 'eZVoteData',
			'name' => 'ezvotecollector_data' 
			);
    }


    /**
     * Creates new vote entry based on parameters. All parameters are required.
     *
     * @param integer $value
     * @param integer $objectID
     * @param string $identifier
     * @return new vote entry persistent object
     */
    public static function create( $value, $objectID, $identifier )
    {
        eZVoteData::validateInteger( $value );
        eZVoteData::validateInteger( $objectID );

        if( $classID = eZVoteData::getClassId( $objectID ) )
        {
            $row = array(
				'id' => null,
		        'value' => $value,
                'object_id' => $objectID,
                'identifier' => $identifier,
                'user_id' => eZUser::currentUserID(),
                'class_id' => $classID,
                'created' => time() 
            );
            return new eZVoteData( $row );
        }

        return false;
    }


    /**
     * Gets class ID for object of a given objectID.
     * Returns false on failure.
     *
     * @param integer $objectID
     * @return string
     */
    static function getClassId( $objectID )
    {
        eZVoteData::validateInteger($objectID);
        $object = eZContentObject::fetch( $objectID );
        if ( !$object )
        {
            return false;
        }
        if ( !$object->attribute( 'can_read' ) )
        {
            return false;
        }
        return $object->ClassID;
    }


    /**
     * Gets class identifier for object of a given objectID.
     * Returns false on failure.
     *
     * @param integer $objectID
     * @return string
     */
    static function getClassIdentifierByObjectID( $objectID )
    {
        eZVoteData::validateInteger( $objectID );
        $object = eZContentObject::fetch( $objectID );
        if ( !$object )
        {
            return false;
        }
        if ( !$object->attribute( 'can_read' ) )
        {
            return false;
        }
        return $object->ClassIdentifier;
    }


    /**
     * Evaluates value range string, based on configuration files and class identifier.
     * Returns default integer range if defined as "no value range".
     * Returns false on failure.
     *
     * @param string $classIdentifier
     * @return string
     */
    private static function getRangeString ( $classIdentifier )
    {

        include_once( "lib/ezutils/classes/ezini.php" );
        $ini = eZINI::instance('ezvote.ini');

        $rangeString = false;

        if( $ini->hasVariable( 'ValueSettings', 'DefaultValueRange' ) )
        {
            $rangeString = $ini->variable( 'ValueSettings', 'DefaultValueRange' );
        }

        if( $ini->hasVariable( 'ValueSettings', 'ClassValueRange' ) )
        {
            $iniClassRangeArray = $ini->variable( 'ValueSettings', 'ClassValueRange' );
            if(in_array( $classIdentifier, array_keys( $iniClassRangeArray ) ) )
            {
                $rangeString = $iniClassRangeArray[$classIdentifier];
            }
        }

        if( $ini->hasVariable( 'TimeoutSettings', 'NoValueRangeClasses' ) )
        {
            $iniNoValueRangeClasses = $ini->variable( 'TimeoutSettings', 'NoValueRangeClasses' );
            $iniNoValueRangeClassesArray = explode( ';' , $iniNoValueRangeClasses );
            foreach( $iniNoValueRangeClassesArray as $k => $v )
            {
                $iniNoValueRangeClassesArray[$k] = trim($v);
            }
            if( in_array( $classIdentifier, $iniNoValueRangeClassesArray ) )
            {
                $rangeString = '0,2147483647';
            }
        }

        return $rangeString;

    }


    public static function getStats( $objectID, $identifier )
    {
        $db = eZDB::instance();
        $resultArray = array();

        $range = self::getRange( $objectID );
        $resultArray['range'] = array(
            'min' => min( $range), 
            'max' => max( $range), 
        );

        $query = "SELECT COUNT(id) AS count, SUM(value) as sum
        	FROM ezvotecollector_data 
        	WHERE object_id=".(int)$objectID." 
        	AND identifier='".$db->escapeString( $identifier )."' ";

        if( self::EZVOTE_DEBUG )
        eZDebug::writeDebug('Query: '.$query, 'eZVoteData::getStats');

        $rows = $db->arrayQuery( $query );

        $resultArray['stats']['sum'] = (integer)$rows[0]['sum'];
        $resultArray['stats']['count'] = (integer)$rows[0]['count'];
        if( $rows[0]['count'] )
        {
            $resultArray['stats']['average'] = round( $resultArray['stats']['sum']/$resultArray['stats']['count'], 2 );
        }
        else
        {
            $resultArray['stats']['average'] = (float)0;
        }

        return $resultArray;
    }


    /**
     * Gets range array of a vote collecton, based on objectID
     *
     * @param integer $objectID
     * @return array
     */
    static function getRange( $objectID )
    {

        eZVoteData::validateInteger($objectID);

        $classIdentifier = eZVoteData::getClassIdentifierByObjectID( $objectID );
        if ( !$classIdentifier ) {
            return false;
        }

        $rangeString = eZVoteData::getRangeString( $classIdentifier );
        $rangeArray = array();

        if( $rangeString ) {
            $rangeStringArray = explode(',', $rangeString);
            foreach($rangeStringArray as $k => $v)
            {
                $rangeStringArray[$k] = (int)trim($v);
            }
            for( $s=$rangeStringArray[0]; $s<=$rangeStringArray[1]; $s++ )
            {
                array_push( $rangeArray, $s );
            }
        }

        return $rangeArray;
    }


    /**
     * Verifies if the vote value is valid againts configuration range settings.
     *
     * @param integer $value
     * @param integer $objectID
     * @return boolean
     */
    static function validateValue( $value, $objectID )
    {
        eZVoteData::validateInteger($value);
        eZVoteData::validateInteger($objectID);

        $classIdentifier = eZVoteData::getClassIdentifierByObjectID( $objectID );
        if ( !$classIdentifier ) {
            return false;
        }

        $rangeString = eZVoteData::getRangeString( $classIdentifier );

        if( $rangeString ) {
            $rangeStringArray = explode(',', $rangeString);
            foreach( $rangeStringArray as $k => $v )
            {
                $rangeStringArray[$k] = (int)trim($v);
            }
            if( $value >= $rangeStringArray[0] && $value <= $rangeStringArray[1] )
            {
                return true;
            }
        }

        return false;
    }


    /**
     * Verifies if current user can submit vote, based on objectID,
     * and optionally on Identifier
     *
     * @param integer $objectID
     * @param string $identifier
     * @return boolean
     */
    static function canVote ( $objectID, $identifier )
    {
         
        eZVoteData::validateInteger($objectID);

        $classIdentifier = eZVoteData::getClassIdentifierByObjectID( $objectID );
        if ( !$classIdentifier ) {
            return false;
        }

        include_once('kernel/classes/datatypes/ezuser/ezuser.php');
        $userID = eZUser::currentUserID();

        include_once( "lib/ezutils/classes/ezini.php" );
        $ini = eZINI::instance('ezvote.ini');

        $generalINI = $ini->group( 'GeneralSettings' );
        if( !isset( $generalINI['IdentifiersByClassIdentifier'][$classIdentifier] ) )
        {
            return false;
        }

        $identifiersByClassIdentifier = explode( ';', $generalINI['IdentifiersByClassIdentifier'][$classIdentifier] );
        $allowedIdentifiers = array();
        foreach( $identifiersByClassIdentifier as $iniIdentifier )
        {
            $iniIdentifier = trim( $iniIdentifier );
            if( $iniIdentifier )
            {
                array_push( $allowedIdentifiers, $iniIdentifier );
            }
        }
        if( !in_array( $identifier, $allowedIdentifiers ) )
        {
            return false;
        }


        $timeout = (int)$ini->variable( 'TimeoutSettings', 'DefaultTimeout' );

        if( $ini->hasVariable( 'TimeoutSettings', 'ClassTimeout' ) )
        {
            $iniClassTimeoutArray = $ini->variable( 'TimeoutSettings', 'ClassTimeout' );
            if(in_array($classIdentifier, array_keys($iniClassTimeoutArray)))
            {
                $timeout = (int)$iniClassTimeoutArray[$classIdentifier];
            }
        }

        if( $ini->hasVariable( 'TimeoutSettings', 'NoTimeoutClasses' ) )
        {
            $iniNoTimeoutClasses = $ini->variable( 'TimeoutSettings', 'NoTimeoutClasses' );
            $iniNoTimeoutClassesArray = explode( ';' , $iniNoTimeoutClasses );
            foreach($iniNoTimeoutClassesArray as $k => $v)
            {
                $iniNoTimeoutClassesArray[$k] = trim($v);
            }
            if(in_array($classIdentifier, $iniNoTimeoutClassesArray))
            {
                $timeout = false;
            }
        }


        $blockMethod = $ini->variable( 'TimeoutSettings', 'DefaultBlockMethod' );

        if( $ini->hasVariable( 'TimeoutSettings', 'ClassBlockMethod' ) )
        {
            $iniClassBlockMethodArray = $ini->variable( 'TimeoutSettings', 'ClassBlockMethod' );
            if(in_array($classIdentifier, array_keys($iniClassBlockMethodArray)))
            {
                $blockMethod = $iniClassBlockMethodArray[$classIdentifier];
            }
        }

        if( $blockMethod == 'session' )
        {
            if( $timeout || $timeout === 0 )
            {
                $http = eZHTTPTool::instance();
                if( $http->hasSessionVariable( 'eZVoteBlock' ) )
                {
                    $eZVoteBlock = $http->sessionVariable( 'eZVoteBlock' );
                    if( !is_array( $eZVoteBlock ) )
                    {
                        $eZVoteBlock = array();
                    }
                    $blockID = md5( $objectID . $identifier );
                    if( in_array( $blockID, array_keys( $eZVoteBlock ) ) )
                    {
                        if( $eZVoteBlock[$blockID] < time() )
                        {
                            unset( $eZVoteBlock[$blockID] );
                            $http->setSessionVariable( 'eZVoteBlock', $eZVoteBlock );
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        if( $blockMethod == 'database' )
        {
            $db = eZDB::instance();
            $query = "SELECT COUNT(id) AS count FROM ezvotecollector_data
        	WHERE user_id=".$userID." 
            AND object_id=".$objectID." 
            AND identifier='".$db->escapeString( $identifier )."'";

            if( $timeout || $timeout === 0 )
            {
                $timeDifference = time() - $timeout;
                $query .= ' AND created > '.$timeDifference;
            }

            if( self::EZVOTE_DEBUG )
            eZDebug::writeDebug('Query: '.$query, 'eZVoteData::canVote');

            $rows = $db->arrayQuery( $query );
            return ($rows[0]['count'] == 0);
        }

        return false;

    }


    /**
     * Adds a session-type of block for a given object and identifier.
     *
     * @param integer $objectID
     * @param string $identifier
     * @return boolean
     */
    public static function addBlock( $objectID, $identifier )
    {

        eZVoteData::validateInteger($objectID);

        $classIdentifier = eZVoteData::getClassIdentifierByObjectID( $objectID );
        if ( !$classIdentifier ) {
            return false;
        }

        include_once( "lib/ezutils/classes/ezini.php" );
        $ini = eZINI::instance('ezvote.ini');

        $blockMethod = $ini->variable( 'TimeoutSettings', 'DefaultBlockMethod' );

        if( $ini->hasVariable( 'TimeoutSettings', 'ClassBlockMethod' ) )
        {
            $iniClassBlockMethodArray = $ini->variable( 'TimeoutSettings', 'ClassBlockMethod' );
            if(in_array($classIdentifier, array_keys($iniClassBlockMethodArray)))
            {
                $blockMethod = $iniClassBlockMethodArray[$classIdentifier];
            }
        }

        if( $blockMethod == 'session' )
        {

            $http = eZHTTPTool::instance();
            $timeout = (int)$ini->variable( 'TimeoutSettings', 'DefaultTimeout' );

            if( $ini->hasVariable( 'TimeoutSettings', 'ClassTimeout' ) )
            {
                $iniClassTimeoutArray = $ini->variable( 'TimeoutSettings', 'ClassTimeout' );
                if(in_array($classIdentifier, array_keys($iniClassTimeoutArray)))
                {
                    $timeout = (int)$iniClassTimeoutArray[$classIdentifier];
                }
            }

            if( $ini->hasVariable( 'TimeoutSettings', 'NoTimeoutClasses' ) )
            {
                $iniNoTimeoutClasses = $ini->variable( 'TimeoutSettings', 'NoTimeoutClasses' );
                $iniNoTimeoutClassesArray = explode( ';' , $iniNoTimeoutClasses );
                foreach($iniNoTimeoutClassesArray as $k => $v)
                {
                    $iniNoTimeoutClassesArray[$k] = trim($v);
                }
                if(in_array($classIdentifier, $iniNoTimeoutClassesArray))
                {
                    $timeout = false;
                }
            }

            if( $http->hasSessionVariable( 'eZVoteBlock' ) )
            {
                $eZVoteBlock = $http->sessionVariable( 'eZVoteBlock' );
            }
            else
            {
                $eZVoteBlock = array();
            }
            $blockID = md5( $objectID . $identifier );
            $eZVoteBlock[$blockID] = time() + $timeout;
            $http->setSessionVariable( 'eZVoteBlock', $eZVoteBlock );
        }

    }


    /**
     * Fetch top content. Get object IDs of objects with highest ratings in
     * a given timespan based on a class ID(s) and optionally identifier.
     *
     * This method may become quite cost expensive, so it should not be called
     * to often.
     *
     * @param integer $results
     * @param array $classIDArray
     * @param integer $timespan
     * @param string $identifier
     * @return array
     */
    public static function fetchTopContent( $results, $classIDArray, $timespan=false, $identifier=false, $skipObjectIDArray=false, $minCount=false, $subtree=false )
    {
        $db = eZDB::instance();

        $conditionCount = 0;
        $query = 'SELECT AVG(value) AS average, object_id, COUNT(object_id) AS total_count
            FROM ezvotecollector_data, ezcontentobject';
        if( $subtree )
        {
            $query .= ', ezcontentobject_tree';
            
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezcontentobject_tree.contentobject_id=ezcontentobject.id';
            
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezcontentobject_tree.path_string LIKE ' . "'" . $subtree . "%'";
            
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezcontentobject_tree.contentobject_version=ezcontentobject.current_version';

            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezcontentobject_tree.is_invisible=0';
            
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezcontentobject_tree.node_id=ezcontentobject_tree.main_node_id';
        }

        $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
        $query .= ' '.$conditionWord.' ezvotecollector_data.class_id=ezcontentobject.contentclass_id';
        
        $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
        $query .= ' '.$conditionWord.' ezvotecollector_data.object_id=ezcontentobject.id'; 

        $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
        $query .= ' '.$conditionWord.' ezcontentobject.status=' . eZContentObject::STATUS_PUBLISHED;
        
        if( $timespan )
        {
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezvotecollector_data.created > '.( time() - (int)$timespan );
        }
        if( $identifier )
        {
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezvotecollector_data.identifier=\''.$db->escapeString( $identifier ).'\'';
        };
        if( $skipObjectIDArray )
        {
            $skipObjectIDCleanArray = array();
            foreach( $skipObjectIDArray as $skipObjectID )
            {
                $skipObjectID = (int)$skipObjectID;
                if( $skipObjectID !== 0 )
                {
                    array_push( $skipObjectIDCleanArray, $skipObjectID );
                }
            }
            if( count( $skipObjectIDCleanArray ) > 0 )
            {
                $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
                $query .= ' '.$conditionWord.' ezvotecollector_data.object_id NOT IN ( ' . implode( ', ', $skipObjectIDCleanArray ) . ') ';
            }
        }
        if( is_array( $classIDArray ) )
        {
            foreach( $classIDArray as $classIDIndex => $classID )
            {
                $classIDArray[$classIDIndex] = (int)$classID;
            }
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' ezvotecollector_data.class_id IN ('.implode( ', ', $classIDArray ).')';
        }
        $query .= " GROUP BY object_id ";
        if( $minCount )
        {
            $query .= " HAVING total_count>=" . (int)$minCount;
        };
        $query .= " ORDER BY average DESC
            LIMIT 0, " . (int)$results;

        if( self::EZVOTE_DEBUG )
        eZDebug::writeDebug('Query: '.$query, 'eZVoteData::fetchTopContent');

        $rows = $db->arrayQuery( $query );

        $resultArray = array();
        foreach( $rows as $row )
        {
            array_push( $resultArray, array(
                'object_id' => (int)$row['object_id'],
                'average' => (float)$row['average'],
                'total_count' => (int)$row['average'],
            ) );
        }

        return $resultArray;
    }


    public static function fetchResultCollection( $objectIDArray, $identifier=false, $maxValue=1 )
    {
        $resultArray = array();
        if( $maxValue == 0 )
        {
            $maxValue = 1;
        }

        $cleanObjectIDArray = array();
        if( is_array( $objectIDArray ) )
        {
            foreach( $objectIDArray as $objectID )
            {
                $objectID = (int)$objectID;
                if( $objectID > 0 )
                {
                    array_push( $cleanObjectIDArray, $objectID );
                }
            }
        }

        if( count( $cleanObjectIDArray ) > 0 )
        {
            $db = eZDB::instance();

            $query = "SELECT object_id, COUNT(*) count, AVG(value) average
                FROM ezvotecollector_data 
                WHERE object_id IN ( " . implode( ', ', $cleanObjectIDArray ) . " )";
            if( $identifier )
            {
                $query .= " AND identifier='" . $db->escapeString( $identifier ) . "'";
            }
            $query .= " GROUP BY object_id";

            if( self::EZVOTE_DEBUG )
            eZDebug::writeDebug('Query: '.$query, 'eZVoteData::fetchResultCollection');

            $rows = $db->arrayQuery( $query );
            if( $rows )
            {
                foreach( $rows as $row )
                {
                    $resultArray[$row['object_id']] = array(
                        'count' => (int)$row['count'],
                        'average' => (float)$row['average'],
                        'percent' => (int)( 100 * $row['average'] / $maxValue ),
                    );
                }
            }
        }

        foreach( $cleanObjectIDArray as $objectID )
        {
            if( !isset( $resultArray[$objectID] ) )
            {
                $resultArray[$objectID] = array(
                    'count' => 0,
                    'average' => 0.00,
                    'percent' => 0,
                );
            }
        }

        return $resultArray;
    }


    /**
     * Fetches a list of vote entries based on given conditions.
     * Any combination of these conditions is allowed.
     *
     * The list of conditions and the results have to be in agreement with
     * fetchListCount method conditions and results!
     *
     * @param integer $objectID
     * @param string $identifier
     * @param integer $userID
     * @param integer $classID
     * @param integer $asObject
     * @return object
     */
    public static function fetchList( $objectID = false, $identifier = false, $userID = false, $classID = false, $asObject = true )
    {
        $objectDefinition = eZVoteData::definition();
        $conditions = array ();

        if( $objectID ) {
            eZVoteData::validateInteger($objectID);
            $conditions[$objectDefinition['name'] . '.object_id'] = $objectID;
        }
        if( $identifier ) {
            $conditions[$objectDefinition['name'] . '.identifier'] = $identifier;
        }
        if( $userID ) {
            eZVoteData::validateInteger($userID);
            $conditions[$objectDefinition['name'] . '.user_id'] = $userID;
        };
        if( $classID ) {
            eZVoteData::validateInteger($classID);
            $conditions[$objectDefinition['name'] . '.class_id'] = $classID;
        };

        $result = eZPersistentObject::fetchObjectList(
        eZVoteData::definition(),
        null,
        $conditions,
        null,
        null,
        $asObject,
        false,
        null
        );

        return $result;
    }


    /**
     * Fetches results based on specific conditions, grouped by values and summed up.
     *
     * @param integer $objectID
     * @param string $identifier
     * @param integer $userID
     * @param integer $classID
     * @param boolean $orderByValue
     * @return array
     *
     */
    public static function fetchCollection( $objectID = false, $identifier = false, $orderByValue = true, $orderDesc = true )
    {
        $db = eZDB::instance();

        $conditionCount = 0;
        $query = 'SELECT COUNT(id) AS count, value FROM ezvotecollector_data';
        if( $objectID )
        {
            eZVoteData::validateInteger( $objectID );
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' object_id='.(int)$objectID;
        }
        if( $identifier )
        {
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' identifier=\''.$db->escapeString( $identifier ).'\'';
        };
        $query .= ' GROUP BY value';

        if( self::EZVOTE_DEBUG )
        eZDebug::writeDebug('Query: '.$query, 'eZVoteData::fetchCollection');

        $rows = $db->arrayQuery( $query );


        $resultArray = array();

        reset($rows);
        while( list( , $row )=each( $rows ) )
        {
            $resultArray[$row['value']] = (int)$row['count'];
        }

        $rangeString = false;
        include_once( "lib/ezutils/classes/ezini.php" );
        $ini = eZINI::instance('ezvote.ini');

        if( $ini->hasVariable( 'ValueSettings', 'DefaultValueRange' ) )
        {
            $rangeString = $ini->variable( 'ValueSettings', 'DefaultValueRange' );
        }

        if( $ini->hasVariable( 'ValueSettings', 'ClassValueRange' ) )
        {
            $classIdentifier = eZVoteData::getClassIdentifierByObjectID( $objectID );
            $iniClassRangeArray = $ini->variable( 'ValueSettings', 'ClassValueRange' );
            if(in_array( $classIdentifier, array_keys( $iniClassRangeArray ) ) )
            {
                $rangeString = $iniClassRangeArray[$classIdentifier];
            }
        }

        if( $rangeString ) {
            $rangeStringArray = explode(',', $rangeString);
            foreach($rangeStringArray as $k => $v)
            {
                $rangeStringArray[$k] = (int)trim($v);
            }

            for($v = $rangeStringArray[0]; $v<=$rangeStringArray[1]; $v++)
            {
                if(!in_array($v, array_keys($resultArray)))
                {
                    $resultArray[$v] = 0;
                }
            }
        }

        if( $orderByValue )
        {
            if ( $orderDesc )
            {
                krsort($resultArray);
            }
            else
            {
                ksort($resultArray);
            }
        }
        else
        {
            if ( $orderDesc )
            {
                arsort($resultArray);
            }
            else
            {
                asort($resultArray);
            }
        }

        return $resultArray;
    }


    /**
     * Fetches a count of vote entries based on given conditions.
     * Any combination of these conditions is allowed.
     *
     * The list of conditions and the results have to be in agreement with
     * fetchList method conditions and results!
     *
     * @param integer $objectID
     * @param string $identifier
     * @param integer $userID
     * @param integer $classID
     * @return unknown
     *
     */
    public static function fetchListCount( $objectID = false, $identifier = false, $userID = false, $classID = false )
    {
        $db = eZDB::instance();

        $conditionCount = 0;
        $query = 'SELECT COUNT(id) AS count FROM ezvotecollector_data';
        if( $objectID )
        {
            eZVoteData::validateInteger($objectID);
            $conditionWord = eZVoteData::sqlConditionSwitch($conditionCount);
            $query .= ' '.$conditionWord.' object_id='.(int)$objectID;
        }
        if( $identifier )
        {
            $conditionWord = eZVoteData::sqlConditionSwitch( $conditionCount );
            $query .= ' '.$conditionWord.' identifier=\''.$db->escapeString( $identifier ).'\'';
        };
        if( $userID )
        {
            eZVoteData::validateInteger($userID);
            $conditionWord = eZVoteData::sqlConditionSwitch($conditionCount);
            $query .= ' '.$conditionWord.' user_id='.(int)$userID;
        };
        if( $classID )
        {
            eZVoteData::validateInteger($classID);
            $conditionWord = eZVoteData::sqlConditionSwitch($conditionCount);
            $query .= ' '.$conditionWord.' class_id='.(int)$classID;
        };

        if( self::EZVOTE_DEBUG )
        eZDebug::writeDebug('Query: '.$query, 'eZVoteData::fetchListCount');

        $rows = $db->arrayQuery( $query );
        return $rows[0]['count'];
    }


    /**
     * A simple helper function for automatic condition joining in SQL queries.
     *
     * @param integer $count
     * @return string
     */
    public static function sqlConditionSwitch(&$count) {
        if($count == 0)
        {
            $count++;
            return 'WHERE';
        }
        else
        {
            $count++;
            return 'AND';
        }
    }


    /**
     * Forces proper parameter value and type
     *
     * @param unknown_type $value
     */
    public static function validateInteger(&$value)
    {
        if( !is_numeric( $value ) )
        {
            $value = 0;
        }
        else
        {
            $value = (int)abs($value);
        }
        return;
    }


    public static function objectSynchronize( $cli, $isQuiet )
    {
        $ini = eZINI::instance( 'ezvote.ini' );
        $syncINI = $ini->group( 'SynchronizeSettings' );

        $db = eZDB::instance();
        $queryCount = 0;

        foreach( $syncINI['SynchronizeMap'] as $attributeData )
        {
            $attributeDataArray = explode( ';', $attributeData);
            $voteIdentifier = $attributeDataArray[0];
            $attributeID = $attributeDataArray[1];
            $type = $attributeDataArray[2];

            if ( !$isQuiet )
            {
                $cli->output( '########## ATTRIBUTE #'.$attributeID.'... ', false );
            }

            $attributeObject = eZContentClassAttribute::fetch( $attributeID );
            if( is_object( $attributeObject ) )
            {
                if ( !$isQuiet )
                {
                    $cli->output( 'VALID ##########' );
                }

                if( in_array( $attributeObject->DataTypeString, $syncINI['SynchronizeDatatypes'] ) )
                {
                    $query = "SELECT
                			coa.id counter_attribute_id, 
                			COUNT(vc.value) counter_count, 
                			SUM(vc.value) counter_sum 
            			FROM ezvotecollector_data vc, 
							ezcontentobject co, 
							ezcontentobject_attribute coa 
						WHERE co.id=coa.contentobject_id 
						AND co.id=vc.object_id 
						AND co.current_version=coa.version 
						AND coa.contentclassattribute_id=".$attributeID." 
						AND vc.identifier='".$db->escapeString( $voteIdentifier )."' 
						GROUP BY vc.object_id ";

                    $rows = $db->arrayQuery( $query );
                    $queryCount++;


                    foreach( $rows as $row )
                    {
                        switch( $type )
                        {
                            case 'count':
                                $dataInt = $row['counter_count'];
                                break;
                            case 'sum':
                                $dataInt = $row['counter_sum'];
                                break;
                            case 'average':
                            default:
                                $dataInt = round( 100*$row['counter_sum']/$row['counter_count'] );
                                break;
                        }

                        $query = "UPDATE ezcontentobject_attribute
							SET data_int=".$dataInt.",
							sort_key_int=data_int 
							WHERE id=".$row['counter_attribute_id'];

                        $rows = $db->query( $query );
                        $queryCount++;
                        if ( !$isQuiet )
                        {
                            $cli->output( '.', false );
                        }
                    }
                    if ( !$isQuiet )
                    {
                        $cli->output( '' );
                        $cli->output( '' );
                    }
                }
                else
                {
                    if ( !$isQuiet )
                    {
                        $cli->output( 'Datatype \''.$attributeObject->DataTypeString.'\' is not allowed to accept counter data!' );
                        $cli->output( '' );
                    }
                }
            }
            else
            {
                if ( !$isQuiet )
                {
                    $cli->output( 'INVALID ########' );
                    $cli->output( '' );
                }
            }
        }

        if ( !$isQuiet )
        {
            $cli->output( 'SQL queries total: '.$queryCount );
        }

    }


}
?>
