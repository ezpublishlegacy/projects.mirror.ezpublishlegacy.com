
DROP TABLE IF EXISTS `ezvotecollector_data`;
CREATE TABLE IF NOT EXISTS `ezvotecollector_data` (
  `id` int(11) NOT NULL auto_increment,
  `value` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  `identifier` varchar(20) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `class_id` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `object_id` (`object_id`),
  KEY `user_id` (`user_id`),
  KEY `class_id` (`class_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
