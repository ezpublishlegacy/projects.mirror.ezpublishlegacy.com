<?php

class bpce_accesInfo
{
    static function info()
    {
        return array( 'Name' => "BPCE Acces",
                      'Version' => "1.1",
                      'Copyright' => "Copyright (C) 1999-2009 BPCE",
                      'License' => "GNU General Public License v2.0"
                      );
    }
}
?>
