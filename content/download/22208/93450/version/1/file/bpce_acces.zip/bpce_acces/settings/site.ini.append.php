<?php /* #?ini charset="utf-8"?

ExtensionDirectory[]
ExtensionDirectory[]=bpce_acces

[RegionalSettings]
TranslationExtensions[]=bpce_acces

[UserSettings]
LogoutRedirect=/
SingleSignOnHandlerArray[]
SingleSignOnHandlerArray[]=ssoip
ExtensionDirectory[]=bpce_acces

*/ ?>
