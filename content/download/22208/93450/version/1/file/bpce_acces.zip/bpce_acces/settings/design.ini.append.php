<?php /*

[ExtensionSettings]
DesignExtensions[]=bpce_acces

*/ ?>