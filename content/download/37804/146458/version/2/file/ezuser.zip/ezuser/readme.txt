   ___            _                 _      __
  /__ \__  ____  (_)___ _____ ___  (_)____/ /_____ _
   / _/_ \/ __ \/ / __ `/ __ `__ \/ / ___/ __/ __ `/
  /_/  __/ / / / / /_/ / / / / / / (__  ) /_/ /_/ /
 (_)\___/_/ /_/_/\__, /_/ /_/ /_/_/____/\__/\__,_/
  EniGMistA     /____/  enigmista_80@hotmail.com
 
    version: 1.0
    date: 10/08/2005
    time: 20:10:35
    name: ezuserPLUS

    Copyright (c) 2005 Ciro La Ferrara
		
eZUser Plus 1.0
----------------
eZPlus is an extension of ezuser module. With it You can add a photo to the user.
The software is licensed under the GPL.
For installation just replace the files.

NOTE: I have tested It with a MySQL database.

If You use this module please send me an email :)