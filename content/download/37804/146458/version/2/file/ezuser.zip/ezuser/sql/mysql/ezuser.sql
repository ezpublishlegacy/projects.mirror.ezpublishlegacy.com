# MySQL-Front Dump 2.4
#
# Host: 192.168.0.16   Database: ezpublish
#--------------------------------------------------------
# Server version 4.0.23a


#
# Table structure for table 'eZUser_Author'
#

DROP TABLE IF EXISTS eZUser_Author;
CREATE TABLE `eZUser_Author` (
  `ID` int(11) NOT NULL default '0',
  `Name` varchar(255) default NULL,
  `EMail` varchar(255) default NULL,
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Cookie'
#

DROP TABLE IF EXISTS eZUser_Cookie;
CREATE TABLE `eZUser_Cookie` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) default '0',
  `Hash` varchar(33) default NULL,
  `Time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Forgot'
#

DROP TABLE IF EXISTS eZUser_Forgot;
CREATE TABLE `eZUser_Forgot` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) NOT NULL default '0',
  `Hash` varchar(33) default NULL,
  `Time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Group'
#

DROP TABLE IF EXISTS eZUser_Group;
CREATE TABLE `eZUser_Group` (
  `ID` int(11) NOT NULL default '0',
  `Name` varchar(100) default NULL,
  `Description` text,
  `SessionTimeout` int(11) default '60',
  `IsRoot` int(11) default '0',
  `GroupURL` varchar(200) default NULL,
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_GroupPermissionLink'
#

DROP TABLE IF EXISTS eZUser_GroupPermissionLink;
CREATE TABLE `eZUser_GroupPermissionLink` (
  `ID` int(11) NOT NULL default '0',
  `GroupID` int(11) default NULL,
  `PermissionID` int(11) default NULL,
  `IsEnabled` int(11) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Module'
#

DROP TABLE IF EXISTS eZUser_Module;
CREATE TABLE `eZUser_Module` (
  `ID` int(11) NOT NULL default '0',
  `Name` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `Name` (`Name`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Permission'
#

DROP TABLE IF EXISTS eZUser_Permission;
CREATE TABLE `eZUser_Permission` (
  `ID` int(11) NOT NULL default '0',
  `ModuleID` int(11) default NULL,
  `Name` varchar(100) default NULL,
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Photographer'
#

DROP TABLE IF EXISTS eZUser_Photographer;
CREATE TABLE `eZUser_Photographer` (
  `ID` int(11) NOT NULL default '0',
  `Name` char(255) default NULL,
  `EMail` char(255) default NULL,
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_Trustees'
#

DROP TABLE IF EXISTS eZUser_Trustees;
CREATE TABLE `eZUser_Trustees` (
  `ID` int(11) NOT NULL default '0',
  `OwnerID` int(11) NOT NULL default '0',
  `UserID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_User'
#

DROP TABLE IF EXISTS eZUser_User;
CREATE TABLE `eZUser_User` (
  `ID` int(11) NOT NULL default '0',
  `Login` varchar(50) NOT NULL default '',
  `Password` varchar(50) NOT NULL default '',
  `Email` varchar(50) default NULL,
  `FirstName` varchar(50) default NULL,
  `LastName` varchar(50) default NULL,
  `InfoSubscription` int(11) default '0',
  `Signature` text NOT NULL,
  `SimultaneousLogins` int(11) NOT NULL default '0',
  `CookieLogin` int(11) default '0',
  `ImageID` int(11) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `User_Login` (`Login`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_UserAddressLink'
#

DROP TABLE IF EXISTS eZUser_UserAddressLink;
CREATE TABLE `eZUser_UserAddressLink` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) NOT NULL default '0',
  `AddressID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_UserGroupDefinition'
#

DROP TABLE IF EXISTS eZUser_UserGroupDefinition;
CREATE TABLE `eZUser_UserGroupDefinition` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) NOT NULL default '0',
  `GroupID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_UserGroupLink'
#

DROP TABLE IF EXISTS eZUser_UserGroupLink;
CREATE TABLE `eZUser_UserGroupLink` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) default NULL,
  `GroupID` int(11) default NULL,
  PRIMARY KEY  (`ID`),
  KEY `UserGroupLink_UserID` (`UserID`),
  KEY `UserGroupLink_GroupID` (`GroupID`)
) TYPE=MyISAM;



#
# Table structure for table 'eZUser_UserShippingLink'
#

DROP TABLE IF EXISTS eZUser_UserShippingLink;
CREATE TABLE `eZUser_UserShippingLink` (
  `ID` int(11) NOT NULL default '0',
  `UserID` int(11) default '0',
  `AddressID` int(11) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

