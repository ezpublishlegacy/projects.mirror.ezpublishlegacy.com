<?php
//
// Definition of eZSPPlusChecker class
//
// Created on: <18-June-2009 11:00:00 dl>
//
// SOFTWARE NAME: eZ Publish
// SOFTWARE RELEASE: 4.0.1
// BUILD VERSION: 22260
// COPYRIGHT NOTICE: Copyright (C) 1999-2008 eZ Systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezsppluschecker.php
*/

/*!
  \class eZSPPlusChecker ezsppluschecker.php
*/


// Include libs
include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');

// Needed for activateOrder function
include_once('kernel/shop/ezshopoperationcollection.php');
include_once('kernel/classes/ezbasket.php');

class eZSPPlusChecker extends eZPaymentCallbackChecker
{
	/*!
	    Constructor.
	*/
	function eZSPPlusChecker()
	{	
		$this->eZPaymentCallbackChecker('ezspplus.ini');

		// Load vars
		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");

		// Sys lib call
		$this->ezsys = eZSys::instance();

		$this->logger = eZPaymentLogger::CreateForAdd($iniVarDir."/log/eZSPPlusGateway.log");
		$this->logger->writeTimedString('eZSPPlusChecker::eZSPPlusChecker()');	
	}
	
	/*!
	    Convinces of completion of the payment.
	*/
	function handleResponse($socket)
	{
		// If data was posted to shop/checkout then change state
		if($this->createDataFromGET() && isset($this->callbackData['etat']) && $this->callbackData['etat']==1 )
		{
			// Retrieve received datas for validation
			$orderID = $this->callbackData['orderID'];
			$sessionID = $this->callbackData['return_context'];

			// Get order
			$order = eZOrder::fetch($orderID);

			// Not accepeted so accept it
			if($order->attribute("is_temporary"))
			{
				// Will activate order but doesnt clean basket as it should
				//eZShopOperationCollection::activateOrder($orderID);

				// Fetch basket with session_id
//				$basket = eZBasket::fetch($sessionID);

				// If there is a basket with this sessionID then activate order and remove basket
//				if($basket) $basket->remove();

				// Validate order
//				$order->activate();

				// String that will be registered				
				$paymentInfos  = "Reference : ".$this->callbackData['reference'].";";
				$paymentInfos .= "Siret : ".$this->callbackData['siret'].";";
				$paymentInfos .= "Langue : ".$this->callbackData['langue'].";";
				$paymentInfos .= "Devise : ".$this->callbackData['devise'].";";
				$paymentInfos .= "Montant : ".$this->callbackData['montant'].";";
				$paymentInfos .= "Taxe : ".$this->callbackData['taxe'].";";
				$paymentInfos .= "Moyen : ".$this->callbackData['moyen'].";";
				$paymentInfos .= "Modalite : ".$this->callbackData['modalite'].";";
				$paymentInfos .= "Refsfp : ".$this->callbackData['refsfp'].";";
				$paymentInfos .= "Etat : ".$this->callbackData['etat'].";";
				$paymentInfos .= "Hmac : ".$this->callbackData['hmac'];
				

				// Record Payment infos				
				$order->setAttribute('data_text_2', $paymentInfos);
				$order->store();
			}

			return true;
		}

		return false;
	}
}

?>
