<?php
//
// Definition of eZSPPlusGateway class
//
// Created on: <18-June-2009 11:00:00 dl>
//
// SOFTWARE NAME: eZ Publish
// SOFTWARE RELEASE: 4.0.1
// BUILD VERSION: 22260
// COPYRIGHT NOTICE: Copyright (C) 1999-2008 eZ Systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezspplusgateway.php
*/

/*!
  \class eZSPPlusGateway ezspplusgateway.php
*/


// Activate validation function to register
ext_activate('ezspplus','classes/ezsppluschecker.php');

// Activate validation function to register
include_once('kernel/shop/classes/ezpaymentgateway.php');

// Define different variables

define("EZ_PAYMENT_NOT_ACCEPTED", 1);
define("EZ_PAYMENT_ACCEPTED", 2);


class eZSPPlusGateway extends eZPaymentGateway
{
	/*!
	 Constructor.
	*/
	function eZSPPlusGateway()
	{
		// Load ini
		$this->ini = eZINI::instance('ezspplus.ini');
		$this->http = eZHTTPTool::instance();

		// Load var dir
		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");		
	}

	/*!
	    Creates new eZSipsGateway object.
	*/
	function execute($process, $event)
	{
		
		$checker = new eZSPPlusChecker();
//		// If data was posted to shop/checkout then change state
		if($checker->handleResponse())
		{
			// Put workflow in result mode
			$process->setAttribute('event_state', EZ_PAYMENT_ACCEPTED);
		}

		// Switch between two state of workflow process
		switch ($process->attribute('event_state'))
		{
			// Load the request
			case EZ_PAYMENT_NOT_ACCEPTED :
			{			
				return $this->handleRequest($process);
			}
			break;

			// This order has been treated
			case EZ_PAYMENT_ACCEPTED :
			{
				return eZWorkflowType::STATUS_ACCEPTED;
			}
			break;
		}
	}

	/*!
	    Handle request
	*/
	function handleRequest($process, $errors = 0)
	{
		$http = eZHTTPTool::instance();
		// Get process params
		$processParams = $process->attribute('parameter_list');
		$orderID = $processParams['order_id'];		
   		$session_id = $http->getSessionKey();
   		
		// Get order
		$order = eZOrder::fetch($orderID);
		// Get total including tax
		//$amount = //str_replace(".","",sprintf("%01.2lf",));		
		$URLService=$this->ini->variable('eZSPPlusSettings','URLService');
   		$URLRetour=$this->ini->variable('eZSPPlusSettings','URLRetour');
		$clent =$this->ini->variable('eZSPPlusSettings','Clen');
   		$codesiret = $this->ini->variable('eZSPPlusSettings','CodeSiret');   			   		
   		$devise=$this->ini->variable('eZSPPlusSettings','Devise');
   		$reference = substr($this->ini->variable('eZSPPlusSettings','Reference'),0,5)."_". date("YmdHis");	    
  		$langue=$this->ini->variable('eZSPPlusSettings','Langue');
   		$taxe=$this->ini->variable('eZSPPlusSettings','Taxe');
   		$moyen=$this->ini->variable('eZSPPlusSettings','Moyen');
   		$modalite=$this->ini->variable('eZSPPlusSettings','Modalite');
   		
//   		$email=$order->attribute('email');
   		$montant=$order->attribute('total_inc_vat');
   		
   		
   		$url_signeurlpaiement = $URLService."?"."urlretour=$URLRetour&siret=$codesiret&reference=$reference&langue=$langue&devise=$devise&montant=$montant&taxe=$taxe&moyen=$moyen&modalite=$modalite&orderID=$orderID&return_context=$session_id";
   		$urlspplus=signeurlpaiement($clent,$url_signeurlpaiement);   		   		
		
		// soit on affiche le tpl 
		// Assign template & vars
		$process->Template = array('templateName' => 'design:ezspplusrequest.tpl',
					   'templateVars' => array('page_title' => 'Choisissez votre carte de paiement',
								   'lien' => $urlspplus,
								 ),
					 );

		// Return the workflow status - I don't know why
		return eZWorkflowType::STATUS_FETCH_TEMPLATE_REPEAT;
	}
}

eZPaymentGatewayType::registerGateway("eZSPPlus", "eZSPPlusGateway", "eZSPPlus");

?>
