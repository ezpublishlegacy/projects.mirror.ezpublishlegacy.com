<?php /* #?ini charset="iso-8859-1"?

[eZSPPlusSettings]
URLService=https://www.spplus.net/paiement/init.do
URLRetour=http://www.mon_site.fr/shop/checkout
CodeSiret=00000000000000-001
Clen=11 22 33 ...
Devise=978
Langue=FR
Moyen=CBS
Modalite=1x
Taxe=0
## reference : 5 caracteres max 
Reference=ref
*/ ?>
