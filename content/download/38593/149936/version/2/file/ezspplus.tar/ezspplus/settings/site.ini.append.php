<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
ActiveExtensions[]
ActiveExtensions[]=ezspplus

*/ ?>
