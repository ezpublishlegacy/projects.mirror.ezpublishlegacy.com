<?php
class bcarraysortInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/bcarraysort'>BC Array Sort</a>",
            'Version' => "1.0.0",
            'Copyright' => "Copyright (C) 2008 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Brookins Consulting",
            'License' => "GNU General Public License",
            'Based on the following third-party software' => array( 'Name' => 'ArraySortOperator',
                                                                    'Author' => 'Marc Boon',
                                                                    'Version' => '1.0 - April 2006',
                                                                    'License' => 'Unknown',
                                                                    'For more information' => 'http://ez.no/developer/contribs/template_plugins/arraysortoperator' )
                     );

    }
}
?>
