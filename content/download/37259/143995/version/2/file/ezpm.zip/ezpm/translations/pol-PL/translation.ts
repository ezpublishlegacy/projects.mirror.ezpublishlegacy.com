<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezpm</name>
    <message>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Od</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Do</translation>
    </message>
    <message>
        <source>Date sent</source>
        <translation>Wysłano</translation>
    </message>
    <message>
        <source>Date read</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
</context>
</TS>
