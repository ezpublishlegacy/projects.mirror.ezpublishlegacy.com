<?php

include_once( 'kernel/common/template.php' );
include_once( 'extension/ezpm/modules/pm/classes/ezpm.php' );
include_once( 'extension/ezpm/modules/pm/classes/ezcontact.php' );

$Module =& $Params['Module'];
$messageID =& $Params['Parameters'][0]; // first parameter from link is message id
$message =& eZPm::fetch( $messageID, true );
$message->markMessageAsRead();

$is_contact =& eZContact::isOnContactList( $message->SenderUserID );

$tpl =& templateInit();
$tpl->setVariable( 'user_id', eZUser::currentUserID() );
$tpl->setVariable( 'messageID', $messageID );
$tpl->setVariable( 'is_contact', $is_contact );

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:pm/pm.tpl' );
$Result['pagelayout'] = 'pm_pagelayout.tpl';
$Result['path'] = array( array( 'url' => false,
                                'text' => $message->Subject ) );

?>
