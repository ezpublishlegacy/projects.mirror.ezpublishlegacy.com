<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=sortobjectsoperators

*/ ?>