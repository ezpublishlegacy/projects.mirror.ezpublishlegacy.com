<?php

class sortobjectsoperatorsInfo
{
    static function info()
    {
        return array(
            'Name' => 'Content objects/nodes sorting template operators extension',
            'Version' => '1.0',
            'Copyright' => 'Copyright (C) 2011 Alex Kozeka',
            'License' => 'GNU General Public License v2.0',
        );
    }
}

?>