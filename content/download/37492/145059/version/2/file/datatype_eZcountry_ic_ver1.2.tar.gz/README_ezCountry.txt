/*!
  \class eZCountryType ezcountrytype.php
  \ingroup eZKernel
  \brief A content datatype which handles countries

  Provides 'Country' as a class/object property
  Based on ezcountrytype.php datatype contributed by Esben Maal�
  
  This version (1.2) supports information collector 
  it has been tested for EZP 3.3.3, 3.5 and 3.6.10 adding this ezcountry datatype to 
  the Feedback form class supplied by EZP3 Corporate setup.   
  
  Zoran Marinkovic
  http://www.zwebb.com
  
  Initial version by:
  Lazaro Ferreira
      
  More info:

  New country names added: Serbia (RS) and Montenegro (ME) instead of Yugoslavia (YU).
  
  This version - it does not store countries as keys - rather
  as literal text strings (it stores 'Slovakia' not 'SK')- dynamic translation 
  is therefore NOT possible and it is not the ideal solution for a country 
  datatype. However it is sufficient for a monolingual site - if you want to
  translate it have a look at the file 
    
    /design/templates/content/datatypes/edit/ezcountry_options.tpl
  
  If you want to fix this class so that it stores keys we have provided

   /design/templates/content/datatypes/edit/ezcountry_options.with.keys.tpl
  
  to help you out. This file is NOT used by this class - but it could be :)
  
  esm@baseclass.modulweb.dk

*/


INSTALLATION:

1) Untar all the files over your ezpub3 installation - Nothing in your current installation will be overwritten (unless you already have some other stuff called ezcountry)

2) Update EZP default translation file at share/translations/untranslated/translation.ts

Look for this context in translation.ts :
...
<context>
    <name>kernel/classes/datatypes</name>
... 
then add the new translation inserting the piece of code below within the context
...
    <message>
        <source>Country</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
... 
NOTE: The explanation above is for a quick and dirty translation, it also can be done using the GUI translation tools  
3)
Add the ezcountry datatype in content.ini

like this:

================== <SNIPPET file='settings/content.ini'> ==============================
[DataTypeSettings]
# A list of directories to check for datatypes
RepositoryDirectories[]=kernel/classes/datatypes
# A list of extensions which have content object datatypes
# It's common to create a settings/content.ini.append file
# in your extension and add the extension name to automatically
# get datatypes from the extension when it's turned on.
ExtensionDirectories[]

AvailableDataTypes[]=ezcountry
AvailableDataTypes[]=ezstring
AvailableDataTypes[]=eztext
AvailableDataTypes[]=ezxmltext
AvailableDataTypes[]=ezdate
AvailableDataTypes[]=ezdatetime
AvailableDataTypes[]=eztime
AvailableDataTypes[]=ezboolean
AvailableDataTypes[]=ezinteger
AvailableDataTypes[]=ezfloat
AvailableDataTypes[]=ezenum
AvailableDataTypes[]=ezobjectrelation
AvailableDataTypes[]=ezimage
AvailableDataTypes[]=ezbinaryfile
AvailableDataTypes[]=ezmedia
AvailableDataTypes[]=ezauthor
AvailableDataTypes[]=ezurl
AvailableDataTypes[]=ezemail
AvailableDataTypes[]=ezoption
AvailableDataTypes[]=ezprice
AvailableDataTypes[]=ezuser
AvailableDataTypes[]=ezisbn
AvailableDataTypes[]=ezkeyword
AvailableDataTypes[]=ezsubtreesubscription
================== </SNIPPET> ==============================

4) Clear all the cache 

5) That's all

-------------------------------------------------------
FUTURE WORK:
- Adding multilanguage support using i18n operator in country option list template
- Implementing this as EZP3 extension

 


