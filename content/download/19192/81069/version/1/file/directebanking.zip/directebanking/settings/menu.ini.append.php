<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[directebankingpart]=DIRECTebanking.com

[TopAdminMenu]
Tabs[]=directebanking

[Topmenu_directebanking]
NavigationPartIdentifier=directebankingpart
Name=DIRECTebanking.com
Tooltip=Control your DIRECTebanking.com Account
URL[]
URL[default]=directebanking/profile/view
Enabled[]
Enabled[default]=false
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=false
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
