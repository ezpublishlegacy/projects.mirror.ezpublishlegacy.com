<?php /*

[RegionalSettings]
TranslationExtensions[]=directebanking

[RoleSettings]
PolicyOmitList[]=directebanking/notificate

*/ ?>
