<?php

class directebankingInfo
{
    static function info()
    {
        return array( 'Name' => 'DIRECTebanking',
                      'Version' => '2.0.0',
                      'License' => 'GNU General Public License v2.0',
                      'Description' => 'This extension contains methods to use sofort&uuml;berweisung.de as payment gateway.',
                      'Copyright' => 'Copyright &copy; '.date('Y').' by <a href="http://www.all2e.com" title="all2e GmbH">all2e GmbH</a>'
                     );
    }
}
?>
