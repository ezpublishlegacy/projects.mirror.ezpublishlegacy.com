<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=directebanking

[StylesheetSettings]
CSSFileList[]=jscal2.css
CSSFileList[]=border-radius.css
CSSFileList[]=steel.css

*/ ?>
