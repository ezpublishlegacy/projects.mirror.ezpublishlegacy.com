<?php /* #?ini charset="utf-8"? */
/**
 * File containing the site ini
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */

/*

# this settings you should copy to your siteaccess site.ini
# so you have the fully control which ts files are loaded
#[RegionalSettings]
#TranslationExtensions[]=cjw_newsletter


[TemplateSettings]
ExtensionAutoloadPath[]=cjw_newsletter

*/ ?>
