<?php /* #?ini charset="utf-8"? */
/**
 * File containing the template ini
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version //autogentag//
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */

/*

[PHP]
# used for email templates
PHPOperatorList[nl2br]=nl2br

*/ ?>

