<?php /* #?ini charset="utf-8"?

# [EditSettings]
# GroupedInput[]=ezshipping

*/ ?>