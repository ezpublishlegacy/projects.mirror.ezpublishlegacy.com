<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=bcstaticshipping
AvailableEventTypes[]=event_bcstaticshipping

[SimpleShippingWorkflow]
FreeShipping=Enabled
FreeShippingPrice=50.00
FreeShippingWeightDiscount=5.00
eZoption2ProductVariations=Enabled
ShippingVendorName=eZ

*/ ?>