<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=bcstaticshipping
# AvailableDataTypes[]=ezshipping

*/ ?>