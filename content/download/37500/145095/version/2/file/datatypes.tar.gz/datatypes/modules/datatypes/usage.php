<?php

$Module =& $Params['Module'];
$moduleName = $Params['ModuleName'];
$functionName = $Params['FunctionName'];

$userParams = $Params['UserParameters'];

$datatypeString = $Params['DatatypeString'];

// $limitation = $Params['Limitation'];

/*

$currentAction = $Module->currentAction();

if ( $Module->hasActionParameter( 'parametername' ) )
{
    eZDebug::writeDebug( $Module->actionParameter( 'parameternamer' ) );
}

*/

/*
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

$http =& eZHTTPTool::instance();
$ini =& eZINI::instance();
*/

/*
return $Module->redirectTo( $redirectURI );
*/

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

include_once( 'lib/ezdb/classes/ezdb.php' );

$db =& eZDB::instance();

if ( $datatypeString )
{
    $sql = "SELECT d.id as class_id, d.identifier AS class_identifier, d.name AS class_name, e.identifier AS attribute_identifier, e.name AS attribute_name, e.id AS attribute_id FROM ezcontentclass_attribute e, ezcontentclass d where d.version=0 AND e.data_type_string='" .$db->escapeString( $datatypeString ) . "' AND e.contentclass_id=d.id AND e.version=d.version ORDER BY d.identifier, e.identifier";

    $attributes = $db->arrayQuery( $sql );

    $tpl->setVariable( 'data_type_string', $datatypeString );
    $tpl->setVariable( 'attributes', $attributes );

    $Result = array();
    $Result['content'] = $tpl->fetch( 'design:datatypes/attributes.tpl' );
    $Result['path'] = array( array( 'text' => ezi18n( 'datatypes', 'Datatypes' ),
                                'url' => false ),
                         array( 'text' => ezi18n( 'datatypes', 'Usage' ),
                                'url' => '/datatypes/usage' ),
                         array( 'text' => $datatypeString,
                                'url' => false ) );
}
else
{
    $sql = "SELECT e.data_type_string, COUNT(e.id) AS attribute_count FROM ezcontentclass_attribute e, ezcontentclass d where d.version=0 AND e.contentclass_id=d.id AND e.version=d.version GROUP BY e.data_type_string ORDER BY e.data_type_string";

    $datatypes = $db->arrayQuery( $sql );

    $tpl->setVariable( 'datatypes', $datatypes );

    $Result = array();
    $Result['content'] = $tpl->fetch( 'design:datatypes/usage.tpl' );
    $Result['path'] = array( array( 'text' => ezi18n( 'datatypes', 'Datatypes' ),
                                'url' => false ),
                         array( 'text' => ezi18n( 'datatypes', 'Usage' ),
                                'url' => false ) );
}

?>