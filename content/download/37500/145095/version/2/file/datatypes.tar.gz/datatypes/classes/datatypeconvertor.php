<?php

class DatatypeConvertor
{
    function possibleConversions( $datatypeString )
    {
        $result = array();

        $ini =& eZINI::instance( 'datatypeconvertor.ini' );
        $groups = $ini->groups();
        foreach( $groups as $identifier => $group )
        {
            if ( $group['Datatype'] == $datatypeString )
            {
                $result[$identifier] = array( 'identifier' => $identifier,
                                              'name' => $group['Name'] );
            }
        }

        return $result;
    }

    function convert( $classAttributeID, $conversionMethod )
    {
        include_once( 'kernel/classes/ezcontentclassattribute.php' );
        $classAttribute =& eZContentClassAttribute::fetch( $classAttributeID );

        if ( ! is_object( $classAttribute ) )
        {
            return false;
        }

        $datatypeString = $classAttribute->attribute( 'data_type_string' );

        $ini =& eZINI::instance( 'datatypeconvertor.ini' );

        if ( $ini->hasGroup( $conversionMethod ) )
        {
            if ( $ini->variable( $conversionMethod, 'Datatype' ) == $datatypeString )
            {
                $class = trim( $ini->variable( $conversionMethod, 'Class' ) );
                $function = $ini->variable( $conversionMethod, 'Function' );
                $includeFile = $ini->variable( $conversionMethod, 'IncludeFile' );

                if ( $class != '' )
                {
                    $callback = array( $class, $function );
                }
                else
                {
                    $callback = $function;
                }

                if ( file_exists( $includeFile ) )
                {
                    include_once( $includeFile );
                }
                if ( is_callable( $callback ) )
                {
                    call_user_func( $callback, $classAttribute );
                }
            }
        }

        return false;
    }
}

?>