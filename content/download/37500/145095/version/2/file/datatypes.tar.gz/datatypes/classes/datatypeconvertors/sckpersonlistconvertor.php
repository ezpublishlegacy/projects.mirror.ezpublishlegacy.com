<?php

class SCKPersonListConvertor
{
    function convertToObjectRelationList( &$classAttribute )
    {
        include_once( 'lib/ezdb/classes/ezdb.php' );
        $db =& eZDB::instance();
        $db->begin();

        include_once( 'kernel/classes/ezcontentobjectattribute.php' );
        $attributes = eZContentObjectAttribute::fetchSameClassAttributeIDList( $classAttribute->attribute( 'id' ) );
        $count = count( $attributes );
        eZDebug::writeDebug( 'attribute count: ' . $count, 'SCKPersonListConvertor::convertToObjectRelationList' );

        $classAttribute->setAttribute( 'data_text5', '' );
        $classAttribute->setAttribute( 'data_type_string', 'ezobjectrelationlist' );
        $classAttribute->store();

        for ( $i = 0; $i < $count; $i++ )
        {
            eZDebug::writeDebug( 'cycle ' . $i );
            eZDebug::writeDebug( $attributes[$i]->attribute( 'data_text' ) );
            $persons = $attributes[$i]->attribute( 'content' );

            if ( is_object( $persons ) )
            {
                eZDebug::writeDebug( 'person object: ' . $attributes[$i]->attribute( 'id' ) . ' ' . $attributes[$i]->attribute( 'version' ) );
                $personList =  $persons->attribute( 'person_list' );

                $attributes[$i]->setAttribute( 'data_type_string', 'ezobjectrelationlist' );
                $attributes[$i]->setAttribute( 'data_text', '' );
                $attributes[$i]->initialize();

                // reset object attribute's virtual content attribute
                $attributes[$i]->Content = null;
    
                $content = $attributes[$i]->content();
                $priority = 0;
                for ( $j = 0; $j < count( $content['relation_list'] ); ++$j )
                {
                    if ( $content['relation_list'][$j]['priority'] > $priority )
                    {
                        $priority = $content['relation_list'][$j]['priority'];
                    }
                }

                foreach ( $personList as $person )
                {
                    if ( $person['id'] )
                    {
                        include_once( 'kernel/classes/ezcontentobject.php' );
                        $object = eZContentObject::fetch( $person['id'] );
                        eZDebug::writeDebug( $object->attribute( 'name' ) . ' ' . $person['name'] . ' ' . $person['firstname'] );
    
                        if ( $object )
                        {
                            ++$priority;
                            include_once( 'kernel/classes/datatypes/ezobjectrelationlist/ezobjectrelationlisttype.php' );
                            $content['relation_list'][] = eZObjectRelationListType::appendObject( $person['id'], $priority, $attributes[$i] );
                            $attributes[$i]->setContent( $content );
                            var_dump( $attributes[$i] );
                            $attributes[$i]->store();
                        }
                    }
                    else
                    {
                        eZDebug::writeDebug( 'no person id' );
                        $db->rollback();
                        return false;
                    }
                }
            }
            else
            {
                eZDebug::writeDebug( 'no person object: ' . $attributes[$i]->attribute( 'id' ) . ' ' . $attributes[$i]->attribute( 'version' ) );
            }
        }

        eZDebug::writeDebug( $classAttribute->attribute( 'id' ) );

        $db->commit();
        return true;
    }
}
?>