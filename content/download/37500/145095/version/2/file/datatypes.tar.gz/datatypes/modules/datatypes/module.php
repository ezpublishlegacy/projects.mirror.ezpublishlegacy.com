<?php

$Module = array( 'name' => 'Datatypes', 'variable_params' => false, 'ui_component_match' => 'view' );

$ViewList = array();

$ViewList['usage'] = array( 
    'script' => 'usage.php',
    'params' => array( 'DatatypeString' ),
    'default_navigation_part' => 'ezsetupnavigationpart',
    'functions' => array( 'read' )
);

$ViewList['convert'] = array(
    'script' => 'convert.php',
    'params' => array( 'ClassAttributeID' ),
    'default_navigation_part' => 'ezsetupnavigationpart',
    'functions' => array( 'convert' )
);

/*
$ViewList['viewname'] = array(
    'script' => ,
    'params' => ,
    'ui_context' => ,
    'ui_component' => ,
    'default_navigation_part' => ,
    'unordered_params' => ,
    'default_action' => array(
    array(
        'name' => '',
        'type' => 'post',
        'parameters' = array( 'postvariablename' ) ),
    'single_post_actions' => array(
        'postvariablename' => 'actionname' ),
    'post_actions' => array( 'postvariablename' )
    'post_action_parameters' => array(
        'actionname' => array( 'parametername' => 'postvariablename' ) ),
    'post_value_action_parameters' => array(
        'actionname' => array( 'parametername' => 'postvariablenamestart' )
    );
*/

$FunctionList = array();

$FunctionList['read'] = array();
$FunctionList['convert'] = array();

?>