<?php

$Module =& $Params['Module'];
$moduleName = $Params['ModuleName'];
$functionName = $Params['FunctionName'];

$userParams = $Params['UserParameters'];

$classAttributeID = $Params['ClassAttributeID'];

$selectedConversion = false;

// $limitation = $Params['Limitation'];

/*

$currentAction = $Module->currentAction();

if ( $Module->hasActionParameter( 'parametername' ) )
{
    eZDebug::writeDebug( $Module->actionParameter( 'parameternamer' ) );
}

*/

include_once( 'lib/ezutils/classes/ezhttptool.php' );
$http =& eZHTTPTool::instance();

if ( $http->hasPostVariable( 'ConversionMethod' ) )
{
    $selectedConversion = $http->postVariable( 'ConversionMethod' );
}

if ( !$classAttributeID )
{
    return $Module->handleError( EZ_ERROR_KERNEL_NOT_FOUND );
}

include_once( 'kernel/classes/ezcontentclassattribute.php' );
$classAttribute =& eZContentClassAttribute::fetch( $classAttributeID );

if ( !is_object( $classAttribute ) )
{
    return $Module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE );
}

include_once( 'extension/datatypes/classes/datatypeconvertor.php' );
$conversions =& DatatypeConvertor::possibleConversions( $classAttribute->attribute( 'data_type_string' ) );

if ( $http->hasPostVariable( 'ConvertButton' ) )
{
    if ( $selectedConversion )
    {
        $result = DatatypeConvertor::convert( $classAttributeID, $selectedConversion );
        eZDebug::writeDebug( $result, 'Datatype conversion result' );
    }
}

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

$tpl->setVariable( 'selectedConversion', $selectedConversion );
$tpl->setVariable( 'conversions', $conversions );
$tpl->setVariable( 'classAttribute', $classAttribute );

$Result = array();
$Result['content'] = $tpl->fetch( 'design:datatypes/convert.tpl' );
$Result['path'] = array( array( 'text' => ezi18n( 'datatypes', 'Datatypes' ),
                            'url' => '/datatypes/usage' ),
                     array( 'text' => ezi18n( 'datatypes', 'Convert' ),
                            'url' => false ),
                     array( 'text' => $classAttributeID,
                            'url' => false ) );

include_once( 'lib/ezdb/classes/ezdb.php' );

$db =& eZDB::instance();



?>