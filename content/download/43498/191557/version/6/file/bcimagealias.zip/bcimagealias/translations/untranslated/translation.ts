<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>extension/bcimagealias/popupmenu</name>
    <message>
        <source>BC ImageAlias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image variations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create image variations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove image variations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create by node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create current siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create related siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create by node subtree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerate by node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerate current siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerate related siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerate by node subtree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove by node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove by current siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove by related siteaccess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove by node subtree</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
