<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=bcimagealias
AvailableEventTypes[]=event_bcimagealiascreateobjectimagevariations

*/ ?>
