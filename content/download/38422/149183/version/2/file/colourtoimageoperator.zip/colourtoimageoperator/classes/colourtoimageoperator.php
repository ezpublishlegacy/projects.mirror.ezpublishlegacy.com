<?php
/*!
\class   colourToImageOperator colourtoimageoperator.php
\ingroup eZTemplateOperators
\brief   Creates a new image from supplied args and stores it if it doesn't already exist
\version 1.0
\date    29 October 2008
\author  Nathan Kelly - nathan[AT]nathan-kelly[DOT]com

usage:
\code
<img src="{rgbtoimage( red, green, blue, hash( 'width', width, 'height', height, 'type', type ) )}" alt="" />
<img src="{hextoimage( hex, hash( 'width', width, 'height', height, 'type', type ) )} alt="" />
\endcode

examples

input:
\code
<img src="{rgbtoimage( 200, 160, 56, hash( 'width', 500, 'height', 200, 'type', 'png' ) )}" alt="" />
<img src="{hextoimage( "3399ff", hash( 'width', 300, 'height', 100 ) )}" alt="" />
<img src="{hextoimage( "#2f577f", hash( 'type', 'png' ) )}" alt="" />
\endcode

output:
\code
<img src="var/[siteaccess]/storage/images/colourtoimage/200_160_56_500_200.png" alt="" />
<img src="var/[siteaccess]/storage/images/colourtoimage/51_153_255_300_100.jpg" alt="" />
<img src="var/[siteaccess]/storage/images/colourtoimage/47_87_127_200_100.png" alt="" />
\endcode

filename consists of rgb values + width + height
width and height can be predefined in site.ini.append.php
type defaults to jpg
hexidecimal values are converted to rgb for processing by eZImageInterface::allocateColor
*/

class colourToImageOperator
{
    /*!
      Constructor.
    */
    function colourToImageOperator( $rgb = 'rgbtoimage', $hex = 'hextoimage' )
    {
	$this->Operators = array( $rgb, $hex );
	$this->RGB = $rgb;
	$this->HEX = $hex;
    }
    
    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return $this->Operators;
    }
    
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( $this->RGB => array( 'red' => array( 'type' => 'numeric', 'required' => true, 'default' => 0 ),
					   'grn' => array( 'type' => 'numeric', 'required' => true, 'default' => 0 ),
					   'blu' => array( 'type' => 'numeric', 'required' => true, 'default' => 0 ),
					   'options' => array( 'type' => 'hash', 'required' => false, 'default' => false ) ),					   
		      $this->HEX => array( 'hex' => array( 'type' => 'string', 'required' => true, 'default' => '000000'),
		      			   'options' => array( 'type' => 'hash', 'required' => false, 'default' => false ) ) );
    }

    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
    {
	$ini = eZINI::instance( 'colourtoimage.ini' );
	$opts = $namedParameters['options'];
	if ( isset( $opts['width'] ) )
	{
	    $width = $opts['width'];
	}
	else
	{
	    $width = $ini->variable( 'ColourToImageSettings', 'DefaultWidth' );
	}
	if ( isset( $opts['height'] ) )
	{
	    $height = $opts['height'];
	}
	else
	{
	    $height = $ini->variable( 'ColourToImageSettings', 'DefaultHeight' );
	}
	if ( isset( $opts['type'] ) )
	{
	    $fileType = $opts['type'];
	}
	else
	{
	    $fileType = 'jpg';
	}	
	switch ( $operatorName )
	{
	    case $this->HEX:
	        $hash = $namedParameters['hex'];
		if ( 0 === strpos( $hash, '#' ) )
		{
		   $hash = substr( $hash, 1 );
		}
		$cutpoint = ceil( strlen( $hash ) / 2 ) -1;
		$hextorgb = explode( ':', wordwrap( $hash, $cutpoint, ':', $cutpoint ), 3 );
		$red = ( isset( $hextorgb[0] ) ? hexdec( $hextorgb[0] ) : 0 );
		$grn = ( isset( $hextorgb[1] ) ? hexdec( $hextorgb[1] ) : 0 );
		$blu = ( isset( $hextorgb[2] ) ? hexdec( $hextorgb[2] ) : 0 );
		break;
	    case $this->RGB:
	    	$red = $namedParameters['red'];
		$grn = $namedParameters['grn'];
		$blu = $namedParameters['blu'];
		break;
	    default:
	        // null
		break;
	}
	
	$siteini = eZINI::instance( 'site.ini' );
	$fileName = $red . '_' . $grn . '_' . $blu . '_' . $width . '_' . $height . '.' . $fileType;	
	$varDir = $siteini->variable( 'FileSettings', 'VarDir' );
	$storeDir = $siteini->variable( 'FileSettings', 'StorageDir' );	
	$imageDir = $ini->variable( 'ColourToImageSettings', 'StorageDir' );	
	$filePath = $varDir . '/' . $storeDir . '/' . $imageDir . '/';
	$fullPath = $filePath . $fileName;
	
	if ( !file_exists( $fullPath ) )
	{
		eZDebug::writeNotice( 'Image (' . $fileName . ') does not exist in (' . $filePath . '), creating new image.', 'colourToImageOperator::modify' );
		$newImage = eZImageInterface::createImage( $width, $height, $useTruecolor );
		$image = new eZImageInterface( $newImage, $newImage, $width, $height );	
		$image->setAlternativeText( $red . '_' . $grn . '_' . $blu );	
		$image->allocateColor( $fileName, $red, $grn, $blu );	
		$image->store( $fileName, $filePath, $fileType );		
	}
	
	$operatorValue = '/' . $fullPath;
    }
    
    public $Operators;
    public $RGB;
    public $HEX;
};

?>
