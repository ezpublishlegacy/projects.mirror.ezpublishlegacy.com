<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/colourtoimageoperator/classes/colourtoimageoperator.php',
                                    'class' => 'colourToImageOperator',
                                    'operator_names' => array( 'rgbtoimage', 'hextoimage' ) );
?>