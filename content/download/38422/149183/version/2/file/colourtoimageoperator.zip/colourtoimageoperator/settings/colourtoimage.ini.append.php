<?php /*

[ColourToImageSettings]
# StorageDir relative to site.ini StorageDir
StorageDir=images/colourtoimage
# Defaults
DefaultWidth=200
DefaultHeight=100

*/ ?>
