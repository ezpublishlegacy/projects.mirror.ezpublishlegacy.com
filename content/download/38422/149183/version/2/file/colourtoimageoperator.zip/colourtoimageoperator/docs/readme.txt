colourToImageOperator colourtoimageoperator.php

Creates a new image from supplied args and stores it if it doesn't already exist.
Returns the path to the image that was stored.
Uses Class eZImageInterface in /lib/ezimage/classes
--------------------------------------------------------------------------------
usage:
\code
<img src="{rgbtoimage( red, green, blue, hash( 'width', width, 'height', height, 'type', type ) )}" alt="" />
<img src="{hextoimage( hex, hash( 'width', width, 'height', height, 'type', type ) )} alt="" />
\endcode

examples

input:
\code
<img src="{rgbtoimage( 200, 160, 56, hash( 'width', 500, 'height', 200, 'type', 'png' ) )}" alt="" />
<img src="{hextoimage( "3399ff", hash( 'width', 300, 'height', 100 ) )}" alt="" />
<img src="{hextoimage( "#2f577f", hash( 'type', 'png' ) )}" alt="" />
\endcode

output:
\code
<img src="var/[siteaccess]/storage/images/colourtoimage/200_160_56_500_200.png" alt="" />
<img src="var/[siteaccess]/storage/images/colourtoimage/51_153_255_300_100.jpg" alt="" />
<img src="var/[siteaccess]/storage/images/colourtoimage/47_87_127_200_100.png" alt="" />
\endcode

filename consists of rgb values + width + height + type

width and height default to values defined in colourtoimage.ini.append.php

type defaults to jpg

hexadecimal values are converted to rgb for processing by 
eZImageInterface::allocateColor in /lib/ezimage/classes/ezimageinterface.php

--------------------------------------------------------------------------------
Nathan Kelly - nathan[AT]nathan-kelly[DOT]com
