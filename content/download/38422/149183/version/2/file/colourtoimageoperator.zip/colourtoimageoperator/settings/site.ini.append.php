<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=colourtoimageoperator

*/?>