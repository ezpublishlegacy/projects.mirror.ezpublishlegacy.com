<?php /* #?ini charset="utf-8"?


[ModuleSettings]
ExtensionRepositories[]=cplot
ModuleList[]=cplot

#[RoleSettings]
#PolicyOmitList[]=cplot/graph

*/?>