<?php

class FlashPlotChart{


    public static function getResult($title, $type, $render, $xlegend, $ylegend, $data, $width, $height) {

		switch($type){
			case 'candle':
				return FlashPlotChart::getCandle($title, $xlegend, $ylegend, $data, $width, $height);
			case 'bar':
				return FlashPlotChart::getBar($title, $xlegend, $ylegend, $data, $width, $height);
			case 'line':
				return FlashPlotChart::getBar($title, $xlegend, $ylegend, $data, $width, $height);
			case 'pie':
				return FlashPlotChart::getPie($title, $xlegend, $ylegend, $data, $width, $height);
			case 'radar':
				return FlashPlotChart::getRadar($title, $xlegend, $ylegend, $data, $width, $height);
		}
		
        return "";
    }
	
	public static function getCandle($title, $xlegend, $ylegend, $data, $width, $height) {

        $candledata = array();
        $xlabel=array();
        $max=0;
        $min=999999;
        $k=0;

        foreach ($data as $r) {

            if( $min > $r['low'])$min=$r['low'];

            if( $max < $r['high'])$max=$r['high'];

            $candledata[$k] = new candle_value(
                    number_format($r['high'],2),
                    number_format($r['open'],2),
                    number_format($r['close'],2),
                    number_format($r['low'],2));
					
			if(isset($r['date'])){
				$candledata[$k]->set_tooltip($r['date']."<br>High: #high#<br>Open: #open#<br>Close: #close#<br>Low: #low#");
				$xlabel[$k]=$r['date'];
			} else {
				$candledata[$k]->set_tooltip("$k<br>High: #high#<br>Open: #open#<br>Close: #close#<br>Low: #low#");
				$xlabel[$k]="$k";
			
			}
            $k++;

        }


        $candle = new candle('#E02020','#0000A0');
        $candle->set_values($candledata);
		
//$candle->set_on_show(new bar_on_show('drop', .9, 0));

        $y = new y_axis();
        $y->set_range( $min-3, $max+3, ($max-$min)/5);

        $x = new x_axis();
        $step=intval(count($data)/6);
        //echo $step;
        if(count($data)>6)
            $x->set_steps($step);
        $x->set_labels_from_array( $xlabel );

        $chart = new open_flash_chart();
		

        $chart->add_element( $candle );
        $chart->set_y_axis( $y );
        $chart->set_x_axis( $x );

		$x_legend = new x_legend( $xlegend );
		$x_legend->set_style( '{font-size: 20px; color: #778877}' );
		$chart->set_x_legend( $x_legend );
		//$chart->set_grid_colour( '#AAAAAA' );
		$y_legend = new y_legend( $ylegend );
		$y_legend->set_style( '{font-size: 22px; color: #778877}' );
		$chart->set_y_legend( $y_legend );

        

       
        return FlashPlotChart::plot($chart, $title, $width, $height);
    }
	
	public static function getBar($title, $xlegend, $ylegend, $data, $width, $height) {

        $candledata = array();
        $xlabel=array();
        $ymax=0;
        $ymin=999999;
		$xmax=0;
        $xmin=999999;
        $k=0;

        foreach ($data['y'] as $r) {

            if( $ymin > $r)$ymin=$r;

            if( $ymax < $r)$ymax=$r;

		}
					
		if(isset($data['x'])){
			foreach ($data['x'] as $r) {
				if( $xmin > $r)$xmin=$r;

				if( $xmax < $r)$xmax=$r;
				$xlabel[$k]="$r";
				$k++;
			}
			
		} else {
			$xmin=0;
			
			foreach ($data['y'] as $r) {
				$xlabel[$k]="$k";
				$k++;
			}
			$xmax=$k;
		}
            



		
        $line_1 = new bar();

        $line_1->set_values($data['y']);
		//$line_1->set_width( 3 );
//$candle->set_on_show(new bar_on_show('drop', .9, 0));
		
        $y = new y_axis();
		if($ymin>0)$ymin=0;
        $y->set_range( $ymin, $ymax+3, ($ymax-$ymin)/5);
		
		
        $x = new x_axis();
		$x->set_labels_from_array( $xlabel );
		
			
		
        $chart = new open_flash_chart();
		

        $chart->add_element( $line_1 );
        $chart->set_y_axis( $y );
        $chart->set_x_axis( $x );

		$x_legend = new x_legend( $xlegend );
		$x_legend->set_style( '{font-size: 20px; color: #778877}' );
		$chart->set_x_legend( $x_legend );
		
		$y_legend = new y_legend( $ylegend );
		$y_legend->set_style( '{font-size: 22px; color: #778877}' );
		$chart->set_y_legend( $y_legend );

        



        return FlashPlotChart::plot($chart, $title, $width, $height);
    }
	
	public static function getRadar($title, $xlegend, $ylegend, $data, $width, $height) {

        $radardata = array();

        $k=0;
		
		$xlabel=array();
		if(isset($data['x'])){
			foreach ($data['x'] as $r) {

				$xlabel[$k]="$r";
				$k++;
			}
			
		} else {

			
			foreach ($data['y'] as $r) {
				$xlabel[$k]="$k";
				$k++;
			}

		}
            

		
        $area = new area();
		// set the circle line width:
		$area->set_width( 1 );
		$area->set_default_dot_style( new s_hollow_dot('#45909F', 5) );
		$area->set_colour( '#45909F' );
		$area->set_fill_colour( '#45909F' );
		$area->set_fill_alpha( 0.4 );
		$area->set_loop();
		$area->set_values($data['y']);
		
			
		
        $chart = new open_flash_chart();	

		$chart->add_element( $area );
		$chart->x_axis = null;

		$r = new radar_axis( count($data['y']) );

		$r->set_colour( '#EFD1EF' );
		$r->set_grid_colour( '#AAAAAA' );

		$labels = new radar_axis_labels( $xlabel );
		$labels->set_colour( '#9F819F' );
		$r->set_labels( $labels );

		$chart->set_radar_axis( $r );

		$tooltip = new tooltip();
		$tooltip->set_proximity();
		$chart->set_tooltip( $tooltip );
        


		return FlashPlotChart::plot($chart, $title, $width, $height);
    }
	
	public static function getPie($title, $xlegend, $ylegend, $data, $width, $height) {

        $piedata = array();

        $k=0;
					
		if(isset($data['x'])){
			foreach ($data['x'] as $r) {

				$piedata[$k]=new pie_value($data['y'][$k], "$r");
				$k++;
			}
			
		} else {
			
			foreach ($data['y'] as $r) {
				$piedata[$k]=$r;
				$k++;
			}
			$xmax=$k;
		}
            

		
        $pie = new pie();
		$pie->set_alpha(0.6);
		$pie->set_start_angle( 35 );
		$pie->add_animation( new pie_fade() );
		$pie->set_tooltip( '#val# of #total#<br>#percent# of 100%' );
		$pie->set_colours( array('#1C9E05','#FF368D') );
		$pie->set_values( $piedata );
		
			
		
        $chart = new open_flash_chart();	

		$chart->add_element( $pie );
		$chart->x_axis = null;


        return FlashPlotChart::plot($chart, $title, $width, $height);
    }
	
	public static function plot( $chart, $title, $width, $height) {
		$chart->set_bg_colour( '#FFFFFF' );
		
		$ctitle=new title( $title );
		$ctitle->set_style( "{font-size: 20px; font-family: Times New Roman; font-weight: bold; color: #333333; text-align: center;}" );
        $chart->set_title( $ctitle );
		
        $id=CPlotOperator::$count;
		CPlotOperator::$count++;
        $result = "
                <div id=\"my_chart$id\">
					<h1>Download Flash</h1>
					<p><a href=\"http://www.adobe.com/go/getflashplayer\"><img src=\"http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif\" alt=\"Get Adobe Flash player\" /></a></p>
				</div>

                <script type=\"text/javascript\">
                    swfobject.embedSWF(\"".eZSys::wwwDir()."/extension/cplot/design/standard/flash/open-flash-chart.swf\", \"my_chart$id\", \"".$width."\", \"".$height."\", \"9.0.0\", \"".eZSys::wwwDir()."/extension/cplot/design/standard/flash/expressInstall.swf\", {\"get-data\":\"get_data_$id\"} );
                </script>
                <script type=\"text/javascript\">

                function get_data_$id()
                {
                        return JSON.stringify(data$id);
                }


                var data$id = ".$chart->toPrettyString().";

                </script>";
        return $result;
	
	}



}

?>
