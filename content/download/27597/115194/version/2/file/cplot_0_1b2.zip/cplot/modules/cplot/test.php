<?php

//require_once("extension/cplot/lib/Math/REGRESS/SimpleRegression.php");
//include_once( "lib/ezutils/classes/ezfilehandler.php" );

//include_once( "lib/ezdb/classes/ezdb.php" );


/*
$db = eZDB::instance();


$res = $db->arrayQuery("SELECT data, PREABE
FROM `cotacoes`
WHERE CODNEG = 'petr4'
AND DATA > '2008-01-01'");
$data = array();
$k=0;
$index = array();
foreach ($res as $r) {



    $X[$k]=date("d/m/y", strtotime($r['data']));

    $Y[$k]=$r['PREABE'];
    $index[$k]=$k;
    $k++;



}


//$ls=new LeastSquares($Y,$index,2);


$conf_int = 95;

$slr = new SimpleRegression($index, $Y, $conf_int);




$svg="graph1.svg";
$width=800;
$height=300;
$code="<object data=\"".eZSys::wwwDir()."/"
        .$svg."\" height=\"".$height."\"
type=\"\image/svg+xml\" width=\"".$width."\"></object>";

$graph = new ezcGraphLineChart(); 
$graph->title = 'Cotação petr4';

$graph->yAxis->label  = 'R$';


for ( $i  = 0; $i < count($Y); $i++ ) {
    $x="".$X[$i]."";
    $data[$x] = $Y[$i];
}
$graph->data['Real'] = new ezcGraphArrayDataSet( $data );

$data=array();
//$graph->data['Previsão'] = new ezcGraphArrayDataSet( $ls->getResults($X) );
for ( $i  = 0; $i <  count($Y); $i++ ) {
    $x="".$X[$i]."";

    $data[$x] = $slr->getYInt() + ($slr->getSlope()*$i);
}
$graph->data['Previsão1'] = new ezcGraphArrayDataSet( $data );
$graph->render( $width, $height, $svg );
*/
$tpl = eZTemplate::factory();

//$tpl->setVariable('code',$code);
$Result = array();
$Result['path'] = array( array( 'url' => false,

                'text' => 'CPlot Test' ),

        array( 'url' => false,

                'text' => 'Graph' ) );
$Result['content']=$tpl->fetch("design:cplot/test.tpl");

?>
