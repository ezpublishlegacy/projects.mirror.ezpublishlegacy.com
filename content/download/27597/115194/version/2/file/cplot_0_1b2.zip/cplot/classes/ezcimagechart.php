<?php

class ezcImageChart {
 public static function getResult($title, $type, $render, $xlegend, $ylegend, $data, $width, $height) {
		umask (0000);
		$ini = eZINI::instance( 'texttoimage.ini' );
		$TemporaryImageDirPath = $ini->variable( 'PathSettings', 'CacheDir' ). '/';
		
		if(!file_exists($TemporaryImageDirPath)) 
		{ 
			mkdir($TemporaryImageDirPath); 

		} 	
		


		$id=time().CPlotOperator::$count;
		CPlotOperator::$count++;		
		
		$rendered_chart="g".$id.".".$render;
		$rendered_chartpath=$TemporaryImageDirPath.$rendered_chart;
		
		$chartdata = array();		
		$graph;
		switch ($type){
			case 'line':
				$graph = new ezcGraphLineChart();
				break;
			case 'bar':
				$graph = new ezcGraphBarChart(); 
				break;
			case 'pie':
				$graph = new ezcGraphPieChart();
				break;	
			case 'radar':
				$graph = new ezcGraphRadarChart(); 
				break;		
		
		}
		
		if ( !($type == 'pie' or $type == 'radar')) $graph->xAxis->label  = $xlegend;

		$graph->title = $title;
		
		$graph->palette = new  ezcGraphPaletteEzBlue(); 
		
		

		if(isset($data['x'])){

			for ( $i  = 0; $i < count($data['x']); $i++ ) {
				$x="".$data['x'][$i]."";

				$chartdata[$x] = $data['y'][$i];
			}
			
		} else {
			for ( $i  = 0; $i < count($data['y']); $i++ ) {
				$chartdata[$i] = $data['y'][$i];
			}
			
		}
		
		$graph->data[$ylegend] = new ezcGraphArrayDataSet( $chartdata );

		
		$code="";
		switch ($render){
			case 'png':
				$graph->driver = new  ezcGraphGdDriver(); 
		
				$graph->driver->options->supersampling = 1;

				$graph->palette = new  ezcGraphPaletteEzBlue(); 
				$graph->driver->options->imageFormat = IMG_PNG; 
				$tpl = eZTemplate::factory();
				$fontpath=str_replace(eZSys::instance()->wwwDir() . '/', "", eZURLOperator::eZDesign($tpl,'fonts/font.ttf',''));
				$graph->options->font  = $fontpath; 	
				$graph->options->font->maxFontSize = 10; 
				$graph->title->font->maxFontSize = 14; 
				
				$code = "<img src=\"".eZSys::wwwDir()."/".$rendered_chartpath."\" alt=\"".$title."\" />";
				break;
			case 'svg':
				$code = "<object data=\"".eZSys::wwwDir()."/"
						.$rendered_chartpath."\" height=\"".$height."\"
						type=\"\image/svg+xml\" width=\"".$width."\"></object>";
				break;
		
		}
		
		$graph->render( $width, $height, $rendered_chart );
		
		rename($rendered_chart,$rendered_chartpath);
		
		return $code;
		
    }


}

?>
