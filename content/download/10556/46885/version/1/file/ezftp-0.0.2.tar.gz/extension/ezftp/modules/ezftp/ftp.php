<?php

eZExecution::cleanExit();

?>