<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=mbpaex

*/ ?>
