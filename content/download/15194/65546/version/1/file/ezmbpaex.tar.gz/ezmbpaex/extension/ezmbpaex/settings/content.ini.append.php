<?php /* #?ini charset="utf8"?

[DataTypeSettings]
ExtensionDirectories[]=mbpaex
AvailableDataTypes[]=ezpaex

[ContentOverrideSettings]
EnableClassGroupOverride=true

*/ ?>
