<?php

/**

    PDF catalogue extension for eZ Publish - Information about the extension

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

class abpdfcatalogueInfo
{

    public static function info()
    {
        return array( 'Name'      => 'ab PDF Catalogue',
                      'Version'   => '0.9.6',
                      'Copyright' => 'Copyright (C) 2009-' . date( 'Y' ) . ' <a href="http://www.alexander-block.net/">Alexander Block</a>',
                      'License'   => 'GNU General Public License v2.0',
                      'Includes the third-party FPDF software' => array(
                            'Name'      => '<a href="http://www.fpdf.org/">FPDF</a> library',
                            'Version'   => '1.6',
                            'Copyright' => 'Olivier Plathey',
                            'License'   => 'permissive license: there is no usage restriction. You may embed it freely in your application (commercial or not), with or without modifications.'
                      ),
                      'Includes the third-party FPDI software' => array(
                            'Name'      => '<a href="http://www.setasign.de/products/pdf-php-solutions/fpdi">FPDI</a>',
                            'Version'   => '1.3.2',
                            'Copyright' => '2004-2010 Setasign',
                            'License'   => 'Apache License, Version 2.0'
                      ),
                      'Includes the third-party Paradox PDF software' => array(
                            'Name'      => '<a href="http://www.tricinty.com">Tricinty</a>',
                            'Version'   => '2.1.4',
                            'Copyright' => 'Copyright (C) 2009 Mohamed Karnichi',
                            'License'   => 'GNU General Public License v2.0'
                      )
                    );
    }

}

?>
