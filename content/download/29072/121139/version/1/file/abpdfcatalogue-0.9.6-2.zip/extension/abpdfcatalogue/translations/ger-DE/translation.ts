<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_GB">
<context>
    <name>design/abpdfcatalogue/send</name>
    <message>
        <source>Please fill out the form below to send an email to the person you want to recommend your personal PDF catalogue. The send button will be activated once you have filled out the form correctly. If the email could not be send, the form will remain as is after clicking the send button, otherwise it will be closed. A link to this PDF catalogue will be appended to the email text automatically.</source>
        <translation>Bitte füllen Sie das unten angezeigte Formular aus, um den persönliches PDF Katalog per E-Mail weiter zu empfehlen. Der Senden Knopf wird aktiviert, sobald das Formular korrekt ausgefüllt wurde. Falls die E-Mail nicht erfolgreich verschickt werden kann, wird das Formular nach dem Anklicken des Senden Knopfes weiterhin angezeigt, andernfalls wird es wieder ausgeblendet. Ein Verweis auf den PDF Katalog wird automatisch an den Text der E-Mail angehängt.</translation>
    </message>
    <message>
        <source>Sender Email</source>
        <translation>E-Mail des Senders</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Ungültig</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Betreff</translation>
    </message>
    <message>
        <source>%1 - PDF Catalogue recommendation</source>
        <translation>%1 - Empfehlung eines PDF Katalogs</translation>
    </message>
    <message>
        <source>Receiver Email</source>
        <translation>E-Mail des Empfängers</translation>
    </message>
    <message>
        <source>Email Text</source>
        <translation>E-Mail Text</translation>
    </message>
    <message>
        <source>Dear</source>
        <translation>Sehr geehrter</translation>
    </message>
    <message>
        <source>I prepared the following PDF catalogue for you. Please use the link below to access the recommended catalogue.</source>
        <translation>Ich habe den folgende PDF Katalog für Sie vorbereitet. Bitte verwenden Sie den u.a. Verweis, um den empfholenen PDF Katalog anzuzeigen.</translation>
    </message>
    <message>
        <source>Sincerely</source>
        <translation>Mit freundlichen Grüßen</translation>
    </message>
    <message>
        <source>Send email</source>
        <translation>E-Mail senden</translation>
    </message>
    <message>
        <source>Click on this button to send the selected pages of the PDF catalogue by email to the receiver you entered in the form above</source>
        <translation>Klicken Sie auf diese Schaltfläche, um die ausgewählten Seiten des PDF Katalogs per E-Mail an den im Formular angegebenen Empfänger zu verschicken</translation>
    </message>
    <message>
        <source>You do not have the permission to send this personal PDF catalogue</source>
        <translation>Sie haben keine ausreichende Berechtigung, um den PDF Katalog zu versenden</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Click on this button to cancel the send out of the selected PDF catalogue pages by email</source>
        <translation>Klicken Sie auf diese Schaltfläche, um den Versand der ausgewählten Seiten des PDF Katalogs abzubrechen</translation>
    </message>
</context>
<context>
    <name>design/abpdfcatalogue/view</name>
    <message>
        <source>Create catalogue</source>
        <translation>Katalog erstellen</translation>
    </message>
    <message>
        <source>Loading</source>
        <translation>Lade</translation>
    </message>
    <message>
        <source>You do not have the permission to generate a personal PDF catalogue</source>
        <translation type="obsolete">Sie haben keine Berechtigung, um einen personalisierten PDF Katalog zu erstellen</translation>
    </message>
    <message>
        <source>Remove document</source>
        <translation>Dokument entfernen</translation>
    </message>
    <message>
        <source>Download document</source>
        <translation>Dokument herunterladen</translation>
    </message>
    <message>
        <source>show</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>No documents selected</source>
        <translation>Keine Dokumente ausgewählt</translation>
    </message>
    <message>
        <source>Use the mouse to drag catalogue documents and drop them in the target zone</source>
        <translation>Nehmen Sie Katalog Dokumente mit der Maus auf und lassen Sie sie im Zielbereich wieder los</translation>
    </message>
    <message>
        <source>You do not have the permission to generate this personal PDF catalogue</source>
        <translation>Sie haben keine ausreichende Berechtigung, um den PDF Katalog zu erstellen</translation>
    </message>
    <message>
        <source>Send catalogue</source>
        <translation>Katalog versenden</translation>
    </message>
    <message>
        <source>Click on this button to open a form for sending the selected PDF catalogue pages by email to somebody else</source>
        <translation>Klicken Sie auf diese Schaltfläche, um ein Formular zum Versenden der ausgewählten Seiten dieses PDF Katalogs per E-Mail an jemand anderen zu öffnen</translation>
    </message>
    <message>
        <source>You do not have the permission to send this personal PDF catalogue</source>
        <translation>Sie haben keine ausreichende Berechtigung, um diesen persönlichen PDF Katalog zu versenden</translation>
    </message>
    <message>
        <source>Current node</source>
        <translation>Aktueller Knoten</translation>
    </message>
    <message>
        <source>Click here to finally create a PDF catalogue from the selected pages</source>
        <translation>Klicken Sie auf diese Schaltfläche, um den PDF Katalog aus den ausgewählten Seiten zu erzeugen</translation>
    </message>
    <message>
        <source>No items in catalogue</source>
        <translation>Bisher keine Seiten</translation>
    </message>
    <message>
        <source>Click here to get this page as a PDF document</source>
        <translation>Klicken Sie hier, um die aktuelle Seite als PDF Dokument zu erhalten</translation>
    </message>
</context>
<context>
    <name>pdfcatalogue</name>
    <message>
        <source>Page %1 of %2</source>
        <translation>Seite %1 von %2</translation>
    </message>
    <message>
        <source>Page %1</source>
        <translation>Seite %1</translation>
    </message>
</context>
</TS>
