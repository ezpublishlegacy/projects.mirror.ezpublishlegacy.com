<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezipcountry/kernel/common/ezipcountryoperator.php',
                                    'class' => 'eZIPCountryOperator',
                                    'operator_names' => array( 'ezipcountry' ) );
