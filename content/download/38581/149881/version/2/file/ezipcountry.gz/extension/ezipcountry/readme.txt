Installation
------------
See the installation.txt file


Reference
------------
This routine uses the database and converstion PHP code from http://ip-to-country.com
The base of this code is from ezRSS release by eZ publish http://ez.no