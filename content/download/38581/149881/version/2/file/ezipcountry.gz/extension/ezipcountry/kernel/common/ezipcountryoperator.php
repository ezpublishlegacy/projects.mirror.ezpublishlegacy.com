<?php
//
// Definition of eZIPCountryOperator class
//
// Created on: <9-May-2003 TW>
//
// Copyright (C) 1999-2003 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation 
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//

/*! \file eZCCTVOperator.php
*/

/*!
  \class eZCCTVOperator eZCCTVoperator.php
  \brief The class eZCCTVOperator get the country from the ip address range

*/
class eZIPCountryOperator
{
    /*!
     Initialises the object with the name $name, default is "ezipcountry".
    */
    function eZIPCountryOperator( $name = "ezipcountry" )
    {
	$this->Operators = array( $name );
    }

    /*!
	Returns the template operators.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    function namedParameterList()
    {
        return array( 'ip_command' => array( 'type' => 'string',
                                           'required' => true,
                                           'default' => false ));
    }

    /*!
    Converts IP adress to IP number
    */
    function IPAddress2IPNumber($dotted) {
   		$dotted = preg_split( "/[.]+/", $dotted);
    	$ip = (double) ($dotted[0] * 16777216) + ($dotted[1] * 65536) + ($dotted[2] * 256) + ($dotted[3]);
        return $ip;
    }

    /*!
    Not currently used but in for reference
    */
    function IPNumber2IPAddress($number) {
        $a = ($number / 16777216) % 256;
        $b = ($number / 65536) % 256;
        $c = ($number / 256) % 256;
        $d = ($number) % 256;
        $dotted = $a.".".$b.".".$c.".".$d;
        return $dotted;
    }
     
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
    	include_once( "lib/ezdb/classes/ezdb.php" );

    	// fetch the database instance
 		$db =& eZDB::instance();

		// Get client ip address
		$my_ip=getenv('REMOTE_ADDR');
		
		//$my_ip="10.0.0.1"; // for testing
		
		$ipnumber=  $this->IPAddress2IPNumber( $my_ip );
				
  		// fetch country data
  		$rows =& $db->arrayQuery( "SELECT country_name, country_code FROM ezipcountry WHERE $ipnumber BETWEEN ip_from AND ip_to" );
        
		//Create values for eZ publish templates
		$ipData['version'] = "0.1";
		$ipData['client_ip'] = $my_ip;
		$ipData['ip_number'] = $ipnumber;
		$ipData['rows'] = $rows;

		if  ( $row = $rows[0] ) {
  		$ipData['long_name'] = $row["country_name"];
     	$ipData['short_name'] = $row["country_code"];
		}
		else {
		
		// If range is unkown return this
		$ipData['long_name'] = "unknown";
     	$ipData['short_name'] = "XX";
		}
             
        // Return data
        $operatorValue = $ipData;
    }

    
    var $Operators;
}
?>
