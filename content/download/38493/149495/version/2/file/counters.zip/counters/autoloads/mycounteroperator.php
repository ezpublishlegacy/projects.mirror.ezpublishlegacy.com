<?php   
/*
  Template operator to handle counters
  based on a custom content class
  
  date: 01.06.2006
  by: Nebojsa Eric, eMail: nebojsa@outsys.co.uk
*/


include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'kernel/classes/ezcontentcachemanager.php' );

class MyCounterOperator {    
/*!     Constructor    */
    function MyCounterOperator()    {
	        $this->Operators = array( 'getcounter' );    
			}      
/*!     Returns the operators in this class.    */
    function &operatorList()    {
	        return $this->Operators;    }      

/*!      
   Return true to tell the template engine that the parameter list
   exists per operator type, this is needed for operator classes
   that have multiple operators.    */

    function namedParameterPerOperator()    {
	        return true;    
	}
/*!     The first operator has two parameters, the other has none.
        See eZTemplateOperator::namedParameterList()    */

    function namedParameterList()    { 
            return array( 'getcounter' => array( 'nodeid' => array( 'type' => 'integer', 'required' => true), 'attributeid' => array( 'type' => 'integer', 'required' => true ), 'shouldincrement' => array( 'type' => 'integer', 'required' => true ) ), -1 => array() );    
	}
/*!     Executes the needed operator(s).
        Checks operator names, and calls the appropriate functions.    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters ) {
	        switch ( $operatorName )
	        {
               case 'getcounter':
               {
                  $operatorValue = $this->getCounter( $namedParameters['nodeid'], $namedParameters['attributeid'], $namedParameters['shouldincrement'] );
               } break;
/*   
               case -1:
               {                
  			      $operatorValue = $this->helloWorld();
  			   } break;*/
            }    
	}
			
/*   Update class with A + 1 result.    */
    function getCounter( $nodeid, $attributeid, $shouldincrement )    {
           $anode =& eZContentObjectTreeNode::fetch( $nodeid );
           if ( !$anode )
           {
                  eZDebugSetting::writeDebug( 'kernel-notification',
                                        'Newsletter module: No node with ID: ' . $nodeid );
               return;
           }
		   
           $anodeObject =& $anode->object();
           $attributes =& $anodeObject->contentObjectAttributes();
           $atvalue = $attributes[$attributeid]->content();

		   if ($shouldincrement == 1)
		   {
			 $atvalue = $atvalue + 1;
             $attributes[$attributeid]->setAttribute( "data_int", $atvalue );
             $attributes[$attributeid]->store();

		     /* store object */
		     $anodeObject->store(); 
		   
             // publish the new version  
		     $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $anodeObject->attribute( 'id' ), 'version' => $anodeObject->attribute('current_version') ) );

             // manually clear cache for object
		     eZContentCacheManager::clearContentCacheIfNeeded( $anodeObject->attribute( 'id' ) );
		   }

		   /* return */
           return $atvalue;
    } 

/// privatesection    var $Operators; }			
}
?>