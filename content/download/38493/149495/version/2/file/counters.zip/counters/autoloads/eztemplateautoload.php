<?php   
  // Operator autoloading   
  $eZTemplateOperatorArray = array();   
  $eZTemplateOperatorArray[] = array( 'script' => 'extension/counters/autoloads/mycounteroperator.php', 'class' => 'MyCounterOperator', 'operator_names' => array( 'getcounter' ) );   
?>