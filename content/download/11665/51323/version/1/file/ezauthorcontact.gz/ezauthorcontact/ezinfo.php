<?php

class ezauthorcontactInfo
{
    function info()
    {
        return array( 'Name' => "eZ Author Contact",
                      'Version' => "1.0.0",
                      'Copyright' => "Copyright (C) 1999-2006 eZ systems AS",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
