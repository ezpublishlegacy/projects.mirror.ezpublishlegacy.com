<?php /*

[RegionalSettings]
TranslationExtensions[]=ezauthorcontact

*/ ?>