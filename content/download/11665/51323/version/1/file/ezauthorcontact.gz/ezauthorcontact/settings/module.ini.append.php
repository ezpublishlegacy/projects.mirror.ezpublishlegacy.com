<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezauthorcontact

*/ ?>