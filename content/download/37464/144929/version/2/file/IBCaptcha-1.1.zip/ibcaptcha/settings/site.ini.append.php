<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=ibcaptcha

[RoleSettings]
PolicyOmitList[]=ibcaptcha/get

*/ ?>