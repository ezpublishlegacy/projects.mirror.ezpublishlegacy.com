<?php
[DataTypeSettings]
ExtensionDirectories[]=ibcaptcha
AvailableDataTypes[]=ibcaptcha
?>
