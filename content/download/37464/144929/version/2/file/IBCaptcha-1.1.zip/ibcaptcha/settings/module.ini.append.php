[ModuleSettings]
ExtensionRepositories[]=ibcaptcha