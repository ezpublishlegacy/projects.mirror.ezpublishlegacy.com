<?php
[ExtensionSettings]
DesignExtensions[]=ibcaptcha

[JavaScriptSettings]
JavaScriptList[]=mootools-1.2.js
JavaScriptList[]=mootools-1.2-plugins.js
JavaScriptList[]=moorainbow.js
JavaScriptList[]=colorpickersinstall.js

[StylesheetSettings]
CSSFileList[]=colorpicker.css
?>
