<?php
class ibcaptchaInfo {
    function info() {
        return array(
            'Name'      => 'IB Captcha',
            'Version'   => '1.0.0',
            'Copyright' => 'Copyright (C) 2009 <a href="http://i-b.com.com/">Internet Bureau</a>',
            'Author'    => 'Dolgushev Serhey, Internet Bureau',
            'License'   => 'GNU General Public License'
        );
    }
}
?>