<? /* #?ini charset="utf-8"?

### SHOULD NOT BE CHANGED
[DatatypeSettings]
# 1st value is the type of data
TableStructure[]
TableStructure[id]=int
TableStructure[value]=varchar
TableStructure[ezcontentobject_id]=int
TableStructure[ezcontentobject_alias]=varchar
TableStructure[ezcontentobject_attribute_id]=int
TableStructure[ezcontentclass_identifier]=varchar
TableStructure[modified]=int
### /SHOULD NOT BE CHANGED

# ID of the content class attribute targeted by the objectrelation of the class
# _class_name_[_datatype_identifier_]=_id_
[MetaSearchTargetContentClassAttributeID]

# THIS BELOW IS FOR EXAMPLE PURPOSE AND CAN BE REMOVED FREELY
gp_news[fiches_jeu]=308
gp_news[illustration]=337
gp_news[personnalites]=392
gp_news[entreprises]=382

gp_personnalite[a_travaille_sur]=308
gp_personnalite[a_travaille_pour]=382

gp_illustration[fiches_jeu]=308

# /END REMOVABLE

[ResultDisplaySettings]
Limit=10

*/

?>
