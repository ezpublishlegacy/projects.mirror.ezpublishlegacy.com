﻿<!DOCTYPE TS><TS>
<context>
    <name>ezstringindexed/metasearch/result</name>
    <message>
        <source>No results were found. Check your typing or create a new object.</source>
        <translation>Aucun résultats trouvés. Vérifier l'orthographe ou créer un nouvel objet.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Please provide a valid object name then choose among the results below</source>
        <translation>Entrez un nom d'objet valide puis choississez parmi les résultats ci-dessous</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Text line with object indexed</source>
        <translation>Ligne de texte avec contenu indexé</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Change to "ezstringindexed" datatype</source>
        <translation>Transformer ce champ en "ezstringindexed"</translation>
    </message>
    <message>
        <source>Choose database table</source>
        <translation>Choississez la table dans la base de données</translation>
    </message>
    <message>
        <source>Not implemented yet. Stay tuned.</source>
        <translation>Pas encore implémenté. Stay tuned.</translation>
    </message>
</context>
</TS>