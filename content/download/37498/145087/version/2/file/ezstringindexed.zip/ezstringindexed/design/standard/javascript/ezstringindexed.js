var myTimeout = 1;
var timeBeforeRequest = 50;
var AttributeBase = "ContentObjectAttribute";
function metaSearchInitTimer( inputObject , targetContentClassAttributeID , editVersion )
{
    value = inputObject.value;
    if( value.length >= 2 )
    {
        idSplited = inputObject.id.split( "_" );
        window.clearTimeout( myTimeout );
        myTimeout = window.setTimeout( "xajax_metaSearchQuery('" + value + "' , " +  idSplited[1] + " , " + targetContentClassAttributeID + " , " + editVersion + " )" , timeBeforeRequest );
    }
}

function metaSearchSelectResultObjectrelationlist( nodeID , contentObjectID , contentObjectAttributeID , name )
{
    ulTargetElement = document.getElementById( 'UnorderedListAttribute_' + contentObjectAttributeID );
    liElement = document.createElement("li");
    
    checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.defaultChecked = true;
    
    tempId = AttributeBase + "_data_object_relation_list_" + contentObjectAttributeID + "[" + nodeID + "]";
    checkbox.id = tempId;
    checkbox.value = contentObjectID;
    
    liElement.appendChild( checkbox );
    ulTargetElement.appendChild( liElement );
    liElement.innerHTML += name;
    
    document.getElementById( tempId ).value = contentObjectID;
    document.getElementById( tempId ).name = AttributeBase + "_data_object_relation_list_" + contentObjectAttributeID + "[" + nodeID + "]";
}

function metaSearchSelectResultObjectrelation( nodeID , contentObjectID , contentObjectAttributeID , name )
{
    ulTargetElement = document.getElementById( 'UnorderedListAttribute_' + contentObjectAttributeID );
    ulTargetElement.innerHTML = "";
    liElement = document.createElement("li");
    
    checkbox = document.createElement("input");
    checkbox.type = "hidden";
    
    tempId = AttributeBase + "_data_object_relation_id_" + contentObjectAttributeID;
    checkbox.id = tempId;
    checkbox.value = contentObjectID;
    
    liElement.appendChild( checkbox );
    ulTargetElement.appendChild( liElement );
    liElement.innerHTML += name;
    
    document.getElementById( tempId ).value = contentObjectID;
    document.getElementById( tempId ).name = tempId;
}