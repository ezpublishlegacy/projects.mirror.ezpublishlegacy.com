
<?php
/*!
  \class   TemplateTestOperator templatetestoperator.php
  \ingroup eZTemplateOperators
  \brief   Prend en charge l'opérateur de template test. En utilisant test vous pouvez...
  \version 1.0
  \date    Jeudi 28 Décembre 2006 12:46:38 pm
  \author  Alimi Nabil

  

  Exemple:
\code
{gp_get_db_tablesname()}
\endcode
*/

/*
If you want to have autoloading of this operator you should create
a eztemplateautoload.php file and add the following code to it.
The autoload file must be placed somewhere specified in AutoloadPath
under the group TemplateSettings in settings/site.ini

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'templatetestoperator.php',
                                    'class' => 'TemplateTestOperator',
                                    'operator_names' => array( 'test' ) );

If your template operator is in an extension, you need to add the following settings:

To extension/YOUREXTENSION/settings/site.ini.append:
---
[TemplateSettings]
ExtensionAutoloadPath[]=YOUREXTENSION
---

To extension/YOUREXTENSION/autoloads/eztemplateautoload.php:
----
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/YOUEXTENSION/YOURPATH/templatetestoperator.php',
                                    'class' => 'TemplateTestOperator',
                                    'operator_names' => array( 'test' ) );
---

Create the files if they don't exist, and replace YOUREXTENSION and YOURPATH with the correct values.

*/


class eZStringIndexedOperators
{
    /*!
      Constructeur, par défaut ne fait rien.
    */
    function eZStringIndexedOperators()
    {
    }

    /*!
     
eturn an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'gp_db_get_tables_name' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'gp_db_get_tables_name' => array(  ) );
    }
    /*!
     Exécute la fonction PHP correspondant à l'opérateur "cleanup" et modifie \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        // Exemple de code, ce code doit être modifié pour que l'opérateur fasse ce qu'il doit faire. Actuellement il effectue juste un "trim" du texte.
        switch ( $operatorName )
        {
            case 'gp_db_get_tables_name':
            {
                $operatorValue = $this->gpGetDbTablesName();
            } break;
        }
    }
    
    /**
    * @desc Retourne les tables de la base de donn�es
    * 
    * @return array Tables de la base
    */
    function gpGetDbTablesName()
    {
        $query = "SHOW TABLES ";
        $gpDB = ezdb::instance();
        
        $tablesName = $gpDB->arrayQuery( $query );        
        return $tablesName;
    }
}

?>