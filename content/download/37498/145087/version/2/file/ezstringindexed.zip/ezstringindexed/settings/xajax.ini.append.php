<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
ExtensionDirectories[]=ezstringindexed

# metaSearchQuery is the function name
# query(.php) is the file under the xajax/ dir which contains the function
AvailableFunctions[metaSearchQuery]=query

[DebugSettings]
DebugAlert=disabled
*/

?>
