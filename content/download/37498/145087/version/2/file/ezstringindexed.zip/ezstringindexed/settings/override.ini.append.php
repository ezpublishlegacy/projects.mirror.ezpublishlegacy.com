<?php /* #?ini charset="utf-8"?

[metasearch_result_objectrelation]
Source=ezstringindexed/metasearch_results.tpl
Subdir=templates
MatchFile=ezstringindexed/metasearch_results/objectrelation.tpl
Match[contentobjectattribute_type]=ezobjectrelation

*/
?>
