<?
$Module = array( 'name' => 'EzstringIndexed Module' );

$ViewList['upgradeezstring'] = array( 'script' => 'upgradeezstring.php', 'params' => array( 'ContentClassAttributeID' , 'EditLanguage' , 'ContentClassID' ) );
$ViewList['updatecontentobjectattribute'] = array( 'script' => 'updatecontentobjectattribute.php', 'params' => array( 'ContentClassAttributeID' ) );

?>
