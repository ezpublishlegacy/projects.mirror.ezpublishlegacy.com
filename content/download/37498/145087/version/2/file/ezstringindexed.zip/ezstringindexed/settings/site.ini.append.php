<? /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezstringindexed

[RegionalSettings]
TranslationExtensions[]=ezstringindexed
*/
?>
