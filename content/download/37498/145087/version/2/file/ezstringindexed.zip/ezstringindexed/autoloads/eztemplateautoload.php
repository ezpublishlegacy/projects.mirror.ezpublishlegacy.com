<?php
/**
* D�clarations
*
* @author Alimi Nabil <nal@ingenieursetconsultants.com>
* @copyright Alimi Nabil
* @since 28/12/2006
* @version 1.0
*/
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezstringindexed/autoloads/ezstringindexedoperators.php',
        				'class' => 'eZStringIndexedOperators',
        				'operator_names' => array( 'gp_db_get_tables_name' ) );
?>
