<?
include_once( "lib/ezutils/classes/ezini.php" ) ;
class eZStringindexedFunctions
{
    /**
    * @desc Checks if choosen table has the right structure. We check every column of the chosen Table with the definition in the ini file.
    * 
    * @param string $tableName Choose table
    * @return boolean Returns true or false. If there is more or less fields in the two => returns false. If type differs, returns false.
    */
    function checkTableStructure( $tableName )
    {
        if( $tableName == '' )
            return false;
        $query = "SHOW COLUMNS FROM ".$tableName;
        $gpDB = ezdb::instance();
        $chosenTableStructure = $gpDB->arrayQuery( $query );
        
        $gpINIezStringIndexed = ezini::instance( 'ezstringindexed.ini.append.php' );
        $gpINITableStructure = $gpINIezStringIndexed->variable( 'DatatypeSettings' , 'TableStructure' );
        
        // Pour chaque ligne de la table choisit
        // On v�rifie qu'elle est d�finit dans le fichier de configuration
        // Et que son type correspond � celui d�finit dans le fichier de conf
        foreach( $chosenTableStructure as $row )
        {
            if( !isset( $gpINITableStructure[$row['Field']] ) || ( strpos( $row['Type'] , $gpINITableStructure[$row['Field']] ) === false ) )
            {
                return false;
            }
        }
        return true;
    }
}
