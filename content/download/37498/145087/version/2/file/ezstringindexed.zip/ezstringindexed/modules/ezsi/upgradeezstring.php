<?php

/**
* @desc Update datatype to "ezstringindexed" type
* 
* Direct SQL Query upon database. Bouh, ugly.
* 
* @param int $contentClassAttributeID
* @param string $dbTable
* 
* @return bool
*/
$Module =& $Params['Module'];


$http =& eZHTTPTool::instance();
$contentClassAttributeID = $Params['ContentClassAttributeID'];

if( $http->hasPostVariable( 'TransformIntoEzstringindexed_'.$contentClassAttributeID ) && $http->hasPostVariable( 'DBTableName_'.$contentClassAttributeID ) )
{
    echo "OK : step 1";
    $dbTableName = $http->postVariable( 'DBTableName_'.$contentClassAttributeID );
    echo $dbTableName;
    echo $contentClassAttributeID;
    //return upgradeEzstringToEzstringindexed( (int)$contentClassAttributeID , $dbTableName );
    if( $contentClassAttributeID != 0 && !is_null( $dbTableName ) )
    {
        include_once( 'extension/ezstringindexed/classes/ezstringindexedfunctions.php' );
        include_once( "lib/ezutils/classes/ezini.php" ) ;
        if( !eZStringindexedFunctions::checkTableStructure( $dbTable ) )
            return false;
        $gpDB =& eZDB::instance();
        
        $gpDB->begin();
        
        $query = "UPDATE ezcontentclass_attribute 
        SET data_type_string = 'ezstringindexed', 
        data_text2 = '".$dbTable."',
        data_int2 = 1
        WHERE data_type_string = 'ezstring'
        AND version = 1
        AND id = ".$contentClassAttributeID;
        echo $query;
        $gpDB->query( $query ) or die( mysql_error() );
        
        /*
        $query = "UPDATE ezcontentobject_attribute SET data_type_string = 'ezstringindexed'
        WHERE data_type_string = 'ezstring'
        AND contentclassattribute_id = ".$contentClassAttributeID;
        $gpDB->query( $query ) or die( mysql_error() );
        */
        
        $gpDB->commit();
        $ClassID = $http->postVariable( 'ContentClassID' );
        $EditLanguage = $http->postVariable( 'CurrentLanguage' );
        $Module->redirectTo( 'class/edit' . '/' . $ClassID . '/(language)/' . $EditLanguage );
        return true;
    }
    return false;
}
else
    return false;

?>
