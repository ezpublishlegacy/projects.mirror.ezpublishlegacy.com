<?

include_once( "lib/ezutils/classes/ezini.php" ) ;
/**
* @desc Retrieves objects from specific database table based on user input
* 
* @param string $input User input
* @param int $contentObjectAttributeID Id of current attribute that the user wants to fill
* @param int $targetContentClassAttributeID The related id the content class
*/
function metaSearchQuery( $input , $contentObjectAttributeID , $targetContentClassAttributeID , $editVersion , $offset = 0 )
{
    $objResponse = new xajaxResponse();
    
    include_once( 'kernel/classes/ezcontentclassattribute.php' );
    include_once( 'kernel/classes/ezcontentobjectattribute.php' );
    $targetContentClassAttribute = eZContentClassAttribute::fetch( $targetContentClassAttributeID );
    $dbTable = $targetContentClassAttribute->attribute( 'data_text2' );
    
    $targetContentClass =& eZContentClass::fetch( $targetContentClassAttribute->attribute( 'contentclass_id' ) );
    $targetContentClassIdentifier = $targetContentClass->attribute( 'identifier' );
    
    $contentObjectAttribute =& eZContentObjectAttribute::fetch( $contentObjectAttributeID , $editVersion );
    $contentObjectAttributeType = $contentObjectAttribute->attribute( 'data_type_string' );
    
    include_once( "lib/ezi18n/classes/ezchartransform.php" );
    $translator =& eZCharTransform::instance();
    $cleanInput = $translator->transformByGroup( $input , 'urlalias' );
    
    $ezsiINI = ezini::instance( 'ezstringindexed.ini' );
    $limit = $ezsiINI->variable( 'ResultDisplaySettings' , 'Limit' );
    if( $offset < 0 )
        $offset = 0;
    else
        $offset = (int)$offset;
    
    $gpDB =& ezdb::instance();
    $query = "SELECT ezcontentobject_id , value FROM ".$dbTable." 
    WHERE ezcontentobject_alias LIKE '%".$gpDB->escapeString( $cleanInput )."%' 
    AND ezcontentclass_identifier = '".$targetContentClassIdentifier."' 
    ORDER BY 'value' ASC";
    $queryResults = $gpDB->arrayQuery( $query , array( 'limit' => $limit , 'offset' => $offset ) );
    
    $query = "SELECT count(*) as total_count FROM ".$dbTable." 
    WHERE ezcontentobject_alias LIKE '%".$gpDB->escapeString( $cleanInput )."%' 
    AND ezcontentclass_identifier = '".$targetContentClassIdentifier."'";
    $totalCountQueryResults = $gpDB->arrayQuery( $query );
    $totalCount = $totalCountQueryResults[0]['total_count'];
    
    include_once( 'kernel/common/eztemplatedesignresource.php' );
    $res =& eZTemplateDesignResource::instance();
    $keysArray = array( array( 'targetcontentclass_identifier' , $targetContentClassIdentifier ),
                        array( 'contentobjectattribute_type' , $contentObjectAttributeType ) );
    $res->setKeys( $keysArray );
    include_once( 'kernel/common/template.php' );
    $tpl =& templateInit();
    if( count( $queryResults ) > 0 )
    {
        $tpl->setVariable( 'results' , $queryResults );
        $tpl->setVariable( 'attribute_id' , $contentObjectAttributeID );
        $tpl->setVariable( 'targetcontentclassattribute_id' , $targetContentClassAttributeID );
        $tpl->setVariable( 'input' , $input );
        $tpl->setVariable( 'offset' , $offset );
        $tpl->setVariable( 'limit' , $limit );
        $tpl->setVariable( 'total_count' , $totalCount );
        $tpl->setVariable( 'edit_version' , $editVersion );
        $output =& $tpl->fetch( 'design:ezstringindexed/metasearch_results.tpl' );
    }
    else
    {
        $output =& $tpl->fetch( 'design:ezstringindexed/metasearch_noresults.tpl' );    
    }
    
    $objResponse->addAssign( 'Suggestion_'.$contentObjectAttributeID , 'innerHTML' , $output );
    
    return $objResponse->getXML();
}

?>
