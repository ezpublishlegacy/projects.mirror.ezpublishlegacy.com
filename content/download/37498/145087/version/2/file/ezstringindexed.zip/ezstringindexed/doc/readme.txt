============
WHAT IS IT ?
============

Ezstringindexed is an enhanced version of ezstring datatype. 
It indexes content in a simple way in a different table in order to dynamically get access to objects while establishing object relations.
See animated gif for example.

It requires XAJAX extension available here : http://ez.no/community/contribs/applications/xajax

Developped on Ezpublish 3.9.
Tested with Internet Explorer 7 and Firefox 2.0. 
Any feedback is welcome : nal@ingenieursetconsultants.com

===========
CHANGELOG
===========
14/02/07
- Added google navigator-like
- Reduced timer before auto-query and reduced minimum character to 2
- Added index on ezsitablestructure
- A few CSS changes
05/02/07
- Initial release



===========
WHAT'S DONE
===========
- Content indexation
- Object relation linking
- French translation
- Cace-block implementation

===========
TODO
===========

- Add removal for objectrelation
- Add image preview for metasearch_results.tpl
- Complete script to transform ezstring to ezstringindexed


Copyright 2006, 2007 Alimi Nabil <nal@ingenieursetconsultants.com>