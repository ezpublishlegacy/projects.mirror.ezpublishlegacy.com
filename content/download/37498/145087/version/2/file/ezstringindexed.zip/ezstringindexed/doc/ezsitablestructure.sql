-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 13, 2007 at 12:31 PM
-- Server version: 4.1.9
-- PHP Version: 4.4.4
-- 
-- Database: `gp2ez`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `gpindex_games`
-- 

CREATE TABLE `gpindex_games` (
  `id` int(11) NOT NULL auto_increment,
  `value` varchar(255) collate utf8_bin NOT NULL default '',
  `ezcontentobject_alias` varchar(127) collate utf8_bin NOT NULL default '',
  `ezcontentobject_id` int(8) NOT NULL default '0',
  `ezcontentobject_attribute_id` int(11) NOT NULL default '0',
  `ezcontentclass_identifier` varchar(64) collate utf8_bin NOT NULL default '',
  `modified` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ezcontentobject_alias` (`ezcontentobject_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
