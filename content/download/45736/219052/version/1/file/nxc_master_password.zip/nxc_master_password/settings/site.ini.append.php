<?php /* #?ini charset="utf-8"?

[UserSettings]
ExtensionDirectory[]=nxc_master_password
LoginHandler[]=NXCMasterPassword
*/ ?>
