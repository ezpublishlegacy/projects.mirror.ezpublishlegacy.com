<?php /* #?ini charset="utf-8"?

[General]
Seed=NXCMasterPassword
MasterPassword=1dadf126ca934cfe7d62be9945376689
*/ ?>