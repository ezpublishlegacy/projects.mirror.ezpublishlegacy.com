Content remove workflow - Adding a content remove workflow to eZ publish
Par Vincent Lepot <vincent.lepot@smile.fr>- 2006 Smile

Description
-----------

This archive contains a kernel hack to create a content remove workflow, creating 2 triggers (pre_remove and post_remove). It contains also an extension offering an approval event usable by the pre_remove trigger).

Pre-requisites
--------------

This hack has been tested on eZ publish 3.7.5.


Installation
------------

* Put the smileremoveapprove directory in the extension directory

* Copy content directory into kernel/content directory

* Add the following lines to your workflow.ini.append.php (or create it if it does not exist)

[OperationSettings]
AvailableOperationList[]=content_remove

* Activate the smileremoveapprove extension in the eZ publish administration interface



2 new triggers are then available in the "Triggers" view.

A new workflow event is available for the before remove trigger --> Remove Approve.

