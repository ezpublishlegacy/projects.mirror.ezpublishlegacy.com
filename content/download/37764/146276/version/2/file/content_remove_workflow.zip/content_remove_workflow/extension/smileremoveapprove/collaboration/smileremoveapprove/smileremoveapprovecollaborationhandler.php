<?php
//
// Definition of SmileRemoveApproveCollaborationHandler class
//
// Duplication of eZApproveCollaborationHandler 

/*! \file smileremoveapprovecollaborationhandler.php
*/

/*!
  \class SmileRemoveApproveCollaborationHandler smileremoveapprovecollaborationhandler.php
  \brief Handles approval communication using the collaboration system

  The handler uses the fields data_int1 and data_int3 to store
  information on the contentobject and the approval status.

  - data_int1 - The content object ID
  - data_int3 - The status of the approval, see defines.

*/

include_once( 'kernel/classes/ezcollaborationitemhandler.php' );
include_once( 'kernel/classes/ezcollaborationitem.php' );
include_once( 'kernel/classes/ezcollaborationitemmessagelink.php' );
include_once( 'kernel/classes/ezcollaborationitemparticipantlink.php' );
include_once( 'kernel/classes/ezcollaborationitemgrouplink.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'kernel/classes/ezcollaborationprofile.php' );
include_once( 'kernel/classes/ezcollaborationsimplemessage.php' );
include_once( 'kernel/classes/ezcontentobjectversion.php' );
include_once( 'kernel/common/i18n.php' );

/// Approval message type
if (! defined("EZ_COLLABORATION_MESSAGE_TYPE_APPROVE") ) { define( "EZ_COLLABORATION_MESSAGE_TYPE_APPROVE", 1 ); }

/// Default status, no approval decision has been made
if (! defined("EZ_COLLABORATION_APPROVE_STATUS_WAITING") ) { define( "EZ_COLLABORATION_APPROVE_STATUS_WAITING", 0 ); }
/// The contentobject was approved and will be removed.
if (! defined("EZ_COLLABORATION_APPROVE_STATUS_ACCEPTED") ) { define( "EZ_COLLABORATION_APPROVE_STATUS_ACCEPTED", 1 ); }
/// The contentobject was denied and will be left untouched.
if (! defined("EZ_COLLABORATION_APPROVE_STATUS_DENIED") ) { define( "EZ_COLLABORATION_APPROVE_STATUS_DENIED", 2 ); }
/// The contentobject was deferred and will be left untouched.
if (! defined("EZ_COLLABORATION_APPROVE_STATUS_DEFERRED") ) { define( "EZ_COLLABORATION_APPROVE_STATUS_DEFERRED", 3 ); }

class SmileRemoveApproveCollaborationHandler extends eZCollaborationItemHandler
{
    /*!
     Initializes the handler
    */
    function SmileRemoveApproveCollaborationHandler()
    {
        $this->eZCollaborationItemHandler( 'smileremoveapprove',
                                           ezi18n( 'smileremoveapprove/classes', 'Remove Approval' ),
                                           array( 'use-messages' => true,
                                                  'notification-types' => true,
                                                  'notification-collection-handling' => EZ_COLLABORATION_NOTIFICATION_COLLECTION_PER_PARTICIPATION_ROLE ) );
    }

    /*!
     \reimp
    */
    function title( &$collaborationItem )
    {
        return ezi18n( 'smileremoveapprove/classes', 'Remove Approval' );
    }

    /*!
     \reimp
    */
    function &content( &$collaborationItem )
    {
        return array( "content_object_id" => $collaborationItem->attribute( "data_int1" ),
//                      "content_object_version" => $collaborationItem->attribute( "data_int2" ), 
                      "approval_status" => $collaborationItem->attribute( "data_int3" ) );
    }

    function notificationParticipantTemplate( $participantRole )
    {
        if ( $participantRole == EZ_COLLABORATION_PARTICIPANT_ROLE_APPROVER )
        {
            return 'approve.tpl';
        }
        else if ( $participantRole == EZ_COLLABORATION_PARTICIPANT_ROLE_AUTHOR )
        {
            return 'author.tpl';
        }
        else
            return false;
    }

    /*!
     \return the content object version object for the collaboration item \a $collaborationItem
    */
    function &contentObject( &$collaborationItem )
    {
        $contentObjectID = $collaborationItem->contentAttribute( 'content_object_id' );
        $contentObjectVersion = $collaborationItem->contentAttribute( 'content_object_version' );
        return eZContentObject::fetch( $contentObjectID );
    }

    /*!
     \reimp
     Updates the last_read for the participant link.
    */
    function readItem( &$collaborationItem )
    {
        $collaborationItem->setLastRead();
    }

    /*!
     \reimp
     \return the number of messages for the approve item.
    */
    function messageCount( &$collaborationItem )
    {
        return eZCollaborationItemMessageLink::fetchItemCount( array( 'item_id' => $collaborationItem->attribute( 'id' ) ) );
    }

    /*!
     \reimp
     \return the number of unread messages for the approve item.
    */
    function unreadMessageCount( &$collaborationItem )
    {
//         $participantID =& eZUser::currentUserID();
//         $participant =& eZCollaborationItemParticipantLink::fetch( $collaborationItem->attribute( 'id' ), $participantID );
        $lastRead = 0;
        $status =& $collaborationItem->attribute( 'user_status' );
        if ( $status )
            $lastRead = $status->attribute( 'last_read' );
        return eZCollaborationItemMessageLink::fetchItemCount( array( 'item_id' => $collaborationItem->attribute( 'id' ),
                                                                      'conditions' => array( 'modified' => array( '>', $lastRead ) ) ) );
    }

    /*!
     \static
     \return the status of the approval collaboration item \a $approvalID.
    */
    function checkApproval( $approvalID )
    {
        $collaborationItem =& eZCollaborationItem::fetch( $approvalID );
        if ( $collaborationItem !== null )
        {
            return $collaborationItem->attribute( 'data_int3' );
        }
        return false;
    }

    /*!
     \static
     \return makes sure the approval item is activated for all participants \a $approvalID.
    */
    function activateApproval( $approvalID )
    {
        $collaborationItem =& eZCollaborationItem::fetch( $approvalID );
        if ( $collaborationItem !== null )
        {
//             eZDebug::writeDebug( $collaborationItem, "reactivating approval $approvalID" );
            $collaborationItem->setAttribute( 'data_int3', EZ_COLLABORATION_APPROVE_STATUS_WAITING );
            $collaborationItem->setAttribute( 'status', EZ_COLLABORATION_STATUS_ACTIVE );
            $timestamp = time();
            $collaborationItem->setAttribute( 'modified', $timestamp );
            $collaborationItem->store();
            $participantList =& eZCollaborationItemParticipantLink::fetchParticipantList( array( 'item_id' => $approvalID ) );
            for ( $i = 0; $i < count( $participantList ); ++$i )
            {
                $participantLink =& $participantList[$i];
                $collaborationItem->setIsActive( true, $participantLink->attribute( 'participant_id' ) );
            }
            return true;
        }
        return false;
    }

    /*!
     Creates a new approval collaboration item which will approve the content object \a $contentObjectID
     with version \a $contentObjectVersion.
     The item will be added to the author \a $authorID and the approver \a $approverID.
     \return the collaboration item.
    */
//    function createApproval( $contentObjectID, $contentObjectVersion, $authorID, $approverID )
    function createApproval( $contentObjectID, $authorID, $approverID )
    {
        $collaborationItem =& eZCollaborationItem::create( 'smileremoveapprove', $authorID );
        $collaborationItem->setAttribute( 'data_int1', $contentObjectID );
        //$collaborationItem->setAttribute( 'data_int2', $contentObjectVersion );
        $collaborationItem->setAttribute( 'data_int3', false );
        $collaborationItem->store();
        $collaborationID = $collaborationItem->attribute( 'id' );

        $participantList = array( array( 'id' => $authorID,
                                         'role' => EZ_COLLABORATION_PARTICIPANT_ROLE_AUTHOR ),
                                  array( 'id' => $approverID,
                                         'role' => EZ_COLLABORATION_PARTICIPANT_ROLE_APPROVER ) );
        foreach ( $participantList as $participantItem )
        {
            $participantID = $participantItem['id'];
            $participantRole = $participantItem['role'];
            $link =& eZCollaborationItemParticipantLink::create( $collaborationID, $participantID,
                                                                 $participantRole, EZ_COLLABORATION_PARTICIPANT_TYPE_USER );
            $link->store();

            $profile =& eZCollaborationProfile::instance( $participantID );
            $groupID =& $profile->attribute( 'main_group' );
//             eZDebug::writeDebug( 'Adding item group link' );
            eZCollaborationItemGroupLink::addItem( $groupID, $collaborationID, $participantID );
        }

        // Create the notification
        $collaborationItem->createNotificationEvent();
        return $collaborationItem;
    }

    /*!
     \reimp
     Adds a new comment, approves the item or denies the item.
    */
    function handleCustomAction( &$module, &$collaborationItem )
    {
        $redirectView = 'item';
        $redirectParameters = array( 'full', $collaborationItem->attribute( 'id' ) );
        $addComment = false;

        if ( $this->isCustomAction( 'Comment' ) )
        {
            $addComment = true;
        }
        else if ( $this->isCustomAction( 'Accept' ) or
                  $this->isCustomAction( 'Deny' ) or
                  $this->isCustomAction( 'Defer' ) )
        {
            $contentObjectVersion =& $this->contentObjectVersion( $collaborationItem );
            $status = EZ_COLLABORATION_APPROVE_STATUS_DENIED;
            if ( $this->isCustomAction( 'Accept' ) )
                $status = EZ_COLLABORATION_APPROVE_STATUS_ACCEPTED;
//             else if ( $this->isCustomAction( 'Defer' ) )
//                 $status = EZ_COLLABORATION_APPROVE_STATUS_DEFERRED;
//             else if ( $this->isCustomAction( 'Deny' ) )
//                 $status = EZ_COLLABORATION_APPROVE_STATUS_DENIED;
            else if ( $this->isCustomAction( 'Defer' ) or
                      $this->isCustomAction( 'Deny' ) )
                $status = EZ_COLLABORATION_APPROVE_STATUS_DENIED;
            $collaborationItem->setAttribute( 'data_int3', $status );
            $collaborationItem->setAttribute( 'status', EZ_COLLABORATION_STATUS_INACTIVE );
            $timestamp = time();
            $collaborationItem->setAttribute( 'modified', $timestamp );
            $collaborationItem->setIsActive( false );
            $redirectView = 'view';
            $redirectParameters = array( 'summary' );
            $addComment = true;
        }
        if ( $addComment )
        {
            $messageText = $this->customInput( 'ApproveComment' );
            if ( trim( $messageText ) != '' )
            {
                $message =& eZCollaborationSimpleMessage::create( 'ezapprove_comment', $messageText );
                $message->store();
//                 eZDebug::writeDebug( $message );
                eZCollaborationItemMessageLink::addMessage( $collaborationItem, $message, EZ_COLLABORATION_MESSAGE_TYPE_APPROVE );
            }
        }
        $collaborationItem->sync();
        return $module->redirectToView( $redirectView, $redirectParameters );
    }

}

?>
