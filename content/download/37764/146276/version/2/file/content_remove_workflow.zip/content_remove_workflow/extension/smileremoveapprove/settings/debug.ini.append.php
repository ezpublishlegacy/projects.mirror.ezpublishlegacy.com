<?php /* #?ini charset="iso-8859-1"?

[GeneralCondition]
smileremoveapprove-workflow-removeapprove=enabled
kernel-workflow-removeapprove=enabled
*/ ?>