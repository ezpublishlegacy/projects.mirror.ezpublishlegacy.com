﻿<!DOCTYPE TS><TS>
<context>
	<name>smileremoveapprove/classes</name>
	<message>
		<source>Remove Approval</source>
		<translation>Approbation de suppression</translation>
	</message>
</context>
<context>
	<name>design/admin/collaboration/handler/view/full/smilremoveapprove</name>
	<message>
		<source>The content object %1 awaits approval before it can be removed.</source>
		<translation>L&apos;objet de contenu %1 attend l&apos;approbation pour suppression.</translation>
	</message>
	<message>
		<source>If you wish you may send a message to the person approving it?</source>
		<translation>Voulez-vous envoyer un message à la personne qui l&apos;approuvera ?</translation>
	</message>
    <message>
        <source>The content object %1 needs your approval before it can be removed.</source>
        <translation>L&apos;objet de contenu %1 nécessite votre approbation avant sa suppression.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being removed?</source>
        <translation>Approuvez-vous la suppression de l&apos;objet de contenu ?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be removed once the removing workflow continues.</source>
        <translation>La suppression de l&apos;objet de contenu %1 a été approuvée et sera effective dans la suite du workflow de suppression.</translation>
    </message>
    <message>
        <source>The content object %1 removal was not accepted.</source>
        <translation>La suppression de l&apos;objet de contenu %1 a été refusée.</translation>
    </message>
</context>
<context>
	<name>design/admin/collaboration/handler/view/line/smileremoveapprove</name>
	<message>
		<source>%1 awaits remove approval by editor</source>
		<translation>%1 attend l'approbation de l'éditeur pour sa suppression</translation>
	</message>
	<message>
		<source>%1 awaits your remove approval</source>
		<translation>La suppression de %1 attend votre approbation</translation>
	</message>
	<message>
		<source>%1 was approved for removing</source>
		<translation>La suppression de %1 a été approuvée</translation>
	</message>
	<message>
		<source>%1 was not approved for removing</source>
		<translation>La suppression de %1 n'a pas été approuvée</translation>
	</message>
</context>

<context>
	<name>design/standard/collaboration/handler/view/full/smilremoveapprove</name>
	<message>
		<source>The content object %1 awaits approval before it can be removed.</source>
		<translation>L&apos;objet de contenu %1 attend l&apos;approbation pour suppression.</translation>
	</message>
	<message>
		<source>If you wish you may send a message to the person approving it?</source>
		<translation>Voulez-vous envoyer un message à la personne qui l&apos;approuvera ?</translation>
	</message>
    <message>
        <source>The content object %1 needs your approval before it can be removed.</source>
        <translation>L&apos;objet de contenu %1 nécessite votre approbation avant sa suppression.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being removed?</source>
        <translation>Approuvez-vous la suppression de l&apos;objet de contenu ?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be removed once the removing workflow continues.</source>
        <translation>La suppression de l&apos;objet de contenu %1 a été approuvée et sera effective dans la suite du workflow de suppression.</translation>
    </message>
    <message>
        <source>The content object %1 removal was not accepted.</source>
        <translation>La suppression de l&apos;objet de contenu %1 a été refusée.</translation>
    </message>
</context>
<context>
	<name>design/standard/collaboration</name>
	<message>
		<source>%1 awaits remove approval by editor</source>
		<translation>%1 attend l'approbation de l'éditeur pour sa suppression</translation>
	</message>
	<message>
		<source>%1 awaits your remove approval</source>
		<translation>La suppression de %1 attend votre approbation</translation>
	</message>
	<message>
		<source>%1 was approved for removing</source>
		<translation>La suppression de %1 a été approuvée</translation>
	</message>
	<message>
		<source>%1 was not approved for removing</source>
		<translation>La suppression de %1 n'a pas été approuvée</translation>
	</message>
</context>
<context>
	<name>design/standard/collaboration</name>
	<message>
		<source>%1 awaits remove approval by editor</source>
		<translation>%1 attend l'approbation de l'éditeur pour sa suppression</translation>
	</message>
	<message>
		<source>%1 awaits your remove approval</source>
		<translation>La suppression de %1 attend votre approbation</translation>
	</message>
	<message>
		<source>%1 was approved for removing</source>
		<translation>La suppression de %1 a été approuvée</translation>
	</message>
	<message>
		<source>%1 was not approved for removing</source>
		<translation>La suppression de %1 n'a pas été approuvée</translation>
	</message>
	<message>
		<source>[%sitename] Approval of removal for &quot;%objectname&quot; awaits your attention</source>
		<translation>[%sitename] &quot;%objectname&quot; attend votre approbation pour suppression</translation>
	</message>
    <message>
        <source>This e-mail is to inform you that "%objectname" awaits your attention at %sitename.
The removing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation type="obsolete">Ce courriel vous informe que &quot;%objectname&quot; attend votre approbation sur &apos;%sitename&apos;.
Le processus de suppression est en attente, et vous devez décider s&apos;il doit continuer ou s&apos;arrêter.
Le contenu peut être visualisé en utilisant l&apos;adresse ci-dessous.
</translation>
    </message>

    <message>
        <source>[%sitename] &quot;%objectname&quot; removal awaits approval</source>
        <translation>[%sitename] La suppression de &quot;%objectname&quot; est en attente d&apos;approbation</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that "%objectname" awaits approval at %sitename before it is removed.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation type="obsolete">Ce courriel vous informe que la suppression de &quot;%objectname&quot; est en attente d&apos;approbation sur &apos;%sitename&apos;.
Si vous souhaitez envoyer un commentaire au responsable de l&apos;approbation ou voir le statut de l&apos;objet, utilisez l&apos;adresse ci-dessous.
        </translation>
    </message>
</context>
<context>
	<name>smileremoveapprove/workflow/event</name>
	<message>
		<source>Remove Approve</source>
		<translation>Approbation de suppression</translation>
	</message>
</context>
</TS>
