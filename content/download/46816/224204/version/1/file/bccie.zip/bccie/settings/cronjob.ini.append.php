<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=bccie

[CronjobPart-exportcsv]
Scripts[]
Scripts[]=exportcsv.php

[CronjobPart-exportsylk]
Scripts[]
Scripts[]=exportsylk.php

*/ ?>