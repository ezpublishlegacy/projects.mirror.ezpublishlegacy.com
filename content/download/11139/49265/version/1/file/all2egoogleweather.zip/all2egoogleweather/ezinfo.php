<?php

class all2egoogleweatherInfo
{
    function info()
    {
        return array( 'Name' => "all2e Google Weather Datatype",
                      'Version' => "1.0.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://all2e.com'>all2e GmbH</a>"
                     );
    }
}
?>
