<?php /*

[ExtensionSettings]
DesignExtensions[]=all2egoogleweather

*/
?>
