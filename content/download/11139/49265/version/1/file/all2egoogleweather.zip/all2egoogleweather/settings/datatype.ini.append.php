<?php /*

[EditSettings]
GroupedInput[]=all2eweather

*/

?>
