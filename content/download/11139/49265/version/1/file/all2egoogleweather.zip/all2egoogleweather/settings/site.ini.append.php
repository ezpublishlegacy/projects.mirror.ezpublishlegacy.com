<?php /*

[RegionalSettings]
TranslationExtensions[]=all2egoogleweather

*/ ?>
