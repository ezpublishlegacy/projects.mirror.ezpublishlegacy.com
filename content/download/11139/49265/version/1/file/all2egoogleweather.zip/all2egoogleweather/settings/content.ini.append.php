<?php /*

[DataTypeSettings]
ExtensionDirectories[]=all2egoogleweather
AvailableDataTypes[]=all2eweather


*/

?>
