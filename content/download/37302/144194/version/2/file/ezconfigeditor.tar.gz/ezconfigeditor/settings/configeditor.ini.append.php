<? php /* #?ini charset="iso-8859-1"?
[ConfigDirectorySettings]
ConfigDir[]
ConfigDir[]=settings
ConfigDir[]=settings/override
ConfigDir[]=settings/siteaccess
ConfigDir[]=extension/configeditor/settings
ConfigDir[]=var/log

*/ ?>

