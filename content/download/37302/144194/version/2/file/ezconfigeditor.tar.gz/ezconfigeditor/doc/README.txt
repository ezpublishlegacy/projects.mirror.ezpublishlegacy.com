eZ Config file editor:
eZ Config editor is designed to list, view and edit the eZ ini files in one text field.

How to :
- Add "ezconfigeditor" to extension folder of eZ Publish root directory.
- Activate the extension "ezconfigeditor"
- Edit following ini file.
  "extension/configeditor/settings/configeditor.ini.append.php"
  
  Add the settings file path to ConfigDir[], which file you want to allow to edit
  by this editor.

  for e.g.

  [ConfigDirectorySettings]
  ConfigDir[]
  ConfigDir[]=settings
  ConfigDir[]=settings/override

- Go to Admin interface you will get "Config Editor" item in the top menu.


Note :
- It is not recomended to use this editor for daily perpose.
  because it does not lock the file while editing it so 
  if more than one person will edit the same file simultaneiously 
  then it's very easy to mesh the setting files and your file might be lost. 
- Please take a regular backup of your settings if you are using this extension.
- I have tested this extension on linux only.

