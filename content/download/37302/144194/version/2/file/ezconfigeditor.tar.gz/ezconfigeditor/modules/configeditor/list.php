<?php
//
// Created on: <26-Dec-2006 09:15:27 gv>
//
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0  of the GNU General
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of version 2.0 of the GNU General
// Public License along with this program; if not, write to the Free
// Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA.
//

/*! file : configeditor.php
 */


include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'lib/ezlocale/classes/eztime.php');

$http =& eZHTTPTool::instance();
$tpl =& templateInit();
$tpl->setVariable( 'file_list', false );
$Module =& $Params["Module"];
$action = $Params['action'];
$filename = $Params['filename'];
$filePath = $Params['Parameters'];

$ini =& eZINI::instance( 'configeditor.ini.append.php' );
$pathDir = $ini->variable( 'ConfigDirectorySettings', 'ConfigDir' );

$follow_path = array();

if( $action )
{
    if( $action == 'opendir' )
    {
        $file_path = "";
        $flag = false;
        foreach( $filePath as $keys => $path_element )
        {   $follow_path_element = array();
            if( $keys >0 )
            {
                if( $file_path == "" )
                {
                    $file_path = $path_element;
                }
                else
                {
                    $file_path = $file_path . '/' . $path_element;
                }
                if( $flag )
                {
                    $follow_path_element['current_dir'] = $path_element;
                    $follow_path_element['full_path'] = $file_path;
                    $follow_path[] = $follow_path_element;
                }
                else if( $path_element == 'settings' )
                {
                    $flag = true;
                    $follow_path_element['current_dir'] = $file_path;
                    $follow_path_element['full_path'] = $file_path;
                    $follow_path[] = $follow_path_element;
                 }

            }
        }
        $fileList = getFileList( $file_path );
        $tpl->setVariable( 'file_list', $fileList );
        $tpl->setVariable( 'file_path', $file_path );
        $tpl->setVariable( 'follow_path', $follow_path );
    }
}


if( $http->hasPostVariable( 'ListINIFile' ) and $http->hasPostVariable('selectedINIDir') )
{
    $selectedDir = $http->postVariable('selectedINIDir');
    if ( is_dir( $selectedDir ) )
    {
        $fileList = getFileList( $selectedDir );
    }
    $tpl->setVariable( 'file_list', $fileList );
    $tpl->setVariable( 'file_path', $selectedDir );
    $follow_path_element['current_dir'] = $selectedDir;
    $follow_path_element['full_path'] = $selectedDir;
    $follow_path[] = $follow_path_element;
    $tpl->setVariable( 'follow_path', $follow_path );
}

$tpl->setVariable( 'dir_list', $pathDir );
$Result = array();
$Result['content'] =& $tpl->fetch( 'design:configeditor/list.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Config editor' ),
                         array( 'url' => false,
                                'text' => 'List' ) );

function getFileList( $selectedDir )
{
    if ( is_dir( $selectedDir ) )
    {
        if ( $dh = opendir( $selectedDir ) )
        {
            while ( ( $file = readdir( $dh ) ) !== false )
            {   $fileData = array();
                if( $file != "." and $file != ".." and $file[0] != '.' and substr( $file, -1, 1) != '~' )
                {
                    $tmpFileList[] = $file;
                }
            }
            closedir( $dh );
            sort( $tmpFileList );
            $fileList = array();
            foreach( $tmpFileList as $tmpFile )
            {   $tmpFileGroup=array();
                $tmpFileGroup['name'] = $tmpFile;
                $tmpFileGroup['type'] = filetype( $selectedDir. '/' . $tmpFile );
                $tmpFileGroup['atime'] = fileatime( $selectedDir. '/' . $tmpFile );
                $tmpFileGroup['mtime'] = filemtime( $selectedDir. '/' . $tmpFile );
                $fileList[]=$tmpFileGroup;
            }
         }
        return $fileList;
     }
    return null;
}

?>
