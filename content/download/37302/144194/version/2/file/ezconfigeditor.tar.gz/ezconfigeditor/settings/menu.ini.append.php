[TopAdminMenu]
Tabs[]=configeditor

[Topmenu_configeditor]
NavigationPartIdentifier=ezconfigeditornavigationpart
URL[]
URL[default]=configeditor/list
URL[browse]=configeditor/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true
Name=Config Editor

[NavigationPart]
Part[ezconfigeditornavigationpart]=Configeditor

