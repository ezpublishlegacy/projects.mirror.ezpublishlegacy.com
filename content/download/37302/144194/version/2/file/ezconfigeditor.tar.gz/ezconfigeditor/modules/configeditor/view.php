<?php

//
// Created on: <26-Dec-2006 09:15:27 gv>
//
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0  of the GNU General
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of version 2.0 of the GNU General
// Public License along with this program; if not, write to the Free
// Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA.
//

/*! file : view.php
 */


include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'lib/ezlocale/classes/eztime.php');

$http =& eZHTTPTool::instance();
$tpl =& templateInit();
$tpl->setVariable( 'file_list', false );
$tpl->setVariable( 'error_msg', false );

$Module =& $Params["Module"];
$filePath = $Params['Parameters'];

$ini =& eZINI::instance( 'configeditor.ini.append.php' );
$pathDir = $ini->variable( 'ConfigDirectorySettings', 'ConfigDir' );

if( $filePath )
{
    $follow_path = array();
    $buffer = "";
    $file_path ="";
    $flag = false;
    foreach( $filePath as $key => $path_element )
    {
        $follow_path_element = array();
        if( $file_path == "" )
        {
            $file_path = $path_element;
        }
        else
        {
            $file_path = $file_path . '/' . $path_element;
        }
        if( ( $key + 1 ) < count( $filePath ) )
        {
            if( $flag )
            {
                $follow_path_element['current_dir'] = $path_element;
                $follow_path_element['full_path'] = $file_path;
                $follow_path[] = $follow_path_element;
            }
            else if( $path_element == 'settings' )
            {
                $flag = true;
                $follow_path_element['current_dir'] = $file_path;
                $follow_path_element['full_path'] = $file_path;
                $follow_path[] = $follow_path_element;
             }

        }
    }

    $perms = fileperms( $file_path );

    $info ="";
    // Owner
    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ?
             (($perms & 0x0800) ? 's' : 'x' ) :
             (($perms & 0x0800) ? 'S' : '-'));

    // Group
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ?
             (($perms & 0x0400) ? 's' : 'x' ) :
             (($perms & 0x0400) ? 'S' : '-'));

    // World
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ?
             (($perms & 0x0200) ? 't' : 'x' ) :
             (($perms & 0x0200) ? 'T' : '-'));

    if( 'w' !=  (($perms & 0x0002) ? 'w' : '-') )
    {
        $tpl->setVariable( 'error_msg', 'You do not have enough permission to edit this file.' );
    }

    $buffer = file_get_contents( $file_path );

    $fl_size = filesize( $file_path );
    $tpl->setVariable( 'file_name', $filename );
    $tpl->setVariable( 'file_path', $file_path );
    $tpl->setVariable( 'file_size', $fl_size );
    $tpl->setVariable( 'file_data', $buffer );
    $tpl->setVariable( 'follow_path', $follow_path );
    $tpl->setVariable( 'file_perms', $info );
}

if( $http->hasPostVariable( 'Edit' ) )
{
    $filePath = $http->postVariable( 'filePath' ) ;
    $Module->redirectTo( '/configeditor/edit/' . $filePath );
}

if( $http->hasPostVariable( 'BackToList' ) )
{
    $filePath = $http->postVariable('filePath');
    $Module->redirectTo( '/configeditor/list/opendir/' . implode(array_slice(explode('/',$filePath),0,-1),'/'));
}

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:configeditor/view.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Logreader' ),
                         array( 'url' => false,
                                'text' => 'View' ) );
?>
