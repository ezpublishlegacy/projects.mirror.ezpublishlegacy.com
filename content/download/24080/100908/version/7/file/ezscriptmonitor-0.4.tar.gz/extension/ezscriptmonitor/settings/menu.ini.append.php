<?php /* #?ini charset="utf-8"?

[Leftmenu_setup]
Links[_script_monitor]=/scriptmonitor/list

*/ ?>
