var files =
[
    [ "autoloads", "dir_647e64d812b3cad7656c888f07f2c523.html", "dir_647e64d812b3cad7656c888f07f2c523" ],
    [ "ezinfo.php", "ezinfo_8php.html", [
      [ "ezdebugInfo", "classezdebugInfo.html", "classezdebugInfo" ]
    ] ]
];