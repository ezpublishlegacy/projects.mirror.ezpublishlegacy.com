var classeZDebugOperators =
[
    [ "eZdebug", "classeZDebugOperators.html#af6836d770d9649a048f22dab153ffd8b", null ],
    [ "getDefinedVars", "classeZDebugOperators.html#aed433cb98a2acab708484469f1397c33", null ],
    [ "modify", "classeZDebugOperators.html#afbe528346b66699696d06c7b93d300e6", null ],
    [ "namedParameterList", "classeZDebugOperators.html#aed55d3020167d1088e0c3daabc6c14da", null ],
    [ "namedParameterPerOperator", "classeZDebugOperators.html#a4f22f7844056ae339bea54de8dd84ee7", null ],
    [ "numqueries", "classeZDebugOperators.html#acf899b0ef2710346684b0f464e0d376b", null ],
    [ "objdebug", "classeZDebugOperators.html#a5ae1e80e62ea3f84c4134591c4897285", null ],
    [ "operatorList", "classeZDebugOperators.html#a3d8368443ad2f7d447c7697f55dd5f19", null ],
    [ "$inspectcounter", "classeZDebugOperators.html#ace94fa3be5e19f7afda5be81cb4e677c", null ],
    [ "$operators", "classeZDebugOperators.html#a005c609accfdecc823783af0e420204c", null ]
];