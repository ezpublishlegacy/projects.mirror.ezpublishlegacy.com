<?php
//
// Definition of eZWordtoimageoperator class
//
// Created on: <27-Mar-2003 13:43:10 oh>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezwordtoimageoperator.php
*/

/*!
  \class eZWordtoimageoperator ezwordtoimageoperator.php
  \brief The class eZWordtoimageoperator does

*/
class eZWordToImageOperator
{
    /*!
     Initializes the object with the name $name, default is "wash".
    */
    function eZWordToImageOperator()
    {
        $this->Operators = array( "wordtoimage",
                                  "mimetype_icon", "class_icon", "classgroup_icon", "action_icon", "icon",
                                  "flag_icon", "icon_info" );
        $this->IconInfo = array();
    }

    /*!
      Returns the template operators.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case "wordtoimage":
            {
                include_once( "lib/ezutils/classes/ezini.php" );
                $ini =& eZINI::instance("wordtoimage.ini");
                $iconRoot = $ini->variable( 'WordToImageSettings', 'IconRoot' );

                $replaceText = $ini->variable( 'WordToImageSettings', 'ReplaceText' );
                $replaceIcon = $ini->variable( 'WordToImageSettings', 'ReplaceIcon' );

                $wwwDirPrefix = "";
                if ( strlen( eZSys::wwwDir() ) > 0 )
                    $wwwDirPrefix = eZSys::wwwDir() . "/";
                foreach( $replaceIcon as $icon )
                {
                    $icons[] = '<img src="' . $wwwDirPrefix . $iconRoot .'/' . $icon . '"/>';
                }

                $operatorValue = str_replace( $replaceText, $icons, $operatorValue );
            } break;

            // icon_info( <type> ) => array() containing:
            // - repository - Repository path
            // - theme - Theme name
            // - theme_path - Theme path
            // - size_path_list - Associative array of size paths
            // - size_info_list - Associative array of size info (width and height)
            // - icons - Array of icon files, relative to theme and size path
            // - default - Default icon file, relative to theme and size path
            case 'icon_info':
            {
                if ( !isset( $operatorParameters[0] ) )
                {
                    $tpl->missingParameter( $operatorName, 'type' );
                    return;
                }
                $type = $tpl->elementValue( $operatorParameters[0], $rootNamespace, $currentNamespace );

                // Check if we have it cached
                if ( isset( $this->IconInfo[$type] ) )
                {
                    $operatorValue = $this->IconInfo[$type];
                    return;
                }

                $ini =& eZINI::instance( 'icon.ini' );
                $default_repository = $ini->variable( 'IconSettings', 'Repository' );
                $primary_theme = $ini->variable( 'IconSettings', 'Theme' );
                $groups = array( 'mimetype' => 'MimeIcons',
                                 'class' => 'ClassIcons',
                                 'classgroup' => 'ClassGroupIcons',
                                 'action' => 'ActionIcons',
                                 'icon' => 'Icons' );
                $configGroup = $groups[$type];
                $mapNames = array( 'mimetype' => 'MimeMap',
                                   'class' => 'ClassMap',
                                   'classgroup' => 'ClassGroupMap',
                                   'action' => 'ActionMap',
                                   'icon' => 'IconMap' );
                $mapName = $mapNames[$type];
                $standard_theme = $ini->variable( 'IconSettings', 'StandardTheme' );
                $extensions = $ini->variable( 'ExtensionSettings', 'IconExtensions' );
                $siteDir = eZSys::siteDir();
                $matches = array();
                $iconFileAvalible = false;
                include_once( 'lib/ezutils/classes/ezextension.php' );
                $extensionDirectory = eZExtension::baseDirectory();

                // Check if the specific icon type has a theme setting
                if ( $ini->hasVariable( $configGroup, 'Theme' ) )
                {
                    $theme = $ini->variable( $configGroup, 'Theme' );
                }

                $avalibleThemes = $ini->variable( 'IconSettings', 'AdditionalThemeList' );
                if ( !is_array($avalibleThemes) )
                    $avalibleThemes = array();
                array_unshift($avalibleThemes, $primary_theme);
                array_push($avalibleThemes, $standard_theme);

                foreach ( $extensions as $extension )
                {
                    $matches[] = "$extensionDirectory/$extension/icons";
                }
                
                $matches[] = $default_repository;
                
                foreach ( $avalibleThemes as $theme )
                {
                    foreach ( $matches as $repository )
                    {
                        // Load icon settings from the theme
                        $themeINI =& eZINI::instance( 'icon.ini', $repository . '/' . $theme );

                        $sizes = $themeINI->variable( 'IconSettings', 'Sizes' );
                        if ( $ini->hasVariable( 'IconSettings', 'Sizes' ) )
                        {
                            $sizes = array_merge( $sizes,
                                                  $ini->variable( 'IconSettings', 'Sizes' ) );
                        }

                        $sizePathList = array();
                        $sizeInfoList = array();
                        foreach ( $sizes as $key => $size )
                        {
                            $pathDivider = strpos( $size, ';' );
                            if ( $pathDivider !== false )
                            {
                                $sizePath = substr( $size, $pathDivider + 1 );
                                $size = substr( $size, 0, $pathDivider );
                            }
                            else
                            {
                                $sizePath = $size;
                            }

                            $width = false;
                            $height = false;
                            $xDivider = strpos( $size, 'x' );
                            if ( $xDivider !== false )
                            {
                                $width = (int)substr( $size, 0, $xDivider );
                                $height = (int)substr( $size, $xDivider + 1 );
                            }
                            $sizePathList[$key] = $sizePath;
                            $sizeInfoList[$key] = array( $width, $height );
                        }

                        $map = array();

                        // Load mapping from theme
                        if ( $themeINI->hasVariable( $configGroup, $mapName ) )
                        {
                            $map = array_merge( $map,
                                                $themeINI->variable( $configGroup, $mapName ) );
                        }
                        // Load override mappings if they exist
                        if ( $ini->hasVariable( $configGroup, $mapName ) )
                        {
                            $map = array_merge( $map,
                                                $ini->variable( $configGroup, $mapName ) );
                        }

                        $default = false;
                        if ( $themeINI->hasVariable( $configGroup, 'Default' ) )
                            $default = $themeINI->variable( $configGroup, 'Default' );
                        if ( $ini->hasVariable( $configGroup, 'Default' ) )
                            $default = $ini->variable( $configGroup, 'Default' );

                        // Build return value
                        $iconInfo = array( 'repository' => $repository,
                                           'theme' => $theme,
                                           'theme_path' => $repository . '/' . $theme,
                                           'size_path_list' => $sizePathList,
                                           'size_info_list' => $sizeInfoList,
                                           'icons' => $map,
                                           'default' => $default );

                        $files_exists = true;
                        foreach ( $sizePathList as $sizePath )
                        {
                            $filesystemIconPath = $siteDir . $repository . '/' . $theme . '/' . $sizePath . '/' . $icon;
                            if ( is_file($filesystemIconPath) )
                            {
                                $files_exists = false;
                            }
                        }
                        if ( $files_exists )
                        {
                            $iconFileAvalible = true;
                            break;
                        }
                        else if ( !isset($fallbackIcon) )
                        {
                            $fallbackIcon = $iconInfo;
                        }
                    }
                    if ( $iconFileAvalible )
                    {
                        break;
                    }
                    else if ( isset($fallbackIcon) )
                    {
                        $iconInfo = $fallbackIcon;
                    }
                }
                $this->IconInfo[$type] = $iconInfo;
                $operatorValue = $iconInfo;
            } break;

            case 'flag_icon':
            {
                $ini =& eZINI::instance( 'icon.ini' );
                $default_repository = $ini->variable( 'IconSettings', 'Repository' );
                $theme = $ini->variable( 'FlagIcons', 'Theme' );
                $extensions = $ini->variable( 'ExtensionSettings', 'IconExtensions' );
                $matches = array();
                $iconFileAvalible = false;

                include_once( 'lib/ezutils/classes/ezextension.php' );
                $extensionDirectory = eZExtension::baseDirectory();

                foreach ( $extensions as $extension )
                {
                    $matches[] = "$extensionDirectory/$extension/icons";
                }
                $matches[] = $default_repository;

                foreach ( $matches as $repository )
                {
                    // Load icon settings from the theme
                    $themeINI =& eZINI::instance( 'icon.ini', $repository . '/' . $theme );

                    $iconFormat = $themeINI->variable( 'FlagIcons', 'IconFormat' );
                    if ( $ini->hasVariable( 'FlagIcons', 'IconFormat' ) )
                    {
                        $iconFormat = $ini->variable( 'FlagIcons', 'IconFormat' );
                    }

                    $icon = $operatorValue . '.' . $iconFormat;
                    $iconPath = $repository . '/' . $theme . '/' . $icon;

                    if ( is_readable( $iconPath ) )
                    {
                        $iconFileAvalible = true;
                        break;
                    }
                    else if ( !isset($defaultIcon) )
                    {
                        $defaultIcon = $themeINI->variable( 'FlagIcons', 'DefaultIcon' );
                    }
                }
                
                if ( !$iconFileAvalible )
                {
                    $iconPath = $repository . '/' . $theme . '/' . $defaultIcon . '.' . $iconFormat;
                }
                
                if ( strlen( eZSys::wwwDir() ) > 0 )
                    $wwwDirPrefix = eZSys::wwwDir() . '/';
                else
                    $wwwDirPrefix = '/';
                $operatorValue = $wwwDirPrefix . $iconPath;
            } break;

            case 'mimetype_icon':
            case 'class_icon':
            case 'classgroup_icon':
            case 'action_icon':
            case 'icon':
            {
                // Determine whether we should return only the image URI instead of the whole HTML code.
                if ( isset( $operatorParameters[2] ) )
                    $returnURIOnly = $tpl->elementValue( $operatorParameters[2], $rootNamespace, $currentNamespace );
                else
                    $returnURIOnly = false;

                if ( !isset($GLOBALS['eZWordToImageOperatorCache']) )
                {
                    $GLOBALS['eZWordToImageOperatorCache'] = array();
                }
                
                if ( !in_array($operatorName, array_keys($GLOBALS['eZWordToImageOperatorCache'])) )
                {
                    $GLOBALS['eZWordToImageOperatorCache'][$operatorName] = array();
                }

                if ( isset( $operatorParameters[0] ) )
                {
                    $sizeName = $tpl->elementValue( $operatorParameters[0], $rootNamespace, $currentNamespace );
                    if ( !in_array($operatorName, array_keys($GLOBALS['eZWordToImageOperatorCache'])) )
                    {
                        $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue] = array();
                    }
                }

                if ( !isset($sizeName) or !in_array($sizeName, array_keys($GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue])) )
                {
                    $ini =& eZINI::instance( 'icon.ini' );
                    $default_repository = $ini->variable( 'IconSettings', 'Repository' );
                    $primary_theme = $ini->variable( 'IconSettings', 'Theme' );
                    $standard_theme = $ini->variable( 'IconSettings', 'StandardTheme' );
                    $extensions = $ini->variable( 'ExtensionSettings', 'IconExtensions' );
                    $siteDir = eZSys::siteDir();
                    $matches = array();
                    $iconFileAvalible = false;

                    include_once( 'lib/ezutils/classes/ezextension.php' );
                    $extensionDirectory = eZExtension::baseDirectory();

                    $groups = array( 'mimetype_icon' => 'MimeIcons',
                                     'class_icon' => 'ClassIcons',
                                     'classgroup_icon' => 'ClassGroupIcons',
                                     'action_icon' => 'ActionIcons',
                                     'icon' => 'Icons' );
                    $configGroup = $groups[$operatorName];

                    // Check if the specific icon type has a theme setting
                    if ( $ini->hasVariable( $configGroup, 'Theme' ) )
                    {
                        $default_theme = $ini->variable( $configGroup, 'Theme' );
                    }

                    $avalibleThemes = $ini->variable( 'IconSettings', 'AdditionalThemeList' );
                    if ( !is_array($avalibleThemes) )
                        $avalibleThemes = array();
                    array_unshift($avalibleThemes, $primary_theme);
                    array_push($avalibleThemes, $standard_theme);

                    foreach ( $extensions as $extension )
                    {
                        $matches[] = "$extensionDirectory/$extension/icons";
                    }
                    
                    $matches[] = $default_repository;
                    
                    foreach ( $avalibleThemes as $theme )
                    {
                        foreach ( $matches as $repository )
                        {
                            // Load icon settings from the theme
                            $themeINI =& eZINI::instance( 'icon.ini', $repository . '/' . $theme );

                            if ( isset( $operatorParameters[0] ) )
                            {
                                $sizeName = $tpl->elementValue( $operatorParameters[0], $rootNamespace, $currentNamespace );
                            }
                            else
                            {
                                $sizeName = $ini->variable( 'IconSettings', 'Size' );
                                // Check if the specific icon type has a size setting
                                if ( $ini->hasVariable( $configGroup, 'Size' ) )
                                {
                                    $theme = $ini->variable( $configGroup, 'Size' );
                                }
                            }

                            $sizes = $themeINI->variable( 'IconSettings', 'Sizes' );
                            if ( $ini->hasVariable( 'IconSettings', 'Sizes' ) )
                            {
                                $sizes = array_merge( $sizes,
                                                      $ini->variable( 'IconSettings', 'Sizes' ) );
                            }

                            if ( isset( $sizes[$sizeName] ) )
                            {
                                $size = $sizes[$sizeName];
                            }
                            else
                            {
                                $size = $sizes[0];
                            }

                            $pathDivider = strpos( $size, ';' );
                            if ( $pathDivider !== false )
                            {
                                $sizePath = substr( $size, $pathDivider + 1 );
                                $size = substr( $size, 0, $pathDivider );
                            }
                            else
                            {
                                $sizePath = $size;
                            }

                            $width = false;
                            $height = false;
                            $xDivider = strpos( $size, 'x' );
                            if ( $xDivider !== false )
                            {
                                $width = (int)substr( $size, 0, $xDivider );
                                $height = (int)substr( $size, $xDivider + 1 );
                            }

                            if ( $operatorName == 'mimetype_icon' )
                            {
                                $iniGroup = 'MimeIcons';
                                $icon = $this->iconGroupMapping( $ini, $themeINI,
                                                                 $iniGroup, 'MimeMap',
                                                                 strtolower( $operatorValue ) );
                            }
                            else if ( $operatorName == 'class_icon' )
                            {
                                $iniGroup = 'ClassIcons';
                                $icon = $this->iconDirectMapping( $ini, $themeINI,
                                                                  $iniGroup, 'ClassMap',
                                                                  strtolower( $operatorValue ) );
                            }
                            else if ( $operatorName == 'classgroup_icon' )
                            {
                                $iniGroup = 'ClassGroupIcons';
                                $icon = $this->iconDirectMapping( $ini, $themeINI,
                                                                  $iniGroup, 'ClassGroupMap',
                                                                  strtolower( $operatorValue ) );
                            }
                            else if ( $operatorName == 'action_icon' )
                            {
                                $iniGroup = 'ActionIcons';
                                $icon = $this->iconDirectMapping( $ini, $themeINI,
                                                                  $iniGroup, 'ActionMap',
                                                                  strtolower( $operatorValue ) );
                            }
                            else if ( $operatorName == 'icon' )
                            {
                                $iniGroup = 'Icons';
                                $icon = $this->iconDirectMapping( $ini, $themeINI,
                                                                  $iniGroup, 'IconMap',
                                                                  strtolower( $operatorValue ) );
                            }

                            $filesystemIconPath = $siteDir . $repository . '/' . $theme . '/' . $sizePath . '/' . $icon;
                            $iconField = array( 'repository' => $repository,
                                                'theme' => $theme,
                                                'sizePath' => $sizePath,
                                                'icon' => $icon,
                                                'width' => $width,
                                                'height' => $height );

                            if ( is_file($filesystemIconPath) and
                                 $icon != $themeINI->variable( $iniGroup, 'Default' ) and
                                 $icon != $ini->variable( $iniGroup, 'Default' ) )
                            {
                                $iconFileAvalible = true;
                                $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName] = $iconField;
                                break;
                            }
                            else if ( !isset($fallbackIconField) and is_file($filesystemIconPath) and
                                      ( $icon == $themeINI->variable( $iniGroup, 'Default' ) or
                                        $icon == $ini->variable( $iniGroup, 'Default' ) ) )
                            {
                                $fallbackIconField = $iconField;
                            }
                        }
                        if ( $iconFileAvalible )
                        {
                            break;
                        }
                        else if ( isset($fallbackIconField) )
                        {
                            $repository = $fallbackIconField['repository'];
                            $theme = $fallbackIconField['theme'];
                            $sizePath = $fallbackIconField['sizePath'];
                            $icon = $fallbackIconField['icon'];
                            $width = $fallbackIconField['width'];
                            $height = $fallbackIconField['height'];
                        }
                        else
                        {
                            if ( $theme == $standard_theme and $repository == $default_repository )
                            {
                                eZDebug::writeError( "Missing icon file for '$operatorValue' with size '$sizeName'", "eZWordToImageOperator, case '$operatorName'" );
                            }
                        }
                    }
                }
                else
                {
                    $repository = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['repository'];
                    $theme = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['theme'];
                    $sizePath = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['sizePath'];
                    $icon = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['icon'];
                    $width = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['width'];
                    $height = $GLOBALS['eZWordToImageOperatorCache'][$operatorName][$operatorValue][$sizeName]['height'];
                }

                $iconPath = '/' . $repository . '/' . $theme;
                $iconPath .= '/' . $sizePath;
                $iconPath .= '/' . $icon;
                
                if ( isset( $operatorParameters[1] ) )
                {
                    $altText = $tpl->elementValue( $operatorParameters[1], $rootNamespace, $currentNamespace );
                }
                else
                {
                    $altText = $operatorValue;
                }

                $wwwDirPrefix = "";
                if ( strlen( eZSys::wwwDir() ) > 0 )
                    $wwwDirPrefix = eZSys::wwwDir();
                $sizeText = '';
                if ( $width !== false and $height !== false )
                {
                    $sizeText = ' width="' . $width . '" height="' . $height . '"';
                }

                // The class will be detected by ezpngfix.js, which will force alpha blending in IE.
                if ( ( !isset( $sizeName ) || $sizeName == 'normal' || $sizeName == 'original' ) && strstr( strtolower( $iconPath ), ".png" ) )
                {
                    $class = 'class="transparent-png-icon" ';
                }
                else
                {
                    $class = '';
                }

                if ( $returnURIOnly )
                    $operatorValue = $wwwDirPrefix . $iconPath;
                else
                    $operatorValue = '<img ' . $class . 'src="' . $wwwDirPrefix . $iconPath . '"' . $sizeText . ' alt="' .  htmlspecialchars( $altText ) . '" title="' . htmlspecialchars( $altText ) . '" />';
            } break;

            default:
            {
                eZDebug::writeError( "Unknown operator: $operatorName", "ezwordtoimageoperator.php" );
            }

        }

    }

    /*!
     \private
     Tries to find icon file by considering \a $matchItem as a single value.

     It will first try to match the whole \a $matchItem value in the mapping table.

     \return The relative path to the icon file.

     Example
     \code
     $icon = $this->iconDirectMapping( $ini, $themeINI, 'ClassIcons', 'ClassMap', 'Folder' );
     \encode

     \sa iconGroupMapping
    */
    function iconDirectMapping( &$ini, &$themeINI, $iniGroup, $mapName, $matchItem )
    {
        $map = array();

        // Load mapping from theme
        if ( $themeINI->hasVariable( $iniGroup, $mapName ) )
        {
            $map = array_merge( $map,
                                $themeINI->variable( $iniGroup, $mapName ) );
        }
        // Load override mappings if they exist
        if ( $ini->hasVariable( $iniGroup, $mapName ) )
        {
            $map = array_merge( $map,
                                $ini->variable( $iniGroup, $mapName ) );
        }

        $icon = false;
        if ( isset( $map[$matchItem] ) )
        {
            $icon = $map[$matchItem];
        }
        if ( $icon === false )
        {
            if ( $themeINI->hasVariable( $iniGroup, 'Default' ) )
                $icon = $themeINI->variable( $iniGroup, 'Default' );
            if ( $ini->hasVariable( $iniGroup, 'Default' ) )
                $icon = $ini->variable( $iniGroup, 'Default' );
        }
        return $icon;
    }

    /*!
     \private
     Tries to find icon file by considering \a $matchItem as a group,
     split into two parts and separated by a slash.

     It will first try to match the whole \a $matchItem value and then
     the group name.

     \return The relative path to the icon file.

     Example
     \code
     $icon = $this->iconGroupMapping( $ini, $themeINI, 'MimeIcons', 'MimeMap', 'image/jpeg' );
     \encode

     \sa iconDirectMapping
    */
    function iconGroupMapping( &$ini, &$themeINI, $iniGroup, $mapName, $matchItem )
    {
        $map = array();

        // Load mapping from theme
        if ( $themeINI->hasVariable( $iniGroup, $mapName ) )
        {
            $map = array_merge( $map,
                                $themeINI->variable( $iniGroup, $mapName ) );
        }
        // Load override mappings if they exist
        if ( $ini->hasVariable( $iniGroup, $mapName ) )
        {
            $map = array_merge( $map,
                                $ini->variable( $iniGroup, $mapName ) );
        }

        $icon = false;
        // See if we have a match for the whole match item
        if ( isset( $map[$matchItem] ) )
        {
            $icon = $map[$matchItem];
        }
        else
        {
            // If not we have to check the group (first part)
            $pos = strpos( $matchItem, '/' );
            if ( $pos !== false )
            {
                $mimeGroup = substr( $matchItem, 0, $pos );
                if ( isset( $map[$mimeGroup] ) )
                {
                    $icon = $map[$mimeGroup];
                }
            }
        }

        // No icon? If so use default
        if ( $icon === false )
        {
            if ( $themeINI->hasVariable( $iniGroup, 'Default' ) )
                $icon = $themeINI->variable( $iniGroup, 'Default' );
            if ( $ini->hasVariable( $iniGroup, 'Default' ) )
                $icon = $ini->variable( $iniGroup, 'Default' );
        }
        return $icon;
    }

    /// \privatesection
    var $Operators;
    var $IconInfo;
}
?>
