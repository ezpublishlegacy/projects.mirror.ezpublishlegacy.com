<?php /*

[DesignSettings]
AdditionalSiteDesignList[]=standard

[RegionalSettings]
TranslationExtensions[]=ezflowplayer

*/ ?>