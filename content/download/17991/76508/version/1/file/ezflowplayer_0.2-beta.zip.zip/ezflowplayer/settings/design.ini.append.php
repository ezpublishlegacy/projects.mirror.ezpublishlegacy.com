<?php /*

[ExtensionSettings]
DesignExtensions[]=ezflowplayer

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
JavaScriptList[]=flowplayer-3.1.1.min.js

[StylesheetSettings]
CSSFileList[]=flowplayer.css

*/ ?>