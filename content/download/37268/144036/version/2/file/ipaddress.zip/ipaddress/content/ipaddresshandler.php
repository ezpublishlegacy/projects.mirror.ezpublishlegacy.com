<?php
class IpAddressHandler extends eZContentObjectEditHandler
{
    function fetchInput( &$http, &$module, &$class, &$object, &$version, &$contentObjectAttributes, $editVersion, $editLanguage, $fromLanguage )
    {
		
    }

    function storeActionList()
    {
		
    }

    function publish( $contentObjectID, $contentObjectVersion )
    {
		// fetch object
        $object =& eZContentObject::fetch( $contentObjectID );
        // get content class object
        $contentClass =& $object->attribute('content_class');

		// check if edited class is forum_topic (28) or forum_reply (29)
        if ( $contentClass->attribute( 'id' ) == 28 || $contentClass->attribute( 'id' ) == 29 )
        {			
			$contentObjectAttributes =& $object->contentObjectAttributes();

            $loopLenght = count( $contentObjectAttributes );

            // Fill up content object name attribute with user object name
            for( $i = 0; $i < $loopLenght; $i++ )
            {
                switch( $contentObjectAttributes[$i]->attribute( 'contentclass_attribute_identifier' ) )
                {
					// check if attribute is ip_address and set client's IP
                    case 'ip_address':
                        $contentObjectAttributes[$i]->setAttribute( 'data_text', $_SERVER["REMOTE_ADDR"] );
                        $contentObjectAttributes[$i]->store();
                        break;
                }
            }
		}
    }
}
?>
