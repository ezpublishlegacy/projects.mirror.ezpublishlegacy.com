****************************************************************************
*
*	eZ Publish extension - edit handler for saving IP address
*   Copyright (C) 2007  Webstyle Systems, http://www.ws-webstyle.com
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
****************************************************************************

It's a sample custom edit handler for saving IP address as class attribute.

Installation:
1) Copy this edit handler to extensions directory of eZ Publish
2) Turn on extension in administration panel or by adding activating it in
override/site.ini.append.php settings file:

[ExtensionSettings]
ActiveExtensions[]=ipaddress

3) Activate edit handler in override/content.ini.append.php settings file:

[EditSettings]
ExtensionDirectories[]=ipaddress

Enjoy