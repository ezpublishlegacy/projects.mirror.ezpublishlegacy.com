<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Uredi &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Prevođenje sadržaja iz %from_lang u %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Objavi</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Objavi sadržaj skice koja se uređuje. Skica će postati objavljena verzija objekta.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Spremi skicu</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Pohrani sadržaj skice koja se uređuje i nastavi uređivanje. Koristite ovu naredbu za perodično snimanje prilikom uređivanja.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Odbaci skicu</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Jeste li sigurni da želite odbaciti skicu?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Odbaci skicu koja se uređuje. To će također izbrisati sve pripadajuće prijevode (ako postoje).</translation>
    </message>
    <message>
        <source>Related objects [%related_objects]</source>
        <translation>Povezani objekti [%related_objects]</translation>
    </message>
    <message>
        <source>Related images [%related_images]</source>
        <translation>Povezane slike [%related_images]</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>Nemate dozvolu za pregled objekta</translation>
    </message>
    <message>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>Kopirajte sljedeći kod i nalijepite ga u XML polje.</translation>
    </message>
    <message>
        <source>Related files [%related_files]</source>
        <translation>Povezane datoteke [%related_files]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Tip datoteke</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>XML code</source>
        <translation>XML kod</translation>
    </message>
    <message>
        <source>Related content [%related_objects]</source>
        <translation>Povezani sadržaj [%related_objects]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tip</translation>
    </message>
    <message>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>Ne postoje objekti koji su povezani s trenutno otvorenim objektom.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Ukloni odabrano</translation>
    </message>
    <message>
        <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
        <translation>Ukloni odabrane elemente sa gornje liste. Samo će relacije biti izbrisane. Elementi neće biti izbrisani.</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Dodaj postojeći</translation>
    </message>
    <message>
        <source>Add an existing item as a related object.</source>
        <translation>Dodaj postojeći element kao povezani objekt.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Učitaj sada</translation>
    </message>
    <message>
        <source>Upload a file and add it as a related object.</source>
        <translation>Učitaj datoteku i dodaj ju kao povezani objekt.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Year</source>
        <translation>Godina</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mjesec</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Dan</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Sat</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuta</translation>
    </message>
</context>
<context>
    <name>ezxnewsletter</name>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>External HTML</source>
        <translation>Vajnski HTML</translation>
    </message>
    <message>
        <source>Not send</source>
        <translation>Nije poslano</translation>
    </message>
    <message>
        <source>Building sending list</source>
        <translation>Stvaranje liste za slanje</translation>
    </message>
    <message>
        <source>Sending</source>
        <translation>Šalje se</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Završeno</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Skica</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Objavljeno</translation>
    </message>
    <message>
        <source>Send mailing</source>
        <translation>Slanje pošte</translation>
    </message>
    <message>
        <source>Mark as sent</source>
        <translation>Označi kao poslano</translation>
    </message>
    <message>
        <source>On hold</source>
        <translation>Na čekanju</translation>
    </message>
    <message>
        <source>Not set</source>
        <translation>Nije postavljeno</translation>
    </message>
    <message>
        <source>Silver</source>
        <translation>Srebreni</translation>
    </message>
    <message>
        <source>Gold</source>
        <translation>Zlatni</translation>
    </message>
    <message>
        <source>Platinum</source>
        <translation>Platinasti</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>U obradi</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrđeno</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Odobreno</translation>
    </message>
    <message>
        <source>Removed self</source>
        <translation>Uklonjen (samostalno)</translation>
    </message>
    <message>
        <source>Removed by admin</source>
        <translation>Uklonjen (administrator)</translation>
    </message>
    <message>
        <source>Confirm user</source>
        <translation>Potvrdi korisnika</translation>
    </message>
    <message>
        <source>Confirm and approve user</source>
        <translation>Potvrdi i odobri korisnika</translation>
    </message>
    <message>
        <source>Select a source for newsletter articles</source>
        <translation>Odaberi izvor za članke</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a source location for articles to be used in the newsletter, and click &quot;OK&quot;.</source>
        <translation>Koristeći radio polja izaberi izvor za članke koji će se koristiti u listi i stisni &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Za olakšano korištenje, sučelje se sastoji od tabova (gore), izbornika (lijevo) i liste sadržaja (u sredini).</translation>
    </message>
    <message>
        <source>Please select an eZ publish user.</source>
        <translation>Izaberite eZ publish korisnika.</translation>
    </message>
    <message>
        <source>Confirm bounce entry removal</source>
        <translation>Potvrdi brisanje unosa o odbijenom slanju</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entry?</source>
        <translation>Jeste li sigurni da želite izbrisati unos o odbijenom slanju?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entries?</source>
        <translation>Jeste li sigurni da želite izbrisati unose o odbijenim slanjima?</translation>
    </message>
    <message>
        <source>The following bounce entries will be removed</source>
        <translation>Sljedeći unosi o odbijenom slanju će biti izbrisani</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Napomena</translation>
    </message>
    <message>
        <source>Proceed only if you know what you are doing.</source>
        <translation>Nastavite ukoliko ste sigurni da znate što radite.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Confirm newsletter removal</source>
        <translation>Potvrdi brisanje liste</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter?</source>
        <translation>Jeste li sigurni da želite izbrisati listu?</translation>
    </message>
    <message>
        <source>The following newsletters will be removed</source>
        <translation>Sljedeće liste će biti izbrisane</translation>
    </message>
    <message>
        <source>Confirm newsletter type removal</source>
        <translation>Potvrdi brisanje tipa liste</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter type?</source>
        <translation>Jeste li sigurni da želite izbrisati tip liste?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter types?</source>
        <translation>Jeste li sigurni da želite izbrisati tipove listi?</translation>
    </message>
    <message>
        <source>The following newsletter types will be removed</source>
        <translation>Sljedeći tipovi listi će biti izbrisani</translation>
    </message>
    <message>
        <source>Confirm onhold entry removal</source>
        <translation>Potvrdi brisanje unosa o čekanju</translation>
    </message>
    <message>
        <source>The following entries on hold will be removed</source>
        <translation>Sljedeći unosi o čekanju će biti izbrisani</translation>
    </message>
    <message>
        <source>Edit Newsletter</source>
        <translation>Uredi listu</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Newsletter send date</source>
        <translation>Datum slanja liste</translation>
    </message>
    <message>
        <source>Newsletter category</source>
        <translation>Kategorija liste</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Izlazni format</translation>
    </message>
    <message>
        <source>Send preview address</source>
        <translation>Adresa za pregled</translation>
    </message>
    <message>
        <source>Send preview</source>
        <translation>Pošalji pregled</translation>
    </message>
    <message>
        <source>Message on hold</source>
        <translation>Poruka na čekanju</translation>
    </message>
    <message>
        <source>Send item data:</source>
        <translation>Podaci o slanju:</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Newsletter ID</source>
        <translation>ID liste</translation>
    </message>
    <message>
        <source>Newsletter name</source>
        <translation>Naziv liste</translation>
    </message>
    <message>
        <source>Sent to address</source>
        <translation>Adresa za slanje</translation>
    </message>
    <message>
        <source>Recipient name</source>
        <translation>Naziv primatelja</translation>
    </message>
    <message>
        <source>Set new sendout status</source>
        <translation>postavi novi izlazni status</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Postavi</translation>
    </message>
    <message>
        <source>Back to on hold list</source>
        <translation>Povratak na listu čekanja</translation>
    </message>
    <message>
        <source>Edit Newsletter type</source>
        <translation>Uredi tip liste</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining the newsletter.</source>
        <translation>U polje za opis napišite kratko pojašnjenje liste.</translation>
    </message>
    <message>
        <source>Sender address</source>
        <translation>Adresa pošiljatelja</translation>
    </message>
    <message>
        <source>Personalize Newsletter</source>
        <translation>Personaliziraj listu</translation>
    </message>
    <message>
        <source>Valid content classes</source>
        <translation>Ispravne klase</translation>
    </message>
    <message>
        <source>Allowed output formats</source>
        <translation>Dozvoljeni izlazni formati</translation>
    </message>
    <message>
        <source>Subscription lists</source>
        <translation>Lista prijavljenih</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Inbox</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Povezani objekti</translation>
    </message>
    <message>
        <source>Add related object</source>
        <translation>Dodaj povezani objekt</translation>
    </message>
    <message>
        <source>Remove object location</source>
        <translation>Ukloni lokaciju objekta</translation>
    </message>
    <message>
        <source>No object relation selected</source>
        <translation>Nije odabrana relacija objekta</translation>
    </message>
    <message>
        <source>Newsletter suggestion inbox</source>
        <translation>Inbox za prijedloge</translation>
    </message>
    <message>
        <source>Change inbox placement</source>
        <translation>Promijeni smještaj Inboxa</translation>
    </message>
    <message>
        <source>Delete inbox placement</source>
        <translation>Ukloni smještaj Inboxa</translation>
    </message>
    <message>
        <source>No newsletter placement is specified</source>
        <translation>Nije definiran smještaj liste</translation>
    </message>
    <message>
        <source>Add inbox placement</source>
        <translation>Dodaj smještaj Inboxa</translation>
    </message>
    <message>
        <source>Newsletter placement</source>
        <translation>Smještaj liste</translation>
    </message>
    <message>
        <source>Change newsletter placement</source>
        <translation>Promijeni smještaj liste</translation>
    </message>
    <message>
        <source>Delete newletter placement</source>
        <translation>Ukloni smještaj liste</translation>
    </message>
    <message>
        <source>Add newsletter placement</source>
        <translation>Dodaj smještaj liste</translation>
    </message>
    <message>
        <source>Edit &lt;%subscription_name&gt; [Subscription]</source>
        <translation>Uredi &lt;%subscription_name&gt; [Prijava]</translation>
    </message>
    <message>
        <source>Name of the subscriber.</source>
        <translation>Naziv prijavljenog korisnika.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation>E-mail prijavljenog korisnika.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Lozinka</translation>
    </message>
    <message>
        <source>eZ publish user</source>
        <translation>eZ publish korisnik</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Odabir</translation>
    </message>
    <message>
        <source>Apply the changes and return subscription list view.</source>
        <translation>Prihvati promjene i vrati se na listu prijava.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ukloni</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Vip</source>
        <translation>Vip</translation>
    </message>
    <message>
        <source>VIP status</source>
        <translation>VIP status</translation>
    </message>
    <message>
        <source>OutputFormat</source>
        <translation>Izlazni format</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>Odbaci promjene u vrati se na listu prijava.</translation>
    </message>
    <message>
        <source>Edit &lt;%subscription_list_name&gt; [Subscription list]</source>
        <translation>Uredi &lt;%subscription_list_name&gt; [Lista prijava]</translation>
    </message>
    <message>
        <source>Name of the subscription list.</source>
        <translation>Naziv liste prijava.</translation>
    </message>
    <message>
        <source>RegistrationURL</source>
        <translation>URL za registraciju</translation>
    </message>
    <message>
        <source>URL : %url</source>
        <translation>URL: %url</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>URL to subscription.</source>
        <translation>URL za prijavu.</translation>
    </message>
    <message>
        <source>Generate hash</source>
        <translation>Generiraj hash</translation>
    </message>
    <message>
        <source>Generate hash for URL.</source>
        <translation>Generiraj hash za URL.</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining what subscription list is beeing used to.</source>
        <translation>U opisno polje upiši objašnjenje za što se koristi lista prijava.</translation>
    </message>
    <message>
        <source>Login steps</source>
        <translation>Koraci kod prijave</translation>
    </message>
    <message>
        <source>Require password</source>
        <translation>Zahtjeva se lozinka</translation>
    </message>
    <message>
        <source>Allow anonymous users</source>
        <translation>Dopusti anonimne korisnike</translation>
    </message>
    <message>
        <source>Auto confirm registered users</source>
        <translation>Automatski prihvati registrirane korisnike</translation>
    </message>
    <message>
        <source>Automaticly confirm registered users</source>
        <translation>Automatski prihvati registrirane korisnike</translation>
    </message>
    <message>
        <source>Auto approve registered users</source>
        <translation>Automatski odobri registrirane korisnike</translation>
    </message>
    <message>
        <source>Newsletter archive</source>
        <translation>Arhiv listi</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Vlasnik</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Kreirano</translation>
    </message>
    <message>
        <source>Send Status</source>
        <translation>Status slanja</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># poslano</translation>
    </message>
    <message>
        <source># read</source>
        <translation># pročitano</translation>
    </message>
    <message>
        <source>Preview Newsletter</source>
        <translation>Pregled liste</translation>
    </message>
    <message>
        <source>Newsletter drafts</source>
        <translation>Skice liste</translation>
    </message>
    <message>
        <source>Newsletter in progress</source>
        <translation>Slanje u toku</translation>
    </message>
    <message>
        <source>Soft bounce</source>
        <translation>Vraćeno (soft)</translation>
    </message>
    <message>
        <source>Hard bounce</source>
        <translation>Vraćeno (hard)</translation>
    </message>
    <message>
        <source>Newsletter bounces</source>
        <translation>Vraćanja</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Obrnuta selekcija.</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation>Broj vraćanja</translation>
    </message>
    <message>
        <source>Bounce type</source>
        <translation>Tip vraćanja</translation>
    </message>
    <message>
        <source>Bounce arrived</source>
        <translation>Vraćanje detektirano</translation>
    </message>
    <message>
        <source>No bounces detected</source>
        <translation>Nije detektirano nijedno vraćanje</translation>
    </message>
    <message>
        <source>Select bounce to clear bounce entry</source>
        <translation>Odaberi unos vraćanja</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Ukloni odabrano</translation>
    </message>
    <message>
        <source>Remove selected bounce entries.</source>
        <translation>Ukloni odabrane unose vraćanja.</translation>
    </message>
    <message>
        <source>Send items on hold</source>
        <translation>Pošalji na čekanje</translation>
    </message>
    <message>
        <source>Modify</source>
        <translation>Ažuriraj</translation>
    </message>
    <message>
        <source>No messages on hold detected</source>
        <translation>Nisu detektirane poruke na čekanju</translation>
    </message>
    <message>
        <source>Select an iten on hold to delete the scheduled sendout</source>
        <translation>Odaberi unos na čekanju</translation>
    </message>
    <message>
        <source>Remove selected entries on hold.</source>
        <translation>Ukloni odabrane unose na čekanju</translation>
    </message>
    <message>
        <source>Newsletter types</source>
        <translation>Tipovi listi</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Kreirao</translation>
    </message>
    <message>
        <source>Article pool</source>
        <translation>Repozitorij članaka</translation>
    </message>
    <message>
        <source>Created on</source>
        <translation>Kreirano</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>No newsletters defined</source>
        <translation>Nije definirana lista</translation>
    </message>
    <message>
        <source>Select newsletter type for removal</source>
        <translation>Odaberi tip liste za brisanje</translation>
    </message>
    <message>
        <source>newsletter</source>
        <translation>lista</translation>
    </message>
    <message>
        <source>Create a new newsletter of the type &lt;%newsletter_type&gt;</source>
        <translation>Kreiraj novu listu tipa &lt;%newsletter_type&gt;</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; newsletter type.</source>
        <translation>Uredi &lt;%newsletter_name&gt; tip liste.</translation>
    </message>
    <message>
        <source>Remove selected newsletter types.</source>
        <translation>Ukloni odabrani tip liste.</translation>
    </message>
    <message>
        <source>New newsletter type</source>
        <translation>Novi tip liste</translation>
    </message>
    <message>
        <source>Create a new newsletter type.</source>
        <translation>Kreiraj novi tip liste.</translation>
    </message>
    <message>
        <source>Subscribers</source>
        <translation>Prijavljeni korisnici</translation>
    </message>
    <message>
        <source>Select subscription list for removal</source>
        <translation>Odaberi listu prijava za brisanje</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription list.</source>
        <translation>Uredi &lt;%newsletter_name&gt; listu prijava.</translation>
    </message>
    <message>
        <source>Remove selected subscription list.</source>
        <translation>Ukloni odabranu listu prijava.</translation>
    </message>
    <message>
        <source>New subscription list</source>
        <translation>Nova lista prijava</translation>
    </message>
    <message>
        <source>Create a new subscription list.</source>
        <translation>Kreiraj novu listu prijava.</translation>
    </message>
    <message>
        <source>Newsletter subscription verification</source>
        <translation>Verifikacija prijave na listu</translation>
    </message>
    <message>
        <source>Hi %name

Thank you for registering to the subscription list %listName. To activate your subscription
you must go to this link: %link .

For editing you settings, please visit : %settingsLink .

Have a nice day.</source>
        <translation>Poštovani %name,

hvala na prijavi na listu %listName. Za aktivaciju Vaše prijave morate kliknuti na sljedeći link: %link.

Za ažuriranje vaših postavki, posjetite: %settingsLink.

Želimo Vam ugodan nastavak dana.</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Prijavi se</translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation>Dodaj u prijave.</translation>
    </message>
    <message>
        <source>Cancel, and discard.</source>
        <translation>Odustani.</translation>
    </message>
    <message>
        <source>Thank you for registering</source>
        <translation>Zahvaljujemo na prijavi</translation>
    </message>
    <message>
        <source>Thank you for registering to %name.</source>
        <translation>Zahvaljujemo na prijavi na %name listu.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Nastavi</translation>
    </message>
    <message>
        <source>Subscription activated</source>
        <translation>Prijava aktivirana</translation>
    </message>
    <message>
        <source>Hi %name

Your subscription to %subscriptionName has now been activated.</source>
        <translation>Poštovani %name,

vaša prijava na %subscriptionName je aktivirana.</translation>
    </message>
    <message>
        <source>Import suscribers to subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Uvezi prijavljene korisnike u listu &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Uvezi datoteku</translation>
    </message>
    <message>
        <source>Import subscriptions</source>
        <translation>Uvezi prijavljene korisnike</translation>
    </message>
    <message>
        <source>Select row to import</source>
        <translation>Odaberi redak za uvoz</translation>
    </message>
    <message>
        <source>Cancel subscription import.</source>
        <translation>Otkaži uvoz prijava.</translation>
    </message>
    <message>
        <source>Import selected</source>
        <translation>Uvoz odabran</translation>
    </message>
    <message>
        <source>Import selected.</source>
        <translation>Uvoz odabran.</translation>
    </message>
    <message>
        <source>Subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Lista prijava &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>No related object specified</source>
        <translation>Nije specificiran povezani objekt</translation>
    </message>
    <message>
        <source>Edit current subscription list.</source>
        <translation>Uredi trenutnu listu prijava.</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Show all</source>
        <translation>Prikaži sve</translation>
    </message>
    <message>
        <source>VIP:</source>
        <translation>VIP:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtar</translation>
    </message>
    <message>
        <source>Filter  subscription list.</source>
        <translation>Filtriraj listu prijava.</translation>
    </message>
    <message>
        <source>Subscriber list</source>
        <translation>Lista prijavljenih</translation>
    </message>
    <message>
        <source>VIP</source>
        <translation>VIP</translation>
    </message>
    <message>
        <source>Removed</source>
        <translation>Izbrisano</translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation>Odaberi korisnike za brisanje</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n/a</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription.</source>
        <translation>Uredi prijavu &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation>Ukloni odabrane prijave.</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nova prijava</translation>
    </message>
    <message>
        <source>Create a new subscription.</source>
        <translation>Kreiraj novu prijavu.</translation>
    </message>
    <message>
        <source>Import contact from CSV file</source>
        <translation>Uvezi konakte iz CSV datoteke</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Odjava</translation>
    </message>
    <message>
        <source>Unsubscribe subscription.</source>
        <translation>Odjava sa liste.</translation>
    </message>
    <message>
        <source>Edit user settings</source>
        <translation>Uredi korisničke postavke</translation>
    </message>
    <message>
        <source>Your subscriptions</source>
        <translation>Vaše prijave</translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation>Nema prijava</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Osvježi</translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation>Osvježi postavke.</translation>
    </message>
    <message>
        <source>Please enter your password</source>
        <translation>Unesite lozinku</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Pošalji</translation>
    </message>
    <message>
        <source>Sent item data:</source>
        <translation>Poslani podaci:</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Poslano</translation>
    </message>
    <message>
        <source>Subscription ID</source>
        <translation>ID prijave</translation>
    </message>
    <message>
        <source>Subscriber data:</source>
        <translation>Podaci o prijavljenom korisniku:</translation>
    </message>
    <message>
        <source>Subscriber name</source>
        <translation>Naziv prijavljenog korisnika</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bounce details:</source>
        <translation>Podaci o vraćanju:</translation>
    </message>
    <message>
        <source>Bounce response message:</source>
        <translation>Povratna poruka:</translation>
    </message>
    <message>
        <source>Subscription data:</source>
        <translation>Podaci o prijavi:</translation>
    </message>
    <message>
        <source>Subscription list name</source>
        <translation>Naziv liste prijava</translation>
    </message>
    <message>
        <source>Set new subscription status</source>
        <translation>Postavi novi status prijave</translation>
    </message>
    <message>
        <source>Back to bounce list</source>
        <translation>Vrati se na listu vraćanja</translation>
    </message>
    <message>
        <source>Newsletter type</source>
        <translation>Tip liste</translation>
    </message>
    <message>
        <source>%newsletter_type_name [Newsletter type]</source>
        <translation>%newsletter_type_name [Tip liste]</translation>
    </message>
    <message>
        <source>Create newsletter</source>
        <translation>Kreiraj Newsletter</translation>
    </message>
    <message>
        <source>Default subscription</source>
        <translation>Osnovna prijava</translation>
    </message>
    <message>
        <source>Suggestion inbox</source>
        <translation>Inbox prijedloga</translation>
    </message>
    <message>
        <source>No inbox set</source>
        <translation>Nije postavljen Inbox</translation>
    </message>
    <message>
        <source>Edit this newsletter type.</source>
        <translation>Uredi tip liste.</translation>
    </message>
    <message>
        <source>Newsletter lists</source>
        <translation>Liste</translation>
    </message>
    <message>
        <source>Email address &quot;%address&quot; did not validate</source>
        <translation>E-mail &quot;%address&quot; nije ispravan</translation>
    </message>
    <message>
        <source>Edit newslettertype</source>
        <translation>Uredi tip liste</translation>
    </message>
    <message>
        <source>Edit Subscription</source>
        <translation>Uredi prijavu</translation>
    </message>
    <message>
        <source>Subscription Lists</source>
        <translation>Liste prijava</translation>
    </message>
    <message>
        <source>View newsletter type</source>
        <translation>Pregled tipova listi</translation>
    </message>
    <message>
        <source>Messages on hold</source>
        <translation>Poruke na čekanju</translation>
    </message>
    <message>
        <source>Newsletter items on hold</source>
        <translation>Elementi liste na čekanju</translation>
    </message>
    <message>
        <source>View newsletter bounce entry</source>
        <translation>Pregled liste vraćanja</translation>
    </message>
    <message>
        <source>View newsletter bounces</source>
        <translation>Pregled vraćanja</translation>
    </message>
    <message>
        <source>Newsletters</source>
        <translation>Newsletters</translation>
    </message>
    <message>
        <source>You&apos;re already a registered subscriber</source>
        <translation>Vi ste već prijavljeni</translation>
    </message>
    <message>
        <source>Passwords did not match.</source>
        <translation>Lozinke nisu iste.</translation>
    </message>
    <message>
        <source>You must enter a name.</source>
        <translation>Morate unijeti ime.</translation>
    </message>
    <message>
        <source>You must provide a valid email address.</source>
        <translation>Morate unijeti ispravnu e-mail adresu.</translation>
    </message>
    <message>
        <source>Register subscription</source>
        <translation>Regisrtirajte prijavu</translation>
    </message>
    <message>
        <source>Activate Subscription</source>
        <translation>Aktivirajte prijavu</translation>
    </message>
    <message>
        <source>Subscription List</source>
        <translation>Lista prijava</translation>
    </message>
    <message>
        <source>The given email address is already in use. Please use another.</source>
        <translation>Unesena e-mail adresa se već koristi. Molim Vas unesite drugu.</translation>
    </message>
    <message>
        <source>Password did not match</source>
        <translation>Lozinke nisu iste</translation>
    </message>
</context>
<context>
    <name>ezxnewslettert</name>
    <message>
        <source>Back to subscription lists</source>
        <translation>Povratak na listu prijava</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>RowNum</source>
        <translation>Broj retka</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nijedan</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naziv</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Newsletter read</source>
        <translation>Čitanje newslettera</translation>
    </message>
</context>
</TS>
