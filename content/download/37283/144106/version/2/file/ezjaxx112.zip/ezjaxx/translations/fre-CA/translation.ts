<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezjaxx</name>
    <message>
        <source>Please wait...</source>
        <translation>Merci de patienter...</translation>
    </message>
    <message>
        <source>Search in subtree:</source>
        <translation>Rechercher dans l'arborescence:</translation>
    </message>
     <message>
        <source>Manage compiled cache</source>
        <translation>G�rer le cache compil�</translation>
    </message>
    <message>
        <source>Write the name of the template you want to clear compile cache for.</source>
        <translation>Saisir le nom du template dont vous souhaitez compiler le cache.</translation>
    </message>
    <message>
        <source>The template name should have a length of 1 or higher!</source>
        <translation>Le nom du template devrait contenir au moins un caract�re!</translation>
    </message>
</context>
<context>
	<name>design/admin/popupmenu</name>
    <message>
        <source>Copy here</source>
        <translation>Copier ici</translation>
    </message>
</context>
<context>
	<name>design/admin/pagelayout</name>
    <message>
        <source>Quick search</source>
        <translation>Recherche rapide</translation>
    </message>
</context>
</TS>