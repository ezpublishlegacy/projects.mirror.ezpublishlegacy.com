<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezjaxx</name>
    <message>
        <source>Please wait...</source>
        <translation>Aguarde, por favor...</translation>
    </message>
</context>
</TS>
