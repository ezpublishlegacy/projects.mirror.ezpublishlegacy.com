<?php /* #?ini charset="iso-8859-1"?

[Tool]
AvailableToolArray[]=admin_search

[Toolbar_admin_developer]
#Tool[]
Tool[]=admin_search

*/ ?>