<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezjaxx</name>
    <message>
        <source>Please wait...</source>
        <translation>Bitte warten...</translation>
    </message>
</context>
</TS>
