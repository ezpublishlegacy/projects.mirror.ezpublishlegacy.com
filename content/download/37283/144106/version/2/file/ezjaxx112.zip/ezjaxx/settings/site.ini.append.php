<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=jaxx/expand
PolicyOmitList[]=jaxx/search
PolicyOmitList[]=jaxx/keyword
PolicyOmitList[]=jaxx/preferences

[RegionalSettings]
TranslationExtensions[]=ezjaxx


#[SearchSettings]
#EnableWildcard=true


[SSLZoneSettings] 
ModuleViewAccessMode[jaxx/*]=keep




*/ ?>
