<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezjaxx</name>
    <message>
        <source>Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search in subtree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage compiled cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write the name of the template you want to clear compile cache for.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The template name should have a length of 1 or higher!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
	<name>design/admin/popupmenu</name>
    <message>
        <source>Copy here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
	<name>design/admin/pagelayout</name>
    <message>
        <source>Quick search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>