<?php
//
// Created on: <13-May-2007 00:00:00 ar>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: Cache Manager for eZ Publish
// FOR SOFTWARE RELEASE: 3.8.x
// COPYRIGHT NOTICE: Copyright (C) 2007-* Lagardere
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//


include_once( 'lib/ezutils/classes/ezsys.php' );
include_once( 'kernel/common/template.php' );
include_once( 'lib/eztemplate/classes/eztemplatecompiler.php' );

$mode = $Params['mode'];

if ($mode == 'search')
{
    $template_name = trim( str_replace(".tpl", "", $_POST['template']) );
    $only_old = (int) $_POST['onlyold'];
    
    if ( strpos( $template_name, '*') === false ) $template_name .= '*';
    
    echo '<!-- template_name: ' . $template_name . ' -->'; //debug
    
    $cacheDir = eZSys::cacheDirectory() . '/template/compiled/' . $template_name;
    
    echo '<!-- cacheDir: ' . $cacheDir . ' -->'; //debug
    
    $arr = glob( $cacheDir. '.php' );
    $c = count( $arr );
    $cDel = 0;
    $cacheTime = 0;
    $templateTime = 0;
    $line = 0;
    $templateName = '';
    
   
    if ($c == 0)
    {
      echo "0 compiled templates found with the given name pattern: $template_name ! <br />";
      eZExecution::cleanExit();
    } else if ( $c > 100)
    {
      echo "$c compiled templates found with the given name pattern: $template_name , please restrict your search word! <br />";
      eZExecution::cleanExit();
    }

	foreach ($arr as $cacheName)
	{
		if ( strpos( $cacheName, 'common.php') !== false )
        {
            continue;
        }
        
		$line = 0;
        $templateTime = 0;
		$templateName = '';
        $cacheTime = filemtime( $cacheName );
        $handle = fopen( $cacheName, "r" );

		if ( $handle )
		{
		    while (!feof( $handle ) && $line < 3)
		    {
		        $buffer = fgets( $handle, 4096 );
		        if ($line == 2)	
		            $templateName = trim( str_replace( '// Filename:', '', $buffer ) );

		        $line++;
		    }
		    fclose($handle);
		}
        
		if ($only_old && $templateName && file_exists( $templateName ) )
			$templateTime = filemtime( $templateName );
        elseif ( !$only_old && $templateName && file_exists( $templateName ) )
            $templateTime = $cacheTime + 1;
            
         
        if ($templateTime > $cacheTime)
        {
            echo "$cacheName <a onclick=\"reCompileCompiledTemplate(this, '$templateName' )\" style='color: green' title='Recompile, only works on current siteaccess templates!'>[R]</a> ";
            echo "<a onclick=\"reCompileCompiledTemplate(this, '$cacheName', true )\" style='color: red' title='Delet. Warning: unsafe!'>[D]</a> <br />";
            $cDel++;
        }
	}
    if ( !$cDel )
        echo  $c . ' compiled template' . ($c == 1?'':'s') . ' where found but where up to date! <br />';

}
elseif ($mode == 'delet')
{
    $file_name = trim( $_POST['file'] );
    if ( is_writable( $file_name) )
    {
        unlink ( $file_name );
        echo  "$file_name deleted <br />";
    }
    else
    {
        echo  "$file_name not writable <br />";
    }   
}
elseif ($mode == 're_compile')
{
    $file_name = trim( $_POST['file'] );
    if ( file_exists( $file_name) )
    {
        $sys =& eZSys::instance();
        /* don't work:
        $siteaccess = 'gallery_site';
        include_once( "access.php" );
        if ( $siteaccess != $sys->AccessPath[0] )
            $access = array( 'name' => $siteaccess, 'type' => EZ_ACCESS_TYPE_STATIC );

        $access = changeAccess( $access );
        $GLOBALS['eZCurrentAccess'] =& $access;
        $sys->AccessPath[0]  = $siteaccess;       
        
        $ini =& eZINI::instance();
        if ( $ini->hasVariable( 'SiteAccessSettings', 'RelatedSiteAccessList' ) )
            $sys->AccessPath = $ini->variable( 'SiteAccessSettings', 'RelatedSiteAccessList' );
*/
        echo '<!-- access: ' . $sys->AccessPath[0]  .' -->';

        $tpl  = templateInit();
        eZTemplateCompiler::setSettings( array( 'generate' => true ) );
        $stat = $tpl->compileTemplateFile( $file_name );
        echo  "compiled template $file_name recompiled <br /><!--  status: $stat -->";
    }
    else
    {
        echo  "$file_name not found <br />";
    }

}

//$GLOBALS["show_page_layout"]= false;
eZExecution::cleanExit();


?>
