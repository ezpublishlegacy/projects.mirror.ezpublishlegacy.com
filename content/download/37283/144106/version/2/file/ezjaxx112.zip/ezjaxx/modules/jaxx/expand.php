<?php
//
// Created on: <1-Des-2006 00:00:00 ar>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZjaxx Ajax extension for eZ Publish
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2006-* eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
// ## BEGIN ABOUT TEXT, SPECS AND DESCRIPTION  ##
//
// MODULE:      JAXX
// VIEW:        EXPAND
// PARAMS:      'UIcontext', 'CurrentID', 'NodeID', 'CustomCallBack'
// OUTPUT:      xhtml
// TEMPLATE(S): contentstructuremenu/dyn_show_content_structure.tpl
//              if template mode is on, default is to generate output in php for speed
// DESCRIPTION: This module generates the on demand xhtml for the admin content structur
//              menu, it has three different mods explained in jaxx.ini
//
// ## END ABOUT TEXT, SPECS AND DESCRIPTION  ##
//


include_once( 'lib/ezutils/classes/ezfunctionhandler.php' );
include_once( 'kernel/common/eztemplatedesignresource.php' );
include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezuri.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'extension/ezjaxx/classes/expandfunctions.php' );


$nodeID        = 0;
$jsCallBack    = '';
$UIcontext     = 'navigation';
$currentNodeID = (int) $Params['CurrentID'];


if ( isset( $Params['context'] ) )
{
     $UIcontext = $Params['context'];
}

if ( isset( $Params['NodeID'] ) && is_numeric($Params['NodeID']))
{
   $nodeID = (int) $Params['NodeID'];
}

if ( isset( $Params['CustomCallBack'] ) && trim( $Params['CustomCallBack'] )  )
{
   $jsCallBack = trim( $Params['CustomCallBack'] );
}


if ($nodeID === 0)
{
    echo 'No NodeID!';
    eZExecution::cleanExit();
}

$menuINI            =& eZINI::instance( 'contentstructuremenu.ini' );
$showClasses        = $menuINI->variable( 'TreeMenu', 'ShowClasses' );
$maxNodes           = $menuINI->variable( 'TreeMenu', 'MaxNodes' );
$iconSize           = $menuINI->variable( 'TreeMenu', 'ClassIconsSize' );
$toolTips           = ($menuINI->variable( 'TreeMenu', 'ToolTips' ) == 'enabled');
$itemClickAction    = $menuINI->variable( 'TreeMenu', 'ItemClickAction' );
$createHereMenu     = $menuINI->variable( 'TreeMenu', 'CreateHereMenu' );

$jaxxINI            =& eZINI::instance( 'jaxx.ini' );
$expandType         = $jaxxINI->variable( 'JaxxSettings', 'ExpandType' );
$node               = eZContentObjectTreeNode::fetch( $nodeID );

if (!$node)
{
    echo 'No Parent Node!';
    eZExecution::cleanExit();
}

if ( $itemClickAction )
{
    eZURI::transformURI( $itemClickAction );
}
elseif ( $UIcontext === 'browse' )
{
    $itemClickAction = '/content/browse/';
    eZURI::transformURI( $itemClickAction );
}


if ( $expandType == 'subtree' )
{

    $node_array = $node->subTree(
        array( 'Depth' => 1,
               'Limit'            => $maxNodes,
               'Offset'           => 0,
               'SortBy'           => $node->attribute( 'sort_array' ),
               'DepthOperator'    => 'eq',
               'ClassFilterType'  => 'include',
               'ClassFilterArray' => $showClasses,
               'AsObject'         => false
               ));

    $nodeCount = count( $node_array );

    if (!$nodeCount)
    {
        echo 'No Child Nodes!';
        eZExecution::cleanExit();
    }

    --$nodeCount;
    $db                 =& eZDB::instance();
    $resource           =& eZTemplateDesignResource::instance();
    $image_open_path    =  filePath( '/images/content_tree-open.gif', $resource );
    $image_blank_path   =  filePath( '/images/1x1.gif', $resource );
    $objectTreeNode     = new eZContentObjectTreeNode;
    $contentLanguage    = (class_exists( 'eZContentLanguage' )) ? new eZContentLanguage : false;
    $classListJs        = ($createHereMenu !== 'disabled' && method_exists($objectTreeNode, "availableClassListJsArray"));
    $languageListJs     = ($contentLanguage && method_exists($contentLanguage, "jsArrayByMask"));
    $classesSql = eZContentObjectTreeNode::createClassFilteringSQLString( 'include', $showClasses );
    if ( $classListJs && $createHereMenu === 'simplified' )
        $classList = ", '%classList%', " . $objectTreeNode->availableClassListJsArray( $node_array[0]  );
    else 
        $classList = '';
        


    foreach ($node_array as $key => $item)
    {
        $liClass = array();
        $itemNodeID = $item['node_id'];
        $itemName = htmlspecialchars( $item['name'] );
        $visibility = '';
        if ( $toolTips )
        {
            $visibility = ' title="Node ID: ' . $itemNodeID . ' Visibility: ';
            if ($item['is_hidden']) $visibility .= 'Hidden"';
            elseif ($item['is_invisible']) $visibility .= 'Hidden by superior"';
            else $visibility .= 'Visible"';
        }
        $item_href =  $item['path_identification_string'];
        $has_children = fetchNodeChildCount($itemNodeID, $classesSql, $db);
        /*eZContentObjectTreeNode::subTreeCount( array( 'Depth' => 1,
                                                                      'DepthOperator'    => 'eq',
                                                                      'ClassFilterType'  => 'include',
                                                                      'ClassFilterArray' => $showClasses
                                                                      ), $itemNodeID );*/
        if ( $classListJs && $createHereMenu === 'full' )
            $classList = ", '%classList%', " . $objectTreeNode->availableClassListJsArray( $item  );
        
        $languageList = ($languageListJs) ? ", '%languages%', " . $contentLanguage->jsArrayByMask( $item['language_mask'] ) : '';

        if ($itemClickAction != '') $item_href = $itemClickAction . '/' . $itemNodeID;
        else eZURI::transformURI( $item_href );

        if ($key == $nodeCount) array_push($liClass, 'lastli');
        if ($key === 0) array_push($liClass, 'firstli');
        if ($itemNodeID === $currentNodeID) array_push($liClass, 'currentnode');

        echo '<li id="n' . $itemNodeID . '"';
        if (isset($liClass[0]))  echo ' class="' . implode( ' ', $liClass) . '"';
        if (!$has_children) echo '><span class="openclose"><img alt="." border="0" src="' . $image_blank_path . '" /></span>';
        else echo '><a class="openclose" href="'. $item_href .'" title="' . ezi18n( 'design/admin/contentstructuremenu', 'Fold/Unfold' )  . '" onclick="ezpopmenu_hideAll();"><img border="0" src="' . $image_open_path . '" alt="Open sub menu" /></a>';

        if ($UIcontext === 'browse')
            echo ' <a class="nodeicon" href="#">';
        else
            echo ' <a class="nodeicon" href="#" onclick="ezpopmenu_showTopLevel( event, ' . "'ContextMenu'" . ", ez_createAArray( new Array( '%nodeID%', " . $itemNodeID . ", '%objectID%', " . $item['contentobject_id'] . $languageList . $classList . " ) ) , '" . str_replace( array( "\\", "\"", "'"), array( "\\\\", "\\042", "\\047" ) , substr($item['name'], 0, 18) ) . "', " . $itemNodeID . ((!$classList) ? ", 'menu-create-here'" : '') .');return false;' . '">';

        echo classIcon($item['class_identifier'], $iconSize ) . '</a>';
        if ($jsCallBack) echo ' <a class="nodetext" onclick="' . $jsCallBack . '(this, ' .$itemNodeID .')"';
        else echo ' <a class="nodetext" href="' . $item_href . '"';

        if ($item['is_hidden'])
            echo $visibility . '><span class="node-name-hidden">' . $itemName . '</span><span class="node-hidden">(Hidden)</span></a>';
        elseif ($item['is_invisible'])
            echo $visibility . '><span class="node-name-hiddenbyparent">' . $itemName . '</span><span class="node-hiddenbyparent">(Hidden by parent)</span></a>';
        else
            echo $visibility .'><span class="node-name-normal">' . $itemName . '</span></a>';

        if ($has_children) echo '<ul class="subMenu" style="display:none;"><li class="lastli loading">' . ezi18n( 'design/standard/ezjaxx', 'Please wait...' ) . '</li></ul>';
        echo '</li>';
    }
}
elseif ( $expandType == 'direct' )
{
    $db         =& eZDB::instance();
    $classesSql = eZContentObjectTreeNode::createClassFilteringSQLString( 'include', $showClasses );
    /*
        $limitation = ( isset( $params['Limitation']  ) && is_array( $params['Limitation']  ) ) ? $params['Limitation']: false;
        $limitationList = eZContentObjectTreeNode::getLimitationList( $limitation );
        $sqlPermissionChecking = eZContentObjectTreeNode::createPermissionCheckingSQL( $limitationList );
     */
    
    $node_array = fetchNodeList( $nodeID, nodeSortSql( $node->attribute( 'sort_array' ) ), $classesSql, $maxNodes, $db );
    $nodeCount  = count( $node_array );

    if (!$nodeCount)
    {
        echo 'No Child Nodes!';
        eZExecution::cleanExit();
    }

    --$nodeCount;
    $resource         =& eZTemplateDesignResource::instance();
    $image_open_path  =  filePath( '/images/content_tree-open.gif', $resource );
    $image_blank_path =  filePath( '/images/1x1.gif', $resource );


    foreach ($node_array as $key => $item)
    {
        $liClass = array();
        $itemNodeID = $item['node_id'];
        $itemName = htmlspecialchars( $item['name'] );
        $visibility = '';
        if ( $toolTips )
        {
            $visibility = ' title="Node ID: ' . $itemNodeID . ' Visibility: ';
            if ($item['is_hidden']) $visibility .= 'Hidden"';
            elseif ($item['is_invisible']) $visibility .= 'Hidden by superior"';
            else $visibility .= 'Visible"';
        }
        $item_href =  $item['url_alias'];
        $has_children = ($item['is_container'] && fetchNodeChildCount($itemNodeID, $classesSql, $db));
        if ($itemClickAction != '') $item_href = $itemClickAction . '/' . $itemNodeID;
        else eZURI::transformURI($item_href);

        if ($key == $nodeCount) array_push($liClass, 'lastli');
        if ($key === 0) array_push($liClass, 'firstli');
        if ($itemNodeID === $currentNodeID) array_push($liClass, 'currentnode');

        echo '<li id="n' . $itemNodeID . '"';
        if (isset($liClass[0]))  echo ' class="' . implode( ' ', $liClass) . '"';
        if (!$has_children) echo '><span class="openclose"><img alt="." border="0" src="' . $image_blank_path . '" /></span>';
        else echo '><a class="openclose" href="'. $item_href .'" title="' . ezi18n( 'design/admin/contentstructuremenu', 'Fold/Unfold' )  . '" onclick="ezpopmenu_hideAll();"><img border="0" src="' . $image_open_path . '" alt="Open sub menu" /></a>';

        if ($UIcontext === 'browse')
            echo ' <a class="nodeicon" href="#">';
        else
            echo ' <a class="nodeicon" href="#" onclick="ezpopmenu_showTopLevel( event, ' . "'ContextMenu'" . ", ez_createAArray( new Array( '%nodeID%', " . $itemNodeID . ", '%objectID%', " . $item['contentobject_id'] . " ) ) , '" . str_replace( array( "\\", "\"", "'"), array( "\\\\", "\\042", "\\047" ) , substr($item['name'], 0, 18) ) . "', " . $itemNodeID . ');return false;' . '">';

        echo classIcon($item['class_identifier'], $iconSize ) . '</a> <a class="nodetext" href="' . $item_href . '"';

        if ($item['is_hidden'])
            echo $visibility . '><span class="node-name-hidden">' . $itemName . '</span><span class="node-hidden">(Hidden)</span></a>';
        elseif ($item['is_invisible'])
            echo $visibility . '><span class="node-name-hiddenbyparent">' . $itemName . '</span><span class="node-hiddenbyparent">(Hidden by parent)</span></a>';
        else
            echo $visibility .'><span class="node-name-normal">' . $itemName . '</span></a>';

        if ($has_children) echo '<ul class="subMenu" style="display:none;"><li class="lastli loading">' . ezi18n( 'design/standard/ezjaxx', 'Please wait...' ) . '</li></ul>';
        echo '</li>';
    }
}
else
{
    $nodeList = $node->subTree(
        array( 'Depth' => 1,
               'Limit'            => $maxNodes,
               'Offset'           => 0,
               'SortBy'           => $node->attribute( 'sort_array' ),
               'DepthOperator'    => 'eq',
               'ClassFilterType'  => 'include',
               'ClassFilterArray' => $showClasses,
               'AsObject'         => true
               ));
    $nodeCount = count( $nodeList );

    if (!$nodeCount)
    {
        echo 'No Child Nodes!';
        eZExecution::cleanExit();
    }

    include_once( 'kernel/common/template.php' );

    $tpl =& templateInit();
    $tpl->setVariable( 'ui_context', $UIcontext );
    $tpl->setVariable( 'ShowClasses', $showClasses );
    $tpl->setVariable( 'currentNodeList', $nodeList );
    $tpl->setVariable( 'itemClickAction', $itemClickAction );
    $tpl->setVariable( 'createHereMenu', $createHereMenu );
    $tpl->setVariable( 'last_key', $nodeCount -1 );
    $tpl->setVariable( 'currentNodeID', $currentNodeID );
    $tpl->setVariable( 'classIconsSize', $iconSize  );

    echo $tpl->fetch( 'design:contentstructuremenu/dyn_show_content_structure.tpl' );
}

eZExecution::cleanExit();
//$GLOBALS['show_page_layout'] = false;

?>