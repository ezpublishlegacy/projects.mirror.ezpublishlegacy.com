<?php /* #?ini charset="utf-8"?


[JavaScriptSettings]
JavaScriptList[]=jaxx.js
JavaScriptList[]=common_ezjaxx.js


[StylesheetSettings]
CSSFileList[]=ezjaxx.css


*/ ?>
