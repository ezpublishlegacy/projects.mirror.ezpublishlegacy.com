<?php /* #?ini charset="utf-8"?

[JaxxSettings]
# There are three expand types: 'template', 'subtree' and 'direct'
# 'template' and 'subtree' is similar in funtionality, 'subtree' is a bit faster then 
# 'template'' since it does not use a template to display the result, but because of
#  that you can not override the output by template.
# 'direct' is fastest, but does not currently support permission, translations
# and create here menu, and is mostly ment for testing on eZ Publish 3.8 and 3.9
ExpandType=subtree

#Controlls if some buttons in setup/cache should be disabled, basicly forcing user
#to use the finer controlls for cache clear. This is nice for production sites where
#to many people have access to clearing cache :)
#Affects: Clear All, Clear All Template Cache, Cleare View and Block cache
RestrictClearCache=enabled


# Class ID's to include in search, will search on all classes if left empty
SearchClassIdArray[]

# Attribute ID's to include in search, will search on all if left empty
SearchAttributeIdArray[]
#SearchAttributeIdArray[]=1
#SearchAttributeIdArray[]=4

# Only search for keywords whithin same class type
KeywordClassLimit=disabled

# Limit number of keywords to suggest from db, 0 = do not search in db
KeywordLimit=7

# Static list of class wide suggestion words, will be suggested in top to down order
KeywordSuggestionsArray[]
KeywordSuggestionsArray[]=eZ
KeywordSuggestionsArray[]=System
KeywordSuggestionsArray[]=Publish
KeywordSuggestionsArray[]=Now
KeywordSuggestionsArray[]=Components

*/
?>