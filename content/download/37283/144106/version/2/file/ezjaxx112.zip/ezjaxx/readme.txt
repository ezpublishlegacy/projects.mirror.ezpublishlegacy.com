eZjaxx extension 1.x README
Ajax extension for eZ Publish 3.6 - 3.9


What is the eZjaxx extension?
==============================

eZjaxx is a take on improving the speed of eZ Publish admin
interface and include some bells and whistles to improve editing
and admin workflow.
This is done by both template improvements and the use 
of Javascript / Ajax.
