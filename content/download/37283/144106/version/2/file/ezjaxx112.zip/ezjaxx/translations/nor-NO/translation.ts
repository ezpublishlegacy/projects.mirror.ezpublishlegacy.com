<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezjaxx</name>
    <message>
        <source>Please wait...</source>
        <translation>Vennligst vent...</translation>
    </message>
    <message>
        <source>Search in subtree:</source>
        <translation>S�k i innholdstree:</translation>
    </message>
    <message>
        <source>Manage compiled cache</source>
        <translation>H�ndter kompilert mal cache</translation>
    </message>
    <message>
        <source>Write the name of the template you want to clear compile cache for.</source>
        <translation>Skriv inn navnet p� malen du �nsker til � fjerne cache for.</translation>
    </message>
    <message>
        <source>The template name should have a length of 1 or higher!</source>
        <translation>Mal navnet m� v�re 1 tegn eller mer!</translation>
    </message>
</context>
<context>
	<name>design/admin/popupmenu</name>
    <message>
        <source>Copy here</source>
        <translation>Kopier hit</translation>
    </message>
</context>
<context>
	<name>design/admin/pagelayout</name>
    <message>
        <source>Quick search</source>
        <translation>Hurtigsøk</translation>
    </message>
</context>
</TS>
