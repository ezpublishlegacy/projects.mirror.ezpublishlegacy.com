<?php
//
// Created on: <15-Jan-2007 00:00:00 ar>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZjaxx Ajax extension for eZ Publish
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2007-* eZ systems AS
//                   Copyright (C) 2006-* Kristof Coomans
//                   ( Based on code by Kristof Coomans
//                   in Xajax ClassAttributes )
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
// ## BEGIN ABOUT TEXT, SPECS AND DESCRIPTION  ##
//
// MODULE:      JAXX
// VIEW:        CLASSMOVE
// PARAMS:      id, action, datatype
// OUTPUT:      json or xml
// DESCRIPTION: Moving class attributes upp or down or adding new attributes
//
// ## END ABOUT TEXT, SPECS AND DESCRIPTION  ##
//


include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );

$user =& eZUser::currentUser();
$accessResult = $user->hasAccessTo( 'class', 'edit' );

if ( $accessResult['accessWord'] == 'no' )
{
    echo 'alert("You are not allowed to edit content classes");';
    eZExecution::cleanExit();
}

$id = $Params["id"];
$action = $Params["action"];
$datatypeString = $Params["datatype"];
$EditLanguage = $Params["lang"];

if ($action != 'Add')
{
    
    include_once( 'kernel/classes/ezdatatype.php' );
    eZDataType::loadAndRegisterAllTypes();
    $attribute = eZContentClassAttribute::fetch( $id, true, EZ_CLASS_VERSION_STATUS_TEMPORARY,
                                                  array( 'contentclass_id', 'version', 'placement' ) );

    if ( !$attribute )
    {
        echo 'alert("Unable to fetch the class attribute.");';
        eZExecution::cleanExit();
    }

    $classID = $attribute->attribute( 'contentclass_id' );

}
else
{
    $classID = $id;
}

include_once( 'kernel/classes/ezcontentclass.php' );
$class = eZContentClass::fetch( $classID, true, EZ_CLASS_VERSION_STATUS_TEMPORARY );

if ( !is_object( $class ) || $class->attribute( 'id' ) == null )
{
    echo 'alert("Unable to find the temporary version of the class.");';
    eZExecution::cleanExit();
}

include_once( 'lib/ezlocale/classes/ezdatetime.php' );

include_once( 'lib/ezutils/classes/ezini.php' );
$contentIni = eZIni::instance( 'content.ini' );
$timeOut = $contentIni->variable( 'ClassSettings', 'DraftTimeout' );

if ( $class->attribute( 'modifier_id' ) != $user->attribute( 'contentobject_id' ) &&
     $class->attribute( 'modified' ) + $timeOut > time() )
{
    $message = 'This class is already being edited by someone else.';
    $message = $message . ' The class is temporarly locked and thus it can not be edited by you.';

    echo 'alert("' . $message . '");';
    eZExecution::cleanExit();
}


if ( !$EditLanguage )
{
    // Check number of languages
    include_once( 'kernel/classes/ezcontentlanguage.php' );
    $languages = eZContentLanguage::fetchList();
    // If there is only one language we choose it for the user.
    if ( count( $languages ) == 1 )
    {
        $language = array_shift( $languages );
        $EditLanguage = $language->attribute( 'locale' );
    }
    elseif ( count( $class->attribute( 'can_create_languages' ) ) == 0)
    {
        $EditLanguage = $class->attribute( 'top_priority_language_locale' );
    }
}



if ($action == 'Add')
{
    $existingAttributes = eZContentClass::fetchAttributes( $classID, false, EZ_CLASS_VERSION_STATUS_TEMPORARY );

    $new_number = count( $existingAttributes ) + 1;

    header("Content-Type: text/xml; charset=utf-8");

    $new_attribute = eZContentClassAttribute::create( $classID, $datatypeString, array(), $EditLanguage );
    
    // Since 3.9 added multilang support to classes, we need to look for methods
    if ( method_exists($new_attribute,'setName') )
        $new_attribute->setName( ezi18n( 'kernel/class/edit', 'new attribute' ) . $new_number, $EditLanguage );
    else
        $new_attribute->setAttribute( 'name', ezi18n( 'kernel/class/edit', 'new attribute' ) . $new_number );
    
    $dataType = $new_attribute->dataType();
    $dataType->initializeClassAttribute( $new_attribute );
    $new_attribute->store();


    include_once( 'kernel/common/template.php' );
    $tpl =& templateInit();

    $tpl->setVariable( 'attribute', $new_attribute );
    $tpl->setVariable( 'number', $new_number );
    $tpl->setVariable( 'language_code', 0 ); // This is a new attribute, there are no need to get language

     echo str_replace( array("\r\n", "\n", "   ", "  "), '', $tpl->fetch( 'design:class/edit_jaxx_attribute.tpl' ) );

}
else
{
   $attribute->move( ($action == 'MoveDown') );
   echo 'classEditUpDownMove(' . $id . ', "' . $action . '" );';
}
eZExecution::cleanExit();

?>