<?php

$Module = array( 'name' => 'eZaxx Module and Views',
                 'variable_params' => true );

$ViewList = array();

$ViewList["expand"] = array(
    "script" => "expand.php",
    'params' => array( 'context', 'CurrentID', 'NodeID', 'CustomCallBack' )
    );
    
$ViewList["search"] = array(
    "script" => "search.php",
    'params' => array( 'UIcontext', 'Offset' )
    );
    
$ViewList["keyword"] = array(
    "script" => "keyword.php",
    'params' => array( 'ClassID' )
    );

$ViewList["preferences"] = array(
    "script" => "preferences.php",
    'params' => array( 'Function', 'Key', 'Value' )
    );

$ViewList["copyobject"] = array(
    "script" => "copyobject.php",
    'params' => array( 'ObjectID' )
    );
    
$ViewList["roleedit"] = array(
    "script" => "roleedit.php",
    'params' => array( 'moduleName' )
    );
    
/*$ViewList["image"] = array(
    "script" => "image.php",
    'params' => array( 'SortColumn', 'SortOrder', 'NodeID' )
    );*/

$ViewList["classattribute"] = array(
    "script" => "classattribute.php",
    'params' => array( 'id', 'action', 'datatype', 'lang' )
    );
    
$ViewList["clear_compiled"] = array(
    "script" => "clear_compiled.php",
    "params" => array( 'mode' )
    );
    
  
  
$FunctionList = array();
$FunctionList['clear_compiled'] = array();
$FunctionList['classattribute'] = array();
$FunctionList['roleedit'] = array();
$FunctionList['copyobject'] = array();
    

?>
