<?php
//
// Created on: <1-Mar-2007 00:00:00 ar>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: eZjaxx Ajax extension for eZ Publish
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2006-* eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//
// Common functions for expand view



function fetchNodeSort( $node_id, &$db )
{
    $query = 'SELECT sort_field,
                     sort_order
                  FROM ezcontentobject_tree
                  WHERE node_id='.$node_id;

    $node_array = $db->arrayQuery( $query );
    return $node_array;
}


function filePath($path, &$resource)
{
    $bases = $resource->allDesignBases();
    foreach ( $bases as $base )
    {
        if ( file_exists( $base . $path ) )
        {
            return eZSys::wwwDir() . '/' . $base . $path;
        }
    }
    return '';
}


function nodeSortSql($sort)
{
    $sort = $sort[0];
    $sort_order = array('DESC','ASC');
    $sort_order = $sort_order[$sort[1]];
    switch ( $sort[0] )
    {
        case 'owner':
            return ' ORDER BY ezcontentobject.owner_id ' . $sort_order;
        case 'path':
            return ' ORDER BY ezcontentobject_tree.path_string ' . $sort_order;
        case 'published':
            return ' ORDER BY ezcontentobject.published ' . $sort_order;
        case 'modified':
            return ' ORDER BY ezcontentobject.modified ' . $sort_order;
        case 'section':
            return ' ORDER BY ezcontentobject.section_id ' . $sort_order;
        case 'depth':
            return ' ORDER BY ezcontentobject_tree.depth ' . $sort_order;
        case 'class_identifier':
            return ' ORDER BY ezcontentclass.identifier ' . $sort_order;
        case 'class_name':
            return ' ORDER BY ezcontentclass.name ' . $sort_order;
        case 'priority':
            return ' ORDER BY ezcontentobject_tree.priority ' . $sort_order;
        case 'name':
            return ' ORDER BY ezcontentobject.name ' . $sort_order;
        case 'modified_subnode':
            return ' ORDER BY ezcontentobject_tree.modified_subnode ' . $sort_order;
        default:
            return '';
    }
}


function classIcon($class_identifier, $sizeName)
{
    $ini =& eZINI::instance( 'icon.ini' );
    $repository = $ini->variable( 'IconSettings', 'Repository' );
    $configGroup = 'ClassIcons';

    // Check if the specific icon type has a theme setting
    if ( $ini->hasVariable( $configGroup, 'Theme' ) )
        $theme = $ini->variable( $configGroup, 'Theme' );
    else
        $theme = $ini->variable( 'IconSettings', 'Theme' );


    // Load icon settings from the theme
    $themeINI =& eZINI::instance( 'icon.ini', $repository . '/' . $theme );


    $sizes = $themeINI->variable( 'IconSettings', 'Sizes' );
    if ( $ini->hasVariable( 'IconSettings', 'Sizes' ) )
    {
        $sizes = array_merge( $sizes,
                              $ini->variable( 'IconSettings', 'Sizes' ) );
    }

    if ( isset( $sizes[$sizeName] ) )
        $size = $sizes[$sizeName];
    else
        $size = $sizes[0];


    $pathDivider = strpos( $size, ';' );
    if ( $pathDivider !== false )
    {
        $sizePath = substr( $size, $pathDivider + 1 );
        $size = substr( $size, 0, $pathDivider );
    }
    else
    {
        $sizePath = $size;
    }

    $sizeText = '';
    $xDivider = strpos( $size, 'x' );
    if ( $xDivider !== false )
        $sizeText = ' width="' . (int)substr( $size, 0, $xDivider ) . '" height="' . (int)substr( $size, $xDivider + 1 ). '"';


    $altText = "Click on the icon to get a context sensitive menu.";
    $map = array();

    // Load mapping from theme
    if ( $themeINI->hasVariable( 'ClassIcons', 'ClassMap' ) )
        $map = array_merge( $map,
                            $themeINI->variable( 'ClassIcons', 'ClassMap' ) );

    // Load override mappings if they exist
    if ( $ini->hasVariable( 'ClassIcons', 'ClassMap') )
        $map = array_merge( $map,
                            $ini->variable( 'ClassIcons', 'ClassMap' ) );

    if ( isset( $map[$class_identifier] ) )
    {
        $icon = $map[$class_identifier];
    }
    else
    {
        if ( $themeINI->hasVariable( 'ClassIcons', 'Default' ) )
            $icon = $themeINI->variable( 'ClassIcons', 'Default' );
        if ( $ini->hasVariable( 'ClassIcons', 'Default' ) )
            $icon = $ini->variable( 'ClassIcons', 'Default' );
    }

    $iconPath = eZSys::wwwDir(). '/' . $repository . '/' . $theme . '/' . $sizePath . '/' . $icon;

    return '<img src="' .  $iconPath . '"' . $sizeText . ' alt="' .   $altText  . '" title="' .  $altText . '" />';
}



function fetchNodeList($parent_node_id, $parent_sort_sql, $classesSql, $max_nodes, &$db )
{
    //based on code from Paul Forsyth @ VisionWT
    $query = 'SELECT ezcontentobject_tree.contentobject_id as contentobject_id,
                     ezcontentobject_tree.contentobject_version as contentobject_version,
                     ezcontentobject_tree.is_hidden as is_hidden,
                     ezcontentobject_tree.is_invisible as is_invisible,
                     ezcontentobject_tree.path_identification_string as url_alias,
                     ezcontentobject_tree.node_id as node_id,
                     ezcontentobject.name as name,
                     ezcontentclass.is_container as is_container,
                     ezcontentclass.identifier as class_identifier
                  FROM ezcontentobject_tree, ezcontentclass, ezcontentobject
                  WHERE ezcontentobject_tree.parent_node_id=' . $parent_node_id . '
                  AND ezcontentobject.contentclass_id=ezcontentclass.id
                  AND';

    if ($classesSql)
        $query = $query . $classesSql;
        
    $query .= ' ezcontentobject_tree.contentobject_id=ezcontentobject.id ';
    if ( $parent_sort_sql )
        $query = $query . $parent_sort_sql;

    //WARNING: This line makes this view only work on mySql and PostgreSql.
    //FIX: Comment this line and enforce the limit inside the $node_array php loop
    // instead if you want slower but cross db support.
    if ($max_nodes) $query = $query . ' LIMIT ' . $max_nodes;

    return $db->arrayQuery( $query );
}


function fetchNodeChildCount( $parent_node_id, $classesSql, &$db )
{
    $query = 'SELECT COUNT(ezcontentobject_tree.node_id) as child_count
                  FROM ezcontentobject_tree, ezcontentclass, ezcontentobject
                  WHERE ezcontentobject_tree.parent_node_id='.$parent_node_id.'
                  AND ezcontentobject.contentclass_id=ezcontentclass.id
                  AND';

    if ($classesSql)
        $query = $query . $classesSql;
    
    $query .= ' ezcontentobject_tree.contentobject_id=ezcontentobject.id ';
    $count = $db->arrayQuery( $query );
    return $count[0]['child_count'];
}

?>