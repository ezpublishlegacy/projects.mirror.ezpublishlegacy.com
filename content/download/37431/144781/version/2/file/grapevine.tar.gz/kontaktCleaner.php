<?php

include_once( "kernel/classes/ezcontentobjecttreenode.php" );



// Check for extension
include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'kernel/common/ezincludefunctions.php' );
eZExtension::activateExtensions();
// Extension check end

include_once( "lib/ezutils/classes/ezini.php" );
$ini =& eZINI::instance( 'content.ini' );
$unpublishClasses[] = 63;

$rootNodeIDList[] = 36;

include_once( 'lib/ezlocale/classes/ezdatetime.php' );
$currrentDate = eZDateTime::currentTimeStamp();

foreach( $rootNodeIDList as $nodeID )
{
    $rootNode =& eZContentObjectTreeNode::fetch( $nodeID );

    $articleNodeArray =& $rootNode->subTree( array( 'ClassFilterType' => 'include',
                                                    'ClassFilterArray' => $unpublishClasses ) );

    foreach ( array_keys( $articleNodeArray ) as $key )
    {
        $article =& $articleNodeArray[$key]->attribute( 'object' );
        $dataMap =& $article->attribute( 'data_map' );
        $dateAttribute =& $dataMap['unpublish_date'];

        if ( is_null( $dateAttribute ) )
            continue;

        $date = $dateAttribute->content();
        $articleRetractDate = $date->attribute( 'timestamp' );
        if ( $articleRetractDate > 0 && $articleRetractDate < $currrentDate )
        {
        	$article->remove( $article->attribute( 'id' ), $articleNodeArray[$key]->attribute( 'node_id' ) );
        	
        	// get object
			$object =& $article;
			$objectId= $article->attribute('id');
			$data_map = $object->dataMap();
		
			$vorname = $data_map['vorname']->content();
	        $nachname = $data_map['nachname']->content();
			$receivers_email = $data_map['email']->content();
			
        	// send mail
	    	// read mailsettings.ini
	    	$debugINI =& eZINI::instance( 'mailsettings.ini' );
	    	$server = $debugINI->variable( 'MailSettings', 'Server' );
	    	if ($server == '') {
	    		$siteIni =& eZINI::instance();
	    		$server = 'http://'.$siteIni->variable( 'SiteSettings', 'SiteURL');
	    	}
	    	$vereinsEmail = $debugINI->variable( 'MailSettings', 'VereinsEmail' );
	    	if ($vereinsEmail == '') {
	    		$siteIni =& eZINI::instance();
	    		$vereinsEmail = $siteIni->variable( 'MailSettings', 'AdminEmail');
	    	}
	    	$memberCharge = $debugINI->variable( 'MoneySettings', 'MemberCharge' );
	    	$communityCharge = $debugINI->variable( 'MoneySettings', 'CommunityCharge' );
	    	$account = $debugINI->variable( 'MoneySettings', 'Account' );
	    	$bank = $debugINI->variable( 'MoneySettings', 'Bank' );
	    	$blz = $debugINI->variable( 'MoneySettings', 'BLZ' );
	    	// done reading config
	    	$hashLink = $server."/verwitwet/content/edit/"; 			
			$hashLink .= $objectId;
			// read Enum 'Anzeigendauer'
			foreach ($data_map as $key => $value) {
				if ($key == 'dauer') {
					$enumObjectContent = $value->attribute('content');
					$SelectedEnums = $enumObjectContent->ObjectEnumerations;
				}
				if ($key == 'mitglied') {
					$enumObjectContent = $value->attribute('content');
					$SelectedEnums2 = $enumObjectContent->ObjectEnumerations;
				}
			}
			$anzeigendauer = $SelectedEnums[0]->EnumValue;
			$verein = $SelectedEnums2[0]->EnumValue;
			
			/*
			 * sending mail analog to workflow 'ApproveMail'
			 */
			
			
		    $subject = "Deine Kontaktanzeige auf verwitwet.de";
	        $mailContent = "Hallo $vorname!<br>";
			$mailContent .= "Deine Kontaktanzeige auf verwitwet.de ist heute abgelaufen und die Anzeige wurde entfernt.<br>";
			$mailContent .= "Du hast die M�glichkeit, Deine Anzeige zu bearbeiten und sie erneut freizuschalten. Dieses w�rde folgende Geb�hren kosten:<br>";
			if ($verein == 'ja') {
				if ($memberCharge == 0) {
					$mailContent .= "F�r Dich als Vereinsmitglied ist die Anzeige kostenlos.<br>";
				} else {
					$mailContent .= "Da du Vereinsmitglied bist, kostet die Anzeige ".$memberCharge." Euro im Monat.<br>";
				}
			} else {
				if ($communityCharge == 0) {
					$mailContent .= "F�r Dich als Communitymitglied ist die Anzeige kostenlos.<br>";
				} else {
					$mailContent .= "Da du Communitymitglied bist, kostet die Anzeige ".$communityCharge." Euro im Monat.<br>";
				}
			}
			$mailContent .= "Um die Anzeige zu bearbeiten, klicke auf folgenden <a href=\"$hashLink\">Link</a>.<br>";
			$mailContent .= "Zum Bearbeiten Deiner Anzeige musst Du Dich einloggen.<br>";
			$mailContent .= "M�chtest Du die Anzeige nicht noch einmal aufgeben, ignoriere diese Mail bitte.<br>";
			$mailContent .= "<br><br>Viel Gl�ck!<br>Oliver ;-)<br><a href=\"http://verwitwet.de\">www.verwitwet.de</a>";
	        $header ="From: verwitwet.de <kontaktanzeige@verwitwet.de>\r\n";
			$header .= "Content-Type: text/html\r\nContent-Transfer-Encoding: 8bit\r\n";
	        
	        mail($receivers_email, $subject, $mailContent, $header);
		
	        // notify club / admin
	        $receivers_email = $vereinsEmail;
	        $subject = "[".$vorname." ".$nachname."] abgelaufene Kontaktanzeige";
	        $mailContent = "Hallo Oliver!<br>";
	        $mailContent .= "Hier spricht Kontakti, Deine Kontaktb�rse auf verwitwet.de, und ich m�chte Dir mitteilen, dass die Kontaktanzeige von ".$vorname." ".$nachname." heute abgelaufen ist.<br>";
			$mailContent .= "Ich habe ".$vorname." angeboten, die Anzeige zu bearbeiten und erneut zu ver�ffentlichen. Nimmt er diese M�glichkeit wahr, so werde ich Dich rechtzeitig informieren.";
	        $mailContent .= "Sch�ne Gr��e,<br>";
	        $mailContent .= "Kontakti ;-)";
	        mail($receivers_email, $subject, $mailContent, $header);
	        // done sending mail
        }
    }
}


?>
