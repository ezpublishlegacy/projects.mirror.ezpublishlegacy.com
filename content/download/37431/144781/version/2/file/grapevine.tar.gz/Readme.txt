Features of "lonely hearts ad"
==============================

Visitors of your website can easily create lonely hearts ads by filling in a form. The generated ad will automatically be unpublished by a workflow and the advertiser and the admin will be informed about the new ad.
The confirmation email contains an application for payment. Fees can be easily set in a configuration file. The email also contains a link. It allows the advertiser to publish his ad by clicking the link, but you should ask him to pay the money first.
While filling in the form the advertiser has set the duration of his ad in months. This time runs from the moment the ad was published. On the expiration date the ad will be unpublished by a cronjob script. At the same time an email is sent to the advertiser with the chance to reactivate the ad by clicking a link. Of course he has to pay for this... The admin will be informed by email about every action of the advertiser. In this way controlling is easy - most of the work will be done by the advertiser.

Environment
===========

This grapevine was developed for a website with two usergroups: community and club member (and of course admins and editors...). So please don't wonder when the sourcecode makes differences between these groups. 
I suppose you won't have these groups, so simply adjust the code to your requirements (mainly emails in workflow 'approveMail' and file 'kontaktCleaner.phh').

Installation of "lonely hearts ad"
==================================

1. Extract all gz-files to a temporal folder in order to restore the complete directory structure.

2. Use your eZ publish administration to create a folder. Place it where the grapevine should be located. Fill the attributes 'introduction' and 'description' as you like.

3. Use the file 'full_node_36' from the gz-file as template for the new created folder. Therefore you have to register it in your override.ini.append-file.

4. Import the package 'Lonely_hearts_ad-1.0-1.ezpkg' from the gz-file to your eZ publish. The file 'full_class_63' is the template for the new imported content class. Register it in your override.ini.append-file. Same for 'edit_class_63', this is the edit template.

5. Copy the extension folder 'kontakt' from the gz-file to your extension directory. 

6. Activate the extension in your site.ini.append by adding the following lines
	   [ExtensionSettings]
	   ActiveExtensions[]=kontakt

7. Adjust the settings in /extension/kontakt/settings/mailsettings.ini. You can set the following values:
	a. VereinsEmail - an email address where all notifications should be sent, if this value is empty the AdminEmail from site.ini will be taken.

8. Copy the workflow-extension 'approvemail' from the gz-file to your extension directory.

9. Activate the extension in your site.ini.append by adding the following lines
	   [ExtensionSettings]
	   ActiveExtensions[]=approvemail

10. Adjust the settings in /extension/approvemail/settings/mailsettings.ini. You can set the following values:
	a. Server - the FQDN of your server for the confirmation link, eg 'http://www.example.com'. If this field is empty, the value SiteURL from site.ini will be taken.
	b. VereinsEmail - an email address where all notifications should be sent, if this value is empty the AdminEmail from site.ini will be taken.
	c. MemberCharge - the fee in Euros a club member has to pay for a 1 month advertisement. Value can be 0 or a digital number in English notation with '.', eg. 9.50 for 9,50 Euros.
	d. CommunityCharge - the fee in Euros a community member has to pay for a 1 month advertisement. Value can be 0 or a digital number in English notation with '.', eg. 9.50 for 9,50 Euros.
	e. Account - place the number uf your bank account here. The fee will be paid from the advertiser to this account.
	f. Bank - place the name of your bank here
	g. BLZ - place the bank identifier code here

11. Go to the administration of your eZ publish. Under 'Setup', 'Workflows' create a new workflow that contained the event 'Approve Mail', which is now available. (If not, try clearing the cache.)

12. Go to 'Setup', 'Triggers' and place your new workflow under 'content - publish - after'. Save the changes.

13. Go to 'Users', 'Roles' and adjust the roles of your user groups. You need to stet the following rights:
	a. Anonymous user: 
	   kontakt   *   *
	   This setting allows to search for an ad, to contact the advertiser and to confirm (publish) an ad by clicking the link in the confirmation mail.
	b. User who can place an ad: 
	   content   create   Class ( Kontaktb�rse ), Node ( [your created folder] )

14. Copy the file 'kontaktCleaner.php' from the gz-file to the directoy /cronjobs. Activate the script to be run by cronjob. Therefore add the following line to your /settings/cronjob.ini.append file:
	   [CronjobSettings]
	   Scripts[]=kontaktCleaner.php
   Cronjob has to be properly installed on your system, see eZ publish documentation.

15. Copy the folder called 'kontaktanzeige' containing images to your image folder, e.g. /design/standard/images. This folder contains the zodiac signs that will be shown if no other picture is uploaded by the advertiser.

16. Now you will have to do some adjustments in the template files. 
    In general, you will have to change '36' to the node_id of your folder (see step 2) and '63' to the id of the imported content class 'Kontaktanzeige' (see step 4).
  - File full_node_36.tpl
	line 197: [...] hash(parent_node_id,36, [..]
		replace 36 with the node_id of your folder (see step 2)
	line 218: [...] name="ClassID" value="63" [...]
		replace 63 with the id of the content class 'kontaktanzeige' imported on step 4

  - File full_class_63.tpl
	line 74: [...] name="ClassID" value="63" [...]
		replace 63 with the id of the content class 'kontaktanzeige' imported on step 4
    
  - File kontaktCleaner.php
	line 15: $unpublishClasses[] = 63;
		replace 63 with the id of the content class 'kontaktanzeige' imported on step 4
	line 17: $rootNodeIDList[] = 36;
		replace 36 with the node_id of your folder (see step 2)

  - Further on you will have to adjust the emails in the php files. If you like, change the mail and server addresses printed in the email from 'example.com' to whatever you like.
	These changes are not essential.
		
17. Navigate to the folder you created in step 1 and enjoy your grapevine! I hope I didn't forget an important step. ;-)


Commemts or questions?
Sebastian Sprenger
S.Sprenger@gmx.de