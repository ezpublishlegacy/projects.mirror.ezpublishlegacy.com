<?php
//////////////////////////////////////////////////////////////////////////////
//
// $RCSfile: module.php,v $
//
// This file is part of the tv-buddy project.
// by Patrizio Bekerle (patrizio@bekerle.com)
// www.bekerle.com
//
//////////////////////////////////////////////////////////////////////////////
//
// $Author: omega $ (this revision)
// $Revision: 1.1.1.1 $
// $Date: 2004/04/07 07:29:10 $ (UTC)
// $Name:  $ (tag name used to check out this file)
//
//////////////////////////////////////////////////////////////////////////////
//
// Description:
//
// MultipleFileUpload module.php
//
//////////////////////////////////////////////////////////////////////////////


$Module = array( "name" => "MultipleFileUpload" );

$ViewList = array();
$ViewList["select"] = array( "script" => "select.php" );
$ViewList["upload"] = array( "script" => "upload.php" );
$ViewList["upload_process"] = array( "script" => "upload_process.php", 'params' => array( 'ParentNodeID' ) );
?>
