<?php
//////////////////////////////////////////////////////////////////////////////
//
// $RCSfile: upload_process.php,v $
//
// by Patrizio Bekerle (patrizio@bekerle.com)
// www.bekerle.com
//
//////////////////////////////////////////////////////////////////////////////
//
// $Author: omega $ (this revision)
// $Revision: 1.8 $
// $Date: 2005/09/02 11:52:29 $ (UTC)
// $Name:  $ (tag name used to check out this file)
//
//////////////////////////////////////////////////////////////////////////////
//
// Description:
//
// Fileupload process file
// The uploaded files will be processed here
//
// (only images will work at the moment)
//
//////////////////////////////////////////////////////////////////////////////


include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezextension.php" );
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( 'lib/ezutils/classes/ezcli.php' );
include_once( "lib/ezutils/classes/ezdebug.php" );
include_once( "lib/ezutils/classes/ezmimetype.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php" );
include_once( "kernel/common/template.php" );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );



$ParentNodeID =& $Params["ParentNodeID"];
if ( $ParentNodeID == 0 )
{
    print "No ParentNodeID set!";
    exit;
}

$tpl =& templateInit();
$tpl->setVariable( 'parentnodeid', $ParentNodeID );

$parentNode =& eZContentObjectTreeNode::fetch( $ParentNodeID );
$tpl->setVariable( 'parentnodename', $parentNode->getName() );

$fileNameArr = array();
foreach($_FILES as $tagname=>$objekt)
{
    // get the temporary name (e.g. /tmp/php34634.tmp)
    $tempName = $objekt['tmp_name'];

    // get the real filename
    $realName = stripslashes( $objekt['name'] );

    addImage( $tempName, $realName, $parentNode );
    $fileNameArr[] = $realName;
}

$tpl->setVariable( 'filenamearr', $fileNameArr );


$Result = array();
$Result['content'] =& $tpl->fetch( "design:multiplefileupload/upload_process.tpl" );
$Result['path'] = array( array( 'url' => '/multiplefileupload/upload_process',
                                'text' => false ) );


function addImage( $imageFile, $imagename, $parent )
{
    $ini =& eZINI::instance( 'multiplefileupload.ini' );
    $imageContentClassID =  (int) $ini->variable( 'GeneralSettings', 'ImageContentClassID' );
    $nameAttributeNumber =  (int) $ini->variable( 'GeneralSettings', 'NameAttributeNumber' );
    $imageAttributeNumber = (int) $ini->variable( 'GeneralSettings', 'ImageAttributeNumber' );

    if ( $imageContentClassID == 0 )  $imageContentClassID = 5;
    if ( $nameAttributeNumber == 0 )  $nameAttributeNumber = 1;
    if ( $imageAttributeNumber == 0 ) $imageAttributeNumber = 3;

    $nameAttributeIndex = $nameAttributeNumber - 1;
    $imageAttributeIndex = $imageAttributeNumber - 1;

    $mimeObj = new eZMimeType();
    // $mime = $mimeObj->mimeTypeFor( false, $imageFile );
    $mime = $mimeObj->mimeTypeFor( false, $imagename );
    $mimeArray = explode( '/', $mime );

    if ( $mimeArray[0] != 'image' )
        return;

    $db =& eZDB::instance();
    $db->setIsSQLOutputEnabled( false );
    $class =& eZContentClass::fetch( $imageContentClassID );

    unset( $contentObject );

    // try to extract the priority from the filename
    preg_match( "/^(\d+)[\s-]*([^\s-].+)\..+$/i", $imagename, $matches );
    $priority = (int) $matches[1];
    $imageName = $matches[2];

    // if the extraction of the priority fails, get the filename (w/o extension) as imagename)
    if ( $imageName == "" )
    {
        preg_match( "/^(.+?)\..+?$/i", $imagename, $matches );
        $imageName = $matches[1];
    }

    $imageDescription = $imageName;
    $imageCreatedTime = filemtime( $imageFile );
    $imageFileName = $imagename;
    $imageOriginalFileName = $imagename;
    $imageCaption = $imageName;

    // set remoteID
    $remoteID = "image_" . $imageName;

    $userID = eZUser::currentUserID();

    if ( $userID != null )
    {
        $object = $parent->object();

        // Create object by user id in the section of the parent object
        $contentObject =& $class->instantiate( $userID, $object->attribute( 'section_id' ) );
        $contentObject->setAttribute('remote_id', $remoteID );
        $contentObject->setAttribute( 'name', $imageName );

        $nodeAssignment =& eZNodeAssignment::create( array(
                                                         'contentobject_id' => $contentObject->attribute( 'id' ),
                                                         'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                         'parent_node' => $parent->attribute( 'node_id' ),
                                                         'sort_field' => 2,
                                                         'sort_order' => 0,
                                                         'is_main' => 1
                                                         )
                                                     );
        $nodeAssignment->store();

        $version =& $contentObject->version( 1 );

        $contentObjectID = $contentObject->attribute( 'id' );
        $contentObjectAttributes =& $version->contentObjectAttributes();

        $contentObjectAttributes[$nameAttributeIndex]->setAttribute( 'data_text', $imageName );
        $contentObjectAttributes[$nameAttributeIndex]->store();

        $contentObjectAttribute =& $contentObjectAttributes[$imageAttributeIndex];

        $imagefile = saveImage( $imageFile, $imagename, $imageCaption, $contentObjectAttribute );
        $contentObjectAttributes[$imageAttributeIndex]->store();

        $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                     'version' => 1 ) );
        // set the priority of the node
        $assignedNodes = $contentObject->assignedNodes();
        $assignedNodes[0]->setAttribute( 'priority', $priority );
        $assignedNodes[0]->store();

        // unlink the eZ 3.2 "original" image
        unlink( $imagefile );
    }
}

function saveImage( $sourceImage, $originalImageFileName, $caption, &$contentObjectAttribute )
{
    include_once( "lib/ezutils/classes/ezdir.php" );
    $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
    $version = $contentObjectAttribute->attribute( "version" );

    include_once( "kernel/classes/datatypes/ezimage/ezimage.php" );
    $image =& eZImage::create( $contentObjectAttributeID , $version );

    $image->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
    $image->setAttribute( "version", $version );


    $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();
    $nameArray = explode( '.', $originalImageFileName );
    $ext = $nameArray[ count($nameArray ) - 1 ];
    $uniqueName = tempnam( $storage_dir . "/original/image/", "imp");
    unlink( $uniqueName );
    $uniqueName .= '.'.$ext;
    $separator = ( substr( php_uname(), 0, 7 ) == "Windows" ) ? '\\' : '/';
    $uniqueNameArray = explode( $separator, $uniqueName );
    $uniqueNameFile = $uniqueNameArray[ count( $uniqueNameArray ) - 1 ];
    $image->setAttribute( "filename", $uniqueNameFile );
    $image->setAttribute( "original_filename", $originalImageFileName );

    $mimeObj = new eZMimeType();
    $mime = $mimeObj->mimeTypeFor( false, $originalImageFileName );
    $image->setAttribute( "mime_type", $mime );
    $image->setAttribute( "alternative_text", $caption );
    $image->store();

    $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();

    $ori_dir = $storage_dir . '/' . "original/image";
    if ( !file_exists( $ori_dir ) )
    {
        eZDir::mkdir( $ori_dir, 0777, true);
    }

    $source_file = $sourceImage;
    $target_file = $storage_dir . "/original/image/" . $uniqueNameFile;
    copy($source_file, $target_file );

    return $target_file;
}

?>