<?php
//////////////////////////////////////////////////////////////////////////////
//
// $RCSfile: select.php,v $
//
// This file is part of the tv-buddy project.
// by Patrizio Bekerle (patrizio@bekerle.com)
// www.bekerle.com
//
//////////////////////////////////////////////////////////////////////////////
//
// $Author: omega $ (this revision)
// $Revision: 1.1.1.1 $
// $Date: 2004/04/07 07:29:10 $ (UTC)
// $Name:  $ (tag name used to check out this file)
//
//////////////////////////////////////////////////////////////////////////////
//
// Description:
//
// You will select the object where you want to upload the files here
//
//////////////////////////////////////////////////////////////////////////////


include_once( "kernel/classes/ezcontentbrowse.php" );
$Module =& $Params["Module"];

eZContentBrowse::browse( array( 'action_name' => 'AssignFileUploadFolder',
                                'description_template' => 'design:multiplefileupload/browse_placement.tpl', 
                                'from_page' => '/multiplefileupload/upload' ),
                         $Module );
return;

?>