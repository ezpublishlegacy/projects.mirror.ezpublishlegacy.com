<!DOCTYPE TS><TS>
<context>
    <name>extension/multiplefileupload</name>
    <message>
        <source>File Upload</source>
        <translation>Dateiupload</translation>
    </message>
    <message>
        <source>Parent folder</source>
        <translation>Aufwärts</translation>
    </message>
    <message>
        <source>Home folder</source>
        <translation>Eigene Dateien</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation>Detailiert</translation>
    </message>
    <message>
        <source>Thumbnails</source>
        <translation>Thumbnails</translation>
    </message>
    <message>
        <source>Open dialog to add files</source>
        <translation>&apos;Datei öffnen&apos; Dialog</translation>
    </message>
    <message>
        <source>Remove file from filequeue</source>
        <translation>Datei deselektieren</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Hochladen</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Ordner</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Aktionen</translation>
    </message>
    <message>
        <source>Multiple File Upload</source>
        <translation>Mehrfach Dateiupload</translation>
    </message>
    <message>
        <source>Please choose the location where you want to place the uploaded files.</source>
        <translation>Bitte wählen Sie aus wo sie die Dateien speichern möchten.</translation>
    </message>
    <message>
        <source>Please select the files you want to upload to &apos;%1&apos; (doubleclick them).</source>
        <translation>Bitte wählen Sie die Dateien aus, die sie nach &apos;%1&apos; laden wollen (einfach die Dateien doppelklicken).</translation>
    </message>
    <message>
        <source>Only images will work at the moment.</source>
        <translation>Im Augenblick werden nur Bilder unterstützt.</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>The module will use the first characters of the filenames as node priority if they are numbers. You can separate the priority and the imagename with whitespaces and hyphens if you want. You can use a bulkrename tool to do this.</source>
        <translation>Wenn die ersten Zeichen eines Dateinamens Zahlen sind, benutzt dieses Modul diese Zahlen als Knotenpriorität. Sie können Priorität und Name mit Leerzeichen und Bindestrichen trennen. Am besten verwenden Sie dazu ein &quot;Bulkrename&quot; Tool.</translation>
    </message>
    <message>
        <source>Example: &apos;003 - my little image.gif&apos; will have priority 3 and the imagename will be &apos;my little image&apos;</source>
        <translation type="unfinished">Beispiel: &apos;003 - mein kleines bild.gif&apos; bekommt die Priorität 3 und der Name wird &apos;mein kleines bild&apos; sein.</translation>
    </message>
    <message>
        <source>After selecting all files press &apos;Upload&apos; on the bottom of the page.</source>
        <translation>Am Schluss einfach am unteren Ende der Seite auf &apos;Hochladen&apos; klicken.</translation>
    </message>
    <message>
        <source>Upload to &apos;%1&apos;</source>
        <translation>Upload nach &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Processed file</source>
        <translation>Verarbeitete Datei</translation>
    </message>
</context>
</TS>
