<?php
//////////////////////////////////////////////////////////////////////////////
//
// $RCSfile: upload.php,v $
//
// This file is part of the tv-buddy project.
// by Patrizio Bekerle (patrizio@bekerle.com)
// www.bekerle.com
//
//////////////////////////////////////////////////////////////////////////////
//
// $Author: omega $ (this revision)
// $Revision: 1.4 $
// $Date: 2005/04/21 09:36:13 $ (UTC)
// $Name:  $ (tag name used to check out this file)
//
//////////////////////////////////////////////////////////////////////////////
//
// Description:
//
// You will select the file you want to upload here
//
// (only images will work at the moment)
//
// I use slightly modified and fixed code from Sergiy Pushchin's
// "Image batch uploadscript from local harddrive" script to save the images.
//
//////////////////////////////////////////////////////////////////////////////


include_once( "lib/ezutils/classes/ezini.php" );
include_once( "kernel/common/template.php" );
include_once( "kernel/classes/ezcontentbrowse.php" );


$Module =& $Params["Module"];

$selectedNodeIDArray = eZContentBrowse::result( 'AssignFileUploadFolder' );
$selectedNodeID = $selectedNodeIDArray[0];

if ( !$selectedNodeID )
{
     $Module->redirectToView( "select" );
     return;
}

preg_match( "/^(.*)\/multiplefileupload\//i", "http://".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"], $matches );
$url = $matches[1];

$uploadurl = "$url/layout/set/multiplefileupload/multiplefileupload/upload_process/$selectedNodeID";

$tpl =& templateInit();
$tpl->setVariable( 'uploadurl', $uploadurl );
$tpl->setVariable( 'cookies', $_COOKIE );
$tpl->setVariable( 'host_name', $_SERVER["HTTP_HOST"] );
$tpl->setVariable( 'selectednodeid', $selectedNodeID );

$selectedNode =& eZContentObjectTreeNode::fetch( $selectedNodeID );
$tpl->setVariable( 'selectednodename', $selectedNode->getName() );

$ini =& eZINI::instance( 'multiplefileupload.ini' );
$useFirefoxTemplate = $ini->variable( 'GeneralSettings', 'UseFirefoxTemplate' ) == "true";

$Result = array();
$Result['content'] =& $tpl->fetch( "design:multiplefileupload/".( $useFirefoxTemplate ? "upload_firefox.tpl" : "upload.tpl" ) );
$Result['path'] = array( array( 'url' => '/multiplefileupload/upload',
                                'text' => ezi18n( 'extension/multiplefileupload', 'File Upload' ) ) );

?>