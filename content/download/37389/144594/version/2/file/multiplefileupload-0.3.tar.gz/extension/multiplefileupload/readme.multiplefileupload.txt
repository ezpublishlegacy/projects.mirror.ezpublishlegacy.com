MultiFileUpload Extension 0.3
-----------------------------

2004/2005 by Patrizio Bekerle (patrizio@bekerle.com)
http://www.bekerle.com

With this eZPublish (3.3+) extension you can upload multiple files
(only images at the moment) to a content object.

This is a true eZPublish 3 extension, which doesn't affect the eZPublish kernel/core,
so you don't have to fear the next core update.


I use slightly modified and fixed code from Sergiy Pushchin's
"Image batch uploadscript from local harddrive" script to save the images.

To upload the files I use the JUpload Java Applet (http://jupload.biz/),
which is free for privat usage. Please visit their webpage for commercial version prices.
It provides multiple file selection and an image preview.

You will find some screenshots here:
http://www.bekerle.com/article/articleview/19/1/2/

The module will use the first characters of the filenames as node priority if they are numbers.
You can separate the priority and the imagename with whitespaces and hyphens if you want. You can use a bulkrename tool to do this.
Example: "003 - my little image.gif" will have priority 3 and the imagename will be "my little image"


Languages
---------

English and a German translation are included at the moment.


Installation
------------

Just copy my extension to your extension folder.
Don't forget to check "multiplefileupload" in Setup/Extension on the eZP admin page.


You will need
-------------

+ A java enabled webbrowser


Usage
-----

Just browse to
http://<yourez3webpage>/<yoursitepath>/multiplefileupload/select
or
http://<yourez3webpage>/multiplefileupload/select
if you use the virtual host setting.
Then follow the instructions ;-)


History
-------

# 0.1
- initial release

# 0.2
- BugFix: Fixed a problem with the browserCookie java parameter
- BugFix: Added "ezroot" to the java applets

# 0.2.1
- The images are not draft after upload, they are published now.
  Any complains about this change?

# 0.2.2
- Now I set the section id of the parent object for the uploaded files.

# 0.2.3
- Added a small bugfix for multiwebpage eZPublish distributions
- The upload page in the upload applet has its own pagelayout.tpl now
- The module will use the first characters of the filenames as node priority if they are numbers now

# 0.2.4
- The eZ 3.2 legacy files will be cleared automatically after upload, 
  so the will not lay around when you delete your images in ez3.3
  (Do not use this version if you have eZ 3.2!)

# 0.2.5
- Added a small fix for eZPublish 3.4

# 0.2.6
- Fixed the "related object" problem

# 0.2.7
- Added fixes for eZPublish 3.5.1
- By public demand the "Caption" field will not be set any more

# 0.2.8
- Added an INI file multiplefileupload.ini, so you can set you image class id and the
  number of the "name" and "image" attributes (if you changed your image class)
- Updated the the JUpload applet to the latest version
- Added a new template f�r the upload page which uses no JS (didn't work in Firefox).
  This template will be used by default now, if you liked the old one you can set
  UseFirefoxTemplate=false in you multiplefileupload.ini.append

# 0.2.9
- Fixed some "strange behaviour" of eZP with $Module->redirectTo(...)
- Added the GNU license file ;-)

# 0.3
- Fix for upload problems with windows servers
