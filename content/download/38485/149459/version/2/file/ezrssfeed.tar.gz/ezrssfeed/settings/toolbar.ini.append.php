<?php /*

[Tool]
AvailableToolArray[]=rssfeed

[Tool_rssfeed]
rsstitle=My feed
rsschannel_check=yes
rssurl=
rssitems=4
rssimage_check=yes
rssdesclength=80
rssexpiry=300


[Tool_rssfeed_description]
rsstitle=Title
rsschannel_check=Show channel name in title (disable to show your Title)
rssurl=URL to RSS feed
rssitems=Number of items to show (0 to show all)
rssimage_check=Show channel image
rssdesclength=Number of chars of description to show (0 to show all)
rssexpiry=Number of seconds before reload of feed-data

*/ ?>