<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezrssfeed

*/ ?>