<?php /*

[ExtensionSettings]
DesignExtensions[]=ezrssfeed

*/ ?>