<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezrssfeed/autoloads/ezrssfeedoperator.php',
                                    'class' => 'eZRSSFeedOperator',
                                    'operator_names' => array( 'ezrssfeed' ) );
?>