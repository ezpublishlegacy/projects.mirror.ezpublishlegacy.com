<?php /* #?ini charset="iso-8859-1"?

[full_playlist]
Source=node/view/full.tpl
MatchFile=full/playlist.tpl
Subdir=templates
Match[class_identifier]=playlist

*/
?>