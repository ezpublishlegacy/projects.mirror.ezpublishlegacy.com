<?php

/*! \file eztemplateautoload.php
*/

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/createplaylist/autoloads/createplaylist.php',
                                    'class' => 'PlaylistOperator',
                                    'operator_names' => array( 'playlistgenerator' ) );
?>
