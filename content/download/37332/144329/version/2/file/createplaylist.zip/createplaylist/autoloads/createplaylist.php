<?php

include_once( "lib/ezdb/classes/ezdb.php" ); //(muss glaub ich gar nicht sein)

class PlaylistOperator
{
	/*!
	Konstruktor hat standardm��ig keine Aufgabe.
	*/
	function PlaylistOperator()
	{
	}

	/*!   
	return an array with the template operator name.
	*/
	function operatorList()
	{
		return array( 'playlistgenerator' );
	}
	/*!
	\return true to tell the template engine that the parameter list exists per operator type,
	this is needed for operator classes that have multiple operators.
	*/
	function namedParameterPerOperator()
	{
		return true;
	}
	/*!
	See eZTemplateOperator::namedParameterList
	*/
	function namedParameterList()
	{
		return array( 'playlistgenerator' =>
			array(
					'song_array'	=>	array(
						'type' => 'array',
						'required' => true,
						'default' => '0' 
					),
					'node_id'	=>	array(
						'type' => 'integer',
						'required' => true,
						'default' => '0'
					)
			)
		);
	}
	/*!
	F�hrt die PHP Funktion f�r die Operator S�uberung aus und modifiziert \a $operatorValue.
	*/
	function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
	{	
		$song_array = $namedParameters['song_array'];
		$node_id = $namedParameters['node_id'];
		
		$xml = '';
		$xml .= '<?xml version="1.0" encoding="iso-8859-15"?>
				 <songs>
				 ';
		foreach ( $song_array as $song )
		{
			$xml .= '<song path="'.$song[0].'" artist="'.$song[1].'" title="'.$song[1].'"/>
			';  
		}
		$xml .= "</songs>";	   
				
				
	    eZFile::create( "pl_$node_id.xml", 'var/playlist', $xml );

		$operatorValue = "var/playlist/pl_$node_id.xml";
		
	}
}

?>