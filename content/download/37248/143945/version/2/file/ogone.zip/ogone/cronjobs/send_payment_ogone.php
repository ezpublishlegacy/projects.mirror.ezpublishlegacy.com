<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Nicolas BASTIAN <nicolas.bastian@internethic.com> Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/		
				
				
/*

CREATE TABLE `ogone_order` (
  `id` int(11) NOT NULL auto_increment,
  `date_subscription` varchar(24) collate utf8_unicode_ci NOT NULL,
  `date_dernier_paiement` int(11) default NULL,
  `nb_paiement_restant` int(11) default NULL,
  `nb_paiement_total` int(11) NOT NULL,
  `montant_total` float NOT NULL,
  `email_abonne` varchar(16) collate utf8_unicode_ci default NULL,
  `pay_id` text NOT NULL,
  `alias` text NOT NULL,
  `order_id` int(11) NOT NULL,
  `card_no` text NOT NULL,
  `card_ed` text NOT NULL,
  `date_prochain_paiement` int(11) NOT NULL,
  `status` text NOT NULL,
  `message` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;


*/


				
				

include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'kernel/classes/ezorder.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

		print( "Debut cronjob ogone \n" );
		
		
		$today = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) );
		//on fixe une limite de 4 transations a la minute
		$db =& eZDB::instance();
		$db->begin();
		$res = $db->arrayQuery("SELECT * FROM ogone_order WHERE status = 'attend_jour_paiement' and date_prochain_paiement = '".$today."'" );
		$count=count( $res );
		$db->commit();


		if ($count > 4)
		{
		$countdiv=$count / 4;
			for ($i=0;$i<=$countdiv;$i++)
			{
			transaction();
			print ("Procedure de temporistaion (60ms)\n");
			sleep(60); //on attend 1 minutes avant de relancer 4 transaction
			}
		}
		else
		{
		transaction();		
		}
		
	function transaction()
	{
		print ("Lancement de la charge des transactions\n");
		$ogoneINI =& eZINI::instance( 'ogone.ini' );
		$url = $ogoneINI->variable( 'OGONE', 'DirectLink' );
		$pspid=$ogoneINI->variable( 'OGONE', 'PSPID' );
		$passphrase=$ogoneINI->variable( 'OGONE', 'PassPhrase' );
		$userid=$ogoneINI->variable( 'OGONE', 'UserID' );
		$pswd=$ogoneINI->variable( 'OGONE', 'PassUser' );
		$currency=$ogoneINI->variable( 'OGONE', 'Currency' );
		
		$db =& eZDB::instance();
		$db->begin();
				
	 // on limit a 4 
		$today = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) );
		$res = $db->arrayQuery("SELECT * FROM ogone_order WHERE status = 'attend_jour_paiement' and date_prochain_paiement = '".$today."' LIMIT 0,4" );
		$db->commit();
		$nb_part=0;
		
		if( count( $res ) > 0 )
		{
		$i=0;
		foreach( $res as $result )
			{
			  print ( 'Etape foreach\n' );
				$montant=$result['montant_total'];
				$montant1=$montant/12;
				$montant1=round($montant1,2);
				$amount=$montant1*100;
				
				$cardno=$result['card_no'];
				$ed=$result['card_ed'];
				$alias=$result['alias'];
				$order_id=$result['order_id'];
				$email_abonne = $result['email_abonne'];
				$pay_id = $result['pay_id'];
				$card_no = $result['card_no'];
			  $card_ed = $result['card_ed'];
				$date_subscription =	$result['date_subscription'];
				$nb_paiement_restant=$result['nb_paiement_restant'];
		
				//$card_no="4111111111111111";
		
				$shasign = strtoupper( bin2hex( mhash( MHASH_SHA1, $pay_id.$amount.$currency.$card_no.$pspid.$alias.$passphrase ) ) );
				$finaleUrl = $url.'?PSPID='.$pspid.'&USERID='.$userid.'&PSWD='.$pswd.'&orderID='.$pay_id.'&amount='.$amount.'&currency='.$currency.'&CARDNO='.$card_no.'&ED='.$card_ed.'&ALIAS='.$alias.'&SHASign='.$shasign;

				$userAgent = 'eZ Publish ' . "\r\n" .'Cookie: ' . $mySessionVar;
				//on envoi la requete directLink et on recupere sa reponse
		    $result_http= eZHTTPTool::sendHTTPRequest( $finaleUrl , 443, array(), 'eZ publish', false );
				
				//on lis la reponse XML de la banque
				$xml =& new eZXML();
				$domTree =& $xml->domTree( $result_http );
				$ncResponse =& $domTree->elementsByName( 'ncresponse' );
				$ncResponse = $ncResponse[0];
				$brand_xml = $ncResponse->attributeValue( 'BRAND' );
				$alias_xml = $ncResponse->attributeValue( 'ALIAS' );
				$pm_xml = $ncResponse->attributeValue( 'PM' );
				$currency_xml = $ncResponse->attributeValue( 'currency' );
				$amount_xml = $ncResponse->attributeValue( 'amount' );
				$status_xml = $ncResponse->attributeValue( 'STATUS' );
				$acceptance_xml = $ncResponse->attributeValue( 'ACCEPTANCE' );
				$ncerrorplus_xml = $ncResponse->attributeValue( 'NCERRORPLUS' );
				$ncerror_xml = $ncResponse->attributeValue( 'NCERROR' );
				$ncstatus_xml = $ncResponse->attributeValue( 'NCSTATUS' );
				$paysid_xml = $ncResponse->attributeValue( 'PAYID' );
				$orderid_xml = $ncResponse->attributeValue( 'orderID' );
	
				
				//$db->begin();
				if( $ncerror_xml == '0' && $ncstatus_xml == '0' )
				{
					//on enleve 1mois de paiement a payer
					$nb_paiement_restant--;
					//il ne reste plus de paiement donc labonnement a �t� pay�
					if ($nb_paiement_restant<=0){
						$status="PAIEMENT_COMPLETED";
						//on update le status de la commande en attente en cmd pay�
						$result = $db->query("UPDATE ogone_order SET status='".$status."' WHERE alias='".$alias."' and status='attend_jour_paiement' ");
						$db->commit();
						print ( "Paiement complet -> UPDATE\n" );
					}
					else
					{
					  $status="paiement_effectue";
					  //on rajoute 31 jour a la date courante pour la prochaine date de paiement
						$date_prochain_paiement = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) )+(31 * 3600 * 24);  //::::::::::::modif
											
						$sql = "INSERT INTO ogone_order (pay_id, order_id, montant_total, email_abonne, alias";
						$sql .= ", date_prochain_paiement, card_no, card_ed, date_subscription,nb_paiement_total,nb_paiement_restant,status) ";
						$sql .= " VALUE ( '".$pay_id."', '".$order_id."', '".$montant."', '".$email_abonne."', '".$alias."', ";
						$sql .= "'".$date_prochain_paiement."', '".$card_no."', '".$card_ed."', '".$date_subscription."', '11', '".$nb_paiement_restant."', 'attend_jour_paiement' )";
											
						
						$db->query( $sql );
						$db->commit();
						
						print ( "Paiement effectu� -> SQL INSERT\n" );
						
						//on update le status de la commande en attente en cmd pay�
						$result = $db->query("UPDATE ogone_order SET status='".$status."' WHERE alias='".$alias."' and status='attend_jour_paiement' ");
						$db->commit();
						print ( "Paiement effectu� -> SQL UPDATE\n" );
					}
					print ( "Fin de procedure de validation du paiement\n" );
				}else
				{


											$msg='paiement_refuse';
											//on update le status de la commande en attente en cmd impay� avec erreur
											$result = $db->query("UPDATE ogone_order SET status='$msg', message='$ncerrorplus_xml' WHERE alias='$alias' and status='attend_jour_paiement' ");
											$db->commit();
											//on rajoute 1 jour a la date courante pour la prochaine date de paiement car le serveur bancaire na pa reussi la transaction
											$date_prochain_paiement = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) )+(1 * 3600 * 24);
											$sql = "INSERT INTO ogone_order (pay_id, order_id, montant_total, email_abonne, alias";
											$sql .= ", date_prochain_paiement, card_no, card_ed, date_subscription,nb_paiement_total,nb_paiement_restant,status) ";
											$sql .= " VALUE ( '".$pay_id."', '".$order_id."', '".$montant."', '".$email_abonne."', '".$alias."', ";
											$sql .= "'".$date_prochain_paiement."', '".$card_no."', '".$card_ed."', '".$date_subscription."', '11', '11', 'attend_jour_paiement' )";
											
											$db->query( $sql );
											$db->commit();
											//on previent l'administrateur
											//mail ('dev@internethic.com','[Auralog] Echec de paiement Ogone','Order id:'.$order_id.'<br>'.'Id :'.mysql_insert_id());
											print ( "Paiement refus� -> SQL INSERT + UPDATE\n" );
				}
				print ( "Procedure de temporisation (20ms)\n" );
				sleep(20);
				
				//$db->commit();
				
			}
			print ( "Fin!\n" );
		}
	}

	print( "Fin cronjob \n" );
		

?>
