<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice PEREZ <fp@internethic.com>
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');
include_once( 'lib/ezutils/classes/ezini.php' );
class ogoneChecker extends eZPaymentCallbackChecker
{

	function ogoneChecker ( $iniFile )
	{
		$this->eZPaymentCallbackChecker( $iniFile );
		$this->logger =& eZPaymentLogger::CreateForAdd( 'var/log/ogoneChecker.log' );
		$this->logger->writeTimedString( "Creation " );
	}


	function createDataFromPOST( )
	{
		$this->callbackData = array();
		
		foreach( $_POST as $key=>$value ){
			$this->callbackData[$key] = $value;
		}

		return ( count( $this->callbackData ) > 0 );
	}
	function checkPaymentStatus()
	{
		if ( $this->callbackData['NCERROR'] == 0 && isset( $this->callbackData[orderID] ) && $this->callbackData['STATUS']=="9")
		{
			$this->logger->writeTimedString("checkPaymentStatus true");
			$return = true;
		} else {
			$this->logger->writeTimedString("checkPaymentStatus failed");
			$return = false;
		}
		return $return;
	}
	
	

	function setupOrderAndPaymentObject( $orderID )
	{
		if (isset( $orderID ) && $orderID > 0 )
		{
			/********************************************************************************/
			$this->paymentObject =& eZPaymentObject::fetchByOrderID( $orderID );
			/********************************************************************************/

			if ( isset( $this->paymentObject ) )
			{
				$this->logger->writeTimedString("ISSET ".isset( $this->paymentObject ) );
				$this->order = eZOrder::fetch( $orderID );
				if ( isset( $this->order ) )
				{
					return true;
				}
				return false;
			}
			return false;
		}
		return false;
	}

	function getFieldValue( $field )
	{
		if ( isset( $this->callbackData[$field] ) )
		{
			return $this->callbackData[$field];
		}
		return null;
	}

	function approvePayment( $continueWorkflow=true )
	{
		if ( $this->paymentObject )
		{
			$this->logger->writeTimedString("approvePayment");
			$this->paymentObject->approve();
			$this->paymentObject->store();

			return ( $continueWorkflow ? $this->continueWorkflow() : null );
		}
		return null;
	}

	function continueWorkflow()
	{
		if ( $this->paymentObject )
		{
			$workflowID = $this->paymentObject->attribute( 'workflowprocess_id' );
			if ( $workflowID )
			{
				$return = eZPaymentObject::continueWorkflow( $workflowID );
				return $return;
			}
			return null;
		}
		return null;
	}

	function checkAmount( $amount )
	{

		$amount = $amount * 100;
		$orderAmount = $this->order->attribute( 'total_inc_vat' );
		$orderAmount = $orderAmount;

		
		if ( (int)$orderAmount == (int)$amount )
		{
			$this->logger->writeTimedString(" Amount is ok" );
			return true;
		}
		if( (int)$orderAmount - (int)$amount <= 0.01 ){
			$this->logger->writeTimedString( "Order id=".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).", 'checkamount failed');
			$message = "Order id= ".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).";
			mail('nospam@ez.no', 'OGONE Probleme paiement', $message);
			return false;
		}
		$this->logger->writeTimedString( "Order id=".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).", 'checkamount failed');
		return false;
	}

	function checkCurrency( $currency )
	{
		include_once( 'lib/ezlocale/classes/ezlocale.php' );
		$locale =& eZLocale::instance();
		$orderCurrency = $locale->currencyShortName();
		
		if ( $orderCurrency == $currency )
		{
			return true;
		}
		$this->logger->writeTimedString( "Order currency ($orderCurrency) and received currency ($currency).", 'checkcurrency failed');
		return false;
	}
}

?>
