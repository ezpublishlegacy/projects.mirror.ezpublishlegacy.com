<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Nicolas BASTIAN <nicolas.bastian@internethic.com> 
# Fabrice PEREZ <fp@internethic.com>
# Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezpaymentgateway.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'kernel/classes/ezorder.php' );

//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_OGONE", "ogone" );
define( "EZ_GATEWAY_OBJECT_NOT_CREATED", 1 );
define( "EZ_GATEWAY_OBJECT_CREATED", 2 );

class ogoneGateway extends eZPaymentGateway
{
    /*!
        Constructor.
    */
    function ogoneGateway()
    {
        //__DEBUG__
            $this->logger   = eZPaymentLogger::CreateForAdd( "var/log/ogoneGateway.log" );
            $this->logger->writeTimedString( 'ogoneGateway::ogoneGateway()' );
        //___end____
    }

    /*!
        Creates new sogenactifGateway object.
    */
    function &createPaymentObject( &$processID, &$orderID )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createPaymentObject");
        //___end____

        return eZPaymentObject::createNew( $processID, $orderID, 'Sogenactif' );
    }

    function generateRequestForm( $orderID )
    {
    	$order =& eZOrder::fetch( $orderID );
    	
    	$ogoneIni =& eZINI::instance( 'ogone.ini' );
    	$siteIni =& eZINI::instance( 'site.ini' );

    	$siteUrl = 'http://'.$siteIni->variable( 'SiteSettings', 'SiteURL' );
    	$formAction = $ogoneIni->variable( 'OGONE', 'Url' );
    	$PSPID = $ogoneIni->variable( 'OGONE', 'PSPID' );
    	$passPhrase = $ogoneIni->variable( 'OGONE', 'PassPhrase' );
    	$amount = $order->totalIncVAT();
    	
    	include_once( 'lib/ezlocale/classes/ezlocale.php' );
		$locale =& eZLocale::instance();
		$orderCurrency = $locale->currencyShortName();
		
		$language = $siteIni->variable( 'RegionalSettings', 'ContentObjectLocale' );
		/* Nous avons la langue sur 6 caracteres => fre-FR
		Ogone n'accepte que sur 5 caracteres => fr_FR
		*/

		$language = substr( $language, 0, 2 ).'_'.substr( $language, 4, 2 );
		
		$user =& $order->user();
		$userEmail = $user->attribute( 'email' );
		$userObject = $user->contentObject();
		$userDataMap =& $userObject->dataMap();
		
		$customerName = $userDataMap['first_name']->content().' '.$userDataMap['last_name']->content();
    	
    	$customeZip = $userDataMap['zip_code']->content();
    	$customerAddress = $userDataMap['address']->content();
    	$customerCountry = $userDataMap['country']->content();

    	foreach( $customerCountry['value'] as $country ){
    		$customerCountry = $country['Name'];
    	}
    	
    	$customerTown = $userDataMap['city']->content();
    	$customerPhone = $userDataMap['phone']->content();
    	
    	
    	
		$form = "<!-- general parameters --> \n";
		$form .= "<input type=\"hidden\" name=\"PSPID\" value=\"$PSPID\"> \n";
		$form .= "<input type=\"hidden\" name=\"orderID\" value=\"$orderID\"> \n";
		$form .= "<input type=\"hidden\" name=\"currency\" value=\"$orderCurrency\"> \n";
		$form .= "<input type=\"hidden\" name=\"language\" value=\"$language\"> \n";
		$form .= "<input type=\"hidden\" name=\"CN\" value=\"$customerName\"> \n";
		$form .= "<input type=\"hidden\" name=\"EMAIL\" value=\"$userEmail\"> \n";
		$form .= "<input type=\"hidden\" name=\"ownerZIP\" value=\"$customeZip\"> \n";
		$form .= "<input type=\"hidden\" name=\"owneraddress\" value=\"$customerAddress\"> \n";
		$form .= "<input type=\"hidden\" name=\"ownercty\" value=\"$customerCountry\"> \n";
		$form .= "<input type=\"hidden\" name=\"ownertown\" value=\"$customerTown\"> \n";
		$form .= "<input type=\"hidden\" name=\"ownertelno\" value=\"$customerPhone\"> \n";


		$acceptUrl = $siteUrl."/shop/checkout";
		$cancelUrl = $siteUrl."/shop/basket";
		$exceptionUrl = $siteUrl.'/ogone/exception';
		$form .= "<!-- post payment redirection: see chapter 7 --> \n";
		$form .= "<input type=\"hidden\" name=\"accepturl\" value=\"$acceptUrl\"> \n";
		$form .= "<input type=\"hidden\" name=\"declineurl\" value=\"$cancelUrl\"> \n";
		$form .= "<input type=\"hidden\" name=\"exceptionurl\" value=\"$exceptionUrl\"> \n";
		$form .= "<input type=\"hidden\" name=\"cancelurl\" value=\"$cancelUrl\"> \n";
		$AliasUsage=$ogoneIni->variable( 'OGONE', 'AliasUsage' );
		$alias=str_replace(".","",str_replace ("@","",$userEmail));
		$formabo = $form . "<input type=\"hidden\" name=\"Alias\" value=\"$alias\"> \n";
		$formabo .= "<input type=\"hidden\" name=\"ALIASUSAGE\" value=\"$AliasUsage\"> \n";

		$amountabo=$amount/12;
		$amountabo = round( $amountabo, 2 );
		$amountabo = $amountabo * 100;
		$amount=$amount*100;
		$form .= "<!-- check before the payment: see chapter 5 --> \n";
		$SHASign = strtoupper( bin2hex( mhash( MHASH_SHA1, $orderID.$amount.$orderCurrency.$PSPID.$passPhrase ) ) );
		$SHASignAbo = strtoupper( bin2hex( mhash( MHASH_SHA1, $orderID.$amountabo.$orderCurrency.$PSPID.$alias.$AliasUsage.$passPhrase ) ) );
		$form .= "<input type=\"hidden\" name=\"SHASign\" value=\"$SHASign\"> \n";
		$formabo .= "<input type=\"hidden\" name=\"SHASign\" value=\"$SHASignAbo\"> \n";			
		
		$form .= "<input type=\"hidden\" name=\"amount\" value=\"$amount\"> \n";
		$formabo .= "<input type=\"hidden\" name=\"amount\" value=\"$amountabo\"> \n";
		$formabo .= "<input type=\"hidden\" name=\"ECI\" value=\"9\"> \n";
		return array( 'form' => $form, 'formAction' => $formAction,'formabo' => $formabo );

    }
    
    
    function execute ( &$process, &$event )
    {

			$processParameters =& $process->attribute( 'parameter_list' );
			$processID = $process->attribute( 'id' );
	
			switch( $process->attribute( 'event_state') )
			{
				case EZ_GATEWAY_OBJECT_CREATED:
				{
		        //__DEBUG__
		            $this->logger->writeTimedString( 'sogenactifGateway::EZ_GATEWAY_OBJECT_CREATED' );
		        //___end____
	
					$thePayment = eZPaymentObject::fetchByProcessID( $processID );
					/******************************************************************/
	
	
					if (is_object( $thePayment ) && $thePayment->approved() )
					{
						$this->logger->writeTimedString( 'Workflow accepte, on passe EZ_WORKFLOW_TYPE_STATUS_ACCEPTED' );
						return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
					}
					else
					{
					}
					return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
				}
				break;
				case EZ_GATEWAY_OBJECT_NOT_CREATED:
		        //__DEBUG__
		            $this->logger->writeTimedString( 'sogenactifGateway::EZ_GATEWAY_OBJECT_NOT_CREATED' );
		        //___end____
				default:
				{
					$orderID = $processParameters['order_id'];
					$paymentObject =& $this->createPaymentObject( $processID, $orderID );
	
					if (is_object( $paymentObject ))
					{
						$paymentObject->store();
						$process->setAttribute( 'event_state', EZ_GATEWAY_OBJECT_CREATED );
						$returnArray = $this->generateRequestForm( $orderID );
						
						$form = $returnArray['form'];
						$formabo = $returnArray['formabo'];
						$formAction = $returnArray['formAction'];
						
						$process->Template = array();
						$process->Template['templateName'] = 'design:ogone_request.tpl';
						$process->Template['templateVars'] = array( 'form' => $form,
																												'formabo' => $formabo,
																												'formAction' => $formAction
																											);
					}
					else
					{
						$this->logger->writeTimedString( "Unable to create 'eZPaymentObject'. Payment rejected." );
		        //__DEBUG__
		            $this->logger->writeTimedString( 'ogoneGateway::EZ_WORKFLOW_TYPE_STATUS_REJECTED' );
		        //___end____
						return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
					}
				}
				break;
			};
      //__DEBUG__
          $this->logger->writeTimedString( 'ogoneGateway::EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT' );
      //___end____
			return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
    }


}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_OGONE, "ogonegateway", "ogone" );

?>
