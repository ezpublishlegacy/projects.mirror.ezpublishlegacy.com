<?php
/*
#?ini charset="iso-8859-1"?

[OGONE]

# AREA OF TEST
Url=https://secure.ogone.com/ncol/test/orderstandard.asp
PassPhrase=pass //edit this line with your account PassPhrase
PSPID=pspid //edit this line with your account PSPID
DirectLink=https://secure.ogone.com/ncol/test/orderdirect.asp

#// In order to use Ogone susbcription method
#// make in your Ogone Merchant Administration 
#// on Users Panel a new User and check the box "Special user for API (no access to the admin)" 
#// to enable an user to process the subscription method

UserID= //edit this
PassUser= //edit this

# AREA OF PROD 
#// When you have completed the configuration 
#// decomment informations below and comment URL, PSPID, Passphrase ...behind
#// to move in production
#Url=https://secure.ogone.com/ncol/prod/orderstandard.asp
#PSPID=
#PassPhrase=
#DirectLink=https://secure.ogone.com/ncol/prod/orderdirect.asp
#UserID=
#PassUser=

Currency=EUR
AliasUsage=Abonnement sur 12 mois
MinAmount=950

*/
?>