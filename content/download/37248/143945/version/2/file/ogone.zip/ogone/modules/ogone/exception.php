<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

$data = $_POST["DATA"];
eZDebug::writeDebug($data);
if ($data == "") 
	$data = "Pas de retour";
$tpl->setVariable( 'data', $data ); 
$text =& $tpl->fetch( "design:mercanet/call_response.tpl" );

$Result = array();
$Result['content'] =& $tpl->fetch( "design:mercanet/call_response.tpl" );
$Result['path'] = array( array( 'url' => false,
				'text' => 'Retour paiement' ) );

/*				
if( $checker->createDataFromPOST() )
{
  unset ($_POST);
  if( $checker->requestValidation() && $checker->checkPaymentStatus() )
  {
      $orderID = $checker->getFieldValue( 'custom' );
      if( $checker->setupOrderAndPaymentObject( $orderID ) )
      {
          $amount   = $checker->getFieldValue( 'mc_gross' );
          $currency = $checker->getFieldValue( 'mc_currency' );
          if( $checker->checkAmount( $amount ) && $checker->checkCurrency( $currency ) )
          {
              $checker->approvePayment();
          }
      }
  }
}

$logger->writeTimedString( 'notify_url.php was propertly ended' );
*/
?>
