<?php
/*#?ini charset="iso-8859-1"?
[CronjobSettings]
Scripts[]=send_payment.php

ExtensionDirectories[]=ogone

[CronjobPart-ogone]
Scripts[]=send_payment_ogone.php

*/
?>