<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Nicolas BASTIAN <nicolas.bastian@internethic.com> Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');
include_once( 'lib/ezutils/classes/ezini.php' );
class ogoneChecker extends eZPaymentCallbackChecker
{

	function ogoneChecker ( $iniFile )
	{
		$this->eZPaymentCallbackChecker( $iniFile );
		$this->logger =& eZPaymentLogger::CreateForAdd( 'var/log/ogoneCheckerabo.log' );
		$this->logger->writeTimedString( "Creation " );
	}


	function createDataFromPOST( )
	{
		$this->callbackData = array();
		
		foreach( $_POST as $key=>$value ){
			$this->callbackData[$key] = $value;
		}

		return ( count( $this->callbackData ) > 0 );
	}

	function checkPaymentStatus()
	{
		if ( $this->callbackData['NCERROR'] == 0 && isset( $this->callbackData[orderID] ) && $this->callbackData['STATUS']=="5")
		{
			$this->logger->writeTimedString("checkPaymentStatus true");
			$return = true;
		} else {
			$this->logger->writeTimedString("checkPaymentStatus failed");
			$return = false;
		}
		return $return;
	}
	
	

	function setupOrderAndPaymentObject( $orderID )
	{
		if (isset( $orderID ) && $orderID > 0 )
		{
			/********************************************************************************/
			$this->paymentObject =& eZPaymentObject::fetchByOrderID( $orderID );
			/********************************************************************************/

			if ( isset( $this->paymentObject ) )
			{
				$this->logger->writeTimedString("ISSET ".isset( $this->paymentObject ) );
				$this->order = eZOrder::fetch( $orderID );
				if ( isset( $this->order ) )
				{
					return true;
				}
				return false;
			}
			return false;
		}
		return false;
	}

	function getFieldValue( $field )
	{
		if ( isset( $this->callbackData[$field] ) )
		{
			return $this->callbackData[$field];
		}
		return null;
	}

	function approvePayment( $continueWorkflow=true )
	{
		if ( $this->paymentObject )
		{
			$this->logger->writeTimedString("approvePayment");
			$this->paymentObject->approve();
			$this->paymentObject->store();
			
			
			$order_id = $this->callbackData[orderID];
			$order = eZOrder::fetch( $order_id );
			$email_abonne = $order->attribute( 'email' );
			$montant = $orderAmount = $this->order->attribute( 'total_inc_vat' );
			$pay_id = $this->callbackData[PAYID];
			$card_no = $this->callbackData[CARDNO];
			$card_ed = $this->callbackData[ED];
			$alias = $this->callbackData[ALIAS];
			$date_subscription =	date('ddmmyyyy');
			//on rajoute 31 jour a la date courante pour la prochaine date de paiement
			$date_prochain_paiement = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) )+(31 * 3600 * 24);			

			
			/*la on sais que le paiement a bien �t� approuv� on enregistre donc en base*/
			$db =& eZDB::instance();
			$db->begin();
			
			$sql = "INSERT INTO ogone_order (pay_id, order_id, montant_total, email_abonne, alias";
			$sql .= ", date_prochain_paiement, card_no, card_ed, date_subscription,nb_paiement_total,nb_paiement_restant,status) ";
			$sql .= " VALUE ( '".$pay_id."', '".$order_id."', '".$montant."', '".$email_abonne."', '".$alias."', ";
			$sql .= "'".$date_prochain_paiement."', '".$card_no."', '".$card_ed."', '".$date_subscription."', '11', '11', 'attend_jour_paiement' )";
			$db->query( $sql );
			$db->commit();
			
			return ( $continueWorkflow ? $this->continueWorkflow() : null );
		}
		return null;
	}

	function continueWorkflow()
	{
		if ( $this->paymentObject )
		{
			$workflowID = $this->paymentObject->attribute( 'workflowprocess_id' );
			if ( $workflowID )
			{
				$return = eZPaymentObject::continueWorkflow( $workflowID );
				return $return;
			}
			return null;
		}
		return null;
	}

	function checkAmount( $amount )
	{
		$amount = $amount * 100;
		$orderAmount = $this->order->attribute( 'total_inc_vat' );
		$amountabo=$orderAmount/12;
		$amountabo = round( $amountabo, 2 );
		$orderAmount = $amountabo*100;
		
		if ( (int)$orderAmount == (int)$amount )
		{
			$this->logger->writeTimedString(" Amount is ok" );
			return true;
		}
		if( (int)$orderAmount - (int)$amount <= 0.01 ){
			$this->logger->writeTimedString( "Order id=".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).", 'checkamount failed');
			$message = "Order id= ".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).";
			mail('developpement@internethic.com', 'AURALOG Probleme paiement', $message);
			// !!!!! PAS BIEN !!!!!
			return true;
		}
		$this->logger->writeTimedString( "Order id=".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).", 'checkamount failed');
		return false;
	}

	function checkCurrency( $currency )
	{
		include_once( 'lib/ezlocale/classes/ezlocale.php' );
		$locale =& eZLocale::instance();
		$orderCurrency = $locale->currencyShortName();
		
		if ( $orderCurrency == $currency )
		{
			return true;
		}
		$this->logger->writeTimedString( "Order currency ($orderCurrency) and received currency ($currency).", 'checkcurrency failed');
		return false;
	}
}

?>
