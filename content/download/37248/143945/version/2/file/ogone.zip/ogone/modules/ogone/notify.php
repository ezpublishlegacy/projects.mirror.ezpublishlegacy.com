<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Nicolas BASTIAN <nicolas.bastian@internethic.com> Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

// on verifie si on recoit la confirmation pour un abonnement ou un paiement direct

if (isset($_POST['ALIAS']))
{

// debut de la methode d'abonnement
	ext_activate( 'ogone', 'classes/ogonecheckerabo.php' );
	include_once( 'lib/ezutils/classes/ezini.php' );
	$ogoneIni =& eZINI::instance( 'ogone.ini' );
	
	
	$logger =& eZPaymentLogger::CreateForAdd( 'var/log/ogone_autoresponseabo.log' );
	$checker =& new ogoneChecker( 'ogone.ini' );
	
	$logger->writeTimedString( 'creation de la reponse abo' );
	
	$create = $checker->createDataFromPOST();
	
	$valid = false;
	
	$checker->callbackData['orderID'];
	
	if( $create ){
	
	
		$stringToHash = $checker->callbackData['orderID'] .
										$checker->callbackData['currency'] .
										$checker->callbackData['amount'] .
										$checker->callbackData['PM'] .
										$checker->callbackData['ACCEPTANCE'] .
										$checker->callbackData['STATUS'] .
										$checker->callbackData['CARDNO'] .
										$checker->callbackData['ALIAS'] .
										$checker->callbackData['PAYID'] .
										$checker->callbackData['NCERROR'] .
										$checker->callbackData['BRAND'] .
										$ogoneIni->variable( 'OGONE', 'PassPhrase' );
										
		$logger->writeTimedString( 'string to hash '.$stringToHash );
		$hashDoneByBank = $checker->callbackData['SHASIGN'];
		$logger->writeTimedString( 'key returned '.$hashDoneByBank );
		$logger->writeTimedString( 'key calculee '.strtoupper( bin2hex( mhash( MHASH_SHA1, $stringToHash ) ) ) );
		//mail ('thefrox@gmail.com','key returned',$hashDoneByBank);
		//mail ('thefrox@gmail.com','key calculee',strtoupper( bin2hex( mhash( MHASH_SHA1, $stringToHash))));
			
		if( strtoupper( bin2hex( mhash( MHASH_SHA1, $stringToHash ) ) ) == $hashDoneByBank ){
			$valid = true;
		}
	}
	
	
	if ( $valid )
	{

		unset($_POST);
		$retour = $checker->checkPaymentStatus();
		$logger->writeTimedString( 'retour checkPaymentStatus '.$retour );
		if ( $retour )
		{
			$orderID = $checker->getFieldValue( 'orderID' );
			$logger->writeTimedString( "order_id : $orderID" );

			if ( $checker->setupOrderAndPaymentObject( $orderID ) )
			{
				$amount = $checker->getFieldValue( 'amount' );

				if ( $checker->checkAmount( $amount ) )
				{
					$toto = $checker->approvePayment();

				}
			}
		}
	}
	else {

		$logger->writeTimedString( 'The SHA1 signature isn\'t valid' );
	}
	
	$logger->writeTimedString( 'call_autoresponseabo.php was properly ended' );
	
	include_once( 'kernel/common/template.php' );
	$Module =& $Params["Module"];
	
	$tpl =& templateInit();
	
	
	$Result = array();
	$Result['content'] = $tpl->fetch('design:ogone/response.tpl' );
	$Result['pagelayout'] = false;
	$Result['path'] = array( array( 'url' => '',
	                                'text' => "") );
}else{

// debut de la methode de paiement direct

	ext_activate( 'ogone', 'classes/ogonechecker.php' );
	
	include_once( 'lib/ezutils/classes/ezini.php' );
	$ogoneIni =& eZINI::instance( 'ogone.ini' );
	
	
	$logger =& eZPaymentLogger::CreateForAdd( 'var/log/ogone_autoresponse.log' );
	$checker =& new ogoneChecker( 'ogone.ini' );
	
	$logger->writeTimedString( 'call_autoresponse' );
	
	$create = $checker->createDataFromPOST();
	
	$valid = false;
	
	$checker->callbackData['orderID'];
	
	if( $create ){
	

	
		$stringToHash = $checker->callbackData['orderID'] .
										$checker->callbackData['currency'] .
										$checker->callbackData['amount'] .
										$checker->callbackData['PM'] .
										$checker->callbackData['ACCEPTANCE'] .
										$checker->callbackData['STATUS'] .
										$checker->callbackData['CARDNO'] .
										$checker->callbackData['PAYID'] .
										$checker->callbackData['NCERROR'] .
										$checker->callbackData['BRAND'] .
										$ogoneIni->variable( 'OGONE', 'PassPhrase' );
		$logger->writeTimedString( 'string to hash '.$stringToHash );
		$hashDoneByBank = $checker->callbackData['SHASIGN'];
		$logger->writeTimedString( 'key returned '.$hashDoneByBank );
		$logger->writeTimedString( 'key calculee '.strtoupper( bin2hex( mhash( MHASH_SHA1, $stringToHash ) ) ) );
		
		if( strtoupper( bin2hex( mhash( MHASH_SHA1, $stringToHash ) ) ) == $hashDoneByBank ){
			$valid = true;
		
		}
	}
	
	
	if ( $valid )
	{

		unset($_POST);
		$retour = $checker->checkPaymentStatus();
		$logger->writeTimedString( 'retour checkPaymentStatus '.$retour );
		if ( $retour )
		{
			$orderID = $checker->getFieldValue( 'orderID' );
			$logger->writeTimedString( "order_id : $orderID" );

			if ( $checker->setupOrderAndPaymentObject( $orderID ) )
			{
				$amount = $checker->getFieldValue( 'amount' );

				if ( $checker->checkAmount( $amount ) )
				{
					$toto = $checker->approvePayment();
	
				}
			}
		}
	}
	else {

		$logger->writeTimedString( 'The SHA1 signature isn\'t valid' );
	}
	
	$logger->writeTimedString( 'call_autoresponse.php was properly ended' );
	
	include_once( 'kernel/common/template.php' );
	$Module =& $Params["Module"];
	
	$tpl =& templateInit();
	
	
	$Result = array();
	$Result['content'] = $tpl->fetch('design:ogone/response.tpl' );
	$Result['pagelayout'] = false;
	$Result['path'] = array( array( 'url' => '',
	                                'text' => "") );
}
?>

