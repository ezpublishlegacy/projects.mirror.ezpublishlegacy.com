<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=extendeddate
AvailableDataTypes[]=extendeddate

*/ ?>