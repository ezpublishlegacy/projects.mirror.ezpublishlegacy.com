<?php

/*!
  \class   extendedDateType extendedDateType.php
  \ingroup eZDatatype
  \brief
  \version 1.0
  \date    Lundi 28 Juin 2010 11:10:59
  \author  Pierre martel
*/

class extendedDateType extends eZDataType
{
	const DATA_TYPE_STRING = "extendeddate";
	const CHOOSEN_FIELDS = 'data_text1';
	const CHOOSEN_FIELDS_VARIABLE = "_extendeddate_fields_";
	const SHOW_MONTH_LIST = 'data_int1';
	const SHOW_MONTH_LIST_VARIABLE = "_extendeddate_monthlist_";
	const YEAR_RANGE_MIN = 'data_int2';
	const YEAR_RANGE_MIN_VARIABLE = "_extendeddate_yearmin_";
	const YEAR_RANGE_MAX = 'data_int3';
	const YEAR_RANGE_MAX_VARIABLE = "_extendeddate_yearmax_";

    function extendedDateType()
    {
        $this->eZDataType( self::DATA_TYPE_STRING, "Extended Date" );
    }

    /*!
    Validates all variables given on content class level
     \return eZInputValidator::STATE_ACCEPTED or eZInputValidator::STATE_INVALID if
             the values are accepted or not
    */
    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
		$status = eZInputValidator::STATE_ACCEPTED;

		$choosenfieldsName = $base . self::CHOOSEN_FIELDS_VARIABLE . $classAttribute->attribute( 'id' );
		if ( $http->hasPostVariable( $choosenfieldsName ) )
        {
			if( count( $http->postVariable( $choosenfieldsName ) )==0){
				$status=eZInputValidator::STATE_INVALID;
			}
		}

		$yearminName = $base . self::YEAR_RANGE_MIN_VARIABLE . $classAttribute->attribute( 'id' );
		if ( $http->hasPostVariable( $yearminName ) )
        {
			$yearmminValue = $http->postVariable( $yearmaxName );
			if ( !is_numeric( $yearmminValue ) && $yearmminValue != '' ){
				$status=eZInputValidator::STATE_INVALID;
			}
		}

		$yearmaxName = $base . self::YEAR_RANGE_MAX_VARIABLE . $classAttribute->attribute( 'id' );
		if ( $http->hasPostVariable( $yearmaxName ) )
        {
			$yearmaxValue = $http->postVariable( $yearmaxName );
			if ( !is_numeric( $yearmaxValue ) && $yearmaxValue != '' ){
				$status=eZInputValidator::STATE_INVALID;
			}
		}
        return $status;
    }

    /*!
     Fetches all variables inputed on content class level
     \return true if fetching of class attributes are successfull, false if not
    */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $choosenfieldsName = $base . self::CHOOSEN_FIELDS_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $choosenfieldsName ) )
        {
            $classAttribute->setAttribute( self::CHOOSEN_FIELDS,  implode( $http->postVariable( $choosenfieldsName ) ) );
        }

        $showmonthlistName = $base . self::SHOW_MONTH_LIST_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $showmonthlistName ) )
        {
            $classAttribute->setAttribute( self::SHOW_MONTH_LIST,  $http->postVariable( $showmonthlistName ) );
        }

        $yearminName = $base . self::YEAR_RANGE_MIN_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $yearminName ) )
        {
            $classAttribute->setAttribute( self::YEAR_RANGE_MIN,  $http->postVariable( $yearminName ) );
        }

        $yearmaxName = $base . self::YEAR_RANGE_MAX_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $yearmaxName ) )
        {
            $classAttribute->setAttribute( self::YEAR_RANGE_MAX,  $http->postVariable( $yearmaxName ) );
        }
        return true;
    }

    /*!
     Validates input on content object level
     \return eZInputValidator::STATE_ACCEPTED or eZInputValidator::STATE_INVALID if
             the values are accepted or not
    */
    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
		$shownFields=$classAttribute->attribute(self::CHOOSEN_FIELDS);
		$required=false;
		$attribute_id=$contentObjectAttribute->attribute( 'id' );
		$year='';$month='';$day='';

		if ( !$classAttribute->attribute( 'is_information_collector' ) and $contentObjectAttribute->validateIsRequired() )
		{
			$required=true;
		}
		if(strripos($shownFields, 'Y')!==false)
		{
			if ( $http->hasPostVariable( $base . '_date_year_' . $attribute_id ) && $http->postVariable( $base . '_date_year_' . $attribute_id )!='' )
			{
				$year = $http->postVariable( $base . '_date_year_' . $attribute_id );
				$current_year = date('Y');
				$range_min=$classAttribute->attribute(self::YEAR_RANGE_MIN);
				if ( is_numeric( $range_min ) && $range_min != 0 )
				{
					$year_min = $current_year - $range_min;
					if ( $year < $year_min )
					{
						$contentObjectAttribute->setValidationError( "The year must be greater or equals than $year_min." );
						return eZInputValidator::STATE_INVALID;
					}
				}
				$range_max=$classAttribute->attribute(self::YEAR_RANGE_MAX);
				if ( is_numeric( $range_max ) && $range_max != 0 )
				{
					$year_max = $current_year + $range_max;
					if ( $year > $year_max )
					{
						$contentObjectAttribute->setValidationError( "The year must be less or equals than $year_max." );
						return eZInputValidator::STATE_INVALID;
					}
				}
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}
		if(strripos($shownFields, 'M')!==false)
		{
			if ( $http->hasPostVariable( $base . '_date_month_' . $attribute_id ) && $http->postVariable( $base . '_date_month_' . $attribute_id )!='')
			{
				$month = $http->postVariable( $base . '_date_month_' . $attribute_id );
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}
		if (strripos($shownFields, 'D')!==false)
		{
			if ( $http->hasPostVariable( $base . '_date_day_' . $attribute_id ) && $http->postVariable( $base . '_date_day_' . $attribute_id )!='' )
			{
				$day = $http->postVariable( $base . '_date_day_' . $attribute_id );
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}

		// Random values to test if the user's input is correct when the variables are not set
		if ( !$year )
		{
			$year = 2000;
		}
		if ( !$month )
		{
			$month = 1;
		}
		if ( !$day )
		{
			$day = 1;
		}
		return $this->validateDateTimeHTTPInput( $day, $month, $year, $contentObjectAttribute );
    }

    function validateDateTimeHTTPInput( $day, $month, $year, $contentObjectAttribute )
    {
        $state = eZDateTimeValidator::validateDate( $day, $month, $year );
        if ( $state == eZInputValidator::STATE_INVALID )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'Date is not valid.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        return $state;
    }

    /*!
     Fetches all variables from the object
     \return true if fetching of class attributes are successfull, false if not
    */
    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
		$attribute_id=$contentObjectAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $base . '_date_year_' . $attribute_id ) ||
             $http->hasPostVariable( $base . '_date_month_' . $attribute_id ) ||
             $http->hasPostVariable( $base . '_date_day_' . $attribute_id ) )
        {
            $content=array(
				"year" 	=> 	$http->postVariable( $base . '_date_year_' . $attribute_id ),
				"month" => 	$http->postVariable( $base . '_date_month_' . $attribute_id ),
				"day" 	=> 	$http->postVariable( $base . '_date_day_' . $attribute_id )
            );
			$contentObjectAttribute->setAttribute( 'data_text', serialize( $content ) );
            return true;
        }
        return false;
    }

    function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
		$shownFields=$classAttribute->attribute(self::CHOOSEN_FIELDS);
		$required=false;
		$attribute_id=$contentObjectAttribute->attribute( 'id' );
		$year='';$month='';$day='';

		if ( $contentObjectAttribute->validateIsRequired() )
		{
			$required=true;
		}
		if(strripos($shownFields, 'Y')!==false){
			if ( $http->hasPostVariable( $base . '_date_year_' . $attribute_id ) && $http->postVariable( $base . '_date_year_' . $attribute_id )!='' )
			{
				$year = $http->postVariable( $base . '_date_year_' . $attribute_id );
				$current_year = date('Y');
				$range_min=$classAttribute->attribute(self::YEAR_RANGE_MIN);
				if ( is_numeric( $range_min ) && $range_min!= 0 )
				{
					$year_min = $current_year - $range_min;
					if ( $year < $year_min )
					{
						$contentObjectAttribute->setValidationError( "The year must be greater or equals than $year_min." );
						return eZInputValidator::STATE_INVALID;
					}
				}
				$range_max=$classAttribute->attribute(self::YEAR_RANGE_MAX);
				if ( is_numeric( $range_max ) &&  $range_max != 0 )
				{
					$year_max = $current_year + $range_max;
					if ( $year > $year_max )
					{
						$contentObjectAttribute->setValidationError( "The year must be less or equals than $year_max." );
						return eZInputValidator::STATE_INVALID;
					}
				}
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}
		if(strripos($shownFields, 'M')!==false)
		{
			if ( $http->hasPostVariable( $base . '_date_month_' . $attribute_id ) && $http->postVariable( $base . '_date_month_' . $attribute_id )!='' )
			{
				$month = $http->postVariable( $base . '_date_month_' . $attribute_id );
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}
		if(strripos($shownFields, 'D')!==false)
		{
			if ( $http->hasPostVariable( $base . '_date_day_' . $attribute_id ) && $http->postVariable( $base . '_date_day_' . $attribute_id )!='' )
			{
				$day = $http->postVariable( $base . '_date_day_' . $attribute_id );
			}
			else if ( $required )
			{
				$contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing date input.' ) );
				return eZInputValidator::STATE_INVALID;
			}
		}

		// Random values to test if the user's input is correct when the variables are not set
		if ( !$year ) {
			$year = 2000;
		}
		if ( !$month ) {
			$month = 1;
		}
		if ( !$day ) {
			$day = 1;
		}
		return $this->validateDateTimeHTTPInput( $day, $month, $year, $contentObjectAttribute );
    }

    /*!
     Fetches the http post variables for collected information
    */
    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
		$attribute_id=$contentObjectAttribute->attribute( 'id' );

        if ( $http->hasPostVariable( $base . '_date_year_' . $attribute_id ) ||
             $http->hasPostVariable( $base . '_date_month_' . $attribute_id ) ||
             $http->hasPostVariable( $base . '_date_day_' . $attribute_id ) )
        {
            $content=array(
				"year" 	=> 	$http->postVariable( $base . '_date_year_' . $attribute_id ),
				"month" => 	$http->postVariable( $base . '_date_month_' . $attribute_id ),
				"day" 	=> 	$http->postVariable( $base . '_date_day_' . $attribute_id )
            );
			$collectionAttribute->setAttribute( 'data_text', serialize( $content ) );
            return true;
        }
        return false;
    }

    /*!
     Returns the content.
    */
    function objectAttributeContent( $contentObjectAttribute )
    {
        return unserialize($contentObjectAttribute->attribute( 'data_text' ));
    }

    /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( $contentObjectAttribute )
    {
		return $this->toString( $contentObjectAttribute );
    }

    function sortKeyType()
    {
        return 'string';
    }

    /*!
     Returns the value as it will be shown if this attribute is used in the object name pattern.
    */
    function title( $contentObjectAttribute, $name = null )
    {
        return $this->toString( $contentObjectAttribute );
    }

    /*!
     \return true if the datatype can be indexed
    */
    function isIndexable()
    {
        return true;
    }

    function isInformationCollector()
    {
        return true;
    }

    function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return is_array( $contentObjectAttribute->attribute( 'data_text' ) );
    }

    /*!
     \return string representation of an contentobjectattribute data for simplified export

    */
    function toString( $contentObjectAttribute )
    {
		$date = $this->objectAttributeContent( $contentObjectAttribute );
		return str_replace( "  ", " ", $date['year'] . ' ' . $date['month'] . ' ' . $date['day'] );
    }

	/* $string => serialised array */
    function fromString( $contentObjectAttribute, $string )
    {
        $contentObjectAttribute->setAttribute( 'data_text',  $string );
    }

    function diff( $old, $new, $options = false )
    {
        $diff = new eZDiff();
        $diff->setDiffEngineType( $diff->engineType( 'text' ) );
        $diff->initDiffEngine();
        $old_content = unserialize( $old->DataText );
        $old_content = str_replace( "  ", " ", $old_content['year'] . ' ' . $old_content['month'] . ' ' . $old_content['day'] );
        $new_content = unserialize( $new->DataText );
        $new_content = str_replace( "  ", " ", $new_content['year'] . ' ' . $new_content['month'] . ' ' . $new_content['day'] );
        $diffObject = $diff->diff( "$old_content", "$new_content" );
        return $diffObject;
    }

}

eZDataType::register( extendedDateType::DATA_TYPE_STRING, "extendedDateType" );
?>