<?php /*

[PHP]
PHPOperatorList[htmlspecialchars]=htmlspecialchars

*/
?>