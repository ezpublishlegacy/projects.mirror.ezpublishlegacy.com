<?php /* #?ini charset="utf-8"?

[full_teamspeakdisplay]
Source=node/view/full.tpl
MatchFile=teamspeakdisplay/teamspeakdisplay.tpl
Subdir=templates
Match[class_identifier]=teamspeakdisplay

*/ ?>
