<?php /*

#?ini charset="iso-8859-1"?
# eZ publish configuration file.

[TemplateSettings]
AutoloadPathList[]=extension/teamspeakdisplay/autoloads

[RegionalSettings]
TranslationExtensions[]=teamspeakdisplay

*/
?>
