<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=accolorpicker

[JavaScriptSettings]
FrontendJavaScriptList[]=spectrum.js
BackendJavaScriptList[]=spectrum.js

[StylesheetSettings]
FrontendCSSFileList[]=spectrum.css
BackendCSSFileList[]=spectrum.css

*/ ?>
