<?php /* #?ini charset="iso-8859-1"?
# eZ publish extended attribute filter configuration file.


#The name of the filter.
[ExtendedImageFilter]

#The name of the extension where the filtering code is defined.
ExtensionName=gwfutils

#The name of the filter class.
ClassName=eZExtendedImageFilter

#The name of the method which is called to generate the SQL parts.
MethodName=createSqlParts

#The file which should be included (extension/myextension will automatically be prepended).
FileName=kernel/classes/ezimagefilter.php


*/ ?>
