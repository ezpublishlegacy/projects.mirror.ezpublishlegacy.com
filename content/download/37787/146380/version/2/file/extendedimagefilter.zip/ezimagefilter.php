<?php

class eZExtendedImageFilter
{
    /*!
     Constructor
    */
    function eZExtendedImageFilter()
    {
        // Empty...
    }

    function createSqlParts( $params )
    {
        $result = array( 'tables' => '', 'joins'  => '' );
        if ( isset( $params['attribute'] ) )
        {
             $filterAttributeID = $params['attribute'];
        }
        else
        	return $result;
        
        if ( !is_numeric( $filterAttributeID ) )
        	$filterAttributeID = eZContentObjectTreeNode::classAttributeIDByIdentifier( $filterAttributeID );
        
        $filterSQL = array();
        $filterSQL['from']  = ", ezcontentobject_attribute i1 ";
        $filterSQL['where'] = " (
		       i1.contentobject_id = ezcontentobject.id AND
		       i1.contentclassattribute_id = $filterAttributeID AND
		       i1.version = ezcontentobject_name.content_version AND
		       i1.language_code = ezcontentobject_name.real_translation AND 
		       i1.data_text LIKE '%is_valid=\"1\"%' ) AND
		       ";

        return array( 'tables' => $filterSQL['from'], 'joins'  => $filterSQL['where'] );

    }
}

?>
