

INSERT INTO ezcontentclass VALUES (29,0,'Email message','emailmessage','<fromname>: <subject>',14,14,1056132947,1056134780);


INSERT INTO ezcontentclass_attribute VALUES (169,0,29,'received','Received','ezdatetime',0,0,1,1,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (174,0,29,'subject','Subject','ezstring',1,0,2,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (177,0,29,'fromname','From Name','ezstring',1,0,3,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (170,0,29,'from','From','ezstring',1,0,4,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (171,0,29,'to','To','ezstring',1,0,5,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (172,0,29,'cc','Cc','ezstring',1,0,6,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (173,0,29,'bcc','Bcc','ezstring',1,0,7,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (175,0,29,'replyto','ReplyTo','ezstring',1,0,8,0,0,0,0,0,0,0,0,'','','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (176,0,29,'bodytext','BodyText','eztext',1,0,9,10,0,0,0,0,0,0,0,'','','','','',0);


INSERT INTO ezcontentclass_classgroup VALUES (29,0,6,'WebMail');

INSERT INTO ezcontentclassgroup VALUES (6,'WebMail',14,14,1056132928,1056132942);



INSERT INTO ezcontentobject VALUES (229,14,1,1,'Emails',1,0,1056136711,1056136711,1,'');
INSERT INTO ezcontentobject VALUES (230,14,1,1,'admin',1,0,1056136741,1056136741,1,'');
INSERT INTO ezcontentobject VALUES (231,14,1,1,'inbox',1,0,1056136758,1056136758,1,'');
INSERT INTO ezcontentobject VALUES (232,14,1,1,'drafts',1,0,1056136770,1056136770,1,'');

INSERT INTO ezcontentobject_attribute VALUES (653,'eng-GB',1,229,4,'Emails',0,0);
INSERT INTO ezcontentobject_attribute VALUES (654,'eng-GB',1,229,119,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<section>\n  <paragraph>Folder for emails</paragraph>\n  <paragraph>In future there will be in separate tree (not in content tree)</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (655,'eng-GB',1,230,4,'admin',0,0);
INSERT INTO ezcontentobject_attribute VALUES (656,'eng-GB',1,230,119,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<section>\n  <paragraph>Admin&apos;s emails</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (657,'eng-GB',1,231,4,'inbox',0,0);
INSERT INTO ezcontentobject_attribute VALUES (658,'eng-GB',1,231,119,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<section />',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (659,'eng-GB',1,232,4,'drafts',0,0);
INSERT INTO ezcontentobject_attribute VALUES (660,'eng-GB',1,232,119,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<section />',1045487555,0);


INSERT INTO ezcontentobject_version VALUES (799,229,14,1,1056136654,1056136711,1,0,0);
INSERT INTO ezcontentobject_version VALUES (800,230,14,1,1056136719,1056136741,1,0,0);
INSERT INTO ezcontentobject_version VALUES (801,231,14,1,1056136751,1056136758,1,0,0);
INSERT INTO ezcontentobject_version VALUES (802,232,14,1,1056136762,1056136770,1,0,0);



INSERT INTO ezcontentobject_name VALUES (229,'Emails',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (230,'admin',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (231,'inbox',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (232,'drafts',1,'eng-GB','eng-GB');

INSERT INTO ezcontentobject_tree VALUES (215,2,229,1,1,1283582034,2,'/1/2/215/','emails',1,9,0,215,'af67ca2fe7ffcec86822126de0ffc4d7');
INSERT INTO ezcontentobject_tree VALUES (216,215,230,1,1,2090036275,3,'/1/2/215/216/','emails/admin',1,9,0,216,'e9e1416d3280068087eefccf73667e3d');
INSERT INTO ezcontentobject_tree VALUES (217,216,231,1,1,-751230379,4,'/1/2/215/216/217/','emails/admin/inbox',1,9,0,217,'5f14d3290debf32ec09ec85dc504ae75');
INSERT INTO ezcontentobject_tree VALUES (218,216,232,1,1,-1467752094,4,'/1/2/215/216/218/','emails/admin/drafts',1,9,0,218,'761c0c52396fd09df2ae30ebc760bc55');

INSERT INTO eznode_assignment VALUES (534,229,1,2,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (535,230,1,215,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (536,231,1,216,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (537,232,1,216,1,1,9,0,0);
