<?php


/*! \defgroup eZUtils Utility classes */

/*!
  \class eZWebMail ezwebmail.php
  \ingroup eZUtils
  \brief WebMail handler

  Class for storing Emails in eZPublish DB

*/

include_once( 'lib/i18n/classes/eztextcodec.php' );
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezextension.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );


class eZWebMail
{
    /*!
      Constructs a new eZWebMail object.
    */
	function eZWebMail()
	{
		$webMailINI =& eZINI::instance( 'webmail.ini' );
		$this->emailMessageClassID = $webMailINI->variable('settings', 'emailMessageClassID');
		$this->rootEmailNode = $webMailINI->variable('settings', 'rootEmailNode');
		$this->emailDefaultUser = $webMailINI->variable('settings', 'emailDefaultUser');
	}


    /*!
      Finds eZ publish user by login and set userid
    */
	function FindeZPublishUser($email)
	{
// TODO	
		$email['ezuser']['loginid'] = 14;
		return(true);
	}

    /*!
      Finds requested folder for user and set folderid
    */
	function FindFolder($email)
	{
// TODO
		$email['ezuser']['folderid'] = $this->rootEmailNode;

		return(true);
	}

    /*!
      Checks restrictions & e-mail rules for user
	  (max. space, max. number of emails, redirections, mail forwardings, etc.)
    */
	function CheckEmailRules($email)
	{
// TODO
	// checking for max. space, max. number of emails, redirections, mail forwardings, etc
		return(true);
	}

    /*!
      Stores a new mail in DB.
    */
	function StoreMailToeZPublish($email)
	{
		
		if (!$this->FindeZPublishUser($email))
		{
			// if exists default mail user - redirect it to him
			$email['ezuser']['login'] = $this->emailDefaultUser;
			if (!$this->FindeZPublishUser($email))
				return(false);
		}
		if (!$this->FindFolder($email))
			return(false);


		// create new e-mail
		// email node
		$emailNode =& eZContentObjectTreeNode::fetch( $this->rootEmailNode );

		// Email class 
    	$class =& eZContentClass::fetch( $this->emailMessageClassID );
	    // Create object by user 
	    $contentObject =& $class->instantiate( $email['ezuser']['loginid'], 1 );
    	$nodeAssignment =& eZNodeAssignment::create( 
							array('contentobject_id' => $contentObject->attribute( 'id' ),
									'contentobject_version' => $contentObject->attribute( 'current_version' ),
									'parent_node' => $emailNode->attribute( 'node_id' ),
									'is_main' => 1));
		$version =& $contentObject->version( 1 );
    	$contentObjectAttributes =& $version->contentObjectAttributes();

		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'subject', $email['subject']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_int',  'received', $email['date']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'from', $email['from']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'fromname', $email['fromname']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'to', $email['to']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'cc', $email['cc']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'bcc', $email['bcc']);
		$this->_SetAttributeByName($contentObjectAttributes, 'data_text', 'bodytext', $email['body']);

    	$version->setAttribute( 'modified', eZDateTime::currentTimeStamp() );
	    $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
    	$version->store();
	    $nodeAssignment->store();
	    $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObject->attribute( 'id' ), 'version' => 1 ) );
	}

	
    /*!
      Only for internal use by StoreMailToeZPublish
    */
	function _SetAttributeByName($contentObjectAttributes, $fieldtype, $name, $value)
	{
		for($i=0; (($i<count($contentObjectAttributes)) && ($contentObjectAttributes[$i]->attribute('contentclass_attribute_identifier') != $name)); $i++);
		if ($i<count($contentObjectAttributes))
		{
 			$contentObjectAttributes[$i]->setAttribute( $fieldtype, $value );
		    $contentObjectAttributes[$i]->store();
		}
		else	
		{
// TODO - made some debug message or log
			echo "I haven't found it! ($name)<BR>";
			return(false);
		}
		return(true);
	}
}
?>
