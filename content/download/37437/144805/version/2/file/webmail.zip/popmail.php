#!/usr/local/php/bin/php
<?php

//set_time_limit( 0 );
set_time_limit( 60 );

// Initialize module loading
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezextension.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );

include_once( 'webmail.php' );

$moduleINI =& eZINI::instance( 'module.ini' );
$globalModuleRepositories = $moduleINI->variable( 'ModuleSettings', 'ModuleRepositories' );
$extensionRepositories = $moduleINI->variable( 'ModuleSettings', 'ExtensionRepositories' );
$extensionDirectory = eZExtension::baseDirectory();
$globalExtensionRepositories = array();
foreach ( $extensionRepositories as $extensionRepository )
{
	$modulePath = $extensionDirectory . '/' . $extensionRepository . '/modules';
	if ( file_exists( $modulePath ) )
	{
	$globalExtensionRepositories[] = $modulePath;
	}
}
$moduleRepositories = array_merge( $moduleRepositories, $globalModuleRepositories, $globalExtensionRepositories );
eZModule::setGlobalPathList( $moduleRepositories );


// this was just some initialization
//******************************************************************************************************



//******************************************************************************************************
// this create nice email format for me
//
	function CreateAddress($addressArray)
	{
		$result = '';
		for($i=0; $i<count($addressArray); $i++)
		{
			if (strlen($result))
				$result .= ', ';
			// maybe here should be imap_mime_header_decode
			// remove '
			$personal = str_replace("'", "", $addressArray[$i]->personal);
			if (strlen($personal))
				$result .= "\"$personal\" ";
			// this should be allways true
			if ((strlen($addressArray[$i]->mailbox)) && (strlen($addressArray[$i]->host)))
				$result .= '<'.$addressArray[$i]->mailbox.'@'.$addressArray[$i]->host.">";
		}
		return($result);
	}


//******************************************************************************************************
// go throug whole email parts and get as much info as possible
//
	function ProcessStructure(&$email, $structure, $mbox, $msgNr, $path="")
	{
		// print it for debug
		$sl = '';
		for($rr=0; $rr<count(explode('.', $path)); $rr++)
			$sl .= '&nbsp;&nbsp;&nbsp;&nbsp;';

// TODO remove this part after it get debugged
print ".................................................<BR>";
  		print("$sl type:   ". $structure->type)."<br>\n";
  		print("$sl encoding:   ". $structure->encoding)."<br>\n";
  		print("$sl ifsubtype:   ". $structure->ifsubtype)."<br>\n";
  		print("$sl subtype:   ". $structure->subtype)."<br>\n";
  		print("$sl ifdescription:   ". $structure->ifdescription)."<br>\n";
  		print("$sl description:   ". $structure->description)."<br>\n";
  		print("$sl ifid:   ". $structure->ifid)."<br>\n";
  		print("$sl id:   ". $structure->id)."<br>\n";
  		print("$sl lines:   ". $structure->lines)."<br>\n";
  		print("$sl bytes:   ". $structure->bytes)."<br>\n";
  		print("$sl ifdisposition:   ". $structure->ifdisposition)."<br>\n";
  		print("$sl disposition:   ". $structure->disposition)."<br>\n";
  		print("$sl ifdparameters:   ". $structure->ifdparameters)."<br>\n";
  		print("$sl dparameters:   ". $structure->dparameters)."<br>\n";
		if ($structure->dparameters > 0)
		{
			while (list ($key,$val) = each ($structure->dparameters)) 
			{
   	    		echo $sl.$val->attribute." = ".$val->value."<br>\n";
	    	}
		}
  		print("$sl ifparameters:   ". $structure->ifparameters)."<br>\n";
  		print("$sl parameters:   ". $structure->parameters)."<br>\n";
// end of removing

		$filename = "";
		$charset = "";
		while (list ($key,$val) = each ($structure->parameters)) 
		{
// TODO remove next line
   	    	echo $sl.$val->attribute." = ".$val->value."<br>\n";
			if (strtolower($val->attribute) == 'name')
				$filename = $val->value;
			if (strtolower($val->attribute) == 'charset')
				$charset = $val->value;
    	}

		// if it's multipart, decode each part
		if ($structure->type == 1)
		{
			$_p=1;
			foreach($structure->parts as $part)
			{
				ProcessStructure($email, $part, $mbox, $msgNr, (($path == "") ? $_p : $path.'.'.$_p));
				$_p++;
			}
		}
		else
		{
			print "``````````````````````````````````````````````````````<BR>";
			$body = imap_fetchbody($mbox, $msgNr, $path);
			
			// decode this part
			switch ($structure->encoding)
			{
				// 7BIT
				case 0:
// TODO - don't know how to decode it!
					$body =	$body; 

				// 8BIT 
				case 1:
					$body = imap_8bit($body);

				// BINARY 
				case 2:		
					$body =	imap_binary($body); 

				// BASE64 
				case 3:		
					$body = imap_base64($body);

				// QUOTED-PRINTABLE 
				case 4:		
					$body = imap_qprint($body);

				// OTHER 
				case 5:		
				default:
// TODO - don't know how to decode it!
					$body =	$body; 
			}


			if ($filename != "")
			{

				print "filename:<BR>";
				print "<code> ".htmlspecialchars($body)." </code><BR>";	
/*
				$xx = fopen ( "c:\\test\\$filename", 'w+');
				fwrite($xx, $body);
				fclose($xx);
*/
				$email['attachements'][] = array('filename' => $filename,
												 'size'		=> $structure->bytes,
												 'content'	=> $body);
			}
			else
			{
				if (($structure->type == 0) && ($structure->ifsubtype == 1) && (strtolower($structure->subtype) == "plain"))
				{
					print "PLAIN:<BR>";
					print "<code> $body </code><BR>";	
					// .= just for sure, that nothing got lost
					$email['body'] .= $body;
				}
				elseif (($structure->type == 0) && ($structure->ifsubtype == 1) && (strtolower($structure->subtype) == "html"))
				{
					print "HTML:<BR>";
					print "<code> $body </code><BR>";	
					// .= just for sure, that nothing got lost
					$email['htmlBody'] .= $body;
				}
				else
				{
// TODO - INLINE, etc.
					print "?????:<BR>";
					print "<code> $body </code><BR>";	
				}

			}
			print "``````````````````````````````````````````````````````<BR>";
		}


	}


	function RetrieveEmails($server, $username, $password, &$emails)
	{
		$emails = array();

		$mbox = @imap_open ("{".$server.":110/pop3}INBOX", $username, $password);
		if (!$mbox)
			return(false);
	
		$status = @imap_status($mbox,"{".$server.":110/pop3}INBOX",SA_ALL);
		if (!$status) 		
		{
			@imap_close();
			return(false);
		}


  print("nr of messages:   ". $status->messages   )."<br>\n";
 
		for($msgNr=1; $msgNr<=$status->messages; $msgNr++)
#		for($msgNr=11; $msgNr<=11; $msgNr++)
		{
			$email = array();


		$header = @imap_headerinfo ($mbox, $msgNr);
		$structure = @imap_fetchstructure ($mbox, $msgNr);
		if ((!$header) || (!$structure))
		{
			@imap_close();
			return(false);
		}

		$email['from'] = CreateAddress($header->from);
		$subject=imap_mime_header_decode($header->subject);
		if (count($subject))
		{
			if (strtolower($subject[0]->charset) == 'default')
				$subject = $subject[0]->text;
			else
			{
// TODO
				// transcode it to DB charset!
				$subject = $subject[0]->text;				
			}		
		}
		else
			$subject = '!count';
		$email['subject'] = $subject;
		$email['date'] = $header->udate;
		$email['from'] = CreateAddress($header->from);
		$email['fromname'] = CreateAddress($header->from);	
		$email['to'] = CreateAddress($header->to);
		$email['cc'] = CreateAddress($header->cc);
		$email['bcc'] = CreateAddress($header->bcc);
		$email['reply_to'] = CreateAddress($header->reply_to);
		$email['senderaddress'] = CreateAddress($header->senderaddress);
		$email['bytes'] = $structure->bytes;
		$email['attachements'] = array();
		$email['body'] = '';
		$email['htmlBody'] = '';
		// now get all attachements, process structure

print "******************************************************<BR>";
print "Message $msgNr ($email[subject] = ".$header->subject." ... ".strftime("%d.%m.%Y %H:%M:%S", $header->udate).")<BR>";

		ProcessStructure($email, $structure, $mbox, $msgNr);

		$emails[] = $email;
}




		@imap_close($mbox);
		return(true);
	}

//**************************************************************************
// Main section
	// initialize webmail object
	$webMail =& new eZWebMail;


/*
	// and now just test
	$email = array();
	$email['ezuser'] = array('login' 	=> 'admin',
							 'loginid'	=> -1,
							 'store'	=> true,
							 'folder'	=> 'inbox',
							 'folderid'	=> -1);

	$email['subject'] = 'P�edm�t zpr�vy';
	$email['date'] = mktime();
	$email['from'] = '"Petr" <p@nowhere.cz>';
	$email['fromname'] = '"Petr" <p@nowhere.cz>';
	$email['to'] = '"Petr" <p@nowhere.cz>';
	$email['cc'] = '"Petr" <p@nowhere.cz>';
	$email['bcc'] = '"Petr" <p@nowhere.cz>';
	$email['reply_to'] = '"Petr" <p@nowhere.cz>';
	$email['senderaddress'] = '"Petr" <p@nowhere.cz>';
	$email['bytes'] = 100 ;
	$email['attachements'] = array();
	$email['body'] = 'Telo pokusneho textu';
	$email['htmlBody'] = '';

	$webMail->StoreMailToeZPublish($email);
	
	exit(0);
*/



	// read ini-file
	$webMailINI =& eZINI::instance( 'webmail.ini' );
	$popServer = $webMailINI->variableArray( 'POPServers', 'POPServer1' );
	$popServer = $popServer[0];
	// get all mails from POP3 server
	$emails = array();
	RetrieveEmails($popServer[1], $popServer[2], $popServer[3], $emails);

// TODO
	// check for who are they
	if ($popServer[0] != '*') 
	{
		// check if such users are in eZ publish

	}
	else
	{
		// all mails are for $popServer[0]
		
	}
	// check mail restrictions (size, count, forwarding, etc.)
	

	// store mails to eZ publish
	foreach ($emails as $email)
	{
		$webMail->StoreMailToeZPublish($email);

	}
	

	// that's all folks!

exit;





