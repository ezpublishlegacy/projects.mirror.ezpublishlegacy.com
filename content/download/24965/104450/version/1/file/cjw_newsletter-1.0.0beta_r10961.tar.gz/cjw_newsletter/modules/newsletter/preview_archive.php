<?php
/**
 * File preview_archive.php
 *
 * -get the stored content of newsletter edition<br>
 * -may be parse user content<br>
 * -newsletter / archive / $edition_send_hash<br>
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0beta | $Id: preview_archive.php 10958 2010-03-30 13:39:59Z felix $
 * @package cjw_newsletter
 * @subpackage modules
 * @filesource
 */

include_once( 'kernel/common/template.php' );

$module = $Params["Module"];
$http = eZHTTPTool::instance();

$editionSendId = (int) $Params['EditionSendId'];

$outputFormatId = 0;
$newsletterUserId = 0;

if( $Params['OutputFormat'] )
    $outputFormatId = (int) $Params['OutputFormat'];

if( $Params['NewsletterUserId'] )
    $newsletterUserId = $Params['NewsletterUserId'];


$editionSendObject = CjwNewsletterEditionSend::fetch( $editionSendId );

if( !is_object( $editionSendObject  ) )
{
    return $module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
}

$newsletterDataArray = $editionSendObject->getParsedOutputXml();
$newsletterContent = false;

if( isset( $newsletterDataArray[ $outputFormatId ]) )
{
    $newsletterContentArray = $newsletterDataArray[ $outputFormatId ];
}

// html / text  - multipart/alternative
if( $outputFormatId === 0 )
{
    $newsletterContent .= $newsletterContentArray['body']['html'];
    $textContent = "<hr /><pre>" . $newsletterContentArray['body']['text'] . "</pre></body>";
    $newsletterContent = preg_replace( array('%</body>%'), array( $textContent ), $newsletterContent);
}
// plain/text
elseif( $outputFormatId === 1 )
{

    $newsletterContent .= '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>newsletter - outputformat - text</title></head><body><pre>'. $newsletterContentArray['body']['text'] .'</pre></body></html>';
}
else
{
    return $module->handleError( eZError::KERNEL_NOT_FOUND, 'kernel' );
}

$mailSubject = "<body><b>Email subject:</b> ". $newsletterContentArray['subject'] . "<br />";
$newsletterContent = preg_replace( array('%<body>%'), array( $mailSubject ), $newsletterContent);

$debug = 0;

if( $debug == 0 )
{
    header( "Content-type: text/html" );
    echo $newsletterContent;
    eZExecution::cleanExit();
}
else
{
    $Result = array();
    $Result['content'] = '<code>'.$newsletterContent.'</code>';
  //  header( "Content-type: text/html" );
}


?>