<?php
/**
 * File send.php
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0beta | $Id: send.php 10958 2010-03-30 13:39:59Z felix $
 * @package cjw_newsletter
 * @subpackage modules
 * @filesource
 */

include_once( 'kernel/common/template.php' );

$LogFile = new eZLog();

$ini = eZINI::instance();
$varDir = $ini->variable( 'FileSettings', 'VarDir' );
$logDir = $ini->variable( 'FileSettings', 'LogDir' );
$logName = 'cjw_newsletter.log';
$logFolder = $varDir . '/' . $logDir;
//$fileName = $logFolder. '/' . $logName;

$module = $Params["Module"];
$http = eZHTTPTool::instance();

$viewParameters = array();

$message = '';

if( isSet( $Params['NodeId'] ) )
{
    $nodeId = $Params['NodeId'];
}
elseif( $http->hasVariable('ContentNodeID') )
{
    $nodeId = (int) $http->variable('ContentNodeID');
}
else
{
    $nodeId = null;
}


$tpl = templateInit();
$tpl->setVariable( 'view_parameters', $viewParameters );
$tpl->setVariable( 'node_id', $nodeId );

// $objectVersion = eZContentObjectVersion::fetchVersion( $contentObjectVersion, $contentObjectId );

$node = eZContentObjectTreeNode::fetch( $nodeId );

if ( !is_object( $node ) )
{
    // return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
    return $module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
}

$objectVersion = $node->attribute( 'contentobject_version_object' );

if( is_object( $objectVersion ) )
{
    $tpl->setVariable( 'object_version', $objectVersion );
}
else
{
    $tpl->setVariable( 'error', 'No Object found!' );
}

// Newsletter test verschicken
if ( $module->isCurrentAction( 'SendNewsletterTest' ) )
{
    if ( $module->hasActionParameter('EmailReseiverTest') )
    {
        $emailReceiverTest = $module->actionParameter('EmailReseiverTest');
        $newsletterMail = new CjwNewsletterMail();

        $testSendResultArray = $newsletterMail->sendNewsletterTestMail( $objectVersion, $emailReceiverTest );
        $tpl->setVariable( 'email_test_send_result_array', $testSendResultArray );
    }
}

// Newsletter versenden
else if ( $module->isCurrentAction( 'SendNewsletter' ) )
{

    $editionDataMap = $objectVersion->attribute('data_map');
    $attributeEdition = $editionDataMap['newsletter_edition'];
    $attributeEditionContent = $attributeEdition->attribute('content');

    if ( $attributeEditionContent->attribute('is_process') )
    {
        $message = ezi18n( 'cjw_newsletter/datatype/cjwnewsletteredition', "The current edition is already in sending process - to create a new version please stop it first", null , array(  ) );
    }
    elseif ( $attributeEditionContent->attribute('is_archive') )
    {
        $message = ezi18n( 'cjw_newsletter/datatype/cjwnewsletteredition', "The current edition was already send and is in archive!", null , array(  ) );
    }
    // für entwurf + abgebrochen ist es möglich newsletter zu versenden
    else
    {

        $containerNodeId = $nodeId;
         // $containerNodeId = 43;

        $createResult = $attributeEditionContent->createNewsletterSendObject( $containerNodeId );

        // redirect auf current url   newsletter/send/ nodeId  damit die PostVariablen verloren gehen
        // return $module->redirectCurrent();

        $redirectUri = "/content/view/full/$nodeId";
        return $module->redirectTo( $redirectUri );
    }

    // 1. check ob es schon ein newslettersentobject für die aktuelle version gibt
    // 2. send_object erstellen mit status 'NEW'
    // 3. Meldung ausgeben
    /**if( $module->hasActionParameter('EmailReseiverTest') )
    {
        $emailReceiverTest = $module->actionParameter('EmailReseiverTest');
        $newsletterMail = new CjwNewsletterMail();

        $testSendResultArray = $newsletterMail->sendNewsletterTestMail( $objectVersion, $emailReceiverTest );
        $tpl->setVariable( 'email_test_send_result_array', $testSendResultArray );
    }
    */
}


//$tpl->setVariable( 'mail_newsletter', $mail_newsletter );

$tpl->setVariable( 'message', $message );

$Result = array();

//$Result['content'] = $email_html_content;
$Result['content'] = $tpl->fetch( "design:newsletter/send.tpl" );
$Result['path'] = array( array( 'url' => false,
                                    'text' => ezi18n('cjw_newsletter/send', 'Newsletter Send') )
                              );
//$Result['left_menu'] = 'design:parts/newsletter/menu.tpl';

?>
