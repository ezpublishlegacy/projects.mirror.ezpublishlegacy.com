<?php /* #?ini charset="utf-8"? */

/**
 * File containing the content ini
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0beta | $Id: content.ini.append.php 10958 2010-03-30 13:39:59Z felix $
 * @package cjw_newsletter
 * @subpackage ini
 * @filesource
 */
/*
[DataTypeSettings]
ExtensionDirectories[]=cjw_newsletter

AvailableDataTypes[]=cjwnewsletterlist
AvailableDataTypes[]=cjwnewsletteredition
AvailableDataTypes[]=cjwnewslettersubscription

*/?>