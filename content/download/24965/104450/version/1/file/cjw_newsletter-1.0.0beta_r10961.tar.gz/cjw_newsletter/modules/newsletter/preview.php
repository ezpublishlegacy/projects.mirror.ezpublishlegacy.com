<?php
/**
 * File preview.php
 *
 * Create a preview - return text or html<br>
 * -preview/ object_id / version_id/ outputformat/ siteaccess
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0beta | $Id: preview.php 10958 2010-03-30 13:39:59Z felix $
 * @package cjw_newsletter
 * @subpackage modules
 * @filesource
 */

$http = eZHTTPTool::instance();
$module = $Params["Module"];

$editionContentObjectId = $Params['EditionContentObjectId'];
$versionId = $Params['VersionId'];
$outputFormat = $Params['OutputFormat'];
$siteAccess = $Params['SiteAccess'];
$skinName = $Params['SkinName'];


/*
$currentEditionSendObject = CjwNewsletterEditionSend::fetchByEditionContentObjectIdVersion(
                                                    $editionContentObjectId,
                                                    $versionId
                                                    );

// if an send object exists => the newsletter is in sending process and the rendered newsletter output is in db
if( is_object( $currentEditionSendObject  ) )
{
    $module->redirect( 'newsletter', 'preview_archive', array( $currentEditionSendObject->attribute('id'),
                                                               $outputFormat ) );
    return eZModule::HOOK_STATUS_CANCEL_RUN;
}
*/

$showRawContent = false;

if( $http->hasVariable( 'ShowRawContent' ) )
{
    $showRawContent = true;
}

$newsletterContent = '';
$newsletterContentArray = CjwNewsletterEdition::getOutput( $editionContentObjectId, $versionId, $outputFormat, $siteAccess, $skinName );

if( $newsletterContentArray['content_type'] == 'text/html' )
{
    $newsletterContent .= $newsletterContentArray['body']['html'];

}
elseif( $newsletterContentArray['content_type'] == 'multipart/alternative' )
{
    $newsletterContent .= $newsletterContentArray['body']['html'];
    if( $showRawContent === false )
    {
        $textContent = "<hr /><pre>" . $newsletterContentArray['body']['text'] . "</pre></body>";
        $newsletterContent = preg_replace( array('%</body>%'), array( $textContent ), $newsletterContent);
    }
}
elseif( $newsletterContentArray['content_type'] == 'text/plain' )
{
    if( $showRawContent === false )
    {
        $newsletterContent .= '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>newsletter - outputformat - text</title></head><body><pre>'. $newsletterContentArray['body']['text'] .'</pre></body></html>';
    }
    else
    {
         $newsletterContent = $newsletterContentArray['body']['text'];
    }
}
else
{
    return $module->handleError( eZError::KERNEL_NOT_FOUND, 'kernel' );
}

if( $showRawContent === false )
{
    $mailSubject = "<body><b>Email subject:</b> ". $newsletterContentArray['subject'] . "<br />";
    $newsletterContent = preg_replace( array('%<body>%'), array( $mailSubject ), $newsletterContent );
}

$debug = 0;

if( $debug == 0 )
{
    header( "Content-type: text/html; charset=utf-8" );
    echo $newsletterContent;
    eZExecution::cleanExit();
}
else
{
    $Result = array();
    $Result['content'] = '<code>'.$newsletterContent.'</code>';
    // header( "Content-type: text/html" );
}


?>