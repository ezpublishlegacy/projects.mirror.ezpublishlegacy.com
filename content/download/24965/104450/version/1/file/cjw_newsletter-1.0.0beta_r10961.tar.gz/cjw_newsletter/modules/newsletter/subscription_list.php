<?php
/**
 * File subscription_list.php
 *
 * @copyright Copyright (C) 2007-2010 CJW Network - Coolscreen.de, JAC Systeme GmbH, Webmanufaktur. All rights reserved.
 * @license http://ez.no/licenses/gnu_gpl GNU GPL v2
 * @version 1.0.0beta | $Id: subscription_list.php 10958 2010-03-30 13:39:59Z felix $
 * @package cjw_newsletter
 * @subpackage modules
 * @filesource
 */

include_once( 'kernel/common/template.php' );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();

$templateFile = "design:newsletter/subscription_list.tpl";

$nodeId = (int) $Params['NodeId'];

$node = eZContentObjectTreeNode::fetch( $nodeId );
if( !is_object($node ))
{
    return $module->handleError( eZError::KERNEL_NOT_AVAILABLE, 'kernel' );
}

$viewParameters = array();

if( is_array( $Params['UserParameters'] ) )
{
    $viewParameters = array_merge( $viewParameters, $Params['UserParameters'] );
}

// Parameter der View als Array dem Template übergeben
$tpl->setVariable( 'view_parameters', $viewParameters );
$tpl->setVariable( 'node', $node );

$Result = array();

$Result['node_id'] = $nodeId;
$Result['content'] = $tpl->fetch( $templateFile );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'cjw_newsletter/subscription_list', 'List Subscription List' ) ) );


?>