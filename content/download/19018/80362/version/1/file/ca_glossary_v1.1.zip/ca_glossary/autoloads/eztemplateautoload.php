<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ca_glossary/autoloads/ca_glossary.php',
                                    'class' => 'CAGlossary',
                                    'operator_names' => array( 'ca_glossary' ) );
?>