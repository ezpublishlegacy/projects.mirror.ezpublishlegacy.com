<?php /*

[ModuleSettings]
ExtensionRepositories[]=arh_jdebug
ModuleList[]=debug

*/ ?>
