<?php

require_once "lib/src/phpfreechat.class.php";
require_once "../../autoload.php";
$params["title"] = isset($_GET['title'])?$_GET['title']:"Quick chat";
$params["language"] = isset($_GET['language'])?$_GET['language']:"en_US";
$params["theme"] = isset($_GET['theme'])?$_GET['theme']:"phoenity";
$pathArray=explode('/',$_SERVER['PHP_SELF']);
$sitePrefix="";



foreach($pathArray as $key => $path) {
   
        if( $path == "extension" )    break;
		if( $path != "" ) $sitePrefix.="/".$path;
		
       
       
}
$params["isadmin"] = false;
$params["nick"] = "Anonymous".rand(1,1000);
$params["data_public_url"] = $sitePrefix."/extension/chat/lib/data/public";
$params["prototypejs_url"] = $sitePrefix."/extension/chat/lib/data/public/js/prototype.js";

$params["dyn_params"]=array("title","language","theme","isadmin","display_pfc_logo","display_ping","prototypejs_url","data_public_url");

$params["serverid"] = md5(__FILE__);
$params["debug"] = false;
$chat = new phpFreeChat( $params );

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
 <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title>phpFreeChat- Sources Index</title> 
 </head>
 <body>




  <?php $chat->printChat(); ?>
  <?php if (isset($params["isadmin"]) && $params["isadmin"]) { ?>
    <p style="color:red;font-weight:bold;">Warning: because of "isadmin" parameter, everybody is admin. Please modify this script before using it on production servers !</p>
  <?php } ?>


    
</body></html>
