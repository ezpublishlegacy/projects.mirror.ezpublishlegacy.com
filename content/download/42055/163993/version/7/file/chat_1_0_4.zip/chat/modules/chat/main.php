﻿<?php

$params["title"] = "Quick chat";
$params["language"] = "en_US";
$params["theme"] = "phoenity";

$params["data_public_url"] = eZSys::wwwDir()."/extension/chat/lib/data/public";

$params["prototypejs_url"] = eZSys::wwwDir()."/extension/chat/lib/data/public/js/prototype.js";
$params["server_script_path"] = eZSys::wwwDir()."/extension/chat/chat.php?title=".$params["title"]."&language=".$params["language"]."&theme=".$params["theme"];
$params["server_script_url"] = eZSys::wwwDir()."/extension/chat/chat.php?title=".$params["title"]."&language=".$params["language"]."&theme=".$params["theme"];

$user = eZUser::currentUser();

if(in_array(12,$user->attribute("groups"))){
  $params["isadmin"] = true;
}
else
{
  $params["isadmin"] = false;
}

$params["dyn_params"]=array("theme","title","language","data_public_url","isadmin","prototypejs_url","server_script_url","server_script_path");


if($user->isLoggedIn()) {

$params["nick"] = $user->attribute("login");

} else {

$params["nick"] = "Anonymous".rand(1,10000);  // setup the intitial nickname

}

$params["serverid"] = md5(__FILE__); // calculate a unique id for this chat
$params["debug"] = false;
$chat = new phpFreeChat( $params );


$tpl = eZTemplate::factory();

$tpl->setVariable( 'chat',$chat->printChat(true) );

$Result = array();
$Result['path'] = array(array('url' => false,
        'text' => 'Chat'),
    array('url' => false,
        'text' => 'Main'));
$Result['content'] = $tpl->fetch("design:chat/main.tpl");
?>
