<?php
$Module = array(
        "name" => 'Chat'
);

$ViewList = array();
$ViewList['main'] = array(
        'functions' => array( 'main' ),
        'script'  => 'main.php'
);


$FunctionList[ 'main' ] = array();


?>
