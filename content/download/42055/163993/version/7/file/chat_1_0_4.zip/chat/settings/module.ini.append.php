<?php /* #?ini charset="utf-8"?


[ModuleSettings]
ExtensionRepositories[]=chat
ModuleList[]=chat

*/?>