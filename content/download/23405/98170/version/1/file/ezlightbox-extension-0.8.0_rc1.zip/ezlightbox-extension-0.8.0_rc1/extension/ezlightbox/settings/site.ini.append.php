<?php /*

[RegionalSettings]
TranslationExtensions[]=ezlightbox

[TemplateSettings]
AutoloadPathList[]=extension/ezlightbox/autoloads

*/ ?>
