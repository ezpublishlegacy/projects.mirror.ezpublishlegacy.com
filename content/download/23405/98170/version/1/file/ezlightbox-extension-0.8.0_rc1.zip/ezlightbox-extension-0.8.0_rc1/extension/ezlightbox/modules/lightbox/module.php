<?php
//
// Created on: <2007-11-21 13:01:28 ab>
//
// SOFTWARE NAME: eZ Lightbox extension for eZ Publish
// SOFTWARE RELEASE: 0.x
// COPYRIGHT NOTICE: Copyright (C) 1999-2010 eZ Systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

$Module = array( 'name' => 'lightbox' );

$ViewList = array();

$ViewList['add'] = array(
    'script'                  => 'add.php',
    'params'                  => array( 'LightboxID', 'ItemID', 'TypeID' ),
    'functions'               => array( 'add' ),
    'default_navigation_part' => 'ezlightboxnavigationpart',
    'ui_context'              => 'browse'
);

$ViewList['create'] = array(
    'script'                  => 'create.php',
    'functions'               => array( 'create' ),
    'default_navigation_part' => 'ezlightboxnavigationpart',
    'ui_context'              => 'edit'
);

$ViewList['edit'] = array(
    'script'                  => 'edit.php',
    'params'                  => array( 'LightboxID' ),
    'functions'               => array( 'edit' ),
    'default_navigation_part' => 'ezlightboxnavigationpart',
    'ui_context'              => 'edit'
);

$ViewList['view'] = array(
    'script'                  => 'view.php',
    'params'                  => array( 'ViewMode', 'LightboxID' ),
    'functions'               => array( 'view' ),
    'default_navigation_part' => 'ezlightboxnavigationpart',
    'ui_context'              => 'view'
);

$ViewList['send'] = array(
    'script'                  => 'send.php',
    'params'                  => array( 'LightboxID' ),
    'functions'               => array( 'view' ),
    'default_navigation_part' => 'ezlightboxnavigationpart',
    'ui_context'              => 'browse'
);

$FunctionList = eZLightbox::generatePermissionFunctionList();

?>
