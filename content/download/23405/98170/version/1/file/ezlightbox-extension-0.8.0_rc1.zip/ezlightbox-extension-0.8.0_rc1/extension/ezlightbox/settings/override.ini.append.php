<?php /*

[ContentObjectLightboxItem]
Source=lightbox/item/view/line.tpl
MatchFile=lightbox/item/view/object_line.tpl
Subdir=templates
Match[itemtypeid]=1

[ContentNodeLightboxItem]
Source=lightbox/item/view/line.tpl
MatchFile=lightbox/item/view/node_line.tpl
Subdir=templates
Match[itemtypeid]=2

*/ ?>
