<!DOCTYPE TS><TS>
<context>
    <name>ezcustomshop/addtobasket</name>
    <message>
        <source>Add to basket</source>
        <translation>zum Warenkorb hinzufügen</translation>
    </message>
</context>
</TS>