eZ CUSTOMSHOP extension 0.0.1 USAGE

1. Add a new form to your template

<form method="post" action={"customshop/addtobasket"|ezurl}>
	<input type="hidden" name="ProductItemIDList[]" value="" />
	<select name="ProductItemCountList[]">
    {for 0 to 100 as $counter}
    	<option value="{mul($counter,100)}">{mul($counter,100)}</option>
    {/for}
    </select>
	<div class="content-action">
			<input type="submit" class="defaultbutton" name="ActionAddToBasket" value="{'Add to basket'|i18n('ezcustomshop/addtobasket')}" />
			<input type="hidden" name="ContentObjectID" value="{$node.contentobject_id}" />
	</div>
</form>   


2. Usage in an existing form:

Alternatively you can call the javascript method to call the module action 
from within another form:

<form method="post" action={"content/action"|ezurl}>
	<input type="hidden" name="ProductItemIDList[]" value="" />
	<select name="ProductItemCountList[]">
    {for 0 to 100 as $counter}
    	<option value="{mul($counter,100)}">{mul($counter,100)}</option>
    {/for}
	</select>
	<input type="button" class="defaultbutton" name="ActionAddToBasket" value="{'Add to basket'|i18n('ezcustomshop/addtobasket')}" onclick="customShopAddToBasket(this);"/>
	<input type="hidden" name="ContentObjectID" value="{$node.contentobject_id}" />
</form>  


