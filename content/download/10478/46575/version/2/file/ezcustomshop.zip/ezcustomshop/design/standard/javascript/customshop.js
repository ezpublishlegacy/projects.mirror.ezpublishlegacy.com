/*
Customshop.js
*/

/*changes the action of the current form and submits it*/
function customShopAddToBasket(what){
	what.form.action="/customshop/addtobasket";
	what.form.submit();
}
