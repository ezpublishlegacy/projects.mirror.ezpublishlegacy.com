<?php
$Module = array(
"name" => 'customshop'
);
$ViewList = array();
$ViewList['addtobasket'] = array(
'functions' => array( 'addtobasket' ),
'script' => 'addtobasket.php'
);
$FunctionList[ 'addtobasket' ] = array();
?>