<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezcustomshop

[JavaScriptSettings]
JavaScriptList[]=customshop.js

*/?>