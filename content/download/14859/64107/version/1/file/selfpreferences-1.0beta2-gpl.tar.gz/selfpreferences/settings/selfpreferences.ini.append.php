<?php /* #?ini charset="utf-8"?

[GeneralSettings]

# List of default values for given preference names.
# Each line is created as follows:
# DefaultValues[{$VARIABLE_NAME}]={$TYPE_NAME}:{$VALUE}
# Do not worry if you have more than one '::' separator in your $VALUE - it will not be a problem.
# The only thing is that one $VALUE must remain within one line!
# DefaultValues[]
# DefaultValues[string_sample]=string::This is my default string
# DefaultValues[float_sample]=float::123.45
# DefaultValues[boolean_sample_1]=boolean::true
# DefaultValues[boolean_sample_2]=boolean::1
# DefaultValues[integer_sample]=integer::1928394852
# DefaultValues[complex_sample]=complex::a:1:{s:1:"a";s:1:"b";}

DefaultValues[]

*/ ?>