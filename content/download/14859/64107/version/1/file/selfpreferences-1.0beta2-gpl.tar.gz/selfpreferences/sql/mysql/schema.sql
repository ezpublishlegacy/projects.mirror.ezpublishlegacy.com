
CREATE TABLE `selfpreferences` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `data_int` int(11) NULL,
  `data_float` float NULL,
  `data_text` text NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `USER_NAME` (`name`,`user_id`),
  KEY `NAME` (`name`),
  KEY `USER_ID` (`user_id`)
) ENGINE=InnoDB;
