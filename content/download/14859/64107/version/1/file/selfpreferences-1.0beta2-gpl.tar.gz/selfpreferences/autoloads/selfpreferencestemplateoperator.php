<?php

/**
 * SELF Preferences extension for eZ Publish 4.0
 * Written by Piotrek Karaś, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class SELFPreferencesTemplateOperator {


    var $Operators;


    function __construct()
    {
        $this->Operators = array(
            'selfpreferences_value',
            'selfpreferences_values',
            'selfpreferences_setvalue',
        );
    }


    function &operatorList()
    {
        return $this->Operators;
    }


    function namedParameterPerOperator()
    {
        return true;
    }


    function namedParameterList()
    {
        return array(
			'selfpreferences_value' => array(
                'name' => array(  
                    'type' => 'string',
                    'required' => true,
                    'default' => false,
        ),
                'user_object' => array(  
                    'type' => 'object',
                    'required' => false,
                    'default' => false,
        ),
        ),
            'selfpreferences_values' => array(
                'user_object' => array(  
                    'type' => 'object',
                    'required' => false,
                    'default' => false,
        ),
        ),
            'selfpreferences_setvalue' => array(
                'name' => array(  
                    'type' => 'string',
                    'required' => true,
                    'default' => false,
        ),
                'value' => array(  
                    'type' => 'mixed',
                    'required' => true,
                    'default' => false,
        ),
                'type_name' => array(  
                    'type' => 'string',
                    'required' => true,
                    'default' => false,
        ),
                'store_user_id' => array(  
                    'type' => 'integer',
                    'required' => false,
                    'default' => false,
        ),
        ),
        );
    }


    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch( $operatorName )
        {
            case 'selfpreferences_value':
                {
                    $name = $namedParameters['name'];
                    $userObject = $namedParameters['user_object'];
                    $operatorValue = SELFPreferences::value( $name, $userObject );
                }
                break;
            case 'selfpreferences_values':
                {
                    $userObject = $namedParameters['user_object'];
                    $operatorValue = SELFPreferences::values( $userObject );
                }
                break;
            case 'selfpreferences_setvalue':
                {
                    $name = $namedParameters['name'];
                    $value = $namedParameters['value'];
                    $typeName = $namedParameters['type_name'];
                    $storeUserID = $namedParameters['store_user_id'];
                    $operatorValue = SELFPreferences::setValue( $name, $value, $typeName, $storeUserID );
                }
                break;
        }
    }


};

?>
