SELF Preferences extension for eZ Publish 4.0
version 1.0 stable

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ez.ryba.eu



What is it?
-----------

This extension substitutes for default eZ Publish eZPreference API and operators. 
It basically does the same thing, just slightly better (but also heavier).

The problems that are fixed with this extension:
- 4.0.x (and possibly other) bug with session vs. database data inconsistencies
- eZPreference limitations of 100 characters for values (way too little for serialization, for example)
- All variables treated as strings - here you have several datatypes/combinations
- Lack of automated serialization
- Complex values such as arrays or objects can now also have their INI-based default values

SELFPreferences supports (and maintains type of) most of variable types, categorized into 5 groups:
- integer (called as either one: integer, int, number)
- float (called as either one: float, double)
- boolean (called as either one: boolean, bool)
- string (called as either one: string, text)
- complex (called as either one: complex, serialize, object, array)

It is posible to use the following method to get/set preferences:
- PHP API
- eZ Template operators:
- URLs ( /selfpreferences/set/{var_name}/{var_value}/{type_name} 

Template operators:
selfpreferences_value( $name [, $userObject] )
selfpreferences_values( [$userObject] )
selfpreferences_setvalue( $name, $value, $typeName [, $storeUserID] )



When should I use it?
---------------------

1) When you need preference value type-sensitive solution
2) When you need to store values larger than 100 characters (especially for serialization)

However, remember than this solution is slightly heavier than default eZPreferences.
You should not try to migrate to this solution entirely!



TODOs
-----

Find out what maintenance mechanisms should be also implemented (cleanup, periodical cleanup, etc).



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components: Base, File



Tested with
-----------
4.0.1



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/selfpreferences/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=selfpreferences

3. Regenerate autoloads.

4. Import the schema.sql into your database.

5. Modify user role's privileges if you want users to be able to set values via URLs.
