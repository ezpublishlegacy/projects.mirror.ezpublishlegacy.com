<?php

/**
 * SELF Preferences extension for eZ Publish 4.0
 * Written by Piotrek Karaś, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


/**
 * @author Piotr Karaś partly based on eZPreferences class
 *
 * This class provides API for all the operations connected with preference
 * storage, retrieval, cleanup, caching etc.
 */

class SELFPreferences
{


    const EXT_DEBUG = false;

    const SESSION_NAME = 'SELFPreferences';

    const TYPE_INTEGER = 1;
    const TYPE_FLOAT = 2;
    const TYPE_STRING = 3;
    const TYPE_BOOLEAN = 4;
    const TYPE_COMPLEX = 5;


    /**
     * This method converts a casual name of value type into an internal
     * type ID. If the name is not found, assume string as default type.
     *
     * @param string $typeName
     * @return integer
     */
    public static function typeNameToTypeID( $typeName )
    {
        switch( $typeName )
        {
            case 'integer':
            case 'int':
            case 'number':
                return self::TYPE_INTEGER;
                break;
            case 'float':
            case 'double':
                return self::TYPE_FLOAT;
                break;
            case 'bool':
            case 'boolean':
                return self::TYPE_BOOLEAN;
                break;
            case 'string':
            case 'text':
                return self::TYPE_STRING;
                break;
            case 'complex':
            case 'serialize':
            case 'object':
            case 'array':
                return self::TYPE_COMPLEX;
                break;
            default:
                return self::TYPE_STRING;
                break;
        }
    }


    /**
     * This method converts a type ID into the default casual name of value type.
     * If the given ID is not found, assume string as default type.
     *
     * @param integer $typeID
     * @return string
     */
    public static function typeIDToTypeName( $typeID )
    {
        switch( $typeID )
        {
            case self::TYPE_INTEGER:
                return 'integer';
                break;
            case self::TYPE_FLOAT:
                return 'float';
                break;
            case self::TYPE_STRING:
                return 'string';
                break;
            case self::TYPE_BOOLEAN:
                return 'boolean';
                break;
            case self::TYPE_COMPLEX:
                return 'complex';
                break;
            default:
                return 'string';
                break;
        }
    }


    /**
     * This method takes a value with its type ID and generates an associative array
     * of four basic condition field-value pairs for the purposes of generating
     * SQL INSERT/UPDATE queries.
     * 
     * The array always is initiated with null values for abstraction db fields
     * (data_int, data_float, data_text). Only one of those fields will get actual 
     * value.
     * 
     * Important! The values must be escaped and quoted HERE!
     *
     * @param integer $typeID
     * @param mixed $value
     * @return array
     */
    public static function valueToDBConditionsByTypeID( $typeID, $value )
    {
        $resultArray = array(
            'type_id' => $typeID,
            'data_int' => 'null',
            'data_float' => 'null',
            'data_text' => 'null',
        );
        switch( $typeID )
        {
            case self::TYPE_INTEGER:
                $resultArray['data_int'] = (integer) $value;
                break;
            case self::TYPE_FLOAT:
                $resultArray['data_float'] = (float) $value;
                break;
            case self::TYPE_STRING:
                $db = eZDB::instance();
                $resultArray['data_text'] = "'" . $db->escapeString( $value ) . "'";
                break;
            case self::TYPE_BOOLEAN:
                $resultArray['data_int'] = (integer) (boolean) $value;
                break;
            case self::TYPE_COMPLEX:
                $db = eZDB::instance();
                $resultArray['data_text'] = "'" . $db->escapeString( serialize( $value ) ) . "'";
                break;
            default:
                $db = eZDB::instance();
                $resultArray['data_text'] = "'" . $db->escapeString( $value ) . "'";
                break;
        }
        return $resultArray;
    }


    /**
     * This method must be used to cast the current preference value to be stored
     * as a session variable. It deals with all value types in its own way.
     *
     * @param integer $typeID
     * @param mixed $value
     * @return mixed
     */
    public static function valueToSessionValueByTypeID( $typeID, $value )
    {
        switch( $typeID )
        {
            case self::TYPE_INTEGER:
                return (integer) $value;
                break;
            case self::TYPE_FLOAT:
                return (float) $value;
                break;
            case self::TYPE_STRING:
                return (string) $value;
                break;
            case self::TYPE_BOOLEAN:
                return (boolean) $value;
                break;
            case self::TYPE_COMPLEX:
                return $value;
                break;
            default:
                return (string) $value;
                break;
        }
    }


    /**
     * This method must be used to cast the default preference value to real
     * usable value. It deals with all value types in its own way.
     *
     * @param integer $typeID
     * @param string $value
     * @return mixed
     */
    public static function defaultValueToValueByTypeID( $typeID, $value )
    {
        switch( $typeID )
        {
            case self::TYPE_INTEGER:
                return (integer) $value;
                break;
            case self::TYPE_FLOAT:
                return (float) $value;
                break;
            case self::TYPE_STRING:
                return (string) $value;
                break;
            case self::TYPE_BOOLEAN:
                return (boolean) $value;
                break;
            case self::TYPE_COMPLEX:
                return unserialize( $value );
                break;
            default:
                return (string) $value;
                break;
        }
    }


    /**
     * This method takes as a parameter an entire DB array query row
     * and returns a real value based on the DB abstraction and type declaration.
     *
     * @param array $dbRow
     * @return mixed
     */
    public static function dbRowToValue( $dbRow )
    {
        switch( $dbRow['type_id'] )
        {
            case self::TYPE_INTEGER:
                return (integer) $dbRow['data_int'];
                break;
            case self::TYPE_FLOAT:
                return (float) $dbRow['data_float'];
                break;
            case self::TYPE_STRING:
                return (string) $dbRow['data_text'];
                break;
            case self::TYPE_BOOLEAN:
                return (boolean) $dbRow['data_int'];
                break;
            case self::TYPE_COMPLEX:
                return unserialize( $dbRow['data_text'] );
                break;
            default:
                return (string) $dbRow['data_text'];
                break;
        }
    }


    /**
     * This method sets preference value.
     *
     * @param string $name
     * @param mixed $value
     * @param string $typeName
     * @param integer $storeUserID
     * @return boolean
     */
    public static function setValue( $name, $value, $typeName, $storeUserID=false )
    {
        $name = trim( $name );

        if ( $name != '' )
        {
            $db = eZDB::instance();
            $typeID = self::typeNameToTypeID( $typeName );

            $isCurrentUser = true;
            if ( $storeUserID === false )
            {
                $userObject = eZUser::currentUser();
            }
            else
            {
                $currentID = eZUser::currentUserID();
                if ( $currentID != $storeUserID )
                {
                    $isCurrentUser = false;
                }

                $userObject = eZUser::fetch( $storeUserID );
                if ( !is_object( $userObject ) )
                {
                    eZDebug::writeError( 'Cannot set preference for user ' . $storeUserID . ', the user does not exist' );
                    return false;
                }
            }

            if ( $storeUserID !== false or $userObject->isLoggedIn() )
            {
                $userID = (integer) $userObject->attribute( 'contentobject_id' );

                $query = "SELECT *
                    FROM selfpreferences 
                    WHERE user_id=" . $userID . " 
                    AND name='" . $db->escapeString( $name ) . "'";
                if ( self::EXT_DEBUG )
                {
                    eZDebug::writeDebug( $query );
                }
                $existingResult = $db->arrayQuery( $query );

                $prepValues = self::valueToDBConditionsByTypeID( $typeID, $value );
                $prepValuesCount = count( $prepValues );
                $cnt = 0;

                if ( count( $existingResult ) > 0 )
                {
                    $preferenceID = (integer) $existingResult[0]['id'];
                    $query = "UPDATE selfpreferences SET ";
                    foreach( $prepValues as $columnName => $columnValue )
                    {
                        $cnt++;
                        $query .= $columnName . "=" . $columnValue;
                        if ( $cnt < $prepValuesCount )
                        {
                            $query .= ",";
                        }
                        $query .= " ";
                    }
                    $query .= "WHERE id=" . $preferenceID;
                    if ( self::EXT_DEBUG )
                    {
                        eZDebug::writeDebug( $query );
                    }
                    $db->query( $query );
                }
                else
                {
                    $query = "INSERT INTO selfpreferences ( name, user_id, type_id, data_int, data_float, data_text ) VALUES (
                        '" . $db->escapeString( $name ) . "', 
                        " . $userID . ",
                        " . $prepValues['type_id'] . ",
                        " . $prepValues['data_int'] . ",
                        " . $prepValues['data_float'] . ",
                        " . $prepValues['data_text'] . " 
                    )";
                    if ( self::EXT_DEBUG )
                    {
                        eZDebug::writeDebug( $query );
                    }
                    $db->query( $query );
                }
            }

            if ( $isCurrentUser )
            {
                self::storeInSession( $name, $value, $typeID );
            }

            return true;
        }
        return false;
    }


    /**
     * Get preference value based on its name (and optionally user).
     *
     * @param string $name
     * @param object $userObject
     * @return mixed
     */
    public static function value( $name, $userObject=false )
    {
        if ( !( $userObject instanceof eZUser ) )
        {
            $userObject = eZUser::currentUser();
        }

        $value = false;
        $typeID = false;

        $http = eZHTTPTool::instance();
        $useCache = ( $userObject->ContentObjectID == $http->sessionVariable( 'eZUserLoggedInID' ) );
        if ( $useCache and self::isStoredInSession( $name ) )
        {
            return self::storedSessionValue( $name );
        }

        if ( $userObject->isAnonymous() )
        {
            return false;
        }

        $db = eZDB::instance();
        $userID = (integer) $userObject->attribute( 'contentobject_id' );
        $query = "SELECT type_id, data_int, data_float, data_text
            FROM selfpreferences 
            WHERE user_id=" . $userID . " 
            AND name='" . $db->escapeString( $name ) . "'";
        if ( self::EXT_DEBUG )
        {
            eZDebug::writeDebug( $query );
        }
        $existingResults = $db->arrayQuery( $query );

        if ( count( $existingResults ) == 1 )
        {
            $value = self::dbRowToValue( $existingResults[0] );
        }
        else
        {
            $ini = eZINI::instance( 'selfpreferences.ini' );
            $defaultValues = $ini->variable( 'GeneralSettings', 'DefaultValues' );
            if ( array_key_exists( $name, $defaultValues ) )
            {

                $valueArray = explode( '::', $defaultValues[$name], 2 );
                $typeName = $valueArray[0];
                $typeID = self::typeNameToTypeID( $typeName );
                $stringValue = $valueArray[1];
                $value = self::defaultValueToValueByTypeID( $typeID, $stringValue );
            }
        }

        if ( $useCache )
        {
            self::storeInSession( $name, $value, $typeID );
        }
        return $value;
    }


    /**
     * Gets a list of all preferences of a user.
     *
     * @param object $userObject
     * @return array
     */
    public static function values( $userObject=false )
    {
        if ( !( $userObject instanceof eZUser ) )
        {
            $userObject = eZUser::currentUser();
        }

        if ( !$userObject->isAnonymous() )
        {
            $http = eZHTTPTool::instance();
            $useCache = ( $userObject->ContentObjectID == $http->sessionVariable( 'eZUserLoggedInID' ) );

            $returnArray = array();
            $userID = (integer) $userObject->attribute( 'contentobject_id' );
            $db = eZDB::instance();
            $query = "SELECT name, type_id, data_int, data_float, data_text
                FROM selfpreferences 
                WHERE user_id=" . $userID . " 
                ORDER BY id";
            $values = $db->arrayQuery( $query );
            if ( self::EXT_DEBUG )
            {
                eZDebug::writeDebug( $query );
            }
            foreach ( $values as $item )
            {
                $value = self::dbRowToValue( $item );
                if ( $useCache )
                {
                    self::storeInSession( $item['name'], $value, $item['type_id'] );
                }
                $returnArray[$item['name']] = $value;
            }
            return $returnArray;
        }
        else
        {
            $http = eZHTTPTool::instance();
            if ( $http->hasSessionVariable( eZPreferences::SESSION_NAME ) )
            {
                return $http->sessionVariable( eZPreferences::SESSION_NAME );
            }
            return array();
        }
    }


    /**
     * Clean up session.
     *
     * @return void
     */
    public static function sessionCleanup()
    {
        $http = eZHTTPTool::instance();
        $http->removeSessionVariable( self::SESSION_NAME );
    }


    /**
     * Stores a preference value in session.
     *
     * @param string $name
     * @param mixed $value
     * @param integer $typeID
     * @return void
     */
    public static function storeInSession( $name, $value, $typeID )
    {
        $http = eZHTTPTool::instance();
        $preferencesInSession = array();
        if ( $http->hasSessionVariable( self::SESSION_NAME ) )
        {
            $preferencesInSession = $http->sessionVariable( self::SESSION_NAME );
        }
        $preferencesInSession[$name] = self::valueToSessionValueByTypeID( $typeID, $value );
        $http->setSessionVariable( self::SESSION_NAME, $preferencesInSession );
    }


    /**
     * Checks if a session by given $name is stored in session.
     *
     * @param string $name
     * @return boolean
     */
    public static function isStoredInSession( $name )
    {
        $http = eZHTTPTool::instance();
        if ( !$http->hasSessionVariable( self::SESSION_NAME ) )
        {
            return false;
        }
        $preferencesInSession = $http->sessionVariable( self::SESSION_NAME );
        return array_key_exists( $name, $preferencesInSession );
    }


    /**
     * Get preference by its name only if it is stored as a session variable. 
     *
     * @param string $name
     * @return mixed
     */
    public static function storedSessionValue( $name )
    {
        $http = eZHTTPTool::instance();
        if ( !$http->hasSessionVariable( self::SESSION_NAME ) )
        {
            return null;
        }
        $preferencesInSession = $http->sessionVariable( self::SESSION_NAME );
        if ( !array_key_exists( $name, $preferencesInSession ) )
        {
            return null;
        }
        return $preferencesInSession[$name];
    }


    /**
     * Purge all preferences from the database.
     *
     * @return void
     */
    public static function cleanup()
    {
        $db = eZDB::instance();
        $query = "DELETE FROM selfpreferences";
        if ( self::EXT_DEBUG )
        {
            eZDebug::writeDebug( $query );
        }
        $db->query( $query );
    }


}






?>