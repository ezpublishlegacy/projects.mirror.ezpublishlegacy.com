<?php /* #?ini charset="utf-8"?

######################################
# PUT THIS FILE IN SETTINGS/OVERRIDE #
######################################

#Rename formulaire_indiv with the name of your current collected form 
[formulaire_indiv]
AvailableMail[]
AvailableMail[FR]=nospam@ez.no;nospam1@ez.no
AvailableMail[US]=nospam@ez.no
AvailableMail[CA]=nospam@ez.no;nospam1@ez.no
AvailableMail[IT]=nospam@ez.no;nospam1@ez.no;nospam@ez.no
#AvailableMail[ES]=
#AvailableMail[BR]=
#AvailableMail[DE]=
#AvailableMail[AT]=
#AvailableMail[CH]=.....
#....
#USE A DEFAULT VALUE
AvailableMail[DEFAULT]=nospam@ez.no;

[form_partenaires]
#....


*/ ?>

