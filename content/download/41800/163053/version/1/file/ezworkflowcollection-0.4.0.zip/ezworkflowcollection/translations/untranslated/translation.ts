<!DOCTYPE TS><TS>
<context>
    <name>extension/ezworkflowcollection</name>
    <message>
        <source>Target nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multipublish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ClassAttribute name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter on class attributes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(only booleans supported)</source>
        <translation type="unfinished"></translation>
    </message>

    <message>
        <source>Subtree Multiplexer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Affected subtree</source>
        <translation type="unfinished"></translation>
    </message
</context>
<context>
    <name>extension/ezworkflowcollection/design/admin/updatestate/list</name>
    <message>
        <source>Contents in state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List contents in state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is no contents in state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update selected content objects for following state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ezworkflowcollection/admin/parts/my/menu</name>
    <message>
        <source>Update states</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ezworkflowcollection/dashboard</name>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
