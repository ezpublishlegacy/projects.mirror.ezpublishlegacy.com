<?php

class ezworkflowcollectionInfo
{
    static function info()
    {
        return array( 'Name' => "ezworkflowcollection",
                      'Version' => "0.4.0",
                      'Copyright' => "Copyright (C) 2010-2011 G. Giunta - O. Portier",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>