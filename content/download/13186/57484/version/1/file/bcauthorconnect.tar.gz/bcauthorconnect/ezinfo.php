<?php

class bcauthorconnectInfo
{
    function info()
    {
        return array(
                     'Name' => "<a href='http://projects.ez.no/bcauthorconnect'>BC Author Connect</a>",
                     'Version' => "1.0.0",
                     'Copyright' => "Copyright (C) 2008 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
                     'Author' => "Brookins Consulting",
                     'License' => "GNU General Public License",
                     'Based on the following third-party software' => array( 'Name' => 'eZ Author Contact',
                                                                              'Author' => 'Łukasz Serwatka',
                                                                              'Version' => '1.0.0 - January 2007',
                                                                              'License' => 'GNU GPL',
                                                                              'For more information' => 'http://ez.no/developer/contribs/applications/ez_author_contact' )

                     );
    }
}
?>
