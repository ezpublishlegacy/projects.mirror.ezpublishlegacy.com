<?php /* #?ini charset="utf-8"?

[DebugJquerySettings]
DebugOutput=enabled

*/ ?>