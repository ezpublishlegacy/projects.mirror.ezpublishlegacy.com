<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for design

[ExtensionSettings]
DesignExtensions[]=arh_jdebug

*/ ?>