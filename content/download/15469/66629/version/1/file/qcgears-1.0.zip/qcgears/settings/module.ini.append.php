<?php /*

[ModuleSettings]
ExtensionRepositories[]=qcgears
ModuleList[]=qcgears


*/ ?>