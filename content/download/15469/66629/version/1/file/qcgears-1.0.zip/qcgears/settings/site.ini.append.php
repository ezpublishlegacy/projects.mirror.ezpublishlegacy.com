<?php /*

[RoleSettings]
PolicyOmitList[]=qcgears/manifest

*/ ?>