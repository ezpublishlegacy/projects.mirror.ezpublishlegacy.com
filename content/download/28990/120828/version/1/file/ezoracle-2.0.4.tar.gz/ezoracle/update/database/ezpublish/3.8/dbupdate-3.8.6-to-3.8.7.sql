UPDATE ezsite_data SET value='3.8.7' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='13' WHERE name='ezpublish-release';