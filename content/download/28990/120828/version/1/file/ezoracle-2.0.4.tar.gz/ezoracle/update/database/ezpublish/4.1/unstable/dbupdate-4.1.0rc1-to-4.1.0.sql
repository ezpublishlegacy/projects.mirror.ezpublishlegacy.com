UPDATE ezsite_data SET value='4.1.0' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='1' WHERE name='ezpublish-release';

DROP TABLE ezimage;

DROP TABLE ezimagevariation;
