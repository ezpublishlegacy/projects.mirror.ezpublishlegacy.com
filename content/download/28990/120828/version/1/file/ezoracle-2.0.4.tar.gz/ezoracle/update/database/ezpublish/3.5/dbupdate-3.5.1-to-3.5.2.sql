UPDATE ezsite_data SET value='3.5.2' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='7' WHERE name='ezpublish-release';

DROP TABLE ezsubtree_expiry;
