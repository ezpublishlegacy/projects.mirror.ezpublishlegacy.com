<?php
//
/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
 * 
 * Add 3 fonction in EZ.
1. it can be used for the page with view_parameter
2. to avoid generet the bad page with error. add <!-- KeywordForAvoidBadCacheGenereted --> in all override template
3. don't add "/content/view/x" in table ezpending_action 
4.// check costum url for if add it in table pending action list
 * 
 */

/*! \file laezstaticcache.php
*/

class LAeZStaticCache extends eZStaticCache
{
	function cacheURL( $url, $nodeID = false, $skipExisting = false, $delay = true )
    {
        // Set default hostname
        $hostname = $this->HostName;
        $staticStorageDir = $this->StaticStorageDir;

        // Check if URL should be cached
        if ( substr_count( $url, "/") >= $this->MaxCacheDepth )
            return false;

        $doCacheURL = false;
        foreach ( $this->CachedURLArray as $cacheURL )
        {
            if ( $url == $cacheURL )
            {
                $doCacheURL = true;
            }
            else if ( strpos( $cacheURL, '*') !== false )
            {
                if ( strpos( $url, str_replace( '*', '', $cacheURL ) ) === 0 )
                {
                    $doCacheURL = true;
                }
            }
        }
        
		$myStaticURLObj = laStaticURLHandler::instance();
    	// filter custom page,don't add it in ezpending_action
        if ( $doCacheURL == false || !$myStaticURLObj->checkURL($url) )
        {
            return false;
        }

        // added for add costum url in table pending action list
		$addition_url = $myStaticURLObj->addURL($url);
        $this->storeCache( $url, $hostname, $staticStorageDir, $addition_url, $skipExisting, $delay );

        return true;
    }

    
	
	function storeCache( $url, $hostname, $staticStorageDir, $alternativeStaticLocations = array(), $skipUnlink = false, $delay = true )
    {
    
    	$ini_la	= eZINI::instance( "lastaticcache.ini" );
    	$useKeyword = $keyword = false;
    	if($ini_la->variable( 'CacheSettings', 'UseKeywordForAvoidBadCacheGenereted' ) == "enabled")
    	{
    		$useKeyword = true;
    		$keyword = "<!-- " . $ini_la->variable( 'CacheSettings', 'KeywordForAvoidBadCacheGenereted' ) . " -->";
    	}
    	$ini = eZINI::instance( 'staticcache.ini');
    	$clearByCronjob = ( $ini->variable( 'CacheSettings', 'CronjobCacheClear' ) == 'enabled' );
        if ( is_array( $this->CachedSiteAccesses ) and count ( $this->CachedSiteAccesses ) )
        {
            $dirs = array();
            foreach ( $this->CachedSiteAccesses as $dir )
            {
                $dirs[] = '/' . $dir ;
            }
        }
        else
        {
            $dirs = array ('');
        }
        $http = eZHTTPTool::instance();

        foreach ( $dirs as $dir )
        {
            $cacheFiles = array();
            if ( !is_dir( $staticStorageDir . $dir ) )
            {
                eZDir::mkdir( $staticStorageDir . $dir, 0777, true );
            }
			//$cacheFiles array($old_url, $cacheFiles); 
            $cacheFiles[] = array( $url, $this->buildCacheFilename( $staticStorageDir, $dir . $url ) );
            foreach ( $alternativeStaticLocations as $location )
            {
                $cacheFiles[] = array( $location, $this->buildCacheFilename(  $staticStorageDir, $dir . $location ));
            }

            /* Store new content */
            $content = false;
            foreach ( $cacheFiles as $cacheFile )
            {
            	$org_url = $cacheFile[0];
                $file = $cacheFile[1];
                if ( !$skipUnlink || !file_exists( $file ) )
                {
                    $fileName = "http://$hostname$dir$org_url";
                    if ( $delay )
                    {
                    	if( !$clearByCronjob && $useKeyword && $keyword && strpos($content, $keyword)=== false )
                    	{
                    		eZDebug::writeNotice( "Could not grab content (from $fileName), is the hostname correct and Apache running?",
                                                  'Static Cache' );
                    		continue;
                    	}
                    	else
                    	{
                        	$this->addAction( 'store', array( $file, $fileName ) );
                    	}
                    }
                    else
                    {
                        /* Generate content, if required */
                        if ( $content === false )
                        {
                            $content = $http->getDataByURL( $fileName, false, self::USER_AGENT );
                        }
                        if ( $content === false )
                        {
                            eZDebug::writeNotice( "Could not grab content (from $fileName), is the hostname correct and Apache running?",
                                                  'Static Cache' );
                        }
                        elseif( $useKeyword && $keyword && strpos($content, $keyword)=== false)
                        {
                        //if we can't find the keyword in template, the page is created with error. so don't add it in cache
							eZDebug::writeError( $fileName." hav'nt ".$keyword,'Static Cache' );
                        }
                        else
                        {
                            eZStaticCache::storeCachedFile( $file, $content );
                        }
                    }
                }
            }
        }
}
}


?>
