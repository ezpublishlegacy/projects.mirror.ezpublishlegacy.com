<?php
/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
/*! \file lastaticcache_cleanup.php
*/


if ( !$isQuiet )
{
    $cli->output( "Starting processing pending static cache cleanups" );
}
$ini	= eZINI::instance( "lastaticcache.ini" );
$useKeyword = $keyword = false;
if($ini->variable( 'CacheSettings', 'UseKeywordForAvoidBadCacheGenereted' ) == "enabled")
{
	$useKeyword = true;
	$keyword = $ini->variable( 'CacheSettings', 'KeywordForAvoidBadCacheGenereted' );
}

$db = eZDB::instance();

$offset = 0;
$limit = 20;
$doneDestList = array();

while( true )
{
    $entries = $db->arrayQuery( "SELECT param FROM ezpending_actions WHERE action = 'static_store'",
                                array( 'limit' => $limit,
                                       'offset' => $offset ) );
    $inSQL = '';

    if ( is_array( $entries ) and count( $entries ) )
    {
        $db->begin();
        foreach ( $entries as $entry )
        {
            $param = $entry['param'];
            $destination = explode( ',', $param );
            $source = $destination[1];
            $destination = $destination[0];
            $success = false;
            if ( !isset( $doneDestList[$destination] ) )
            {
                if ( !isset( $fileContentCache[$source] ) )
                {
                    if ( !$isQuiet )
                    {
                        $cli->output( "\tFetching URL: $source" );
                    }
	                $fileContentCache[$source] = file_get_contents( $source );
                }
                if ( $fileContentCache[$source] === false )
                {
                    $cli->output( "\tCould not grab content, is the hostname correct and Apache running?" );
                    $db->query( "update ezpending_actions set action='static_error' WHERE action='static_store' AND param = '".$param."'" );	
                }
                elseif( $useKeyword && $keyword && strpos($fileContentCache[$source], $keyword)=== false)
                {
                        //if we can't find the keyword in template, the page is created with error. so don't add it in cache
					$db->query( "update ezpending_actions set action='static_error' WHERE action='static_store' AND param = '".$param."'" );	
                	eZDebug::writeError( $source." hav'nt ".$keyword,'Static Cache' );
                }
                else
                {
                    LAeZStaticCache::storeCachedFile( $destination, $fileContentCache[$source] );
                    $doneDestList[$destination] = 1;
                    $success = true;
                }
            }
            else
            {
                $success = true;
            }

            if ( $success )
            {
                if ( $inSQL != '' )
                {
                    $inSQL .= ', ';
                }
                $inSQL .= '\'' . $param . '\'';
            }
        }
		if($inSQL)
        $db->query( "DELETE FROM ezpending_actions WHERE action='static_store' AND param IN ($inSQL)" );
        $db->commit();
    }
    else
    {
        break; // No valid result from ezpending_actions
    }
}

if ( !$isQuiet )
{
    $cli->output( "Done" );
}

?>
