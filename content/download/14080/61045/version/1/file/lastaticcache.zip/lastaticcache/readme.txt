/**
 * @author      LIU Bin <liubin@live.fr>
 * 
 /

Requirement
Ez4.0.1 

Description
 override EZ staticcache and Add 3 fonctions :
1. it can be used for the page with view_parameter. add costum url in table ezpending_actions by lastaticcache.ini

Example :
http://mysite.com/my_node
http://mysite.com/my_node/(my_sort)/asc
http://mysite.com/my_node/(my_sort)/desc
When the my_node edited, the tree files static cache will be generated.
2. to avoid generet the bad page with error (ez error or timeout ...).
check if a custom keyword exist in the cache file. if no keyword, it means the page isn't genereted correctly, stop this page cache genereted.
The keyword should be added in all override template.
Example : : <!--lagardere-->

3. Don't add "/content/view/x" in table ezpending_action. /content/view/x is no useful.
4. filter custom page,don't add it in ezpending_action

Install
1. add ActiveExtensions[]=lastaticcache in site.ini
2. make you custom staticurlhandler. by default, it use the lastaticurlhandler.
3. add the keyword in all your override template.
4. config staticcache.ini and lastaticcache.ini
5. excute php bin/php/ezpgenerateautoloads.php
6. copy extension/lastaticcache/bin/php/lamakestaticcache.php in bin/php/lamakestaticcache.php of the root
7. excute "php bin/php/lamakestaticcache.php" for the first time.
8. add cronjob lacleancache in your cronjob (php runcronjob.php lacleancache -s siteaccess )
9. hack in kernel/classes/ezcontentcachemanager.php
and kernel/classes/ezcontentobjecttreenode.php
$staticCache = new eZStaticCache();
like
$staticCache = new LAeZStaticCache();

PS :
If you use more than one siteaccess
create staticcache.ini in each siteaccess
Example :
2 siteaccess : mysite and mysite_iphone

#for mysite staticcache.ini
[CacheSettings]
HostName=www.mysite.fr
StaticStorageDir=static
MaxCacheDepth=10
CachedSiteAccesses[]
CachedURLArray[]
CachedURLArray[]=all the site 
 
#for mysite_iphone staticcache.ini
[CacheSettings]
HostName=iphone.mysite.fr or www.mysite.fr
StaticStorageDir=static-iphone
MaxCacheDepth=10
CachedSiteAccesses[]=iphone
CachedURLArray[]
CachedURLArray[]=only for iphone
