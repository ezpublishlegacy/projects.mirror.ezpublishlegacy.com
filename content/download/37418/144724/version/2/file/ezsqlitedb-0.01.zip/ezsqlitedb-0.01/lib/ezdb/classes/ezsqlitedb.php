<?php
//
// $Id$
//
// Definition of eZSQLite class
//
// Copyright (C) 2004 Kai Duebbert <public [at] duebbert [.] de>.  All rights reserved.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, US
//

/*!
  \class eZSQLite eZSQLite.php
  \ingroup eZDB
  \brief The eZSQLite class provides SQLite implementation of the database interface.

  eZSQLite is the SQLite implementation of eZDB.
  \sa eZDB
*/

include_once( "lib/ezutils/classes/ezdebug.php" );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezdb/classes/ezdbinterface.php" );

class eZSQLiteDB extends eZDBInterface
{
    /*!
      Create a new eZSQLite object and connects to the database backend.
    */
    function eZSQLiteDB( $parameters )
    {
        $this->eZDBInterface( $parameters );

        if ( !extension_loaded( 'sqlite' ) )
        {
            if ( function_exists( 'eZAppendWarningItem' ) )
            {
                eZAppendWarningItem( array( 'error' => array( 'type' => 'ezdb',
                                                              'number' => EZ_DB_ERROR_MISSING_EXTENSION ),
                                            'text' => 'SQLite extension was not found, the DB handler will not be initialized.' ) );
                $this->IsConnected = false;
                return;
            }
        }

        $socketPath = $this->socketPath();

        /// Connect to master server
        if ( $this->DBWriteConnection == false )
        {
            $connection = $this->connect( $this->Server, $this->DB, $this->User, $this->Password, $socketPath );
            if ( $this->IsConnected )
            {
                $this->DBWriteConnection = $connection;
            }
        }

        // Connect to slave
        if ( $this->DBConnection == false )
        {
            if ( $this->UseSlaveServer === true )
            {
                $connection = $this->connect( $this->SlaveServer, $this->SlaveDB, $this->SlaveUser, $this->SlavePassword, $socketPath );
            }
            else
            {
                $connection =& $this->DBWriteConnection;
            }

            if ( $connection and $this->DBWriteConnection )
            {
                $this->DBConnection = $connection;
                $this->IsConnected = true;
            }
        }

        eZDebug::createAccumulatorGroup( 'SQLite_total', 'SQLite Total' );
    }

    /*!
     \private
     Opens a new connection to a SQLite database and returns the connection
    */
    function &connect( $server, $db, $user, $password, $socketPath )
    {
        $connection = false;

        if ( $this->UsePersistentConnection == true )
        {
            $connection = @sqlite_popen( $server );
        }
        else
        {
            $connection = @SQLite_open( $server );
        }
        $dbErrorText = SQLite_error_string( sqlite_last_error( $connection ) );
        $maxAttempts = $this->connectRetryCount();
        $waitTime = $this->connectRetryWaitTime();
        $numAttempts = 1;
        while ( $connection == false and $numAttempts <= $maxAttempts )
        {
            sleep( $waitTime );
            if ( $this->UsePersistentConnection == true )
            {
                $connection = @SQLite_popen( $this->Server );
            }
            else
            {
                $connection = @SQLite_open( $this->Server );
            }
            $numAttempts++;
        }
        $this->setError();

        $this->IsConnected = true;

        if ( $connection == false )
        {
            eZDebug::writeError( "Connection error: Couldn't connect to database. Please try again later or inform the system administrator.\n$dbErrorText", "eZSQLite" );
            $this->IsConnected = false;
        }

        /* if ( $this->IsConnected && $db != null )
        {
            $ret = @SQLite_select_db( $db, $connection );
            $this->setError();
            if ( !$ret )
            {
                eZDebug::writeError( "Connection error: " . @SQLite_errno( $connection ) . ": " . @sqlite_error_string( $connection ), "eZSQLite" );
                $this->IsConnected = false;
            }
        }*/
        return $connection;
    }

    /*!
     \reimp
    */
    function databaseName()
    {
        return 'SQLite';
    }

    /*!
     \reimp
    */
    function &query( $sql )
    {
        if ( $this->IsConnected )
        {
            if ( $this->OutputSQL )
            {
	            eZDebug::accumulatorStart( 'SQLite_query', 'SQLite_total', 'SQLite_queries' );
                $this->startTimer();
            }

            $result =& SQLite_query( $sql, $this->DBConnection );
            if ( $this->RecordError )
                $this->setError();

            if ( $this->OutputSQL )
            {
                $this->endTimer();
				eZDebug::accumulatorStop( 'SQLite_query' );
                $num_rows = SQLite_num_rows( $result );
                $this->reportQuery( 'eZSQLite', $sql, $num_rows, $this->timeTaken() );
            }

            if ( $result )
            {
                return $result;
            }
            else
            {
                eZDebug::writeError( "Query error: " . sqlite_error_string( sqlite_last_error( $connection ) ) . ". Query: ". $sql, "eZSQLite"  );
                $this->RecordError = true;
                return false;
            }
        }
        else
        {
            eZDebug::writeError( "Trying to do a query without being connected to a database!", "eZSQLite"  );
            return false;
        }


    }

    /*!
     \reimp
    */
    function &arrayQuery( $sql, $params = array() )
    {
        $retArray = array();
        if ( $this->IsConnected )
        {
            $limit = false;
            $offset = 0;
            $column = false;
            // check for array parameters
            if ( is_array( $params ) )
            {
                if ( isset( $params["limit"] ) and is_numeric( $params["limit"] ) )
                    $limit = $params["limit"];

                if ( isset( $params["offset"] ) and is_numeric( $params["offset"] ) )
                    $offset = $params["offset"];

                if ( isset( $params["column"] ) and is_numeric( $params["column"] ) )
                    $column = $params["column"];
            }

            if ( $limit !== false and is_numeric( $limit ) )
            {
                $sql .= "\nLIMIT $offset, $limit ";
            }
            else if ( $offset !== false and is_numeric( $offset ) and $offset > 0 )
            {
                $sql .= "\nLIMIT $offset, -1 ";
            }
            $result =& $this->query( $sql );

            if ( $result == false )
            {
                $this->reportQuery( 'eZSQLite', $sql, false, false );
                return false;
            }

            $numRows = SQLite_num_rows( $result );
            if ( $numRows > 0 )
            {
                if ( !is_string( $column ) )
                {
                    eZDebug::accumulatorStart( 'SQLite_loop', 'SQLite_total', 'Looping result' );
                    for ( $i=0; $i < $numRows; $i++ )
                    {
                        if ( $this->InputTextCodec )
                        {
                            $tmp_row =& SQLite_fetch_array( $result, SQLITE_ASSOC );
                            $tmp_row = $this->sqlite_clean_keys( $tmp_row );
                            unset( $conv_row );
                            $conv_row = array();
                            reset( $tmp_row );
                            while( ( $key = key( $tmp_row ) ) !== null )
                            {
                                eZDebug::accumulatorStart( 'SQLite_conversion', 'SQLite_total', 'String conversion in SQLite' );
                                $conv_row[$key] =& $this->OutputTextCodec->convertString( $tmp_row[$key] );
                                eZDebug::accumulatorStop( 'SQLite_conversion' );
                                next( $tmp_row );
                            }
                            $retArray[$i + $offset] =& $conv_row;
                        }
                        else
                        {
                            $retArray[$i + $offset] =& $this->sqlite_clean_keys( SQLite_fetch_array( $result, SQLITE_ASSOC ) );
                    	}
                    }
                    eZDebug::accumulatorStop( 'SQLite_loop' );

                }
                else
                {
                    eZDebug::accumulatorStart( 'SQLite_loop', 'SQLite_total', 'Looping result' );
                    for ( $i=0; $i < $numRows; $i++ )
                    {
                        $tmp_row =& SQLite_fetch_array( $result, SQLITE_ASSOC );
                        $tmp_row = $this->sqlite_clean_keys( $tmp_row );
                        if ( $this->InputTextCodec )
                        {
                            eZDebug::accumulatorStart( 'SQLite_conversion', 'SQLite_total', 'String conversion in SQLite' );
                            $retArray[$i + $offset] =& $this->OutputTextCodec->convertString( $tmp_row[$column] );
                            eZDebug::accumulatorStop( 'SQLite_conversion' );
                        }
                        else
                            $retArray[$i + $offset] =& $tmp_row[$column];
                    }
                    eZDebug::accumulatorStop( 'SQLite_loop' );
                }
            }
        }
        return $retArray;
    }

    /*!
     \private
    */
    function subString( $string, $from, $len = null )
    {
        if ( $len == null )
        {
            return " substring( $string from $from ) ";
        }else
        {
            return " substring( $string from $from for $len ) ";
        }
    }

    function concatString( $strings = array() )
    {
        $str = implode( "," , $strings );
        return " concat( $str  ) ";
    }

    function md5( $str )
    {
        return " MD5( $str ) ";
    }

    /*!
     \reimp
    */
    function supportedRelationTypeMask()
    {
        return EZ_DB_RELATION_TABLE_BIT;
    }

    /*!
     \reimp
    */
    function supportedRelationTypes()
    {
        return array( EZ_DB_RELATION_TABLE );
    }

    /*!
     \reimp
    */
    function relationCounts( $relationMask )
    {
        if ( $relationMask & EZ_DB_RELATION_TABLE_BIT )
            return $this->relationCount();
        else
            return 0;
    }

    /*!
      \reimp
    */
    function relationCount( $relationType = EZ_DB_RELATION_TABLE )
    {
        if ( $relationType != EZ_DB_RELATION_TABLE )
        {
            eZDebug::writeError( "Unsupported relation type '$relationType'", 'eZSQLite::relationCount' );
            return false;
        }
        $count = false;
        if ( $this->IsConnected )
        {
            $result =& $this->SQLite_list_tables( $this->DBConnection );
            $count = count( $result );
            // SQLite_free_result( $result );
        }
        return $count;
    }

    /*!
      \reimp
    */
    function relationList( $relationType = EZ_DB_RELATION_TABLE )
    {
        if ( $relationType != EZ_DB_RELATION_TABLE )
        {
            eZDebug::writeError( "Unsupported relation type '$relationType'", 'eZSQLite::relationList' );
            return false;
        }
        $tables = array();
        if ( $this->IsConnected )
        {
            $tables =& $this->sqlite_list_tables( $this->DBConnection );
            /*$count = SQLite_num_rows( $result );
            for ( $i = 0; $i < $count; ++ $i )
            {
                $tables[] = SQLite_tablename( $result, $i );
            }
            SQLite_free_result( $result ); */
        }
        return $tables;
    }

    /*!
     \reimp
    */
    function eZTableList()
    {
        $tables = array();
        if ( $this->IsConnected )
        {
            $result =& $this->sqlite_list_tables( $this->DBConnection );
            $count = count( $result );
            for ( $i = 0; $i < $count; ++ $i )
            {
                $tableName = $result[$i];
                if ( substr( $tableName, 0, 2 ) == 'ez' )
                {
                    $tables[$tableName] = EZ_DB_RELATION_TABLE;
                }
            }
            // SQLite_free_result( $result );
        }
        return $tables;
    }

    /*!
      \reimp
    */
    function removeRelation( $relationName, $relationType )
    {
        $relationTypeName = $this->relationName( $relationType );
        if ( !$relationTypeName )
        {
            eZDebug::writeError( "Unknown relation type '$relationType'", 'eZSQLite::removeRelation' );
            return false;
        }

        if ( $this->IsConnected )
        {
            $sql = "DROP $relationTypeName $relationName";
            return $this->query( $sql );
        }
        return false;
    }

    /*!
     \reimp
    */
    function lock( $table )
    {
        /* if ( $this->IsConnected )
        {
            if ( is_array( $table ) )
            {
                $lockQuery = "LOCK TABLES";
                $first = true;
                foreach( array_keys( $table ) as $tableKey )
                {
                    if ( $first == true )
                        $first = false;
                    else
                        $lockQuery .= ",";
                    $lockQuery .= " " . $table[$tableKey]['table'] . " WRITE";
                }
                $this->query( $lockQuery );
            }
            else
            {
                $this->query( "LOCK TABLES $table WRITE" );
            }
        } */
    }

    /*!
     \reimp
    */
    function unlock()
    {
        /* if ( $this->IsConnected )
        {
            $this->query( "UNLOCK TABLES" );
        } */
    }

    /*!
     \reimp
    */
    function begin()
    {
        if ( $this->IsConnected )
        {
            $this->query( "BEGIN" );
        }
    }

    /*!
     \reimp
    */
    function commit()
    {
        if ( $this->IsConnected )
        {
            $this->query( "COMMIT" );
        }
    }

    /*!
     \reimp
    */
    function rollback()
    {
        if ( $this->IsConnected )
        {
            $this->query( "ROLLBACK" );
        }
    }

    /*!
     \reimp
    */
    function lastSerialID( $table = false, $column = false )
    {
        if ( $this->IsConnected )
        {
            $id = SQLite_last_insert_rowid( $this->DBWriteConnection );
            return $id;
        }
        else
            return false;
    }

    /*!
     \reimp
    */
    function &escapeString( $str )
    {
        return SQLite_escape_string( $str );
    }

    /*!
     \reimp
    */
    function close()
    {
        if ( $this->IsConnected )
        {
            @SQLite_close( $this->DBConnection );
            @SQLite_close( $this->DBWriteConnection );
        }
    }

    /*!
     \reimp
    */
    function createDatabase( $dbName )
    {
        if ( $this->DBConnection != false )
        {
            // SQLite_open( $dbName, $this->DBConnection );
            eZDebug::writeError( "TODO: Not sure what to do with createDatabase '$dbName'", 'eZSQLite::createDatabase' );
            // $this->setError();
        }
    }

    /*!
     \reimp
    */
    function setError()
    {
        if ( $this->DBConnection )
        {
            $this->ErrorNumber = SQLite_last_error( $this->DBConnection );
	        $this->ErrorMessage = sqlite_error_string( $this->ErrorNumber );
        }
        else
        {
	        $this->ErrorNumber = -1;
            $this->ErrorMessage = "Error: No database connection!";

        }
    }

    /*!
     \reimp
    */
    function availableDatabases()
    {
		// SQLite only has one database and we have put that name in Server.
		// Should maybe be changed in the future.
        return array( $this->Server );
    }

    /*!
     \reimp
    */
    function databaseServerVersion()
    {
        $versionInfo = SQLite_libversion();

        $versionArray = explode( '.', $versionInfo );

        return array( 'string' => $versionInfo,
                      'values' => $versionArray );
    }

    /*!
     \reimp
    */
    function databaseClientVersion()
    {
        $versionInfo = SQLite_libversion();

        $versionArray = explode( '.', $versionInfo );

        return array( 'string' => $versionInfo,
                      'values' => $versionArray );
    }

    /*!
     \reimp
    */
    function isCharsetSupported( $charset )
    {
        if ( $charset == 'utf-8' )
        {
            $encodingInfo = sqlite_libencoding();
            if ( $encodingInfo == $charset )
                return true;
            return false;
        }
        else
            return true;
    }

    function sqlite_list_tables (&$dblink) {
       $tables = array ();

       $sql = "SELECT name FROM sqlite_master WHERE (type = 'table')";
       if ($res = sqlite_query ($dblink, $sql)) {
           while (sqlite_has_more($res)) {
               $tables[] = sqlite_fetch_single($res);
           }
       }

       return $tables;
   }

   function sqlite_clean_keys($array)
	{
	  foreach ($array as $key => $value) {

	   //if you want to keep the old element with its key remove the following line
	   //unset($array[$key]);

	   //now we clean the key from the dot and tablename (alise) and set the new element
	     $key = substr($key, strpos($key, '.')+1);
	     $array[$key] = $value;
	  }
	  return $array;
	}


    /// \privatesection
}

?>
