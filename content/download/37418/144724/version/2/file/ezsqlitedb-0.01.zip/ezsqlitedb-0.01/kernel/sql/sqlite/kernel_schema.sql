-- 
-- Created by SQL::Translator::Producer::SQLite
-- Created on Sat Jul  3 16:36:09 2004
-- 
BEGIN TRANSACTION;

--
-- Table: ezapprove_items
--
CREATE TABLE ezapprove_items (
  id INTEGER PRIMARY KEY NOT NULL,
  workflow_process_id int(11) NOT NULL DEFAULT '0',
  collaboration_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezbasket
--
CREATE TABLE ezbasket (
  id INTEGER PRIMARY KEY NOT NULL,
  session_id varchar(255) NOT NULL DEFAULT '',
  productcollection_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezbinaryfile
--
CREATE TABLE ezbinaryfile (
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  version int(11) NOT NULL DEFAULT '0',
  filename varchar(255) NOT NULL DEFAULT '',
  original_filename varchar(255) NOT NULL DEFAULT '',
  mime_type varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (contentobject_attribute_id, version)
);

--
-- Table: ezcollab_group
--
CREATE TABLE ezcollab_group (
  id INTEGER PRIMARY KEY NOT NULL,
  parent_group_id int(11) NOT NULL DEFAULT '0',
  depth int(11) NOT NULL DEFAULT '0',
  path_string varchar(255) NOT NULL DEFAULT '',
  is_open int(11) NOT NULL DEFAULT '1',
  user_id int(11) NOT NULL DEFAULT '0',
  title varchar(255) NOT NULL DEFAULT '',
  priority int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcollab_item
--
CREATE TABLE ezcollab_item (
  id INTEGER PRIMARY KEY NOT NULL,
  type_identifier varchar(40) NOT NULL DEFAULT '',
  creator_id int(11) NOT NULL DEFAULT '0',
  status int(11) NOT NULL DEFAULT '1',
  data_text1 longtext(4294967295) NOT NULL,
  data_text2 longtext(4294967295) NOT NULL,
  data_text3 longtext(4294967295) NOT NULL,
  data_int1 int(11) NOT NULL DEFAULT '0',
  data_int2 int(11) NOT NULL DEFAULT '0',
  data_int3 int(11) NOT NULL DEFAULT '0',
  data_float1 float(8,2) NOT NULL DEFAULT '0',
  data_float2 float(8,2) NOT NULL DEFAULT '0',
  data_float3 float(8,2) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcollab_item_group_link
--
CREATE TABLE ezcollab_item_group_link (
  collaboration_id int(11) NOT NULL DEFAULT '0',
  group_id int(11) NOT NULL DEFAULT '0',
  user_id int(11) NOT NULL DEFAULT '0',
  is_read int(11) NOT NULL DEFAULT '0',
  is_active int(11) NOT NULL DEFAULT '1',
  last_read int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (collaboration_id, group_id, user_id)
);

--
-- Table: ezcollab_item_message_link
--
CREATE TABLE ezcollab_item_message_link (
  id INTEGER PRIMARY KEY NOT NULL,
  collaboration_id int(11) NOT NULL DEFAULT '0',
  participant_id int(11) NOT NULL DEFAULT '0',
  message_id int(11) NOT NULL DEFAULT '0',
  message_type int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcollab_item_participant_link
--
CREATE TABLE ezcollab_item_participant_link (
  collaboration_id int(11) NOT NULL DEFAULT '0',
  participant_id int(11) NOT NULL DEFAULT '0',
  participant_type int(11) NOT NULL DEFAULT '1',
  participant_role int(11) NOT NULL DEFAULT '1',
  is_read int(11) NOT NULL DEFAULT '0',
  is_active int(11) NOT NULL DEFAULT '1',
  last_read int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (collaboration_id, participant_id)
);

--
-- Table: ezcollab_item_status
--
CREATE TABLE ezcollab_item_status (
  collaboration_id int(11) NOT NULL DEFAULT '0',
  user_id int(11) NOT NULL DEFAULT '0',
  is_read int(11) NOT NULL DEFAULT '0',
  is_active int(11) NOT NULL DEFAULT '1',
  last_read int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (collaboration_id, user_id)
);

--
-- Table: ezcollab_notification_rule
--
CREATE TABLE ezcollab_notification_rule (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id varchar(255) NOT NULL DEFAULT '',
  collab_identifier varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezcollab_profile
--
CREATE TABLE ezcollab_profile (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  main_group int(11) NOT NULL DEFAULT '0',
  data_text1 longtext(4294967295) NOT NULL,
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcollab_simple_message
--
CREATE TABLE ezcollab_simple_message (
  id INTEGER PRIMARY KEY NOT NULL,
  message_type varchar(40) NOT NULL DEFAULT '',
  creator_id int(11) NOT NULL DEFAULT '0',
  data_text1 longtext(4294967295) NOT NULL,
  data_text2 longtext(4294967295) NOT NULL,
  data_text3 longtext(4294967295) NOT NULL,
  data_int1 int(11) NOT NULL DEFAULT '0',
  data_int2 int(11) NOT NULL DEFAULT '0',
  data_int3 int(11) NOT NULL DEFAULT '0',
  data_float1 float(8,2) NOT NULL DEFAULT '0',
  data_float2 float(8,2) NOT NULL DEFAULT '0',
  data_float3 float(8,2) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcontent_translation
--
CREATE TABLE ezcontent_translation (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) NOT NULL DEFAULT '',
  locale varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezcontentbrowsebookmark
--
CREATE TABLE ezcontentbrowsebookmark (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  node_id int(11) NOT NULL DEFAULT '0',
  name varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezcontentbrowserecent
--
CREATE TABLE ezcontentbrowserecent (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  node_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  name varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezcontentclass
--
CREATE TABLE ezcontentclass (
  id int NOT NULL,
  version int(11) NOT NULL DEFAULT '0',
  name varchar(255) DEFAULT NULL,
  identifier varchar(50) NOT NULL DEFAULT '',
  contentobject_name varchar(255) DEFAULT NULL,
  creator_id int(11) NOT NULL DEFAULT '0',
  modifier_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  remote_id varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (id, version)
);

--
-- Table: ezcontentclass_attribute
--
CREATE TABLE ezcontentclass_attribute (
  id int NOT NULL,
  version int(11) NOT NULL DEFAULT '0',
  contentclass_id int(11) NOT NULL DEFAULT '0',
  identifier varchar(50) NOT NULL DEFAULT '',
  name varchar(255) NOT NULL DEFAULT '',
  data_type_string varchar(50) NOT NULL DEFAULT '',
  is_searchable int(11) NOT NULL DEFAULT '0',
  is_required int(11) NOT NULL DEFAULT '0',
  placement int(11) NOT NULL DEFAULT '0',
  data_int1 int(11) DEFAULT NULL,
  data_int2 int(11) DEFAULT NULL,
  data_int3 int(11) DEFAULT NULL,
  data_int4 int(11) DEFAULT NULL,
  data_float1 float(8,2) DEFAULT NULL,
  data_float2 float(8,2) DEFAULT NULL,
  data_float3 float(8,2) DEFAULT NULL,
  data_float4 float(8,2) DEFAULT NULL,
  data_text1 varchar(50) DEFAULT NULL,
  data_text2 varchar(50) DEFAULT NULL,
  data_text3 varchar(50) DEFAULT NULL,
  data_text4 varchar(255) DEFAULT NULL,
  data_text5 longtext(4294967295),
  is_information_collector int(11) NOT NULL DEFAULT '0',
  can_translate int(11) DEFAULT '1',
  PRIMARY KEY (id, version)
);

--
-- Table: ezcontentclass_classgroup
--
CREATE TABLE ezcontentclass_classgroup (
  contentclass_id int(11) NOT NULL DEFAULT '0',
  contentclass_version int(11) NOT NULL DEFAULT '0',
  group_id int(11) NOT NULL DEFAULT '0',
  group_name varchar(255) DEFAULT NULL,
  PRIMARY KEY (contentclass_id, contentclass_version, group_id)
);

--
-- Table: ezcontentclassgroup
--
CREATE TABLE ezcontentclassgroup (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) DEFAULT NULL,
  creator_id int(11) NOT NULL DEFAULT '0',
  modifier_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcontentobject
--
CREATE TABLE ezcontentobject (
  id INTEGER PRIMARY KEY NOT NULL,
  owner_id int(11) NOT NULL DEFAULT '0',
  section_id int(11) NOT NULL DEFAULT '0',
  contentclass_id int(11) NOT NULL DEFAULT '0',
  name varchar(255) DEFAULT NULL,
  current_version int(11) DEFAULT NULL,
  is_published int(11) DEFAULT NULL,
  published int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  status int(11) DEFAULT '0',
  remote_id varchar(100) DEFAULT NULL
);

--
-- Table: ezcontentobject_attribute
--
CREATE TABLE ezcontentobject_attribute (
  id int NOT NULL,
  language_code varchar(20) NOT NULL DEFAULT '',
  version int(11) NOT NULL DEFAULT '0',
  contentobject_id int(11) NOT NULL DEFAULT '0',
  contentclassattribute_id int(11) NOT NULL DEFAULT '0',
  data_text longtext(4294967295),
  data_int int(11) DEFAULT NULL,
  data_float float(8,2) DEFAULT NULL,
  attribute_original_id int(11) DEFAULT '0',
  sort_key_int int(11) NOT NULL DEFAULT '0',
  sort_key_string varchar(255) NOT NULL DEFAULT '',
  data_type_string varchar(50) DEFAULT '',
  PRIMARY KEY (id, version)
);

--
-- Table: ezcontentobject_link
--
CREATE TABLE ezcontentobject_link (
  id INTEGER PRIMARY KEY NOT NULL,
  from_contentobject_id int(11) NOT NULL DEFAULT '0',
  from_contentobject_version int(11) NOT NULL DEFAULT '0',
  to_contentobject_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezcontentobject_name
--
CREATE TABLE ezcontentobject_name (
  contentobject_id int(11) NOT NULL DEFAULT '0',
  name varchar(255) DEFAULT NULL,
  content_version int(11) NOT NULL DEFAULT '0',
  content_translation varchar(20) NOT NULL DEFAULT '',
  real_translation varchar(20) DEFAULT NULL,
  PRIMARY KEY (contentobject_id, content_version, content_translation)
);

--
-- Table: ezcontentobject_tree
--
CREATE TABLE ezcontentobject_tree (
  node_id INTEGER PRIMARY KEY NOT NULL,
  parent_node_id int(11) NOT NULL DEFAULT '0',
  contentobject_id int(11) DEFAULT NULL,
  contentobject_version int(11) DEFAULT NULL,
  contentobject_is_published int(11) DEFAULT NULL,
  depth int(11) NOT NULL DEFAULT '0',
  path_string varchar(255) NOT NULL DEFAULT '',
  sort_field int(11) DEFAULT '1',
  sort_order int(11) DEFAULT '1',
  priority int(11) NOT NULL DEFAULT '0',
  path_identification_string longtext(4294967295),
  main_node_id int(11) DEFAULT NULL,
  modified_subnode int(11) DEFAULT '0',
  remote_id varchar(100) NOT NULL DEFAULT ''
);

--
-- Table: ezcontentobject_version
--
CREATE TABLE ezcontentobject_version (
  id INTEGER PRIMARY KEY NOT NULL,
  contentobject_id int(11) DEFAULT NULL,
  creator_id int(11) NOT NULL DEFAULT '0',
  version int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  status int(11) NOT NULL DEFAULT '0',
  workflow_event_pos int(11) DEFAULT '0',
  user_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezdiscountrule
--
CREATE TABLE ezdiscountrule (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezdiscountsubrule
--
CREATE TABLE ezdiscountsubrule (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) NOT NULL DEFAULT '',
  discountrule_id int(11) NOT NULL DEFAULT '0',
  discount_percent float(8,2) DEFAULT NULL,
  limitation char(1) DEFAULT NULL
);

--
-- Table: ezdiscountsubrule_value
--
CREATE TABLE ezdiscountsubrule_value (
  discountsubrule_id int(11) NOT NULL DEFAULT '0',
  value int(11) NOT NULL DEFAULT '0',
  issection int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (discountsubrule_id, value, issection)
);

--
-- Table: ezenumobjectvalue
--
CREATE TABLE ezenumobjectvalue (
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  contentobject_attribute_version int(11) NOT NULL DEFAULT '0',
  enumid int(11) NOT NULL DEFAULT '0',
  enumelement varchar(255) NOT NULL DEFAULT '',
  enumvalue varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (contentobject_attribute_id, contentobject_attribute_version, enumid)
);

--
-- Table: ezenumvalue
--
CREATE TABLE ezenumvalue (
  id int NOT NULL,
  contentclass_attribute_id int(11) NOT NULL DEFAULT '0',
  contentclass_attribute_version int(11) NOT NULL DEFAULT '0',
  enumelement varchar(255) NOT NULL DEFAULT '',
  enumvalue varchar(255) NOT NULL DEFAULT '',
  placement int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id, contentclass_attribute_id, contentclass_attribute_version)
);

--
-- Table: ezforgot_password
--
CREATE TABLE ezforgot_password (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  hash_key varchar(32) NOT NULL DEFAULT '',
  time int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezgeneral_digest_user_settings
--
CREATE TABLE ezgeneral_digest_user_settings (
  id INTEGER PRIMARY KEY NOT NULL,
  address varchar(255) NOT NULL DEFAULT '',
  receive_digest int(11) NOT NULL DEFAULT '0',
  digest_type int(11) NOT NULL DEFAULT '0',
  day varchar(255) NOT NULL DEFAULT '',
  time varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezimage
--
CREATE TABLE ezimage (
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  version int(11) NOT NULL DEFAULT '0',
  filename varchar(255) NOT NULL DEFAULT '',
  original_filename varchar(255) NOT NULL DEFAULT '',
  mime_type varchar(50) NOT NULL DEFAULT '',
  alternative_text varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (contentobject_attribute_id, version)
);

--
-- Table: ezimagefile
--
CREATE TABLE ezimagefile (
  id INTEGER PRIMARY KEY NOT NULL,
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  filepath longtext(4294967295) NOT NULL
);

--
-- Table: ezimagevariation
--
CREATE TABLE ezimagevariation (
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  version int(11) NOT NULL DEFAULT '0',
  filename varchar(255) NOT NULL DEFAULT '',
  additional_path varchar(255) DEFAULT NULL,
  requested_width int(11) NOT NULL DEFAULT '0',
  requested_height int(11) NOT NULL DEFAULT '0',
  width int(11) NOT NULL DEFAULT '0',
  height int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (contentobject_attribute_id, version, requested_width, requested_height)
);

--
-- Table: ezinfocollection
--
CREATE TABLE ezinfocollection (
  id INTEGER PRIMARY KEY NOT NULL,
  contentobject_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  user_identifier varchar(34) DEFAULT NULL,
  modified int(11) DEFAULT '0'
);

--
-- Table: ezinfocollection_attribute
--
CREATE TABLE ezinfocollection_attribute (
  id INTEGER PRIMARY KEY NOT NULL,
  informationcollection_id int(11) NOT NULL DEFAULT '0',
  data_text longtext(4294967295),
  data_int int(11) DEFAULT NULL,
  data_float float(8,2) DEFAULT NULL,
  contentclass_attribute_id int(11) NOT NULL DEFAULT '0',
  contentobject_attribute_id int(11) DEFAULT NULL,
  contentobject_id int(11) DEFAULT NULL
);

--
-- Table: ezkeyword
--
CREATE TABLE ezkeyword (
  id INTEGER PRIMARY KEY NOT NULL,
  keyword varchar(255) DEFAULT NULL,
  class_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezkeyword_attribute_link
--
CREATE TABLE ezkeyword_attribute_link (
  id INTEGER PRIMARY KEY NOT NULL,
  keyword_id int(11) NOT NULL DEFAULT '0',
  objectattribute_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezmedia
--
CREATE TABLE ezmedia (
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  version int(11) NOT NULL DEFAULT '0',
  filename varchar(255) NOT NULL DEFAULT '',
  original_filename varchar(255) NOT NULL DEFAULT '',
  mime_type varchar(50) NOT NULL DEFAULT '',
  width int(11) DEFAULT NULL,
  height int(11) DEFAULT NULL,
  has_controller int(11) DEFAULT '0',
  is_autoplay int(11) DEFAULT '0',
  pluginspage varchar(255) DEFAULT NULL,
  quality varchar(50) DEFAULT NULL,
  controls varchar(50) DEFAULT NULL,
  is_loop int(11) DEFAULT '0',
  PRIMARY KEY (contentobject_attribute_id, version)
);

--
-- Table: ezmessage
--
CREATE TABLE ezmessage (
  id INTEGER PRIMARY KEY NOT NULL,
  send_method varchar(50) NOT NULL DEFAULT '',
  send_weekday varchar(50) NOT NULL DEFAULT '',
  send_time varchar(50) NOT NULL DEFAULT '',
  destination_address varchar(50) NOT NULL DEFAULT '',
  title varchar(255) NOT NULL DEFAULT '',
  body longtext(4294967295),
  is_sent int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezmodule_run
--
CREATE TABLE ezmodule_run (
  id INTEGER PRIMARY KEY NOT NULL,
  workflow_process_id int(11) DEFAULT NULL,
  module_name varchar(255) DEFAULT NULL,
  function_name varchar(255) DEFAULT NULL,
  module_data longtext(4294967295)
);

--
-- Table: eznode_assignment
--
CREATE TABLE eznode_assignment (
  id INTEGER PRIMARY KEY NOT NULL,
  contentobject_id int(11) DEFAULT NULL,
  contentobject_version int(11) DEFAULT NULL,
  parent_node int(11) DEFAULT NULL,
  sort_field int(11) DEFAULT '1',
  sort_order int(11) DEFAULT '1',
  is_main int(11) NOT NULL DEFAULT '0',
  from_node_id int(11) DEFAULT '0',
  remote_id int(11) NOT NULL DEFAULT '0',
  parent_remote_id varchar(100) NOT NULL DEFAULT ''
);

--
-- Table: eznotificationcollection
--
CREATE TABLE eznotificationcollection (
  id INTEGER PRIMARY KEY NOT NULL,
  event_id int(11) NOT NULL DEFAULT '0',
  handler varchar(255) NOT NULL DEFAULT '',
  transport varchar(255) NOT NULL DEFAULT '',
  data_subject longtext(4294967295) NOT NULL,
  data_text longtext(4294967295) NOT NULL
);

--
-- Table: eznotificationcollection_item
--
CREATE TABLE eznotificationcollection_item (
  id INTEGER PRIMARY KEY NOT NULL,
  collection_id int(11) NOT NULL DEFAULT '0',
  event_id int(11) NOT NULL DEFAULT '0',
  address varchar(255) NOT NULL DEFAULT '',
  send_date int(11) NOT NULL DEFAULT '0'
);

--
-- Table: eznotificationevent
--
CREATE TABLE eznotificationevent (
  id INTEGER PRIMARY KEY NOT NULL,
  status int(11) NOT NULL DEFAULT '0',
  event_type_string varchar(255) NOT NULL DEFAULT '',
  data_int1 int(11) NOT NULL DEFAULT '0',
  data_int2 int(11) NOT NULL DEFAULT '0',
  data_int3 int(11) NOT NULL DEFAULT '0',
  data_int4 int(11) NOT NULL DEFAULT '0',
  data_text1 longtext(4294967295) NOT NULL,
  data_text2 longtext(4294967295) NOT NULL,
  data_text3 longtext(4294967295) NOT NULL,
  data_text4 longtext(4294967295) NOT NULL
);

--
-- Table: ezoperation_memento
--
CREATE TABLE ezoperation_memento (
  id int NOT NULL,
  memento_key varchar(32) NOT NULL DEFAULT '',
  memento_data longtext(4294967295) NOT NULL,
  main int(11) NOT NULL DEFAULT '0',
  main_key varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (id, memento_key)
);

--
-- Table: ezorder
--
CREATE TABLE ezorder (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  productcollection_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  is_temporary int(11) NOT NULL DEFAULT '1',
  order_nr int(11) NOT NULL DEFAULT '0',
  data_text_2 longtext(4294967295),
  data_text_1 longtext(4294967295),
  account_identifier varchar(100) NOT NULL DEFAULT 'default',
  ignore_vat int(11) NOT NULL DEFAULT '0',
  email varchar(150) DEFAULT ''
);

--
-- Table: ezorder_item
--
CREATE TABLE ezorder_item (
  id INTEGER PRIMARY KEY NOT NULL,
  order_id int(11) NOT NULL DEFAULT '0',
  description varchar(255) DEFAULT NULL,
  price float(8,2) DEFAULT NULL,
  vat_value int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezpdf_export
--
CREATE TABLE ezpdf_export (
  id INTEGER PRIMARY KEY NOT NULL,
  title varchar(255) DEFAULT NULL,
  show_frontpage int(11) DEFAULT NULL,
  intro_text longtext(4294967295),
  sub_text longtext(4294967295),
  source_node_id int(11) DEFAULT NULL,
  export_structure varchar(255) DEFAULT NULL,
  export_classes varchar(255) DEFAULT NULL,
  site_access varchar(255) DEFAULT NULL,
  pdf_filename varchar(255) DEFAULT NULL,
  modifier_id int(11) DEFAULT NULL,
  modified int(11) DEFAULT NULL,
  created int(11) DEFAULT NULL,
  creator_id int(11) DEFAULT NULL,
  status int(11) DEFAULT NULL
);

--
-- Table: ezpending_actions
--
CREATE TABLE ezpending_actions (
  action varchar(64) NOT NULL DEFAULT '',
  param longtext(4294967295)
);

--
-- Table: ezpolicy
--
CREATE TABLE ezpolicy (
  id INTEGER PRIMARY KEY NOT NULL,
  role_id int(11) DEFAULT NULL,
  function_name varchar(255) DEFAULT NULL,
  module_name varchar(255) DEFAULT NULL
);

--
-- Table: ezpolicy_limitation
--
CREATE TABLE ezpolicy_limitation (
  id INTEGER PRIMARY KEY NOT NULL,
  policy_id int(11) DEFAULT NULL,
  identifier varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezpolicy_limitation_value
--
CREATE TABLE ezpolicy_limitation_value (
  id INTEGER PRIMARY KEY NOT NULL,
  limitation_id int(11) DEFAULT NULL,
  value varchar(255) DEFAULT NULL
);

--
-- Table: ezpreferences
--
CREATE TABLE ezpreferences (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  name varchar(100) DEFAULT NULL,
  value varchar(100) DEFAULT NULL
);

--
-- Table: ezproductcollection
--
CREATE TABLE ezproductcollection (
  id INTEGER PRIMARY KEY NOT NULL,
  created int(11) DEFAULT NULL
);

--
-- Table: ezproductcollection_item
--
CREATE TABLE ezproductcollection_item (
  id INTEGER PRIMARY KEY NOT NULL,
  productcollection_id int(11) NOT NULL DEFAULT '0',
  contentobject_id int(11) NOT NULL DEFAULT '0',
  item_count int(11) NOT NULL DEFAULT '0',
  price float(8,2) DEFAULT '0',
  is_vat_inc int(11) DEFAULT NULL,
  vat_value float(8,2) DEFAULT NULL,
  discount float(8,2) DEFAULT NULL
);

--
-- Table: ezproductcollection_item_opt
--
CREATE TABLE ezproductcollection_item_opt (
  id INTEGER PRIMARY KEY NOT NULL,
  item_id int(11) NOT NULL DEFAULT '0',
  option_item_id int(11) NOT NULL DEFAULT '0',
  name varchar(255) NOT NULL DEFAULT '',
  value varchar(255) NOT NULL DEFAULT '',
  price float(8,2) NOT NULL DEFAULT '0',
  object_attribute_id int(11) DEFAULT NULL
);

--
-- Table: ezrole
--
CREATE TABLE ezrole (
  id INTEGER PRIMARY KEY NOT NULL,
  version int(11) DEFAULT '0',
  name varchar(255) NOT NULL DEFAULT '',
  value char(1) DEFAULT NULL
);

--
-- Table: ezrss_export
--
CREATE TABLE ezrss_export (
  id INTEGER PRIMARY KEY NOT NULL,
  title varchar(255) DEFAULT NULL,
  modifier_id int(11) DEFAULT NULL,
  modified int(11) DEFAULT NULL,
  url varchar(255) DEFAULT NULL,
  description longtext(4294967295),
  image_id int(11) DEFAULT NULL,
  active int(11) DEFAULT NULL,
  access_url varchar(255) DEFAULT NULL,
  created int(11) DEFAULT NULL,
  creator_id int(11) DEFAULT NULL,
  status int(11) DEFAULT NULL,
  site_access varchar(255) DEFAULT NULL,
  rss_version varchar(255) DEFAULT NULL
);

--
-- Table: ezrss_export_item
--
CREATE TABLE ezrss_export_item (
  id INTEGER PRIMARY KEY NOT NULL,
  rssexport_id int(11) DEFAULT NULL,
  source_node_id int(11) DEFAULT NULL,
  class_id int(11) DEFAULT NULL,
  title varchar(255) DEFAULT NULL,
  description varchar(255) DEFAULT NULL
);

--
-- Table: ezrss_import
--
CREATE TABLE ezrss_import (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) DEFAULT NULL,
  url longtext(4294967295),
  destination_node_id int(11) DEFAULT NULL,
  class_id int(11) DEFAULT NULL,
  class_title varchar(255) DEFAULT NULL,
  class_url varchar(255) DEFAULT NULL,
  class_description varchar(255) DEFAULT NULL,
  active int(11) DEFAULT NULL,
  creator_id int(11) DEFAULT NULL,
  created int(11) DEFAULT NULL,
  modifier_id int(11) DEFAULT NULL,
  modified int(11) DEFAULT NULL,
  status int(11) DEFAULT NULL,
  object_owner_id int(11) DEFAULT NULL
);

--
-- Table: ezsearch_object_word_link
--
CREATE TABLE ezsearch_object_word_link (
  id INTEGER PRIMARY KEY NOT NULL,
  contentobject_id int(11) NOT NULL DEFAULT '0',
  word_id int(11) NOT NULL DEFAULT '0',
  frequency float(8,2) NOT NULL DEFAULT '0',
  placement int(11) NOT NULL DEFAULT '0',
  prev_word_id int(11) NOT NULL DEFAULT '0',
  next_word_id int(11) NOT NULL DEFAULT '0',
  contentclass_id int(11) NOT NULL DEFAULT '0',
  published int(11) NOT NULL DEFAULT '0',
  section_id int(11) NOT NULL DEFAULT '0',
  contentclass_attribute_id int(11) NOT NULL DEFAULT '0',
  identifier varchar(255) NOT NULL DEFAULT '',
  integer_value int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezsearch_return_count
--
CREATE TABLE ezsearch_return_count (
  id INTEGER PRIMARY KEY NOT NULL,
  phrase_id int(11) NOT NULL DEFAULT '0',
  time int(11) NOT NULL DEFAULT '0',
  count int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezsearch_search_phrase
--
CREATE TABLE ezsearch_search_phrase (
  id INTEGER PRIMARY KEY NOT NULL,
  phrase varchar(250) DEFAULT NULL
);

--
-- Table: ezsearch_word
--
CREATE TABLE ezsearch_word (
  id INTEGER PRIMARY KEY NOT NULL,
  word varchar(150) DEFAULT NULL,
  object_count int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezsection
--
CREATE TABLE ezsection (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) DEFAULT NULL,
  locale varchar(255) DEFAULT NULL,
  navigation_part_identifier varchar(100) DEFAULT 'ezcontentnavigationpart'
);

--
-- Table: ezsession
--
CREATE TABLE ezsession (
  session_key varchar(32) NOT NULL DEFAULT '',
  expiration_time int(11) NOT NULL DEFAULT '0',
  data longtext(4294967295) NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (session_key)
);

--
-- Table: ezsite_data
--
CREATE TABLE ezsite_data (
  name varchar(60) NOT NULL DEFAULT '',
  value longtext(4294967295) NOT NULL,
  PRIMARY KEY (name)
);

--
-- Table: ezsubtree_expiry
--
CREATE TABLE ezsubtree_expiry (
  subtree varchar(255) NOT NULL DEFAULT '',
  cache_file varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezsubtree_notification_rule
--
CREATE TABLE ezsubtree_notification_rule (
  id INTEGER PRIMARY KEY NOT NULL,
  use_digest int(11) DEFAULT '0',
  node_id int(11) NOT NULL DEFAULT '0',
  user_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: eztipafriend_counter
--
CREATE TABLE eztipafriend_counter (
  node_id INTEGER PRIMARY KEY NOT NULL DEFAULT '0',
  count int(11) NOT NULL DEFAULT '0'
);

--
-- Table: eztrigger
--
CREATE TABLE eztrigger (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) DEFAULT NULL,
  module_name varchar(200) NOT NULL DEFAULT '',
  function_name varchar(200) NOT NULL DEFAULT '',
  connect_type char(1) NOT NULL DEFAULT '',
  workflow_id int(11) DEFAULT NULL
);

--
-- Table: ezurl
--
CREATE TABLE ezurl (
  id INTEGER PRIMARY KEY NOT NULL,
  url varchar(255) DEFAULT NULL,
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  is_valid int(11) NOT NULL DEFAULT '1',
  last_checked int(11) NOT NULL DEFAULT '0',
  original_url_md5 varchar(32) NOT NULL DEFAULT ''
);

--
-- Table: ezurl_object_link
--
CREATE TABLE ezurl_object_link (
  url_id int(11) NOT NULL DEFAULT '0',
  contentobject_attribute_id int(11) NOT NULL DEFAULT '0',
  contentobject_attribute_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (url_id, contentobject_attribute_id, contentobject_attribute_version)
);

--
-- Table: ezurlalias
--
CREATE TABLE ezurlalias (
  id INTEGER PRIMARY KEY NOT NULL,
  source_url longtext(4294967295) NOT NULL,
  source_md5 varchar(32) DEFAULT NULL,
  destination_url longtext(4294967295) NOT NULL,
  is_internal int(11) NOT NULL DEFAULT '1',
  forward_to_id int(11) NOT NULL DEFAULT '0',
  is_wildcard int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezuser
--
CREATE TABLE ezuser (
  contentobject_id INTEGER PRIMARY KEY NOT NULL DEFAULT '0',
  login varchar(150) NOT NULL DEFAULT '',
  email varchar(150) NOT NULL DEFAULT '',
  password_hash_type int(11) NOT NULL DEFAULT '1',
  password_hash varchar(50) DEFAULT NULL
);

--
-- Table: ezuser_accountkey
--
CREATE TABLE ezuser_accountkey (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  hash_key varchar(32) NOT NULL DEFAULT '',
  time int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezuser_discountrule
--
CREATE TABLE ezuser_discountrule (
  id INTEGER PRIMARY KEY NOT NULL,
  discountrule_id int(11) DEFAULT NULL,
  contentobject_id int(11) DEFAULT NULL,
  name varchar(255) NOT NULL DEFAULT ''
);

--
-- Table: ezuser_role
--
CREATE TABLE ezuser_role (
  id INTEGER PRIMARY KEY NOT NULL,
  role_id int(11) DEFAULT NULL,
  contentobject_id int(11) DEFAULT NULL,
  limit_identifier varchar(255) DEFAULT '',
  limit_value varchar(255) DEFAULT ''
);

--
-- Table: ezuser_setting
--
CREATE TABLE ezuser_setting (
  user_id INTEGER PRIMARY KEY NOT NULL DEFAULT '0',
  is_enabled int(11) NOT NULL DEFAULT '0',
  max_login int(11) DEFAULT NULL
);

--
-- Table: ezvattype
--
CREATE TABLE ezvattype (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) NOT NULL DEFAULT '',
  percentage float(8,2) DEFAULT NULL
);

--
-- Table: ezview_counter
--
CREATE TABLE ezview_counter (
  node_id INTEGER PRIMARY KEY NOT NULL DEFAULT '0',
  count int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezwaituntildatevalue
--
CREATE TABLE ezwaituntildatevalue (
  id int NOT NULL,
  workflow_event_id int(11) NOT NULL DEFAULT '0',
  workflow_event_version int(11) NOT NULL DEFAULT '0',
  contentclass_id int(11) NOT NULL DEFAULT '0',
  contentclass_attribute_id int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id, workflow_event_id, workflow_event_version)
);

--
-- Table: ezwishlist
--
CREATE TABLE ezwishlist (
  id INTEGER PRIMARY KEY NOT NULL,
  user_id int(11) NOT NULL DEFAULT '0',
  productcollection_id int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezworkflow
--
CREATE TABLE ezworkflow (
  id int NOT NULL,
  version int(11) NOT NULL DEFAULT '0',
  is_enabled int(11) NOT NULL DEFAULT '0',
  workflow_type_string varchar(50) NOT NULL DEFAULT '',
  name varchar(255) NOT NULL DEFAULT '',
  creator_id int(11) NOT NULL DEFAULT '0',
  modifier_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id, version)
);

--
-- Table: ezworkflow_assign
--
CREATE TABLE ezworkflow_assign (
  id INTEGER PRIMARY KEY NOT NULL,
  workflow_id int(11) NOT NULL DEFAULT '0',
  node_id int(11) NOT NULL DEFAULT '0',
  access_type int(11) NOT NULL DEFAULT '0',
  as_tree int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezworkflow_event
--
CREATE TABLE ezworkflow_event (
  id int NOT NULL,
  version int(11) NOT NULL DEFAULT '0',
  workflow_id int(11) NOT NULL DEFAULT '0',
  workflow_type_string varchar(50) NOT NULL DEFAULT '',
  description varchar(50) NOT NULL DEFAULT '',
  data_int1 int(11) DEFAULT NULL,
  data_int2 int(11) DEFAULT NULL,
  data_int3 int(11) DEFAULT NULL,
  data_int4 int(11) DEFAULT NULL,
  data_text1 varchar(50) DEFAULT NULL,
  data_text2 varchar(50) DEFAULT NULL,
  data_text3 varchar(50) DEFAULT NULL,
  data_text4 varchar(50) DEFAULT NULL,
  placement int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id, version)
);

--
-- Table: ezworkflow_group
--
CREATE TABLE ezworkflow_group (
  id INTEGER PRIMARY KEY NOT NULL,
  name varchar(255) NOT NULL DEFAULT '',
  creator_id int(11) NOT NULL DEFAULT '0',
  modifier_id int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0'
);

--
-- Table: ezworkflow_group_link
--
CREATE TABLE ezworkflow_group_link (
  workflow_id int(11) NOT NULL DEFAULT '0',
  group_id int(11) NOT NULL DEFAULT '0',
  workflow_version int(11) NOT NULL DEFAULT '0',
  group_name varchar(255) DEFAULT NULL,
  PRIMARY KEY (workflow_id, group_id, workflow_version)
);

--
-- Table: ezworkflow_process
--
CREATE TABLE ezworkflow_process (
  id INTEGER PRIMARY KEY NOT NULL,
  process_key varchar(32) NOT NULL DEFAULT '',
  workflow_id int(11) NOT NULL DEFAULT '0',
  user_id int(11) NOT NULL DEFAULT '0',
  content_id int(11) NOT NULL DEFAULT '0',
  content_version int(11) NOT NULL DEFAULT '0',
  node_id int(11) NOT NULL DEFAULT '0',
  session_key varchar(32) NOT NULL DEFAULT '0',
  event_id int(11) NOT NULL DEFAULT '0',
  event_position int(11) NOT NULL DEFAULT '0',
  last_event_id int(11) NOT NULL DEFAULT '0',
  last_event_position int(11) NOT NULL DEFAULT '0',
  last_event_status int(11) NOT NULL DEFAULT '0',
  event_status int(11) NOT NULL DEFAULT '0',
  created int(11) NOT NULL DEFAULT '0',
  modified int(11) NOT NULL DEFAULT '0',
  activation_date int(11) DEFAULT NULL,
  event_state int(11) DEFAULT NULL,
  status int(11) DEFAULT NULL,
  parameters longtext(4294967295),
  memento_key varchar(32) DEFAULT NULL
);

CREATE INDEX ezbasket_session_id_ezbasket on ezbasket (session_id);
CREATE INDEX ezcollab_group_path_ezcollab_g on ezcollab_group (path_string);
CREATE INDEX ezcollab_group_depth_ezcollab_ on ezcollab_group (depth);
CREATE INDEX ezcontentbrowsebookmark_user_e on ezcontentbrowsebookmark (user_id);
CREATE INDEX ezcontentbrowserecent_user_ezc on ezcontentbrowserecent (user_id);
CREATE INDEX ezcontentclass_version_ezconte on ezcontentclass (version);
CREATE INDEX ezcontentobject_attribute_contentobject_id_ezcontentobj on ezcontentobject_attribute (contentobject_id);
CREATE INDEX ezcontentobject_attribute_language_code_ezcontentobject on ezcontentobject_attribute (language_code);
CREATE INDEX sort_key_int_ezcontentobject_a on ezcontentobject_attribute (sort_key_int);
CREATE INDEX sort_key_string_ezcontentobjec on ezcontentobject_attribute (sort_key_string);
CREATE INDEX ezcontentobject_attribute_co_id_ver_lang_code_ezcontent on ezcontentobject_attribute (contentobject_id, version, language_code);
CREATE INDEX ezcontentobject_tree_path_ezco on ezcontentobject_tree (path_string);
CREATE INDEX ezcontentobject_tree_p_node_id_ezcontentobject_tre on ezcontentobject_tree (parent_node_id);
CREATE INDEX ezcontentobject_tree_co_id_ezc on ezcontentobject_tree (contentobject_id);
CREATE INDEX ezcontentobject_tree_depth_ezc on ezcontentobject_tree (depth);
CREATE INDEX modified_subnode_ezcontentobje on ezcontentobject_tree (modified_subnode);
CREATE INDEX ezenumobjectvalue_co_attr_id_co_attr_ver_ezenum on ezenumobjectvalue (contentobject_attribute_id, contentobject_attribute_version);
CREATE INDEX ezenumvalue_co_cl_attr_id_co_class_att_ver_ on ezenumvalue (contentclass_attribute_id, contentclass_attribute_version);
CREATE INDEX ezimagefile_coid_ezimagefile on ezimagefile (contentobject_attribute_id);
CREATE INDEX ezimagefile_file_ezimagefile on ezimagefile (filepath);
CREATE INDEX ezoperation_memento_memento_key_main_ezoperation_ on ezoperation_memento (memento_key, main);
CREATE INDEX ezorder_item_order_id_ezorder_ on ezorder_item (order_id);
CREATE INDEX ezpending_actions_action_ezpen on ezpending_actions (action);
CREATE INDEX ezpreferences_name_ezpreferenc on ezpreferences (name);
CREATE INDEX ezpreferences_user_id_idx_ezpr on ezpreferences (user_id, name);
CREATE INDEX ezproductcollection_item_productcollection_id_ezproduc on ezproductcollection_item (productcollection_id);
CREATE INDEX ezproductcollection_item_contentobject_id_ezproductcol on ezproductcollection_item (productcollection_id);
CREATE INDEX ezproductcollection_item_opt_item_id_ezproductcollection_i on ezproductcollection_item_opt (item_id);
CREATE INDEX ezrss_export_rsseid_ezrss_expo on ezrss_export_item (rssexport_id);
CREATE INDEX ezsearch_object_word_link_object_ezsearch_object_word_l on ezsearch_object_word_link (contentobject_id);
CREATE INDEX ezsearch_object_word_link_word_ezsearch_object_word_lin on ezsearch_object_word_link (word_id);
CREATE INDEX ezsearch_object_word_link_frequency_ezsearch_object_wor on ezsearch_object_word_link (frequency);
CREATE INDEX ezsearch_object_word_link_identifier_ezsearch_object_wo on ezsearch_object_word_link (identifier);
CREATE INDEX ezsearch_object_word_link_integer_value_ezsearch_object on ezsearch_object_word_link (integer_value);
CREATE INDEX ezsearch_word_ezsearch_word on ezsearch_word (word);
CREATE INDEX expiration_time_ezsession on ezsession (expiration_time);
CREATE INDEX ezsession_user_id_ezsession on ezsession (user_id);
CREATE INDEX ezsubtree_expiry_subtree_ezsub on ezsubtree_expiry (subtree);
CREATE INDEX ezsubtree_notification_rule_id_ezsubtree_notification_rul on ezsubtree_notification_rule (id);
CREATE INDEX ezsubtree_notification_rule_user_id_ezsubtree_notificatio on ezsubtree_notification_rule (user_id);
CREATE INDEX eztrigger_fetch_eztrigger on eztrigger (name, module_name, function_name);
CREATE INDEX ezurlalias_source_md5_ezurlali on ezurlalias (source_md5);
CREATE INDEX ezurlalias_source_url_ezurlali on ezurlalias (source_url);
CREATE INDEX ezurlalias_desturl_ezurlalias on ezurlalias (destination_url);
CREATE INDEX ezuser_role_contentobject_id_e on ezuser_role (contentobject_id);
CREATE INDEX ezuser_role_role_id_ezuser_rol on ezuser_role (role_id);
CREATE INDEX ezwaituntildateevalue_wf_ev_id_wf_ver_ezwaituntild on ezwaituntildatevalue (workflow_event_id, workflow_event_version);
CREATE INDEX ezworkflow_process_process_key_ezworkflow_proces on ezworkflow_process (process_key);
CREATE UNIQUE INDEX ezmodule_run_workflow_process_id_s_ezmodul on ezmodule_run (workflow_process_id);
CREATE UNIQUE INDEX eztrigger_def_id_eztrigger on eztrigger (module_name, function_name, connect_type);
COMMIT;
