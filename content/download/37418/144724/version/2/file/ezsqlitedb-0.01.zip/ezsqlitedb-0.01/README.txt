

          ezSQLiteDB Class version 0.01 for eZ publish 3.x



DESCRIPTION
===========

This file extends eZ publish 3.4 with support for SQLite databases (see http://www.sqlite.org).
SQLite is a very light weight, flexible and easy to use database. It's ideal to use
for a development machine or for sites which don't need certain features of MySQL/PostgreSQL
(e.g. access control to the databases. If you can read the file, then you have access to the
database).

That said, it's is a very fast and quite complete database. SQLite will be in PHP5 as a
standard module, so even more reason to try it out.

This is a first alpha version, so be careful. I've created this because
I'm working on a better windows package for eZ publish development (I'll publish that later).
It's only tested on windows and even there I only tested it very rudimentarily.

I'm interested in feedback. Mail me any suggestions you have. (Flames won't be answered.)


Kai Duebbert <public@duebbert.de>
2004-07-04


All files included in this archive are licensed under the GNU Public license Version 2 or later.
See the file LICENSE for the complete text.



INSTALLATION
============

1. Make sure your PHP version has support for SQLite. You can download the module for Windows
   here: http://www.php.net/sqlite  . Make sure you activate the module in the php configuration.

2. Download the command line program sqlite from http://www.sqlite.org/download.html .
   You'll need it to create the first databases as the setup system for eZ publish is not
   working completly yet.

3. Create the database with the supplied SQL files by doing the following commands:

            sqlite [database_name] < .\kernel\sql\sqlite\kernel_schema.sql
            sqlite [database_name] < .\kernel\sql\sqlite\cleandata.sql

        example:

            sqlite ezpublish3.db < .\kernel\sql\sqlite\kernel_schema.sql
            sqlite ezpublish3.db < .\kernel\sql\sqlite\cleandata.sql

4. Edit your site.ini and set the setting "DatabaseImplementation" to ezsqlitedb. Set the
   Server setting to the path of your sqlite database. (This might be changed in the future.)
   Here is an example:

            [DatabaseSettings]
            DatabaseImplementation=ezsqlite
            Server=c:\temp\ezpublish.db

5. Login on your site with "admin" and "publish".


(I know, this is very rudimentary documentation. Write me with a better howto.)