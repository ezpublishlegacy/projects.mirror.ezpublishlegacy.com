<?php

$eZTemplateOperatorArray = array(
     array(
        'script' => 'extension/owsimpleoperator/autoloads/exampleoperator.php',
        'class' => 'ExampleOperator',
        'operator_names' => array(
            'example_sum' ,
        )
     )
);

?>