//
//
// Content structure menu Asynchronous Javascript request library (csm_aj)
// -----------------------------------------------------------------------
// Copyright (C) Kristian Hole 2005
// Copyright (C) 2005 Vision with Technology, All rights reserved.
// http://www.visionwt.com
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact license@visionwt.com if any conditions of this licencing
// are unclear to you.
//
// Authors:
//   Kristian Hole - original code
//   David Heath - further improvements
// 
// Heavily inspired by:
// http://ajaxblog.com/
//
// TODO: 
// - Gracefully handle when XMLHttpRequest is not loaded
// - Error checking of the result, now the result is just outputted
// - Perhaps not use innerHTML as it is not the "official" way of doing it.
// - More/better error checking


var xmlhttp;
var gExpandElement; // the element currently being expanded
var gServiceURL;

/*!
    Pathes to fold/unfold icons
*/
var gUseIcons                                   = false;
var gOpenIcon                                   = '';
var gCloseIcon                                  = '';
var gEmptyIcon                                  = '';
var gIconsWidth                                 = 16;
var gIconsHeight                                = 16;
var gTimeOut                                    = 3000;

// Other globals
var gItemClickAction = '';

function createXMLHttp() {
    try {
        xmlhttp = new XMLHttpRequest();
    } catch (e) {
        var MSXML_XMLHTTP_PROGIDS = new Array(
                                              'MSXML2.XMLHTTP.5.0',
                                              'MSXML2.XMLHTTP.4.0',
                                              'MSXML2.XMLHTTP.3.0',
                                              'MSXML2.XMLHTTP',
                                              'Microsoft.XMLHTTP'
                                              );
        var success = false;
        for (var i=0;i < MSXML_XMLHTTP_PROGIDS.length && !success; i++) {
            try {
                xmlhttp = new ActiveXObject(MSXML_XMLHTTP_PROGIDS[i]);
                success = true;
            } catch (e) {}
        }
        if ( !success ) {
            alert('Cant create XMLHttpRequest - not supported');
            setResponse("Not supported by your browser");
            setStatus("Unsupported");
        }
    }
}

createXMLHttp();

function setStatusMessage(msg)
{
    var statuselem = document.getElementById("status");
    if (statuselem) 
        statuselem.innerHTML=msg;
}

function setResponse(msg)
{
    var responseElem = document.getElementById("response");
    if (responseElem) {
        responseElem.innerHTML=msg;
    }
}


function callInProgress(xmlhttp) {
    return xmlhttp.readyState != 4 && xmlhttp.readyState != 0;
}


function toggleNode(ezpublish_node_id) {
    gExpandElementID = ezpublish_node_id;
    var child_element = document.getElementById('n' + ezpublish_node_id+ '_sub');
    if (!child_element.innerHTML) {
        initiateContentFetchCall(ezpublish_node_id);
        child_element.style.display='';
        child_element.innerHTML='loading...';
    }
    else {
        dynmenu_foldUnfold(gExpandElementID);
    }
}

function initiateContentFetchCall(ezpublish_node_id) {
    if ( !callInProgress(xmlhttp) ) {
        // configure the asynchronous call
        var url=gServiceURL+'/'+ezpublish_node_id;
        if (gItemClickAction) {
            url = url + '/?ica=' + escape(gItemClickAction);
        }
        xmlhttp.open("GET", url, true);
        // Configure the callback handler
        xmlhttp.onreadystatechange = handleResponse;
        // send the request
        xmlhttp.send(null);
        startTimeout();
    } else {
        setStatusMessage("Busy. Please wait a moment");
    }
}

// Callback
function handleResponse() {
    if ( xmlhttp.readyState == 4 ) {
        stopTimeout();
        var child_element = getElementPendingAjaxResponse();
        if (xmlhttp.status == 200) {
            child_element.innerHTML = xmlhttp.responseText;
            setStatusMessage("");
            child_element.style.display='none';
            dynmenu_foldUnfold(gExpandElementID);
        } else {
            alert("Unable to expand menu. Remote server error (response code=" + xmlhttp.status + ")");
            child_element.innerHTML = "ERROR: remote server response code "+ xmlhttp.status;
        }
    }
}

function getElementPendingAjaxResponse() {
    return document.getElementById('n' + gExpandElementID+ '_sub');
}

function setPendingElementContent(new_content) {
    var child_element = getElementPendingAjaxResponse();
    child_element.innerHTML = new_content;
}

// timing functions
var timer;

function startTimeout()
{
    timer = setTimeout("timeout()", gTimeOut);
}
function stopTimeout()
{
    clearTimeout(timer);
}
function timeout()
{
	if ( callInProgress(xmlhttp) ) {
        xmlhttp.abort();
        setStatusMessage("Connection timeout " + xmlhttp.responseText);
        setPendingElementContent("ERROR: Network timeout");
    }
}

function dynmenu_foldUnfold( nodeID )
{
    if (!nodeID)
        return;
    
    var ul_node = document.getElementById('n' + gExpandElementID+ '_sub');
    var img_node = document.getElementById('n' + gExpandElementID+ '_toggle');
    
    if (ul_node.style.display == "none") {
        ul_node.style.display = "";
        img_node.src = gCloseIcon;
    }
    else {
        ul_node.style.display = "none";
        img_node.src = gOpenIcon;
    }
}


/*!
    Sets icons instead of text labels [-]/[+]/[ ]
*/
function dynmenu_init( openIcon, closeIcon, emptyIcon, menu_data_service_url, currentNodePath, itemClickAction, timeOut )
{
        gOpenIcon = openIcon;
        gCloseIcon = closeIcon;
        gEmptyIcon = emptyIcon;
        gServiceURL = menu_data_service_url;
        gUseIcons = true;
        gItemClickAction = itemClickAction;
        highlightNode(currentNodePath);
        gTimeOut = timeOut;
}

function highlightNode(nodePath) {
    var parts = nodePath.split('/');
    var nodeID = parts[parts.length - 1];

    var currentNode = ezjslib_getHTMLNodeById( 'n' + nodeID );
    ezjslib_appendHTMLNodeClassStyle( currentNode, "currentnode" );    
}
