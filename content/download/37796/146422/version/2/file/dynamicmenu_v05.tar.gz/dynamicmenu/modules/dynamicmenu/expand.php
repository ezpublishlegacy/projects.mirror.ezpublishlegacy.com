<?php
//
// Created on: <17-Jun-2005 16:38:41 kh>
// Copyright (C) Kristian Hole 2005
// Copyright (C) 2005 Vision with Technology, All rights reserved.
// http://www.visionwt.com
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact license@visionwt.com if any conditions of this licencing
// are unclear to you.
//

/*! \file view.php
*/

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezdebug.php' );

$http =& eZHTTPTool::instance();

// debugMode ontrols if there should be possible to see debugoutput for this file,
// useful for seeing template errors etc
$debugMode = false;
$turnDebugOn = false;

$tpl =& templateInit();

if ( $http->hasVariable('ica') )
{
    $tpl->setVariable( 'itemClickAction', $http->variable('ica') );
}

$tpl->setVariable( 'parent_node', $Params['NodeID'] ? $Params['NodeID'] : 2 );


if ( $debugMode )
{
    $debug =& eZDebug::instance();
    $debug->updateSettings( array( 'debug-enabled' => $turnDebugOn ) );
    $Result = array();
    $Result[ 'content' ] =& $tpl->fetch( 'design:contentstructuremenu/prototype_menu.tpl' );
    $Result[ 'pagelayout' ] = false;
}
else
{
    echo $tpl->fetch( 'design:contentstructuremenu/prototype_menu.tpl' );
    include_once( 'lib/ezutils/classes/ezexecution.php' );
    eZExecution::cleanExit();
}

?>
