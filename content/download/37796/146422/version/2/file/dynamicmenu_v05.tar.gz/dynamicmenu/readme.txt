------------------------------
Dynamic Contentstructure menu
    for eZ publish 3.6.x
------------------------------

Installing
----------

Unpack to extensions directory. Activate extension. Clear
caches. Voila, the content structure menu on the left side of the
administration interface should now work using dynamic AJAX calls.

About
-----

This is a dynamic tree menu. When you expand a node in the menu tree,
an HTTP request is made to the server to get data for the next level
in the tree. This makes performance much better if you have a very
large tree. 

The code was originally developed by Kristian Hole, with contributions
from David Heath.

Kristian Hole's original comments
---------------------------------
This is proof of concept extension for one solution to the dynamic loading 
of the contentstructure in the administration interface of eZ publish. 

Maybe this can inspire some of you to contribute in  making something 
like this :)

Disclamer: This is done by me on my spare time, and is not connected
to eZ systems in any way.

 - Kristian Hole

Changelog
---------

v0.5 (27 okt 2005)
David:
- add tooltips
- add configurable timeout
Kristian:
- Fixed: Some image tags were not properly closed

v0.4 (12/10/05) - David Heath
  - changed templates to use standard ezpublish look + feel
  - disabled the toggle for turning on/off the dynamic menu - if you
  don't want to use it, don't activate the extension.
  - reworked some of the javascript code

v0.3
- Added: Support for popupmenu

v0.2 (18sept2005)
- Added: Timeouts for connections
- Added: Errormessage for unsupported browser
- Fixed: Menu now works when displaying users and media library
- Added: Support for /content/browse

v0.1
- Initial release

License
-------
Copyright (C) various authors 2005. See individual files for copyright notices.

This file may be distributed and/or modified under the terms of the
"GNU General Public License" version 2 as published by the Free
Software Foundation

This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE.

The "GNU General Public License" (GPL) is available at
http://www.gnu.org/copyleft/gpl.html, or see GPL.txt included in this
package.
