<?php
//
// Created on: <17-Jun-2005 16:38:41 kh>
// Copyright (C) Kristian Hole 2005
// Copyright (C) 2005 Vision with Technology, All rights reserved.
// http://www.visionwt.com
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact license@visionwt.com if any conditions of this licencing
// are unclear to you.
//

$Module = array( "name" => "Structure menu" );

$ViewList = array();
$ViewList["expand"] = array(
    "script" => "expand.php",
    'params' => array( 'NodeID' ) );

?>
