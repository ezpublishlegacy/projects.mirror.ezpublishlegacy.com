<?php
/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
 * 
 */

class laStaticURLHandler
{
	protected $ini;
	
	function __construct()
	{
		$this->ini	= eZINI::instance( "lastaticcache.ini" );
	}
	
	static function instance()
	{
		$ini	= eZINI::instance( "lastaticcache.ini" );
		$StaticURLHandler	= "la";
		if( $ini->hasVariable( 'CacheSettings', 'StaticURLHandler' ) )
		{
			$StaticURLHandler	= $ini->variable( 'CacheSettings', 'StaticURLHandler' );
		}

		$staticClass	= trim($StaticURLHandler).'StaticURLHandler';
		if( !class_exists( $staticClass ) )
		{
			eZDebug::writeError( 'Impossible to instantiate the custom StaticURLHandler handler "' . $staticClass .'".' );
			return null;
		}
		return new $staticClass;
	}
	
	function addURL($url)
	{
		$urls_addition = array();
		if( $this->ini->hasVariable( $url, 'AdditionURLs' ) )
		{
			$urls_addition = $this->ini->variable( $url, 'AdditionURLs' );
		}
		//TO DO other url in your owner handler.
		//example testStaticURLHandler
		return $urls_addition;
	}
}
?>