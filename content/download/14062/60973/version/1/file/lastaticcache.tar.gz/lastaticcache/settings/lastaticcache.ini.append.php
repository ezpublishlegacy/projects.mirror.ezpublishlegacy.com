<?php
/*
#?ini charset="iso-8859-1"?

[CacheSettings]
#change it for you costum url handler
#StaticURLHandler=la
#example : use test handler
StaticURLHandler=test

#we check if the keyword of template is in the cache genereted. 
#if the page is created with error. so no keyword in cache, don't add it in ezpending_actions
UseKeywordForAvoidBadCacheGenereted=disabled


#add <!-- lagardre --> in all your override templetes
KeywordForAvoidBadCacheGenereted=lagardre

#[/path1/path2/path3]
#AdditionURLs[]
#AdditionURLs[]=/path1/path2/path3/(offset)/1
#AdditionURLs[]=/path1/path2/path3/(offset)/2
#AdditionURLs[]=/path1/path2/path3/(offset)/3
#AdditionURLs[]=/path1/path2/path3/(offset)/4
#AdditionURLs[]=/path1/path2/path3/(offset)/5

#add offset for all class sous_rubrique
[sous_rubrique]
AdditionURLs[]
AdditionURLs[]=/(offset)/1
AdditionURLs[]=/(offset)/2
AdditionURLs[]=/(offset)/3
AdditionURLs[]=/(offset)/4
AdditionURLs[]=/(offset)/5

*/?>