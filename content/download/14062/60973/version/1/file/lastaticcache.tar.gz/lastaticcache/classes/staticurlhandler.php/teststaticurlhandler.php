<?php
class testStaticURLHandler extends laStaticURLHandler
{
	function addURL($url)
	{
		$urls_addition = array();
		if( $this->ini->hasVariable( $url, 'AdditionURLs' ) )
		{
			$urls_addition = $this->ini->variable( $url, 'AdditionURLs' );
		}
		$node_id = eZURLAliasML::fetchNodeIDByPath(  $url );
		if($node_id && $node = eZContentObjectTreeNode::fetch($node_id))
		{
			$class_identifier = $node->attribute('class_identifier');
			foreach ($this->ini->variable( $class_identifier, 'AdditionURLs' ) as $addurl)
			{
				$urls_addition[] = $url . $addurl;
			}
		}
		return $urls_addition;
	}
}
?>