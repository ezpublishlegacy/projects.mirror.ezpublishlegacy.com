<?php /*

[RegionalSettings]
TranslationExtensions[]=ezxmlinstaller

*/ ?>