<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=ezxmlinstaller
ModuleList[]=xmlexport

*/ ?>