<!DOCTYPE TS><TS>
<context>
	<name>kernel/navigationpart</name>
	<message>
		<source>Lists by content class</source>
		<translation>Listes par classe</translation>
	</message>
</context>
<context>
    <name>classlists/list</name>
    <message>
        <source>Lists by content class</source>
        <translation>Listes par classe de contenu</translation>
    </message>
    <message>
        <source>%classname objects</source>
        <translation>Objets de la classe %classname</translation>
    </message>
    <message>
        <source>%class_identifier is not a valid content class identifier.</source>
        <translation>%class_identifier n'est pas un identifiant de classe valide</translation>
    </message>
	<message>
		<source>%remove_count objects deleted</source>
		<translation>%remove_count objets supprimés</translation>
	</message>
	<message>
		<source>%count objects</source>
		<translation>%count objets</translation>
	</message>
	<message>
		<source>Classes list</source>
		<translation>Liste des classes</translation>
	</message>
</context>
</TS>
