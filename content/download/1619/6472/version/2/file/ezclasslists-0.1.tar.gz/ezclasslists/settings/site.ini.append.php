<?php
/*

[RegionalSettings]
TranslationExtensions[]=ezclasslists

*/
?>
