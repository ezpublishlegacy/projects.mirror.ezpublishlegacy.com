<? /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=bcsimplesubscription

[CronjobPart-subscriptionexpiration]
Scripts[]
Scripts[]=subscriptionexpiration.php

*/ ?>