<?php /* #?ini charset="utf8"?

# [StylesheetSettings]
# SiteCSS=
# ClassesCSS=
# SiteCSS=packages/styles/t01/files/default/file/design/base/stylesheets/t1/site-colors.css
# ClassesCSS=packages/styles/t01/files/default/file/design/base/stylesheets/t1/classes-colors.css

[ExtensionSettings]
DesignExtensions[]=bcsimplesubscription

# A list of CSS file to always include in the pagelayout
# This can be filled in by extensions to provide styles
# that are not in the standard themes.
# CSSFileList[]

# [JavaScriptSettings]
# List of JavaScript files to include in pagelayout
# JavaScriptList[]

*/ ?>