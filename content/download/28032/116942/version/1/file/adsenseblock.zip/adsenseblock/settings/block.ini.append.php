<?php /*

[General]
AllowedTypes[]=AdSenseBlock

[AdSenseBlock]
Name=AdSense
ManualAddingOfItems=disabled
CustomAttributes[]=slot
CustomAttributes[]=width
CustomAttributes[]=height
ViewList[]=adsenseblock
ViewName[adsenseblock]=AdSense



*/ ?>
