<?php /* #?ini charset="utf-8"?


[block_adsense]
Source=block/view/view.tpl
MatchFile=block/adsenseblock.tpl
Subdir=templates
Match[type]=AdSenseBlock
Match[view]=adsenseblock


*/ ?>