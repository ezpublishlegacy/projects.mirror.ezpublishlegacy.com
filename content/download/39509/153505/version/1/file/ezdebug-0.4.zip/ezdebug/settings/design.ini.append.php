<?php /*

[ExtensionSettings]
DesignExtensions[]=ezdebug

*/ ?>