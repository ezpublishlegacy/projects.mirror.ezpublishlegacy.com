
CREATE TABLE IF NOT EXISTS `ezusercreatelimit_data` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `contentclass_id` int(11) NOT NULL,
  `limit_value` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  `modifier_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=1 ;

