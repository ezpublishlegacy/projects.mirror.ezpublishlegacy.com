<?php

/**
 * eZ User Create Limit extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class eZUserCreateLimitTemplateOperator {


	var $Operators;



	function __construct()
	{
		$this->Operators = array(
			'ezusercreatelimit_getcurrentlimit',
			'ezusercreatelimit_getcurrentobjectcount',
			'ezusercreatelimit_canedit',
			'ezusercreatelimit_cancreate',
			'ezusercreatelimit_cancurrentedit', 
			'ezusercreatelimit_cancurrentcreate',
		);
	}



	function &operatorList()
	{
		return $this->Operators;
	}



	function namedParameterPerOperator()
	{
		return true;
	}



	function namedParameterList()
	{
		return array(
			'ezusercreatelimit_getcurrentlimit' => array(
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => 0,
		),
		),
			'ezusercreatelimit_getcurrentobjectcount' => array(
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => 0,
		),
		),
			'ezusercreatelimit_canedit' => array(
				'user_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
		),
			'ezusercreatelimit_cancreate' => array(
				'user_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
		),
			'ezusercreatelimit_cancurrentedit' => array(
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
		),
			'ezusercreatelimit_cancurrentcreate' => array(
				'class_id' => array(  
					'type' => 'integer',
					'required' => true,
					'default' => false,
		),
		),
		);
	}



	function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
	{
		require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimittools.php' );

		switch( $operatorName )
		{
			case 'ezusercreatelimit_getcurrentlimit':
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::getCurrentUserLimit( $classID );
				break;
			case 'ezusercreatelimit_getcurrentobjectcount':
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::countCurrentUserClassObjects( $classID );
				break;
			case 'ezusercreatelimit_canedit':
				$userID = $namedParameters['user_id'];
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::canUserEdit( $userID, $classID );
				break;
			case 'ezusercreatelimit_cancreate':
				$userID = $namedParameters['user_id'];
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::canUserCreate( $userID, $classID );
				break;
			case 'ezusercreatelimit_cancurrentedit':
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::canCurrentUserEdit( $classID );
				break;
			case 'ezusercreatelimit_cancurrentcreate':
				$classID = $namedParameters['class_id'];
				$operatorValue = eZUserCreateLimitTools::canCurrentUserCreate( $classID );
				break;
		}
	}


};

?>
