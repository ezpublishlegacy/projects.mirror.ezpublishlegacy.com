<!DOCTYPE TS><TS>
<context>
    <name>extension/ezusercreatelimit</name>
    <message>
        <source>User's create limit</source>
        <translation>Limit tworzenia</translation>
    </message>
    <message>
        <source>Create limits</source>
        <translation>Limity tworzenia</translation>
    </message>
    <message>
        <source>Currently you are not allowed to create any objects of this type!</source>
        <translation>Obecnie nie możesz tworzyć żadnych obiektów tego typu!</translation>
    </message>
    <message>
        <source>Currently you are not allowed to create any more objects of this type!</source>
        <translation>Obecnie nie możesz tworzyć kolejnych obiektów tego typu!</translation>
    </message> 
    <message>
        <source>You have already created %objects objects of this type (including this one). Your limit is %limit.</source>
        <translation>Liczba stworzonych przez Ciebie obiektów tego typu (włącznie z bieżącym) wynosi %objects. Twój limit, to %limit.</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>    
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>  
    
    <message>
        <source>No user found by given ID!</source>
        <translation>Nie znaleziono użytkownika o podanym ID!</translation>
    </message>
    <message>
        <source>Given user ID is invalid!</source>
        <translation>Podany ID użytkownika jest nieprawidłowy!</translation>
    </message>
     <message>
        <source>Search for a user</source>
        <translation>Szukaj użytkownika</translation>
    </message>
     <message>
        <source>User found!</source>
        <translation>Znaleziono użytkownika!</translation>
    </message> 
    
     <message>
        <source>New limit value</source>
        <translation>Nowy limit</translation>
    </message>
     <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
     <message>
        <source>User ID</source>
        <translation>ID użytkownika</translation>
    </message>
     <message>
        <source>Apply changes</source>
        <translation>Wprowadź zmiany</translation>
    </message>
 	<message>
		<source>Search user</source>
		<translation>Wyszukaj użytkownika</translation>
	</message>	

     <message>
        <source>Limit overrides</source>
        <translation>Nadpisania limitów</translation>
    </message>
     <message>
        <source>Status overrides</source>
        <translation>Nadpisania statusów</translation>
    </message>
     <message>
        <source>Main settings</source>
        <translation>Ustawienia główne</translation>
    </message>

     <message>
        <source>Override zero limits</source>
        <translation>Nadpisz limity zerowe</translation>
    </message>
     <message>
        <source>Override unlimited</source>
        <translation>Nadpisz nielimitowane</translation>
    </message>
    
     <message>
        <source>Override default status</source>
        <translation>Nadpisz domyślne</translation>
    </message>
     <message>
        <source>Override individual status</source>
        <translation>Nadpisz indywidualne</translation>
    </message>
     <message>
        <source>Override 'by class' status</source>
        <translation>Nadpisz ustawione 'po klasie'</translation>
    </message>
     <message>
        <source>Override 'by user' status</source>
        <translation>Nadpisz ustawione 'po użytkowniku'</translation>
    </message>

     <message>
        <source>Default</source>
        <translation>Domyślny</translation>
    </message>
     <message>
        <source>Individual</source>
        <translation>Indywidualny</translation>
    </message>
     <message>
        <source>By class</source>
        <translation>Po klasie</translation>
    </message>
     <message>
        <source>By user</source>
        <translation>Po użytkowniku</translation>
    </message>

     <message>
        <source>Change class limits for all users</source>
        <translation>Zmiana limitów klasy dla wszystkich użytkowników</translation>
    </message>
     <message>
        <source>Change user limits for all classes</source>
        <translation>Zmiana limitów użytkownika dla wszystkich klas</translation>
    </message>
     <message>
        <source>Change user limits for given class</source>
        <translation>Zmiana limitów użytkownika dla konkretnej klasy</translation>
    </message>  
     <message>
        <source>List of user's limits</source>
        <translation>Lista limitów użytkownika</translation>
    </message> 
     <message>
        <source>User search</source>
        <translation>Wybór użytkownika</translation>
    </message>

	<message>
		<source>Class name</source>
		<translation>Nazwa klasy</translation>
	</message>    
	<message>
		<source>Objects</source>
		<translation>Obiektów</translation>
	</message>
	<message>
		<source>Limit</source>
		<translation>Limit</translation>
	</message>
	<message>
		<source>Created</source>
		<translation>Stworzono</translation>
	</message>
	<message>
		<source>Modified</source>
		<translation>Ost. modyfikacja</translation>
	</message>
	<message>
		<source>Modifier</source>
		<translation>Modyfikował(a)</translation>
	</message>
	<message>
		<source>Status</source>
		<translation>Status</translation>
	</message>

	<message>
		<source>User's limits list</source>
		<translation>Lista limitów użytkownika</translation>
	</message>
	<message>
		<source>Limit individually</source>
		<translation>Limitowanie indywidualne</translation>
	</message>
	<message>
		<source>Limit by class</source>
		<translation>Limitowanie po klasie</translation>
	</message>
	<message>
		<source>Limit by user</source>
		<translation>Limitowanie po użytkowniku</translation>
	</message>

	<message>
		<source>Show</source>
		<translation>Pokaż</translation>
	</message>
	<message>
		<source>Hide</source>
		<translation>Ukryj</translation>
	</message>	
	<message>
		<source>User ID</source>
		<translation>ID użytkownika</translation>
	</message>
	
	<message>
		<source>Unlimited</source>
		<translation>Nielimitowane</translation>
	</message>
	
	<message>
		<source>Edit user's limits</source>
		<translation>Edycja limitów użytkownika</translation>
	</message>
	<message>
		<source>Readme</source>
		<translation>Readme</translation>
	</message>
	
	<message>
		<source>Readme file</source>
		<translation>Plik readme</translation>
	</message>
	
	<message>
		<source>unlimited</source>
		<translation>bez limitu</translation>
	</message>
	<message>
		<source>under limit</source>
		<translation>poniżej limitu</translation>
	</message>
	<message>
		<source>over limit</source>
		<translation>powyżej limitu</translation>
	</message>
	<message>
		<source>has limit attribute in class definition</source>
		<translation>posiada atrybut limitowania w definicji klasy</translation>
	</message>	

</context>
</TS>
