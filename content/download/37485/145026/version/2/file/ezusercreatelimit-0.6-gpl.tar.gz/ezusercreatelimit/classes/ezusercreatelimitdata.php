<?php

/**
 * eZ User Create Limit extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimittools.php' );

/*
 * This class is responsible for operations on data of the persistent layer
 */
class eZUserCreateLimitData extends eZPersistentObject
{

	// Debug mode?
	const EZUSERCREATELIMIT_DEBUG = 0;


	/**
	 * Construct
	 *
	 * @param array $row
	 */
	public function __construct( $row )
	{
		$this->eZPersistentObject( $row );
	}


	/**
	 * Data definition
	 *
	 * @return array
	 */
	public static function definition()
	{
		return array(
			'fields' => array(
				'id' => array( 
					'name' => 'ID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true 
		),
				'user_id' => array(
					'name' => 'UserID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true 		
		),
				'contentclass_id' => array(
					'name' => 'ContentClassID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true 		
		),
				'limit_value' => array(
					'name' => 'LimitValue',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true 		
		),
				'status' => array(
					'name' => 'Status',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true 		
		),
				'created' => array(
					'name'  => 'Created',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true
		),
				'modified' => array(
					'name'  => 'Modified',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true
		),
				'modifier_id' => array(
					'name'  => 'ModifierID',
					'datatype' => 'integer',
					'default' => 0,
					'required' => true
		),
		),
			'keys'=> array(
				'id' 
				),
			'increment_key' => 'id',
			'class_name' => 'eZUserCreateLimitData',
			'name' => 'ezusercreatelimit_data' 
			);
	}


	/**
	 * Init record
	 *
	 * status #1 - config based
	 * status #2 - individual
	 * status #3 - all users by class
	 * status #4 - all classes by user
	 *
	 * @param integer $userID
	 * @param integer $contentClassID
	 * @param integer $limitValue
	 * @return object
	 */
	public static function doCreate( $userID, $contentClassID, $limitValue )
	{
		eZUserCreateLimitData::validateInteger( $userID );
		eZUserCreateLimitData::validateInteger( $contentClassID );
		eZUserCreateLimitData::validateInteger( $limitValue );

		$row = array(
			'id' => null,
			'user_id' => $userID,
			'contentclass_id' => $contentClassID,
			'limit_value' => $limitValue,
			'status' => 1,
			'created' => time(),
			'modified' => time(),
			'modifier_id' => eZUserCreateLimitTools::getCurrentUserID(),
		);

		return new eZUserCreateLimitData( $row );
		return false;
	}


	
	/**
	 * Main method for performing updates - operations on limits. 
	 *
	 * @param integer $limitValue
	 * @param integer $status
	 * @param integer $modifierID
	 * @param integer $id
	 * @param integer $userID
	 * @param integer $contentClassID
	 * @param boolean $skipNoLimit
	 * @param boolean $skipZeroLimit
	 * @param array $statusArray
	 */
	public static function doUpdate( $limitValue, $status, $modifierID, $id=false, $userID=false, $contentClassID=false, $skipNoLimit=true, $skipZeroLimit=true, $statusArray=false )
	{

		if( !$id && !$userID && !$contentClassID )
		{
			return;
		}

		if( !$statusArray )
		{
			$statusArray = array( 1 );
		}
		
		$commaCount = 0;
		$conditionCount = 0;

		$query = "UPDATE ezusercreatelimit_data SET ";

		$separate = self::commaSeparate( $commaCount );
		eZUserCreateLimitData::validateInteger( $limitValue );
		$query .= $separate.'limit_value='.$limitValue;

		$separate = self::commaSeparate( $commaCount );
		eZUserCreateLimitData::validateInteger( $status );
		$query .= $separate.'status='.$status;

		$separate = self::commaSeparate( $commaCount );
		eZUserCreateLimitData::validateInteger( $modifierID );
		$query .= $separate.'modifier_id='.$modifierID;

		$separate = self::commaSeparate( $commaCount );
		$query .= $separate.'modified='.time();

		if( $id )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			eZUserCreateLimitData::validateInteger( $id );
			$query .= ' '.$separate.' id='.$id;
		}

		if( $userID )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			eZUserCreateLimitData::validateInteger( $userID );
			$query .= ' '.$separate.' user_id='.$userID;
		}

		if( $contentClassID )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			eZUserCreateLimitData::validateInteger( $contentClassID );
			$query .= ' '.$separate.' contentclass_id='.$contentClassID;
		}

		if( $skipNoLimit )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$separate.' limit_value<>-1';
		}

		if( $skipZeroLimit )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			eZUserCreateLimitData::validateInteger( $contentClassID );
			$query .= ' '.$separate.' limit_value<>0';
		}

		if( is_array( $statusArray ) )
		{
			$separate = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$separate.' status IN ( ';
			$statusCnt = 0;
			foreach( $statusArray as $status )
			{
				eZUserCreateLimitData::validateInteger( $status );
				if( is_numeric( $status ) )
				{
					$statusCnt++;
					if( $statusCnt > 1 )
					{
						$query .= ', ';
					}
					$query .= $status;
				}
			}
			$query .= ' ) ';
		}
		
		if( self::EZUSERCREATELIMIT_DEBUG )
		eZDebug::writeDebug('Query: '.$query, 'eZUserCreateLimitData::doUpdate');

		$db = eZDB::instance();
		$db->query( $query );
		return;
	}


	/**
	 * Fetch data based on userID and/or contentClassID
	 * Fetching equivalent of doCount
	 *
	 * @param integer $userID
	 * @param integer $contentClassID
	 * @return array
	 */
	public static function doFetch( $userID=false, $contentClassID=false )
	{
		$conditionCount = 0;
		$query = 'SELECT * FROM ezusercreatelimit_data';

		if( $userID )
		{
			eZUserCreateLimitData::validateInteger( $userID );
			$conditionWord = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$conditionWord.' user_id='.$userID;
		}

		if( $contentClassID )
		{
			eZUserCreateLimitData::validateInteger( $contentClassID );
			$conditionWord = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$conditionWord.' contentclass_id='.$contentClassID;
		}

		if( self::EZUSERCREATELIMIT_DEBUG )
		eZDebug::writeDebug('Query: '.$query, 'eZUserCreateLimitData::doFetch');
		
		$db = eZDB::instance();
		$rows = $db->arrayQuery( $query );
		return $rows;
	}


	/**
	 * Count data based on userID and/or contentClassID
	 * Counting equivalent of doFetch
	 *
	 * @param integer $userID
	 * @param integer $contentClassID
	 * @return integer
	 */
	public static function doCount( $userID=false, $contentClassID=false )
	{
		$conditionCount = 0;
		$query = 'SELECT COUNT(id) AS cnt FROM ezusercreatelimit_data';

		if( $userID )
		{
			eZUserCreateLimitData::validateInteger( $userID );
			$conditionWord = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$conditionWord.' user_id='.$userID;
		}

		if( $contentClassID )
		{
			eZUserCreateLimitData::validateInteger( $contentClassID );
			$conditionWord = self::sqlConditionSwitch( $conditionCount );
			$query .= ' '.$conditionWord.' contentclass_id='.$contentClassID;
		}

		if( self::EZUSERCREATELIMIT_DEBUG )
		eZDebug::writeDebug('Query: '.$query, 'eZUserCreateLimitData::doCount');
		
		$db = eZDB::instance();
		$rows = $db->arrayQuery( $query );
		return $rows[0]['cnt'];
	}


	/**
	 * Helper: SQL condition automation
	 *
	 * @param integer $count
	 * @return string
	 */
	public static function sqlConditionSwitch( &$count )
	{
		if($count == 0)
		{
			$count++;
			return 'WHERE';
		}
		else
		{
			$count++;
			return 'AND';
		}
	}


	/**
	 * Helper: comma separate
	 *
	 * @param integer $value
	 */	
	public static function commaSeparate( &$count )
	{
		if($count == 0)
		{
			$count++;
			return '';
		}
		else
		{
			$count++;
			return ', ';
		}
	}


	/**
	 * Helper: safe-force integer
	 *
	 * @param integer $value
	 */
	public static function validateInteger( &$value )
	{
		if( !is_numeric( $value ) )
		{
			$value = 0;
		}
		else
		{
			$value = (int)round( $value );
		}
		return;
	}



}
?>
