<?php

/**
 * eZ User Create Limit extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


class eZUserCreateLimitType extends eZDataType
{


	const DATA_TYPE_STRING = 'ezusercreatelimit';


	public function __construct()
	{
		$this->eZDataType( self::DATA_TYPE_STRING, ezi18n( 'extension/ezusercreatelimit', "User's create limit" ) );
	}


	function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
	{
		if ( $currentVersion != false )
		{
			$dataText = $originalContentObjectAttribute->attribute( "data_text" );
			$contentObjectAttribute->setAttribute( "data_text", $dataText );
		}
	}


	function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
	{
		require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimittools.php' );
		return eZUserCreateLimitTools::validateHTTPInput( $contentObjectAttribute );
	}


	function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
	{
		if ( $http->hasPostVariable( $base . "_data_text_" . $contentObjectAttribute->attribute( "id" ) ) )
		{
			$data = $http->postVariable( $base . "_data_text_" . $contentObjectAttribute->attribute( "id" ) );
			$contentObjectAttribute->setAttribute( "data_text", $data );
			return true;
		}
		return true;
	}


	function storeObjectAttribute( $attribute )
	{
		return;
	}


	function objectAttributeContent( $contentObjectAttribute )
	{
		return $contentObjectAttribute->attribute( "data_text" );
	}


	function isIndexable()
	{
		return false;
	}


	function metaData( $contentObjectAttribute )
	{
		return '';
	}


	function toString( $contentObjectAttribute )
	{
		return $contentObjectAttribute->attribute( 'data_text' );
	}


	function fromString( $contentObjectAttribute, $string )
	{
		return $contentObjectAttribute->setAttribute( 'data_text', $string );
	}


	function title( $contentObjectAttribute, $name = null )
	{
		return $contentObjectAttribute->attribute( "data_text" );
	}


	function hasObjectAttributeContent( $contentObjectAttribute )
	{
		return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
	}


	function isInformationCollector()
	{
		return false;
	}


	function sortKey( $contentObjectAttribute )
	{
		return '';
	}


	function sortKeyType()
	{
		return 'string';
	}


}

eZDataType::register( eZUserCreateLimitType::DATA_TYPE_STRING, "eZUserCreateLimitType" );

?>
