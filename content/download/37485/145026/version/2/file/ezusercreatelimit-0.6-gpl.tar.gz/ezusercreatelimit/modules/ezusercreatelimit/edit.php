<?php

/**
 * eZ User Create Limit extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

require_once( 'kernel/common/template.php' );
require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimittools.php' );
require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimitdata.php' );



$tpl = templateInit();
$Result = array();
$Module = $Params['Module'];


$http = eZHTTPTool::instance();


if( $http->hasPostVariable( 'eZUserCreateLimitUserSearch' ) )
{
	if( $http->hasPostVariable( 'eZUserCreateLimitUserID' ) )
	{
		if( is_numeric( $http->postVariable( 'eZUserCreateLimitUserID' ) ) )
		{
			$Module->redirectToView( 'edit', array( $http->postVariable( 'eZUserCreateLimitUserID' ) ) );
		}
	}
}



if( $http->hasPostVariable( 'eZUserCreateLimitOneClassOneUser' ) || $http->hasPostVariable( 'eZUserCreateLimitOneClassAllUsers' ) || $http->hasPostVariable( 'eZUserCreateLimitOneUserAllClasses' ) )
{
	$newLimitValue = 0;
	if( $http->hasPostVariable( 'eZUserCreateLimitLimitValue' ) )
	{
		if( is_numeric( $http->postVariable( 'eZUserCreateLimitLimitValue' ) ) )
		{
			$newLimitValue = (int)$http->postVariable( 'eZUserCreateLimitLimitValue' );
			if( $newLimitValue < -1 )
			{
				$newLimitValue = 0;
			}
		}
	}
}


if( $http->hasPostVariable( 'eZUserCreateLimitOneClassAllUsers' ) || $http->hasPostVariable( 'eZUserCreateLimitOneUserAllClasses' ) )
{
	$statusArray = array();
	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideStatus1' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideStatus1' ) == 'on' )
		{
			$statusArray[]=1;
		}
	}
	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideStatus2' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideStatus2' ) == 'on' )
		{
			$statusArray[]=2;
		}
	}
	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideStatus3' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideStatus3' ) == 'on' )
		{
			$statusArray[]=3;
		}
	}

	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideStatus4' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideStatus4' ) == 'on' )
		{
			$statusArray[]=4;
		}
	}

	$skipNoLimit=true;
	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideNoLimit' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideNoLimit' ) == 'on' )
		{
			$skipNoLimit=false;
		}
	}

	$skipZeroLimit=true;
	if( $http->hasPostVariable( 'eZUserCreateLimitOverrideZeroLimit' ) )
	{
		if( $http->postVariable( 'eZUserCreateLimitOverrideZeroLimit' ) == 'on' )
		{
			$skipZeroLimit=false;
		}
	}
}


if( $http->hasPostVariable( 'eZUserCreateLimitOneClassAllUsers' ) )
{
	if( is_numeric( $http->postVariable( 'eZUserCreateLimitClassID' ) ) )
	{
		eZUserCreateLimitTools::limitOneClassAllUsers( $newLimitValue, $http->postVariable( 'eZUserCreateLimitClassID' ), $skipNoLimit, $skipZeroLimit, $statusArray );
	}
}


if( $http->hasPostVariable( 'eZUserCreateLimitOneUserAllClasses' ) )
{
	if( is_numeric( $http->postVariable( 'eZUserCreateLimitUserID' ) ) )
	{
		eZUserCreateLimitTools::limitOneUserAllClasses( $newLimitValue, $http->postVariable( 'eZUserCreateLimitUserID' ), $skipNoLimit, $skipZeroLimit, $statusArray );
	}
}

if( $http->hasPostVariable( 'eZUserCreateLimitOneClassOneUser' ) )
{
	if( is_numeric( $http->postVariable( 'eZUserCreateLimitUserID' ) ) && is_numeric( $http->postVariable( 'eZUserCreateLimitClassID' ) ) )
	{
		eZUserCreateLimitTools::limitOneClassOneUser( $newLimitValue, $http->postVariable( 'eZUserCreateLimitUserID' ), $http->postVariable( 'eZUserCreateLimitClassID' ) );
	}
}


$Result['path'] = array( array( 'url' => false,'text' => 'User create limit' ) );


$tpl->setVariable( 'userID', $Module->NamedParameters['UserID'] );
$tpl->setVariable( 'mainTemplate', 'nouser' );
$tpl->setVariable( 'mainTemplateData', false );


if( isset( $Module->NamedParameters['UserID'] ) )
{
	if( is_numeric( $Module->NamedParameters['UserID'] ) )
	{
		
		
		$userID = $Module->NamedParameters['UserID'];
		$userObject = eZUserCreateLimitTools::getUserObjectByID( $userID );
		if( is_object( $userObject ) )
		{
			
			array_push( $Result['path'], array( 'url' => false, 'text' => 'Edit' ) );
			$classLimitMatrixResult = eZUserCreateLimitTools::getClassLimitMatrixByUserID( $userID );

			if( $classLimitMatrixResult[1] )
			{
				$Module->redirectToView( 'edit', array( $userID ) );
			}

			$classLimitMatrix = $classLimitMatrixResult[0];
			$classSelectArray = eZUserCreateLimitTools::getSelectClassList();

			$tpl->setVariable( 'mainTemplate', 'user' );
			$tpl->setVariable( 'mainTemplateData', $classLimitMatrix );
			$tpl->setVariable( 'mainTemplateSelectArray', $classSelectArray );

		}
		else
		{
			array_push( $Result['path'], array( 'url' => false, 'text' => 'Unknown user' ) );
			$tpl->setVariable( 'mainTemplate', 'unknownuser' );
		}


	}
	else
	{
		array_push( $Result['path'], array( 'url' => false, 'text' => 'Invalid user' ) );
		$tpl->setVariable( 'mainTemplate', 'invaliduser' );
	}
}




$Result['left_menu'] = 'design:parts/createlimit/menu.tpl';
$Result['content'] = $tpl->fetch( "design:createlimit/edit.tpl" );


?>