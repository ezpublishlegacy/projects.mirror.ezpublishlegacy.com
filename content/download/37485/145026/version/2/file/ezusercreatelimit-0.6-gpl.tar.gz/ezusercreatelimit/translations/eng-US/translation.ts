<!DOCTYPE TS><TS>
<context>
    <name>extension/ezusercreatelimit</name>
    <message>
        <source>User's create limit</source>
        <translation>User's create limit</translation>
    </message>
    <message>
        <source>Create limits</source>
        <translation>Create limits</translation>
    </message>
    <message>
        <source>Currently you are not allowed to create any objects of this type!</source>
        <translation>Currently you are not allowed to create any objects of this type!</translation>
    </message>
    <message>
        <source>Currently you are not allowed to create any more objects of this type!</source>
        <translation>Currently you are not allowed to create any more objects of this type!</translation>
    </message> 
    <message>
        <source>You have already created %objects objects of this type (including this one). Your limit is %limit.</source>
        <translation>You have already created %objects objects of this type (including this one). Your limit is %limit.</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>    
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>    
    
    
    <message>
        <source>No user found by given ID!</source>
        <translation>No user found by given ID!</translation>
    </message>
    <message>
        <source>Given user ID is invalid!</source>
        <translation>Given user ID is invalid!</translation>
    </message>
     <message>
        <source>Search for a user</source>
        <translation>Search for a user</translation>
    </message>
     <message>
        <source>User found!</source>
        <translation>User found!</translation>
    </message> 
    
     <message>
        <source>New limit value</source>
        <translation>New limit value</translation>
    </message>
     <message>
        <source>Class</source>
        <translation>Class</translation>
    </message>
     <message>
        <source>User ID</source>
        <translation>User ID</translation>
    </message>
     <message>
        <source>Apply changes</source>
        <translation>Apply changes</translation>
    </message>
	<message>
		<source>Search user</source>
		<translation>Search user</translation>
	</message>	

     <message>
        <source>Limit overrides</source>
        <translation>Limit overrides</translation>
    </message>
     <message>
        <source>Status overrides</source>
        <translation>Status overrides</translation>
    </message>
     <message>
        <source>Main settings</source>
        <translation>Main settings</translation>
    </message>

     <message>
        <source>Override zero limits</source>
        <translation>Override zero limits</translation>
    </message>
     <message>
        <source>Override unlimited</source>
        <translation>Override unlimited</translation>
    </message>
    
     <message>
        <source>Override default status</source>
        <translation>Override default status</translation>
    </message>
     <message>
        <source>Override individual status</source>
        <translation>Override individual status</translation>
    </message>
     <message>
        <source>Override 'by class' status</source>
        <translation>Override 'by class' status</translation>
    </message>
     <message>
        <source>Override 'by user' status</source>
        <translation>Override 'by user' status</translation>
    </message>

     <message>
        <source>Default</source>
        <translation>Default</translation>
    </message>
     <message>
        <source>Individual</source>
        <translation>Individual</translation>
    </message>
     <message>
        <source>By class</source>
        <translation>By class</translation>
    </message>
     <message>
        <source>By user</source>
        <translation>By user</translation>
    </message>

     <message>
        <source>Change class limits for all users</source>
        <translation>Change class limits for all users</translation>
    </message>
     <message>
        <source>Change user limits for all classes</source>
        <translation>Change user limits for all classes</translation>
    </message>
     <message>
        <source>Change user limits for given class</source>
        <translation>Change user limits for given class</translation>
    </message>
     <message>
        <source>List of user's limits</source>
        <translation>List of user's limits</translation>
    </message>
     <message>
        <source>User search</source>
        <translation>User search</translation>
    </message>
    
	<message>
		<source>Class name</source>
		<translation>Class name</translation>
	</message>    
	<message>
		<source>Objects</source>
		<translation>Objects</translation>
	</message>
	<message>
		<source>Limit</source>
		<translation>Limit</translation>
	</message>
	<message>
		<source>Created</source>
		<translation>Created</translation>
	</message>
	<message>
		<source>Modified</source>
		<translation>Modified</translation>
	</message>
	<message>
		<source>Modifier</source>
		<translation>Modifier</translation>
	</message>
	<message>
		<source>Status</source>
		<translation>Status</translation>
	</message>
	
	<message>
		<source>User's limits list</source>
		<translation>User's limits list</translation>
	</message>
	<message>
		<source>Limit individually</source>
		<translation>Individual limits</translation>
	</message>
	<message>
		<source>Limit by class</source>
		<translation>Limits by class</translation>
	</message>
	<message>
		<source>Limit by user</source>
		<translation>Limits by user</translation>
	</message>
		
	<message>
		<source>Show</source>
		<translation>Show</translation>
	</message>
	<message>
		<source>Hide</source>
		<translation>Hide</translation>
	</message>	
	<message>
		<source>User ID</source>
		<translation>User ID</translation>
	</message>	
	
	<message>
		<source>Unlimited</source>
		<translation>Unlimited</translation>
	</message>	

	<message>
		<source>Edit user's limits</source>
		<translation>Edit user's limits</translation>
	</message>
	<message>
		<source>Readme</source>
		<translation>Readme</translation>
	</message>

	<message>
		<source>Readme file</source>
		<translation>Readme file</translation>
	</message>

	<message>
		<source>unlimited</source>
		<translation>unlimited</translation>
	</message>
	<message>
		<source>under limit</source>
		<translation>under limit</translation>
	</message>
	<message>
		<source>over limit</source>
		<translation>over limit</translation>
	</message>
	<message>
		<source>has limit attribute in class definition</source>
		<translation>has limit attribute in class definition</translation>
	</message>

</context>
</TS>
