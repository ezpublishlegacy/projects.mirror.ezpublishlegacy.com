<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezusercreatelimit

*/ ?>
