<?php /* #?ini charset="utf-8"?


[NavigationPart]
Part[ezcreatelimitnavigationpart]=Create limits


[TopAdminMenu]
Tabs[]=createlimit


[Topmenu_createlimit]
NavigationPartIdentifier=ezcreatelimitnavigationpart
Name=Create limits
#Tooltip=Manage items and settings that belong to your account.
URL[]
URL[default]=ezusercreatelimit/edit
URL[browse]=ezusercreatelimit/edit
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>