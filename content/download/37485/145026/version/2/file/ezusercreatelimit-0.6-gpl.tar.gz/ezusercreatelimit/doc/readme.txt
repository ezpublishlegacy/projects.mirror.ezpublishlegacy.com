eZ User Create Limit extension for eZ Publish 4.0
version 0.6 beta

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ryba.eu



What is it?
-----------

This extension is meant to provide a flexible control over each user's 
create/edit activity in relation to each content class. It introduces 
a datatype that doesn't validate if user is trying to go beyond one's defined 
limits, and couple of template operators that can help produce functional
templates.

When you install this extension, a new datatype will be available, called
'User's create limit'. Simply add one attribute of this type to each class for
which you wish to be able to define creation limits per user. That's it.
The very first time the user attempts to create/edit an object of such class,
a default limit will be stored, based on your ini configuration file. From
that moment on you can control and change any user's limits via administration
interface (a new tab and navigation part will be available).

More comming soon...



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Template operators
------------------

ezusercreatelimit_canedit( $userID, $classID )
ezusercreatelimit_cancreate( $userID, $classID )
ezusercreatelimit_cancurrentedit( $classID )
ezusercreatelimit_cancurrentcreate( $classID )

Detailed description coming soon...



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components: Base, File
- MySQL access for table creation



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/ezusercreatelimit/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=ezusercreatelimit

3. Import SQL to you database (/sql subdirectory).

4. Configure usercreatelimit.ini file according to your preferences.

5. Clear cache.



Changelog
---------

# Consider
- Add draft/trash configuration
- Default limits by user groups 
- Cronjob diagnostics
- Turn on/off validation per siteaccess

# v1.0 stable, unreleased
- Confirmation that it works OK ;)

# v0.7 beta, public, unreleased
- Enhanced user search feature (by string or by group or a browseing tool)

# v0.6 beta, public, 2007.12.27
+ Bug fix: links to the limit modifier are invalid.

# v0.5 beta, public, 2007.12.23
+ Tests with multiple versions, translations, trash, drafts.
+ Improved admin interface with icons and legends.
+ Debug mode off by default.

# v0.4 beta, public, 2007.12.21
+ Code review, phpdoc.
+ Cover everything with translations.
+ Better documentation.
+ Improved admin interface.
+ Development errors fixed.

# v0.3 beta, local, 2007.12.20
+ Operations on limits.
+ Administration interface tools for easier limit management.
+ Use translations.
+ Debug mode improved.

# v0.2 beta, public, 2007.12.13
+ Better code documentation and cleanup.
+ Logging and debugging. 

# v0.1 alpha, public, 2007.12.11
+ First almost fully working version, the basic elements and functionality 
  only, with little info. 

# v0.0 alpha, local, 2007.12.11
+ Start.


/+/ complete
/-/ plan or in progress
