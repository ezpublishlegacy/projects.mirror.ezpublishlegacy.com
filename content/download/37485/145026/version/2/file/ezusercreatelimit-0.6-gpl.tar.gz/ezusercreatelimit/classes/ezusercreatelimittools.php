<?php

/**
 * eZ User Create Limit extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


require_once( 'extension/ezusercreatelimit/classes/ezusercreatelimitdata.php' );

class eZUserCreateLimitTools
{


	// Debug mode?
	const EZUSERCREATELIMIT_DEBUG = 0;


	/**
	 * This methid is directly used to validate ezusercreatelimit datatype
	 * It checks if user can still create/edit, if not - it yields invalid
	 * state and sets a proper message
	 *
	 * @param object $contentObjectAttribute
	 * @return integer
	 */
	public static function validateHTTPInput( $contentObjectAttribute )
	{
		$contentObjectID = $contentObjectAttribute->ContentObjectID;
		$contentObject = eZContentObject::fetch( $contentObjectID, true );
		$classID = $contentObject->ClassID;

		$canEdit = self::canCurrentUserEdit( $classID );
		if( !$canEdit )
		{
			$currentUserLimit = self::getCurrentUserLimit( $classID );

			switch( $currentUserLimit )
			{
				case -1:
					break;
				case 0:
					$contentObjectAttribute->setValidationError( ezi18n('extension/ezusercreatelimit',
						'Currently you are not allowed to create any objects of this type!' ) );
					break;
				default:
					$contentObjectAttribute->setValidationError( ezi18n('extension/ezusercreatelimit',
						'Currently you are not allowed to create any more objects of this type!' ) );
					break;
			}
			return eZInputValidator::STATE_INVALID;
		}
		return;
	}


	/**
	 * Count content objects created by given user
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return integer
	 */
	public static function countClassObjectsByUserID( $userID, $classID )
	{
		return eZContentObject::fetchObjectCountByUserID( $classID, $userID );
	}


	/**
	 * Count content objects created by current user
	 *
	 * @param integer $classID
	 * @return integer
	 */
	public static function countCurrentUserClassObjects( $classID )
	{
		return self::countClassObjectsByUserID( self::getCurrentUserID(), $classID );
	}


	/**
	 * Retrieves an array of class IDs that belong to classes that actually do
	 * have the attribute used by this extension
	 *
	 * @return array
	 */
	public static function getUserCreateLimitedClassArray()
	{
		$classArray = array();
		$attributeArray = eZContentClassAttribute::fetchList( true, array( 'data_type' => 'ezusercreatelimit' ) );
		foreach( $attributeArray as $classAttribute )
		{
			array_push( $classArray, $classAttribute->ContentClassID );
		}
		return $classArray;
	}



	/**
	 * This is the main method used to retrieve and arrange data for
	 * extension's administration interface edit tool.
	 *
	 * @param integer $userID
	 * @return array
	 */
	public static function getClassLimitMatrixByUserID( $userID )
	{
		$userLimitArray = self::getStoredLimitsByUserID( $userID );
		$classList = self::getClassList();
		$limitedClassList = self::getUserCreateLimitedClassArray();
		$classLimitMatrix = array();
		$mustRedirect = false;
		$modifierArray = array();

		foreach( $classList as $classObject )
		{
			$classID = $classObject->ID;
			$classLimitMatrix[$classID] = array();

			if( isset( $userLimitArray[$classID] ) )
			{
				$classLimitMatrix[$classID] = $userLimitArray[$classID];
			}
			else
			{
				eZUserCreateLimitTools::getLimitByUserID( $userID, $classID );
				$classLimit = eZUserCreateLimitData::doFetch( $userID, $classID );
				$classLimitMatrix[$classID] = $classLimit;
				$mustRedirect = true;
			}

			$classLimitMatrix[$classID]['object_count'] = self::countClassObjectsByUserID( $userID, $classID );

			$classLimitMatrix[$classID]['is_limited'] = false;
			if( in_array( $classID, $limitedClassList ) )
			{
				$classLimitMatrix[$classID]['is_limited'] = true;
			}

			$classLimitMatrix[$classID]['class_identifier'] = $classObject->Identifier;

			if( $classLimitMatrix[$classID]['modifier_id'] != 0 )
			{
				if( !isset( $modifierArray[$classLimitMatrix[$classID]['modifier_id']] ) )
				{
					$mainNode = eZContentObjectTreeNode::findMainNode( $classLimitMatrix[$classID]['modifier_id'] );
					$userNode = eZContentObjectTreeNode::fetch( $mainNode );
					$modifierArray[$classLimitMatrix[$classID]['modifier_id']]['name'] = $userNode->Name;
					$modifierArray[$classLimitMatrix[$classID]['modifier_id']]['path'] = $userNode->urlAlias();
				}
				$classLimitMatrix[$classID]['modifier_name'] = $modifierArray[$classLimitMatrix[$classID]['modifier_id']]['name'];
				$classLimitMatrix[$classID]['modifier_path'] = $modifierArray[$classLimitMatrix[$classID]['modifier_id']]['path'];
			}
			else
			{
				$classLimitMatrix[$classID]['modifier_name'] = '0';
			}
			// TODO: Secure multiple language contexts!
			$classLimitMatrix[$classID]['class_name'] = $classObject->NameList->NameList[$classObject->NameList->NameList['always-available']];
		}
		return array( $classLimitMatrix, $mustRedirect );
	}


	/**
	 * This method gets all user's stored limit information (no defauls
	 * or other rules will be taken under consideration here).
	 *
	 * @param integer $userID
	 * @return array
	 */
	
	public static function getStoredLimitsByUserID( $userID )
	{
		$limitArray = eZUserCreateLimitData::doFetch( $userID );
		$limitArrayByClassID = array();
		foreach( $limitArray as $limit )
		{
			$limitArrayByClassID[$limit['contentclass_id']] = $limit;
		}
		return $limitArrayByClassID;
	}


	/**
	 * Gets a list of all available classes in the system and arranges them
	 * for best HTML form drop-down list use.
	 *
	 * @return array
	 */	
	public static function getSelectClassList()
	{
		$classList = self::getClassList();
		$selectArray = array();
		foreach( $classList as $class )
		{
			// TODO: Secure multiple language contexts!
			$selectArray[$class->ID] = $class->NameList->NameList[$class->NameList->NameList['always-available']];
		}
		return $selectArray;
	}

	
	/**
	 * A wrapper method to retrieve all classes available in the system
	 *
	 * @return array
	 */
	public static function getClassList()
	{
		return eZContentClass::fetchAllClasses();
	}


	/**
	 * Attempts to find a persistent data record with limit entry
	 * Returns limit value on success, otherwise false
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return integer
	 */
	public static function getStoredLimitByUserID( $userID, $classID )
	{
		$data = eZUserCreateLimitData::doFetch( $userID, $classID );
		if( $data )
		{
			if( isset( $data[0]['limit_value'] ) )
			{
				return (int)$data[0]['limit_value'];
			}
		}
		return false;
	}


	/**
	 * This method is run if it failed to find a persistent record
	 * It figures out user's limit and attempts to create persistent record
	 * Returns user's limit
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return integer
	 */
	public static function getDefaultLimitByUserID( $userID, $classID )
	{
		$defaultLimit = false;
		$classIdentifier = self::getClassIdentifierByID( $classID );
		$ini = eZINI::instance('usercreatelimit.ini');
		if( $classIdentifier )
		{
			if( $ini->hasGroup( 'DefaultLimitSettings' ) )
			{
				$defaultLimitSettings = $ini->group( 'DefaultLimitSettings' );
					
				if( is_array( $defaultLimitSettings['LimitByUserID'] ) )
				{
					if( in_array( $userID, array_keys( $defaultLimitSettings['LimitByUserID'] ) ) )
					{
						$defaultLimit = $defaultLimitSettings['LimitByUserID'][$userID];
					}
					else
					{
						if( is_array( $defaultLimitSettings['LimitByClassIdentifier'] ) )
						{
							if( in_array( $classIdentifier, array_keys( $defaultLimitSettings['LimitByClassIdentifier'] ) ) )
							{
								$defaultLimit = $defaultLimitSettings['LimitByClassIdentifier'][$classIdentifier];
							}
						}
					}
				}
					
			}
		}
		if( !$defaultLimit )
		{
			if( $ini->hasVariable( 'DefaultLimitSettings', 'LimitGlobal' ) )
			{
				$defaultLimit = $ini->variable( 'DefaultLimitSettings', 'LimitGlobal' );
			}
			else
			{
				$defaultLimit = 1;
			}
		}

		$eZLimitObject = eZUserCreateLimitData::doCreate( $userID, $classID, $defaultLimit );
		$eZLimitObject->store();

		return $defaultLimit;
	}


	/**
	 * The main method called for getting user limit for a given class.
	 * If no stored limit found, defaults will be evaluated.
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return integer
	 */
	public static function getLimitByUserID( $userID, $classID )
	{
		$limit = self::getStoredLimitByUserID( $userID, $classID );
		if( is_int( $limit ) )
		{
			return $limit;
		}
		return self::getDefaultLimitByUserID( $userID, $classID );
	}


	/**
	 * Gets limit of a current user for a given classID
	 *
	 * @param integer $classID
	 * @return integer
	 */
	public static function getCurrentUserLimit( $classID )
	{
		return self::getLimitByUserID( self::getCurrentUserID(), $classID );
	}


	/**
	 * Helper: get classIdentifier based on classID
	 * Returns false on failure
	 *
	 * @param integer $classID
	 * @return string
	 */
	public static function getClassIdentifierByID( $classID )
	{
		$contentClassObject = eZContentClass::fetch( $classID, true );
		if( is_object( $contentClassObject ) )
		{
			return $contentClassObject->Identifier;
		}
		eZDebug::writeError( 'No class identifier found for class id '.$classID, 'eZUserCreateLimitTools::getClassIdentifierByID' );
		return false;
	}


	/**
	 * Checks if current user can edit class of given classID
	 *
	 * @param integer $classID
	 * @return boolean
	 */
	public static function canCurrentUserEdit( $classID )
	{
		return self::canUserEdit( self::getCurrentUserID(), $classID );
	}


	/**
	 * Checks if user can edit class of given classID
	 * If limit is -1, there's no limit.
	 * If limit is 0, there's nothing to be allowed ;)
	 * Otherwise, it's limit value
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return boolean
	 */
	public static function canUserEdit( $userID, $classID )
	{
		$userLimit = self::getLimitByUserID( $userID, $classID );
		if( $userLimit === -1 )
		{
			return true;
		}

		$userObjectCount = self::countClassObjectsByUserID( $userID, $classID );
		if( $userObjectCount <= $userLimit )
		{
			if( $userLimit > 0 )
			{
				return true;
			}
		}

		return false;
	}


	/**
	 * Checks if current user can create class of given classID
	 *
	 * @param integer $classID
	 * @return boolean
	 */
	public static function canCurrentUserCreate( $classID )
	{
		return self::canUserCreate( self::getCurrentUserID(), $classID );
	}


	/**
	 * Checks if user can create class of given classID
	 * If limit is -1, there's no limit.
	 * If limit is 0, there's nothing to be allowed ;)
	 * Otherwise, it's limit value
	 *
	 * @param integer $userID
	 * @param integer $classID
	 * @return boolean
	 */
	public static function canUserCreate( $userID, $classID )
	{
		$userLimit = self::getLimitByUserID( $userID, $classID );
		if( $userLimit === -1 )
		{
			return true;
		}

		$userObjectCount = self::countClassObjectsByUserID( $userID, $classID );
		if( $userObjectCount < $userLimit )
		{
			if( $userLimit > 0 )
			{
				return true;
			}
		}

		return false;
	}


	/**
	 * Gets current userID
	 *
	 * @return integer
	 */
	public static function getCurrentUserID()
	{
		return eZUser::currentUserID();
	}


	/**
	 * Gets user objects by user id (wrapper).
	 *
	 * @param integer $userID
	 * @return object
	 */
	
	public static function getUserObjectByID( $userID )
	{
		return eZUser::fetch( $userID );
	}


	/**
	 * Performs limit operations that apply to all users for given content
	 * class. This operation, if carried out on a single limit record, leaves
	 * it with status 3.
	 *
	 * @param integer $limit
	 * @param integer $contentClassID
	 * @param boolean $skipNoLimit
	 * @param boolean $skipZeroLimit
	 * @param array $statusArray
	 */
	public static function limitOneClassAllUsers( $limit, $contentClassID, $skipNoLimit=true, $skipZeroLimit=true, $statusArray=false )
	{
		eZUserCreateLimitTools::updateData( $limit, 3, false, false, $contentClassID, $skipNoLimit, $skipZeroLimit, $statusArray );
	}


	/**
	 * Performs limit operations that apply to all classes for a given user.
	 * This operation, if carried out on a single limit record, leaves
	 * it with status 4.
	 * 
	 * @param integer $limit
	 * @param integer $userID
	 * @param boolean $skipNoLimit
	 * @param boolean $skipZeroLimit
	 * @param array $statusArray
	 */
	public static function limitOneUserAllClasses( $limit, $userID, $skipNoLimit=true, $skipZeroLimit=true, $statusArray=false )
	{
		eZUserCreateLimitTools::updateData( $limit, 4, false, $userID, false, $skipNoLimit, $skipZeroLimit, $statusArray );
	}


	/**
	 * Performs limit operations that apply to exactly one user and one class.
	 * This operation, if carried out on a single limit record, leaves it with
	 * status 2.
	 * 
	 * Since this is exact targeting, this method overrides any previous limit
	 * and any previous status by default.
	 *
	 * @param integer $limit
	 * @param integer $userID
	 * @param integer $contentClassID
	 */
	public static function limitOneClassOneUser( $limit, $userID, $contentClassID )
	{
		eZUserCreateLimitTools::updateData( $limit, 2, false, $userID, $contentClassID, false, false, array( 1, 2, 3, 4 ) );
	}


	/**
	 * This class wraps around update method in the persistent data class.
	 *
	 * @param integer $limit
	 * @param integer $status
	 * @param integer $id
	 * @param integer $userID
	 * @param integer $contentClassID
	 * @param boolean $skipNoLimit
	 * @param boolean $skipZeroLimit
	 * @param array $statusArray
	 */
	public static function updateData( $limit, $status, $id=false, $userID=false, $contentClassID=false, $skipNoLimit=true, $skipZeroLimit=true, $statusArray=false )
	{
		eZUserCreateLimitData::doUpdate( $limit, $status, self::getCurrentUserID(), $id, $userID, $contentClassID, $skipNoLimit, $skipZeroLimit, $statusArray );
	}


}
?>
