<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezusercreatelimit

[CronjobPart-infrequent]
Scripts[]=ezusercreatelimit_diagnostics.php

*/ ?>
