<?php /*

[ExtensionSettings]
DesignExtensions[]=ezjpdatatypes

*/ ?>
