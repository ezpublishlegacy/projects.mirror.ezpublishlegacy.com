<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpMail
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpMail extends eZEmailType
{
    const DATATYPE_STRING = "jpmail";

    /**
     * Ctor.
     * 
     */
    public function jpMail()
    {
        $this->eZDataType( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "email with verification",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'email' )) );
    }

    function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) )
            )
        {
            $mail1 = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( "id" ) );
            $mail2 = $http->postVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( "id" ) );
            return $this->validateMailAdress( $mail1, $mail2, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) )
            )
        {
            $mail1 = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( "id" ) );
            $mail2 = $http->postVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( "id" ) );
            return $this->validateMailAdress( $mail1, $mail2, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function validateMailAdress( $mail1, $mail2, $contentObjectAttribute )
    {
        $trimmedEmail = trim( $mail1 );
        $trimmedEmail2 = trim( $mail2 );

        if ( $trimmedEmail == "" )
        {
            // if entered email is empty and required then return state invalid
            if ( $contentObjectAttribute->validateIsRequired() )
            {
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                    'The email address is empty.' ) );
                return eZInputValidator::STATE_INVALID;
            }
            else
            {
                return eZInputValidator::STATE_ACCEPTED;
            }
        }
        else
        {
            if( $trimmedEmail !== $trimmedEmail2 )
            {
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                     'The emails addresses dont match.' ) );
                return eZInputValidator::STATE_INVALID;
            }
            // if entered email is not empty then we should validate it in any case
            return $this->validateEMailHTTPInput( $trimmedEmail, $contentObjectAttribute );
        }
    }

    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) )
            )
        {
            $email = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $email2 = $http->postVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) );
            $email_text = $email . "::" . $email2;
            $email_text = $email_text == '::' ? '' : $email_text;
            $contentObjectAttribute->setAttribute( 'data_text', $email_text );
            return true;
        }
        return false;
    }

    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) )
            )
        {
            $email = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) );
            $email2 = $http->postVariable( $base . '_data_text2_' . $contentObjectAttribute->attribute( 'id' ) );
            $email_text = $email . "::" . $email2;
            $email_text = $email_text == '::' ? '' : $email_text;
            $collectionAttribute->setAttribute( 'data_text', $email_text );
            return true;
        }
        return false;
    }

    public function objectAttributeContent( $contentObjectAttribute )
    {
        $data = $contentObjectAttribute->attribute( 'data_text' );
        list ( $mail1, $mail2 ) = array_merge( preg_split( '/::/', $data ), array( "mail1" => '', "mail2" => '' ) );
        $mail = array( "mail1" => $mail1, "mail2" => $mail2 );
        return $mail;
    }

}
eZDataType::register( jpMail::DATATYPE_STRING, "jpMail" );
?>
