<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpGender
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpGender extends eZDataType
{
    const DATATYPE_STRING          = "jpgender";

    /**
     * Ctor.
     * 
     */
    public function __construct()
    {
        parent::__construct( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "Gender",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'value' )) );
    }

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
    }

    /**
     * Validates the input from the object edit form concerning this attribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return int eZInputValidator::STATE_INVALID/STATE_ACCEPTED
     */
    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $text = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) );

            if ( $text == "" )
            {
                // we require user to enter an address only if the attribute is not an informationcollector
                if ( !$classAttribute->attribute( 'is_information_collector' ) and
                     $contentObjectAttribute->validateIsRequired() )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'The field is empty.' ) );
                    return eZInputValidator::STATE_INVALID;
                }
            }
            else
            {
                return $this->validateProvinceHTTPInput( $data_text, $contentObjectAttribute );
            }
        }
        else if ( !$classAttribute->attribute( 'is_information_collector' ) 
               and $contentObjectAttribute->validateIsRequired() )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing text input.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        return eZInputValidator::STATE_ACCEPTED;
    }

    static function genders( ){
        return array( "male", "female" );
    }

    /**
     * Stores the object attribute input in the $contentObjectAttribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean Whether to save the changes to the db or not.
     */
    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $gender_id = $http->postVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) );
            $genders = jpGender::genders();
            $contentObjectAttribute->setAttribute( 'data_text', $genders[$gender_id] );
            $contentObjectAttribute->setAttribute( 'data_int', $gender_id );
            return true;
        }
        return false;
    }

    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $gender_id = $http->postVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) );
            $genders = jpGender::genders();
            $collectionAttribute->setAttribute( 'data_text', $genders[$gender_id] );
            $collectionAttribute->setAttribute( 'data_int', $gender_id );
            return true;
        }
        return false;
    }


    function validateJapaneseSexHTTPInput( $value, $contentObjectAttribute )
    {
        if( ! $contentObjectAttribute->validateIsRequired() && $value=="" )
        {
            return eZInputValidator::STATE_ACCEPTED;
        }
        if( ($value == 0) || ($value == 1) ){
            return eZInputValidator::STATE_ACCEPTED;
        }
        else
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'Select a gender.' ) );
        }
        return eZInputValidator::STATE_INVALID;
    }

    public function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) ) ){
            $jpgender = $http->postVariable( $base . "_jpgender_" . $contentObjectAttribute->attribute( "id" ) );
            return $this->validateJapaneseSexHTTPInput( $jpgender, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function initializeClassAttribute( $classAttribute )
    {
        return false;
    }


    /**
     * Handles the input specific for one attribute from the class edit interface.
     *
     * @param mixed  $http           Class eZHTTPTool.
     * @param string $base           Seems to be always 'ContentClassAttribute'.
     * @param mixed  $classAttribute Class eZContentClassAttribute.
     *
     * @return boolean
     */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        return true;
    }

    /**
     * Returns the content object of the attribute.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function objectAttributeContent( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );;
    }

    /**
     * Returns the meta data used for storing search indeces.
     * 
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns a string that could be used for the object title.
     *
     * @param mixed $contentObjectAttribute ContentObjectAttribute.
     * @param mixed $name                   No idea...
     *
     * @return string
     */
    public function title( $contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns whether the attribute contains data.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean
     */
    public function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
    }

    /**
     * IsIndexable.
     *
     * @return boolean
     */
    public function isIndexable()
    {
        return true;
    }

    /**
     * IsInformationCollector.
     *
     * @return boolean
     */
    function isInformationCollector()
    {
        return true;
    }

    /**
     * Returns a key to sort attributes.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function sortKey( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }

    /**
     * Returns the type of the sortKey.
     *
     * @return string
     */
    public function sortKeyType()
    {
        return 'string';
    }

}
eZDataType::register( jpGender::DATATYPE_STRING, "jpGender" );
?>
