<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpTexlibe
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpTextline extends eZDataType
{
    const DATATYPE_STRING          = "jptextline";
    const VALIDATION_TYPE_FIELD    = "data_int1";
    const VALIDATION_TYPE_VARIABLE = "_jptextline_validation_type_";
    const VALIDATION_TYPE_HIRAGANA = 0;
    const VALIDATION_TYPE_KATAKANA = 1;

    /**
     * Ctor.
     * 
     */
    public function __construct()
    {
        parent::__construct( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "Japanese Textline",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'value' )) );
    }

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
    }


    /**
     * Validates the input from the object edit form concerning this attribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return int eZInputValidator::STATE_INVALID/STATE_ACCEPTED
     */
    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) ) ){
            $data_text = $http->postVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) );
            if($contentObjectAttribute->attribute("is_required") && $data_text=="")
            {
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                     'Input required.' ) );
                return eZInputValidator::STATE_INVALID;
            }
            $validationType = $contentObjectAttribute->contentClassAttribute()->attribute( self::VALIDATION_TYPE_FIELD );
            return $this->validateJapaneseTextHTTPInput( $data_text, $validationType, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    /**
     * Stores the object attribute input in the $contentObjectAttribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean Whether to save the changes to the db or not.
     */
    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $data = $http->postVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) );
            $contentObjectAttribute->setAttribute( "data_text", $data );
            return true;
        }
        return false;
    }


    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $dataText = $http->postVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) );
            $collectionAttribute->setAttribute( 'data_text', $dataText );
            return true;
        }
        return false;
    }


    function validateJapaneseTextHTTPInput( $text, $validationType, $contentObjectAttribute )
    {
        mb_internal_encoding("UTF-8");
        mb_regex_encoding("UTF-8"); 
        switch($validationType) 
        {
            case jpTextline::VALIDATION_TYPE_HIRAGANA:
                if( mb_ereg("^[ぁ-んー　]*$", $text) )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
                else
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'The text is not fullwidth hiragana.' ) );
                }
                break;
            case jpTextline::VALIDATION_TYPE_KATAKANA:
                if( mb_ereg("^[ァ-ヶー 　]*$", $text) )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
                else
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'The text is not fullwidth katakana.' ) );
                }
                break;
        }
        return eZInputValidator::STATE_INVALID;
    }

    public function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) ) ){
            $data_text = $http->postVariable( $base . "_jptextline_" . $contentObjectAttribute->attribute( "id" ) );
            if($contentObjectAttribute->attribute("is_required") && $data_text=="")
            {
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                     'Input required.' ) );
                return eZInputValidator::STATE_INVALID;
            }
            $validationType = $contentObjectAttribute->contentClassAttribute()->attribute( self::VALIDATION_TYPE_FIELD );
            return $this->validateJapaneseTextHTTPInput( $data_text, $validationType, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function initializeClassAttribute( $classAttribute )
    {
        if ( $classAttribute->attribute( self::VALIDATION_TYPE_FIELD ) == null )
            $classAttribute->setAttribute( self::VALIDATION_TYPE_FIELD, 0 );
        $classAttribute->store();
    }


    /**
     * Handles the input specific for one attribute from the class edit interface.
     *
     * @param mixed  $http           Class eZHTTPTool.
     * @param string $base           Seems to be always 'ContentClassAttribute'.
     * @param mixed  $classAttribute Class eZContentClassAttribute.
     *
     * @return boolean
     */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $validationType = $base . self::VALIDATION_TYPE_VARIABLE . $classAttribute->attribute( "id" );
        if ($http->hasPostVariable( $validationType ) )
        {
            $validationTypeValue = $http->postVariable( $validationType );
            $classAttribute->setAttribute( self::VALIDATION_TYPE_FIELD, $validationTypeValue );
        }
        return true;
    }

    /**
     * Returns the content object of the attribute.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function objectAttributeContent( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns the meta data used for storing search indeces.
     * 
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns a string that could be used for the object title.
     *
     * @param mixed $contentObjectAttribute ContentObjectAttribute.
     * @param mixed $name                   No idea...
     *
     * @return string
     */
    public function title( $contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns whether the attribute contains data.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean
     */
    public function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
    }

    /**
     * IsIndexable.
     *
     * @return boolean
     */
    public function isIndexable()
    {
        return true;
    }

    /**
     * IsInformationCollector.
     *
     * @return boolean
     */
    function isInformationCollector()
    {
        return true;
    }

    /**
     * Returns a key to sort attributes.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function sortKey( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }

    /**
     * Returns the type of the sortKey.
     *
     * @return string
     */
    public function sortKeyType()
    {
        return 'string';
    }

}
eZDataType::register( jpTextline::DATATYPE_STRING, "jpTextline" );
?>
