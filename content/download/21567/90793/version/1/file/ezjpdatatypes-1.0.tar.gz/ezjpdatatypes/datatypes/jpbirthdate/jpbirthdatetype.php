<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpBirthdate
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpBirthdate extends eZDataType
{
    const DATATYPE_STRING = "jpbirthdate";
    private $eras_list;
    private $months_list;

    /**
     * Ctor.
     * 
     */
    public function __construct()
    {
        parent::__construct( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "Japanese birthdate",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'birthdate' )) );
    }

    static function convertYearToGregorian( $date )
    {
        if( $date["era"] == 0 )
        {
            return $date;
        }
        $eras_list = self::get_eras_list();
        $count = 0;
        foreach( $eras_list as $name=>$era){
            if( $count == $date["era"] ){
                $era_data = $era;
            }
            $count++;
        }
        if( $date["year"] > $era_data["years"] )
        {
            return false;
        }
        else
        {
            $date["year"] += $era_data["start_at"] - 1;
            $date["era"] = 1;
        }
        return $date;
    } 

    static function get_eras_list()
    {
        return array(
            "Gregorian" => array(
                    "years" => "present",
                    "start_at" => 0
                ),
            "Meiji" => array(
                    "years" => 45,
                    "start_at" => 1868
                ),
            "Taisho" => array(
                    "years" => 15,
                    "start_at" => 1912
                ),
            "Showa" => array(
                    "years" => 64,
                    "start_at" => 1926
                ),
            "Heisei" => array(
                    "years" => "present",
                    "start_at" => 1989
                )
            );
    } 

    static function get_months_list()
    {
        return array( "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" );
    } 

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
    }


    /**
     * Validates the input from the object edit form concerning this attribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return int eZInputValidator::STATE_INVALID/STATE_ACCEPTED
     */
    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
        
        if ( $http->hasPostVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $birthdate = array();
            $birthdate["era"] = $http->postVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["year"] = $http->postVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["month"] = $http->postVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["day"] = $http->postVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate_text = $birthdate["era"] ."-". $birthdate["year"] ."-". $birthdate["month"] ."-". $birthdate["day"];
            if ( true )
            {
                if ( !$contentObjectAttribute->validateIsRequired() )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
                if ( !$classAttribute->attribute( 'is_information_collector' ) and
                    $contentObjectAttribute->validateIsRequired() )
                {   
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'The field is empty.' ) );
                    return eZInputValidator::STATE_INVALID;
                }
            }
            else
            {
                return $this->validateJapaneseBirthdateHTTPInput( $birthdate, $contentObjectAttribute );
            }
        }
        else if ( !$classAttribute->attribute( 'is_information_collector' ) and
                   $contentObjectAttribute->validateIsRequired() )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing text input.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        return eZInputValidator::STATE_ACCEPTED;
    }

    /**
     * Stores the object attribute input in the $contentObjectAttribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean Whether to save the changes to the db or not.
     */
    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $birthdate = array();
            $birthdate["era"] = $http->postVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["year"] = $http->postVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["month"] = $http->postVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["day"] = $http->postVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate_text = $birthdate["era"] ."-". $birthdate["year"] ."-". $birthdate["month"] ."-". $birthdate["day"];
            $contentObjectAttribute->setAttribute( "data_text", $birthdate_text );
            return true;
        }
        return false;
    }

    function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $birthdate = array();
            $birthdate["era"] = $http->postVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["year"] = $http->postVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["month"] = $http->postVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["day"] = $http->postVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( "id" ) );
            if($contentObjectAttribute->attribute("is_required") && ($birthdate["year"]=="" || $birthdate["month"]=="") )
            {
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                     'Input required.' ) );
                return eZInputValidator::STATE_INVALID;
            }
            $birthdate_text = $birthdate["era"] ."-". $birthdate["year"] ."-". $birthdate["month"] ."-". $birthdate["day"];
            return $this->validateJapaneseBirthdateHTTPInput( $birthdate, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $birthdate = array();
            $birthdate["era"] = $http->postVariable( $base . '_jpbirthdate_era_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["year"] = $http->postVariable( $base . '_jpbirthdate_year_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["month"] = $http->postVariable( $base . '_jpbirthdate_month_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate["day"] = $http->postVariable( $base . '_jpbirthdate_day_' . $contentObjectAttribute->attribute( "id" ) );
            $birthdate_text = $birthdate["era"] ."-". $birthdate["year"] ."-". $birthdate["month"] ."-". $birthdate["day"];
            $birthdate_text = $birthdate_text == '0--0-' ? '' : $birthdate_text;
            $collectionAttribute->setAttribute( "data_text", $birthdate_text );
            $collectionAttribute->setAttribute( "data_int", $birthdate );
            return true;
        }
        return false;
    }

    function validateJapaneseBirthdateHTTPInput( $birthdate, $contentObjectAttribute )
    {
        $gregorian_date = self::convertYearToGregorian( $birthdate );
        if( ! $gregorian_date )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'The year is not valid.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        $last_month_day = date('d', mktime(0, 0, 0, $gregorian_date["month"] + 1, 0, $gregorian_date["year"]));
        if( $gregorian_date["day"] > $last_month_day )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'The day is not valid.' ) );
            return eZInputValidator::STATE_INVALID;
        }

        return eZInputValidator::STATE_ACCEPTED;
    }

    public function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        return false;
    }

    /**
     * Returns the content object of the attribute.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function objectAttributeContent( $contentObjectAttribute )
    {
        $data = $contentObjectAttribute->attribute( 'data_text' );
        list ( $era, $year, $month, $day ) = array_merge( preg_split( '/-/', $data ), array( "era" => '', "year" => '', "month" => '', "day" => '' ) );
        $birthdate = array( "era" => $era, "year" => $year, "month" => $month, "day" => $day );
        return $birthdate;
    }

    /**
     * Returns the meta data used for storing search indeces.
     * 
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns a string that could be used for the object title.
     *
     * @param mixed $contentObjectAttribute ContentObjectAttribute.
     * @param mixed $name                   No idea...
     *
     * @return string
     */
    public function title( $contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns whether the attribute contains data.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean
     */
    public function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
    }

    /**
     * IsIndexable.
     *
     * @return boolean
     */
    public function isIndexable()
    {
        return true;
    }

    /**
     * IsInformationCollector.
     *
     * @return boolean
     */
    function isInformationCollector()
    {
        return true;
    }

    /**
     * Returns a key to sort attributes.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function sortKey( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }

    /**
     * Returns the type of the sortKey.
     *
     * @return string
     */
    public function sortKeyType()
    {
        return 'string';
    }

}
eZDataType::register( jpBirthdate::DATATYPE_STRING, "jpBirthdate" );
?>
