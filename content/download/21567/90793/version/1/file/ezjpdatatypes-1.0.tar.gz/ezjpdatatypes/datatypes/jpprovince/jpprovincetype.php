<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpProvince
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpProvince extends eZDataType
{
    const DATATYPE_STRING          = "jpprovince";

    /**
     * Ctor.
     * 
     */
    public function __construct()
    {
        parent::__construct( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "Japanese Province",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'value' )) );
    }

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
    }


    static function get_provinces_list()
    {
        return array(
            "Select a province",
            "Hokkaido",
            "Aomori",
            "Iwate",
            "Miyagi",
            "Akita",
            "Yamagata",
            "Fukushima",
            "Ibaraki",
            "Tochigi",
            "Gunma",
            "Saitama",
            "Chiba",
            "Tokyo",
            "Kanagawa",
            "Niigata",
            "Toyama",
            "Ishikawa",
            "Fukui",
            "Yamanashi",
            "Nagano",
            "Gifu",
            "Shizuoka",
            "Aichi",
            "Mie",
            "Shiga",
            "Kyoto",
            "Osaka",
            "Hyogo",
            "Nara",
            "Wakayama",
            "Tottori",
            "Shimane",
            "Okayama",
            "Hiroshima",
            "Yamaguchi",
            "Tokushima",
            "Kagawa",
            "Ehime",
            "Kochi",
            "Fukuoka",
            "Saga",
            "Nagasaki",
            "Kumamoto",
            "Oita",
            "Miyazaki",
            "Kagoshima",
            "Okinawa" 
            );
    }

    /**
     * Validates the input from the object edit form concerning this attribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return int eZInputValidator::STATE_INVALID/STATE_ACCEPTED
     */
    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        $classAttribute = $contentObjectAttribute->contentClassAttribute();
        if ( $http->hasPostVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $text = $http->postVariable( $base . '_data_text_' . $contentObjectAttribute->attribute( 'id' ) );

            if ( $text == "" )
            {
                // we require user to enter an address only if the attribute is not an informationcollector
                if ( !$classAttribute->attribute( 'is_information_collector' ) and
                     $contentObjectAttribute->validateIsRequired() )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'The field is empty.' ) );
                    return eZInputValidator::STATE_INVALID;
                }
            }
            else
            {
                return $this->validateProvinceHTTPInput( $data_text, $contentObjectAttribute );
            }
        }
        else if ( !$classAttribute->attribute( 'is_information_collector' ) 
               and $contentObjectAttribute->validateIsRequired() )
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes', 'Missing text input.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        return eZInputValidator::STATE_ACCEPTED;
    }

    /**
     * Stores the object attribute input in the $contentObjectAttribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean Whether to save the changes to the db or not.
     */
    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $province_id = $http->postVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) );
            $provinces = self::get_provinces_list();
            $contentObjectAttribute->setAttribute( 'data_text', $provinces[$province_id] );
            $contentObjectAttribute->setAttribute( "data_int", $province_id );
            return true;
        }
        return false;
    }

    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) ) )
        {
            $province_id = $http->postVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) );
            $provinces = self::get_provinces_list();
            $collectionAttribute->setAttribute( 'data_text', $provinces[$province_id] );
            $collectionAttribute->setAttribute( 'data_int', $province_id );
            return true;
        }
        return false;
    }


    function validateJapaneseProvinceHTTPInput( $value, $contentObjectAttribute )
    {
        if( ! $contentObjectAttribute->validateIsRequired() && $value==0 )
        {
            return eZInputValidator::STATE_ACCEPTED;
        }
        if( $value != 0 ){
            return eZInputValidator::STATE_ACCEPTED;
        }
        else
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'Input required.' ) );
        }
        return eZInputValidator::STATE_INVALID;
    }

    public function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) ) ){
            $jpprovince = $http->postVariable( $base . "_jpprovince_" . $contentObjectAttribute->attribute( "id" ) );
            return $this->validateJapaneseProvinceHTTPInput( $jpprovince, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function initializeClassAttribute( $classAttribute )
    {
        return false;
    }


    /**
     * Returns the content object of the attribute.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function objectAttributeContent( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns the meta data used for storing search indeces.
     * 
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns a string that could be used for the object title.
     *
     * @param mixed $contentObjectAttribute ContentObjectAttribute.
     * @param mixed $name                   No idea...
     *
     * @return string
     */
    public function title( $contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns whether the attribute contains data.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean
     */
    public function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
    }

    /**
     * IsIndexable.
     *
     * @return boolean
     */
    public function isIndexable()
    {
        return true;
    }

    /**
     * IsInformationCollector.
     *
     * @return boolean
     */
    function isInformationCollector()
    {
        return true;
    }

    /**
     * Returns a key to sort attributes.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function sortKey( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }

    /**
     * Returns the type of the sortKey.
     *
     * @return string
     */
    public function sortKeyType()
    {
        return 'string';
    }

}
eZDataType::register( jpProvince::DATATYPE_STRING, "jpProvince" );
?>
