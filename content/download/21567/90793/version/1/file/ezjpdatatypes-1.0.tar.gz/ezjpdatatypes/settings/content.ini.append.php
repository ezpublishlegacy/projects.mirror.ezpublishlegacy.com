<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezjpdatatypes
AvailableDataTypes[]=jptextline
AvailableDataTypes[]=jppostalcode
AvailableDataTypes[]=jpphonenumber
AvailableDataTypes[]=jpprovince
AvailableDataTypes[]=jpbirthdate
AvailableDataTypes[]=jpmail
AvailableDataTypes[]=jpgender

 */?>
