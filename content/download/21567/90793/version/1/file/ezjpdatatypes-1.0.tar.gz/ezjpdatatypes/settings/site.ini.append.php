<?php /*

[RegionalSettings]
TranslationExtensions[]=ezjpdatatypes

[TemplateSettings]
ExtensionAutoloadPath[]=ezjpdatatypes

 */?>
