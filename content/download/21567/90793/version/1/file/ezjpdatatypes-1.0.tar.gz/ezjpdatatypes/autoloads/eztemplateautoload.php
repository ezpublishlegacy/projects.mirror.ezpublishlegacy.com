<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezjpdatatypes/autoloads/jpdatatypes_utils.php',
                                    'class' => 'JpDatatypesUtils',
                                    'operator_names' => array( 'jp_eras_list', 'jp_months_list', 'jp_genders_list', 'jp_provinces_list' ) );

?>
