<?php

class JpDatatypesUtils
{
    var $operators;
    /*!
      Constructor, does nothing by default.
    */
    function __construct()
    {
        $this->operators = array( 'jp_eras_list', 'jp_months_list', 'jp_genders_list', 'jp_provinces_list' );
    }

    /*!
     \return an array with the template operator name.
    */
    function &operatorList()
    {
        return $this->operators;
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return false;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return false;
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {
        switch ( $operatorName )
        {
            case 'jp_eras_list':
            {
                $eras_list = jpBirthdate::get_eras_list();
                $operatorValue = $eras_list;
            } break;
            case 'jp_months_list':
            {
                $months_list = jpBirthdate::get_months_list();
                $operatorValue = $months_list;
            } break;
            case 'jp_genders_list':
            {
                $sex_list = jpGender::genders(); 
                $operatorValue = $sex_list;
            } break;
            case 'jp_provinces_list':
            {
                $sex_list = jpProvince::get_provinces_list(); 
                $operatorValue = $sex_list;
            } break;

        }
    }
}

?>
