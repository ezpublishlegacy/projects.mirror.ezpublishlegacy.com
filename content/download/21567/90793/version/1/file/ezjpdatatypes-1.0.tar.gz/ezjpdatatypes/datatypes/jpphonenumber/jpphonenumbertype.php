<?php
/**
 * A content datatype which which validate hiragana and katakana 
 * 
 * @uses       eZDataType
 * @package    jpDatatype
 * @subpackage jpPhonenumber
 * @version    //autogen//
 * @author     Eric Sagnes
 * @license    
 */

class jpPhonenumber extends eZDataType
{
    const DATATYPE_STRING = "jpphonenumber";
    const PHONE_TYPE_FIELD    = "data_int4";
    const PHONE_TYPE_VARIABLE = "_jpphonenumber_phone_type_";
    const PHONE_TYPE_ALL = 0;
    const PHONE_TYPE_HOME = 1;
    const PHONE_TYPE_MOBILE = 2;

    /**
     * Ctor.
     * 
     */
    public function __construct()
    {
        parent::__construct( self::DATATYPE_STRING,
                              ezi18n( 'kernel/classes/datatypes',
                                      "Japanese phone number",
                                      'Datatype name' ),
                              array( 'serialize_supported'  => true,
                                     'object_serialize_map' => array( 'data_text' => 'phone_number' )) );
    }

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
    }

    /**
     * Stores the object attribute input in the $contentObjectAttribute.
     *
     * @param mixed  $http                   Class eZHTTPTool.
     * @param string $base                   Seems to be always 'ContentObjectAttribute'.
     * @param mixed  $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean Whether to save the changes to the db or not.
     */
    public function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $field1 = $http->postVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( "id" ) );
            $field2 = $http->postVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( "id" ) );
            $field3 = $http->postVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( "id" ) );
            $phone_number = $field1 .'-'. $field2 .'-'. $field3;
            $contentObjectAttribute->setAttribute( "data_text", $phone_number );
            return true;
        }
        return false;
    }

    public function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $field1 = $http->postVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( "id" ) );
            $field2 = $http->postVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( "id" ) );
            $field3 = $http->postVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( "id" ) );
            $phone_number = $field1 .'-'. $field2 .'-'. $field3;
            echo("sasdsdasdasdsadasd");
            return $this->validateJapanesePhonenumberHTTPInput( $phone_number, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function validateCollectionAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $field1 = $http->postVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( "id" ) );
            $field2 = $http->postVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( "id" ) );
            $field3 = $http->postVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( "id" ) );
            $phone_number = $field1 .'-'. $field2 .'-'. $field3;
            return $this->validateJapanesePhonenumberHTTPInput( $phone_number, $contentObjectAttribute );
        }
        return eZInputValidator::STATE_INVALID;
    }

    function fetchCollectionAttributeHTTPInput( $collection, $collectionAttribute, $http, $base, $contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( 'id' ) ) and
             $http->hasPostVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $field1 = $http->postVariable( $base . '_jpphonenumber1_' . $contentObjectAttribute->attribute( "id" ) );
            $field2 = $http->postVariable( $base . '_jpphonenumber2_' . $contentObjectAttribute->attribute( "id" ) );
            $field3 = $http->postVariable( $base . '_jpphonenumber3_' . $contentObjectAttribute->attribute( "id" ) );
            $phone_number = $field1 .'-'. $field2 .'-'. $field3;
            $phone_number = $phone_number == '--' ? '' : $phone_number;
            $collectionAttribute->setAttribute( "data_text", $phone_number );
            return true;
        }
        return false;
    }

    function validateJapanesePhonenumberHTTPInput( $phonenumber, $contentObjectAttribute )
    {
        if( ! $contentObjectAttribute->validateIsRequired() && $phonenumber==="--" )
        {
            return eZInputValidator::STATE_ACCEPTED;
        }
        elseif($contentObjectAttribute->validateIsRequired() && $phonenumber==="--")
        {
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'Input required.' ) );
            return eZInputValidator::STATE_INVALID;
        }
        $phone_type = $contentObjectAttribute->contentClassAttribute()->attribute( self::PHONE_TYPE_FIELD );
        switch ( $phone_type)
        {
            case jpPhonenumber::PHONE_TYPE_ALL:
                if ( preg_match( '/^\d{2,4}-\d{2,4}-\d{4}$/', $phonenumber ) )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
            break;
            case jpPhonenumber::PHONE_TYPE_HOME:
                if ( preg_match( '/^\d{2,4}-\d{2,4}-\d{4}$/', $phonenumber ) )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
            break;
            case jpPhonenumber::PHONE_TYPE_MOBILE:
                if ( preg_match( '/^0\d0\-\d{4}\-\d{4}$/', $phonenumber ) )
                {
                    return eZInputValidator::STATE_ACCEPTED;
                }
            break;
        }
        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                             'The phone number is not valid.' ) );
        return eZInputValidator::STATE_INVALID;
    }

    public function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $phone_type = $base . self::PHONE_TYPE_VARIABLE . $classAttribute->attribute( "id" );
        if ($http->hasPostVariable( $phone_type ) )
        {
            $phone_type_value = $http->postVariable( $phone_type );
            $classAttribute->setAttribute( self::PHONE_TYPE_FIELD, $phone_type_value );
        }
        return true;
    }

    /**
     * Returns the content object of the attribute.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function objectAttributeContent( $contentObjectAttribute )
    {
        $data = $contentObjectAttribute->attribute( 'data_text' );
        list ( $field1, $field2, $field3 ) = array_merge( preg_split( '/-/', $data ), array( "field1" => '', "field2" => '', "field3" => '' ) );
        $phone = array( "field1" => $field1, "field2" => $field2, "field3" => $field3 );
        return $phone;
    }

    /**
     * Returns the meta data used for storing search indeces.
     * 
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function metaData( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns a string that could be used for the object title.
     *
     * @param mixed $contentObjectAttribute ContentObjectAttribute.
     * @param mixed $name                   No idea...
     *
     * @return string
     */
    public function title( $contentObjectAttribute, $name = null )
    {
        return $contentObjectAttribute->attribute( "data_text" );
    }

    /**
     * Returns whether the attribute contains data.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return boolean
     */
    public function hasObjectAttributeContent( $contentObjectAttribute )
    {
        return trim( $contentObjectAttribute->attribute( "data_text" ) ) != '';
    }

    /**
     * IsIndexable.
     *
     * @return boolean
     */
    public function isIndexable()
    {
        return true;
    }

    /**
     * IsInformationCollector.
     *
     * @return boolean
     */
    function isInformationCollector()
    {
        return true;
    }

    /**
     * Returns a key to sort attributes.
     *
     * @param mixed $contentObjectAttribute Class eZContentObjectAttribute.
     *
     * @return string
     */
    public function sortKey( $contentObjectAttribute )
    {
        return $contentObjectAttribute->attribute( 'data_text' );
    }

    /**
     * Returns the type of the sortKey.
     *
     * @return string
     */
    public function sortKeyType()
    {
        return 'string';
    }

}
eZDataType::register( jpPhonenumber::DATATYPE_STRING, "jpPhonenumber" );
?>
