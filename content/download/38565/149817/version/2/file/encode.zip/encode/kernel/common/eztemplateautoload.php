<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/encode/kernel/common/ezencodeoperator.php',
                                    'class' => 'eZEncodeOperator',
                                    'operator_names' => array( 'encode' ) );
?>