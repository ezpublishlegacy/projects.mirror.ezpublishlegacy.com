<?php
//
// Created on: <21-Apr-2004 09:18:06 bf>
//
// Copyright (C) 1999-2004 Musikverlage Hans Gerig. All rights reserved.
//

/*! \file ezenccodeoperator.php
*/

/*!
  \class eZEncodeOperator ezenccodeoperator.php
  \brief The class v does

*/

include_once( "lib/ezutils/classes/ezdebug.php" );

class eZEncodeOperator
{
    /*!
     Initializes the object with the name $name, default is "encode".
    */
    function eZEncodeOperator( $name = "encode" )
    {
		$this->Operators = array( $name );
    }

    /*!
	 Returns the template operators.
    */
    function &operatorList()
    {
		return $this->Operators;
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
    	eZDebug::writeDebug( $operatorParameters );
    	$type = $operatorParameters[0][0][1];
    	eZDebug::writeNotice( $type );
    	//array of params in which each param is an array of length 3
    	switch( $type )
	   	{
	   	case "html":
	   		$encoded = htmlentities( $operatorValue );
	   	case "url":
	   		$encoded = urlencode( $operatorValue );
	   		break;
	   		
	   	case "md5":	
    		$encoded = md5( $operatorValue );
    		break;
    		
		default:
			$encoded = $operatorValue;
        }

       	$operatorValue = $encoded;
    }
    
    var $Operators;
}
?>
