<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=ezcategoryselection

*/
?>
