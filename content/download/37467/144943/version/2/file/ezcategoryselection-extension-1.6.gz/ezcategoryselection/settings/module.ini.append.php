<?php
/*

[ModuleSettings]
ExtensionRepositories[]=ezcategoryselection

*/
?>
