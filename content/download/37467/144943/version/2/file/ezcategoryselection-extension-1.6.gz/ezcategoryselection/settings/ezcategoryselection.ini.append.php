<?php
/*

[CategoryClassFilterSettings]
#default[]
#default[]=decision_table
#food[]
#food[]=decision_table

*/
?>
