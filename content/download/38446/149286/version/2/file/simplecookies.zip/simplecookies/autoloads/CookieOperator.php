<?php
/*!
  \class   CookieOperator CookieOperator.php
  \ingroup eZTemplateOperators
  \brief   Wrapper to handle setting and getting cookies from a template
  \version 2007.08.30
  \date    2007.08.30
  \author  syorex (alex@soyrex.comrerer4)
  \licence GPL version 2.

*/

include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezdebug.php" );

class CookieOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function CookieOperator()
    {
	

        $this->Operators= array( 'cookieset', 'cookieget' );
    }

    /*!
    Return an array with the template operator name.
    */
    function operatorList()
    {
        return $this->Operators;
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }
    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'cookieset' => array( 
				'cookie_name' 	=> array( 'type' 	=> 'string',	'required' => true ),
                'cookie_val' 	=> array( 'type'	=> 'string', 	'required' => true ),
                'expiry_time' 	=> array( 'type'	=> 'string', 'default'=>'0', 	'required' => false )
				),
				 
                 'cookieget' => array(
				'cookie_name' 	=> array( 'type' 	=> 'string',	'required' => true )
				 )
            );
    }
    
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $key = $namedParameters['cookie_name'];
				
		// Check from ini for defaults:
		$ini =& eZINI::instance('simplecookies.ini');
		$prefix = $ini->variable( 'SimpleCookies', 'CookieKeyPrefix' );

		$key = "{$prefix}{$key}";
		
        switch ( $operatorName )
        {
			// Set a cookie value:
            case 'cookieset':
            {
				// Get our parameters:
				$value = $namedParameters['cookie_val'];
				$expire = $namedParameters['expiry_time'];
				
				// Check and calculate the expiry time:
				if($expire > 0)
				{
					// It is a number of days:
					$expire = time()+60*60*24*$expire; 
				}
				
				// Return the result of our set function, so we
				// can test against it in the template:
				$operatorValue = setcookie($key,$value,$expire);
                return;
                
            } break;
			
            // get a cookie value:
            case 'cookieget':
            {
				$operatorValue = false;

				// if it's set then return it:
				// else return false:
				if(isset($_COOKIE[$key]))	
					$operatorValue = $_COOKIE[$key];
				
                return;
                
            } break;
        }
    }
}

?>
