<?php

// Operator autoloading
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/simplecookies/autoloads/CookieOperator.php',
                                    'class' => 'CookieOperator',
                                    'operator_names' => array( 'cookieset', 'cookieget' ) );

?>