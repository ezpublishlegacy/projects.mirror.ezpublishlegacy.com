<?php
//
// Definition of eZWordtoimageoperator class
//
// Created on: <27-Mar-2003 13:43:10 oh>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezwordtoimageoperator.php
*/

/*!
  \class eZWordtoimageoperator ezwordtoimageoperator.php
  \brief The class eZWordtoimageoperator does

*/
include_once( "lib/ezutils/classes/ezini.php" );

class eZWordToImageOperator
{
    /*!
     Initializes the object with the name $name, default is "wash".
    */
    function eZWordToImageOperator( $name = "wordtoimage" )
    {
	$this->Operators = array( $name );
    }

    /*!
Returns the template operators.
    */
    function &operatorList()
    {
		return $this->Operators;
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        
        $ini =& eZINI::instance("wordtoimage.ini");
        $iconRoot = $ini->variable( 'WordToImageSettings', 'IconRoot' ) . "/";

		$installedIcons = $ini->variable( 'WordToImageSettings', 'InstalledIcons' );
		
		$search = array();
    	$replace = array();
    	
    	if ($installedIcons !== false)
    	{
    		foreach ( $installedIcons as $item)
			{
				$search_temp = $ini->variable( $item, 'ReplaceText' );
				$replace_temp = $ini->variable( $item, 'ReplaceIcon' );
				
				if ($search_temp !== false  and 
				    $replace_temp !== false and trim ($replace_temp) != "")
				{
					if (is_array($search_temp))
					{
						$add = true;
						foreach ($search_temp as $search_item)
						{
							if ($search_item === false or trim ($search_item) == "")
								$add = false;
						}	
						if ($add === true)
						{
							$search[] = $search_temp;
							$replace[] = $replace_temp;			
						}
					}
				}
			}	
    	}
    	
    	$operatorValue = str_replace ("\r", "", $operatorValue);
		$operatorValue = trim ($operatorValue);
		
    	for ($i = 0; $i < count($search); $i++)
    	{
    		for ($j = 0; $j < count($search[$i]); $j++)
    		{
    			$operatorValue = preg_replace ("#([\s|\n]+)".$search[$i][$j]."#i", 
    						"\\1<img src='$iconRoot".$replace[$i]."' />\\2", $operatorValue);		
    			$operatorValue = preg_replace ("#^".$search[$i][$j]."#i", 
    						"\\1<img src='$iconRoot".$replace[$i]."' />", $operatorValue);		
    		}	
    	}

    }
    var $Operators;
}
?>
