<?php /*
#
# $Id: site.ini.append.php 31 2010-02-21 23:29:48Z dpobel $
# $HeadURL: http://svn.projects.ez.no/admin2pp/tags/admin2pp_0.2_ez44/extension/admin2pp/settings/site.ini.append.php $
#

[RegionalSettings]
TranslationExtensions[]=admin2pp


*/ ?>
