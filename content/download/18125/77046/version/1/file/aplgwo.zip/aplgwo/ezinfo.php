<?php

class aplgwo
{
    function info()
    {
        return array( 'Name' => 'aplgwo - Google Website Optimizer extension by Aplyca',
                      'Version' => '1.0.0',
                      'Copyright' => 'Copyright (C) 2009 Aplyca www.aplyca.com',
                      'License' => 'GNU General Public License v2.0'
                    );
    }
}
?>