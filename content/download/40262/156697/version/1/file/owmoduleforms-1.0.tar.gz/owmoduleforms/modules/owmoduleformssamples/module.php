<?php

$Module = array( 'name' => 'owFormTest',
                 'variable_params' => true );

$ViewList = array();

$ViewList['calculator'] = array(
    'script' => 'calculator.php',
    'params' => array(),
);

$ViewList['register'] = array(
    'script' => 'register.php',
    'params' => array(),
);

?>