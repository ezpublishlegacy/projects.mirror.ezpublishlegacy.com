<?php

class owFormMarkup extends owFormElement
{
    var $type='markup';
}

?>