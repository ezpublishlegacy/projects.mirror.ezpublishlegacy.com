<?php
//
// Created on: <12-���-2003 18:48:10 sp>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file importimages.php
*/

$folderName = '/home/sp/images/';
$parentNodeID = 207759;

set_time_limit( 0 );

include_once( "lib/ezutils/classes/ezextension.php" );
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( 'lib/ezutils/classes/ezcli.php' );
include_once( 'kernel/classes/ezscript.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( "lib/ezutils/classes/ezdebug.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );


$cli =& eZCLI::instance();
$script =& eZScript::instance( array( 'debug-message' => '',
                                      'use-session' => true,
                                      'use-modules' => true,
                                      'use-extensions' => true ) );

$script->startup();

$endl = $cli->endlineString();
$webOutput = $cli->isWebOutput();

$siteaccess = false;
$debugOutput = false;
$allowedDebugLevels = false;
$useDebugAccumulators = false;
$useDebugTimingpoints = false;
$useIncludeFiles = false;
$useColors = false;
$isQuiet = false;
$useLogFiles = false;
$showSQL = false;
$cronPart = false;

$script->setUseDebugOutput( $debugOutput );
$script->setAllowedDebugLevels( $allowedDebugLevels );
$script->setUseDebugAccumulators( $useDebugAccumulators );
$script->setUseDebugTimingPoints( $useDebugTimingpoints );
$script->setUseIncludeFiles( $useIncludeFiles );

if ( $webOutput )
    $useColors = true;

$cli->setUseStyles( $useColors );
$script->setDebugMessage( "\n\n" . str_repeat( '#', 36 ) . $cli->style( 'emphasize' ) . " DEBUG " . $cli->style( 'emphasize-end' )  . str_repeat( '#', 36 ) . "\n" );

$script->setUseSiteAccess( $siteaccess );

$script->initialize();

$cli->output( "Running " . $cli->stylize( 'emphasize', 'imortimages.php' ) );



$tab = '';

function importDir( $dirName, $parentNode, $tab )
{
    $cli =& eZCLI::instance();
    if ( $handle = opendir( $dirName ))
    {
        $folder = null;
        echo "folder: $dirName\n";

        $pathParts = explode( '/',$dirName );
        $file = $pathParts[count( $pathParts ) -2 ];
        $folder =& addFolder( $dirName, $file, $parentNode );
        echo "folder: ";
        var_dump( $folder );
        echo "$file\n ";
        /* This is the correct way to loop over the directory. */
        while (false !== ($file = readdir($handle)))
        {
            if ( $file == '.' || $file == '..' )
                continue;
            $cli->output( $tab . "$file\n" );
            if (  filetype( $dirName . '/' . $file ) == 'dir' )
            {
                $cli->output( "$tab Show Dir $dirName$file\n" );
                importDir( $dirName . '/' . $file . '/' , $folder,  $tab . ' ' );
            }
            else
            {
                addImage( $dirName . '/' . $file, $file, $folder );
            }
            flush();

        }
        closedir($handle);
    }
}

$ini =& eZINI::instance();

$server = $ini->variable( 'DatabaseSettings', 'Server' );
$user = $ini->variable( 'DatabaseSettings', 'User' );
$pwd = $ini->variable( 'DatabaseSettings', 'Password' );
$dbb = $ini->variable( 'DatabaseSettings', 'Database' );
$cli->output( "$server $user $pwd $dbb\n" );

$parentNode =& eZContentObjectTreeNode::fetch( $parentNodeID );
importDir( $folderName, $parentNode,'' );

function &addFolder( $folderFile, $folderName, $parent )
{
    $db =& eZDB::instance();
	$db->setIsSQLOutputEnabled( false );
	//fetch folder class
	$class =& eZContentClass::fetch( 1 );

    $folderName = $folderName;
    $folderDescription = $folderName;
    $folderCreatedTime = filemtime( $folderFile );
    $folderFileName = $folderName;
    $folderOriginalFileName = $folderName;
    $folderCaption = $folderName;
    $remoteID = "folder_" . $folderName;
    $userID = 14;

    $contentObject =& $class->instantiate( $userID, 3 );
    $contentObject->setAttribute('remote_id', $remoteID );
    $contentObject->setAttribute( 'name', $folderName );

    $nodeAssignment =& eZNodeAssignment::create( array(
                                                     'contentobject_id' => $contentObject->attribute( 'id' ),
                                                     'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                     'parent_node' => $parent->attribute( 'node_id' ),
                                                     'sort_field' => 2,
                                                     'sort_order' => 0,
                                                     'is_main' => 1
                                                     )
                                                 );
    $nodeAssignment->store();

    $version =& $contentObject->version( 1 );
    $version->setAttribute( 'modified', $folderCreatedTime );
    $version->setAttribute( 'created', $folderCreatedTime );
    $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
    $version->store();

    $contentObjectID = $contentObject->attribute( 'id' );
    $contentObjectAttributes =& $version->contentObjectAttributes();

    $contentObjectAttributes[0]->setAttribute( 'data_text', $folderName );
    $contentObjectAttributes[0]->store();

    $inputData = "<?xml version=\"1.0\"?>";
    $inputData .= "<section>";
    $inputData .= "<paragraph>";
    $inputData .= $folderDescription;
    $inputData .= "</paragraph>";
    $inputData .= "</section>";

    include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php" );
    $dumpdata = "";
    $simplifiedXMLInput = new eZSimplifiedXMLInput( $dumpdata, null, null );
    $inputData = $simplifiedXMLInput->convertInput( $inputData );
    $description = $inputData[0]->toString();
    $contentObjectAttributes[1]->setAttribute( 'data_text', $description );
    $contentObjectAttributes[1]->store();


    include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
    $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                 'version' => 1 ) );
    $contentObject->setAttribute('modified', $folderCreatedTime );
    $contentObject->setAttribute('published', $folderCreatedTime );
    $contentObject->store();
    $contentObject =& eZContentObject::fetch( $contentObject->attribute( 'id' ) );

    echo $contentObject->attribute( 'main_node_id' );
    return eZContentObjectTreeNode::fetch( $contentObject->attribute( 'main_node_id' ) );

}

function addImage( $imageFile, $imagename, $parent )
{
    $mimeObj = new eZMimeType();
    $mime = $mimeObj->mimeTypeFor( false, $imageFile );
    $mimeArray = explode( '/', $mime );
    if ( $mimeArray[0] != 'image' )
        return;
    $db =& eZDB::instance();
	$db->setIsSQLOutputEnabled( false );
	$class =& eZContentClass::fetch( 5 );

    unset( $contentObject );
    $nameArray = explode( '.', $imagename );
    $imageName = $nameArray[0];
    $imageDescription = $imageName;
    $imageCreatedTime = filemtime( $imageFile );
    $imageFileName = $imagename;
    $imageOriginalFileName = $imagename;
    $imageCaption = $imageName;

    // set remoteID
    $remoteID = "image_" . $imageName;

    $userID = 14;

    if ( $userID != null )
    {
        // Create object by user id in section 1
        $contentObject =& $class->instantiate( $userID, 3 );
        $contentObject->setAttribute('remote_id', $remoteID );
        $contentObject->setAttribute( 'name', $imageName );

        $nodeAssignment =& eZNodeAssignment::create( array(
                                                         'contentobject_id' => $contentObject->attribute( 'id' ),
                                                         'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                         'parent_node' => $parent->attribute( 'node_id' ),
                                                         'sort_field' => 2,
                                                         'sort_order' => 0,
                                                         'is_main' => 1
                                                         )
                                                     );
        $nodeAssignment->store();

        $version =& $contentObject->version( 1 );
        $version->setAttribute( 'modified', $imageCreatedTime );
        $version->setAttribute( 'created', $imageCreatedTime );
        $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
        $version->store();

        $contentObjectID = $contentObject->attribute( 'id' );
        $contentObjectAttributes =& $version->contentObjectAttributes();

        $contentObjectAttributes[0]->setAttribute( 'data_text', $imageName );
        $contentObjectAttributes[0]->store();

        $inputData = "<?xml version=\"1.0\"?>";
        $inputData .= "<section>";
        $inputData .= "<paragraph>";
        $inputData .= $imageDescription;
        $inputData .= "</paragraph>";
        $inputData .= "</section>";

        include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php" );
        $dumpdata = "";
        $simplifiedXMLInput = new eZSimplifiedXMLInput( $dumpdata, null, null );
        $inputData = $simplifiedXMLInput->convertInput( $inputData );
        $description = $inputData[0]->toString();
        $contentObjectAttributes[1]->setAttribute( 'data_text', $description );
        $contentObjectAttributes[1]->store();

        $contentObjectAttribute =& $contentObjectAttributes[2];

        saveImage( $imageFile, $imagename, $imageCaption, $contentObjectAttribute );
        $contentObjectAttributes[2]->store();

        include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
        $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                 'version' => 1 ) );
        $contentObject->setAttribute('modified', $imageCreatedTime );
        $contentObject->setAttribute('published', $imageCreatedTime );
        $contentObject->store();
    }
}

function saveImage( $sourceImage, $originalImageFileName, $caption, &$contentObjectAttribute )
{
    include_once( "lib/ezutils/classes/ezdir.php" );
    $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
    $version = $contentObjectAttribute->attribute( "version" );

    include_once( "kernel/common/image.php" );
    $image =& eZImage::create( $contentObjectAttributeID , $version );

    $image->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
    $image->setAttribute( "version", $version );


    $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();
    $nameArray = explode( '.', $originalImageFileName );
    $ext = $nameArray[ count($nameArray ) - 1 ];
    $uniqueName = tempnam( $storage_dir . "/original/image/", "imp") . '.' . $ext;
    $uniqueNameArray = explode( '/', $uniqueName );
    $uniqueNameFile = $uniqueNameArray[ count( $uniqueNameArray ) - 1 ];
    $image->setAttribute( "filename", $uniqueNameFile );
    $image->setAttribute( "original_filename", $originalImageFileName );

    $mimeObj = new eZMimeType();
    $mime = $mimeObj->mimeTypeFor( false, $originalImageFileName );
    $image->setAttribute( "mime_type", $mime );
    $image->setAttribute( "alternative_text", $caption );
    $image->store();

    $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();

    $ori_dir = $storage_dir . '/' . "original/image";
    $ref_dir = $storage_dir . '/' . "reference/image";
    if ( !file_exists( $ori_dir ) )
    {
        eZDir::mkdir( $ori_dir, 0777, true);
    }
    if ( !file_exists( $ref_dir ) )
    {
        eZDir::mkdir( $ref_dir, 0777, true);
    }


    $source_file = $sourceImage;
    $target_file = $storage_dir . "/original/image/" . $uniqueNameFile;
    $reference_file = $storage_dir . "/reference/image/" . $uniqueNameFile;
    copy($source_file, $target_file );
    copy($source_file, $reference_file );
}




?>
