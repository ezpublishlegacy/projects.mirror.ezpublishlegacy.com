<?php
//
// Definition of WorldPayGateway class
//
// Created on: <18-Jul-2004 14:18:58 dl>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezpaypalgateway.php
*/

/*!
  \class WorldPayGateway ezpaypalgateway.php
  \brief The class WorldPayGateway implements
  functions to perform redirection to the PayPal
  payment server.
*/

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezredirectgateway.php' );

//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_WORLDPAY", "worldpay" );

class WorldPayGateway extends eZRedirectGateway
{
    /*!
        Constructor.
    */
    function WorldPayGateway()
    {
        //__DEBUG__
            $this->logger   = eZPaymentLogger::CreateForAdd( "var/log/WorldPayType.log" );
            $this->logger->writeTimedString( 'WorldPayGateway::WorldPayGateway()' );
        //___end____
    }

    /*!
        Creates new WorldPayGateway object.
    */
    function &createPaymentObject( &$processID, &$orderID )
    {
        //__DEBUG__
        $this->logger->writeTimedString("createPaymentObject");
        //___end____
        
        $paymentData = array(
            'session' => eZHTTPTool::getSessionKey());
        return eZPaymentObject::createNew( $processID, $orderID, serialize($paymentData) );
    }

    /*!
        Creates redirectional url to paypal server.
    */
    function &createRedirectionUrl( &$process )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createRedirectionUrl");
        //___end____

        $worldpayINI    =& eZINI::instance( 'worldpay.ini' );

        $worldpayUrl    = $worldpayINI->variable( 'Worldpay', 'WorldpayFormAddress');

        $processParams  =& $process->attribute( 'parameter_list' );
        $orderID        = $processParams['order_id'];

        $indexDir       = eZSys::indexDir();
        $localHost      = eZSys::hostname();
        $localURI       = eZSys::serverVariable( 'REQUEST_URI' );

        $order          =& eZOrder::fetch( $orderID );

        include_once( 'lib/ezlocale/classes/ezlocale.php' );
        $locale         =& eZLocale::instance();
        $accountInfo    = $order->attribute( 'account_information' );

        $addressElems = array();
        foreach (array('organisation', 'address1', 'address2', 'address3', 'town', 'county') as $field) {
            if (trim($accountInfo[$field])) {
                $addressElems[] = $accountInfo[$field];
            }
        }
        $address = implode('&#10;', $addressElems);

        $user =& eZUser::currentUser();	
        $user_id = $user->attribute( "contentobject_id" );

        $http_get_vars = 
            array(
                'instId' => $worldpayINI->variable('Worldpay', 'InstallationID'),
                'cartId' => $orderID,
                'amount' => $order->attribute( 'total_inc_vat' ),
                'currency' => $worldpayINI->variable( "Worldpay", "DefaultCurrency" ),
                'desc' => $this->createShortDescription( $order, $worldpayINI->variable( 'Worldpay', 'MaxDescriptionLength')),
                'testMode' => $worldpayINI->variable('Worldpay', 'TestMode'),
                'name' => $accountInfo['title'] . ' ' . $accountInfo['initial'] . ' ' . $accountInfo['surname'],
                'address' => $address,
                'postcode' => $accountInfo['postcode'],
                'country' => $accountInfo['country'],
                'tel' => $accountInfo['telephone'],
                'email' => $accountInfo['email'],
                'fixContact' => '', // prevents the user from editing contact details on worldpay page
                'lang' => 'en',
                'M_email' => $accountInfo['email'],
                'M_PHPSESSID' => eZHTTPTool::getSessionKey(),
                'M_USERID' => $user_id,
                'M_ORDERCREATED' => $order->attribute( "created" ),
                'MC_callback' => $worldpayINI->variable( 'Worldpay', 'CallbackUrl')
                );

        $url = $worldpayUrl;
        $sep = '?';
        foreach ($http_get_vars as $name => $value) {
            $url.= $sep . $name . '=' . urlencode($value);
            $sep = '&';
        }
    
        //__DEBUG__
            $this->logger->writeTimedString("item_name      = " . $http_get_vars['desc']);
            $this->logger->writeTimedString("orderID        = " . $orderID);
            $this->logger->writeTimedString("localHost      = " . $localHost);
            $this->logger->writeTimedString("amount         = " . $http_get_vars['amount']);
            $this->logger->writeTimedString("currency_code  = " . $http_get_vars['currency']);
        //___end____

        return $url;
    }
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_WORLDPAY, "worldpaygateway", "Worldpay" );

?>
