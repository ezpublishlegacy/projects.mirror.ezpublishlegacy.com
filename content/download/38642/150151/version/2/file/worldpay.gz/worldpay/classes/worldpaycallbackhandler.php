<?php

define( "WORLDPAY_ERROR_CALLBACK_INVALID", 0 );
define( "WORLDPAY_SUCCESS", 1 );
define( "WORLDPAY_ERROR_PAYMENT_FAILED", 2 );
define( "WORLDPAY_ERROR_BAD_CONFIGURATION", 3 );

require_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
require_once( 'kernel/shop/classes/ezpaymentobject.php' );
require_once( 'kernel/classes/ezorder.php' );
require_once( 'lib/ezutils/classes/ezoperationhandler.php' );

/**
 * Verifies that the current HTTP request represents a valid WorldPay
 * callback, and if so, processes it.
 */
class WorldPayCallbackHandler {
    var $_logger;

    function WorldPayCallbackHandler() {
        $this->_logger =& eZPaymentLogger::CreateForAdd( 'var/log/WorldPayCallback.log' );
    }

    function &_worldpayIni() {
        return eZINI::instance( "worldpay.ini" );
    }
    function &_exchangeRateIni() {
        return eZINI::instance( "xrate.ini" );
    }
    function &_httpRequest() {
        return eZHTTPTool::instance();
    }
    function _httpRemoteIP() {
        return $_SERVER['REMOTE_ADDR'];
    }
    function &_shopAccountHandler() {
        require_once('kernel/classes/ezshopaccounthandler.php');
        return eZShopAccountHandler::instance();
    }
    function &_lookupPaymentObjectByOrderId($order_id) {
        return eZPaymentObject::fetchByOrderID($order_id);
    }
    function &_lookupOrder($order_id) {
        return eZOrder::fetch($order_id);
    }

    function _logNotice($message) {
        $this->_logger->writeTimedString($message);
    }
    
    function _logError($message) {
        $this->_logger->writeTimedString($message);
    }

    function _executeOperation($moduleName, $operationName, $operationParameters) {
        return eZOperationHandler::execute($moduleName, $operationName, $operationParameters);
    }
    
    function handleCallback() {
        if (!$this->_verifyIniFiles()) {
            return WORLDPAY_ERROR_BAD_CONFIGURATION;
        }

        $http_request =& $this->_httpRequest();
        if (!$this->_verifyCallback($http_request) ) {
            return WORLDPAY_ERROR_CALLBACK_INVALID;
        }
        
        if (!$this->_verifyPayment($http_request) ) {
            return WORLDPAY_ERROR_PAYMENT_FAILED;
        }
        
        // Run workflow for this order
        $this->_executeOperation( 'shop', 'checkout', array( 'order_id' => (int) $http_request->variable( "cartId" ) ) );
        
		return WORLDPAY_SUCCESS;
    }

    function _verifyIniFiles() {
        $required_ini_vars = array('WPServer', 'Password', 'InstallationID', 'DefaultCurrency', 'AcceptableCurrencyConversionErrorMargin', 'WorldpayFormAddress', 'TestMode');
        $ini =& $this->_worldpayIni();

        foreach ($required_ini_vars as $var_name) {
            if ($ini->hasVariable('Worldpay', $var_name))
                continue;

            $this->_failReason("Configuration error: required worldpay.ini variable '$var_name' not defined");
            return false;
        }
        
        return true;
    }
    
    function _verifyCallback(&$http_request ) {
        if ( !$this->_verifyRemoteIP() or
             !$this->_verifyPostVars())
        {
            return false;
        }	

        $ini =& $this->_worldpayIni();

        $expected_installation_id = $ini->variable('Worldpay', 'InstallationID');
        $actual_installation_id = $http_request->variable('instId');
        if ( $expected_installation_id != $actual_installation_id )
        {
            $this->_failReason("Worldpay Installation ID does not match");
            return false;
        }
        
        if ( $ini->variable( "Worldpay", "Password" ) != $http_request->variable( "callbackPW" ) )
        {
            $this->_failReason("Worldpay passwords do not match");
            return false;
        }
        
        return true;
    }
    
    function _verifyPostVars() {
        $required_post_vars = array(
            'cartId', 'instId', 'M_USERID', 'amount', 'postcode', 'email',
            'M_ORDERCREATED', 'M_PHPSESSID', 'authCurrency', 'callbackPW', 'rawAuthCode',
            'name');

        $http =& $this->_httpRequest();

        foreach ($required_post_vars as $var_name) {
            if ($http->hasVariable($var_name))
                continue;

            $this->_failReason("Configuration error: required HTTP POST variable '$var_name' not defined");
            return false;
        }
        return true;
    }
    
    function _verifyRemoteIP() {
        $ini =& $this->_worldpayIni();
        
        //Get valid Worldpay server IP range array
        $wpServer = $ini->variable( "Worldpay", "WPServer" );

        //Get IP address of calling system
        $remoteIP = $this->_httpRemoteIP();
        $longintRemoteIP = $this->_ip2hex($remoteIP);

        // loop thru ranges in ini to check for valid ip		
        foreach ( $wpServer as $ip  ) {
            $wpServerRange = explode("-",$ip);

            if ( count($wpServerRange)==1) {
                if ($longintRemoteIP == $this->_ip2hex($wpServerRange[0]))
                    return true;
            }
            else {
                $wpServerStart = $this->_ip2hex($wpServerRange[0]);
                $wpServerEnd = $this->_ip2hex($wpServerRange[1]);

                // note we are doing a string comparison on these,
                // since php uses signed integers, so it wouldn't cope
                // with an ip address range spanning 128.0.0.0
                // boundary
                if ( $longintRemoteIP >= $wpServerStart and $longintRemoteIP <= $wpServerEnd)
                {
                    return true;
                }
            }
        }
        
        $this->_failReason("Worldpay callback originated from server IP '$remoteIP', which is not in the required ranges (".implode(', ', $wpServer).")");
        return false;
    }

    /**
     * Get an 8 digit hex representation of an ip address (padded left
     * with 0's)
     */
    function _ip2hex($ip) {
        return sprintf('%08x', ip2long($ip));
    }

    function _lookupExchangeRate($auth_currency) {
        $ini =& $this->_worldpayIni();
        $default_currency = $ini->variable('Worldpay', 'DefaultCurrency');
        
        // based on the passed back currency run the currency check 		
        switch( $auth_currency )
        {
            case "GBP":
            case "EUR":
            case "USD":
                $currency_pair = $default_currency . '_' . $auth_currency;
                break;
                
            default:
                $this->_failReason("Unknown auth currency: $auth_currency");
                return false;
        }

        // Get exchange rates from Worldpay downloaded ini file
        $inix =& $this->_exchangeRateIni();

        if (!$inix) {
            $this->_failReason( "System configuration error: Exchange rate table 'xrate.ini' not found" );
            return false;
        }
        
        if ( !$inix->hasVariable( "", $currency_pair ) )
        {
            $this->_failReason( "System configuration error: Exchange rate not defined for $currency_pair" );
            return false;
        }
        
        return $inix->variable('', $currency_pair);
    }

    /**
     * Ensure the authorised amount is within a certain tolerance of
     * the expected amount. This is to allow for currency conversion inaccuracies.
     */
    function _verifyAmount($auth_currency, $auth_amount, $expected_amount ) {
        $rate = $this->_lookupExchangeRate($auth_currency);
        if (!$rate) {
            return false;
        }

        $ini =& $this->_worldpayIni();
        $price_tolerance = $ini->variable( "Worldpay", "AcceptableCurrencyConversionErrorMargin" );

        if ( abs(($auth_amount) / $rate - $expected_amount) <= $expected_amount * $price_tolerance )
        {
            return true;
        } else {
            $this->_failReason("Authorised payment amount is NOT within range: authorised amount: $auth_amount auth currency: $auth_currency expected amount: $expected_amount rate: $rate permitted price tolerance: $price_tolerance discrepancy: " . abs(($auth_amount) / $rate - $expected_amount));
            return false;
        }
    }
    
    function _verifyPayment( $http_request ) {
        $ini =& $this->_worldpayIni();

        // Check values with persistant object
        $order_id = (int) $http_request->variable( "cartId" );
        $payment_object =& $this->_lookupPaymentObjectByOrderId($order_id);
        
        if ( !$payment_object )
        {	
            $this->_failReason("Payment Object ID '$order_id' specified in callback could not be found" );
            return false;
        }
        
        //Order found and has been payed this is a problem
        if ( $payment_object->approved() )
        {
            // email admin
            $this->_failReason("Order has already been payed");
            return false;
        }

        $actual_order_details = array('user_id' => $http_request->variable( "M_USERID" ),
                                      'postcode' => $http_request->variable( "postcode" ),
                                      'created' => $http_request->variable( "M_ORDERCREATED" ),
                                      'session' => $http_request->variable( "M_PHPSESSID" ),
                                      'email' => $http_request->variable( "email" ) );
        $order =& $this->_lookupOrder($order_id);
        $shop_account_handler =& $this->_shopAccountHandler();
        $expected_order_details = $shop_account_handler->accountInformation($order);
        $expected_order_details['user_id'] = $order->attribute('user_id');
        $expected_order_details['created'] = $order->attribute('created');
        $details = unserialize($payment_object->attribute('payment_string'));
        $expected_order_details['session'] = $details['session'];
        
        foreach (array_keys($actual_order_details) as $name) {
            if ($actual_order_details[$name] != $expected_order_details[$name]) {
                // Order details do not match
                $this->_failReason(sprintf("Order details do not match: $name expected '%s' but got '%s'",
                                           $expected_order_details[$name],
                                           $actual_order_details[$name]));
                return false;
            }
        }

        if ( !$this->_verifyAmount( $http_request->variable( "authCurrency" ),
                                    $http_request->variable( "authAmount" ),
                                    $order->attribute('total_inc_vat') ))
        {
            return false;
        }
        
        // Now check for authorisation.
        if ( $http_request->variable( "rawAuthCode" ) != "A" )
        {
            // **** Payment cancelled ***
            $this->_failReason("Payment not authorised by Worldpay");
            return false;
        }
        
        // **** An accepted payment so lets mark the db as payed ***
        $this->_logNotice("Payment passes check and is authorised by worldpay" );
        $payment_object->approve();

        return true;
    }

    function _failReason( $fail_reason ) {
        $post_data = array();
        foreach ($_POST as $name=>$val) {
            $post_data[] = "$name=$val";
        }
        $this->_logError("FAILURE: $fail_reason. \$_POST=[" . implode(', ', $post_data) . "]");
        
        $http_request =& $this->_httpRequest();
        
        // See if we have an order number so we can set the fail reason
        $order_id = $http_request->variable( "cartId" );
        if ( !$order_id ) {
            return;
        }
        
        $payment_object =& $this->_lookupOrder($order_id);
        if ( !$payment_object ) {
            return;
        }

        $details = unserialize($payment_object->attribute('payment_string'));
        $details['fail_reason'] = $fail_reason;
        $payment_object->setAttribute( 'payment_string', serialize($details) );
        $payment_object->store();
    }
}

?>
