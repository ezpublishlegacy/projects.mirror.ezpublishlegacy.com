<?php /* #?ini charset="iso-8859-1"?

[Worldpay]

# Installation ID
InstallationID=

# Worldpay Form address - normally you don't need to change this
WorldpayFormAddress=https://select.worldpay.com/wcc/purchase

# Address where worldpay will send callback. Change www.example.com to
# your server address. Must be accessible from the public internet, ie
# not NATed or behind a firewall
CallbackUrl=http://www.example.com/worldpay/callback

# Worldpay callback password - as entered in the Customer Management System
Password=

# Worldpay Test Mode - 100 means "test", 0 means "live"
TestMode=100

# The product description passed to worldpay is trimmed to this number
# of characters if it's too long
MaxDescriptionLength=255

# Default Currency
DefaultCurrency=GBP

# The authorised amount is allowed to differ from the expected
# transaction value by this fraction of the expected value
AcceptableCurrencyConversionErrorMargin=0.01

# IP Address ranges for the remote worldpay servers. Any callbacks
# from IP addresses outside these ranges will be considered invalid
# and logged
WPServer[]=155.136.68.0-155.136.68.255
WPServer[]=193.41.220.0-193.41.221.255

*/ ?>
