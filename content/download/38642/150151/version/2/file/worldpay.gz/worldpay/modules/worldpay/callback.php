<?php
//
// Definition of Worldpay module
//
// Created on: <30-June-2003 TW>
//
// Copyright (C) 1999-2003 Vision with Technology, All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation 
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@visionwt.com if any conditions of this licencing isn't clear to
// you.
//
/*
Author:       Tony Wood
Version:      $Id: callback.php 1307 2005-08-20 19:15:58Z paulf $
*/

$module =& $Params["Module"];

require_once( "kernel/common/template.php" );
$tpl =& templateInit();

require_once('extension/worldpay/classes/worldpaycallbackhandler.php');
$callback_handler =& new WorldPayCallbackHandler();
$tpl->setVariable( "status", $callback_handler->handleCallback());
$http =& eZHTTPTool::instance();
$tpl->setVariable( "name", $http->variable('name'));

$currency_symbol_map = array('USD' => '$', 'GBP' => '&pound;', 'EUR' => '&euro;');
$tpl->setVariable( "amount", $currency_symbol_map[$http->variable('authCurrency')] . sprintf('%.2f', $http->variable('authAmount')));

$Result = array();
$Result['pagelayout'] = 'wp_pagelayout.tpl';
$Result['content'] =& $tpl->fetch( "design:callback.tpl" );
return true;
	
?>
