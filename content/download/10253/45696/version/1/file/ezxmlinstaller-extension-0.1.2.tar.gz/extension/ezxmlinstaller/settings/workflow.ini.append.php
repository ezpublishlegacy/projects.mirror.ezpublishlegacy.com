<?php /* #?ini charset="iso-8859-1"?


[EventSettings]
ExtensionDirectories[]=ezxmlinstaller
AvailableEventTypes[]=event_ezxmlpublisher

*/ ?>