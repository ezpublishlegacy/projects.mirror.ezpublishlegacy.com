<?php

class ngresposiveimagesInfo
{
    public static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/ngresponsiveimages">Netgen Responsive Images</a> extension',
            'Version' => '2.0',
            'Copyright' => 'Copyright (&copy;) 2010-2013 <a href="http://www.netgenlabs.com" target="_blank">Netgen</a>',
            'License' => 'GNU General Public License v2.0'
        );
    }
}

?>
