<?php /* #?ini charset="utf-8"?

[SiteSettings]
MetaDataArray[viewport]=width=device-width,initial-scale=1
*/?>
