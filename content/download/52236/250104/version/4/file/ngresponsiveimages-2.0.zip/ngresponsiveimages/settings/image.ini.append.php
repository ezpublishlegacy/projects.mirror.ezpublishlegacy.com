<?php /* #?ini charset="utf-8"?

#[AliasSettings]
#AliasList[]=imagefull
#AliasList[]=image2full
#AliasList[]=i450_3_2
#AliasList[]=i480_3_2
#AliasList[]=i640_3_2
#AliasList[]=i900_3_2

#[imagefull]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=1000

#[image2full]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=1200

#[image2full3]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=1200

#[i450_3_2]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=450

#[i480_3_2]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=480

#[i640_3_2]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=640

#[i900_3_2]
#Reference=original
#Filters[]=geometry/scalewidthdownonly=900
*/ ?>
