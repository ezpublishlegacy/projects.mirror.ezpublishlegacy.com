Google Translate in backend 1.2

With this module you can translate from language to language using the Google Ajax Translate API.

The extension is based on YUI and Google Translate API.

I invite you to download this plugin. This is a beta version, if something is not working correctly, please write.
If you find any errors, please write a comment. If you have any suggestions / ideas about this extension, please write.
If you are using the extension successfully, leave your comment :)

Quick Install

1. Extract extension to directory extension
2. The default is set siteaccess site_admin. If your siteaccess is different, it should be changed. Then you have to rename the directory:
- settings / siteaccess / site_admin (change to its name),
- settings / siteaccess / site_admin / site.ini.append.php:
[DesignSettings]
AdditionalSiteDesignList [] = site_admin (change to its name)
- design / site_admin (change to its name) 
3. Activate in setup/extension and regenerate
4. Clear Cache

The extension works with:
- ezstring
- eztext
- ezxmltext
- ezxmltext_ezoe
- ezimage
- ezkeyword

By default, there are two translations of the interface: English and Polish language. You can add a new translation in the directory extension / ezgoogletranslate / translations based on the version of the pol-PL.




