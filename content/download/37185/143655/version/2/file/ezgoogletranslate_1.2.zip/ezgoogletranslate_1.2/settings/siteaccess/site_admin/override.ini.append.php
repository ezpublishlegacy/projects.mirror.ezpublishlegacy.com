[ezstring_override]
Source=content/datatype/edit/ezstring.tpl
MatchFile=content/datatype/edit/ezstring_override.tpl
Subdir=templates

[ezxmltext_override]
Source=content/datatype/edit/ezxmltext.tpl
MatchFile=content/datatype/edit/ezxmltext_override.tpl
Subdir=templates

[ezxmltext_ezoe_override]
Source=content/datatype/edit/ezxmltext_ezoe.tpl
MatchFile=content/datatype/edit/ezxmltext_ezoe_override.tpl
Subdir=templates

[eztext_override]
Source=content/datatype/edit/eztext.tpl
MatchFile=content/datatype/edit/eztext_override.tpl
Subdir=templates

[ezkeyword_override]
Source=content/datatype/edit/ezkeyword.tpl
MatchFile=content/datatype/edit/ezkeyword_override.tpl
Subdir=templates

[ezimage_override]
Source=content/datatype/edit/ezimage.tpl
MatchFile=content/datatype/edit/ezimage_override.tpl
Subdir=templates
