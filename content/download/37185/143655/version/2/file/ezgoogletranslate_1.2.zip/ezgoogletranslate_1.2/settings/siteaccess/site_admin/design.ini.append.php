[ExtensionSettings]
DesignExtensions[]=ezgoogletranslate

[StylesheetSettings]
CSSFileList[]=ezgoogletranslate.css
CSSFileList[]=yui/build/container/assets/skins/sam/container.css

[JavaScriptSettings]
JavaScriptList[]=yui/build/yahoo-dom-event/yahoo-dom-event.js
JavaScriptList[]=yui/build/container/container-min.js
JavaScriptList[]=yui/build/dragdrop/dragdrop-min.js
JavaScriptList[]=yui/build/yahoo/yahoo-min.js
JavaScriptList[]=yui/build/event/event-min.js
JavaScriptList[]=yui/build/connection/connection-min.js
