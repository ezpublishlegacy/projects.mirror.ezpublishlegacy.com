<?php
//
// Creation Date : 28-06-2009
// Author : Lukasz Klejnberg
// www.idealsolutions.pl
//
// This module allows translate with google api and YUI
//

$Module = array( 'name' => 'ezgoogletranslate' );

$ViewList = array();
$ViewList['output'] = array( 'script' => 'output.php' );

?>