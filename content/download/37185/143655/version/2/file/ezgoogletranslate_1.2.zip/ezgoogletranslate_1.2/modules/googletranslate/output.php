<?php
// sometime pecl json php is not install on servers so we can use this function
// function from: http://us.php.net/manual/en/function.json-decode.php#91216
if ( !function_exists('json_decode') ){ 
	function json_decode($json)
	{ 
	    // Author: walidator.info 2009
	    $comment = false;
	    $out = '$x=';
	   
	    for ($i=0; $i<strlen($json); $i++)
	    {
	        if (!$comment)
	        {
	            if ($json[$i] == '{')        $out .= ' array(';
	            else if ($json[$i] == '}')    $out .= ')';
	            else if ($json[$i] == ':')    $out .= '=>';
	            else                         $out .= $json[$i];           
	        }
	        else $out .= $json[$i];
	        if ($json[$i] == '"')    $comment = !$comment;
	    }
	    eval($out . ';');
	    return $x;
	}
	
	$jsondecode = 1;
}

// include library
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$http = eZHTTPTool::instance();

$text = rawurlencode(strip_tags($http->postVariable('text'),'<p><h1><h2><h3><h4><h5>'));

if( $http->postVariable('from_language') )
	$from  = $http->postVariable('from_language');
else
	$from = 'pl';
	
if( $http->postVariable('to_language') )
	$to = $http->postVariable('to_language');
else
	$to = 'en';
	
$data = file_get_contents("http://ajax.googleapis.com/ajax/services/language/translate?v=1.0&q=$text&langpair=$from%7C$to");

$data = json_decode($data);

$tpl = templateInit();

// check if this php pecl json
if ( $jsondecode )
{
	// is translated?
	if( $data['responseStatus'] == 200 ) {
		$tpl->setVariable('translated',$data['responseData']['translatedText']);
		echo $tpl->fetch( 'design:googletranslate/translate.tpl' );
	} else {
		$tpl->setVariable('translated',ezi18n( 'extension/ezgoogletranslate', 'I can not translate this text. Try change some words.' ));
		echo $tpl->fetch( 'design:googletranslate/translate.tpl' );
	}
} else {
	// is translated?
	if( $data->{'responseStatus'} == 200 ) {
		$tpl->setVariable('translated',$data->{'responseData'}->{'translatedText'});
		echo $tpl->fetch( 'design:googletranslate/translate.tpl' );
	} else {
		$tpl->setVariable('translated',ezi18n( 'extension/ezgoogletranslate', 'I can not translate this text. Try change some words.' ));
		echo $tpl->fetch( 'design:googletranslate/translate.tpl' );
	}
}

include_once( 'lib/ezutils/classes/ezexecution.php' );
eZExecution::cleanup();
eZExecution::setCleanExit();
exit();

?>