[ModuleSettings]
ExtensionRepositories[]=ezgoogletranslate
ModuleList[]=ezgoogletranslate