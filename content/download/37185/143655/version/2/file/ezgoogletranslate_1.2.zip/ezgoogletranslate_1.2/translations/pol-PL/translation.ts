<!DOCTYPE TS><TS>
<context>
    <name>extension/ezgoogletranslate</name>
    <message>
        <source>I can not translate this text. Try change some words.</source>
        <translation>Nie mogę przetłumaczyć tego tekstu. Spróbuj zmienić jakieś słowa.</translation>
    </message>
    <message>
        <source>show google translate</source>
        <translation>pokaż google translate</translation>
    </message>
    <message>
        <source>Translate from:</source>
        <translation>Tłumacz z:</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <source>translate</source>
        <translation>tłumacz</translation>
    </message>
    <message>
        <source>Translating, please wait...</source>
        <translation>Trwa tłumaczenie, proszę czekać...</translation>
    </message>
    <message>
        <source>Translate:</source>
        <translation>Tłumaczenie:</translation>
    </message>
</context>
</TS>
