<?php
/**
* Allows to create an object from the pathbar (no need to post)
*/

include_once( 'kernel/common/template.php' );

function error ($message)
{
  // how do I display an error message ?
  die ($message);
}

$tpl =& templateInit();
$http =& eZHTTPTool::instance();
$objectid=null;
$ownerid=null;

if (isset ($Params['Parameters'][0]) && isset ($Params['Parameters'][1]))
{
  $parentnodeid=$Params['Parameters'][0];
  $classid=$Params['Parameters'][1];
}
  else
    error ("syntax: /getobjects/create/{nodeid}/{classid}");
}

die ("");
?>
