[TemplateSettings]
ExtensionAutoloadPath[]=getobjects

