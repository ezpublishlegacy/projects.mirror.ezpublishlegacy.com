<?php
$Module = array( "name" => "sydesy" );

$ViewList = array();
$ViewList["create"] = array( "script" => "create.php",
                             "params" => array ('parentnodeid','classid'),
               ); 
?>
