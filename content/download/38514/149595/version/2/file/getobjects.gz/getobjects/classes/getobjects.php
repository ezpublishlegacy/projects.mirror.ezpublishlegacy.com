<?
/*!
  This operator allows to get as a list all the objects embedded into a xmltext.  See the doc for usage examples
*/

include_once( 'lib/ezxml/classes/ezxml.php' );

class getObjectsOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function getObjectsOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'getobjects' ,
					  'getembedded','getlinks' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    
 
    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'getobjects' => array( 'xmlattribute' => array( 'type' => 'attribute',
                                                                         'required' => true,
                                                                         'default' => "" ),
												 'asObjects' => array('type' => 'boolean',
																		'required' => false,
																	'default' => false) ) );

    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        if (!isset($namedParameters['xmlattribute']->DataText))
        {
            // what's the proper way of raising an error ?
            $operatorValue[]="should be an attribute";
            return "should be an attribute";
        }
        $operatorValue = array ();
        $xmldata =& $namedParameters['xmlattribute']->DataText;
        $xml = new eZXML();
        $dom =& $xml->domTree( $xmldata );
        if ( is_object ($dom) )
        {
						// 3.5 object tag
            $objects =& $dom->elementsByName( "object" );
            foreach ($objects as $object)
            {
                $attributes=& $object->attributes();
                foreach ($attributes as $attribute)
                {
                    if ($attribute->Name == "id")
                        $operatorValue[] = $attribute->content;
                } 
            }
					 // 3.6 embed tag
           $objects =& $dom->elementsByName( "embed" );
           foreach ($objects as $object)
           {
               $attributes=& $object->attributes();
               foreach ($attributes as $attribute)
               {
                   if ($attribute->Name == "object_id")
                       $operatorValue[] = $attribute->content;
               } 
           }
        }
    }
}
?>
