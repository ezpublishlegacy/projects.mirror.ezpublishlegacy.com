<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' =>
'extension/getobjects/classes/getobjects.php',
         'class' => 'GetObjectsOperator',
         'operator_names' => array( 'getobjects','getlinks','getembedded' ) );

?>
