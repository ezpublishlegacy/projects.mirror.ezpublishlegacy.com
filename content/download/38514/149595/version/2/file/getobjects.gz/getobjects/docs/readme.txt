get objects
---------------------------

/*
    Get objects extension for eZ publish 3.x
    Copyright (C) 2005  Sydesy ltd

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

1. Introduction
------------
This operator allows to retrieve a list of all the embedded objects into a xmltext attribute. This is useful (at least to me) to avoid duplicates between the objects embedded into the body of an article and the list of the related objects for instance.


2. Example of use
-----------------

On the template full/article.tpl :
{let embedded=getobjects($node.object.data_map.body)}

Display the body attribute, that might have a lot of embeded objects, like the picture of my son (Dorian).
<div class="article_body">{attribute_view_gui attribute=$node.object.data_map.body}</div>

<h2>Related Objects</h2>
here your list all the the embeded objects, but you don't display the picture of Dorian, as it is already displayed in the body above.
{section loop $node.object.related_contentobject_array}
        {content_view_gui view=text_linked content_object=$:item}
{section-exclude match=$embedded|contains($:item.id)}
 {/section}

{/let}


3. Known bugs and limitations
-----------------------------

None, but feel free to send me a mail (ez AT sydesy DOT com) if you find one

4. Thanks possible evolutions
--------------------------------

Thanks to Ben Pirt, that modified this extension so it works with 3.6
On the long run, I'd like to have this operator shipped with ez.

5. Disclaimer & Copyright
-------------------------
/*
    get objects for eZ publish 3.x
    Copyright (C) 2005  Sydesy ltd

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
The operator is tailored to fit our needs, and is shared with the community as is.


Thanks for your attention

Xavier DUTOIT


