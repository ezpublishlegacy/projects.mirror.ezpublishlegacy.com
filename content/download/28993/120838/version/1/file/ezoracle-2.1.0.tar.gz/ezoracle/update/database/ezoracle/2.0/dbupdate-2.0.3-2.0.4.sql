ALTER TABLE ezenumvalue MODIFY ( enumelement NULL );
ALTER TABLE ezenumvalue MODIFY ( enumvalue NULL );
ALTER TABLE ezenumobjectvalue MODIFY ( enumvalue NULL );
ALTER TABLE ezcontentclass_name MODIFY ( name NULL );
