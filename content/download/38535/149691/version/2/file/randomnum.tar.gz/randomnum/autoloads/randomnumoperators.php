<?php
/***************************************************************************
 *   Copyright (C) 2005 by Annnn                                           *
 *   cookiem@akl.lt                                                        *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

/*!
  \class   RandomnumOperator randomoperators.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator random. By using random you can get *suprisingly* random integers :)
  \version 1.0
  \date    Wednesday March 02 2005 09:01:53 pm
  \author  Darjus Loktevic

  

  Example:
\code
{randomnum($min,$max)}
\endcode
*/

class RandomnumOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function RandomnumOperator()
    {
	srand((double)microtime()*1000000);
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'randomnum' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'randomnum' => array( 'min' => array( 'type' => 'integer',
                                                                 'required' => true,
                                                                 'default' => 0 ),
                                         'max' => array( 'type' => 'integer',
                                                                  'required' => true,
                                                                  'default' => 0 ) ) );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $min = $namedParameters['min'];
        $max = $namedParameters['max'];

        switch ( $operatorName )
        {
            case 'randomnum':
            {
                $operatorValue = rand($min,$max);
            } break;
        }
    }
}
?>