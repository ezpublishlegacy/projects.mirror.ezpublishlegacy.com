<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=nl_googleplus

[RegionalSettings]
TranslationExtensions[]=nl_googleplus

*/ ?>
