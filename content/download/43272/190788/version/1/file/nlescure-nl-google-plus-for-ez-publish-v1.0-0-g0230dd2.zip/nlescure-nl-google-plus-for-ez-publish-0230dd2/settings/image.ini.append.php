<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=googlpluslist

[googlpluslist]
Reference=
Filters[]
Filters[]=geometry/scaledownonly=100;160
*/ ?>