<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nl_googleplus

[StylesheetSettings]
CSSFileList[]=style.css

[JavaScriptSettings]
JavaScriptList[]=https://apis.google.com/js/plusone.js

*/ ?>
