<?php /* #?ini charset="utf-8"?

[GooglePlus]
#format : <clientid>@developer.gserviceaccount.com
ClientId=<clientid>@developer.gserviceaccount.com
ClientSecret=<clientsecret>
DeveloperKey=<developerkey>
Scope=https://www.googleapis.com/auth/plus.me

[Feed]
MaxResults=10
UserId=108189603281362876853

*/ ?>
