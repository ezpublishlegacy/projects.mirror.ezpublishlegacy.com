<?php

class nl_cronjobsInfo
{
    static function info()
    {
        return array( 'Name' => "NL Google Plus",
                      'Version' => "1.0",
                      'Copyright' => "Nicolas Lescure",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
