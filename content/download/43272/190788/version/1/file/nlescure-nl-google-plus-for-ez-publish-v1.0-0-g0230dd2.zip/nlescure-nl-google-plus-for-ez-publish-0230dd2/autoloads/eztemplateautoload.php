<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/nl_googleplus/autoloads/nl_googleplus.php',
                                    'class' => 'NlGooglePlus',
                                    'operator_names' => array( 'nlgoogleplus' ) );

?>
