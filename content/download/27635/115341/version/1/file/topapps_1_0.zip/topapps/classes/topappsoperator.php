<?php
include_once('extension/topapps/classes/simple_html_dom.php');
/*!
  \class   TopAppsOperator topappsoperator.php
  \ingroup eZTemplateOperators
  \brief   List top apps from app store.
  \version 1.0
  \date    Wednesday 28 July 2010 11:37:15 am
  \author  Thiago Campos Viana

*/


class TopAppsOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function TopAppsOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'topapps' );
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'topapps' => array( 'type' => array(	'type' => 'string',
															'required' => false,
															'default'=>'free')));
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {

		$type = $namedParameters['type'];
		
        
		$html = file_get_html("http://www.apple.com/itunes/charts/".$type."-apps");

		// get article block
		$output = array_slice(($html->find('div[id=grid] ul li')), 0, 10); 
		$operatorValue="<ul class=\"top-".$type."-apps\">";
		$count=1;
		//print_r($output);
		foreach($output as $article) {
			// get title
			$operatorValue.="<li class=\"top-".$count."\">";
			
			$title = trim($article->find('h3',0)->innertext);
			$link = trim($article->find('a',0)->getAttribute('href'));
			$img = trim($article->find('img',0)->outertext );
			$developer = trim($article->find('h4',0)->innertext );
			$operatorValue.="<strong>".$count.".</strong>";
			$operatorValue.="<a href=\"".$link."\">".$img."</a>";
			$operatorValue.="<h3>".$title."</h3>";
			$operatorValue.="<h4>".$developer."</h4>";
			$operatorValue.="</li>";
			$count++;		

		}
		$operatorValue.="</ul>";
		// clean up memory
		$html->clear();
		unset($html);
		
    }
}

?>