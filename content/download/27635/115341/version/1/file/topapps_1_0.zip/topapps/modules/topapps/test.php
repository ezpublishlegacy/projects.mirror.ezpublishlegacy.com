<?php

$tpl = eZTemplate::factory();

$Result = array();
$Result['path'] = array( array( 'url' => false,

                'text' => 'TopApps' ),

        array( 'url' => false,

                'text' => 'Test' ) );
$Result['content']=$tpl->fetch("design:topapps/test.tpl");

?>
