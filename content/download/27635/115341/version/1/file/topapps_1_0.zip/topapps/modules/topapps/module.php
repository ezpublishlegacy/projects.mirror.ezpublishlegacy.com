<?php
$Module = array(
        "name" => 'topapps'
);

$ViewList = array();
$ViewList['test'] = array(
        'functions' => array( 'test' ),
        'script'  => 'test.php'
);

$FunctionList[ 'test' ] = array();

?>
