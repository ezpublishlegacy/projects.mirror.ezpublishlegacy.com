<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/breakingpre/autoloads/breakingpreoperator.php',
         'class' => 'BreakingPREOperator',
         'operator_names' => array( 'plainToBreakPre' ) );

?>