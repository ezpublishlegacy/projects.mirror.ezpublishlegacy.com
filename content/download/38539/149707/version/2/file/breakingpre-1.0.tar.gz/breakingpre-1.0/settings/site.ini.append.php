[TemplateSettings]
ExtensionAutoloadPath[]=breakingpre