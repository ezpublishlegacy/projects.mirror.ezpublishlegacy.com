<?
//
// Definition of BreakingPREOperator class
//
// Created on: <15-January-2005 12:15:07 fh>
//
// Copyright (C) 1999-2004 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// Licencees holding a valid "eZ publish professional licence" version 2
// may use this file in accordance with the "eZ publish professional licence"
// version 2 Agreement provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" version 2 is available at
// http://ez.no/ez_publish/licences/professional/ and in the file
// PROFESSIONAL_LICENCE included in the packaging of this file.
// For pricing of this licence please contact us via e-mail to licence@ez.no.
// Further contact information is available at http://ez.no/company/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//


class BreakingPREOperator
{
    /*!
     Constructor
    */
    function BreakingPREOperator()
    {
        $this->Operators = array( 'plainToBreakPre' );
    }

    /*!
     Returns the operators in this class.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     \return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     The first operator has two parameters, the other has none.
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {
        return array( 'plainToBreakPre' => array() );
    }

    /*!
     Executes the needed operator(s).
     Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                     &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'plainToBreakPre':
            {
                $operatorValue = $this->plainToBreakPre( $operatorValue );
            } break;
        }
    }

    /*!
     \return Perform the magic:
       - All lines must be withing <span class="line"></span>
       - All empty lines are converted to <span class="line"></span>
       - All spaces (except single spaces) are converted into &nbsp.
    */
    function plainToBreakPre( $stringValue )
    {
        $outputString = "";
        $numChar = strlen( $stringValue );
        $numSpaces = 0;
        $currentlyInLine = false;

        for( $i = 0; $i < $numChar; ++$i )
        {
            $curVal = $stringValue[$i];
            switch( $curVal )
            {
                case "\r": break; // eat
                case "\n":
                {
                    if( $currentlyInLine == true )
                    {
                        $outputString .= "</span>\n";
                        $currentlyInLine = false;
                    }
                    else // linebreak all by itself
                    {
                        $outputString .= "<span class=\"line\"></span>\n";
                    }
                    break;
                }
                case ' ':
                {
                    ++$numSpaces;
                    break;
                }
                default:
                {
                    if( $currentlyInLine != true )
                    {
                        $outputString .= "<span class=\"line\">";
                        $currentlyInLine = true;
                    }

                    if( $numSpaces > 1 )
                    {
                        $outputString .= str_repeat( "&nbsp;", $numSpaces );
                    }
                    else if( $numSpaces == 1 )
                    {
                        $outputString .= ' ';
                    }
                    $numSpaces = 0;

                    $outputString .= $curVal;
                    break;
                }
            }
        }

        if( $currentlyInLine ) $outputString .= "</span>\n";
        return $outputString;
    }

    // \privatesection
    var $Operators;
}

?>
