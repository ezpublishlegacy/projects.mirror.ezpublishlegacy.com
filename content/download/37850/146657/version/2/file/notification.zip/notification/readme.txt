NOTIFICATION DIGEST IMPROVEMENTS

These files add options for daily and monthly notification digest settings, in addition to
weekly digest, which is already supported. This will be part of eZ publish 3.5.

Installation:

Just copy these files into your eZ publish installation.

kernel/classes/notification/eznotificationschedule.php
kernel/classes/notification/handler/ezsubtree/ezsubtreehandler.php
kernel/classes/notification/handler/ezgeneraldigest/ezgeneraldigesthandler.php
kernel/classes/notification/handler/ezgeneraldigest/ezgeneraldigestusersettings.php
design/standard/templates/notification/handler/ezgeneraldigest/settings/edit.tpl
lib/ezlocale/classes/ezlocale.php
