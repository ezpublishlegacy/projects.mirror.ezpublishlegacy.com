<?php /* #?ini charset="iso-8859-1"?

[CustomTagSettings]
AvailableCustomTags[]=youtube
IsInline[youtube]=true

[youtube]
CustomAttributes[]=movie_url
CustomAttributes[]=width
CustomAttributes[]=height
CustomAttributesDefaults[movie_url]=Eg: http://www.youtube.com/v/(Insert MovieID)
CustomAttributesDefaults[width]=425
CustomAttributesDefaults[height]=350


*/ ?>
