<?php
class bcpostalcodeInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/bcpostalcode'>BC Postal Code</a>",
            'Version' => "0.0.1",
            'Copyright' => "Copyright (C) 2001 - 2007 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Brookins Consulting",
            'License' => "GNU General Public License"
        );
    }
}
?>