<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=bcpostalcode
AvailableDataTypes[]=bcpostalcode
# AvailableDataTypes[]=bcphonestring
# AvailableDataTypes[]=bcstateselect

*/ ?>