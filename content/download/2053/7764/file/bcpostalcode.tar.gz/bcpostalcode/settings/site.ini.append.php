<?php /* #?ini charset="utf-8"?

[DesignSettings]
# SiteDesign=ezwebin
# AdditionalSiteDesignList[]=standard
AdditionalSiteDesignList[]=bcpostalcode

*/ ?>