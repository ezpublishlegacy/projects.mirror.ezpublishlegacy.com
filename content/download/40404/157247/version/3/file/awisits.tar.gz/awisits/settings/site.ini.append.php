<?php
/* 
[TemplateSettings]
ExtensionAutoloadPath[]=awisits


 */
?>
