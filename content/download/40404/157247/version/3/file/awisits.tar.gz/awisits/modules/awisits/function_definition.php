<?php
$FunctionList = array();
$FunctionList['readFileGrep'] = array(
		'name' => 'Read_file_with_grep_command',
		'call_method' => array(
			'include_file' => 'extension/awisits/modules/awisits/utils.php',
			'class' => 'Utils',
			'method' => 'readFileGrep'
			),
		'parameters_type' => 'standard',
		'parameters' => array( array(
					'name' => 'command',
					'type' => 'string',
					'required' => true) )
);


?>
