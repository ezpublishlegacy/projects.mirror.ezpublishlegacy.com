<?php
/*
[ModuleSettings]
ExtensionRepositories[]=awisits
ModuleList[]=awisits
*/
?>
