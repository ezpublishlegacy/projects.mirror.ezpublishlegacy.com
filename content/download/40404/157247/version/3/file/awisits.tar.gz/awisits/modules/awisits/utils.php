<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of utiles
 *
 * @author hugo
 */
class Utils {

    function readFileGrep ($command) {
        $result=array();
        $coutput=`$command`;
        $totals=explode(" ", ltrim(str_replace("TotalVisits", "", $coutput)));
        $result=array_sum($totals);
        return array('result'=>$result);
    }

}
?>
