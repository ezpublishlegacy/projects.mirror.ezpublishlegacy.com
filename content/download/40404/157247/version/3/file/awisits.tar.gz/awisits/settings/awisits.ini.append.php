<?php
/* 
[AWStats]
Files=/home/<yourhomefolder>/awstats/*www*
Preffix=grep -h -v ^#
Suffix=grep TotalVisits

 */
?>
