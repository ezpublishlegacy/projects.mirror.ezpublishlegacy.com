<?php
/* 
[ExtensionSettings]
DesignExtensions[]=awisits

[StylesheetSettings]
CSSFileList[]=awstyles.css


*/

?>
