<?php

/**
 * SELF Var Cache extension for eZ Publish 4.0
 * Written by Piotrek Karas, Copyright (C) SELF s.c.
 * http://www.mediaself.pl, http://ez.ryba.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



class SELFVarCacheTemplateOperator {


    var $Operators;


    function __construct()
    {
        $this->Operators = array(
			'selfvarcache_setcollection',
            'selfvarcache_getcollection',
            'selfvarcache_fetchcollection',
        );
    }


    function &operatorList()
    {
        return $this->Operators;
    }


    function namedParameterPerOperator()
    {
        return true;
    }


    function namedParameterList()
    {
        return array(
			'selfvarcache_setcollection' => array(
                'collection' => array(  
                    'type' => 'string',
                    'required' => true,
                    'default' => false,
        ),
                'keys' => array(
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
                'expiry' => array(  
                    'type' => 'integer',
                    'required' => true,
                    'default' => false,
        ),
                'variables' => array(  
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
        ),
            'selfvarcache_getcollection' => array(
                'collection' => array(  
                    'type' => 'string',
                    'required' => true,
                    'default' => false,
        ),
                'keys' => array(
                    'type' => 'array',
                    'required' => true,
                    'default' => false,
        ),
                'expiry' => array(  
                    'type' => 'integer',
                    'required' => true,
                    'default' => false,
        ),
        ),
            'selfvarcache_fetchcollection' => array(
                'object' => array(  
                    'type' => 'object',
                    'required' => true,
                    'default' => false,
        ),
                'max_level' => array(  
                    'type' => 'integer',
                    'required' => true,
                    'default' => false,
        ),
        ),
        );
    }


    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch( $operatorName )
        {
            case 'selfvarcache_setcollection':
                $collection  = $namedParameters['collection'];
                $keys  = $namedParameters['keys'];
                $expiry  = $namedParameters['expiry'];
                $variables  = $namedParameters['variables'];
                $operatorValue = $this->setCollection( $tpl, $collection, $keys, $expiry, $variables );
                break;
            case 'selfvarcache_getcollection':
                $collection  = $namedParameters['collection'];
                $keys  = $namedParameters['keys'];
                $expiry  = $namedParameters['expiry'];
                $operatorValue = $this->getCollection( $tpl, $collection, $keys, $expiry );
                break;
            case 'selfvarcache_fetchcollection':
                $object  = $namedParameters['object'];
                $maxLevel = $namedParameters['max_level'];
                $this->fetchCollection( $object, 0, $maxLevel );
                $operatorValue = $object;
                break;
        }
    }


    /**
     * Go through the object and build the final value and its structure.
     *
     * @param object $value
     * @param integer $currentLevel
     * @param integer $maxLevel
     */
    private function fetchCollection( &$value, $currentLevel, $maxLevel )
    {
        if( $maxLevel !== false and $currentLevel >= $maxLevel )
        {
            return;
        }
        if( is_array( $value ) )
        {
            foreach( $value as $key => $item )
            {
                $this->fetchCollection( $item, $currentLevel+1, $maxLevel );
            }
        }
        else if( is_object( $value ) )
        {
            if( !method_exists( $value, "attributes" ) or !method_exists( $value, "attribute" ) )
            {
                return;
            }
            $attrs = $value->attributes();
            foreach( $attrs as $key )
            {
                $item = $value->attribute( $key );
                $this->fetchCollection( $item, $currentLevel+1, $maxLevel );
            }
        }
    }

    
    /**
     * Calculate collection path based on its name and keys.
     * Create the directory structure, if missing.
     * Return full path to the collection file.
     *
     * @param string $collection
     * @param array $keys
     * @return string
     */
    private function getCollectionPath( $collection, $keys )
    {
        $cacheDir = eZSys::cacheDirectory() . '/selfvarcache/' . $collection . '/';
        if( !file_exists( $cacheDir ) )
        {
            eZDir::mkdir( $cacheDir, eZDir::directoryPermission(), true );
        }

        $keysString = md5( join( $keys ) );
        return $cacheDir . $keysString. '.var';
    }


    /**
     * Expire the requested collection file, if needed.
     *
     * @param string $collection
     * @param array $keys
     * @param integer $expiry
     */
    private function expireCollection( $collection, $keys, $expiry )
    {
        $cachePath = $this->getCollectionPath( $collection, $keys );
        if( ( filemtime( $cachePath ) + (int)$expiry ) < time() )
        {
            unlink( $cachePath );
        }
    }


    /**
     * This method should be called in order to check if the requested var
     * collection is available. If so, there will be no need to set the cache.
     *
     * Before variables are retreived and returned, the method checks if they
     * should be expired. If the cache file is still there, unserialize all
     * vars and pass on to the template layer.
     *
     * @param object $tpl
     * @param string $collection
     * @param array $keys
     * @param integer $expiry
     * @return boolean
     */
    private function getCollection( &$tpl, $collection, $keys, $expiry )
    {
        $this->expireCollection( $collection, $keys, $expiry );

        $cachePath = $this->getCollectionPath( $collection, $keys );
        if( !file_exists( $cachePath ) )
        {
            return false;
        }

        $serializedVariables = eZFile::getContents( $cachePath );
        $variables = unserialize( $serializedVariables );

        foreach( $variables as $variableName => $variableValue )
        {
            $tpl->setVariable( $variableName, $variableValue );
        }
        return true;
    }


    /**
     * This method should be called in order to set the requested variables
     * and create a cache file for their collection.
     *
     * Before variables are retreived and returned, the method checks if they
     * should be expired. If the cache file is not found, serialize all
     * vars and create the cache file.
     *
     * @param object $tpl
     * @param string $collection
     * @param array $keys
     * @param integer $expiry
     * @param array $variables
     */
    private function setCollection( &$tpl, $collection, $keys, $expiry, $variables )
    {
        $this->expireCollection( $collection, $keys, $expiry );

        $cachePath = $this->getCollectionPath( $collection, $keys );
        if( !file_exists( $cachePath ) )
        {
            $serializedVariables = serialize( $variables );
            eZFile::create( $cachePath, false, $serializedVariables );
        }

        foreach( $variables as $variableName => $variableValue )
        {
            $tpl->setVariable( $variableName, $variableValue );
        }
        return;
    }


};

?>
