SELF Var Cache extension for eZ Publish 4.0
version 0.2 beta

Written by Piotrek Karaś, Copyright (C) SELF s.c. & mediaSELF.pl
http://www.mediaself.pl, http://ez.ryba.eu



What is it?
-----------

This extension provides additional cacheing method dedicated to variables.

There are multiple problems with accessing and managing variables that have
beed placed within view cache and template cache, especially when they have
to be reused and different expiry times are set for cache blocks.

This extension provides lightweight cacheing of variable collections, so that
the variables can be easily placed and available in non-cached template areas,
for example directly in the pagelayout, but without being fetched over and
over again.



License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



Template operators
------------------

- selfvarcache_getcollection( $collection, $keys, $expiry ) :bool
This operator checks if there is a collection cache matching the criteria.
If so, it retrieves the variables (sets them directly in the template) and 
returns true, otherwise it returns false.

- selfvarcache_setcollection( $collection, $keys, $expiry, $variables ) :void
This operator sets the variables and creates a cache for the collection.

$collection [string] - identifier of the variable collection.
$keys [array] - an array of parameters for unique cache files.
$expiry [integer] - number of seconds.
$variables [array] - an associative array (hash) of variables, where the key
will be used to name the variable and the value will become its value.

- selfvarcache_fetchcollection( $value, $maxlevel ) :mixed
This operator inspects arrays/objects and returns it. This kind of solves 
the problem of variables not being passed from compound objects.
$value [array/object] - object or array to grab
$maxlevel [integer] - levels to inspect


Template example
----------------

{def $keys=array( $module_result.node_id ) $expiry=3600 $collection='main_vars'}
{if not( selfvarcache_getcollection( $collection, $keys, $expiry ) )}
    {selfvarcache_setcollection( $collection, $keys, $expiry, hash( 
        'current_node_id', $module_result.node_id,
        'current_time', currentdate(),
        'current_node', fetch( 'content', 'node', hash( 'node_id', $module_result.node_id ) ),
    ) )}
{/if}

Suggested model:

{if not( selfvarcache_getcollection( $collection, $keys, $expiry ) )}
    {* Here you put all your expensive calculations and operations *}
    {* that will be cached as variables in the next step *}
    {selfvarcache_setcollection( $collection, $keys, $expiry, hash( 
        'variable_name_1', 'variable_value_1',
        'variable_name_2', 'variable_value_2',
    ) )}
{/if}

Additional ispection operator selfvarcache_fetchcollection for compond vars:

{def $keys=array( $module_result.node_id ) $expiry=3600 $collection='main_vars'}
{if not( selfvarcache_getcollection( $collection, $keys, $expiry ) )}
    {selfvarcache_setcollection( $collection, $keys, $expiry, hash( 
        'current_node_id', $module_result.node_id,
        'current_time', currentdate(),
        'current_node', selfvarcache_fetchcollection( 
            fetch( 'content', 'node', hash( 'node_id', $module_result.node_id ) ), 2 
        ),
    ) )}
{/if}



Requirements
------------
- eZ Publish 4.0.0+
- eZ Publish Components: Base, File



Tested with
-----------
4.0.0



Installation
------------

1. Copy the extension to the /extension folder, so that 
you have /extension/selfvarcache/* structure.

2. Enable the extension (either via administration panel or directly with 
settings files):
[ExtensionSettings]
ActiveExtensions[]=selfvarcache



Changelog
---------

# v0.2 beta, public, 2008.04.22
+ New ispection operator to grab array/object values. 

# v0.1 alpha, public, 2008.04.11
+ Fully working version. 

# v0.0 alpha, local, 2008.04.11
+ Start.


/+/ complete
/-/ plan or in progress
