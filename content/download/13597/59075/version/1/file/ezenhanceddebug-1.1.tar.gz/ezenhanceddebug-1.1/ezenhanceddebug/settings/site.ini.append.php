<?php /* charset=utf-8

[SiteAccessSettings]
AnonymousAccessList[]=ezenhanceddebug/pieceofcode

[RoleSettings]
PolicyOmitList[]=ezenhanceddebug/pieceofcode
*/
?>
