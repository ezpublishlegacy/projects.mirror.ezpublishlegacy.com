<?php
class eZEnhancedDebugInfo
{
    function info()
    {
        return array( 'name' => "eZ Enhanced Debug",
                      'version' => "1.1",
                      'copyright' => "Copyright (C) Jérôme Renard &lt;jr@ez.no&gt;",
                      'license' => "GNU General Public License v2.0"
                    );
    }
}
?>
