<?php /* charset=utf-8
[ExtensionSettings]
DesignExtensions[]=ezenhanceddebug
*/
?>
