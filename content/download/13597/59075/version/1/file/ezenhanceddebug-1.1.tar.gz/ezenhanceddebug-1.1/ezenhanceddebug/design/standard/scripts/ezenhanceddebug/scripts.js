// table sorter
$(document).ready(function() { 
    $("table").tablesorter({ 
        // sort on the first column and third column, order asc 
        sortList: [[5,1]] 
    }); 
});
