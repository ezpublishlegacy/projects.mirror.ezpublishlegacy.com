<?php /* charset=utf-8
[ModuleSettings]
ExtensionRepositories[]=ezenhanceddebug
ModuleList[]=ezenhanceddebug
*/
?>
