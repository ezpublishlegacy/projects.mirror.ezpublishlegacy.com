<?php

include_once('lib/ezutils/classes/ezdebug.php');
include_once('lib/ezutils/classes/ezhttptool.php');
include_once('lib/ezdb/classes/ezdb.php');

function sectionEditPostFetch( &$module, &$class, &$object, &$version, &$contentObjectAttributes, $editVersion, $editLanguage, $fromLanguage, &$validation )
{
  if ($module->isCurrentAction('SectionEdit'))
  {
    $http =& eZHTTPTool::instance();

    $db =& eZDB::instance();
    $db->begin();

    $treeNode =& eZContentObjectTreeNode::fetchByContentObjectID($object->attribute('id'));
    $assignedNodes =& $object->attribute('assigned_nodes');
    foreach ($assignedNodes as $node)
    {
      eZContentObjectTreeNode::assignSectionToSubTree(
        $node->attribute('node_id'), $http->postVariable('SelectedSectionId'));
    }
    $object->expireAllViewCache();
    $db->commit();

//** This is a workaround that ensures that the drop-down (where the user
//** selected the new section) is updated and the new section is pre-selected
    $module->redirectTo('http://' . eZSys::hostname() .
                        $_SERVER['REQUEST_URI']);
  }

}

function sectionEditPreCommit( &$module, &$class, &$object, &$version, &$contentObjectAttributes, $editVersion, $editLanguage )
{
}

function sectionEditActionCheck( &$module, &$class, &$object, &$version, &$contentObjectAttributes, $editVersion, $editLanguage, $fromLanguage )
{
}

function sectionEditPreTemplate( &$module, &$class, &$object, &$version, &$contentObjectAttributes, $editVersion, $editLanguage, &$tpl )
{
}

function initializeSectionEdit( &$module )
{
    $module->addHook( 'post_fetch', 'sectionEditPostFetch' );
    $module->addHook( 'pre_commit', 'sectionEditPreCommit' );
    $module->addHook( 'action_check', 'sectionEditActionCheck' );
    $module->addHook( 'pre_template', 'sectionEditPreTemplate' );
}

?>
