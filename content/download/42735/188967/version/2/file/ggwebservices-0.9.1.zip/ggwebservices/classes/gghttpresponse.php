<?php
/**
 * Class used to wrap http responses.
 *
 * @author G. Giunta
 * @version $Id: gghttpresponse.php 324 2011-03-31 10:33:39Z gg $
 * @copyright (C) G. Giunta 2009-2011
 */

class ggHTTPResponse extends ggWebservicesResponse
{

    /**
      Returns the payload for the response.
    */
    function payload()
    {
        return $this->Value;
    }

    /**
    * Decodes the HTTP response stream.
    */
    function decodeStream( $request, $stream, $headers=false, $cookies=array() )
    {
	    $this->Value = $stream;
    }
}

?>