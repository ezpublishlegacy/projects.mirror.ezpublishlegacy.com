<?php
/*

[ExtensionSettings]
DesignExtensions[]=ezcategoryselection

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
BackendJavaScriptList[]=ezcategoryselection.js
FrontendJavaScriptList[]=ezcategoryselection.js

*/
?>
