<?php
/*

[ModuleSettings]
ExtensionRepositories[]=ezcategoryselection
ModuleList[]=ezcategoryselection

*/
?>
