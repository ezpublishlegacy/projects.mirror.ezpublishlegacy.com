<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=ezcategoryselection
AvailableDataTypes[]=ezcategoryselection


*/
?>
