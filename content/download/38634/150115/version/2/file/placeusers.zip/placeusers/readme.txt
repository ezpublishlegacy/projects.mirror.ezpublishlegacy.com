How to: 

Unzip the content into your extension folder, i.e. The path should be: �extension/placeusers/�. Log in as admin an go to setup, select �Extensions� and tag placeusers and click �Apply changes�.

1: First create the user groups the users should automatically be moved to, remember their node id's and their names.  

2: Now create your user class (new class or edit your existing user class. Your user class must have an attribute of type �selection� as that is the one which decides to which user group the user is moved to. Typically you will now name the various options for the selection the same as the names for your user groups from 1. Important that you now remember their order and their node ids (of the user groups). Remember to update your site.ini (in your override or siteaccess)  user settings so that eZ uses your new default user. 

3: Now modify the �extension/placeusers/placeusers.ini.php� file. 

UserAttributeSelectionIdentifier should be the identifier of the  user class selection(the one from 2). 

MoveToUserGroupId[] should be the user groups node id (from 1) in the SAME order as they are typed into user selection option. 
MoveToUserGroupId[] 

Typical example: 
Employee having selection with identifier �type� with options  {journalist, driver, cheif} in that order

Creating user groups {drivers , journalists, cheifs} with node id's {23,24,25}

Insert into: �extension/placeusers/placeusers.ini.php�
UserAttributeSelectionIdentifier=type
MoveToUserGroupId[] =24
MoveToUserGroupId[] =23
MoveToUserGroupId[] =25

NOTE THE order since it is based on the ORDER of the options within the user selection!

Now add the workflow to an trigger, i.e: 

Log in as admin, go to setup, click workflow, create new workflow group, named it something, for instance �User regiser�. Now select �New workflow�, name it and select �Event/placeusers� and �Add event� and then �Ok�.Go to trigger and set content, publish, after to the name on the work flow just created. Click apply changes. 

Now everything should for, for debugging check out the code and see the /var/log/notice.log file.