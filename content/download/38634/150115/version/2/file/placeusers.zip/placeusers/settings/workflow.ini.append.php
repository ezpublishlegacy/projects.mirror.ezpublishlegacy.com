[EventSettings]
ExtensionDirectories[]=placeusers
AvailableEventTypes[]=event_placeusers