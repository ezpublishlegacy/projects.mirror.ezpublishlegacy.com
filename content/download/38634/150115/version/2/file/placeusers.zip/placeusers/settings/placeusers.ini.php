#?ini charset="iso-8859-1"?

[PlaceUser]
# MoveToUserGroup is the user group you want to place the user in, depending upon the 
# value in ezSelection, the order they are listed here MUST correspond to the order of options in
# the Selection values list in the user attribute. 
MoveToUserGroupId[]=59
MoveToUserGroupId[]=60
# The eZ selection attribute of the user which holds the various user groups to user
# can select among
UserAttributeSelectionIdentifier=type
# Example: The above setting means that the user class has an selection attribute with identifier type with
# two options, if the use selects the first option he is moved to usergroup with node id 59, 
# the second option will lead him to usergroup with node id 60