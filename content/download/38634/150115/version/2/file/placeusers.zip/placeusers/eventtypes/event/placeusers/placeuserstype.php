<?php
//
// Processing of placing an user depending upon an selection attribute
//
// Created on: <03 Februar 2006> Tore Skobba
//
// Copyright (C) 1999-2006 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//
/* * * * * * * * * * * * * * * * * * * * * * * * * * *
Author:			Tore Skobba
				
Created on:		3 February 2006
Last change on:	20 February 2006 
Version:		1.0
Description:	Move user to an specific usergroup according to an eZ Selection attribute. 
				1: Fetch relevant data(object being edited, id of default user class etc)
				2: Check if edited object is an default user
				3: If yes then fetch mapping from placeusers.ini
				4: Move the user to the appropriate usergroup depending upon the value in the user Selection
				attribute
 				NB: ALL EZDEBUG::WRITENOTICE ARE WRITTEN TO NOTICE LOG FILE AND NOT THE SCREEN!!! 
 				An great Thank you goes to all persons who contributed with their code so that I could 
 				learn workflow myself. 
* * * * * * * * * * * * * * * * * * * * * * * * * * */

define( "EZ_WORKFLOW_TYPE_PLACEUSERS_ID", "placeusers" );
include_once('kernel/classes/ezworkflowtype.php');
include_once('lib/ezutils/classes/ezoperationhandler.php');

class placeUsersType extends eZWorkflowEventType
{
    function placeUsersType() 
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_PLACEUSERS_ID, "Placeusers" );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( 'after' ) ) ) );
        // eZDebug::writeNotice("Start placeusers","Constructor");
    }

    function execute( &$process, &$event ) 
    {
		// eZDebug::writeNotice("Start execute","Workflow placeusers");
		$user_class_id=0;
		$new_user_group_id=0;
		$user_groups=array();
		$selection_name=null;
		// Reading the default user class id as I need to check that I only do checks on 
		// eventual user publishing, that is registering or modifying user data and not other objects
		$Ini =& eZINI::instance( 'site.ini' );
		if ( $Ini->hasVariable( 'UserSettings', 'UserClassID' ) )
		{
    		$user_class_id = $Ini->variable( 'UserSettings', 'UserClassID'  );
		}
		if ( $Ini->hasVariable( 'UserSettings', 'DefaultUserPlacement' ) )
		{
    		// Help variable which is adjusted in if else branch for class of. This variable decides
        	// to which user group the user is in the end automatically moved. It is the default placment
        	// at init.
    		$new_user_group_id = $Ini->variable( 'UserSettings', 'DefaultUserPlacement'  );
		}
		// eZDebug::writeNotice("User class id is:".$user_class_id.' Default user group is: '.$new_user_group_id,"Workflow placeusers");
        
		
		// get object and objektId
    	$parameters = $process->attribute( 'parameter_list' );
    	$objectId= $parameters['object_id'];
		// This is the actual object begin edited or created
		$object =& eZContentObject::fetch( $parameters['object_id'] );
		// eZDebug::writeNotice("Object:".$object,"Workflow placeusers");	
		
		$data_map = $object->dataMap();
		// eZDebug::writeNotice("Object name:".$data_map['name'],"Workflow placeusers");	
		
		$content_class = $object->contentClass();
		// eZDebug::writeNotice("Content Class is".$content_class,"Workflow placeusers");	
		$content_class_id = $content_class->ID;
		// eZDebug::writeNotice("Default user class id is:".$user_class_id."This object class id is: ".$content_class_id,"Workflow placeusers");	
		
		if ($content_class_id==$user_class_id)
		{  
			// Read the init values for this workflow  
        	$Ini =& eZINI::instance( 'placeusers.ini.php' );
			if ( $Ini->hasVariable( 'PlaceUser', 'MoveToUserGroupId' ) )
			{
    			$user_groups = $Ini->variable( 'PlaceUser', 'MoveToUserGroupId'  );
			}
				if ( $Ini->hasVariable( 'PlaceUser', 'UserAttributeSelectionIdentifier' ) )
			{
    			$selection_identifier = $Ini->variable( 'PlaceUser', 'UserAttributeSelectionIdentifier'  );    		
			}
        	// eZDebug::writeNotice("Attribute name:".$selection_identifier." :User groups id's:".implode(',',$user_groups),"Workflow placeusers");
 			// eZDebug::writeNotice($selection_identifier." is: ".$data_map[$selection_identifier]->DataText." :User groups id's:".implode(',',$user_groups),"Workflow placeusers");
               
        	// Get the selection
        	$selection=$data_map[$selection_identifier]->DataText;
	
			// ezDebug::writeNotice($selection."is set to: ".$selection,"Workflow placeusers");
			
			if ($selection<0 || $selection>count($user_groups)) 
			{ // ERROR, out of bounds, use default user group, no need to set it as I did so
			  // when fetching init data
			}
			// Else set the new user group correctly
			else $new_user_group_id=$user_groups[$selection];
					
			// get latest Version number
    		$maxVersion =& $object->getVersionCount();
    		$allVersions = $object->versions();
    		$latestVersion = $allVersions[$maxVersion-1];
    		$maxVersion= $latestVersion->attribute('version');
    		$version =& $object->version( $maxVersion );
			$nodeAssignments = $version->nodeAssignments();
			
			// ezDebug::writeNotice("Starting node assignment with version: ".$maxVersion,"Workflow placeusers");
			
			// Only move the main node
			foreach ($nodeAssignments as $assignment) 
			{
				$parentObject = $assignment->getParentNode();
				// ezDebug::writeNotice("PArent node is: ".$parentObject->attribute("main_node_id"),"Workflow placeusers");
				// ezDebug::writeNotice("Is this node main: ".$assignment->attribute("is_main"),"Workflow placeusers");
		
				// If this is the main node AND it is different from the ones it should be then change it
				if ($assignment->attribute("is_main")=="1" AND $parentObject->attribute("main_node_id")<>$new_user_group_id)
				{
					// ezDebug::writeNotice("Moving ".$object->name()." from: ".$parentObject->attribute("main_node_id")."to: ".$new_user_group_id,"Workflow placeusers");
					// This is the main node assignment, and subject to change
					// Remove this node assignment
					$version->removeAssignment($parentObject->attribute("main_node_id"));	
					// Assign the new node id, new_user_group_id is set in the if else branch 
					// second parameter (1) says that this is going to be the main node, last parameter is 
					// from node (i.e. the old parent node)
					$version->assignToNode($new_user_group_id,1,$parentObject->attribute("main_node_id"));
					$version->store();
					// Publish the object in order to set everything on the site
					// ezDebug::writeNotice("Publishing Object id".$objectId,"Workflow placeusers");	
		    		$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $objectId,
		                                                                                 'version' => $maxVersion ) );
				} // ends if node is to be changed
			} // ends foreach
		}
		else
		{
			// ezDebug::writeNotice($object->name()."Is not an student class","Workflow placeusers");	
		}
		return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }		
}	

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_PLACEUSERS_ID, "placeuserstype" );

?>