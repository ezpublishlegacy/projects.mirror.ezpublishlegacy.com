<?php /*

[yql]
providerType=REST
providerUri=http://query.yahooapis.com/v1/public/yql
Options[]
Options[nameVariable]=q

*/ ?>