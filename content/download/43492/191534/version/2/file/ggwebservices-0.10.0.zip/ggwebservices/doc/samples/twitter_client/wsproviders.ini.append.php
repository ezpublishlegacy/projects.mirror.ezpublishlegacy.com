<?php /*

[twitter]
providerType=REST
providerUri=http://api.twitter.com/1/
Options[]

*/ ?>