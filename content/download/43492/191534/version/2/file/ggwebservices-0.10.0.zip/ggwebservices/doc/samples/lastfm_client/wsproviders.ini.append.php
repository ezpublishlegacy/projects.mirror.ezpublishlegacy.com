<?php /*

[lastfm]
providerType=REST
providerUri=http://ws.audioscrobbler.com/2.0/
Options[]
Options[nameVariable]=method

*/ ?>