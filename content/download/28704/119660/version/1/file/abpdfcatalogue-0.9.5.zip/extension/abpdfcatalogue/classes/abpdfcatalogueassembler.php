<?php

/**

    PDF catalogue extension for eZ Publish - Class abPDFCatalogueAssembler

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

class abPDFCatalogueAssembler extends abPDFAssembler
{

    const DEFAULT_PDF_SUBJECT   = 'Custom PDF Catalogue',
          DEFAULT_PDF_TITLE     = 'PDF Catalogue',
          DEFAULT_PDF_AUTHOR    = 'Alexander Block',
          DEFAULT_PDF_CREATOR   = 'Alexander Block PDF Catalogue',
          DEFAULT_PDF_KEYWORDS  = 'Alexander Block, http://www.alexander-block.net/',
          DEFAULT_TOC_TITLE     = 'Content',
          DEFAULT_CELL_WIDTH    = 0,
          DEFAULT_CELL_HEIGHT   = 10,
          FONT                  = 'Arial',
          PDFCOMPRESSION        = true,
          TOC_TITLE_FONT_SIZE   = 24,
          TOC_ENTRY_FONT_SIZE   = 10,
          PAGE_NUMBER_FONT_SIZE = 8,
          PAGE_NUMBER_Y_OFFSET  = -10.5;

    public function __construct( $orientation = 'P', $format = 'A4' )
    {
        parent::__construct( $orientation, $format );
    }

    protected function putPDFMetaData()
    {
        if ( array_key_exists( 'pdf_subject', $this->metaData ) && $this->metaData['pdf_subject'] !== false )
        {
            $this->SetSubject( $this->metaData['pdf_subject'] );
        }
        else
        {
            $this->SetSubject( self::DEFAULT_PDF_SUBJECT );
        }
        if ( array_key_exists( 'pdf_title', $this->metaData ) && $this->metaData['pdf_title'] !== false )
        {
            $this->SetTitle( $this->metaData['pdf_title'] );
        }
        else
        {
            $this->SetTitle( self::DEFAULT_PDF_TITLE );
        }
        if ( array_key_exists( 'pdf_author', $this->metaData ) && $this->metaData['pdf_author'] !== false )
        {
            $this->SetAuthor( $this->metaData['pdf_author'] );
        }
        else
        {
            $this->SetAuthor( self::DEFAULT_PDF_AUTHOR );
        }
        if ( array_key_exists( 'pdf_keywords', $this->metaData ) && $this->metaData['pdf_keywords'] !== false )
        {
            $this->SetKeywords( $this->metaData['pdf_keywords'] );
        }
        else
        {
            $this->SetKeywords( self::DEFAULT_PDF_KEYWORDS );
        }
        $this->SetCreator( self::DEFAULT_PDF_CREATOR );
    }

    protected function putCurrentPageNumber( $page, $pagecount )
    {
        $this->SetY( self::PAGE_NUMBER_Y_OFFSET );
        $this->SetFont( self::FONT, 'B', self::PAGE_NUMBER_FONT_SIZE );
        $this->SetTextColor( 120, 120, 120 );

        $string = ezi18n( 'pdfcatalogue', 'Page %1 of %2', null, array( $page, $pagecount ) );

        $this->Cell( self::DEFAULT_CELL_WIDTH, self::DEFAULT_CELL_HEIGHT, $string, 0, 0, 'C' );
    }

    protected function putTableOfContentsEntry( $index, $title, $pagenumber )
    {
        $leadingZero = '';
        if ( $pagenumber < 10 )
        {
            $leadingZero = '00';
        }
        else if ( $pagenumber < 100 )
        {
            $leadingZero = '0';
        }
        $prefix = ezi18n( 'pdfcatalogue', 'Page %1', null, array( $leadingZero . $pagenumber ) );

        $this->SetFont( self::FONT, '', self::TOC_ENTRY_FONT_SIZE );
        $this->Cell( self::DEFAULT_CELL_WIDTH, self::DEFAULT_CELL_HEIGHT, $prefix . ': ' . $title, 0, 1 );
    }

    protected function putTableOfContentsTitle()
    {
        $this->SetFont( self::FONT, '', self::TOC_TITLE_FONT_SIZE );
        if ( array_key_exists( 'toc_title', $this->metaData ) && $this->metaData['toc_title'] !== false )
        {
            $this->Cell( self::DEFAULT_CELL_WIDTH, self::DEFAULT_CELL_HEIGHT, $this->metaData['toc_title'], 0, 1 );
            return $this->metaData['toc_title'];
        }
        else
        {
            $this->Cell( self::DEFAULT_CELL_WIDTH, self::DEFAULT_CELL_HEIGHT, self::DEFAULT_TOC_TITLE, 0, 1 );
            return self::DEFAULT_TOC_TITLE;
        }
    }

}

?>