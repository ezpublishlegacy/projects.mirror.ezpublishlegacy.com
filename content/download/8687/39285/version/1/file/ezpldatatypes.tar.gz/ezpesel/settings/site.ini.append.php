<?php /*

[RegionalSettings]
TranslationExtensions[]=ezpesel

*/ ?>