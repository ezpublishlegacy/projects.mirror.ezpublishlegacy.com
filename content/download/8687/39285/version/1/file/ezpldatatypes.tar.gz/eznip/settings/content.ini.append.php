<?php /*

[DataTypeSettings]
ExtensionDirectories[]=eznip
AvailableDataTypes[]=eznip

*/ ?>