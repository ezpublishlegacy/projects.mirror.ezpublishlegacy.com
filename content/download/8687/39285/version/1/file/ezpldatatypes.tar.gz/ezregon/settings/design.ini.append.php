<?php /*

[ExtensionSettings]
DesignExtensions[]=ezregon

*/ ?>
