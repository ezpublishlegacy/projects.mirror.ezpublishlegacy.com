<?php

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );
include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinputparser.php' );
include_once( 'kernel/classes/datatypes/ezxmltext/ezxmltexttype.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'lib/ezfile/classes/ezfile.php' );
include_once( 'lib/ezfile/classes/ezdir.php' );
include_once( 'lib/ezutils/classes/ezsys.php' );

function getParamsFromString( $str )
{
    $params = array();

    foreach ( explode( ',', $str ) as $strItem )
    {
        $param = split( ':', $strItem );
        $params[$param[0]] = $param[1];
    }

    return $params;
}

$headers = apache_request_headers();

if ( isset( $headers['X-WSSE'] ) )
{
    preg_match( '/username=[\\\\"|"]*(?P<username>.*?)[\\\\"|"]*,\s*PasswordDigest=[\\\\"|"]*(?P<digest>.*?)[\\\\"|"]*,\s*Nonce=[\\\\"|"]*(?P<nonce>.*?)[\\\\"|"]*,\s*Created=[\\\\"|"]*(?P<created>.*?)[\\\\"|"]/i', $headers['X-WSSE'], $digest );

	$ini =& eZINI::instance();
	$i18nINI =& eZINI::instance( 'i18n.ini' );
	$passwords = $ini->variable( 'UserSettings', 'Passwords' );

	$matchDigest = base64_encode( pack( "H*", sha1( base64_decode( $digest['nonce'] ) . $digest['created'] . $passwords[$digest['username']] ) ) );

	if ( $digest['digest'] === $matchDigest )
	{
	    header( 'Content-Type: application/atom+xml; charset=' . $i18nINI->variable( 'CharacterSettings', 'Charset' ) );

		$tpl =& templateInit();

		if ( $_SERVER['REQUEST_METHOD'] == 'POST' )
		{
		    $xmlData = $GLOBALS['HTTP_RAW_POST_DATA'];
            $xmlObject = new eZXML();
            $domDocument =& $xmlObject->domTree( $xmlData );
            $root =& $domDocument->root();

            $title = $root->elementByName( 'title' );
            $content = $root->elementByName( 'content' );
            $standalone = $root->elementByName( 'standalone' );
            $summary = $root->elementByName( 'summary' );
            $type = $root->elementByName( 'type' );
            $format = $root->elementByName( 'format' );
            $links = $root->elementsByName( 'link' );

            $contentINI =& eZINI::instance( 'content.ini' );
            $blogNodeID = $contentINI->variable( 'BlogSettings', 'BlogNodeID' );
            $blogPostContentClassIdentifier = $contentINI->variable( 'BlogPostSettings', 'ContentClassIdentifier' );

            $cacheDir = eZSys::cacheDirectory() . '/lifeblog';

            $creator = eZUser::fetchByName( $digest['username'] );
            $creatorID = $creator->attribute( 'contentobject_id' );

            $blogNode = eZContentObjectTreeNode::fetch( $blogNodeID );
            $blogNodeObject =& $blogNode->object();
            $sectionID = $blogNodeObject->attribute( 'section_id' );

            if ( $standalone )
            {
                // SMS / Note / MMS
                if ( $type && $format )
                {
                    switch ( $format->textContent() )
                    {
                    	case 'SMS':
                    	case 'Note':
                    	    $originalFileName = $title->textContent();
                            $fileName = md5( $title->textContent() . microtime() . mt_rand() ) . '.txt';
                            $filePath = $cacheDir . '/' . $fileName;

                            $file = new eZFile();
                            $res = $file->create( $fileName, $cacheDir, $content->textContent() . '' . $summary->textContent() );

                            header( 'Status: 201 Created' );
                            $tpl->setVariable( 'name', $title->textContent() );
                            $tpl->setVariable( 'is_standalone', true );
                            $tpl->setVariable( 'id', 'reference:' . $fileName );
                            $tpl->setVariable( 'issued', date('Y-m-d\Th:i:s\Z') );
                            echo $tpl->fetch( 'design:lifeblog/response.tpl' );
                    		break;
                    }
                }
                else
                {
                    if ( $content->attributeValue( 'mode' ) == 'base64'
                            && $content->attributeValue( 'type' ) == 'image/jpeg' )
                    {
                        $originalFileName = $title->textContent();
                        $fileName = md5( $title->textContent() . microtime() . mt_rand() ) . '.jpg';
                        $filePath = $cacheDir . '/' . $fileName;

                        $file = new eZFile();
                        $res = $file->create( $fileName, $cacheDir, base64_decode( $content->textContent() ) );

                        if ( $res )
                        {
                            $contentClass = eZContentClass::fetchByIdentifier( 'image' );

                            $contentObject = $contentClass->instantiate( $creatorID, $sectionID );
                            $contentObjectID = $contentObject->attribute( 'id' );
                            $contentObject->store();

                            $version =& $contentObject->version( 1 );
                            $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
                            $version->store();

                            $contentObjectID = $contentObject->attribute( 'id' );
                            $dataMap =& $contentObject->dataMap();

                            $dataMap['name']->setAttribute( 'data_text', $originalFileName );
                            $dataMap['name']->store();

                            $imageContent =& $dataMap['image']->attribute( 'content' );
                            $imageContent->initializeFromFile( $filePath, false, $originalFileName );
                            $dataMap['image']->store();

                            $parser = new eZSimplifiedXMLInputParser( $contentObjectID );
                            $parser->setParseLineBreaks( true );

                            $document = $parser->process( $summary->textContent() );
                            $xmlString = eZXMLTextType::domString( $document );

                            $dataMap['caption']->setAttribute( 'data_text', $xmlString );
                            $dataMap['caption']->store();

                            header( 'Status: 201 Created' );
                            $tpl->setVariable( 'name', $contentObject->attribute( 'name' ) );
                            $tpl->setVariable( 'is_standalone', true );
                            $tpl->setVariable( 'id', 'object_id:' . $contentObject->attribute( 'id' ) );
                            $tpl->setVariable( 'issued', date('Y-m-d\Th:i:s\Z') );
                            echo $tpl->fetch( 'design:lifeblog/response.tpl' );
                        }
                    }
                }
            }
            else
            {
                $titleContent = $title->textContent();

                if ( !$titleContent )
                    $titleContent = 'Lifeblog post';

                $contentClass = eZContentClass::fetchByIdentifier( $blogPostContentClassIdentifier );
                $contentObject =& $contentClass->instantiate( $creatorID, $sectionID );
                $contentObjectID = $contentObject->attribute( 'id' );
                $contentObject->store();

                $nodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObjectID,
                                                                   'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                                   'is_main' => 1,
                                                                   'parent_node' => $blogNode->attribute( 'node_id' ) ) );
                $nodeAssignment->store();

                $version =& $contentObject->version( 1 );
                $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
                $version->store();

                $dataMap =& $contentObject->dataMap();

                $attributeTitle =& $dataMap[$contentINI->variable( 'BlogPostSettings', 'TitleAttributeIdentifier' )];

                if ( $attributeTitle != null && $title != null )
                {
                    $attributeTitle->setAttribute( 'data_text', $titleContent );
                    $attributeTitle->store();
                }

                $attributeContent =& $dataMap[$contentINI->variable( 'BlogPostSettings', 'ContentAttributeIdentifier' )];

                if ( $attributeContent != null && $attributeContent != null )
                {
                    if ( $attributeContent->attribute( 'data_type_string' ) == 'ezxmltext' )
                    {
                        $parser = new eZSimplifiedXMLInputParser( $contentObjectID );
                        $parser->setParseLineBreaks( true );

                        $document = $parser->process( $content->textContent() );

                        $contentRoot =& $document->root();

                        if ( count( $links ) > 0 )
                        {
                            foreach ( $links as $link )
                            {
                                $params = getParamsFromString( $link->attributeValue( 'href' ) );

                                if ( isset( $params['object_id'] ) )
                                {

                                    $paragraph = $document->createElementNode( 'paragraph' );

                                    if ( $contentRoot->firstChild() )
                                        $contentRoot->insertBefore( $paragraph, $contentRoot->firstChild() );
                                    else
                                        $contentRoot->appendChild( $paragraph );

                                    $line = $document->createElementNode( 'line' );
                                    $paragraph->appendChild( $line );

                                    $embed = $document->createElementNode( 'embed' );
                                    $embed->setAttribute( 'object_id', $params['object_id'] );
                                    // TODO: add INI settings so user can control default value, also for size.
                                    $embed->setAttribute( 'align', 'left' );
                                    $line->appendChild( $embed );

                                    unset( $paragraph );
                                    unset( $line );
                                    unset( $embed );
                                }

                                if ( isset( $params['reference'] ) )
                                {
                                    $paragraph = $document->createElementNode( 'paragraph' );

                                    if ( $contentRoot->firstChild() )
                                        $contentRoot->insertBefore( $paragraph, $contentRoot->firstChild() );
                                    else
                                        $contentRoot->appendChild( $paragraph );

                                    $fileContent = eZFile::getContents( $cacheDir . '/' . $params['reference'] );

                                    $line = $document->createElementNode( 'line' );
                                    $lineContent = $document->createTextNode( $fileContent );
                                    $line->appendChild( $lineContent );
                                    $paragraph->appendChild( $line );

                                    unset( $paragraph );
                                    unset( $line );
                                    unset( $lineContent );
                                }
                            }
                        }

                        $xmlString = eZXMLTextType::domString( $document );
                        $attributeContent->setAttribute( 'data_text', $xmlString );
                    }
                    else
                    {
                        $attributeContent->setAttribute( 'data_text', $content->textContent() );
                    }
                    $attributeContent->store();
                }

                $contentObject->store();

                $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                             'version' => 1 ) );

                if ( isset( $operationResult['status'] ) && $operationResult['status'] == 1 )
                {
                    $contentTreeNode = $contentObject->attribute( 'main_node' );

                    if ( count( $links ) > 0 )
                    {
                        foreach ( $links as $link )
                        {
                            $params = getParamsFromString( $link->attributeValue( 'href' ) );

                            if ( isset( $params['object_id'] ) )
                            {
                                $nodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $params['object_id'],
                                                                                   'contentobject_version' => 1,
                                                                                   'is_main' => 1,
                                                                                   'parent_node' =>  $contentTreeNode->attribute( 'node_id' ) ) );
                                $nodeAssignment->store();

                                $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $params['object_id'],
                                                                                                             'version' => 1 ) );
                            }
                        }
                    }

                    eZDir::recursiveDelete( $cacheDir );

                    header( 'Status: 201 Created' );
                    $tpl->setVariable( 'name', $titleContent );
                    $tpl->setVariable( 'is_standalone', false );
                    $tpl->setVariable( 'id', 'object_id:' . $contentObject->attribute( 'id' ) );
                    $tpl->setVariable( 'url_alias', $contentTreeNode->attribute( 'url_alias' ) );
                    $tpl->setVariable( 'issued', date('Y-m-d\Th:i:s\Z') );
                    echo $tpl->fetch( 'design:lifeblog/response.tpl' );
                }

            }
		}

		if ( $_SERVER['REQUEST_METHOD'] == 'GET' )
		{
		    echo $tpl->fetch( 'design:lifeblog/atom.tpl' );
		}
	}
}
else
{
    header( 'Status: 401 Unauthorized' );
	header( 'WWW-Authenticate: WSSE realm="foo", profile="UsernameToken"' );
}

eZExecution::cleanExit();

?>