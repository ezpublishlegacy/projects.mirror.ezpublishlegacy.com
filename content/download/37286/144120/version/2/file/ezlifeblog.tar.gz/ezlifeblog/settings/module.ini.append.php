<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezlifeblog

*/ ?>