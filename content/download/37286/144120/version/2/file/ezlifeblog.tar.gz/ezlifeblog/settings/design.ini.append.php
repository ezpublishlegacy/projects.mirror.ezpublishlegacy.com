<?php /*

[ExtensionSettings]
DesignExtensions[]=ezlifeblog

*/ ?>
