<?php /*

# Place where blog posts will be store
[BlogSettings]
BlogNodeID=131

# Settings for blog post content class
[BlogPostSettings]
ContentClassIdentifier=blog_post
TitleAttributeIdentifier=title
ContentAttributeIdentifier=body

*/ ?>