<?php

$Module = array( 'name' => 'eZ Lifeblog' );

$ViewList = array();
$ViewList['atom'] = array( 'script' => 'atom.php' );

?>