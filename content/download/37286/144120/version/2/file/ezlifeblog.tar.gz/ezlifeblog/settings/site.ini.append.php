<?php /*

[SiteAccessSettings]
AnonymousAccessList[]=lifeblog/atom

[RoleSettings]
PolicyOmitList[]=lifeblog/atom

# eZ Publish and Lifeblog uses different password hashes.
# Array key is a user login in eZ Publish and value is a password
[UserSettings]
Passwords[admin]=1234

*/ ?>