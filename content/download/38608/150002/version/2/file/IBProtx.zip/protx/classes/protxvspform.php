<?php
//
// Created on: <2-Mar-2009>
//
// SOFTWARE NAME: IB Protx Payment Gateway
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
class ProtxVSPForm {
    public function ProtxVSPForm( $order ) {        
        $this->settings = eZINI::instance( 'protx.ini' );        		        
	      
        $this->actionURL   = $this->getProtxBaseURL();
		$this->VPSProtocol = $this->settings->variable( 'PrtoxGatewaySettings', 'VPSProtocol' );
		$this->TxType      = $this->settings->variable( 'PrtoxGatewaySettings', 'TransactionType' );
		$this->Vendor      = $this->settings->variable( 'PrtoxGatewaySettings', 'VendorName' );
		$this->Crypt       = $this->base64Encode(
			$this->simpleXor(
				$this->getVSPFormCrypt( $order ),
				$this->settings->variable( 'PrtoxGatewaySettings', 'EncryptionPassword' )
			)
		);		
    }
    
    private function getProtxBaseURL() {
		switch ( $this->settings->variable( 'PrtoxGatewaySettings', 'ProtxConnectTo' ) ) {
			case 'LIVE' :
				return 'https://ukvps.protx.com/vspgateway/service/vspform-register.vsp';
			case 'TEST' :
				return 'https://ukvpstest.protx.com/vspgateway/service/vspform-register.vsp';
			default:
				return 'https://ukvpstest.protx.com/VSPSimulator/VSPFormGateway.asp';
		}  	
    }
    
    private function getVSPFormCrypt( $order ) {
        $indexDir  = eZSys::indexDir();
        $serverURL = eZSys::serverURL();
    	
    	$cryptStr = 'VendorTxCode=' . $order->ID;
    	$cryptStr .= '&Description=' . $this->settings->variable( 'PrtoxGatewaySettings', 'Description' );
		$cryptStr .= '&VendorEMail=' . $this->settings->variable( 'PrtoxGatewaySettings', 'VendorEMail' );		
		$cryptStr .= '&SuccessURL=' . $serverURL . $indexDir . '/protx/success_url';
		$cryptStr .= '&FailureURL=' . $serverURL . $indexDir . '/protx/failure_url';		
		$cryptStr .= '&Currency=' . $this->settings->variable( 'PrtoxGatewaySettings', 'Currency' );
		
		$basketStr    = '';		
  		$productList  = $order->attribute( 'product_items' );
		$productCount = count( $productList );
		$basket       = eZBasket::currentBasket();
		$shippingInfo = eZShippingManager::getShippingInfo( $basket->attribute( 'productcollection_id' ) );
		
		if( $shippingInfo ) {
			$cryptStr .= '&Amount=' . ( $order->productTotalIncVAT() + $shippingInfo['cost'] );	
		} else {
			$cryptStr .= '&Amount=' . $order->productTotalIncVAT();
		}
				    		
  		foreach( $productList as $product ) {
  			$basketStr .= 
				':' . $product['object_name'] . 
				':' . $product['item_count'] . 
				':' . number_format( $product['price_ex_vat'], 2 ) . 
				':' . number_format( $product['price_ex_vat'] * ( $product['vat_value'] / 100 ), 2 ) . 
				':' . number_format( $product['price_inc_vat'], 2 ) . 
				':' . number_format( $product['total_price_inc_vat'], 2 );
		} 	
		if( $shippingInfo ) {
			$shippingPrice =  number_format( $shippingInfo['cost'], 2 );
			$basketStr .= 
				':' . $shippingInfo['description'] . ':1:' .
				$shippingPrice . ':-:' . 
				$shippingPrice . ':' .
				$shippingPrice;
			$productCount++;
		}
		
		
		$basketStr =  $productCount . $basketStr;
		$cryptStr .= '&Basket=' . $basketStr;	
		
		return $cryptStr;				
    }
    
    public static function base64Encode( $plain ) {
		return base64_encode( $plain );
	}
	
	public static function base64Decode( $scrambled ) {
		return base64_decode( str_replace( ' ', '+', $scrambled ) );
	}
	
	public static function simpleXor( $inString, $key ) {	
		$KeyList = array();
		$output  = '';
  
  		// Convert $key into array of ASCII values
		for( $i = 0; $i < strlen( $key ); $i++ ){
			$keyList[$i] = ord( substr( $key, $i, 1 ) );
		}

  		// Step through string a character at a time
  		for( $i = 0; $i < strlen( $inString ); $i++ ) {
    		// Get ASCII code from string, get ASCII code from key (loop through with MOD), XOR the two, get the character from the result
    		// % is MOD (modulus), ^ is XOR
    		$output .= chr( ord( substr( $inString, $i, 1 ) ) ^ ( $keyList[ $i % strlen( $key ) ] ) );
  		}

		return $output;
	}
	
	public function getData() {
		return array(
			'action'      => $this->actionURL,
			'VPSProtocol' => $this->VPSProtocol,
			'TxType'      => $this->TxType,
			'Vendor'      => $this->Vendor,
			'Crypt'       => $this->Crypt
		);		
	}
	
	public static function getToken( $string ) {  	
		$tokens = array(
    		'Status',
			'StatusDetail',
			'VendorTxCode',
			'VPSTxId',
			'TxAuthNo',
			'Amount',
			'AVSCV2', 
			'AddressResult', 
			'PostCodeResult', 
			'CV2Result', 
			'GiftAid', 
			'3DSecureStatus', 
			'CAVV'
		);
  
		$output = array();
		$resultArray = array();
  

		for ( $i = count( $tokens ) - 1 ; $i >= 0 ; $i-- ) {    
    		$start = strpos( $string, $tokens[ $i ] );	
    		if ( $start !== false ){      
      			$resultArray[$i]->start = $start;
      			$resultArray[$i]->token = $tokens[$i];
    		}
  		}
  		sort($resultArray);
  			
		for ( $i = 0; $i < count( $resultArray ); $i++ ) {
    		$valueStart = $resultArray[$i]->start + strlen( $resultArray[$i]->token ) + 1;	
    		if ( $i == ( count( $resultArray ) - 1 ) ) {
      			$output[$resultArray[$i]->token] = substr( $string, $valueStart);
    		} else {
      			$valueLength = $resultArray[$i+1]->start - $resultArray[$i]->start - strlen( $resultArray[$i]->token ) - 2;
	  			$output[$resultArray[$i]->token] = substr( $string, $valueStart, $valueLength );
    		}
		}

		return $output;
	}	
}
?>