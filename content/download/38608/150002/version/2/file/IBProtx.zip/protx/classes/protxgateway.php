<?php
//
// Created on: <2-Mar-2009>
//
// SOFTWARE NAME: IB Protx Payment Gateway
// SOFTWARE RELEASE: 1.0
// COPYRIGHT NOTICE: Copyright (C) 2009 Internet Bureau
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
//
define( 'EZ_PAYMENT_GATEWAY_TYPE_PROTX', 'protx' );

class ProtxGateway extends eZRedirectGateway {
	
    public function ProtxGateway() {        
        $this->logger = eZPaymentLogger::CreateForAdd( 'var/log/eZProtx.log' );
        $this->logger->writeTimedString( 'ProtxGateway::ProtxGateway()' );        
    }

    public function createPaymentObject( $processID, $orderID ) {
		$this->logger->writeTimedString( 'createPaymentObject' );
        return eZPaymentObject::createNew( $processID, $orderID, 'ProtxGateway' );
    }

    public function createRedirectionUrl( $process ) {
        $this->logger->writeTimedString( 'createRedirectionUrl' );        
		
        $processParams  = $process->attribute( 'parameter_list' );
        $serverURL      = eZSys::serverURL();
        $indexDir       = eZSys::indexDir();          
        
		return $serverURL . $indexDir . '/protx/vspform_redirect/' . $processParams['order_id'];
    }    		
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_PROTX, 'protxgateway', 'Protx' );

?>
