<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Modifica &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Traduzione contenuto da %from_lang a %to_lang</translation>
    </message>
    <message>
        <source>Back to edit</source>
        <translation>Torna a modifica</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Pubblica</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Pubblica il contenuto della bozza aperta in modifica. La bozza attuale diverrà quindi la versione pubblicata dell&apos;oggetto.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Salva bozza</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Salva il contenuto della bozza aperta e continua con la modifica. Utile per salvare periodicamente il lavoro.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Annulla bozza</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Sicuro di voler annullare la bozza?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Annulla la bozza aperta. Verranno rimosse anche le eventuali traduzioni della bozza.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Show 10 items per page.</source>
        <translation>Mostra 10 elementi per pagina.</translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation>Mostra 10 elementi per pagina.</translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation>Mostra 25 elementi per pagina.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Modifica &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Non ti è consentito modificare &lt;%child_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Content structure</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>Manage the main content structure of the site.</source>
        <translation>Gestione della struttura dei contenuti del sito.</translation>
    </message>
    <message>
        <source>Media library</source>
        <translation>Media</translation>
    </message>
    <message>
        <source>Manage images, files, documents, etc.</source>
        <translation>Gestione immagini, file, documenti, etc.</translation>
    </message>
    <message>
        <source>User accounts</source>
        <translation>Utenti</translation>
    </message>
    <message>
        <source>Manage users, user groups and permission settings.</source>
        <translation>Gestione impostazioni utenti, gruppi di utenti e permessi.</translation>
    </message>
    <message>
        <source>Webshop</source>
        <translation>Negozio</translation>
    </message>
    <message>
        <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
        <translation>Gestione clienti, ordini, sconti e tipi di IVA; accesso alle statistiche di vendita.</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Design</translation>
    </message>
    <message>
        <source>Manage templates, menus, toolbars and other things related to appearence.</source>
        <translation>Gestione layout, menù, barre degli strumenti e altri elementi dell&apos;interfaccia.</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <source>Configure settings and manage advanced functionality.</source>
        <translation>Configurazione delle impostazioni e gestione di funzioni avanzate.</translation>
    </message>
    <message>
        <source>My account</source>
        <translation>Il mio account</translation>
    </message>
    <message>
        <source>Manage items and settings that belong to your account.</source>
        <translation>Gestione elementi e impostazioni riferite al tuo account.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/content/menu</name>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Cambia la larghezza del menù di sinistra in Piccola</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Piccola</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Media</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Cambia la larghezza del menù di sinistra in Grande.</translation>
    </message>
    <message>
        <source>Grande</source>
        <translation>Breit</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Cambia la larghezza del menù di sinistra in Media.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/browse_article_pool</name>
    <message>
        <source>Select a source for newsletter articles</source>
        <translation>Seleziona l&apos;origine per gli articoli della newsletter</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a source location for articles to be used in the newsletter, then click &quot;OK&quot;.</source>
        <translation>Usa i radio button per scegliere la posizione per gli articoli della newsletter, poi clicca su &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Naviga usando i tab disponibili (sopra), il menù ad albero (a sinistra) e la lista dei contenuti (in mezzo).</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/browse_single_user_select</name>
    <message>
        <source>Please select an eZ Publish user.</source>
        <translation>Seleziona un utente di eZ Publish.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_bounce</name>
    <message>
        <source>Confirm bounce entry removal</source>
        <translation>Conferma l&apos;eliminazione di una istanza di rimbalzo</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entry?</source>
        <translation>Sicuro di voler eliminare una istanza di rimbalzo?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the bounce entries?</source>
        <translation>Sicuro di voler eliminare le istanze di rimbalzo?</translation>
    </message>
    <message>
        <source>The following bounce entries will be removed:</source>
        <translation>Verranno rimosse le seguenti istanze di rimbalzo:</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Do not proceeed unless you are sure.</source>
        <translation>Non procedere se non sei sicuro di quello che stai facendo</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_newsletter</name>
    <message>
        <source>Confirm newsletter removal</source>
        <translation>Conferma cancellazione newsletter</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter?</source>
        <translation>Sicuro di voler cancellare la newsletter?</translation>
    </message>
    <message>
        <source>The following newsletters will be removed:</source>
        <translation>Verrano rimosse le seguenti newsletter:</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Do not proceed unless you are sure.</source>
        <translation>Non procedere se non sai cosa stai facendo.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_newslettertype</name>
    <message>
        <source>Confirm newsletter type removal</source>
        <translation>Conferma rimozione tipo di newsletter</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter type?</source>
        <translation>Sicuro di voler rimuovere questo tipo di newsletter?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the newsletter types?</source>
        <translation>Sicuro di voler rimuovere le Newsletter?</translation>
    </message>
    <message>
        <source>The following newsletter types will be removed:</source>
        <translation>Le seguenti Newsletter saranno rimosse:</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Do not proceed unless you are sure.</source>
        <translation>Non procedere se non sai cosa stai facendo.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/confirmremove_onhold</name>
    <message>
        <source>Confirm on hold entry removal</source>
        <translation>Conferma la rimozione della voce in sospeso</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the on hold entry?</source>
        <translation>Sicuro di voler rimuovere la voce in sospeso?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the on hold entries?</source>
        <translation>Sicuro di voler rimuovere le voci in sospeso?</translation>
    </message>
    <message>
        <source>The following entries on hold will be removed:</source>
        <translation>Le seguenti voci in sospeso saranno rimosse:</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Do not proceed unless you are sure.</source>
        <translation>Non procedere se non sai cosa stai facendo.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/contentstructuremenu</name>
    <message>
        <source>Archive</source>
        <translation>Archivio</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Bozze</translation>
    </message>
    <message>
        <source>Ideas</source>
        <translation>Inbox</translation>
    </message>
    <message>
        <source>In progress</source>
        <translation>In progress</translation>
    </message>
    <message>
        <source>Recurring</source>
        <translation>Ricorrenti</translation>
    </message>
    <message>
        <source>Fold/Unfold</source>
        <translation>Apri/Chiudi</translation>
    </message>
    <message>
        <source>Newsletter type list</source>
        <translation>Lista Newsletter</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_object</name>
    <message>
        <source>Edit newsletter</source>
        <translation>Modifica newsletter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Newsletter send date</source>
        <translation>Data invio newsletter</translation>
    </message>
    <message>
        <source>Newsletter category</source>
        <translation>Categoria newsletter</translation>
    </message>
    <message>
        <source>Pretext</source>
        <translation>Introduzione</translation>
    </message>
    <message>
        <source>Posttext</source>
        <translation>Testo in calce</translation>
    </message>
    <message>
        <source>Design to use</source>
        <translation>Design da utilizzare</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Formato di output</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <source>Send preview address</source>
        <translation>Indirizzo e-mail per invio anteprima</translation>
    </message>
    <message>
        <source>Send preview mobile number</source>
        <translation>Numero di telefono per invio anteprima</translation>
    </message>
    <message>
        <source>Send preview</source>
        <translation>Invia anteprima</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_onhold</name>
    <message>
        <source>Message on hold</source>
        <translation>Messaggio in sospeso</translation>
    </message>
    <message>
        <source>Send item data:</source>
        <translation>Invia dati elemento:</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Newsletter ID</source>
        <translation>ID newsletter</translation>
    </message>
    <message>
        <source>Newsletter name</source>
        <translation>Nome newsletter name</translation>
    </message>
    <message>
        <source>Sent to address</source>
        <translation>Invia a</translation>
    </message>
    <message>
        <source>Recipient name</source>
        <translation>Nome destinatario</translation>
    </message>
    <message>
        <source>Set new sendout status</source>
        <translation>Imposta nuovo status di invio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Imposta</translation>
    </message>
    <message>
        <source>Back to on hold list</source>
        <translation>Torna alla lista in sospeso</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newsletter_recurrence</name>
    <message>
        <source>Newsletter recurrence</source>
        <translation>Ricorrenza newsletter</translation>
    </message>
    <message>
        <source>Recurrence type</source>
        <translation>Tipo di ricorrenza</translation>
    </message>
    <message>
        <source>Daily</source>
        <translation>Quotidiana</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Giorni della settimana</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lunedì</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Martedì</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercoledì</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Giovedì</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Venerdì</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Sabato</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Domenica</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Settimanale</translation>
    </message>
    <message>
        <source>Day of week</source>
        <translation>Giorno della settimana</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Mensile</translation>
    </message>
    <message>
        <source>Day of month</source>
        <translation>Giorno del mese</translation>
    </message>
    <message>
        <source>Deactivated</source>
        <translation>Disattivata</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_newslettertype</name>
    <message>
        <source>Edit newsletter type</source>
        <translation>Modifica tipo newsletter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Use the description field to explaining the purpose of this newslettertype.</source>
        <translation>Usa il campo descrizione per specificare la finalità di questo tipo di newsletter.</translation>
    </message>
    <message>
        <source>Sender address</source>
        <translation>Indirizzo mittente</translation>
    </message>
    <message>
        <source>Send date modifier</source>
        <translation>Modificatore data di invio</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>Giorni</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>Ore</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>Minuti</translation>
    </message>
    <message>
        <source>Default pretext</source>
        <translation>Introduzione predefinita</translation>
    </message>
    <message>
        <source>Default posttext</source>
        <translation>Testo in calce predefinito</translation>
    </message>
    <message>
        <source>Personalize newsletter</source>
        <translation>Personalizza newsletter</translation>
    </message>
    <message>
        <source>Valid content classes</source>
        <translation>Classi di contenuto valide</translation>
    </message>
    <message>
        <source>Allowed designs</source>
        <translation>Design consentiti</translation>
    </message>
    <message>
        <source>Allowed output formats</source>
        <translation>Formati di output consentiti</translation>
    </message>
    <message>
        <source>Subscription lists</source>
        <translation>Liste abbonati</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Oggetti correlati</translation>
    </message>
    <message>
        <source>Add related object</source>
        <translation>Aggiungi oggetto correlato</translation>
    </message>
    <message>
        <source>Remove object location</source>
        <translation>Rimuovi collocazione dell&apos;oggetto</translation>
    </message>
    <message>
        <source>No object relation selected</source>
        <translation>Nessuna relazione tra oggetti selezionata</translation>
    </message>
    <message>
        <source>Newsletter suggestion inbox</source>
        <translation>Inbox per i suggerimenti</translation>
    </message>
    <message>
        <source>Change inbox placement</source>
        <translation>Cambia la collocazione della inbox</translation>
    </message>
    <message>
        <source>Delete inbox placement</source>
        <translation>Elimina la collocazione della inbox</translation>
    </message>
    <message>
        <source>No newsletter placement is specified</source>
        <translation>Nessuna collocazione specificata per la newsletter</translation>
    </message>
    <message>
        <source>Add inbox placement</source>
        <translation>Aggiungi collocazioni per la inbox</translation>
    </message>
    <message>
        <source>Newsletter placement</source>
        <translation>Collocazione newsletter</translation>
    </message>
    <message>
        <source>Change newsletter placement</source>
        <translation>Cambia collocazione newsletter</translation>
    </message>
    <message>
        <source>Delete newsletter placement</source>
        <translation>Elimina collocazione newsletter</translation>
    </message>
    <message>
        <source>Add newsletter placement</source>
        <translation>Aggiungi collocazione newsletter</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>Validazione dei dati inseriti: non riuscita.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_relation_newsletter</name>
    <message>
        <source>Related objects [%related_objects]</source>
        <translation>Oggetti correlati [%related_objects]</translation>
    </message>
    <message>
        <source>Related images [%related_images]</source>
        <translation>Immagini correlate [%related_images]</translation>
    </message>
    <message>
        <source>You do not have permissions to view this object</source>
        <translation>Non sei autorizzato ad accedere a questo oggetto</translation>
    </message>
    <message>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>Copia questo codice e incollalo in un campo XML.</translation>
    </message>
    <message>
        <source>Related files [%related_files]</source>
        <translation>File correlati [%related_files]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Tipo di file</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <source>XML code</source>
        <translation>Codice XML</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>Non hai credenziali sufficienti per accedere a questo oggetto</translation>
    </message>
    <message>
        <source>Related content [%related_objects]</source>
        <translation>Contentuto correlato [%related_objects]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>Non ci sono oggetti correlati a quello attualmente in modifica.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove the selected items from the list(s) above. Only the relations that will be removed. The items will not be deleted.</source>
        <translation>Rimuovi gli elementi selezionati dalla/e lista/e qui sopra. Verranno rimosse solo le relazioni, non gli oggetti.</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Aggiungi esistente</translation>
    </message>
    <message>
        <source>Add an existing item as a related object.</source>
        <translation>Aggiungi un elemento esistente come oggetto correlato.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Carica nuovo</translation>
    </message>
    <message>
        <source>Upload a file and add it as a related object.</source>
        <translation>Carica un file e aggiungilo come oggetto correlato.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_subscription</name>
    <message>
        <source>First name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>First name of the subscriber.</source>
        <translation>Nome dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Cognome</translation>
    </message>
    <message>
        <source>Last name of the subscriber.</source>
        <translation>Cognome dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation>E-Mail dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Mobile number</source>
        <translation>Numero di cellulare</translation>
    </message>
    <message>
        <source>Mobile number of the subscriber.</source>
        <translation>Numero di cellulare dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>eZ Publish user</source>
        <translation>utente eZ Publish</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleziona</translation>
    </message>
    <message>
        <source>Apply the changes and return to subscription list view.</source>
        <translation>Applica le modifiche e torna alla lista abbonati.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Vip</source>
        <translation>VIP</translation>
    </message>
    <message>
        <source>VIP status</source>
        <translation>VIP Status</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Formato di output</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Apply the changes and return subscription list view.</source>
        <translation>Applica le modifiche e torna alla lista abbonati.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>Annulla le modifiche e torna alla lista abbonati.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/edit_subscription_list</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Name of the subscription list.</source>
        <translation>Nome della lista abbonati.</translation>
    </message>
    <message>
        <source>Registration URL</source>
        <translation>URL per la registrazione</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>URL to subscription.</source>
        <translation>URL per l&apos;abbonamento.</translation>
    </message>
    <message>
        <source>Generate hash</source>
        <translation>Genera hash</translation>
    </message>
    <message>
        <source>Generate hash for URL.</source>
        <translation>Genera un hash casuale per l&apos;URL.</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Oggetti correlati</translation>
    </message>
    <message>
        <source>Add related object</source>
        <translation>Aggiungi oggetto correlato</translation>
    </message>
    <message>
        <source>Remove object location</source>
        <translation>Rimuovi la collocazione dell&apos;oggetto</translation>
    </message>
    <message>
        <source>No object relation selected</source>
        <translation>Nessuna relazione tra oggetti selezionata</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Use the description to explain the purpose of this subscription list.</source>
        <translation>Descrivi brevemente il motivo d&apos;essere di questa lista abbonati.</translation>
    </message>
    <message>
        <source>Login steps</source>
		<translation>Procedura di login</translation>
    </message>
    <message>
        <source>Require password</source>
        <translation>Richiedi password</translation>
    </message>
    <message>
        <source>Allow anonymous users</source>
        <translation>Autorizza utenti anonimi</translation>
    </message>
    <message>
        <source>Auto confirm registered users</source>
        <translation>Conferma automaticamente gli utenti registrati</translation>
    </message>
    <message>
        <source>Automatically confirm registered users</source>
        <translation>Conferma automaticamente gli utenti registrati</translation>
    </message>
    <message>
        <source>Automatically approve registered users</source>
        <translation>Approva automaticamente gli utenti registrati</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Apply the changes and return to the subscription list view.</source>
        <translation>Applica le modifiche e torna alla lista abbonati.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the subscriptions list.</source>
        <translation>Annulla le modifiche e torna alla lista abbonati.</translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation>Abbonamenti</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>OutputFormat</source>
        <translation>Formato di output</translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation>Nessun abbonamento disponibile</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation>Aggiorna impostazioni.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_archive</name>
    <message>
        <source>Newsletter archive</source>
        <translation>Archivio Newsletter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Send status</source>
        <translation>Status invio</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># inviato</translation>
    </message>
    <message>
        <source># read</source>
        <translation># letto</translation>
    </message>
    <message>
        <source>Preview newsletter</source>
        <translation>Anteprima Newsletter</translation>
    </message>
    <message>
        <source>Send date</source>
        <translation>Data invio</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_draft</name>
    <message>
        <source>Newsletter drafts</source>
        <translation>Bozze Newsletter</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Send status</source>
        <translation>Status invio</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># inviato</translation>
    </message>
    <message>
        <source># read</source>
        <translation># letto</translation>
    </message>
    <message>
        <source>Send date</source>
        <translation>Data invio</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_inprogress</name>
    <message>
        <source>Newsletter in progress</source>
        <translation>Newsletter in progress</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Send status</source>
        <translation>Status invio</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># inviato</translation>
    </message>
    <message>
        <source># read</source>
        <translation># letto</translation>
    </message>
    <message>
        <source>Preview newsletter</source>
        <translation>Anteprima Newsletter</translation>
    </message>
    <message>
        <source>Send date</source>
        <translation>Data invio</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_bounce</name>
    <message>
        <source>Soft bounce</source>
        <translation>Rimbalzi di tipo Soft</translation>
    </message>
    <message>
        <source>Hard bounce</source>
        <translation>Rimbalzi di tipo Hard</translation>
    </message>
    <message>
        <source>Newsletter bounces</source>
        <translation>Rimbalzi Newsletter</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Sent to address</source>
        <translation>Inviato all&apos;indirizzo</translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation>Conteggio rimbalzi</translation>
    </message>
    <message>
        <source>Bounce type</source>
        <translation>Tipo di rimbalzo</translation>
    </message>
    <message>
        <source>Bounce arrived</source>
        <translation>Rimbalzi arrivati</translation>
    </message>
    <message>
        <source>No bounces detected</source>
        <translation>Nessun rimbalzo trovato</translation>
    </message>
    <message>
        <source>Select bounce to clear bounce entry.</source>
        <translation>Seleziona i rimbalzi da eliminare.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected bounce entries.</source>
        <translation>Rimuovi le voci di rimbalzo selezionate.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_onhold</name>
    <message>
        <source>Soft bounce</source>
        <translation>Rimbalzo di tipo Soft</translation>
    </message>
    <message>
        <source>Hard bounce</source>
        <translation>Rimbalzo di tipo Hard</translation>
    </message>
    <message>
        <source>Send items on hold</source>
        <translation>Invia voci in sospeso</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Sent to address</source>
        <translation>Inviato all&apos;indirizzo</translation>
    </message>
    <message>
        <source>Recipient name</source>
        <translation>Nome del destinatario</translation>
    </message>
    <message>
        <source>No messages on hold detected</source>
        <translation>Nessun messaggio in sospeso trovato</translation>
    </message>
    <message>
        <source>Select an iten on hold to delete the scheduled sendout.</source>
        <translation>Seleziona una voce in sospeso per eliminare l&apos;invio programmato.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected entries on hold.</source>
        <translation>Rimuovi le voci in sospeso selezionate.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_newsletter_type</name>
    <message>
        <source>Newsletter types</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Creato da</translation>
    </message>
    <message>
        <source>Newsletter placement</source>
        <translation>Collocazione Newsletter</translation>
    </message>
    <message>
        <source>Created on</source>
        <translation>Creato il</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuovo</translation>
    </message>
    <message>
        <source>No newsletters defined</source>
        <translation>Nessuna newsletter</translation>
    </message>
    <message>
        <source>Select newsletter type for removal.</source>
        <translation>Seleziona la Newsletter da rimuovere.</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; newsletter type.</source>
        <translation>Modifica la Newsletter &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected newsletter types.</source>
        <translation>Rimuovi le Newsletter selezionate.</translation>
    </message>
    <message>
        <source>New newsletter type</source>
        <translation>Nuova Newsletter</translation>
    </message>
    <message>
        <source>Create a new newsletter type.</source>
        <translation>Crea una nuova Newsletter.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_recurring</name>
    <message>
        <source>Recurring newsletter</source>
        <translation>Newsletter ricorrente</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Send status</source>
        <translation>Status invio</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <source>Preview newsletter</source>
        <translation>Anteprima Newsletter</translation>
    </message>
    <message>
        <source>Send date</source>
        <translation>Data invio</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/list_subscriptions</name>
    <message>
        <source>Subscription lists</source>
        <translation>Liste abbonati</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Subscribers</source>
        <translation>Abbonati</translation>
    </message>
    <message>
        <source>Select subscription list for removal.</source>
        <translation>Seleziona la lista abbonati da rimuovere.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected subscription list.</source>
        <translation>Rimuovi la lista abbonati selezionata.</translation>
    </message>
    <message>
        <source>New subscription list</source>
        <translation>Nuova lista abbonati</translation>
    </message>
    <message>
        <source>Create a new subscription list.</source>
        <translation>Crea una nuova lista abbonati.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_preview</name>
    <message>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>Return to last view.</source>
        <translation>Ritorna alla vista precedente.</translation>
    </message>
    <message>
        <source>Copy this item to the same location</source>
        <translation>Copia questo elemento nella medesima posizione.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/no_subscription</name>
    <message>
        <source>You are not subscribed to any newsletter or your profile is invalid.</source>
        <translation>Non risulti abbonato ad alcuna Newsletter o il tuo profilo è incompleto.</translation>
    </message>
    <message>
        <source>Please check your profile link.</source>
        <translation>Per cortesia controlla il link al tuo profilo.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/bounce_menu</name>
    <message>
        <source>Bounce management</source>
        <translation>Gestione rimbalzi</translation>
    </message>
    <message>
        <source>On hold</source>
        <translation>In sospeso</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/eznewsletter_menu</name>
    <message>
        <source>Newslettermenu</source>
        <translation>Menù Newsletter</translation>
    </message>
    <message>
        <source>List management</source>
        <translation>Gestione liste</translation>
    </message>
    <message>
        <source>Search subscriber</source>
        <translation>Ricerca abbonati</translation>
    </message>
    <message>
        <source>Newslettertypes</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Bounce management</source>
        <translation>Gestione rimbalzi</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/newsletter_menu</name>
    <message>
        <source>Newslettertypes</source>
        <translation>Newsletter</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/parts/robinson_menu</name>
    <message>
        <source>List management</source>
        <translation>Gestione lista</translation>
    </message>
    <message>
        <source>Opt-out list</source>
        <translation>Robinsonlist</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/pending</name>
    <message>
        <source>Your email address has not been confirmed yet.</source>
        <translation>Il tuo indirizzo E-mail non è stato ancora confermato come valido.</translation>
    </message>
    <message>
        <source>Please click on the subscription confirmation link you received by email to validate your account.</source>
        <translation>Per attivare l&apos;abbonamento clicca sul link di conferma che ti è stato inviato via E-mail.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/register_subscription</name>
    <message>
        <source>Register subscription</source>
        <translation>Registrazione abbonamento</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>First name of the subscriber.</source>
        <translation>Nome dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Cognome</translation>
    </message>
    <message>
        <source>Last name of the subscriber.</source>
        <translation>Cognome dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Mobile number</source>
        <translation>Numero di cellulare</translation>
    </message>
    <message>
        <source>Mobile number of the subscriber.</source>
        <translation>Numero di cellulare dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation>E-Mail dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Formato di output</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Abbonamento!</translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation>Aggiungi all&apos;abbonamento.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Annulla</translation>
    </message>
    <message>
        <source>Cancel and discard.</source>
        <translation type="obsolete">Annulla e scarta.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/register_subscription_info</name>
    <message>
        <source>Thank you for registering</source>
        <translation>Grazie per la registrazione</translation>
    </message>
    <message>
        <source>Thank you for subscribing to %name.</source>
        <translation>Grazie per l&apos;abbonamento a &quot;%name&quot;.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="obsolete">Continua</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_edit</name>
    <message>
        <source>Edit robinsonlist entry</source>
        <translation>Modifica voce Robinsonlist</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Type of data:</source>
        <translation>Tipo di dati:</translation>
    </message>
    <message>
        <source>Email address or mobile number</source>
        <translation>Indirizzo E-mail o numero di cellulare</translation>
    </message>
    <message>
        <source>Email address or mobile phone number.</source>
        <translation>Indirizzo E-mail o numero di cellulare.</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Apply the changes and return to opt-out list.</source>
        <translation>Applica le modifiche e torna alla Robinsonlist.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the opt-out list.</source>
        <translation>Annulla le modifiche e torna alla Robinsonlist</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_import</name>
    <message>
        <source>Opt-out list import</source>
        <translation>Importazione Robinsonlist</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Carica file</translation>
    </message>
    <message>
        <source>First row is label</source>
        <translation>Nomi dei campi nella prima riga</translation>
    </message>
    <message>
        <source>Import to list:</source>
        <translation>Importa nella lista:</translation>
    </message>
    <message>
        <source>Type of data:</source>
        <translation>Tipo di dati:</translation>
    </message>
    <message>
        <source>Import options:</source>
        <translation>Opzioni di importazione:</translation>
    </message>
    <message>
        <source>Data to import</source>
        <translation>Dati da importare</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>RowNum</source>
        <translation>N. riga</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation>Cellulare</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Select row to import</source>
        <translation>Seleziona riga da importare</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel subscription import.</source>
        <translation>Annulla importazione abbonamento.</translation>
    </message>
    <message>
        <source>Import selected</source>
        <translation>Importa selezionati</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_show</name>
    <message>
        <source>Opt-out list</source>
        <translation>Robinsonlist</translation>
    </message>
    <message>
        <source>Filter list by local/global entries:</source>
        <translation>Filtra per voci locali/globali:</translation>
    </message>
    <message>
        <source>List type:</source>
        <translation>Tipo lista:</translation>
    </message>
    <message>
        <source>Show all</source>
        <translation>Mostra tutti</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Filter  subscription list.</source>
        <translation>Filtra la lista abbonati.</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Select entry for removal.</source>
        <translation>Seleziona la voce da rimuovere.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit entry.</source>
        <translation>Modifica voce.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation>Cellulare</translation>
    </message>
    <message>
        <source>Select entry for removal</source>
        <translation>Seleziona la voce da rimuovere</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected entry.</source>
        <translation>Rimuovi la voce selezionata.</translation>
    </message>
    <message>
        <source>New entry</source>
        <translation>Nuova voce</translation>
    </message>
    <message>
        <source>Create a new entry.</source>
        <translation>Crea una nuova voce.</translation>
    </message>
    <message>
        <source>Import entries from file</source>
        <translation type="obsolete">Importa le voci da un file</translation>
    </message>
    <message>
        <source>Import from file</source>
        <translation>Importa da file</translation>
    </message>
    <message>
        <source>Import entries from file.</source>
        <translation>Importa le voci da un file.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/robinson_user</name>
    <message>
        <source>Opt-out list settings</source>
        <translation>Impostazioni Robinsolist</translation>
    </message>
    <message>
        <source>Email address</source>
        <translation>Indirizzo E-mail</translation>
    </message>
    <message>
        <source>Mobile phone number</source>
        <translation>Numero di cellulare</translation>
    </message>
    <message>
        <source>Add to list</source>
        <translation>Aggiungi alla lista</translation>
    </message>
    <message>
        <source>Apply the changes and return to the opt-out list.</source>
        <translation>Applica modifiche e torna alla Robinsonlist.</translation>
    </message>
    <message>
        <source>Remove from list</source>
        <translation>Rimuovi dalla lista</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/registration</name>
    <message>
        <source>Newsletter subscription verification</source>
        <translation>Verifica abbonamento Newsletter</translation>
    </message>
    <message>
        <source>Hi %name

Thank you for subscribing to the list %listName. To activate your subscription, visit this link: %link .

To edit your settings, visit : %settingsLink</source>
        <translation>Salve %name

Complimenti per l&apos;iscrizione alla lista &quot;%listName&quot;. Per attivare il tuo abbonamento, clicca su questo link: %link.

Per modificare le tue preferenze, visita: %settingsLink</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/subscription</name>
    <message>
        <source>Newsletter subscription activation</source>
        <translation>Attivazione abbonamento Newsletter</translation>
    </message>
    <message>
        <source>Hello,

Thank you for subscribing to %listName.</source>
        <translation>Salve,

Complimenti per l&apos;attivazione del tuo abbonamento a &quot;%name&quot;.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/sendout/unscubscription</name>
    <message>
        <source>Newsletter subscription deactivation</source>
        <translation>Disattivazione abbonamento Newsletter</translation>
    </message>
    <message>
        <source>Hello,

Your subscription to %listName was deactivated.

Thank you for using this service.</source>
        <translation>Salve,

Il tuo abbonamento a %listName è stato disattivato.

Grazie e arrivederci.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_activate</name>
    <message>
        <source>Subscription activated</source>
        <translation>Abbonamento Newsletter attivato con successo</translation>
    </message>
    <message>
        <source>Hi %name

Your subscription to %subscriptionName has been activated.</source>
        <translation>Salve %name

Il tuo abbonamento a &quot;%subscriptionName&quot; è stato attivato.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_import</name>
    <message>
        <source>Import subscribers to subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Importazione abbonati nella lista &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Carica file</translation>
    </message>
    <message>
        <source>First row is label</source>
        <translation>Nomi dei campi nella prima riga</translation>
    </message>
    <message>
        <source>CSV field delimiter</source>
        <translation>Separatore di colonna</translation>
    </message>
    <message>
        <source>Import subscriptions</source>
        <translation>Importa abbonamenti</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno/a</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Cognome</translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation>Cellulare</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Select row to import</source>
        <translation>Seleziona riga da importare</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel subscription import.</source>
        <translation>Annulla importazione abbonamento.</translation>
    </message>
    <message>
        <source>Import selected</source>
        <translation>Importa selezionati</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_list</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Login steps</source>
        <translation>Procedura di login</translation>
    </message>
    <message>
        <source>Require password</source>
        <translation>Password obbligatoria</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Allow anonymous users</source>
        <translation>Autorizza utenti anonimi</translation>
    </message>
    <message>
        <source>Automatically confirm registered users</source>
        <translation>Conferma automaticamente gli utenti registrati</translation>
    </message>
    <message>
        <source>Automatically approve registered users</source>
        <translation>Approva automaticamente gli utenti registrati</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Oggetti correlati</translation>
    </message>
    <message>
        <source>No related object specified</source>
        <translation>Nessun oggetto correlato</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Edit current subscription list.</source>
        <translation>Modifica la lista abbonati corrente.</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Show all</source>
        <translation>Mostra tutti</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Filter  subscription list.</source>
        <translation>Filtra lista abbonati.</translation>
    </message>
    <message>
        <source>VIP:</source>
        <translation>VIP:</translation>
    </message>
    <message>
        <source>Subscriber list</source>
        <translation>Lista abbonati</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Cognome</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>VIP</source>
        <translation>VIP</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
    <message>
        <source>Removed</source>
        <translation>Rimosso</translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation>Seleziona l&apos;abbonato da rimuovere</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n.d.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation>Rimuovi l&apos;abbonamento selezionato.</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nuovo abbonamento</translation>
    </message>
    <message>
        <source>Create a new subscription.</source>
        <translation>Crea un nuovo abbonamento.</translation>
    </message>
    <message>
        <source>Import CSV</source>
        <translation>Importa CSV</translation>
    </message>
    <message>
        <source>Import contact from CSV file.</source>
        <translation>Importa contatti da file CSV.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/subscription_search</name>
    <message>
        <source>Search result is greater than 50, please check your search text!</source>
        <translation>La ricerca ha prodotto più di 50 risultati, per cortesia controlla il testo inserito.</translation>
    </message>
    <message>
        <source>Subscription search</source>
        <translation>Ricerca abbonamenti</translation>
    </message>
    <message>
        <source>Enter name or email address:</source>
        <translation>Inserisci il nome o l&apos;indirizzo E-Mail:</translation>
    </message>
    <message>
        <source>Search text.</source>
        <translation>Cerca testo.</translation>
    </message>
    <message>
        <source>Search subscription.</source>
        <translation>Cerca abbonamento.</translation>
    </message>
    <message>
        <source>Subscriber list</source>
        <translation>Lista abbonati</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Cognome</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation>Numero di cellulare</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
    <message>
        <source>Removed</source>
        <translation>Rimosso</translation>
    </message>
    <message>
        <source>Select subscriber for removal</source>
        <translation>Seleziona l&apos;abbonato da rimuovere</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n.d.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove selected subscription.</source>
        <translation>Rimuovi abbonamento selezionato.</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nuovo abbonamento</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Newsletter setup</source>
        <translation>Impostazioni Newsletter</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/topmenu</name>
    <message>
        <source>Topics</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>Manage newsletters</source>
        <translation>Gestione Newsletter</translation>
    </message>
    <message>
        <source>Newsletter</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Look &amp; Feel</source>
        <translation>Layout</translation>
    </message>
    <message>
        <source>Newsletter setup</source>
        <translation>Impostazioni Newsletter</translation>
    </message>
    <message>
        <source>Manage the newsletter topics</source>
        <translation>Gestione contenuti Newsletter</translation>
    </message>
    <message>
        <source>Newsletter menu</source>
        <translation>Menù Newsletter</translation>
    </message>
    <message>
        <source>eZ Newsletter setup</source>
        <translation>Impostazioni eZ Newsletter</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/unsubscribe</name>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation>E-Mail dell&apos;abbonato.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Cancellami</translation>
    </message>
    <message>
        <source>Unsubscribe subscription</source>
        <translation>Cancella abbonamento</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Cancel and discard.</source>
        <translation>Annulla e scarta.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_addsubscription</name>
    <message>
        <source>Subscribe to multiple</source>
        <translation type="obsolete">Abbonati a più</translation>
    </message>
    <message>
        <source>Please select a list you want to add:</source>
        <translation>Seleziona una lista da aggiungere:</translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation>Nessun abbonamento disponibile</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Add Subscription</source>
        <translation>Aggiungi abbonamento</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_password</name>
    <message>
        <source>Please enter your password</source>
        <translation>Inserisci la password</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Invia</translation>
    </message>
    <message>
        <source>Update settings</source>
        <translation>Aggiorna impostazioni</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_profile</name>
    <message>
        <source>Your settings</source>
        <translation>Le tue impostazioni</translation>
    </message>
    <message>
        <source>Firstname</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation>Numero di cellulare</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation>Aggiorna impostazioni.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/user_settings_user</name>
    <message>
        <source>Your subscriptions</source>
        <translation>I tuoi abbonamenti</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Subscribed</source>
        <translation>Abbonato</translation>
    </message>
    <message>
        <source>Output format</source>
        <translation>Fomato di output</translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation>Nessun abbonamento disponibile</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation>Aggiorna impostazioni.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/view_newsletter_bounce</name>
    <message>
        <source>Soft bounce</source>
        <translation>Rimbalzi di tipo Soft</translation>
    </message>
    <message>
        <source>Hard bounce</source>
        <translation>Rimbalzi di tipo Hard</translation>
    </message>
    <message>
        <source>Newsletter bounces</source>
        <translation>Rimbalzi newsletter</translation>
    </message>
    <message>
        <source>Sent item data:</source>
        <translation>Dati elemento inviato:</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Inviato</translation>
    </message>
    <message>
        <source>Newsletter ID</source>
        <translation>ID Newsletter</translation>
    </message>
    <message>
        <source>Subscription ID</source>
        <translation>ID abbonamento</translation>
    </message>
    <message>
        <source>Newsletter name</source>
        <translation>Nome Newsletter</translation>
    </message>
    <message>
        <source>Subscriber data:</source>
        <translation>Dati abbonato:</translation>
    </message>
    <message>
        <source>Subscriber name</source>
        <translation>Nome dell&apos;abbonato</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Bounce details:</source>
        <translation>Dettagli rimbalzo:</translation>
    </message>
    <message>
        <source>Bounce response message:</source>
        <translation>Messaggio su rimbalzo:</translation>
    </message>
    <message>
        <source>Subscription data:</source>
        <translation>Info abbonamento:</translation>
    </message>
    <message>
        <source>Subscription list name</source>
        <translation>Nome lista abbonati</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Bounce count</source>
        <translation>Conteggio rimbalzi</translation>
    </message>
    <message>
        <source>Set new subscription status</source>
        <translation>Imposta nuovo status dell&apos;abbonamento</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Imposta</translation>
    </message>
    <message>
        <source>Back to bounce list</source>
        <translation>Torna alla lista dei rimbalzi</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/view_newslettertype</name>
    <message>
        <source>Newsletter type</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Sender address</source>
        <translation>Indirizzo del mittente</translation>
    </message>
    <message>
        <source>Send date modifier</source>
        <translation>Modificatore data invio</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>Giorni</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>Ore</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>Minuti</translation>
    </message>
    <message>
        <source>Default pretext</source>
        <translation>Introduzione di default</translation>
    </message>
    <message>
        <source>There is no default pretext defined.</source>
        <translation>Nessuna introduzione definita.</translation>
    </message>
    <message>
        <source>Default posttext</source>
        <translation>Testo in calce di default</translation>
    </message>
    <message>
        <source>There is no default posttext defined.</source>
        <translation>Nessun testo in calce definito.</translation>
    </message>
    <message>
        <source>Default subscription</source>
        <translation>Abbonamento di default</translation>
    </message>
    <message>
        <source>Subscription lists</source>
        <translation>Liste abbonati</translation>
    </message>
    <message>
        <source>Allowed designs</source>
        <translation>Layout grafici consentiti</translation>
    </message>
    <message>
        <source>Allowed output formats</source>
        <translation>Formati di output consentiti</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Oggetti correlati</translation>
    </message>
    <message>
        <source>No related object specified</source>
        <translation>Nessun oggetto correlato</translation>
    </message>
    <message>
        <source>Suggestion inbox</source>
        <translation>Cartella Inbox</translation>
    </message>
    <message>
        <source>No inbox set</source>
        <translation>Inbox non impostata</translation>
    </message>
    <message>
        <source>Newsletter placement</source>
        <translation>Collocazione Newsletter</translation>
    </message>
    <message>
        <source>No newsletter placement is specified.</source>
        <translation>Nessuna collocazione specificata per la newsletter</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit this newsletter type.</source>
        <translation>Modifica questa Newsletter.</translation>
    </message>
    <message>
        <source>Create newsletter</source>
        <translation>Crea Newsletter</translation>
    </message>
    <message>
        <source>Newsletter lists</source>
        <translation>Liste Newsletter</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source># sent</source>
        <translation># inviato</translation>
    </message>
    <message>
        <source># read</source>
        <translation># letto</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Year</source>
        <translation>Anno</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mese</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Giorno</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Ora</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuti</translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Edit &lt;%subscription_name&gt; [Subscription]</source>
        <translation>Modifica &lt;%subscription_name&gt; [Abbonamento]</translation>
    </message>
    <message>
        <source>Edit &lt;%subscription_list_name&gt; [Subscription list]</source>
        <translation>Modifica &lt;%subscription_list_name&gt; [Lista abbonati]</translation>
    </message>
    <message>
        <source>URL : %url</source>
        <translation>URL : %url</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription list.</source>
        <translation>Modifica la lista abbonati &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Opt-out lists ( %number_emails Emails / %number_mobile Mobile numbers )</source>
        <translation>Robinsonlist ( %number_emails E-mail / %number_mobile Numeri cellulare )</translation>
    </message>
    <message>
        <source>Subscription list &lt;%subscription_list_name&gt;</source>
        <translation>Lista abbonati &lt;%subscription_list_name&gt;</translation>
    </message>
    <message>
        <source>Edit the &lt;%newsletter_name&gt; subscription.</source>
        <translation>Modifica l&apos;abbonamento a &lt;%newsletter_name&gt;.</translation>
    </message>
    <message>
        <source>Newslettertype: %newsletter_type_name [%newsletter_type_id]</source>
        <translation>Newsletter: %newsletter_type_name [%newsletter_type_id]</translation>
    </message>
    <message>
        <source>No subscription.</source>
        <translation>Nessun abbonamento.</translation>
    </message>
    <message>
        <source>Activate Subscription</source>
        <translation>Attiva abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_newslettertype</name>
    <message>
        <source>Email address &quot;%address&quot; did not validate.</source>
        <translation>L&apos;indirizzo E-mail &quot;%address&quot; non ha superato la validazione.</translation>
    </message>
    <message>
        <source>Edit newsletter type</source>
        <translation>Modifica Newsletter</translation>
    </message>
    <message>
        <source>You have not defined a name for this newslettertype</source>
        <translation>Devi inserire un nome per questa Newsletter</translation>
    </message>
    <message>
        <source>You have to select at least one allowed output format.</source>
        <translation>Devi selezionare almeno un formato di output.</translation>
    </message>
    <message>
        <source>You have to select at least one design.</source>
        <translation>Devi selezionare almento un layout.</translation>
    </message>
    <message>
        <source>You have to select at least one subscription list.</source>
        <translation>Devi selezionare almeno una lista di abbonati.</translation>
    </message>
    <message>
        <source>You have to select a valid newsletter placement.</source>
        <translation>Devi seleziona una poszione valida per la Newsletter.</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_subscription</name>
    <message>
        <source>Email address or mobile phone number is in opt-out list!</source>
        <translation>L&apos;indirizzo E-mail o il numero di cellulare sono nella Robinsonlist!</translation>
    </message>
    <message>
        <source>Email Address or mobile phone number is in Robinsonlist!</source>
        <translation>L&apos;indirizzo E-mail o il numero di cellulare sono nella Robinsonlist!</translation>
    </message>
    <message>
        <source>Edit subscription</source>
        <translation>Modifica abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/edit_subscription_list</name>
    <message>
        <source>Subscription lists</source>
        <translation>Liste abbonati</translation>
    </message>
</context>
<context>
    <name>eznewsletter/eznewslettertype/output_format</name>
    <message>
        <source>Plain text</source>
        <translation>Formato testo</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML con immagini embedded</translation>
    </message>
    <message>
        <source>HTML w/external images</source>
        <translation>HTML con immagini linkate</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_archive</name>
    <message>
        <source>View newsletter type</source>
        <translation>Vedi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_draft</name>
    <message>
        <source>View newsletter type</source>
        <translation>Vedi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_inprogress</name>
    <message>
        <source>View newsletter type</source>
        <translation>Vedi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_newsletterbounce</name>
    <message>
        <source>Messages on hold</source>
        <translation>Messaggi in sospeso</translation>
    </message>
    <message>
        <source>Newsletter items on hold</source>
        <translation>Newsletter in sospeso</translation>
    </message>
    <message>
        <source>View newsletter bounce entry</source>
        <translation>Vedi rimbalzo della Newsletter</translation>
    </message>
    <message>
        <source>Newsletter types</source>
        <translation>Newsletter</translation>
    </message>
    <message>
        <source>View newsletter bounces</source>
        <translation>Vedi rimbalzi</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_newslettertype</name>
    <message>
        <source>Newsletter types</source>
        <translation>Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_recuring</name>
    <message>
        <source>View newsletter type</source>
        <translation>Vedi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/list_subscriptions</name>
    <message>
        <source>Subscription lists</source>
        <translation>Lista abbonati</translation>
    </message>
</context>
<context>
    <name>eznewsletter/login_steps</name>
    <message>
        <source>Confirm user</source>
        <translation>Conferma utente</translation>
    </message>
    <message>
        <source>Confirm and approve user</source>
        <translation>Conferma e approva utente</translation>
    </message>
</context>
<context>
    <name>eznewsletter/modify_subscription</name>
    <message>
        <source>The given email address is already in use. Please use another.</source>
        <translation>L&apos;indirizzo di posta specificato è già presente nei nostri archivi. Per cortesia usane un altro.</translation>
    </message>
    <message>
        <source>Password did not match</source>
        <translation>La password è errata</translation>
    </message>
    <message>
        <source>No subscription</source>
        <translation>Nessun abbonamento</translation>
    </message>
    <message>
        <source>Activate subscription</source>
        <translation>Attiva l&apos;abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/newsletter/edit_subscription</name>
    <message>
        <source>You must provide a valid email address.</source>
        <translation>Devi inserire un indirizzo E-mail valido.</translation>
    </message>
</context>
<context>
    <name>eznewsletter/object_status</name>
    <message>
        <source>Draft</source>
        <translation>Bozza</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Pubblicata</translation>
    </message>
</context>
<context>
    <name>eznewsletter/ouput_formats</name>
    <message>
        <source>External HTML</source>
        <translation>HTML con immagini linkate</translation>
    </message>
</context>
<context>
    <name>eznewsletter/output_formats</name>
    <message>
        <source>Text</source>
        <translation>Formato testo</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML con immagini embedded</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>External HTML</source>
        <translation>HTML con immagini linkate</translation>
    </message>
</context>
<context>
    <name>eznewsletter/recurrencetype</name>
    <message>
        <source>Daily</source>
        <translation>Quotidiana</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Settimanale</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Mensile</translation>
    </message>
</context>
<context>
    <name>eznewsletter/register_subscription</name>
    <message>
        <source>You are already a registered subscriber</source>
        <translation>Sei già un utente abbonato</translation>
    </message>
    <message>
        <source>You have renewed your subscription.</source>
        <translation>Hai rinnovato il tuo abbonamento.</translation>
    </message>
    <message>
        <source>Passwords did not match.</source>
        <translation>Le password inserite non coincidono.</translation>
    </message>
    <message>
        <source>You must enter a first name.</source>
        <translation>Devi inserire il Nome.</translation>
    </message>
    <message>
        <source>You must enter a last name.</source>
        <translation>Devi inserire il Cognome.</translation>
    </message>
    <message>
        <source>You must provide a valid email address.</source>
        <translation>Devi inserire un indirizzo E-mail valido.</translation>
    </message>
    <message>
        <source>You&apos;re already a registered subscriber</source>
        <translation>Sei già un utente abbonato</translation>
    </message>
    <message>
        <source>Email address or mobile phone number is in opt-out list. Subscribing is not possible.</source>
        <translation>L&apos;indirizzo E-mail o il numero di cellulare sono nella Robinsonlist. Non è possibile abbonarsi.</translation>
    </message>
    <message>
        <source>Register subscription</source>
        <translation>Conferma abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_edit</name>
    <message>
        <source>Please enter a valid email.</source>
        <translation>Per cortesia inserisci un indirizzo E-mail valido.</translation>
    </message>
    <message>
        <source>Please fill in all required fields.</source>
        <translation>Per cortesia completa tutti i campi obbligatori.</translation>
    </message>
    <message>
        <source>Opt-out list edit</source>
        <translation>Modifica Robinsonlist</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_import</name>
    <message>
        <source>Opt-out list</source>
        <translation>Robinsonlist</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_show</name>
    <message>
        <source>Opt-out list</source>
        <translation>Robinsonlist</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinson_user</name>
    <message>
        <source>Entered email address is already in the list.</source>
        <translation>L&apos;indirizzo E-mail inserito è già presente nella lista.</translation>
    </message>
    <message>
        <source>Entered email address is not in the list.</source>
        <translation>L&apos;indirizzo E-mail inserito non è nella lista.</translation>
    </message>
    <message>
        <source>Please enter a valid email.</source>
        <translation>Per cortesia inserisci un indirizzo E-mail valido.</translation>
    </message>
    <message>
        <source>Entered mobile phone number is already in the list.</source>
        <translation>Il numero di cellulare inserito è già presente nella lista.</translation>
    </message>
    <message>
        <source>Entered mobile phone number is not in the list.</source>
        <translation>Il numero di cellulare inserito non è nella lista.</translation>
    </message>
    <message>
        <source>An error occured, no updates were made.</source>
        <translation>Si è verificato un errore, nessun aggiornamento effettuato.</translation>
    </message>
    <message>
        <source>Updates complete.</source>
        <translation>Aggiornamenti completati.</translation>
    </message>
    <message>
        <source>You must fill in at least one field.</source>
        <translation>Devi completare almeno un campo.</translation>
    </message>
    <message>
        <source>Robinsonlist settings</source>
        <translation>Impostazioni Robinsonlist</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_action</name>
    <message>
        <source>Synchronize</source>
        <translation>Sincronizza</translation>
    </message>
    <message>
        <source>Only add new</source>
        <translation>Aggiungi solo nuovi</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_entrysource</name>
    <message>
        <source>Local</source>
        <translation>Locale</translation>
    </message>
    <message>
        <source>External data</source>
        <translation>Dati esterni</translation>
    </message>
</context>
<context>
    <name>eznewsletter/robinsonlist_entrytype</name>
    <message>
        <source>Email address</source>
        <translation>Indirizzo E-mail</translation>
    </message>
    <message>
        <source>Mobile phone number</source>
        <translation>Numero di cellulare</translation>
    </message>
</context>
<context>
    <name>eznewsletter/send_status</name>
    <message>
        <source>Not sent</source>
        <translation>Non inviato</translation>
    </message>
    <message>
        <source>Building sendout list</source>
        <translation>Elaborazione lista destinatari</translation>
    </message>
    <message>
        <source>Sending</source>
        <translation>Invio in corso</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Invio completo</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Invio stoppato</translation>
    </message>
</context>
<context>
    <name>eznewsletter/senditem_status</name>
    <message>
        <source>Send mailing</source>
        <translation>Invia</translation>
    </message>
    <message>
        <source>Mark as sent</source>
        <translation>Segna come inviato</translation>
    </message>
    <message>
        <source>On hold</source>
        <translation>In sospeso</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_activate</name>
    <message>
        <source>Activate subscription</source>
        <translation>Attiva abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_import</name>
    <message>
        <source>Subscription list</source>
        <translation>Lista abbonati</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_list</name>
    <message>
        <source>Subscription list</source>
        <translation>Lista abbonati</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_search</name>
    <message>
        <source>Edit Subscription</source>
        <translation>Modifica abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/subscription_status</name>
    <message>
        <source>Pending</source>
        <translation>In attesa</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
    <message>
        <source>Removed by self</source>
        <translation>Rimosso da sé</translation>
    </message>
    <message>
        <source>Removed by admin</source>
        <translation>Rimosso dall&apos;Admin</translation>
    </message>
</context>
<context>
    <name>eznewsletter/user_settings</name>
    <message>
        <source>The given email address is already in use. Please use another.</source>
        <translation>L&apos;indirizzo di posta specificato è già presente nei nostri archivi. Per cortesia usane un altro.</translation>
    </message>
    <message>
        <source>Password did not match</source>
        <translation>La password non coincide</translation>
    </message>
</context>
<context>
    <name>eznewsletter/user_settings_password.tpl</name>
    <message>
        <source>Activate subscription</source>
        <translation>Attiva abbonamento</translation>
    </message>
</context>
<context>
    <name>eznewsletter/view_newslettertype</name>
    <message>
        <source>View newsletter type</source>
        <translation>Vedi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewsletter/vip_type</name>
    <message>
        <source>Not set</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Silver</source>
        <translation>Silver</translation>
    </message>
    <message>
        <source>Gold</source>
        <translation>Gold</translation>
    </message>
    <message>
        <source>Platinum</source>
        <translation>Platinum</translation>
    </message>
</context>
<context>
    <name>eznewsletter/workflow/event</name>
    <message>
        <source>Newsletter read</source>
        <translation>Leggi Newsletter</translation>
    </message>
</context>
<context>
    <name>eznewslettert</name>
    <message>
        <source>Back to subscription list</source>
        <translation>Torna alla lista degli abbonati</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>RowNum</source>
        <translation>N. riga</translation>
    </message>
    <message>
        <source>Back to subscription lists</source>
        <translation type="obsolete">Torna alla liste degli abbonati</translation>
    </message>
</context>
</TS>
