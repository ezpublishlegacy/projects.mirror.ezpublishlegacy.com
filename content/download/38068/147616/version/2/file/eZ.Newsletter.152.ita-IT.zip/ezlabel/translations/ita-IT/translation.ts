<!DOCTYPE TS><TS>
<context>
    <name>extension/ezlabel</name>
    <message>
        <source>Private label</source>
        <translation>Etichetta privata</translation>
    </message>
    <message>
        <source>Global label</source>
        <translation>Etichetta globale</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Rimuovi etichetta</translation>
    </message>
    <message>
        <source>Unassign label</source>
        <translation>Stacca etichetta</translation>
    </message>
    <message>
        <source>List all labels</source>
        <translation>Lista etichette</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Assegna</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/create</name>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Labels defined</source>
        <translation>Etichette definite</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Globale</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privata</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Crea</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Assegna</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/edit</name>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Labels defined</source>
        <translation>Etichette definite</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/list</name>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Labels defined</source>
        <translation>Etichette definite</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Private label</source>
        <translation>Etichetta privata</translation>
    </message>
    <message>
        <source>Global label</source>
        <translation>Etichetta globale</translation>
    </message>
    <message>
        <source>There are no labels.</source>
        <translation>Nessuna etichetta.</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Globale</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privata</translation>
    </message>
    <message>
        <source>Crea</source>
        <translation>Erstellen</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/toolbar/full</name>
    <message>
        <source>Hide label view</source>
        <translation>Nascondi etichette</translation>
    </message>
    <message>
        <source>Labels</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <source>Show label view</source>
        <translation>Mostra etichette</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Rimuovi etichetta</translation>
    </message>
    <message>
        <source>Unassign label</source>
        <translation>Stacca etichetta</translation>
    </message>
    <message>
        <source>Private label</source>
        <translation>Etichetta privata</translation>
    </message>
    <message>
        <source>Global label</source>
        <translation>Etichetta globale</translation>
    </message>
    <message>
        <source>No Labels assigned.</source>
        <translation>Nessuna etichetta assegnata.</translation>
    </message>
    <message>
        <source>List all labels</source>
        <translation>Lista etichette</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Assegna</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Globale</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privata</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Crea</translation>
    </message>
    <message>
        <source>No labels assigned.</source>
        <translation>Nessuna etichetta assegnata.</translation>
    </message>
</context>
<context>
    <name>extension/ezlabel/view_full</name>
    <message>
        <source>Assigned objects</source>
        <translation>Oggetti assegnati</translation>
    </message>
    <message>
        <source>Objects assigned to label</source>
        <translation>Oggetti assegnati all'etichetta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>There are no objects assigned to this label.</source>
        <translation>Nessun oggetto assegnato a questa etichetta.</translation>
    </message>
</context>
<context>
    <name>extension/label</name>
    <message>
        <source>Labels</source>
        <translation>Etichette</translation>
    </message>
</context>
</TS>
