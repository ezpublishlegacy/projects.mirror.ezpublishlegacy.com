<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Modifica &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Traduzione da %from_lang a %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Pubblica</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Pubblica il contenuto della bozza aperta in modifica. La bozza attuale diverrà quindi la versione pubblicata dell'oggetto.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Salva bozza</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Salva il contenuto della bozza aperta e continua con la modifica. Utile per salvare periodicamente il lavoro.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Annulla bozza</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Sicuro di voler annullare la bozza?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Annulla la bozza aperta. Verranno rimosse anche le eventuali traduzioni della bozza.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Last modified</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID nodo</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID oggetto</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Modifica i contenuti di questo elemento.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation>Non sei autorizzato a modificare questo elemento.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Sposta</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Sposta questo elemento in un'altra collocazione</translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation>Non sei autorizzato a spostare questo elemento in un'altra collocazione.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Rimuovi questo elemento.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation>Non sei autorizzato a rimuovere questo elemento.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Modifica &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Non sei autorizzato a modificare &lt;%child_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Cerca in tutti i contenuti.</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Tutti i contenuti</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Cerca a partire dalla posizione corrente.</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>Posizione corrente</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>La stessa collocazione</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzata</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Ricerca avanzata.</translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation>Logout dal sistema.</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logout</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/editor_view/article_list</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Classe &quot;Newsletter - Articolo; non trovata, impossibile filtrare gli articoli!</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/bounce</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>La convalida dei dati inseriti ha avuto esito negativo.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter/newsletter_setup/edit_bounceaccount</name>
    <message>
        <source>The validation of your entries failed.</source>
        <translation>La convalida dei dati inseriti ha avuto esito negativo.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/datatype_view</name>
    <message>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list</name>
    <message>
        <source>Topics</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of articles in the current view</comment>
        <translation>%from - %to di %total_count</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Target utenza</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Data di scadenza</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Dada di validità</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Invii</translation>
    </message>
    <message>
        <source>Reads</source>
        <translation>Letture</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato il</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Spiacente, nessun articolo in questa categoria</translation>
    </message>
    <message>
        <source>New article</source>
        <translation>Nuovo articolo</translation>
    </message>
    <message>
        <source>Create a new article.</source>
        <translation>Crea un nuovo articolo.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Rimuovi selezione</translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation>Rimuovi gli elementi selezionati dalla lista qui sopra.</translation>
    </message>
    <message>
        <source>Category name</source>
        <translation>Categoria</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_list_browse</name>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Classe &quot;Newsletter - Articolo; non trovata, impossibile filtrare gli articoli!</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Sorry no articles in this category</source>
        <translation>Spiacente, nessun articolo in questa categoria</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Target utenza</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Data di scadenza</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Data di validità</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Sendouts</source>
        <translation>Invii</translation>
    </message>
    <message>
        <source>Letture</source>
        <translation>Gelesen</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creato il</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_stats_box</name>
    <message>
        <source>Statistics</source>
        <translation>Statistiche</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/article_view</name>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit this article.</source>
        <translation>Modifica questo articolo.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Rimuovi questo elemento.</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Sposta questo elemento in un'altra collocazione.</translation>
    </message>
    <message>
        <source>Copy to</source>
        <translation>Copia su</translation>
    </message>
    <message>
        <source>Copy this article to another location.</source>
        <translation>Copia questo articolo in un'altra collocazione.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Copy this article to the same location.</source>
        <translation>Crea una copia di questo articolo nella stessa collocazione.</translation>
    </message>
    <message>
        <source>Newsletter categories</source>
        <translation>Categorie Newsletter</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>New category</source>
        <translation>Nuova categoria</translation>
    </message>
    <message>
        <source>Create a new category.</source>
        <translation>Crea una nuova categoria.</translation>
    </message>
    <message>
        <source>Apply filters to view.</source>
        <translation>Applica filtri.</translation>
    </message>
    <message>
        <source>Reset filters for view.</source>
        <translation>Reimposta filtri.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/category_list</name>
    <message>
        <source>%from - %to out of %total_count</source>
        <comment>Shows the current viewed range and total count of categories in the current view</comment>
        <translation>%from - %to di %total_count</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/filter_box</name>
    <message>
        <source>Filter options</source>
        <translation>Opzioni filtri</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorità:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Target audience:</source>
        <translation>Target utenza:</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation>Lingua:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etichetta:</translation>
    </message>
    <message>
        <source>From (Y/M/D):</source>
        <translation>Da (A/M/G):</translation>
    </message>
    <message>
        <source>To (Y/M/D):</source>
        <translation>A (A/M/G):</translation>
    </message>
    <message>
        <source>Apply filters</source>
        <translation>Applica filtri</translation>
    </message>
    <message>
        <source>Reset filters</source>
        <translation>Reimposta filtri</translation>
    </message>
    <message>
        <source>Introducion date</source>
        <translation>Data di inserimento</translation>
    </message>
    <message>
        <source>Expire Date</source>
        <translation>Data di scadenza</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/editor_view/idea_list</name>
    <message>
        <source>Ideas</source>
        <translation>Inbox</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <source>Target audience</source>
        <translation>Target utenza</translation>
    </message>
    <message>
        <source>Expiry date</source>
        <translation>Data di scadenza</translation>
    </message>
    <message>
        <source>Validity date</source>
        <translation>Data di validità</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Proposer</source>
        <translation>Proponente</translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation>In entrata</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_builder/eznewsletter_setup/edit_bounceaccount</name>
    <message>
        <source>Comma separated flags ( visit http://php.net/imap_open for more information )</source>
        <translation>Flag separate da virgola ( vedi http://php.net/imap_open per maggiori informazioni )</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_setup/bounce</name>
    <message>
        <source>Invert selection</source>
        <translation>Inverti selezione</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/bounce</name>
    <message>
        <source>Bounce settings</source>
        <translation>Impostazioni rimbalzo</translation>
    </message>
    <message>
        <source>Softbounce limit</source>
        <translation>Limite rimbalzi soft</translation>
    </message>
    <message>
        <source>The softbounce limit defines the amount of soft bounces, that will be allowed until sending to the subscriber will be suspended.</source>
        <translation>I limite rimbalzi soft definisce la quantità di rimbalzi tollerati prima di sospendere l'invio della Newsletter all'abbonato</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reimposta</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Account</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificatore</translation>
    </message>
    <message>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation>Protocollo</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Flag</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit the &lt;%account_name&gt; account.</source>
        <translation>Modifica l'account &lt;%account_name&gt;.</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation>Elimina selezionati</translation>
    </message>
    <message>
        <source>Create account</source>
        <translation>Crea account</translation>
    </message>
    <message>
        <source>Bounce account [%account]</source>
        <translation>Account per i rimbalzi [%account]</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Hostname</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Utente</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>New accountname</source>
        <translation>Nuovo nome account</translation>
    </message>
    <message>
        <source>Password verification</source>
        <translation>Verifica password</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/general</name>
    <message>
        <source>General setup</source>
        <translation>Impostazioni generali</translation>
    </message>
    <message>
        <source>Newsletter sendout</source>
        <translation>Invio Newsletter</translation>
    </message>
    <message>
        <source>Sendout transport method</source>
        <translation>Metodo di trasporto per l'invio</translation>
    </message>
    <message>
        <source>Preview transport method</source>
        <translation>Anteprima metodo di trasporto</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reimposta</translation>
    </message>
</context>
<context>
    <name>design/newsletter_setup/menu</name>
    <message>
        <source>Newsletter setup</source>
        <translation>Impostazioni Newsletter</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Bounce</source>
        <translation>Rimbalzi</translation>
    </message>
    <message>
        <source>SMTP Cluster</source>
        <translation>Cluster SMTP</translation>
    </message>
    <message>
        <source>Email registration</source>
        <translation>Registrazione via E-Mail</translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Newsletter article class not found, creating newsletter articles not possible!</source>
        <translation>Classe &quot;Newsletter - Articolo; non trovata, impossibile creare nuovi articoli!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder</name>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
    <message>
        <source>Newsletter article class not found, filtering newsletter articles not possible!</source>
        <translation>Classe &quot;Newsletter - Articolo; non trovata, impossibile filtrare gli articoli!</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup</name>
    <message>
        <source>eZ Newsletter setup</source>
        <translation>eZ Newsletter setup</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/bounce</name>
    <message>
        <source>You have to enter a valid limit for softbounces.</source>
        <translation>Devi inserire un limite valido per i rimbalzi soft.</translation>
    </message>
    <message>
        <source>You have to define an accountname.</source>
        <translation>Devi inserire un nome account.</translation>
    </message>
    <message>
        <source>The passwords must be equal.</source>
        <translation>Le password devono essere identiche.</translation>
    </message>
</context>
<context>
    <name>eznewsletter_builder/newsletter_setup/general</name>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>File (for SMTP cluster)</source>
        <translation>File (per cluster SMTP)</translation>
    </message>
</context>
</TS>
