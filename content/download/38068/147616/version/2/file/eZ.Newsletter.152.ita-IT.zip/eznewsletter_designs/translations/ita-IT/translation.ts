<!DOCTYPE TS><TS>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout</name>
    <message>
        <source>Interested? Learn more ...</source>
        <translation>Interessato? Per saperne di più...</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Spiacente, articolo non trovato!</translation>
    </message>
    <message>
        <source>Topics</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>Upcoming Events</source>
        <translation>Prossimi eventi</translation>
    </message>
    <message>
        <source>Legal Information</source>
        <translation>Informazioni legali</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Cancellami</translation>
    </message>
    <message>
        <source>Upcoming events</source>
        <translation>Prossimi eventi</translation>
    </message>
    <message>
        <source>Legal information</source>
        <translation>Informazioni legali</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>News della settimana</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>EVENTS THIS MONTH</source>
        <translation>Eventi del mese</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profilo</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Salve, ci sono news per te. Visita %url_to_newsletter per leggere la nostra ultima Newsletter.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite</name>
    <message>
        <source>back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation>Spiacente, articolo non trovato!</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Leggi tutto...</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Copertina</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Cancellami</translation>
    </message>
    <message>
        <source>Also today</source>
        <translation>Altre novità</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Contatti</translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation>News della settimana</translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profilo</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Salve, ci sono news per te. Visita %url_to_newsletter per leggere la nostra ultima Newsletter.</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/node/view/newsletter</name>
    <message>
        <source>Read the full story ...</source>
        <translation>Leggi tutto...</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout</name>
    <message>
        <source>Read more</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <source>Only</source>
        <translation>Solo</translation>
    </message>
    <message>
        <source>Buy this product now</source>
        <translation>Compralo subito</translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation>Contatti</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Cancellami</translation>
    </message>
    <message>
        <source>ONLY</source>
        <translation>SOLO</translation>
    </message>
    <message>
        <source>Profil</source>
        <translation>Profilo</translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout/sms</name>
    <message>
        <source>Hello, we have some products available which might interrest you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation>Ciao, abbiamo dei prodotti disponibili che ti potrebbero interessare. Visita %url_to_newsletter per leggere la nostra ultima Newsletter.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Prezzo:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Il tuo prezzo:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Risparmio:</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Prezzo</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Informazioni account</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID utente</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
</context>
</TS>
