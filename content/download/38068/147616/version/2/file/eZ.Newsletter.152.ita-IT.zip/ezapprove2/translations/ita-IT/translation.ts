<!DOCTYPE TS><TS>
<context>
    <name>crm</name>
    <message>
        <source>Select minimum number of required approvals.</source>
        <translation type="obsolete">Seleziona il numero minimo di approvazioni.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/full/ezapprove</name>
    <message>
        <source>Approval</source>
        <translation>Approvazione</translation>
    </message>
    <message>
        <source>The content object awaits approval before it can be published.</source>
        <translation>Il contenuto attende approvazione per la pubbicazione.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Vuoi mandare un messaggio alla persona designata per l'approvazione?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Il contenuto %1 richiede la tua approvazione per la pubblicazione.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Dai la tua approvazione al contenuto proposto per la pubblicazione?</translation>
    </message>
    <message>
        <source>You have approved the content, and it is waiting for more approvers, or the workflow to continue the processing of the object,</source>
        <translation>Hai approvato il contenuto, che rimane in attesa di ulteriori approvazioni o dell'esecuzione del workflow per la pubblicazione definitiva,</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Il contenuto %1 è stato approvato e verrà pubblicato al termine delle procedure previste dal workflow.</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was approved and will be published once the publishing workflow continues.</source>
        <translation>Il contenuto %1 [eliminato] è stato approvato e verrà pubblicato al termine delle procedure previste dal workflow.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Il contenuto %1 non è stato approvato ma rimane disponibile come bozza.</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was not accepted but is available as a draft again.</source>
        <translation>Il contenuto %1 [eliminato] non è stato approvato ma rimane disponibile come bozza.</translation>
    </message>
    <message>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>Puoi modificare la bozza e richiedere nuovamente l'approvazione del contenuto.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Modifica il contenuto</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Il contenuto %1 non è stato approvato ma rimane disponibile come bozza per il suo autore.</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was not accepted but will be available as a draft for the author.</source>
        <translation>Il contenuto %1 [eliminato] non è stato approvato ma rimane disponibile come bozza per il suo autore.</translation>
    </message>
    <message>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>L'autore può modificare la bozza e richiedere nuovamente l'approvazione.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commenta</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Aggiungi commento</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Approva</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Nega approvazione</translation>
    </message>
    <message>
        <source>Add approver</source>
        <translation>Aggiungi designato per l'approvazione</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Messaggi</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Partecipanti</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/line/ezapprove</name>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 attende approvazione dell'editor</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 è stato approvato</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 non è stato approvato</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 attende la tua approvazione</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Modifica &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Non hai l'autorizzazione per modificare &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
        <source>Affected sections</source>
        <translation type="obsolete">Sezioni interessate</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation type="obsolete">Tutte le sezioni</translation>
    </message>
    <message>
        <source>Users select approvers themselves</source>
        <translation type="obsolete">Gli utenti scelgono da sé le persone designate per l'approvazione</translation>
    </message>
    <message>
        <source>Users select who should approve the content when publishing</source>
        <translation type="obsolete">Gli utenti scelgono chi approva i loro contenuti a momento della pubblicazione</translation>
    </message>
    <message>
        <source>Required number of users to approve content</source>
        <translation type="obsolete">Numero richiesto di utenti che approvano il contenuto</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Uno o più</translation>
    </message>
    <message>
        <source>Select if one or all is enough to approve content.</source>
        <translation type="obsolete">Seleziona se ne bastano uno o più.</translation>
    </message>
    <message>
        <source>Allow approvers to be added while approving content.</source>
        <translation type="obsolete">Consenti l'aggiunta di altri designati per l'approvazione contestualmente all'approvazione del contenuto.</translation>
    </message>
    <message>
        <source>Pre selected approvers</source>
        <translation type="obsolete">Persone già designate per l'approvazione</translation>
    </message>
    <message>
        <source>Users who approves content</source>
        <translation type="obsolete">Utenti che approvano il contentuto</translation>
    </message>
    <message>
        <source>User</source>
        <translation type="obsolete">Utente</translation>
    </message>
    <message>
        <source>No users selected.</source>
        <translation>Nessun utente selezionato.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Elimina selezionati</translation>
    </message>
    <message>
        <source>Add users</source>
        <translation>Aggiungi utenti</translation>
    </message>
    <message>
        <source>Groups who approves content</source>
        <translation type="obsolete">Gruppi che approvano il contenuto</translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="obsolete">Gruppo</translation>
    </message>
    <message>
        <source>No groups selected.</source>
        <translation type="obsolete">Nessun gruppo selezionato.</translation>
    </message>
    <message>
        <source>Add groups</source>
        <translation type="obsolete">Aggiungi gruppi</translation>
    </message>
    <message>
        <source>Excluded user groups ( users in these groups do not need to have their content approved )</source>
        <translation type="obsolete">Gruppi esclusi dall'approvazione (gli utenti di questi gruppi non abbisognano di approvazione per i loro contenuti)</translation>
    </message>
    <message>
        <source>User and user groups</source>
        <translation type="obsolete">Utenti e gruppi di utenti</translation>
    </message>
    <message>
        <source>Approve users</source>
        <translation>Approva utenti</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continua</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Posted: %1</source>
        <translation>Inviato: %1</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] L'approvazione di &quot;%objectname&quot; attende la tua considerazione</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>Questo messaggio per informarti che &quot;%objectname&quot; attende la tua considerazione su %sitename.
Il workflow di pubblicazione è stato fermato e la sua continuazione dipende da te.
Puoi accedere alle funzioni di approvazione dei contenuti cliccando sull'URL sotto riportato.</translation>
    </message>
    <message>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot; attende approvazione</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>Questo messaggio per informarti che &quot;%objectname&quot; attende approvazione su %sitename prima di essere pubblicato.
Se desideri inviare commenti alla persona designata per l'approvazione o vedere lo stato di avanzamento della procedura, usa l'URL sotto riportato.</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Se non desideri più ricevere queste notifiche,
cambia le tue preferenze qui:</translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation>%sitename - Notifiche automatiche</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
        <source>Approver users</source>
        <translation>Utenti designati per l'approvazione</translation>
    </message>
    <message>
        <source>Approver groups</source>
        <translation>Gruppi di utenti designati per l'approvazione</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sezioni</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Qualsiasi</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Utenti senza approvazione</translation>
    </message>
</context>
<context>
    <name>ezapprove2</name>
    <message>
        <source>One</source>
        <translation>Uno</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>User defined</source>
        <translation>Definito dall'utente</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <source>Predefined</source>
        <translation>Predefinito</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Approva</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>New Draft</source>
        <translation>Nuova bozza</translation>
    </message>
    <message>
        <source>Select users to do content approval &lt;%object_name&gt;</source>
        <translation>Seleziona gli utenti per l'approvazione di &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Update list</source>
        <translation>Aggiorna lista</translation>
    </message>
    <message>
        <source>Edit Subscription</source>
        <translation>Modifica abbonamento</translation>
    </message>
    <message>
        <source>You need to select at least %num_users users to approve your content.</source>
        <translation>Devi selezionare almeno %num_users utenti per l'approvazione del tuo contenuto.</translation>
    </message>
    <message>
        <source>Select users for content approval &lt;%object_name&gt;</source>
        <translation>Seleziona gli utenti per l'approvazione del contenuto &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Select approver</source>
        <translation>Seleziona utenti per l'approvazione</translation>
    </message>
    <message>
        <source>In approval</source>
        <translation>In attesa di approvazione</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Approvato</translation>
    </message>
    <message>
        <source>Discarded</source>
        <translation>Non approvato</translation>
    </message>
    <message>
        <source>Finnished</source>
        <translation>Concluso</translation>
    </message>
    <message>
        <source>Select minimum number of required approvals.</source>
        <translation>Seleziona il numero minimo di approvazioni.</translation>
    </message>
    <message>
        <source>Elements awaiting approval</source>
        <translation>Contenuti in attesa di approvazione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Inverti selezione.</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID oggetto</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Started</source>
        <translation>Iniziato</translation>
    </message>
    <message>
        <source># Approved</source>
        <translation># Approvato</translation>
    </message>
    <message>
        <source># Required</source>
        <translation># Richiesto</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Select approval for removal. This will will mark the pending version as archived.</source>
        <translation>Seleziona l'approvazione da rimuovere. La versione in corso di modifica verrà archiviata.</translation>
    </message>
    <message>
        <source>Update approval statuses.</source>
        <translation>Aggiorna lo status delle approvazioni.</translation>
    </message>
    <message>
        <source>Approve List</source>
        <translation>Approva lista</translation>
    </message>
    <message>
        <source>Affected sections</source>
        <translation>Sezioni interessate</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Tutte le sezioni</translation>
    </message>
    <message>
        <source>Users select approvers themselves</source>
        <translation>Gli utenti scelgono da sé le persone designate per l'approvazione</translation>
    </message>
    <message>
        <source>Users select who should approve the content when publishing</source>
        <translation>Gli utenti scelgono chi approva i loro contenuti a momento della pubblicazione</translation>
    </message>
    <message>
        <source>Required number of users to approve content</source>
        <translation>Numero richiesto di utenti che approvano il contenuto</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Uno o più</translation>
    </message>
    <message>
        <source>Select if one or all is enough to approve content.</source>
        <translation>Seleziona se ne bastano uno o più.</translation>
    </message>
    <message>
        <source>Allow approvers to be added while approving content.</source>
        <translation>Consenti l'aggiunta di altri designati per l'approvazione contestualmente all'approvazione del contenuto.</translation>
    </message>
    <message>
        <source>Pre selected approvers</source>
        <translation>Persone già designate per l'approvazione</translation>
    </message>
    <message>
        <source>Users who approves content</source>
        <translation>Utenti che approvano il contentuto</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utente</translation>
    </message>
    <message>
        <source>No users selected.</source>
        <translation>Nessun utente selezionato.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Elimina selezionati</translation>
    </message>
    <message>
        <source>Add users</source>
        <translation>Aggiungi utenti</translation>
    </message>
    <message>
        <source>Groups who approves content</source>
        <translation>Gruppi che approvano il contenuto</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>No groups selected.</source>
        <translation>Nessun gruppo selezionato.</translation>
    </message>
    <message>
        <source>Add groups</source>
        <translation>Aggiungi gruppi</translation>
    </message>
    <message>
        <source>Excluded user groups ( users in these groups do not need to have their content approved )</source>
        <translation>Gruppi esclusi dall'approvazione (gli utenti di questi gruppi non abbisognano di approvazione per i loro contenuti)</translation>
		</message>
    <message>
        <source>User and user groups</source>
        <translation>Utenti e gruppi di utenti</translation>
    </message>
</context>
<context>
    <name>ezxapprove2</name>
    <message>
        <source>Select approver</source>
        <translation type="obsolete">Seleziona utenti per l'approvazione</translation>
    </message>
    <message>
        <source>In approval</source>
        <translation type="obsolete">In attesa di approvazione</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="obsolete">Approvato</translation>
    </message>
    <message>
        <source>Discarded</source>
        <translation type="obsolete">Non approvato</translation>
    </message>
    <message>
        <source>Finnished</source>
        <translation type="obsolete">Concluso</translation>
    </message>
</context>
<context>
    <name>ezxnewsletter</name>
    <message>
        <source>Elements awaiting approval</source>
        <translation type="obsolete">Contenuti in attesa di approvazione</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="obsolete">Inverti selezione.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nome</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="obsolete">Autore</translation>
    </message>
    <message>
        <source>Started</source>
        <translation type="obsolete">Iniziato</translation>
    </message>
    <message>
        <source># Approved</source>
        <translation type="obsolete"># Approvato</translation>
    </message>
    <message>
        <source># Required</source>
        <translation type="obsolete"># Richiesto</translation>
    </message>
    <message>
        <source>Select approval for removal. This will will mark the pending version as archived.</source>
        <translation type="obsolete">Seleziona l'approvazione da rimuovere. La versione in corso di modifica verrà archiviata.</translation>
    </message>
    <message>
        <source>Update approval statuses.</source>
        <translation type="obsolete">Aggiorna lo status delle approvazioni.</translation>
    </message>
    <message>
        <source>Approve List</source>
        <translation type="obsolete">Approva lista</translation>
    </message>
</context>
<context>
    <name>ezxnewslettert</name>
    <message>
        <source>Object ID</source>
        <translation type="obsolete">ID oggetto</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Azione</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval2</source>
        <translation>Approvazione2</translation>
    </message>
    <message>
        <source>Approval v.2</source>
        <translation>Approvazione v.2</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Approve2</source>
        <translation>Approvazione2</translation>
    </message>
</context>
</TS>
