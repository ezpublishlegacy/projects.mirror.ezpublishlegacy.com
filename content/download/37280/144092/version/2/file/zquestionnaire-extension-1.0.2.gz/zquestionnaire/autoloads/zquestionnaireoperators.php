<?php
//
// Definition of eZCategorySelectionUtil class
//
// Created on: <2-Sep-2006 21:00:27 GTM+8>
//
// SOFTWARE NAME: 
// SOFTWARE RELEASE: 
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 ZERUS TECHNOLOGY LTD (http://www.zerustech.com) AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

require_once('lib/ezxml/classes/ezxml.php');
require_once('kernel/classes/ezcontentobject.php');
require_once('extension/ezcategoryselection/autoloads/ezcategoryselectionutiloperators.php');

class ZQuestionnaireOperators{

      var $Operators;

      function ZQuestionnaireOperators(){

	      $this->Operators = array ('questionnaire_result');

      }

      function &operatorList(){

          return $this->Operators;

      }

      function namedParameterPerOperator(){

          return true;

      }

      function namedParameterList(){

	       return array('questionnaire_result'=>array('collection'=>
		                               array('type'=>'array',
			                             'required'=>true,
						     'default'=>0),
				                     'sort'=>
		                               array('type'=>'string',
			                             'required'=>false,
						     'default'=>'desc'),
				                     'limit'=>
		                               array('type'=>'integer',
			                             'required'=>false,
						     'default'=>0)));

      }

      function modify(&$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                      &$currentNamespace, &$operatorValue, &$namedParameters){

               switch($operatorName){

                      case 'questionnaire_result': {

			   $operatorValue = $this->questionnaire_result($namedParameters['collection'],
				                                        $namedParameters['sort'],
                                                                        $namedParameters['limit']);

		      }
		      
		      break;

	       }

      }

      function &questionnaire_result(&$collection,$sort='desc',$limit=false){

	       $questionnaire_result = array();

	       $total_scores = array();

	       $attribute_names = array();

	       $util = new eZCategorySelectionUtil();

               foreach($collection as $attribute){

		       $class_attribute = $attribute->attribute('contentclass_attribute');
		       $class_attribute_id = $attribute->attribute('contentclass_attribute_id');
		       $cross_class = $class_attribute->attribute('data_int2');
		       $data_type_string = $class_attribute->attribute('data_type_string');

		       $class_id = $class_attribute->attribute('contentclass_id');

		       if($data_type_string=="ezcategoryselection" &&
                          $cross_class == 1){

                          $selected_options = explode("-",$attribute->attribute('data_text')); 

			  foreach($selected_options as $option_id){

				  $category_option_values = $util->category_option_values($class_attribute_id,$option_id);

				  //$category_values = $category_option_values['category_value'];

				  foreach($category_option_values as $category_id=>$contents){

					  $category_class_attribute = eZContentClassAttribute::fetch($category_id);

					  $category_class_id = $category_class_attribute->attribute('contentclass_id');

					  //internal categories are ignored for calculating scores
					  //In other words, only external (cross class) categories are used
					  if($category_class_id==$class_id){

					     continue;

					  }

					  $values = $contents['values'];

					  $category_name = $contents['name'];

					  $attribute_names[$category_id] = $category_name;

					  $value = (int)$values[0];

					  if(isset($total_scores[$category_id])){

						  $total_scores[$category_id]+=$value;

					  }else{

						  $total_scores[$category_id]=$value;

					  }

				  }

			  }

		       } 

	       }


	       if($sort=="asc"){

                  asort($total_scores);

	       }else{

	          arsort($total_scores);

	       }

	       $index = 0;

	       foreach($total_scores as $key=>$score){

		       if($limit && $index>=$limit){
			  break;
		       }

		       $questionnaire_result[$key]['name']=$attribute_names[$key];

		       $questionnaire_result[$key]['score']=$score;

		       $index++;

		       $thresholds = $util->thresholds($key);

		       $description = $thresholds[0];

		       foreach($thresholds as $threshold_score=>$threshold_description){

			       if($score<=$threshold_score){

				       $description = $threshold_description;

				       break;

			       }

		       }

		       $questionnaire_result[$key]['description']=$description;

	       }

	       return $questionnaire_result;

      }

}

?>
