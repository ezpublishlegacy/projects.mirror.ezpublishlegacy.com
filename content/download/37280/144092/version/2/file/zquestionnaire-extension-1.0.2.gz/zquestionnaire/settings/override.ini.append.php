<?php /* #?ini charset="iso-8859-1"?

#copy this rule to override.ini.append.php of user site accesses
#[full_questionnaire]
#Source=node/view/full.tpl
#MatchFile=full/questionnaire.tpl
#Subdir=templates
##Match[parent_node]=<PARENT_NODE_ID>

#copy this rule to override.ini.append.php of user site accesses
#[questionnaire_result]
#Source=content/collectedinfo/form.tpl
#MatchFile=content/collectedinfo/questionnaire.tpl
#Subdir=templates
#Match[parent_node]=<PARENT_NODE_ID>

#copy this rule to override.ini.append.php of admin site accesses
#[questionnaire_result]
#Source=content/collectedinfo/form.tpl
#MatchFile=content/collectedinfo/questionnaire.tpl
#Subdir=templates
#Match[parent_node]=<PARENT_NODE_ID>

*/ ?>
