<?php
/*

[ExtensionSettings]
DesignExtensions[]=zquestionnaire

*/
?>
