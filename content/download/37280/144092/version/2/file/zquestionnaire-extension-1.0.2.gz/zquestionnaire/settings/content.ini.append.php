<?php
/*
[ContentOverrideSettings]
# Set this to true if you would like to do an override
# based on the class group of the content
EnableClassGroupOverride=true
*/
?>
