<?php
/*

[TemplateSettings]
ExtensionAutoloadPath[]=zquestionnaire

*/
?>
