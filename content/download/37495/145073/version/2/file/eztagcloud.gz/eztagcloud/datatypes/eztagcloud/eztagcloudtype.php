<?php
//
// eztagcloud.php
//
// COPYRIGHT NOTICE: Copyright (C) 2007 CommonPlaces eSolutions, Inc.
//      http://www.commonplaces.com
// AUTHOR: Betsy Gamrat
// VERSION: 0.7
// CREATED: 7 August 2007
//

/*!
  \class   eztag cloudtype eztag cloudtype.php
  \ingroup eZDatatype
  \brief   Handles the datatype tag cloud. By using tag cloud you can enter a list of words or phrases and see a tag cloud of them, with links into the system.

*/

include_once( "extension/eztagcloud/common/constants.php");
include_once( "kernel/classes/datatypes/eztext/eztexttype.php");

class eztagcloudtype extends eZTextType
{
    /*!
      Constructor
    */
    function eztagcloudtype()
    {
        $this->eZDataType( EZ_DATATYPESTRING_TAGCLOUD, ezi18n( 'kernel/classes/datatypes', "Tag cloud", 'Datatype name' ),  array('translation_allowed'=>false));
    }

    /*!
     \return true if the datatype can be indexed
    */
    function isIndexable()
    {
        return true;
    }

    /*!
     \return true if the data type can do information collection
    */
    function hasInformationCollection()
    {
        return false;
    }

    /*!
     \return true if the datatype can be used as an information collector
    */
    function isInformationCollector()
    {
        return false;
    }
}

eZDataType::register( EZ_DATATYPESTRING_TAGCLOUD, "eztagcloudtype" );
?>
