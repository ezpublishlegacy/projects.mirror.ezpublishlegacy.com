<?php /*
[ExtensionSettings]
DesignExtensions[]=eztagcloud
*/ ?>

