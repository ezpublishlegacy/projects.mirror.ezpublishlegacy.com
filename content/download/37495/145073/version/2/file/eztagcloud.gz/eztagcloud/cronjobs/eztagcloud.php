<?php
//
// eztagcloud.php
//
// COPYRIGHT NOTICE: Copyright (C) 2007 CommonPlaces eSolutions, Inc.
//      http://www.commonplaces.com
// AUTHOR: Betsy Gamrat
// VERSION: 0.7
// CREATED: 7 August 2007
//
// This code creates tagcloud templates to support the tagcloud datatypes.
//
// Create a link to this file from the cronjobs directory.
//
// Run from commandline, with php -C 
// 


//init shell script
include_once( 'lib/ezutils/classes/ezmodule.php' );
include_once( 'lib/ezutils/classes/ezcli.php' );
include_once( 'kernel/classes/ezsearch.php' );


if (!isset($script))
{
        include_once( 'kernel/classes/ezscript.php' );
        $script =& eZScript::instance( array( 'debug-message' => true,
                                      'use-session' => true,
                                      'use-modules' => true,
                                      'use-extensions' => true ) );
        $script->startup();
        $script->initialize();
        $standalone=true;
}
else
        $standalone=false;

if (!isset($cli))
{
        $cli =& eZCLI::instance();
        $cli->setUseStyles( true ); // enable colors
}

// Check for extension
include_once( 'lib/ezutils/classes/ezextension.php' );
include_once( 'kernel/common/ezincludefunctions.php' );
eZExtension::activateExtensions();
// Extension check end

require_once( "extension/eztagcloud/common/constants.php");

if ( !$isQuiet )
{
    $cli->output( "Starting",true);
}

$cli->output(EZ_DATATYPESTRING_TAGCLOUD);

include_once( 'lib/ezdb/classes/ezdb.php' );
$contentObjects = array();
$db =& eZDB::instance();

$offset = 0;
$limit = 50;

define ('SPAN',0);
define ('TAG',1);
define ('TAGCOUNT',2);

$patterns[SPAN]='/_SPAN_/';
$patterns[TAG]='/_TAG_/';
$patterns[TAGCOUNT]='/_TAGCOUNT_/';

$template_dirname='extension/eztagcloud/design/standard/templates/content/datatype/view/';
$master_template=$template_dirname.MASTER_TEMPLATE;
$master_template=file_get_contents($master_template);

/* Clean up any generated templates.  Generated template names are prefixed with _ (underscore) */
$d=dir($template_dirname);
while (false !== ($entry = $d->read())) {
   if ($entry[0]=='_')
	unlink($d->path.$entry);
}
$d->close();

while( true )
{
    $tag_clouds = $db->arrayQuery( "SELECT data_text,id,version FROM ezcontentobject_attribute WHERE data_type_string = '".
				EZ_DATATYPESTRING_TAGCLOUD."'",
                                array( 'limit' => $limit,
                                       'offset' => $offset ) );
   
    if ( is_array( $tag_clouds ) && count( $tag_clouds ) != 0 )
    {
	$offset += count($tag_clouds);
        foreach ( $tag_clouds as $tag_cloud )
        {
	    if (trim($tag_cloud['data_text'])!='')
	    {
	            $template_name='_tagcloud_'.$tag_cloud['id'].'_'.$tag_cloud['version'].'.tpl';
		    $tag_array=explode("\r\n",$tag_cloud['data_text']);
		    shuffle($tag_array);
		    $outhtml='{* *** GENERATED TEMPLATE *** DO NO MODIFY *** *}'."\n";
		    $outhtml.='{* Change '.MASTER_TEMPLATE.' instead *}'."\n";
		    foreach ($tag_array as $tag)
		    {
			$searchResult=eZSearch::search($tag);
			$sc=$searchResult['SearchCount'];
			if ($sc < 100)
				if ($sc > 25)
					$span_class=(int)$sc - ($sc % 25);
				else
					$span_class='25';
			else
				$span_class=(int)$sc - ($sc % 100);

			$replacements[SPAN]=$span_class;
			$replacements[TAG]=$tag;
			$replacements[TAGCOUNT]=$sc;
			$outhtml.=preg_replace($patterns,$replacements,$master_template);
		    }
		    $ofp=fopen($template_dirname.$template_name,'w');
		    fwrite($ofp,$outhtml);
		    fclose($ofp);
	    }
        }
    }
    else
    {
        break; // No valid result
    }
}

if ( !$isQuiet )
{
    $cli->output( "Done",true );
}

if ($standalone)
        $script->shutdown();
?>
