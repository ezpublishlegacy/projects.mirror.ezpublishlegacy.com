<?php
//
// constants.php
//
// COPYRIGHT NOTICE: Copyright (C) 2007 CommonPlaces eSolutions, Inc.
//      http://www.commonplaces.com
// AUTHOR: Betsy Gamrat
// VERSION: 0.7
// CREATED: 7 August 2007
//
// Defines common constants to support eZ tag cloud datatype and cronjob

define( 'EZ_DATATYPESTRING_TAGCLOUD','eztagcloud' );
define( 'MASTER_TEMPLATE','eztagcloud_master.tpl');
?>
