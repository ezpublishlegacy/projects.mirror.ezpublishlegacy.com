<?php /*
[DataTypeSettings]
ExtensionDirectories[]=eztagcloud
AvailableDataTypes[]=eztagcloud
*/ ?>

