<?php
//Auteur : Yannick Komotir

class eZLessCss
{

    function __construct()
    {
        //vide
    }
    
    static function lesscssfy( $cssFile )
    {
        
    }

}

?>