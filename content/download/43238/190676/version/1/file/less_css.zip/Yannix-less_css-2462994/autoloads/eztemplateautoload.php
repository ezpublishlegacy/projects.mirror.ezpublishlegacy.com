<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/less_css/autoloads/simplelesscssoperator.php',
                                    'class' => 'SimpleLessCssOperator',
                                    'operator_names' => array( 'lesscss' ) 
                                   );

?>