/*
* File Name: nodePath\fckPlugin.js
*
* Licensed under the terms of the GNU Lesser General Public License:
* 		http://www.opensource.org/licenses/lgpl-license.php
*
*	Plugin for FCKeditor that shows a status bar with the path to the current selected node
*	Users can click a path node to select it.
*
*  version 0.1 12/11/2005
*		-initial release, just a nice status bar.
*  version 0.2 21/03/2006
*		-extended release, with the ability to select elements from notelist.
*  version 0.3 29/04/2006
*		-improved StatusBar to make it a self contained class, so that it can be extended
		easily to add functions, and more documentation
*
*
* File Authors:
*		Alfonso Martínez de Lizarrondo (Uritec) alfonso -at- uritec dot net
*		Holger Hees hhees -at- systemconcept dot de
*		liuspider -at- users dot sourceforge dot net
*/

var FCKStatusBar = function () {
    //Create the status bar

    var table = this.getFCKeditorTable();
    if(!table)
        return;

    //Create the container to hold the node path
    var tr=table.insertRow(-1);
    var td=tr.insertCell(-1);
    td.className='statusbarTD';
    td.innerHTML='<table class="layout"><tbody><tr><td width=95%><table class="layout"><tbody><tr><td></td><td></td></tr></tbody></table></td> \
    <td><span class="editorName statusbarSection"><a href="http://sf.net/projects/sjsd" target="_blank" class="" >SJSD Editor</a></span></td></tr></tbody></table>';

    //these properties can be customized
    var innerTD = td.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild;
    innerTD.firstChild.innerHTML='<div class="statusbarSection">FCKStatusBar is successfully loaded!</div>';
    innerTD.childNodes[1].innerHTML='<div style="display: none;" class="statusbarSection"></div>';
    this._PathContainer = innerTD.firstChild.firstChild;
    this._SingleLineHeight = this._PathContainer.offsetHeight;
    this._ExtraInfoContainer = innerTD.childNodes[1].firstChild;
    this._PathPrefix = "Current Node: ";
    this._PathSuffix = "";
    this._PathNodeSeperator = '&nbsp;&raquo;&nbsp;';

    //DO NOT TOUCH any variables below
    //_SbNode stores the currently selected node
    this._SbNode = null;

    this._pageYOffset = 0;
}

FCKStatusBar.prototype.getFCKeditorTable = function() {
    var table=document.body.firstChild;
    while (table.nodeName!='TABLE') {
        table=table.nextSibling
    }
    if(!table)
    {
        alert("Error: can not find the table which contain the FCKeditor!");
    }
    return table;
}

FCKStatusBar.prototype.update = function() {
    var node;
    var text='&nbsp;'; // + FCKSelection.GetType() + " " + new Date();

    var isDeepest=true;
    //the selected node (not valid if nothing is selected)
    node=FCKSelection.GetSelectedElement();
    if (node) {
        text=this.getNodeName(node, isDeepest) + text;
        isDeepest=false;
    }

    var i=0;
    //parent, up to the body
    node=FCKSelection.GetParentElement();
    this._SbNode=node;
    while (node && node.nodeName!='BODY') {
        if(!isDeepest) text = this._PathNodeSeperator + text;

        text='<a href="javascript:oStatusBar.selectSBElement('+i+')" onmouseover="oStatusBar.getEditorOffset();">' +
            this.getNodeName(node, isDeepest)+'</a>' + text;
        node=node.parentNode;
        isDeepest=false;
        i++;
    }

    //update the text
    this._PathContainer.innerHTML=this._PathPrefix+text+this._PathSuffix;

    if(this.PostUpdate)
        this.PostUpdate()
}

//when click on a node, the EditorWindow will be scrolled to the top
//so we have to save it first
FCKStatusBar.prototype.getEditorOffset = function(){
    this._pageYOffset = FCK.EditorWindow.pageYOffset;
//     alert(this._pageYOffset);
}

FCKStatusBar.prototype.selectSBElement = function(pos){
    if(this._SbNode){
        node=this._SbNode;
        for(i=0;i<pos;i++){
            node=node.parentNode;
        }
        FCKSelection.SelectNode(node);

        ensureVisible(node, FCK.EditorWindow, this._pageYOffset);

        FCK.Events.FireEvent( "OnSelectionChange" );
    }
}

function ensureVisible(el, _window, origPageYOffset){
    var c = FCKTools.GetElementPosition(node, FCK.EditorWindow);
    if(origPageYOffset > c.Y)
    {
        el.scrollIntoView(false);
    } else if(origPageYOffset + _window.innerHeight< c.Y)
    {
        el.scrollIntoView(false);
    } else
        _window.scrollTo( 0, origPageYOffset );
}

//Overwrite this function to customize the name of a tag
FCKStatusBar.prototype.getNodeName = function(oTag) {
    var oRealTag;
    if (!oTag)
        return "";

    if (oTag.getAttribute('_fckfakelement') )
        oRealTag = FCK.GetRealElement( oTag ) ;
    else
        oRealTag=oTag;

    var sTagName=oRealTag.nodeName.toLowerCase();

    var name=sTagName;

    return name;
}

var eZStatusBar = function () {
    this._PathContainer.innerHTML = "SJSD StatusBar is successfully loaded"
    this._PathPrefix = "";
};
// Inherit from StatusBar
eZStatusBar.prototype = new FCKStatusBar;

//overwrite getNodeName
eZStatusBar.prototype.getNodeName = function(oTag, isDeepest) {
    if(!oTag)
    {
        alert('Failed to get node tag name');
        return 'Unknown';
    }
    var oRealTag;
    if (oTag.getAttribute('_fckfakelement') )
        oRealTag = FCK.GetRealElement( oTag ) ;
    else
        oRealTag = oTag;

    var tagName = oRealTag.nodeName.toLowerCase();

    var showExtra = false;
    switch(tagName)
    {
        case 'h1':
        case 'h2':
        case 'h3':
        case 'h4':
        case 'h5':
        case 'h6':
            showExtra = true;
            this._ExtraInfoContainer.innerHTML = "Level is " +tagName.charAt(1)+"";
            tagName = 'header';
            break;
        case 'div':
        case 'span':
            //TODO: show custom attributes
            var isvalid = true;
            if(oRealTag.id == undefined)
            {
                isvalid = false;
            } else
            {
                var id = oRealTag.id.toLowerCase();
                if(id.startsWith('custom_'))
                {
                    tagName = id.substr(7);
                }else
                    isvalid = false;
            }
            if(!isvalid)
            {
                alert("Detected unknown tag '"+tagName+"', removed.");
                FCKTools.RemoveOuterTags(oRealTag);
            } else
                tagName = id.substr(7);
            break;
        case 'img':
            //TODO: show custom attributes
            tagName = "embed";
            break;
        case 'pre':
            tagName = "literal";
            break;
        case 'a':
            showExtra = true;
            if(oRealTag.childNodes.length == 0)
            {
                tagName = 'anchor';
                this._ExtraInfoContainer.innerHTML = "Anchor Name is '" +oRealTag.getAttribute('name') +"'";
            } else
            {
                tagName = 'link';
                //TODO: check the validation of the href and anchor
                _href=  oRealTag.getAttribute('href');
                this._ExtraInfoContainer.innerHTML = 'Link to <a href="'+_href+'" target="_blank">'+_href+'</a>';
            }
            break;
        default:
    }

    if(isDeepest)
    {
        this._ExtraInfoContainer.style.display = showExtra ? '' : 'none';
    }
    return tagName;
}

eZStatusBar.prototype.PostUpdate = function()
{
    if(this._ExtraInfoContainer.style.display != 'none')
    {
        if(this._ExtraInfoContainer.offsetHeight > this._SingleLineHeight)
        {
	    var title;
	    if(this._ExtraInfoContainer.textContent)
	        title = this._ExtraInfoContainer.textContent;
	    else
	        title = this._ExtraInfoContainer.innerHTML.replace(/<[^>]*>/g, '');
            this._ExtraInfoContainer.innerHTML = '<span title="'+title+'">...</span>';
        }
    }
}

var oStatusBar=new eZStatusBar();

function findNodePath()
{
    oStatusBar.update();
}

FCK.Events.AttachEvent( 'OnSelectionChange', findNodePath ) ;
