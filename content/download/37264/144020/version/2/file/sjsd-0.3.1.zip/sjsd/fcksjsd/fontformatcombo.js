//custom FCKToolbarFontFormatCombo to get rid of the label
var EZFontFormatCombo = function( tooltip, style )
{
        this.Command    = FCKCommands.GetCommand( 'FontFormat' ) ;
        this.Label              = this.GetLabel() ;
        this.Tooltip    = tooltip ? tooltip : this.Label ;
        this.Style              = style ? style : FCK_TOOLBARITEM_ICONTEXT ;

        this.NormalLabel = 'Normal' ;

        this.PanelWidth = 190 ;
}

// Inherit from FCKToolbarSpecialCombo.
EZFontFormatCombo.prototype = new FCKToolbarSpecialCombo ;

EZFontFormatCombo.prototype.GetLabel = function()
{
    return '';//FCKLang.FontFormat ;
}

EZFontFormatCombo.prototype.CreateItems = function( targetSpecialCombo )
{
        // Get the format names from the language file.
        var aNames = FCKLang['FontFormats'].split(';') ;
        var oNames = {
                p               : aNames[0],
                pre             : aNames[1],
                address : aNames[2],
                h1              : aNames[3],
                h2              : aNames[4],
                h3              : aNames[5],
                h4              : aNames[6],
                h5              : aNames[7],
                h6              : aNames[8],
                div             : aNames[9]
        } ;

        // Get the available formats from the configuration file.
        var aTags = FCKConfig.FontFormats.split(';') ;

        for ( var i = 0 ; i < aTags.length ; i++ )
        {
                // Support for DIV in Firefox has been reintroduced on version 2.2.
//              if ( aTags[i] == 'div' && FCKBrowserInfo.IsGecko )
//                      continue ;

                var sTag        = aTags[i] ;
                var sLabel      = oNames[sTag] ;

                if ( sTag == 'p' )
                        this.NormalLabel = sLabel ;

                this._Combo.AddItem( sTag, '<div class="BaseFont"><' + sTag + '>' + sLabel + '</' + sTag + '></div>', sLabel ) ;
        }
}

var oEZFormatCombo = new EZFontFormatCombo() ;
FCKToolbarItems.RegisterItem( 'EZ_Format', oEZFormatCombo ) ;