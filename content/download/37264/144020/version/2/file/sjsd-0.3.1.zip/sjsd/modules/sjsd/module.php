<?php


$Module = array( 'name' => 'sjsd' );

$ViewList = array();

$ViewList['xmlhttp'] = array(
    'functions' => array( 'read' ),
    'script' => 'xmlhttp.php',
    'params' => array( 'Func' ),
    'default_navigation_part' => 'ezsetupnavigationpart');
$ViewList['browse'] = array(
    'functions' => array( 'read' ),
    'script' => 'browse.php',
    'params' => array( 'ActionName' ),
    'default_navigation_part' => 'ezcontentnavigationpart');
$ViewList['upload'] = array(
    'functions' => array( 'create' ),
    'default_navigation_part' => 'ezcontentnavigationpart',
    'script' => 'upload.php',
    'single_post_actions' => array( 'UploadFileButton' => 'UploadFile',
                                    'CancelUploadButton' => 'CancelUpload' ),
    'post_action_parameters' => array( 'UploadFile' => array( 'UploadLocation' => 'UploadLocationChoice' ) ),
    'params' => array('ObjectID', 'EditVersion', 'EditLanguage') );
?>
