var oEditor		= window.parent.InnerDialogLoaded() ;
var FCK			= oEditor.FCK ;
var FCKTools    = oEditor.FCKTools ;
var FCKConfig	= oEditor.FCKConfig ;
var fckPage		= oEditor.parent.window;

var EZInfo 		= fckPage.EZInfo;
var CustomTags  = EZInfo.CustomTags;

var FCKDebug	= oEditor.FCKDebug ;

window.onload = function Init(){
    document.getElementsByTagName('body')[0].style.display = '';
    //add popup stylesheet:
    var FCKTools = oEditor.FCKTools ;
    FCKTools.AppendStyleSheet( document, EZInfo['WWWRoot']+'design/admin/stylesheets/core.css' ) ;
    FCKTools.AppendStyleSheet( document, EZInfo['WWWRoot']+'design/admin/stylesheets/site.css' ) ;
    FCKTools.AppendStyleSheet( document,
        EZInfo['WWWRoot']+'extension/sjsd/design/standard/stylesheets/sjsd/popup.css' ) ;

    //TODO Handle sub/sup etc
    // Get the custom tag div/span
    //TODO: copied from fcksjsd/contextmenu.js, see there
    var oTag = FCKTools.GetElementAscensor(FCK.Selection.GetParentElement(),'SPAN,DIV');
    if(!oTag) //in IE, it does not return the node, we try it another way
    {
        oTag = FCK.Selection.MoveToAncestorNode('SPAN');
        if(!oTag)
            oTag = FCK.Selection.MoveToAncestorNode('DIV');
    }


    if(oTag && !oTag.id.toLowerCase().startsWith('custom_'))
        oTag = null;
    if(!oTag)
    {
        alert('Error: can not find a custom tag!');
        return;
    }

    while(oTag)
    {
        if(oTag.id.toLowerCase().startsWith('custom_'))
        {
            var customtagname = oTag.id.toLowerCase().substr(7) ;
            FCKTools.AddSelectOption(window.document, GetE('customTagName'), customtagname, customtagname);
        }
        oTag = FCKTools.GetElementAscensor(oTag.parentNode,'SPAN,DIV');
    }

    window.parent.SetAutoSize( true ) ;
    // Activate the "OK" button.
    window.parent.SetOkButton( true ) ;
    changeType();
}

function Ok(){
    var oTag = findCustomTag();
    if(!oTag)
    {
        alert("Can not find custom tag '"+customTagName+"'");
        return;
    }

    //remove all existing attribute
    for(var i=0;i<oTag.attributes.length;++i)
    {
        oTag.attributes.removeNamedItem(oTag.attributes[i].name);
    }
    var customTagName = document.getElementById("customTagName").value;
    oTag.setAttribute('id', 'custom_'+customTagName);
    var CustomAttributeName = document.getElementsByName("CustomAttributeName");
    if ( CustomAttributeName.length != null )
    {
        var CustomAttributeValue = document.getElementsByName("CustomAttributeValue");
        var customAttributes = new Array();
	    if ( CustomAttributeName.length != null )
	    {
	       for (var i=0;i<CustomAttributeName.length;i++)
	        {
                oTag.setAttribute(CustomAttributeName[i].value, CustomAttributeValue[i].value);
	        }
        }
//         else
//         {
//             customAttributes[0]=CustomAttributeName.value + "|" + CustomAttributeValue.value;
//         }
//         customTagParameters["customAttributes"] = customAttributes;
    }
//     opener.addCustomTag( editorID, customTagParameters );
//     window.close();
    return true;
}

function checkDuplicate( tagname )
{
    var res = false;
    var CustomAttributeName = document.getElementsByName("CustomAttributeName");
    if ( CustomAttributeName.length != null )
    {
        var CustomAttributeValue = document.getElementsByName("CustomAttributeValue");
        if ( CustomAttributeName.length != null )
        {
            for (var i=0;!res && i<CustomAttributeName.length;i++)
            {
                if(CustomAttributeName[i].value == tagname)
                    res = true;
            }
        }
//         else
//         {
//             customAttributes[0]=CustomAttributeName.value + "|" + CustomAttributeValue.value;
//         }
//         customTagParameters["customAttributes"] = customAttributes;
    }
    return res;
}

function clearTable()
{
    var table = GetE("attributes");

    while(table.rows.length > 1)
        table.deleteRow(1) ;

    GetE('noattributes').style.display="";
    GetE('attributes').style.display="none";
}

function getAttributes( oTag, customtagname )
{
    var attributeArray = oTag.attributes;
    var attrs = EZInfo['CustomTags'][customtagname]['attributes'];
    var isRequiredMap = new Object;
    if(typeof(attrs) == 'object')
    {
        for(var i in attrs)
        {
            var att = attrs[i];
            isRequiredMap[att['name']] = att['isRequired'];
        }
    }

    for (var i=0;i<attributeArray.length;i++)
    {
        var attr = attributeArray[i];
        if(attr.nodeName.toLowerCase() != 'id' && !attr.nodeName.startsWith('_moz_'))
            if(attr.specified == undefined || attr.specified) //IE lists all attributes, even default ones, filter them
                addAttribute( attr.nodeName, attr.nodeValue, isRequiredMap[attr.nodeName] )
    }
}

function addNew(){
    addAttribute('', '', false);
}

function addAttribute( attrName, attrValue, required ){
    if(checkDuplicate(attrName))
        return;

    var tbody = document.getElementById("attributes").getElementsByTagName("tbody")[0];
    var row1 = tbody.insertRow(-1);
    var td1 = document.createElement("td");
//     if(!required)
    {
        var checkbox1 = document.createElement("input");
        checkbox1.setAttribute( 'name', 'Selected_attribute' );
        checkbox1.setAttribute( 'id', 'Selected_attribute' );
        if(required)
            checkbox1.setAttribute( 'type', 'hidden' );
        else
            checkbox1.setAttribute( 'type', 'checkbox' );
        td1.appendChild(checkbox1);
    }
    var td2 = document.createElement("td");
    var input1 = document.createElement("input");
    input1.setAttribute( 'name', 'CustomAttributeName' );
    input1.setAttribute( 'id', 'CustomAttributeName' );
    input1.setAttribute( 'type', 'text' );
    input1.setAttribute( 'size', '10' );
    if(required)
        input1.setAttribute( 'readOnly', true );
    input1.value = attrName;
    td2.appendChild(input1);
    var td3 = document.createElement("td");
    var input2 = document.createElement("input");
    input2.setAttribute( 'name', 'CustomAttributeValue' );
    input2.setAttribute( 'id', 'CustomAttributeValue' );
    input2.setAttribute( 'type', 'text' );
    input2.setAttribute( 'size', '10' );
    input2.value = attrValue;
    td3.appendChild(input2);
    row1.appendChild(td1);
    row1.appendChild(td2);
    row1.appendChild(td3);
    GetE('noattributes').style.display="none";
    GetE('attributes').style.display="";
}

function removeSelected(){
    var table = document.getElementById("attributes");
    var tbody = table.getElementsByTagName("tbody")[0];
    var attributeTitle = document.getElementById("attributeTitle");
    var CustomAttributeName = document.getElementsByName("CustomAttributeName");
    var Selected_attribute = document.getElementsByName("Selected_attribute");
//     var lastPropertyRow = document.getElementById("lastPropertyRow");
    if (  CustomAttributeName.length != null )
    {
        if ( Selected_attribute.length != null )
        {
            var deleteArray = new Array();
            var deleteArrayIndex = 0;
            for (var i=0;i<Selected_attribute.length;i++)
            {
                if ( Selected_attribute[i].checked == true )
                {                    deleteArray[deleteArrayIndex] = i;
                    deleteArrayIndex++;
                }
            }
            var baseIndex = 1;
            for (var j=0;j<deleteArray.length;j++)
            {
                rowIndex = baseIndex + deleteArray[j];
                table.deleteRow(rowIndex);
                baseIndex--;
            }
        }
        else
        {
            if ( Selected_attribute.checked == true )
                table.deleteRow(1);
        }
        if ( CustomAttributeName.length == 0 )
        {
            GetE('noattributes').style.display="";
            GetE('attributes').style.display="none";
        }
    }
}

function findCustomTag()
{
    var customTagName = document.getElementById("customTagName").value;
    if(EZInfo['CustomTags'][customTagName] == undefined)
    {
        alert('Error: ' + customTagName + " is not a registered custom tag");
        return;
    }

    //TODO: copied from fcksjsd/contextmenu.js, see there
    var oTag = FCKTools.GetElementAscensor(FCK.Selection.GetParentElement(),'SPAN,DIV');
    if(!oTag) //in IE, it does not return the node, we try it another way
    {
        oTag = FCK.Selection.MoveToAncestorNode('SPAN');
        if(!oTag)
            oTag = FCK.Selection.MoveToAncestorNode('DIV');
    }

    while(oTag && oTag.id.toLowerCase() != 'custom_' + customTagName)
        oTag = FCKTools.GetElementAscensor(oTag.parentNode,'SPAN,DIV');

    return oTag;
}

function changeType(){
    clearTable();

    var customTagName = document.getElementById("customTagName").value;
    var oTag = findCustomTag();
    if(!oTag)
    {
        alert("Can not find custom tag '"+customTagName+"'");
        return;
    }

    getAttributes(oTag, customTagName);

    var attrs = EZInfo['CustomTags'][customTagName]['attributes'];
//     alert(attrs.toString());
    if(typeof(attrs) == 'object')
    {
        for(var i in attrs)
        {
            var att = attrs[i];
            addAttribute(att['name'], '', att['isRequired']);
        }
    }else if(attrs != undefined)
        alert('Attributes for custom tag '+customTagName+' is not recognized.');
}
