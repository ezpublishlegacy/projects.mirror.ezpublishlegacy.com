<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/sjsd/autoloads/template_sjsd_operator.php',
                                    'class' => 'TemplateSJSDOperator',
                                    'operator_names' => array( 'sjsd_get_customtag_settings') );
?>
