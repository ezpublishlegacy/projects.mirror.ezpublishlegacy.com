/* $Id: fckplugin.js 131 2006-05-11 15:17:15Z liuspider $ */

var EZInfo = window.parent.window.EZInfo;
FCKScriptLoader.AddScript(EZInfo['WWWRoot']+"extension/sjsd/fcksjsd/contextmenu.js");
FCKScriptLoader.AddScript(EZInfo['WWWRoot']+"extension/sjsd/fcksjsd/fontformatcombo.js");
FCKScriptLoader.AddScript(EZInfo['WWWRoot']+"extension/sjsd/fcksjsd/customtag.js");
FCKScriptLoader.AddScript(EZInfo['WWWRoot']+"extension/sjsd/fcksjsd/nodepath.js");

SJSD_VERSION = "0.3.1";
SJSD_REVISION = "$Revision: 131 $";

// Register the related commands.
FCKCommands.RegisterCommand( 'EZ_Source'   , new FCKDialogCommand( 'EZ_Source', FCKLang['DlgEZSourceTitle']  , FCKConfig.PluginsPath + 'fcksjsd/dialog/ez_source.html', 500, 400 ) ) ;
FCKCommands.RegisterCommand( 'EZ_Embed'   , new FCKDialogCommand( 'EZ_Embed', FCKLang['DlgEZEmbedTitle']  , FCKConfig.PluginsPath + 'fcksjsd/dialog/ez_embed.html', 500, 400 ) ) ;
FCKCommands.RegisterCommand( 'EZ_Link'   , new FCKDialogCommand( 'EZ_Link', FCKLang['DlgEZLinkTitle']  , FCKConfig.PluginsPath + 'fcksjsd/dialog/ez_link.html', 500, 400 ) ) ;

// Create the "EZ_Source" toolbar button.
var oEZSource      = new FCKToolbarButton( 'EZ_Source', FCKLang['DlgEZSourceTitle'] ) ;
//oEZSource.IconPath  = FCKConfig.SkinPath + 'toolbar/ez_source.gif' ;

FCKToolbarItems.RegisterItem( 'EZ_Source', oEZSource );

// Create the "EZ_Embed" toolbar button.
var oEZEmbed      = new FCKToolbarButton( 'EZ_Embed', FCKLang['DlgEZEmbedTitle'] ) ;
//oEZEmbed.IconPath  = FCKConfig.SkinPath + 'toolbar/ez_embed.gif' ;

FCKToolbarItems.RegisterItem( 'EZ_Embed', oEZEmbed );

// Create the "EZ_Link" toolbar button.
var oEZLink      = new FCKToolbarButton( 'EZ_Link', FCKLang['DlgEZLinkTitle'] ) ;
//oEZLink.IconPath  = FCKConfig.SkinPath + 'toolbar/ez_link.gif' ;

FCKToolbarItems.RegisterItem( 'EZ_Link', oEZLink );
