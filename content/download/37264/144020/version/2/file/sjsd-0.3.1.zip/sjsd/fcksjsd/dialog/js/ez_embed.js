var oEditor		= window.parent.InnerDialogLoaded() ;
var FCK			= oEditor.FCK ;
var FCKConfig	= oEditor.FCKConfig ;
var fckPage		= oEditor.parent.window;
var oHttpRequest = new fckPage.FCKXml;
var EZInfo 		= fckPage.EZInfo;
var FCKDebug	= oEditor.FCKDebug ;

var CurrentEZItemObjectID	= fckPage.CurrentEZItem['EZObjectID'];
var CurrentEZItemVersion	= fckPage.CurrentEZItem['EZVersion'];
var CurrentEZItemEZLanguage	= fckPage.CurrentEZItem['EZLanguage'];

var bImageButton = ( document.location.search.length > 0 && document.location.search.substr(1) == 'ImageButton' ) ;

// Get the selected image (if available).
var oImage = FCK.Selection.GetSelectedElement() ;
var presel_objectID = "";
if ( oImage && oImage.tagName != 'IMG' && !( oImage.tagName == 'INPUT' && oImage.type == 'image' ) )
    oImage = null ;

// var FCKLang		= oEditor.FCKLang ;

window.onload=function Init(){
    //add popup stylesheet:
    var FCKTools = oEditor.FCKTools ;
    FCKTools.AppendStyleSheet( document, EZInfo['WWWRoot']+'design/admin/stylesheets/core.css' ) ;
    FCKTools.AppendStyleSheet( document, EZInfo['WWWRoot']+'design/admin/stylesheets/site.css' ) ;
    FCKTools.AppendStyleSheet( document,
        EZInfo['WWWRoot']+'extension/sjsd/design/standard/stylesheets/sjsd/popup.css' ) ;

    var customAttributes = -1;
    var objectSrc = "";
    var imageExist = false;
    // Translate the dialog box texts.
    oEditor.FCKLanguageManager.TranslatePage(document) ;

    hideAllRelationTables();
    document.getElementById('loading').style.display = '';

    //load property list
    if(fckPage.ObjectSizes == undefined || fckPage.ObjectSizes.length ==0 ||
        fckPage.ObjectClasses == undefined || fckPage.ObjectClasses.length ==0)
    {
        document.getElementById('loading').style.display = '';
        var url = EZInfo['FCKEditorXMLHttp'] + "/GetObjectPropertyOptionList";
        oHttpRequest.LoadJSONUrl(url, false);
        if(oHttpRequest.CheckJSONError( oHttpRequest ) != 0 )
            alert('Can not read out property options!');

        fckPage.ObjectSizes = oHttpRequest.JSON.Sizes;
        fckPage.ObjectClasses = oHttpRequest.JSON.Classes;
    }

    var objsizesel = GetE('ContentObjectSize');
    for ( var i in fckPage.ObjectSizes)
    {
        var e = document.createElement('OPTION');
        e.value = fckPage.ObjectSizes[i];
        e.innerHTML = fckPage.ObjectSizes[i];
        objsizesel.appendChild(e);
    }

    objsizesel = GetE('ObjectClass');
    for ( var i in fckPage.Classes)
    {
        var e = document.createElement('OPTION');
        e.value = fckPage.Classes[i];
        e.innerHTML = fckPage.Classes[i];
        objsizesel.appendChild(e);
    }

    //load object parameters
    if(oImage != null)
    {
        var altdecoded = oImage.getAttribute('alt').replace(/&amp;/g, '&');
        altdecoded = altdecoded.replace(/&lt;/g, '<');
        altdecoded = altdecoded.replace(/&tt;/g, '>');
        altdecoded = altdecoded.replace(/&quot;/g, "\"");
        var attrs = JSON.parse(altdecoded);
        presel_objectID = parseInt(attrs.object_id);
        if(isNaN(presel_objectID))
        {
            if(attrs.href.startsWith('ezobject://'))
                presel_objectID = parseInt(attrs.href.substr(11));
        }
        if(isNaN(presel_objectID))
            alert("object_id is empty!");
        document.getElementById("ContentObjectAlignment").value = attrs.align;
        document.getElementById("ContentObjectSize").value = attrs.size;
        if(attrs['class'] != null && attrs['class'] != undefined && attrs['class'].length > 0)
            document.getElementById("ObjectClass").value = attrs['class'];
        document.getElementById("ObjectView").value = attrs.view;
        if(attrs['id'] != undefined)
            document.getElementById("HtmlID").value = attrs['id'];

        changeView();

        var custom = attrs.Custom;
        for(var i in custom)
            addAttribute(i, custom[i]);
// 		alert(attrs.size);
    }

    retrieveRelationList();

    var aos = GetE('all_objects');
    if (aos.addEventListener){
        aos.addEventListener('click', changeObject, false); 
    } else if (aos.attachEvent){
        aos.attachEvent('onclick', changeObject);
    }

    // Activate the "OK" button.
    window.parent.SetOkButton( true ) ;
}

function changeView(){
    var view = GetE('ObjectView').value;
    var isInlineCheckbox =  GetE('isInlineCheckbox');
    var ContentObjectAlignment = GetE('ContentObjectAlignment');
    if(view == 'text_linked')
    {
        isInlineCheckbox.checked = true;
	ContentObjectAlignment.value = 'center';
	ContentObjectAlignment.disabled = true;
    } else
    {
        //isInlineCheckbox.checked = false;
	ContentObjectAlignment.disabled = false;
    }
}

function upload(){
    var uploadurl = EZInfo['SJSDExtensionActionBase'] + '/upload/' + CurrentEZItemObjectID + '/' + CurrentEZItemVersion + '/' + CurrentEZItemEZLanguage;

    OpenFileBrowser( uploadurl, FCKConfig.LinkBrowserWindowWidth, FCKConfig.LinkBrowserWindowHeight );
}

function cleanup(){
     //This is required in IE, called by <PUBLIC:ATTACH EVENT="ondetach" ONEVENT="cleanup()" />
     //in the html file
     GetE('all_objects').detachEvent('onclick', changeObject);
}

function retrieveRelationList(){
    hideAllRelationTables();
    document.getElementById('loading').style.display = '';
    var url = EZInfo['FCKEditorXMLHttp'] + "/GetRelationList" +
            "?oid=" + CurrentEZItemObjectID +
            "&ov=" + CurrentEZItemVersion;
    oHttpRequest.LoadJSONUrl(url, loadRelationList);
}

function clearTable(table, rows)
{
    // Remove all other rows available.
    while ( table.rows.length > rows )
        table.deleteRow(rows) ;
}

function hideAllRelationTables()
{
    document.getElementById('no_relates').style.display = 'none';
    document.getElementById('loading').style.display = 'none';
    document.getElementById('images').style.display = 'none';
    document.getElementById('files').style.display = 'none';
    document.getElementById('objects').style.display = 'none';
}

function loadRelationList(fckXml){
    if ( fckXml.CheckJSONError( fckXml ) != 0 )
        return ;

    // Get the current item.
    var curobject = fckXml.JSON.Object ;
    var groupedrelation = fckXml.JSON.GroupedRelationList ;
    var no_relation = true;
    hideAllRelationTables();

    for (var group in groupedrelation)
    {
        var lists = groupedrelation[group];
        if(lists.length>0)
        {
            var table = document.getElementById(group+'_table') ;
            if(table == undefined)
            {
                alert('Can not find Table for Group: ' + group);
                continue;
            }
            var rowoffset = (group == "images"?0:1);
            clearTable(table, rowoffset); //only images_table does not have a th
            var imagesLastRow;
            for(var i=0;i<lists.length;++i)
            {
                var cobj=lists[i];
                var ccheckbox = document.createElement('input');
                ccheckbox['type']="checkbox";
		if ( oEditor.FCKBrowserInfo.IsIE ) //document.getElementsByName does not work in IE, we have to use id here
                    ccheckbox['id']="ContentObjectIDString";
		else
		    ccheckbox['name']="ContentObjectIDString";
                ccheckbox['value']=cobj.ID;
                ccheckbox['classification']=group;
                if(!isNaN(presel_objectID) && presel_objectID == parseInt(cobj.ID))
                    ccheckbox.checked = true;
                switch(group)
                {
                    case 'images':
                        if(imagesLastRow == undefined || imagesLastRow.cells.length >= 3)
                            imagesLastRow = table.insertRow(-1) ;
                        var oCell = imagesLastRow.insertCell(-1) ;
                        var thumbnail = cobj.DataMap.image.Content.small; //use alias small
                        if(!thumbnail)
                            thumbnail = cobj.DataMap.image.Content.original; //fallback to original
// 						alert(EZInfo['WWWRoot'] + thumbnail.url);
                        var div = document.createElement('div');
                        oCell.appendChild(div);
                        div.className = "image-thumbnail-item";
                        div.innerHTML = '<img src="' + EZInfo['WWWRoot'] + thumbnail.url + '" width="' + thumbnail.width + '" height="' + thumbnail.height + '"  style="border: 0px;" alt="'+cobj.DataMap.image.Content.alternative_text+'" title="'+cobj.DataMap.image.Content.alternative_text+'" />';
                        var para = document.createElement('p');
                        div.appendChild(para);
                        para.appendChild(ccheckbox);
                        para.appendChild(document.createTextNode(cobj.Name));
                        break;
                    case 'files':
                        var cfile = cobj.DataMap.file.Content; //use alias small
                        var icon=fckPage.LoadIcon('MimeIcons','small',cfile.MimeType);
                        var oRow = table.insertRow(-1) ;
                        oRow.className= (table.rows-rowoffset)%2 == 0 ? "bgdark" : "bglight";
                        var oCell = oRow.insertCell(-1) ;
                        oCell.className = "checkbox";
                        oCell.appendChild(ccheckbox);
                        oCell = oRow.insertCell(-1) ;
                        oCell.className = "name";
                        oCell.innerHTML = icon+'&nbsp;'+cobj.Name;
                        oCell = oRow.insertCell(-1) ;
                        oCell.className = "filetype";
                        oCell.innerHTML = cfile.MimeType;
                        oCell = oRow.insertCell(-1) ;
                        oCell.className = "filesize";
                        oCell.innerHTML = fckPage.EZTmpOps.si(cfile.filesize,'byte');
                        break;
                    case 'objects':
                        var icon=fckPage.LoadIcon('ClassIcons','small',cobj.ClassIdentifier);
                        var oRow = table.insertRow(-1) ;
                        oRow.className= (table.rows-rowoffset)%2 == 0 ? "bgdark" : "bglight";
                        var oCell = oRow.insertCell(-1) ;
                        oCell.className = "checkbox";
                        oCell.appendChild(ccheckbox);
                        oCell = oRow.insertCell(-1) ;
                        oCell.className = "name";
                        oCell.innerHTML = icon+'&nbsp;'+cobj.Name;
                        oCell = oRow.insertCell(-1) ;
                        oCell.className = "class";
                        oCell.innerHTML = cobj.ClassName;
                        break;
                }
            }
            document.getElementById(group).style.display = '';
            no_relation=false;
        }
    }

    if(no_relation)
        document.getElementById('no_relates').style.display = '';

    window.parent.SetAutoSize( true ) ;

    changeObject();
// 	alert(curobject.Name);
}
function Ok(){
    if(GetE('ObjectView').disabled)
    {
        alert("Please select one and only one object!");
        return false;
    }

// 	if(oImage == null)
// 		oImage = FCK.CreateElement( 'IMG' ) ;

// 	var editorID = document.getElementById("editorID").value;
    var objectParameters = new Object();
    var objectIDToInsert = "";
    var ContentObjectIDString = document.getElementsByName("ContentObjectIDString");
    for (var i=0;i<ContentObjectIDString.length;i++)
    {
        if ( ContentObjectIDString[i].checked == true)
        {
            objectIDToInsert = ContentObjectIDString[i].value;
            break;
        }
    }
    if ( objectIDToInsert != "" )
    {
        objectParameters["objectIDToInsert"] = objectIDToInsert;
        objectParameters["objectAlign"] = GetE("ContentObjectAlignment").value;
        if ( GetE("ContentObjectSize").disabled == true )
            objectParameters["objectSize"] = "";
        else
            objectParameters["objectSize"] = GetE("ContentObjectSize").value;
        objectParameters["objectClass"] = GetE("ObjectClass").value;
        objectParameters["objectView"] = GetE("ObjectView").value;
        objectParameters["htmlID"] = GetE("HtmlID").value;
	objectParameters["isInline"] = GetE('isInlineCheckbox').checked ? 1 : 0;

        var CustomAttributeName = document.getElementsByName("CustomAttributeName");
        if ( CustomAttributeName.length != null )
        {
            var CustomAttributeValue = document.getElementsByName("CustomAttributeValue");
            var customAttributes = new Object();
            if ( CustomAttributeValue.length != null )
            {
                for (var i=0;i<CustomAttributeName.length;i++)
                {
                    customAttributes[CustomAttributeName[i].value] = CustomAttributeValue[i].value;
                }
            }
// 			else
// 				customAttributes[CustomAttributeName.value]=CustomAttributeValue.value;

            objectParameters["customAttributes"] = customAttributes;
        }

        var url = EZInfo['FCKEditorXMLHttp'] + "/GetEmbedObjectHtml" +
        "?content=" + encodeURIComponent(JSON.stringify(objectParameters));

// 		FCKDebug.Output("Send below string:")
//         FCKDebug.Output(url,'black');

        oHttpRequest.LoadJSONUrl(url, false);
        if(oHttpRequest.CheckJSONError(oHttpRequest) != 0)
            return false;

        if(oImage != null)
        {
            var par = oImage.parentNode;
            par.removeChild(oImage);
        }
        FCK.InsertHtml(oHttpRequest.JSON.RawImage);
        return true;
    }
    else
    {
        alert( "You must select an object to insert" );
    }
    return false;
}

function changeObject(event){
    var ContentObjectIDString = document.getElementsByName("ContentObjectIDString");
    var ContentObjectSize = document.getElementById("ContentObjectSize");
    var sizeRow = document.getElementById("sizeRow");
    var objectIDString = "";
    var selectedinputs = 0;
// 	var deselectprev = true;
    var targetnode;

    if(event != undefined)
    {
    	var target;
    	if(event.target != undefined) //Gecko
	    target = event.target;
	else if(event.srcElement != undefined) //IE
	    target = event.srcElement;
	
        if(target != undefined && target.nodeName.toLowerCase()=="input" &&
            target.type.toLowerCase()=="checkbox" && !event.shiftKey)
        {
            targetnode = target;
        }
// 		alert(event.target.id+" "+event.target.name);
    }

    for (var i=0;i<ContentObjectIDString.length;i++)
    {
        if(targetnode!=undefined && ContentObjectIDString[i]!=targetnode)
            ContentObjectIDString[i].checked = false;

        if ( ContentObjectIDString[i].checked == true)
        {
            objectIDClassification = ContentObjectIDString[i].classification;
            ContentObjectIDString[i].style.className = "selected";
            ++selectedinputs;
        }
        else
            ContentObjectIDString[i].style.className = "unselected";
    }

    if(selectedinputs != 1)
    {
        disableFormElements('property_buttons', true);
        disableFormElements('attributes', true);
    }
    else
    {
        disableFormElements('property_buttons', false);
        disableFormElements('attributes', false);
        if(selectedinputs == 1)
        {
            var isObject = (objectIDClassification != "images");
            if ( isObject )
            {
                ContentObjectSize.disabled=true;
                sizeRow.disabled=true;
            }
            else
            {
                ContentObjectSize.disabled=false;
                sizeRow.disabled=false;
            }
        }
    }

    if(selectedinputs > 0)
        disableInputElement(GetE("deleteRelationButton"), false);
    else
        disableInputElement(GetE("deleteRelationButton"), true);
}
function disableInputElement(btn, dis)
{
    if(dis)
    {
        if(btn.className=='button')
            btn.className = 'button-disabled';
        btn.disabled = true;
    }
    else
    {
        if(btn.className=='button-disabled')
            btn.className = 'button';
        btn.disabled = false;
    }
}
function disableFormElements(parentid, dis)
{
    var inputctls = GetE(parentid).getElementsByTagName('input');
    for(var i=0;i<inputctls.length;++i)
        disableInputElement(inputctls[i], dis);

    inputctls = GetE(parentid).getElementsByTagName('select');
    for(var i=0;i<inputctls.length;++i)
        inputctls[i].disabled = dis;
    changeView();
}
function browseServer()
{
    //add ReturnType is the user selected eznode or ezobject
    var browserurl = FCKConfig.LinkBrowserURL;
    browserurl += browserurl.indexOf('?') != -1 ? '&' : '?';
    browserurl += "ReturnType=1&MultiSelect=1"
    OpenFileBrowser( browserurl, FCKConfig.LinkBrowserWindowWidth, FCKConfig.LinkBrowserWindowHeight );
}
function deleteRelation()
{
    var ContentObjectIDString = document.getElementsByName("ContentObjectIDString");
    var ids = new Array;

    for (var i=0;i<ContentObjectIDString.length;i++)
    {
        if ( ContentObjectIDString[i].checked == true)
        {
            ids[ids.length] = ContentObjectIDString[i].value;
        }
    }

    if(ids.length>0)
    {
        var url = EZInfo['FCKEditorXMLHttp'] + "/RemoveObjectRelation" +
                "?oid=" + CurrentEZItemObjectID +
                "&ov=" + CurrentEZItemVersion +
                "&ids=" + ids.join('_');
        oHttpRequest.LoadJSONUrl(url, loadRelationList);
    }
}
function SetUrl( urls )
{
    var ids = new Array;
    if(urls.length>0)
    {
        var url;
        for (var i in urls)
        {
            url = urls[i];
            if(url.substr(0,11) == 'ezobject://')
            {
                var id = parseInt(url.substr(11));
                if(isNaN(id))
                {
                    alert('Error: can not determine id from returned value: ' + url);
                    continue;
                }
                ids[ids.length]=id;
            } else
                alert('Error: invalid item: ' + url);
        }
    } else alert('Error: invalid return: ' + urls.toString());

    if(ids.length>0)
    {
        var url = EZInfo['FCKEditorXMLHttp'] + "/AddObjectRelation" +
                "?oid=" + CurrentEZItemObjectID +
                "&ov=" + CurrentEZItemVersion +
                "&ids=" + ids.join('_');
        //syn-call here, otherwise the request will fail under firefox
        oHttpRequest.LoadJSONUrl(url, false);
        loadRelationList(oHttpRequest);
    }
}

// ----------------- Properties handling --------------------
function addAttribute( attrName, attrValue ){
    var table = document.getElementById("attributes");
    var row1 = table.insertRow(-1);
    var td1 = row1.insertCell(-1);
    var checkbox1 = document.createElement("input");
    checkbox1.setAttribute( 'name', 'Selected_attribute' );
    checkbox1.setAttribute( 'type', 'checkbox' );
    td1.appendChild(checkbox1);
    var td2 = row1.insertCell(-1);
    var input1 = document.createElement("input");
    input1.setAttribute( 'name', 'CustomAttributeName' );
    input1.setAttribute( 'type', 'text' );
    input1.setAttribute( 'size', '10' );
    if(attrName != undefined)
        input1.value = attrName;
    td2.appendChild(input1);
    var td3 = row1.insertCell(-1);
    var input2 = document.createElement("input");
    input2.setAttribute( 'name', 'CustomAttributeValue' );
    input2.setAttribute( 'type', 'text' );
    input2.setAttribute( 'size', '10' );
    if(attrValue != undefined)
        input2.value = attrValue;
    td3.appendChild(input2);
}
function removeSelected(){
    var table = document.getElementById("attributes");
    var tbody = table.getElementsByTagName("tbody")[0];
    var attributeTitle = document.getElementById("attributeTitle");
    var CustomAttributeName = document.getElementsByName("CustomAttributeName");
    var Selected_attribute = document.getElementsByName("Selected_attribute");
    if (  CustomAttributeName.length != null )
    {
        if ( Selected_attribute.length != null )
        {
            var deleteArray = new Array();
            var deleteArrayIndex = 0;
            for (var i=0;i<Selected_attribute.length;i++)
            {
                if ( Selected_attribute[i].checked == true )
                {
                    deleteArray[deleteArrayIndex] = i;
                    deleteArrayIndex++;
                }
            }
            var baseIndex = 6;
            for (var j=0;j<deleteArray.length;j++)
            {
                rowIndex = baseIndex + deleteArray[j];
                table.deleteRow(rowIndex);
                baseIndex--;
            }
        }
        else
        {
            if ( Selected_attribute.checked == true )
                table.deleteRow(6);
        }
    }
}
