var oEditor		= window.parent.InnerDialogLoaded() ;
var FCK			= oEditor.FCK ;
var FCKConfig	= oEditor.FCKConfig ;
var fckPage		= oEditor.parent.window;
var oHttpRequest = new fckPage.FCKXml;
var EZInfo 		= fckPage.EZInfo;
var oXmlRequest	= oHttpRequest.GetHttpRequest() ;
var textarea;

var CurrentEZItemVersion	= fckPage.CurrentEZItem['EZVersion'];

window.onload = function()
{
    textarea = document.getElementById('txtSource');
    textarea.disabled = true;
    oXmlRequest.open("POST", EZInfo['FCKEditorXMLHttp'] + "/input", true);
    oXmlRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    oXmlRequest.onreadystatechange=function()
    {
        if (oXmlRequest.readyState==4)
        {
            var result = JSON.parse(oXmlRequest.responseText);
            if(result == false)
                alert("Respond text is not valid JSON format:\n"+oXmlRequest.responseText);
            else
                inputCallBack(result);
        }
    //else alert(oXmlRequest.responseText);
    }
    var str = 'att='+encodeURIComponent(FCK.Name)+'&ver=' + CurrentEZItemVersion + '&content=' + encodeURIComponent( FCK.GetXHTML( FCKConfig.FormatSource ) );
    oXmlRequest.send(str);
}

function inputCallBack(result)
{
    textarea.value = result[0];
    if(result[1].length>0)
        alert(result[1].join(''));
    textarea.disabled = false;
}

function retrieveOutput()
{
    oXmlRequest.open("POST", EZInfo['FCKEditorXMLHttp'] + "/output", true);
    oXmlRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    oXmlRequest.onreadystatechange=function()
    {
        if (oXmlRequest.readyState==4)
        {
            var result = JSON.parse(oXmlRequest.responseText);
            outputCallBack(result);
        }
    //else alert(oXmlRequest.responseText);
    }
    var str = 'att='+encodeURIComponent(FCK.Name)+'&ver=' + CurrentEZItemVersion + '&content=' + encodeURIComponent( textarea.value );
    oXmlRequest.send(str);

}

function outputCallBack(result)
{
    textarea.value = result[0];
    if(result[1].length>0)
        alert(result[1].join(''));
    textarea.disabled = false;
    document.getElementById('BtnOutput').style.display = 'none';
    // Activate the "OK" button.
    window.parent.SetOkButton( true ) ;
}

//#### The OK button was hit.
function Ok()
{
// 	if ( oEditor.FCKBrowserInfo.IsIE )
    oEditor.FCKUndo.SaveUndoStep() ;

    FCK.SetHTML( document.getElementById('txtSource').value, false ) ;

    return true ;
}
