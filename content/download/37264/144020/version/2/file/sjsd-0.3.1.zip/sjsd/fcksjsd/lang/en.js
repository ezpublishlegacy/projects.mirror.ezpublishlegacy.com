FCKLang['DlgEZSourceTitle']		= 'EZ Source';
FCKLang['DlgEZEmbedTitle']		= 'Insert Object' //lowercase of this string is the icon name for command EZ_Embed
FCKLang['DlgEZLinkTitle']		= 'Link' ;
