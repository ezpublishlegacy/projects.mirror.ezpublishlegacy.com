<?php
class TemplateSJSDOperator
{
    var $json;
    function TemplateSJSDOperator()
    {
        include_once( 'extension/sjsd/lib/JSON.php');
        $this->json = new Services_JSON();
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'sjsd_get_customtag_settings' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array('sjsd_get_customtag_settings' => array( ));
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        switch ( $operatorName )
        {
            case 'sjsd_canshow':
            {
                $user =& eZUser::currentUser();
                $access =& $user->hasAccessTo( 'sjsd', '*' );
                $operatorValue = ( $access['accessWord'] == 'no' ) ? false : true;
                
            } break;
            case 'sjsd_get_customtag_settings':
            {
                $tags = array();
                $ini =& eZINI::instance( 'content.ini' );
                $availableCustomTags =& $ini->variable( 'CustomTagSettings', 'AvailableCustomTags' );

                $sjsdini =& eZINI::instance( 'sjsd.ini' );
                $startTags =& $sjsdini->variable( 'CustomTagSettings', 'StartTags' );

                $isCustomInlineTagList =& $ini->variable( 'CustomTagSettings', 'IsInline' );

                $tagsHasAtts =& $sjsdini->variable( 'CustomTagSettings', 'TagHasCustomAttributes' );

                foreach($availableCustomTags as $tag)
                {
                    if(!isset($startTags[$tag]))    //use span/div
                    {
                        $inline = false;
                        if(isset($isCustomInlineTagList[$tag]) &&
                            $isCustomInlineTagList[$tag] == 'true')
                                $inline = true;
                        $attributes = array();
                        if(in_array($tag, $tagsHasAtts))
                        {
                            $names = $sjsdini->variable( 'CustomTagAttributes_'.$tag, 'AttributeNames' );
                            $isrequireds = $sjsdini->variable( 'CustomTagAttributes_'.$tag, 'AttributeIsRequired' );
                            for($ti=0;$ti<count($names);++$ti)
                                $attributes[] = array('name'=>$names[$ti],
                                                      'isRequired'=>$isrequireds[$ti]);
                        }
                        $tags[$tag] = array('isBlock'=>!$inline);
                        if(count($attributes)>0) $tags[$tag]['attributes']=$attributes;
                    }
                }

                $operatorValue = $this->json->encode($tags);
//                 $operatorValue

            } break;
            case 'xmlarea_escape':
            {
                $operatorValue = str_replace('"', '\\"', $operatorValue);
                $operatorValue = str_replace('\\\\"', '\\"', $operatorValue);
                $operatorValue = str_replace("\n", '\n', $operatorValue);
            } break;
        }
    }
}
?>
