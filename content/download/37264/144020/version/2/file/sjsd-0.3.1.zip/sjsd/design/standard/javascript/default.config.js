FCKConfig.ToolbarSets['EZDefaulToolbar'] = [
    ['EZ_Format', '-', 'Bold','Italic','Underline','StrikeThrough','-','Subscript','Superscript'],
    ['Cut','Copy','Paste','PasteText','PasteWord','-','SpellCheck'],
    ['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
    ['OrderedList','UnorderedList','-','Outdent','Indent'],
// 	['StyleSimple','FontFormatSimple','FontNameSimple','FontSizeSimple'],
    ['EZ_Link','Unlink', 'Anchor', 'EZ_Embed','SpecialChar','PageBreak','UniversalKey'],
    ['Table','-','TableInsertRow','TableDeleteRows','TableInsertColumn','TableDeleteColumns','TableInsertCell','TableDeleteCells','TableMergeCells','TableSplitCell'],
    ['SourceSimple', 'EZ_Source', 'EZCustomTag'/*,'-','About'*/]
    ] ;

//use plain html tag, not span
FCKConfig.GeckoUseSPAN = false;

FCKConfig.FontFormats	= 'p;pre;h1;h2;h3;h4;h5;h6' ;

// set the default plugin path.
var builtinpluginsdir = FCKConfig.BasePath.substr(0, FCKConfig.BasePath.length - 7) + 'editor/plugins/';

FCKConfig.Plugins.Add( 'tablecommands', null, builtinpluginsdir ) ;
FCKConfig.Plugins.Add( 'simplecommands', null, builtinpluginsdir ) ;

FCKConfig.PluginsPath = FCKConfig.BasePath.substr(0, FCKConfig.BasePath.length - 18);
FCKConfig.Plugins.Add( 'fcksjsd', 'en,it,fr') ;

//append contenxt menu for custom tag properties
FCKConfig.ContextMenu[FCKConfig.ContextMenu.length] = 'EzCustomTagMenu';
