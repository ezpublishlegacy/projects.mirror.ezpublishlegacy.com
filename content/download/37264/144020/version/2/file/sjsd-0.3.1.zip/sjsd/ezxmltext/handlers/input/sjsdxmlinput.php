<?php
//
// Definition of SJSDXMLOutput class
//
// Copyright (C) 2006 liucougar
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Less General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//

include_once( 'kernel/classes/datatypes/ezxmltext/ezxmlinputhandler.php' );
include_once( 'kernel/classes/datatypes/ezurl/ezurlobjectlink.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'extension/sjsd/ezxmltext/handlers/output/sjsdxmloutput.php' );

class SJSDXMLInput extends eZXMLInputHandler
{
    function SJSDXMLInput( &$xmlData, $aliasedType, $contentObjectAttribute )
    {
        $this->eZXMLInputHandler( $xmlData, $aliasedType, $contentObjectAttribute );

        // Initialize size array for image.
        $imageIni =& eZINI::instance( 'image.ini' );
        if ( $imageIni->hasVariable( 'AliasSettings', 'AliasList' ) )
        {
            $sizeArray = $imageIni->variable( 'AliasSettings', 'AliasList' );
            $sizeArray[] = 'original';
        }
        else
            $sizeArray = array( 'original' );

        $contentIni =& eZINI::instance( 'content.ini' );
        if ( $contentIni->hasVariable( 'header', 'UseStrictHeaderRule' ) )
        {
            if ( $contentIni->variable( 'header', 'UseStrictHeaderRule' ) == "true" )
                $this->IsStrictHeader = true;
        }

        $this->availableCustomTags =& $contentIni->variable( 'CustomTagSettings', 'AvailableCustomTags' );

        $sjsdini =& eZINI::instance( 'sjsd.ini' );
        $this->startTags =& $sjsdini->variable( 'CustomTagSettings', 'StartTags' );
//         $endTags =& $contentIni->variable( 'CustomTagSettings', 'EndTags' );

        $this->isCustomInlineTagList =& $contentIni->variable( 'CustomTagSettings', 'IsInline' );

        //NOTICE: omit endTags
        foreach ( $this->availableCustomTags as $key )
        {
            if ( isset( $this->startTags[$key] ) && !empty($this->startTags[$key]) )
            {
                $this->htmlTagToCustomTag[$this->startTags[$key]] = $key;
            }
        }

        $this->SubTagArray['section'] = $this->SectionArray;
        $this->SubTagArray['paragraph'] = array_merge( $this->BlockTagArray, $this->InLineTagArray );
        $this->SubTagArray['header'] = $this->InLineTagArray;
        $this->SubTagArray['table'] = array( 'tr' );
        $this->SubTagArray['tr'] = array( 'td', 'th' );
        $this->SubTagArray['td'] = $this->SubTagArray['section'];
        $this->SubTagArray['th'] = $this->SubTagArray['section'];
        $this->SubTagArray['ol'] = array( 'li', 'ol', 'ul' );
        $this->SubTagArray['ul'] = array( 'li', 'ol', 'ul' );
        $this->SubTagArray['literal'] = array( );
        $this->SubTagArray['custom'] = $this->SectionArray;
        $this->SubTagArray['object'] = array( );
        $this->SubTagArray['embed'] = array( );
        $this->SubTagArray['li'] = array( 'paragraph' );
        $this->SubTagArray['strong'] = $this->InLineTagArray;
        $this->SubTagArray['emphasize'] = $this->InLineTagArray;
        $this->SubTagArray['link'] = $this->InLineTagArray;
        $this->SubTagArray['anchor'] = $this->InLineTagArray;
        $this->SubTagArray['line'] = $this->InLineTagArray;

        $this->TagAttributeArray['table'] = array( 'class' => array( 'required' => false ),
                                                'width' => array( 'required' => false ),
                                                'border' => array( 'required' => false ) );

        $this->TagAttributeArray['link'] = array( 'class' => array( 'required' => false ),
                                                'href' => array( 'required' => false ),
                                                'id' => array( 'required' => false ),
                                                'target' => array( 'required' => false ),
                                                'title' => array( 'required' => false ),
                                                'object_id' => array( 'required' => false ),
                                                'node_id' => array( 'required' => false ),
                                                'show_path' => array( 'required' => false ),
                                                'anchor_name' => array( 'required' => false ),
                                                'url_id' => array( 'required' => false ) );

        $this->TagAttributeArray['anchor'] = array( 'name' => array( 'required' => true ) );

        $this->TagAttributeArray['object'] = array( 'class' => array( 'required' => false ),
                                                    'id' => array( 'required' => true ),
                                                    'size' => array( 'required' => false, 'value' => $sizeArray),
                                                    'align' => array( 'required' => false ),
                                                    'view' => array( 'required' => false ),
                                                    'ezurl_href' => array( 'required' => false ),
                                                    'ezurl_id' => array( 'required' => false ),
                                                    'ezurl_target' => array( 'required' => false ) );

        $this->TagAttributeArray['embed'] = array( 'href' => array( 'required' => false ),
                                            'object_id' => array( 'required' => false ),
                                            'node_id' => array( 'required' => false ),
                                            'show_path' => array( 'required' => false ),
                                            'size' => array( 'required' => false, 'value' => $sizeArray),
                                            'align' => array( 'required' => false ),
                                            'view' => array( 'required' => false ),
                                            'id' => array( 'required' => false ),
                                            'class' => array( 'required' => false ) );

        $this->TagAttributeArray['custom'] = array( 'name' => array( 'required' => true ) );

        $this->TagAttributeArray['header'] = array( 'class' => array( 'required' => false ),
                                                    'level' => array( 'required' => false ),
                                                    'anchor_name' => array( 'required' => false ) );

        $this->TagAttributeArray['td'] = array( 'class' => array( 'required' => false ),
                                                'width' => array( 'required' => false ),
                                                'colspan' => array( 'required' => false ),
                                                'rowspan' => array( 'required' => false ) );

        $this->TagAttributeArray['th'] = array( 'class' => array( 'required' => false ),
                                                'width' => array( 'required' => false ),
                                                'colspan' => array( 'required' => false ),
                                                'rowspan' => array( 'required' => false ) );

        $this->TagAttributeArray['ol'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['li'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['ul'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['literal'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['strong'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['emphasize'] = array( 'class' => array( 'required' => false ) );

        $this->TagAttributeArray['paragraph'] = array( 'class' => array( 'required' => false ) );

        $this->IsInputValid = true;
        $this->ContentObjectAttribute = $contentObjectAttribute;
    }

    function &jsrsValidateInput( &$data )
    {
        $data =& $this->convertInput( $data, false );
        return array($this->domString($data[0]), $data[1]);
    }
    /*!
    Updates related objects list.
    */
    function updateRelatedObjectsList( &$contentObjectAttribute, &$relatedObjectIDArray )
    {
        $contentObjectID = $contentObjectAttribute->attribute( "contentobject_id" );

        $editVersion = $contentObjectAttribute->attribute('version');
//     $editObjectID = $contentObjectAttribute->attribute('contentobject_id');
        $editObject =& eZContentObject::fetch( $contentObjectID );

        // Check that all embeded objects exists in database
        $db =& eZDB::instance();

        // $relatedObjectIDArray[] should be casted to (int)
        $objectIDInSQL = $db->implodeWithTypeCast( ', ', $relatedObjectIDArray, 'int' );
        $objectQuery = "SELECT id FROM ezcontentobject WHERE id IN ( $objectIDInSQL )";
        $objectRowArray =& $db->arrayQuery( $objectQuery );

        $existingObjectIDArray = array();
        if ( count( $objectRowArray ) > 0 )
        {
            foreach ( array_keys( $objectRowArray ) as $key )
            {
                $existingObjectIDArray[] = $objectRowArray[$key]['id'];
            }
        }

        if ( count( array_diff( $relatedObjectIDArray, $existingObjectIDArray ) ) > 0 )
        {
            $objectIDString = implode( ', ', array_diff( $relatedObjectIDArray, $existingObjectIDArray ) );
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                'Object %1 does not exist.', false, array( $objectIDString ) ) );
            return false;
        }

        // Fetch existing related objects
        $relatedObjectQuery = "SELECT to_contentobject_id
                            FROM ezcontentobject_link
                            WHERE from_contentobject_id = $contentObjectID AND
                                    from_contentobject_version = $editVersion";

        $relatedObjectRowArray =& $db->arrayQuery( $relatedObjectQuery );
        // Add existing embeded objects to object relation list if it is not already
        $existingRelatedObjectIDArray = array();
        foreach ( $relatedObjectRowArray as $relatedObjectRow )
        {
            $existingRelatedObjectIDArray[] = $relatedObjectRow['to_contentobject_id'];
        }

        if ( array_diff( $relatedObjectIDArray, $existingRelatedObjectIDArray ) )
        {
            $diffIDArray = array_diff( $relatedObjectIDArray, $existingRelatedObjectIDArray );
            foreach ( $diffIDArray as $relatedObjectID )
            {
                $editObject->addContentObjectRelation( $relatedObjectID, $editVersion );
            }
        }

        return true;
    }


    /*!
    \reimp
    Validates the input and returns true if the input was valid for this datatype.
    */
    function &validateInput( &$http, $base, &$contentObjectAttribute )
    {
        if(!eZPreferences::value("enable_sjsd_editor"))
        {
            include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );
            $dummy = '';
            $simplexml = new eZSimplifiedXMLInput( $dummy, null, $contentObjectAttribute );
            return $simplexml->validateInput($http, $base, $contentObjectAttribute);
        }
        $contentObjectID = $contentObjectAttribute->attribute( "contentobject_id" );
        $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
        $contentObjectAttributeVersion = $contentObjectAttribute->attribute('version');
        if ( $http->hasPostVariable( $base . "_data_text_" . $contentObjectAttributeID ) )
        {
            $data =& $http->postVariable( $base . "_data_text_" . $contentObjectAttributeID );

            // Set original input to a global variable
            $originalInput = "originalInput_" . $contentObjectAttributeID;
            $GLOBALS[$originalInput] = $data;

            // Set input valid true to a global variable
            $isInputValid = "isInputValid_" . $contentObjectAttributeID;
            $GLOBALS[$isInputValid] = true;

//             $en_sjsd = eZPreferences::value('enable_sjsd_editor');

            $switchBack = false;
            if ( $http->hasPostVariable( 'CustomActionButton' ) )
            {
                $customActionArray =& $http->postVariable( 'CustomActionButton' );
                foreach($customActionArray as $k => $v)
                    if(substr($k,-19) == '_enable_sjsd_editor')
                        $switchBack = true;
            }

            if ($switchBack)
            {
                include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );

                $dummy = '';
                $handler = new eZSimplifiedXMLInput($dummy, null, $contentObjectAttribute);

                return $handler->validateInput($http, $base, $contentObjectAttribute);
            }

            $data =& $this->convertInput( $data );

            $message = $data[1];
            if ( $this->IsInputValid == false )
            {
                $GLOBALS[$isInputValid] = false;
                $errorMessage = null;
                foreach ( $message as $line )
                {
                    $errorMessage .= $line .";";
                }
                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                    $errorMessage ) );
                return EZ_INPUT_VALIDATOR_STATE_INVALID;
            }
            else
            {
                // Remove all url-object links to this attribute.
                eZURLObjectLink::removeURLlinkList( $contentObjectAttributeID, $contentObjectAttributeVersion );
                $dom = $data[0];

                $relatedObjectIDArray = array();

                $objects =& $dom->elementsByName( 'object' );

                if ( $objects !== null )
                {
                    foreach ( array_keys( $objects ) as $objectKey )
                    {
                        $object =& $objects[$objectKey];
                        $objectID = $object->attributeValue( 'id' );

                        // protection from self-embedding
                        if ( $objectID == $contentObjectID )
                        {
                            $GLOBALS[$isInputValid] = false;
                            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                'Object %1 can not be embeded to itself.', false, array( $objectID ) ) );
                            return false;
                        }

                        if ( !in_array( $objectID, $relatedObjectIDArray ) )
                            $relatedObjectIDArray[] = $objectID;

                //    $currentObject =& eZContentObject::fetch( $objectID );

                        // If there are any image object with links.
                        $href = $object->attributeValueNS( 'ezurl_href', "http://ez.no/namespaces/ezpublish3/image/" );
                        //washing href. single and double quotes inside url replaced with their urlencoded form
                        $href = str_replace( array('\'','"'), array('%27','%22'), $href );

                        $urlID = $object->attributeValueNS( 'ezurl_id', "http://ez.no/namespaces/ezpublish3/image/" );

                        if ( $href != null )
                        {
                            $linkID =& eZURL::registerURL( $href );
                            $linkObjectLink =& eZURLObjectLink::fetch( $linkID, $contentObjectAttributeID, $contentObjectAttributeVersion );
                            if ( $linkObjectLink == null )
                            {
                                $linkObjectLink =& eZURLObjectLink::create( $linkID, $contentObjectAttributeID, $contentObjectAttributeVersion );
                                $linkObjectLink->store();
                            }
                            $object->appendAttribute( $dom->createAttributeNodeNS( 'http://ez.no/namespaces/ezpublish3/image/', 'image:ezurl_id', $linkID ) );
                            $object->removeNamedAttribute( 'ezurl_href' );
                        }

                        if ( $urlID != null )
                        {
                            $url =& eZURL::url( $urlID );
                            if (  $url == null )
                            {
                                $GLOBALS[$isInputValid] = false;
                                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                    'The link %1 does not exist.',
                                                                                    false, array( $urlID ) ) );
                                return EZ_INPUT_VALIDATOR_STATE_INVALID;
                            }
                            else
                            {
                                $linkObjectLink =& eZURLObjectLink::fetch( $urlID, $contentObjectAttributeID, $contentObjectAttributeVersion );
                                if ( $linkObjectLink == null )
                                {
                                    $linkObjectLink =& eZURLObjectLink::create( $urlID, $contentObjectAttributeID, $contentObjectAttributeVersion );
                                    $linkObjectLink->store();
                                }
                            }
                        }
                    }
                }

                $embedTags =& $dom->elementsByName( 'embed' );

                if ( $embedTags !== null )
                {
                    foreach ( array_keys( $embedTags ) as $embedTagKey )
                    {
                        $embedTag =& $embedTags[$embedTagKey];

                        $href = $embedTag->attributeValue( 'href' );
                        //washing href. single and double quotes replaced with their urlencoded form
                        $href = str_replace( array('\'','"'), array('%27','%22'), $href );

                        //TODO: incorporate these checking in the convert procedure
                        if ( $href != null )
                        {
                            if ( ereg( "^ezobject://[0-9]+$" , $href ) )
                            {
                                $objectID = substr( strrchr( $href, "/" ), 1 );

                                // protection from self-embedding
                                if ( $objectID == $contentObjectID )
                                {
                                    $GLOBALS[$isInputValid] = false;
                                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Object %1 can not be embeded to itself.', false, array( $objectID ) ) );
                                    return false;
                                }

                                $embedTag->appendAttribute( $dom->createAttributeNode( 'object_id', $objectID ) );

                                if ( !in_array( $objectID, $relatedObjectIDArray ) )
                                    $relatedObjectIDArray[] = $objectID;
                            }
                            elseif ( ereg( "^eznode://.+$" , $href ) )
                            {
                                $nodePath = substr( strchr( $href, "/" ), 2 );

                                if ( ereg( "^[0-9]+$", $nodePath ) )
                                {
                                    $nodeID = $nodePath;
                                    $node =& eZContentObjectTreeNode::fetch( $nodeID );
                                    if ( $node == null)
                                    {
                                        $GLOBALS[$isInputValid] = false;
                                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Node %1 does not exist.',
                                                                                            false, array( $nodeID ) ) );
                                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                                    }
                                }
                                else
                                {
                                    $node =& eZContentObjectTreeNode::fetchByURLPath( $nodePath );
                                    if ( $node == null)
                                    {
                                        $GLOBALS[$isInputValid] = false;
                                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Node \'%1\' does not exist.',
                                                                                            false, array( $nodePath ) ) );
                                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                                    }
                                    $nodeID = $node->attribute('node_id');
                                    $embedTag->appendAttribute( $dom->createAttributeNode( 'show_path', 'true' ) );
                                }

                                $embedTag->appendAttribute( $dom->createAttributeNode( 'node_id', $nodeID ) );

                                $objectID = $node->attribute( 'contentobject_id' );

                                // protection from self-embedding
                                if ( $objectID == $contentObjectID )
                                {
                                    $GLOBALS[$isInputValid] = false;
                                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Object %1 can not be embeded to itself.', false, array( $objectID ) ) );
                                    return false;
                                }

                                if ( !in_array( $objectID, $relatedObjectIDArray ) )
                                    $relatedObjectIDArray[] = $objectID;
                            }
                            else
                            {
                                $GLOBALS[$isInputValid] = false;
                                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                    'Invalid reference in <embed> tag. Note that <embed> tag supports only \'eznode\' and \'ezobject\' protocols.' ) );
                                return EZ_INPUT_VALIDATOR_STATE_INVALID;
                            }
                        }

                        $embedTag->removeNamedAttribute( 'href' );
                    }
                }

                $links =& $dom->elementsByName( 'link' );

                if ( $links !== null )
                {
                    $urlArray = array();

                    foreach ( array_keys( $links ) as $linkKey )
                    {
                        $link =& $links[$linkKey];

                /*      // Remove attributes in case they are present in the input
                        if ( $link->attributeValue( 'object_id' ) != null )
                            $link->removeNamedAttribute( 'object_id' );
                        if ( $link->attributeValue( 'node_id' ) != null )
                            $link->removeNamedAttribute( 'node_id' );
                        if ( $link->attributeValue( 'anchor_id' ) != null )
                            $link->removeNamedAttribute( 'anchor_id' );
                */

                        $href = $link->attributeValue( 'href' );
                        //washing href. single and double quotes replaced with their urlencoded form
                        $href = str_replace( array('\'','"'), array('%27','%22'), $href );

                        if ( $href != null )
                        {
                            if ( ereg( "^ezobject://[0-9]+(#.*)?$" , $href ) )
                            {
                                $url = strtok( $href, '#' );
                                $anchorName = strtok( '#' );

                                $objectID = substr( strrchr( $url, "/" ), 1 );
                                $link->appendAttribute( $dom->createAttributeNode( 'object_id', $objectID ) );

                                if ( $anchorName )
                                    $link->appendAttribute( $dom->createAttributeNode( 'anchor_name', $anchorName ) );

                                if ( !in_array( $objectID, $relatedObjectIDArray ) )
                                    $relatedObjectIDArray[] = $objectID;
                            }
                            elseif ( ereg( "^eznode://.+(#.*)?$" , $href ) )
                            {
                                $url = strtok( $href, '#' );
                                $anchorName = strtok( '#' );

                                $nodePath = substr( strchr( $url, "/" ), 2 );

                                if ( ereg( "^[0-9]+$", $nodePath ) )
                                {
                                    $nodeID = $nodePath;
                                    $node =& eZContentObjectTreeNode::fetch( $nodeID );
                                    if ( $node == null)
                                    {
                                        $GLOBALS[$isInputValid] = false;
                                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Node %1 does not exist.',
                                                                                            false, array( $nodeID ) ) );
                                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                                    }
                                }
                                else
                                {
                                    $node =& eZContentObjectTreeNode::fetchByURLPath( $nodePath );
                                    if ( $node == null)
                                    {
                                        $GLOBALS[$isInputValid] = false;
                                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                        'Node \'%1\' does not exist.',
                                                                                            false, array( $nodePath ) ) );
                                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                                    }
                                    $nodeID = $node->attribute('node_id');
                                    $link->appendAttribute( $dom->createAttributeNode( 'show_path', 'true' ) );
                                }

                                $link->appendAttribute( $dom->createAttributeNode( 'node_id', $nodeID ) );

                                if ( $anchorName )
                                    $link->appendAttribute( $dom->createAttributeNode( 'anchor_name', $anchorName ) );

                                $objectID = $node->attribute( 'contentobject_id' );
                                if ( !in_array( $objectID, $relatedObjectIDArray ) )
                                    $relatedObjectIDArray[] = $objectID;
                            }
                            elseif ( ereg( "^#.*$" , $href ) )
                            {
                                $anchorName = substr( $href, 1 );

                                $link->appendAttribute( $dom->createAttributeNode( 'anchor_name', $anchorName ) );
                            }
                            else
                            {
                                // Cache all URL's not converted to relations
                                $url = strtok( $href, '#' );
                                $anchorName = strtok( '#' );

                                if ( $anchorName )
                                    $link->appendAttribute( $dom->createAttributeNode( 'anchor_name', $anchorName ) );

                                if ( !in_array( $url, $urlArray ) )
                                    $urlArray[] = $url;
                            }
                        }

                        // If url_id attribute is present, we should get url from ezurl list
                        //   and add it to urlArray
                        if ( $link->attributeValue( 'url_id' ) != null )
                        {
                            $linkID = $link->attributeValue( 'url_id' );
                            $url =& eZURL::url( $linkID );
                            if ( $url == null )
                            {
                                $GLOBALS[$isInputValid] = false;
                                $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                                    'Link %1 does not exist.',
                                                                                    false, array( $linkID ) ) );
                                return EZ_INPUT_VALIDATOR_STATE_INVALID;
                            }
                            else
                            {
                                if ( !in_array( $url, $urlArray ) )
                                    $urlArray[] = $url;
                            }
                        }
                    }

                    // Optimized for speed, we have found all urls and now fetch them from DB

                    if ( count( $urlArray ) > 0 )
                    {
                        // Fetch the ID's of all existing URL's and register unexisting
                        $linkIDArray =& eZURL::registerURLArray( $urlArray );

                        // Register all unique URL's for this object attribute
                        /* We're not using the persistent object interface here as
                        * that's a bit suboptimal as it checks if the record
                        * exists first (and we're sure it doesn't as we removed
                        * the whole bunch before in this function). We also
                        * optimize for mysql as it supports multiple insertions
                        * per query. */
                        $db =& eZDB::instance();
                        $dbImpl = $db->databaseName();

                        // replace column names with their short aliases
                        include_once( 'kernel/classes/datatypes/ezurl/ezurlobjectlink.php' );
                        $def       =& eZURLObjectLink::definition();
                        $fieldDefs =& $def['fields'];
                        $insertFields = array( 'url_id', 'contentobject_attribute_id', 'contentobject_attribute_version' );
                        eZPersistentObject::replaceFieldsWithShortNames( $db, $fieldDefs, $insertFields );
                        $insertFieldsString = implode( ', ', $insertFields );
                        unset( $insertFields, $fieldDefs, $def );

                        if ( $dbImpl == 'mysql' )
                        {
                            $baseQuery = 'INSERT INTO ezurl_object_link( ' . $insertFieldsString . ' ) VALUES';
                            $valueArray = array();
                            foreach ( $linkIDArray as $url => $linkID)
                            {
                                $valueArray[] = "($linkID, $contentObjectAttributeID, $contentObjectAttributeVersion)";
                            }
                            if ( count( $valueArray ) )
                            {
                                $db->query( $baseQuery . implode( ', ', $valueArray ) );
                            }
                        }
                        else
                        {
                            $baseQuery = 'INSERT INTO ezurl_object_link( ' . $insertFieldsString . ' ) VALUES';
                            foreach ( $linkIDArray as $url => $linkID)
                            {
                                $value = "($linkID, $contentObjectAttributeID, $contentObjectAttributeVersion)";
                                $db->query( $baseQuery . $value );
                            }
                        }
                    }

                    // Update XML to only store url id, not href
                    foreach ( array_keys( $links ) as $linkKey )
                    {
                        $link =& $links[$linkKey];

                        // We need to append url id only if it's not a link to an object or a node
                        if ( $link->attributeValue( 'node_id' ) == null && $link->attributeValue( 'object_id' ) == null )
                        {
                            $temp = explode( '#', $link->attributeValue( 'href' ) );
                            $url = $temp[0];
                            //washing href. single and double quotes inside url replaced with their urlencoded form
                            $url = str_replace( array('\'','"'), array('%27','%22'), $url );

                            if ( $url != null )
                            {
                                $linkID = $linkIDArray[$url];

                                if ( $link->attributeValue( 'url_id' ) == null )
                                    $link->appendAttribute( $dom->createAttributeNode( 'url_id', $linkID ) );
                            }
                        }
                        $link->removeNamedAttribute( 'href' );
                    }
                }

                if ( count( $relatedObjectIDArray ) > 0 )
                    if ( $this->updateRelatedObjectsList( $contentObjectAttribute, $relatedObjectIDArray, $isInputValid, 'object_id' ) == false )
                    {
                        $GLOBALS[$isInputValid] = false;
                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                    }

                //Do not use eZXMLTextType::domString, for it is impossible to disable
                //specialchar conversion: & eZXMLTextType::domString( $dom );
                $domString =& $this->domString($dom);

//                $tmpDom = & $dom;
                //the $dom parser should not generate these code in the first place
//                 $domString = str_replace( "<paragraph> </paragraph>", "<paragraph>&nbsp;</paragraph>", $domString );
//                 $domString = str_replace ( "<paragraph />" , "", $domString );
//                 $domString = str_replace ( "<line />" , "", $domString );
//                 $domString = str_replace ( "<paragraph></paragraph>" , "", $domString );
//                 //$domString = preg_replace( "#<paragraph>&nbsp;</paragraph>#", "<paragraph />", $domString );
//                 $domString = str_replace( "<paragraph></paragraph>", "", $domString );
//
//                 $domString = preg_replace( "#[\n]+#", "", $domString );
//                 $domString = preg_replace( "#&lt;/line&gt;#", "\n", $domString );
//                 $domString = preg_replace( "#&lt;paragraph&gt;#", "\n\n", $domString );
//
//                 $xml = new eZXML();
//                 $tmpDom =& $xml->domTree( $domString,
//                                         array( 'ConvertSpecialChars'=>false,
//                                                'CharsetConversion'=>false ) );
//                 //replace eZXMLTextType::domString( $tmpDom ); with toString as well here
//                 $domString = $tmpDom->toString(true,false,false);

                $contentObjectAttribute->setAttribute( "data_text", $domString );
                $contentObjectAttribute->setValidationLog( $message );

                $paragraphs = $dom->elementsByName( 'paragraph' );
                $headers = $dom->elementsByName( 'header' );

                $classAttribute =& $contentObjectAttribute->contentClassAttribute();
                if ( $contentObjectAttribute->validateIsRequired() )
                {
                    if ( count( $paragraphs ) == 0  && count( $headers ) == 0  )
                    {
                        $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                            'Input required' ) );
                        return EZ_INPUT_VALIDATOR_STATE_INVALID;
                    }
                    else
                        return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
                }
                else
                    return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
            }
            return EZ_INPUT_VALIDATOR_STATE_INVALID;
        }
        return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
    }

    /*!
     \return the XML structure in \a $domDocument as text.
             It will take of care of the necessary charset conversions
             for content storage.
     COPIED from kernel/classes/datatypes/ezxmltext/ezxmltexttype.php
     add options to disable convertspecialchars
    */
    function domString( &$domDocument )
    {
        $ini =& eZINI::instance();
        $xmlCharset = $ini->variable( 'RegionalSettings', 'ContentXMLCharset' );
        if ( $xmlCharset == 'enabled' )
        {
            include_once( 'lib/ezi18n/classes/eztextcodec.php' );
            $charset = eZTextCodec::internalCharset();
        }
        else if ( $xmlCharset == 'disabled' )
            $charset = true;
        else
            $charset = $xmlCharset;
        if ( $charset !== true )
        {
            include_once( 'lib/ezi18n/classes/ezcharsetinfo.php' );
            $charset = eZCharsetInfo::realCharsetCode( $charset );
        }
        $domString = $domDocument->toString( $charset, true, false );
        return $domString;
    }

    /*!
    Change input tags to standard tag name
    */
    function &standardizeTag( $tagName )
    {
        foreach ( $this->TagAliasArray as $tag => $aliases )
        {
            if ( in_array( $tagName, $aliases ) )
            {
//                 $convertedTagName = $tag;
                return $tag;
//                 break;
            }
        }
        $convertedTagName = $tagName;
//         echo $tagName." ".$this->htmlTagToCustomTag[$tagName]."\n";
        if(isset($this->htmlTagToCustomTag[$tagName]))
            $convertedTagName = 'custom';
        return $convertedTagName;
    }

    function &extractText($node)
    {
        if($node->name() != '#text')
        {
            $output = '';
            if($node->hasChildren())
            {
                $cnt = $node->childrenCount();
                $chd =& $node->children();
                for($i=0;$i<$cnt;++$i)
                    $output .= $this->extractText($chd[$i]);
            }

            return $output;
        } else
            return $node->content();
    }
    /*as there is not section corresponding html tags, so we
    have to guess when to add a section child
    to my best knowledge, section is used to encapsulate
    a header and its following paragraph(s). and section
    can be nested. Example:
    the xhtml input:
            <h1>header 1</h1>
            <p>para 1 under header 1</p>
            <p>para 2 under header 1</p>
            <h2>header 2</h2>
            <p>para 1 under header 2</p>
            <p>para 2 under header 2</p>
            <h1>header 3</h1>
            <p>para 1 under header 3</p>
            <p>para 2 under header 3</p>
        will result in these xml:
    <section>
        <header>header 1</header>
        <paragraph>para 1 under header 1</paragraph>
        <paragraph>para 2 under header 1</paragraph>
        <section>
        <header>header 2</header>
        <paragraph>para 1 under header 2</paragraph>
        <paragraph>para 2 under header 2</paragraph>
        </section>
    </section>
    <section>
        <header>header 3</header>
        <paragraph>para 1 under header 3</paragraph>
        <paragraph>para 2 under header 3</paragraph>
    </section>
    */
    function convertSectionDomNode( &$inode, &$onode, &$message, &$odom )
    {
        $ccount = $inode->childrenCount();
        $children =& $inode->children();

        $SectionNodeStack = array();
        $curoparentnode =& $onode;
        unset($onode);

        $fakepar = eZDOMDocument::createElementNode( "p" );
        for($i=0;$i<$ccount;++$i)
        {
            $cinode =& $children[$i];
            $inodename = strtolower($cinode->name());
            if(in_array($inodename, $this->HeaderNames) )
            {
                $this->checkParagraph($fakepar, $curoparentnode, $message, $odom);

                $level = $inodename[1];
                if ( $this->IsStrictHeader && $level > count($SectionNodeStack) )
                {
                    $level = count($SectionNodeStack)+1;
                }

                while($level<=count($SectionNodeStack))
                {
                    //array_pop does not return reference, so do it manually
                    unset($curoparentnode);
                    $curoparentnode =& $SectionNodeStack[count($SectionNodeStack)-1];
                     /*$curoparentnode =&*/ array_pop($SectionNodeStack);
                }
                while($level > count($SectionNodeStack))
                {
                    $nnode = eZDOMDocument::createElementNode( "section" );
                    $curoparentnode->appendChild($nnode);
                    $odom->registerElement($nnode);
                    $SectionNodeStack[] =& $curoparentnode;
                    unset($curoparentnode);
                    $curoparentnode =& $nnode;
                    unset( $nnode );
                }

                if($cinode->childrenCount() > 0)
                {
                    $nnode = eZDOMDocument::createElementNode( "header" );
		    $this->convertParagraphDomNode($cinode, $nnode, $message, $odom);
                    $curoparentnode->appendChild($nnode);
                    $odom->registerElement($nnode);
                }
            }else if($inodename == 'paragraph' || $inodename == 'p')
            {
                $this->checkParagraph($fakepar, $curoparentnode, $message, $odom);

                $nnode = eZDOMDocument::createElementNode( "paragraph" );
                $curoparentnode->appendChild($nnode);
                $odom->registerElement($nnode);
                $this->convertParagraphDomNode($cinode, $nnode, $message, $odom);
            }
            else
            {
                $fakepar->appendChild($cinode);
            }
	    unset($nnode);
        }

        $this->checkParagraph($fakepar, $curoparentnode, $message, $odom);
    }



    function checkParagraph(&$p, &$parent, &$message, &$odom)
    {
        if(get_class( $p ) == "ezdomnode" && get_class( $parent ) == "ezdomnode")
        {
            if($p->hasChildren())
            {
                $tmpparagraph = eZDOMDocument::createElementNode( "paragraph" );
                $odom->registerElement($tmpparagraph);
                $this->convertParagraphDomNode($p, $tmpparagraph, $message, $odom);
                $parent->appendChild($tmpparagraph);
                $p->removeChildren();
            }
        }
    }

    function convertListDomNode(&$inode, &$onode, &$message, &$odom)
    {
        $ccount = $inode->childrenCount();
        $children =& $inode->children();
        $toponodename = $onode->name();

        for($i=0;$i<$ccount;++$i)
        {
            $cinode =& $children[$i];
            $inodename = strtolower($cinode->name());

            switch($inodename)
            {
                case 'ul':
                case 'ol':
                    if(!$onode->hasChildren())
                    {
                        $fakelistitem = eZDOMDocument::createElementNode( 'li' );
                        $odom->registerElement($fakelistitem);
                        $onode->appendChild($fakelistitem);
                        $fakelistitempara = eZDOMDocument::createElementNode( "paragraph" );
                        $odom->registerElement($fakelistitempara);
                        $fakelistitem->appendChild($fakelistitempara);
                        unset($fakelistitempara);
                        unset($fakelistitem);
                    }
                    if($onode->hasChildren())
                    {
                        $lastlistchild =& $onode->lastChild();
                        if($lastlistchild->name() == 'li')
                        {
                            $lastlistchildpara =& $lastlistchild->lastChild();
                            if($lastlistchildpara->name() == 'paragraph')
                            {
                                //wrap previous inline tags in a <line> tag
                                $this->wrapInLine($onode, $message, $odom);

                                //TODO: add a shadowClone funtion to copy attributes as well
                                $fakelist = eZDOMDocument::createElementNode( $inodename );
                                $this->convertListDomNode($cinode, $fakelist, $message, $odom);
                                $odom->registerElement($fakelist);
                                $lastlistchildpara->appendChild($fakelist);
                                unset($fakelist);
                            } else
                                $message[] = "Should not happen: li's last child is not paragraph.\n";
                            unset($lastlistchildpara); 
                        } else
                            $message[] = "Should not happen: last child in list is not a li.\n";
                        unset($lastlistchild); 
                    } else
                        $message[] = "Should not happen: output list element does not have child.\n";

                    break;

                case 'li':
                    //TODO: add a shadowClone funtion to copy attributes as well
                    $listitem = eZDOMDocument::createElementNode( 'li' );
                    $odom->registerElement($listitem);
                    $onode->appendChild($listitem);
                    $cltmpnode = eZDOMDocument::createElementNode( "paragraph" );
                    $odom->registerElement($cltmpnode);
                    $listitem->appendChild($cltmpnode);
                    $this->convertParagraphDomNode($cinode, $cltmpnode, $message, $odom);
                    unset($cltmpnode);
                    unset($listitem);
            }
        }
    }

    function convertParagraphDomNode(&$inode, &$onode, &$message, &$odom)
    {
        $ccount = $inode->childrenCount();
        $children =& $inode->children();
        $toponodename = $onode->name();
        $toponodeisblock = true;

        if($toponodename == 'custom')
        {
            $customname = $onode->attributeValue('name');
            $custominline = false;
            if(isset($this->isCustomInlineTagList[$customname]))
                $custominline = $this->isCustomInlineTagList[$customname];
            $toponodeisblock = !$custominline;
        } else if(in_array($toponodename, $this->InLineTagArray))
            $toponodeisblock = false;

        for($i=0;$i<$ccount;++$i)
        {
            $cinode =& $children[$i];
            $inodename = $this->standardizeTag(strtolower($cinode->name()));
            $inodeisblock = (!in_array($inodename, $this->InLineTagArray) && $inodename!='#text');
            if($inodename == 'custom')
            {
                $customname = $cinode->attributeValue('name');
                if(empty($customname))
                    if(isset($this->htmlTagToCustomTag[$cinode->name()]))
                        $customname = $this->htmlTagToCustomTag[$cinode->name()];
                    else if(substr($cinode->attributeValue('id'),0,7)=='custom_')
                    {
                        $customname = substr($cinode->attributeValue('id'),7);
                        if(!in_array($customname, $this->availableCustomTags))
                        {
                            $message[] = "Detected custom tag '$customname', but the name is not in the available custom tag list. Did you forget to add it to content.ini? The Tag: '".$cinode->toString()."'. Ignored.\n";
                            continue;
                        }
                        $cinode->removeNamedAttribute('id');
                        $attrs =& $cinode->attributes();
                        $keys = array_keys($attrs);
                        for($ai=0;$ai<count($keys);++$ai)
                            $attrs[$keys[$ai]]->setPrefix('custom');
                        unset($attrs);
                    }
                    else
                    {
                        $message[] = "Can not determine the name for the custom tag: '".$cinode->toString()."'. Ignored.\n";
                        continue;
                    }

                $inodeisblock = true;
                if(isset($this->isCustomInlineTagList[$customname]))
                    $inodeisblock = ($this->isCustomInlineTagList[$customname] != 'true');
                if($inodeisblock && !$toponodeisblock)
                {
                    $message[] = "Block custom tag can not be child of inline tag $toponodename. Custom tag is '".$cinode->toString()."'. Ignored.\n";
                    continue;
                }
            }
            //If this tag is not allowed here, just append the text content of it and its children
            else if($inodename != '#text' && $inodename != 'br' && $toponodename != 'custom'
                && !in_array($inodename, $this->SubTagArray[$toponodename]))
            {
//                 $this->IsInputValid = false;
                $message[] = "tag '$inodename (".$cinode->name().")' is not allowed as children of '$toponodename', removed while text content is retained;\n";
                $onode->appendChild(eZDOMDocument::createTextNode($this->extractText($cinode)));
                continue;
            } else if ($toponodename == 'custom')
            {
//                 if($toponodeisblock)
//                 {
//                     $message[] = "Block custom tag should contain only section tags. Ignored.\n";
//                     continue;
//                 }

                if($inodeisblock/* && $inodename != 'paragraph'*/)
                {
                    $message[] = "$inodename is not inline tag, and it can not be child of inline custom tag. Ignored.\n";
                    continue;
                }
            }

            //if in paragraph, and this one is a block tag, then make all previous
            //inline tag in a <line> tag
            if ($toponodename == 'paragraph' && $inodeisblock)
                $this->wrapInLine($onode, $message, $odom);

            if($inodename == '#text')
            {
                $textcontent =& $cinode->content();
                //if the text only contains &nbsp; and spaces, ignore it
                if(!preg_match('/^(&nbsp;|\s|\b)+$/Di',$textcontent))
                {
                    // Get rid of linebreak and spaces stored in xml file
                    $textcontent = str_replace( "\n\n", "", $textcontent );
                    $textcontent = preg_replace( "/\s\s+/", " ", $textcontent );
                    $nnode = eZDOMDocument::createTextNode($textcontent);
                }/* else if(preg_match('/^(\s)+$/Di',$textcontent))
                    $nnode = eZDOMDocument::createTextNode('&nbsp;');*/
            }
            else if(in_array($inodename, $this->CloneTags))
            {
                $nnode = new eZDOMNode();
                $nnode->Name = $inodename;
                $nnode->Type = $cinode->Type;
                $nnode->Content = $cinode->Content;
    //             $nnode->Children = $cinode->Children;
                $nnode->Attributes = $cinode->Attributes;
                $nnode->NamespaceURI = $cinode->NamespaceURI;
                $nnode->LocalName = $cinode->LocalName;
                $nnode->Prefix = $cinode->Prefix;

                if($inodename == 'ul' || $inodename == 'ol')
                    $this->convertListDomNode($cinode, $nnode, $message, $odom);
                else
                    $this->convertParagraphDomNode($cinode, $nnode, $message, $odom);
            }
            else if($inodename == 'paragraph')
            {
                //in nested p case, just ignore this one and process its children
                //and append to the current $onode
//                 if($toponodename == 'paragraph')
                    $this->convertParagraphDomNode($cinode, $onode, $message, $odom);
            }
            else if(in_array($inodename, $this->HeaderNames) )
            {
                //not allowed: TODO: retain content
            }
            else if($inodename == 'link')
            {
                if(!$cinode->hasChildren())  //no children, then this is an anchor
                {
                    $nnode = eZDOMDocument::createElementNode( "anchor" );
                    $nnode->set_attribute('name', $cinode->attributeValue('name'));
                    $cinode->removeAttributes(); //do not need any other attributes
                }
                else
                {
                    $nnode = eZDOMDocument::createElementNode( "link" );
                    include_once( 'lib/version.php' );
                    if(eZPublishSDK::minorVersion() == 8)
                    {   //if this is 3.8, then store url_id/object_id/node_id instead
                        $href = $cinode->attributeValue('href');
                        unset($match);
                        if(preg_match($this->InternalLinkPattern, $href, $match))
                        {
                            if(!empty($match[2]))
                            {
                                if(substr($match[1], 0, 3) == 'ezo')
                                    $nnode->set_attribute('object_id', $match[2]);
                                else
                                    $nnode->set_attribute('node_id', $match[2]);

                                if(!empty($match[3]))
                                    $href=$match[3];
                            }
                        } else if($href[0] == '#')
                        {
                            //pass through intentionally
                        }
                        else //external link
                        {
                            $url = strtok( $href, '#' );
                            $anchorName = strtok( '#' );
                            $id = eZURL::registerURL($url);
    //                         $message[] = "registering url: $url $id\n";
                            $nnode->set_attribute('url_id', $id);
                            $anchorName = '#'.$anchorName;
                        }

                        if($href[0] == '#')
                        {
                            $href = substr($href,1);
                            $nnode->set_attribute('anchor_name', $href);
                        }
                        $cinode->removeNamedAttribute('href');
                    }
                    $this->convertParagraphDomNode($cinode, $nnode, $message, $odom);    //process children
                }
            }
            else if($inodename == 'embed')
            {
                $nnode = eZDOMDocument::createElementNode( "embed" );
                $rawdata = $cinode->attributeValue('alt');
    
                include_once( 'extension/sjsd/lib/JSON.php' );
                $json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
                $realattrs = $json->decode(html_entity_decode($rawdata));

		if(isset($realattrs['inline']))
		{
		    if($realattrs['inline'] == '1')
		        $nnode = eZDOMDocument::createElementNode( "embed-inline" );
		    unset($realattrs['inline']);
		}
                foreach( $realattrs as $key => $val )
                {
                    if($key == 'Custom')
                    {
                        foreach( $val as $k => $v )
                        {
                            $tmpatt =
                                eZDOMDocument::createAttributeNode($k, htmlspecialchars($v));
                            $tmpatt->setPrefix( "custom" );
                            $nnode->appendAttribute($tmpatt);
                        }
                    }
                    else if(!empty($val))
                    {
                        if($key == 'href')
                        {
                            if(substr($val,0,11) == 'ezobject://')
                            {
                                $key='object_id';
                                $val=substr($val,11);
                            }
                            elseif(substr($val,0,9) == 'eznode://')
                            {
                                $key='node_id';
                                $val=substr($val,9);
                            }
                        }
			
                        $nnode->set_attribute($key, htmlspecialchars($val));
                    }
                }

                $cinode->removeAttributes(); //omit other attributes
                $cinode->removeChildren();
            } else if($inodename == 'custom')
            {
                $nnode = eZDOMDocument::createElementNode( "custom" );
                $nnode->set_attribute('name', $customname);
                if($inodeisblock)
                {
                    $this->convertSectionDomNode($cinode, $nnode, $message, $odom);    //process children
                }
                else
                    $this->convertParagraphDomNode($cinode, $nnode, $message, $odom);    //process children
            }
            else if($inodename == 'literal')
            {
                $nnode = eZDOMDocument::createElementNode( "literal" );
                $lccount = $cinode->childrenCount();
                $lchildren =& $cinode->children();
                $literalcontent = "";
                for($li=0;$li<$lccount;++$li) //only tag <br> is allowed as the child of literal
                    switch($lchildren[$li]->name())
                    {
                        case 'br':
                            $literalcontent .= "\n";
                            break;
                        case '#text':
                            $literalcontent .= $lchildren[$li]->content();
                            break;
                        default:
                            $message[] = 'Tag "'.$lchildren[$li]->name()."\" is not allowd as child of literal/pre. Retain its text content\n";
                            $literalcontent .= $this->extractText($lchildren[$li]);
                    }
                $nnode_child = eZDOMDocument::createTextNode( $literalcontent );
                $nnode->appendChild($nnode_child);
                unset($nnode_child);
            }
            else if($inodename == 'table')
            {
                if($cinode->hasChildren())
                {
                    $nnode = eZDOMDocument::createElementNode( "table" );
                    $firstc = $cinode->firstChild();
                    if(strtolower($firstc->name()) == 'tbody')
                        $rows =& $firstc->children();
                    else
                        $rows =& $cinode->children();
                    $crows = count($rows);

                    for($row=0;$row<$crows;++$row)
                    {
                        //NOTICE: may have problems in php 4.4
                        $rownode = eZDOMDocument::createElementNode( 'tr' );
                        $odom->registerElement($rownode);
                        $nnode->appendChild($rownode);
                        $cells =& $rows[$row]->children();
                        $ccells = count($cells);
                        for($cell=0;$cell<$ccells;++$cell)
                        {
                            $celltag = $cells[$cell]->name() == 'th' ?'th':'td';
                            $cellnode = eZDOMDocument::createElementNode( $celltag );
                            $odom->registerElement($cellnode);
                            $rownode->appendChild($cellnode);
                            if($cells[$cell]->hasChildren())
                            {
                                //set this to section so we can process it content below
                                $cells[$cell]->setType('section');
//                                 $tmpcellnode = eZDOMDocument::createElementNode( 'section' );
//                                 $cellnode->appendChild($tmpcellnode);
                                $this->convertSectionDomNode($cells[$cell], $cellnode, $message, $odom);    //process children
                            }
                            unset($cellnode);
                        }
                        unset($rownode);
                    }
                }
            } else if($inodename == 'br')
            {
                if($toponodename == 'paragraph' && $onode->hasChildren())
                {
                    //detect a <br/> in a paragraph, insert a <line> element for 
                    //all the inline tags before this <br/>
                    $this->wrapInLine($onode, $message, $odom);
                }
            }
            else
            {
                $message[] = "Unknown node: '".$cinode->toString()."'. Ignored.\n";
                continue;
            }

            if(isset($nnode) && get_class( $nnode ) == "ezdomnode")
            {
                //append attributes
                $attrs =& $cinode->attributes();
		$keys = array_keys($attrs);
                for($ai=0;$ai<count($keys);++$ai)
		{
                    $at = $attrs[$keys[$ai]];
                    $content =& $at->content();
                    if(!empty($content))
                        $nnode->appendAttribute($at);
                    unset($content);
                }
                unset($attrs);

                //only appendchild which has children or is a tag which does not have children
                if(in_array($nnode->name(), $this->EmptyTags) || $nnode->hasChildren() )
                {
                    $odom->registerElement($nnode);
                    $onode->appendChild($nnode);
                }
            }
            unset($cinode);
            unset($nnode);
        }

        //if paragraph contains line tags, make sure
        //the last inline tags are wrapeed in a <line> tag
        if($onode->name() == 'paragraph')
        {
            $lines =& $onode->elementsByName('line');
            if(count($lines)>0)
                $this->wrapInLine($onode, $message, $odom);
        }
    }

    function wrapInLine(&$onode, &$message, &$odom)
    {
        $nnode = eZDOMDocument::createElementNode('line');
        $inlinenodeStatck = array();
        while($tmpnode =& $onode->lastChild())
        {
            $isinline = false;
            if(in_array($tmpnode->name(), $this->LineTagArray)
                || $tmpnode->name() == '#text')
                $isinline = true;
            else if($tmpnode->name()=='custom')
            {
                $customtagname = $tmpnode->attributeValue('name');
                if(isset($this->isCustomInlineTagList[$customtagname]))
                    $isinline = $this->isCustomInlineTagList[$customtagname];
            }
            if($isinline)
            {
                $inlinenodeStatck[] = $tmpnode;
                $onode->removeLastChild();
            } else
                break;
        }

        while ( $lastStackNode = array_pop( $inlinenodeStatck ) )
        {
            $nnode->appendChild( $lastStackNode );
            unset( $lastStackNode );
        }

        if($nnode->hasChildren())
        {
            $odom->registerElement($nnode);
            $onode->appendChild($nnode);
        }
        unset($nnode);
    }

    /*!
    \reimp
    */
    function &convertInput( &$text )
    {
        // fix newlines
        // Convet windows newlines
        $text =& preg_replace( "#\r\n#", "\n", $text );
        // Convet mac newlines
        $text =& preg_replace( "#\r#", "\n", $text );
        // remove all \n
        $text =& preg_replace( "#\n+#", "", $text );

        $xhtml = '<xhtml>'.$text.'</xhtml>';
        $ezxml = new eZXML;
        $idom =& $ezxml->domTree($xhtml, array('CharsetConversion' => false,
                                            'ConvertSpecialChars' => false));
        $message = array();
        $odom =&  new eZDOMDocument();

        if(!$idom)
        {
            $message[] = 'Input Text is not in valid XML format: '.$text."\n";
            return array( $odom, $message );
        }

        $iroot = &$idom->root();
        assert($iroot->name() == 'xhtml');

        $nnode = eZDOMDocument::createElementNode( "section" );
        $attr = eZDOMDocument::createAttributeNode( 'image', 'http://ez.no/namespaces/ezpublish3/image/', 'xmlns' );
        $nnode->appendAttribute($attr );
        unset($attr);
        $attr = eZDOMDocument::createAttributeNode( 'xhtml', 'http://ez.no/namespaces/ezpublish3/xhtml/', 'xmlns' );
        $nnode->appendAttribute($attr );
        unset($attr);
        $attr = eZDOMDocument::createAttributeNode( 'custom', 'http://ez.no/namespaces/ezpublish3/custom/', 'xmlns' );
        $nnode->appendAttribute($attr );
        unset($attr);
        $odom->setRoot($nnode);
        unset($nnode);
        $this->convertSectionDomNode($idom->root(), $odom->root(), $message, $odom);

        $output = array( $odom, $message );
        return $output;
    }

    /*!
    \reimp
    Returns the input XML representation of the datatype.
    */
    function &inputXML()
    {
        $out =& new SJSDXMLOutput( $this->XMLData, null, $this->ContentObjectAttribute, true );
        return $out->outputText();
    }

    function customObjectAttributeHTTPAction( $http, $action, &$contentObjectAttribute )
    {
        include_once( 'kernel/classes/ezpreferences.php' );
        $enable = 1;
        if($action == 'disable_sjsd_editor')
            $enable = 0;
        eZPreferences::setValue("enable_sjsd_editor", $enable);
    }

    var $SectionArray = array( 'paragraph', 'section', 'header' );

    var $BlockTagArray = array( 'table', 'ul', 'ol', 'literal', 'custom' );

    var $InLineTagArray = array( 'emphasize', 'strong', 'link', 'anchor', 'line', 'object', 'embed' );

    var $LineTagArray = array( 'emphasize', 'strong', 'link', 'anchor', /*'li',*/ 'object', 'embed' );

    var $TagAliasArray = array( 'strong' => array( 'b', 'bold' ), 'emphasize' => array( 'em', 'i' ), 'link' => array( 'a' ) , 'header' => array( 'h' ), 'paragraph' => array( 'p' ), 'literal' => array( 'pre' ), 'embed' => array( 'img', 'object' ), 'custom' => array( 'span', 'div' ) );

    /// Contains all supported tag for xml parse
    var $SupportedTagArray = array( 'paragraph', 'section', 'header', 'table', 'ul', 'ol', 'literal', 'custom', 'object', 'embed', 'emphasize', 'strong', 'link', 'anchor', 'tr', 'td', 'th', 'li', 'line' );

    /// Contains all supported input tag
    var $SupportedInputTagArray = array( 'header', 'table', 'ul', 'ol', 'literal', 'custom', 'object', 'embed', 'emphasize', 'strong', 'link', 'anchor', 'tr', 'td', 'th', 'li' );

    var $ContentObjectAttribute;

    var $IsInputValid;

    /// Contains all links hashed by ID
    var $LinkArray = array();

    var $IsStrictHeader = false;

    var $HeaderNames = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6');
    var $CloneTags = array( 'strong', 'emphasize', 'ul', 'ol' );

    var $InternalLinkPattern = '/(ezobject:\/\/|eznode:\/\/)(\d+)(#.*)?/';
    //only tags in this array can be included in the generated xml with
    //no subs tags all others will be removed
    var $EmptyTags = array( '#text', 'embed', 'embed-inline', 'anchor', 'object' );
}
?>
