/** 
* Add "Object Properties" to the Image contextmenu to replace the orignal "Image Properties" item
* Overwrite the internal function that returns the Context Menu items 
*/
FCKContextMenu.__GetGroup = FCKContextMenu._GetGroup; 
FCKContextMenu._GetGroup = function( groupName ) 
{
	var oGroup ;
 
	switch ( groupName )
	{
		case 'EzCustomTagMenu':
		    oGroup = new FCKContextMenuGroup(true) ;
// 		    oGroup.Add( new FCKContextMenuSeparator() ) ;
		    oGroup.Add( new FCKContextMenuItem( this, 'EZCustomAttributes'       , 'Custom Tag Properties' , false ) ) ;
			oGroup.__RefreshState = oGroup.RefreshState;
			oGroup.RefreshState = function()
			{
			     //TODO Handle sub/sup etc
				// Get the custom tag div/span
				//var incustom = FCK.Selection.HasAncestorNode( 'SPAN' ) || FCK.Selection.HasAncestorNode( 'DIV' );
				var oTag = FCKTools.GetElementAscensor(FCK.Selection.GetParentElement(),'SPAN,DIV');
				//TODO: this is caused by a bug in FCK.Selection.GetParentElement() in IE,
				//for now, we work around it, hopefully it is gone in next release of fck
				if(!oTag) //in IE, it does not return the node, we try it another way
				{
				    oTag = FCK.Selection.MoveToAncestorNode('SPAN');
				    if(!oTag)
				        oTag = FCK.Selection.MoveToAncestorNode('DIV');
				}
				if(oTag && !oTag.id.toLowerCase().startsWith('custom_'))
				    oTag = null;
				if(!oTag)
				{
				    this.SetVisible( false ) ;
                } else
                    this.SetVisible( true ) ;

// 	            var customtagname = oTag.id.toLowerCase().substr(7) ;
// 	            alert(customtagname);
// 	            this.Add( new FCKContextMenuItem( this, 'EZCustomAttributes',
// 	               customtagname+' Properties' , false ) ) ;
				this.__RefreshState();
			}
			break;
		case 'Image' :
			oGroup = new FCKContextMenuGroup(true, this, 'EZ_Embed', 'Object Properties', true) ;

			oGroup.__RefreshState = oGroup.RefreshState;
			oGroup.RefreshState = function()
			{
				// Get the actual selected tag (if any). 
				var oTag = FCKSelection.GetSelectedElement() ;
				var sTagName ;
	
				if ( oTag )
					sTagName = oTag.tagName ;
                                if( sTagName == 'IMG' )
				{
				    this.SetVisible( oTag.getAttribute('_ez_embed')=='1' ) ;
				}
				this.__RefreshState();
			}
		break ;
		default:
// 				Calls the original function
				oGroup = this.__GetGroup(groupName);
	}
	return oGroup;
}
