// var fckPage		= window.opener.window.parent.window.opener.window.parent.window;
// var EZInfo 		= fckPage.EZInfo;

var listtable;
//TODO: move this function to global
//When FCKeditor has this one, remove it
function addEventListener(element, event, callback)
{
    if (element.addEventListener){
        element.addEventListener(event, callback, false);
    } else if (element.attachEvent){
        element.attachEvent('on'+event, callback);
    }
}
window.onload = function()
{
    var tables = document.getElementsByTagName('TABLE') ;
    for(var i in tables)
        if(tables[i].className != undefined && (tables[i].className.toLowerCase() == 'list' ||
            tables[i].className.toLowerCase() == 'list-thumbnails'))
        {
            listtable = tables[i];
            break;
        }
    if(listtable == undefined)
    {
        alert('Error: can not find the list table!');
        return false;
    }

    var okbutton = document.getElementsByName('SelectButton')[0] ;
    if(okbutton == undefined)
    {
        alert('Error: can not find the ok button!');
        return false;
    } else
        addEventListener(okbutton, 'click', okClicked);

    var cancelbutton = document.getElementsByName('BrowseCancelButton')[0] ;
    if(cancelbutton == undefined)
    {
        alert('Error: can not find the cancelbutton button!');
        return false;
    } else
        addEventListener(cancelbutton, 'click', cancelClicked);

    //remove the action property of the browse form
    var iforms = document.getElementsByTagName('FORM') ;
    for(var i in iforms)
        if(iforms[i].name == "browse")
        {
            iforms[i].action = '';
            break;
        }
}

function okClicked() {
    var ids = listtable.getElementsByTagName('INPUT') ;
    var selectedids = new Array;
    for(var i=0;i<ids.length;++i)
    if(ids[i].checked)
    {
        if(ids[i].name=='SelectedObjectIDArray[]')
            selectedids[selectedids.length]="ezobject://"+ids[i].value;
        else
            selectedids[selectedids.length]="eznode://"+ids[i].value;
    }
    if(selectedids.length>0)
    {
//         alert(window.top.opener.location);
        window.opener.SetUrl( selectedids ) ;
        window.close() ;
        window.opener.focus() ;
        return false;
    }
    alert("Please select at least one item!");
    return false;
}

function cancelClicked() {
    window.close();
    return false;
}
