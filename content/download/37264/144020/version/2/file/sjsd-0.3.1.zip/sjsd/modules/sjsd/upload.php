<?
include_once( 'kernel/classes/ezcontentupload.php' );

$module =& $Params['Module'];

if ( isset( $Module ) )
    $Module =& $Params['Module'];
$objectID =& $Params['ObjectID'];
if ( !isset( $EditVersion ) )
    $editVersion =& $Params['EditVersion'];

if ( !isset( $editLanguage ) and
     isset( $Params['EditLanguage'] ) )
    $editLanguage = $Params['EditLanguage'];
if ( !isset( $editLanguage ) or
     !is_string( $editLanguage ) or
     strlen( $editLanguage ) == 0 )
    $editLanguage = false;

// if ( !isset( $FromLanguage ) and
//      isset( $Params['FromLanguage'] ) )
//     $FromLanguage = $Params['FromLanguage'];
// if ( !isset( $FromLanguage ) or
//      !is_string( $FromLanguage ) or
//      strlen( $FromLanguage ) == 0 )
//     $FromLanguage = false;

if(!is_numeric($objectID))
{
    echo "Error: ObjectID is invalid in the request!";
    eZExecution::cleanExit();
}

// $objectID = $Params['ObjectID'];
$object = eZContentObject::fetch($objectID);
if(!is_object($object))
{
    echo "Error: Can not fetch object with object id $objectID!";
    eZExecution::cleanExit();
}

$classID = $object->attribute( 'contentclass_id' );
$class = eZContentClass::fetch( $classID );
echo var_dump($_FILES);

// echo "<br>xs".$http->postVariable( 'UploadLocationChoice' );
// if ( isset($_FILES['UploadFile']))
if ( $module->isCurrentAction( 'UploadedFileRelation' ) )
{
    $http =& eZHTTPTool::instance();
    //if ( $module->hasActionParameter('contentobject_id') )
    if($http->hasSessionVariable( 'ContentUploadParameters' ))
    {
        $para = $http->sessionVariable( 'ContentUploadParameters' );
        $relatedObjectID = $para['result']['object_id'];
        if ( $relatedObjectID )
        {
            $db =& eZDB::instance();
            $db->begin();
            $object->addContentObjectRelation( $relatedObjectID, $editVersion );
            $db->commit();

            echo '<html><script type="text/javascript">window.opener.window.location.reload(false) ;window.close() ;window.opener.focus() ;</script></html>';
            
        } else
            echo "Error: in relatedObjectID!";

        eZExecution::cleanExit();
    }
    else
        echo var_dump($result['errors']);//"Error in upload->handleUpload!";
}
else
{
    $pa = array( 'action_name' => 'RelatedObjectUpload',
                'description_template' => 'design:content/upload_related.tpl',
    //             'navigation_part_identifier' => $navigationPart,
                'content' => array( 'object_id' => $objectID,
                                    'object_version' => $editVersion,
                                    'object_language' => $editLanguage ),
                'keys' => array( 'class' => $class->attribute( 'id' ),
                                    'class_id' => $class->attribute( 'identifier' ),
                                    'classgroup' => $class->attribute( 'ingroup_id_list' ),
                                    'section' => $object->attribute( 'section_id' ) ),
                'result_action_name' => 'UploadedFileRelation',
                'ui_context' => 'upload',
                'result_module' => array( 'sjsd', 'upload',
                                        array( $objectID, $editVersion, $editLanguage, ) ));

    eZContentUpload::upload($pa, $module);
}
?>
