<?php
//
// Definition of SJSDXMLOutput class
//
// Copyright (C) 2006 liucougar
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Less General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//

include_once( 'kernel/classes/datatypes/ezxmltext/ezxmloutputhandler.php' );
include_once( 'lib/eztemplate/classes/eztemplateincludefunction.php' );
include_once( "kernel/common/template.php" );
include_once( 'extension/sjsd/lib/JSON.php' );

class SJSDXMLOutput extends eZXMLOutputHandler
{
    function SJSDXMLOutput( &$xmlData, $aliasedType, &$contentObjectAttribute, $washLiteralContent = false )
    {
        $this->eZXMLOutputHandler( $xmlData, $aliasedType );
        $this->ContentObjectAttribute = $contentObjectAttribute;
        $this->washLiteralContent = $washLiteralContent;
    }

    /*!
    \reimp
    */
    function &outputText()
    {
        return $this->xhtml();
    }

    /*!
    \return the XHTML rendered value of the XML data
    */
    function &xhtml()
    {
        $tpl =& templateInit();
        $xml = new eZXML();
        $res =& eZTemplateDesignResource::instance();
        if ( $this->ContentObjectAttribute )
        {
            $res->setKeys( array( array( 'attribute_identifier', $this->ContentObjectAttribute->attribute( 'contentclass_attribute_identifier' ) ) ) );
        }
        $dom =& $xml->domTree( $this->XMLData,array('CharsetConversion' => false,
                                                    'ConvertSpecialChars' => false) );
        if ( $dom )
        {
            $domNode =& $dom->elementsByName( "section" );

            $relatedObjectIDArray = array();
            $nodeIDArray = array();

            // Fetch all links and cache the url's
            $links =& $dom->elementsByName( "link" );

            if ( count( $links ) > 0 )
            {
                $linkIDArray = array();
                // Find all Link id's
                foreach ( $links as $link )
                {
                    $linkID = $link->attributeValue( 'url_id' );
                    if ( $linkID != null )
                        if ( !in_array( $linkID, $linkIDArray ) )
                            $linkIDArray[] = $linkID;

                    $objectID = $link->attributeValue( 'object_id' );
                    if ( $objectID != null )
                        if ( !in_array( $objectID, $relatedObjectIDArray ) )
                            $relatedObjectIDArray[] = $objectID;

                    $nodeID = $link->attributeValue( 'node_id' );
                    if ( $nodeID != null )
                        if ( !in_array( $nodeID, $nodeIDArray ) )
                            $nodeIDArray[] = $nodeID;
                }

                if ( count( $linkIDArray ) > 0 )
                {
                    $inIDSQL = implode( ', ', $linkIDArray );

                    $db =& eZDB::instance();
                    $linkArray = $db->arrayQuery( "SELECT * FROM ezurl WHERE id IN ( $inIDSQL ) " );

                    foreach ( $linkArray as $linkRow )
                    {
                        $this->LinkArray[$linkRow['id']] = $linkRow['url'];
                    }
                }
            }

            // Fetch all embeded objects and cache by ID
            $objectArray =& $dom->elementsByName( "object" );

            if ( count( $objectArray ) > 0 )
            {
                foreach ( $objectArray as $object )
                {
                    $objectID = $object->attributeValue( 'id' );
                    if ( $objectID != null )
                        if ( !in_array( $objectID, $relatedObjectIDArray ) )
                            $relatedObjectIDArray[] = $objectID;
                }
            }

            $embedTagArray =& $dom->elementsByName( "embed" );

            if ( count( $embedTagArray ) > 0 )
            {
                for ( $i = 0; $i < count( $embedTagArray ); ++$i )//$embedTagArray as $embedTag )
                {
                    $embedTag = &$embedTagArray[$i];
                    if ( strlen($embedTag->attributeValue( 'href' ) ) > 0 )
                    {
                        $href = rtrim($embedTag->attributeValue( 'href' ), '/'); //get rid of IE extra /
                        if ( substr( $href, 0, 11 ) == "ezobject://" )
                        {
                            $objectID = substr( $href, 11, 100 );
                            $embedTag->set_attribute('object_id', $objectID);
                        } else if ( substr( $href, 0, 9 ) == "eznode://" )
                        {
                            $nodeID = substr( $href, 9, 100 );
                            $embedTag->set_attribute('node_id', $nodeID);
                        }
                        $embedTag->removeNamedAttribute( 'href' );
                    }
                    $objectID = $embedTag->attributeValue( 'object_id' );
                    if ( $objectID != null )
                        if ( !in_array( $objectID, $relatedObjectIDArray ) )
                            $relatedObjectIDArray[] = $objectID;

                    $nodeID = $embedTag->attributeValue( 'node_id' );
                    if ( $nodeID !=null )
                        if ( !in_array( $nodeID, $nodeIDArray ) )
                            $nodeIDArray[] = $nodeID;
                }
            }

            if ( $relatedObjectIDArray != null )
                $this->ObjectArray =& eZContentObject::fetchIDArray( $relatedObjectIDArray );

            if ( $nodeIDArray != null )
            {
                $nodes =& eZContentObjectTreeNode::fetch( $nodeIDArray );

                if ( is_array( $nodes ) )
                {
                    foreach( $nodes as $node )
                    {
                        $nodeID = $node->attribute( 'node_id' );
                        $this->NodeArray["$nodeID"] = $node;
                    }
                }
                elseif ( $nodes )
                {
                    $node =& $nodes;
                    $nodeID = $node->attribute( 'node_id' );
                    $this->NodeArray["$nodeID"] = $node;
                }
            //  else
            //  {
            //      eZDebug::writeError( "Embedded node(s) fetching failed", "XML output handler" );
            //  }
            }

            $sectionNode =& $domNode[0];
            $output = "";
            if ( get_class( $sectionNode ) == "ezdomnode" )
            {
                $output =& $this->renderXHTMLSection( $tpl, $sectionNode, 0 );
            }
        }
        $res->removeKey( 'attribute_identifier' );
        return $output;
    }

    /*!
    \private
    \return the XHTML rendered version of the section
    */
    function &renderXHTMLSection( &$tpl, &$section, $currentSectionLevel, $tdSectionLevel = null )
    {
        $output = "";
        eZDebugSetting::writeDebug( 'kernel-datatype-ezxmltext', "level " . $section->toString( 0 ) );
        foreach ( $section->children() as $sectionNode )
        {
            if ( $tdSectionLevel == null )
            {
                $sectionLevel = $currentSectionLevel;
            }
            else
            {
                $sectionLevel = $tdSectionLevel;
                $currentSectionLevel = $currentSectionLevel;
            }
            $tagName = $sectionNode->name();


            switch ( $tagName )
            {
                // tags with parameters
                case 'header' :
                {
                    //TODO: fix this in INPUT handler: Add the anchor tag before the header.
                    $name = $sectionNode->attributeValue( 'anchor_name' );
                    $class = $sectionNode->attributeValue( 'class' );
                    $level = $sectionLevel;
                    if($level == 0)
                        $level = $sectionNode->attributeValue( 'level' );
                    $headerAttr = "";
                    if ( $name )
                    {
                        $output .= "<a name=\"$name\" />";
                    }
//                     $output .= "<h$level>";
    
                    if ( $class != null )
                        $headerAttr .= " class='$class'";
		    $headerchildtext = "";
		    foreach($sectionNode->children() as $child)
		        $headerchildtext .= $this->renderXHTMLTag($tpl, $child, $currentSectionLevel, $tdSectionLevel );
                    $output .= "<h$level$headerAttr>" .$headerchildtext . "</h$level>\n";
                }break;

                case 'paragraph' :
                {
                    $output .= $this->renderXHTMLParagraph( $tpl, $sectionNode, $currentSectionLevel, $tdSectionLevel );
                }break;

                case 'section' :
                {
                    $sectionLevel += 1;
                    eZDebugSetting::writeDebug( 'kernel-datatype-ezxmltext', "level ". $sectionLevel );
                    if ( $tdSectionLevel == null )
                        $output .= $this->renderXHTMLSection( $tpl, $sectionNode, $sectionLevel );
                    else
                        $output .= $this->renderXHTMLSection( $tpl, $sectionNode, $currentSectionLevel, $sectionLevel );
                }break;

                // Supported tags
                case 'emphasize' :
                case '#text' :
                case 'line' :
                case 'strong' :
                case 'ul' :
                case 'ol' :
                case 'literal' :
                case 'custom' :
                case 'link' :
                case 'table' :
                case 'object' :
                case 'anchor' :
                case 'embed' :
                {
                    $output .= $this->renderXHTMLTag( $tpl, $sectionNode, $currentSectionLevel, $isBlockTag );
                }break;

                default :
                {
                    eZDebug::writeError( "Unsupported tag at this level: $tagName", "eZXMLTextType::inputSectionXML()" );
                }break;
            }
        }
        return $output;
    }

    function &renderObjectTag(&$tpl, &$tag, &$isBlockTag, $standalone = false )
    {
        $objectID = $tag->attributeValue( 'id' );
        // fetch attributes
        $objectAttributes =& $tag->attributes();

        if ( !$standalone )
            $object =& $this->ObjectArray["$objectID"];
        else
            $object = eZContentObject::fetch( $objectID );

        // Fetch from cache
        if ( get_class( $object ) == "ezcontentobject" and
                $object->attribute( 'status' ) == EZ_CONTENT_OBJECT_STATUS_PUBLISHED )
        {
            $view = $tag->attributeValue( 'view' );
            $alignment = $tag->attributeValue( 'align' );
            $class = $tag->attributeValue( 'class' );
            $objectID = $object->attribute( 'id' );

            $res =& eZTemplateDesignResource::instance();

            // Save current class identifier for it to be restored below
            if ( isset($savedKeys['class_identifier'] ) )
            {
                $restore_class_identifier = true;
                $savedKeys = $res->keys();
                $savedClassIdentifier = $savedKeys['class_identifier'];
                unset( $savedKeys );
            } else
                $restore_class_identifier = false;

            $res->setKeys( array( array( 'classification', $class ),
                                    array( 'class_identifier', $object->attribute( 'class_identifier' ) ) ) );

            $hasLink = false;
            $linkID = $tag->attributeValue( 'ezurl_id' );
            $linkhref = $tag->attributeValue( 'ezurl_href' );

            if ( $linkID != null )
            {
                $href =& eZURL::url( $linkID );
                $target = $tag->attributeValue( 'ezurl_target' );
                $hasLink = true;
            } elseif ( strlen($linkhref) > 0 )
            {
                $href = $linkhref;
            $target = $tag->attributeValue( 'ezurl_target' );
            $hasLink = true;
            }

            if ( !isset( $target ) )
                $target = "_self";

            $attstr = '';
            $objectParameters = array();
            $objectParameters['align'] = 'right';
            foreach ( $objectAttributes as $attribute )
            {
                if ( $attribute->name() == "ezurl_id" )
                {
                    $this->LinkParameters = array();
                    $this->LinkParameters['href'] = $href;
                    $attstr .= 'ezurl_id|' . $attribute->content() . '|';
                    $attstr .= 'ezurl_href|' . $href . '|';
                }
                else if ( $attribute->name() == "ezurl_target" )
                {
                    $this->LinkParameters['target'] = $target;
                    $attstr .= 'ezurl_target|' . $target . '|';
                }
                else if ( $attribute->name() == "align" )
                {
                    $objectParameters['align'] = $alignment;
                    //$attstr .= $attribute->name() . '|' . $attribute->content() . '|';
                }
                else
                {
                    $objectParameters[$attribute->name()] = $attribute->content();
                    $attstr .= $attribute->name() . '|' . $attribute->content() . '|';
                }
            }

            if ( strlen( $view ) == 0 )
            {
                $view = "embed";
                $attstr .= 'view|embed|';
            }

            if ( $object->attribute( 'can_read' ) )
            {
                $xmlTemplate = 'object';
            }
            else
            {
                $xmlTemplate = 'object_denied';
            }

            $attstr = "alt='$attstr' id='$objectID' align='$alignment' class='object'";

            $tpl->setVariable( 'attributes', $attstr, 'xmltagns' );
            $tpl->setVariable( 'classification', $class, 'xmltagns' );
            $tpl->setVariable( 'object', $object, 'xmltagns' );
            $tpl->setVariable( 'view', $view, 'xmltagns' );
            $tpl->setVariable( 'object_parameters', $objectParameters, 'xmltagns' );
            //$tpl->setVariable( 'link_parameters', $this->LinkParameters, 'xmltagns' );

            if ( $standalone )
            {
                $tpl->setVariable( 'link_parameters', '', 'xmltagns' );
                $uri = "design:sjsd/ezxmltags/object.tpl";
                $textElements = array();
                eZTemplateIncludeFunction::handleInclude( $textElements, $uri, $tpl, "foo", "xmltagns" );
                $tagText2 = implode( '', $textElements );
            }

            $uri = "design:sjsd/ezxmltags/$xmlTemplate.tpl"; //TODO object_denied.tpl
            //$uri = "design:sjsd/ezxmltags/$xmlTemplate.tpl";

            $textElements = array();
            eZTemplateIncludeFunction::handleInclude( $textElements, $uri, $tpl, "foo", "xmltagns" );
            $tagText = implode( '', $textElements );

            // Set to true if tag breaks paragraph flow as default
            $isBlockTag = true;

            // Check if the template overrides the block flow setting
            $isBlockTagOverride = 'true';
            if ( $tpl->hasVariable( 'is_block', 'xmltagns:ContentView' ) )
            {
                $isBlockTagOverride = $tpl->variable( 'is_block', 'xmltagns:ContentView' );
            }
            else if ( $tpl->hasVariable( 'is_block', 'xmltagns' ) )
            {
                $isBlockTagOverride = $tpl->variable( 'is_block', 'xmltagns' );
            }

            if ( $isBlockTagOverride == 'true' )
                $isBlockTag = true;
            else
                $isBlockTag = false;

            if($restore_class_identifier)
            {
                // Remove the design key, so it will not override other tags
                $res->removeKey( 'classification' );
                $tpl->unsetVariable( 'classification', 'xmltagns' );

                // Restore previously saved class identifier
                $res->removeKey( 'class_identifier' );
                $res->setKeys( array( array( 'class_identifier', $savedClassIdentifier ) ) );
            }

            if (!$standalone)
                return $tagText;
            else
                return array( $tagText2, $tagText );
        }

        return "";
    }

    function &renderEmbedTag(&$tpl, &$tag, &$isBlockTag, $standalone = false )
    {
        $href = rtrim($tag->attributeValue( 'href' ), '/'); //get rid of IE extra /
        if ( substr( $href, 0, 11 ) == "ezobject://" )
        {
            $objectID = substr( $href, 11 );
        } else if ( substr( $href, 0, 9 ) == "eznode://" )
            $nodeID = substr( $href, 9 );
        else
            $objectID = $tag->attributeValue( 'object_id' );

        if ( $objectID )
        {
            if ( !$standalone )
                $object =& $this->ObjectArray["$objectID"];
            
	    if(!$object)
                $object = eZContentObject::fetch( $objectID );
            $tag->set_attribute( 'href', 'ezobject://'.$objectID );
        }

        if ( !isset($nodeID) )
            $nodeID = $tag->attributeValue( 'node_id' );

        if ( is_numeric($nodeID) )
        {
            if ( isset( $this->NodeArray[$nodeID] ) )
            {
                if ( !$standalone )
                    $node =& $this->NodeArray[$nodeID];
                else
                    $node = eZContentObjectTreeNode::fetch( $nodeID );

                $objectID = $node->attribute( 'contentobject_id' );
                $object =& $node->object();
                $tag->set_attribute( 'href', 'ezobject://'.$objectID );
            }
            else
            {
                //   eZDebug::writeError( "Node $nodeID doesn't exist", "XML output handler" );
            }
        }

        if ( !$object )
        {
            //eZDebug::writeError( "Can't fetch object. objectID: $objectID, nodeID: $nodeID", "XML output handler" );
            if (!$standalone)
                return "Can't fetch object. href: $href, objectID: $objectID, nodeID: $nodeID";
            else
                return array( "Can't fetch object. href: $href, objectID: $objectID, nodeID: $nodeID", "" );
        }

        // fetch attributes
        $embedAttributes =& $tag->attributes();

        // Fetch from cache
//         $attstr = '';
        if ( get_class( $object ) == "ezcontentobject" and
                $object->attribute( 'status' ) == EZ_CONTENT_OBJECT_STATUS_PUBLISHED )
        {
            $res =& eZTemplateDesignResource::instance();

            // Save current class identifier for it to be restored below
            if ( isset($savedKeys['class_identifier'] ) )
            {
                $restore_class_identifier = true;
                $savedKeys = $res->keys();
                $savedClassIdentifier = $savedKeys['class_identifier'];
                unset( $savedKeys );
            } else
                $restore_class_identifier = false;

            $class = $tag->attributeValue( 'class' );

            $res->setKeys( array( array( 'classification', $class ),
                                    array( 'class_identifier', $object->attribute( 'class_identifier' ) ) ) );

            $view = $tag->attributeValue( 'view' );
            if ( $view == null )
            {
                $view = 'embed';
            }

// 			$attstr .= "view|$view|";

//             if($standalone)
//                 $skipattrs = array('node_id','object_id' );
//             else
                $skipattrs = array('node_id' );
            $topattrs = array('view','size','align','id','class','href', 'object_id', 'inline');
            $objectParameters = array();
            $objectParameters['align'] = 'right';
            $objectParameters['Custom'] = array();
            foreach ( $embedAttributes as $attribute )
            {
                $attrName = $attribute->name();
                if (!in_array($attrName, $skipattrs))
                {
                    if(in_array($attrName, $topattrs))
                        $objectParameters[$attribute->name()] = $attribute->content();
                    else
                        $objectParameters['Custom'][$attribute->name()] = $attribute->content();
//                     $attstr .= $attribute->name() . '|' . $attribute->content() . '|';
                }
            }

            if ( $object->attribute( 'can_read' ) )
            {
                $xmlTemplate = 'embed';
            }
            else
            {
                $xmlTemplate = 'embed_denied';
            }

            $json = new Services_JSON();
            //only one htmlspecialchars won't make it survive fckeditor demangle, so call it twice here
            $allattrsstring = htmlspecialchars(htmlspecialchars($json->encode($objectParameters)));

            $attstr = "alt=\"$allattrsstring\" align=\"".$objectParameters['align']."\"";
            $attstr .= " _ez_embed='1'";
	    if(!empty($class) && $class!= "-1")	$attstr .= " class=\"$class\"";
            $tpl->setVariable( 'attributes', $attstr, 'xmltagns' );
            $tpl->setVariable( 'classification', $class, 'xmltagns' );
            $tpl->setVariable( 'object', $object, 'xmltagns' );
            $tpl->setVariable( 'view', $view, 'xmltagns' );
            $tpl->setVariable( 'object_parameters', $objectParameters, 'xmltagns' );
//             $tpl->setVariable( 'link_parameters', $this->LinkParameters, 'xmltagns' );

            if ( $standalone )
            {
                $tpl->setVariable( 'link_parameters', '', 'xmltagns' );
                $uri = "design:sjsd/ezxmltags/embed.tpl";
                $textElements = array();
                eZTemplateIncludeFunction::handleInclude( $textElements, $uri, $tpl, "foo", "xmltagns" );
                $tagText2 = implode( '', $textElements );
            }

            $uri = "design:sjsd/ezxmltags/$xmlTemplate.tpl"; //TODO embed_denied.tpl

            $textElements = array();
            eZTemplateIncludeFunction::handleInclude( $textElements, $uri, $tpl, "foo", "xmltagns" );
            $tagText = implode( '', $textElements );

            // Set to true if tag breaks paragraph flow as default
            $isBlockTag = $tag->attributeValue('inline') == '1' ? false : true;

            // Check if the template overrides the block flow setting
            /*$isBlockTagOverride = 'true';
            if ( $tpl->hasVariable( 'is_block', 'xmltagns:ContentView' ) )
            {
                $isBlockTagOverride = $tpl->variable( 'is_block', 'xmltagns:ContentView' );
            }
            else if ( $tpl->hasVariable( 'is_block', 'xmltagns' ) )
            {
                $isBlockTagOverride = $tpl->variable( 'is_block', 'xmltagns' );
            }

            if ( $isBlockTagOverride == 'true' )
                $isBlockTag = true;
            else
                $isBlockTag = false;*/

            if($restore_class_identifier)
            {
                // Remove the design key, so it will not override other tags
                $res->removeKey( 'classification' );
                $tpl->unsetVariable( 'classification', 'xmltagns' );

                // Restore previously saved class identifier
                $res->removeKey( 'class_identifier' );
                $res->setKeys( array( array( 'class_identifier', $savedClassIdentifier ) ) );
            }

            if (!$standalone)
                return $tagText;
            else
                return array( $tagText2, trim($tagText) );
        }

        return "";
    }

    /*!
    \private
    \return the XHTML rendered version of the section
    */
    function &renderList( &$tpl, &$listNode, $currentSectionLevel, $listSectionLevel = null )
    {
        $output = "";
        $tagName = $listNode->name();
        switch ( $tagName )
        {
            case 'paragraph' :
            {
                $output .= $this->renderXHTMLParagraph( $tpl, $listNode, $currentSectionLevel, $listSectionLevel );
            }break;

            case 'section' :
            {
                $sectionLevel += 1;
                if ( $listSectionLevel == null )
                    $output .= $this->renderXHTMLSection( $tpl, $listNode, $sectionLevel );
                else
                    $output .= $this->renderXHTMLSection( $tpl, $listNode, $currentSectionLevel, $sectionLevel );
            }break;

            default :
            {
                eZDebug::writeError( "Unsupported tag at this level: $tagName", "eZXMLTextType::inputSectionXML()" );
            }break;
        }
        return $output;
    }

    /*!
    \private
    \return XHTML rendered version of the paragrph
    */
    function &renderXHTMLParagraph( &$tpl, $paragraph, $currentSectionLevel, $tdSectionLevel = null )
    {
        $insideParagraph = true;
        $paragraphCount = 0;
        $paragraphContentArray = array();

        $sectionLevel = $currentSectionLevel;
        $class = $paragraph->attributeValue( 'class' );
        $curChildIndex = 0;
        $totalChildren = count( $paragraph->children() );
			
        foreach ( $paragraph->children() as $paragraphNode )
        {
            $curChildIndex++;

            if ( $curChildIndex == $totalChildren ) 
            {
                $this->LastParagraphChild = true;
            }
            else
            {
                $this->LastParagraphChild = false;
            }
            $isBlockTag = false;
            $content =& $this->renderXHTMLTag( $tpl, $paragraphNode, $sectionLevel, $isBlockTag, $tdSectionLevel );
            if ( $isBlockTag === true )
            {
                $paragraphCount++;
            }

            if ( !isset( $paragraphContentArray[$paragraphCount]['Content'] ) )
                $paragraphContentArray[$paragraphCount] = array( "Content" => $content, "IsBlock" => $isBlockTag );
            else
                $paragraphContentArray[$paragraphCount] = array( "Content" => $paragraphContentArray[$paragraphCount]['Content'] . $content, "IsBlock" => $isBlockTag );
            if ( $isBlockTag === true )
            {
                $paragraphCount++;
            }
        }
        $output = "";
        foreach ( $paragraphContentArray as $paragraphContent )
        {
            if ( !$paragraphContent['IsBlock'] )
            {
                $output .= '<p>'.$paragraphContent['Content']."</p>\n";
            }
            else
            {
                $output .= $paragraphContent['Content'];
            }

        }
//         if ( $paragraph->children() == null )
//             $output = "<p>&nbsp;</p>";
        return $output;
    }

    /*!
    \private
    Will render a tag and return the rendered text.
    */
    function &renderXHTMLTag( &$tpl, &$tag, $currentSectionLevel, &$isBlockTag, $tdSectionLevel = null, $isChildOfLinkTag = false )
    {
        $tagText = "";
        $childTagText = "";
        $tagName = $tag->name();

        // Set link parameters for rendering children of link tag
        if ( $tagName=="link" )
        {
            $href='';
            if ( $tag->attributeValue( 'url_id' ) != null )
            {
                $linkID = $tag->attributeValue( 'url_id' );
                $href = $this->LinkArray[$linkID];

                include_once( 'lib/ezutils/classes/ezmail.php' );
                if ( eZMail::validate( $href ) )
                    $href = "mailto:" . $href;
            }
            elseif ( $tag->attributeValue( 'node_id' ) != null )
            {
                $nodeID = $tag->attributeValue( 'node_id' );
                $node =& $this->NodeArray[$nodeID];
                if ( $node != null )
                {
                    $href = "eznode://".$nodeID;
                }
                //else
                //{
                //    eZDebug::writeError( "Node $nodeID doesn't exist", "XML output handler" );
                //}
            }
            elseif ( $tag->attributeValue( 'object_id' ) != null )
            {
                $objectID = $tag->attributeValue( 'object_id' );
                $object =& $this->ObjectArray["$objectID"];
                if ( $object )
                {
                    $node =& $object->attribute( 'main_node' );
                    if ( $node )
                    {
                        $href = "ezobject://".$objectID;
                    }
                    // else
                    // {
                    //     eZDebug::writeError( "Object $objectID is not attached to a node", "XML output handler" );
                    // }
                }
                // else
                //  {
                //     eZDebug::writeError( "Object $objectID doesn't exist", "XML output handler" );
                //  }
            }
            elseif ( $tag->attributeValue( 'href' ) != null )
            {
                $href = $tag->attributeValue( 'href' );
                include_once( 'lib/ezutils/classes/ezmail.php' );
                if ( eZMail::validate( $href ) )
                    $href = "mailto:" . $href;
            }

            if ( $tag->attributeValue( 'anchor_name' ) != null )
            {
                $href .= '#' . $tag->attributeValue( 'anchor_name' );
            }

            if ( $href != '' )
            {

            // Making valid URI  (commented cause decided to use ezurl in template)
            // include_once( 'lib/ezutils/classes/ezuri.php' );
            //  eZURI::transformURI( $href );

                $this->LinkParameters['href'] = $href;

                $this->LinkParameters['class'] = $tag->attributeValue( 'class' );
                $this->LinkParameters['target'] = $tag->attributeValue( 'target' );
                $this->LinkParameters['title'] = $tag->attributeValueNS( 'title', 'http://ez.no/namespaces/ezpublish3/xhtml/' );
                $this->LinkParameters['id'] = $tag->attributeValueNS( 'id', 'http://ez.no/namespaces/ezpublish3/xhtml/' );
            }
        }

        // render children tags using recursion
        $tagChildren = $tag->children();

        foreach ( $tagChildren as $childTag )
        {
            switch( $tagName )
            {
                case "literal" :
                {
                    //<br/> is required for fckeditor to mark a new line
                    $text = str_replace("\n",'<br />',$childTag->content());

                    if($this->washLiteralContent)
                        $text = htmlspecialchars($text);

                    $childTagText .= $text;
                }break;

                // Tables and lists are rendered separately
                case "table":
                case "ul":
                case "ol":
                    break;
                default :
                    $childTagText .= $this->renderXHTMLTag( $tpl, $childTag, $currentSectionLevel, $isBlockTag, $tdSectionLevel, $isChildOfLinkTag );
            }
        }

        switch ( $tagName )
        {
            case 'link' :
            {
                $text = $childTagText;
                $attrstr = '';
                if(!empty($this->LinkParameters['target']))
                    $attrstr = " target=\"".$this->LinkParameters['target']."\"";
                $tagText .= "<a href=\"".$this->LinkParameters['href']."\"$attrstr>$text</a>";
            }break;
            case '#text' :
            {
                $text = $tag->content();
                // Get rid of linebreak and spaces stored in xml file
                $text =& preg_replace( "#[\n]+#", "", $text );
                $text =& preg_replace( "#    #", "", $text );

//                 if ( $isChildOfLinkTag )
//                 {
//                     $res =& eZTemplateDesignResource::instance();
//                     $res->setKeys( array( array( 'classification', $this->LinkParameters['class'] ) ) );
// 
//                     $tpl->setVariable( 'content', $text, 'xmltagns' );
// 
//                     $tpl->setVariable( 'href', $this->LinkParameters['href'], 'xmltagns' );
//                     $tpl->setVariable( 'target', $this->LinkParameters['target'], 'xmltagns' );
//                     $tpl->setVariable( 'classification', $this->LinkParameters['class'], 'xmltagns' );
//                     $tpl->setVariable( 'title', $this->LinkParameters['title'], 'xmltagns' );
//                     $tpl->setVariable( 'id', $this->LinkParameters['id'], 'xmltagns' );
// 
//                     $uri = "design:sjsd/ezxmltags/link.tpl";
// 
//                     eZTemplateIncludeFunction::handleInclude( $textElements, $uri, $tpl, 'foo', 'xmltagns' );
// 
//                     $tagText .= implode( '', $textElements );
// 
//                     // Remove the design key, so it will not override other tags
//                     $res->removeKey( 'classification' );
//                     $tpl->unsetVariable( 'classification', 'xmltagns' );
//                 }
//                 else
                {
                    $tagText .= $text;
                }
            }break;

            case 'object' :
            {
                $tagText = $this->renderObjectTag($tpl, $tag, $isBlockTag );
            }break;

	    case 'embed-inline' :
	        $tag->appendAttribute( eZDOMDocument::createAttributeNode( 'inline', '1' ) );
		//fall through
            case 'embed' : 
            {
                $tagText = $this->renderEmbedTag($tpl, $tag, $isBlockTag );
            }break;

            case 'table' :
            {
                $tableRows = "";
                $border = $tag->attributeValue( 'border' );
                if ( $border === null )
                    $border = 1;

                $width = $tag->attributeValue( 'width' );
                if ( $width === null )
                    $width = "100%";

                $tableClassification = $tag->attributeValue( 'class' );

                $rowCount = 0;
                // find all table rows
                foreach ( $tag->children() as $tableRow )
                {
                    $tableData = "";
                    $cellCount = 0;
                    foreach ( $tableRow->children() as $tableCell )
                    {
                        $cellContent = "";
                        $tableCellChildren = $tableCell->children();
                        // If <paragraph> is the one and only child then don't render it as <p>.
                        if ( ( count( $tableCellChildren ) == 1 ) and ( count( $tableCellChildren[0]->children() ) == 1  ) )
                        {
                            if ( $tableCellChildren[0]->name() == "paragraph" )
                            {
                                $cellContent .= $this->renderXHTMLSection( $tpl, $tableCellChildren[0], 0, 0 );
                            }
                            else
                                $cellContent .= $this->renderXHTMLSection( $tpl, $tableCell, 0, 0 );
                        }
                        else
                            $cellContent .= $this->renderXHTMLSection( $tpl, $tableCell, 0, 0 );

                        $cellWidth = $tableCell->attributeValueNS( 'width', "http://ez.no/namespaces/ezpublish3/xhtml/" );
                        $colspan = $tableCell->attributeValueNS( 'colspan', "http://ez.no/namespaces/ezpublish3/xhtml/" );
                        $rowspan = $tableCell->attributeValueNS( 'rowspan', "http://ez.no/namespaces/ezpublish3/xhtml/" );

                        $class = $tableCell->attributeValue( 'class' );

                        $res =& eZTemplateDesignResource::instance();
                        $res->setKeys( array( array( 'classification', $class ),
                                            array( 'table_classification', $tableClassification ) ) );

//                         if ( $tableCell->Name == "th" )
//                             $uri = "design:sjsd/ezxmltags/th.tpl";
//                         else
//                             $uri = "design:sjsd/ezxmltags/td.tpl";
                        $textElements = array();

//                         $tpl->setVariable( 'row_count', $rowCount, 'xmltagns' );
//                         $tpl->setVariable( 'col_count', $cellCount, 'xmltagns' );

                        if(empty($cellContent)) $cellContent='&nbsp;';

                        if ( $tableCell->Name == "th" )
                            $celltype = 'th';
                        else
                            $celltype = 'td';
                        $attstr = '';
                        if(!empty($class)) $attstr .= " class=\"$class\"";
                        if(!empty($colspan)) $attstr .= " colspan=\"$colspan\"";
                        if(!empty($rowspan)) $attstr .= " rowspan=\"$rowspan\"";
                        if(!empty($cellWidth)) $attstr .= " width=\"$cellWidth\"";

                        $tableData .= "<$celltype$attstr>$cellContent</$celltype>\n";

                        $cellCount++;
                    }
                    $attstr = '';
                    if(!empty($class)) $attstr .= " class=\"$class\"";

                    $tableRows .= "<tr$attstr>\n$tableData</tr>\n";

//                     $tpl->setVariable( 'row_count', $rowCount, 'xmltagns' );
                    $rowCount++;
                }

                $attstr = '';
                if(!empty($class)) $attstr .= " class=\"$class\"";
                if(!empty($border)) $attstr .= " border=\"$border\"";
                if(!empty($width)) $attstr .= " width=\"$width\"";

                $tagText .= "<table$attstr>\n$tableRows</table>\n";

//                 $tpl->setVariable( 'rows', $tableRows, 'xmltagns' );

                $isBlockTag = true;
            }break;

            case 'ul' :
            case 'ol' :
            {
                $isBlockTag = true;

                $listContent = "";
                // find all list elements
                foreach ( $tag->children() as $listItemNode )
                {
                    $listItemContent = "";

                    $listSectionLevel = $currentSectionLevel;

                    $listChildren =& $listItemNode->children();

                    // If <paragraph> is the one and only child then don't render it as <p>.
                    if ( count( $listChildren ) == 1 )
                    {
                        if ( $listChildren[0]->name() == "paragraph" )
                        {
                            $listChildren = $listChildren[0]->children();
                        }
                    }

                    foreach ( $listChildren as $itemChildNode )
                    {
                        $listSectionLevel = $currentSectionLevel;
                        if ( $itemChildNode->name() == "section" or $itemChildNode->name() == "paragraph" )
                        {
                            $listItemContent .= $this->renderList( $tpl, $itemChildNode, $currentSectionLevel, $listSectionLevel );
                        }
                        else
                        {
                            $listItemContent .= $this->renderXHTMLTag( $tpl, $itemChildNode, 0, $isBlockTag );
                        }
                    }

                    $liClass = $listItemNode->attributeValue( 'class' );
                    $attstr = '';
                    if(!empty($liClass))
                        $attstr = " class=\"$liClass\"";
                    $listContent .= "<li$attstr>$listItemContent</li>\n";
                }

                $className = $tag->attributeValue( 'class' );
                $attstr = '';
                if(!empty($className))
                    $attstr = " class=\"$className\"";
                $tagText .= "<$tagName$attstr>\n$listContent</$tagName>\n";
            }break;

            // Literal text which allows xml specific caracters < >
            case 'literal' :
                $isBlockTag = true;
            case 'emphasize' :
            case 'strong' :
            {
                $class = $tag->attributeValue( 'class' );
                $attstr = '';
                if(!empty($class))
                    $attstr = " class=\"$class\"";
                $mapedtagname = $this->XmlTag2HtmlTag[$tagName];
                $tagText .= "<$mapedtagname$attstr>".$childTagText."</$mapedtagname>";
            }break;

            case 'line' :
            {
                $tagText .= $childTagText;
                if ( $tagName == 'line' && !$this->LastParagraphChild )
                    $tagText .= "<br />";
            }break;
            // custom tags which could added for special custom needs.
            case 'custom' :
            {
                // Get the name of the custom tag.
                $name = $tag->attributeValue( 'name' );
                $isInline = false;
                include_once( "lib/ezutils/classes/ezini.php" );
                $ini =& eZINI::instance( 'content.ini' );

                $isInlineTagList =& $ini->variable( 'CustomTagSettings', 'IsInline' );
                foreach ( array_keys ( $isInlineTagList ) as $key )
                {
                    $isInlineTagValue =& $isInlineTagList[$key];
                    if ( $isInlineTagValue )
                    {
                        if ( $name == $key )
                            $isInline = true;
                    }
                }

                if ( $isInline )
                {
                    $childContent = $childTagText;
                }
                else
                {
                    $childContent = $this->renderXHTMLSection( $tpl, $tag, $currentSectionLevel, $tdSectionLevel );
                    $isBlockTag = true;
                }

                $customattstr = '';
                $customAttributes =& $tag->attributesNS( "http://ez.no/namespaces/ezpublish3/custom/" );
                foreach ( $customAttributes as $attribute )
                {
                    $customattstr .= " ".$attribute->Name.'="'.$attribute->Content.'"';
                }
                $sjsdini =& eZINI::instance( 'sjsd.ini' );
                $startTags =& $sjsdini->variable( 'CustomTagSettings', 'StartTags' );
                if(isset($startTags[$name]))
                {
                    $ctmtag = $startTags[$name];
                    $tagText .= "<$ctmtag$customattstr>$childContent</$ctmtag>";
                } else //div or span custom tags
                {
                    $customattstr .= " id=\"custom_$name\"";
                    if($isInline)   //span
                    {
                        $tagText .= "<span$customattstr>$childContent</span>";
                    }else
                    {
                        $tagText .= "<div$customattstr>$childContent</div>";
                    }
                }
            }break;

            case 'anchor' :
            {
                $name = $tag->attributeValue( 'name' );
                if($name[0] == '#')
                    $name = substr($name,1);
                $tagText .= "<a name=\"$name\" ></a>";
            }break;

            default :
            {
                // unsupported tag
            }break;
        }
        return $tagText;
    }

    /// Contains the URL's for <link> tags hashed by ID
    var $LinkArray = array();

    /// Contains the Objects hashed by ID
    var $ObjectArray = array();

    var $InLineTagArray = array( 'emphasize', 'strong', 'link', 'anchor', '#text' );

    var $XmlTag2HtmlTag = array('literal'=>'pre','emphasize'=>'i','strong'=>'b');

    /// Contains the Nodes hashed by ID
    var $NodeArray = array();

    /// Array of parameters for rendering tags that are children of 'link' tag
    var $LinkParameters = array();

    /// Contains boolean flag if current child is last among paragraph children
    /// used when rendering last <line> tag.
    var $LastParagraphChild = false;

    var $washLiteralContent = false;
}

?>
