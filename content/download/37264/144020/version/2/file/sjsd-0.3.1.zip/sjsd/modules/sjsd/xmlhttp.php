<?php

include_once( 'lib/ezutils/classes/ezhttppersistence.php' );
include_once( 'extension/sjsd/ezxmltext/handlers/input/sjsdxmlinput.php' );
include_once( 'extension/sjsd/ezxmltext/handlers/output/sjsdxmloutput.php' );
include_once( 'kernel/classes/ezcontentobjectattribute.php' );
include_once( 'extension/sjsd/lib/JSON.php');
include_once( 'kernel/classes/ezcontentobjecttreenode.php');

include_once( 'lib/ezutils/classes/ezhttptool.php' );

$Module =& $Params["Module"];

function input( $attributeField, $ver, $input )
{
    $attID = substr( strrchr( $attributeField, "_" ), 1 );

    $att = eZContentObjectAttribute::fetch( $attID, $ver );
    $dummy = '';
    $in = new SJSDXMLInput( $dummy, null, $att );

    $data = $in->jsrsValidateInput( $input );

    return $data;
}

function output( $attributeField, $ver, $input )
{
    $attID = substr( strrchr( $attributeField, "_" ), 1 );
    $att = eZContentObjectAttribute::fetch( $attID, $ver );

    $input = ltrim($input);
    $first8chars = substr($input, 0, 8);
    $message = array();
    if($first8chars !='<?xml ve' && $first8chars != '<section')
    {
        //this is probably a simplified xml input, try it
        include_once( 'kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php' );
        $dummy = '';
        $simplexml =& new eZSimplifiedXMLInput( $dummy, null, $att );
        $data =& $simplexml->convertInput( $input, false );
        if($simplexml->IsInputValid)
            $input = $data[0]->toString(false,false,false);
        else
            $message = $data[1];
    }
    $out =& new SJSDXMLOutput( $input, null, $att, false );

    return array($out->outputText(), $message);
}

function getEmbedObjectHtml($attrs)
{
    $attstr = "object_id=\"".$attrs['objectIDToInsert']."\" ";
    if(isset($attrs['objectClass']) && !empty($attrs['objectClass']) && $attrs['objectClass']!='-1')
        $attstr .= "class=\"".$attrs['objectClass']."\" ";
    $attstr .= "view=\"".$attrs['objectView']."\" ";
    $attstr .= "align=\"".$attrs['objectAlign']."\" ";
    $attstr .= "xhtml:id=\"".htmlspecialchars($attrs['htmlID'])."\" ";
    $attstr .= "inline=\"".$attrs['isInline']."\" ";
    if(!empty($attrs['objectSize']))
        $attstr .= "size=\"".$attrs['objectSize']."\" ";

    foreach ( $attrs['customAttributes'] as $key => $val)
    {
        $attstr .= $key . "='" . $val . "' ";
    }
//     return array( 'Error' => 0, 'Preview' => '', 'RawImage'=>$attstr);
    $ezxml = new eZXML;
    $dom = $ezxml->domTree( '<tag><embed ' . $attstr . '/></tag>' );

    $node = $dom->elementsByName('embed');

    $objtpl =& templateInit();

    include_once( 'kernel/classes/datatypes/ezxmltext/ezxmloutputhandler.php' );

    $isBlockTag = true;

    $data = SJSDXMLOutput::renderEmbedTag($objtpl, $node[0], $isBlockTag, true );

    return array( 'Error' => 0, 'Preview' => $data[0], 'RawImage'=>$data[1]);
}

function embed( $custom )
{
    $arr = array();
    $arr = explode( '|', $custom );
    $attstr = '';

    for ( $i=0; $i<count( $arr ); $i+=2 )
    {
        if ( isset($arr[$i]) && isset($arr[$i+1]) )
        {
            $name = strtolower( trim( $arr[$i] ) );
            $content = trim( $arr[$i+1] );
            if ( $name != '' && $content != '' )
            {
                $attstr .= $name . "='" . $content . "' ";
            }
        }
    }

    $dom = eZXML::domTree( '<tag><embed ' . $attstr . '/></tag>' );

    $node = $dom->elementsByName('embed');

    $objtpl =& templateInit();

    include_once( 'kernel/classes/datatypes/ezxmltext/ezxmloutputhandler.php' );

    $isBlockTag = true;

    $data = SJSDXMLOutput::renderEmbedTag($objtpl, $node[0], $isBlockTag, true );

    return jsrsArrayToString( $data, "{)!(}" );
}

function obj( $custom )
{
    $arr = array();
    $arr = explode( '|', $custom );
    $attstr = '';

    for ( $i=0; $i<count( $arr ); $i+=2 )
    {
        if ( isset($arr[$i]) && isset($arr[$i+1]) )
        {
            $name = strtolower( trim( $arr[$i] ) );
            $content = trim( $arr[$i+1] );
            if ( $name != '' && $content != '' )
            {
                switch ( $name )
                {
                    case 'ezurl_id' :
                        $attstr .= "image:ezurl_id='" . $content . "' "; break;
                    case 'ezurl_href' :
                        $attstr .= "image:ezurl_href='" . $content . "' "; break;
                    case 'target' :
                        $attstr .= "image:ezurl_target='" . $content . "' "; break;
                    default :
                        $attstr .= $name . "='" . $content . "' ";
                }
            }
        }
    }

    //return jsrsArrayToString( array( '<pre>'.$attstr.'</pre>', '' ), "{)!(}" );
    $dom = eZXML::domTree( '<tag><object ' . $attstr . '/></tag>' );

    $node = $dom->elementsByName('object');

    $objtpl =& templateInit();

    include_once( 'kernel/classes/datatypes/ezxmltext/ezxmloutputhandler.php' );

    $isBlockTag = true;

    $data = SJSDXMLOutput::renderObjectTag($objtpl, $node[0], $isBlockTag, true );

    return jsrsArrayToString( $data, "{)!(}" );
}

function jsrsArrayToString( $a, $delim ){
// user function to flatten 1-dim array to string for return to client
$d = "~";
if (isset($delim)) $d = $delim;
return implode($a,$d);
}


if ( isset( $Params['Func'] ) )
{
    $output = "Error: Content is not found or function is not reconganized!";
    $http =& eZHTTPTool::instance();
    $jsonDepth = 0;
    if ( $http->hasVariable('content') )
    {
        switch ( $Params['Func'] )
        {
            case 'input':
            case 'output':
                if ( $http->hasVariable('att') && $http->hasVariable('ver'))
                {
                    $jsonDepth = -1;
                    $func = $Params['Func'];
                    $output = $func( $http->variable('att'), $http->variable('ver'), $http->variable('content') );
                }
                break;
            case 'object':
                $output = obj( $http->variable('content') );
                break;
            case 'embed':
                $output = embed( $http->variable('content') );
        break;
        }
    }

    switch ( $Params['Func'] )
    {
        case 'AddObjectRelation':
        case 'RemoveObjectRelation':
            if ( $http->hasVariable('oid') && is_numeric($http->variable('oid')) &&
                $http->hasVariable('ov') && is_numeric($http->variable('ov')) &&
                $http->hasVariable('ids'))
            {
                $rawids = $http->variable('ids');
                $selectedObjectIDArray = explode('_',$rawids);
                if(!is_array($selectedObjectIDArray) || count($selectedObjectIDArray)==0)
                {
                    $jsonDepth = -1;
                    $output = array('Error'=>1,
                            'ErrorText'=>'Selected object ids is incorrectly passed!');
                    break;
                }

                $objectID = $http->variable('oid');
                $editVersion = $http->variable('ov');
                $object = eZContentObject::fetch($objectID);
                $relatedObjects =& $object->relatedContentObjectArray( $editVersion );
                $relatedObjectIDArray = array();

                foreach (  $relatedObjects as  $relatedObject )
                    $relatedObjectIDArray[] = $relatedObject->attribute( 'id' );
                if($Params['Func'] == 'AddObjectRelation')
                {
                    foreach ( $selectedObjectIDArray as $selectedObjectID )
                    {
                        if ( $selectedObjectID != $objectID &&
                                !in_array( $selectedObjectID, $relatedObjectIDArray ) )
                            $object->addContentObjectRelation( $selectedObjectID, $editVersion );
                    }
                }
                else
                {
                    foreach ( $selectedObjectIDArray as $selectedObjectID )
                        if ( $selectedObjectID != $objectID &&
                                in_array( $selectedObjectID, $relatedObjectIDArray ) )
                            $object->removeContentObjectRelation( $selectedObjectID, $editVersion );
                }
            }
            //fall through intentally: return GetRelationList
        case 'GetRelationList':
            if ( $http->hasVariable('oid') && is_numeric($http->variable('oid')) &&
                $http->hasVariable('ov') && is_numeric($http->variable('ov')))
            {
                $objectid = $http->variable('oid');
                $editVersion = $http->variable('ov');
                $object = eZContentObject::fetch($objectid);
                //we have to retrieve this manually to display the correct icon
                $object->contentClassIdentifier();
                $relatedObjects =& $object->relatedContentObjectArray( $editVersion );

                for ( $i=0;$i<count($relatedObjects);++$i )
                {
                    $relatedObjects[$i]->contentClassIdentifier();

                    //get rid of version and language
                    $sub_dataMap = &$relatedObjects[$i]->fetchDataMap();
                    $relatedObjects[$i]->DataMap = & $sub_dataMap;

                    //retrieve some extra info for ezimage and ezbinaryfile
                    foreach(array_keys($sub_dataMap) as $key)
                    {
                        $objectattr = & $sub_dataMap[$key];
                        if($objectattr->DataTypeString == 'ezimage')
                        {
                            $content = &$objectattr->content();
                            $contattrs = &$content->attributes();
                            foreach ( $contattrs as $ca)
                            {
                                $content->$ca = $content->attribute($ca);
                            }

                            //make sure we have the alias small available
                            $ensure_alias = array("small");
                            foreach ( $ensure_alias as $ens)
                                if($content->$ens == null)
                                    $content->$ens = $content->imageAlias("$ens");

                            //ContentObjectAttribute has to be unset, it leads to recursion
                            unset($content->ContentObjectAttribute);
                        }
                        else if($objectattr->DataTypeString == 'ezbinaryfile')
                        {
                            $content = &$objectattr->content();
                            //we do not need all of the attributes,
                            //seems the standard on plus filesize is enough
                            $contattrs = array("filesize");//&$content->attributes();
                            foreach ( $contattrs as $ca)
                            {
                                $content->$ca = $content->attribute($ca);
                            }
                        }
                    }
                    //cleanup some large useless attribute
                    unset($relatedObjects[$i]->ContentObjectAttributes);
                    unset($relatedObjects[$i]->ContentObjectAttributeArray);

// 					$relatedObjects[$i]->fetchDataMap();
                }

                $ini =& eZINI::instance( 'content.ini' );

                $groups = $ini->variable( 'RelationGroupSettings', 'Groups' );
                $defaultGroup = $ini->variable( 'RelationGroupSettings', 'DefaultGroup' );

                $groupedRelatedObjects = array();
                $groupClassLists = array();
                $classGroupMap = array();
                foreach ( $groups as $groupName )
                {
                    $groupedRelatedObjects[$groupName] = array();
                    $setting = strtoupper( $groupName[0] ) . substr( $groupName, 1 ) . 'ClassList';
                    $groupClassLists[$groupName] = $ini->variable( 'RelationGroupSettings', $setting );
                    foreach ( $groupClassLists[$groupName] as $classIdentifier )
                    {
                        $classGroupMap[$classIdentifier] = $groupName;
                    }
                }
                $groupedRelatedObjects[$defaultGroup] = array();

                foreach ( $relatedObjects as $relatedObjectKey => $relatedObject )
                {
                    $classIdentifier = $relatedObject->attribute( 'class_identifier' );
                    if ( isset( $classGroupMap[$classIdentifier] ) )
                    {
                        $groupName = $classGroupMap[$classIdentifier];
                        $groupedRelatedObjects[$groupName][] =& $relatedObjects[$relatedObjectKey];
                    }
                    else
                    {
                        $groupedRelatedObjects[$defaultGroup][] =& $relatedObjects[$relatedObjectKey];
                    }
                }
                $jsonDepth = -1;
                $output = array(
                'Object'=>$object,
                'RelationList'=>$relatedObjects,
                'GroupedRelationList'=>$groupedRelatedObjects,
                'Error'=>0);
            }
            break;
        case 'GetList':
            if ( $http->hasVariable('CurrentID') && is_numeric($http->variable('CurrentID')) )
            {
                $curid = $http->variable('CurrentID');
                if($curid == 0)	$curid = 2;	//default

                $offset = 0;
                if($http->hasVariable('Offset'))
                    $offset = $http->variable('Offset');

                $jsonDepth = -1;
                $node = eZContentObjectTreeNode::fetch($curid);
                $output = array(
                'Node'=>$node,
                'Children'=>eZContentObjectTreeNode::subTree(array(
                        'Limit'=>10, 'Depth'=>1, 'Offset'=> $offset,
                        'AsObject'=>true,
                        'SortBy'=>array(
                        eZContentObjectTreeNode::sortFieldName($node->attribute('sort_field')),
                        $node->attribute('sort_order'))),
                        $curid),
                'Error'=>0);
            } else
            {
                $jsonDepth = -1;
                $output = array(
                'Node'=>'',
                'Children'=>'',
                'Error'=>102) ;
            }
            break;
        case 'GetEmbedObjectHtml':
            $json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
            $attrs = $json->decode( $http->variable('content') );
            $jsonDepth = -1;

            $output = getEmbedObjectHtml($attrs);
            break;
        case 'GetObjectPropertyOptionList':
            // Initialize size array for image.
            $imageIni =& eZINI::instance( 'image.ini' );
            if ( $imageIni->hasVariable( 'AliasSettings', 'AliasList' ) )
            {
                $sizeArray = $imageIni->variable( 'AliasSettings', 'AliasList' );
                $sizeArray[] = 'original';
            }
            else
                $sizeArray = array( 'original' );

            $contentIni =& eZINI::instance( 'content.ini' );
            $objectClasses = array();
            if ( $contentIni->hasVariable( 'object', 'AvailableClasses' ) )
                $objectClasses = $contentIni->variable( 'object', 'AvailableClasses' );

            $jsonDepth = -1;
            $output = array('Error'=>0, 'Sizes'=>$sizeArray, 'Classes'=>$objectClasses);
            break;
        case 'MimeIcons':
        case 'ClassIcons':
        case 'ClassGroupIcons':
        case 'ActionIcons':
        case 'Icons':
        {
            $returnURIOnly = false;
            // Determine whether we should return only the image URI instead of the whole HTML code.
            if ( $http->hasVariable('urionly') && $http->variable('urionly') == '1')
                $returnURIOnly = true;

            $ini =& eZINI::instance( 'icon.ini' );
            $repository = $ini->variable( 'IconSettings', 'Repository' );
            $theme = $ini->variable( 'IconSettings', 'Theme' );
            $configGroup = $Params['Func'];

            // Check if the specific icon type has a theme setting
            if ( $ini->hasVariable( $configGroup, 'Theme' ) )
            {
                $theme = $ini->variable( $configGroup, 'Theme' );
            }

            // Load icon settings from the theme
            $themeINI =& eZINI::instance( 'icon.ini', $repository . '/' . $theme );

            if ( $http->hasVariable('size') )
            {
                $sizeName = $http->variable('size');
            }
            else
            {
                $sizeName = $ini->variable( 'IconSettings', 'Size' );
                // Check if the specific icon type has a size setting
                if ( $ini->hasVariable( $configGroup, 'Size' ) )
                {
                    $theme = $ini->variable( $configGroup, 'Size' );
                }
            }

            $sizes = $themeINI->variable( 'IconSettings', 'Sizes' );
            if ( $ini->hasVariable( 'IconSettings', 'Sizes' ) )
            {
                $sizes = array_merge( $sizes,
                                    $ini->variable( 'IconSettings', 'Sizes' ) );
            }

            if ( isset( $sizes[$sizeName] ) )
            {
                $size = $sizes[$sizeName];
            }
            else
            {
                $size = $sizes[0];
            }

            $pathDivider = strpos( $size, ';' );
            if ( $pathDivider !== false )
            {
                $sizePath = substr( $size, $pathDivider + 1 );
                $size = substr( $size, 0, $pathDivider );
            }
            else
            {
                $sizePath = $size;
            }

            $width = false;
            $height = false;
            $xDivider = strpos( $size, 'x' );
            if ( $xDivider !== false )
            {
                $width = (int)substr( $size, 0, $xDivider );
                $height = (int)substr( $size, $xDivider + 1 );
            }

            $iniGroup = $Params['Func'];
            if ( $Params['Func'] == 'MimeIcons' )
            {
                $mapName = 'MimeMap';
            }
            else if ( $Params['Func'] == 'ClassIcons' )
            {
                $mapName = 'ClassMap';
            }
            else if ( $Params['Func'] == 'ClassGroupIcons' )
            {
                $mapName = 'ClassGroupMap';
            }
            else if ( $Params['Func'] == 'ActionIcons' )
            {
                $mapName = 'ActionMap';
            }
            else if ( $Params['Func'] == 'Icons' )
            {
                $mapName = 'IconMap';
            }

            $map = array();
            // Load mapping from theme
            if ( $themeINI->hasVariable( $iniGroup, $mapName ) )
            {
                $map = array_merge( $map,
                                    $themeINI->variable( $iniGroup, $mapName ) );
            }
            // Load override mappings if they exist
            if ( $ini->hasVariable( $iniGroup, $mapName ) )
            {
                $map = array_merge( $map,
                                    $ini->variable( $iniGroup, $mapName ) );
            }
            $iconPath = '/' . $repository . '/' . $theme;
            $iconPath .= '/' . $sizePath;

            if ( $themeINI->hasVariable( $iniGroup, 'Default' ) )
                $dicon = $themeINI->variable( $iniGroup, 'Default' );
            if ( $ini->hasVariable( $iniGroup, 'Default' ) )
                $dicon = $ini->variable( $iniGroup, 'Default' );

            //add a default icon
            $map['_Default'] = $dicon;

            $wwwDirPrefix = "";
            if ( strlen( eZSys::wwwDir() ) > 0 )
                $wwwDirPrefix = eZSys::wwwDir();
            $sizeText = '';
            if ( $width !== false and $height !== false )
            {
                $sizeText = ' width="' . $width . '" height="' . $height . '"';
            }

            // The class will be detected by ezpngfix.js, which will force alpha blending in IE.
            if ( ( !isset( $sizeName ) || $sizeName == 'normal' || $sizeName == 'original' ) && strstr( strtolower( $iconPath ), ".png" ) )
            {
                $class = 'class="transparent-png-icon" ';
            }
            else
            {
                $class = '';
            }

            $retmap = array();
            foreach ( $map as $classname => $icon )
            {
                if ( $returnURIOnly )
                    $retmap[$classname] = $wwwDirPrefix . $iconPath . '/' . $icon;
                else
                {
                    $altText = $classname;
                    $retmap[$classname] = '<img ' . $class . 'src="' . $wwwDirPrefix . $iconPath . '/' . $icon . '"' . $sizeText . ' alt="' .  htmlspecialchars( $altText ) . '" title="' . htmlspecialchars( $altText ) . '" />';
                }
            }

            $jsonDepth = -1;
            $output = array("Error" => 0, "IconMap" => $retmap);
        }
        break;
    }

            if($jsonDepth!=0)
            {
                $json = new Services_JSON();
                if($http->hasVariable('debug'))
                    $output = var_dump($output);
                else
                    $output = $json->encode($output,$jsonDepth);
            }
            while ( @ob_end_flush() );
            echo $output;
}

eZExecution::cleanExit();
?>
