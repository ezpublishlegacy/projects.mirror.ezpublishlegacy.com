var EZCustomTag = function(name)
{
    this.Name = name;
    this._FormatBlock = new FCKFormatBlockCommand();
    this._InlineStyles = new Object;
    this._Panel = new FCKPanel();
    this._Panel.AppendStyleSheet(FCKConfig.SkinPath+'fck_contextmenu.css');
    this._CreatePanelBody(this._Panel.Document, this._Panel.PanelDiv);
}

EZCustomTag.prototype.Execute = function(panelX, panelY, relElement)
{
    //TODO: find which style is already applied
    //ostyle.buttonDiv
    this._Panel.Show(panelX, panelY, relElement);
}

EZCustomTag.prototype.SetTag = function(tagname, isblock, recattributes)
{
    var remove = false;
    var addedcustomtag;

    //alert('here '+tagname+" "+isblock);
    if(isblock)
    {
        //TODO: BLOCKQUOTE
        this._FormatBlock.Execute('div');
        var div = FCK.Selection.MoveToAncestorNode('DIV');
        if(!div)
        {
            alert('Error: can not find the DIV just added!');
            return;
        }

        div.setAttribute('id', 'custom_'+tagname);
        addedcustomtag = div;
    }
    else
    {
        //alert(FCKSelection.GetType());
        var span;/* = FCKSelection.GetSelectedElement();
        if(span == undefined || span.tagName.toUpper() != 'SPAN')
        {
            if(span != undefined && span.tagName.toUpper() == 'TEXT')
            {
            alert(span.textContent());
                FCKSelection.Collapse(true);
            }
            span = FCK.Selection.MoveToAncestorNode('SPAN');
        }*/
        span = FCK.Selection.MoveToAncestorNode('SPAN');
        if(span)
        {
                do
            {
                if(this._InlineStyles[tagname].IsEqual(span))
                {
                    remove = true;
                    //FCKSelection.SelectNode(span);
                    break;
                }
                span=span.parentNode;
            }while(span != undefined && span.tagName.toUpper() != 'BODY');
        }
        //alert(remove);
        if(remove)
            this._InlineStyles[tagname].RemoveFromSelection();
        else
        {
            //TODO: MODIFY fckedito to let ApplyToSelection return the element inserted
            addedcustomtag = this._InlineStyles[tagname].ApplyToSelection() ;
//             FCKSelection.SelectNode(addedcustomtag);
//             addedcustomtag = FCK.Selection.MoveToAncestorNode('SPAN');
            if(false)
            if(addedcustomtag ==undefined || addedcustomtag.id.toLowerCase() != 'custom_'+ tagname)
            {
                alert(addedcustomtag);
                alert("Error: added SPAN is not valid!");
                return;
            }
        }
    }

    if(!remove)
    {
        if(typeof(recattributes) == 'object')
        {
            for(var i in recattributes)
            {
                var att = recattributes[i];
                if(att['isRequired'])
                {
                    var uinput="";
                    do
                    {
                        uinput=prompt("Please specify the content of the required attribute '"+att['name']+"'","");
                    }while(typeof(uinput)!='string' || uinput.length==0);

                    addedcustomtag.setAttribute(att['name'], uinput);
                }
            }
        }
//         FCK.Focus() ;
//         FCKSelection.Collapse();
    }
    return;
}

function EZCustomTagCommand_OnMouseOver()
{
    this.className='ColorSelected';
}

function EZCustomTagCommand_OnMouseOut()
{
    this.className='ColorDeselected';
}

function EZCustomTagCommand_OnClick()
{
    this.className = 'ColorDeselected';
    this.Command._Panel.Hide();
    this.Command.SetTag(this.CustomName, this.CustomIsBlock, this.CustomAttributes);
}

EZCustomTag.prototype._CreatePanelBody = function(targetDocument, targetDiv)
{
    function CreateSelectionDiv(CustomName)
    {
        var oDiv = targetDocument.createElement("DIV") ;
        oDiv.innerHTML = '<div class="ColorBoxBorder" title='+CustomName+' style="width:16px;height:16px;background:url(' + FCKConfig.SkinPath + 'toolbar/' + CustomName.toLowerCase() + '.gif) no-repeat center center;"></div>';
        oDiv.className		= 'ColorDeselected' ;
        oDiv.onmouseover	= EZCustomTagCommand_OnMouseOver ;
        oDiv.onmouseout		= EZCustomTagCommand_OnMouseOut ;
        return oDiv ;
    }

    var oTable = targetDiv.appendChild(targetDocument.createElement('TABLE'));
    oTable.style.tableLayout = 'fixed';
    oTable.cellPadding = 0;
    oTable.cellSpacing = 0;
    oTable.border = 0;
    oTable.width = 50;

    var oCell = oTable.insertRow(-1).insertCell(-1);
    oCell.colSpan = 2;

    var aCustomTags = EZInfo.CustomTags;
    var iCounter = 0;
//     while(iCounter < aCustomTags.length)
    var oRow;
    for(var key in aCustomTags)
    {
        if(iCounter%oCell.colSpan == 0)
            oRow = oTable.insertRow(-1);

        iCounter++;

        var oDiv = oRow.insertCell(-1).appendChild(CreateSelectionDiv(key));
        oDiv.CustomName = key;
        oDiv.CustomIsBlock = aCustomTags[key]['isBlock'];
        oDiv.CustomAttributes = aCustomTags[key]['attributes'];
        oDiv.Command = this;
        oDiv.onclick = EZCustomTagCommand_OnClick;
        var oStyleDef;
        if(!oDiv.CustomIsBlock)
        {
            oStyleDef = new FCKStyleDef(oDiv.CustomName, 'SPAN');
            oStyleDef.AddAttribute('id', 'custom_'+oDiv.CustomName);
        }else
            oStyleDef = new Object;

        oStyleDef.buttonDiv = oDiv;
        this._InlineStyles[oDiv.CustomName] = oStyleDef;
    }
}

EZCustomTag.prototype.GetState = function()
{
    return FCK_TRISTATE_OFF;
}

FCKCommands.RegisterCommand('EZCustomTag', new EZCustomTag('EZCustomTag'));

var oTaggingItem = new FCKToolbarPanelButton('EZCustomTag', FCKLang.Tagging);
FCKToolbarItems.RegisterItem('EZCustomTag', oTaggingItem);

FCKCommands.RegisterCommand( 'EZCustomAttributes'   , new FCKDialogCommand( 'EZCustomAttributes', 'Custom Tag Attributes', FCKConfig.PluginsPath + 'fcksjsd/dialog/ez_custom_attributes.html', 500, 400 ) ) ;