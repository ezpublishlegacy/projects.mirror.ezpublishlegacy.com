<?php

include_once( 'kernel/classes/ezcontentbrowse.php' );
include_once( "kernel/common/template.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );

$module =& $Params["Module"];

if(!isset($Params['ActionName']) || empty($Params['ActionName']))
{
    $Params['ActionName'] = 'AddRelatedObject';
}
$parameters = array( 'action_name' => $Params['ActionName'], 'from_page' => '');

eZContentBrowse::browse( $parameters, $module );
?>

