<?php
/*
#?ini charset="iso-8859-1"?

[ServerSettings]
ServerName=https://ssl.paiement.cic-banques.fr
RequestURI=/test/paiement.cgi
#RequestURI=/paiement.cgi

[CybermutSettings]
Business=test //edit this
Version=1.2open
TPE=6098765 //edit this

[Locale]
Currency[]
Currency[FR]=EUR

[PaymentServerSettings]
ServerName=https://ssl.paiement.cic-banques.fr
RequestURI=/test/capture_paiement.cgi
#RequestURI=/capture_paiement.cgi

*/
?>
