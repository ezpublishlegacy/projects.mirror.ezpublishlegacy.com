<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once( 'lib/ezdb/classes/ezdb.php' );
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'extension/cybermut/classes/cybermut_order.php' );
include_once( 'kernel/classes/ezorder.php' );
include_once( 'lib/ezxml/classes/ezxml.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );
$db =& eZDB::instance();

$fianetINI =& eZINI::instance( 'fianet.ini' );
print( "Debut cron \n" );

$now = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) );

$db->begin();
/* On va chercher en base tous les paiements ouverts a faire qui ne sont pas refuses par fianet */
$res = $db->arrayQuery( 'SELECT max(`payment_number`), `payment_method`, max(id), order_id, fianet FROM cybermut_order WHERE next_payment <= '.$now.' AND fianet <> 2 group BY order_id' );
$db->commit();

$refusedOrders  = array();
$nonValidOrders = array();
 
foreach ( $res as $row ){
	$valid = false;
	$orderId = $row['order_id'];
	if ( $row['fianet'] == 1 )
	{
		$valid = true;
	}else
	{
		// Demande de validation de fianet.
		$siteId = $fianetINI->variable( 'Site', 'siteId' );
		$login = $fianetINI->variable( 'Site', 'login' );
		$password = $fianetINI->variable( 'Site', 'password' );
		$url = $fianetINI->variable( 'Control', 'URL' );
		
		$order = eZOrder::fetch( $orderId );
		$orderNr = $order->attribute('order_nr');

		$finaleUrl = $url.'?SiteID='.$siteId.'&Pwd='.urlencode( $password ).'&RefID='.$orderNr.'&Mode=mini';
		
		$port = "443";
		
		$http =& eZHTTPTool::instance();
		$result = $http->sendHTTPRequest( $finaleUrl, $port, array(), 'eZ publish', false );

		$xml = new eZXML;
		$return = $xml->domTree( $result );
		if( !$return ){
			 array_push( $nonValidOrders, $orderId );
		}
		$eval = $return->elementsByName( 'eval' );
		
		// Si on a aucun resultat d'eval c'est que la commande est inconnu. On previent par mail
		if( !$eval ){
			array_push( $nonValidOrders, $orderId );
			$db->begin();
			$db->query( 'DELETE FROM cybermut_order WHERE order_id = '.$orderId );
			$db->commit();
		}else{
			$evalChildren = $eval[0]->children();
			$eval = $evalChildren[0]->content();
			
			$db->begin();
			if( $eval == '-1' || $eval == '100' ){
				$valid = true;
				// On marque la commande comme valide pour fianet
				$db->query( 'UPDATE cybermut_order SET fianet = 1 WHERE order_id = '.$orderId );
			}else{
				// On la marque comme refusee
				$db->query( 'UPDATE cybermut_order SET fianet = 2 WHERE order_id = '.$orderId );
				array_push( $refusedOrders, $orderId );
			}
			$db->commit();
		}
		
	}
	if( $valid ) {
		cybermutOrder::sendPayment( $orderId );
	}
}
print( "Fin cron \n" );

?>
