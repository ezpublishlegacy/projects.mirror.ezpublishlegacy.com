<?php
/*
#?ini charset="iso-8859-1"?

[RoleSettings]
PolicyOmitList[]=cybermut/notify_url

*/ ?>
