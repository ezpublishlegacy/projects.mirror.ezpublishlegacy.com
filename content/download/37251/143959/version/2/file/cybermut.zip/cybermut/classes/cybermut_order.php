<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

/*
CREATE TABLE `cybermut_order` (
  `id` int(11) NOT NULL auto_increment,
  `creation_date` varchar(24) collate utf8_unicode_ci NOT NULL,
  `last_payment_date` int(11) default NULL,
  `payment_number` int(1) default NULL,
  `number_of_payment` int(1) NOT NULL,
  `total_price` float NOT NULL,
  `already_paid` float NOT NULL,
  `payment_method` varchar(8) collate utf8_unicode_ci NOT NULL,
  `order_id` int(11) NOT NULL,
  `next_payment` int(11) NOT NULL,
  `payment_mode` varchar(4) collate utf8_unicode_ci NOT NULL,
  `state` varchar(16) collate utf8_unicode_ci default NULL,
  `status` int(11) default NULL,
  `message` varchar(32) collate utf8_unicode_ci default NULL,
  `from_site` varchar(4) collate utf8_unicode_ci NOT NULL,
  `fianet` int(1) default 0,
  `ip` varchar(16) collate utf8_unicode_ci default NULL
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;

Pour Fianet, les etats sont 0, 1, 2
	0 => pas traite
	1 => accepte
	2 => refuse
*/
include_once( 'lib/ezutils/classes/ezini.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

class cybermutOrder {
	function store( $orderId, $totalPrice, $creationDate, $lastPaymentDate = 0, $paymentNumber = 0, $numberOfPayment = 1, $paymentMethod = '100%', $alreadyPaid = 0.0, $nextPayment = false, $paymentMode='cb1', $state = 'running', $status = 1, $message = '', $fromSite, $fianet = 1, $ip = '' )
	{
		$db =& eZDB::instance();
		$db->begin();
		$result = $db->query("INSERT INTO cybermut_order VALUES ('', '".$creationDate."', ".$lastPaymentDate.", ".$paymentNumber.", ".$numberOfPayment.", ".$totalPrice.", ".$alreadyPaid.", '".$paymentMethod."', ".$orderId.", ".$nextPayment.", '".$paymentMode."', '".$state."', ".$status.", '".$message."', '".$fromSite."', ".$fianet.", '".$ip."' )");
		$db->commit();
		
		return true;
	}
	
	function CMCIC_getMyTPE($soc="mysoc",$lang="FR")
	{
		@require("extension/cybermut/classes/MyTpeCMCIC.inc.php");
		if (!is_array($MyTpe) ) { die ('cant require Tpe config.'); }
		
		return $MyTpe;
	}

	function sendPayment( $orderID )
	{
		$db =& eZDB::instance();
		$db->begin();
		
		$returnState = false;

		$res = $db->arrayQuery("SELECT * FROM cybermut_order WHERE order_id = ".$orderID." ORDER BY id" );

		$result = array();
		foreach( $res as $row )
		{
			// On prend le dernier
			$result = $row;
			/* Comme on garde la trace de tous les paiements effectues, on verifie si le paiement n'a pas ete deja traite et fini */
			if( $row['state'] == 'finished' ){
				unset( $result );
				break;
			}
		}		
		
		if( $result )
		{
			@require_once("extension/cybermut/classes/CMCIC_HMAC.inc.php");
			if (!function_exists('CMCIC_hmac') ) { die ('Cant require hmac function.'); }
			
			$CMCIC_Tpe = cybermutOrder::CMCIC_getMyTPE();
			
			$cybermutINI =& eZINI::instance( 'cybermut.ini' );
			
			$cybermutServer = $cybermutINI->variable( 'PaymentServerSettings', 'ServerName');
			$requestURI = $cybermutINI->variable( 'PaymentServerSettings', 'RequestURI');
			$business = urlencode( $cybermutINI->variable( 'CybermutSettings', 'Business' ) );
			$version = urlencode( $cybermutINI->variable( 'CybermutSettings', 'Version' ) );
			$TPE = urlencode( $cybermutINI->variable( 'CybermutSettings', 'TPE' ) );
			
			$orderID = $result['order_id'];
			
			
			$date	= date("d/m/Y:H:i:s");
			$today = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) );
			$http =& eZHTTPTool::instance();
			
			$paymentMode = $result['payment_mode']; // cb1, cb3
			$ini =& eZINI::instance( 'ezpaymentchoose.ini' );
			$paymentMethod = $result['payment_method']; // 100%, 30%, 33.33%
			
			$numberOfPayment = $result['number_of_payment'];
			
			$dateOfPayment = (int)$result['next_payment'];
			
			$state = 'running';

	    	if( $dateOfPayment <= $today )
	    	{
	    		/* On fait le paiement */
				$totalPrice = $result['total_price'];
		    	$priceToCapture = 0.0;
		    	$alreadyPaid = $result['already_paid'];
		    	
		    	$newPriceAlreadyPaid = 0.0;
		    	$newDateOfPayment = $dateOfPayment;
		    	$newPaymentNumber = 0;
		    	
		    	$onePayment = false;
		    	$sortOfPayment = 'in_payment';
		    	$paymentMode = 'cb1';
		    	
	    		switch( $result['number_of_payment'] ){
	    			case '1':
	    				$priceToCapture = $totalPrice;
	    				$newPriceAlreadyPaid = $priceToCapture;
	    				$newPaymentNumber = 1;
	    				$state = 'finished';
	    				$onePayment = true;
	    				break;
	    			case '2':
	    				/* Paiement de 30% a la commande. On encaisse le premier paiement et on le termine */
	    				$priceToCapture = round( ( $totalPrice * 30 ) / 100, 2 );
	    				$newPriceAlreadyPaid = $priceToCapture;
	    				$newPaymentNumber = 2;
	    				$state = 'finished';
	    				$sortOfPayment = 'multi';
	    				break;
	    			case '3':
	    				$priceToCapture = round( ( $totalPrice * 33.33 ) / 100, 2 );
	    				$newPriceAlreadyPaid = (float)$result['already_paid'] + $priceToCapture;
	    				$newPaymentNumber = (int)$result['payment_number'] + 1;
	    				if( $newPaymentNumber != 3 ){
	    					$newDateOfPayment = mktime( 0, 0, 0, date( "m" ) + 1, date( "d" ), date( "Y" ) );
	    				}else{
	    					$state = 'finished';
	    				}
	    				$sortOfPayment = 'multi';
	    				$paymentMode = 'cb3';
	    				break;
	    		}
	    		
	    		$siteIni =& eZINI::instance( 'site.ini' );
				$language = $siteIni->variable( 'RegionalSettings', 'Locale' );
				$languageArray = explode( '-', $language );
				$language = $languageArray[1];
				
				$cybermutCurrencies = $cybermutINI->variable( 'Locale', 'Currency' );
				$currency = $cybermutCurrencies[ $language ]; 
	
				$remainingPrice = round( $totalPrice - $newPriceAlreadyPaid, 2 );						      
				
				$PHP1_FIELDS = sprintf("%s*%s*%s%s%s*%s*%s*%s*%s*%s*",
																		$TPE,
																		$date,
																		$priceToCapture.$currency,
																		$alreadyPaid.$currency,
																		$remainingPrice.$currency,
																		(int)$orderID,
																		"",
																		$version,
																		$language,
																		$business);
				
				$keyedMAC = CMCIC_hmac( $CMCIC_Tpe, $PHP1_FIELDS );
	    		$postParameters = array();
	    		$postParameters['version'] = $version;
	    		$postParameters['TPE'] = $TPE;
	    		$postParameters['date'] = $date;
	    		$postParameters['date_commande'] = $result['creation_date'];
	    		$postParameters['montant'] = $totalPrice.$currency;
	    		$postParameters['montant_a_capturer'] = $priceToCapture.$currency;
	    		$postParameters['montant_deja_capture'] = $alreadyPaid.$currency;
	    		$postParameters['montant_restant'] = $remainingPrice.$currency;
	    		$postParameters['reference'] = (int)$orderID;
	    		$postParameters['texte-libre'] = "";
	    		$postParameters['lgue'] = $language;
	    		$postParameters['societe'] = $business;
	    		$postParameters['MAC'] = $keyedMAC;
	 		
	    		$http =& eZHTTPTool::instance();
	    		$res = $http->sendHTTPRequest( $cybermutServer.$requestURI, "443", $postParameters, 'eZ publish', false );
					
	    		$arrayRes = explode( "\n", $res );
	    		$returnState = '';
	    		$returnLib = '';
	    		foreach( $arrayRes as $res ){
	    			$key = strpos( $res, '=' );
	    			if( $key !== false && substr( $res, 0, $key ) == 'cdr' ){
	    				$returnState = substr( $res, $key+1 );
	    			}
	    			if( $key !== false && substr( $res, 0, $key ) == 'lib' ){
	    				$returnLib = substr( $res, $key+1 );
	    			}
	    		}
					
				if( $returnState != '-1' )
				{
					CybermutOrder::store( $orderID, 
											$totalPrice, 
											$result['creation_date'], 
											$today, 
											$newPaymentNumber, 
											$numberOfPayment, 
											$paymentMethod, 
											$newPriceAlreadyPaid, 
											$newDateOfPayment, 
											$paymentMode, 
											$state, 
											$result['status'], 
											'', 
											$result['from_site'],
											$result['fianet']  );
				}else
				{
					$sql = "UPDATE cybermut_order SET state = 'halted', status = 0, message = '".$returnLib."' WHERE id = ".$result['id'];
					$db->query( $sql );
					$returnState = false;
				}
	    	}

		}

		$db->commit();
		
		return $returnState;
	}
	 
	function getPaymentMode( $orderId )
	{
		$db =& eZDB::instance();
		$db->begin();

		$res = $db->arrayQuery("SELECT * FROM cybermut_order WHERE order_id = ".$orderId );
		
		$result = array();

		foreach( $res as $row )
		{
			$result = array( 'method' => $row['payment_method'], 'mode' => $row['payment_mode'], 'from_site' => $row['from_site'], 'ip' => $row['ip'] );
		}

		$db->commit();
		
		return $result;
	}
	
	
	
	
}
?>