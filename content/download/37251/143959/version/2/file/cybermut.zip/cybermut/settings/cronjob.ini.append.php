<?php
/*#?ini charset="iso-8859-1"?
[CronjobSettings]
Scripts[]=send_payment.php

ExtensionDirectories[]=cybermut

[CronjobPart-cybermut]
Scripts[]=send_payment.php

*/
?>