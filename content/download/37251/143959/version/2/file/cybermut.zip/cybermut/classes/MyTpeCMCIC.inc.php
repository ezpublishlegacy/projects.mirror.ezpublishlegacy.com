<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/


/*****************************************************************************
 *
 * CM_CIC_Paiement "open source" kit for CyberMUT-P@iement(TM) and
 *                  P@iementCIC(TM).
 * TPE functions for PHP.
 *
 * File "MyTpeCMCIC.inc.php":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.03
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. All rights reserved.
 * License  : see attached document "Licence.txt".
 *
 *----------------------------------------------------------------------------
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * fonctions TPE en PHP
 *
 * Fichier "MyTpeCMCIC.inc.php" :
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.03
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/
// ----------------------------------------------------------------------------
// Note : typically to be rewrited to get configurations depending on 
//        $soc,$lang from your  database
// Note : � r�-�crire pour rechercher les configurations d�pendant de
//        $soc,$lang dans votre database
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// If the merchant suscribed several Terminal (TPE) numbers, distinct TPE 
// configurations may be retrieved from here, depending on $soc argument.
// Dans le cas ou un m�me marchand d�tient plusieurs num�ros de TPE virtuels,
// plusieurs configurations de TPE peuvent �tre obtenues ici, 
// selon le param�tre $soc . 
// ----------------------------------------------------------------------------
switch ($soc) 
{
    case "doNotOverwrite":
        $MyTpe = array ( "tpe" =>"7654321",
                         "soc" => "doNot",
                         "key" => "098765432456709876543893" ); //edit this key
        break;
    default:

    // <<<--- begin custom OverWrite ---

    $MyTpe = array ( "tpe" =>"65756543456", "soc" => "XXX SOCIETY XXX", "key" => "3365d7987654398765310f1e2ebbb8a129" ); //edit this

    
    include_once( "lib/ezutils/classes/ezsys.php" );
    //$siteUrl = $hostname.'/'.$GLOBALS['eZCurrentAccess']['name'];
    $siteUrl = 'http://'.eZSys::hostname();
    
		$MyTpe["retourok"] = $siteUrl."/shop/checkout";
		$MyTpe["retourko"] = $siteUrl."/shop/basket";
		$MyTpe["submit"]   = "Paiement CB - Card Payment";




    // --->>>  end  custom OverWrite ---
}

// ----------------------------------------------------------------------------
// Additional TPE configuration datas may be retrieved from here, depending on
// $soc,$lang arguments
// Autres infos de configuration de TPE selon les param�tres $soc,$lang
// ----------------------------------------------------------------------------
switch ($lang)
{
    case "xx":
        $MyTpe["retourok"] = "http://www.google.cn";
        $MyTpe["retourko"] = "http://www.google.tv";
        break;
}

// ----------------------------------------------------------------------------
// Important : ReWrite to use secure databases under Merchant's responsibility.
// Important : Il est de la responsabilit� du marchand de r�-�crire le code en
// fonction de ses bases et outils de s�curit�.
// ----------------------------------------------------------------------------

?>
