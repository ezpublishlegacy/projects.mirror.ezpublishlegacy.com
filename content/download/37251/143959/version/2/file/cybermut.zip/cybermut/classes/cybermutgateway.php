<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Fabrice Perez <fp@internethic.com> Wed February 20 11:02:56 CEST 2008
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/


//
// Definition of eZPaypalGateway class
//
// Created on: <18-Jul-2004 14:18:58 dl>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file ezcybermutgateway.php
*/

/*!
  \class eZPaypalGateway ezcybermutgateway.php
  \brief The class eZPaypalGateway implements
  functions to perform redirection to the PayPal
  payment server.
*/

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezredirectgateway.php' );


//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_CYBERMUT", "cybermut" );
define("CMCIC_PHP1_FIELDS", "%s%s*%s*%s%s*%s*%s*%s*%s*%s*");
define("CMCIC_PHP2_FIELDS", "%s*%s*%s%s%s*%s*%s*%s*%s*%s*");

@require_once("CMCIC_HMAC.inc.php");
if (!function_exists('CMCIC_hmac') ) { die ('Cant require hmac function.'); }

class CybermutGateway extends eZRedirectGateway
{
    /*!
        Constructor.
    */
    function CybermutGateway()
    {
        //__DEBUG__
            $this->logger   = eZPaymentLogger::CreateForAdd( "var/log/Cybermut.log" );
            $this->logger->writeTimedString( 'CybermutGateway::CybermutGateway()' );
        //___end____
    }
    
    function execute( &$process, &$event )
    {
        //__DEBUG__
        $this->logger->writeTimedString("execute");
        //___end____

        /* On recupere l'adresse IP de l'internaute */
        $remoteip = '';
		if (getenv('HTTP_CLIENT_IP')) {
			$remoteip = getenv('HTTP_CLIENT_IP');
		} elseif (getenv('HTTP_X_FORWARDED_FOR')) {
			$remoteip = getenv('HTTP_X_FORWARDED_FOR');
		} elseif (getenv('HTTP_X_FORWARDED')) {
			$remoteip = getenv('HTTP_X_FORWARDED');
		} elseif (getenv('HTTP_FORWARDED_FOR')) {
			$remoteip = getenv('HTTP_FORWARDED_FOR');
		} elseif (getenv('HTTP_FORWARDED')) {
			$remoteip = getenv('HTTP_FORWARDED');
		} else {
			$remoteip = $_SERVER['REMOTE_ADDR'];
		}

        $processParameters =& $process->attribute( 'parameter_list' );
        $processID         =  $process->attribute( 'id' );

        switch ( $process->attribute( 'event_state' ) )
        {
            case EZ_REDIRECT_GATEWAY_OBJECT_CREATED:
            {
                //__DEBUG__
                $this->logger->writeTimedString("case EZ_REDIRECT_GATEWAY_OBJECT_CREATED");
                //___end____

                $thePayment = eZPaymentObject::fetchByProcessID( $processID );
                if ( is_object( $thePayment ) && $thePayment->approved() )
                {
                    //__DEBUG__
                    $this->logger->writeTimedString("Payment accepted.");
                    //___end____
                    return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
                }
                //__DEBUG__
                else
                {
                    $this->logger->writeTimedString("Error. Payment rejected: unable to fetch 'eZPaymentObject' or payment status 'not approved'");
                }
                //___end____

                return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
            }break;

            case EZ_REDIRECT_GATEWAY_OBJECT_NOT_CREATED:
                //__DEBUG__
                $this->logger->writeTimedString("case EZ_REDIRECT_GATEWAY_OBJECT_NOT_CREATED");
                //___end____

            default:
            {
                $orderID        = $processParameters['order_id'];
                $paymentObject  =& $this->createPaymentObject( $processID, $orderID );

                if( is_object( $paymentObject ) )
                {
                    $paymentObject->store();
                    $process->setAttribute( 'event_state', EZ_REDIRECT_GATEWAY_OBJECT_CREATED );

                    $process->RedirectUrl = $this->createRedirectionUrl( $process );
                }
                else
                {
                    //__DEBUG__
                    $this->logger->writeTimedString("Unable to create 'eZPaymentObject'. Payment rejected.");
                    //___end____
                    return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
                }
            }break;
        };

        //__DEBUG__
        $this->logger->writeTimedString("return EZ_WORKFLOW_TYPE_STATUS_REDIRECT_REPEAT");
        //___end____
        return EZ_WORKFLOW_TYPE_STATUS_REDIRECT_REPEAT;
    }

    /*!
        Creates new CybermutGateway object.
    */
    function &createPaymentObject( &$processID, &$orderID )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createPaymentObject");
        //___end____

        return eZPaymentObject::createNew( $processID, $orderID, 'Cybermut' );
    }

    /*!
        Creates redirectional url to cybermut server.
    */
    function CMCIC_getMyTPE($soc="mysoc",$lang="FR")
    {
    	@require("MyTpeCMCIC.inc.php");
			if (!is_array($MyTpe) ) { die ('cant require Tpe config.'); }

			return $MyTpe;
    }
    
   function HtmlEncode ($data)
   {
    $SAFE_OUT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890._-";
    $encoded_data = "";
    $result = "";
    for ($i=0; $i<strlen($data); $i++)
    {
        if (strchr($SAFE_OUT_CHARS, $data{$i})) {
            $result .= $data{$i};
        }
        else if (($var = bin2hex(substr($data,$i,1))) <= "7F"){
            $result .= "&#x" . $var . ";";
        }
        else
            $result .= $data{$i};
            
    }
    return $result;
   }
   
    function &createRedirectionUrl( &$process )
    {
      //__DEBUG__
          $this->logger->writeTimedString("createRedirectionUrl");
      //___end____

		$CMCIC_Tpe = $this->CMCIC_getMyTPE();
		
		$this->logger->writeTimedString("CMCIC_Tpe key: ".$CMCIC_Tpe['key']);
		$cybermutINI =& eZINI::instance( 'cybermut.ini' );
		$tinyErpINI =& eZINI::instance( 'tinyerp.ini' );
		
		$cybermutServer = $cybermutINI->variable( 'ServerSettings', 'ServerName');
		$requestURI = $cybermutINI->variable( 'ServerSettings', 'RequestURI');
		$business = urlencode( $cybermutINI->variable( 'CybermutSettings', 'Business' ) );

		$version = urlencode( $cybermutINI->variable( 'CybermutSettings', 'Version' ) );
		$TPE = urlencode( $cybermutINI->variable( 'CybermutSettings', 'TPE' ) );
		$processParams =& $process->attribute( 'parameter_list' );
		$orderID = $processParams['order_id'];
		
		$creationDate = $date	= date("d/m/Y:H:i:s");
		
		$order =& eZOrder::fetch( $orderID );

		/*
		Comme le contrat est un paiement partiel, le premier envoi a cybermut est une demande d'autorisation.
		Ensuite, sur le retour, selon la reponse de la banque, on fera le premier prelevement qu'il soit total ou partiel.
		On va stocker en base la commande
		*/
		
		$price = urlencode( $order->attribute( 'total_inc_vat' ) );
		
		$http =& eZHTTPTool::instance();
		
		$paymentMode = 'cb1'; // cb1, cb3
		if( $http->hasSessionVariable( 'Payment-Mode' ) )
		{
			$paymentMode = $http->sessionVariable( 'Payment-Mode' );
		}
		
		$paymentAmount = '100%'; // 100%, 33,33%
		$paymentMethod = '100%';
		if( $http->hasSessionVariable( 'Payment-Method' ) )
		{
			$paymentMethod = $http->sessionVariable( 'Payment-Method' ); // 100%, 30%
		}
		
		$numberOfPayment = 1;
		
		if( $paymentAmount == '33,33%' ){
			$paymentMethod = $paymentAmount;
			$numberOfPayment = 3;
		}elseif( $paymentMethod == '30%' ){
			$numberOfPayment = 2;
		}
      
      /* On met la date du prochain payment */
      $nextPayment = mktime( 0, 0, 0, date( "m" ), date( "d" ), date( "Y" ) );
      
		/* On recupere l'adresse IP de l'internaute */
		if (getenv('HTTP_CLIENT_IP')) {
			$remoteip = getenv('HTTP_CLIENT_IP');
		} elseif (getenv('HTTP_X_FORWARDED_FOR')) {
			$remoteip = getenv('HTTP_X_FORWARDED_FOR');
		} elseif (getenv('HTTP_X_FORWARDED')) {
			$remoteip = getenv('HTTP_X_FORWARDED');
		} elseif (getenv('HTTP_FORWARDED_FOR')) {
			$remoteip = getenv('HTTP_FORWARDED_FOR');
		} elseif (getenv('HTTP_FORWARDED')) {
			$remoteip = getenv('HTTP_FORWARDED');
		} else {
			$remoteip = $_SERVER['REMOTE_ADDR'];
		}
		
		include_once( 'extension/cybermut/classes/cybermut_order.php' );
		
		CybermutOrder::store(   $orderID, 
								$price, 
								$creationDate, 
								0, 
								0, 
								$numberOfPayment, 
								$paymentMethod, 
								0.0, 
								$nextPayment, 
								$paymentMode, 
								'running', 
								1, 
								'', 
								'',
								0,
								$remoteip );

		$siteIni =& eZINI::instance( 'site.ini' );
		$language = $siteIni->variable( 'RegionalSettings', 'Locale' );
		$languageArray = explode( '-', $language );
		$language = $languageArray[1];
		
		$cybermutCurrencies = $cybermutINI->variable( 'Locale', 'Currency' );
		$currency = $cybermutCurrencies[ $language ];      
			
		$textLibre = $remoteip.'::'.$paymentMode;

    	$PHP1_FIELDS = sprintf( CMCIC_PHP1_FIELDS,
								"",
								$TPE,
								$date,
								$price,
								$currency,
								$orderID,
								$textLibre,
								$version,
								$language,
								$business);
			
		$keyedMAC = CMCIC_hmac($CMCIC_Tpe, $PHP1_FIELDS);					      
		
		$url_retour =	$CMCIC_Tpe["retourok"];
		$url_retourok = $CMCIC_Tpe["retourok"];
		$url_retourko = $CMCIC_Tpe["retourko"];
		$submit = $CMCIC_Tpe["submit"];

		$url =  $cybermutServer . $requestURI .
				"?version=".urlencode($version) .
				"&TPE=".urlencode($TPE) .
				"&date=".urlencode($date)	.
				"&montant=".urlencode($price).urlencode($currency).
				"&reference=".urlencode($orderID) .
				"&MAC=".urlencode($keyedMAC) .
				"&url_retour=".urlencode($url_retour) .
				"&url_retour_ok=".urlencode($url_retourok) .
				"&url_retour_err=".urlencode($url_retourko) .
				"&lgue=".urlencode($language) .
				"&societe=".urlencode($business) .
				"&texte-libre=".urlencode($textLibre) .
				"&bouton =".urlencode($submit);
        //__DEBUG__
        $this->logger->writeTimedString("business       = $business");
        $this->logger->writeTimedString("item_name      = ");
        $this->logger->writeTimedString("custom         = $orderID");
        $this->logger->writeTimedString("amount         = $amount");
        $this->logger->writeTimedString("currency_code  = EUR");
        $this->logger->writeTimedString("return         = $url_retour");
        $this->logger->writeTimedString("cancel_return  = $url_retourko");
        //___end____

        return $url;
    }

}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_CYBERMUT, "cybermutgateway", "Cybermut" );

?>
