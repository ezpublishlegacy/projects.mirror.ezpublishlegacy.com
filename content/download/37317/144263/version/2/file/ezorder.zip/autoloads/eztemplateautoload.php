<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
  array( 'script' => 'extension/ezorder/autoloads/op_ext_shop.php',
         'class' => 'ShopOperator',
         'operator_names' => array('get_order'));
?>
