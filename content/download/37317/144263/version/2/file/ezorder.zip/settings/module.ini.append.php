[ModuleSettings]
ExtensionRepositories[]=ezorder
