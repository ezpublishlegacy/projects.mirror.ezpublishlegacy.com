<?php

$Module = array( 'name' => 'ezorder' );

$ViewList = array();

$ViewList["orderview"] = array(
    "script" => "orderview.php",
    "params" => array( "UserID" , "OrderID" ) );
	
?>


