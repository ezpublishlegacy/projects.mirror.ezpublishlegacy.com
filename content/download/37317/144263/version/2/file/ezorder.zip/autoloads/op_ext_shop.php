<?php
// librairies eZ publish

include_once("lib/ezutils/classes/ezextension.php");
include_once("lib/ezutils/classes/ezmodule.php");
include_once("lib/ezutils/classes/ezcli.php");
include_once("lib/ezutils/classes/ezini.php");
include_once("lib/ezutils/classes/ezoperationhandler.php");
include_once("lib/ezdb/classes/ezdb.php");
include_once("kernel/classes/datatypes/ezuser/ezuser.php");
include_once("kernel/classes/datatypes/ezuser/ezusersetting.php");
include_once("kernel/classes/ezcontentobject.php");
include_once("kernel/classes/ezrole.php");

class ShopOperator
{
    /*!
     Constructor
    */
    function ShopOperator()
    {
        $this->Operators = array('get_order');
    }

    /*!
     Returns the operators in this class.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    /*!
     \return true to tell the template engine that the parameter list
    exists per operator type, this is needed for operator classes
    that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     The first operator has two parameters, the other has none.
     See eZTemplateOperator::namedParameterList()
    */
    function namedParameterList()
    {	
        return array(	'get_order' => array( 'clientID' => array('type' => 'integer', 'required' => true, 'default' => '' ))
					);																	
	}
 /*!
     Executes the needed operator(s).
     Checks operator names, and calls the appropriate functions.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                     &$currentNamespace, &$operatorValue, &$namedParameters )
    {   
        switch ( $operatorName )
        {   
			case 'get_order':
	            {
	                $operatorValue = $this->get_order($namedParameters['clientID']);
	            } break;
		}
    }

	/*
	
	*/
	function get_order( $user_id)
	{
	
		$ini =& eZINI::instance( 'ezorder_settings.ini' );
		
		$orderTable =  $ini->variable( 'EzOrder','dbTable' );
		$id = $ini->variable( 'EzOrder','dbFieldID' );
		$date = $ini->variable( 'EzOrder','dbFieldDc' );
		$info = $ini->variable( 'EzOrder','dbFieldInfo' );
		$prodId = $ini->variable( 'EzOrder','dbFieldProd' );

		$prodTable =  $ini->variable( 'EzProductCollection','dbTable' );
		$discount = $ini->variable( 'EzProductCollection','dbFieldDs' );
		$is_tva = $ini->variable( 'EzProductCollection','dbFieldTi' );
		$count = $ini->variable( 'EzProductCollection','dbFieldCt' );
		$name = $ini->variable( 'EzProductCollection','dbFieldNm' );
		$price = $ini->variable( 'EzProductCollection','dbFieldPc' );
		$prodId = $ini->variable( 'EzProductCollection','dbFieldProd' );
		$tva = $ini->variable( 'EzProductCollection','dbFieldTva' );
		
		$db =& eZDB::instance();

		$query = "SELECT  $date, $id, $info, $prodId FROM $orderTable WHERE  user_id='$user_id' ";
	
		$result_set = $db->query($query);
		$listOrder = array();
		while ($order = mysql_fetch_assoc($result_set)) {
			$listOrder[] = $order;
		}
		
		for ($i=0 ; $i < count($listOrder);$i++)
		{
			$sum=0;
			$prod_ID = $listOrder[$i][$prodId];
		
			$query = "SELECT $discount, $is_tva, $count, $name, $price, $prodId, $tva  FROM $prodTable WHERE  $prodId='$prod_ID' ";
		  	  
			$result_set = $db->query($query);
			$listProd = array();
			while ($prod = mysql_fetch_assoc($result_set)) {
				if( $prod[$discount] != 0 )
					$sum = $sum + $prod[$count] * ($prod[$price] - $prod[$price]*$prod[$discount] / 100) ;
				else
					$sum = $sum + $prod[$count] * $prod[$price];
			}
			$listOrder[$i]['total']=$sum;
			$listOrder[$i][$date]=date("d/m/y", $listOrder[$i][$date]);
		}
		return  $listOrder;
	}
    // privatesection
	var $Operators;
}

?>
