<?
include_once("lib/ezutils/classes/ezini.php");
function full_order($order_id,$UserID)
{
	$ini =& eZINI::instance( 'ezorder_settings.ini' );

	$orderTable =  $ini->variable( 'EzOrder','dbTable' );
	$id = $ini->variable( 'EzOrder','dbFieldID' );
	$info = $ini->variable( 'EzOrder','dbFieldInfo' );
	$prodId = $ini->variable( 'EzOrder','dbFieldProd' );

	$prodTable =  $ini->variable( 'EzProductCollection','dbTable' );
	$discount = $ini->variable( 'EzProductCollection','dbFieldDs' );
	$is_tva = $ini->variable( 'EzProductCollection','dbFieldTi' );
	$count = $ini->variable( 'EzProductCollection','dbFieldCt' );
	$name = $ini->variable( 'EzProductCollection','dbFieldNm' );
	$price = $ini->variable( 'EzProductCollection','dbFieldPc' );
	$prodId = $ini->variable( 'EzProductCollection','dbFieldProd' );
	$tva = $ini->variable( 'EzProductCollection','dbFieldTva' );	
	
	$db =& eZDB::instance();

	$query = "SELECT $discount, $is_tva, $count, $prodTable.$name, $price, $prodTable.$prodId, $tva  FROM $prodTable INNER JOIN $orderTable ON $prodTable.$prodId=$orderTable.$prodId WHERE  $orderTable.$id='$order_id' AND $orderTable.user_id='$UserID'";

	$result_set = $db->query($query);
	$listProd = array();
	$i=0;
	while ($prod = mysql_fetch_assoc($result_set)) {
		$listProd[$i]=$prod;
		
		if( $is_tva != 0 )
		{
			$prixprod_tva = $prod[$price];
			$prixprod = ($prod[$price] - $prod[$price]*$prod[$tva] / 100);
		}
		else
		{
			$prixprod_tva = ($prod[$price] + $prod[$price]*$prod[$tva] / 100) ;
			$prixprod = $prod[$price];
		}
		if( $prod[$discount] != 0 )
		{
			$prixprod = $prod[$count] * ($prixprod - $prixprod*$prod[$discount] / 100) ;
			$prixprod_tva = $prod[$count] * ($prixprod_tva - $prixprod_tva*$prod[$discount] / 100) ;
		}
		else
		{
			$prixprod = $prod[$count] * $prixprod;
			$prixprod_tva = $prod[$count] * $prixprod_tva;
		}
		$listProd[$i]['total_ex']=$prixprod;
		$listProd[$i]['total_inc']=$prixprod_tva;
		
		$i++;
	}
	
	return $listProd;
}

function get_date($order_id,$UserID)
{
	$ini =& eZINI::instance( 'ezorder_settings.ini' );

	$orderTable =  $ini->variable( 'EzOrder','dbTable' );
	$id = $ini->variable( 'EzOrder','dbFieldID' );
	$date = $ini->variable( 'EzOrder','dbFieldDc' );
	
	$db =& eZDB::instance();

	$query = "SELECT $date FROM $orderTable WHERE $id='$order_id' AND $orderTable.user_id='$UserID'";
	$result = mysql_fetch_assoc($db->query($query));
	$date  = date("d/m/y", $result[$date]);

	return $date;
}

function get_status($order_id,$UserID)
{
	$ini =& eZINI::instance( 'ezorder_settings.ini' );

	$orderTable =  $ini->variable( 'EzOrder','dbTable' );
	$id = $ini->variable( 'EzOrder','dbFieldID' );
	
	$db =& eZDB::instance();

	$query = "SELECT ezorder_status.name FROM ezorder_status INNER JOIN ezorder ON $orderTable.status_id=ezorder_status.status_id WHERE  $orderTable.$id='$order_id' AND $orderTable.user_id='$UserID'";
	$result = mysql_fetch_assoc($db->query($query));
	$status  = $result['name'];

	return $status;
}
function get_total($order_id,$UserID)
{
	$ini =& eZINI::instance( 'ezorder_settings.ini' );

	$orderTable =  $ini->variable( 'EzOrder','dbTable' );
	$id = $ini->variable( 'EzOrder','dbFieldID' );
	$prodId = $ini->variable( 'EzOrder','dbFieldProd' );

	$prodTable =  $ini->variable( 'EzProductCollection','dbTable' );
	$discount = $ini->variable( 'EzProductCollection','dbFieldDs' );
	$count = $ini->variable( 'EzProductCollection','dbFieldCt' );
	$price = $ini->variable( 'EzProductCollection','dbFieldPc' );
	$prodId = $ini->variable( 'EzProductCollection','dbFieldProd' );
	
	$db =& eZDB::instance();

	$query = "SELECT $discount, $count, $price, $prodTable.$prodId  FROM $prodTable INNER JOIN $orderTable ON $prodTable.$prodId=$orderTable.$prodId WHERE  $orderTable.$id='$order_id' AND $orderTable.user_id='$UserID'";

	$result_set = $db->query($query);
	
	$sum=0;
	while ($prod = mysql_fetch_assoc($result_set)) {
		if( $is_tva != 0 )
			$prixprod = ($prod[$price] + $prod[$price]*$prod[$tva] / 100) ;		
		else
			$prixprod = $prod[$price];		
			
		if( $prod[$discount] != 0 )
			$sum = $sum + $prod[$count] * ($prixprod - $prixprod*$prod[$discount] / 100) ;
		else
			$sum = $sum + $prod[$count] * $prixprod;
	}
	
	return $sum;
}
function get_total_tva($order_id, $UserID)
{
	$ini =& eZINI::instance( 'ezorder_settings.ini' );

	$orderTable =  $ini->variable( 'EzOrder','dbTable' );
	$id = $ini->variable( 'EzOrder','dbFieldID' );
	$prodId = $ini->variable( 'EzOrder','dbFieldProd' );

	$prodTable =  $ini->variable( 'EzProductCollection','dbTable' );
	$discount = $ini->variable( 'EzProductCollection','dbFieldDs' );
	$is_tva = $ini->variable( 'EzProductCollection','dbFieldTi' );
	$count = $ini->variable( 'EzProductCollection','dbFieldCt' );
	$price = $ini->variable( 'EzProductCollection','dbFieldPc' );
	$prodId = $ini->variable( 'EzProductCollection','dbFieldProd' );
	$tva = $ini->variable( 'EzProductCollection','dbFieldTva' );	
	
	$db =& eZDB::instance();

	$query = "SELECT $discount, $is_tva, $count, $price, $prodTable.$prodId, $tva  FROM $prodTable INNER JOIN $orderTable ON $prodTable.$prodId=$orderTable.$prodId WHERE  $orderTable.$id='$order_id' AND $orderTable.user_id='$UserID'";

	$result_set = $db->query($query);
	
	$sum=0;
	while ($prod = mysql_fetch_assoc($result_set)) {
		if( $is_tva != 0 )
			$prixprod = $prod[$price];			
		else
			$prixprod = ($prod[$price] + $prod[$price]*$prod[$tva] / 100) ;
			
		if( $prod[$discount] != 0 )
			$sum = $sum + $prod[$count] * ($prixprod - $prixprod*$prod[$discount] / 100) ;
		else
			$sum = $sum + $prod[$count] * $prixprod;
	}
	
	return $sum;
}
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/common/template.php' );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );

//$http =& eZHTTPTool::instance();
$OrderID = $Params['OrderID'];
$UserID = $Params['UserID'];
$module =& $Params['Module'];

$currentUser =& eZUser::currentUser();
$currentUserID = $currentUser->attribute( "contentobject_id" );
$tpl =& templateInit();
$listprod=full_order($OrderID,$UserID);
if($currentUserID == $UserID && count($listprod) != 0)
{
	$tpl->setVariable( "listProd", $listprod);
	$tpl->setVariable( "orderID", $OrderID);
	$tpl->setVariable( "order_date", get_date($OrderID,$UserID));
	$tpl->setVariable( "order_status_name", get_status($OrderID,$UserID));
	$tpl->setVariable( "order_total_ex_vat", get_total($OrderID,$UserID));
	$tpl->setVariable( "order_total_inc_vat", get_total_tva($OrderID,$UserID));
}
else
	$tpl->setVariable( "warning", 1);
$Result = array();
$Result['content'] =& $tpl->fetch( 'design:ezorder/orderview.tpl' );

?>
