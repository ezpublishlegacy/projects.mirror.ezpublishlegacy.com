To use get_order function add this in user/edit.tpl for example.

{def $listOrder = get_order($userID)}
<div id="orders">
	<h2>{"My orders"|i18n("design/ezwebin/user/edit")}</h2>
	{foreach $listOrder as $order}
		<a href={concat("/ezorder/orderview/", $userID, "/", $order.id)|ezurl}>{$order.created|wash} -  {$order.total|l10n(currency)} - Commande n� {$order.id|wash}</a><br />
	{/foreach}

Don't forget to had the right to read the ezorder module.

Add in site.ini.append.php
[TemplateSettings]
ExtensionAutoloadPath[]=ezorder
