<?php /* #?ini charset="utf-8" ?
[embed]
AvailableViewModes[]=jquerylightbox-thumb
AvailableViewModes[]=jquerylightbox-link
*/
