<?php /* #?ini charset="utf-8" ?

[ExtensionSettings]
DesignExtensions[]=ezjquerylightbox

[StylesheetSettings]
CSSFileList[]=jquery.lightbox-0.5.css

[JavaScriptSettings]
JavaScriptList[]=jquery.js
JavaScriptList[]=jquery.lightbox-0.5.js
JavaScriptList[]=jquery.lightbox.function.js
*/

?>
