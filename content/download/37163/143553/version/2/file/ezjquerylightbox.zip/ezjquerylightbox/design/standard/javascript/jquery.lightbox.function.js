$(document).ready(function(){
	$('a[rel*=lightbox]').lightBox({
		overlayBgColor: '#BBB',
		overlayOpacity: 0.6
	});
});