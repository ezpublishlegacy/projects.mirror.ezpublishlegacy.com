<?php /* #?ini charset="utf-8"?

[image_content_view_jquerylightbox-thumb]
Source=content/view/jquerylightbox-thumb.tpl
MatchFile=content/view/jquerylightbox-thumb/image.tpl
Subdir=templates
Match[class_identifier]=image

[image_content_view_jquerylightbox-link]
Source=content/view/jquerylightbox-link.tpl
MatchFile=content/view/jquerylightbox-link/image.tpl
Subdir=templates
Match[class_identifier]=image

*/
?>
