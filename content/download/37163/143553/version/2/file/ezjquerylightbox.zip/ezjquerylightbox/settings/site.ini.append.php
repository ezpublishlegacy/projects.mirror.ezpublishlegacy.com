<?php /* #?ini charset="utf-8" ?

[EmbedViewModeSettings]
AvailableViewModes[]=jquerylightbox-thumb
AvailableViewModes[]=jquerylightbox-link

*/
?>
