<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezmailhide

[MailHideSettings]
Keys[]
# Generate your own reCAPTCHA Mailhide API key at http://mailhide.recaptcha.net/apikey and paste it here : 
Keys[Public]=01OqYnqAAmFPjA_iiX:tVhcpw==
Keys[Private]=EDD4323850F50D2FBA379AFE8529DEFA

*/ ?>