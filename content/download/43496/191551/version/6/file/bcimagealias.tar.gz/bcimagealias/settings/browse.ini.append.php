<?php /* #?ini charset="utf-8"?

[BCImageAliasCreateAliasesAddNode]
StartNode=content
SelectionType=multiple
ReturnType=NodeID

[BCImageAliasRemoveAliasesAddNode]
StartNode=content
SelectionType=multiple
ReturnType=NodeID

*/ ?>
