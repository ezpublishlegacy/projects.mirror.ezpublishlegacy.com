<?php

$Module = array( 'name' => 'Soap Server' );

$ViewList = array();
$ViewList['server'] = array(
	'script' => 'server.php',
	"params" => array( 'Modulename' => 'Modulename' ),
	"unordered_params" => array(  ) );
?>