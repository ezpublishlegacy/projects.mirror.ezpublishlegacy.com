SmileLDAP - Extension qui permet l'imprt d'utilisateur � partir d'un LDAP
Par Emmanuel SARRACO <emmanuel.sarraco@smile.fr>- � 2006 Smile

Description
-----------
Cette extension permet de pouvoir importer un utilisateur dans eZpublish � partir des donn�es contenues
dans un LDAP. 

Pr�-requis
----------
L'extension LDAP de PHP doit �tre active.

Contraintes
-----------
Aucunes

Installation
------------
1 - Copier le r�pertoire smileldap dans le r�pertoire extension d'eZpublish.
2 - Editer le fichier settings/override/site.ini.append.php et ins�rer les lignes :

[UserSettings]
LoginHandler[]=LDAP

3 - Cr�er le fichier settings/override/ldap.ini.append.php.
4 - Activer l'extension dans le back office eZpublish � partir de Administration > Extensions.


Lancement
---------
L'extension dispose d'un onglet dans le back office. On rentre dans le champ de saisie le login de 
l'utilisateur que l'on veut importer.


Configuration
-------------
La configuration de l'extension se fait � partir du fichier global de configuration settings/override/ldap.ini.append.php.
Si ce fichier n'existe pas, il faut copier le fichier settings/ldap.ini dans settings/override/.

LDAPVersion
Version du LDAP cible

LDAPEnabled=true
Si mis � "true", le LDAP est activ�.

LDAPServer
Adresse IP ou nom de la machine qui supporte le LDAP.

LDAPPort
Num�ro du port LDAP � attaquer.

LDAPBaseDn
Distinguished Name de base du LDAP.

LDAPSearchScope=sub
Search Scope du LDAP (valeur par d�faut : sub).

LDAPSearchFilters[]
Filtres LDAP. On remplace le signe "=" par "--". Par exemple : objectClass--inetOrgPerson.

LDAPLoginAttribute
Attribut LDAP utilis� pour se logger. Par d�faut, uid.

LDAPUserGroupType
Type du groupe d'utilisateur. Par d�faut, id.

LDAPUserGroup[]
Endroit par d�faut pour stocker les utilisateurs LDAP. Cela peut �tre aussi bien l'id de l'objet ou le nom
du groupe.

LDAPFirstNameAttribute
Attribut LDAP pour le Pr�nom. Par d�faut, le "givenname".

LDAPLastNameAttribute
Attribut LDAP pour le Nom. Par d�faut, le "surname".

LDAPEmailAttribute
Attribut LDAP pour l'email. Par d�faut, le "mail".

Utf8Encoding=true
Si mis � true, l'encodage UTF8 est utilis�.



Pour effectuer une configuration plus fine par site access, il suffit de copier le fichier de configuration 
dans le r�pertoire de configuration du site access settings/<mon site access> et de le configurer 
sp�cifiquement.
Ensuite, il faut retirer le fichier de configuration smileldap/settings/ldap.ini.append.php.