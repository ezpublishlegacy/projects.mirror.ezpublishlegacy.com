<?php /*
[NavigationPart]
Part[ldapnavigationpart]=LDAP

[TopAdminMenu]
Tabs[]=LDAP

[Topmenu_LDAP]
NavigationPartIdentifier=ldapnavigationpart
Name=LDAP
Tooltip=Cr�ation d'utilisateur LDAP
URL[]
URL[default]=smileldap/createuser
Enabled[]
Enabled[default]=true
Enabled[browse]=true
Enabled[edit]=true
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/?>
