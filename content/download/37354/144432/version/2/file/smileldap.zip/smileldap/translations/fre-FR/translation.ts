﻿<!DOCTYPE TS><TS>
<context>
  <name>content</name>
  <message>
    <source>This user was already created</source>
    <translation>Cet utilisateur a déjà été créé</translation>
  </message>
  <message>
    <source>An error occured during the user creation</source>
    <translation>Une erreur est survenue durant la création de l'utilisateur</translation>
  </message>
  <message>
    <source>LDAP user was not found in the repository</source>
    <translation>L'utilisateur n'a pas été trouvé dans l'annuaire LDAP</translation>
  </message>
  <message>
    <source>Login is mandatory</source>
    <translation>L'identifiant est obligatoire</translation>
  </message>
  <message>
    <source>Login</source>
    <translation>Identifiant</translation>
  </message>
  <message>
    <source>Create User</source>
    <translation>Créer un utilisateur</translation>
  </message>
  <message>
    <source>Task failed</source>
    <translation>Echec de la tâche</translation>
  </message>
  <message>
    <source>Task performed</source>
    <translation>Tâche exécutée avec succès.</translation>
  </message>
  <message>
    <source>The user was created with success</source>
    <translation>L'utilisateur a été créé avec succès</translation>
  </message>
  <message>
    <source>Show user</source>
    <translation>Afficher l'utilisateur</translation>
  </message>
</context>
<context>
  <name>button</name>
  <message>
   <source>Create</source>
    <translation>Créer</translation>
  </message>
</context>
<context>
  <name>kernel/navigationpart</name>
  <message>
    <source>LDAP</source>
    <translation>LDAP</translation>
  </message>
</context>
</TS>
