<?php /*#?ini charset="iso-8859-1"?
[LDAPSettings]
LDAPVersion=3
LDAPEnabled=true
LDAPServer=ldap-server
LDAPPort=389
LDAPBaseDn=dc=foobar,dc=fr
LDAPSearchScope=sub
# Use the equla sign to replace "=" when specify LDAPBaseDn or LDAPSearchFiltersLDAPEqualSign=--
# Example LDAPSearchFilters[]=objectClass--inetOrgPerson
LDAPSearchFilters[]
# LDAP attribute for login. Normally, uid
LDAPLoginAttribute=uid
# Could be id or name
LDAPUserGroupType=id
# Default place to store LDAP users. Could be content object id or group name for LDAP user group,
# depends on LDAPUserGroupType.
LDAPUserGroup[]
LDAPUserGroup[]=128
# LDAP attribute for First name. Normally, givenname
LDAPFirstNameAttribute=givenname
# LDAP attribute for Last name. Normally, sn
LDAPLastNameAttribute=sn
# LDAP attribute for email. Normally, mail
LDAPEmailAttribute=mail
# LDAP encoding is utf-8 or not
Utf8Encoding=true
*/ ?>
