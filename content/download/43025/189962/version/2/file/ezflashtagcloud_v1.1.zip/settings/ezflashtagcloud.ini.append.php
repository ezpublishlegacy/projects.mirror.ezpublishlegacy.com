<?php /*

[FlashSettings]
Width=300
Height=300
BackgroundColor=ffffff

#use transparent background
Transparent=true

#distr	String: true|false	If set to true, the tags are distributed evenly over the spheres surface.
Distr=true

#tcolor	Hex color value for	the default tag color
Tcolor=052fff

#tcolor2	Hex color value	Second tag color. If supplied, tags will get a color from a gradient between both colors based on their popularity.
Tcolor2=6e7ecc

#hicolor	Hex color value	Tag mouseover/hover color
Hicolor=000000

#tspeed	Number: percentage	Determines the speed of the sphere�s rotation. The default is 100, higher numbers increase the speed.
Tspeed=100

*/ ?>