<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezflashtagcloud

*/ ?>