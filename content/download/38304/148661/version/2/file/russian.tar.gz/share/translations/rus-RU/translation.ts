<!DOCTYPE TS><TS>
<context>
    <name> {attribute_view_gui attribute=$content_object.data_map.byline</name>
    <message>
        <source>Av</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>:&lt;/b&gt; {$article_info.block_count</name>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Магазин</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Пользователи</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Установки</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личные</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Главная страница</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Совместная работа</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Классы</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Процессы</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Тригеры</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Статистика поиска</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типы НДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Скидки</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Роли</translation>
    </message>
</context>
<context>
    <name>design/npk</name>
    <message>
        <source>Words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Photos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 cannot be downloaded. Downloading is not support for %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 cannot be export to NITF format. Export is not support for %2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/shop</name>
    <message>
        <source>Payment was canceled. Try to buy again.</source>
        <translation>Оплата отменена. Попытайтесь еще раз.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size:</source>
        <translation type="obsolete">Макс размер файла:</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Множественный выбор</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation>Стиль выбора</translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation>Стиль чекбокса</translation>
    </message>
    <message>
        <source>Enum Element:</source>
        <translation type="obsolete">Элемент множества:</translation>
    </message>
    <message>
        <source>Enum Value:</source>
        <translation type="obsolete">Значение элемента множества:</translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation>Новый Элемент</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Удалить выбранные</translation>
    </message>
    <message>
        <source>Default value:</source>
        <translation type="obsolete">Значение по умолчанию:</translation>
    </message>
    <message>
        <source>Min float value:</source>
        <translation type="obsolete">Мин. значение с плавающей точкой:</translation>
    </message>
    <message>
        <source>Max float value:</source>
        <translation type="obsolete">Макс. значение с плавающей точкой:</translation>
    </message>
    <message>
        <source>Min integer value:</source>
        <translation type="obsolete">Мин.целое:</translation>
    </message>
    <message>
        <source>Max integer value:</source>
        <translation type="obsolete">Макс.целое:</translation>
    </message>
    <message>
        <source>Media player type:</source>
        <translation type="obsolete">Тип медиа проигрывателя :</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Флеш</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows медиа проигрыватель</translation>
    </message>
    <message>
        <source>VAT type:</source>
        <translation type="obsolete">тип НДС:</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с НДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без НДС</translation>
    </message>
    <message>
        <source>Max string length:</source>
        <translation type="obsolete">Максимальная длна строки:</translation>
    </message>
    <message>
        <source>Prefered columns</source>
        <translation type="obsolete">Предпочитаемые колонки</translation>
    </message>
    <message>
        <source>Prefered columns:</source>
        <translation type="obsolete">Предпочитаемые колонки:</translation>
    </message>
    <message>
        <source>Max file size</source>
        <translation>Макс размер файла</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Значение по умолчанию</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Пусто</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Текущая дата</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Текущее время и дата</translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation>Элемент множества</translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation>Значение элемента множества</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Мин. значение вещественного числа</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Макс. значение вещественного числа</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Мин. значение целого числа</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Макс. значение целого числа</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Тип медиа проигрывателя</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Имя по умолчанию</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Тип НДС</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Макс. длинна строки</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Предпочитаемое количество строк</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Текущее время</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class type</source>
        <translation type="obsolete">Редактирование класса</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>Создан</translation>
    </message>
    <message>
        <source>on</source>
        <translation></translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Изменен</translation>
    </message>
    <message>
        <source>Object name:</source>
        <translation type="obsolete">Имя объекта:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Идентификатор:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>In group:</source>
        <translation type="obsolete">В группе:</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation type="obsolete">Добавить группу</translation>
    </message>
    <message>
        <source>Remove group</source>
        <translation type="obsolete">Удалить группу</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибуты</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Тип:</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Обязателен</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Инд. в поиске</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Информационное хранилище</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Editing class group</source>
        <translation>Редактирование группы классов</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) class(es)?</source>
        <translation type="obsolete">Вы уверенны что хотите удалить этот(эти) класс(ы)?</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation type="obsolete">Удалить класс</translation>
    </message>
    <message>
        <source>will remove</source>
        <translation type="obsolete">удалит</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) group(s)?</source>
        <translation type="obsolete">Вы уверенны что хотите удалить этот(эти) группу(ы)?</translation>
    </message>
    <message>
        <source>Editing class</source>
        <translation>Редактируется класс</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation>Последний раз редактировался</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Шаблон имени объекта</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>В группе</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Добавить в группу</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Исключить из групп</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Тип данных</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Отменить изменения</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Вы уверенны, что хотите удалить эти классы?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Удаление класса %1 приведет к удалению %2!</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Вы уверенны, что хотите удалить эти группы классов?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Удаление группы классов %1 приведет к удалению классов %2!</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Defined class groups</source>
        <translation type="obsolete">Определенные группы классов</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Изменил:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Изменен:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Группы классов</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Новая группа</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes have been defined for </source>
        <translation type="obsolete">Небыл определен класс для</translation>
    </message>
    <message>
        <source>Defined class types for</source>
        <translation type="obsolete">Определенные классы для</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Идентификатор:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Изменил:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Изменен:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>No classes in </source>
        <translation>Нет классов в</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Классы в</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ИД</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Изменил</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Новый класс</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Список групп для &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>В группе нет элементов.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Группы</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 ожидает подтверждения от редактора</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>Публикация %1 была подтверждена</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>Публикация %1 не была подтверждена</translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation>%1 был перенаправлен для изменения</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 ожидает подтверждения</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Просмотрен</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочтенный</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивный</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Отправлен: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Нет новых элементов для обработки.</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Необходимо подтверждение прежде чем объект %1 может быть опубликован.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Если вы хотите, вы можете послать сообщение челевеку подтверждающему публикацию?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Необходимо подтверждение прежде чем объект %1 может быть опубликован.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Подтверждаете ли вы публикацию объекта?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Публикация объекта % была подтверждена. Объект будет опубликован, когда продолжится контроль потока.</translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived. If you wish you may publish a new version of the object by clicking the edit link.</source>
        <translation>Публикация объекта %1 не была подтверждена и объект будет заархивирован. Если вы хотите вы можете опубликовать новую версию объекта нажав на ссылку &quot;Редактировать&quot;.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Редактровать объект</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Объект %1 не был принят но доступен как черновик.</translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation>Вы должны снова отредактировать черновик и опубликовать его еще раз, для того чтобы продолжить процесс подтверждения.</translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation>Если редактор посчитает изменения удовлетворительными то объект будет принят.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Объект %1 не был принят, но будет доступен, как черновик, для автора.</translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation>Автору необходимо снова отредактировать черновик и опубликовать его еще раз, для продолжения процесса подтверждения.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Добавить комментарий</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Отказать</translation>
    </message>
    <message>
        <source>Pushback</source>
        <translation>Отпрвить обратно</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Участник</translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation>Объект класса %1</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Сообщения</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Вы уверенны, что хотите удалить этот перевод?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Изменить перевод для содержимого</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Выберите один из переводов из списка для изменения или введите новый в поля для ввода.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Новый перевод для содержимого</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Выберите один из переводов из списка для изменения или введите новый в поля для ввода.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Специализированный</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Имя перевода</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Регион</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Создать</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Переводы содержимого</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Ниже вы найдете список активных языков на котыры может быть переведенн объект.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Копирование %1</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>Колличество версий %1, текущая версия %2.</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Копировать все версии</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Копировать текущую версию</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Создать</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="obsolete">E-mail:</translation>
    </message>
    <message>
        <source>New author</source>
        <translation>Новый автор</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Удалить выбранные</translation>
    </message>
    <message>
        <source>Filename:</source>
        <translation type="obsolete">Имя файла:</translation>
    </message>
    <message>
        <source>Existing filename:</source>
        <translation type="obsolete">Существующие имя файла:</translation>
    </message>
    <message>
        <source>Existing orignal filename:</source>
        <translation type="obsolete">Существующие исходное имя файла:</translation>
    </message>
    <message>
        <source>Existing mime/type:</source>
        <translation type="obsolete">Существующий mime/type:</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Удалить</translation>
    </message>
    <message>
        <source>Year:</source>
        <translation type="obsolete">Год:</translation>
    </message>
    <message>
        <source>Month:</source>
        <translation type="obsolete">Месяц:</translation>
    </message>
    <message>
        <source>Day:</source>
        <translation type="obsolete">День:</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation type="obsolete">Час:</translation>
    </message>
    <message>
        <source>Minute:</source>
        <translation type="obsolete">Минуты:</translation>
    </message>
    <message>
        <source>Image filename:</source>
        <translation type="obsolete">Имя файла изображения:</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Удалить изображение</translation>
    </message>
    <message>
        <source>ISBN:</source>
        <translation type="obsolete">ISBN:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="obsolete">Ширина:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="obsolete">Высота:</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="obsolete">Качество:</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Высокое</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Лучшее</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Низкое</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Авто высокий</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Авто низкий</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Авто проигрывание</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Цикл</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Контролер</translation>
    </message>
    <message>
        <source>Controls:</source>
        <translation type="obsolete">Controls:</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Окно изображения</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>InfoVolumePanel</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Информационная панель</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Найти объект</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Опции:</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Новая опция</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation type="obsolete">URL:</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation type="obsolete">Текст:</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation>Имя пользователя:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation>e-mail:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>Password confirmation:</source>
        <translation>Подтверждекние пароля:</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Цена:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Ваша цена:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Вы экономите:</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Информация о пользователе</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation type="obsolete">E-mail:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <source>Confirmation:</source>
        <translation>Подтверждекние:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <source>MIME Type</source>
        <translation>MIME тип</translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation>Размер файла</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Год</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Месяц</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>День</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Час</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Минута</translation>
    </message>
    <message>
        <source>Image filename</source>
        <translation>Имя файла изображения</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Альтернативный текст изображения</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Качество</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Средства управления</translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation> Имя существующего  файла</translation>
    </message>
    <message>
        <source>Existing orignal filename</source>
        <translation> Оригинальное имя существующего  файла</translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation>mime/type существующего файла</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Нет отношения</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Начальное значение</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Конечное значение</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Значение шага</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ИД пользователя</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Подтвердите пароль</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Цена</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from:</source>
        <translation type="obsolete">Информация собрана с:</translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation>Следущая информация была собрана:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Сортировать по</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Сортировка</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Главный</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Переместить</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="obsolete">Путь</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Опубликовано</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Изменено</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Глубина</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Идентификатор класса</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Имя класса</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Add location(s)</source>
        <translation type="obsolete">Добавить расположение</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Предвар. просмотр</translation>
    </message>
    <message>
        <source>Store Draft</source>
        <translation type="obsolete">Сохранить  черновик</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Отправить для публикации</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Информация об объекте</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation type="obsolete">Создано:</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Еще не опубликовано</translation>
    </message>
    <message>
        <source>Version info</source>
        <translation type="obsolete">Информация о версии</translation>
    </message>
    <message>
        <source>Editing:</source>
        <translation type="obsolete">Редактирование:</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation> Править</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Родственные объекты</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Вы уверены что хотите отменить черновик?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Собранная информация с %1</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Сохранить черновик</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Добавить расположение</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Создан</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Редактирование</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Нет информации о регионе )</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>Проверка правильности неудалась</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Неправильное расположение объекта</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Расширенный поиск</translation>
    </message>
    <message>
        <source>No results were found when searching for:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Search for:</source>
        <translation>Искать:</translation>
    </message>
    <message>
        <source>returned</source>
        <translation>возвращенно</translation>
    </message>
    <message>
        <source>matches</source>
        <translation>совпадений</translation>
    </message>
    <message>
        <source>Search all the words:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Search the exact phrase:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Search with at least one of the words:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Любой класс</translation>
    </message>
    <message>
        <source>Class attribute:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Обновить атрибуты</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Любая секция</translation>
    </message>
    <message>
        <source>Published:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Любое время</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>За последний день</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>За последнюю неделю</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>За последний месяц</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>За последние три месяца</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>За последний год</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>No results were found for searching:</source>
        <translation>Не было найдено результатов при поиске:</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Искать все слова</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Искать точное совпадение фразы</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>По крайней мере одно из слов</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Атрибут класса</translation>
    </message>
    <message>
        <source>In</source>
        <translation>В</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Опубликовано</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Не было найдено результатов при поиске &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Поиск по &quot;%1&quot; вернул %2 совпадений</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <translation>Для большего колличества опций попробуйте %1Расширенный поиск%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Следущие слова были исключены из поиска:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Послать другу</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Сообщение посланно.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Нажмите здесь, чтобы возвратиться к первоначальной странице.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Сообщение не было посланно.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Сообщение не было посланно из-за неизвестной ошибки. Пожалуйста известите администратора сайта об этой ошибке.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Пожалуйста исправте следущие ошибки:</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Ваше имя</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Ваш E-mail</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Имена получателей</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>E-mail адреса получателей</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Послать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Это сообщение было послано вам потому что &quot;%1 &lt;%2&gt;&quot;  считает, что вам будет интерестна страница &quot;%3&quot; на %4.</translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation>Это ссылка на страницу:</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation>Комментарий от &quot;%1 &lt;%2&gt;&quot;:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating</source>
        <translation>Пеевод</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>input was stored successfully</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove the following translations from</source>
        <translation>Удалить следущие переводу из</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Нет информации о регионе )</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Translate into:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Переводы</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Перевести</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Edit Object</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 данные успешно сохранены</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Регион</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Перевести на</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текущая версия</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Восстановить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Корзина пустая</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for:</source>
        <translation>Версии для:</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Версия не черновик</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>is not available for editing anymore, only drafts can be edited.</source>
        <translation>не доступна более для редактирования. Только черновики могут быть отредактированны.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Для редактирования данной версии создайте ее копию.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Версия вам не принадлежит</translation>
    </message>
    <message>
        <source>was not created by you, only your own drafts can be edited.</source>
        <translation>была создана не вами, только лишь ваши собственные шаблоны могут быть отредактированы.</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Версия:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Статус:</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Переводы:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Создатель:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Изменено:</translation>
    </message>
    <message>
        <source>Object Edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Копировать и редактировать</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation>Пролистать</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>Select:</source>
        <translation type="obsolete">Выбрать:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Версия:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Редактировать:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>У вас нет черновиков</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation type="obsolete">Текущая версия:</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Родственные объекты</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Пусто</translation>
    </message>
    <message>
        <source>Translation:</source>
        <translation type="obsolete">Перевод:</translation>
    </message>
    <message>
        <source>Placement:</source>
        <translation type="obsolete">Расположение:</translation>
    </message>
    <message>
        <source>Site Design:</source>
        <translation type="obsolete">Site Design:</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Опубликовать</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Для выбора объектов, выберите подходящий переключатель(ли), и нажмите кнопку &quot;Выбрать&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Для выбора дочернего объекта одного из отображенных объектов, нажмите на имя объекта и вы получите список с дочерними элементами.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текущая версия</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Расположени</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Дизайн сайта</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Доступ запрещен</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>У вас нет разрешения на доступ в этот раздел.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не найдено</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Модуль не найден</translation>
    </message>
    <message>
        <source>The requested module</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>could not be found.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Вид не найден</translation>
    </message>
    <message>
        <source>The requested view</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>could not be found in module:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation>Недоступен</translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation>Объект недоступен.</translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation>Войдите в систему, чтобы получить надлежащие разрешения.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Нажмите на кнопку &quot;Войти&quot; для того, чтобы войти в систему.</translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation>Запрашиваемый модуль &apos;%1&apos; не найден.</translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation>Запрашиваемый вид &apos;%1&apos; не найден в модуле: &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Content</source>
        <translation type="obsolete">Содержимое</translation>
    </message>
    <message>
        <source>List</source>
        <translation type="obsolete">Список</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation type="obsolete">Мои черновики</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation type="obsolete">Установить</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation type="obsolete">Классы</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation type="obsolete">Секции</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation type="obsolete">Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="obsolete">Тригеры</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation type="obsolete">Статистика поиска</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation type="obsolete">Магазин</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="obsolete">Список заказов</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="obsolete">типы НДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="obsolete">Скидки</translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="obsolete">Пользователи</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="obsolete">Роли</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation type="obsolete">Мой извещения</translation>
    </message>
    <message>
        <source>My Tasks</source>
        <translation type="obsolete">Мои задания</translation>
    </message>
    <message>
        <source>New article</source>
        <translation type="obsolete">Новая статья</translation>
    </message>
    <message>
        <source>New link</source>
        <translation type="obsolete">Новая ссылка</translation>
    </message>
    <message>
        <source>New product</source>
        <translation type="obsolete">Новый продукт</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Добро пожаловать в управление eZ Publish</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Для входа введите действительное имя пользователя и пароль.</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Расширенный поиск</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Имя:</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Изменить Пароль</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Войти</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>About eZ publish</source>
        <translation type="obsolete">О eZ publish</translation>
    </message>
    <message>
        <source>About eZ publish 3</source>
        <translation type="obsolete">О eZ publish 3</translation>
    </message>
    <message>
        <source>Installation &amp; configuration</source>
        <translation type="obsolete">Установка &amp; конфигурация</translation>
    </message>
    <message>
        <source>Install using installers</source>
        <translation type="obsolete">Установка используя инстоляторы</translation>
    </message>
    <message>
        <source>Install manually</source>
        <translation type="obsolete">Ручная установка</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation type="obsolete">Деинсталировть</translation>
    </message>
    <message>
        <source>SDK &amp; Technical references</source>
        <translation type="obsolete">SDK &amp; Technical references</translation>
    </message>
    <message>
        <source>eZ publish SDK</source>
        <translation type="obsolete">eZ publish SDK</translation>
    </message>
    <message>
        <source>Redirecting to:</source>
        <translation type="obsolete">Перенапрвление на:</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Перенаправление</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Запуск снова</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Загрузка модуля не удалась</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Не определен модуль:</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Сайт:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Версия:</translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation>%1 главная страница</translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation>Искать %1</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Версия для печати</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Главная страница</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личные</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Redirecting to %1</source>
        <translation>Перенаправление на %1</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Предыдущая</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Слудущая</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>from node</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>?</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>!</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation>Удаление привязки к узлу </translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) node(s)?</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Removing</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>will remove the node itself and it&apos;s</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Следущие товары были удалены из вашей корзины, так как свойстав этих товаров были изменены</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Вы уверены что хотите удалить %1 из узла %@2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation>Удаление этой привязки также удалит этот %1!</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Примечание:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Удаленные узлы могут быть восстановлены позднее. Вы можете найти их в корзине.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation>Вы уверены, что хотите удалитьб эти узлы?</translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2! %3</source>
        <translation>Удаление %1 удалить сам узел и его %2! %3</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>m.nam</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Sorting:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Документ</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Карта сайта</translation>
    </message>
    <message>
        <source>Object:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Section ID:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>You are not allowed to create child objects</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Группа пользователя</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Создать здесь</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Notification registration form</source>
        <translation>Форма регистрации уведомления</translation>
    </message>
    <message>
        <source>Send Method:</source>
        <translation>Метод посылки:</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>СМС</translation>
    </message>
    <message>
        <source>Internal message</source>
        <translation>Внутреннее сообщение</translation>
    </message>
    <message>
        <source>Send day:</source>
        <translation>День посылки:</translation>
    </message>
    <message>
        <source>Immediately</source>
        <translation>Немедленно</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Понедельник</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Вторник</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Среда</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Четверг</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Пятница</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Суббота</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Воскресенье</translation>
    </message>
    <message>
        <source>Send time:</source>
        <translation>Время посылки:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation>ИД:</translation>
    </message>
    <message>
        <source>Rule Type:</source>
        <translation>Тип правила:</translation>
    </message>
    <message>
        <source>Class Name:</source>
        <translation>Имя класса:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation>Ключевое слово:</translation>
    </message>
    <message>
        <source>Additional constraint:</source>
        <translation>Дополнительное ограничение:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation>Редактировать:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation>Удаление:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>New Rule</source>
        <translation>Новое правило</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation>Послать сообщение</translation>
    </message>
    <message>
        <source>Patd:</source>
        <translation>Путь:</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/rules</name>
    <message>
        <source>Content Class Name:</source>
        <translation>Имя класса содержимого:</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Путь:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation>Ключевое слово:</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Создать правило для</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Шаг 1</translation>
    </message>
    <message>
        <source>Give access to module:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Все модули</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Разрешить всё</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Разрешить с ограничениями</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ОтменитьОтменить</translation>
    </message>
    <message>
        <source>Module:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Access:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ограниченный</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Вернуться к шагу 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Вы не мошете разрешить ограниченный доступ к функциям модуля</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>потому что список функций не определенн.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Шаг 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Укажите функцию в модуле</translation>
    </message>
    <message>
        <source>Function:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Вернуться к шагу 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Шаг 3</translation>
    </message>
    <message>
        <source>Specify limitations in function</source>
        <translation>Укажите список ограничений для функции</translation>
    </message>
    <message>
        <source>in module</source>
        <translation> в модуле</translation>
    </message>
    <message>
        <source>&apos;Any&apos; means no limitation by this parameter.</source>
        <translation>Под &quot;Любой&quot; подразумевается отсутсвие ограничений по этому параметру.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation>Редактирование роли</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Current policies:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Limitation list:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Список ролей</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Просмотр роли</translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Правила роли</translation>
    </message>
    <message>
        <source>Limitation:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Пользователи и группы пользователей которым назначена эта роль</translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Назначить</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Дать доступ к модулю</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модуль</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Доступ</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Текущие правила</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Отменить изменения</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Статистика поиска</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Наиболее частые поисковые фразы</translation>
    </message>
    <message>
        <source>Phrase:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Number of phrases:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Average result returned:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Фраза</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Количество фраз</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Средний результат</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section</source>
        <translation>Назначить секцию</translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation>Назначить секцию узлу</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Редактирование секции</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохравнить</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Список секций</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>assign</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новая</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Вы уверены что хотите удалить эти секции?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Удаление этих секций может привести к повреждению прав доступа, дизайна сайта, и других участков системы. Не делайте этого если вы не уверены в точности 6 что вы делаете.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Часть навигации</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Магазин</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Пользователи</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Установить</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личное</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>Про части навигации</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>Административный интерфейс eZ publish разделен на навигационные части. Это способ сгруппировать различные области администрирования сайта. Выберите навигационную часть которая должна быть активной  когда просматривается эта секция.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ИД</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>site registration</source>
        <translation>Регистрация сайта</translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation>Информация о сайте:</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation>Информация о PHP:</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation>Информация об ОС:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation>Информация о БД:</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Драйвер</translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <source>Supported</source>
        <translation>Поддерживается</translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation>Не поддерживается</translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation>Демонстрационные данные:</translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation>Демо данные были установленны.</translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation>Демо данные не были установленны.</translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation>Email информация:</translation>
    </message>
    <message>
        <source>Transport</source>
        <translation>Транспорт</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>sendmail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation>Преобразование изображений:</translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation>ImageMagick был найден и использован.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Путь</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Выполняемый</translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation>Расширение ImageGD было найдено и использовано.</translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation>Региональная информация:</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Одноязычный</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Многоязычный</translation>
    </message>
    <message>
        <source>Primary</source>
        <translation>Главный</translation>
    </message>
    <message>
        <source>Additional</source>
        <translation>Дополнительный</translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation>Критические тесты:</translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation>Другие тесты:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <source>setup</source>
        <translation>Установка</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Если вы не можете установить соединение с базой данных, вам следует посмотреть на</translation>
    </message>
    <message>
        <source>at</source>
        <translation>на </translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Вступление</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL это СУБД созданная  MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>В данный момент это одна из самых популярных баз данных в секции Свободного програмного обеспечения и наиболее часто ее поддержка включена в PHP по умолчанию.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>С сайта производителя:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL самая популярная в мире СУБД с открытым исходным кодом, разработана для скорости, мощности и точности в критическом, с большой загрузкой использовании.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Более подробная информация может быть найдена на</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL хороший выбор для поддержки западных языков, однако это в данный момент не лучший выбор для Unicode или не западных языков.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Инсталяция</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>Используя</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>опцию конфигурации вы позволяете PHP получать доступ к БД MySQL. Если вы используете эту опцию без указания пути к MySQL, PHP  будет использовать встроенные библиотеки клиента MySQL.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Дополнительная информация о расширении MySQL может быть найдена на</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL это СУБД  разработанная в университете Калифорнии  в депортаменте компьютерных наук Беркли.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>Это очень популярная СУБД в сообществе открытого програмного обеспечения, она предоставляет расширенную функциональность.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL сложная объектно-реляционная СУБД, поддерживающая почти все конструкции языка SQL, включая подзапросы, транзакции, пользовательские типы данных и финкции. Это одна из самых продвинутых субд с открытым исходным кодом.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL хороший выбор для поддержки большинства языков, включая Unicode, но требует настройки для получения хорошей скорости работы.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Для включения поддержки PostgreSQL,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>необходимо при компиляции PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Дополнительная информация о PostgreSQL может быть найдена на</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button when ready.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue and remove the data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue and skip database initialization.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It can take some time creating the database so please be patient and wait until the new page is finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Driver:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Unicode support:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to start the configuration process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servername:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Databasename:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Username:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>which must available on the server or</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you find a bug (error), please go to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the URL to access your new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button. Enjoy one of the most successful web content management systems!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title of your site:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>URL to your site:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to re-run the system checking.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to loose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servername</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Socket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Databasename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL to your site</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>colon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>configuration and set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on the subject can be found at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration example:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Product:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Count:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>VAT:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Price ex. VAT:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Price inc. VAT:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Discount:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Total Price ex. VAT:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Total Price inc. VAT:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation>Всего без НДС:</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Всего с НДС:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Продолжить покупки</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Расчитаться</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>В вашей корзине нет продуктов</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Подтвердите заказ</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Товары</translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation>Итоговый заказ:</translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation>За товары:</translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation>Заказ всего:</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Подтвердить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Defined discount groups</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Editing discount group</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Просмотр группы</translation>
    </message>
    <message>
        <source>Group Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Defined rules:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Apply to:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Добавить правило</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Удалить правило</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Клиенты</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Добавить клиента</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Удалить клиента</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирование правила</translation>
    </message>
    <message>
        <source>Discount percent:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Choose which classes or sections applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Выберите к каким классам и секциям применяется данное правило, под &quot;Любой&quot; подразумевается что это правило брименяется ко всем.</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Любой</translation>
    </message>
    <message>
        <source>Section:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ИД</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Всего без НДС</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Всего с НДС</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Заказ</translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation>Клиент:</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Типы НДС</translation>
    </message>
    <message>
        <source>Percentage:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Список пожеланий</translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation>Удалить элементы</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Очистить список пожеланий</translation>
    </message>
    <message>
        <source>Pris pr. pakke</source>
        <translation></translation>
    </message>
    <message>
        <source>Antall</source>
        <translation></translation>
    </message>
    <message>
        <source>Sum</source>
        <translation></translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Всего:</translation>
    </message>
    <message>
        <source>Price pr. pakke</source>
        <translation></translation>
    </message>
    <message>
        <source>Antall pakker</source>
        <translation></translation>
    </message>
    <message>
        <source>Subtotal:</source>
        <translation>Предварительная сумма:</translation>
    </message>
    <message>
        <source>Order:</source>
        <translation>Заказ:</translation>
    </message>
    <message>
        <source>Vendor name:</source>
        <translation>Vendor name:</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Товар</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>НДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без НДС</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с НДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Скидка</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Полная цена без НДС</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Полная цена с НДС</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Грппы скидок</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Редактировать группу скидок - %1</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Название группы</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Определенные правила</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Применить к</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Процент скидки</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Класс</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Сумма за товары</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Список заказов пуст</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Заказ всего</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Зарегестрировать информацию о счете</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Ошибки ввода, заполните все поля</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Процент</translation>
    </message>
</context>
<context>
    <name>design/standard/task</name>
    <message>
        <source>Creating new task</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Assignment</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Date:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>From:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Please select receiver</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Parent type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Parent ID:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Access Type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Read/Write</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Object Type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Content Object</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Content Class</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Work Flow</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Role</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Assignment for object:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Choose Object</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Convert To Assignment</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Convert To Task</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Change Receiver</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit task message</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Object list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Find object</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Task message</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Task view</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Task list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Incoming</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Title:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Created:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Outgoing</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Sub tasks</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Receiver:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New Task</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New Assignment</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New Message</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Close Task</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Cancel Task</source>
        <translation type="obsolete"></translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Triggers list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Triggers editing</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation>Названи модуля</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Название функции</translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation>Тип соединения</translation>
    </message>
    <message>
        <source>Workflow ID</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Нет процесса</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Trigger list</source>
        <translation>Список тригеров</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Процесс</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Правильный</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Неправильный</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>URL более не является правильным.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>Это значит что url более недоступен или был перемещен.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>URL указывает на %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Последний раз изменен %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>URL не содержит дату изменения</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Последний раз проверен %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>URL не был проверен</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Activate account</source>
        <translation>Активировать счет</translation>
    </message>
    <message>
        <source>Login ID:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Registed user profile</source>
        <translation>Зарегестрированный профиль пользователя</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Update Profile</source>
        <translation>Обновить профайл</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation>Изменить установки</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Войти</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Невозможно зарегестрироваться</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Действительное имя пользователя и пароль необходимы для регистрации в системе.</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Изменить пароль пользователю</translation>
    </message>
    <message>
        <source>Old Password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New Password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Retype Password:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Зарегестрировать пользователя</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Ввод не утвержден</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Данные успешно сохранены</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Установки пользователя</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Максимальное количество входов в систему</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Действителен</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Пользователь зарегестрирован</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Ваш счет был успешно создан.</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Сгенерировать</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Доступ запрещен</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>У вас нет прав для доступа %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <source>Old Password</source>
        <translation>Старый пароль</translation>
    </message>
    <message>
        <source>New Password</source>
        <translation>Новый пароль</translation>
    </message>
    <message>
        <source>Retype Password</source>
        <translation>Подтвердите пароль</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>Confirm user registration at %1</source>
        <translation>Подтвердите регистрацию пользователя на %1</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation>%1 новый пароль</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation>Нажмите для получения нового пароля:</translation>
    </message>
    <message>
        <source>New user registered at %1</source>
        <translation>Новый пользователь зарегестрирован на %1</translation>
    </message>
    <message>
        <source>%1 registration info</source>
        <translation>%1 регистрационная информация</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Editing workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pos:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Новый</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished">Сохранить</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation type="unfinished">Изменен</translation>
    </message>
    <message>
        <source>Defined workflow groups</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>using version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defined workflows for</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Temporary workflows for</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished">Изменено</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Sections:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users without approval:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Checkout text:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Section IDs:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Users without workflow IDs:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Minutes:</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sections</source>
        <translation type="unfinished">Секции</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section IDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation type="unfinished">Удалить выбранные</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/result</name>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Список классов группы</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Список групп классов</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Удалить класс</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Редактировать класс</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Классы</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Список классов</translation>
    </message>
    <message>
        <source> object</source>
        <translation>объект</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>объекты</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Удалить классы</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>нет классов</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Удалить группы классов</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Стандартные</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Наблюдатель</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Владелец</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Входящие</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Еще не определен статус</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Процесс выполняется</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Процесс закончен</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Процесс неудался на событии</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Событие процесса перенаправленно на выполнение cron-демону</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>процесс отменен</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Процесс был переинициализирован для повторного использования</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Принятое событие</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Отброшенное событие</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Событие перенаправленно cron-демону</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Событие процесса перенаправленно на выполнение cron-демону, событи будет начато с начала</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>Событие выполняет подсобытие</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Отменен весь процесс</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatype/ezbinaryfiletype</name>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Загрузка файлов не включена. Нефозможно обработать файл.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is requied.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation>Должно присутствовать имя автора.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation>Не правильный E-mail адрес.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation>Необходим правильный файл.</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation>Необходим действительный Email.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation>Не правильный E-mail адрес.</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation>По крайней мере одно из полей должно быть выбрано.</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation>Введенные данные не являются числом.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation>Число должно быть больше %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation>Число должно быть меньше %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation>Числе вне предопределенного диапазона %1 - %2</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation>Необходимо правильное изображение.</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation>Введенные данные не являются целым числом.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Число должно быть больше %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation>Число должно быть меньше %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation>Числе вне предопределенного диапазона %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation>Код ISBN не правилен. Пожалуйста перепроверте введенные данные</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation>Формат ISBN не правилен.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation>Необходим правильный файл.</translation>
    </message>
    <message>
        <source>At least one option is requied.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation>Должно присутствовать значение опции.</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Пустая строка ввода, необходимо содержимое.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation>Длнна строки превышает максимально допустимую %1.</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Пустае поле для текста, необходимо содержимое.</translation>
    </message>
    <message>
        <source>An user account must be filled up</source>
        <comment>eZUserType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Login name exist, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Please confirm your password.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>The minimum length of password should be 3.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Object </source>
        <translation>Объект</translation>
    </message>
    <message>
        <source>Link </source>
        <translation>Ссылка</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <comment>eZAuthorType</comment>
        <translation>По крайней мере один необходимо указать одного автора.</translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation>Отсутвует дата.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Не указано время и дата.</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <comment>eZOptionType</comment>
        <translation>Необходима по крайней мере одна опция.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation>Неправильная дополнительная цена для значения опции.</translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Отсутвует время.</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation>Необходим логин пользователя</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation>Данное имя пользователя уже существует, пожалуйста выберите другое.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation>Не правильный E-mail адрес.</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <comment>eZUserType</comment>
        <translation>Пользователь с данным email адресом уже существует.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>Подтвержденный пароль не совпадает.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation>Пароль дожен быть как минимум 3 символа длинной.</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Специальное событие совместной работы</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Совместная работа</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Не выбран главный узел, пожалуйста укажите один.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои черновики</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Удалить редактируемую версию</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Удалить объект</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Закладка от %1: %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Почтовый адрес отправителя неправилен</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Почтовый адрес получателя неправилен</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Послать другу</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Перевести</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Переводы содержимого</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Мусорная корзина</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Дочерний</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>дочерние</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Дакже это удалит узлы:</translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Дочерний</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>дочерние</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Права</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation>Создать правила - шаг 2 - укажите функцию</translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation>Создать правила - шаг 3 - укажите ограничения</translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation>Создать правила - шаг 1 - укажите модуль</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Список ролей</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Статистика поиска</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Редактировать секцию</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Корзина</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Расчитаться</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Подтвердите заказ</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Грппа скидок</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>просмотр группы правила скоидок</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирование правила</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Список заказов</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Просмотр заказа</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Введите данные счета</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типы НДС</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Триггер</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вид</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Пользователь</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Забыли пароль</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Зарегестрировать</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Регистрационная информация</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Новый пользователь зарегестрирован</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Редактировать процесс</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Процесс</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Редактировать группу процессов</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Редактировать группу</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Список групп процессов</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Список групп</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Список процессов</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Список процессов в группе</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Обнаружено несколько ошибок в шаблонах. Просмотрите отладочную информацию для дополнительной информации.</translation>
    </message>
</context>
<context>
    <name>logon</name>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
</context>
<context>
    <name>pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
</context>
<context>
    <name>signup</name>
    <message>
        <source>Sign Up</source>
        <translation>Зарегестрироваться</translation>
    </message>
</context>
<context>
    <name>workflow/eventtype/result/event_ezcheckout</name>
    <message>
        <source>Wrapping</source>
        <translation type="obsolete"></translation>
    </message>
</context>
</TS>
