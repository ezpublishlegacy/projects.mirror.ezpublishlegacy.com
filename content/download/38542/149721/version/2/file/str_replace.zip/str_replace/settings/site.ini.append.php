<?php

[TemplateSettings]
ExtensionAutoloadPath[]=str_replace

?>