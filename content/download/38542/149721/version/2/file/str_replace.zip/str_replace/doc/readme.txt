**************************************************

String Replace Operator

**************************************************

Author : Alexandre Abric
Date : April 2005

1/ Unzip file in your extension directory

2/ Activate the extension in the admin interface

3/ To use operator in a template :

{ezstr_replace($search,$replace,$subject)}