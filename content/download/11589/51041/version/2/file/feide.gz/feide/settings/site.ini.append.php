<?php /* #?ini charset="utf-8"?


[RoleSettings]
PolicyOmitList[]=simplesaml
PolicyOmitList[]=feide/login
PolicyOmitList[]=feide/logout

*/ ?>