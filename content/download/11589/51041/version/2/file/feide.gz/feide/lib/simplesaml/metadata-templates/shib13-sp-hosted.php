<?php
/* 
 * SAML 2.0 Meta data for simpleSAMLphp
 *
 */

$metadata = array(

	/*
	 * Example of hosted Shibboleth 1.3 SP.
	 */
	'sp-provider-id' => array(
		'host' => 'sp.example.org'
	)

);

?>