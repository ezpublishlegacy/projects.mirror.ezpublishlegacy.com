<?php /* #?ini charset="utf-8"?

[Feide]
EnabledSiteaccesses[]
EnabledSiteaccesses[]=eng

# User vil be redirected to this page after login
LoginRedirect=/

[SimpleSaml]
ExtensionAutoloadPath[]=feide


[Groups]
// All feide users wil have the main node created in this group
MainGroupNodeId=160
GroupAttributes[]
GroupAttributes[]=eduPersonAffiliation


# Definition and mapping for the user account attribute in the user class
[UserAccount]
eZAttributeIdentifier=user_account
LoginAttribute=eduPersonPrincipalName
MailAttribute=mail
# Defines attributes than specifies which user groups a user should belong to


# Mapping for the rest of the fields in the ez user class in the following format:
# ez_attribute_identifier=feide_attribute_identifier
[FieldMapping]
first_name=givenName
last_name=sn
image=jpegPhoto

*/ ?>
