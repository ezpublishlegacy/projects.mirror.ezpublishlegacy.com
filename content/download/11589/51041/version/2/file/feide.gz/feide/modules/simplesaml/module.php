<?php

$Module=array(
	'name'=>'simplesaml',
	'function'=>array(
		'script'=>'testsingle.php',
		'ui_context'=>'test',
		'params' => array(),
	),
);

$ViewList=array();

?>
