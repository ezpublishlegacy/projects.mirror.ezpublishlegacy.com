<?php


echo "This is content from test1.php\n";

echo "\n";
echo "GET: ".var_export($_GET,true)."\n";

?>
