<?php
/** 
 * SAML 2.0 Meta data for simpleSAMLphp
 *
 *
 *
 *
 */


$metadata = array(
	'theproviderid-of-the-idp'	=> array(
		'SingleSignOnService'  => 'https://idp.example.org/shibboleth-idp/SSO',
		'certFingerprint'      => 'c7279a9f28f11380509e072441e3dc55fb9ab864' 
	)
);

?>