<?php


$basePath='extension/feide/lib/simplesaml/www/';


/*
if( isset($_SESSION['SimpleSAMLphp_SESSION']) && is_string($_SESSION['SimpleSAMLphp_SESSION'])) {
	$_SESSION['SimpleSAMLphp_SESSION'] = unserialize( base64_decode($_SESSION['SimpleSAMLphp_SESSION']) );
}
*/




$uri=eZSys::requestURI();
$modName=$Params['Module']->attribute('name');
if ($uri=='/'.$modName) {
	header('Location: /'.$modName.'/');
	eZExecution::cleanExit();
}
if (substr($uri,0,1)=='/') {
	$uri=substr($uri,1);
}
$parts=explode('/',$uri);
if ($parts[0]==$modName) {
	array_shift($parts);
}
$uri=implode('/',$parts);
if ($uri=='') {
	$uri='index.php';
}
if ($basePath!='' && substr($basePath,-1)!='/') {
	$basePath.='/';
}
$path=$basePath.$uri;
if (file_exists($path)) {
	if (is_dir($path)) {
		header('Location: /'.$modName.'/'.$uri.'/index.php');
	} else {
		$pi=pathinfo($path);
		if ($pi['extension']=='php') {
			$dir=getcwd();
			chdir($pi['dirname']);
			require(basename($path));
			chdir($dir);
		} elseif($pi['extension']=='css') {
			header('Content-Type: text/css');
			readfile($path);
		} else {
			$mimetype=mime_content_type($path);
			if ($mimetype!='') {
				header('Content-Type: '.$mimetype);
			}
			readfile($path);
		}
	}
} else {
	header('HTTP/1.1 404 Not Found');
	echo "File not found.";
}
eZExecution::cleanExit();

?>
