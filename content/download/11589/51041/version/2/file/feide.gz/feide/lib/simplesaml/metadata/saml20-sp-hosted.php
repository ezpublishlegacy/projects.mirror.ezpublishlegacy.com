<?php
/* 
 * SAML 2.0 Meta data for simpleSAMLphp
 *
 * The SAML 2.0 IdP Remote config is used by the SAML 2.0 SP to identify itself.
 *
 */
 
$metadata = array( 

	/*
	 * Example of a hosted SP 
	 */
	 
	 
	'urn:mace:feide.no:services:no.nxc.ezpublish' => array(
		'host'							=>	'feide.nxc.no',
		'ForceAuthn'					=>	'false',

	 
		/*
		 * When request.signing is true the privatekey and certificate of the SP
		 * will be used to sign/verify all messages received/sent with the HTTPRedirect binding.
		 * 
		 * Certificate and privatekey must be placed in the cert directory.
		 */
		 
/*		 
		'request.signing' => false,	
		'privatekey' => 'server.pem',
		'certificate' => 'server.pem',
*/		
	)

);


?>