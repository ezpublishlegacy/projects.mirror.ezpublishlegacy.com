<?php

$Module = array( 'name' => 'feide',
                 'variable_params' => true );

$ViewList = array();

$ViewList['simplesaml'] = array(
    'script' => 'simplesaml.php',
    'default_action' => array(),
    'single_post_actions' => array(),
    'post_action_parameters' => array(),
    'params' => array( 'page' ) );

		
$ViewList['login'] = array(
    'script' => 'login.php',
    'default_action' => array(),
    'single_post_actions' => array(),
    'post_action_parameters' => array(),
    'params' => array( 'page' ) );

$ViewList['logout'] = array(
    'script' => 'logout.php',
    'default_action' => array(),
    'single_post_actions' => array(),
    'post_action_parameters' => array(),
    'params' => array( 'page' ) );

		
?>

