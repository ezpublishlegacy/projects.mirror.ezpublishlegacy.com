<?php
$Module =& $Params['Module'];
$page =& $Params['page'];


include_once( 'lib/ezutils/classes/ezoperationhandler.php' ); // For publish
include_once( "lib/ezutils/classes/ezhttptool.php" );

$http = eZHTTPTool::instance();

include_once( "extension/feide/lib/simplesaml/www/index.php" );




eZExecution::cleanExit();

?>

