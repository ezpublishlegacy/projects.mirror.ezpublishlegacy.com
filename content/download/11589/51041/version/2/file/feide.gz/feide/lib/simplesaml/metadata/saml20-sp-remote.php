<?php
/* 
 * SAML 2.0 Meta data for simpleSAMLphp
 *
 * The SAML 2.0 SP Remote config is used by the SAML 2.0 IdP to identify trusted SAML 2.0 SPs.
 *
 *	Required parameters:
 * 
 *		spNameQualifier
 *		NameIDFormat
 *		simplesaml.attributes (Will you send an attributestatement [true/false])
 *
 *	Optional parameters:
 *
 *		ForceAuthn (default: "false")
 *		simplesaml.nameidattribute (only needed when you are using NameID format email.
 *
 */

$metadata = array( 

	/* Feide */
	'max.feide.no' => array(
		'name'                 => 'FEIDE test',
		'description'          => 'FEIDE test id provider',
 		'AssertionConsumerService'		=>	'https://feide.nxc.no/simplesaml/saml2/sp/AssertionConsumerService.php', 
 		'SingleLogoutService'			=>	'https://feide.nxc.no/simplesaml/saml2/sp/SingleLogoutService.php',
		'ForceAuthn'					=>	'false',
		'NameIDFormat'					=>	'urn:mace:feide.no:services:no.nxc.feide',
		
		/* If base64attributes is set to true, then all attributes will be base64 encoded. Make sure
		 * that you set the SP to have the same value for this.
		 */
		'base64attributes'	=>	false,
		'simplesaml.attributes'			=>	true,
		//'attributemap'				=>	'test',
		//'attributes'					=>	array('mail')
		
	 
		/*
		 * When request.signing is true the certificate of the sp 
		 * will be used to verify all messages received with the HTTPRedirect binding.
		 * 
		 * The certificate from the SP must be installed in the cert directory 
		 * before verification can be done.  
		 */
		'request.signing' => false,
		'certificate' => "saml2sp.example.org.crt"
	),



		

);


?>
