<?php

require_once('extension/feide/lib/simplesaml/www/_include.php');
require_once('SimpleSAML/Session.php');
require_once('SimpleSAML/Utilities.php');
require_once('SimpleSAML/Metadata/MetaDataStorageHandler.php');
require_once('SimpleSAML/XHTML/Template.php');
require_once('SimpleSAML/Utilities.php');
require_once('SimpleSAML/Logger.php');
require_once('SimpleSAML/XHTML/Template.php');
require_once('SimpleSAML/Metadata/MetaDataStorageHandler.php');
require_once('SimpleSAML/XML/SAML20/AuthnRequest.php');
require_once('SimpleSAML/XML/SAML20/LogoutRequest.php');
require_once('SimpleSAML/Bindings/SAML20/HTTPRedirect.php');
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );


class nxcFeide {
	
	private $feideSession = null;
	private $isLoggedIn = false;
	private $feideIni = null;
	private $dirty = false;
	
		function __construct() {
			$this->feideIni = eZINI::instance( 'feide.ini' );
		}
	
	 static function instance( $databaseImplementation = false, $databaseParameters = false, $forceNewInstance = false ) {	
		 $impl =& $GLOBALS['nxcFeideInstance'];
		 if ( !( $impl instanceof eZDBInterface ) ) {
			 $impl = new nxcFeide();
		 }
		 return $impl;
	 }
	
	
	 
	 public function loginUser() {
		$siteAccess = $GLOBALS['eZCurrentAccess']['name'];
		$feideIni = eZINI::instance( 'feide.ini' );

		$feideEnabled = false;
		$feideEnabled = true;
		$feideEnabledSiteaccesses = $feideIni->variable( "Feide", "EnabledSiteaccesses" );
		
		
		foreach($feideEnabledSiteaccesses as $enabledSiteaccess) {
			if($enabledSiteaccess == $siteAccess) $feideEnabled = true;
		}
		
		$module = $GLOBALS['module'];
		
		
		if( $module->Name == 'simplesaml') {
			 $feideEnabled = false;
		}
		
		if( $feideEnabled && true) {
			
			$currentUser = eZUser::currentUser();
			
			$config = SimpleSAML_Configuration::getInstance();

			$metadata = SimpleSAML_Metadata_MetaDataStorageHandler::getMetadataHandler();
			$session = SimpleSAML_Session::getInstance(true);
			
			
			if (!isset($session) || !$session->isValid('saml2') ) {
				
				
				/**
				 * Incomming URL parameters
				 *
				 * idpentityid 	optional	The entityid of the wanted IdP to authenticate with. If not provided will use default.
				 * spentityid	optional	The entityid of the SP config to use. If not provided will use default to host.
				 * RelayState	required	Where to send the user back to after authentication.
				 * 
				 */		
			
				 
				SimpleSAML_Logger::info('SAML2.0 - SP.initSSO: Accessing SAML 2.0 SP initSSO script');
				
				if (!$config->getValue('enable.saml20-sp', false))
					SimpleSAML_Utilities::fatalError($session->getTrackID(), 'NOACCESS');
				
				try {
				
					$idpentityid = isset($_GET['idpentityid']) ? $_GET['idpentityid'] : $config->getValue('default-saml20-idp') ;
					$spentityid = isset($_GET['spentityid']) ? $_GET['spentityid'] : $metadata->getMetaDataCurrentEntityID();
				
				} catch (Exception $exception) {
					SimpleSAML_Utilities::fatalError($session->getTrackID(), 'METADATA', $exception);
				}
				
				
				
				
				if ($idpentityid == null) {
				
					SimpleSAML_Logger::info('SAML2.0 - SP.initSSO: No chosen or default IdP, go to SAML2disco');
					
					$returnURL = urlencode(SimpleSAML_Utilities::selfURL());
					$discservice = '/' . $config->getBaseURL() . 'saml2/sp/idpdisco.php?entityID=' . $spentityid . 
						'&return=' . $returnURL . '&returnIDParam=idpentityid';
						
					SimpleSAML_Utilities::redirect($discservice);
			
			
					eZExecution::cleanExit();
				}
				
				
				
				try {
					$sr = new SimpleSAML_XML_SAML20_AuthnRequest($config, $metadata);
				
					$md = $metadata->getMetaData($idpentityid, 'saml20-idp-remote');
					$req = $sr->generate($spentityid, $md['SingleSignOnService']);
			
					$httpredirect = new SimpleSAML_Bindings_SAML20_HTTPRedirect($config, $metadata);
					$relayState = SimpleSAML_Utilities::selfURL();
					
					SimpleSAML_Logger::info('SAML2.0 - SP.initSSO: SP (' . $spentityid . ') is sending AuthNRequest to IdP (' . $idpentityid . ')');
		
					$httpredirect->sendMessage($req, $spentityid, $idpentityid, $relayState);
					eZExecution::cleanExit();
				
				} catch(Exception $exception) {		
					SimpleSAML_Utilities::fatalError($session->getTrackID(), 'CREATEREQUEST', $exception);
				}
			}
			
			
			$ini = eZINI::instance();
			if($currentUser->isAnonymous() ) {

				if( $session->isValid('saml2') ) {
					$this->feideSession = $session;
					$this->isLoggedIn = true;
					$attributes = $this->feideSession->getAttributes();
					$feide_username = $attributes['eduPersonPrincipalName'][0];
					
					$mainGroupNodeId = $feideIni->variable( "Groups", "MainGroupNodeId" );
					$user = eZUser::fetchByName($feide_username);
					
					$this->publishUpdateUser( $mainGroupNodeId );

					
				}
			}
		} // if enabled
			return true;
	 }
	 
	 
	 function logoutUser() {
					 
			$config = SimpleSAML_Configuration::getInstance();
			$session = SimpleSAML_Session::getInstance();
			
			if (!$config->getValue('enable.saml20-sp', false))
				eZDebug::writeError( "enable.saml20-sp not found in config file", "nxcfeide::logoutUser()" );
				//SimpleSAML_Utilities::fatalError($session->getTrackID(), 'NOACCESS');
			
				
			if (isset($session) ) {
				
				try {
				
					$metadata = SimpleSAML_Metadata_MetaDataStorageHandler::getMetadataHandler();
				
					$idpentityid = $session->getIdP();
					$spentityid = isset($_GET['spentityid']) ? $_GET['spentityid'] : $metadata->getMetaDataCurrentEntityID();
				
					/**
					 * Create a logout request
					 */
					$lr = new SimpleSAML_XML_SAML20_LogoutRequest($config, $metadata);
					$req = $lr->generate($spentityid, $idpentityid, $session->getNameID(), $session->getSessionIndex(), 'SP');
					
					$httpredirect = new SimpleSAML_Bindings_SAML20_HTTPRedirect($config, $metadata);
					
					$relayState = "/user/logout";
					
					//SimpleSAML_Logger::info('SAML2.0 - SP.initSLO: SP (' . $spentityid . ') is sending logout request to IdP (' . $idpentityid . ')');
					
					$httpredirect->sendMessage($req, $spentityid, $idpentityid, $relayState, 'SingleLogoutService', 'SAMLRequest', 'SP');
					eZExecution::cleanExit();
			
				} catch(Exception $exception) {
					SimpleSAML_Utilities::fatalError($session->getTrackID(), 'CREATEREQUEST', $exception);
				}
			
			} else {
			
				if (!isset($_REQUEST['RelayState']))
					SimpleSAML_Utilities::fatalError($session->getTrackID(), 'NORELAYSTATE');		
				
				$relaystate = $_REQUEST['RelayState'];
				SimpleSAML_Logger::info('SAML2.0 - SP.initSLO: User is already logged out. Go back to relaystate');
				SimpleSAML_Utilities::redirect($relaystate);
				
			}
			
		 
		 
		 
		 
	 }
	 
	
    /*
        Static method, for internal usage only.
        Publishes new or update existing user
    */
    function publishUpdateUser( $mainNodePlacement, $isUtf8Encoding = false ) {

				$this->dirty = false;
			
				$userAttributes = $this->feideSession->getAttributes();
        $thisFunctionErrorLabel = 'nxcFeide.php, function publishUpdateUser()';
				
				$mappingDefinition = $this->feideIni->group('FieldMapping');
				$accountDefinition = $this->feideIni->group('UserAccount');
				
        if ( !is_array( $userAttributes ) or
             !isset( $userAttributes[ $accountDefinition['LoginAttribute'] ][0] ) or empty( $userAttributes[ $accountDefinition['LoginAttribute'] ][0] ) )
        {
            eZDebug::writeWarning( 'Empty user login passed.',
                                   $thisFunctionErrorLabel );
            return false;
        }
				
				$groupAttributes =  $this->feideIni->variable( "Groups", "GroupAttributes" );
        $parentNodeIDs = array();
				
				foreach($groupAttributes as $groupAttribute) {
					$groupNames = $userAttributes[$groupAttribute];
					foreach($groupNames as $groupName) {
						$group_node = $this->getGroup($groupName);
						if($group_node != null) {
							$parentNodeIDs[] = $group_node->attribute('node_id');
						}
					}
				}

//$parentNodeIDs[] = $this->getGroup('Test gruppe')->attribute('node_id');
				
        $parentNodeIDs = array_unique( $parentNodeIDs );
				

        $login      = $userAttributes[ $accountDefinition['LoginAttribute'] ][0];
				$first_name = $userAttributes[ $mappingDefinition['first_name'] ][0];
				$last_name  = $userAttributes[ $mappingDefinition['last_name'] ][0];
        $email      = $userAttributes[ $accountDefinition['MailAttribute'] ][0];

        $user = eZUser::fetchByName( $login );
        $createNewUser = ( is_object( $user ) ) ? false : true;
				

        if ( $createNewUser )
        {
            if ( !isset( $first_name ) or empty( $first_name ) or
                 !isset( $last_name ) or empty( $last_name ) or
                 !isset( $email ) or empty( $email ) )
            {
                eZDebug::writeWarning( 'Cannot create user with empty first name (last name or email).',
                                       $thisFunctionErrorLabel );
                return false;
            }

            $ini = eZINI::instance();
            $userClassID = $ini->variable( "UserSettings", "UserClassID" );
            $userCreatorID = $ini->variable( "UserSettings", "UserCreatorID" );
            $defaultSectionID = $ini->variable( "UserSettings", "DefaultSectionID" );

            $class = eZContentClass::fetch( $userClassID );
            $contentObject = $class->instantiate( $userCreatorID, $defaultSectionID );

            $remoteID = "FEIDE_" . $login;
            $contentObject->setAttribute( 'remote_id', $remoteID );
            $contentObject->store();

            $userID = $contentObjectID = $contentObject->attribute( 'id' );

            $version = $contentObject->version( 1 );
            $version->setAttribute( 'modified', time() );
            $version->setAttribute( 'status', eZContentObjectVersion::STATUS_DRAFT );
            $version->store();

            $user = eZUser::create( $userID );
            $user->setAttribute( 'login', $login );
        }
        else
        {
            $userID = $contentObjectID = $user->attribute( 'contentobject_id' );
            $contentObject = eZContentObject::fetch( $userID );
            $version = $contentObject->attribute( 'current' );
            //$currentVersion = $contentObject->attribute( 'current_version' );
        }

        //================= common part : start ========================
        $contentObjectAttributes = $version->contentObjectAttributes();

        foreach( $contentObjectAttributes as $attribute ) {
					$attrIdentifier = $attribute->attribute('contentclass_attribute_identifier');
					if( isset($mappingDefinition[$attrIdentifier]) && $mappingDefinition[$attrIdentifier] != '') {
						$feideAttribute = $mappingDefinition[$attrIdentifier];
						
						
						
						$data_type_string = $attribute->attribute('data_type_string');
						if( $data_type_string == 'ezimage' ) {
							/* Image datatype disabled for now
							$feideContent = $userAttributes[$feideAttribute][0];
							$sys = eZSys::instance();
							$storage_dir = eZSys::storageDirectory();
							$filename = $storage_dir . '/' . md5( $feideContent ) . '.jpg';
							
							$fp = fopen($filename, 'wb');
							fwrite($fp, $feideContent);
							fclose($fp);
							
							$content = $attribute->content();
							if ( is_object( $content ) ) {
								$content->initializeFromFile( $filename );
								if ( $content->isStorageRequired() ) {
									$content->store($attribute);
								}
							}
							
							unlink($filename);
							*/
						} else {
							$feideContent = implode(',', $userAttributes[$feideAttribute]);
							$existingContent = $attribute->attribute('data_text');
							if($feideContent != $existingContent) {
								$attribute->setAttribute( 'data_text', $feideContent );
								$attribute->store();
								$this->dirty = true;
							}
						}
						
					}
					
        }
				
				
				
        $contentClass = $contentObject->attribute( 'content_class' );
        $name = $contentClass->contentObjectName( $contentObject );
        $contentObject->setName( $name );

        $user->setAttribute( 'email', $email );
        $user->setAttribute( 'password_hash', "" );
        $user->setAttribute( 'password_hash_type', 0 );
        $user->store();
				
				
				// Update the rest of the attributes
				
				
				
				
        //================= common part : end ==========================
				$versionNo = $version->attribute('version');

				
        if ( $createNewUser ) {
            
						// Create main node assignment
						$newNodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObjectID,
                                                                      'contentobject_version' => 1,
                                                                      'parent_node' => $mainNodePlacement,
                                                                      'is_main' => 1 ) );
						$newNodeAssignment->setAttribute( 'parent_remote_id', "FEIDE_" . $mainNodePlacement );
						$newNodeAssignment->store();
					
					
            
            // Add node assignments according to user attributes
            foreach( $parentNodeIDs as $parentNodeID )
            {
                $newNodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObjectID,
                                                                      'contentobject_version' => 1,
                                                                      'parent_node' => $parentNodeID,
                                                                      'is_main' => 0 ) );
                $newNodeAssignment->setAttribute( 'parent_remote_id', "FEIDE_" . $parentNodeID );
                $newNodeAssignment->store();
            }

            //$adminUser = eZUser::fetchByName( 'admin' );
            //eZUser::setCurrentlyLoggedInUser( $adminUser, $adminUser->attribute( 'contentobject_id' ) );

            
            $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                         'version' => 1 ) );
        } else {
					// Update group assignments

					// Remove nodes
					$nodes = $contentObject->assignedNodes();
					foreach($nodes as $node) {
						$parent_node_id = $node->attribute('parent_node_id');
						if( !$node->attribute('is_main') ) {
							if( !in_array($parent_node_id, $parentNodeIDs) ) {
								$nodeassignment = eZNodeAssignment::fetch( $contentObjectID, $versionNo, $parent_node_id);
								if($nodeassignment != null) $nodeassignment->remove();
								$node->removeThis();
								$this->dirty = true;
							}
						}
						$existingParentNodes[] = $parent_node_id;
					}

					
					//Add new node assignments
					
					foreach( $parentNodeIDs as $parentNodeID ) {
						if( !in_array($parentNodeID, $existingParentNodes) ) {

							$newNodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObjectID,
                                                                      'contentobject_version' => $versionNo,
                                                                      'parent_node' => $parentNodeID,
                                                                      'is_main' => 0 ) );
							$newNodeAssignment->setAttribute( 'parent_remote_id', "FEIDE_" . $parentNodeID );
							$newNodeAssignment->store();
							$this->dirty = true;
						}
					}
					
        
        }

				if( $this->dirty ) {
					$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID, 'version' => $versionNo ) );
				}
				
				
        eZUser::updateLastVisit( $userID );
        //eZUser::setCurrentlyLoggedInUser( $user, $userID );
        // Reset number of failed login attempts
        eZUser::setFailedLoginAttempts( $userID, 0 );
				
				$user->loginCurrent();
				
        return $user;
    }

		
		
		
		// Finds group bu name or creates new group.
		function getGroup($groupName) {
			if($groupName == '') return null;
			
			
			//Get some info first
			$contentIni = eZINI::instance('content.ini');
			$userRootNode = $contentIni->variable( "NodeSettings", "UserRootNode" );
			
			$ini = eZINI::instance();
			$userGroupClassID = $ini->variable( "UserSettings", "UserGroupClassID" );
			$userCreatorID = $ini->variable( "UserSettings", "UserCreatorID" );
			$defaultSectionID = $ini->variable( "UserSettings", "DefaultSectionID" );

			// Find group node
			$params = array( 'ClassFilterType' => 'include',
											 'ClassFilterArray' => array( $userGroupClassID ),
											 'IgnoreVisibility' => true,
											 'Limitation' => array(),
											 'AttributeFilter' => array(  array( 'name', 'like', $groupName ) )
											 );
			
			
			$groupNodes = eZContentObjectTreeNode::subTreeByNodeID( $params, $userRootNode );
			
			if( count($groupNodes) > 0 ) {
				// We have a group
				return $groupNodes[0];
			} else {
				// No group was found. Create new group.

				$userGroupClass = eZContentClass::fetch( $userGroupClassID );
        $contentObject = $userGroupClass->instantiate( $userCreatorID, $defaultSectionID );

        $remoteID = "FEIDE_" . $groupName;
        $contentObject->setAttribute( 'remote_id', $remoteID );
        $contentObject->store();

        $contentObjectID = $contentObject->attribute( 'id' );

        $nodeAssignment = eZNodeAssignment::create( array( 'contentobject_id' => $contentObjectID,
                                                           'contentobject_version' => 1,
                                                           'parent_node' => $userRootNode,
                                                           'is_main' => 1 ) );
        $nodeAssignment->setAttribute( 'parent_remote_id', "FEIDE_" . $userRootNode );
        $nodeAssignment->store();

        $version = $contentObject->version( 1 );
        $version->setAttribute( 'modified', time() );
        $version->setAttribute( 'status', eZContentObjectVersion::STATUS_DRAFT );
        $version->store();
				
				
				$contentObjectAttributes = $version->contentObjectAttributes();

        // find ant set 'name' and 'description' attributes (as standard user group class)
        $nameIdentifier = 'name';
        $descIdentifier = 'description';
        $nameContentAttribute = null;
        $descContentAttribute = null;
        
				foreach( $contentObjectAttributes as $attribute ) {
            if ( $attribute->attribute( 'contentclass_attribute_identifier' ) == 'name' ) {
							 $attribute->setAttribute( 'data_text', $groupName );
							 $attribute->store();
            }
        }
				
				$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID, 'version' => 1 ) );
				
				$newObject = eZContentObject::fetch( $contentObjectID );
				$node = $newObject->attribute('main_node');
				return $node;
				
			}
			
			return null;
		}
		
/*		
		private function saveImage( $sourceImage, &$contentObjectAttribute ) {
			$content =& $contentObjectAttribute->content();
			if ( is_object( $content ) ) {
				$content->initializeFromFile( $sourceImage );
				if ( $content->isStorageRequired() ) {
					$content->store($contentObjectAttribute);
				}
			}
		}
*/
	
}


?>
