<?php
$Module =& $Params['Module'];
$page =& $Params['page'];


include_once( 'lib/ezutils/classes/ezoperationhandler.php' ); // For publish
include_once( "lib/ezutils/classes/ezhttptool.php" );
require_once('extension/feide/lib/classes/nxcfeide.php');
			
			
$http = eZHTTPTool::instance();


$feide = nxcFeide::instance();

//print_r( $feide->getGroup('Test gruppe') );

//print_r($feide);
if( $feide->loginUser() ) {
	
	// Redirect user to page specified in feide.ini
	$feideIni = eZINI::instance( 'feide.ini' );
	$LoginRedirect = $feideIni->variable( "Feide", "LoginRedirect" );				
	
	return $Module->redirectTo( $LoginRedirect );
	
}
	
	
	
	
	
	
	
//print_r($feide);




/*
unset($_SESSION['SimpleSAMLphp_SESSION']);


die();
*/



//print("<pre>"); print_r($_SESSION); print("</pre>"); die();

/*
if(isset($_SESSION['SimpleSAMLphp_SESSION']) &&$_SESSION['SimpleSAMLphp_SESSION'] === null) {
	unset($_SESSION['SimpleSAMLphp_SESSION']);
}

if( isset($_SESSION['SimpleSAMLphp_SESSION'] ) && is_string($_SESSION['SimpleSAMLphp_SESSION']) ) {
//	print("Session var type: " . gettype( $_SESSION['SimpleSAMLphp_SESSION'] ) . "<br/>\n");
//	print("Session var: " . print_r( $_SESSION['SimpleSAMLphp_SESSION'], true ) . "<br/>\n");
	$_SESSION['SimpleSAMLphp_SESSION'] = unserialize( base64_decode($_SESSION['SimpleSAMLphp_SESSION']) );
	
}
*/

//print_r($_SESSION); die();














//eZExecution::cleanExit();

?>

