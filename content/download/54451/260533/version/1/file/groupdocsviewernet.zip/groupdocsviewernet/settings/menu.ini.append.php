<?php /*
[NavigationPart]
Part[groupdocsviewernetnavigationpart]=GD Viewer .NET
[TopAdminMenu]
Tabs[]=groupdocsviewernet
[Topmenu_groupdocsviewernet]
NavigationPartIdentifier=groupdocsviewernetnavigationpart
Name=Groupdocs Viewer for .NET
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsviewernet/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>