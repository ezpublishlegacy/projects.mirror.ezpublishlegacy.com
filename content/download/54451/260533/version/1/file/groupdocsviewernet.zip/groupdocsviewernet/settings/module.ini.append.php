<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsviewernet
ModuleList[]=groupdocsviewernet
*/ ?>