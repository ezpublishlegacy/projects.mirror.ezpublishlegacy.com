<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsviewernet

#[StylesheetSettings]
#BackendCSSFileList[]=gdviewernet_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdviewernet.js
*/ ?>