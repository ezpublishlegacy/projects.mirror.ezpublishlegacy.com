<?php /*
[ModuleSettings]
ExtensionRepositories[]=ntags
ModuleList[]=ntags
*/
?>
