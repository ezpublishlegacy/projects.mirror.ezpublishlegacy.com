<?php /* 
[NavigationPart]
Part[ntags]=Tags

[TopAdminMenu]
Tabs[]=ntags

[Topmenu_ntags]
Name=Tags
NavigationPartIdentifier=ntags
URL[]
URL[default]=ntags/taglist
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true
*/ ?>
