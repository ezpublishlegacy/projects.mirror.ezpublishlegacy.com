<?php /*

[ClassesExport]
GroupBlackListID[]
# blacklist group "Setup"
GroupBlackListID[]=4

ClassBlackListID[]
# blacklist class "User group"
ClassBlackListID[]=3

*/ ?>
