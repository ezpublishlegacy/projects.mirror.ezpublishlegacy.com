<!DOCTYPE TS><TS>
<context>
    <name>accesskeys/overview</name>
    <message>
        <source>Access Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Access Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
