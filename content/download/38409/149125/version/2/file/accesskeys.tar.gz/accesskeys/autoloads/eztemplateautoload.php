<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/accesskeys/autoloads/accesskeysoperators.php',
                                    'class' => 'AccessKeysOperators',
                                    'operator_names' => array( 'ak_skip', 'ak_list', 'ak_skip_target' ) );

?>
