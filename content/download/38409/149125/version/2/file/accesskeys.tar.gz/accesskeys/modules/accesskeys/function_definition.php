<?php

$FunctionList = array();

$FunctionList['in_plan'] = array(
    'name' => 'in_plan',
    'operation_types' => array( 'read' ),
    'call_method' => array( 
        'include_file' => 'extension/planyourday/classes/pyditem.php',
        'class' => 'PYDItem',
        'method' => 'inPlan' 
    ),
    'parameter_type' => 'standard',
    'parameters' => array(
        array( 
            'name' => 'userID',
            'type' => 'integer',
            'required' => true
        ),
        array(
            'name' => 'eventID',
            'type' => 'integer',
            'required' => true
        )
    )
);
$FunctionList['check_conflict'] = array(
    'name' => 'check_conflict',
    'operation_types' => array( 'read' ),
    'call_method' => array(
        'include_file' => 'extension/planyourday/classes/pyditem.php',
        'class' => 'PYDItem',
        'method' => 'checkConflict'
    ),
    'parameter_type' => 'standard',
    'parameters' => array(
        array(
            'name' => 'userID',
            'type' => 'integer',
            'required' => true
        ),
        array(
            'name' => 'eventID',
            'type' => 'integer',
            'required' => true
        )
    )
);

?>
