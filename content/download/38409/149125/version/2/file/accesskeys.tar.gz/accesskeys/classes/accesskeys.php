<?php

class accessKeys
{
  var $attributes = array();

  function accessKeys( )
  {
  }

  /* Returns an array containing the INI entries */
  static function listKeys( )
  {
    $list = false;
    $ini = eZINI::instance( 'accesskeys.ini.append.php' );
    $iniEntries = $ini->variable( 'AccessKeySettings', 'Keys' );
    foreach( $iniEntries as $thisIniEntry ) {
      $akListData = explode( ';', $thisIniEntry );
      if( count( $akListData ) == 3 ) {
        $list[] = array( 'accesskey' => $akListData[0],
                         'href' => $akListData[1],
                         'text' => $akListData[2] );
      }
    }
    return $list;
  }
}

?>
