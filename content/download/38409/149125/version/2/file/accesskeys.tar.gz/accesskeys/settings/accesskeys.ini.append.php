<?php /* #?ini charset="utf-8"?

[AccessKeySettings]
SkipToContentText=Skip to main content
Keys[]=0;/accesskeys;Access Key Listing
Keys[]=1;/;Home
Keys[]=3;/Exhibiting;Exhibiting
*/ ?>
