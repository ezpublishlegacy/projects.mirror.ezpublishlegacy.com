<?php

$Module = array( 'name' => 'Access Keys' );

$ViewList = array();

$ViewList[''] = array( "default_navigation_part" => "ezcontentnavigationpart",
    "functions" => array( 'view' ),
    "script" => "overview.php",
    "single_post_actions" => array( "AKOverview" => "Overview" ),
);

$FunctionList['view'] = array();

?>
