<?php

class AccessKeysOperators
{
    function AccessKeysOperators()
    {
        $this->Operators = array( 'ak_skip', 'ak_list', 'ak_skip_target');
        $this->Debug = false;
    }

    function operatorList()
    {
        return $this->Operators;
    }

    function namedParameterPerOperator()
    {
        return true;
    }

    function namedParameterList()
    {
        return false;
    }

    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
    {
        switch ( $operatorName )
        {
            case 'ak_skip':
            {
                $operatorValue = $this->ak_skip( );
            }
            break;
            case 'ak_list':
            {
                $operatorValue = $this->ak_list( );
            }
            break;
            case 'ak_skip_target':
            {
                $operatorValue = $this->ak_skip_target( );
            }
            break;
        }
    }

    function ak_skip()
    {
      $ini = eZINI::instance( 'accesskeys.ini.append.php' );
      $xmlParser = new eZXMLInputParser;
      $skipLabel = $ini->variable( 'AccessKeySettings', 'SkipToContentText' );
      $ret = '<div style="left: -550px; position: absolute;"><ul><li><a href="#skip-to-content" accesskey="s">'.$xmlParser->washText( $skipLabel ).'</a></li></ul></div>'."\n";
      return $ret;
    }

    function ak_skip_target()
    {
      $ret = '<a name="skip-to-content"></a>'."\n";
      return $ret;
    }

    function ak_list()
    {
      $xmlParser = new eZXMLInputParser;
      $accessKeyList = accessKeys::listKeys();
      if( count( $accessKeyList ) > 0 ) {
        $ret = '<div style="left: -550px; position: absolute;" id="accesskeylist"><ul>'."\n";
        foreach( $accessKeyList as $thisKey ) {
          eZURI::transformURI($thisKey['href']);
          $ret .= '<li><a href="'.$thisKey['href'].'" accesskey="'.$thisKey['accesskey'].'">'.$xmlParser->washText( $thisKey['text'] ).'</a></li>'."\n";
        }
        $ret .= '</ul></div>'."\n";
      } else {
        $ret = false;
      }
      return $ret;
    }
    /// \privatesection

    /// \return The class variable 'Operators' which contains an array of available operators names.
    var $Operators;

    /// \privatesection
    /// \return The class variable 'Debug' to false.
    var $Debug;

}

?>
