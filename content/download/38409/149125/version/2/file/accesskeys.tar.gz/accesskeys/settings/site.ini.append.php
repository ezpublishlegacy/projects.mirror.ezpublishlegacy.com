<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=accesskeys

[TemplateSettings]
ExtensionAutoloadPath[]=accesskeys

[RegionalSettings]
TranslationExtensions[]=accesskeys

 */ ?>
