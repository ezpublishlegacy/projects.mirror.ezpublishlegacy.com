<?php
include_once( 'lib/ezutils/classes/ezfunctionhandler.php' );
include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezini.php' );

$module = $Params['Module'];
$result = false;
$http = eZHTTPTool::instance();
$tpl = templateInit();
$tpl->setVariable( 'module_name', 'accesskeys' );

$accessKeys = accessKeys::listKeys();
$tpl->setVariable( 'accessKeys', $accessKeys );
$Result['content'] = $tpl->fetch( 'design:accesskeys/overview.tpl' );
?>
