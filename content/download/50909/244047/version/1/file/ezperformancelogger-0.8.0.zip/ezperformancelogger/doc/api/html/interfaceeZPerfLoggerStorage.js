var interfaceeZPerfLoggerStorage =
[
    [ "insertStats", "interfaceeZPerfLoggerStorage.html#a247517717be6fd843fd6b385a255acc2", null ]
];