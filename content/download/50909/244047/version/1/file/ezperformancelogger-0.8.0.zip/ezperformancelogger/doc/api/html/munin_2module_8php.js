var munin_2module_8php =
[
    [ "$FunctionList", "munin_2module_8php.html#a81d0c7ad3471ab93425a3cdf655a9c95", null ],
    [ "$Module", "munin_2module_8php.html#a643d60fb839b5d58f0725a88d0ecd1a0", null ],
    [ "$ViewList", "munin_2module_8php.html#a8e0c26fc38651904852a8f967a548fa2", null ],
    [ "$ViewList", "munin_2module_8php.html#a3f7f69715b8c6668dfa2c532c28449bb", null ]
];