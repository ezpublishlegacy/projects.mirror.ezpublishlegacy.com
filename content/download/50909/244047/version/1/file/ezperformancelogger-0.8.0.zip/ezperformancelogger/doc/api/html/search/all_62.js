var searchData=
[
  ['big_5fendian',['BIG_ENDIAN',['../classprtbfr.html#a2c19b8b70c45d21ac5306aba429f701d',1,'prtbfr']]]
];
