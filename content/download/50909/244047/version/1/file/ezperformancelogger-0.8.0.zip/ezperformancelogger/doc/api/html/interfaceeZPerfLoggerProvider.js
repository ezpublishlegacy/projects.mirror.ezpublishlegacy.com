var interfaceeZPerfLoggerProvider =
[
    [ "measure", "interfaceeZPerfLoggerProvider.html#abf356d4c6d82eb55e228bc1d60e6ba74", null ],
    [ "supportedVariables", "interfaceeZPerfLoggerProvider.html#af7568c735c38b489f291fb28fe87a33b", null ]
];