var classeZPerfLoggerPinbaLogger =
[
    [ "_timer_get_info", "classeZPerfLoggerPinbaLogger.html#a0b973865bf73ca925ba4a9698fb29ac3", null ],
    [ "doLog", "classeZPerfLoggerPinbaLogger.html#aa6c39a7783bde7b86d5c1f0f033101a8", null ],
    [ "flush", "classeZPerfLoggerPinbaLogger.html#acb44234be33429023fadd4cbb28d4c2f", null ],
    [ "supportedLogMethods", "classeZPerfLoggerPinbaLogger.html#aef54f058d43b85cc6da31ed00a9fa98c", null ]
];