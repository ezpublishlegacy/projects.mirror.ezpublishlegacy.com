var searchData=
[
  ['sample_5fconfig_2ephp',['sample_config.php',['../sample__config_8php.html',1,'']]],
  ['save_5frun',['save_run',['../interfaceiXHProfRuns.html#a6969d83c3181c70ba05def354414147d',1,'iXHProfRuns\save_run()'],['../classXHProfRuns__Default.html#ae91af6dac754e6f7758afdd1d17ec9fd',1,'XHProfRuns_Default\save_run()']]],
  ['savedruns',['savedRuns',['../classeZXHProfLogger.html#a74de477561e817af21fe558a1b85c42a',1,'eZXHProfLogger']]],
  ['script_5fname_5fset',['script_name_set',['../classpinba.html#a86a5033fe8c43a9b6adb1f4e906e19d6',1,'pinba']]],
  ['setoptions',['setOptions',['../classeZPerfLoggerUrlExtractorStorage.html#acdf68c56b7f6ff14360cd495cdeb7714',1,'eZPerfLoggerUrlExtractorStorage']]],
  ['sfixed32_5fencode',['sfixed32_encode',['../classprtbfr.html#a70d6c3de30c3b84311a6bb109c918a0c',1,'prtbfr']]],
  ['sfixed64_5fencode',['sfixed64_encode',['../classprtbfr.html#a93246e227dfe15ab61b6047f6aa96091',1,'prtbfr']]],
  ['shouldlog',['shouldLog',['../interfaceeZPerfLoggerFilter.html#a1b3a98c6d27c31b37506a1a8cfcfa2c1',1,'eZPerfLoggerFilter']]],
  ['sort_5fcbk',['sort_cbk',['../xhprof_8php.html#ad597b83d7fc11ca129078baef0ac26eb',1,'xhprof.php']]],
  ['start',['start',['../classeZXHProfLogger.html#a8594f99222ba56d9c3a7498af48016dd',1,'eZXHProfLogger']]],
  ['stat_5fdescription',['stat_description',['../xhprof_8php.html#ac08d0b3dd7891ffed272a2eb33870518',1,'xhprof.php']]],
  ['stop',['stop',['../classeZXHProfLogger.html#acffa25e73c9ff4b031474586600ff6d4',1,'eZXHProfLogger']]],
  ['supportedlogmethods',['supportedLogMethods',['../classeZPerfLogger.html#aaaed99b2dd3d38bae70686b306081a53',1,'eZPerfLogger\supportedLogMethods()'],['../classeZPerfLoggerPinbaLogger.html#aef54f058d43b85cc6da31ed00a9fa98c',1,'eZPerfLoggerPinbaLogger\supportedLogMethods()'],['../interfaceeZPerfLoggerLogger.html#aecf6f4402d8a624f014b885b01e7966c',1,'eZPerfLoggerLogger\supportedLogMethods()']]],
  ['supportedvariables',['supportedVariables',['../classeZPerfLogger.html#a95d6d223735bca1f0f68ce754451ee30',1,'eZPerfLogger\supportedVariables()'],['../classezPerfLoggerEventListener.html#ad95dcf15014d9fa24a2d2d4bf89408f4',1,'ezPerfLoggerEventListener\supportedVariables()'],['../interfaceeZPerfLoggerProvider.html#af7568c735c38b489f291fb28fe87a33b',1,'eZPerfLoggerProvider\supportedVariables()']]],
  ['symbol_5freport',['symbol_report',['../xhprof_8php.html#abd3cec4a7ca1efc73e9e64313118bdaa',1,'xhprof.php']]]
];
