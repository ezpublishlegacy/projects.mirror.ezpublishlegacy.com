var callgraph__utils_8php =
[
    [ "xhprof_generate_dot_script", "callgraph__utils_8php.html#a25fd418619454848d10e539f40360090", null ],
    [ "xhprof_generate_image_by_dot", "callgraph__utils_8php.html#a1523d7ecf0fa4bebe7dd05689b548f2e", null ],
    [ "xhprof_generate_mime_header", "callgraph__utils_8php.html#ab21e0c4e2f01b578379f3f748744a184", null ],
    [ "xhprof_get_children_table", "callgraph__utils_8php.html#a9b384e135af6a4db17dcb04e3a92dd63", null ],
    [ "xhprof_get_content_by_run", "callgraph__utils_8php.html#ae8be90e2e451379599c45e944c63f8d9", null ],
    [ "xhprof_http_header", "callgraph__utils_8php.html#a1c89f8fdbd1b26d078f1c86f3175dfe3", null ],
    [ "xhprof_render_diff_image", "callgraph__utils_8php.html#af8a80089130d9c3ee56b895edcb05811", null ],
    [ "xhprof_render_image", "callgraph__utils_8php.html#a5f5acb9dd5cd44bd9bbb82c9e864ae79", null ],
    [ "$xhprof_legal_image_types", "callgraph__utils_8php.html#a244fef77b4864b6a145427435d5bd351", null ]
];