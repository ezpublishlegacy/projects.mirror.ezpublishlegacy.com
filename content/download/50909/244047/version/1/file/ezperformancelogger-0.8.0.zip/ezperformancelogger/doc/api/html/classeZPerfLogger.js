var classeZPerfLogger =
[
    [ "accumulatorStart", "classeZPerfLogger.html#adbe24dc01eb70191f48ea3d7842ae85a", null ],
    [ "accumulatorStop", "classeZPerfLogger.html#aa8a3bfe742277b9d1d42fdfc764c0af1", null ],
    [ "cleanup", "classeZPerfLogger.html#a1895c94fe4903b5c166d8a2093c98990", null ],
    [ "doLog", "classeZPerfLogger.html#a2b9b127ffb0489543cbd02059183fa0e", null ],
    [ "filter", "classeZPerfLogger.html#ac1709f4338f17af91eaf86b6dc021c5d", null ],
    [ "getValues", "classeZPerfLogger.html#a05955980f33ce85cfa42653179285152", null ],
    [ "isEnabled", "classeZPerfLogger.html#a4df6d5523d873d7520c87537bb3a7703", null ],
    [ "logIfNeeded", "classeZPerfLogger.html#a3340dfeacf5b8719580eabfcc8f8a836", null ],
    [ "measure", "classeZPerfLogger.html#a3952ebdfeda2fd81492a54bfbdea6bfc", null ],
    [ "preoutput", "classeZPerfLogger.html#ad99113cee6bc9281bad13694d114aeab", null ],
    [ "recordValue", "classeZPerfLogger.html#a26375ce3a77d6cbdafb106c351aa6961", null ],
    [ "recordValues", "classeZPerfLogger.html#a92b03d3bcc1a3f94d55a7b3d59b60119", null ],
    [ "supportedLogMethods", "classeZPerfLogger.html#aaaed99b2dd3d38bae70686b306081a53", null ],
    [ "supportedVariables", "classeZPerfLogger.html#a95d6d223735bca1f0f68ce754451ee30", null ],
    [ "TimeAccumulatorList", "classeZPerfLogger.html#aa2955eadebd2d449444adb4b1eb4a3f3", null ],
    [ "$custom_variables", "classeZPerfLogger.html#a0c79904ce0043c976652c698f0e635df", null ],
    [ "$has_run", "classeZPerfLogger.html#a18ef708664f5e2cf4aabb47833ccbfad", null ],
    [ "$outputSize", "classeZPerfLogger.html#a8ad2257e3c367ffdb3b0767fcb36edbb", null ],
    [ "$timeAccumulatorList", "classeZPerfLogger.html#aa836dbec07449c94808548704c0378a6", null ]
];