var dir_b7f5aec8f75fc8e6def8752bca865c24 =
[
    [ "callgraph_utils.php", "callgraph__utils_8php.html", "callgraph__utils_8php" ],
    [ "xhprof_lib.php", "xhprof__lib_8php.html", "xhprof__lib_8php" ],
    [ "xhprof_runs.php", "xhprof__runs_8php.html", [
      [ "iXHProfRuns", "interfaceiXHProfRuns.html", "interfaceiXHProfRuns" ],
      [ "XHProfRuns_Default", "classXHProfRuns__Default.html", "classXHProfRuns__Default" ]
    ] ]
];