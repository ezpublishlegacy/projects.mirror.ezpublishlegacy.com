var interfaceiXHProfRuns =
[
    [ "get_run", "interfaceiXHProfRuns.html#a18cf4b6e2152e2139f0542be06d16283", null ],
    [ "save_run", "interfaceiXHProfRuns.html#a6969d83c3181c70ba05def354414147d", null ]
];