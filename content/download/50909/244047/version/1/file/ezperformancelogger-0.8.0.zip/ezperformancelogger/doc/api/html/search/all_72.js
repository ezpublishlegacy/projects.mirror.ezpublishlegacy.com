var searchData=
[
  ['readupdatetoken',['readUpdateToken',['../classeZPerfLoggerLogManager.html#a1e6a56dab729e776b52534cbd3beebf7',1,'eZPerfLoggerLogManager']]],
  ['recordcontentcache',['recordContentCache',['../classezPerfLoggerEventListener.html#a3661b6ffd28339e074d715d0b71ac6f3',1,'ezPerfLoggerEventListener']]],
  ['recordevent',['recordEvent',['../classezPerfLoggerEventListener.html#af9b16975f0e6f717e8418b9da5b3e6e8',1,'ezPerfLoggerEventListener']]],
  ['recordimagealias',['recordImageAlias',['../classezPerfLoggerEventListener.html#a1b376de7d80c2b64baa486b2f51baf62',1,'ezPerfLoggerEventListener']]],
  ['recordvalue',['recordValue',['../classeZPerfLogger.html#a26375ce3a77d6cbdafb106c351aa6961',1,'eZPerfLogger']]],
  ['recordvalues',['recordValues',['../classeZPerfLogger.html#a92b03d3bcc1a3f94d55a7b3d59b60119',1,'eZPerfLogger']]],
  ['removesavedruns',['removeSavedRuns',['../classeZXHProfLogger.html#ad93053d75df80d41f14557bee9e97c37',1,'eZXHProfLogger']]],
  ['removexhprofdata_2ephp',['removexhprofdata.php',['../removexhprofdata_8php.html',1,'']]],
  ['resetstats',['resetStats',['../classeZPerfLoggerMemStorage.html#a4fdcf5f71805f49bc2435e121076f145',1,'eZPerfLoggerMemStorage\resetStats()'],['../classeZPerfLoggerUrlExtractorStorage.html#a442cd0971048e205bad184f8d58ee5ee',1,'eZPerfLoggerUrlExtractorStorage\resetStats()']]],
  ['rotatelogs',['rotateLogs',['../classeZPerfLoggerLogManager.html#a0c50398684e016a9554cf4b9c776da0a',1,'eZPerfLoggerLogManager']]],
  ['rotateperflogs_2ephp',['rotateperflogs.php',['../cronjobs_2rotateperflogs_8php.html',1,'']]],
  ['rotateperflogs_2ephp',['rotateperflogs.php',['../bin_2php_2rotateperflogs_8php.html',1,'']]],
  ['runs',['runs',['../classeZXHProfLogger.html#a9fb17d2010fa0b9ea638cd15aefc53e2',1,'eZXHProfLogger']]]
];
