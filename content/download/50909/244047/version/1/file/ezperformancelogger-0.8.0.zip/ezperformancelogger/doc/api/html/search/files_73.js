var searchData=
[
  ['sample_5fconfig_2ephp',['sample_config.php',['../sample__config_8php.html',1,'']]]
];
