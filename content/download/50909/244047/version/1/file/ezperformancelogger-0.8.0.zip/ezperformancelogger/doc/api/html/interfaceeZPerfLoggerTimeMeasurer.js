var interfaceeZPerfLoggerTimeMeasurer =
[
    [ "accumulatorStart", "interfaceeZPerfLoggerTimeMeasurer.html#aad4517afc75f50753407f829bd7e4676", null ],
    [ "accumulatorStop", "interfaceeZPerfLoggerTimeMeasurer.html#af367ee4fcdf0f6604460ec180808ee3e", null ],
    [ "TimeAccumulatorList", "interfaceeZPerfLoggerTimeMeasurer.html#aa238ab481c63723752e435f17cde1409", null ]
];