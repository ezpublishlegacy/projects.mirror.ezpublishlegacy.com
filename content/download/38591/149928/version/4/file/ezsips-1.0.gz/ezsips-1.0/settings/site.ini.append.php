[ExtensionSettings]
ActiveExtensions[]
ActiveExtensions[]=ezsips

[RoleSettings]
PolicyOmitList[]=ezsips/autoresponse
