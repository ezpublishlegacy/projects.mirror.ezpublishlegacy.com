<?php

// Include libs
include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');

// Needed for activateOrder function
include_once('kernel/shop/ezshopoperationcollection.php');
include_once('kernel/classes/ezbasket.php');

class eZSipsChecker extends eZPaymentCallbackChecker
{
	/*!
	    Constructor.
	*/
	function eZSipsChecker()
	{
		$this->eZPaymentCallbackChecker('ezsips.ini');

		// Load vars
		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");

		$this->logger =& eZPaymentLogger::CreateForAdd($iniVarDir."/log/eZSipsGateway.log");
		$this->logger->writeTimedString('eZSipsChecker::eZSipsChecker()');
	}

	/*!
	    Parses 'POST' response and create array with received data.
	*/
	function createDataFromPOST()
	{
		//__DEBUG__
		$this->logger->writeTimedString('eZSips : createDataFromPOST');
		//___end____

		eZSys::removeMagicQuotes();

		// Where is the cgi
		$response_cgi = $this->ini->variable('eZSipsSettings', 'response_cgi');
		$pathfile = $this->ini->variable('eZSipsSettings', 'pathfile');

		// Recuperation des datas crypted in DATA
		if($_POST)
		{
			$params  =" message=".$_POST['DATA'];
			$params .= " pathfile=".$pathfile;

			$result = exec("$response_cgi $params");

			// Put cgi output in array
			$tableau = explode("!", $result);

			// List each value
			$this->checkerData = array();
			$this->checkerData['code'] = $tableau[1];
			$this->checkerData['error'] = $tableau[2];
			$this->checkerData['merchant_id'] = $tableau[3];
			$this->checkerData['merchant_country'] = $tableau[4];
			$this->checkerData['amount'] = ($tableau[5])/100;
			$this->checkerData['transaction_id'] = $tableau[6];
			$this->checkerData['payment_means'] = $tableau[7];
			$this->checkerData['transmission_date'] = $tableau[8];
			$this->checkerData['payment_time'] = $tableau[9];
			$this->checkerData['payment_date'] = $tableau[10];
			$this->checkerData['response_code'] = $tableau[11];
			$this->checkerData['payment_certificate'] = $tableau[12];
			$this->checkerData['authorisation_id'] = $tableau[13];
			$this->checkerData['currency_code'] = $tableau[14];
			$this->checkerData['card_number'] = $tableau[15];
			$this->checkerData['cvv_flag'] = $tableau[16];
			$this->checkerData['cvv_response_code'] = $tableau[17];
			$this->checkerData['bank_response_code'] = $tableau[18];
			$this->checkerData['complementary_code'] = $tableau[19];
			$this->checkerData['complementary_info'] = $tableau[20];
			$this->checkerData['return_context'] = $tableau[21];
			$this->checkerData['caddie'] = $tableau[22];
			$this->checkerData['receipt_complement'] = $tableau[23];
			$this->checkerData['merchant_language'] = $tableau[24];
			$this->checkerData['language'] = $tableau[25];
			$this->checkerData['customer_id'] = $tableau[26];
			$this->checkerData['order_id'] = $tableau[27];
			$this->checkerData['customer_email'] = $tableau[28];
			$this->checkerData['customer_ip_address'] = $tableau[29];
			$this->checkerData['capture_day'] = $tableau[30];
			$this->checkerData['capture_mode'] = $tableau[31];
			$this->checkerData['data'] = $tableau[32];

			// Error in cgi call
			if($this->checkerData['code'] == "" && $this->checkerData['error'] == "")
			{
				$this->logger->writeTimedString('eZSips : CGI not found !');

				return false;
			}
			// Error : Display message
			elseif($this->checkerData['code'] != 0)
			{
				$this->logger->writeTimedString("eZSips : Error : $error !");

				return false;
			}
			// Ok so record order
			else
			{
				// Payment is accepted
				if($this->checkerData['response_code'] != "00")
				{
					// Log something
					$this->logger->writeTimedString("eZSips : Mercanet response problem #".$this->checkerData['response_code']);

					return false;
				}
				else
				{
					// Log something
					$this->logger->writeTimedString("eZSips : Payment accepted");

					return true;
				}
			}
		}
		else
		{
			return false;
		}
	}

	/*!
	    Parses 'POST' response and create array with received data.
	*/
	function ajustStock($order)
	{
		//__DEBUG__
		$this->logger->writeTimedString('eZSips : Ajust Stock');
		//___end____

		$productCollection = $order->productCollection();

		$orderedItems = $productCollection->itemList();

		// List order products
		foreach ($orderedItems as $item)
		{
			$contentObject = $item->contentObject();

			$contentObjectVersion =& $contentObject->version($contentObject->attribute('current_version'));
			$contentObjectAttributes =& $contentObjectVersion->contentObjectAttributes();

			// List attributes
			foreach (array_keys($contentObjectAttributes) as $key)
			{
				$contentObjectAttribute =& $contentObjectAttributes[$key];
				$contentClassAttribute =& $contentObjectAttribute->contentClassAttribute();
				$attributeIdentifier = $contentClassAttribute->attribute("identifier");

				// Each attribute has an attribute identifier called 'quantity' that identifies it.
				if ($attributeIdentifier == "quantite")
				{
					$newQuantite = $contentObjectAttribute->attribute("value") - $item->ItemCount;

					$contentObjectAttribute->fromString($newQuantite);
					$contentObjectAttribute->store();
				}
			}
		}
	}

	/*!
	    Convinces of completion of the payment.
	*/
	function &handleResponse()
	{
		//__DEBUG__
		$this->logger->writeTimedString("eZSips : handleResponse");
		//___end____

		// If data was posted to shop/checkout then change state
		if($this->createDataFromPOST())
		{
			// Retrieve received datas for validation
			$orderID = $this->checkerData['order_id'];
			//$orderID = 113;
			$sessionID = $this->checkerData['return_context'];
			//$sessionID = '0ccbcf5e316db91833861e3ed3fbac9f';

			// Get order
			$order =& eZOrder::fetch($orderID);

			// Not accepeted so accept it and ajust stocks
			if($order->attribute("is_temporary"))
			{
				// Will activate order but doesnt clean basket as it should
				//eZShopOperationCollection::activateOrder($orderID);

				// Fetch basket with session_id
				$basket = eZBasket::fetch($sessionID);

				// If there is a basket with this sessionID then activate order and remove basket
				if($basket) $basket->remove();

				// Validate order
				$order->activate();

				// Ajust stock
				//$this->ajustStock($order);

				// Payment infos
				$transactionID = $this->checkerData['transaction_id'];
				$authorisationID = $this->checkerData['authorisation_id'];
				$paymentCertificate = $this->checkerData['payment_certificate'];

				// String that will be registered
				$paymentInfos  = "Transaction ID : ".$transactionID;
				$paymentInfos .= " - Authorisation ID : ".$authorisationID;
				$paymentInfos .= " - Certificat de paiement : ".$paymentCertificate;

				// Record Payment infos
				$order->setAttribute('data_text_1', $paymentInfos);
				$order->store();
			}

			return true;
		}

		return false;
	}
}

?>
