[eZSipsSettings]

# Demo ID (CHANGE IT TO PRODUCTION ID WHEN NEEDED)
#merchant_id=082584341411111

pathfile=extension/ezsips/lib/param/pathfile

request_cgi=extension/ezsips/lib/bin/request
response_cgi=extension/ezsips/lib/bin/response
