<?php

// Simple include once
ext_activate('ezsips','classes/ezsipschecker.php');

// Start checker
$checker =& new eZSipsChecker();

// Checks & Approve | Reject
$checker->handleResponse();

?>
