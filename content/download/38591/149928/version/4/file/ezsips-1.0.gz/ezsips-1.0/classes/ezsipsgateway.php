<?php

// Activate validation function to register
ext_activate('ezsips','classes/ezsipschecker.php');

include_once('kernel/shop/classes/ezpaymentgateway.php');

// Define different variables
define("EZ_PAYMENT_GATEWAY_TYPE_EZSIPS", "eZSips");

define("EZ_PAYMENT_GATEWAY_NOT_ACCEPTED", 1);
define("EZ_PAYMENT_GATEWAY_ACCEPTED", 2);


class eZSipsGateway extends eZPaymentGateway
{
	/*!
	 Constructor.
	*/
	function eZSipsGateway()
	{
		// Load ini
		$this->ini =& eZINI::instance('ezsips.ini');

		// Load var dir
		$ini = eZINI::instance("site.ini");
		$iniVarDir = $ini->variable("FileSettings", "VarDir");

		//__DEBUG__
		$this->logger = eZPaymentLogger::CreateForAdd($iniVarDir."/log/eZSipsGateway.log");
		$this->logger->writeTimedString('eZSipsGateway::eZSipsGateway()');
		//___end____
	}

	/*!
	    Creates new eZSipsGateway object.
	*/
	function execute(&$process, $event)
	{
		//__DEBUG__
		$this->logger->writeTimedString("eZSips : execute");
		//___end____

		// Must declare checker to handle a response to shop/checkout
		$checker =& new eZSipsChecker();

		// If data was posted to shop/checkout then change state
		if($checker->handleResponse())
		{
			// Put workflow in result mode
			$process->setAttribute('event_state', EZ_PAYMENT_GATEWAY_ACCEPTED);
		}

		// Switch between two state of workflow process
		switch ($process->attribute('event_state'))
		{
			// Load the request
			case EZ_PAYMENT_GATEWAY_NOT_ACCEPTED :
			{
				//__DEBUG__
				$this->logger->writeTimedString("eZSips : eZSips Request");
				//___end____

				return $this->handleRequest($process);
			}
			break;

			// This order has been treated
			case EZ_PAYMENT_GATEWAY_ACCEPTED :
			{
				return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
			}
			break;
		}
	}

	/*!
	    Handle request
	*/
	function handleRequest(&$process, $errors = 0)
	{
		// Get process params
		$processParams =& $process->attribute('parameter_list');
		$orderID = $processParams['order_id'];

		// Get order
		$order =& eZOrder::fetch($orderID);

		// Get total including tax
		$amount = str_replace(".","",sprintf("%01.2lf",$order->attribute('total_inc_vat')));

		// Request CGI
		$request_cgi = $this->ini->variable('eZSipsSettings', 'request_cgi');
		$pathfile = $this->ini->variable('eZSipsSettings', 'pathfile');

		// Session ID
		$session_id = eZHTTPTool::getSessionKey();

		// Make params appended to call
		$params  = "";
		$params .= " pathfile=".$pathfile;
		$params .= " merchant_id=".$this->ini->variable('eZSipsSettings', 'merchant_id');
		$params .= " merchant_country=fr";
		$params .= " currency_code=978";
		$params .= " amount=".$amount;
		$params .= " order_id=".$orderID;
		$params .= " return_context=".$session_id;

		// Execute de request with params
		$result = exec("$request_cgi $params");

		// List variables that exit from cgi call
		$tableau = explode("!",$result);

		$code = $tableau[1];
		$error = $tableau[2];
		$message = $tableau[3];

		// Analyse code
		$sips = ($code == -1) ? "Erreur API SIPS : $error\n" : eregi_replace("<br>","",$message);

		// Assign template & vars
		$process->Template = array('templateName' => 'design:request.tpl',
					   'templateVars' => array('page_title' => 'Choisissez votre carte de paiement',
								   'SIPS' => $sips,
								 ),
					 );

		// Return the workflow status - I don't know why
		return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
	}
}

eZPaymentGatewayType::registerGateway(EZ_PAYMENT_GATEWAY_TYPE_EZSIPS, "ezsipsgateway", "eZSips");

?>
