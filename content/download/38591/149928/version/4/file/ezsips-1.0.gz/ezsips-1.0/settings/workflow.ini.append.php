[EventSettings]
ExtensionDirectories[]=ezsips
AvailableEventTypes[]=event_ezsips
