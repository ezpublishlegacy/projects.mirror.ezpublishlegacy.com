<?php include 'templates/head.php'; ?>
<form action="gallery.php?action=add&album=<?php echo $template['album']->id ?>" enctype="multipart/form-data" method="POST">
<table width="400">
 <tr>
  <td align="right">
   Title:
  </td>
  <td align="left">
   <input type="text" name="title" />
  </td>
 </tr>
 <tr>
  <td align="right">
   Description:
  </td>
  <td align="left">
   <input type="text" name="description" />
  </td>
 </tr>
 <tr>
  <td align="right">
   Photo:
  </td>
  <td align="left">
   <input type="file" name="photo" accept="image/*" />
  </td>
 </tr>
 <tr>
  <td colspan="2" align="center">
   <input type="submit" value="Add!" />
  </td>
 </tr>
</table>
</form>
<?php include 'templates/foot.php'; ?>
