<?php

require_once 'PEAR/PackageFileManager2.php';

$packagedir = dirname(__FILE__);

$version = '1.0';

$summary = 'An example application to show eZ components.';

$description = <<<EOT
This application shows how to use eZ components. It is a very basic image 
gallery script, that makes use of eZ components Database, PersistenObject, 
ImageConversion and UserInput.
EOT;
    
$notes = <<<EOT
Initial release.
EOT;

$p2 = new PEAR_PackageFileManager2();
$p2->setOptions(
    array(
        'baseinstalldir'    => '/ezc/Applications/Gallery',
        'filelistgenerator' => 'file',
        'packagedirectory'  => $packagedir,
        'ignore'            => array(
            'generate_package_xml.php',
            'package.xml',
        ),
        'exceptions'        => array(
            'README'        => 'doc',
        ),
        'simpleoutput'      => true,
    )
);

$p2->setPackage('appGallery');
$p2->setSummary($summary);
$p2->setDescription($description);
$p2->setChannel('components.ez.no');

$p2->setPackageType('php');

$p2->addReplacement('setup.php', 'pear-config', '@php_dir@', 'php_dir');

$postInstall = $p2->initPostinstallScript('setup.php');

$postInstall->addParamGroup(
    'database',
    array( 
        $postInstall->getParam('dbHost', 'Database host', 'string', 'localhost'),
        $postInstall->getParam('dbName', 'Database name'),
        $postInstall->getParam('dbUser', 'Database user'),
        $postInstall->getParam('dbPass', 'Database password', 'string', '<none>'),
    ),
    'Database settings'
);

$postInstall->addParamGroup(
    'webroot',
    array( 
        $postInstall->getParam('webroot', 'Webroot directory'),
    ),
    'Webroot settings'
);

$p2->addPostInstallTask($postInstall, 'setup.php');

$p2->generateContents();

$p2->setReleaseVersion($version);
$p2->setAPIVersion('1.0');
$p2->setReleaseStability('stable');
$p2->setAPIStability('stable');

$p2->setNotes($notes);

$p2->addMaintainer('lead', 'toby', 'Tobias Schlitt', 'toby@php.net');

$p2->setPhpDep('5.1.0');
$p2->setPearinstallerDep('1.4.0');

$p2->setLicense('New BSD License', 'http://ez.no/licenses/new_bsd');

$p2->addPackageDepWithChannel('required', 'eZComponents', 'components.ez.no', '1.0');


if (isset($_GET['make']) || (isset($_SERVER['argv']) && @$_SERVER['argv'][1] == 'make')) {
    echo "Writing package file\n";
    $p2->writePackageFile();
} else {
    echo "Debugging package file\n";
    $p2->debugPackageFile();
}
?>
