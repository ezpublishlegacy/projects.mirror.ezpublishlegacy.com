<?php
/**
 * Post install script for the eZ components gallery example.
 *
 * @category   Applications
 * @package    Gallery
 * @author     Tobias Schlitt <ts@ez.no>
 * @copyright Copyright (C) 2005, 2006 eZ systems as. All rights reserved.
 * @license http://ez.no/licenses/new_bsd New BSD License
 * @version    CVS: $Id$
 * @link       http://ez.no/products/ez_components
 */

/**
 * Post install script class.
 * Remember, that this class name has to end with "postinstall" and it has
 * to implement the init() and run() methods, because they are called from the
 * Installer to issue the post install script.
 * 
 * @category   Applications
 * @package    Gallery
 * @author     Tobias Schlitt <ts@ez.no>
 * @copyright Copyright (C) 2005, 2006 eZ systems as. All rights reserved.
 * @license http://ez.no/licenses/new_bsd New BSD License
 * @version    1.0.0
 * @link       http://ez.no/products/ez_components
 */

define('ALBUM_TABLE_SQL', <<<EOT
CREATE TABLE IF NOT EXISTS album (
  id int(11) unsigned NOT NULL auto_increment,
  title varchar(200) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOT
);

define('PHOTO_TABLE_SQL', <<<EOT
CREATE TABLE IF NOT EXISTS photo (
  id int(11) unsigned NOT NULL auto_increment,
  album int(11) NOT NULL default '0',
  title varchar(200) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOT
);

define('CONFIG_TEMPLATE', <<<EOT
<?php
    define('CONFIG_DSN', '%s');
    define('CONFIG_PHP', '%s');
    ini_set('include_path', ini_get('include_path') . PATH_SEPARATOR . CONFIG_PHP);
?>
EOT
);

// {{{ __autoload()

require_once 'ezc/Base/base.php';

/**
 * Autoload ezc classes 
 * 
 * @param string $class_name 
 */
function __autoload( $class_name )
{
    if ( ezcBase::autoload( $class_name ) )
    {
        return;
    }
}

// }}}

class setup_postinstall 
{

    // {{{ $_config

    /**
     * PEAR_Config object 
     * 
     * @var object(PEAR_Config)
     * @access protected
     */
    private $_config;

    // }}}
    // {{{ $_ui

    /**
     * PEAR_Installer_Ui 
     * 
     * @var object(PEAR_Installer_Ui)
     * @access protected
     */
    private $_ui;

    // }}}

    // {{{ $_phpDir

    /**
     * Directory of PHP files. 
     * 
     * @var string
     * @access protected
     */
    private $_phpDir;

    // }}}
    // {{{ $_dsn

    /**
     * Data source name. 
     * 
     * @var string
     * @access protected
     */
    private $_dsn;

    // }}}

    // {{{ init()

    /**
     * Initialize this module.
     * Initialize PEAR environment objects. This method is called first from the Installer,
     * before the real post install process takes place. We do some initialization here.
     * 
     * @param object(PEAR_Config) $config The PEAR configuration object, you can get and set
     *                                    all PEAR Installer configuration values using this.
     * @link http://pear.php.net/package/PEAR/docs/1.4.4/PEAR/PEAR_Config.html
     *                                    
     * @param object(PEAR_PackageFile_v2) $self The parsed package.xml object, you can use 
     *                                          this one to access the values defined in your
     *                                          packaege.xml.
     * @link http://pear.php.net/package/PEAR/docs/1.4.4/PEAR/PEAR_PackageFile_v2.html
     * 
     * @param string $lastInstalledVersion The version number of your package, which is currently
     *                                     installed on the target system, or null, if this is the
     *                                     first time, your application is installed. We don't care
     *                                     about that in this example
     * @access public
     * @return bool True if initialized successfully, otherwise false.
     */
    function init(&$config, $self, $lastInstalledVersion = null)
    {
       $this->_config = &$config;
       
       // One should utilized the Ui of the Installer in preference of "echo" or similar,
       // because the Installer can also use different frontends, like 
       $this->_ui = &PEAR_Frontend::singleton();
       
       $this->_phpDir = '@php_dir@' . DIRECTORY_SEPARATOR . 'ezc' . DIRECTORY_SEPARATOR . 'Applications' . DIRECTORY_SEPARATOR . 'Gallery';
       
       return true;
    }

    // }}}
    // {{{ run()

    /**
     * Run the post installation process.
     * This method is called by the PEAR Installer each time, it has requested a set of data from the user,
     * meaning, after each <paramgroup> defined in the package.xml. On error, the PEAR Installer
     * calls this metod with "_undoOnError" as the $paramGroup value and has all information submitted so far
     * available in the $infoArray variable. In every other case the $paramGroup contains the name of the
     * performed <paramgroup> section and $infoArray contains the values selected from there.
     * 
     * @param array $infoArray The values entered by the user.
     * @param string $paramGroup The name of the parameter group we currently work on.
     * @access public
     * @return bool True if process went well, otherwise false to indicate that the process has to be repeated.
     */
    function run($infoArray, $paramGroup)
    {
        // Choose, which <paramgroup> is processed now
        switch ($paramGroup) {
        case '_undoOnError':
            // We just give a message, usually you should try to revert the changes
            // you already made in this place.
            $this->_ui->outputData('An error occured during installation.');
            return false;
        case 'database':
            // The database paramgroup is processed.
            return $this->setupDatabase($infoArray);
            break;
        case 'webroot':
            // The config paramgroup is processed.
            return $this->setupWebroot($infoArray);
            break;
        default:
            echo 'ERROR: Unknown parameter group <'.$paramGroup.'>.';
            return false;
        }
    }

    // }}}

    // {{{ setupDatabase()

    /**
     * Setup the database utilized by the ezcGallery.
     * 
     * @param array $infoArray The $infoArray passed over from the run() method.
     * @access public
     * @return bool True on sucess, otherwise false.
     */
    function setupDatabase($infoArray)
    {
        if ($infoArray['dbPass'] == '<none>') {
            $infoArray['dbPass'] = '';
        }
        // Grab DB settings from user values
        $this->_dsn = 'mysql://' . $infoArray['dbUser'] . ':' . $infoArray['dbPass'] . '@' . $infoArray['dbHost'] . '/' . $infoArray['dbName'];
        
        // Attempt to connect to the DB
        try {
            $db = ezcDbFactory::create($this->_dsn);
        } catch (PDOException $e) {
            // Found an error. Print out error message and return failure.
            $this->_ui->outputData('Error connecting to your database: <'.$e->getMessage().'>.');
            return false;
        }

        try {
            if ($db->exec(ALBUM_TABLE_SQL) === false) {
                $this->_ui->outputData('Error creating albums table.');
                return false;
            }
            if ($db->exec(PHOTO_TABLE_SQL) === false) {
                $this->_ui->outputData('Error creating albums table.');
                return false;
            }
        } catch (PDOException $e) {
            $this->_ui->outputData('Creating necessary tables failed: <'.$e->getMessage().'>.');
            return false;
        }

        // Indicate success for this param group
        return true;
    }

    // }}}
    // {{{ setupWebroot()

    /**
     * Insert configuration into database.
     * This method takes the configuration provided by the user and inserts it
     * into the Serendipity database.
     * 
     * @param array $infoArray The $infoArray passed over from the run() method.
     * @return void
     * @return bool True on sucess, otherwise false.
     */
    function setupWebroot($infoArray)
    {
        $webroot = $infoArray['webroot'];

        // Check / create webroot
        if (!is_dir($webroot)) {
            if (!mkdir($webroot)) {
                $this->_ui->outputData('Specified webroot diretory does not exist and could not be created.');
                return false;
            }
        }
        
        $webroot = realpath($webroot);
        $datadir = $webroot . DIRECTORY_SEPARATOR . 'data';
        
        if (
            copy(
                $this->_phpDir . DIRECTORY_SEPARATOR . 'gallery.php', 
                $webroot . DIRECTORY_SEPARATOR . 'gallery.php'
                ) === false
            ) {
            $this->_ui->outputData('Could not copy gallery main file to specified output directory.');
            return false;
        }

        $res = file_put_contents(
            $webroot . DIRECTORY_SEPARATOR . 'config.php',
            sprintf(CONFIG_TEMPLATE, $this->_dsn, $this->_phpDir)
        );
        if ($res === false) {
            $this->_ui->outputData('Could not write config file.');
            return false;
        }

        if (!is_dir($datadir) && !mkdir($datadir)) {
            $this->_ui->outputData('Could not create data dir.');
            return false;
        }

        if (chmod($datadir, 0777) === false) {
            $this->_ui->outputData('Could not change permissions on data dir.');
            return false;
        }

        return true;
    }

      // }}}

}

?>
