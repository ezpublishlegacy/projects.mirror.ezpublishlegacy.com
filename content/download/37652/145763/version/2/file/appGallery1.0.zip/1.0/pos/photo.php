<?php

$def = new ezcPersistentObjectDefinition();
$def->table = "photo";
$def->class = "Photo";

$def->idProperty = new ezcPersistentObjectIdProperty();
$def->idProperty->columnName = 'id';
$def->idProperty->propertyName = 'id';
$def->idProperty->generator = new ezcPersistentGeneratorDefinition(  'ezcPersistentSequenceGenerator' );

$def->properties['album'] = new ezcPersistentObjectProperty();
$def->properties['album']->columnName   = 'album';
$def->properties['album']->propertyName = 'album';
$def->properties['album']->propertyType = ezcPersistentObjectProperty::PHP_TYPE_INT;

$def->properties['title'] = new ezcPersistentObjectProperty();
$def->properties['title']->columnName   = 'title';
$def->properties['title']->propertyName = 'title';
$def->properties['title']->propertyType = ezcPersistentObjectProperty::PHP_TYPE_STRING;

$def->properties['description'] = new ezcPersistentObjectProperty();
$def->properties['description']->columnName   = 'description';
$def->properties['description']->propertyName = 'description';
$def->properties['description']->propertyType = 'string';

return $def;

?>
