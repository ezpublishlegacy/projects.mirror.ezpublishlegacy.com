<?php include 'templates/head.php'; ?>
<table width="600">
 <tr>
  <td>[<a href="gallery.php">Main</a>]</td>
  <td>[<a href="gallery.php?action=add&album=<?php echo $template['photo']->album; ?>">Add photo</a>]</td>
 </tr>
</table>
The following photo was uploaded:
<table width="400">
 <tr>
  <td align="right">
   Thumbnail:
  </td>
  <td align="left">
   <img src="data/<?php echo $template['photo']->id; ?>_thumb.jpg" border="0" />
  </td>
 </tr>
 <tr>
  <td align="right">
   Title:
  </td>
  <td align="left">
   <?php echo $template['photo']->title; ?>
  </td>
 </tr>
 <tr>
  <td align="right">
   Description:
  </td>
  <td align="left">
   <?php echo $template['photo']->description; ?>
  </td>
 </tr>
</table>
<?php include 'templates/foot.php'; ?>
