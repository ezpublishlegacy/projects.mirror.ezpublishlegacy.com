<?php

require_once 'ezc/Base/base.php';

function __autoload( $className )
{
    return ezcBase::autoload( $className );
}

require_once 'config.php';

class ezcGallery 
{

    private $actions = array( 
        'listing' => 'actions/listing.php',
        'show'    => 'actions/show.php',
        'create'  => 'actions/create.php',
        'add'     => 'actions/add.php',
    );
    
    private $currentAction;

    private static $persistentSession;
    private static $imageConverter;
    
    public function __construct()
    {
        $action = 'listing';
        if ( ezcInputForm::hasGetData() )
        {
            $definition = array( 
                'action' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'string'
                ),
            );
            $form = new ezcInputForm( INPUT_GET, $definition );
            $action = ( $form->hasValidData( 'action' ) ) ? $form->action : 'listing';
        }
        if ( !isset( $this->actions[$action] ) )
        {
            throw new Exception( "Invalid action <".htmlentities($action).">." );
        }

        require_once $this->actions[$action];
        $this->currentAction = new $action;
    }

    public function run()
    {
        $this->currentAction->run();
    }

    public function display()
    {
        $template = $this->currentAction->getTemplateVars();
        ob_start();
        $res = include 'templates/' . $this->currentAction->getTemplate();
        $html = ob_get_contents();
        ob_end_clean();
        if ( $res === false )
        {
            throw new Exception( 'Template error.' );
        }
        echo $html;
    }

    public static function getSession()
    {
        if ( !isset( self::$persistentSession ) )
        {
            $db = ezcDbFactory::create( CONFIG_DSN );
            ezcDbInstance::set( $db );
            
            self::$persistentSession = new ezcPersistentSession(
                ezcDbInstance::get(),
                new ezcPersistentCodeManager( CONFIG_PHP . DIRECTORY_SEPARATOR . 'pos' )
            );
        }
        return self::$persistentSession;
    }

    public static function getConverter()
    {
        if ( !isset( self::$imageConverter ) )
        {
            self::$imageConverter = new ezcImageConverter(
                new ezcImageConverterSettings(
                    array( 
                        new ezcImageHandlerSettings( 'imagemagick', 'ezcImageImagemagickHandler' ),
                        new ezcImageHandlerSettings( 'gd', 'ezcImageGdHandler' ),
                    )
                )
            );

            self::$imageConverter->createTransformation(
                'photo',
                array( 
                    new ezcImageFilter( 
                        'scale',
                        array( 
                            'width'     => 640,
                            'height'    => 480,
                            'direction' => ezcImageGeometryFilters::SCALE_DOWN,
                        )
                    ),
                ),
                array( 
                    'image/jpeg',
                )
            );
            
            self::$imageConverter->createTransformation(
                'thumb',
                array( 
                    new ezcImageFilter( 
                        'scale',
                        array( 
                            'width'     => 150,
                            'height'    => 113,
                            'direction' => ezcImageGeometryFilters::SCALE_DOWN,
                        )
                    ),
                    new ezcImageFilter( 
                        'border',
                        array( 
                            'width'     => 5,
                            'color'     => array(
                                255, 255, 255,
                            ),
                        )
                    ),
                    new ezcImageFilter( 
                        'colorspace',
                        array( 
                            'space'     => ezcImageColorspaceFilters::COLORSPACE_SEPIA,
                        )
                    ),
                    new ezcImageFilter( 
                        'border',
                        array( 
                            'width'     => 1,
                            'color'     => array(
                                0, 0, 0,
                            ),
                        )
                    ),
                ),
                array( 
                    'image/jpeg',
                )
            );
        }
        return self::$imageConverter;
    }

    
}


try
{
    $gallery = new ezcGallery();
    $gallery->run();
    $gallery->display();
}
catch ( Exception $e )
{
    die( $e->getMessage() );
}

?>
