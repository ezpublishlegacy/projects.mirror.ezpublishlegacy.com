<?php include 'templates/head.php'; ?>
<table width="600">
 <tr>
  <td>[<a href="gallery.php?action=create">Create album</a>]</td>
 </tr>
</table>
<ul>
<?php
    foreach ( $template['albums'] as $album )
    {
        ?>
        <li><a href="gallery.php?action=show&album=<?php echo $album->id; ?>"><?php echo $album->title; ?></a>(<?php echo $album->description; ?>)</li>
        <?php
    }
?>
</ul>
<?php include 'templates/foot.php'; ?>
