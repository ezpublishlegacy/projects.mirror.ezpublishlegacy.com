<?php

require_once 'interfaces/action.php';

require_once 'models/album.php';

class Listing implements Action
{

    private $albums;
    
    public function __construct()
    {
    }

    public function run()
    {
        $this->albums = ezcGallery::getSession()->find( 
            ezcGallery::getSession()->createFindQuery( 'Album' ),
            'Album'
        );
    }

    public function getTemplate()
    {
        return 'listing.php';
    }
    
    public function getTemplateVars()
    {
        return array( 'albums' => $this->albums );
    }
}

?>
