<?php

require_once 'interfaces/action.php';

require_once 'models/album.php';

class Create implements Action
{

    private $template = 'create_form.php';

    private $album;
    
    public function __construct()
    {
    }

    public function run()
    {
        if ( ezcInputForm::hasPostData() )
        {
            $definition = array( 
                'title' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'string'
                ),
                'description' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'string'
                ),
            );
            $form = new ezcInputForm( INPUT_POST, $definition );
            if ( !$form->hasValidData( 'title' ) )
            {
                throw new Exception( 'Title missing.' );
            }
            if ( !$form->hasValidData( 'description' ) )
            {
                throw new Exception( 'Desription missing.' );
            }

            $this->album = new Album();
            $this->album->title = $form->title;
            $this->album->description = $form->description;

            ezcGallery::getSession()->save( $this->album );

            $this->template = 'create_submit.php';
        }
        else
        {
            $this->template = 'create_form.php';
        }
    }

    public function getTemplate()
    {
        return $this->template;
    }
    
    public function getTemplateVars()
    {
        return array( 'album' => $this->album );
    }
}

?>
