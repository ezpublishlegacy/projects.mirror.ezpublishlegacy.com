<?php

class Album
{
    public $id = null;
    
    public $title = '';
    public $description = 'No description available.';

    public function getState()
    {
        return array( 
                'id'            => $this->id,
                'title'         => $this->title,
                'description'   => $this->description,
        );
    }

    public function setState( array $properties )
    {
        foreach ( $properties as $key => $val )
        {
            $this->$key = $val;
        }
    }
}

?>
