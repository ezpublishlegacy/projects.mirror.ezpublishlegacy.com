<?php

require_once 'interfaces/action.php';

require_once 'models/album.php';
require_once 'models/photo.php';

class Add implements Action
{

    private $template = 'create_form.php';

    private $album;

    private $photo;

    private $tmpData = array( 
        'photoPath' => '',
        'thumbPath' => '',
    );
    
    public function __construct()
    {
        if ( ezcInputForm::hasGetData() )
        {
            $definition = array( 
                'album' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'int'
                ),
            );
            $form = new ezcInputForm( INPUT_GET, $definition );
            if ( !$form->hasValidData( 'album' ) )
            {
                throw new Exception( 'Album ID missing.' );
            }
            $this->album = ezcGallery::getSession()->load( 'Album', $form->album );
        }
        else
        {
            throw new Exception( 'Album ID missing.' );
        }

    }

    public function run()
    {
        if ( ezcInputForm::hasPostData() )
        {
            $definition = array( 
                'title' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'string'
                ),
                'description' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'string'
                ),
            );
            
            $form = new ezcInputForm( INPUT_POST, $definition );
            
            if ( !$form->hasValidData( 'title' ) )
            {
                throw new Exception( 'Title missing.' );
            }
            if ( !$form->hasValidData( 'description' ) )
            {
                throw new Exception( 'Desription missing.' );
            }

            $this->convertPhoto( $_FILES['photo']['tmp_name'] );

            $this->photo = new Photo();
            $this->photo->album = $this->album->id;
            $this->photo->title = $form->title;
            $this->photo->description = $form->description;

            ezcGallery::getSession()->save( $this->photo );
            
            $this->movePhoto( $this->photo );

            $this->template = 'add_submit.php';
        }
        else
        {
            $this->template = 'add_form.php';
        }
    }

    public function getTemplate()
    {
        return $this->template;
    }
    
    public function getTemplateVars()
    {
        return array( 'album' => $this->album, 'photo' => $this->photo );
    }

    private function convertPhoto( $imagePath )
    {
        if ( !is_uploaded_file( $imagePath ) )
        {
            throw new Exception( 'Illigal upload file detected.' );
        }
        $this->tmpData['photoPath'] = $imagePath;
        $this->tmpData['thumbPath'] = tempnam( '', 'thumb' );
        
        try
        {
            ezcGallery::getConverter()->transform( 'photo', $this->tmpData['photoPath'], $this->tmpData['photoPath'] );
            ezcGallery::getConverter()->transform( 'thumb', $this->tmpData['photoPath'], $this->tmpData['thumbPath'] );
        }
        catch ( ezcImageTransformationException $e )
        {
            throw new Exception( 'Image conversion error: <' . $e->getMessage() . '>' );
        }
    }

    private function movePhoto( $photo )
    {
        $analyzer = new ezcImageAnalyzer( $this->tmpData['photoPath'] );
        if ( rename( $this->tmpData['photoPath'], 'data/' . $photo->id . '.jpg' ) === false )
        {
            throw new Exception( 'Unable to store photo.' );
        }
        if ( rename( $this->tmpData['thumbPath'], 'data/' . $photo->id . '_thumb' . '.jpg' ) === false )
        {
            throw new Exception( 'Unable to store thumbnail.' );
        }
    }
}

?>
