<?php include 'templates/head.php'; ?>
<table width="600">
 <tr>
  <td>[<a href="gallery.php">Main</a>]</td>
  <td>[<a href="gallery.php?action=add&album=<?php echo $template['album']->id; ?>">Add photo</a>]</td>
 </tr>
</table>
<ul>
<?php
    foreach ( $template['photos'] as $photo )
    {
        ?>
        <li><ul>
            <li><a href="data/<?php echo $photo->id; ?>.jpg"><img src="data/<?php echo $photo->id; ?>_thumb.jpg" border="0"></a></li>
            <li><strong><?php echo $photo->title; ?></strong></li>
            <li><small><?php echo $photo->description; ?></small></li>
        </ul></li>
        <?php
    }
?>
</ul>
<?php include 'templates/foot.php'; ?>
