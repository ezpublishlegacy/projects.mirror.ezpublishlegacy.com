<?php include 'templates/head.php'; ?>
The following album has been created successfully:
<table width="400">
 <tr>
  <td align="right">
   ID:
  </td>
  <td align="left">
   <?php echo $template['album']->id; ?>
  </td>
 </tr>
 <tr>
  <td align="right">
   Title:
  </td>
  <td align="left">
   <?php echo $template['album']->title; ?>
  </td>
 </tr>
 <tr>
  <td align="right">
   Description:
  </td>
  <td align="left">
   <?php echo $template['album']->description; ?>
  </td>
 </tr>
</table>
<?php include 'templates/foot.php'; ?>
