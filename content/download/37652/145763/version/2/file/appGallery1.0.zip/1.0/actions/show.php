<?php

require_once 'interfaces/action.php';

require_once 'models/album.php';
require_once 'models/photo.php';

class Show implements Action
{

    private $album;

    private $photos;
    
    public function __construct()
    {
        if ( ezcInputForm::hasGetData() )
        {
            $definition = array( 
                'album' => new ezcInputFormDefinitionElement(
                    ezcInputFormDefinitionElement::REQUIRED, 'int'
                ),
            );
            $form = new ezcInputForm( INPUT_GET, $definition );
            if ( !$form->hasValidData( 'album' ) )
            {
                throw new Exception( 'No valid album ID.' );
            }

            $this->album =ezcGallery::getSession()->load( 'Album', $form->album );
        }
        else
        {
            throw new Exception( 'No album selected.' );
        }
    }

    public function run()
    {
        $query = ezcGallery::getSession()->createFindQuery( 'Photo' );
        $query->where( 
            $query->expr->eq( 'album', $this->album->id )
        );
        $this->photos = ezcGallery::getSession()->find( $query, 'Photo' );
    }

    public function getTemplate()
    {
        return 'show.php';
    }
    
    public function getTemplateVars()
    {
        return array( 'photos' => $this->photos, 'album' => $this->album );
    }
}

?>
