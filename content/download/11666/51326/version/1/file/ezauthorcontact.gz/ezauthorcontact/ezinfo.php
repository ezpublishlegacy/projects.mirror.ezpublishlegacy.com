<?php

class ezauthorcontactInfo
{
    public static function info()
    {
        return array( 'Name' => 'eZ Author Contact',
                      'Version' => '1.1.0',
                      'Copyright' => 'Copyright (C) 1999-' . date( 'Y' ) . ' eZ Systems AS',
                      'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
