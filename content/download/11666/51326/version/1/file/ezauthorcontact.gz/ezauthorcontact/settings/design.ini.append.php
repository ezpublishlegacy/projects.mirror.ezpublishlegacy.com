<?php /*

[ExtensionSettings]
DesignExtensions[]=ezauthorcontact

*/ ?>