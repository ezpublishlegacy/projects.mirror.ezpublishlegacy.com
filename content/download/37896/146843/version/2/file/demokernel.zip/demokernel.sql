# MySQL dump 9.07
#
# Host: localhost    Database: nextgen
#############################
# Server version    4.0.10-gamma

#
# Table structure for table 'ezapprove_items'
#

CREATE TABLE ezapprove_items (
  id int(11) NOT NULL auto_increment,
  workflow_process_id int(11) NOT NULL default '0',
  collaboration_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezapprove_items'
#


#
# Table structure for table 'ezbasket'
#

CREATE TABLE ezbasket (
  id int(11) NOT NULL auto_increment,
  session_id varchar(255) NOT NULL default '',
  productcollection_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezbasket'
#


#
# Table structure for table 'ezbinaryfile'
#

CREATE TABLE ezbinaryfile (
  contentobject_attribute_id int(11) NOT NULL default '0',
  version int(11) NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  original_filename varchar(255) NOT NULL default '',
  mime_type varchar(50) NOT NULL default '',
  PRIMARY KEY  (contentobject_attribute_id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezbinaryfile'
#

INSERT INTO ezbinaryfile VALUES (617,1,'phpNS7wkL.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (630,1,'phpCeZRCW.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (630,2,'phpCeZRCW.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (630,3,'phpCeZRCW.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (633,1,'php23Q4Ut.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (633,2,'php23Q4Ut.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (633,3,'php23Q4Ut.txt','tmp.txt','text/plain');
INSERT INTO ezbinaryfile VALUES (633,4,'php23Q4Ut.txt','tmp.txt','text/plain');

#
# Table structure for table 'ezcollab_group'
#

CREATE TABLE ezcollab_group (
  id int(11) NOT NULL auto_increment,
  parent_group_id int(11) NOT NULL default '0',
  depth int(11) NOT NULL default '0',
  path_string varchar(255) NOT NULL default '',
  is_open int(11) NOT NULL default '1',
  user_id int(11) NOT NULL default '0',
  title varchar(255) NOT NULL default '',
  priority int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY ezcollab_group_path (path_string),
  KEY ezcollab_group_depth (depth)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_group'
#


#
# Table structure for table 'ezcollab_item'
#

CREATE TABLE ezcollab_item (
  id int(11) NOT NULL auto_increment,
  type_identifier varchar(40) NOT NULL default '',
  creator_id int(11) NOT NULL default '0',
  status int(11) NOT NULL default '1',
  data_text1 text NOT NULL,
  data_text2 text NOT NULL,
  data_text3 text NOT NULL,
  data_int1 int(11) NOT NULL default '0',
  data_int2 int(11) NOT NULL default '0',
  data_int3 int(11) NOT NULL default '0',
  data_float1 float NOT NULL default '0',
  data_float2 float NOT NULL default '0',
  data_float3 float NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_item'
#


#
# Table structure for table 'ezcollab_item_group_link'
#

CREATE TABLE ezcollab_item_group_link (
  collaboration_id int(11) NOT NULL default '0',
  group_id int(11) NOT NULL default '0',
  user_id int(11) NOT NULL default '0',
  is_read int(11) NOT NULL default '0',
  is_active int(11) NOT NULL default '1',
  last_read int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (collaboration_id,group_id,user_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_item_group_link'
#


#
# Table structure for table 'ezcollab_item_message_link'
#

CREATE TABLE ezcollab_item_message_link (
  id int(11) NOT NULL auto_increment,
  collaboration_id int(11) NOT NULL default '0',
  participant_id int(11) NOT NULL default '0',
  message_id int(11) NOT NULL default '0',
  message_type int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_item_message_link'
#


#
# Table structure for table 'ezcollab_item_participant_link'
#

CREATE TABLE ezcollab_item_participant_link (
  collaboration_id int(11) NOT NULL default '0',
  participant_id int(11) NOT NULL default '0',
  participant_type int(11) NOT NULL default '1',
  participant_role int(11) NOT NULL default '1',
  is_read int(11) NOT NULL default '0',
  is_active int(11) NOT NULL default '1',
  last_read int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (collaboration_id,participant_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_item_participant_link'
#


#
# Table structure for table 'ezcollab_item_status'
#

CREATE TABLE ezcollab_item_status (
  collaboration_id int(11) NOT NULL default '0',
  user_id int(11) NOT NULL default '0',
  is_read int(11) NOT NULL default '0',
  is_active int(11) NOT NULL default '1',
  last_read int(11) NOT NULL default '0',
  PRIMARY KEY  (collaboration_id,user_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_item_status'
#


#
# Table structure for table 'ezcollab_profile'
#

CREATE TABLE ezcollab_profile (
  id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  main_group int(11) NOT NULL default '0',
  data_text1 text NOT NULL,
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_profile'
#


#
# Table structure for table 'ezcollab_simple_message'
#

CREATE TABLE ezcollab_simple_message (
  id int(11) NOT NULL auto_increment,
  message_type varchar(40) NOT NULL default '',
  creator_id int(11) NOT NULL default '0',
  data_text1 text NOT NULL,
  data_text2 text NOT NULL,
  data_text3 text NOT NULL,
  data_int1 int(11) NOT NULL default '0',
  data_int2 int(11) NOT NULL default '0',
  data_int3 int(11) NOT NULL default '0',
  data_float1 float NOT NULL default '0',
  data_float2 float NOT NULL default '0',
  data_float3 float NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcollab_simple_message'
#


#
# Table structure for table 'ezcontent_translation'
#

CREATE TABLE ezcontent_translation (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  locale varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontent_translation'
#


#
# Table structure for table 'ezcontentclass'
#

CREATE TABLE ezcontentclass (
  id int(11) NOT NULL auto_increment,
  version int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  identifier varchar(50) NOT NULL default '',
  contentobject_name varchar(255) default NULL,
  creator_id int(11) NOT NULL default '0',
  modifier_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id,version),
  KEY ezcontentclass_version (version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentclass'
#

INSERT INTO ezcontentclass VALUES (1,0,'Folder','folder','<name>',-1,14,1024392098,1048495167);
INSERT INTO ezcontentclass VALUES (2,0,'Article','article','<title>',-1,14,1024392098,1048495185);
INSERT INTO ezcontentclass VALUES (3,0,'User group','user_group','<name>',-1,14,1024392098,1048495321);
INSERT INTO ezcontentclass VALUES (4,0,'User','user','<first_name> <last_name>',-1,14,1024392098,1048495334);
INSERT INTO ezcontentclass VALUES (5,0,'Image','image','<name>',8,14,1031484992,1048495356);
INSERT INTO ezcontentclass VALUES (6,0,'Forum','forum','<name>',14,14,1034181899,1048495203);
INSERT INTO ezcontentclass VALUES (8,0,'Forum message','forum_message','<topic>',14,14,1034185241,1048495217);
INSERT INTO ezcontentclass VALUES (22,0,'Product','product','<title>',14,14,1034251361,1048495394);
INSERT INTO ezcontentclass VALUES (23,0,'Product review','product_review','<title>',14,14,1034258928,1048495257);
INSERT INTO ezcontentclass VALUES (24,0,'Info page','info_page','<name>',14,14,1035882216,1048495274);
INSERT INTO ezcontentclass VALUES (25,0,'Link','link','<title>',14,14,1037280490,1048495289);
INSERT INTO ezcontentclass VALUES (26,0,'File','file','<name>',14,14,1038917558,1048495369);
INSERT INTO ezcontentclass VALUES (27,0,'Comment','comment','<subject>',14,14,1045816920,1048495302);

#
# Table structure for table 'ezcontentclass_attribute'
#

CREATE TABLE ezcontentclass_attribute (
  id int(11) NOT NULL auto_increment,
  version int(11) NOT NULL default '0',
  contentclass_id int(11) NOT NULL default '0',
  identifier varchar(50) NOT NULL default '',
  name varchar(255) NOT NULL default '',
  data_type_string varchar(50) NOT NULL default '',
  is_searchable int(1) NOT NULL default '0',
  is_required int(1) NOT NULL default '0',
  placement int(11) NOT NULL default '0',
  data_int1 int(11) default NULL,
  data_int2 int(11) default NULL,
  data_int3 int(11) default NULL,
  data_int4 int(11) default NULL,
  data_float1 float default NULL,
  data_float2 float default NULL,
  data_float3 float default NULL,
  data_float4 float default NULL,
  data_text1 varchar(50) default NULL,
  data_text2 varchar(50) default NULL,
  data_text3 varchar(50) default NULL,
  data_text4 varchar(50) default NULL,
  is_information_collector int(11) NOT NULL default '0',
  PRIMARY KEY  (id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentclass_attribute'
#

INSERT INTO ezcontentclass_attribute VALUES (123,0,2,'enable_comments','Enable comments','ezboolean',0,0,5,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (116,0,5,'name','Name','ezstring',1,1,1,150,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (12,0,4,'user_account','User account','ezuser',0,1,3,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (118,0,5,'image','Image','ezimage',0,0,3,2,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (117,0,5,'caption','Caption','ezxmltext',1,0,2,10,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (122,0,2,'thumbnail','Thumbnail','ezimage',0,0,4,2,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (7,0,3,'description','Description','ezstring',1,0,2,255,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (6,0,3,'name','Name','ezstring',1,1,1,255,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (129,0,8,'message','Message','eztext',1,1,2,10,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (128,0,8,'topic','Topic','ezstring',1,1,1,150,0,0,0,0,0,0,0,'New topic','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (160,0,25,'link','Link','ezurl',0,1,3,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (156,0,24,'image','Image','ezimage',0,0,3,1,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (158,0,25,'title','Title','ezstring',1,1,1,100,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (159,0,25,'description','Description','ezxmltext',1,0,2,10,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (162,0,26,'description','Description','ezxmltext',1,0,2,5,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (154,0,24,'name','Name','ezstring',1,1,1,100,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (152,0,23,'geography','Town, Country','ezstring',1,1,4,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (153,0,23,'review','Review','ezxmltext',1,0,5,5,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (126,0,6,'description','Description','ezxmltext',1,0,3,15,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (124,0,6,'name','Name','ezstring',1,1,1,150,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (125,0,6,'icon','Icon','ezimage',0,0,2,1,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (151,0,23,'reviewer_name','Reviewer Name','ezstring',1,1,3,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (149,0,23,'title','Title','ezstring',1,1,1,50,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (165,0,27,'message','Message','eztext',1,1,3,10,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (164,0,27,'subject','Subject','ezstring',1,1,1,40,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (166,0,27,'author','Author','ezstring',1,1,2,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (147,0,22,'price','Price','ezprice',0,1,5,1,0,0,0,1,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (145,0,22,'description','Description','ezxmltext',1,0,4,20,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (8,0,4,'first_name','First name','ezstring',1,1,1,255,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (9,0,4,'last_name','Last name','ezstring',1,1,2,255,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (119,0,1,'description','Description','ezxmltext',1,0,2,15,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (4,0,1,'name','Name','ezstring',1,1,1,255,0,0,0,0,0,0,0,'Folder','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (121,0,2,'body','Body','ezxmltext',1,0,3,20,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (120,0,2,'intro','Intro','ezxmltext',1,0,2,5,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (1,0,2,'title','Title','ezstring',1,1,1,255,0,0,0,0,0,0,0,'New article','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (150,0,23,'rating','Rating','ezenum',1,0,2,0,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (148,0,22,'photo','Photo','ezimage',0,0,6,1,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (155,0,24,'body','Body','ezxmltext',1,0,2,20,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (163,0,26,'file','File','ezbinaryfile',0,1,3,5,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (161,0,26,'name','Name','ezstring',1,1,1,0,0,0,0,0,0,0,0,'New file','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (157,0,22,'intro','Intro','ezxmltext',1,0,3,5,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (144,0,22,'product_nr','Product nr.','ezstring',1,0,2,40,0,0,0,0,0,0,0,'','','','',0);
INSERT INTO ezcontentclass_attribute VALUES (142,0,22,'title','Title','ezstring',1,1,1,100,0,0,0,0,0,0,0,'','','','',0);

#
# Table structure for table 'ezcontentclass_classgroup'
#

CREATE TABLE ezcontentclass_classgroup (
  contentclass_id int(11) NOT NULL default '0',
  contentclass_version int(11) NOT NULL default '0',
  group_id int(11) NOT NULL default '0',
  group_name varchar(255) default NULL,
  PRIMARY KEY  (contentclass_id,contentclass_version,group_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentclass_classgroup'
#

INSERT INTO ezcontentclass_classgroup VALUES (1,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (2,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (4,0,2,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (5,0,3,'Media');
INSERT INTO ezcontentclass_classgroup VALUES (3,0,2,'');
INSERT INTO ezcontentclass_classgroup VALUES (6,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (8,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (23,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (24,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (22,0,5,'Book Corner');
INSERT INTO ezcontentclass_classgroup VALUES (25,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (26,0,3,'Media');
INSERT INTO ezcontentclass_classgroup VALUES (27,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (22,0,1,'Content');
INSERT INTO ezcontentclass_classgroup VALUES (23,0,5,'Book Corner');

#
# Table structure for table 'ezcontentclassgroup'
#

CREATE TABLE ezcontentclassgroup (
  id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  creator_id int(11) NOT NULL default '0',
  modifier_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentclassgroup'
#

INSERT INTO ezcontentclassgroup VALUES (1,'Content',1,14,1031216928,1033922106);
INSERT INTO ezcontentclassgroup VALUES (2,'Users',1,14,1031216941,1033922113);
INSERT INTO ezcontentclassgroup VALUES (3,'Media',8,14,1032009743,1033922120);
INSERT INTO ezcontentclassgroup VALUES (5,'Products',14,14,1034258883,1035971034);

#
# Table structure for table 'ezcontentobject'
#

CREATE TABLE ezcontentobject (
  id int(11) NOT NULL auto_increment,
  owner_id int(11) NOT NULL default '0',
  section_id int(11) NOT NULL default '0',
  contentclass_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  current_version int(11) default NULL,
  is_published int(11) default NULL,
  published int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  status int(11) default '0',
  remote_id varchar(100) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject'
#

INSERT INTO ezcontentobject VALUES (1,0,1,1,'My folder',3,0,1037197879,1037197879,1,NULL);
INSERT INTO ezcontentobject VALUES (4,0,9,3,'Users',1,0,0,0,1,NULL);
INSERT INTO ezcontentobject VALUES (10,8,9,4,'Anonymous User',1,0,1033920665,1033920665,1,NULL);
INSERT INTO ezcontentobject VALUES (11,8,9,3,'Guest accounts',1,0,1033920746,1033920746,1,NULL);
INSERT INTO ezcontentobject VALUES (12,8,9,3,'Administrator users',1,0,1033920775,1033920775,1,NULL);
INSERT INTO ezcontentobject VALUES (13,8,9,3,'Editors',1,0,1033920794,1033920794,1,NULL);
INSERT INTO ezcontentobject VALUES (14,8,9,4,'Administrator User',1,0,1033920830,1033920830,1,NULL);
INSERT INTO ezcontentobject VALUES (15,14,2,1,'White box',5,0,1035893229,1035893229,1,NULL);
INSERT INTO ezcontentobject VALUES (17,14,2,1,'Flowers',4,0,1035886818,1035886818,1,NULL);
INSERT INTO ezcontentobject VALUES (23,14,3,1,'News',2,0,1035967901,1035967901,1,NULL);
INSERT INTO ezcontentobject VALUES (25,14,3,1,'Frontpage',3,0,1034334677,1034334677,1,NULL);
INSERT INTO ezcontentobject VALUES (26,14,3,1,'Sport',3,0,1034334718,1034334718,1,NULL);
INSERT INTO ezcontentobject VALUES (29,14,3,1,'World news',3,0,1034334767,1034334767,1,NULL);
INSERT INTO ezcontentobject VALUES (30,14,4,1,'Crossroads forum',1,0,1034181792,1034181792,1,NULL);
INSERT INTO ezcontentobject VALUES (31,14,4,1,'Forums',1,0,1034181825,1034181825,1,NULL);
INSERT INTO ezcontentobject VALUES (57,14,1,20,'',1,0,1034190865,1034190865,1,NULL);
INSERT INTO ezcontentobject VALUES (62,14,5,1,'The Book Corner',2,0,1035971219,1035971219,1,NULL);
INSERT INTO ezcontentobject VALUES (63,14,5,1,'Thriller',3,0,1035973207,1035973207,1,NULL);
INSERT INTO ezcontentobject VALUES (64,14,5,1,'Bestsellers',1,0,1034252256,1034252256,1,NULL);
INSERT INTO ezcontentobject VALUES (65,14,5,1,'Recommendations',1,0,1034252479,1034252479,1,NULL);
INSERT INTO ezcontentobject VALUES (83,14,2,24,'Whitebox contemporary art gallery',5,0,1035967595,1035967595,1,NULL);
INSERT INTO ezcontentobject VALUES (84,14,2,1,'Forest',5,0,1035892777,1035892777,1,NULL);
INSERT INTO ezcontentobject VALUES (85,14,2,5,'Forest 1',3,0,1035888358,1035888358,1,NULL);
INSERT INTO ezcontentobject VALUES (86,14,2,5,'Flower 1',5,0,1035892919,1035892919,1,NULL);
INSERT INTO ezcontentobject VALUES (87,14,2,5,'Flower 2',3,0,1035892937,1035892937,1,NULL);
INSERT INTO ezcontentobject VALUES (88,14,2,5,'',2,0,1035888272,1035888272,1,NULL);
INSERT INTO ezcontentobject VALUES (89,14,2,5,'',2,0,1035888302,1035888302,1,NULL);
INSERT INTO ezcontentobject VALUES (90,14,2,5,'Forest 2',2,0,1035888387,1035888387,1,NULL);
INSERT INTO ezcontentobject VALUES (91,14,2,5,'Forest 3',2,0,1035888410,1035888410,1,NULL);
INSERT INTO ezcontentobject VALUES (92,14,2,5,'Forest 4',2,0,1035888444,1035888444,1,NULL);
INSERT INTO ezcontentobject VALUES (93,14,2,1,'Water',1,0,1035887037,1035887037,1,NULL);
INSERT INTO ezcontentobject VALUES (94,14,2,5,'Water 1',3,0,1035888486,1035888486,1,NULL);
INSERT INTO ezcontentobject VALUES (95,14,2,5,'Water 2',2,0,1035888527,1035888527,1,NULL);
INSERT INTO ezcontentobject VALUES (96,14,2,5,'Water 3',2,0,1035888554,1035888554,1,NULL);
INSERT INTO ezcontentobject VALUES (97,14,2,5,'Water 4',2,0,1035888617,1035888617,1,NULL);
INSERT INTO ezcontentobject VALUES (98,14,2,1,'Animals',1,0,1035887250,1035887250,1,NULL);
INSERT INTO ezcontentobject VALUES (99,14,2,5,'Animal 1',2,0,1035888720,1035888720,1,NULL);
INSERT INTO ezcontentobject VALUES (100,14,2,5,'Animal 2',2,0,1035888750,1035888750,1,NULL);
INSERT INTO ezcontentobject VALUES (101,14,2,5,'Animal 3',2,0,1035888654,1035888654,1,NULL);
INSERT INTO ezcontentobject VALUES (102,14,2,5,'Animal 4',2,0,1035888685,1035888685,1,NULL);
INSERT INTO ezcontentobject VALUES (103,14,2,1,'Landscape',1,0,1035887800,1035887800,1,NULL);
INSERT INTO ezcontentobject VALUES (104,14,2,5,'Landscape 1',2,0,1035888035,1035888035,1,NULL);
INSERT INTO ezcontentobject VALUES (105,14,2,5,'Landscape 2',2,0,1035888065,1035888065,1,NULL);
INSERT INTO ezcontentobject VALUES (106,14,2,5,'Landscape 3',2,0,1035888094,1035888094,1,NULL);
INSERT INTO ezcontentobject VALUES (107,14,2,5,'Landscape 4',2,0,1035888131,1035888131,1,NULL);
INSERT INTO ezcontentobject VALUES (109,14,3,2,'New article',3,0,1035905739,1035905739,2,'');
INSERT INTO ezcontentobject VALUES (110,14,3,1,'Action',1,0,1035905816,1035905816,1,NULL);
INSERT INTO ezcontentobject VALUES (111,14,3,2,'eZ systems travel company',1,0,1035905861,1035905861,1,NULL);
INSERT INTO ezcontentobject VALUES (112,14,3,1,'Leisure',1,0,1035905944,1035905944,1,NULL);
INSERT INTO ezcontentobject VALUES (113,14,3,2,'Food for the soul',3,0,1045818963,1045818963,1,NULL);
INSERT INTO ezcontentobject VALUES (114,14,3,2,'We did it again',4,0,1035989523,1035989523,1,NULL);
INSERT INTO ezcontentobject VALUES (115,14,3,2,'eZ publish 3.0',2,0,1035969409,1035969409,1,NULL);
INSERT INTO ezcontentobject VALUES (116,14,3,2,'Collaboration in eZ publish',5,0,1035974950,1048520954,1,'');
INSERT INTO ezcontentobject VALUES (117,14,3,2,'New article',1,0,1035969959,1035969959,2,'');
INSERT INTO ezcontentobject VALUES (118,14,4,6,'Sports',2,0,1035988501,1035988501,1,NULL);
INSERT INTO ezcontentobject VALUES (119,14,4,6,'Computers',2,0,1035988870,1035988870,1,NULL);
INSERT INTO ezcontentobject VALUES (120,14,4,6,'Games',3,0,1035989049,1035989049,1,NULL);
INSERT INTO ezcontentobject VALUES (121,14,4,6,'Politics',3,0,1035989376,1035989376,1,NULL);
INSERT INTO ezcontentobject VALUES (122,14,4,8,'Formula 1 2003',1,0,1035970902,1035970902,1,NULL);
INSERT INTO ezcontentobject VALUES (123,14,3,2,'A weekend in the mountain',2,0,1035971131,1035971131,1,NULL);
INSERT INTO ezcontentobject VALUES (125,14,5,22,'The thriller book',4,0,1037264916,1037264916,1,NULL);
INSERT INTO ezcontentobject VALUES (127,14,5,23,'I\'ve read this book',1,0,1035974003,1035974003,1,NULL);
INSERT INTO ezcontentobject VALUES (128,14,3,2,'Sports weekend',1,0,1035974314,1035974314,1,NULL);
INSERT INTO ezcontentobject VALUES (131,14,4,8,'The best football team in England',1,0,1035976181,1035976181,1,NULL);
INSERT INTO ezcontentobject VALUES (132,14,4,8,'Are sports for idiots ?',1,0,1035976274,1035976274,1,NULL);
INSERT INTO ezcontentobject VALUES (133,14,4,8,'Computer nerds',1,0,1035976334,1035976334,1,NULL);
INSERT INTO ezcontentobject VALUES (134,14,4,8,'Without computers the world stops',1,0,1035976395,1035976395,1,NULL);
INSERT INTO ezcontentobject VALUES (135,14,4,8,'Colin McRae Rally 3',1,0,1035976440,1035976440,1,NULL);
INSERT INTO ezcontentobject VALUES (136,14,4,8,'Games should be done outside',1,0,1035976529,1035976529,1,NULL);
INSERT INTO ezcontentobject VALUES (137,14,4,8,'Politics are boring',1,0,1035976603,1035976603,1,NULL);
INSERT INTO ezcontentobject VALUES (139,14,4,8,'I do not agree !!!',1,0,1035976794,1035976794,1,NULL);
INSERT INTO ezcontentobject VALUES (140,14,4,8,'Without politics chaos will rule',1,0,1035977266,1035977266,1,NULL);
INSERT INTO ezcontentobject VALUES (141,14,4,8,'Yes, and it is great',1,0,1035977376,1035977376,1,NULL);
INSERT INTO ezcontentobject VALUES (142,14,4,8,'Yes',1,0,1035977386,1035977386,1,NULL);
INSERT INTO ezcontentobject VALUES (143,14,4,8,'I agree',1,0,1035977458,1035977458,1,NULL);
INSERT INTO ezcontentobject VALUES (144,14,4,8,'Hmmm',1,0,1035977973,1035977973,1,NULL);
INSERT INTO ezcontentobject VALUES (145,14,4,8,'Test',1,0,1035978540,1035978540,1,NULL);
INSERT INTO ezcontentobject VALUES (146,14,4,8,'Not !',1,0,1035978999,1035978999,1,NULL);
INSERT INTO ezcontentobject VALUES (148,14,5,22,'Forest fog',7,0,1037265917,1037265917,1,NULL);
INSERT INTO ezcontentobject VALUES (149,14,5,1,'Computers',1,0,1035983221,1035983221,1,NULL);
INSERT INTO ezcontentobject VALUES (150,14,5,22,'How to make a perfect CMS solution',7,0,1037265165,1037265165,1,NULL);
INSERT INTO ezcontentobject VALUES (151,14,5,22,'eZ publish - a tutorial',3,0,1037264747,1037264747,1,NULL);
INSERT INTO ezcontentobject VALUES (152,14,5,1,'House and garden',1,0,1035985040,1035985040,1,NULL);
INSERT INTO ezcontentobject VALUES (153,14,5,22,'Color is everything',2,0,1037264782,1037264782,1,NULL);
INSERT INTO ezcontentobject VALUES (154,14,5,22,'Peaceful waters',3,0,1037264815,1037264815,1,NULL);
INSERT INTO ezcontentobject VALUES (155,14,4,8,'Ferrari or BMW ?',1,0,1035985365,1035985365,1,NULL);
INSERT INTO ezcontentobject VALUES (156,14,5,1,'Travel',1,0,1035985697,1035985697,1,NULL);
INSERT INTO ezcontentobject VALUES (157,14,5,22,'Travel guide',2,0,1037264847,1037264847,1,NULL);
INSERT INTO ezcontentobject VALUES (158,14,5,22,'Animal planet',3,0,1037265973,1037265973,1,NULL);
INSERT INTO ezcontentobject VALUES (160,14,6,1,'My company',2,0,1037197585,1037197585,1,NULL);
INSERT INTO ezcontentobject VALUES (161,14,6,1,'News',1,0,1037177708,1037177708,1,NULL);
INSERT INTO ezcontentobject VALUES (163,14,6,1,'Products',3,0,1037263615,1037263615,1,NULL);
INSERT INTO ezcontentobject VALUES (164,14,6,1,'Software',1,0,1037192378,1037192378,1,NULL);
INSERT INTO ezcontentobject VALUES (165,14,6,1,'Services',2,0,1037281706,1037281706,1,NULL);
INSERT INTO ezcontentobject VALUES (169,14,6,24,'About',3,0,1037285403,1037285403,1,NULL);
INSERT INTO ezcontentobject VALUES (170,14,6,24,'Careers',6,0,1037284973,1037284973,1,NULL);
INSERT INTO ezcontentobject VALUES (171,14,6,2,'My company wins award',1,0,1037200671,1037200671,1,NULL);
INSERT INTO ezcontentobject VALUES (172,14,6,2,'My company wins $ billion contract',1,0,1037201872,1037201872,1,NULL);
INSERT INTO ezcontentobject VALUES (174,14,6,1,'Servers',1,0,1037202070,1037202070,1,NULL);
INSERT INTO ezcontentobject VALUES (184,14,6,24,'Consulting',1,0,1037261018,1037261018,1,NULL);
INSERT INTO ezcontentobject VALUES (185,14,6,24,'Support',1,0,1037261069,1037261069,1,NULL);
INSERT INTO ezcontentobject VALUES (186,14,6,24,'Programming',1,0,1037261113,1037261113,1,NULL);
INSERT INTO ezcontentobject VALUES (187,14,6,24,'Sys admin',1,0,1037261172,1037261172,1,NULL);
INSERT INTO ezcontentobject VALUES (188,14,6,24,'Feature request',1,0,1037261217,1037261217,1,NULL);
INSERT INTO ezcontentobject VALUES (191,14,6,22,'My company desktop editor',2,0,1037281355,1037281355,1,NULL);
INSERT INTO ezcontentobject VALUES (192,14,6,22,'Server optimized',3,0,1037281397,1037281397,1,NULL);
INSERT INTO ezcontentobject VALUES (196,14,4,1,'Links',1,0,1037280633,1037280633,1,NULL);
INSERT INTO ezcontentobject VALUES (197,14,4,25,'eZ systems',1,0,1037280728,1037280728,1,NULL);
INSERT INTO ezcontentobject VALUES (201,14,4,25,'eZ publish',1,0,1037281396,1037281396,1,NULL);
INSERT INTO ezcontentobject VALUES (202,14,4,24,'About this forum',1,0,1037281592,1037281592,1,NULL);
INSERT INTO ezcontentobject VALUES (203,14,7,1,'My Intranet',1,0,1038916142,1038916142,1,NULL);
INSERT INTO ezcontentobject VALUES (204,14,7,1,'News',1,0,1038916156,1038916156,1,NULL);
INSERT INTO ezcontentobject VALUES (205,14,7,1,'Files',1,0,1038916201,1038916201,1,NULL);
INSERT INTO ezcontentobject VALUES (206,14,7,26,'Important document',1,0,1038917707,1038917707,1,NULL);
INSERT INTO ezcontentobject VALUES (207,14,7,2,'This months budget',1,0,1038919010,1038919010,1,NULL);
INSERT INTO ezcontentobject VALUES (208,14,7,2,'Wine lottery today',1,0,1038919541,1038919541,1,NULL);
INSERT INTO ezcontentobject VALUES (209,14,7,26,'Document template',3,0,1038919177,1038919177,1,NULL);
INSERT INTO ezcontentobject VALUES (210,14,7,26,'Another template',4,0,1038919287,1038919287,1,NULL);
INSERT INTO ezcontentobject VALUES (211,14,7,2,'Meeting today at 13',1,0,1038920436,1038920436,1,NULL);
INSERT INTO ezcontentobject VALUES (212,14,8,1,'My site',1,0,1039687283,1039687283,1,NULL);
INSERT INTO ezcontentobject VALUES (213,14,8,24,'About me',2,0,1039687926,1039687926,1,NULL);
INSERT INTO ezcontentobject VALUES (214,14,8,24,'Portfolio',1,0,1039687794,1039687794,1,NULL);
INSERT INTO ezcontentobject VALUES (72,14,3,2,'Typhoon is near',9,0,1034264438,1034264438,0,NULL);
INSERT INTO ezcontentobject VALUES (39,10,4,8,'New Forum message',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (43,10,4,8,'First reply',1,0,1034186575,1034186575,0,NULL);
INSERT INTO ezcontentobject VALUES (45,10,4,8,'I agree !',1,0,1034186992,1034186992,0,NULL);
INSERT INTO ezcontentobject VALUES (46,10,4,8,'This forum is bad!!!!!!!!!!',1,0,1034187189,1034187189,0,NULL);
INSERT INTO ezcontentobject VALUES (47,10,4,8,'This is my reply',1,0,1034187441,1034187441,0,NULL);
INSERT INTO ezcontentobject VALUES (159,14,4,8,'New Forum message',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (70,14,5,23,'Fantastic',1,0,1034259506,1034259506,0,NULL);
INSERT INTO ezcontentobject VALUES (108,14,2,5,'New Image',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (126,14,3,2,'New Article',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (138,14,4,8,'New Forum message',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (147,14,5,23,'Good',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (194,10,4,8,'New Forum message',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (178,14,6,1,'System administration',1,0,1037202310,1037202310,0,NULL);
INSERT INTO ezcontentobject VALUES (193,14,5,22,'New Product',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (190,14,5,22,'New Product',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (195,14,1,2,'New Article',1,0,0,0,0,NULL);
INSERT INTO ezcontentobject VALUES (200,14,3,2,'Test article',1,0,1037281016,1037281016,0,NULL);
INSERT INTO ezcontentobject VALUES (215,14,3,27,'First post!',1,0,1045819013,1045819013,2,NULL);
INSERT INTO ezcontentobject VALUES (216,10,3,27,'My comment',1,0,1045819258,1045819258,1,NULL);

#
# Table structure for table 'ezcontentobject_attribute'
#

CREATE TABLE ezcontentobject_attribute (
  id int(11) NOT NULL auto_increment,
  language_code varchar(20) NOT NULL default '',
  version int(11) NOT NULL default '0',
  contentobject_id int(11) NOT NULL default '0',
  contentclassattribute_id int(11) NOT NULL default '0',
  data_text text,
  data_int int(11) default NULL,
  data_float float default NULL,
  PRIMARY KEY  (id,version),
  KEY ezcontentobject_attribute_contentobject_id (contentobject_id),
  KEY ezcontentobject_attribute_language_code (language_code)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject_attribute'
#

INSERT INTO ezcontentobject_attribute VALUES (1,'eng-GB',1,1,4,'My folder',NULL,NULL);
INSERT INTO ezcontentobject_attribute VALUES (2,'eng-GB',1,1,119,'This folder contains some information about...',NULL,NULL);
INSERT INTO ezcontentobject_attribute VALUES (7,'eng-GB',1,4,5,'Main group',NULL,NULL);
INSERT INTO ezcontentobject_attribute VALUES (8,'eng-GB',1,4,6,'Users',NULL,NULL);
INSERT INTO ezcontentobject_attribute VALUES (32,'eng-GB',1,15,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Contemporary art gallery.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (31,'eng-GB',1,15,4,'White box',0,0);
INSERT INTO ezcontentobject_attribute VALUES (1,'eng-GB',2,1,4,'My folder',0,0);
INSERT INTO ezcontentobject_attribute VALUES (2,'eng-GB',2,1,119,'This folder contains some information about...',0,0);
INSERT INTO ezcontentobject_attribute VALUES (21,'eng-GB',1,10,12,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (22,'eng-GB',1,11,6,'Guest accounts',0,0);
INSERT INTO ezcontentobject_attribute VALUES (19,'eng-GB',1,10,8,'Anonymous',0,0);
INSERT INTO ezcontentobject_attribute VALUES (20,'eng-GB',1,10,9,'User',0,0);
INSERT INTO ezcontentobject_attribute VALUES (23,'eng-GB',1,11,7,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (24,'eng-GB',1,12,6,'Administrator users',0,0);
INSERT INTO ezcontentobject_attribute VALUES (25,'eng-GB',1,12,7,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (26,'eng-GB',1,13,6,'Editors',0,0);
INSERT INTO ezcontentobject_attribute VALUES (27,'eng-GB',1,13,7,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (28,'eng-GB',1,14,8,'Administrator',0,0);
INSERT INTO ezcontentobject_attribute VALUES (29,'eng-GB',1,14,9,'User',0,0);
INSERT INTO ezcontentobject_attribute VALUES (30,'eng-GB',1,14,12,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (266,'eng-GB',2,104,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Windy hills</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',1,17,4,'Gallery 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',1,17,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (265,'eng-GB',2,104,116,'Landscape 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (276,'eng-GB',1,107,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',2,17,4,'Gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',2,17,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (275,'eng-GB',1,107,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (273,'eng-GB',1,106,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (274,'eng-GB',1,107,116,'Landscape 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (272,'eng-GB',1,106,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (267,'eng-GB',2,104,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (31,'eng-GB',2,15,4,'White box',0,0);
INSERT INTO ezcontentobject_attribute VALUES (32,'eng-GB',2,15,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Contemporary art gallery.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (31,'eng-GB',3,15,4,'White box',0,0);
INSERT INTO ezcontentobject_attribute VALUES (32,'eng-GB',3,15,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Contemporary art gallery.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (52,'eng-GB',1,23,4,'News',0,0);
INSERT INTO ezcontentobject_attribute VALUES (53,'eng-GB',1,23,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>folder with the news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',1,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',1,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on frideay evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',1,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',1,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',1,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',2,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',2,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',2,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',2,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',2,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (59,'eng-GB',1,25,4,'politics',0,0);
INSERT INTO ezcontentobject_attribute VALUES (60,'eng-GB',1,25,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>political news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (61,'eng-GB',1,26,4,'sports',0,0);
INSERT INTO ezcontentobject_attribute VALUES (62,'eng-GB',1,26,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>sport news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (236,'eng-GB',1,93,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (67,'eng-GB',1,29,4,'world',0,0);
INSERT INTO ezcontentobject_attribute VALUES (68,'eng-GB',1,29,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>around the word</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (69,'eng-GB',1,30,4,'Crossroads forum',0,0);
INSERT INTO ezcontentobject_attribute VALUES (70,'eng-GB',1,30,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (71,'eng-GB',1,31,4,'Forums',0,0);
INSERT INTO ezcontentobject_attribute VALUES (72,'eng-GB',1,31,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (245,'eng-GB',1,96,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (237,'eng-GB',1,94,116,'Water 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (238,'eng-GB',1,94,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (239,'eng-GB',1,94,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (237,'eng-GB',2,94,116,'Water 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (238,'eng-GB',2,94,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (239,'eng-GB',2,94,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (240,'eng-GB',1,95,116,'Water 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (241,'eng-GB',1,95,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (242,'eng-GB',1,95,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (243,'eng-GB',1,96,116,'Water 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (244,'eng-GB',1,96,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (235,'eng-GB',1,93,4,'Water',0,0);
INSERT INTO ezcontentobject_attribute VALUES (229,'eng-GB',1,91,116,'Forest 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (230,'eng-GB',1,91,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (231,'eng-GB',1,91,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (232,'eng-GB',1,92,116,'Forest 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (233,'eng-GB',1,92,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (234,'eng-GB',1,92,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (226,'eng-GB',1,90,116,'Forest 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (213,'eng-GB',2,85,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (225,'eng-GB',1,89,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',4,17,4,'Flowers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',4,17,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (211,'eng-GB',2,85,116,'Forest 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (212,'eng-GB',2,85,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Caption..</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (88,'eng-GB',1,39,128,'New topic',0,0);
INSERT INTO ezcontentobject_attribute VALUES (89,'eng-GB',1,39,129,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (95,'eng-GB',1,43,128,'First reply',0,0);
INSERT INTO ezcontentobject_attribute VALUES (96,'eng-GB',1,43,129,'This is what I think about that...\r\n\r\n-b',0,0);
INSERT INTO ezcontentobject_attribute VALUES (98,'eng-GB',1,45,128,'I agree !',0,0);
INSERT INTO ezcontentobject_attribute VALUES (99,'eng-GB',1,45,129,'But how can you know it\'s true ?\r\n-c',0,0);
INSERT INTO ezcontentobject_attribute VALUES (100,'eng-GB',1,46,128,'This forum is bad!!!!!!!!!!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (101,'eng-GB',1,46,129,'Yeah!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (102,'eng-GB',1,47,128,'This is my reply',0,0);
INSERT INTO ezcontentobject_attribute VALUES (103,'eng-GB',1,47,129,'Foo bar..\r\n\r\n-d',0,0);
INSERT INTO ezcontentobject_attribute VALUES (113,'eng-GB',1,57,140,'rfdegrw3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (130,'eng-GB',1,62,4,'The Book Corner',0,0);
INSERT INTO ezcontentobject_attribute VALUES (131,'eng-GB',1,62,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (132,'eng-GB',1,63,4,'Top 20 Books',0,0);
INSERT INTO ezcontentobject_attribute VALUES (133,'eng-GB',1,63,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (134,'eng-GB',1,64,4,'Bestsellers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (135,'eng-GB',1,64,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (136,'eng-GB',1,65,4,'Recommendations',0,0);
INSERT INTO ezcontentobject_attribute VALUES (137,'eng-GB',1,65,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section></section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (319,'eng-GB',2,118,124,'Sports',0,0);
INSERT INTO ezcontentobject_attribute VALUES (320,'eng-GB',2,118,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (321,'eng-GB',2,118,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a sample discussion forum about sports. Open discussions about everything that has to do with sports. What you like and what you do not like, or even hate. Have any questions you want answered?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (224,'eng-GB',1,89,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (223,'eng-GB',1,89,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (214,'eng-GB',1,86,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (215,'eng-GB',1,86,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (216,'eng-GB',1,86,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (217,'eng-GB',1,87,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (218,'eng-GB',1,87,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (219,'eng-GB',1,87,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (220,'eng-GB',1,88,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (221,'eng-GB',1,88,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (222,'eng-GB',1,88,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',3,17,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',3,17,4,'Flowers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (209,'eng-GB',1,84,4,'Forrest',0,0);
INSERT INTO ezcontentobject_attribute VALUES (210,'eng-GB',1,84,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (211,'eng-GB',1,85,116,'Forrest 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (212,'eng-GB',1,85,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Caption..</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (213,'eng-GB',1,85,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (208,'eng-GB',1,83,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (207,'eng-GB',1,83,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The art gallery...</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (206,'eng-GB',1,83,154,'Whitebox contemporary art gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (156,'eng-GB',1,70,149,'Fantastic',0,0);
INSERT INTO ezcontentobject_attribute VALUES (157,'eng-GB',1,70,150,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (158,'eng-GB',1,70,151,'jezmondinio',0,0);
INSERT INTO ezcontentobject_attribute VALUES (159,'eng-GB',1,70,152,'Moscow, Russia',0,0);
INSERT INTO ezcontentobject_attribute VALUES (160,'eng-GB',1,70,153,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Habi senatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim patruriam potiem se factuasdam aus auctum la puli publia nos stretil erra, et, C. Graris hos hosuam P. Si ponfecrei se, Casdactesine mac tam. Catili prae mantis iam que interra? Pat, fatique idem erfervi erit, nore culicavenius horbitas fue iam, quidefactus viliam Roma, constil host res publii probses locciemoerum con tus ad consus dum prae, se conum vis ocre confirm hilicae icienteriam idem esil tem hacteri factoret, ut nox nonimus, cotabefacit L. An defecut in Etris; in speri, que acioca L. Maet; Cas nox nulinte renica; nos, constraeque probus reis publibuntia mo Catqui pubissimis apere nor ut puli iaet in Italegero movente issimus niu consulintiu vitin dis. Opicae con intem, vivere porum spiordiem mo mactantenatu es mo Cat. Serenih libus sedo, num inatium diem host C. maiorei senam ora, senit; nonsult retis.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (271,'eng-GB',1,106,116,'Landscape 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (269,'eng-GB',1,105,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (270,'eng-GB',1,105,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (267,'eng-GB',1,104,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (268,'eng-GB',1,105,116,'Landscape 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (266,'eng-GB',1,104,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (265,'eng-GB',1,104,116,'Landscape 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (263,'eng-GB',1,103,4,'Landscape',0,0);
INSERT INTO ezcontentobject_attribute VALUES (264,'eng-GB',1,103,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (260,'eng-GB',1,102,116,'Animal 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (261,'eng-GB',1,102,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (262,'eng-GB',1,102,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (246,'eng-GB',1,97,116,'Water 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (247,'eng-GB',1,97,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (248,'eng-GB',1,97,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (249,'eng-GB',1,98,4,'Animals',0,0);
INSERT INTO ezcontentobject_attribute VALUES (250,'eng-GB',1,98,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (251,'eng-GB',1,99,116,'Animal 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (252,'eng-GB',1,99,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (253,'eng-GB',1,99,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (254,'eng-GB',1,100,116,'Animal 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (255,'eng-GB',1,100,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (256,'eng-GB',1,100,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (257,'eng-GB',1,101,116,'Animal 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (258,'eng-GB',1,101,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (259,'eng-GB',1,101,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',3,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',3,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',3,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',3,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',3,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',4,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (60,'eng-GB',2,25,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Hot news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (59,'eng-GB',3,25,4,'Frontpage',0,0);
INSERT INTO ezcontentobject_attribute VALUES (60,'eng-GB',3,25,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Hot news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (61,'eng-GB',2,26,4,'Sport',0,0);
INSERT INTO ezcontentobject_attribute VALUES (62,'eng-GB',2,26,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Sport news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (61,'eng-GB',3,26,4,'Sport',0,0);
INSERT INTO ezcontentobject_attribute VALUES (62,'eng-GB',3,26,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Sport news</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (67,'eng-GB',2,29,4,'World news',0,0);
INSERT INTO ezcontentobject_attribute VALUES (68,'eng-GB',2,29,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Around the word</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (67,'eng-GB',3,29,4,'World news',0,0);
INSERT INTO ezcontentobject_attribute VALUES (68,'eng-GB',3,29,119,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Around the word</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (59,'eng-GB',2,25,4,'Frontpage',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',4,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',4,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',4,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',4,72,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',5,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',5,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',5,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',5,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',5,72,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',6,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',6,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',6,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',6,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',6,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',7,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',7,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',7,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',7,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',7,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',8,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',8,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',8,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',8,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',8,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (166,'eng-GB',9,72,1,'Typhoon is near',0,0);
INSERT INTO ezcontentobject_attribute VALUES (167,'eng-GB',9,72,120,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>Huge typhoon now is very close to Skien town in norway. It is recomended to sit at home and drink bear, and do not go out in the street on Friday evening :)</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (168,'eng-GB',9,72,121,'<?xml version=\"1.0\" encoding=\"utf-8\" ?><section><paragraph>I\'m just kidding.</paragraph>\n</section>',0,0);
INSERT INTO ezcontentobject_attribute VALUES (169,'eng-GB',9,72,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (170,'eng-GB',9,72,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (228,'eng-GB',1,90,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (227,'eng-GB',1,90,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (268,'eng-GB',2,105,116,'Landscape 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (269,'eng-GB',2,105,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Snowy mountain</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (270,'eng-GB',2,105,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (271,'eng-GB',2,106,116,'Landscape 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (272,'eng-GB',2,106,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Bright blue sky</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (273,'eng-GB',2,106,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (274,'eng-GB',2,107,116,'Landscape 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (275,'eng-GB',2,107,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Natural shape in stone</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (276,'eng-GB',2,107,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',5,17,4,'Flowers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',5,17,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (35,'eng-GB',6,17,4,'Flowers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (36,'eng-GB',6,17,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (214,'eng-GB',2,86,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (215,'eng-GB',2,86,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (216,'eng-GB',2,86,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (214,'eng-GB',3,86,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (215,'eng-GB',3,86,117,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (216,'eng-GB',3,86,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (214,'eng-GB',4,86,116,'Flower 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (215,'eng-GB',4,86,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>White</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (216,'eng-GB',4,86,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (217,'eng-GB',2,87,116,'Flower 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (218,'eng-GB',2,87,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Yellow</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (219,'eng-GB',2,87,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (220,'eng-GB',2,88,116,'Flower 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (221,'eng-GB',2,88,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Yellow and blue</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (222,'eng-GB',2,88,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (223,'eng-GB',2,89,116,'Flower 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (224,'eng-GB',2,89,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Blue and green</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (225,'eng-GB',2,89,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (209,'eng-GB',2,84,4,'Forest',0,0);
INSERT INTO ezcontentobject_attribute VALUES (210,'eng-GB',2,84,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (211,'eng-GB',3,85,116,'Forest 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (212,'eng-GB',3,85,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <P>Blue berries</P>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (213,'eng-GB',3,85,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (226,'eng-GB',2,90,116,'Forest 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (227,'eng-GB',2,90,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Natural shaped man</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (228,'eng-GB',2,90,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (229,'eng-GB',2,91,116,'Forest 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (230,'eng-GB',2,91,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Misty forest</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (231,'eng-GB',2,91,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (232,'eng-GB',2,92,116,'Forest 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (233,'eng-GB',2,92,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Reaching for the sky</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (234,'eng-GB',2,92,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (237,'eng-GB',3,94,116,'Water 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (238,'eng-GB',3,94,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A wonderful view</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (239,'eng-GB',3,94,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (240,'eng-GB',2,95,116,'Water 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (241,'eng-GB',2,95,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Reaching the shore</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (242,'eng-GB',2,95,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (243,'eng-GB',2,96,116,'Water 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (244,'eng-GB',2,96,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Standing all alone</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (245,'eng-GB',2,96,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (246,'eng-GB',2,97,116,'Water 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (247,'eng-GB',2,97,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Can you hear the water?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (248,'eng-GB',2,97,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (257,'eng-GB',2,101,116,'Animal 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (258,'eng-GB',2,101,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Not happy?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (259,'eng-GB',2,101,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (260,'eng-GB',2,102,116,'Animal 4',0,0);
INSERT INTO ezcontentobject_attribute VALUES (261,'eng-GB',2,102,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Black and white beauty</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (262,'eng-GB',2,102,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (251,'eng-GB',2,99,116,'Animal 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (252,'eng-GB',2,99,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Balancing monkey</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (253,'eng-GB',2,99,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (254,'eng-GB',2,100,116,'Animal 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (255,'eng-GB',2,100,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Searching for something to eat</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (256,'eng-GB',2,100,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (209,'eng-GB',4,84,4,'Forest',0,0);
INSERT INTO ezcontentobject_attribute VALUES (210,'eng-GB',3,84,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (209,'eng-GB',3,84,4,'Forest',0,0);
INSERT INTO ezcontentobject_attribute VALUES (210,'eng-GB',4,84,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (209,'eng-GB',5,84,4,'Forest',0,0);
INSERT INTO ezcontentobject_attribute VALUES (210,'eng-GB',5,84,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (215,'eng-GB',5,86,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>White</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (214,'eng-GB',5,86,116,'Flower 1',0,0);
INSERT INTO ezcontentobject_attribute VALUES (216,'eng-GB',5,86,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (217,'eng-GB',3,87,116,'Flower 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (218,'eng-GB',3,87,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Yellow</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (219,'eng-GB',3,87,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (31,'eng-GB',4,15,4,'White box',0,0);
INSERT INTO ezcontentobject_attribute VALUES (32,'eng-GB',4,15,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Having difficulties getting away from it all? Have you forgotten the small thing is life? Remember the humming of a bee? The smell of pine? The beauty of a snowy mountain a cold clear winter day?</paragraph>\n  <paragraph>Here is a chance to escape from the stressful, noisy and hectic day you encounter every day. Get your well-deserved breathing space in this gallery where we salute the beauty of Mother Nature, and get away from it all. \nThrough White box you can dream away for a few minutes.\n  \nWith some much beauty surrounding us many people still forget the beauty right outside our window. Remember the sounds, the smells, the feelings and not to forget the sights?</paragraph>\n  <paragraph>Let your mind drift away!</paragraph>\n  <paragraph>White box presents the following galleries:</paragraph>\n  <paragraph>�    Water\n�    Forest\n�    Flowers\n�    Landscape\n�    Animals</paragraph>\n  <paragraph>?All that is gold does not glitter,\nNot all those who wander are lost\nThe old that is strong does not wither,\nDeep roots are not reached by frost?.\n(J. R. R. Tolkien &quot;Lord of the Rings&quot; )</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (31,'eng-GB',5,15,4,'White box',0,0);
INSERT INTO ezcontentobject_attribute VALUES (32,'eng-GB',5,15,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (206,'eng-GB',2,83,154,'Whitebox contemporary art gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (207,'eng-GB',2,83,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Having difficulties getting away from it all? Have you forgotten the small thing is life? Remember the humming of a bee? The smell of pine? The beauty of a snowy mountain a cold clear winter day?</paragraph>\n  <paragraph>Here is a chance to escape from the stressful, noisy and hectic day you encounter every day. Get your well-deserved breathing space in this gallery where we salute the beauty of Mother Nature, and get away from it all. \nThrough White box you can dream away for a few minutes.\n  \nWith some much beauty surrounding us many people still forget the beauty right outside our window. Remember the sounds, the smells, the feelings and not to forget the sights?</paragraph>\n  <paragraph>Let your mind drift away!</paragraph>\n  <paragraph>White box presents the following galleries:</paragraph>\n  <paragraph>�    Water\n�    Forest\n�    Flowers\n�    Landscape\n�    Animals</paragraph>\n  <paragraph>?All that is gold does not glitter,\nNot all those who wander are lost\nThe old that is strong does not wither,\nDeep roots are not reached by frost?.\n(J. R. R. Tolkien &quot;Lord of the Rings&quot; )</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (208,'eng-GB',2,83,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (206,'eng-GB',3,83,154,'Whitebox contemporary art gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (207,'eng-GB',3,83,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Having difficulties getting away from it all? Have you forgotten the small thing is life? Remember the humming of a bee? The smell of pine? The beauty of a snowy mountain a cold clear winter day?</paragraph>\n  <paragraph>Here is a chance to escape from the stressful, noisy and hectic day you encounter every day. Get your well-deserved breathing space in this gallery where we salute the beauty of Mother Nature, and get away from it all. \nThrough White box you can dream away for a few minutes.\n  \nWith some much beauty surrounding us many people still forget the beauty right outside our window. Remember the sounds, the smells, the feelings and not to forget the sights?</paragraph>\n  <paragraph>Let your mind drift away!</paragraph>\n  <paragraph>White box presents the following galleries:</paragraph>\n  <paragraph>�    Water\n�    Forest\n�    Flowers\n�    Landscape\n�    Animals</paragraph>\n  <paragraph>?All that is gold does not glitter,\nNot all those who wander are lost\nThe old that is strong does not wither,\nDeep roots are not reached by frost?.\n(J. R. R. Tolkien &quot;Lord of the Rings&quot; )</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (208,'eng-GB',3,83,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (277,'eng-GB',1,108,116,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (278,'eng-GB',1,108,117,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (279,'eng-GB',1,108,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (206,'eng-GB',4,83,154,'Whitebox contemporary art gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (207,'eng-GB',4,83,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Having difficulties getting away from it all? Have you forgotten the small thing is life? Remember the humming of a bee? The smell of pine? The beauty of a snowy mountain a cold clear winter day?</paragraph>\n  <paragraph>Here is a chance to escape from the stressful, noisy and hectic day you encounter every day. Get your well-deserved breathing space in this gallery where we salute the beauty of Mother Nature, and get away from it all. \nThrough White box you can dream away for a few minutes.\n  \nWith some much beauty surrounding us many people still forget the beauty right outside our window. Remember the sounds, the smells, the feelings and not to forget the sights?</paragraph>\n  <paragraph>Let your mind drift away!</paragraph>\n  <paragraph>White box presents the following galleries:</paragraph>\n  <paragraph>�    Water\n�    Forest\n�    Flowers\n�    Landscape\n�    Animals</paragraph>\n  <paragraph>?All that is gold does not glitter,\nNot all those who wander are lost\nThe old that is strong does not wither,\nDeep roots are not reached by frost?.\n(J. R. R. Tolkien &quot;Lord of the Rings&quot; )</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (208,'eng-GB',4,83,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (280,'eng-GB',1,109,1,'New article',0,0);
INSERT INTO ezcontentobject_attribute VALUES (281,'eng-GB',1,109,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ systems is proud to announce that the company has been handpicked by The European Tech Tour Association as one of the most exciting companies in Norway. eZ systems was one of 26 companies that The European Tech Tour Association (ETT) think have the most promising future of companies in Norway.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (282,'eng-GB',1,109,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>In a 2 day event, widely covered by the international press, Tech Tour provided the most innovative and upcoming technology companies in Norway with a unique opportunity to meet and network with a selective group of 60 senior professionals from leading blue-chip technology corporations, venture capitalists, advisors, investment banks, and corporate advisors.</paragraph>\n  <paragraph>The objective was to identify the up-coming and leading top 20+ high-growth privately held technology companies in Norway and introduce them to key European, US and Asian investors and professionals who can assist in their global expansion. eZ systems was proudly picked as one of the 26 companies.</paragraph>\n  <paragraph>This shows another step in the always growing popularity of eZ systems and eZ publish. eZ publish has been a great success since the start and is by August 2002 among the worldwide leaders in content management software. With the expected release of the completely new eZ publish 3.0 later this year the future seams bright for present and new users of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (283,'eng-GB',1,109,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (284,'eng-GB',1,109,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (280,'eng-GB',2,109,1,'New article',0,0);
INSERT INTO ezcontentobject_attribute VALUES (281,'eng-GB',2,109,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ systems is proud to announce that the company has been handpicked by The European Tech Tour Association as one of the most exciting companies in Norway. eZ systems was one of 26 companies that The European Tech Tour Association (ETT) think have the most promising future of companies in Norway.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (282,'eng-GB',2,109,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>In a 2 day event, widely covered by the international press, Tech Tour provided the most innovative and upcoming technology companies in Norway with a unique opportunity to meet and network with a selective group of 60 senior professionals from leading blue-chip technology corporations, venture capitalists, advisors, investment banks, and corporate advisors.</paragraph>\n  <paragraph>The objective was to identify the up-coming and leading top 20+ high-growth privately held technology companies in Norway and introduce them to key European, US and Asian investors and professionals who can assist in their global expansion. eZ systems was proudly picked as one of the 26 companies.</paragraph>\n  <paragraph>This shows another step in the always growing popularity of eZ systems and eZ publish. eZ publish has been a great success since the start and is by August 2002 among the worldwide leaders in content management software. With the expected release of the completely new eZ publish 3.0 later this year the future seams bright for present and new users of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (283,'eng-GB',2,109,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (284,'eng-GB',2,109,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (280,'eng-GB',3,109,1,'eZ systems earns award',0,0);
INSERT INTO ezcontentobject_attribute VALUES (281,'eng-GB',3,109,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ systems is proud to announce that the company has been handpicked by The European Tech Tour Association as one of the most exciting companies in Norway. eZ systems was one of 26 companies that The European Tech Tour Association (ETT) think have the most promising future of companies in Norway.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (282,'eng-GB',3,109,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>In a 2 day event, widely covered by the international press, Tech Tour provided the most innovative and upcoming technology companies in Norway with a unique opportunity to meet and network with a selective group of 60 senior professionals from leading blue-chip technology corporations, venture capitalists, advisors, investment banks, and corporate advisors.</paragraph>\n  <paragraph>The objective was to identify the up-coming and leading top 20+ high-growth privately held technology companies in Norway and introduce them to key European, US and Asian investors and professionals who can assist in their global expansion. eZ systems was proudly picked as one of the 26 companies.</paragraph>\n  <paragraph>This shows another step in the always growing popularity of eZ systems and eZ publish. eZ publish has been a great success since the start and is by August 2002 among the worldwide leaders in content management software. With the expected release of the completely new eZ publish 3.0 later this year the future seams bright for present and new users of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (283,'eng-GB',3,109,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (284,'eng-GB',3,109,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (285,'eng-GB',1,110,4,'Action',0,0);
INSERT INTO ezcontentobject_attribute VALUES (286,'eng-GB',1,110,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ systems travels</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (287,'eng-GB',1,111,1,'eZ systems travel company',0,0);
INSERT INTO ezcontentobject_attribute VALUES (288,'eng-GB',1,111,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The Actiongroup from eZ systems are now in the middle of evaluating possible new markets. During the last few months they have focused on what part of the world that has the most beautiful sights. They have visited most corners of the world to come up with a winner.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (289,'eng-GB',1,111,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The analysis will map the identity and beauty from the different places and show what the selected parts will have to offer the next time eZ systems go on a trip. Will the trip go to the mountains, the lake or perhaps to a deep and dark forest?</paragraph>\n  <paragraph>-Reports from World Tourism and Travel Council show that most members of the big eZ crew wants to go to Brasil and Mexico. Meanwhile the depth interviews showed that some of the members just wanted to stay at the office. A crew member, that wants to stay anonymous for his own safety, claims that he is afraid of leaving the office. Everyday a bunch of fans wait outside the company offices. ?They are like a mob? he says. It?s hard to be as hansom as me. I guess that is why the rest og the crew wants to travel. ?They are plain jealous?.</paragraph>\n  <paragraph>On the other hand he believes that the mountains would be a nice place to go. ?No fans there?. Investigations show that the eZ crew is ready to spend a lot of money, but only if the destination is interesting enough.  The language is no problem since one of the barriers for getting a job in eZ systems is that you speak 10-15 languages fluently. Information that has leaked out show that some might have interest in Sweden and India as well. We have not been able to confirm this yet.</paragraph>\n  <paragraph>A lot of work is still to be done before a decision can be done. We can only speculate on what the conclusions will be but we are sure when the crew leaves it will be interesting.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (290,'eng-GB',1,111,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (291,'eng-GB',1,111,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (292,'eng-GB',1,112,4,'Leisure',0,0);
INSERT INTO ezcontentobject_attribute VALUES (293,'eng-GB',1,112,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (294,'eng-GB',1,113,1,'Food for the soul',0,0);
INSERT INTO ezcontentobject_attribute VALUES (295,'eng-GB',1,113,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Soulfood.no is a result of a passionate interest for photography and people. This interesting site runs on eZ publish and is a very good example on what you can do with content and design on an eZ publish powered site.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (296,'eng-GB',1,113,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Christian Houge, b. 1972, is a freelance photographer educated in USA and have worked with advertising, portraits and travelling since 1994. \nOn his last travel, during the winter of 1999, Houge spend six months with the exile tibetanians in the South and North India as well as in Nepal. Many of his pictures are influenced by this visit. For long periods of this stay he lived in a tibetanian monastery as the only western representative and he got an insight in the daily life of the munks.</paragraph>\n  <paragraph>The design for this site is made by Sigurd Kristiansen Superstar.no and has been set up by one of eZ systems official partners Petraflux.com \neZ systems has assisted our partner with support. Automatical image import was created amongst other things.</paragraph>\n  <paragraph>Visit Soulfood</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (297,'eng-GB',1,113,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (298,'eng-GB',1,113,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (299,'eng-GB',1,114,1,'We did it again',0,0);
INSERT INTO ezcontentobject_attribute VALUES (300,'eng-GB',1,114,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We did it again to beat Kings at Outfield which was earlier considered as one of our toughest match for the start of this season.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (301,'eng-GB',1,114,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Our persistence, desire and determination finally paid off when Doppers&apos;s 90th-minute and fifth League goal so far this season gave us not only the last laugh but also broad smiles all over the faces of Footballer team.</paragraph>\n  <paragraph>Yet to recover from the hangover in their rough &apos;Viking ride&apos; near the North Sea causing an early exit from Cup, Kings was rather stubborn to prove a point at Outfield. Their defence marshalled by Desy and Dill was like a &apos;Great Wall of China&apos; for Dopper and Hester to climb over it.</paragraph>\n  <paragraph>The first half seemed equally contested with couple of exchanges from both sides. Kjell and his staff must have injected more fuel to the belly of the players to increase their fire intensity. The team ran out from the tunnel in the second half with more desire to win, especially when Barton was introduced into the game 20 minutes before time.</paragraph>\n  <paragraph>Girro should have scored a spectacular goal in the 52nd minute when his 30-yard goal bounding shot beat Cudic but not the crossbar. Baros was unfortunate not to score for us when his surging run forward caused a lot of problems to their defence. It was only when Dippel came in to replace the tired Murphy that we ignited some sparks in our attack. Simply great to see another defence splitting pass from Dippel to Hester who was also unfortunate not to be in the scoresheet when Cudic made a fine save. Fortunately Dopper was so quick to follow up and slammed the ball into the back of the net.</paragraph>\n  <paragraph>Besides Stevenson, Kjell must have developed another defence splitting passer in Dippel to provide those &apos;special key&apos;s&apos; to strikers to unlock stubborn defences. The totally different reaction between Kjell and Roney when Doppel hit the back of the net said it all.</paragraph>\n  <paragraph>Let&apos;s hope to have a injury free international games break this week end to travel to Highend Road next Saturday. Come on Reds!</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (302,'eng-GB',1,114,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (303,'eng-GB',1,114,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (299,'eng-GB',2,114,1,'We did it again',0,0);
INSERT INTO ezcontentobject_attribute VALUES (300,'eng-GB',2,114,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We did it again to beat Kings at Outfield which was earlier considered as one of our toughest match for the start of this season.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (301,'eng-GB',2,114,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Our persistence, desire and determination finally paid off when Doppers&apos;s 90th-minute and fifth League goal so far this season gave us not only the last laugh but also broad smiles all over the faces of Footballer team.</paragraph>\n  <paragraph>Yet to recover from the hangover in their rough &apos;Viking ride&apos; near the North Sea causing an early exit from Cup, Kings was rather stubborn to prove a point at Outfield. Their defence marshalled by Desy and Dill was like a &apos;Great Wall of China&apos; for Dopper and Hester to climb over it.</paragraph>\n  <paragraph>The first half seemed equally contested with couple of exchanges from both sides. Kjell and his staff must have injected more fuel to the belly of the players to increase their fire intensity. The team ran out from the tunnel in the second half with more desire to win, especially when Barton was introduced into the game 20 minutes before time.</paragraph>\n  <paragraph>Girro should have scored a spectacular goal in the 52nd minute when his 30-yard goal bounding shot beat Cudic but not the crossbar. Barton was unfortunate not to score for us when his surging run forward caused a lot of problems to their defence. It was only when Dippel came in to replace the tired Murphy that we ignited some sparks in our attack. Simply great to see another defence splitting pass from Dippel to Hester who was also unfortunate not to be in the scoresheet when Cudic made a fine save. Fortunately Dopper was so quick to follow up and slammed the ball into the back of the net.</paragraph>\n  <paragraph>Besides Stevenson, Kjell must have developed another defence splitting passer in Dippel to provide those &apos;special key&apos;s&apos; to strikers to unlock stubborn defences. The totally different reaction between Kjell and Roney when Doppel hit the back of the net said it all.</paragraph>\n  <paragraph>Let&apos;s hope to have a injury free international games break this week end to travel to Highend Road next Saturday. Come on Reds!</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (302,'eng-GB',2,114,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (303,'eng-GB',2,114,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (206,'eng-GB',5,83,154,'Whitebox contemporary art gallery',0,0);
INSERT INTO ezcontentobject_attribute VALUES (207,'eng-GB',5,83,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Having difficulties getting away from it all? Have you forgotten the small thing is life? Remember the humming of a bee? The smell of pine? The beauty of a snowy mountain a cold clear winter day?</paragraph>\n  <paragraph>Here is a chance to escape from the stressful, noisy and hectic day you encounter every day. Get your well-deserved breathing space in this gallery where we salute the beauty of Mother Nature, and get away from it all. \nThrough White box you can dream away for a few minutes.\n  \nWith some much beauty surrounding us many people still forget the beauty right outside our window. Remember the sounds, the smells, the feelings and not to forget the sights?</paragraph>\n  <paragraph>Let your mind drift away!</paragraph>\n  <paragraph>White box presents the following galleries:\n    <ul>      <li>Water</li>\n      <li>Forest</li>\n      <li>Flowers</li>\n      <li>Landscape</li>\n      <li>Animals</li>\n</ul>\n</paragraph>\n  <paragraph>    <emphasize>All that is gold does not glitter,\nNot all those who wander are lost\nThe old that is strong does not wither,\nDeep roots are not reached by frost?.\n(J. R. R. Tolkien &quot;Lord of the Rings&quot; )</emphasize>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (208,'eng-GB',5,83,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (52,'eng-GB',2,23,4,'News',0,0);
INSERT INTO ezcontentobject_attribute VALUES (53,'eng-GB',2,23,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>folder with the news</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (299,'eng-GB',3,114,1,'We did it again',0,0);
INSERT INTO ezcontentobject_attribute VALUES (300,'eng-GB',3,114,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We did it again to beat Kings at Outfield which was earlier considered as one of our toughest match for the start of this season.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (301,'eng-GB',3,114,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Our persistence, desire and determination finally paid off when Doppers&apos;s 90th-minute and fifth League goal so far this season gave us not only the last laugh but also broad smiles all over the faces of Footballer team.</paragraph>\n  <paragraph>Yet to recover from the hangover in their rough &apos;Viking ride&apos; near the North Sea causing an early exit from Cup, Kings was rather stubborn to prove a point at Outfield. Their defence marshalled by Desy and Dill was like a &apos;Great Wall of China&apos; for Dopper and Hester to climb over it.</paragraph>\n  <paragraph>The first half seemed equally contested with couple of exchanges from both sides. Kjell and his staff must have injected more fuel to the belly of the players to increase their fire intensity. The team ran out from the tunnel in the second half with more desire to win, especially when Barton was introduced into the game 20 minutes before time.</paragraph>\n  <paragraph>Girro should have scored a spectacular goal in the 52nd minute when his 30-yard goal bounding shot beat Cudic but not the crossbar. Barton was unfortunate not to score for us when his surging run forward caused a lot of problems to their defence. It was only when Dippel came in to replace the tired Murphy that we ignited some sparks in our attack. Simply great to see another defence splitting pass from Dippel to Hester who was also unfortunate not to be in the scoresheet when Cudic made a fine save. Fortunately Dopper was so quick to follow up and slammed the ball into the back of the net.</paragraph>\n  <paragraph>Besides Stevenson, Kjell must have developed another defence splitting passer in Dippel to provide those &apos;special key&apos;s&apos; to strikers to unlock stubborn defences. The totally different reaction between Kjell and Roney when Doppel hit the back of the net said it all.</paragraph>\n  <paragraph>Let&apos;s hope to have a injury free international games break this week end to travel to Highend Road next Saturday. Come on Reds!</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (302,'eng-GB',3,114,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (303,'eng-GB',3,114,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (294,'eng-GB',2,113,1,'Food for the soul',0,0);
INSERT INTO ezcontentobject_attribute VALUES (295,'eng-GB',2,113,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Soulfood.no is a result of a passionate interest for photography and people. This interesting site runs on eZ publish and is a very good example on what you can do with content and design on an eZ publish powered site.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (296,'eng-GB',2,113,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Christian Houge, b. 1972, is a freelance photographer educated in USA and have worked with advertising, portraits and travelling since 1994. \nOn his last travel, during the winter of 1999, Houge spend six months with the exile tibetanians in the South and North India as well as in Nepal. Many of his pictures are influenced by this visit. For long periods of this stay he lived in a tibetanian monastery as the only western representative and he got an insight in the daily life of the munks.</paragraph>\n  <paragraph>The design for this site is made by Sigurd Kristiansen Superstar.no and has been set up by one of eZ systems official partners Petraflux.com \neZ systems has assisted our partner with support. Automatical image import was created amongst other things.</paragraph>\n  <paragraph>Visit Soulfood</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (297,'eng-GB',2,113,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (298,'eng-GB',2,113,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (304,'eng-GB',1,115,1,'eZ publish 3.0',0,0);
INSERT INTO ezcontentobject_attribute VALUES (305,'eng-GB',1,115,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ publish 3.0 is a professional tool for creating advanced and dynamic internet solutions. With eZ publish 3.0 you have the possibility to create powerful and unique websites, web shops, portals and intranet/extranets.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (306,'eng-GB',1,115,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Who is it for?\neZ publish 3.0 is content management system and a tool for Internet Publishing. Everyone that have content stored and wants to communicate and publish this will find eZ publish useful. The features in this generation of eZ publish makes publishing flexible, easy, professional and fun.</paragraph>\n  <paragraph>Key features in 3.0\n? User defined content classes\n? Advanced search engine\n? Centralized Access control\n? Advanced template engine\n? Workflow management\n? SOAP communication library\n? SOAP interface for simple systems integration\n? Database abstraction layer\n? Localisation and internationalization libraries\n? Task system for easy collaboration\n? Image conversion and scaling\n? Locale system\n? A fully documented API\n? Lots of tutorials and howtos\n? UML diagrams completing the documentation\n? XML handling and parsing library</paragraph>\n  <paragraph>eZ publish suites\neZ systems offer solutions for easier set up and use of this advenced content management system. These suites are customized for specific use and usergroups.</paragraph>\n  <paragraph>eZ publish 3.0 licence\n? eZ publish 3.0 is open source and free following the GPL licence\n? If you want to change or resell products based on eZ publish you need to buy a professional licence from eZ systems.\nFor more information about eZ publish 3.0 visit www.ez.no</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (307,'eng-GB',1,115,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (308,'eng-GB',1,115,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (304,'eng-GB',2,115,1,'eZ publish 3.0',0,0);
INSERT INTO ezcontentobject_attribute VALUES (305,'eng-GB',2,115,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ publish 3.0 is a professional tool for creating advanced and dynamic internet solutions. With eZ publish 3.0 you have the possibility to create powerful and unique websites, web shops, portals and intranet/extranets.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (306,'eng-GB',2,115,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <H1>Who is it for?</H1>\n    <P> eZ publish 3.0 is content management system and a tool for Internet Publishing. Everyone that have content stored and wants to communicate and publish this will find eZ publish useful. The features in this generation of eZ publish makes publishing flexible, easy, professional and fun. </P>\n    <P>      <STRONG>Key features in 3.0 ?</STRONG>\n</P>\n    <UL>      <LI>User defined content classes</LI>\n      <LI>Advanced search engine</LI>\n      <LI>Centralized Access control</LI>\n      <LI>Advanced template engine</LI>\n      <LI>Workflow management</LI>\n      <LI>SOAP communication library</LI>\n      <LI>SOAP interface for simple systems integration</LI>\n      <LI>Database abstraction layer</LI>\n      <LI>Localisation and internationalization libraries</LI>\n      <LI>Task system for easy collaboration</LI>\n      <LI>Image conversion and scaling</LI>\n      <LI>Locale system</LI>\n      <LI>A fully documented API</LI>\n      <LI>Lots of tutorials and howtos</LI>\n      <LI>UML diagrams completing the documentation</LI>\n      <LI>XML handling and parsing library</LI>\n</UL>\n    <P>      <STRONG>eZ publish suites</STRONG>\n</P>\n    <P>&amp;nbsp;eZ systems offer solutions for easier set up and use of this advenced content management system. These suites are customized for specific use and usergroups. </P>\n    <P>      <STRONG>eZ publish 3.0 licence</STRONG>\n</P>\n    <P>eZ publish 3.0 is open source and free following the GPL licence. If you want to change or resell products based on eZ publish you need to buy a professional licence from eZ systems. </P>\n    <P>For more information about eZ publish 3.0 visit       <A href=\"http://www.ez.no\" >www.ez.no</A>\n</P>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (307,'eng-GB',2,115,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (308,'eng-GB',2,115,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (309,'eng-GB',1,116,1,'eZ systems and Siemens partner up',0,0);
INSERT INTO ezcontentobject_attribute VALUES (310,'eng-GB',1,116,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >The weekend coming up will be torture for all those who don?t like ? or even hate everything that has something to do with sport. </FONT>\n</FONT>\n</SPAN>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >This weekend will be full of sport in all channels.            <?xml:namespace ns=\"urn:schemas-microsoft-com:office:office\"  />            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (311,'eng-GB',1,116,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <P style=\"MARGIN: 0cm 0cm 0pt\" >        <SPAN style=\"mso-ansi-language: EN-GB\" >          <FONT>            <FONT face=\"Times New Roman\" >              <?xml:namespace ns=\"urn:schemas-microsoft-com:office:office\"  />              <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;</FONT>\n</FONT>\n</SPAN>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Friday evening it all kicks of with American Footballs            <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp; </SPAN>\n?Match of the day? between the Giants and the Dolphins. The game will attract interest from all the fans since both are unbeaten this year and heading for the play-offs.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Saturday starts off at 8 am with cross-country skiing from Holmenkollen, Norway and the 30 km classic. This will be followed by Ice-hockey from the NHL and if you prefer, Gymnastics World Championships from Berlin.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Then at 3 CET the Premier League kicks off with a full round at all stadiums. Since Liverpool already secured the title with last Saturdays win at Anfield the rest of the teams will fight for second an third.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Sunday you can see ski jump 120 from Lahti, ice hockey from the NHL, soccer from Sweden, rowing from Germany, table tennis European Masters and more.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \'Times New Roman\'; mso-ansi-language: EN-GB; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-US; mso-bidi-language: AR-SA\" >Find your favourite chair, take control of the remote, cancel all other activities and enjoy a sport weekend.&amp;nbsp;      <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp;</SPAN>\n      <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp;</SPAN>\n</SPAN>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (312,'eng-GB',1,116,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (313,'eng-GB',1,116,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (314,'eng-GB',1,117,1,'New article',0,0);
INSERT INTO ezcontentobject_attribute VALUES (315,'eng-GB',1,117,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ systems and Siemens proudly announced a partnership between the two companies on a news conference today.\nSiemens Business Services (SBS) and eZ systems (eZ) has entered a partnership, where SBS will market and sell services and products from eZ systems. SBS has bought a professional licence from eZ systems and will become a Premier eZ partner.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (316,'eng-GB',1,117,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>eZ publish, the leading open source content management system, will build a basis for SBS content management solutions, both as eZ publish and under a new Siemens Brand.</paragraph>\n  <paragraph>&quot;eZ publish is a great all in one\nbusiness portal plattform to design and build customer specific solutions.&quot;\nBernd Frey\nPrincipal SBS\ne-business-solutions</paragraph>\n  <paragraph>eZ systems, the creators of eZ publish, see this partnership as an important step. Both because SBS will be contributing to the eZ publish developement, and because they will give income through licence, product and services sales. SBS will also be important for the eZ publish users in Germany, giving them a very competent and reliable delieverer of eZ publish solutions and support.</paragraph>\n  <paragraph>SBS, which is a leading IT consulting company with divisions around the world has a very high level of competence and have already implemented several sites using eZ publish. In fiscal 2001, 35.900 employees in 44 countries achieved sales of approximately EUR 6 billion. (The range of Siemens Business Services service and solution offerings covers all elements\nof the Consult-Design-Build-Operate-Maintain service chain - from process consulting to the design and implementation of application systems, from the operation of the IT and communication infranstructure right through to technical maintenance.)</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (317,'eng-GB',1,117,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (318,'eng-GB',1,117,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (319,'eng-GB',1,118,124,'Sports',0,0);
INSERT INTO ezcontentobject_attribute VALUES (320,'eng-GB',1,118,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (321,'eng-GB',1,118,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a sample discussion forum to comment sports. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (322,'eng-GB',1,119,124,'Computers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (323,'eng-GB',1,119,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (324,'eng-GB',1,119,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Discuss computers and internet here. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (325,'eng-GB',1,120,124,'Games',0,0);
INSERT INTO ezcontentobject_attribute VALUES (326,'eng-GB',1,120,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (327,'eng-GB',1,120,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Games.  Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (325,'eng-GB',2,120,124,'Games',0,0);
INSERT INTO ezcontentobject_attribute VALUES (326,'eng-GB',2,120,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (327,'eng-GB',2,120,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Games.  Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (328,'eng-GB',1,121,124,'Politics',0,0);
INSERT INTO ezcontentobject_attribute VALUES (329,'eng-GB',1,121,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (330,'eng-GB',1,121,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>What do you think about the rebels on tatooine....  Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum. Lorem ipsum lorem ipsum.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (331,'eng-GB',1,122,128,'Formula 1 2003',0,0);
INSERT INTO ezcontentobject_attribute VALUES (332,'eng-GB',1,122,129,'Who will win the 2003 chapionship ?\r\n\r\n--pooh',0,0);
INSERT INTO ezcontentobject_attribute VALUES (333,'eng-GB',1,123,1,'A weekend in the mountain',0,0);
INSERT INTO ezcontentobject_attribute VALUES (334,'eng-GB',1,123,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This weekend some members of eZ systems went climbing in of the majestic mountains in Jotunheimen. After having to choose between flying kites, white water rafting and climbing they ended up in the car heading for Jotunheimen. This is one of the finest climbing areas in Norway and it has a combination of high quality rock, accessibility, and ambience that has quickly put fear in the eZ crew.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (335,'eng-GB',1,123,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The climbing was easy at first but soon it started to be harder. Picture the mountain features and formations taken out of a picture galley about the Norwegian fjords. \nThere they were, in bright sunshine, enjoying the open and powerful mountain and forgetting about the usual days of programming. The guys took a lot of pictures and decided to spend the rest of the weekend in the mountains.</paragraph>\n  <paragraph>Jotunheimen has unlimited options when choosing routes. Everywhere you will find routes that will be suitable for every experience level. If this is the first or 200th time you are in the mountain you will find something that suits you. Perfect climbing days, changing weather, hiking trails and tasting of the sweet berries all over the place will guarantee you the experience of a lifetime.</paragraph>\n  <paragraph>It certainly did to the eZ crew that went on the trip.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (336,'eng-GB',1,123,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (337,'eng-GB',1,123,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (333,'eng-GB',2,123,1,'A weekend in the mountain',0,0);
INSERT INTO ezcontentobject_attribute VALUES (334,'eng-GB',2,123,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This weekend some members of eZ systems went climbing in of the majestic mountains in Jotunheimen. After having to choose between flying kites, white water rafting and climbing they ended up in the car heading for Jotunheimen. This is one of the finest climbing areas in Norway and it has a combination of high quality rock, accessibility, and ambience that has quickly put fear in the eZ crew.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (335,'eng-GB',2,123,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The climbing was easy at first but soon it started to be harder. Picture the mountain features and formations taken out of a picture galley about the Norwegian fjords. \nThere they were, in bright sunshine, enjoying the open and powerful mountain and forgetting about the usual days of programming. The guys took a lot of pictures and decided to spend the rest of the weekend in the mountains.</paragraph>\n  <paragraph>Jotunheimen has unlimited options when choosing routes. Everywhere you will find routes that will be suitable for every experience level. If this is the first or 200th time you are in the mountain you will find something that suits you. Perfect climbing days, changing weather, hiking trails and tasting of the sweet berries all over the place will guarantee you the experience of a lifetime.</paragraph>\n  <paragraph>It certainly did to the eZ crew that went on the trip.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (336,'eng-GB',2,123,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (337,'eng-GB',2,123,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (130,'eng-GB',2,62,4,'The Book Corner',0,0);
INSERT INTO ezcontentobject_attribute VALUES (131,'eng-GB',2,62,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (132,'eng-GB',2,63,4,'Thriller',0,0);
INSERT INTO ezcontentobject_attribute VALUES (133,'eng-GB',2,63,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (132,'eng-GB',3,63,4,'Thriller',0,0);
INSERT INTO ezcontentobject_attribute VALUES (133,'eng-GB',3,63,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (340,'eng-GB',1,125,142,'Thriller book',0,0);
INSERT INTO ezcontentobject_attribute VALUES (341,'eng-GB',1,125,144,'102120',0,0);
INSERT INTO ezcontentobject_attribute VALUES (342,'eng-GB',1,125,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>THis is a real thriller...</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (343,'eng-GB',1,125,147,'',0,12);
INSERT INTO ezcontentobject_attribute VALUES (344,'eng-GB',1,125,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (345,'eng-GB',1,126,1,'New article',0,0);
INSERT INTO ezcontentobject_attribute VALUES (346,'eng-GB',1,126,120,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (347,'eng-GB',1,126,121,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (348,'eng-GB',1,126,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (349,'eng-GB',1,126,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (350,'eng-GB',1,127,149,'I\'ve read this book',0,0);
INSERT INTO ezcontentobject_attribute VALUES (351,'eng-GB',1,127,150,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (352,'eng-GB',1,127,151,'Kjell',0,0);
INSERT INTO ezcontentobject_attribute VALUES (353,'eng-GB',1,127,152,'Skien, Norway',0,0);
INSERT INTO ezcontentobject_attribute VALUES (354,'eng-GB',1,127,153,'<?xml version=\"1.0\"?>\n<section>  <paragraph>I think the book is ok.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (309,'eng-GB',2,116,1,'eZ systems and Siemens partner up',0,0);
INSERT INTO ezcontentobject_attribute VALUES (310,'eng-GB',2,116,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >The weekend coming up will be torture for all those who don?t like ? or even hate everything that has something to do with sport. </FONT>\n</FONT>\n</SPAN>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >This weekend will be full of sport in all channels.            <?xml:namespace ns=\"urn:schemas-microsoft-com:office:office\"  />            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (311,'eng-GB',2,116,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <P style=\"MARGIN: 0cm 0cm 0pt\" >        <SPAN style=\"mso-ansi-language: EN-GB\" >          <FONT>            <FONT face=\"Times New Roman\" >              <?xml:namespace ns=\"urn:schemas-microsoft-com:office:office\"  />              <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;</FONT>\n</FONT>\n</SPAN>\n      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Friday evening it all kicks of with American Footballs            <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp; </SPAN>\n?Match of the day? between the Giants and the Dolphins. The game will attract interest from all the fans since both are unbeaten this year and heading for the play-offs.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Saturday starts off at 8 am with cross-country skiing from Holmenkollen, Norway and the 30 km classic. This will be followed by Ice-hockey from the NHL and if you prefer, Gymnastics World Championships from Berlin.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Then at 3 CET the Premier League kicks off with a full round at all stadiums. Since Liverpool already secured the title with last Saturdays win at Anfield the rest of the teams will fight for second an third.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >Sunday you can see ski jump 120 from Lahti, ice hockey from the NHL, soccer from Sweden, rowing from Germany, table tennis European Masters and more.            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <P style=\"MARGIN: 0cm 0cm 0pt\" >      <SPAN style=\"mso-ansi-language: EN-GB\" >        <FONT>          <FONT face=\"Times New Roman\" >&amp;nbsp;            <o:p /></FONT>\n</FONT>\n</SPAN>\n</P>\n    <SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \'Times New Roman\'; mso-ansi-language: EN-GB; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-US; mso-bidi-language: AR-SA\" >Find your favourite chair, take control of the remote, cancel all other activities and enjoy a sport weekend.&amp;nbsp;      <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp;</SPAN>\n      <SPAN style=\"mso-spacerun: yes\" >&amp;nbsp;</SPAN>\n</SPAN>\n</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (312,'eng-GB',2,116,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (313,'eng-GB',2,116,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (355,'eng-GB',1,128,1,'Sports weekend',0,0);
INSERT INTO ezcontentobject_attribute VALUES (356,'eng-GB',1,128,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The weekend coming up will be torture for all those who don?t like - or even hate everything that has something to do with sport. \nThis weekend will be full of sport in all channels.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (357,'eng-GB',1,128,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Friday evening it all kicks of with American Footballs  ?Match of the day? between the Giants and the Dolphins. The game will attract interest from all the fans since both are unbeaten this year and heading for the play-offs.</paragraph>\n  <paragraph>Saturday starts off at 8 am with cross-country skiing from Holmenkollen, Norway and the 30 km classic. This will be followed by Ice-hockey from the NHL and if you prefer, Gymnastics World Championships from Berlin.</paragraph>\n  <paragraph>Then at 3 CET the Premier League kicks off with a full round at all stadiums. Since Liverpool already secured the title with last Saturdays win at Anfield the rest of the teams will fight for second an third.</paragraph>\n  <paragraph>Sunday you can see ski jump 120 from Lahti, ice hockey from the NHL, soccer from Sweden, rowing from Germany, table tennis European Masters, racing and more.</paragraph>\n  <paragraph>Find your favourite chair, take control of the remote, cancel all other activities and enjoy a sport weekend.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (358,'eng-GB',1,128,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (359,'eng-GB',1,128,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (309,'eng-GB',3,116,1,'Collaboration in eZ publish',0,0);
INSERT INTO ezcontentobject_attribute VALUES (310,'eng-GB',3,116,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>There are many things happening around the world. \nThis article is one of them. This is an article about writing articles in this generation of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (400,'eng-GB',1,146,128,'Not !',0,0);
INSERT INTO ezcontentobject_attribute VALUES (401,'eng-GB',1,146,129,'That\'s not true..',0,0);
INSERT INTO ezcontentobject_attribute VALUES (402,'eng-GB',1,147,149,'Good',0,0);
INSERT INTO ezcontentobject_attribute VALUES (403,'eng-GB',1,147,150,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (404,'eng-GB',1,147,151,'John Doe',0,0);
INSERT INTO ezcontentobject_attribute VALUES (405,'eng-GB',1,147,152,'Nowhere, Anyland',0,0);
INSERT INTO ezcontentobject_attribute VALUES (406,'eng-GB',1,147,153,'<?xml version=\"1.0\"?>\n<section>  <paragraph>I think this book is pretty ok..</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (311,'eng-GB',3,116,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Take one example on what you can use eZ publish for; collaboration. \nAn editor wants to make a story on emigration\nShe assigns the following tasks:\nPhotograph Joe: take pictures\nJournalist Peter: write story\nJournalsit Sally: get background statistics</paragraph>\n  <paragraph>Upon completion the editor will receive the complete article and may choose to publish the story or reject with comments.\nCollaboration may also be used for many other processes, such as distributing tasks in a support service, handling of requests from customers, or invitations to meetings/events.</paragraph>\n  <paragraph>This way the employees in a newspaper can collaborate on an article about water</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (399,'eng-GB',1,145,129,'test',0,0);
INSERT INTO ezcontentobject_attribute VALUES (398,'eng-GB',1,145,128,'Test',0,0);
INSERT INTO ezcontentobject_attribute VALUES (396,'eng-GB',1,144,128,'Hmmm',0,0);
INSERT INTO ezcontentobject_attribute VALUES (397,'eng-GB',1,144,129,'This was hard..\n\n--too',0,0);
INSERT INTO ezcontentobject_attribute VALUES (394,'eng-GB',1,143,128,'I agree',0,0);
INSERT INTO ezcontentobject_attribute VALUES (371,'eng-GB',1,131,129,'Of course the team is Liverpool ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (370,'eng-GB',1,131,128,'The best football team in England',0,0);
INSERT INTO ezcontentobject_attribute VALUES (395,'eng-GB',1,143,129,'It is the best rally game, ever!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (372,'eng-GB',1,132,128,'Are sports for idiots ?',0,0);
INSERT INTO ezcontentobject_attribute VALUES (373,'eng-GB',1,132,129,'No, I think that it is vital for everyone to be interested in something. Why not sports?',0,0);
INSERT INTO ezcontentobject_attribute VALUES (374,'eng-GB',1,133,128,'Computer nerds',0,0);
INSERT INTO ezcontentobject_attribute VALUES (375,'eng-GB',1,133,129,'Everyone that loves playing around with computers are nerds!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (376,'eng-GB',1,134,128,'Without computers the world stops',0,0);
INSERT INTO ezcontentobject_attribute VALUES (377,'eng-GB',1,134,129,'Computers are essential for living today.',0,0);
INSERT INTO ezcontentobject_attribute VALUES (378,'eng-GB',1,135,128,'Colin McRae Rally 3',0,0);
INSERT INTO ezcontentobject_attribute VALUES (379,'eng-GB',1,135,129,'Has anyone tried it yet?',0,0);
INSERT INTO ezcontentobject_attribute VALUES (380,'eng-GB',1,136,128,'Games should be done outside ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (381,'eng-GB',1,136,129,'When I was young we did all our games outside. Now you hardly never see kids outside. That is wrong! ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (382,'eng-GB',1,137,128,'Politics are boring',0,0);
INSERT INTO ezcontentobject_attribute VALUES (383,'eng-GB',1,137,129,'It does not matter what or who you vote for. You will get the same anyway. ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (384,'eng-GB',1,138,128,'New topic',0,0);
INSERT INTO ezcontentobject_attribute VALUES (385,'eng-GB',1,138,129,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (386,'eng-GB',1,139,128,'I do not agree !!!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (387,'eng-GB',1,139,129,'This is not true what you are saying..\r\n\r\n--kalle',0,0);
INSERT INTO ezcontentobject_attribute VALUES (388,'eng-GB',1,140,128,'Without politics chaos will rule',0,0);
INSERT INTO ezcontentobject_attribute VALUES (389,'eng-GB',1,140,129,'Politics are the difference between life today and 500 years ago. Chaos would rule if the politicians were gone ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (390,'eng-GB',1,141,128,'Yes, and it is great',0,0);
INSERT INTO ezcontentobject_attribute VALUES (391,'eng-GB',1,141,129,'It\'s a smash. It can\'t get more realistic than this. But be aware; this game makes you addicted! ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (392,'eng-GB',1,142,128,'Yes',0,0);
INSERT INTO ezcontentobject_attribute VALUES (393,'eng-GB',1,142,129,'or no\n\n--testing',0,0);
INSERT INTO ezcontentobject_attribute VALUES (312,'eng-GB',3,116,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (313,'eng-GB',3,116,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',1,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',1,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',1,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books is about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',1,148,147,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',1,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',2,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',2,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',2,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books is about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',2,148,147,'',0,299);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',2,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',3,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',3,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',3,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books is about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',3,148,147,'',0,29);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',3,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (340,'eng-GB',2,125,142,'The thriller book',0,0);
INSERT INTO ezcontentobject_attribute VALUES (341,'eng-GB',2,125,144,'102120',0,0);
INSERT INTO ezcontentobject_attribute VALUES (342,'eng-GB',2,125,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a real thriller. If you like being scared this paperback is the thing for you. 20 short stories that will make you crawl and regret that you ever opened the book. Do not read this book late at night</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (343,'eng-GB',2,125,147,'',0,12);
INSERT INTO ezcontentobject_attribute VALUES (344,'eng-GB',2,125,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (412,'eng-GB',1,149,4,'Computers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (413,'eng-GB',1,149,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',1,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',1,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',1,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',1,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',1,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (419,'eng-GB',1,151,142,'eZ publish - a tutorial',0,0);
INSERT INTO ezcontentobject_attribute VALUES (420,'eng-GB',1,151,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (421,'eng-GB',1,151,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a tutorial for the professional content management system eZ publish. Written by the developers ofthe system this book gives you the best insight possible. The book is written for everyone that uses or wil use eZ publish. The book takes you from downloading the software to your site is set up and optimized.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (422,'eng-GB',1,151,147,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (423,'eng-GB',1,151,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (419,'eng-GB',2,151,142,'eZ publish - a tutorial',0,0);
INSERT INTO ezcontentobject_attribute VALUES (420,'eng-GB',2,151,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (421,'eng-GB',2,151,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a tutorial for the professional content management system eZ publish. Written by the developers ofthe system this book gives you the best insight possible. The book is written for everyone that uses or wil use eZ publish. The book takes you from downloading the software to your site is set up and optimized.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (422,'eng-GB',2,151,147,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (423,'eng-GB',2,151,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',2,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',2,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',2,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',2,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',2,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (340,'eng-GB',3,125,142,'The thriller book',0,0);
INSERT INTO ezcontentobject_attribute VALUES (341,'eng-GB',3,125,144,'102120',0,0);
INSERT INTO ezcontentobject_attribute VALUES (342,'eng-GB',3,125,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a real thriller. If you like being scared this paperback is the thing for you. 20 short stories that will make you crawl and regret that you ever opened the book. Do not read this book late at night</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (343,'eng-GB',3,125,147,'',0,12);
INSERT INTO ezcontentobject_attribute VALUES (344,'eng-GB',3,125,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',4,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',4,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',4,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books is about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',4,148,147,'',0,29);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',4,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (424,'eng-GB',1,152,4,'House and garden',0,0);
INSERT INTO ezcontentobject_attribute VALUES (425,'eng-GB',1,152,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (426,'eng-GB',1,153,142,'Color is everything',0,0);
INSERT INTO ezcontentobject_attribute VALUES (427,'eng-GB',1,153,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (428,'eng-GB',1,153,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Habefac tam. Tum am aucii te et auctus. Vivehebemorum hocura? Name te, forbis. Habi senatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim patruriam\npotiem se factuasdam aus auctum la puli publia nos stretil erra, et, C. Graris hos hosuam P. Si ponfecrei se, Casdactesine mac tam. Catili prae mantis iam que interra?\nsenatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim part</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (429,'eng-GB',1,153,147,'',0,16);
INSERT INTO ezcontentobject_attribute VALUES (430,'eng-GB',1,153,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (431,'eng-GB',1,154,142,'Peaceful waters',0,0);
INSERT INTO ezcontentobject_attribute VALUES (432,'eng-GB',1,154,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (433,'eng-GB',1,154,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A great tip for getting your ovn little Eden in your backyard. This book gives you lots of suggestions for this. What plants to have, what stones to use, what lawn is the best for playing on. The author also recommend to use water in different forms and sizes. It is very peaceful ang gives your backyard a hole different look and feel</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (434,'eng-GB',1,154,147,'',0,24.99);
INSERT INTO ezcontentobject_attribute VALUES (435,'eng-GB',1,154,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (436,'eng-GB',1,155,128,'Ferrari or BMW ?',0,0);
INSERT INTO ezcontentobject_attribute VALUES (437,'eng-GB',1,155,129,'I don\'t know..',0,0);
INSERT INTO ezcontentobject_attribute VALUES (438,'eng-GB',1,156,4,'Travel',0,0);
INSERT INTO ezcontentobject_attribute VALUES (439,'eng-GB',1,156,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (440,'eng-GB',1,157,142,'Travel guide',0,0);
INSERT INTO ezcontentobject_attribute VALUES (441,'eng-GB',1,157,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (442,'eng-GB',1,157,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A travel guide to the remote areas of the world. Even if that means travelling right outside your doorstep. This book is aimed for those who wants to experience other things than others usually do. Hike the vast hills of Ireland or the deep forests in Colorado. Or visit a small bed and breakfast in a small cummunity in Banglore.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (443,'eng-GB',1,157,147,'',0,23.99);
INSERT INTO ezcontentobject_attribute VALUES (444,'eng-GB',1,157,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (445,'eng-GB',1,158,142,'Animal planet',0,0);
INSERT INTO ezcontentobject_attribute VALUES (446,'eng-GB',1,158,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (447,'eng-GB',1,158,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>See the world through the eyes of the animals. Visit different parts of our planet and get to know the animals that live there. The animal planet is much more exiting that we ever imagine.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (448,'eng-GB',1,158,147,'',0,9.99);
INSERT INTO ezcontentobject_attribute VALUES (449,'eng-GB',1,158,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',3,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',3,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',3,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',3,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',3,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (431,'eng-GB',2,154,142,'Peaceful waters',0,0);
INSERT INTO ezcontentobject_attribute VALUES (432,'eng-GB',2,154,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (433,'eng-GB',2,154,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A great tip for getting your ovn little Eden in your backyard. This book gives you lots of suggestions for this. What plants to have, what stones to use, what lawn is the best for playing on. The author also recommend to use water in different forms and sizes. It is very peaceful ang gives your backyard a hole different look and feel</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (434,'eng-GB',2,154,147,'',0,24.99);
INSERT INTO ezcontentobject_attribute VALUES (435,'eng-GB',2,154,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',5,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',5,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',5,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books is about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',5,148,147,'',0,29);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',5,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (322,'eng-GB',2,119,124,'Computers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (323,'eng-GB',2,119,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (324,'eng-GB',2,119,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Discuss computers and internet here. \nDo you have anything on your mind about computers that you wants others to respond to? Perhaps you are a programming teckie that needs some help on an important issue. \nDo you think of programmers as nerds? Post it here.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (325,'eng-GB',3,120,124,'Games',0,0);
INSERT INTO ezcontentobject_attribute VALUES (326,'eng-GB',3,120,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (327,'eng-GB',3,120,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Games.  What is your favorite game? Have any suggestions for others to try out. Perhaps you have learned some new cheats lately that you want to publish.\nAre you having problems that needs solving? Share it with us!</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (328,'eng-GB',2,121,124,'Politics',0,0);
INSERT INTO ezcontentobject_attribute VALUES (329,'eng-GB',2,121,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (330,'eng-GB',2,121,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>What do you think about the rebels on tatooine....  \nEveryone knows about politics. Even if you do not follow politics at a daily basis you surely have feeling for or against it. Politics always stir up feelings. Some hate what others love while others can not understand what the fuss is all about. It does not matter anyway.\nHave any inputs?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (328,'eng-GB',3,121,124,'Politics',0,0);
INSERT INTO ezcontentobject_attribute VALUES (329,'eng-GB',3,121,125,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (330,'eng-GB',3,121,126,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Even if you do not follow politics at a daily basis you surely have feeling for or against it. Politics always stir up feelings. Some hate what others love while others can not understand what the fuss is all about. It does not matter anyway.\nHave any inputs?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (299,'eng-GB',4,114,1,'We did it again',0,0);
INSERT INTO ezcontentobject_attribute VALUES (300,'eng-GB',4,114,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We did it again to beat Kings at Outfield which was earlier considered as one of our toughest match for the start of this season.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (301,'eng-GB',4,114,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Our persistence, desire and determination finally paid off when Doppers&apos;s 90th-minute and fifth League goal so far this season gave us not only the last laugh but also broad smiles all over the faces of Footballer team.</paragraph>\n  <paragraph>Yet to recover from the hangover in their rough &apos;Viking ride&apos; near the North Sea causing an early exit from Cup, Kings was rather stubborn to prove a point at Outfield. Their defence marshalled by Desy and Dill was like a &apos;Great Wall of China&apos; for Dopper and Hester to climb over it.</paragraph>\n  <paragraph>The first half seemed equally contested with couple of exchanges from both sides. Kjell and his staff must have injected more fuel to the belly of the players to increase their fire intensity. The team ran out from the tunnel in the second half with more desire to win, especially when Barton was introduced into the game 20 minutes before time.</paragraph>\n  <paragraph>Girro should have scored a spectacular goal in the 52nd minute when his 30-yard goal bounding shot beat Cudic but not the crossbar. Barton was unfortunate not to score for us when his surging run forward caused a lot of problems to their defence. It was only when Dippel came in to replace the tired Murphy that we ignited some sparks in our attack. Simply great to see another defence splitting pass from Dippel to Hester who was also unfortunate not to be in the scoresheet when Cudic made a fine save. Fortunately Dopper was so quick to follow up and slammed the ball into the back of the net.</paragraph>\n  <paragraph>Besides Stevenson, Kjell must have developed another defence splitting passer in Dippel to provide those &apos;special key&apos;s&apos; to strikers to unlock stubborn defences. The totally different reaction between Kjell and Roney when Doppel hit the back of the net said it all.</paragraph>\n  <paragraph>Let&apos;s hope to have a injury free international games break this week end to travel to Highend Road next Saturday. Come on Reds!</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (302,'eng-GB',4,114,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (303,'eng-GB',4,114,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (450,'eng-GB',1,159,128,'New topic',0,0);
INSERT INTO ezcontentobject_attribute VALUES (451,'eng-GB',1,159,129,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (226,'eng-GB',3,90,116,'Forest 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (227,'eng-GB',3,90,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Natural shaped man</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (228,'eng-GB',3,90,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (226,'eng-GB',4,90,116,'Forest 2',0,0);
INSERT INTO ezcontentobject_attribute VALUES (227,'eng-GB',4,90,117,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Natural shaped man</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (228,'eng-GB',4,90,118,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (355,'eng-GB',2,128,1,'Sports weekend',0,0);
INSERT INTO ezcontentobject_attribute VALUES (356,'eng-GB',2,128,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The weekend coming up will be torture for all those who don?t like - or even hate everything that has something to do with sport. \nThis weekend will be full of sport in all channels.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (357,'eng-GB',2,128,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Friday evening it all kicks of with American Footballs  ?Match of the day? between the Giants and the Dolphins. The game will attract interest from all the fans since both are unbeaten this year and heading for the play-offs.</paragraph>\n  <paragraph>Saturday starts off at 8 am with cross-country skiing from Holmenkollen, Norway and the 30 km classic. This will be followed by Ice-hockey from the NHL and if you prefer, Gymnastics World Championships from Berlin.</paragraph>\n  <paragraph>Then at 3 CET the Premier League kicks off with a full round at all stadiums. Since Liverpool already secured the title with last Saturdays win at Anfield the rest of the teams will fight for second an third.</paragraph>\n  <paragraph>Sunday you can see ski jump 120 from Lahti, ice hockey from the NHL, soccer from Sweden, rowing from Germany, table tennis European Masters, racing and more.</paragraph>\n  <paragraph>Find your favourite chair, take control of the remote, cancel all other activities and enjoy a sport weekend.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (358,'eng-GB',2,128,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (359,'eng-GB',2,128,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (309,'eng-GB',4,116,1,'Collaboration in eZ publish',0,0);
INSERT INTO ezcontentobject_attribute VALUES (310,'eng-GB',4,116,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>There are many things happening around the world. \nThis article is one of them. This is an article about writing articles in this generation of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (311,'eng-GB',4,116,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Take one example on what you can use eZ publish for; collaboration. \nAn editor wants to make a story on emigration\nShe assigns the following tasks:\nPhotograph Joe: take pictures\nJournalist Peter: write story\nJournalsit Sally: get background statistics</paragraph>\n  <paragraph>Upon completion the editor will receive the complete article and may choose to publish the story or reject with comments.\nCollaboration may also be used for many other processes, such as distributing tasks in a support service, handling of requests from customers, or invitations to meetings/events.</paragraph>\n  <paragraph>This way the employees in a newspaper can collaborate on an article about water</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (312,'eng-GB',4,116,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (313,'eng-GB',4,116,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (452,'eng-GB',1,160,4,'My company',0,0);
INSERT INTO ezcontentobject_attribute VALUES (453,'eng-GB',1,160,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (454,'eng-GB',1,161,4,'News',0,0);
INSERT INTO ezcontentobject_attribute VALUES (455,'eng-GB',1,161,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (461,'eng-GB',1,163,4,'Products',0,0);
INSERT INTO ezcontentobject_attribute VALUES (462,'eng-GB',1,163,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (463,'eng-GB',1,164,4,'Software',0,0);
INSERT INTO ezcontentobject_attribute VALUES (464,'eng-GB',1,164,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (465,'eng-GB',1,165,4,'Services',0,0);
INSERT INTO ezcontentobject_attribute VALUES (466,'eng-GB',1,165,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',1,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',1,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',1,170,154,'Recruit ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (1,'eng-GB',3,1,4,'My folder',0,0);
INSERT INTO ezcontentobject_attribute VALUES (2,'eng-GB',3,1,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (452,'eng-GB',2,160,4,'My company',0,0);
INSERT INTO ezcontentobject_attribute VALUES (453,'eng-GB',2,160,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (476,'eng-GB',2,169,154,'About',0,0);
INSERT INTO ezcontentobject_attribute VALUES (477,'eng-GB',2,169,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Welcome to My company</paragraph>\n  <paragraph>My company is a leader in technology that enable programming and industry customers to improve performance and satisfaction while lowering costs and time spend.</paragraph>\n  <paragraph>My company is located in downtown Metropolis and we operate in about 65 countries and employ around 1,000 people.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (476,'eng-GB',1,169,154,'About',0,0);
INSERT INTO ezcontentobject_attribute VALUES (477,'eng-GB',1,169,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Welcome to My company</paragraph>\n  <paragraph>My company is a leader in technology that enable programming and industry customers to improve performance and satisfaction while lowering costs and time spend. My company is located in a metropolis and we operate in about 65 countries and employ around 1,000 people.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (478,'eng-GB',1,169,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (478,'eng-GB',2,169,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',2,170,154,'Careers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',2,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',2,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',3,170,154,'Careers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',3,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n  <paragraph>Send an application by email to careers@mycompany.my</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',3,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',4,170,154,'Careers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',4,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We are a company that handle business all around the world. Therefore the career opportunities in this company are diverse.</paragraph>\n  <paragraph>We want to provide our employees with the best possible opportunity to develop your own skills and knowledge so that both you and My company can benefit from it. We want people that shows initiative and that wants to feel happy for working with us.</paragraph>\n  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n  <paragraph>Send an application by email to careers@mycompany.my</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',4,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',5,170,154,'Careers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',5,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We are a company that handle business all around the world. Therefore the career opportunities in this company are diverse.</paragraph>\n  <paragraph>We want to provide our employees with the best possible opportunity to develop your own skills and knowledge so that both you and My company can benefit from it. We want people that shows initiative and that wants to feel happy for working with us.</paragraph>\n  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n  <paragraph>Send an application by email to careers@mycompany.my</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',5,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (482,'eng-GB',1,171,1,'My company wins award',0,0);
INSERT INTO ezcontentobject_attribute VALUES (483,'eng-GB',1,171,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company have always had the vision that our co-workers make the company and make it successful. That must be the reason why this company was awarded &quot;The best place to work&quot; award from the city council for 2002.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (484,'eng-GB',1,171,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We believe that this shows that to many companies forget about their most valuable asset in the chase for profit; the co-workers.</paragraph>\n  <paragraph>As the director of this great company I am very proud of being a part of this. And I can promise that we will not stop doing this just because we won this award. We will only get better and with the staff we have I am sure we will make it.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (485,'eng-GB',1,171,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (486,'eng-GB',1,171,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (487,'eng-GB',1,172,1,'My company wins $ billion contract ',0,0);
INSERT INTO ezcontentobject_attribute VALUES (488,'eng-GB',1,172,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Miami, USA, My company today won a three-year, US$ 2 billion contract from Ad comp, the car manufactorer. &quot;This is a big step forward for us&quot; said the chairman Muggers.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (489,'eng-GB',1,172,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This agreement, My company will implement main modules, construct and install our Big case software on their main servers. The servers will be running on the Big solutions core.</paragraph>\n  <paragraph>&quot;This is just one more proof ofthat our quality and effors pay off. &quot;Building big modules with complex modifications has become one of our specialities.&quot;</paragraph>\n  <paragraph>This also means that we will need a lot more workers in the next few weeks.</paragraph>\n  <paragraph>The future is bright</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (490,'eng-GB',1,172,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (491,'eng-GB',1,172,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (461,'eng-GB',2,163,4,'Products',0,0);
INSERT INTO ezcontentobject_attribute VALUES (462,'eng-GB',2,163,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>HEre you can..</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (494,'eng-GB',1,174,4,'Servers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (495,'eng-GB',1,174,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (502,'eng-GB',1,178,4,'System administration',0,0);
INSERT INTO ezcontentobject_attribute VALUES (503,'eng-GB',1,178,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (443,'eng-GB',2,157,147,'',0,23.99);
INSERT INTO ezcontentobject_attribute VALUES (522,'eng-GB',1,186,154,'Programming',0,0);
INSERT INTO ezcontentobject_attribute VALUES (523,'eng-GB',1,186,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Our developers can be hired to create specific software for your company. We usually work in C++ and PHP but can also work with most other languages. Just ask us and we will help you.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (524,'eng-GB',1,186,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (519,'eng-GB',1,185,154,'Support',0,0);
INSERT INTO ezcontentobject_attribute VALUES (520,'eng-GB',1,185,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company can provide four different sorts of support. This way you are free to choose the support you want and pay the price you mean it&apos;s worth.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (521,'eng-GB',1,185,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (525,'eng-GB',1,187,154,'Sys admin',0,0);
INSERT INTO ezcontentobject_attribute VALUES (526,'eng-GB',1,187,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We have the best teckies availible from all aroundthe world. Our system administrators are available for remote administration of your server.</paragraph>\n  <paragraph>Let us help you do the &quot;hard&quot; work.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (527,'eng-GB',1,187,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (528,'eng-GB',1,188,154,'Feature request',0,0);
INSERT INTO ezcontentobject_attribute VALUES (529,'eng-GB',1,188,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>If you have other questions regarding the services, products and consulting work we do, do not hesitate to contact us.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (530,'eng-GB',1,188,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (444,'eng-GB',2,157,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (552,'eng-GB',2,157,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A travel guide to the remote areas of the world. Even if that means travelling right outside your doorstep. This book is aimed for those who wants to experience other things than others usually do.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (570,'eng-GB',2,192,142,'Server optimized',0,0);
INSERT INTO ezcontentobject_attribute VALUES (571,'eng-GB',2,192,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (572,'eng-GB',2,192,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a software package containing everything you need in order to run My company software quickly. You will get Linux, Mac or Windows as operating system, apache as webserver and mysql as the database backend.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (516,'eng-GB',1,184,154,'Consulting',0,0);
INSERT INTO ezcontentobject_attribute VALUES (517,'eng-GB',1,184,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company can provide four different sorts of support. This way you are free to choose the support you want and pay the price you mean it&apos;s worth.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (518,'eng-GB',1,184,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (434,'eng-GB',3,154,147,'',0,24.99);
INSERT INTO ezcontentobject_attribute VALUES (435,'eng-GB',3,154,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (551,'eng-GB',3,154,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A great tip for getting your ovn little Eden in your backyard. This book gives you lots of suggestions for this.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (440,'eng-GB',2,157,142,'Travel guide',0,0);
INSERT INTO ezcontentobject_attribute VALUES (441,'eng-GB',2,157,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (442,'eng-GB',2,157,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A travel guide to the remote areas of the world. Even if that means travelling right outside your doorstep. This book is aimed for those who wants to experience other things than others usually do. Hike the vast hills of Ireland or the deep forests in Colorado. Or visit a small bed and breakfast in a small cummunity in Banglore.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (429,'eng-GB',2,153,147,'',0,16);
INSERT INTO ezcontentobject_attribute VALUES (430,'eng-GB',2,153,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (549,'eng-GB',2,153,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Graris hos hosuam P. Si ponfecrei se, Casdactesine mac tam. Catili prae mantis iam que interra?\nsenatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim part</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (431,'eng-GB',3,154,142,'Peaceful waters',0,0);
INSERT INTO ezcontentobject_attribute VALUES (432,'eng-GB',3,154,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (433,'eng-GB',3,154,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A great tip for getting your ovn little Eden in your backyard. This book gives you lots of suggestions for this. What plants to have, what stones to use, what lawn is the best for playing on. The author also recommend to use water in different forms and sizes. It is very peaceful ang gives your backyard a hole different look and feel</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (428,'eng-GB',2,153,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Habefac tam. Tum am aucii te et auctus. Vivehebemorum hocura? Name te, forbis. Habi senatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim patruriam\npotiem se factuasdam aus auctum la puli publia nos stretil erra, et, C. Graris hos hosuam P. Si ponfecrei se, Casdactesine mac tam. Catili prae mantis iam que interra?\nsenatum ut L. Verfinemus opublicia? Quam poerfer icati, C. C. Catro, quit, fue tela maio esi intem re di, nestiu cupim part</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (419,'eng-GB',3,151,142,'eZ publish - a tutorial',0,0);
INSERT INTO ezcontentobject_attribute VALUES (420,'eng-GB',3,151,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (421,'eng-GB',3,151,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a tutorial for the professional content management system eZ publish. Written by the developers ofthe system this book gives you the best insight possible. The book is written for everyone that uses or wil use eZ publish. The book takes you from downloading the software to your site is set up and optimized.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (422,'eng-GB',3,151,147,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (423,'eng-GB',3,151,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (548,'eng-GB',3,151,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a tutorial for the professional content management system eZ publish. Written by the developers ofthe system this book gives you the best insight possible.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (426,'eng-GB',2,153,142,'Color is everything',0,0);
INSERT INTO ezcontentobject_attribute VALUES (427,'eng-GB',2,153,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (546,'eng-GB',5,150,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',5,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',5,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',4,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',4,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (546,'eng-GB',4,150,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',5,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',5,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',5,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (536,'eng-GB',1,125,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (537,'eng-GB',2,125,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (538,'eng-GB',3,125,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (539,'eng-GB',1,148,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (540,'eng-GB',2,148,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (541,'eng-GB',3,148,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (542,'eng-GB',4,148,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (543,'eng-GB',5,148,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (544,'eng-GB',1,150,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (545,'eng-GB',2,150,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (546,'eng-GB',3,150,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (547,'eng-GB',1,151,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (548,'eng-GB',2,151,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (549,'eng-GB',1,153,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (550,'eng-GB',1,154,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (551,'eng-GB',2,154,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (552,'eng-GB',1,157,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (553,'eng-GB',1,158,157,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',4,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS? \nThis books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',4,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (574,'eng-GB',2,192,147,'',0,34489);
INSERT INTO ezcontentobject_attribute VALUES (575,'eng-GB',2,192,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (461,'eng-GB',3,163,4,'Products',0,0);
INSERT INTO ezcontentobject_attribute VALUES (462,'eng-GB',3,163,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company provides advanced software for all kinds of customers. We offer solutions for most demands to give you easier access and control to your websites and content. Here you will find the powerful Server optimized beteen other powerful products.</paragraph>\n  <paragraph>Our product portfolio grows every day so you can be sure that we will have the product you need.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',4,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (573,'eng-GB',2,192,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a Linux distribution based on the Secure SoftLinux from My company. This linux server provides a secure, fast and easy way of getting the programs up and running in no time. My company software system is installed by default, configured and is ready to use as soon as the installation is complete.</paragraph>\n  <paragraph>My company Server optimizedalso comes with a fast log file analysis program, Herbalizer. Herbalizer is also configured and is ready to go after installation.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (573,'eng-GB',1,192,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a Linux distribution based on the Secure SoftLinux from My company. This linux server provides a secure, fast and easy way of getting the programs up and running in no time. My company software system is installed by default, configured and is ready to use as soon as the installation is complete.</paragraph>\n  <paragraph>My company Server optimizedalso comes with a fast log file analysis program, Herbalizer. Herbalizer is also configured and is ready to go after installation.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (574,'eng-GB',1,192,147,'',0,34489);
INSERT INTO ezcontentobject_attribute VALUES (575,'eng-GB',1,192,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (572,'eng-GB',1,192,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a software package containing everything you need in order to run My company software quickly. You will get Linux, Mac or Windows as operating system, apache as webserver and mysql as the database backend.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (571,'eng-GB',1,192,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (570,'eng-GB',1,192,142,'Server optimized',0,0);
INSERT INTO ezcontentobject_attribute VALUES (564,'eng-GB',1,191,142,'My company desktop editor',0,0);
INSERT INTO ezcontentobject_attribute VALUES (565,'eng-GB',1,191,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (566,'eng-GB',1,191,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company desktop edition is a WYSIWYG (What You See Is What You Get) editor that you can connect to your eZ publish content management system.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (567,'eng-GB',1,191,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>DE lets you edit articles and images on your  web site through a familiar browser and word processing interface.</paragraph>\n  <paragraph>    <strong>Benefits of Desktop Edition</strong>\n</paragraph>\n  <paragraph>The desktop edition editor lets you see more or less how the article will look on your site. The desktop edition can also open a web browser for previews of the resulting page. You can use DE for browsing the categories of articles and images of your site.</paragraph>\n  <paragraph>The desktop edition editor feels almost like an ordinary word processor which makes it really easy to learn. The article and image browsers immitate the functions of other file and image browsers. DE will make editing articles for your web site even easier.</paragraph>\n  <paragraph>    <strong>Requirements</strong>\n</paragraph>\n  <paragraph>Supported operating systems are Linux x86, Win32 (Windows 95, 98, NT, Me, 2000 and XP), and Mac OS X 10.1.x.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (568,'eng-GB',1,191,147,'',0,2999);
INSERT INTO ezcontentobject_attribute VALUES (569,'eng-GB',1,191,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (445,'eng-GB',2,158,142,'Animal planet',0,0);
INSERT INTO ezcontentobject_attribute VALUES (446,'eng-GB',2,158,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (447,'eng-GB',2,158,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>See the world through the eyes of the animals. Visit different parts of our planet and get to know the animals that live there. The animal planet is much more exiting that we ever imagine.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (448,'eng-GB',2,158,147,'',0,9.99);
INSERT INTO ezcontentobject_attribute VALUES (449,'eng-GB',2,158,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (553,'eng-GB',2,158,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>See the world through the eyes of the animals. Visit different parts of our planet and get to know the animals that live there.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (340,'eng-GB',4,125,142,'The thriller book',0,0);
INSERT INTO ezcontentobject_attribute VALUES (341,'eng-GB',4,125,144,'102120',0,0);
INSERT INTO ezcontentobject_attribute VALUES (342,'eng-GB',4,125,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is a real thriller. If you like being scared this paperback is the thing for you. 20 short stories that will make you crawl and regret that you ever opened the book. Do not read this book late at night</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (343,'eng-GB',4,125,147,'',0,12);
INSERT INTO ezcontentobject_attribute VALUES (344,'eng-GB',4,125,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (537,'eng-GB',4,125,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>If you like being scared this paperback is the thing for you. 20 short stories that will make you crawl and regret that you ever opened the book.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',6,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',6,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',6,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A book about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes?\nDo you imagine the sounds- or are they real?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',6,148,147,'',0,29);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',6,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (543,'eng-GB',6,148,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>What happens when you find yourself lost in the forest and the fog comes?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',6,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',6,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',6,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',6,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',6,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (546,'eng-GB',6,150,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (414,'eng-GB',7,150,142,'How to make a perfect CMS solution',0,0);
INSERT INTO ezcontentobject_attribute VALUES (415,'eng-GB',7,150,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (416,'eng-GB',7,150,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This books will get you on the way. Packed with tips, clues and suggestions this is the only book you&apos;ll ever need when making a CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (417,'eng-GB',7,150,147,'',0,39);
INSERT INTO ezcontentobject_attribute VALUES (418,'eng-GB',7,150,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (546,'eng-GB',7,150,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Ever wondered how to make a good CMS?\nThis book will give you some clues on how to do exactly that.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (407,'eng-GB',7,148,142,'Forest fog',0,0);
INSERT INTO ezcontentobject_attribute VALUES (408,'eng-GB',7,148,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (409,'eng-GB',7,148,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A book about the mysterious sounds and sights that can hide in a deep and dark forest. What happens when you find yourself lost in the forest and the fog comes?\nDo you imagine the sounds- or are they real?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (410,'eng-GB',7,148,147,'',0,29);
INSERT INTO ezcontentobject_attribute VALUES (411,'eng-GB',7,148,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (543,'eng-GB',7,148,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>What happens when you find yourself lost in the forest and the fog comes?</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (445,'eng-GB',3,158,142,'Animal planet',0,0);
INSERT INTO ezcontentobject_attribute VALUES (446,'eng-GB',3,158,144,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (447,'eng-GB',3,158,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>See the world through the eyes of the animals. Visit different parts of our planet and get to know the animals that live there. The animal planet is much more exiting that we ever imagine.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (448,'eng-GB',3,158,147,'',0,9.99);
INSERT INTO ezcontentobject_attribute VALUES (449,'eng-GB',3,158,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (553,'eng-GB',3,158,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>See the world through the eyes of the animals. Visit different parts of our planet and get to know the animals that live there.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (582,'eng-GB',1,194,128,'New topic',0,0);
INSERT INTO ezcontentobject_attribute VALUES (583,'eng-GB',1,194,129,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (589,'eng-GB',1,196,4,'Links',0,0);
INSERT INTO ezcontentobject_attribute VALUES (590,'eng-GB',1,196,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (591,'eng-GB',1,197,158,'eZ systems',0,0);
INSERT INTO ezcontentobject_attribute VALUES (592,'eng-GB',1,197,159,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The creators of eZ publish.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (593,'eng-GB',1,197,160,'ez.no',2,0);
INSERT INTO ezcontentobject_attribute VALUES (564,'eng-GB',2,191,142,'My company desktop editor',0,0);
INSERT INTO ezcontentobject_attribute VALUES (565,'eng-GB',2,191,144,'RG 23987',0,0);
INSERT INTO ezcontentobject_attribute VALUES (598,'eng-GB',1,200,1,'Test article',0,0);
INSERT INTO ezcontentobject_attribute VALUES (599,'eng-GB',1,200,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>this is a small and short test on how to make the 4th level</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (600,'eng-GB',1,200,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>this is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th levelthis is a small and short test on how to make the 4th level</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (601,'eng-GB',1,200,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (602,'eng-GB',1,200,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (566,'eng-GB',2,191,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company desktop edition is a WYSIWYG (What You See Is What You Get) editor that you can connect to your eZ publish content management system.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (567,'eng-GB',2,191,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>DE lets you edit articles and images on your  web site through a familiar browser and word processing interface.</paragraph>\n  <paragraph>    <strong>Benefits of Desktop Edition</strong>\n</paragraph>\n  <paragraph>The desktop edition editor lets you see more or less how the article will look on your site. The desktop edition can also open a web browser for previews of the resulting page. You can use DE for browsing the categories of articles and images of your site.</paragraph>\n  <paragraph>The desktop edition editor feels almost like an ordinary word processor which makes it really easy to learn. The article and image browsers immitate the functions of other file and image browsers. DE will make editing articles for your web site even easier.</paragraph>\n  <paragraph>    <strong>Requirements</strong>\n</paragraph>\n  <paragraph>Supported operating systems are Linux x86, Win32 (Windows 95, 98, NT, Me, 2000 and XP), and Mac OS X 10.1.x.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (568,'eng-GB',2,191,147,'',0,2999);
INSERT INTO ezcontentobject_attribute VALUES (569,'eng-GB',2,191,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (603,'eng-GB',1,201,158,'eZ publish',0,0);
INSERT INTO ezcontentobject_attribute VALUES (604,'eng-GB',1,201,159,'<?xml version=\"1.0\"?>\n<section>  <paragraph>An open source web application toolkit and CMS.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (605,'eng-GB',1,201,160,'ez.no/developer',3,0);
INSERT INTO ezcontentobject_attribute VALUES (570,'eng-GB',3,192,142,'Server optimized',0,0);
INSERT INTO ezcontentobject_attribute VALUES (571,'eng-GB',3,192,144,'TGB 21',0,0);
INSERT INTO ezcontentobject_attribute VALUES (572,'eng-GB',3,192,157,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a software package containing everything you need in order to run My company software quickly. You will get Linux, Mac or Windows as operating system, apache as webserver and mysql as the database backend.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (573,'eng-GB',3,192,145,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company Server optimized is a Linux distribution based on the Secure SoftLinux from My company. This linux server provides a secure, fast and easy way of getting the programs up and running in no time. My company software system is installed by default, configured and is ready to use as soon as the installation is complete.</paragraph>\n  <paragraph>My company Server optimizedalso comes with a fast log file analysis program, Herbalizer. Herbalizer is also configured and is ready to go after installation.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (574,'eng-GB',3,192,147,'',0,34489);
INSERT INTO ezcontentobject_attribute VALUES (575,'eng-GB',3,192,148,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (465,'eng-GB',2,165,4,'Services',0,0);
INSERT INTO ezcontentobject_attribute VALUES (466,'eng-GB',2,165,119,'<?xml version=\"1.0\"?>\n<section>  <paragraph>My company and the official partners have highly skilled co-workers ready to advise you. Whatever your problem is, we can help.</paragraph>\n  <paragraph>My company delivers a wide range of serices to make your daily usage of the systems easy. We provide professional training, helping you utilize the possibilities in both you as individuals and the solutions.</paragraph>\n  <paragraph>One of the services we offer is the professional support. Within the support services you can choose the support type you need. And you wil gget the help you deserve from the developers themselves.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (606,'eng-GB',1,202,154,'About this forum',0,0);
INSERT INTO ezcontentobject_attribute VALUES (607,'eng-GB',1,202,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This forum is for discussion, bet you didn&apos;t figure that out.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (608,'eng-GB',1,202,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (479,'eng-GB',6,170,154,'Careers',0,0);
INSERT INTO ezcontentobject_attribute VALUES (480,'eng-GB',6,170,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>We are a company that handle business all around the world. Therefore the career opportunities in this company are diverse.</paragraph>\n  <paragraph>We want to provide our employees with the best possible opportunity to develop your own skills and knowledge so that both you and My company can benefit from it. We want people that shows initiative and that wants to feel happy for working with us.</paragraph>\n  <paragraph>My company is always looking for good co-workers.</paragraph>\n  <paragraph>If you are a person that thing you have something to offer please do not hesitate to send us an application.</paragraph>\n  <paragraph>Do you have the skill to make us better?</paragraph>\n  <paragraph>Send an application by email to careers@mycompany.my</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (481,'eng-GB',6,170,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (476,'eng-GB',3,169,154,'About',0,0);
INSERT INTO ezcontentobject_attribute VALUES (477,'eng-GB',3,169,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Welcome to My company</paragraph>\n  <paragraph>My company is a leader in technology that enable programming and industry customers to improve performance and satisfaction while lowering costs and time spend.</paragraph>\n  <paragraph>My company is located in downtown Metropolis and we operate in about 65 countries and employ around 1,000 people.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (478,'eng-GB',3,169,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (609,'eng-GB',1,203,4,'My Intranet',0,0);
INSERT INTO ezcontentobject_attribute VALUES (610,'eng-GB',1,203,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (611,'eng-GB',1,204,4,'News',0,0);
INSERT INTO ezcontentobject_attribute VALUES (612,'eng-GB',1,204,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (613,'eng-GB',1,205,4,'Files',0,0);
INSERT INTO ezcontentobject_attribute VALUES (614,'eng-GB',1,205,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (615,'eng-GB',1,206,161,'Important document',0,0);
INSERT INTO ezcontentobject_attribute VALUES (616,'eng-GB',1,206,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is the most important document ever written.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (617,'eng-GB',1,206,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (618,'eng-GB',1,207,1,'This months budget',0,0);
INSERT INTO ezcontentobject_attribute VALUES (619,'eng-GB',1,207,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is just a reminder for you all to send in the latest numbers for this month. No delays are accepted.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (620,'eng-GB',1,207,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>The numbers need to include:\n- Total sales\n- Total sales in $\n- Sales per product\n- Total calls made\n- Breakthrough rate (How many have bought)\n- Returns\n- Estimates for the next month</paragraph>\n  <paragraph>These numbers have to be in my mailbox before 1600 today.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (621,'eng-GB',1,207,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (622,'eng-GB',1,207,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (623,'eng-GB',1,208,1,'Wine lottery today',0,0);
INSERT INTO ezcontentobject_attribute VALUES (624,'eng-GB',1,208,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Today we introduce the best wine lottery ever. The success of the lottery brings the wine quality one step up.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (625,'eng-GB',1,208,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Since so many of you have joined this lottery earlier we will make it even more fun this time. In addition to the wine we also give away cheese and cracers to the lucky winners.</paragraph>\n  <paragraph>Drop by my office if you want to purchase a chance to win high quality wine. You can also send me an e-mail if you are prevented from coming.</paragraph>\n  <paragraph>The lottery ticket only cost $ 2.</paragraph>\n  <paragraph>Linda Loo</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (626,'eng-GB',1,208,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (627,'eng-GB',1,208,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (628,'eng-GB',1,209,161,'Document template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (629,'eng-GB',1,209,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A template you can use when creating very large documents.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (630,'eng-GB',1,209,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (628,'eng-GB',2,209,161,'Document template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (629,'eng-GB',2,209,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A template you can use when creating very large documents.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (630,'eng-GB',2,209,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (628,'eng-GB',3,209,161,'Document template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (629,'eng-GB',3,209,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>A template you can use when creating very large documents.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (630,'eng-GB',3,209,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (631,'eng-GB',1,210,161,'Another template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (632,'eng-GB',1,210,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Just another dummy text file for your amusement.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (633,'eng-GB',1,210,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (631,'eng-GB',2,210,161,'Another template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (632,'eng-GB',2,210,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Just another dummy text file for your amusement.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (633,'eng-GB',2,210,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (631,'eng-GB',3,210,161,'Another template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (632,'eng-GB',3,210,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Just another dummy text file for your amusement.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (633,'eng-GB',3,210,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (631,'eng-GB',4,210,161,'Another template',0,0);
INSERT INTO ezcontentobject_attribute VALUES (632,'eng-GB',4,210,162,'<?xml version=\"1.0\"?>\n<section>  <paragraph>Just another dummy text file for your amusement.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (633,'eng-GB',4,210,163,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (634,'eng-GB',1,211,1,'Meeting today at 13',0,0);
INSERT INTO ezcontentobject_attribute VALUES (635,'eng-GB',1,211,120,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is an update for those of you who didn&apos;t attend todays meeting.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (636,'eng-GB',1,211,121,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This was the first &quot;Monday-meeting&quot; in the new year.</paragraph>\n  <paragraph>1. First of all the CEO wished us all a very heppy new year. He also told us shortly about the plans for this year. You will getthat in another memo by e-mail later today or tomorrow.</paragraph>\n  <paragraph>2. a suggestion was that we need to get better when we talk about internal communiucation. To many errors and mistakes come from bad communication. We all have to get betterat this. Inform eachother and at least your manager.</paragraph>\n  <paragraph>PROJECTS: \n- Didi.net: Lot&apos;s of work to do, Tre hope they can have something to show up on Friday and everything should be under control :)\n- Dimm Media: Arthurs and Timm will show them the many fancy things in our new software. This projects wil include most of you and are therefore the number one priority this week.\n- Green lawn: Simmson are going set up an accounting system for them.\n- Billingsaccout: They will visit us today so keep your desks clean and tidy. First impression is everything. We need to get this customer because of the money he will bring in.</paragraph>\n  <paragraph>INTERNAL:\n- The new kitchen help will begin today. Give her the support she needs and do not get angry with her if she makes mistakes on her first day.</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (637,'eng-GB',1,211,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (638,'eng-GB',1,211,123,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (639,'eng-GB',1,212,4,'My site',0,0);
INSERT INTO ezcontentobject_attribute VALUES (640,'eng-GB',1,212,119,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (641,'eng-GB',1,213,154,'About me',0,0);
INSERT INTO ezcontentobject_attribute VALUES (642,'eng-GB',1,213,155,'<?xml version=\"1.0\"?>\n<section />',0,0);
INSERT INTO ezcontentobject_attribute VALUES (643,'eng-GB',1,213,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (644,'eng-GB',1,214,154,'Portfolio',0,0);
INSERT INTO ezcontentobject_attribute VALUES (645,'eng-GB',1,214,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>I&apos;ve done this and that..</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (646,'eng-GB',1,214,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (641,'eng-GB',2,213,154,'About me',0,0);
INSERT INTO ezcontentobject_attribute VALUES (642,'eng-GB',2,213,155,'<?xml version=\"1.0\"?>\n<section>  <paragraph>This is me...</paragraph>\n</section>\n',0,0);
INSERT INTO ezcontentobject_attribute VALUES (643,'eng-GB',2,213,156,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (294,'eng-GB',3,113,1,'Food for the soul',0,0);
INSERT INTO ezcontentobject_attribute VALUES (295,'eng-GB',3,113,120,'<?xml version=\"1.0\" charset=\"UTF-8\"?>\n<section>\n  <paragraph>Soulfood.no is a result of a passionate interest for photography and people. This interesting site runs on eZ publish and is a very good example on what you can do with content and design on an eZ publish powered site.</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (296,'eng-GB',3,113,121,'<?xml version=\"1.0\" charset=\"UTF-8\"?>\n<section>\n  <paragraph>Christian Houge, b. 1972, is a freelance photographer educated in USA and have worked with advertising, portraits and travelling since 1994. \nOn his last travel, during the winter of 1999, Houge spend six months with the exile tibetanians in the South and North India as well as in Nepal. Many of his pictures are influenced by this visit. For long periods of this stay he lived in a tibetanian monastery as the only western representative and he got an insight in the daily life of the munks.</paragraph>\n  <paragraph>The design for this site is made by Sigurd Kristiansen Superstar.no and has been set up by one of eZ systems official partners Petraflux.com \neZ systems has assisted our partner with support. Automatical image import was created amongst other things.</paragraph>\n  <paragraph>Visit Soulfood</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (297,'eng-GB',3,113,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (298,'eng-GB',3,113,123,'',1,0);
INSERT INTO ezcontentobject_attribute VALUES (647,'eng-GB',1,215,164,'First post!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (648,'eng-GB',1,215,165,'This is a comment.',0,0);
INSERT INTO ezcontentobject_attribute VALUES (649,'eng-GB',1,215,166,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (650,'eng-GB',1,216,164,'My comment',0,0);
INSERT INTO ezcontentobject_attribute VALUES (651,'eng-GB',1,216,166,'John Doe',0,0);
INSERT INTO ezcontentobject_attribute VALUES (652,'eng-GB',1,216,165,'I\'m the first poster!',0,0);
INSERT INTO ezcontentobject_attribute VALUES (309,'eng-GB',5,116,1,'Collaboration in eZ publish',0,0);
INSERT INTO ezcontentobject_attribute VALUES (310,'eng-GB',5,116,120,'<?xml version=\"1.0\" encoding=\"iso-8859-15\"?>\n<section>\n  <paragraph>There are many things happening around the world. This article is one of them. This is an article about writing articles in this generation of eZ publish.</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (311,'eng-GB',5,116,121,'<?xml version=\"1.0\" encoding=\"iso-8859-15\"?>\n<section>\n  <paragraph>Take one example on what you can use eZ publish for; collaboration. An editor wants to make a story on emigrationShe assigns the following tasks:Photograph Joe: take picturesJournalist Peter: write storyJournalsit Sally: get background statistics</paragraph>\n  <paragraph>Upon completion the editor will receive the complete article and may choose to publish the story or reject with comments.Collaboration may also be used for many other processes, such as distributing tasks in a support service, handling of requests from customers, or invitations to meetings/events.</paragraph>\n  <paragraph>This way the employees in a newspaper can collaborate on an article about water</paragraph>\n</section>',1045487555,0);
INSERT INTO ezcontentobject_attribute VALUES (312,'eng-GB',5,116,122,'',0,0);
INSERT INTO ezcontentobject_attribute VALUES (313,'eng-GB',5,116,123,'',0,0);

#
# Table structure for table 'ezcontentobject_link'
#

CREATE TABLE ezcontentobject_link (
  id int(11) NOT NULL auto_increment,
  from_contentobject_id int(11) NOT NULL default '0',
  from_contentobject_version int(11) NOT NULL default '0',
  to_contentobject_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject_link'
#

INSERT INTO ezcontentobject_link VALUES (1,79,2,31);
INSERT INTO ezcontentobject_link VALUES (2,79,2,32);
INSERT INTO ezcontentobject_link VALUES (3,79,2,33);
INSERT INTO ezcontentobject_link VALUES (4,79,2,47);
INSERT INTO ezcontentobject_link VALUES (5,79,2,54);
INSERT INTO ezcontentobject_link VALUES (6,79,2,55);
INSERT INTO ezcontentobject_link VALUES (7,79,2,56);
INSERT INTO ezcontentobject_link VALUES (8,39,6,79);
INSERT INTO ezcontentobject_link VALUES (9,34,4,34);
INSERT INTO ezcontentobject_link VALUES (10,34,4,35);
INSERT INTO ezcontentobject_link VALUES (11,34,4,36);
INSERT INTO ezcontentobject_link VALUES (12,32,10,102);
INSERT INTO ezcontentobject_link VALUES (13,32,10,106);
INSERT INTO ezcontentobject_link VALUES (14,32,10,107);
INSERT INTO ezcontentobject_link VALUES (15,32,10,124);
INSERT INTO ezcontentobject_link VALUES (16,119,3,102);
INSERT INTO ezcontentobject_link VALUES (17,119,3,106);
INSERT INTO ezcontentobject_link VALUES (18,119,3,107);
INSERT INTO ezcontentobject_link VALUES (19,119,3,124);
INSERT INTO ezcontentobject_link VALUES (20,31,11,118);
INSERT INTO ezcontentobject_link VALUES (21,31,11,31);
INSERT INTO ezcontentobject_link VALUES (35,169,3,95);
INSERT INTO ezcontentobject_link VALUES (34,169,3,94);
INSERT INTO ezcontentobject_link VALUES (33,170,6,89);
INSERT INTO ezcontentobject_link VALUES (32,170,6,87);
INSERT INTO ezcontentobject_link VALUES (31,170,6,86);
INSERT INTO ezcontentobject_link VALUES (36,169,3,96);

#
# Table structure for table 'ezcontentobject_name'
#

CREATE TABLE ezcontentobject_name (
  contentobject_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  content_version int(11) NOT NULL default '0',
  content_translation varchar(20) NOT NULL default '',
  real_translation varchar(20) default NULL,
  PRIMARY KEY  (contentobject_id,content_version,content_translation)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject_name'
#

INSERT INTO ezcontentobject_name VALUES (1,'My folder',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (4,'Users',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (10,'Anonymous User',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (11,'Guest accounts',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (12,'Administrator users',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (13,'Editors',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (14,'Administrator User',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (15,'White box',5,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (17,'Flowers',4,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (23,'News',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (25,'Frontpage',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (26,'Sport',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (29,'World news',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (30,'Crossroads forum',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (31,'Forums',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (57,'',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (62,'The Book Corner',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (63,'Thriller',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (64,'Bestsellers',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (65,'Recommendations',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (83,'Whitebox contemporary art gallery',5,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (84,'Forest',5,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (85,'Forest 1',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (86,'Flower 1',5,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (87,'Flower 2',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (88,'',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (89,'',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (90,'Forest 2',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (91,'Forest 3',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (92,'Forest 4',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (93,'Water',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (94,'Water 1',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (95,'Water 2',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (96,'Water 3',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (97,'Water 4',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (98,'Animals',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (99,'Animal 1',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (100,'Animal 2',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (101,'Animal 3',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (102,'Animal 4',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (103,'Landscape',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (104,'Landscape 1',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (105,'Landscape 2',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (106,'Landscape 3',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (107,'Landscape 4',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (109,'New article',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (110,'Action',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (111,'eZ systems travel company',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (112,'Leisure',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (113,'Food for the soul',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (114,'We did it again',4,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (115,'eZ publish 3.0',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (116,'eZ systems and Siemens partner up',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (117,'New article',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (118,'Sports',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (119,'Computers',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (120,'Games',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (121,'Politics',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (122,'Formula 1 2003',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (123,'A weekend in the mountain',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (125,'The thriller book',4,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (127,'I\'ve read this book',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (128,'Sports weekend',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (131,'The best football team in England',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (132,'Are sports for idiots ?',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (133,'Computer nerds',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (134,'Without computers the world stops',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (135,'Colin McRae Rally 3',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (136,'Games should be done outside',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (137,'Politics are boring',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (139,'I do not agree !!!',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (140,'Without politics chaos will rule',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (141,'Yes, and it is great',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (142,'Yes',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (143,'I agree',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (144,'Hmmm',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (145,'Test',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (146,'Not !',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (148,'Forest fog',7,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (149,'Computers',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (150,'How to make a perfect CMS solution',7,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (151,'eZ publish - a tutorial',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (152,'House and garden',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (153,'Color is everything',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (154,'Peaceful waters',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (155,'Ferrari or BMW ?',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (156,'Travel',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (157,'Travel guide',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (158,'Animal planet',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (160,'My company',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (161,'News',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (162,'This is our latest customer',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (163,'Products',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (164,'Software',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (165,'Services',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (169,'About',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (170,'Careers',6,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (171,'My company wins award',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (172,'My company wins $ billion contract',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (174,'Servers',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (184,'Consulting',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (185,'Support',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (186,'Programming',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (187,'Sys admin',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (188,'Feature request',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (191,'My company desktop editor',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (192,'Server optimized',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (196,'Links',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (197,'eZ systems',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (201,'eZ publish',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (202,'About this forum',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (203,'My Intranet',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (204,'News',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (205,'Files',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (206,'Important document',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (207,'This months budget',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (208,'Wine lottery today',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (209,'Document template',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (210,'Another template',4,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (211,'Meeting today at 13',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (212,'My site',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (212,'My site',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (212,'My site',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (214,'Portfolio',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (214,'Portfolio',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (214,'Portfolio',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',2,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (213,'About me',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (1,'My folder',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (4,'Users',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (10,'Anonymous User',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (11,'Guest accounts',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (12,'Administrator users',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (13,'Editors',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (14,'Administrator User',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (15,'White box',5,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (17,'Flowers',4,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (23,'News',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (25,'Frontpage',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (26,'Sport',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (29,'World news',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (30,'Crossroads forum',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (31,'Forums',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (57,'',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (62,'The Book Corner',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (63,'Thriller',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (64,'Bestsellers',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (65,'Recommendations',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (83,'Whitebox contemporary art gallery',5,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (84,'Forest',5,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (85,'Forest 1',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (86,'Flower 1',5,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (87,'Flower 2',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (88,'',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (89,'',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (90,'Forest 2',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (91,'Forest 3',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (92,'Forest 4',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (93,'Water',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (94,'Water 1',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (95,'Water 2',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (96,'Water 3',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (97,'Water 4',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (98,'Animals',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (99,'Animal 1',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (100,'Animal 2',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (101,'Animal 3',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (102,'Animal 4',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (103,'Landscape',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (104,'Landscape 1',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (105,'Landscape 2',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (106,'Landscape 3',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (107,'Landscape 4',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (109,'New article',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (110,'Action',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (111,'eZ systems travel company',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (112,'Leisure',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (113,'Food for the soul',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (114,'We did it again',4,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (115,'eZ publish 3.0',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (116,'eZ systems and Siemens partner up',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (117,'New article',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (118,'Sports',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (119,'Computers',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (120,'Games',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (121,'Politics',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (122,'Formula 1 2003',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (123,'A weekend in the mountain',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (125,'The thriller book',4,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (127,'I\'ve read this book',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (128,'Sports weekend',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (131,'The best football team in England',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (132,'Are sports for idiots ?',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (133,'Computer nerds',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (134,'Without computers the world stops',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (135,'Colin McRae Rally 3',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (136,'Games should be done outside',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (137,'Politics are boring',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (139,'I do not agree !!!',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (140,'Without politics chaos will rule',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (141,'Yes, and it is great',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (142,'Yes',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (143,'I agree',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (144,'Hmmm',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (145,'Test',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (146,'Not !',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (148,'Forest fog',7,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (149,'Computers',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (150,'How to make a perfect CMS solution',7,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (151,'eZ publish - a tutorial',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (152,'House and garden',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (153,'Color is everything',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (154,'Peaceful waters',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (155,'Ferrari or BMW ?',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (156,'Travel',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (157,'Travel guide',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (158,'Animal planet',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (160,'My company',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (161,'News',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (162,'This is our latest customer',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (163,'Products',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (164,'Software',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (165,'Services',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (169,'About',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (170,'Careers',6,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (171,'My company wins award',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (172,'My company wins $ billion contract',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (174,'Servers',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (184,'Consulting',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (185,'Support',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (186,'Programming',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (187,'Sys admin',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (188,'Feature request',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (191,'My company desktop editor',2,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (192,'Server optimized',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (196,'Links',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (197,'eZ systems',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (201,'eZ publish',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (202,'About this forum',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (203,'My Intranet',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (204,'News',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (205,'Files',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (206,'Important document',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (207,'This months budget',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (208,'Wine lottery today',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (209,'Document template',3,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (210,'Another template',4,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (211,'Meeting today at 13',1,'eng-US','eng-GB');
INSERT INTO ezcontentobject_name VALUES (1,'My folder',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (4,'Users',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (10,'Anonymous User',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (11,'Guest accounts',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (12,'Administrator users',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (13,'Editors',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (14,'Administrator User',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (15,'White box',5,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (17,'Flowers',4,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (23,'News',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (25,'Frontpage',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (26,'Sport',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (29,'World news',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (30,'Crossroads forum',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (31,'Forums',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (57,'',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (62,'The Book Corner',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (63,'Thriller',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (64,'Bestsellers',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (65,'Recommendations',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (83,'Whitebox contemporary art gallery',5,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (84,'Forest',5,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (85,'Forest 1',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (86,'Flower 1',5,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (87,'Flower 2',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (88,'',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (89,'',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (90,'Forest 2',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (91,'Forest 3',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (92,'Forest 4',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (93,'Water',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (94,'Water 1',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (95,'Water 2',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (96,'Water 3',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (97,'Water 4',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (98,'Animals',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (99,'Animal 1',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (100,'Animal 2',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (101,'Animal 3',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (102,'Animal 4',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (103,'Landscape',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (104,'Landscape 1',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (105,'Landscape 2',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (106,'Landscape 3',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (107,'Landscape 4',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (109,'New article',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (110,'Action',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (111,'eZ systems travel company',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (112,'Leisure',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (113,'Food for the soul',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (114,'We did it again',4,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (115,'eZ publish 3.0',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (116,'eZ systems and Siemens partner up',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (117,'New article',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (118,'Sports',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (119,'Computers',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (120,'Games',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (121,'Politics',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (122,'Formula 1 2003',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (123,'A weekend in the mountain',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (125,'The thriller book',4,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (127,'I\'ve read this book',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (128,'Sports weekend',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (131,'The best football team in England',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (132,'Are sports for idiots ?',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (133,'Computer nerds',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (134,'Without computers the world stops',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (135,'Colin McRae Rally 3',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (136,'Games should be done outside',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (137,'Politics are boring',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (139,'I do not agree !!!',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (140,'Without politics chaos will rule',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (141,'Yes, and it is great',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (142,'Yes',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (143,'I agree',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (144,'Hmmm',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (145,'Test',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (146,'Not !',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (148,'Forest fog',7,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (149,'Computers',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (150,'How to make a perfect CMS solution',7,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (151,'eZ publish - a tutorial',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (152,'House and garden',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (153,'Color is everything',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (154,'Peaceful waters',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (155,'Ferrari or BMW ?',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (156,'Travel',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (157,'Travel guide',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (158,'Animal planet',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (160,'My company',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (161,'News',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (162,'This is our latest customer',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (163,'Products',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (164,'Software',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (165,'Services',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (169,'About',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (170,'Careers',6,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (171,'My company wins award',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (172,'My company wins $ billion contract',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (174,'Servers',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (184,'Consulting',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (185,'Support',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (186,'Programming',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (187,'Sys admin',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (188,'Feature request',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (191,'My company desktop editor',2,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (192,'Server optimized',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (196,'Links',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (197,'eZ systems',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (201,'eZ publish',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (202,'About this forum',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (203,'My Intranet',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (204,'News',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (205,'Files',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (206,'Important document',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (207,'This months budget',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (208,'Wine lottery today',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (209,'Document template',3,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (210,'Another template',4,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (211,'Meeting today at 13',1,'nor-NO','eng-GB');
INSERT INTO ezcontentobject_name VALUES (113,'Food for the soul',3,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (215,'First post!',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (216,'My comment',1,'eng-GB','eng-GB');
INSERT INTO ezcontentobject_name VALUES (116,'Collaboration in eZ publish',5,'eng-GB','eng-GB');

#
# Table structure for table 'ezcontentobject_tree'
#

CREATE TABLE ezcontentobject_tree (
  node_id int(11) NOT NULL auto_increment,
  parent_node_id int(11) NOT NULL default '0',
  contentobject_id int(11) default NULL,
  contentobject_version int(11) default NULL,
  contentobject_is_published int(11) default NULL,
  crc32_path int(11) default NULL,
  depth int(11) NOT NULL default '0',
  path_string varchar(255) NOT NULL default '',
  path_identification_string text,
  sort_order int(1) default '1',
  sort_field int(11) default '1',
  priority int(11) NOT NULL default '0',
  main_node_id int(11) default NULL,
  md5_path varchar(32) default NULL,
  PRIMARY KEY  (node_id),
  KEY ezcontentobject_tree_path (path_string),
  KEY ezcontentobject_tree_p_node_id (parent_node_id),
  KEY ezcontentobject_tree_co_id (contentobject_id),
  KEY ezcontentobject_tree_depth (depth),
  KEY ezcontentobject_tree_crc32_path (crc32_path),
  KEY md5_path (md5_path),
  KEY md5_path_2 (md5_path)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject_tree'
#

INSERT INTO ezcontentobject_tree VALUES (1,1,0,1,1,NULL,0,'/1/',NULL,1,1,0,1,NULL);
INSERT INTO ezcontentobject_tree VALUES (2,1,1,3,1,0,1,'/1/2/','',1,8,0,2,'edb72a68a9cfaab392fe8cf95baeb80d');
INSERT INTO ezcontentobject_tree VALUES (5,1,4,1,0,-195235522,1,'/1/5/','__1',1,1,0,5,'');
INSERT INTO ezcontentobject_tree VALUES (16,2,15,5,1,-905170500,2,'/1/2/16/','white_box',1,1,0,16,'e6a63f4ee6b40c2d439c4285ad9d6ee9');
INSERT INTO ezcontentobject_tree VALUES (11,5,10,1,1,1015610524,2,'/1/5/11/','__1/anonymous_user',1,1,0,11,'a59d2313b486e0f43477433525edea9b');
INSERT INTO ezcontentobject_tree VALUES (12,5,11,1,1,1857785444,2,'/1/5/12/','__1/guest_accounts',1,1,0,12,'c894997127008ea742913062f39adfc5');
INSERT INTO ezcontentobject_tree VALUES (13,5,12,1,1,-1978139175,2,'/1/5/13/','__1/administrator_users',1,1,0,13,'caeccbc33185f04d92e2b6cb83b1c7e4');
INSERT INTO ezcontentobject_tree VALUES (14,5,13,1,1,2094553782,2,'/1/5/14/','__1/editors',1,1,0,14,'39f6f6f51c1e3a922600b2d415d7a46d');
INSERT INTO ezcontentobject_tree VALUES (15,13,14,1,1,-852704961,3,'/1/5/13/15/','__1/administrator_users/administrator_user',1,1,0,15,'2c3f2814cfa91bcb17d7893ca6f8a0c4');
INSERT INTO ezcontentobject_tree VALUES (96,92,97,2,1,-2037262482,4,'/1/2/16/92/96/','white_box/water/water_4',1,1,0,96,'8c1adf228bb72c9083e105ab71c1ef54');
INSERT INTO ezcontentobject_tree VALUES (18,16,17,4,1,-23261470,3,'/1/2/16/18/','white_box/flowers',1,1,0,18,'bbb88b4dcf8f0f69deb36b03f2d264a9');
INSERT INTO ezcontentobject_tree VALUES (95,92,96,2,1,418726605,4,'/1/2/16/92/95/','white_box/water/water_3',1,1,0,95,'41266dc8af0f61ab31c5c341a5c7dfa8');
INSERT INTO ezcontentobject_tree VALUES (24,2,23,2,1,500406608,2,'/1/2/24/','news',1,8,0,24,'508c75c8507a2ae5223dfd2faeb98122');
INSERT INTO ezcontentobject_tree VALUES (26,24,25,3,1,-1149903583,3,'/1/2/24/26/','news/frontpage',1,1,1,26,'7c35fa6d599b052dde38d0694ba84c18');
INSERT INTO ezcontentobject_tree VALUES (27,24,26,3,1,1796760909,3,'/1/2/24/27/','news/sport',1,1,2,27,'50ffe644772ce5852f23fe34c4fc48a1');
INSERT INTO ezcontentobject_tree VALUES (92,16,93,1,1,1569594257,3,'/1/2/16/92/','white_box/water',1,1,0,92,'2803c7bb8be16dc023845301263582a4');
INSERT INTO ezcontentobject_tree VALUES (30,24,29,3,1,-783622642,3,'/1/2/24/30/','news/world_news',1,1,4,30,'de23a31dde3637232e47ef09c2ac78c9');
INSERT INTO ezcontentobject_tree VALUES (31,2,30,1,1,637654945,2,'/1/2/31/','crossroads_forum',1,1,0,31,'f1de02cf99b1475221319ec98fcef8c6');
INSERT INTO ezcontentobject_tree VALUES (32,31,31,1,1,-1109704689,3,'/1/2/31/32/','crossroads_forum/forums',1,1,0,32,'d7d24519f2c2e56ffffe49351941548c');
INSERT INTO ezcontentobject_tree VALUES (91,83,92,2,1,1491175983,4,'/1/2/16/83/91/','white_box/forest/forest_4',1,1,0,91,'6594309f8294c29f011a3844afde797f');
INSERT INTO ezcontentobject_tree VALUES (90,83,91,2,1,-964354164,4,'/1/2/16/83/90/','white_box/forest/forest_3',1,1,0,90,'eca701405d5230043fc2f8fdf2e7561d');
INSERT INTO ezcontentobject_tree VALUES (89,83,90,2,1,-1316868326,4,'/1/2/16/83/89/','white_box/forest/forest_2',1,1,0,89,'dc7d1f6a9ff22553c37b343fc50d51bc');
INSERT INTO ezcontentobject_tree VALUES (88,18,89,2,1,973785005,4,'/1/2/16/18/88/','white_box/flowers/__1',1,1,0,88,'a244aadbb38f6a72751fcb052652a34a');
INSERT INTO ezcontentobject_tree VALUES (55,2,57,1,1,-571349768,2,'/1/2/55/','frontpage20/',1,1,0,55,'8deeb08f2793e6ed85d8840187d863c7');
INSERT INTO ezcontentobject_tree VALUES (93,92,94,3,1,-151313439,4,'/1/2/16/92/93/','white_box/water/water_1',1,1,0,93,'730684d928ce8ab169f95f2b05e99015');
INSERT INTO ezcontentobject_tree VALUES (94,92,95,2,1,1878159963,4,'/1/2/16/92/94/','white_box/water/water_2',1,1,0,94,'b512935ef552d187a46e588e112b9c98');
INSERT INTO ezcontentobject_tree VALUES (60,2,62,2,1,-97909150,2,'/1/2/60/','the_book_corner',1,8,0,60,'b4690804656244a6fd83b20db9b3aad4');
INSERT INTO ezcontentobject_tree VALUES (61,60,63,3,1,71857351,3,'/1/2/60/61/','the_book_corner/thriller',1,1,1,61,'baf644a0ad6fb251a7dd12758aeb20b3');
INSERT INTO ezcontentobject_tree VALUES (62,60,64,1,1,-1965337591,3,'/1/2/60/62/','the_book_corner/bestsellers',1,1,2,62,'5e69c16272460f7a616742ab9862b35a');
INSERT INTO ezcontentobject_tree VALUES (63,60,65,1,1,1923414978,3,'/1/2/60/63/','the_book_corner/recommendations',1,1,3,63,'fb9e3248ed4f08fcd4ce7bc1807a8c20');
INSERT INTO ezcontentobject_tree VALUES (86,18,87,3,1,1563896063,4,'/1/2/16/18/86/','white_box/flowers/flower_2',1,1,0,86,'8c98f5cd5cc1a7a8368559cdb3899e9d');
INSERT INTO ezcontentobject_tree VALUES (87,18,88,2,1,925486222,4,'/1/2/16/18/87/','white_box/flowers/',1,1,0,87,'bed2d36df32e32c1986f8de9fedb3120');
INSERT INTO ezcontentobject_tree VALUES (82,16,83,5,1,-2039763684,3,'/1/2/16/82/','white_box/whitebox_contemporary_art_gallery',1,1,0,82,'abdba2bbc05819141abf5b998d85854c');
INSERT INTO ezcontentobject_tree VALUES (83,16,84,5,1,1240823459,3,'/1/2/16/83/','white_box/forest',1,1,0,83,'7044996d2fa9e66da69ee4f767079696');
INSERT INTO ezcontentobject_tree VALUES (84,83,85,3,1,680230560,4,'/1/2/16/83/84/','white_box/forest/forest_1',1,1,0,84,'a5b66377d0c38cd55ffdd7c7ef233970');
INSERT INTO ezcontentobject_tree VALUES (85,18,86,5,1,-1002538683,4,'/1/2/16/18/85/','white_box/flowers/flower_1',1,1,0,85,'1cf1a6683bc6988f50f05b3c6873bf22');
INSERT INTO ezcontentobject_tree VALUES (97,16,98,1,1,358499391,3,'/1/2/16/97/','white_box/animals',1,1,0,97,'30f827aab2a03589388305f4e737d4a3');
INSERT INTO ezcontentobject_tree VALUES (98,97,99,2,1,-522976646,4,'/1/2/16/97/98/','white_box/animals/animal_1',1,1,0,98,'e5c344c30c3316e722a4e6c84a7f9f54');
INSERT INTO ezcontentobject_tree VALUES (99,97,100,2,1,2044548032,4,'/1/2/16/97/99/','white_box/animals/animal_2',1,1,0,99,'869cb0fc1e6f97e62e7a239e6008cd6a');
INSERT INTO ezcontentobject_tree VALUES (100,97,101,2,1,249193302,4,'/1/2/16/97/100/','white_box/animals/animal_3',1,1,0,100,'4e7a431ec4010b9ce530a2330b69dde8');
INSERT INTO ezcontentobject_tree VALUES (101,97,102,2,1,-1866533131,4,'/1/2/16/97/101/','white_box/animals/animal_4',1,1,0,101,'9d25ab69fa7deaa2972b8872efa8a378');
INSERT INTO ezcontentobject_tree VALUES (102,16,103,1,1,-310936286,3,'/1/2/16/102/','white_box/landscape',1,1,0,102,'e9a618ea1db87e4369536567fb58f395');
INSERT INTO ezcontentobject_tree VALUES (103,102,104,2,1,363314855,4,'/1/2/16/102/103/','white_box/landscape/landscape_1',1,1,0,103,'a5c54bae6bc429a21e43d1a64508dbac');
INSERT INTO ezcontentobject_tree VALUES (104,102,105,2,1,-1934692579,4,'/1/2/16/102/104/','white_box/landscape/landscape_2',1,1,0,104,'f8849bb730dad28d12411ee458b2fa78');
INSERT INTO ezcontentobject_tree VALUES (105,102,106,2,1,-72753269,4,'/1/2/16/102/105/','white_box/landscape/landscape_3',1,1,0,105,'e8312a49da60267be2edfd67c62a7c36');
INSERT INTO ezcontentobject_tree VALUES (106,102,107,2,1,1707952680,4,'/1/2/16/102/106/','white_box/landscape/landscape_4',1,1,0,106,'f53f5fe335b8599c5b07a8e037ff7853');
INSERT INTO ezcontentobject_tree VALUES (108,24,110,1,1,655204301,3,'/1/2/24/108/','news/action',1,1,3,108,'5331d5c665713085cf2fe440f461304d');
INSERT INTO ezcontentobject_tree VALUES (109,108,111,1,1,-783898907,4,'/1/2/24/108/109/','news/action/ez_systems_travel_company',1,1,0,109,'b3eef07ce6c74632d31fea0bbc370369');
INSERT INTO ezcontentobject_tree VALUES (110,24,112,1,1,-306916314,3,'/1/2/24/110/','news/leisure',1,1,5,110,'6430731dda8bd8c67ad4b01673b4d499');
INSERT INTO ezcontentobject_tree VALUES (111,110,113,3,1,1590657753,4,'/1/2/24/110/111/','news/leisure/food_for_the_soul',1,9,0,111,'e91e03fe0b528225fe597a991f3ff8c2');
INSERT INTO ezcontentobject_tree VALUES (112,27,114,4,1,773391812,4,'/1/2/24/27/112/','news/sport/we_did_it_again',1,1,0,112,'abbe24e9a4cd305943226483bbfe16c7');
INSERT INTO ezcontentobject_tree VALUES (114,26,113,3,1,-1361070529,4,'/1/2/24/26/114/','news/frontpage/food_for_the_soul',1,9,0,111,'af8e4059be6ac871c0529210f7859d9b');
INSERT INTO ezcontentobject_tree VALUES (115,110,115,2,1,-201916845,4,'/1/2/24/110/115/','news/leisure/ez_publish_30',1,1,0,115,'78c825aed8ca5e6345a1966c1b00452a');
INSERT INTO ezcontentobject_tree VALUES (117,32,118,2,1,-1900057538,4,'/1/2/31/32/117/','crossroads_forum/forums/sports',1,2,0,117,'03fb29931c00a3b49418d3f3f8e015d4');
INSERT INTO ezcontentobject_tree VALUES (118,32,119,2,1,-1434425004,4,'/1/2/31/32/118/','crossroads_forum/forums/computers',1,2,0,118,'46c8733c95a10e6d117b53eb1fb9475e');
INSERT INTO ezcontentobject_tree VALUES (119,32,120,3,1,-347114709,4,'/1/2/31/32/119/','crossroads_forum/forums/games',1,2,0,119,'4afcb90160ce6f33518af92bd83cff4f');
INSERT INTO ezcontentobject_tree VALUES (120,32,121,3,1,1556655091,4,'/1/2/31/32/120/','crossroads_forum/forums/politics',1,2,0,120,'b2599bbd8601203cee38e04baa05e7e2');
INSERT INTO ezcontentobject_tree VALUES (121,117,122,1,1,-2096366515,5,'/1/2/31/32/117/121/','crossroads_forum/forums/sports/formula_1_2003',0,0,0,121,'1ee7118439d90a4f6bbf59bf9872c618');
INSERT INTO ezcontentobject_tree VALUES (122,108,123,2,1,2065883366,4,'/1/2/24/108/122/','news/action/a_weekend_in_the_mountain',1,1,0,122,'06fd8358fceda37d788f1e3aaca5e2fd');
INSERT INTO ezcontentobject_tree VALUES (123,26,123,2,1,1232201824,4,'/1/2/24/26/123/','news/frontpage/a_weekend_in_the_mountain',1,1,0,123,'91a539e714c76813bf6674bc3512a6a0');
INSERT INTO ezcontentobject_tree VALUES (124,61,125,4,1,-1984614118,4,'/1/2/60/61/124/','the_book_corner/thriller/the_thriller_book',1,1,0,124,'40ac0fbe37c21504bf603fdd12ecc2f4');
INSERT INTO ezcontentobject_tree VALUES (125,124,127,1,1,-1863870665,5,'/1/2/60/61/124/125/','the_book_corner/thriller/the_thriller_book/ive_read_this_book',1,1,0,125,'d289683a216d53e13562689acabd2073');
INSERT INTO ezcontentobject_tree VALUES (126,30,116,5,1,-1753601983,4,'/1/2/24/30/126/','news/world_news/collaboration_in_ez_publish',1,9,0,126,'bdd00f1a341ca80692d117dae10bdded');
INSERT INTO ezcontentobject_tree VALUES (127,27,128,1,1,-610832263,4,'/1/2/24/27/127/','news/sport/sports_weekend',1,1,0,127,'1ff3a3beaf84bf04263d513176271a06');
INSERT INTO ezcontentobject_tree VALUES (129,117,131,1,1,-1838064310,5,'/1/2/31/32/117/129/','crossroads_forum/forums/sports/the_best_football_team_in_england',1,1,0,129,'8994b2da9a1ffcdcabcd3b323e135827');
INSERT INTO ezcontentobject_tree VALUES (130,117,132,1,1,-414229640,5,'/1/2/31/32/117/130/','crossroads_forum/forums/sports/are_sports_for_idiots_',1,1,0,130,'1adad723a0349c7e1e2641f791075696');
INSERT INTO ezcontentobject_tree VALUES (131,118,133,1,1,-1734207038,5,'/1/2/31/32/118/131/','crossroads_forum/forums/computers/computer_nerds',1,1,0,131,'ece87b785f8cab4781ea66939e352ed4');
INSERT INTO ezcontentobject_tree VALUES (132,118,134,1,1,-1974140265,5,'/1/2/31/32/118/132/','crossroads_forum/forums/computers/without_computers_the_world_stops',1,1,0,132,'3d874d30d56081a32ddc77416d6176b4');
INSERT INTO ezcontentobject_tree VALUES (133,119,135,1,1,-134284140,5,'/1/2/31/32/119/133/','crossroads_forum/forums/games/colin_mcrae_rally_3',1,1,0,133,'2a01819bf3fb0b257765e4bec7ba8512');
INSERT INTO ezcontentobject_tree VALUES (134,119,136,1,1,1396823986,5,'/1/2/31/32/119/134/','crossroads_forum/forums/games/games_should_be_done_outside',1,1,0,134,'c117e9ee68cdc239948abfda47e0b779');
INSERT INTO ezcontentobject_tree VALUES (135,120,137,1,1,996921799,5,'/1/2/31/32/120/135/','crossroads_forum/forums/politics/politics_are_boring',1,1,0,135,'5f31e64cc2d64704d0abaef07ead1018');
INSERT INTO ezcontentobject_tree VALUES (136,129,139,1,1,-775874688,6,'/1/2/31/32/117/129/136/','crossroads_forum/forums/sports/the_best_football_team_in_england/i_do_not_agree_',0,0,0,136,'af1f44f7d39debefb24e57fe57823f72');
INSERT INTO ezcontentobject_tree VALUES (137,120,140,1,1,-1510352862,5,'/1/2/31/32/120/137/','crossroads_forum/forums/politics/without_politics_chaos_will_rule',1,1,0,137,'21026aea16973a3aa284d7b8cc0834d9');
INSERT INTO ezcontentobject_tree VALUES (138,133,141,1,1,-547112902,6,'/1/2/31/32/119/133/138/','crossroads_forum/forums/games/colin_mcrae_rally_3/yes_and_it_is_great',0,0,0,138,'7f866f56c75faec9b56eefa42ecfa3d6');
INSERT INTO ezcontentobject_tree VALUES (139,130,142,1,1,-731979268,6,'/1/2/31/32/117/130/139/','crossroads_forum/forums/sports/are_sports_for_idiots_/yes',0,0,0,139,'879a08d61d745ab4a9a41d0cf3d6cd08');
INSERT INTO ezcontentobject_tree VALUES (140,133,143,1,1,194913609,6,'/1/2/31/32/119/133/140/','crossroads_forum/forums/games/colin_mcrae_rally_3/i_agree',0,0,0,140,'0a5441d67a49b743192461013cd64b25');
INSERT INTO ezcontentobject_tree VALUES (141,130,144,1,1,1730759715,6,'/1/2/31/32/117/130/141/','crossroads_forum/forums/sports/are_sports_for_idiots_/hmmm',0,0,0,141,'82d4a814d5a2bd0c80e8d58291e1686b');
INSERT INTO ezcontentobject_tree VALUES (142,130,145,1,1,-1008770397,6,'/1/2/31/32/117/130/142/','crossroads_forum/forums/sports/are_sports_for_idiots_/test',0,0,0,142,'2cb37d0b70746191560ea8f14f6883dc');
INSERT INTO ezcontentobject_tree VALUES (143,130,146,1,1,303120137,6,'/1/2/31/32/117/130/143/','crossroads_forum/forums/sports/are_sports_for_idiots_/not_',0,0,0,143,'da2e64b33562c4a822f557d36c426018');
INSERT INTO ezcontentobject_tree VALUES (144,61,148,7,1,-278354831,4,'/1/2/60/61/144/','the_book_corner/thriller/forest_fog',1,1,0,144,'bdf974595035219b54d4b283a6c6656e');
INSERT INTO ezcontentobject_tree VALUES (145,60,149,1,1,-1854094534,3,'/1/2/60/145/','the_book_corner/computers',1,1,0,145,'9d9aa93f33e6ebad8d9bac4b9d106922');
INSERT INTO ezcontentobject_tree VALUES (146,145,150,7,1,1300096708,4,'/1/2/60/145/146/','the_book_corner/computers/how_to_make_a_perfect_cms_solution',1,1,0,146,'b87b6a904cd348a6d177088907b676a2');
INSERT INTO ezcontentobject_tree VALUES (147,145,151,3,1,-299602195,4,'/1/2/60/145/147/','the_book_corner/computers/ez_publish_a_tutorial',1,1,0,147,'be69de6ab6f45a38508495a045a05a41');
INSERT INTO ezcontentobject_tree VALUES (148,60,152,1,1,1236617995,3,'/1/2/60/148/','the_book_corner/house_and_garden',1,1,0,148,'5a580c852cbe7710d873ad6bddd1511d');
INSERT INTO ezcontentobject_tree VALUES (149,148,153,2,1,972968916,4,'/1/2/60/148/149/','the_book_corner/house_and_garden/color_is_everything',1,1,0,149,'ef92521ebf5345dab31ac19a21caf72c');
INSERT INTO ezcontentobject_tree VALUES (150,121,155,1,1,-1552780740,6,'/1/2/31/32/117/121/150/','crossroads_forum/forums/sports/formula_1_2003/ferrari_or_bmw_',0,0,0,150,'2682b313e05b4981a8c6f4c7b98d00c4');
INSERT INTO ezcontentobject_tree VALUES (151,148,154,3,1,-158729324,4,'/1/2/60/148/151/','the_book_corner/house_and_garden/peaceful_waters',1,1,0,151,'4e79e1fc7e95a35d03bde5d40e99cd4d');
INSERT INTO ezcontentobject_tree VALUES (152,60,156,1,1,-1869995055,3,'/1/2/60/152/','the_book_corner/travel',1,1,0,152,'fc8eaf007e1c0dc9350d53e0bc23f6a8');
INSERT INTO ezcontentobject_tree VALUES (153,152,157,2,1,-845055561,4,'/1/2/60/152/153/','the_book_corner/travel/travel_guide',1,1,0,153,'818fbe75d079bfff4af7d3ef25ea5073');
INSERT INTO ezcontentobject_tree VALUES (154,152,158,3,1,-201733899,4,'/1/2/60/152/154/','the_book_corner/travel/animal_planet',1,1,0,154,'797eb6dd920de728964004c24f5a2214');
INSERT INTO ezcontentobject_tree VALUES (155,62,150,7,1,-1646407085,4,'/1/2/60/62/155/','the_book_corner/bestsellers/how_to_make_a_perfect_cms_solution',1,1,0,155,'18c0a4e3090e99a12ae6ef16bee1c6ac');
INSERT INTO ezcontentobject_tree VALUES (156,62,154,3,1,-2035777282,4,'/1/2/60/62/156/','the_book_corner/bestsellers/peaceful_waters',1,1,0,156,'53e6ddf6e0a7b4534d61a12e41ec84e1');
INSERT INTO ezcontentobject_tree VALUES (191,62,158,3,1,1222115916,4,'/1/2/60/62/191/','the_book_corner/bestsellers/animal_planet',1,1,0,191,'daaf723eb920173947068a03836442ad');
INSERT INTO ezcontentobject_tree VALUES (158,2,160,2,1,-985225885,2,'/1/2/158/','my_company',1,8,0,158,'93991b3a2cc7a1bc8c6eff64a97fe1a1');
INSERT INTO ezcontentobject_tree VALUES (159,158,161,1,1,-543604905,3,'/1/2/158/159/','my_company/news',1,1,2,159,'d9dfb5315b65152afe3c9f3cdd1a9e37');
INSERT INTO ezcontentobject_tree VALUES (161,158,163,3,1,-1939585246,3,'/1/2/158/161/','my_company/products',1,1,3,161,'498230da01fb414d2ad4524fc29d246b');
INSERT INTO ezcontentobject_tree VALUES (162,161,164,1,1,812069886,4,'/1/2/158/161/162/','my_company/products/software',1,1,0,162,'a34b5df1de9e330e4adffd579cbd2aa2');
INSERT INTO ezcontentobject_tree VALUES (163,158,165,2,1,1290599441,3,'/1/2/158/163/','my_company/services',1,1,4,163,'6258930ba5c27aed4021b46ccfb10f4f');
INSERT INTO ezcontentobject_tree VALUES (169,159,171,1,1,191080176,4,'/1/2/158/159/169/','my_company/news/my_company_wins_award',1,1,0,169,'6a8a02248285a3a5ff06f354ba876ae6');
INSERT INTO ezcontentobject_tree VALUES (168,158,170,6,1,-1703774472,3,'/1/2/158/168/','my_company/careers',1,1,5,168,'2927aa6849d67eabe4ef5fe943f6ff5c');
INSERT INTO ezcontentobject_tree VALUES (167,158,169,3,1,726859238,3,'/1/2/158/167/','my_company/about',1,1,1,167,'45abc6a50b7018ec0e001966ef5d8dcb');
INSERT INTO ezcontentobject_tree VALUES (170,159,172,1,1,-1263547748,4,'/1/2/158/159/170/','my_company/news/my_company_wins_billion_contract',1,1,0,170,'a0ee16792f294b7df74c9546602426a4');
INSERT INTO ezcontentobject_tree VALUES (192,31,196,1,1,1030847600,3,'/1/2/31/192/','crossroads_forum/links',1,1,0,192,'dfe9b75887a05a682fc0f49148e2ad45');
INSERT INTO ezcontentobject_tree VALUES (172,161,174,1,1,1243527961,4,'/1/2/158/161/172/','my_company/products/servers',1,1,0,172,'6f1919abcd6c6a0209c499dfd59f44ff');
INSERT INTO ezcontentobject_tree VALUES (183,163,185,1,1,-1219062559,4,'/1/2/158/163/183/','my_company/services/support',1,1,0,183,'5df80d59244f65f94d6dd80e87e924f4');
INSERT INTO ezcontentobject_tree VALUES (184,163,186,1,1,974776337,4,'/1/2/158/163/184/','my_company/services/programming',1,1,0,184,'0cad91d20df246179d5a06eea1ce8d4d');
INSERT INTO ezcontentobject_tree VALUES (186,163,188,1,1,-282020567,4,'/1/2/158/163/186/','my_company/services/feature_request',1,1,0,186,'71cd5305556e0f2c0cd099b51bec4058');
INSERT INTO ezcontentobject_tree VALUES (185,163,187,1,1,-1495057916,4,'/1/2/158/163/185/','my_company/services/sys_admin',1,1,0,185,'5633410cb7f1cdff027c5c68a646ac00');
INSERT INTO ezcontentobject_tree VALUES (190,172,192,3,1,1724278794,5,'/1/2/158/161/172/190/','my_company/products/servers/server_optimized',1,1,0,190,'0f6f59c4133646dd398ae6e87ec8ddde');
INSERT INTO ezcontentobject_tree VALUES (182,163,184,1,1,-1796283891,4,'/1/2/158/163/182/','my_company/services/consulting',1,1,0,182,'9f3976ded39229d17bc894105e521dd2');
INSERT INTO ezcontentobject_tree VALUES (189,162,192,3,1,-391815679,5,'/1/2/158/161/162/189/','my_company/products/software/server_optimized',1,1,0,189,'4693b826566be9560f16748a14c507e0');
INSERT INTO ezcontentobject_tree VALUES (188,162,191,2,1,896700239,5,'/1/2/158/161/162/188/','my_company/products/software/my_company_desktop_editor',1,1,0,188,'5e7b5ecb47e89732a2039004ff19a944');
INSERT INTO ezcontentobject_tree VALUES (193,192,197,1,1,-1222636293,4,'/1/2/31/192/193/','crossroads_forum/links/ez_systems',1,1,0,193,'ccd2d24cfe89a76cda1d16fa7370695a');
INSERT INTO ezcontentobject_tree VALUES (197,192,201,1,1,1847138312,4,'/1/2/31/192/197/','crossroads_forum/links/ez_publish',1,1,0,197,'9bbf4428911ea125ea568b19f764355c');
INSERT INTO ezcontentobject_tree VALUES (198,31,202,1,1,-1348273041,3,'/1/2/31/198/','crossroads_forum/about_this_forum',1,1,0,198,'7ca56b67e0910d5edf8e568f53daf773');
INSERT INTO ezcontentobject_tree VALUES (199,2,203,1,1,-556964099,2,'/1/2/199/','my_intranet',1,1,0,199,'925a84f12d0e2a2afc289c7280b41ef8');
INSERT INTO ezcontentobject_tree VALUES (200,199,204,1,1,-1862150091,3,'/1/2/199/200/','my_intranet/news',1,1,0,200,'04e9eac1496c2cd185b0e0c5a15c1ec7');
INSERT INTO ezcontentobject_tree VALUES (201,199,205,1,1,996214735,3,'/1/2/199/201/','my_intranet/files',1,1,0,201,'8c5ee7aa12c046b0870d54c64e057405');
INSERT INTO ezcontentobject_tree VALUES (202,201,206,1,1,224616523,4,'/1/2/199/201/202/','my_intranet/files/important_document',1,1,0,202,'1db0dc5ebb029baa7f90555899e8bed3');
INSERT INTO ezcontentobject_tree VALUES (203,200,207,1,1,-482428759,4,'/1/2/199/200/203/','my_intranet/news/this_months_budget',1,1,0,203,'6b7d1ef4f448250bed4b3954c4921ca2');
INSERT INTO ezcontentobject_tree VALUES (208,200,208,1,1,1596329671,4,'/1/2/199/200/208/','my_intranet/news/wine_lottery_today',1,1,0,208,'739bbfae29cc4beac30571eb7be961fa');
INSERT INTO ezcontentobject_tree VALUES (205,201,209,3,1,1511889289,4,'/1/2/199/201/205/','my_intranet/files/document_template',1,1,0,205,'3812dee1f79688f36b2de7a3d3b4cc79');
INSERT INTO ezcontentobject_tree VALUES (207,201,210,4,1,-654564523,4,'/1/2/199/201/207/','my_intranet/files/another_template',1,1,0,207,'635ebc96b4cf2276ede6bb8177aa9a70');
INSERT INTO ezcontentobject_tree VALUES (209,200,211,1,1,-2069259164,4,'/1/2/199/200/209/','my_intranet/news/meeting_today_at_13',1,1,0,209,'e08294da9d18b964e3b93bf647cfd71c');
INSERT INTO ezcontentobject_tree VALUES (210,2,212,1,1,-1453055824,2,'/1/2/210/','my_site',1,1,0,210,'6a217f0f7032720eb50a1a2fbf258463');
INSERT INTO ezcontentobject_tree VALUES (211,210,213,2,1,-310959515,3,'/1/2/210/211/','my_site/about_me',1,1,0,211,'e22052175f03daa83f74ab58284d7883');
INSERT INTO ezcontentobject_tree VALUES (212,210,214,1,1,-1733491327,3,'/1/2/210/212/','my_site/portfolio',1,1,0,212,'597a5e8f0e4c910e5c8058ccafc91e49');
INSERT INTO ezcontentobject_tree VALUES (214,111,216,1,1,852786852,5,'/1/2/24/110/111/214/','news/leisure/food_for_the_soul/my_comment',1,9,0,214,'c61815bcc1ca62079709ea1cb755578c');

#
# Table structure for table 'ezcontentobject_version'
#

CREATE TABLE ezcontentobject_version (
  id int(11) NOT NULL auto_increment,
  contentobject_id int(11) default NULL,
  creator_id int(11) NOT NULL default '0',
  version int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  status int(11) NOT NULL default '0',
  workflow_event_pos int(11) NOT NULL default '0',
  user_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezcontentobject_version'
#

INSERT INTO ezcontentobject_version VALUES (1,1,0,1,0,0,3,1,0);
INSERT INTO ezcontentobject_version VALUES (4,4,0,1,0,0,1,1,0);
INSERT INTO ezcontentobject_version VALUES (443,15,14,1,1033922609,1033922626,3,0,0);
INSERT INTO ezcontentobject_version VALUES (436,1,8,2,1033919080,1033919080,1,1,0);
INSERT INTO ezcontentobject_version VALUES (438,10,8,1,1033920649,1033920665,3,0,0);
INSERT INTO ezcontentobject_version VALUES (439,11,8,1,1033920737,1033920746,3,0,0);
INSERT INTO ezcontentobject_version VALUES (440,12,8,1,1033920760,1033920775,3,0,0);
INSERT INTO ezcontentobject_version VALUES (441,13,8,1,1033920786,1033920794,3,0,0);
INSERT INTO ezcontentobject_version VALUES (442,14,8,1,1033920808,1033920830,3,0,0);
INSERT INTO ezcontentobject_version VALUES (546,92,14,1,1035886972,1035886989,3,0,0);
INSERT INTO ezcontentobject_version VALUES (445,17,14,1,1033923938,1033923953,3,0,0);
INSERT INTO ezcontentobject_version VALUES (545,91,14,1,1035886937,1035886955,3,0,0);
INSERT INTO ezcontentobject_version VALUES (521,17,14,2,1034327248,1034327257,3,0,0);
INSERT INTO ezcontentobject_version VALUES (547,93,14,1,1035887027,1035887037,3,0,0);
INSERT INTO ezcontentobject_version VALUES (455,15,14,2,1034085521,1034085521,3,0,0);
INSERT INTO ezcontentobject_version VALUES (456,15,14,3,1034165834,1034165834,3,0,0);
INSERT INTO ezcontentobject_version VALUES (457,23,14,1,1034174426,1034174464,3,0,0);
INSERT INTO ezcontentobject_version VALUES (507,72,14,1,1034260349,1034260496,3,0,0);
INSERT INTO ezcontentobject_version VALUES (459,25,14,1,1034175645,1034175666,3,0,0);
INSERT INTO ezcontentobject_version VALUES (460,26,14,1,1034175689,1034175704,3,0,0);
INSERT INTO ezcontentobject_version VALUES (539,87,14,1,1035886704,1035886716,3,0,0);
INSERT INTO ezcontentobject_version VALUES (463,29,14,1,1034175841,1034175855,3,0,0);
INSERT INTO ezcontentobject_version VALUES (464,30,14,1,1034181778,1034181792,3,0,0);
INSERT INTO ezcontentobject_version VALUES (465,31,14,1,1034181817,1034181825,3,0,0);
INSERT INTO ezcontentobject_version VALUES (540,88,14,1,1035886738,1035886750,3,0,0);
INSERT INTO ezcontentobject_version VALUES (541,89,14,1,1035886776,1035886785,3,0,0);
INSERT INTO ezcontentobject_version VALUES (538,86,14,1,1035886665,1035886676,3,0,0);
INSERT INTO ezcontentobject_version VALUES (536,85,14,1,1035883336,1035883390,3,0,0);
INSERT INTO ezcontentobject_version VALUES (543,85,14,2,1035886855,1035886880,3,0,0);
INSERT INTO ezcontentobject_version VALUES (473,39,10,1,1034185655,1034185655,3,0,0);
INSERT INTO ezcontentobject_version VALUES (542,17,14,4,1035886806,1035886818,3,0,0);
INSERT INTO ezcontentobject_version VALUES (477,43,10,1,1034186555,1034186575,3,0,0);
INSERT INTO ezcontentobject_version VALUES (479,45,10,1,1034186972,1034186992,3,0,0);
INSERT INTO ezcontentobject_version VALUES (480,46,10,1,1034187112,1034187189,3,0,0);
INSERT INTO ezcontentobject_version VALUES (481,47,10,1,1034187190,1034187441,3,0,0);
INSERT INTO ezcontentobject_version VALUES (528,26,14,3,1034334712,1034334718,3,0,0);
INSERT INTO ezcontentobject_version VALUES (527,26,14,2,1034334687,1034334704,3,0,0);
INSERT INTO ezcontentobject_version VALUES (529,29,14,2,1034334737,1034334754,3,0,0);
INSERT INTO ezcontentobject_version VALUES (491,57,14,1,1034190860,1034190865,3,0,0);
INSERT INTO ezcontentobject_version VALUES (496,62,14,1,1034251114,1034251246,3,0,0);
INSERT INTO ezcontentobject_version VALUES (497,63,14,1,1034252121,1034252134,3,0,0);
INSERT INTO ezcontentobject_version VALUES (498,64,14,1,1034252246,1034252256,3,0,0);
INSERT INTO ezcontentobject_version VALUES (499,65,14,1,1034252467,1034252479,3,0,0);
INSERT INTO ezcontentobject_version VALUES (679,118,14,2,1035988367,1035988501,3,0,0);
INSERT INTO ezcontentobject_version VALUES (680,119,14,2,1035988516,1035988870,3,0,0);
INSERT INTO ezcontentobject_version VALUES (535,84,14,1,1035883306,1035883322,3,0,0);
INSERT INTO ezcontentobject_version VALUES (534,83,14,1,1035882282,1035882318,3,0,0);
INSERT INTO ezcontentobject_version VALUES (504,70,14,1,1034259411,1034259505,3,0,0);
INSERT INTO ezcontentobject_version VALUES (526,25,14,3,1034334672,1034334677,3,0,0);
INSERT INTO ezcontentobject_version VALUES (525,25,14,2,1034334639,1034334649,3,0,0);
INSERT INTO ezcontentobject_version VALUES (508,72,14,2,1034261081,1034261100,3,0,0);
INSERT INTO ezcontentobject_version VALUES (544,90,14,1,1035886903,1035886921,3,0,0);
INSERT INTO ezcontentobject_version VALUES (530,29,14,3,1034334761,1034334767,3,0,0);
INSERT INTO ezcontentobject_version VALUES (511,72,14,3,1034263205,1034263215,3,0,0);
INSERT INTO ezcontentobject_version VALUES (512,72,14,4,1034263225,1034263232,3,0,0);
INSERT INTO ezcontentobject_version VALUES (513,72,14,5,1034263570,1034263585,3,0,0);
INSERT INTO ezcontentobject_version VALUES (514,72,14,6,1034264271,1034264283,3,0,0);
INSERT INTO ezcontentobject_version VALUES (515,72,14,7,1034264305,1034264315,3,0,0);
INSERT INTO ezcontentobject_version VALUES (516,72,14,8,1034264329,1034264345,3,0,0);
INSERT INTO ezcontentobject_version VALUES (517,72,14,9,1034264429,1034264438,3,0,0);
INSERT INTO ezcontentobject_version VALUES (537,17,14,3,1035886633,1035886654,3,0,0);
INSERT INTO ezcontentobject_version VALUES (548,94,14,1,1035887054,1035887067,3,0,0);
INSERT INTO ezcontentobject_version VALUES (549,94,14,2,1035887116,1035887130,3,0,0);
INSERT INTO ezcontentobject_version VALUES (550,95,14,1,1035887149,1035887163,3,0,0);
INSERT INTO ezcontentobject_version VALUES (551,96,14,1,1035887181,1035887194,3,0,0);
INSERT INTO ezcontentobject_version VALUES (552,97,14,1,1035887212,1035887226,3,0,0);
INSERT INTO ezcontentobject_version VALUES (553,98,14,1,1035887239,1035887250,3,0,0);
INSERT INTO ezcontentobject_version VALUES (554,99,14,1,1035887258,1035887271,3,0,0);
INSERT INTO ezcontentobject_version VALUES (555,100,14,1,1035887286,1035887300,3,0,0);
INSERT INTO ezcontentobject_version VALUES (556,101,14,1,1035887318,1035887347,3,0,0);
INSERT INTO ezcontentobject_version VALUES (557,102,14,1,1035887362,1035887382,3,0,0);
INSERT INTO ezcontentobject_version VALUES (558,103,14,1,1035887418,1035887800,3,0,0);
INSERT INTO ezcontentobject_version VALUES (559,104,14,1,1035887808,1035887825,3,0,0);
INSERT INTO ezcontentobject_version VALUES (560,105,14,1,1035887841,1035887862,3,0,0);
INSERT INTO ezcontentobject_version VALUES (561,106,14,1,1035887890,1035887919,3,0,0);
INSERT INTO ezcontentobject_version VALUES (562,107,14,1,1035887930,1035887954,3,0,0);
INSERT INTO ezcontentobject_version VALUES (563,104,14,2,1035888016,1035888035,3,0,0);
INSERT INTO ezcontentobject_version VALUES (564,105,14,2,1035888046,1035888065,3,0,0);
INSERT INTO ezcontentobject_version VALUES (565,106,14,2,1035888075,1035888094,3,0,0);
INSERT INTO ezcontentobject_version VALUES (566,107,14,2,1035888103,1035888131,3,0,0);
INSERT INTO ezcontentobject_version VALUES (567,17,14,5,1035888142,1035888142,3,0,0);
INSERT INTO ezcontentobject_version VALUES (568,17,14,6,1035888148,1035888148,3,0,0);
INSERT INTO ezcontentobject_version VALUES (569,86,14,2,1035888164,1035888164,3,0,0);
INSERT INTO ezcontentobject_version VALUES (570,86,14,3,1035888182,1035888182,3,0,0);
INSERT INTO ezcontentobject_version VALUES (571,86,14,4,1035888190,1035888214,3,0,0);
INSERT INTO ezcontentobject_version VALUES (572,87,14,2,1035888223,1035888242,3,0,0);
INSERT INTO ezcontentobject_version VALUES (573,88,14,2,1035888251,1035888271,3,0,0);
INSERT INTO ezcontentobject_version VALUES (574,89,14,2,1035888281,1035888302,3,0,0);
INSERT INTO ezcontentobject_version VALUES (575,84,14,2,1035888323,1035888332,3,0,0);
INSERT INTO ezcontentobject_version VALUES (576,85,14,3,1035888339,1035888358,3,0,0);
INSERT INTO ezcontentobject_version VALUES (577,90,14,2,1035888370,1035888387,3,0,0);
INSERT INTO ezcontentobject_version VALUES (578,91,14,2,1035888395,1035888410,3,0,0);
INSERT INTO ezcontentobject_version VALUES (579,92,14,2,1035888423,1035888444,3,0,0);
INSERT INTO ezcontentobject_version VALUES (580,94,14,3,1035888462,1035888486,3,0,0);
INSERT INTO ezcontentobject_version VALUES (581,95,14,2,1035888494,1035888527,3,0,0);
INSERT INTO ezcontentobject_version VALUES (582,96,14,2,1035888534,1035888554,3,0,0);
INSERT INTO ezcontentobject_version VALUES (583,97,14,2,1035888561,1035888616,3,0,0);
INSERT INTO ezcontentobject_version VALUES (584,101,14,2,1035888631,1035888654,3,0,0);
INSERT INTO ezcontentobject_version VALUES (585,102,14,2,1035888666,1035888685,3,0,0);
INSERT INTO ezcontentobject_version VALUES (586,99,14,2,1035888693,1035888720,3,0,0);
INSERT INTO ezcontentobject_version VALUES (587,100,14,2,1035888727,1035888750,3,0,0);
INSERT INTO ezcontentobject_version VALUES (589,84,14,3,1035892129,1035892129,3,0,0);
INSERT INTO ezcontentobject_version VALUES (590,84,14,4,1035892149,1035892149,3,0,0);
INSERT INTO ezcontentobject_version VALUES (591,84,14,5,1035892768,1035892777,3,0,0);
INSERT INTO ezcontentobject_version VALUES (593,86,14,5,1035892910,1035892919,3,0,0);
INSERT INTO ezcontentobject_version VALUES (594,87,14,3,1035892930,1035892937,3,0,0);
INSERT INTO ezcontentobject_version VALUES (596,15,14,4,1035893160,1035893191,3,0,0);
INSERT INTO ezcontentobject_version VALUES (597,15,14,5,1035893219,1035893229,3,0,0);
INSERT INTO ezcontentobject_version VALUES (598,83,14,2,1035893236,1035893387,3,0,0);
INSERT INTO ezcontentobject_version VALUES (599,83,14,3,1035904363,1035904363,3,0,0);
INSERT INTO ezcontentobject_version VALUES (600,108,14,1,1035904425,1035904425,3,0,0);
INSERT INTO ezcontentobject_version VALUES (601,83,14,4,1035904448,1035904493,3,0,0);
INSERT INTO ezcontentobject_version VALUES (602,109,14,1,1035905574,1035905620,3,0,0);
INSERT INTO ezcontentobject_version VALUES (603,109,14,2,1035905688,1035905688,3,0,0);
INSERT INTO ezcontentobject_version VALUES (604,109,14,3,1035905702,1035905739,3,0,0);
INSERT INTO ezcontentobject_version VALUES (605,110,14,1,1035905757,1035905815,3,0,0);
INSERT INTO ezcontentobject_version VALUES (606,111,14,1,1035905824,1035905861,3,0,0);
INSERT INTO ezcontentobject_version VALUES (607,112,14,1,1035905921,1035905944,3,0,0);
INSERT INTO ezcontentobject_version VALUES (608,113,14,1,1035905959,1035905996,3,0,0);
INSERT INTO ezcontentobject_version VALUES (609,114,14,1,1035906484,1035906797,3,0,0);
INSERT INTO ezcontentobject_version VALUES (610,114,14,2,1035906821,1035906867,3,0,0);
INSERT INTO ezcontentobject_version VALUES (611,83,14,5,1035967526,1035967595,3,0,0);
INSERT INTO ezcontentobject_version VALUES (612,23,14,2,1035967894,1035967901,3,0,0);
INSERT INTO ezcontentobject_version VALUES (613,114,14,3,1035968177,1035968202,3,0,0);
INSERT INTO ezcontentobject_version VALUES (614,113,14,2,1035968241,1035968282,3,0,0);
INSERT INTO ezcontentobject_version VALUES (615,115,14,1,1035969010,1035969125,3,0,0);
INSERT INTO ezcontentobject_version VALUES (616,115,14,2,1035969199,1035969409,3,0,0);
INSERT INTO ezcontentobject_version VALUES (617,116,14,1,1035969523,1035974177,3,0,0);
INSERT INTO ezcontentobject_version VALUES (618,117,14,1,1035969853,1035969958,3,0,0);
INSERT INTO ezcontentobject_version VALUES (619,118,14,1,1035970019,1035970183,3,0,0);
INSERT INTO ezcontentobject_version VALUES (620,119,14,1,1035970211,1035970245,3,0,0);
INSERT INTO ezcontentobject_version VALUES (621,120,14,1,1035970356,1035970380,3,0,0);
INSERT INTO ezcontentobject_version VALUES (622,120,14,2,1035970385,1035970392,3,0,0);
INSERT INTO ezcontentobject_version VALUES (623,121,14,1,1035970402,1035970517,3,0,0);
INSERT INTO ezcontentobject_version VALUES (624,122,14,1,1035970873,1035970902,3,0,0);
INSERT INTO ezcontentobject_version VALUES (625,123,14,1,1035970949,1035971037,3,0,0);
INSERT INTO ezcontentobject_version VALUES (626,123,14,2,1035971094,1035971131,3,0,0);
INSERT INTO ezcontentobject_version VALUES (627,62,14,2,1035971212,1035971219,3,0,0);
INSERT INTO ezcontentobject_version VALUES (629,63,14,2,1035973192,1035973198,3,0,0);
INSERT INTO ezcontentobject_version VALUES (630,63,14,3,1035973204,1035973207,3,0,0);
INSERT INTO ezcontentobject_version VALUES (631,125,14,1,1035973219,1035973240,3,0,0);
INSERT INTO ezcontentobject_version VALUES (632,126,14,1,1035973901,1035973901,3,0,0);
INSERT INTO ezcontentobject_version VALUES (633,127,14,1,1035973975,1035974003,3,0,0);
INSERT INTO ezcontentobject_version VALUES (634,116,14,2,1035974246,1035974246,3,0,0);
INSERT INTO ezcontentobject_version VALUES (635,128,14,1,1035974274,1035974314,3,0,0);
INSERT INTO ezcontentobject_version VALUES (636,116,14,3,1035974407,1035974950,3,0,0);
INSERT INTO ezcontentobject_version VALUES (640,131,14,1,1035976138,1035976181,3,0,0);
INSERT INTO ezcontentobject_version VALUES (641,132,14,1,1035976205,1035976274,3,0,0);
INSERT INTO ezcontentobject_version VALUES (642,133,14,1,1035976298,1035976334,3,0,0);
INSERT INTO ezcontentobject_version VALUES (643,134,14,1,1035976347,1035976395,3,0,0);
INSERT INTO ezcontentobject_version VALUES (644,135,14,1,1035976413,1035976440,3,0,0);
INSERT INTO ezcontentobject_version VALUES (645,136,14,1,1035976452,1035976529,3,0,0);
INSERT INTO ezcontentobject_version VALUES (646,137,14,1,1035976544,1035976603,3,0,0);
INSERT INTO ezcontentobject_version VALUES (647,138,14,1,1035976715,1035976715,3,0,0);
INSERT INTO ezcontentobject_version VALUES (648,139,14,1,1035976775,1035976794,3,0,0);
INSERT INTO ezcontentobject_version VALUES (649,140,14,1,1035977113,1035977266,3,0,0);
INSERT INTO ezcontentobject_version VALUES (650,141,14,1,1035977282,1035977376,3,0,0);
INSERT INTO ezcontentobject_version VALUES (651,142,14,1,1035977285,1035977384,3,0,0);
INSERT INTO ezcontentobject_version VALUES (652,143,14,1,1035977392,1035977451,3,0,0);
INSERT INTO ezcontentobject_version VALUES (654,144,14,1,1035977869,1035977970,3,0,0);
INSERT INTO ezcontentobject_version VALUES (655,145,14,1,1035977985,1035978537,3,0,0);
INSERT INTO ezcontentobject_version VALUES (656,146,14,1,1035978980,1035978996,3,0,0);
INSERT INTO ezcontentobject_version VALUES (657,147,14,1,1035979728,1035979816,3,0,0);
INSERT INTO ezcontentobject_version VALUES (658,148,14,1,1035982132,1035982593,3,0,0);
INSERT INTO ezcontentobject_version VALUES (659,148,14,2,1035982617,1035982637,3,0,0);
INSERT INTO ezcontentobject_version VALUES (660,148,14,3,1035982649,1035982657,3,0,0);
INSERT INTO ezcontentobject_version VALUES (661,125,14,2,1035982685,1035983144,3,0,0);
INSERT INTO ezcontentobject_version VALUES (662,149,14,1,1035983200,1035983221,3,0,0);
INSERT INTO ezcontentobject_version VALUES (663,150,14,1,1035983231,1035983501,3,0,0);
INSERT INTO ezcontentobject_version VALUES (664,151,14,1,1035983530,1035984352,3,0,0);
INSERT INTO ezcontentobject_version VALUES (665,151,14,2,1035984366,1035984380,3,0,0);
INSERT INTO ezcontentobject_version VALUES (666,150,14,2,1035984405,1035984429,3,0,0);
INSERT INTO ezcontentobject_version VALUES (667,125,14,3,1035984454,1035984454,3,0,0);
INSERT INTO ezcontentobject_version VALUES (668,148,14,4,1035984469,1035984485,3,0,0);
INSERT INTO ezcontentobject_version VALUES (669,152,14,1,1035985025,1035985040,3,0,0);
INSERT INTO ezcontentobject_version VALUES (670,153,14,1,1035985049,1035985182,3,0,0);
INSERT INTO ezcontentobject_version VALUES (671,154,14,1,1035985199,1035985541,3,0,0);
INSERT INTO ezcontentobject_version VALUES (672,155,14,1,1035985345,1035985362,3,0,0);
INSERT INTO ezcontentobject_version VALUES (673,156,14,1,1035985690,1035985697,3,0,0);
INSERT INTO ezcontentobject_version VALUES (674,157,14,1,1035985705,1035986064,3,0,0);
INSERT INTO ezcontentobject_version VALUES (675,158,14,1,1035986352,1035986466,3,0,0);
INSERT INTO ezcontentobject_version VALUES (676,150,14,3,1035986570,1035986596,3,0,0);
INSERT INTO ezcontentobject_version VALUES (677,154,14,2,1035986615,1035986637,3,0,0);
INSERT INTO ezcontentobject_version VALUES (678,148,14,5,1035986663,1035986680,3,0,0);
INSERT INTO ezcontentobject_version VALUES (681,120,14,3,1035988889,1035989049,3,0,0);
INSERT INTO ezcontentobject_version VALUES (682,121,14,2,1035989062,1035989292,3,0,0);
INSERT INTO ezcontentobject_version VALUES (683,121,14,3,1035989360,1035989376,3,0,0);
INSERT INTO ezcontentobject_version VALUES (684,114,14,4,1035989507,1035989523,3,0,0);
INSERT INTO ezcontentobject_version VALUES (685,159,14,1,1035990049,1035990049,3,0,0);
INSERT INTO ezcontentobject_version VALUES (686,90,14,3,1036056926,1036056926,3,0,0);
INSERT INTO ezcontentobject_version VALUES (687,90,14,4,1036056933,1036056933,3,0,0);
INSERT INTO ezcontentobject_version VALUES (688,128,14,2,1036056949,1036056949,3,0,0);
INSERT INTO ezcontentobject_version VALUES (689,116,14,4,1036057024,1036057024,3,0,0);
INSERT INTO ezcontentobject_version VALUES (690,160,14,1,1037113911,1037113922,3,0,0);
INSERT INTO ezcontentobject_version VALUES (691,161,14,1,1037177691,1037177708,1,0,0);
INSERT INTO ezcontentobject_version VALUES (693,163,14,1,1037178170,1037178181,3,0,0);
INSERT INTO ezcontentobject_version VALUES (694,164,14,1,1037192366,1037192378,1,0,0);
INSERT INTO ezcontentobject_version VALUES (695,165,14,1,1037196659,1037196669,3,0,0);
INSERT INTO ezcontentobject_version VALUES (705,170,14,1,1037198846,1037199366,3,0,0);
INSERT INTO ezcontentobject_version VALUES (706,170,14,2,1037199474,1037199503,3,0,0);
INSERT INTO ezcontentobject_version VALUES (698,1,14,3,1037196855,1037197879,1,1,0);
INSERT INTO ezcontentobject_version VALUES (699,160,14,2,1037197578,1037197585,1,0,0);
INSERT INTO ezcontentobject_version VALUES (704,169,14,2,1037198761,1037198793,3,0,0);
INSERT INTO ezcontentobject_version VALUES (703,169,14,1,1037198714,1037198736,3,0,0);
INSERT INTO ezcontentobject_version VALUES (707,170,14,3,1037199514,1037199597,3,0,0);
INSERT INTO ezcontentobject_version VALUES (708,170,14,4,1037199650,1037200111,3,0,0);
INSERT INTO ezcontentobject_version VALUES (709,170,14,5,1037200135,1037200157,3,0,0);
INSERT INTO ezcontentobject_version VALUES (710,171,14,1,1037200288,1037200671,1,0,0);
INSERT INTO ezcontentobject_version VALUES (712,172,14,1,1037201086,1037201872,1,0,0);
INSERT INTO ezcontentobject_version VALUES (713,163,14,2,1037201926,1037262748,3,0,0);
INSERT INTO ezcontentobject_version VALUES (746,163,14,3,1037263479,1037263615,1,0,0);
INSERT INTO ezcontentobject_version VALUES (715,174,14,1,1037202053,1037202070,1,0,0);
INSERT INTO ezcontentobject_version VALUES (751,153,14,2,1037264765,1037264782,1,0,0);
INSERT INTO ezcontentobject_version VALUES (750,151,14,3,1037264726,1037264747,1,0,0);
INSERT INTO ezcontentobject_version VALUES (719,178,14,1,1037202294,1037202310,1,0,0);
INSERT INTO ezcontentobject_version VALUES (749,150,14,5,1037264692,1037264714,3,0,0);
INSERT INTO ezcontentobject_version VALUES (747,150,14,4,1037263722,1037264672,3,0,0);
INSERT INTO ezcontentobject_version VALUES (732,185,14,1,1037261058,1037261069,1,0,0);
INSERT INTO ezcontentobject_version VALUES (733,186,14,1,1037261098,1037261113,1,0,0);
INSERT INTO ezcontentobject_version VALUES (734,187,14,1,1037261160,1037261172,1,0,0);
INSERT INTO ezcontentobject_version VALUES (735,188,14,1,1037261202,1037261217,1,0,0);
INSERT INTO ezcontentobject_version VALUES (744,192,14,1,1037263070,1037263277,3,0,0);
INSERT INTO ezcontentobject_version VALUES (745,192,14,2,1037263351,1037263385,3,0,0);
INSERT INTO ezcontentobject_version VALUES (731,184,14,1,1037261005,1037261018,1,0,0);
INSERT INTO ezcontentobject_version VALUES (743,191,14,1,1037262986,1037263025,3,0,0);
INSERT INTO ezcontentobject_version VALUES (752,154,14,3,1037264799,1037264815,1,0,0);
INSERT INTO ezcontentobject_version VALUES (753,157,14,2,1037264832,1037264847,1,0,0);
INSERT INTO ezcontentobject_version VALUES (754,158,14,2,1037264860,1037264879,3,0,0);
INSERT INTO ezcontentobject_version VALUES (755,125,14,4,1037264892,1037264915,1,0,0);
INSERT INTO ezcontentobject_version VALUES (756,148,14,6,1037264927,1037264994,3,0,0);
INSERT INTO ezcontentobject_version VALUES (757,150,14,6,1037265078,1037265091,3,0,0);
INSERT INTO ezcontentobject_version VALUES (758,150,14,7,1037265132,1037265164,1,0,0);
INSERT INTO ezcontentobject_version VALUES (759,148,14,7,1037265213,1037265917,1,0,0);
INSERT INTO ezcontentobject_version VALUES (761,158,14,3,1037265950,1037265973,1,0,0);
INSERT INTO ezcontentobject_version VALUES (762,194,10,1,1037267668,1037267668,0,0,0);
INSERT INTO ezcontentobject_version VALUES (764,196,14,1,1037280618,1037280633,1,0,0);
INSERT INTO ezcontentobject_version VALUES (765,197,14,1,1037280683,1037280728,1,0,0);
INSERT INTO ezcontentobject_version VALUES (770,191,14,2,1037281332,1037281355,1,0,0);
INSERT INTO ezcontentobject_version VALUES (768,200,14,1,1037280978,1037281016,1,0,0);
INSERT INTO ezcontentobject_version VALUES (771,201,14,1,1037281361,1037281396,1,0,0);
INSERT INTO ezcontentobject_version VALUES (772,192,14,3,1037281374,1037281396,1,0,0);
INSERT INTO ezcontentobject_version VALUES (773,165,14,2,1037281412,1037281706,1,0,0);
INSERT INTO ezcontentobject_version VALUES (774,202,14,1,1037281569,1037281592,1,0,0);
INSERT INTO ezcontentobject_version VALUES (775,170,14,6,1037284934,1037284973,1,0,0);
INSERT INTO ezcontentobject_version VALUES (776,169,14,3,1037285268,1037285403,1,0,0);
INSERT INTO ezcontentobject_version VALUES (777,203,14,1,1038916133,1038916142,1,0,0);
INSERT INTO ezcontentobject_version VALUES (778,204,14,1,1038916149,1038916156,1,0,0);
INSERT INTO ezcontentobject_version VALUES (779,205,14,1,1038916171,1038916201,1,0,0);
INSERT INTO ezcontentobject_version VALUES (780,206,14,1,1038917669,1038917707,1,0,0);
INSERT INTO ezcontentobject_version VALUES (781,207,14,1,1038918544,1038919010,1,0,0);
INSERT INTO ezcontentobject_version VALUES (782,208,14,1,1038919033,1038919541,1,0,0);
INSERT INTO ezcontentobject_version VALUES (783,209,14,1,1038919113,1038919152,3,0,0);
INSERT INTO ezcontentobject_version VALUES (784,209,14,2,1038919156,1038919163,3,0,0);
INSERT INTO ezcontentobject_version VALUES (785,209,14,3,1038919168,1038919177,1,0,0);
INSERT INTO ezcontentobject_version VALUES (786,210,14,1,1038919214,1038919252,3,0,0);
INSERT INTO ezcontentobject_version VALUES (787,210,14,2,1038919256,1038919262,3,0,0);
INSERT INTO ezcontentobject_version VALUES (788,210,14,3,1038919266,1038919275,3,0,0);
INSERT INTO ezcontentobject_version VALUES (789,210,14,4,1038919279,1038919287,1,0,0);
INSERT INTO ezcontentobject_version VALUES (790,211,14,1,1038919602,1038920435,1,0,0);
INSERT INTO ezcontentobject_version VALUES (791,212,14,1,1039686929,1039687283,1,0,0);
INSERT INTO ezcontentobject_version VALUES (792,213,14,1,1039687499,1039687512,3,0,0);
INSERT INTO ezcontentobject_version VALUES (793,214,14,1,1039687762,1039687794,1,0,0);
INSERT INTO ezcontentobject_version VALUES (794,213,14,2,1039687894,1039687925,1,0,0);
INSERT INTO ezcontentobject_version VALUES (795,113,14,3,1045818954,1045818963,1,0,0);
INSERT INTO ezcontentobject_version VALUES (796,215,14,1,1045818990,1045819013,1,0,0);
INSERT INTO ezcontentobject_version VALUES (797,216,10,1,1045819234,1045819258,1,0,0);
INSERT INTO ezcontentobject_version VALUES (798,116,14,5,1048520945,1048520954,1,0,0);

#
# Table structure for table 'ezdiscountrule'
#

CREATE TABLE ezdiscountrule (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezdiscountrule'
#


#
# Table structure for table 'ezdiscountsubrule'
#

CREATE TABLE ezdiscountsubrule (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  discountrule_id int(11) NOT NULL default '0',
  discount_percent float default NULL,
  limitation char(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezdiscountsubrule'
#


#
# Table structure for table 'ezdiscountsubrule_value'
#

CREATE TABLE ezdiscountsubrule_value (
  discountsubrule_id int(11) NOT NULL default '0',
  value int(11) NOT NULL default '0',
  issection int(1) NOT NULL default '0',
  PRIMARY KEY  (discountsubrule_id,value,issection)
) TYPE=MyISAM;

#
# Dumping data for table 'ezdiscountsubrule_value'
#


#
# Table structure for table 'ezenumobjectvalue'
#

CREATE TABLE ezenumobjectvalue (
  contentobject_attribute_id int(11) NOT NULL default '0',
  contentobject_attribute_version int(11) NOT NULL default '0',
  enumid int(11) NOT NULL default '0',
  enumelement varchar(255) default NULL,
  enumvalue varchar(255) default NULL,
  PRIMARY KEY  (contentobject_attribute_id,contentobject_attribute_version,enumid),
  KEY ezenumobjectvalue_co_attr_id_co_attr_ver (contentobject_attribute_id,contentobject_attribute_version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezenumobjectvalue'
#

INSERT INTO ezenumobjectvalue VALUES (157,1,3,'5','5');
INSERT INTO ezenumobjectvalue VALUES (351,1,2,'Ok','3');
INSERT INTO ezenumobjectvalue VALUES (403,1,3,'Good','5');

#
# Table structure for table 'ezenumvalue'
#

CREATE TABLE ezenumvalue (
  id int(11) NOT NULL auto_increment,
  contentclass_attribute_id int(11) NOT NULL default '0',
  contentclass_attribute_version int(11) NOT NULL default '0',
  enumelement varchar(255) default NULL,
  enumvalue varchar(255) default NULL,
  placement int(11) NOT NULL default '0',
  PRIMARY KEY  (id,contentclass_attribute_id,contentclass_attribute_version),
  KEY ezenumvalue_co_cl_attr_id_co_class_att_ver (contentclass_attribute_id,contentclass_attribute_version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezenumvalue'
#

INSERT INTO ezenumvalue VALUES (3,150,0,'Good','5',3);
INSERT INTO ezenumvalue VALUES (2,150,0,'Ok','3',2);
INSERT INTO ezenumvalue VALUES (1,150,0,'Poor','2',1);

#
# Table structure for table 'ezforgot_password'
#

CREATE TABLE ezforgot_password (
  id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  hash_key varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezforgot_password'
#


#
# Table structure for table 'ezimage'
#

CREATE TABLE ezimage (
  contentobject_attribute_id int(11) NOT NULL default '0',
  version int(11) NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  original_filename varchar(255) NOT NULL default '',
  mime_type varchar(50) NOT NULL default '',
  alternative_text varchar(255) NOT NULL default '',
  PRIMARY KEY  (contentobject_attribute_id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezimage'
#

INSERT INTO ezimage VALUES (228,1,'DSNsUt.jpg','Forest2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (231,1,'NiykNJ.jpg','Forest3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (169,1,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (213,2,'a72o2K.jpg','Forest1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (225,1,'0FYhVQ.jpg','Flower4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (222,1,'xUQGvP.jpg','Flower3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (219,1,'whm1Qu.jpg','Flower2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (213,1,'RDYut1.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (216,1,'knuUKQ.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (169,2,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,3,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,4,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,5,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,6,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,7,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,8,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (169,9,'sZd6o7.jpg','typhoon.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (234,1,'sPRLs6.jpg','Forest4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (239,1,'sIRnN3.jpg','Water1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (239,2,'XUbmMp.jpg','Water2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (242,1,'oZw9Q4.jpg','Water3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (245,1,'Yc1rQr.jpg','Water4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (248,1,'YwIaai.jpg','Water6.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (253,1,'NQspGB.jpg','Animal1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (256,1,'Kmq7Dt.jpg','Animal2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (259,1,'GmifVM.jpg','Animal3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (262,1,'uSWNNw.jpg','Animal5.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (267,1,'5Pn1q0.jpg','Landscape1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (270,1,'3OeOi3.jpg','Landscape2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (273,1,'UGwCqD.jpg','Landscape9.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (276,1,'JFFPeo.jpg','Landscape7.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (267,2,'5Pn1q0.jpg','Landscape1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (270,2,'3OeOi3.jpg','Landscape2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (273,2,'UGwCqD.jpg','Landscape9.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (276,2,'JFFPeo.jpg','Landscape7.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (216,2,'knuUKQ.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (216,3,'knuUKQ.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (216,4,'knuUKQ.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (219,2,'whm1Qu.jpg','Flower2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (222,2,'xUQGvP.jpg','Flower3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (225,2,'0FYhVQ.jpg','Flower4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (213,3,'a72o2K.jpg','Forest1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (228,2,'DSNsUt.jpg','Forest2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (231,2,'NiykNJ.jpg','Forest3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (234,2,'sPRLs6.jpg','Forest4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (239,3,'XUbmMp.jpg','Water2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (242,2,'oZw9Q4.jpg','Water3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (245,2,'Yc1rQr.jpg','Water4.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (248,2,'YwIaai.jpg','Water6.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (259,2,'GmifVM.jpg','Animal3.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (262,2,'uSWNNw.jpg','Animal5.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (253,2,'NQspGB.jpg','Animal1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (256,2,'Kmq7Dt.jpg','Animal2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (216,5,'knuUKQ.jpg','Flower1.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (219,3,'whm1Qu.jpg','Flower2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (208,4,'XROWkC.jpg','Water8.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (283,1,'8JCcrj.jpg','Artikkel1a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (283,2,'8JCcrj.jpg','Artikkel1a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (283,3,'8JCcrj.jpg','Artikkel1a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (290,1,'XQ1T5V.jpg','Artikkel2a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (297,1,'bqOnp1.jpg','Artikkel3a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (302,1,'Mm158b.jpg','ball.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (302,2,'Mm158b.jpg','ball.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (208,5,'XROWkC.jpg','Water8.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (302,3,'Mm158b.jpg','ball.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (297,2,'bqOnp1.jpg','Artikkel3a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (307,1,'aI1Z3U.gif','ezpublish-logo-100x20.gif','image/gif','');
INSERT INTO ezimage VALUES (307,2,'aI1Z3U.gif','ezpublish-logo-100x20.gif','image/gif','');
INSERT INTO ezimage VALUES (317,1,'1ZrIHy.gif','SBS_white_orangeP158.gif','image/gif','');
INSERT INTO ezimage VALUES (320,1,'jUWs84.gif','skisse1.gif','image/gif','');
INSERT INTO ezimage VALUES (323,1,'Yk7TiO.gif','skisse2.gif','image/gif','');
INSERT INTO ezimage VALUES (326,1,'gucn5F.gif','skisse3.gif','image/gif','');
INSERT INTO ezimage VALUES (326,2,'gucn5F.gif','skisse3.gif','image/gif','');
INSERT INTO ezimage VALUES (329,1,'qHnDRs.gif','skisse4.gif','image/gif','');
INSERT INTO ezimage VALUES (336,1,'1qjt5N.jpg','Landscape6.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (336,2,'1qjt5N.jpg','Landscape6.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (312,1,'KkZgg0.jpg','puck.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (312,2,'KkZgg0.jpg','puck.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (358,1,'5E5HXo.jpg','puck.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (312,3,'zMSpE0.jpg','Water7.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,1,'EGw2aS.jpg','Fog.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,2,'EGw2aS.jpg','Fog.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,3,'EGw2aS.jpg','Fog.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (344,2,'5X01DL.jpg','Creep.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,1,'wPLsSB.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (423,1,'Aa9z4v.jpg','Book1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (423,2,'5qfHJT.jpg','Book1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,2,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (344,3,'5X01DL.jpg','Creep.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,4,'NHFX20.jpg','Spenning1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (430,1,'nd8UHm.jpg','Book4.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (435,1,'HQABpJ.jpg','Book3.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (444,1,'gvRQRC.jpg','travel1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (449,1,'g21z1g.jpg','Animalplanet.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,3,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (435,2,'HQABpJ.jpg','Book3.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,5,'NHFX20.jpg','Spenning1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (320,2,'jUWs84.gif','skisse1.gif','image/gif','');
INSERT INTO ezimage VALUES (323,2,'Yk7TiO.gif','skisse2.gif','image/gif','');
INSERT INTO ezimage VALUES (326,3,'gucn5F.gif','skisse3.gif','image/gif','');
INSERT INTO ezimage VALUES (329,2,'qHnDRs.gif','skisse4.gif','image/gif','');
INSERT INTO ezimage VALUES (329,3,'qHnDRs.gif','skisse4.gif','image/gif','');
INSERT INTO ezimage VALUES (302,4,'Mm158b.jpg','ball.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (228,3,'DSNsUt.jpg','Forest2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (228,4,'DSNsUt.jpg','Forest2.jpg','image/pjpeg','');
INSERT INTO ezimage VALUES (358,2,'5E5HXo.jpg','puck.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (312,4,'zMSpE0.jpg','Water7.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,4,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,5,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (423,3,'5qfHJT.jpg','Book1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (430,2,'nd8UHm.jpg','Book4.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (435,3,'HQABpJ.jpg','Book3.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (444,2,'gvRQRC.jpg','travel1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (449,2,'g21z1g.jpg','Animalplanet.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (344,4,'5X01DL.jpg','Creep.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,6,'NHFX20.jpg','Spenning1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,6,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (418,7,'RWjJMr.jpg','Book2.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (411,7,'NHFX20.jpg','Spenning1.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (449,3,'g21z1g.jpg','Animalplanet.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (297,3,'bqOnp1.jpg','Artikkel3a.jpg','image/jpeg','');
INSERT INTO ezimage VALUES (312,5,'zMSpE0.jpg','Water7.jpg','image/jpeg','');

#
# Table structure for table 'ezimagevariation'
#

CREATE TABLE ezimagevariation (
  contentobject_attribute_id int(11) NOT NULL default '0',
  version int(11) NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  additional_path varchar(255) default NULL,
  requested_width int(11) NOT NULL default '0',
  requested_height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  height int(11) NOT NULL default '0',
  PRIMARY KEY  (contentobject_attribute_id,version,requested_width,requested_height)
) TYPE=MyISAM;

#
# Dumping data for table 'ezimagevariation'
#

INSERT INTO ezimagevariation VALUES (283,3,'8JCcrj_600x600_283.jpg','8/J/C',600,600,150,113);
INSERT INTO ezimagevariation VALUES (317,1,'1ZrIHy_600x600_317.gif','1/Z/r',600,600,200,50);
INSERT INTO ezimagevariation VALUES (312,3,'zMSpE0_600x600_312.jpg','z/M/S',600,600,400,300);
INSERT INTO ezimagevariation VALUES (312,5,'zMSpE0_100x100_312.jpg','z/M/S',100,100,100,75);

#
# Table structure for table 'ezinfocollection'
#

CREATE TABLE ezinfocollection (
  id int(11) NOT NULL auto_increment,
  contentobject_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezinfocollection'
#


#
# Table structure for table 'ezinfocollection_attribute'
#

CREATE TABLE ezinfocollection_attribute (
  id int(11) NOT NULL auto_increment,
  informationcollection_id int(11) NOT NULL default '0',
  data_text text,
  data_int int(11) default NULL,
  data_float float default NULL,
  contentclass_attribute_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezinfocollection_attribute'
#


#
# Table structure for table 'ezmedia'
#

CREATE TABLE ezmedia (
  contentobject_attribute_id int(11) NOT NULL default '0',
  version int(11) NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  original_filename varchar(255) NOT NULL default '',
  mime_type varchar(50) NOT NULL default '',
  width int(11) default NULL,
  height int(11) default NULL,
  has_controller int(1) default NULL,
  is_autoplay int(1) default NULL,
  pluginspage varchar(255) default NULL,
  quality varchar(50) default NULL,
  is_loop int(1) default NULL,
  controls varchar(50) default NULL,
  PRIMARY KEY  (contentobject_attribute_id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezmedia'
#


#
# Table structure for table 'ezmessage'
#

CREATE TABLE ezmessage (
  id int(11) NOT NULL auto_increment,
  send_method varchar(50) NOT NULL default '',
  send_weekday varchar(50) NOT NULL default '',
  send_time varchar(50) NOT NULL default '',
  destination_address varchar(50) NOT NULL default '',
  title varchar(255) NOT NULL default '',
  body text,
  is_sent int(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezmessage'
#


#
# Table structure for table 'ezmodule_run'
#

CREATE TABLE ezmodule_run (
  id int(11) NOT NULL auto_increment,
  workflow_process_id int(11) default NULL,
  module_name varchar(255) default NULL,
  function_name varchar(255) default NULL,
  module_data text,
  PRIMARY KEY  (id),
  UNIQUE KEY ezmodule_run_workflow_process_id_s (workflow_process_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezmodule_run'
#


#
# Table structure for table 'eznode_assignment'
#

CREATE TABLE eznode_assignment (
  id int(11) NOT NULL auto_increment,
  contentobject_id int(11) default NULL,
  contentobject_version int(11) default NULL,
  parent_node int(11) default NULL,
  is_main int(11) NOT NULL default '0',
  sort_order int(1) default '1',
  sort_field int(11) default '1',
  from_node_id int(11) default '0',
  remote_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'eznode_assignment'
#

INSERT INTO eznode_assignment VALUES (2,1,1,1,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (3,4,2,1,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (4,8,2,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (144,4,4,1,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (147,210,1,5,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (146,209,1,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (145,1,2,1,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (148,9,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (149,10,1,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (150,11,1,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (151,12,1,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (152,13,1,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (153,14,1,13,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (154,15,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (155,16,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (156,17,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (157,18,1,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (158,19,1,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (159,20,1,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (160,21,1,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (161,22,1,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (162,18,2,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (163,18,3,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (164,18,4,17,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (165,16,2,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (166,15,2,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (167,15,3,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (168,23,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (169,24,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (170,25,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (171,26,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (172,27,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (173,28,1,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (174,29,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (175,30,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (176,31,1,31,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (177,32,1,32,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (254,17,4,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (251,87,1,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (249,17,3,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (181,36,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (182,37,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (183,38,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (184,39,1,33,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (185,40,1,33,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (186,41,1,33,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (187,42,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (188,43,1,40,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (189,44,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (190,45,1,40,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (191,46,1,40,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (192,47,1,40,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (193,48,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (194,49,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (195,50,1,49,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (196,51,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (197,52,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (198,53,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (199,54,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (200,55,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (201,56,1,53,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (202,57,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (203,58,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (204,59,1,26,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (205,60,1,26,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (206,61,1,26,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (207,62,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (208,63,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (209,64,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (210,65,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (397,118,2,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (398,119,2,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (248,85,1,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (247,84,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (246,83,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (216,70,1,66,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (217,71,1,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (218,71,2,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (219,72,1,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (220,72,2,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (221,73,1,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (222,73,2,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (223,72,3,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (224,72,4,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (225,72,5,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (226,72,6,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (227,72,7,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (228,72,8,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (229,72,9,28,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (250,86,1,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (260,94,1,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (259,93,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (233,17,2,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (258,92,1,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (253,89,1,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (252,88,1,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (237,25,2,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (238,25,3,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (239,26,2,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (240,26,3,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (241,29,2,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (242,29,3,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (257,91,1,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (256,90,1,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (255,85,2,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (261,94,2,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (262,95,1,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (263,96,1,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (264,97,1,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (265,98,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (266,99,1,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (267,100,1,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (268,101,1,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (269,102,1,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (270,103,1,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (271,104,1,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (272,105,1,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (273,106,1,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (274,107,1,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (275,104,2,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (276,105,2,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (277,106,2,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (278,107,2,102,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (279,17,5,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (280,17,6,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (281,86,2,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (282,86,3,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (283,86,4,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (284,87,2,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (285,88,2,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (286,89,2,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (287,84,2,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (288,85,3,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (289,90,2,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (290,91,2,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (291,92,2,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (292,94,3,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (293,95,2,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (294,96,2,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (295,97,2,92,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (296,101,2,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (297,102,2,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (298,99,2,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (299,100,2,97,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (301,84,3,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (302,84,4,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (303,84,5,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (305,86,5,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (306,87,3,18,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (308,15,4,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (309,15,5,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (310,83,2,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (311,83,3,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (312,108,1,82,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (313,83,4,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (314,109,1,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (315,109,2,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (316,109,3,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (317,110,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (318,111,1,108,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (319,112,1,24,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (320,113,1,110,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (321,114,1,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (322,114,2,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (323,83,5,16,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (324,23,2,2,1,1,8,0,0);
INSERT INTO eznode_assignment VALUES (325,114,3,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (326,114,3,26,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (327,113,2,110,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (328,113,2,26,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (329,115,1,110,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (330,115,2,110,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (331,116,1,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (332,117,1,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (333,118,1,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (334,119,1,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (335,120,1,32,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (336,120,2,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (337,121,1,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (338,122,1,117,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (339,123,1,108,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (340,123,2,108,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (341,123,2,26,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (342,62,2,2,1,1,8,0,0);
INSERT INTO eznode_assignment VALUES (344,63,2,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (345,63,3,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (346,125,1,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (347,126,1,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (348,127,1,124,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (349,116,2,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (350,128,1,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (351,116,3,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (355,131,1,117,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (356,132,1,117,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (357,133,1,118,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (358,134,1,118,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (359,135,1,119,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (360,136,1,119,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (361,137,1,120,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (362,138,1,130,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (363,139,1,129,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (364,140,1,120,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (365,141,1,133,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (366,142,1,130,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (367,143,1,133,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (369,144,1,130,0,0,0,0,0);
INSERT INTO eznode_assignment VALUES (370,145,1,130,1,0,0,0,0);
INSERT INTO eznode_assignment VALUES (371,146,1,130,1,0,0,0,0);
INSERT INTO eznode_assignment VALUES (372,147,1,124,1,0,0,0,0);
INSERT INTO eznode_assignment VALUES (373,148,1,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (374,148,2,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (375,148,3,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (376,125,2,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (377,149,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (378,150,1,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (379,151,1,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (380,151,2,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (381,150,2,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (382,125,3,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (383,148,4,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (384,152,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (385,153,1,148,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (386,154,1,148,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (387,155,1,121,1,0,0,0,0);
INSERT INTO eznode_assignment VALUES (388,156,1,60,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (389,157,1,152,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (390,158,1,152,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (391,150,3,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (392,150,3,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (393,154,2,148,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (394,154,2,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (395,148,5,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (396,148,5,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (399,120,3,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (400,121,2,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (401,121,3,32,1,1,2,0,0);
INSERT INTO eznode_assignment VALUES (402,114,4,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (404,159,1,129,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (405,90,3,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (406,90,4,83,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (407,128,2,27,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (408,116,4,30,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (409,160,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (410,161,1,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (412,163,1,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (413,164,1,161,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (414,165,1,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (424,170,1,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (425,170,2,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (417,1,3,1,1,1,8,0,0);
INSERT INTO eznode_assignment VALUES (418,160,2,2,1,1,8,0,0);
INSERT INTO eznode_assignment VALUES (423,169,2,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (422,169,1,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (426,170,3,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (427,170,4,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (428,170,5,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (429,171,1,159,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (431,172,1,159,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (432,163,2,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (465,192,2,172,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (434,174,1,161,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (470,150,5,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (438,178,1,175,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (468,150,4,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (467,150,4,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (466,163,3,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (451,185,1,163,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (452,186,1,163,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (453,187,1,163,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (454,188,1,163,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (463,192,1,162,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (464,192,2,162,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (450,184,1,163,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (462,191,1,162,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (471,150,5,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (472,151,3,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (473,153,2,148,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (474,154,3,148,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (475,154,3,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (476,157,2,152,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (477,158,2,152,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (478,125,4,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (479,148,6,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (480,148,6,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (481,150,6,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (482,150,6,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (483,150,7,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (484,150,7,145,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (485,148,7,61,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (488,158,3,152,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (489,158,3,62,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (490,194,1,118,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (492,196,1,31,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (493,197,1,192,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (498,191,2,162,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (496,200,1,195,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (499,201,1,192,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (500,192,3,172,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (501,192,3,162,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (502,165,2,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (503,202,1,31,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (504,170,6,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (505,169,3,158,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (506,203,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (507,204,1,199,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (508,205,1,199,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (509,206,1,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (510,207,1,200,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (511,208,1,200,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (512,209,1,201,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (513,209,2,5,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (514,209,2,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (517,210,1,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (516,209,3,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (518,210,2,5,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (519,210,2,201,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (520,210,3,5,0,1,1,0,0);
INSERT INTO eznode_assignment VALUES (521,210,3,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (524,211,1,200,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (523,210,4,201,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (525,212,1,2,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (526,213,1,210,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (527,214,1,210,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (528,213,2,210,1,1,1,0,0);
INSERT INTO eznode_assignment VALUES (529,113,3,110,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (530,113,3,26,0,1,9,0,0);
INSERT INTO eznode_assignment VALUES (531,215,1,111,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (532,216,1,111,1,1,9,0,0);
INSERT INTO eznode_assignment VALUES (533,116,5,30,1,1,9,0,0);

#
# Table structure for table 'ezoperation_memento'
#

CREATE TABLE ezoperation_memento (
  id int(11) NOT NULL auto_increment,
  main int(11) NOT NULL default '0',
  memento_key varchar(32) NOT NULL default '',
  memento_data text NOT NULL,
  main_key varchar(32) NOT NULL default '',
  PRIMARY KEY  (id,memento_key)
) TYPE=MyISAM;

#
# Dumping data for table 'ezoperation_memento'
#


#
# Table structure for table 'ezorder'
#

CREATE TABLE ezorder (
  id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  productcollection_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  is_temporary int(11) NOT NULL default '1',
  order_nr int(11) NOT NULL default '0',
  data_text_2 text,
  data_text_1 text,
  account_identifier varchar(100) NOT NULL default 'default',
  ignore_vat int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezorder'
#

INSERT INTO ezorder VALUES (1,14,5,1035976440,1,0,NULL,NULL,'default',0);
INSERT INTO ezorder VALUES (2,10,8,1037195564,1,0,NULL,NULL,'default',0);
INSERT INTO ezorder VALUES (3,10,9,1037195595,1,0,NULL,NULL,'default',0);
INSERT INTO ezorder VALUES (4,10,10,1037195644,1,0,NULL,NULL,'default',0);
INSERT INTO ezorder VALUES (5,10,12,1037263309,1,0,NULL,NULL,'default',0);

#
# Table structure for table 'ezorder_item'
#

CREATE TABLE ezorder_item (
  id int(11) NOT NULL auto_increment,
  order_id int(11) NOT NULL default '0',
  description varchar(255) default NULL,
  price float default NULL,
  vat_value int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezorder_item'
#


#
#
 Table structure for table 'ezpolicy'
#

CREATE TABLE ezpolicy (
  id int(11) NOT NULL auto_increment,
  role_id int(11) default NULL,
  function_name varchar(255) default NULL,
  module_name varchar(255) default NULL,
  limitation char(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezpolicy'
#

INSERT INTO ezpolicy VALUES (308,2,'*','*','*');
INSERT INTO ezpolicy VALUES (367,6,'*','*','*');
INSERT INTO ezpolicy VALUES (401,3,'login','user','*');
INSERT INTO ezpolicy VALUES (400,3,'*','content','*');
INSERT INTO ezpolicy VALUES (402,1,'create','content','');
INSERT INTO ezpolicy VALUES (403,1,'edit','content','');
INSERT INTO ezpolicy VALUES (404,1,'create','content','');
INSERT INTO ezpolicy VALUES (405,1,'*','layout','*');
INSERT INTO ezpolicy VALUES (406,1,'*','shop','*');
INSERT INTO ezpolicy VALUES (407,1,'read','content','');
INSERT INTO ezpolicy VALUES (408,1,'create','content','');
INSERT INTO ezpolicy VALUES (409,1,'login','user','*');
INSERT INTO ezpolicy VALUES (410,1,'read','content','');
INSERT INTO ezpolicy VALUES (411,1,'create','content','');

#
# Table structure for table 'ezpolicy_limitation'
#

CREATE TABLE ezpolicy_limitation (
  id int(11) NOT NULL auto_increment,
  policy_id int(11) default NULL,
  identifier varchar(255) NOT NULL default '',
  role_id int(11) default NULL,
  function_name varchar(255) default NULL,
  module_name varchar(255) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezpolicy_limitation'
#

INSERT INTO ezpolicy_limitation VALUES (340,402,'Class',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (341,402,'ParentClass',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (342,403,'Owner',0,'edit','content');
INSERT INTO ezpolicy_limitation VALUES (343,404,'Class',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (344,404,'Section',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (345,404,'ParentClass',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (346,407,'Class',0,'read','content');
INSERT INTO ezpolicy_limitation VALUES (347,408,'Class',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (348,408,'ParentClass',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (349,410,'Class',0,'read','content');
INSERT INTO ezpolicy_limitation VALUES (350,411,'Class',0,'create','content');
INSERT INTO ezpolicy_limitation VALUES (351,411,'ParentClass',0,'create','content');

#
# Table structure for table 'ezpolicy_limitation_value'
#

CREATE TABLE ezpolicy_limitation_value (
  id int(11) NOT NULL auto_increment,
  limitation_id int(11) default NULL,
  value int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezpolicy_limitation_value'
#

INSERT INTO ezpolicy_limitation_value VALUES (566,340,8);
INSERT INTO ezpolicy_limitation_value VALUES (567,341,6);
INSERT INTO ezpolicy_limitation_value VALUES (568,342,1);
INSERT INTO ezpolicy_limitation_value VALUES (569,343,8);
INSERT INTO ezpolicy_limitation_value VALUES (570,344,4);
INSERT INTO ezpolicy_limitation_value VALUES (571,345,8);
INSERT INTO ezpolicy_limitation_value VALUES (572,346,1);
INSERT INTO ezpolicy_limitation_value VALUES (573,346,2);
INSERT INTO ezpolicy_limitation_value VALUES (574,346,5);
INSERT INTO ezpolicy_limitation_value VALUES (575,346,6);
INSERT INTO ezpolicy_limitation_value VALUES (576,346,8);
INSERT INTO ezpolicy_limitation_value VALUES (577,346,22);
INSERT INTO ezpolicy_limitation_value VALUES (578,346,23);
INSERT INTO ezpolicy_limitation_value VALUES (579,346,24);
INSERT INTO ezpolicy_limitation_value VALUES (580,346,25);
INSERT INTO ezpolicy_limitation_value VALUES (581,346,26);
INSERT INTO ezpolicy_limitation_value VALUES (582,347,23);
INSERT INTO ezpolicy_limitation_value VALUES (583,348,22);
INSERT INTO ezpolicy_limitation_value VALUES (584,349,27);
INSERT INTO ezpolicy_limitation_value VALUES (585,350,27);
INSERT INTO ezpolicy_limitation_value VALUES (586,351,2);

#
# Table structure for table 'ezproductcollection'
#

CREATE TABLE ezproductcollection (
  id int(11) NOT NULL auto_increment,
  created int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezproductcollection'
#

INSERT INTO ezproductcollection VALUES (1,NULL);
INSERT INTO ezproductcollection VALUES (2,NULL);
INSERT INTO ezproductcollection VALUES (3,NULL);
INSERT INTO ezproductcollection VALUES (4,NULL);
INSERT INTO ezproductcollection VALUES (5,NULL);
INSERT INTO ezproductcollection VALUES (6,NULL);
INSERT INTO ezproductcollection VALUES (7,NULL);
INSERT INTO ezproductcollection VALUES (8,NULL);
INSERT INTO ezproductcollection VALUES (9,NULL);
INSERT INTO ezproductcollection VALUES (10,NULL);
INSERT INTO ezproductcollection VALUES (11,NULL);
INSERT INTO ezproductcollection VALUES (12,NULL);

#
# Table structure for table 'ezproductcollection_item'
#

CREATE TABLE ezproductcollection_item (
  id int(11) NOT NULL auto_increment,
  productcollection_id int(11) NOT NULL default '0',
  contentobject_id int(11) NOT NULL default '0',
  item_count int(11) NOT NULL default '0',
  price double default NULL,
  is_vat_inc int(11) default NULL,
  vat_value float default NULL,
  discount float default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezproductcollection_item'
#

INSERT INTO ezproductcollection_item VALUES (5,5,125,1,12,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (4,5,125,1,12,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (11,10,150,1,39,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (10,8,125,1,12,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (12,11,151,1,0,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (13,12,125,1,12,NULL,NULL,NULL);
INSERT INTO ezproductcollection_item VALUES (14,12,192,1,34489,NULL,NULL,NULL);

#
# Table structure for table 'ezproductcollection_item_opt'
#

CREATE TABLE ezproductcollection_item_opt (
  id int(11) NOT NULL auto_increment,
  item_id int(11) NOT NULL default '0',
  option_item_id int(11) NOT NULL default '0',
  name varchar(255) NOT NULL default '',
  value varchar(255) NOT NULL default '',
  price float NOT NULL default '0',
  object_attribute_id int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezproductcollection_item_opt'
#


#
# Table structure for table 'ezrole'
#

CREATE TABLE ezrole (
  id int(11) NOT NULL auto_increment,
  version int(11) default '0',
  name varchar(255) NOT NULL default '',
  value char(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezrole'
#

INSERT INTO ezrole VALUES (1,0,'Anonymous','');
INSERT INTO ezrole VALUES (2,0,'Administrator','*');
INSERT INTO ezrole VALUES (3,0,'Editor','');
INSERT INTO ezrole VALUES (6,2,'Administrator',NULL);

#
# Table structure for table 'ezsearch_object_word_link'
#

#
# Table structure for table 'ezsection'
#

CREATE TABLE ezsection (
  id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  locale varchar(255) default NULL,
  navigation_part_idenfifier varchar(100) default 'ezcontentnavigationpart',
  navigation_part_identifier varchar(100) default 'ezcontentnavigationpart',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#

# Dumping data for table 'ezsection'
#

INSERT INTO ezsection VALUES (1,'Standard section','nor-NO','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (2,'White box','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (3,'News section','nor-NO','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (4,'Crossroards forum','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (5,'The book corner','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (6,'My company','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (7,'Intranet','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (8,'My site','','ezcontentnavigationpart','ezcontentnavigationpart');
INSERT INTO ezsection VALUES (9,'Users','','ezcontentnavigationpart','ezusernavigationpart');

#
# Table structure for table 'ezsession'
#

CREATE TABLE ezsession (
  session_key varchar(32) NOT NULL default '',
  expiration_time int(11) unsigned NOT NULL default '0',
  data text NOT NULL,
  PRIMARY KEY  (session_key),
  KEY expiration_time (expiration_time)
) TYPE=MyISAM;

#
# Dumping data for table 'ezsession'
#


#
# Table structure for table 'eztrigger'
#

CREATE TABLE eztrigger (
  id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  module_name varchar(200) NOT NULL default '',
  function_name varchar(200) NOT NULL default '',
  connect_type char(1) NOT NULL default '',
  workflow_id int(11) default NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY eztrigger_def_id (module_name,function_name,connect_type)
) TYPE=MyISAM;

#
# Dumping data for table 'eztrigger'
#


#
# Table structure for table 'ezurl'
#

CREATE TABLE ezurl (
  id int(11) NOT NULL auto_increment,
  url varchar(255) default NULL,
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  is_valid int(11) NOT NULL default '1',
  last_checked int(11) NOT NULL default '0',
  original_url_md5 varchar(32) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezurl'
#

INSERT INTO ezurl VALUES (1,'',0,0,1,0,'');
INSERT INTO ezurl VALUES (2,'http://ez.no',0,0,1,0,'');
INSERT INTO ezurl VALUES (3,'http://ez.no/developer',0,0,1,0,'');

#
# Table structure for table 'ezuser'
#

CREATE TABLE ezuser (
  contentobject_id int(11) NOT NULL default '0',
  login varchar(150) NOT NULL default '',
  email varchar(150) NOT NULL default '',
  password_hash_type int(11) NOT NULL default '1',
  password_hash varchar(50) default NULL,
  PRIMARY KEY  (contentobject_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezuser'
#

INSERT INTO ezuser VALUES (10,'anonymous','nospam@ez.no',2,'4e6f6184135228ccd45f8233d72a0363');
INSERT INTO ezuser VALUES (14,'admin','nospam@ez.no',2,'c78e3b0f3d9244ed8c6d1c29464bdff9');

#
# Table structure for table 'ezuser_accountkey'
#

CREATE TABLE ezuser_accountkey (
  id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  hash_key varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezuser_accountkey'
#


#
# Table structure for table 'ezuser_discountrule'
#

CREATE TABLE ezuser_discountrule (
  id int(11) NOT NULL auto_increment,
  discountrule_id int(11) default NULL,
  contentobject_id int(11) default NULL,
  name varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezuser_discountrule'
#


#
# Table structure for table 'ezuser_role'
#

CREATE TABLE ezuser_role (
  id int(11) NOT NULL auto_increment,
  role_id int(11) default NULL,
  contentobject_id int(11) default NULL,
  PRIMARY KEY  (id),
  KEY ezuser_role_contentobject_id (contentobject_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezuser_role'
#

INSERT INTO ezuser_role VALUES (24,1,4);
INSERT INTO ezuser_role VALUES (25,2,12);
INSERT INTO ezuser_role VALUES (26,1,11);

#
# Table structure for table 'ezuser_setting'
#

CREATE TABLE ezuser_setting (
  user_id int(11) NOT NULL default '0',
  is_enabled int(1) NOT NULL default '0',
  max_login int(11) default NULL,
  PRIMARY KEY  (user_id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezuser_setting'
#

INSERT INTO ezuser_setting VALUES (10,1,NULL);
INSERT INTO ezuser_setting VALUES (14,1,NULL);

#
# Table structure for table 'ezvattype'
#

CREATE TABLE ezvattype (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  percentage float default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezvattype'
#

INSERT INTO ezvattype VALUES (1,'Std',24);

#
# Table structure for table 'ezwaituntildatevalue'
#

CREATE TABLE ezwaituntildatevalue (
  id int(11) NOT NULL auto_increment,
  workflow_event_id int(11) NOT NULL default '0',
  workflow_event_version int(11) NOT NULL default '0',
  contentclass_id int(11) NOT NULL default '0',
  contentclass_attribute_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id,workflow_event_id,workflow_event_version),
  KEY ezwaituntildateevalue_wf_ev_id_wf_ver (workflow_event_id,workflow_event_version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezwaituntildatevalue'
#


#
# Table structure for table 'ezwishlist'
#

CREATE TABLE ezwishlist (
  id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  productcollection_id int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezwishlist'
#

INSERT INTO ezwishlist VALUES (1,14,3);

#
# Table structure for table 'ezworkflow'
#

CREATE TABLE ezworkflow (
  id int(11) NOT NULL auto_increment,
  version int(11) NOT NULL default '0',
  is_enabled int(1) NOT NULL default '0',
  workflow_type_string varchar(50) NOT NULL default '',
  name varchar(255) NOT NULL default '',
  creator_id int(11) NOT NULL default '0',
  modifier_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow'
#

INSERT INTO ezworkflow VALUES (1,0,0,'group_ezserial','Sp\'s forkflow',8,24,1031927869,1032856662);
INSERT INTO ezworkflow VALUES (1,1,1,'group_ezserial','Sp\'s forkflow',8,14,1031927869,1034172372);

#
# Table structure for table 'ezworkflow_assign'
#

CREATE TABLE ezworkflow_assign (
  id int(11) NOT NULL auto_increment,
  workflow_id int(11) NOT NULL default '0',
  node_id int(11) NOT NULL default '0',
  access_type int(11) NOT NULL default '0',
  as_tree int(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow_assign'
#


#
# Table structure for table 'ezworkflow_event'
#

CREATE TABLE ezworkflow_event (
  id int(11) NOT NULL auto_increment,
  version int(11) NOT NULL default '0',
  workflow_id int(11) NOT NULL default '0',
  workflow_type_string varchar(50) NOT NULL default '',
  description varchar(50) NOT NULL default '',
  data_int1 int(11) default NULL,
  data_int2 int(11) default NULL,
  data_int3 int(11) default NULL,
  data_int4 int(11) default NULL,
  data_text1 varchar(50) default NULL,
  data_text2 varchar(50) default NULL,
  data_text3 varchar(50) default NULL,
  data_text4 varchar(50) default NULL,
  placement int(11) NOT NULL default '0',
  PRIMARY KEY  (id,version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow_event'
#

INSERT INTO ezworkflow_event VALUES (18,0,1,'event_ezapprove','3333333333',0,0,0,0,'','','','',1);
INSERT INTO ezworkflow_event VALUES (20,0,1,'event_ezmessage','foooooo',0,0,0,0,'eeeeeeeeeeeeeeeeee','','','',2);
INSERT INTO ezworkflow_event VALUES (18,1,1,'event_ezapprove','3333333333',0,0,0,0,'','','','',1);
INSERT INTO ezworkflow_event VALUES (20,1,1,'event_ezmessage','foooooo',0,0,0,0,'eeeeeeeeeeeeeeeeee','','','',2);

#
# Table structure for table 'ezworkflow_group'
#

CREATE TABLE ezworkflow_group (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  creator_id int(11) NOT NULL default '0',
  modifier_id int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow_group'
#

INSERT INTO ezworkflow_group VALUES (1,'Standard',-1,-1,1024392098,1024392098);

#
#
 Table structure for table 'ezworkflow_group_link'
#

CREATE TABLE ezworkflow_group_link (
  workflow_id int(11) NOT NULL default '0',
  group_id int(11) NOT NULL default '0',
  workflow_version int(11) NOT NULL default '0',
  group_name varchar(255) default NULL,
  PRIMARY KEY  (workflow_id,group_id,workflow_version)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow_group_link'
#

INSERT INTO ezworkflow_group_link VALUES (1,1,0,'Standard');

#
# Table structure for table 'ezworkflow_process'
#

CREATE TABLE ezworkflow_process (
  id int(11) NOT NULL auto_increment,
  process_key varchar(32) NOT NULL default '',
  workflow_id int(11) NOT NULL default '0',
  user_id int(11) NOT NULL default '0',
  content_id int(11) NOT NULL default '0',
  content_version int(11) NOT NULL default '0',
  node_id int(11) NOT NULL default '0',
  session_key varchar(32) NOT NULL default '0',
  event_id int(11) NOT NULL default '0',
  event_position int(11) NOT NULL default '0',
  last_event_id int(11) NOT NULL default '0',
  last_event_position int(11) NOT NULL default '0',
  last_event_status int(11) NOT NULL default '0',
  event_status int(11) NOT NULL default '0',
  created int(11) NOT NULL default '0',
  modified int(11) NOT NULL default '0',
  activation_date int(11) default NULL,
  event_state int(11) default NULL,
  status int(11) default NULL,
  parameters text,
  memento_key varchar(32) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'ezworkflow_process'
#


