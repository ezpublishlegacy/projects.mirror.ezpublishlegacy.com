<? /* #?ini charset="utf8"?

# default is to use internal user accounts in the system
# simple is for handling account information without user registration

[AccountSettings]
# Handler=ezuser
Handler=ezdefault

# Allows for overriding a handler with another
# Alias[]
# Alias[ezdefault]=eztest

*/ ?>