<?php /* #?ini charset="utf-8"?

[EventSettings]
RepositoryDirectories[]=extension/bcsimplesubscription/workflowtypes
ExtensionDirectories[]=bcsimplesubscription
AvailableEventTypes[]=event_bcsimplesubscription

*/ ?>