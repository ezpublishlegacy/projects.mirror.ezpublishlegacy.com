<?php

$Module = array( 'name' => 'ezsi' );

$ViewList = array();

$ViewList['test'] = array(
   'script' => 'test.php',
   'params' => array ( ) );

?>
