[ExtensionSettings]
ActiveExtensions[]
ActiveExtensions[]=ezauthorize
