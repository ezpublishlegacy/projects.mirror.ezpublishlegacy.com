<?php
//
// Definition of eZAuthorizeGateway class
//
// eZ publish payment gateway for Authorize.net
// implementing transparent credit card payment
// transactions in eZ publish using cURL.
//
// Created on: <01-Dec-2005 7:50:00 Dylan McDiarmid>
// Last Updated: <11-Dec-2005 01:49:35 Graham Brookins>
// Version: 1.0.0
//
// Copyright (C) 2001-2005 Brookins Consulting. All rights reserved.
//
// This source file is part of an extension for the eZ publish (tm)
// Open Source Content Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 (or greater) as published by
// the Free Software Foundation and appearing in the file LICENSE
// included in the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html
//
// Contact licence@brookinsconsulting.com if any conditions
// of this licencing isn't clear to you.
//

/*!
  \class eZAuthorizeGateway ezauthorizegateway.php
  \brief eZAuthorizeGateway extends eZCurlGateway to provide a transparent
  Payment system through Authorize.Net using cURL.
*/

include_once ( 'extension/ezauthorize/classes/ezcurlgateway.php' );
include_once ( 'extension/ezauthorize/classes/ezauthorizeaim.php' );

define( "EZ_PAYMENT_GATEWAY_TYPE_EZAUTHORIZE", "eZAuthorize" );

function ezauthorize_format_number( $str, $decimal_places='2', $decimal_padding="0" ) {
    /* firstly format number and shorten any extra decimal places */
    /* Note this will round off the number pre-format $str if you dont want this fucntionality */
    $str =  number_format( $str, $decimal_places, '.', '');    // will return 12345.67
    $number = explode( '.', $str );
    $number[1] = ( isset( $number[1] ) )?$number[1]:''; // to fix the PHP Notice error if str does not contain a decimal placing.
    $decimal = str_pad( $number[1], $decimal_places, $decimal_padding );
    return (float) $number[0].'.'.$decimal;
}

class eZAuthorizeGateway extends eZCurlGateway
{
    /*!
     Constructor
    */
    function eZAuthorizeGateway()
    {
    }

    function loadForm( &$process, $errors = 0 )
    {
        $http = eZHTTPTool::instance();

        // get parameters
        $processParams = $process->attribute( 'parameter_list' );

        // load ini
        $ini = &eZINI::instance( 'ezauthorize.ini' );

        // regen posted form values
        if ( $http->hasPostVariable( 'validate' ) )
        {
            $tplVars['cardnumber'] = $http->postVariable( 'CardNumber' );
            $tplvars['Cardname'] = $http->postVariable( 'CardName' );
            $tplVars['cardtype'] = strtolower( $http->postVariable( 'CardType' ) );
            $tplVars['expirationmonth'] = $http->postVariable( 'ExpirationMonth' );
            $tplVars['expirationyear'] = $http->postVariable( 'ExpirationYear' );
        }
        else
        {
            // set form values to blank
            $tplVars['cardnumber'] = '';
            $tplVars['cardname'] = '';
            $tplVars['cardtype'] = '';
            $tplVars['expirationmonth'] = '';
            $tplVars['expirationyear'] = '';
        }

        $tplVars['errors'] = $errors;
        $tplVars['order_id'] = $processParams['order_id'];

        $process->Template=array
        (
            'templateName' => 'design:workflow/eventtype/result/' . 'ezauthorize_form.tpl',
            'templateVars' => $tplVars
        );

        return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
    }

    function validateForm( &$process )
    {
        $http = eZHTTPTool::instance();
        $errors = false;

        if ( trim( $http->postVariable( 'CardNumber' ) ) == '' )
        {
            $errors[] = 'You must enter a card number.';
        }
        elseif( strlen( trim( $http->postVariable( 'CardNumber' ) ) ) > 49 )
        {
            $errors[] = 'Your card number should be under 50 characters.';
        }

        if ( trim( $http->postVariable( 'CardName' ) ) == '' )
        {
            $errors[] = 'You must enter a card name.';
        }
        elseif( strlen( trim( $http->postVariable( 'CardName' ) ) ) > 79 )
        {
            $errors[] = 'Your card name should be under 80 characters.';
        }

        if ( trim( $http->postVariable( 'ExpirationMonth' ) ) == '' )
        {
            $errors[] = 'You must select an expiration month.';
        }

        if ( trim( $http->postVariable( 'ExpirationYear' ) ) == '' )
        {
            $errors[] = 'You must select an expiration year.';
        }

        return $errors;
    }

    /*
     * Builds URI and executes the Authorize.Net curl functions.
    */
    function doCURL( &$process )
    {
        include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );

        // load ini
        $ini = eZINI::instance( 'ezauthorize.ini' );

        // retrieve Status Codes
        $startStatusCode =  $ini->variable( 'eZAuthorizeSettings', 'StartStatusCode' );
        $successStatusCode =  $ini->variable( 'eZAuthorizeSettings', 'SuccessStatusCode' );
        $failStatusCode =  $ini->variable( 'eZAuthorizeSettings', 'FailStatusCode' );

        // load http
        $http = eZHTTPTool::instance();

        // make the order object
        $processParams = $process->attribute( 'parameter_list' );

        // get order id
        $order_id = $processParams['order_id'];

        // get order
        $order = &eZOrder::fetch( $processParams['order_id'] );

        // get total order amount, including tax
        $order_total_amount = $order->attribute( 'total_inc_vat' );

        // get total in number format
        $order_total_amount = ezauthorize_format_number( $order_total_amount );

        // get user id
        $user_id = $processParams['user_id'];
        
        // note start of order transmission
        if($startStatusCode)
        {
          $order->modifyStatus($startStatusCode);
        }

        // assign variables to Authorize.Net class from post
        $aim = new eZAuthorizeAIM();

        // assign card name
        $aim->addField( 'x_card_name', trim( $http->postVariable( 'CardName' ) ) );

        // assign card expiration date
        $aim->addField( 'x_exp_date', $http->postVariable( 'ExpirationMonth' ) . $http->postVariable( 'ExpirationYear' ) );

        // assign card number
        $aim->addField( 'x_card_num', trim( $http->postVariable( 'CardNumber' ) ) );

        // check cvv2 code
        if ( $ini->variable( 'eZAuthorizeSettings', 'CustomerCVV2Check' ) == 'true' )
        {
            // assign card security number, cvv2 code
            $aim->addField( 'x_card_code', trim( $http->postVariable( 'SecurityNumber' ) ) );
        }

        // get order customer information
        if ( $ini->variable( 'eZAuthorizeSettings', 'GetOrderCustomerInformation' ) == 'true' )
        {
            if ( $this->getOrderInfo( $order ) ) {

                // Send customer billing address to authorize.net
                if ( $ini->variable( 'eZAuthorizeSettings', 'CustomerAddressVerification' ) == 'true' )
                {
                    $this->addAVS( $aim );
                }

                // Send customer shipping address to authorize.net
                if ( $ini->variable( 'eZAuthorizeSettings', 'SetCustomerShippingAddress' ) == 'true' )
                {
                    $this->addShipping( $aim );
                }
            }
        }
        
        $aim->addField( 'x_invoice_num', $order->attribute( 'order_nr' ) );
        $aim->addField( 'x_description', 'Order ID #' . $order->attribute( 'order_nr' ) );
        
        // assign customer IP
        $aim->addField( 'x_customer_ip', $_SERVER['REMOTE_ADDR'] );

        // assign customer id
        $aim->addField( 'x_cust_id', $user_id );

        // check send customer confirmation email
        if ( $ini->variable( 'eZAuthorizeSettings', 'CustomerConfirmationEmail' ) == 'true' )
        {
            // assign and send customer confirmation email
            $aim->addField( 'x_email', $user_email );
            $aim->addField( 'x_email_customer', 'TRUE' );
            $aim->addField( 'x_merchant_email', $user_email );
        }

        // get currency code
        $currency_code =  $ini->variable( 'eZAuthorizeSettings', 'CurrencyCode' );

        // assign currency code
        if ( $currency_code != '' )
        {
            $aim->addField( 'x_currency_code', $currency_code );
        }

        // assign variables from order
        $aim->addField( 'x_amount', $order_total_amount );

        // assign merchant account information
        $aim->addField( 'x_login', $ini->variable( 'eZAuthorizeSettings', 'MerchantLogin' ) );
        $aim->addField( 'x_tran_key', $ini->variable( 'eZAuthorizeSettings', 'TransactionKey' ) );

        // set authorize.net mode
        $aim->setTestMode( $ini->variable( 'eZAuthorizeSettings', 'TestMode' ) == 'true' );

        // send payment information to authorize.net
        $aim->sendPayment();
        $response = $aim->getResponse();
        ezDebug::writeDebug( $response, 'eZAuthorizeGateway response'  );
        // Enable MD5Hash Verification
        if ( $ini->variable( 'eZAuthorizeSettings', 'MD5HashVerification' ) == 'true' )
        {
            $md5_hash_secret = $ini->variable( 'eZAuthorizeSettings', 'MD5HashSecretWord' );
            $aim->setMD5String ( $md5_hash_secret, $ini->variable( 'eZAuthorizeSettings', 'MerchantLogin' ), $response['Transaction ID'], $order_total_amount );

            // Enable Optional Debug Output | MD5Hash Compare
            if ( $ini->variable( 'eZAuthorizeSettings', 'Debug' ) == 'true' )
            {
                ezDebug::writeDebug( 'Server md5 hash is ' . $response["MD5 Hash"] . ' and client hash is ' . strtoupper( md5( $aim->getMD5String ) ) . ' from string' . $aim->getMD5String );
            }
            $md5pass = $aim->verifyMD5Hash();
        }
        else
        {
            $md5pass = true;
        }

        if ( $aim->hasError() or !$md5pass)
        {
            if (!$md5pass)
            {
                $errors[] = 'This transaction has failed to
                verify that the use of a secure transaction (MD5 Hash Failed).
                Please contact the site administrator and inform them of
                this error. Please do not try to resubmit payment.';
            }
                $errors[] = $response['Response Reason Text'];

            // note payment failure
            if($failStatusCode)
            {
              $order->modifyStatus($failStatusCode);
            }
            
            return $this->loadForm( $process, $errors );
        }
        else
        {
            // note successful payment
            if($successStatusCode)
            {
              $order->modifyStatus($successStatusCode);
            }        
            
            return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
        }
    }

    /*
    TODO:
    This function need fixes it uses hardcoded values from a shop account handler

    Workaround:
    set INI value eZAuthorizeSettings->GetOrderCustomerInformation = false
    */
    function getOrderInfo( $order )
    {
        // get order information out of eZXML
        $xml = new eZXML();
        $xmlDoc = $order->attribute( 'data_text_1' );

        if( $xmlDoc != null )
        {
            $dom = $xml->domTree( $xmlDoc );

            $order_first_name = $dom->elementsByName( "first-name" );
            $this->order_first_name = $order_first_name[0]->textContent();

            $order_last_name = $dom->elementsByName( "last-name" );
            $this->order_last_name = $order_last_name[0]->textContent();

            $order_email = $dom->elementsByName( "email" );
            $this->order_email = $order_email[0]->textContent();

            $order_street1 = $dom->elementsByName( "street1" );
            $this->order_street1 = $order_street1[0]->textContent();
            $this->order_company = $order_street1;

            $order_street2 = $dom->elementsByName( "street2" );
            $this->order_street2 = $order_street2[0]->textContent();

            $order_zip = $dom->elementsByName( "zip" );
            $this->order_zip = $order_zip[0]->textContent();

            $order_place = $dom->elementsByName( "place" );
            $this->order_place = $order_place[0]->textContent();

            $order_state = $dom->elementsByName( "state" );
            $this->order_state = $order_state[0]->textContent();

            $order_country = $dom->elementsByName( "country" );
            $this->order_country = $order_country[0]->textContent();

            $order_comment = $dom->elementsByName( "comment" );
            $this->order_comment = $order_comment[0]->textContent();
            return true;
        }
        return false;
    }

    function addAVS( $aim ) {
        // customer billing address
        $aim->addField( 'x_first_name', $this->order_first_name );
        $aim->addField( 'x_last_name', $this->order_last_name );
        $aim->addField( 'x_company', $this->order_company );

        $aim->addField( 'x_address', $this->order_street2 );
        $aim->addField( 'x_city', $this->order_place );
        $aim->addField( 'x_state', $this->order_state );
        $aim->addField( 'x_zip', $this->order_zip );
        $aim->addField( 'x_country', str_replace( " ", "%20", $this->order_country ) );
    }

    function addShipping( $aim ) {
        // customer shipping address
        $aim->addField( 'x_ship_to_first_name', $this->order_first_name );
        $aim->addField( 'x_ship_to_last_name', $this->order_last_name );
        $aim->addField( 'x_ship_to_company', $this->order_company );

        $aim->addField( 'x_ship_to_address', $this->order_street2 );
        $aim->addField( 'x_ship_to_city', $this->order_place );
        $aim->addField( 'x_ship_to_state', $this->order_state );
        $aim->addField( 'x_ship_to_zip', $this->order_zip );
        $aim->addField( 'x_ship_to_country', str_replace( " ", "%20", $this->order_country ) );
     }
}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_EZAUTHORIZE, "ezauthorizegateway", "Authorize.Net" );

?>