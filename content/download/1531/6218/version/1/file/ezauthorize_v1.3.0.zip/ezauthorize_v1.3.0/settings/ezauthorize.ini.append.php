[eZAuthorizeSettings]
# Extension Debug
Debug=false

# Better Security avialable from curl version > 7.1
# Respose gets verified
SSLVerify=true

# (Required) Authorize.Net Merchant Login User Name
MerchantLogin=false

# (Required) Authorize.Net Transaction Key
TransactionKey=false

# Enable or Disable Authorize.Net Test Mode
# TestMode disables charing credit card

TestMode=true

## Optional

# Provide Customer CVV2 Code Input Verification
CustomerCVV2Check=false

# Perform Authorize.Net Hash Verification

MD5HashVerification=true
MD5HashSecretWord=publish

# Send Customer Authorize.Net Payment Confirmation Email
CustomerConfirmationEmail=false

# Stock eZ publish provides customer information in order,
# if enabled this sends the address information to Authorize.Net

GetOrderCustomerInformation=true
CustomerAddressVerification=true
SendCustomerShippingAddress=true

# Currency Code of Payment
# Defaults to 'US Dollar/USD'
# See AIM_Guide.pdf Appendix I for a complete list

# CurrencyCode=USD

# The eZAuthorize extension can optionally set status codes on the 
# order to record the interaction with the payment gateway in the 
# order's status history. 
# The Start Status Code will be set just before connecting to 
# Authorize.net, and the Success and Failure Codes will be 
# set depending on the provided response. 

# To use these, create new Order Statuses using the Order Status
# Link in the Webshop tab of the eZ Publish Admin

# StartStatusCode=1000
# SuccessStatusCode=1001
# FailStatusCode=1002
