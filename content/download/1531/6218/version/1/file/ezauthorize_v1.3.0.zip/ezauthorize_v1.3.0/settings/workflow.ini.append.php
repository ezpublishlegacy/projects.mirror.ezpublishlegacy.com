[EventSettings]
ExtensionDirectories[]=ezauthorize
AvailableEventTypes[]=event_ezauthorize
