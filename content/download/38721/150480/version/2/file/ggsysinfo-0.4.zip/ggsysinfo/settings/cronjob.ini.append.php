<?php /*

# for future developments...

#[CronjobSettings]
#ExtensionDirectories[]=ggsysinfo

*/ ?>