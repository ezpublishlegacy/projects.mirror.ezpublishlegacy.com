<?php

$GLOBALS['show_todo_strings'] = false;

?>
