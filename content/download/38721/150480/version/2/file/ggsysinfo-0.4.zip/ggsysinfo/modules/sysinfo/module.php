<?php

// an improved setup/info module
$Module = array( 'name' => 'System Information',
                 'variable_params' => false );

$ViewList = sysinfoModule::viewList();

$FunctionList = array();

?>