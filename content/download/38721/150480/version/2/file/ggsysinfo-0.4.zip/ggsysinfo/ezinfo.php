<?php
class ggsysinfoInfo
{
    static function info()
    {
        return array( 'Name' => "<a href=\"http://projects.ez.no/ggsysinfo\">ggsysinfo</a>",
                      'Version' => "0.4",
                      'Copyright' => "Copyright (C) 2008-2010 Gaetano Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>