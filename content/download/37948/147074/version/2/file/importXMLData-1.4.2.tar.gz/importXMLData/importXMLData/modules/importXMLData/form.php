<?php
//
// Created on: <16-Feb-2005>
//
// Copyright (C) 2005-2004 Olivier Pierret & NSI-SA. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezhttpfile.php" );

global $HTTP_POST_FILES;

$http =& eZHTTPTool::instance();

$Module =& $Params['Module'];

$datatype = $http->postVariable('datatype');
if ($http->postVariable('remove')=='on') $remove=true; else $remove = false;
if ($http->postVariable('movetotrash')=='on') $movetotrash = true; else $movetotrash = false;

if ($http->hasPostVariable( 'submitXMLData' ) && isset($_FILES['xmldata'])) {
	$xmldata = file_get_contents($_FILES['xmldata']['tmp_name']);
	$viewParameters = array( 
		'datatype' => $datatype ,
		'submitXMLData' => $http->PostVariable( 'submitXMLData' ), 
		'xmldata'=>$xmldata,
		'remove'=>$remove,
		'moveToTrash'=>$movetotrash
		);
} else { 
	$viewParameters = array( 'datatype' => $datatype );
}

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$tpl->setVariable( 'view_parameters', $viewParameters );

$Result = array();
$Result['content'] = $tpl->fetch( 'design:importXMLData/form.tpl' );
$Result['path'] = array( array( 'url' => false,
                        'text' => 'importXMLData' ),
                        array( 'url' => false,
                        'text' => 'Formulaire' ) );
?>