<?php
/*
[ExtensionSettings]
DesignExtensions[]=importXMLData
*/
?>