<?php
//
// Created on: <16-Feb-2005>
//
// Copyright (C) 2005-2004 Olivier Pierret & NSI-SA. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//


define( "MODULE_INI_FILE", "module.ini" );
include_once ('lib/phpxpath/XPath.class.php');
include_once ('lib/ezlocale/classes/ezdate.php');
include_once ('lib/ezutils/classes/ezoperationhandler.php');

class importXMLDataFunctionCollection
{

	function importXMLDataFunctionCollection()
	
	{
	}

	function &importXMLData( $xmldata, $datatype, $remove, $movetotrash)
	{ 
		eZINI::setIsDebugEnabled( true );
		$importXMLDataINI =& eZINI::instance( MODULE_INI_FILE,"extension/mymodule/settings" );
		$ImportParamIniSection = 'ImportParams_for_data_' . trim($datatype);
		$identifiantClasse = $importXMLDataINI->variable( $ImportParamIniSection , 'DefaultClassIdentifier' );
		$class =& eZContentClass::fetchByIdentifier( $identifiantClasse );
		//set parent node ID 
		$node_id=$importXMLDataINI->variable( $ImportParamIniSection, 'NodeId' );
		$itemTag=$importXMLDataINI->variable( $ImportParamIniSection, 'ItemTag' );
		$listTag=$importXMLDataINI->variable( $ImportParamIniSection, 'ListTag' );
		$fieldNameList=$importXMLDataINI->variableArray( $ImportParamIniSection, 'FieldNameList' ); 
		// fetch parent node 
 		$node =& eZContentObjectTreeNode::fetch($node_id);
		// set associated object to parent node (folder object) 
		if ( !is_object( $node ) ) {
			eZDebug::writeDebug( "node_id=$node_id doesn't seem to be a valid node id", 'importXMLData' );
			return array( 'result' => array('statut' => "erreur"), 'msg' => "node_id=$node_id doesn't seem to be a valid node id" );  
		}
		$parentContentObject =& $node->attribute( 'object' );
		// set user = current user 
		$user =& eZUser::currentUser();
		// set user ID 
		$userID =& $user->attribute( 'contentobject_id' );
		// set section ID =  parent object section
		$sectionID = $parentContentObject->attribute( 'section_id' );
		if ($remove) {
			$children =& $node->subTree( array( 'Limitation' => array() ) );
			$deleteIDArray = array();
			foreach ($children as $child) {
				array_push ($deleteIDArray, $child->attribute( 'node_id' ));
			}
			eZContentObjectTreeNode::removeSubtrees( $deleteIDArray, $movetotrash );
		}

		if ( !is_object( $class ) ) {
			eZDebug::writeDebug( "DefaultClassIdentifier=$identifiantClasse doesn't seem to be a valid class identifier", 'importXMLData' );
			return array( 'result' => array('statut' => "erreur"), 'msg' => "DefaultClassIdentifier=$identifiantClasse doesn't seem to be a valid class identifier" );  
		}
		$contactList = array();
		$i=0;
		$xPathEngine = new XPathEngine();
		$xPathEngine->importFromString($xmldata);
		$paths_item = $xPathEngine->match("//$listTag/$itemTag");
		$isAcountObject=false;
		foreach ($paths_item as $path_item) {
			foreach($fieldNameList as $fieldName) {
				$fieldValue = $xPathEngine->wholeText("$path_item/$fieldName"."[1]");
				$parsedItems[$i][$fieldName]=$fieldValue;
				if ($fieldName=='account-login') $isAcountObject=true;
			}
			//create the new object
			$contentObject =& $class->instantiate( $userID, $sectionID );

			//assign new object to parent node
			$nodeAssignment =& eZNodeAssignment::create( array(
					 'contentobject_id' => $contentObject->attribute( 'id' ),
					 'contentobject_version' => $contentObject->attribute( 'current_version' ),
					 'parent_node' => $node->attribute( 'node_id' ),
					 'is_main' => 1 ));
			$nodeAssignment->store();

			// Set a status for the content object version
			$contentObjectVersion =& $contentObject->version($contentObject->attribute( 'current_version' ) );
			$contentObjectVersion->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT);
			$contentObjectVersion->store();

			// enumerate attributes of the new object to set them
			$contentObjectAttributes =& $contentObjectVersion->contentObjectAttributes();
			foreach ($contentObjectAttributes as $attribute)
			{
				// Each attribute has an attribute called 'identifier' that identifies it.
				if (isset($parsedItems[$i][$attribute->attribute("contentclass_attribute_identifier")]))
				{  
					$data_type_string = $attribute->attribute('data_type_string');
					$xml_content_string = $parsedItems[$i][$attribute->attribute("contentclass_attribute_identifier")];
					switch( $data_type_string ) {
					case 'ezinteger':
						$attribute->setAttribute("data_int",intval($xml_content_string));
						break;
					case 'ezstring':
					case 'eztext':
					case 'ezemail':
					case 'ezisbn':
						$attribute->setAttribute("data_text",$xml_content_string);
						break;
					case 'ezprice':
					case 'ezfloat':
						$attribute->setAttribute("data_float",floatval($xml_content_string));
						break;
					case 'ezboolean':
						if ($xml_content_string == "true") 
							$attribute->setAttribute("data_int",1);
						else
							$attribute->setAttribute("data_int",0);	
						break;
					case 'ezdate':
						$date = new eZDate(strtotime($xml_content_string));
						$attribute->setAttribute("data_int",$date->timeStamp());
						break;
					case 'ezdatetime':
						$date = new eZDateTime(strtotime($xml_content_string));
						$attribute->setAttribute("data_int",$date->timeStamp());
						break;
					case "ezurl":
 						$urlID =& eZURL::registerURL( $xml_content_string );
 						$attribute->setAttribute( 'data_text', $xml_content_string );
 						// store ezurl id in data_int
						eZDebug::writeDebug( "\$urlID = $urlID", 'importXMLData' );
						$attribute->setAttribute( 'data_int', $urlID );
 						break;
					default :
						eZDebug::writeDebug( 'data_type_string: ' . $data_type_string . ' not supported', 'importXMLData' );
					}	
					$attribute->store();
				}
			}
			//If we have account data we have to create a ezUser persistent object and set account values to this object
			if ($isAcountObject) {
				//create new user
				$objectId = $contentObject->attribute( 'id' );
				if ($userID>0) { 
					$user =& new eZUser( $objectId );

					$user->setAttribute('login', $parsedItems[$i]['account-login'] );
					$user->setAttribute('email', $parsedItems[$i]['account-email'] );

					$hashType = eZUser::hashType() . "";
					$newHash = $user->createHash( $parsedItems[$i]['account-login'], $parsedItems[$i]['account-password'], eZUser::site(), $hashType );

					$user->setAttribute( "password_hash_type", $hashType );
					$user->setAttribute( "password_hash", $newHash );

					$user->store();
				} else {
					eZDebug::writeError("error \$objectId invalid (value: $objectId)","ImportXMLDatafunctioncollection");
				}

			}
			
			//publish the newly created node
			$operationResult = eZOperationHandler::execute( 'content', 
															'publish', array( 'object_id' => $contentObject->attribute( 'id' ),
															'version' => $contentObject->attribute( 'current_version' ) ) );
			//eZDebug::writeDebug( 'execute content publish: '.$operationResult['status'], 'importXMLData' ); 
			$i=$i+1;
		}
		$result['keys']= $fieldNameList;
		$result['data']= $parsedItems;
		return array( 'result' => &$result ); 
	}	
}
?>