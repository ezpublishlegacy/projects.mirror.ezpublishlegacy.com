<?php

class OWMigrationContentClassException extends Exception {
}
