<?php

// vim600: noet sw=4 ts=4 fdm=marker

// Created on: <07-12-2006 19:55:23 jr>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.6
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of version 2.0 of the GNU General
//  Public License as published by the Free Software Foundation.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//  GNU General Public License for more details.
//
//  You should have received a copy of version 2.0 of the GNU General
//  Public License along with this program; if not, write to the Free
//  Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//  MA 02110-1301, USA.
//
//

include_once( 'lib/ezxml/classes/ezxml.php' ) ;
include_once( 'lib/ezutils/classes/ezini.php' ) ;
include_once( 'lib/ezutils/classes/ezlog.php' ) ;
include_once( 'feed.php' ) ;

/*!

 \class FeedParser feed_parser.php

 \brief FeedParser handles a feed correctness

 Once the feed has been tested, FeedParser
 returns either an AtomParser object or
 an RssParser object.
*/
class FeedParser
{
	// {{{ Factory()

	/*!
	  Returns an object depending of the type
	  of feed you passed in the URL.

	  Factory will return an AtomParser object if the given URL
	  points to an Atom Feed.

	  Factory will return an RssParser object if the given URL
	  points to :
	  - an RSS 2.0 feed
	  - an RDF 1.0 feed
	  - an RSS 0.91 feed
	  - an RSS 0.92 feed

	  Factory will return false in all other cases
	*/
	function Factory ( $URL )
	{
	    $iniInstance   =& eZINI::instance( 'module.ini' ) ;
	    $tempDirectory = $iniInstance->variable( 'FeedParser', 'TempDirectory' ) ;
	    $maxLifeTime   = $iniInstance->variable( 'FeedParser', 'CacheTime' ) ;
	    
	    $urlFeed = $URL ;
	    
	    $file = $tempDirectory . md5( $URL ) ;
		
	    if( file_exists( $file ) )
	    {
    		$localFileNameMTime = filemtime( $file ) ;
    		clearstatcache() ;
    		$localFileNameAge = time() - $localFileNameMTime ;
    		
    		if ( $localFileNameAge < $maxLifeTime ) 
    		{
    			$urlFeed = $file ;
    		}
	        
	        clearstatcache() ;
	    }

		$feedInfos = FeedParser::_autoDetect( $urlFeed ) ;

		if ( !$feedInfos )
		{
            return false ;
		}

		switch ( $feedInfos['type'] )
		{
		    // RSS
			case 'rss':
		    {
                include_once( 'rss_parser.php' ) ;
                return new RssParser( $URL, $feedInfos['version'] ) ;
		    } break;

		    // Atom
			case 'atom':
		    {
                include_once( 'atom_parser.php' ) ;
                return new AtomParser( $URL ) ;
		    } break;

		    default:
	        {
                return false ;
	        } break ;
		}
	}

	// }}}

	// {{{ _autoDetect()

	/*!
	  \private
	  \static

	  _autoDetect ... detects the type of feed given in the URL
	  
	  Recognized feed are:
	  - RSS 0.91
	  - RSS 0.92
	  - RSS 1.0
	  - RSS 2.0
	  - Atom
	  
	  \return An array with two indexes:
	  - type : feed type : RSS or Atom
	  - version : feed version, empty for Atom
	*/
	function _autoDetect( $URL )
	{
        $content = file_get_contents( $URL ) ;

        if ( empty( $content ) or $content == false )
        {
			eZLog::write( 'Unable to download the file ' . $URL ,  'feeds.log' );
            return false ;
        }

        $patterns = array(
            '#<rss(?:.*)version=(?:"|\')(0.91)(?:"|\')[>]?#i',               // RSS 0.91
            '#<rss(?:.*)version=(?:"|\')(0.92)(?:"|\')[>]?#i',               // RSS 0.92
            '#xmlns=(?:"|\')http://purl.org/rss/(1.0)(?:/)?(?:"|\')#i',      // RSS 1.0
            '#<rss(?:.*)version=(?:"|\')(2.0)(?:"|\')[>]?#i' ,               // RSS 2.0
            '#(?:xmlns=(?:"|\')http://www.w3.org/2005/(Atom)(?:"|\'))|(?:xmlns="http://purl.org/(atom)/[a-z]?)#i') ; // ATOM

        foreach ( $patterns as $pattern )
        {
        	if ( preg_match( $pattern, $content, $matches) )
        	{
        	    if ( !empty( $matches[1] ) )
        	    {
        	       $version = strtolower( $matches[1] ) ;
        	    }
        	    else
        	    {
        	       $version = strtolower( $matches[2] ) ;
        	    }

        	    // Atom
        	    if ( $version == 'atom' )
        	    {
        	    	$result = array( 'type'    => 'atom',
        	    	                 'version' => '' ) ;
        	    }
        	    // RSS
        	    else
        	    {
        	    	$result = array( 'type'    => 'rss',
        	    	                 'version' => $version ) ;
        	    }
                return $result ;
        	}
        }
        return false ;
	}

	// }}}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>