<?php /* #?ini charset="iso-8859-1"?
[ModuleSettings]
ExtensionRepositories[]=feed_parser

[FeedParser]
# Absolute path to the cache directory
# If it does not exist, it will be created
# Do not forget the trailing slash
# Make sure the rights on this directory are configured correctly
TempDirectory=var/cache/feeds/

# Time (in seconds) where the RSS feed should be cached
# 5 minutes by default
CacheTime=300
*/ ?>
