<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=feed_parser
*/ ?>
