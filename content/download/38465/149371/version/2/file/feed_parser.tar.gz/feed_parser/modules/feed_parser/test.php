<?php

// vim600: noet sw=4 ts=4 fdm=marker

include_once( 'kernel/common/template.php' );

$tpl =& templateInit() ;

$Result = array();

$Result['content'] =& $tpl->fetch( 'design:feed_parser/feed_parser.tpl' );

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
