<?php

// vim600: noet sw=4 ts=4 fdm=marker

include_once( 'extension/feed_parser/modules/feed_parser/classes/feed_parser.php' ) ;

class FeedParserFunctionCollection
{
    // {{{ parseFeed()

    /*!
       Parses the RSS/Atom feed defined by $feedUrl and return the number of entries defined by
       $itemNumber.
       
       \return An array with the results
     */
    function parseFeed( $feedUrl, $itemNumber )
    {
		$parser = FeedParser::Factory( $feedUrl ) ;

        if ( !$parser )
        {
            $this->_errorsArray[] = 'Incorrect feed' ;
        }
		else if ( !$parser->parse() )
		{
			$this->_errorsArray[] = $feedUrl ;
		}

        if ( isset( $parser->feedContent['items'] ) )
        {
    		$arrayResult = $this->_cutItemsArray( $parser->feedContent, $itemNumber ) ;
        }
        else
        {
    		$this->_errorsArray[] = 'No informations' ;
        }

        $arrayResult['errors'] = $this->_errorsArray ;

		return array( 'result' => $arrayResult ) ;
    }

    // }}}

	// {{{_cutItemsArray

	function _cutItemsArray( $arrayFeed,  $nb )
	{
		$longueur = sizeof( $arrayFeed['items'] ) ;

		for( $i = $longueur; $i > $nb; $i--)
		{
			array_pop( $arrayFeed['items'] ) ;
		}

		return $arrayFeed ;
	}

	// }}}
	
    // {{{ attributes

	var $_itemsArray = array() ;
	var $_errorsArray = array() ;

	// }}}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
