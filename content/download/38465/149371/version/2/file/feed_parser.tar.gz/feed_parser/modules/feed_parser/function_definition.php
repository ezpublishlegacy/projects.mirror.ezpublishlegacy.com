<?php

// vim600: noet sw=4 ts=4 fdm=marker

$FunctionList = array();

$FunctionList['parsefeed'] = array(
    'name'        => 'parsefeed',
    'call_method' => array(

        'include_file' => 'extension/feed_parser/modules/feed_parser/feed_parserfunctioncollection.php',
        'class'        => 'FeedParserFunctionCollection',
        'method'       => 'parseFeed' ),

    'parameter_type' => 'standard',
    'parameters'     => array( array( 'name'     => 'feedUrl',
									  'type'     => 'string',
									  'required' => true ),

                               array( 'name'     => 'itemNumber',
									  'type'     => 'integer',
									  'required' => true ) ) ) ;

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
