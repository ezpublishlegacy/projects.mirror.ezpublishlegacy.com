<?php

// vim600: noet sw=4 ts=4 fdm=marker

$Module = array( 'name' => 'feed_parser' );

$ViewList = array();

$ViewList['test'] = array(

   'script' => 'test.php',
   'params' => array ( ) ) ;

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
