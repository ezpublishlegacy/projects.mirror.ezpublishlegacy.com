<?php

// vim600: noet sw=4 ts=4 fdm=marker

// Created on: <07-12-2006 19:55:23 jr>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.6
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of version 2.0 of the GNU General
//  Public License as published by the Free Software Foundation.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//  GNU General Public License for more details.
//
//  You should have received a copy of version 2.0 of the GNU General
//  Public License along with this program; if not, write to the Free
//  Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//  MA 02110-1301, USA.
//
//

/*!

  \class RssParser rss_parser.php

  \brief Handles the parsing of RSS files

  See also this class:

  \sa AtomParser, FeedParser
 */
class RssParser extends Feed
{
    // {{{ RssParser

    /*!
	  Constructor of the class.
	  Defines the version of the RSS feed
    */
	function RssParser( $URL, $version )
	{
	    parent::Feed( $URL ) ;

	    $this->version = $version ;
	    $this->feedContent['version'] = $this->version ;
	}

	// }}}

	// {{{ parse()
	
	/*!
	  Parses the RSSfeed
	*/
	function parse()
	{
	    $eZDomTree = parent::createEzDomTree() ;

	    if( !$eZDomTree )
	       return false ;

	    $root = 'rss' ;

		if ( $this->version == '1.0' )
		{
            $root = 'RDF' ;
		}

		$rssNodes = $eZDomTree->elementsbyName( $root ) ;

		foreach ( $rssNodes as $rssNode )
		{
			$this->_parseEzDomNode( $rssNode ) ;
		}

		return true ;
	}

	// }}}

	// {{{ _parseEzDomNode()

	/*!
	   \private
	   Parses the eZDomNode passed in parameter
	*/
	function _parseEzDomNode( $eZDOMNode )
	{
	    // $nodeName = $eZDOMNode->Name ;

        $nodeName = $this->_setNodeName( $eZDOMNode ) ;

		if( $nodeName != '#text')
		{
            if ( $eZDOMNode->hasChildren() )
            {
                foreach ( $eZDOMNode->Children() as $child )
                {
                    $childName = strtolower( $child->Name ) ;

                    if ( $childName == 'channel' )
                    {
                    	$this->feedContent['channel'] = array() ;
                    	$this->_currentArrayIndex = 'channel' ;
                    }

                    // RSS 0.91
                    if ( $childName == 'image' )
                    {
                    	$this->feedContent['image'] = array() ;
                    	$this->_currentArrayIndex = 'image' ;
                    }

                    // RSS 1.0
                    if ( $childName == 'seq' )
                    {
                    	continue ;
                    }

                    if ( $childName == 'item' )
                    {
                    	$this->_setItem( $child );
                    	continue;
                    }

                    if ( ( $child->Name == '#cdata-section' ) or ( $child->Name == '#text') )
                    {
                        $this->feedContent[ $this->_currentArrayIndex ]
                                          [ $nodeName ]
                                          ['value'] = $child->Content ;
                    }

                    if ( $child->hasAttributes() )
                    {
                        foreach ( $child->attributes() as $attribute)
                        {
                            $this->feedContent[ $this->_currentArrayIndex ]
                                              [ $childName ]
                                              ['attributes']
                                              [ strtolower( $attribute->Name ) ]
                                              ['value'] = $attribute->Content ;
                        }
                    }
                    $this->_parseEzDomNode( $child ) ;
                }
            }
		}
	}

	// }}}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
