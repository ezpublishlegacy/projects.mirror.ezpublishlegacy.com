<?php

// vim600: noet sw=4 ts=4 fdm=marker

// Created on: <07-12-2006 19:55:23 jr>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.6
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of version 2.0 of the GNU General
//  Public License as published by the Free Software Foundation.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//  GNU General Public License for more details.
//
//  You should have received a copy of version 2.0 of the GNU General
//  Public License along with this program; if not, write to the Free
//  Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//  MA 02110-1301, USA.
//
//

/*!
 \class Feed feed.php
 \brief Feed handles the parsing of feed files regardless of the feed type

 Feed contains common methods used by AtomParser and RssParser.

 Here is a code example:
 <?php
  $feedInstance = FeedParser::factory( $fileOrURL ) ;
  $feedInstance->parse() ;
  var_dump($feedInstance->feedContent);
 ?>

  \sa feed_parser.tpl
*/
class Feed
{

    // {{{ Feed

	function Feed( $URL )
	{
		$this->URL = $URL ;

		$iniInstance =& eZINI::instance('module.ini') ;
		$this->_tempDirectory = $iniInstance->variable( 'FeedParser', 'TempDirectory') ;
		$this->_feedCacheTime = $iniInstance->variable( 'FeedParser', 'CacheTime') ;

		$this->_setLocalFileName() ;

		$this->_downloadStatus = $this->_downloadFeed() ;
	}

	// }}}

	// {{{ createEzDomTree()

	/*!
	  Creates the eZDomTree by means of the feed downloaded

	  \return the newly created eZDomTree
	 */
	function createEzDomTree ()
	{
	    if( !$this->_downloadStatus )
		{
			return false ;
		}

		$content = file_get_contents( $this->_localFileName ) ;

		if ( empty( $content ) )
		{
            return  false ;
		}

		$domXml = new eZXML() ;
		$domTree =& $domXml->domTree( $content ) ;

        return $domTree ;
	}

	// }}}

	// {{{ _downloadFeed()

	/*!
	   Downloads the file from the given URL
	   If the cache directory does not exists, it will be created

	   \return bool if the operation succeds, false otherwise
	 */
	function _downloadFeed ()
	{
		if ( !is_dir( $this->_tempDirectory ) )
		{
			if ( !mkdir( $this->_tempDirectory  ) )
			{
				return false ;
			}
		}

		if ( !$this->_cacheValid() ) 
		{
			if ( !copy( $this->URL, $this->_localFileName ) )
			{
                return false ;   
			}
		}

		return true ;
	}

	// }}}

	// {{{ cacheValid()
	
	/*!
	   Test if if the cache file is stale or not
	   
	  \return true if valid, false if stale
	 */
	function _cacheValid()
	{
		if ( !file_exists( $this->_localFileName ) )
		{
            return false ;
		}
	    
		$localFileNameMTime = filemtime( $this->_localFileName ) ;

		clearstatcache() ;

		$now = time() ;

		$localFileNameAge = $now - $localFileNameMTime ;
		
		if ( $localFileNameAge > $this->_feedCacheTime ) 
		{
            return false ;   
		}   
		else 
		{
		    return true ;
		}
		
		return true ;
	}
	
	// }}}

 	// {{{ _setLocalFileName

    /*!
	   Defines the file name for the cache copy
     */
	function _setLocalFileName ()
	{
	    $this->_localFileName = $this->_tempDirectory . md5( $this->URL ) ;
	}

	// }}}

	// {{{ _setItems

	/*!
	  Defines and fill the items array

	  \return array
     */
	function _setItem( $itemNode )
	{
		$item = array() ;

		foreach( $itemNode->Children as $node )
		{
            $nodeName = $this->_setNodeName( $node ) ;

			foreach( $node->Children as $children )
			{
                $item[ $nodeName ]['value'] = $children->Content ;
			}

            if ( $node->hasAttributes() )
            {
                foreach ( $node->Attributes as $attribute )
                {
                    $attributeName = strtolower($attribute->Name) ;

                    $attributeValue = $attribute->Content ;

                    if ( $attributeValue == 'alternate' )
                        $nodeName .= '-alternate' ;

                    if ( $attributeValue == 'enclosure' )
                    	$nodeName .= '-enclosure' ;

                   	$item[ $nodeName ]
                   	     ['attributes']
                   	     [$attributeName]
                   	     ['value'] = $attribute->Content ;
                }
            }
		}
		$this->feedContent['items'][] = $item ;
	}

	// }}}
	
	// {{{ _setNodeNAme( $node )
	
	/*!
	   Returns the name of the current node
	   
	   If the XML tag is prefixed, the prefix will only be returned in lowercase

	   Example :
	   
	   <content:encoded> => content
	   <content>         => content
	   
	   $node is the node you want to get the name
	   
	   \return The node name in lowercase
	 */
	function _setNodeName( $node )
	{
	    $nodeName = '' ;

	    if ( $node->Prefix !== false )
	    {
	    	$nodeName = $node->Prefix ;
	    }
	    else
	    {
            $nodeName = $node->Name ;
	    }

	    return strtolower( $nodeName ) ;
	}

	// }}}
	
	// {{{ attributes

	//// \ privatesection

	var $URL ;
	var $_downloadStatus = false ;
	var $_localFileName ;
	var $_tempDirectory ;
	var $feedContent = array() ;
	var $_feedCacheTime ;
	var $version = null ;
	var $_currentArrayIndex ;

	// }}}

}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */

?>
