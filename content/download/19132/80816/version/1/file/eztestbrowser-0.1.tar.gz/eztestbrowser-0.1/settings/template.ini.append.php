<?php /*

[PHP]
PHPOperatorList[date_format]=date_format

*/ ?>