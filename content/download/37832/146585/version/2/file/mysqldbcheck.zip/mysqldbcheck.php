<?php
//
// mysqldbcheck.php, checks all tables in MySQL database for errors and tries to repair them if found.
// Checks the database specified in the siteaccess
// Logs to $checkMySQLdbLog and optionally send email with log to $mailto
// See CONFIG section for all options 
// See install.txt for installation instructions.
//
// Created on: <27-Jan-2005 15:00:00 oh>
// Version: 0.9 beta
// Created by: Ralph Ekekihl, ralph@contactivity.com
// Contactivity bv, Leiden the Netherlands
// info@contactivity.com, http://www.contactivity.com
//
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// This script should be saved as mysqldbcheck.php in folder ezpublish/cronjobs
// The following line should be added underneath the CronjobSettings heading in the cronjob.ini settings file:
//
// Scripts[]=mysqldbcheck.php
//
//


include_once( "lib/ezutils/classes/ezdebug.php" );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( 'lib/ezlocale/classes/ezdatetime.php' );
include_once( "lib/ezutils/classes/ezsys.php" );

/**    START CONFIG     **/

//log settings
$ini =& eZINI::instance( );
$logDir = $ini->variable( 'FileSettings', 'LogDir' );
$sys =& eZSys::instance();
$varDir = $sys->varDirectory();
$checkMySQLdbLog = "checkmysqldb.log";

//database settings
$db = $ini->variable( 'DatabaseSettings','Database' );
$host = $ini->variable( 'DatabaseSettings','Server' );
$user = $ini->variable( 'DatabaseSettings','User' );
$password = $ini->variable( 'DatabaseSettings','Password' );

//script settings
$optimize_tables = true;							//Set to false to disable optimize on tables
$maillevel = 3;									//Mail level, 1=never send mail, 2=always send mail, 3=only send mail when errors are encountered, 4=send mail with errors when you least expect it.
$loglevel = 2;									//Log level, 1 = log errors, 2 = log everything

//mail settings
$mailto = "admin1@yourserver.com, admin2@yourserver.com";			//mail to adresses, comma seperated
$mailfrom = "ezpublish@yourserver.com";						//mail from adress
$headers  = "MIME-Version: 1.0\n";						//Header info
$headers .= "Content-type: text/plain; charset=iso-8859-1\n";    		//Header info text/plain, sets charset
$headers .= "From: eZpublish cronjob MySQL table check script <".$mailfrom.">\n"; //Header info From

/**    END CONFIG      **/



/**   MAIN      **/

//Connect to the db, Not using eZ publish's db layer because doing repair. Minimizing the risk for errors by not using any extra layers of code
$connection = mysql_connect ($host, $user, $password);
mysql_select_db($db);

$st = new eZDateTime();
$log = "\r\n\r\n[".$st->toString()."] Started checking database ".$db." for errors.\r\n";

if ( !$isQuiet )
	 $cli->output(  "[".$st->toString()."] Started checking database \"". $db. "\" for errors.");

$result = mysql_list_tables($db);
	while ($table = mysql_fetch_row($result))
	 {
		 table_check_repair($table[0], $db, $host, $user, $password, $loglevel, $optimize_tables);
	 }

$dt = new eZDateTime();
$log .= "\r\n[".$dt->toString()."] Finished checking database ".$db.".\r\n\r\n";

if ($failed_tables) {
	$log .= "\r\n[".$dt->toString()."] Warning: Errors found in ".$db.".\r\n\r\n";
}

if ( !$isQuiet )
	$cli->output("[".$dt->toString()."] Finished checking database \"". $db. "\".");


if ( !file_exists( $varDir . "/" . $logDir ) )
{
	include_once( 'lib/ezfile/classes/ezdir.php' );
	if ( !eZDir::mkdir( $varDir . "/" . $logDir, 0777, true ) )
	{
		if ( !$isQuiet )
			$cli->output("Couldn't create log directory, perhaps wrong permissions.");
	}
}

$fh = fopen( $varDir . "/" . $logDir . "/" . $checkMySQLdbLog, "a" );
	if ( $fh )
	{
		fwrite( $fh, $log );
		fclose( $fh );
	}

mysql_free_result($result);

/**  SEND MAIL   **/

switch ($maillevel)
	{
		case 1: //never send mail
		break;

		case 2://always send mail
		if ($failed_tables) {
			//Errors were encountered
			mail($mailto, "MySQL table check: errors found","Database ".$db." had errors. Tabel: ".$failed_tables." had errors. Error log: ".$log, $headers);
		} else {
			//No errors were encountered
			mail($mailto, "MySQL table check: no errors found","Database ".$db." has been checked for errors and no corrupted tables were found.", $headers);
		}
		break;

		case 3://only send a mail when errors are encountered
		if ($failed_tables) {
			//Errors were encountered
			mail($mailto, "MySQL table check: errors found", "Database ".$db." had errors. Tabel: ".$failed_tables." had errors. Error log: ".$log, $headers);
		}
		break;
	}



/**   FUNCTION TABLE CHECK & REPAIR      **/

function table_check_repair($dbname, $db, $host, $user, $password, $loglevel, $optimize_tables)
 {
	global $cli;
	global $isQuiet;
	global $log;
	global $failed_tables;

	$connection = mysql_connect ($host, $user, $password);
  	mysql_select_db($db);
	$check = "CHECK TABLE `$dbname` EXTENDED";
	$results = mysql_db_query($db, $check, $connection);
	$results = mysql_fetch_array ($results);

	if ( !$isQuiet )
   			 $cli->output(  "Checking table ".$dbname);

	if ($loglevel==2)
    	$log .="\r\nChecking table ".$dbname.".\r\nTable results: $results[Table] -> $results[Msg_text]\r\n";
	
	
	if( stristr($results['Msg_text'], "closed the table properly") ) 
			{
		
		$repair = "REPAIR TABLE `$dbname` QUICK";
   		$results = mysql_db_query($db, $repair, $connection);
		$results = mysql_fetch_array ($results);
			if ($loglevel==2)
				{
				$log .= "The table ".$dbname." has not been closed properly or is in use. A quick repair was attempted.\r\n";
				$log .= "Quick repair results: $results[Table] -> $results[Msg_text]\r\n";
				}
			}
	
        	
		
			if ($results['Msg_text'] != "OK")
				{
					
				$log .= "The table ".$dbname." did not check out well. A quick repair was attempted.\r\n";
				$failed_tables .= $dbname.", ";
				$repair1 = "REPAIR TABLE `$dbname` QUICK";
				$results = mysql_db_query($db, $repair1, $connection);
				$results = mysql_fetch_array ($results);
				$log .= "Quick repair results: $results[Table] -> $results[Msg_text]\r\n";
		
				if ($results['Msg_text'] != "OK")
				{
					$log .= "The quick repair on table   ".$dbname." failed. A extended repair will be attempted.\r\n";
					$repair2 = "REPAIR TABLE `$dbname` EXTENDED";
					$results = mysql_db_query($db, $repair2, $connection);
					$results = mysql_fetch_array ($results);
					$log .= "Extended repair results: $results[Table] -> $results[Msg_text]\r\n";
		
						if ($results['Msg_text'] != "OK")
						 {
								$optimize_tables = false;
								$log .= "The extended repair on table   ".$dbname." failed. The last repair that was attempted failed.\r\nTable ".$dbname." requires attention!! Check it with mysqlcheck or myisamchk.\r\n";
						 }
				 }
		
			}

	if ($optimize_tables)
	{
		$optimize = "OPTIMIZE TABLE `$dbname`";
		$results = mysql_db_query($db, $optimize, $connection);
		$results = mysql_fetch_array ($results);

		if ($loglevel==2)
    		$log .= "Optimizing  ".$dbname.".\r\nOptimize results: $results[Table] -> $results[Msg_text].\r\n";
	}

}

?>
