/**
 * @author      LIU Bin <bin.liu@lagardere-active.com>
 * 
 /

Requirement
Ez4.0.1 

Objectif 
Add some feature in the base EZ staticcache.
1. don't add  "/content/view/x" directly in table ezpending_action
2. check if exist the keywords in template like : <!--lagardere--> when cache genereted. if no keyword, it means the page is genereted incorrectly, so don't add in ezpending_actions  
3. add costum url in table ezpending_actions by lastaticcache.ini. it's useful for the pagination.
4. define costum url don't generate staticcache

Install
1. add ActiveExtensions[]=lastaticcache in site.ini
2. make you custom staticurlhandler. by default, it use the lastaticurlhandler. and excute php bin/php/ezpgenerateautoloads.php
3. add the keyword in all your override template.
4. config lastaticcache.ini 
5. config staticcache.ini see http://ez.no/download/ez_publish/changelogs/ez_publish_3_6/new_features/static_caching_of_content
6. copy extension/lastaticcache/bin/php/lamakestaticcache.php in bin/php/lamakestaticcache.php of the root
7. excute "php bin/php/lamakestaticcache.php" for the first time.
8. add cronjob lacleancache in your cronjob
runcronjob command:/opt/php/default/bin/php runcronjobs.php lacleancache
9. hack in kernel/classes/ezcontentcachemanager.php
and kernel/classes/ezcontentobjecttreenode.php
$staticCache = new eZStaticCache();
like
$staticCache = new LAeZStaticCache();

ps. Use it with ezsi ( apache include block ).