<?php /* #?ini charset="utf-8"?
#?ini charset="iso-8859-1"?
# eZ Publish configuration file.
#
# NOTE: It is not recommended to edit this file directly, instead
#       a file in override should be created for setting the
#       values that is required for your site. Either create
#       a file called settings/override/staticcache.ini.append or
#       settings/override/staticcache.ini.append.php for more security
#       in non-virtualhost modes (the .php file may already be present
#       and can be used for this purpose).


[CacheSettings]
#change it for you costum url handler
#StaticURLHandler=la
#example : use test handler
StaticURLHandler=ellecn

#we check if the keyword of template is in the cache genereted. 
#if the page is created with error. so no keyword in cache, don't add it in ezpending_actions
UseKeywordForAvoidBadCacheGenereted=enabled


#add <!-- lagardre --> in all your override templetes
KeywordForAvoidBadCacheGenereted=lagardere

[general_article]
AdditionURLs[]=/(offset)/1
AdditionURLs[]=/(offset)/2
AdditionURLs[]=/(offset)/3
AdditionURLs[]=/(offset)/4
AdditionURLs[]=/(offset)/5

[with_pagination_nodes]
with_pagination_node[]=90
with_pagination_node[]=612

#void these class identifier create staticcache
[CheckURL]
filter_class_identifier[]=
filter_class_identifier[]=bloc_programmable
filter_class_identifier[]=get_the_look_item
filter_class_identifier[]=teaser
filter_class_identifier[]=general_article_subpage 
?>