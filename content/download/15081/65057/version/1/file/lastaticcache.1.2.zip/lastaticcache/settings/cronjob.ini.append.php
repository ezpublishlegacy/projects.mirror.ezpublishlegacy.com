<?php
/*
#?ini charset="iso-8859-1"?
# eZ publish configuration file for cronjobs.

[CronjobSettings]
ScriptDirectories[]=extension/lastaticcache/cronjobs/

[CronjobPart-lacleancache]
Scripts[]=lastaticcache_cleanup.php

***/
?>