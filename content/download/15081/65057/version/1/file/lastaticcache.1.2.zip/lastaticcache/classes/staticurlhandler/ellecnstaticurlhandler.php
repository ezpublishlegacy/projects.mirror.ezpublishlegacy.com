<?php
class ellecnStaticURLHandler extends laStaticURLHandler
{
	function addURL($url)
	{
		$urls_addition = array();
		
		if( $this->ini->hasVariable( $url, 'AdditionURLs' ) )
		{
			$urls_addition = $this->ini->variable( $url, 'AdditionURLs' );
		}
		$node_id = eZURLAliasML::fetchNodeIDByPath(  $url );
		
		if ($url == "/") $urls_addition[] = "/(d)/1";
		
		//generate article offset
		if($node_id && $node = eZContentObjectTreeNode::fetch($node_id) )
		{
			$class_identifier = $node->attribute('class_identifier');
			if($this->ini->hasVariable( $class_identifier, 'AdditionURLs' ))
			foreach ($this->ini->variable( $class_identifier, 'AdditionURLs' ) as $addurl)
			{
				$urls_addition[] = $url . $addurl;
			}
		}
		
		//subchannel offset 
		$with_pagination_nodes = $this->ini->variable( "with_pagination_nodes", 'with_pagination_node' );
		if ( $node_id && in_array($node_id,$with_pagination_nodes) )
		{
			for ($page=0;$page<6;$page++)
			{
				$urls_addition[] = $url . "/(offset)/" . $page * 6;
			}
		}
		return $urls_addition;
	}
	
	function checkURL($url)
	{
		$node_id = eZURLAliasML::fetchNodeIDByPath(  $url );
		if($node_id && $node = eZContentObjectTreeNode::fetch($node_id))
		{	
			//if the node is invisible, we don't create staticcache
			if($node->attribute("is_invisible") == true) return false;
			
			//if the node's class identifier is in the filter_class_identifier list, we don't create staticcache.
			$class_identifier = $node->attribute('class_identifier');
			if (in_array($class_identifier,$this->ini->variable( "CheckURL", 'filter_class_identifier' )))
			{
				return false;
			}
		}
		return true;
	}
}
?>