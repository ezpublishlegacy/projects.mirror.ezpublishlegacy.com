<?php /* #?ini charset="utf-8"?

[VersionManagement]

# Store only 1 version for a blog post
VersionHistoryClass[planet_blogpost]=1

*/ ?>