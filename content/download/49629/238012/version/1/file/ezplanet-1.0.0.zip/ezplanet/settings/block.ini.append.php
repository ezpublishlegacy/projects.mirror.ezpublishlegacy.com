<?php /* #?ini charset="utf-8"?

[General]
AllowedTypes[]=ezPlanetPeople
AllowedTypes[]=ezPlanetTagCloud


#
# Block which displays the bloggers (~ people) list
#
[ezPlanetPeople]
Name=[ezPlanet] People
ManualAddingOfItems=disabled
CustomAttributes[]
ViewList[]=ezplanet_people
ViewName[ezplanet_people]=[ezPlanet] People

#
# Block which displays a tag cloud from blog posts
#
[ezPlanetTagCloud]
Name=[ezPlanet] Tag cloud
ManualAddingOfItems=disabled
CustomAttributes[]
ViewList[]=ezplanet_tagcloud
ViewName[ezplanet_tagcloud]=[ezPlanet] Tag cloud
CustomAttributes[]
CustomAttributes[]=limit

*/ ?>