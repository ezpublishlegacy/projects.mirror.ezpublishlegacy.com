<?php /* #?ini charset="utf-8"?

[eZPlanet]
# Tidy configuration
# Look at http://tidy.sourceforge.net/docs/quickref.html
# HTML, XHTML, XML Options Reference
Configuration[alt-text]=
Configuration[output-xhtml]=1
Configuration[show-body-only]=1
# Diagnostics Options Reference
# Pretty Print Options Reference
Configuration[wrap]=0
# Character Encoding Options Reference
# Miscellaneous Options Reference

*/ ?>