<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezplanet

[CronjobPart-planet]
Scripts[]
Scripts[]=planet_import.php

*/ ?>