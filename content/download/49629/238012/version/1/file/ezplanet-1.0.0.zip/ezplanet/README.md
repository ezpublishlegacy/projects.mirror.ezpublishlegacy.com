__Project already hosted on eZ Projects Forge: [http://projects.ez.no/ezplanet](http://projects.ez.no/ezplanet)__


Introduction
============
eZPlanet provide a planet system for eZ Publish:

 * RSS import from a content object attribute instead of the RSS's built-in system. You can use a link in user profil.
 * Cronjob
 * Clean HTML code with Tidy: using [eZTidy](http://projects.ez.no/eztidy)
 * Support keyword

Continuous integration
======================
eZPlanet is under continuous integration: [http://ci.llaumgui.com/job/eZPlanet/](http://ci.llaumgui.com/job/eZPlanet/)

![eZ Publish Certified Developer](http://www.llaumgui.com/images/ezcertdev.png)
