<?php /* #?ini charset="utf-8"?

[block_ezPlanetPeople_ezplanet_people]
Source=block/view/view.tpl
MatchFile=block/ezplanet_people.tpl
Subdir=templates
Match[type]=ezPlanetPeople
Match[view]=ezplanet_people

[block_ezPlanetTagCloud_ezplanet_tagcloud]
Source=block/view/view.tpl
MatchFile=block/ezplanet_tagcloud.tpl
Subdir=templates
Match[type]=ezPlanetTagCloud
Match[view]=ezplanet_tagcloud

*/ ?>