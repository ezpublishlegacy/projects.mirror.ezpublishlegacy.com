<?php /*
#
# $Id: site.ini.append.php 14 2009-11-11 21:39:38Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezclasslists/tags/ezclasslists_1_2/ezclasslists/settings/site.ini.append.php $
#

[RegionalSettings]
TranslationExtensions[]=ezclasslists

*/ ?>
