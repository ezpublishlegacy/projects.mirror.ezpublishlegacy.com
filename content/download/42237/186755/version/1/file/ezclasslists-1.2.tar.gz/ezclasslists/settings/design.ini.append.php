<?php /*
#
# $Id: design.ini.append.php 18 2011-06-22 19:53:59Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezclasslists/tags/ezclasslists_1_2/ezclasslists/settings/design.ini.append.php $
#

[ExtensionSettings]
DesignExtensions[]=ezclasslists

[JavaScriptSettings]
BackendJavaScriptList[]=ezjsc::yui2
BackendJavaScriptList[]=classlists.js

*/ ?>
