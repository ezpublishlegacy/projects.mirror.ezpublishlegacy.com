<?php /* #?ini charset="utf-8"?

[BCWebsiteStatisticsSettings]
OrderSubmit=enabled
PageSubmit=enabled
Urchin=UA-994200-0
HostName=disabled
ShopName=eZPublish
Script=http://www.google-analytics.com/urchin.js
SecureScript=https://ssl.google-analytics.com/urchin.js

*/ ?>