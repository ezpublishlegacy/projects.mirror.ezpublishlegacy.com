<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for workflows.

[EventSettings]
RepositoryDirectories[]=extension/bcwebsitestatistics/workflowtypes
ExtensionDirectories[]=bcwebsitestatistics
AvailableEventTypes[]=event_ezreceipt

*/ ?>