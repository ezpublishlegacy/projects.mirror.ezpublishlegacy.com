<?php /* #?ini charset="utf-8"?

# [pagelayout_analytics]
# Source=pagelayout.tpl
# MatchFile=pagelayout_analytics.tpl
# Subdir=templates
# Match[bcwebsitestatistics]=1

*/ ?>