<?php
class ezeasyrecInfo
{
    static function info()
    {
        return array( 'Name' => "eZeasyrec",
                      'Version' => "v0.1",
                      'Copyright' => "Copyright (C) 1999-2010 eZ Systems AS / O.Portier op@ez.no",
                      'Info_url' => "<a href='http://projects.ez.no/ezeasyrec/'>http://projects.ez.no/ezeasyrec/</a>",
            		  'License' => "GNU General Public License v2.0",
                      '3rdparty_software' =>
                            array ( 'Name' => 'easyrec',
                                    'Version' => 'v0.95',
                                    'copyright' => 'Copyright (c) 2010, The easyrec team',
                                    'License' => 'GNU GPL',
                                    'More information' => "<a href='http://www.easyrec.org'>http://www.easyrec.org</a>" )
                    );
    }
}
?>