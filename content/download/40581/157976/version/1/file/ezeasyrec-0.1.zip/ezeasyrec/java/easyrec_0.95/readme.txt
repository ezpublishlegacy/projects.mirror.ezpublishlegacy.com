easyrec 0.95
------------

Thank you for downloading easyrec!

NOTE: With this new version, easyrec has switched to InnoDB as the default
MySQL database engine. Please make sure you adjust the MySQL configuration
to ensure good performance of easyrec. You can find recommended settings at

https://sourceforge.net/apps/mediawiki/easyrec/index.php?title=InnoDB_settings


You can find more information about easyrec at
http://www.easyrec.org

easyrec is published and distributed via SourceForge.
The official project page can be found at

http://sourceforge.net/projects/easyrec/

For information on how to install and run easyrec, please refer to

http://sourceforge.net/apps/mediawiki/easyrec/

If you encounter problems, have any questions or suggestions, please have
a look at our forum at

http://sourceforge.net/apps/phpbb/easyrec/


The easyrec team
January 28, 2011 research studios austria - smart agent technologies