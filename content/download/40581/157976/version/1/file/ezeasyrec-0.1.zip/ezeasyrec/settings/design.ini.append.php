<?php /*

[ExtensionSettings]
DesignExtensions[]=ezeasyrec

*/ ?>