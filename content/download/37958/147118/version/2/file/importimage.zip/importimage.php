<?php

set_time_limit( 0 );
ERROR_REPORTING (E_ALL);
//print( "Starting image import\n" );
include_once( "lib/ezutils/classes/ezdebug.php" );

include_once( "lib/ezutils/classes/ezmodule.php" );
eZModule::setGlobalPathList( array( "kernel" ) );
include_once( 'lib/ezutils/classes/ezexecution.php' );

include_once( 'kernel/classes/ezcontentobjecttreenode.php' );

eZDebug::setHandleType( EZ_HANDLE_TO_PHP );
eZDebug::setLogFileEnabled( false );
eZINI::setIsCacheEnabled( false );

function eZDBCleanup()
{
    if ( class_exists( 'ezdb' )
         and eZDB::hasInstance() )
    {
        $db =& eZDB::instance();
        $db->setIsSQLOutputEnabled( false );
    }
}

function eZFatalError()
{
    eZDebug::setHandleType( EZ_HANDLE_NONE );
    print( "Fatal error: eZ publish did not finish it's request\n" );
    print( "The execution of eZ publish was abruptly ended." );
}

eZExecution::addCleanupHandler( 'eZDBCleanup' );
eZExecution::addFatalErrorHandler( 'eZFatalError' );

$ini =& eZINI::instance();

$server = $ini->variable( 'DatabaseSettings', 'Server' );
$user = $ini->variable( 'DatabaseSettings', 'User' );
$pwd = $ini->variable( 'DatabaseSettings', 'Password' );
$dbb = $ini->variable( 'DatabaseSettings', 'Database' );

//print( "$server $user $pwd $dbb\n" );
eZExecution::cleanup();
eZExecution::setCleanExit();
//test
/**
 include_once( "lib/ezutils/classes/ezdir.php" );
       $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();
       $ori_dir = $storage_dir . "/" . "original/imagehurtz";
    $ref_dir = $storage_dir . "/" . "reference/image";
    if ( !file_exists( $ori_dir ) )
    {
        eZDir::mkdir( $ori_dir, 0777, true);
    }
    // test 2
    */
    $uploadFtpDir ="upload";
    # Directory name with the cached files
# no trailing slash ('/') !!
//$Directory = '../var/log';
//  $Directory = 'var';


function &imageList ( $uploadFtpDir) {
        /*
        Read current directory and delete files if $DelFiles is true
        */
        if ($handle = opendir( $uploadFtpDir )) {
          //  echo "<li>Directory=$Directory\n";
  //  echo "$uploadFtpDir\n";
            while (false !== ($file = readdir($handle))) {
                # skip the current (.) and previous (..) directory
                if ($file != "." && $file != "..") {

                    if ( is_dir($uploadFtpDir."/".$file) ) {
                        # recurse into the direcotries
                        imageList ($uploadFtpDir.'/'.$file);

                    } else {
                        # show (and delete) files
                  //      echo "$file";
                  if (eregi("_th", $file)){
                  //echo "gfdfgdf $file";
                  }else{
                   $imageArray[] = $file;
                   //echo "$file";
                  }



                     //  echo "\n";
                    }
                }
            }
            closedir($handle);
            return $imageArray;
        }
} // ReadThisDir

//echo '<pre>';
//imageList ( $uploadFtpDir , $DeleteFiles );
  # execute script
//echo '</pre>';
//test emde

$imageList =& imageList($uploadFtpDir);
//var_dump ($imageList);

foreach ( $imageList as $image )
{echo "lala   " . $image;echo "\n";echo "\n";

         $saverImageName = strtolower( $image );
        $saverImageName = preg_replace( array( "/[^a-z0-9_\. ]/" ,
                                                 "/ /",
                                                 "/__+/" ),
                                          array( "",
                                                 "_",
                                                 "_" ),
                                          $saverImageName );
        echo $saverImageName;echo "   dfgdfgdfgdfgdfgdfgdgdfgdfg\n";


echo "\n";echo "\n";
echo "thummmmmmm: ".$imageThumb ;


                                        rename($uploadFtpDir."/".$image,$uploadFtpDir."/".$saverImageName);


  addImage( &$image,&$saverImageName );
}

function addImage( &$image,&$saverImageName )
{
    $db =& eZDB::instance();
    $db->setIsSQLOutputEnabled( false );
    //fetch image class 5
    $class =& eZContentClass::fetch( 5 );

    unset( $contentObject );
 include_once( 'lib/ezlocale/classes/ezdatetime.php' );
  //  $imageID = $image['ID'];
  //  $imageName = $image['Name'];
  $imageName = $image;
 //   $imageDescription = $image['Description'];
// $imageDescription = $image;
$imageDescription = "Here is the description";
 //   $imageCreatedTime = $image['Created'];
 $imageCreatedTime = eZdateTime::currentTimeStamp();
 //   $imageFileName = $image['FileName'];
 $imageFileName = $saverImageName;
 //   $imageOriginalFileName = $image['OriginalFileName'];
 $imageOriginalFileName = $saverImageName;


 //   $imageCaption = $image['Caption'];
 $imageCaption = $image;

 //sdjfgkajskfsfjlsdjflsdjflks
echo  "imageName".$imageName;
 //   $imageDescription = $image['Description'];
echo "imageDescription".$imageDescription;
 //   $imageCreatedTime = $image['Created'];
echo "imageCreatedTime".$imageCreatedTime;
 //   $imageFileName = $image['FileName'];
echo "imageFileName".$imageFileName;
 //   $imageOriginalFileName = $image['OriginalFileName'];
echo "imageOriginalFileName".$imageOriginalFileName;
 // thumb


 //   $imageCaption = $image['Caption'];
echo "imageCaption".$imageCaption;


// exit;

 //dfjlskjfsjdflkjsadlkfjsaldfjsldkjflasjflkasjdflksajdl
 //   $imageUserID = $image['UserID'];
  $imageUserID = "14";

 //   $remoteUserID = "user_" . $imageUserID;
    // set remoteID
 //   $remoteID = "image_" . $imageID;
  //  $remoteParentNodeArray = $db->arrayQuery( "SELECT * from eZImageCatalogue_ImageCategoryLink WHERE ImageID = '$imageID'" );

    $assignedNodes = array();
  //  $remoteParentNodeArray = array(58);
    if ( $remoteParentNodeArray != null )
    {
        // Find all parent node
        foreach ( $remoteParentNodeArray as $remoteParentNode )
        {
            $remoteParentID = "image_category_" . $remoteParentNode['CategoryID'];
            // Find parent node id
            $parentNodeIDArray = $db->arrayQuery( "SELECT ezcontentobject_tree.node_id FROM ezcontentobject, ezcontentobject_tree
                                                   WHERE ezcontentobject.remote_id = '$remoteParentID' AND ezcontentobject.id = ezcontentobject_tree.contentobject_id" );
            $parentNodeID = $parentNodeIDArray[0]['node_id'];
            $assignedNodes[] = $parentNodeID;
        }
    }
    else
    {
        // For those unassigned images, import to main image folder.
  /*      $parentNodeIDArray = $db->arrayQuery( "SELECT ezcontentobject_tree.node_id FROM ezcontentobject, ezcontentobject_tree
                                               WHERE ezcontentobject.remote_id = 'image_unassigned_folder' AND ezcontentobject.id = ezcontentobject_tree.contentobject_id" );

    */
 //  $parentNodeID = $parentNodeIDArray[0]['node_id'];
 // jlhjjhkljhkjhkjhkjhkjhkjhjjhkjhkjhkjhkjhkj
    $parentNodeID = "2";
        $assignedNodes[] = $parentNodeID;
    }

    // Find current user id
//    $userIDArray = $db->arrayQuery( "SELECT id FROM ezcontentobject WHERE remote_id = '$remoteUserID'" );

//    $userID = $userIDArray[0]['id'];

    // If no exist user, set it to administrator.
    if ( $userID == null )
        $userID = 14;

    if ( $userID != null )
    {
        // Create object by user id in section 2
        $contentObject =& $class->instantiate( $userID, 2 );
        $contentObject->setAttribute('remote_id', $remoteID );
        $contentObject->setAttribute( 'name', $imageName );

        foreach ( $assignedNodes as $assignedNode )
        {
            $nodeAssignment =& eZNodeAssignment::create( array(
                                                         'contentobject_id' => $contentObject->attribute( 'id' ),
                                                         'contentobject_version' => $contentObject->attribute( 'current_version' ),
                                                         'parent_node' => $assignedNode,
                                                         'sort_field' => 8,
                                                         'sort_order' => 0,
                                                         'is_main' => 1
                                                         )
                                                     );
            $nodeAssignment->store();
        }

        $version =& $contentObject->version( 1 );
        $version->setAttribute( 'modified', $imageCreatedTime );
        $version->setAttribute( 'created', $imageCreatedTime );
        $version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT );
        $version->store();

        $contentObjectID = $contentObject->attribute( 'id' );
        $contentObjectAttributes =& $version->contentObjectAttributes();

        $contentObjectAttributes[0]->setAttribute( 'data_text', $imageName );
        $contentObjectAttributes[0]->store();

 $inputData = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
         $inputData .= " <section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n";
        $inputData .= "           xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\">\n";
      //  $inputData .= "<section>";
        $inputData .= "<paragraph>";
        $inputData .= $imageDescription;
        $inputData .= "</paragraph>\n";
        $inputData .= "</section>\n";

      //  include_once( "kernel/classes/datatypes/ezxmltext/handlers/input/ezsimplifiedxmlinput.php" );
      //  $dumpdata = "";
      //  $simplifiedXMLInput = new eZSimplifiedXMLInput( $dumpdata, null, null );
      //  $inputData = $simplifiedXMLInput->convertInput( $inputData );
      //  $description = $inputData[0]->toString();
      $description = $inputData;
        $contentObjectAttributes[1]->setAttribute( 'data_text', $description );
        $contentObjectAttributes[1]->store();

        $contentObjectAttribute =& $contentObjectAttributes[2];

 saveImage( $imageFileName, $imageOriginalFileName, $imageCaption, $contentObjectAttribute );

        $contentObjectAttributes[2]->store();

           include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
        $operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
                                                                                 'version' => 1 ) );
        $contentObject->setAttribute('modified', $imageCreatedTime );
        $contentObject->setAttribute('published', $imageCreatedTime );
        $contentObject->store();
    }
}

function saveImage( $imageFileName, $originalImageFileName, $caption, &$contentObjectAttribute )
{
    include_once( "lib/ezutils/classes/ezdir.php" );
    $contentObjectAttributeID = $contentObjectAttribute->attribute( "id" );
    $version = $contentObjectAttribute->attribute( "version" );

    include_once( "kernel/common/image.php" );
    $image =& eZImage::create( $contentObjectAttributeID , $version );

    $image->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
    $image->setAttribute( "version", $version );
    $image->setAttribute( "filename", $imageFileName );
    $image->setAttribute( "original_filename", $originalImageFileName );

    $mimeObj = new eZMimeType();
    $mime = $mimeObj->mimeTypeFor( false, $originalImageFileName );
    $image->setAttribute( "mime_type", $mime );
    $image->setAttribute( "alternative_text", $caption );
    $image->store();

    $sys =& eZSys::instance();
    $storage_dir = $sys->storageDirectory();

//echo $storage_dir;
    $ori_dir = $storage_dir . '/' . "original/image";
    $ref_dir = $storage_dir . '/' . "reference/image";
    if ( !file_exists( $ori_dir ) )
    {
        eZDir::mkdir( $ori_dir, 0777, true);
    }
    if ( !file_exists( $ref_dir ) )
    {
        eZDir::mkdir( $ref_dir, 0777, true);
    }

  //  $source_file = $storage_dir . "/catalogue/" . $imageFileName;
//  $source_file = $uploadFtpDir . "/" . $imageFileName;
 $source_file =  "upload/" . $imageFileName;
// echo $imageFileName ."kfjglksdfg" ;
    $target_file = $storage_dir . "/original/image/" . $imageFileName;
    $reference_file = $storage_dir . "/reference/image/" . $imageFileName;
    copy($source_file, $target_file );
    copy($source_file, $reference_file );
  unlink ($source_file);
 }



?>
