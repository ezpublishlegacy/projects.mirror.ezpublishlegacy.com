tlcaptcha Module
===========================
tlcaptcha is an extension that allows the integration of the KCAPTCHA (http://www.captcha.ru/) anti-spam CAPTCHA service in your eZ publish content objects. tlcaptcha provides a tlcaptcha datatype that can be used in editing content and
information collection.

Installation
-----------------
Follow these steps to add the tlcaptcha module to your eZ publish installation:

  1) Extract the archive into the /extension directory

  2) Edit site.ini.append in /settings/override. Add the following to the file:

       [ExtensionSettings]
       ActiveExtensions[]=tlcaptcha

     If you already have the [ExtensionSettings] block, just add the second line.
  3) Add path to your EZpublish site to img tag of the tlcaptcha.tpl template in design/standard/templates/content/datatype/collect directory, or override this template.


Usage
----------------
  1) Change pagelayout.tpl :

  {let
   captcha=ezhttp('captcha', 'get')
   c1 = array(45, 97, 189)
   c2 = array(143, 171, 219)
}{section show=$captcha}{tlcaptcha('6', '120', '60', $c1, $c2)}{section-else}.....your old pagelayout code here....{/section}{/let}

You must add this without any empty lines or spaces, because tlcapthca operator return an image. In tlcaptcha.tpl: <img src="http://yoursite?captcha=1" /> this
set tlcaptcha session variables and return an image.
  2) tlcaptcha operator attributes:
     tlcaptcha( 'number of symbols in image', 'image width', 'image height', 'foreground_color RGB', 'background_color RGB')
     Other settings in tlcaptcha/classes/kcaptcha_config.php

  3) Add a tlcaptcha attribute to your content class.
  4) Clear Cache.

License
-----------------

This file may be distributed and/or modified under the terms of the "GNU
General Public License" version 2 as published by the Free Software Foundation

This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

The "GNU General Public License" (GPL) is available at
http://www.gnu.org/copyleft/gpl.html.

