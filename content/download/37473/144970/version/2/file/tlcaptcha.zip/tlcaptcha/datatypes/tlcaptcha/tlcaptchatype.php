<?php
/**
 * tlcaptcha extension for eZ Publish
 * Written by Tsay Sergey <tsay@time-line.kz>
 * Copyright (C) 2008. Tsay Sergey.  All rights reserved.
 * http://www.time-line.kz
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */

// Include the super class file
include_once( "kernel/classes/ezdatatype.php" );

// Define the name of datatype string
define( "EZ_DATATYPESTRING_TLCAPTCHA", "tlcaptcha" );


class tlcaptchaType extends eZDataType
{
  /*!
   Construction of the class, note that the second parameter in eZDataType
   is the actual name showed in the datatype dropdown list.
  */
  function tlcaptchaType()
  {
    $this->eZDataType( EZ_DATATYPESTRING_TLCAPTCHA, "tlcaptcha",
                           array( 'serialize_supported' => false,
                                  'translation_allowed' => false ) );
  }

  /*!
    Validates the input and returns true if the input was
    valid for this datatype.
  */
  function validateObjectAttributeHTTPInput( &$http, &$base,
                                               &$objectAttribute )
  {
    $classAttribute = $objectAttribute->contentClassAttribute();

   if( $classAttribute->attribute( 'is_information_collector' ) or $_SESSION['tlcaptcha'] ==  $_POST['code']){
      unset($_SESSION['tlcaptcha']);
      return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;}
    $objectAttribute->setValidationError(ezi18n( 'extension/tlcaptcha', "The code in image wasn't entered correctly. Please try again."));
      unset($_SESSION['tlcaptcha']);
    return EZ_INPUT_VALIDATOR_STATE_INVALID;
  }

  function validateCollectionAttributeHTTPInput( &$http, &$base, &$objectAttribute )
  {
   if( $_SESSION['tlcaptcha'] ==  $_POST['code']){
      unset($_SESSION['tlcaptcha']);
      return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;}
    $objectAttribute->setValidationError(ezi18n( 'extension/tlcaptcha', "The code in image wasn't entered correctly. Please try again."));
      unset($_SESSION['tlcaptcha']);
    return EZ_INPUT_VALIDATOR_STATE_INVALID;
  }

  function isIndexable()
  {
    return false;
  }

  function isInformationCollector()
  {
    return true;
  }

  function hasObjectAttributeContent( &$contentObjectAttribute )
  {
    return false;
  }

}
eZDataType::register( EZ_DATATYPESTRING_TLCAPTCHA, "tlcaptchaType" );