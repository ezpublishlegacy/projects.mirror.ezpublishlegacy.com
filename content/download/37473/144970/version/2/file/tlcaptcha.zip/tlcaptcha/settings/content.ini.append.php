<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=tlcaptcha
AvailableDataTypes[]=tlcaptcha

*/ ?>
