<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
array('script' => 'extension/tlcaptcha/autoloads/timelinecaptcha.php',
        'class' => 'timelinecaptcha',
        'operator_names' => array ( 'tlcaptcha' ));
?>