<!DOCTYPE TS><TS>
<context>
   <name>extension/tlcaptcha</name>
   <message>
       <source>The code in image wasn't entered correctly. Please try again.</source>
       <translation>Код указанный на картинке, был введен неправильно! Попробуйте еще раз.</translation>
   </message>
</context>
</TS>
