<?php
/**
 * tlcaptcha extension for eZ Publish
 * Written by Tsay Sergey <tsay@time-line.kz>
 * Copyright (C) 2008. Tsay Sergey.  All rights reserved.
 * http://www.time-line.kz
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */
class timelinecaptcha {

        function timelinecaptcha()
        {
                $this->Operators = array( 'tlcaptcha' );
        }

        function &operatorList()
        {
                return $this->Operators;
        }

        function namedParameterPerOperator()
        {
            return true;
        }

        function namedParameterList()
        {
        return array('tlcaptcha' => array('length' => array( 'type' =>'string', 'required'=> false, 'default' => '6'),
                'width' => array('type' => 'string', 'required' => false, 'default' =>'120'),
                'height' => array('type' => 'string', 'required' => false, 'default' =>'60'),
                'foreground_color' => array('type' => 'array', 'required' => false, 'default' =>array(192, 158, 103)),
                'background_color' => array('type' => 'array', 'required' => false, 'default' =>array(255, 255, 255))));
        }

        function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
        {
                switch( $operatorName )
                {
                        case 'tlcaptcha':
                        {
                        $operatorValue = $this->tlcaptcha($namedParameters['length'],
                                                                    $namedParameters['width'],
                                                                    $namedParameters['height'],
                                                                    $namedParameters['foreground_color'],
                                                                    $namedParameters['background_color']);
                        } break;
                }
        }

        function tlcaptcha($length, $width, $height, $foreground_color, $background_color)
        {
                include_once( 'extension/tlcaptcha/classes/kcaptcha.php' );
                $captcha = new KCAPTCHA();
                $c1 = $captcha->img($length, $width, $height, $foreground_color, $background_color);
                $_SESSION['tlcaptcha'] = $captcha->getKeyString();
                return $c1;
        }
        var $Operators;

};
?>