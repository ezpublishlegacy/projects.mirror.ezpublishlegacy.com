<?php /* #?ini charset="utf-8"?

# See http://kingdesk.com/projects/php-typography-documentation/class-phptypography/settings-methods/ for more details

[Hyphenation]
# GLOBAL SETTING. Turns on and off the hyphen­ation func­tion­al­ity.
Hyphenation=TRUE

# A string equal to the Lan­guage Code of a hyphen­ation pat­tern.
# Allowed Lan­guage Codes are those for which a dic­tio­nary has been loaded into the ‘php-typography/lang’ direc­tory.
HyphenationLanguage=en-US

# An inte­ger equal to the min­i­mum word length for the hyphen­ation func­tion­al­ity.
HyphenationMinLength=5

# An inte­ger equal to the min­i­mum num­ber of char­ac­ters between the begin­ning of a word and the first hyphen­ation point for the hyphen­ation func­tion­al­ity.
HyphenationMinBefore=3

# An inte­ger equal to the min­i­mum num­ber of char­ac­ters between the last hyphen­ation point and the end of a word for the hyphen­ation func­tion­al­ity.
HyphenationMinAfter=2

# Turns on and off the hyphen­ation func­tion­al­ity for head­ings.
HyphenationHeadings=TRUE

# Turns on and off hyphen­ation of cap­i­tal­ized (title case) words for the hyphen­ation func­tion­al­ity.
# Set this method to FALSE to pro­tect proper nouns from hyphenation.
HyphenationTitleCase=TRUE

# Turns on and off hyphen­ation of words con­sist­ing of all cap­i­tal let­ters for the hyphen­ation func­tion­al­ity.
HyphenationAllCaps=TRUE

# Sets cus­tom hyphen­ation points for spec­i­fied words for the hyphen­ation func­tion­al­ity.
# Each excep­tion should be the cor­rect spelling of the tar­geted word with a hard-hyphen (minus sign) inserted at each allow­able hyphen­ation point.
HyphenationExceptions[]


[Spacing]
# This setting will keep inte­gers and trail­ing frac­tions together on the same line by insert­ing a non-breaking space between them.
FractionSpacing=TRUE

# This setting will keep numeric val­ues and trail­ing units on the same line by insert­ing a non-breaking space between them.
UnitSpacing=TRUE

# Works in con­junc­tion with the UnitSpacing setting. UnitSpacing already looks for a vast set of units. This setting can be used to fill in any holes.
Units[]

# Will force thin-spaces between em or en dashes and adjoin­ing letters.
DashSpacing=TRUE

# Will force force sin­gle char­ac­ter words to wrap to new line
SingleCharacterWordSpacing=TRUE

# Will col­lapse adja­cent spac­ing to a sin­gle char­ac­ter.
# Nor­mal HTML pro­cess­ing col­lapses basic spaces. This option will addi­tion­ally col­lapse no-break spaces, zero-width spaces, fig­ure spaces, etc
SpaceCollapse=TRUE


[Widows]
# GLOBAL SETTING. Will attempt to pro­tect wid­ows.
# Wid­ows are the last word in a block level text that falls to it’s own line. Wid­ows get lonely when they are all alone. Wid­ows are kept com­pany by the injec­tion of a non-breaking space between them and the pre­vi­ous word (caus­ing both words to drop to the next line together).
Dewidow=TRUE

# Sets the max­i­mum word length of wid­ows who will be pro­tected. Some wid­ows are long enough, they can keep them­selves company.
DewidowMaxLength=5

# This method sets the max­i­mum word length that can be pulled from the pre­vi­ous line to keep wid­ows com­pany. Some words are too heavy to move (espe­cially with jus­ti­fied text).
DewidowMaxPull=5


[Wrapping]
# Some browsers will not allow words such as “mother-in-law” to wrap after a hard hyphen at line’s end.
# It will enable wrap­ping after hard hyphens by the inser­tion of a zero-width-space.
WrapHardHyphens=TRUE

# Email addresses can get fairly lengthy, and not all browsers will not allow them to break-apart at line’s end for effi­cient line-wrapping.
# It will enable wrap­ping of email addresses by the strate­gic inser­tion of zero-width spaces after all non-alphanumeric characters.
WrapEmail=TRUE

# URLs can get very lengthy, and not all browsers will not allow them to break-apart at line’s end for effi­cient line-wrapping.
# It will enable wrap­ping of URLs by the strate­gic inser­tion of zero-idth-spaces.
# Wrap­ping points are con­ser­v­a­tively inserted into the domain por­tion of the URL and aggres­sively added to the sub­se­quent path.
WrapUrl=TRUE

# Sets the min­i­mum num­ber of char­ac­ters that must remain together at the end of a URL when URL wrap­ping is enabled.
WrapUrlMinLength=5


[SmartQuotes]
# GLOBAL SETTING. Will trans­form straight quotes and back­ticks into con­tex­tu­ally aware curly quotes, primes, apos­tro­phes, and even double-low-9-quotemarks.
SmartQuotes=TRUE

# Sets the replace­ment char­ac­ters for the dou­ble straight-quote char­ac­ter. Dif­fer­ent lan­guages have dif­fer­ent quo­ta­tion styles…
# Values : doubleCurled, doubleCurledReversed, doubleLow9, doubleLow9Reversed, singleCurled, singleCurledReversed, singleLow9, singleLow9Reversed, doubleGuillemetsFrench, doubleGuillemets, doubleGuillemetsReversed, singleGuillemets, singleGuillemetsReversed, cornerBrackets, whiteCornerBracket
SmartQuotesPrimary=dou­ble­Curled

# Sets the replace­ment char­ac­ters for the sin­gle straight-quote char­ac­ter. Same values as SmartQuotesPrimary
SmartQuotesSecondary=sin­gle­Curled


[SmartDiacritics]
# GLOBAL SETTING. Will auto­mat­i­cally look for words that should uti­lize dia­crit­ics, and ensure they do.
# When enabled, “creme brulee” becomes “crème brûlée”. Note that this method will not process words that have alter­nate mean­ing with­out dia­crit­ics like resume & résumé, divorce & divorcé, and expose & exposé.
SmartDiacritics=FALSE

# A string equal to the Lan­guage Code.
# Allowed Lan­guage Codes are those for which a dic­tio­nary has been loaded into the ‘php-typography/diacritics’ direc­tory.
SmartDiacriticsLanguage=en-US



[SmartElements]
# Will minus-hyphens (or mul­ti­ple minus-hyphens) into con­tex­tu­ally aware en and em dashes (and even no-break-hyphens for phone numbers).
SmartDashes=TRUE

# Will replace three con­sec­u­tive peri­ods with an ellipses character.
SmartEllipses=TRUE

# Will intel­li­gently use proper mark sym­bols. (r), (c), (tm), (sm), and (p) become ®, ©, ™, ℠, and ℗.
SmartMarks=TRUE

# Will intel­li­gently inject proper minus, divi­sion and mul­ti­pli­ca­tion char­ac­ters into math equations.
SmartMath=TRUE

# Will iden­tify expo­nents, super­script them. This makes for pretty exponents.
SmartExponents=TRUE

# Will iden­tify frac­tions, raise the numer­a­tor, lower the denom­i­na­tor and replace the slash with a fraction-slash. This makes for pretty fractions.
SmartFractions=TRUE

# Will iden­tify num­bers fol­lowed by an ordi­nal suf­fix, and super­script the ordi­nal (i.e. 1st, 2nd and 3rd).
SmartOrdinalSuffix=TRUE


[Style]
# Will allow the wrap­ping of amper­sands with <span class="amp">. This pro­vides a hook for spe­cial CSS styling. For instance, the font may be changed to use a highly dec­o­ra­tive ampersand.
StyleAmpersands=TRUE

# Will allow the wrap­ping of acronyms with <span class="caps">. This pro­vides a hook for spe­cial CSS styling. For instance, you can use small-caps for your acronyms.
StyleCaps=TRUE

# Will allow the wrap­ping of num­bers with <span class="numbers">. This pro­vides a hook for spe­cial CSS styling. For instance, you can change a font from low­er­case or upper­case digits.
StyleNumbers=TRUE

# Will allow the wrap­ping of ini­tial sin­gle quotes with <span class="quo"> and ini­tial dou­ble quotes or guillemet with <span class="dquo">. This pro­vides a hook for spe­cial CSS styling. For instance, you can apply a neg­a­tive indent for hang­ing punctuation.
StyleQuotes=TRUE

# Works in con­junc­tion with the StyleQuotes setting. Allows you to spec­ify which block-level HTML ele­ments will allow ini­tial quotes to be styled.
StyleQuotesTags[]=p
StyleQuotesTags[]=h1
StyleQuotesTags[]=h2
StyleQuotesTags[]=h3
StyleQuotesTags[]=h4
StyleQuotesTags[]=h5
StyleQuotesTags[]=h6
StyleQuotesTags[]=blockquote
StyleQuotesTags[]=li
StyleQuotesTags[]=dd
StyleQuotesTags[]=dt


[IgnoredElements]
# HTML ele­ment names to which typo­graphic pro­cess­ing should not be applied.
IgnoredTags[]=code
IgnoredTags[]=head
IgnoredTags[]=kbd
IgnoredTags[]=object
IgnoredTags[]=option
IgnoredTags[]=pre
IgnoredTags[]=samp
IgnoredTags[]=script
IgnoredTags[]=select
IgnoredTags[]=style
IgnoredTags[]=textarea
IgnoredTags[]=title
IgnoredTags[]=var
IgnoredTags[]=math
IgnoredTags[]=script

# HTML class names to which typo­graphic pro­cess­ing should not be applied.
IgnoredClasses[]=vcard
IgnoredClasses[]=noTypo

# HTML IDs to which typo­graphic pro­cess­ing should not be applied.
IgnoredIds[]

*/ ?>
