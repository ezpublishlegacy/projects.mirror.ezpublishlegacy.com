<?php
//
// Definition of eZTypographyFilter class
//
// Created on: <24-jan-2011 10:14:34 bf>
//
// SOFTWARE NAME: eZTypography
// SOFTWARE RELEASE: 1.0
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2010 Pierre Martel and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


/*! \file eztypographyfilter
*/

/*!
  \class eZTypographyFilter eztypographyfilter
  \brief
*/

require_once('php-typography.php');

class eZTypographyFilter
{

	static function filter( $output )
	{
		$ezTypo = new eZTypography();

		$ezTypo->setSetting("IgnoredElements", "IgnoredTags", "set_tags_to_ignore");
		$ezTypo->setSetting("IgnoredElements", "IgnoredClasses", "set_classes_to_ignore");
		$ezTypo->setSetting("IgnoredElements", "IgnoredIds", "set_ids_to_ignore");
		$ezTypo->setSetting("Hyphenation", "Hyphenation", "set_hyphenation");
		$ezTypo->setSetting("Hyphenation", "HyphenationLanguage", "set_hyphenation_language");
		$ezTypo->setSetting("Hyphenation", "HyphenationMinLength", "set_min_length_hyphenation");
		$ezTypo->setSetting("Hyphenation", "HyphenationMinBefore", "set_min_before_hyphenation");
		$ezTypo->setSetting("Hyphenation", "HyphenationMinAfter", "set_min_after_hyphenation");
		$ezTypo->setSetting("Hyphenation", "HyphenationHeadings", "set_hyphenate_headings");
		$ezTypo->setSetting("Hyphenation", "HyphenationTitleCase", "set_hyphenate_title_case");
		$ezTypo->setSetting("Hyphenation", "HyphenationAllCaps", "set_hyphenate_all_caps");
		$ezTypo->setSetting("Hyphenation", "HyphenationExceptions", "set_hyphenation_exceptions");
		$ezTypo->setSetting("Spacing", "FractionSpacing", "set_fraction_spacing");
		$ezTypo->setSetting("Spacing", "UnitSpacing", "set_unit_spacing");
		$ezTypo->setSetting("Spacing", "Units", "set_units");
		$ezTypo->setSetting("Spacing", "DashSpacing", "set_dash_spacing");
		$ezTypo->setSetting("Spacing", "SingleCharacterWordSpacing", "set_single_character_word_spacing");
		$ezTypo->setSetting("Spacing", "SpaceCollapse", "set_space_collapse");
		$ezTypo->setSetting("Widows", "Dewidow", "set_dewidow");
		$ezTypo->setSetting("Widows", "DewidowMaxLength", "set_max_dewidow_length");
		$ezTypo->setSetting("Widows", "DewidowMaxPull", "set_max_dewidow_pull");
		$ezTypo->setSetting("Wrapping", "WrapHardHyphens", "set_wrap_hard_hyphens");
		$ezTypo->setSetting("Wrapping", "WrapEmail", "set_email_wrap");
		$ezTypo->setSetting("Wrapping", "WrapUrl", "set_url_wrap");
		$ezTypo->setSetting("Wrapping", "WrapUrlMinLength", "set_min_after_url_wrap");
		$ezTypo->setSetting("SmartQuotes", "SmartQuotes", "set_smart_quotes");
		$ezTypo->setSetting("SmartQuotes", "SmartQuotesPrimary", "set_smart_quotes_primary");
		$ezTypo->setSetting("SmartQuotes", "SmartQuotesSecondary", "set_smart_quotes_secondary");
		$ezTypo->setSetting("SmartDiacritics", "SmartDiacritics", "set_smart_diacritics");
		$ezTypo->setSetting("SmartDiacritics", "SmartDiacriticsLanguage", "set_diacritic_language");
		$ezTypo->setSetting("SmartElements", "SmartDashes", "set_smart_dashes");
		$ezTypo->setSetting("SmartElements", "SmartEllipses", "set_smart_ellipses");
		$ezTypo->setSetting("SmartElements", "SmartMarks", "set_smart_marks");
		$ezTypo->setSetting("SmartElements", "SmartMath", "set_smart_math");
		$ezTypo->setSetting("SmartElements", "SmartExponents", "set_smart_exponents");
		$ezTypo->setSetting("SmartElements", "SmartFractions", "set_smart_fractions");
		$ezTypo->setSetting("SmartElements", "SmartOrdinalSuffix", "set_smart_ordinal_suffix");
		$ezTypo->setSetting("Style", "StyleAmpersands", "set_style_ampersands");
		$ezTypo->setSetting("Style", "StyleCaps", "set_style_caps");
		$ezTypo->setSetting("Style", "StyleNumbers", "set_style_numbers");
		$ezTypo->setSetting("Style", "StyleQuotes", "set_style_initial_quotes");
		$ezTypo->setSetting("Style", "StyleQuotesTags", "set_initial_quote_tags");

		return $ezTypo->typo->process( $output );
	}

}

class eZTypography
{
	private $ini;
	public $typo;

	function __construct()
	{
		$this->typo = new phpTypography();
		$this->ini = eZINI::instance( "eztypography.ini" );
	}

	public function setSetting( $section, $setting, $function )
	{
		if( $this->ini->hasVariable( $section, $setting ) )
		{
			$value=$this->ini->variable( $section, $setting );
			if( $value=="FALSE" ){
				$value=false;
			}
			$this->typo->$function( $value );
		}
	}
}

?>
