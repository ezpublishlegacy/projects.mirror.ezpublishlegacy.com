[NavigationPart]
Part[collectexport]=Export

[TopAdminMenu]
Tabs[]=collectexport

[Topmenu_collectexport]
NavigationPartIdentifier=collectexport
Name=Export
Tooltip=Export Menu
URL[]
URL[default]=collectexport/overview
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

