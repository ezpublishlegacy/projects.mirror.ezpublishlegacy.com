[ExtensionSettings]
DesignExtensions[]=collectexport
