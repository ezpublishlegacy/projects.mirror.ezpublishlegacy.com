<?php /* #?ini charset="utf-8"?

[full_task_folder]
Source=node/view/full.tpl
MatchFile=full/task_folder.tpl
Subdir=templates
Match[class_identifier]=task_folder

*/ ?>