<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ganttchart

[ExtensionSettings]
ActiveExtensions[]=ganttchart

[RegionalSettings]
TranslationExtensions[]=ganttchart

*/?>