<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
<context>
    <name>design/standard/modelviewer/obj</name>
    <message>
        <source>Show 10 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>