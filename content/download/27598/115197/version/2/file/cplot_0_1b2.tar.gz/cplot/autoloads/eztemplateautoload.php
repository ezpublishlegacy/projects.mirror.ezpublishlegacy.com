<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/cplot/classes/cplotoperator.php',
                                    'class' => 'CPlotOperator',
                                    'operator_names' => array( 'cplot' ) );

?>
