<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=cplot

[ExtensionSettings]
ActiveExtensions[]=cplot


*/?>