<?php

eZCache::clearByID( 'texttoimage' );

?>