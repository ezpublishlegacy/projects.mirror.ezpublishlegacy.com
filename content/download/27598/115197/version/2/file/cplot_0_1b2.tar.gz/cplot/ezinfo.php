<?php
class CPlotInfo
{
    static function info()
    {
        return array(
'Name' => 'CPlot',
'Version' => '1.0',
'Copyright' => 'Copyright (C) 2009-'
 . date('Y') . ' Thiago Campos Viana',
'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
