<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=cplot

[CronjobPart-frequent]
Scripts[]=removetmpimages.php

*/ ?>
