<?php

/*!
  \class   CplotOperator cplotoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator cplot. By using cplot you can plot charts.
  \version 1.0
  \date    Wednesday 28 July 2010 11:37:15 am
  \author  Thiago Campos Viana

*/


class CPlotOperator
{
	public static $count = 0;
    /*!
      Constructor, does nothing by default.
    */
    function CPlotOperator()
    {
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'cplot' );
    }

    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'cplot' => array( 'title' => array( 	'type' => 'string',
															'required' => true),
															
										'render' => array( 	'type' => 'string',
															'required' => true ),
															
										'type' => array( 	'type' => 'string',
															'required' => true ),
															
										'data' => array(	'type' => 'array',
															'required' => true ),						

															
										'xlegend' => array(	'type' => 'string',
															'required' => false,
															'default'=>'x' ),
															
										'ylegend' => array(	'type' => 'string',
															'required' => false,
															'default'=>'y' ),							
															
										'width' => array(	'type' => 'integer',
															'required' => false,
															'default'=> 500 ),
															
										'height' => array(	'type' => 'integer',
															'required' => false,
															'default'=> 300 )
                                        ) );
    }


    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters, $placement )
    {
		$title = $namedParameters['title'];
		$render = $namedParameters['render'];
		$type = $namedParameters['type'];
		$data = $namedParameters['data'];       
        
		$xlegend = $namedParameters['xlegend'];
		$ylegend = $namedParameters['ylegend'];
		
		$width = $namedParameters['width'];
		$height = $namedParameters['height'];
		
        // Example code. This code must be modified to do what the operator should do. Currently it only trims text.
        switch ( $render )
        {
            case 'flash':     
					$operatorValue=FlashPlotChart::getResult($title, $type, $render, $xlegend, $ylegend, $data, $width, $height);
				break;			
			case 'svg':
			case 'png':
					$operatorValue=ezcImageChart::getResult($title, $type, $render, $xlegend, $ylegend, $data, $width, $height);
				
				break;
			default:
				$operatorValue="";
        }
    }
}

?>