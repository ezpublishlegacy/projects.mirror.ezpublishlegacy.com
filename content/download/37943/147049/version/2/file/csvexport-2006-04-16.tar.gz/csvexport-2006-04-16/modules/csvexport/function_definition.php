<?php

$FunctionList = array();

$FunctionList['exportcsv'] = array(
'name' => 'exportcsv',
'call_method' => array( 
		'include_file' => 'extension/csvexport/modules/csvexport/parserinterface.php',
		'class' => 'ParserInterface',
		'method' => 'fetchExportContentTree' ),
'parameter_type' => 'standard',
'parameters' => array(
			array(
				'name' => 'parent_node_id',
				'required' => true,
				'default' => false),
			array( 
				'name' => 'class_id',
				'required' => true,
				'default' => false),
			array(
				'name' => 'attributes_to_export',
				'required' => true,
				'default' => false),
			array(
				'name' => 'separation_char',
				'required' => true,
				'default' => false)

		)
 );

?>
