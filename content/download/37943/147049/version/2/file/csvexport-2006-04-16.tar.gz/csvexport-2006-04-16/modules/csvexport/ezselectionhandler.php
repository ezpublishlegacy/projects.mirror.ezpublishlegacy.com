/* Thanks to Andre R. for this */
<?php
include_once('extension/csvexport/modules/csvexport/parserinterface.php');

class eZSelectionHandler extends BaseHandler{
       function exportAttribute(&$attribute, $seperationChar) {
                $content=&$attribute->content();
                return $this->escape($content[0], $seperationChar);
       }
}

?>

