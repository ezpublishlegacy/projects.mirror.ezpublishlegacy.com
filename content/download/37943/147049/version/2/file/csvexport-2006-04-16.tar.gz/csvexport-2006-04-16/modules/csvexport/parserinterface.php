<?
include_once('lib/ezutils/classes/ezini.php');
include_once('extension/csvexport/modules/csvexport/basehandler.php');
include_once('kernel/classes/ezcontentobjecttreenode.php');

/*
return the datatypes (identifiers) that can be exported
*/

class ParserInterface {

//holds the lookup map for the handler mapings
var $handlerMap=array();
var $exportableDatatypes;

	function ParserInterface() {
		$ini = eZINI::instance( "csv.ini" );
		$this->exportableDatatypes=$ini->variable( "General", "ExportableDatatypes" );
		foreach ($this->exportableDatatypes as $typename) {
			include_once("extension/csvexport/modules/csvexport/".$ini->variable($typename, 'HandlerFile'));
			$classname=$ini->variable($typename, 'HandlerClass'); 
			$handler= new $classname;
			$this->handlerMap[$typename]=array("handler" => $handler,
						"exportable" => true);
		}
	}
	
	function getExportableDatatypes() {
		return $this->exportableDatatypes;
	}
	
	/*
		Export an attribute to a string
	*/
	
	function exportAttribute(&$attribute, $seperationChar) {
		$handler=$this->handlerMap[$attribute->DataTypeString]['handler'];
		return $handler->exportAttribute($attribute, $seperationChar);
		
	}

	function exportContentObject(&$contentobject, &$attributes_to_export, $seperationChar) {
		$resultstring="";
		foreach ($attributes_to_export as $attributeid) {
			if ($attributeid == "contentobjectid") {
				$resultstring=$resultstring . $contentobject->ID . $seperationChar;
			}
			else {
				$attributes=$contentobject->contentObjectAttributes();
				
				foreach ($attributes as $currentattribute) {
					//eZDebug::writeWarning($currentattribute);
			
					if ( ((int) $attributeid)== ((int) $currentattribute->ContentClassAttributeID) ) {
						$resultstring=$resultstring.$this->exportAttribute($currentattribute, $seperationChar).$seperationChar;
					}
				}
			}
		}
		return trim($resultstring, $seperationChar);
		
	}

	function exportContentTree($parent_node_id, $class_id, $attributes_to_export, $seperationChar) {

		//eZDebug::writeWarning($attributes_to_export);
		$tree=eZContentObjectTreeNode::subTree( array(	'ClassFilterArray' => array($class_id),
								'ClassFilterType' => 'include',
								'mainNodeOnly' => true),
							$parent_node_id ) ;
		
		//eZDebug::writeWarning($tree);

		$returnstring="";
		foreach ($tree as $node) {
			$node->ContentObject->contentObjectAttributes();
			$returnstring=$returnstring.$this->exportContentObject($node->ContentObject, $attributes_to_export, $seperationChar)."\n";	
		}
		eZDebug::writeWarning($returnstring);
		return $returnstring;
	}

	function fetchExportContentTree($parent_node_id, $class_id, $attributes_to_export, $seperationChar) {
		return array('result' => $this->exportContentTree($parent_node_id, $class_id, $attributes_to_export, ';'));	
	}
}