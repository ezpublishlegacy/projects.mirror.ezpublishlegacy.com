<?php

include_once ('kernel/classes/ezcontentclass.php');

include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:csvexport/fieldselection.tpl');
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Field Selection' ) );



?>