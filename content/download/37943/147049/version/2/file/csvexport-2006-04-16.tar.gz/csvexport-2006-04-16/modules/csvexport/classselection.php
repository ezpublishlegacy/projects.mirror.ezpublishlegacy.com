<?php


include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:csvexport/classselection.tpl');
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Class Selection' ) );




?>