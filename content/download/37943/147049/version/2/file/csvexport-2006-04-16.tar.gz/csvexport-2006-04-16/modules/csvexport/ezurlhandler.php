<?php

include_once('extension/csvexport/modules/csvexport/basehandler.php');

class eZURLHandler extends BaseHandler {

	function exportAttribute(&$attribute, $seperationChar) {
		//var_export($attribute);
		$tempstring=$attribute->content() . $seperationChar . $attribute->DataText;
		return $this->escape($tempstring, $seperationChar);
	}
}

?>