<?php

$Module = array( 'name' => 'CSV Import/Export' );

$ViewList = array();
$ViewList['classselection'] = array(
    'script' => 'classselection.php',
    'params' => array ( ) );

$ViewList['fieldselection'] = array(
    'script' => 'fieldselection.php',
    'params' => array ( ) );

$ViewList['doexport'] = array(
    'script' => 'doexport.php',
    'params' => array ( ) );

?>