<?php

include_once ('kernel/classes/ezcontentclass.php');

//include_once( 'kernel/common/template.php' );

include_once ('lib/ezutils/classes/ezhttptool.php');

include_once('extension/csvexport/modules/csvexport/parserinterface.php');

include_once('lib/ezutils/classes/ezexecution.php');

header("Content-type:text/csv; charset=utf-8");

$counter=0;
$attributes_to_export=array();
while (true) {
	//echo $counter;
	$currentattribute=eZHTTPTool::postVariable("field_$counter");
	//echo $currentattribute;
	if (!$currentattribute) {
		break;
	}
	$attributes_to_export[]=$currentattribute;
	$counter++;
}

$parent_node_id=2;//eZHTTPTool::postVariable("field_$counter");

$class_id=eZHTTPTool::postVariable("classid");

$seperation_char=eZHTTPTool::postVariable("separation_char");

$parserInterface=new ParserInterface();

$csv_string=$parserInterface->exportContentTree($parent_node_id, $class_id, $attributes_to_export, $seperation_char);




echo($csv_string);
flush();
eZExecution::cleanExit();

/*
//$tpl =& templateInit();

//$Result = array();
//$Result['content'] =& $tpl->fetch( 'design:csvexport/doexport.tpl');
//$Result['path'] = array( array( 'url' => false,
                                'text' => 'Export' ) );


*/

?>