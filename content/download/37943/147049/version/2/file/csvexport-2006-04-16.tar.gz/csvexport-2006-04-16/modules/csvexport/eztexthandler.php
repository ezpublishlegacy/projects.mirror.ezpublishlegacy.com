<?

include_once('extension/csvexport/modules/csvexport/parserinterface.php');

class eZTextHandler extends BaseHandler{
	function exportAttribute(&$attribute, $seperationChar) {
		$content=&$attribute->content();
		return $this->escape($content);
	}
}
?>
