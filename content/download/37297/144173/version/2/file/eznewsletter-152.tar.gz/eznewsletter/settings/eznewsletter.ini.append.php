<?php /*
#[HostSettings]
# Set the default host for sent newsletters here
#defaulthost=http://yourfrontpage.com

[NewsletterAutomapping]
# Enable if attributes of the newslettertype should be mapped to the content object
autoMapping=disabled
# Define the mapping (shema: contentClass[contentClassAttribute]=newsletterTypeAttribute)
# Example if you want to map the attribute 'pretext' from the newsletterType to the attribute 'pretext' of the 'newsletter_issue' content class you do the following
#    newsletter_issue[pretext]=pretext
#newsletter_issue[pretext]=pretext
#newsletter_issue[posttext]=posttext

[NewsletterSendout]
#Select transport class for newsletter sendout. Valid values are SMTP, sendmail or File for pregeneration.
#If SMTP selected, SMTP server must be defined in siteaccess or override settings.
#
#Transport class for preview sendout
PreviewTransport=Sendmail
#Transport class for newsletter sendout via cronjob
Transport=Sendmail

[NewsletterTypeSettings]
# Class limitation prevents the use of classes as newsletter which are not in this list, if empty all classes can be used
#ClassLimitation[]
#ClassLimitation[]=newsletter_issue
*/ ?>
