<?php /* #?ini charset="iso-8859-1"?

[Designs]
Design[]=eznewsletter

[eznewsletter]
Description=Standard
PreviewImage=standarddesign.jpg

*/?>
