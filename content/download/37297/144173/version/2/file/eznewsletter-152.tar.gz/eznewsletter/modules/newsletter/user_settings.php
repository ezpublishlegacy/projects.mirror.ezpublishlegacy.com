<?php
//
// Created on: <24-Jan-2006 16:54:51 hovik>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file user_settings.php
*/

include_once( 'kernel/common/template.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscription.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezusersubscriptiondata.php' );
include_once( 'kernel/common/eztemplatedesignresource.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

$Module =& $Params['Module'];

$http =& eZHTTPTool::instance();

if ( $http->hasPostVariable( 'UpdateSubscriptions' ) )
{
    if( $http->hasVariable('original_email' ) )
    {
        $userData = eZUserSubscriptionData::fetch( $http->postVariable( 'original_email' ) );

        $allowedStatusList = array( eZSubscription_StatusApproved,
                                    eZSubscription_StatusPending,
                                    eZSubscription_StatusConfirmed,
                                    eZSubscription_StatusRemovedSelf );

        $subscriptionList = eZSubscription::fetchListByEmail( $userData->attribute( 'email' ),
                                                              eZSubscription_VersionStatusPublished,
                                                              array( array( eZSubscription_StatusPending,
                                                                        eZSubscription_StatusApproved,
                                                                        eZSubscription_StatusConfirmed,
                                                              eZSubscription_StatusRemovedSelf ) ) );
    foreach( $subscriptionList as $key => $subscription )
    {
       //unsubscribe
       if ( !$http->hasPostVariable( 'Status_' . $subscription->attribute( 'id' ) ) )
       {
           if ( $subscription->attribute('status') == eZSubscription_StatusApproved ||
                $subscription->attribute( 'status') == eZSubscription_StatusConfirmed )
           {
               $subscription->setAttribute( 'status', eZSubscription_StatusRemovedSelf );
               $subscription->sync();
               $subscriptionList[$key] = $subscription;
           }
       }
       else
       {
           if ( $subscription->attribute('status') == eZSubscription_StatusRemovedSelf )
           {
               //subscribe
               $subscription->setAttribute( 'status', eZSubscription_StatusConfirmed );
               $subscription->sync();
               $subscriptionList[$key] = $subscription;
           }
       }
       
       if ( $http->hasPostVariable( 'OutputFormat_' . $subscription->attribute( 'id' ) ) )
       {
            //echo var_dump($http->postVariable( 'OutputFormat_' . $subscription->attribute( 'id' ) ));
        $subscription->setAttribute( 'output_format', implode( ',', $http->postVariable( 'OutputFormat_' . $subscription->attribute( 'id' ) ) ) );   
       }
       
       $subscription->store();
    }
    
    //get new data in memory
    $subscriptionList = eZSubscription::fetchListByEmail( $userData->attribute( 'email' ),
                                                      eZSubscription_VersionStatusPublished,
                                                          array( array( eZSubscription_StatusPending,
                                                                        eZSubscription_StatusApproved,
                                                                        eZSubscription_StatusConfirmed,
                                                                        eZSubscription_StatusRemovedSelf,
                                        eZSubscription_StatusRemovedAdmin ) ) );    

    if ( !isset($user) )
    {
        $userData->setAttribute( 'name', $http->postVariable( 'Name' ) );
        $userData->setAttribute( 'firstname', $http->postVariable( 'FirstName' ) );
        $userData->setAttribute( 'mobile', $http->postVariable( 'Mobile' ) );

        if ( $userData->attribute( 'email' ) != $http->postVariable( 'Email' ) )
        {
            $emailExists = eZUserSubscriptionData::fetch( $http->postVariable( 'Email' ) );
            if ( $emailExists )
            {
                $warning = ezi18n( 'eznewsletter/user_settings', 'The given email address is already in use. Please use another.' );
            }
            else
            {
                $userData->setAttribute( 'email', $http->postVariable( 'Email' ) );
            }
        }

        if ( $http->hasPostVariable( 'Password1' ) &&
             $http->postVariable( 'Password1' ) != 'password' )
        {
            if ( $http->postVariable( 'Password1' ) === $http->postVariable( 'Password2' ) &&
                 strlen( trim( $http->postVariable( 'Password1' ) ) ) > 0 )
            {
                $userData->setAttribute( 'password', md5( $http->postVariable( 'Password1' ) ) );
            }
            else
            {
                $warning = ezi18n( 'eznewsletter/user_settings', 'Password did not match' );
            }
        }

        $userData->sync();
    //get new Data inmemory
    $userData = eZUserSubscriptionData::fetch( $http->postVariable( 'original_email' ) );

    }
    
    }
}

if( $Params['Hash'] )
{
    $userData = eZUserSubscriptionData::fetchByHash( $Params['Hash'] );
        
    if ( !$userData )
        {
            $tpl =& templateInit();

            $Result = array();
            $Result['content'] =& $tpl->fetch( "design:eznewsletter/no_subscription.tpl" );
            $Result['path'] = array( array( 'url' => false,
                                            'text' => ezi18n( 'eznewsletter', 'No subscription.' ) ) );
            return $Result;
        }
    else
    {
        //$warning = false;
        $passwordSet = $userData->attribute( 'password' ) != '';
        if ( $passwordSet && !$http->hasSessionVariable( 'Newsletter_UserSettings_' . $userData->attribute( 'id' ) ) )
        {
                $checkPassword = true;
            if ( $http->hasPostVariable( 'Password' ) )
            {
                if ( md5( $http->postVariable( 'Password' ) ) == $userData->attribute( 'password' ) )
                {
                        $http->setSessionVariable( 'Newsletter_UserSettings_' . $userData->attribute( 'id' ), 1 );
                        $checkPassword = false;
                }
            }

            if ( $checkPassword )
            {
                $tpl =& templateInit();
                $tpl->setVariable( 'hash', $userData->attribute( 'hash' ) );

                $Result = array();
                $Result['content'] =& $tpl->fetch( "design:eznewsletter/user_settings_password.tpl" );
                $Result['path'] = array( array( 'url' => false,
                                            'text' => ezi18n( 'eznewsletter/user_settings_password.tpl', 'Activate subscription' ) ) );
                return $Result;
            }
        }
        $subscriptionList = eZSubscription::fetchListByEmail( $userData->attribute( 'email' ),
                                                              eZSubscription_VersionStatusPublished,
                                                          array( array( eZSubscription_StatusPending,
                                                                        eZSubscription_StatusApproved,
                                                                        eZSubscription_StatusConfirmed,
                                                                        eZSubscription_StatusRemovedSelf,
                                        eZSubscription_StatusRemovedAdmin ) ) );

        $allowedStatusList = array( eZSubscription_StatusApproved,
                                    eZSubscription_StatusConfirmed,
                                    eZSubscription_StatusRemovedSelf );

        $removedStatusList = array( eZSubscription_StatusRemovedAdmin,
                                    eZSubscription_StatusRemovedSelf );

        //check if all subscriptions are not pending
        $pending=true;
        foreach($subscriptionList as $subscription)
        {
        if ($subscription->attribute( 'status' ) != eZSubscription_StatusPending )
        {
            $pending=false;
        }
        }
        if ($pending)
        {
            $tpl =& templateInit();
            $tpl->setVariable( 'hash', $userData->attribute( 'hash' ) );

            $Result = array();
            $Result['content'] =& $tpl->fetch( "design:eznewsletter/pending.tpl" );
            $Result['path'] = array( array( 'url' => false,
                                            'text' => ezi18n( 'eznewsletter', 'Activate Subscription' ) ) );
            return $Result;

        }
    }
}
else
{
    return $Module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
}

//get new data

$tpl =& templateInit();
//$tpl->setVariable( 'user', $user );
if ( isset($warning) )
{
    $tpl->setVariable( 'warning', $warning );
}
$tpl->setVariable( 'hash', $Params['Hash'] );
$tpl->setVariable( 'userData', $userData );
$tpl->setVariable( 'allowedStatusList', $allowedStatusList );
$tpl->setVariable( 'removedStatusList', $removedStatusList );
$tpl->setVariable( 'statusNameMap', eZSubscription::statusNameMap() );
$tpl->setVariable( 'subscriptionList', $subscriptionList );
$tpl->setVariable( 'output_map', eZSubscription::outputFormatNameMap() );
//get profile data

$Result = array();
$Result['content'] =& $tpl->fetch( "design:eznewsletter/user_settings_user.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'eznewsletter', 'Activate Subscription' ) ) );

?>
