<?php
//
// Definition of eZNewsletterType class
//
// Created on: <30-Nov-2005 10:41:07 oms>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file eznewslettertype.php
*/

/*!
  \class eZNewsletterType eznewslettertype.php
  \brief The class eZNewsletterType does

*/

include_once( 'kernel/classes/ezpersistentobject.php' );

define( 'eZNewsletterType_StatusDraft', 0 );
define( 'eZNewsletterType_StatusPublished', 1 );

class eZNewsletterType extends eZPersistentObject
{
    /*!
     Constructor
    */
    function eZNewsletterType( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function definition()
    {
        return array( "fields" => array( "id" => array( 'name' => 'ID',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),
                                         "name" => array( 'name' => 'Name',
                                                          'datatype' => 'string',
                                                          'default' => '',
                                                          'required' => true ),
                                         "contentclass_list" => array( 'name' => 'ContentClassList',
                                                                       'datatype' => 'string',
                                                                       'default' => '',
                                                                       'required' => true ),
                                         "description" => array( 'name' => 'Description',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         'defaultsubscriptionlist_id' => array( 'name' => 'DefaultSubscriptionListID',
                                                                                'datatype' => 'integer',
                                                                                'default' => 0,
                                                                                'required' => true ),
                                         "related_object_id_1" => array( 'name' => 'RelatedObjectID1',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         "related_object_id_2" => array( 'name' => 'RelatedObjectID2',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         "related_object_id_3" => array( 'name' => 'RelatedObjectID3',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         "inbox_id" => array( 'name' => 'InboxID',
                                                              'datatype' => 'integer',
                                                              'default' => 0,
                                                              'required' => false ),
                                         "allowed_output_formats" => array( 'name' => 'AllowedOutputFormats',
                                                                            'datatype' => 'integer',
                                                                            'default' => 0,
                                                                            'required' => true ),
                                         "allowed_designs" => array( 'name' => 'AllowedDesigns',
                                                                            'datatype' => 'string',
                                                                            'default' => 0,
                                                                            'required' => true ),
                                         "article_pool_object_id" => array( 'name' => 'ArticlePool',
                                                                            'datatype' => 'integer',
                                                                            'default' => 0,
                                                                            'required' => true ),
                                         'sender_address' => array( 'name' => 'SendAddress',
                                                                    'datatype' => 'string',
                                                                    'default' => '',
                                                                    'required' => true ),
                                         "status" => array( 'name' => 'Status',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ),
                                         "created" => array( 'name' => 'Created',
                                                             'datatype' => 'integer',
                                                             'default' => 0,
                                                             'required' => true ),
                                         'send_date_modifier' => array( 'name' => 'SendDateModifier',
                                                             'datatype' => 'integer',
                                                             'default' => 0,
                                                             'required' => true ),
                                         "creator_id" => array( 'name' => 'Creator',
                                                                'datatype' => 'integer',
                                                                'default' => 0,
                                                                'required' => true ),
                                         "pretext" => array( 'name' => 'Pretext',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         "posttext" => array( 'name' => 'Posttext',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         "personalise" => array( 'name' => 'Personalise',
                                                                'datatype' => 'integer',
                                                                'default' => 1,
                                                                'required' => true ) ),
                      "keys" => array( 'id', 'status' ),
                      "function_attributes" => array( 'article_pool_object' => 'articlePoolObject',
                                                      'creator' => 'creator',
                                                      'inbox_object' => 'inbox',
                                                      'subscription_list' => 'subscriptionList',
                                                      'subscription_id_list' => 'subscriptionIDList',
                                                      'allowed_designs_array' => 'allowedDesignsArray',
                                                      'allowed_output_formats_index' => 'allowedOutputFormatsIndex',
                                                      'related_object_1' => 'relatedObject1',
                                                      'related_object_2' => 'relatedObject2',
                                                      'related_object_3' => 'relatedObject3',
                                                      'send_date_modifier_list' => 'sendDateModifierList',
                                                      'default_subscription_list' => 'defaultSubscriptionList' ),
                      "increment_key" => "id",
                      "sort" => array( 'id' => 'asc' ),
                      "class_name" => "eZNewsletterType",
                      "name" => "eznewslettertype" );
    }

    function &sendDateModifierList() 
    {
        $sendDateModifier = $this->attribute( 'send_date_modifier');
        
        $sendModifierList = array( );
        $sendModifierList['days'] = (int) ($sendDateModifier / 86400);
        $sendModifierList['hours'] = (int) (( $sendDateModifier % 86400 ) / 3600);
        $sendModifierList['minutes'] = (int) (( $sendDateModifier % 86400 % 3600 ) / 60);

        return $sendModifierList;
    }

    /*!
     Fetch related object 1, 2 and 3
    */
    function &attribute( $attr )
    {
        $retVal = null;
        switch( $attr )
        {
            case 'related_object_1':
            case 'related_object_2':
            case 'related_object_3':
            {
                $retVal = eZContentObject::fetch( $this->attribute( 'related_object_id_' . substr( $attr, -1, 1 ) ) );
            } break;

            case 'inbox_object':
            {
                if( $this->attribute( 'inbox_id' ) ) {
                    $retVal = eZContentObject::fetch( $this->attribute( 'inbox_id' ) );
                }
            } break;

            case 'subscription_id_list':
            {
                $list = eZNewsletterTypeSubscription::fetchList( $this->attribute( 'id' ), false, $this->attribute( 'status' ) );
                if ( $list )
                {
                    $retVal = array();
                    foreach( $list as $subItem )
                    {
                        $retVal[] = $subItem->attribute( 'subscription_id' );
                    }
                }
            } break;

            case 'default_subscription_list':
            {
                include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscriptionlist.php' );
                $subscriptionListLink = eZSubscriptionList::fetch( $this->attribute( 'defaultsubscriptionlist_id' ) );
                if ( !$retVal )
                {
                    $subscriptionList = $this->attribute( 'subscription_list' );
                    if( 0 < count( $subscriptionList ) )
                    {
                        $subscriptionListLink = $subscriptionList[0];
                    }
                }
                if ( $subscriptionListLink )
                {
                    $retVal = $subscriptionListLink->attribute( 'subscription_object' );
                }
            } break;
           
        default:
            {
                $retVal =& eZPersistentObject::attribute( $attr );
            } break;
        }

        return $retVal;
    }

    /*!
     Fetch newsletter list.

     \param $offset ( default = 0 )
     \param $limit ( default = 10 )
     \param $sendStatus ( default = false )
     \param $status ( default = eZNewsletter_StatusPublished )
     \param $asObject ( default = true )

     \return List of newsletter items.
    */
    function fetchNewsletterList( $offset = 0,
                                  $limit = 10,
                                  $sendStatus = false,
                                  $status = eZNewsletter_StatusPublished,
                                  $asObject = true,
                  $grouped = false,
                  $recurring = false )
    {
        include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/eznewsletter.php' );

        $condArray = array( 'newslettertype_id' => $this->attribute( 'id' ),
                            'status' => $status );

        if ( $sendStatus !== false )
        {
            $condArray['send_status'] = $sendStatus;
        }
    if ( $grouped == true )
    {
        $grouping = array('contentobject_id');
    }
    else
    {
         $grouping = null;
    }
    if ( $recurring == true )
    {
            $condArray['recurrence_type'] = array( array( 'd', 'w', 'm' ) );
    }
    
    if ( ( $offset === -1 ) && ( $limit === -1 ) )
    {
        return eZPersistentObject::fetchObjectList( eZNewsletter::definition(),
                                                    null,
                                                    $condArray,
                                                    null,
                                                    $asObject,
                            $grouping );
    } else {
        return eZPersistentObject::fetchObjectList( eZNewsletter::definition(),
                                                    null,
                                                    $condArray,
                                                    null,
                                                    array( 'length' => $limit,
                                                           'offset' => $offset ),
                                                    $asObject,
                            $grouping );
    }
    }

    /*!
     Fetch assigned subscription lists
    */
    function &subscriptionList()
    {
        $retVal = eZNewsletterTypeSubscription::fetchList( $this->attribute( 'id' ), false, $this->attribute( 'status' ) );
        if ( !$retVal )
        {
            $retVal = array();
        }
        return $retVal;
    }

    /*!
     Assign specified subscription list to newsletter type

     \param subscription list id
    */
    function assignSubscription( $subscriptionListID )
    {
        eZNewsletterTypeSubscription::add( $this->attribute( 'id' ),
                                           $subscriptionListID,
                                           $this->attribute( 'status' ) );
    }

    /*!
     Remove specified subscription list to newsletter type

     \param subscription list id
    */
    function removeSubscription( $subscriptionListID = false )
    {
        eZNewsletterTypeSubscription::remove( $this->attribute( 'id' ),
                                              $subscriptionListID,
                                              $this->attribute( 'status' ) );
    }

    /*!
     \return Node id which contain the available articles to be used in the newsletter type.
     */
    function &articlePoolObject()
    {
        if ( $this->attribute( 'article_pool_object_id' ) == 0 )
        {
            $retVal = false;
            return $retVal;
        }
        else
        {
            $retVal = eZContentObject::fetch( $this->attribute( 'article_pool_object_id' ) );
            return $retVal;
        }
    }

    /*!
      \a $asObject BOOL, defaults to true, specifies whether the returned result should be an object or a row.
      \return Array of all newsletter types in the system
    */
    function fetchList( $status = eZNewsletterType_StatusPublished, $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( eZNewsletterType::definition(),
                                                    null,
                                                    array( 'status' => $status ),
                                                    null,
                                                    null,
                                                    $asObject );
    }

    /*!
      \a $newsletterTypeID The id of the requested eZNewsletterType object
      \a $asObject BOOL specifies whether to return object or row
      \return An eZNewsletterType in object or row form
    */
    function fetch( $newsletterTypeID, $status = eZNewsletterType_StatusPublished, $asObject= true )
    {
        return eZPersistentObject::fetchObject( eZNewsletterType::definition(),
                                                null,
                                                array( 'id' => $newsletterTypeID,
                                                       'status' => $status ),
                                                $asObject );
    }

    /*!
      \static
      Fetch draft of eZNewsletterType object. A new object will be created if none exist.

      \param id
    */
    function fetchDraft( $id, $asObject = true )
    {
        $newsletterType = eZNewsletterType::fetch( $id, eZNewsletterType_StatusDraft, $asObject );
        if ( !$newsletterType )
        {
            $newsletterType = eZNewsletterType::fetch( $id, eZNewsletterType_StatusPublished, $asObject );
            if ( $newsletterType )
            {
                $newsletterType->setAttribute( 'status', eZNewsletterType_StatusDraft );
                $newsletterType->store();
            }
        }

        if ( !$newsletterType )
        {
            return false;
        }
        return $newsletterType;
    }

    /*!
      Publish eZNewsletterType
      1. Sets status to publish
      2. Stores the object
      3. Removes the draft
     */
    function publish()
    {
        $this->setAttribute( 'status', eZNewsletterType_StatusPublished );
        $this->store();

        eZNewsletterTypeSubscription::publish( $this->attribute( 'id' ) );

        $this->removeDraft();
    }

    /*!
      Remove draft of current object.
     */
    function removeDraft()
    {
        $newsletterTypeDraft = eZNewsletterType::fetchDraft( $this->attribute( 'id' ) );
        $newsletterTypeDraft->remove();
    }

    /*!
      \static
      Remove all entries in system of \a id

      \param id
     */
    function removeAll( $id )
    {
        eZPersistentObject::removeObject( eZNewsletterType::definition(),
                                          array( 'id' => $id ) );
    }

    /*!
       \static
       Create new eZNewsletterType object
     */
    function create( $name = '', $userID = false )
    {
        if ( $userID === false )
        {
            $userID = eZUser::currentUserID();
        }

        $newsletterType = new eZNewsletterType( array( 'created' => mktime(),
                                                       'creator_id' => $userID,
                                                       'name' => $name,
                                                       'status' => eZNewsletterType_StatusDraft ) );
        $newsletterType->store();
        return $newsletterType;
    }

    /*!
      Get Creator user object
     */
    function &creator()
    {
        include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );
        $user = false;

        if ( $this->attribute( 'creator_id' ) )
        {
            $user = eZUser::fetch( $this->attribute( 'creator_id' ) );
        }
        return $user;
    }

    /*!
      \a $offset Offset from start of dataset.
      \a $limit Number of elements to return in each batch.
      \a $asObject Specifies whether to return datasat as objects or rows.
      \return Array of eZNewsletterType.
     */
    function fetchByOffset( $offset, $limit, $status = eZNewsletterType_StatusPublished, $asObject = true )
    {
        $newsletterTypeList = eZPersistentObject::fetchObjectList( eZNewsletterType::definition(),
                                                            null,
                                                            array( 'status' => $status ),
                                                            array( 'id' => 'ASC' ),
                                                            array( 'offset' => $offset, 'length' => $limit ),
                                                            $asObject );
        return $newsletterTypeList;
    }

    /*!
      \static
      Reads a string, and recreates an array.
     */
    function unserializeArray( $string )
    {
        $retVal = '';
        if ( strlen( $string ) >= 1 )
        {
            $retVal = explode( ',', $string );
        }
        return $retVal;
    }

    /*!
      \static
      Serializes an arraay into a string
     */
    function serializeArray( $arr )
    {
        $retVal = '';
        if ( is_array( $arr ) )
        {
            $string = implode( ',', $arr );
            $retVal = $string;
        }
        return $retVal;
    }

    /*!
     Return allowed designs
     */
    function &allowedDesignsArray()
    {
        $allowedDesigns = $this->attribute( 'allowed_designs', true );
        $allowedDesignsArray = explode( ',', $allowedDesigns);
        return $allowedDesignsArray;
    }

    /*!
      \static
      Return the allowed outputformats to choose between
     */
    function allowedOutputFormatMap()
    {
        $availableOutputFormats = array( 'plaintext' => ezi18n( 'eznewsletter/eznewslettertype/output_format', 'Plain text' ),
                                         'embeddedhtml' => ezi18n( 'eznewsletter/eznewslettertype/output_format', 'HTML' ),
                                         'externalhtml' => ezi18n( 'eznewsletter/eznewslettertype/output_format', 'HTML w/external images' ),
                                         'sms' => ezi18n( 'eznewsletter/eznewslettertype/output_format', 'SMS' ) );
        return $availableOutputFormats;
    }

    /*!
      \static
      Return the allowed outputformats as index values
     */
    function &allowedOutputFormatsIndex()
    {
        $allowedFormatStrings = explode( ',', $this->attribute( 'allowed_output_formats' ) );
        $availableOutputFormats = array( 'plaintext',
                                         'embeddedhtml',
                                         'externalhtml',
                                         'sms' );

        $keys = array();
        foreach( $allowedFormatStrings as $format)
        {
            $key = array_search( $format, $availableOutputFormats );
            if( false!==$key )
            {
                $keys[] = $key;
            }
        }
        return $keys;
    }




}

class eZNewsletterTypeSubscription extends eZPersistentObject
{
    /*!
     Constructor
    */
    function eZNewsletterTypeSubscription( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function definition()
    {
        return array( "fields" => array( "newsletter_id" => array( 'name' => 'NewsletterID',
                                                                   'datatype' => 'integer',
                                                                   'default' => 0,
                                                                   'required' => true ),
                                         "status" => array( 'name' => 'Status',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ),
                                         "subscription_id" => array( 'name' => 'SubscriptionID',
                                                                     'datatype' => 'integer',
                                                                     'default' => 0,
                                                                     'required' => true ) ),
                      'function_attributes' => array( 'subscription_object' => 'subscriptionObject' ),
                      "keys" => array( 'newsletter_id', 'status', 'subscription_id' ),
                      'sort' => array( 'subscription_id' => 'asc' ),
                      "class_name" => "eZNewsletterTypeSubscription",
                      "name" => "ez_newsletter_subscription" );
    }

    function &subscriptionObject()
    {
        include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscriptionlist.php' );
        $retVal = eZSubscriptionList::fetch( $this->attribute( 'subscription_id' ), $this->attribute( 'status' ), true, true );
        return $retVal;
    }

    /*!
     fetch
    */
    function fetch( $newsletterTypeID, $subscriptionListID, $status = eZNewsletterType_StatusPublished, $asObject = true )
    {
        return eZPersistentObject::fetchObject( eZNewsletterTypeSubscription::definition(),
                                                null,
                                                array( 'newsletter_id' => $newsletterTypeID,
                                                       'subscription_id' => $subscriptionListID,
                                                       'status' => $status ),
                                                $asObject );
    }

    /*!
     Fetch list of newsletter type subscriptions.

     fetch
    */
    function fetchList( $newsletterTypeID, $subscriptionListID = false, $status = eZNewsletterType_StatusPublished, $asObject = true )
    {
        $condArray = array( 'newsletter_id' => $newsletterTypeID,
                            'status' => $status );
        if ( $subscriptionListID !== false )
        {
            $condArray['subscription_id'] = $subscriptionListID;
        }

        return eZPersistentObject::fetchObjectList( eZNewsletterTypeSubscription::definition(),
                                                    null,
                                                    $condArray,
                                                    null,
                                                    null,
                                                    $asObject );
    }

    /*!
     Add
    */
    function add( $newsletterTypeID, $subscriptionListID, $status = eZNewsletterType_StatusDraft )
    {
        $existing = eZNewsletterTypeSubscription::fetch( $newsletterTypeID, $subscriptionListID, $status );
        if ( !$existing )
        {
            $newAssignment = new eZNewsletterTypeSubscription( array( 'newsletter_id' => $newsletterTypeID,
                                                                      'subscription_id' => $subscriptionListID,
                                                                      'status' => $status ) );
            $newAssignment->store();
        }
    }

    function remove( $newsletterTypeID, $subscriptionListID = false, $status = eZNewsletterType_StatusDraft )
    {
        $condArray = array( 'newsletter_id' => $newsletterTypeID,
                            'status' => $status );

        if ( $subscriptionListID !== false )
        {
            $condArray['subscription_id'] = $subscriptionListID;
        }
        eZPersistentObject::removeObject( eZNewsletterTypeSubscription::definition(),
                                          $condArray );
    }

    /*!
     Publish
    */
    function publish( $newsletterTypeID )
    {
        eZNewsletterTypeSubscription::remove( $newsletterTypeID, false, eZNewsletterType_StatusPublished );
        foreach( eZNewsletterTypeSubscription::fetchList( $newsletterTypeID, false, eZNewsletterType_StatusDraft ) as $assignment )
        {
            $assignment->setAttribute( 'status', eZNewsletterType_StatusPublished ); // TODO, copy, not alter.
            $assignment->store();
        }
    }
}

?>
