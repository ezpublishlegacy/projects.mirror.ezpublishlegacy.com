<?php /*

[edit_article]
Source=content/edit.tpl
MatchFile=edit_article.tpl
Subdir=templates
Match[class_identifier]=newsletter_issue

*/ ?>
