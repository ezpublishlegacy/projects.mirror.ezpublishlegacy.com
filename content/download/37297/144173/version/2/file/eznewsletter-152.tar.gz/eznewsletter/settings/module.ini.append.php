<? /*

[ModuleSettings]
ExtensionRepositories[]=eznewsletter

*/ ?>
