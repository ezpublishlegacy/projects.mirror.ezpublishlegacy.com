<?php
//
// Created on: <08-Dec-2005 10:40:16 hovik>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file edit_subscription.php
*/

include_once( 'kernel/common/template.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscription.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezusersubscriptiondata.php' );

$Module =& $Params['Module'];

$http =& eZHTTPTool::instance();

if ( $http->hasPostVariable( 'RemoveSubscriptionButton' ) )
{
    foreach( $http->postVariable( 'SubscriptionIDArray' ) as $subscriptionID )
    {
	$userData = eZUserSubscriptionData::fetchById( $subscriptionID );
	$subscriptionList = eZSubscription::fetchListByEmail( $userData->attribute( 'email' ),
                                                          eZSubscription_VersionStatusPublished,
	                                                array( array( eZSubscription_StatusPending,
	                                                            eZSubscription_StatusApproved,
	                                                            eZSubscription_StatusConfirmed,
	                                                            eZSubscription_StatusRemovedSelf,
								    eZSubscription_StatusRemovedAdmin ) ) );

	foreach( $subscriptionList as $subscription)
	{
	    eZSubscription::removeAll( $subscription->Attribute( 'id' ) );
	}
	eZUserSubscriptionData::removeAll( $subscriptionID );
    }
}

if ( $http->hasPostVariable( 'searchString' ) && $http->postVariable( 'searchString' ) != ""  )
{

    $search = strtolower( $http->postVariable( 'searchString' ) );

    $db = eZDB::instance();
    $searchSQL = "select email from ezsubscriptionuserdata where LOWER(firstname) LIKE '%".$search."%' or LOWER(name) LIKE '%".$search."%' or LOWER(email) LIKE '%".$search."%' group by email LIMIT 50";
    $searchResult = $db->arrayQuery( $searchSQL );

    $subscriberList = array();
    foreach( $searchResult as $email )
    {
	$subscriberList[] = eZUserSubscriptionData::fetch( $email['email'] );
    }

    $countSQL = "select id from ezsubscriptionuserdata where LOWER(firstname) LIKE '%".$search."%' or LOWER(name) LIKE '%".$search."%' or LOWER(email) LIKE '%".$search."%' group by email";
    $countResult = $db->arrayQuery( $countSQL );
    $subscriberCount=count($countResult);
}

$tpl =& templateInit();

if ( $http->hasPostVariable( 'searchString' ) )
{
    $tpl->setVariable( 'searchString', $http->postVariable( 'searchString' ) );
}
else
{
    $tpl->setVariable( 'searchString', '' );
}

if ( isset($subscriberList ) )
{
    $tpl->setVariable( 'subscriberList', $subscriberList );
    $tpl->setVariable( 'subscriberCount', $subscriberCount );
}
else
{
    $tpl->setVariable( 'subscriberList', array() );
    $tpl->setVariable( 'subscriberCount', 0 );
}

$Result = array();
$Result['left_menu'] = 'design:parts/content/eznewsletter_menu.tpl';
$Result['content'] =& $tpl->fetch( "design:eznewsletter/subscription_search.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'eznewsletter/subscription_search', 'Edit Subscription' ) ) );

?>
