<?php
//
// Definition of eZRobinsonlistEntry class
//
// Created on: <13-Jan-2006 02:49:01 aw>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file ezrobinsonlistentry.php
*/

/*!
  \class eZRobinsonlistEntry ezrobinsonlistentry.php
  \brief The class eZRobinsonlistEntry does

*/

include_once( 'kernel/classes/ezpersistentobject.php' );

define( 'eZRobinsonlistEntryType_EMAIL', 0 );
define( 'eZRobinsonlistEntryType_MOBILE', 1 );

define( 'eZRobinsonlistEntry_LOCAL', 0 );
define( 'eZRobinsonlistEntry_GLOBAL', 1 );

define( 'eZRobinsonlistEntryImport_SYNC', 0 );
define( 'eZRobinsonlistEntryImport_ADD', 1 );

class eZRobinsonlistEntry extends eZPersistentObject
{
    /*!
     Constructor
    */
    function eZRobinsonlistEntry( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function definition()
    {       
        return array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ),
                     'value' => array( 'name' => 'Value',
                                                           'datatype' => 'string',
                                                           'default' => '',
                                                           'required' => true ),
                     'type' => array( 'name' => 'Type',
                                                           'datatype' => 'integer',
                                                           'default' => 0,
                                                           'required' => true ),
                                         'global' => array( 'name' => 'Global',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ) ),
                      'keys' => array( 'id' ),
                      'function_attributes' => array( 'type_map' => 'typeNameMap',
                                  'global_map' => 'globalNameMap',
                              'import_map' => 'importNameMap' ),
                      'increment_key' => 'id',
              'sort' => array( 'value' => 'asc' ),
                      'class_name' => 'eZRobinsonlistEntry',
                      'name' => 'ezrobinsonlist' );
    }

    function addCondition ($type, $condition)
    {
    $condArray = array();
    if ( $type == eZRobinsonlistEntryType_MOBILE )
    {
        $condArray = array( 'type' => eZRobinsonlistEntryType_MOBILE );
    }
    else
    {
        $condArray = array( 'type' => eZRobinsonlistEntryType_EMAIL );  
    }   
        return array_merge($condition, $condArray);
    }

   /*!
      \a $offset Offset from start of dataset.
      \a $limit Number of elements to return in each batch.
      \a $asObject Specifies whether to return datasat as objects or rows.
      \return Array of eZNewsletterType.
     */
    function fetchByOffset( $type, $condition, $offset, $limit, $asObject = true )
    {    

    $robinsonlistEntrys = eZPersistentObject::fetchObjectList( eZRobinsonlistEntry::definition(),
                                                            null,
                                                            eZRobinsonlistEntry::addCondition($type, $condition),
                                                            array( 'value' => 'ASC' ),
                                                            array( 'offset' => $offset, 'length' => $limit ),
                                                        $asObject );
    return $robinsonlistEntrys;
    }

    function fetchValues( $type, $global )
    {    

    $robinsonlistEntrys = eZPersistentObject::fetchObjectList( eZRobinsonlistEntry::definition(),
                                                            array( 'value' ),
                                                            array( 'type' => $type, 
                                       'global' => $global ),
                                array( 'value' => 'ASC' ),
                                null,
                                                        $asObject );
    $result = array();
    foreach ($robinsonlistEntrys as $entry)
    {
        $result=array_merge($result, $entry[ 'value' ]);
    }
    return $result;
    }


    /*!
      Fetches ans eZrobinsonlistentry object by its newslettersenditem_id
     */
    function inList( $value, $list_type = null, $list_global = null )
    {   
    if ( $value == "" )
    {
        return false;
    }
    
    $cond = array();
    
    if ( $list_global != null )
    {
        $cond = array( 'global' => $list_global );
    }
    
    if ( $list_type != null )
    {
        $cond = array_merge( $cond, array( 'type' => $list_type ) );
    }
    $robinsonlist = eZPersistentObject::fetchObject( eZRobinsonlistEntry::definition(),
                                                   null,
                                                   array_merge( array( 'value' => $value ), $cond ) );
    if ($robinsonlist)
    {
        return true;
    }
    else
    {
            return false;
    }
    }

    /*!
      Fetches an eZrobinsonlistentry object
     */
    function fetchByValue( $value, $asObject = true )
    {
        $robinsonlistEntry = eZPersistentObject::fetchObject( eZRobinsonlistEntry::definition(),
                                                   null,
                                                   array( 'value' => $value ),
                           $asObject );
    return $robinsonlistEntry;
    }

    /*!
      Fetches an eZrobinsonlistentry object
     */
    function fetchById( $id, $asObject = true )
    {
        $robinsonlistEntry = eZPersistentObject::fetchObject( eZRobinsonlistEntry::definition(),
                                                   null,
                                                   array( 'id' => $id ),
                           $asObject );
        return $robinsonlistEntry;
    }

    /*!
     \static

     Get robinsonlistentry list count

     \return eZRobinsonlistEntry count
    */
    function count($type, $cond = array() )
    {
        $rows = eZPersistentObject::fetchObject( eZRobinsonlistEntry::definition($type),
                                                 array(),
                                                 array_merge($cond, eZRobinsonlistEntry::addCondition($type, array())),
                         false,
                                                 false,
                                                 array( array( 'operation' => 'count( * )',
                                                               'name' => 'count' ) ) );
        return $rows['count'];
    }

   /*!
     Create new object
    */
    function create( $value = '', $type = eZRobinsonlistEntryType_EMAIL, $global = eZRobinsonlistEntry_LOCAL )
    {
    
    if ( !eZRobinsonlistEntry::inList($value) )
        {
        $rows = array( 'value' => $value,
                   'type' => $type,
                    'global' => $global );
    
            $entry = new eZRobinsonlistEntry( $rows );
            $entry->store();

            return $entry;
    }
    else
    {
        return null;
    }
    }

    /*
     \param ID
    */
    function removeById( $id )
    {
        eZPersistentObject::removeObject( eZRobinsonlistEntry::definition($type),
                                           array( 'id' => $id ) );
    }

    /*
     \param ID
    */
    function removeByValue( $value, $type, $global )
    {
        eZPersistentObject::removeObject( eZRobinsonlistEntry::definition($type),
                                           array( 'value' => $value,
                          'type' => $type,
                          'global' => $global ) );
    }

    /*!
     \static
     Get Status name map
    */
    function typeNameMap()
    {
        return array( eZRobinsonlistEntryType_EMAIL => ezi18n( 'eznewsletter/robinsonlist_entrytype', 'Email address' ),
                      eZRobinsonlistEntryType_MOBILE => ezi18n( 'eznewsletter/robinsonlist_entrytype', 'Mobile phone number' ) );
    }

    /*!
     \static
     Get Status name map
    */
    function globalNameMap()
    {
        return array( eZRobinsonlistEntry_LOCAL => ezi18n( 'eznewsletter/robinsonlist_entrysource', 'Local' ),
                      eZRobinsonlistEntry_GLOBAL => ezi18n( 'eznewsletter/robinsonlist_entrysource', 'External data' ) );
    }

    /*!
     \static
     Get Status name map
    */
    function importNameMap()
    {
        return array( eZRobinsonlistEntryImport_SYNC => ezi18n( 'eznewsletter/robinsonlist_action', 'Synchronize' ),
                      eZRobinsonlistEntryImport_ADD => ezi18n( 'eznewsletter/robinsonlist_action', 'Only add new' ) );
    }

    function importData($data, $labels, $rows, $global, $type, $options)
    {
    
    if ( $type == eZRobinsonlistEntryType_EMAIL )
    {
        $mapping=$labels['email'];
    }
    else if ( $type == eZRobinsonlistEntryType_MOBILE )
    {
        $mapping=$labels['mobile']; 
    }

    //add new entries
    if ( $options == eZRobinsonlistEntryImport_ADD )
    {
        foreach( $rows as $rowIndex)
        //foreach( $data[$mapping] as $value )
        {
        //add new from new data
        $value = $data[$mapping][$rowIndex];
        //echo "Adding: ".$value." ".$type." ".$global."<br>";
        eZRobinsonlistEntry::create($value, $type, $global);
        }
    } 
    else if ( $options == eZRobinsonlistEntryImport_SYNC )
    {
        $new_values = array();
        foreach( $rows as $rowIndex)
        {   
        $new_values = array_merge($new_values, $data[$mapping][$rowIndex]);
        }
    
        foreach( $new_values as $value)
        {
        //add new from new data
        //echo "Sync Adding: ".$value." ".$type." ".$global."<br>";
        eZRobinsonlistEntry::create($value, $type, $global);
        }
        
        //get all current data
        $old_values = eZRobinsonlistEntry::fetchValues($type, $global);

        foreach( $old_values as $value )
        {
        if ( !in_array( $value, $new_values) )
        {
            //remove from database
            //echo "Sync Removing: ".$value." ".$type." ".$global."<br>";
            eZRobinsonlistEntry::removeByValue($value, $type, $global);
        }
        }
    }
    //echo "<br>";
    }
}

?>
