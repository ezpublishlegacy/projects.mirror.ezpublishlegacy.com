<!DOCTYPE TS><TS>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout</name>
    <message>
        <source>Interested? Learn more ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upcoming Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legal Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upcoming events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legal information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EVENTS THIS MONTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profil</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/companynewsletter/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite</name>
    <message>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, article not found!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout</name>
    <message>
        <source>Read the full story ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Also today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TOPICS this week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TOPICS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profil</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/newssite/sendout/sms</name>
    <message>
        <source>Hello, we have news for you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/node/view/newsletter</name>
    <message>
        <source>Read the full story ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout</name>
    <message>
        <source>Read more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buy this product now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ONLY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profil</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/eznewsletter_designs/shop/sendout/sms</name>
    <message>
        <source>Hello, we have some products available which might interrest you. Visit %url_to_newsletter to view our new newsletter.</source>
        <comment>Notifies the subscriber about a new published newsletter (via SMS).</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You save:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
