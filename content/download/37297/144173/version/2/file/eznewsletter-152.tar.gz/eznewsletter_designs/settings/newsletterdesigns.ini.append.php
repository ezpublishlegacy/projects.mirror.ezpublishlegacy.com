<?php /* #?ini charset="iso-8859-1"?

[Designs]
Design[]
Design[]=companynewsletter
Design[]=newssite
Design[]=shop

[companynewsletter]
Description=Companynewsletter
PreviewImage=companynewsletter.jpg

[newssite]
Description=Newssite
PreviewImage=newssite.jpg

[shop]
Description=Shop
PreviewImage=shop.jpg

*/?>
