<?php
//
// Definition of eZSubscriptionGroup class
//
// Created on: <23-Dec-2005 12:35:22 hovik>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file ezsubscriptiongroup.php
*/

/*!
  \class eZSubscriptionGroup ezsubscriptiongroup.php
  \brief The class eZSubscriptionGroup does

*/

include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscriptionlist.php' );

class eZSubscriptionGroup extends eZPersistentObject
{
    /*!
     Constructor
    */
    function eZSubscriptionGroup( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function definition()
    {
        return array( "fields" => array( "id" => array( 'name' => 'ID',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),
                                         "status" => array( 'name' => 'Status',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ),
                                         "created" => array( 'name' => 'Created',
                                                             'datatype' => 'integer',
                                                             'default' => 0,
                                                             'required' => true ),
                                         "creator_id" => array( 'name' => 'Creator_id',
                                                                'datatype' => 'integer',
                                                                'default' => 0,
                                                                'required' => true ),
                                         "name" => array( 'name' => 'Name',
                                                          'datatype' => 'string',
                                                          'default' => '',
                                                          'required' => true ),
                                         "description" => array( 'name' => 'Description',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         "subscriptionlistid_list" => array( 'name' => 'SubscriptionListIDList',
                                                                             'datatype' => 'string',
                                                                             'default' => '',
                                                                             'required' => true ),
                                         'url_type' => array( 'name' => 'URLType',
                                                              'datatype' => 'integer',
                                                              'default' => 0,
                                                              'required' => true ),
                                         'url' => array( 'name' => 'URL',
                                                         'datatype' => 'string',
                                                         'default' => '',
                                                         'required' => true ) ),
                      "keys" => array( "id", 'status' ),
                      'increment_key' => 'id',
                      'function_attributes' => array( 'creator' => 'creator',
                                                      'subscriptionlist_list' => 'subscriptionListList',
                                                      'url_alias' => 'urlAlias' ),
                      "increment_key" => "id",
                      'sort' => array( 'id' => 'asc' ),
                      "class_name" => "eZSubscriptionGroup",
                      "name" => "ezsubscription_group" );
    }

    /*!
     Get URL alias
    */
    function &urlAlias()
    {
        switch( $this->attribute( 'url_type' ) )
        {
            case eZSubscriptionList_URLTypeName:
            {
                return $this->attribute( 'url' );
            } break;

            default:
            case eZSubscriptionList_URLTypeID:
            {
                return $this->attribute( 'id' );
            } break;
        }
    }

    /*!
     Get Creator user object
    */
    function &creator()
    {
        include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );

        $user = eZUser::fetch( $this->attribute( 'creator_id' ) );
        return $user;
    }

}

?>
