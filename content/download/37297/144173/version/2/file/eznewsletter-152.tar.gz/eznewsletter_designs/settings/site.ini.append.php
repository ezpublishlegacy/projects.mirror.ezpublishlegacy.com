<?php
/*
[RegionalSettings]
TranslationExtensions[]=eznewsletter_designs
*/

?>
