<?php /*

## If you use the landingpages delivered with this extension you should enable this overrides at the specific newsletter location
#[read_newsletter]
#Source=node/view/full.tpl
#MatchFile=view_newsletter.tpl
#Subdir=templates
#Match[class_identifier]=newsletter_issue
#Match[section]=9

#[newsletter_pagelayout]
#Source=pagelayout.tpl
#MatchFile=newsletter_pagelayout.tpl
#Subdir=templates
#Match[class_identifier]=newsletter_issue
#Match[section]=9

*/ ?>
