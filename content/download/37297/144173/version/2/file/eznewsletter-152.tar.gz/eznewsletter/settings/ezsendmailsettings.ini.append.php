<?php /*

[SendNewsletter]
ReplaceMessageIDHost=disabled
Host=host.com
#Set Envelope return path parameter according to your MTA software. Default -V is for sendmail. 
#For example -v is for exim.
MTAEnvelopeReturnPathParameter="-V"

*/ ?>
