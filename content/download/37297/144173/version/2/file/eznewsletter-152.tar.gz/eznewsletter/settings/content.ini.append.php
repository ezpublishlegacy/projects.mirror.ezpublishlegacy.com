<?php /*

[EditSettings]
ExtensionDirectories[]=eznewsletter

*/ ?>
