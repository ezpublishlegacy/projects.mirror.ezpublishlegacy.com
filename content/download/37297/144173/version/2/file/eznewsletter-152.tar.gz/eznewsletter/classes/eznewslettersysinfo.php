<?php
//
// Created on: <02-Nov-2006 14:38:45 tos>
//
// SOFTWARE NAME: eZ Newsletter
// SOFTWARE RELEASE: 1.0.1
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*!
  \brief contains the eZ publish SDK version.
*/

define( "EZ_NEWSLETTER_VERSION_MAJOR", 1 );
define( "EZ_NEWSLETTER_VERSION_MINOR", 5 );
define( "EZ_NEWSLETTER_VERSION_RELEASE", 2 );
define( "EZ_NEWSLETTER_VERSION_STATE", '' );
define( "EZ_NEWSLETTER_VERSION_DEVELOPMENT", false );
define( "EZ_NEWSLETTER_VERSION_REVISION_STRING", '' );
define( "EZ_NEWSLETTER_VERSION_ALIAS", '1.5' );
define( "EZ_NEWSLETTER_VERSION_REVISION", preg_replace( "#\\\$Rev:\s+([0-9]+)\s+\\\$#", '$1', EZ_NEWSLETTER_VERSION_REVISION_STRING ) );

class eZNewsletterSysInfo
{
    /*!
      \return the eZNewsletter version as a string
      \param withRelease If true the release version is appended
      \param withAlias If true the alias is used instead
    */
    function version( $withRelease = true, $asAlias = false, $withState = true )
    {
        if ( $asAlias )
        {
            $versionText = eZNewsletterSysInfo::alias();
            if ( $withState )
                $versionText .= "-" . eZNewsletterSysInfo::state();
        }
        else
        {
            $versionText = eZNewsletterSysInfo::majorVersion() . '.' . eZNewsletterSysInfo::minorVersion();
            if ( $withRelease )
                $versionText .= "." . eZNewsletterSysInfo::release();
            if ( $withState )
                $versionText .= eZNewsletterSysInfo::state();
        }
        return $versionText;
    }

    /*!
     \return the major version
    */
    function majorVersion()
    {
        return EZ_NEWSLETTER_VERSION_MAJOR;
    }

    /*!
     \return the minor version
    */
    function minorVersion()
    {
        return EZ_NEWSLETTER_VERSION_MINOR;
    }

    /*!
     \return the state of the release
    */
    function state()
    {
        return EZ_NEWSLETTER_VERSION_STATE;
    }

    /*!
     \return the development version or \c false if this is not a development version
    */
    function developmentVersion()
    {
        return EZ_NEWSLETTER_VERSION_DEVELOPMENT;
    }

    /*!
     \return the release number
    */
    function release()
    {
        return EZ_NEWSLETTER_VERSION_RELEASE;
    }

    /*!
     \return the SVN revision number
    */
    function revision()
    {
        return EZ_NEWSLETTER_VERSION_REVISION;
    }

    /*!
      \return the version of the database.
      \param withRelease If true the release version is appended
    */
    function databaseVersion( $withRelease = true )
    {
        include_once( 'lib/ezdb/classes/ezdb.php' );
        $db =& eZDB::instance();
        $rows = $db->arrayQuery( "SELECT value as version FROM ezsite_data WHERE name='eznewsletter-version'" );
        $version = false;
        if ( count( $rows ) > 0 )
        {
            $version = $rows[0]['version'];
            if ( $withRelease )
            {
                $release = eZNewsletterSysInfo::databaseRelease();
                $version .= '-' . $release;
            }
        }
        return $version;
    }

    /*!
      \return the release of the database.
    */
    function databaseRelease()
    {
        include_once( 'lib/ezdb/classes/ezdb.php' );
        $db =& eZDB::instance();
        $rows = $db->arrayQuery( "SELECT value as release FROM ezsite_data WHERE name='eznewsletter-release'" );
        $release = false;
        if ( count( $rows ) > 0 )
        {
            $release = $rows[0]['release'];
        }
        return $release;
    }
}

?>
