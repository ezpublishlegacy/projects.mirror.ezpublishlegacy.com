<?php
//
// Definition of eZSubscriptionList class
//
// Created on: <06-Dec-2005 13:31:34 hovik>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file ezsubscriptionlist.php
*/

/*!
  \class eZSubscriptionList ezsubscriptionlist.php
  \brief The class eZSubscriptionList does

*/

include_once(  'kernel/classes/datatypes/ezuser/ezuser.php' );
include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezsubscription.php' );

define( 'eZSubscriptionList_StatusDraft', 0 );
define( 'eZSubscriptionList_StatusPublished', 1 );

define( 'eZSubscriptionList_LoginStepsOne', 0 );
define( 'eZSubscriptionList_LoginStepsTwo', 1 );

define( 'eZSubscriptionList_URLTypeID', 0 );
define( 'eZSubscriptionList_URLTypeName', 1 );

class eZSubscriptionList extends eZPersistentObject
{
    /*!
     Constructor
    */
    function eZSubscriptionList( $row )
    {
        $this->eZPersistentObject( $row );
    }

    function definition()
    {
        return array( "fields" => array( "id" => array( 'name' => 'ID',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),
                                         'name' => array( 'name' => 'Name',
                                                          'datatype' => 'string',
                                                          'default' => '',
                                                          'required' => true ),
                                         'url_type' => array( 'name' => 'URLType',
                                                          'datatype' => 'integer',
                                                          'default' => 0,
                                                          'required' => true ),
                                         'url' => array( 'name' => 'URL',
                                                          'datatype' => 'string',
                                                          'default' => '',
                                                          'required' => true ),
                                         'description' => array( 'name' => 'Description',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         'allow_anonymous' => array( 'name' => 'allowAnonymous',
                                                                     'datatype' => 'integer',
                                                                     'default' => 1,
                                                                     'required' => true ),
                                         'require_password' => array( 'name' => 'requirePassword',
                                                                      'datatype' => 'integer',
                                                                      'default' => 1,
                                                                      'required' => true ),
                                         'login_steps' => array( 'name' => 'loginSteps',
                                                                     'datatype' => 'integer',
                                                                     'default' => 0,
                                                                     'required' => true ),
                                         'auto_confirm_registered' => array( 'name' => 'autoConfirmRegistered',
                                                                             'datatype' => 'integer',
                                                                             'default' => 1,
                                                                             'required' => true ),
                                         'auto_approve_registered' => array( 'name' => 'autoApproveRegistered',
                                                                             'datatype' => 'integer',
                                                                             'default' => 0,
                                                                             'required' => true ),
                                         'created' => array( 'name' => 'Created',
                                                             'datatype' => 'integer',
                                                             'default' => 0,
                                                             'required' => true ),
                                         'creator_id' => array( 'name' => 'Creator',
                                                                'datatype' => 'integer',
                                                                'default' => 0,
                                                                'required' => true ),
                                         "related_object_id_1" => array( 'name' => 'RelatedObjectID1',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         "related_object_id_2" => array( 'name' => 'RelatedObjectID2',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         "related_object_id_3" => array( 'name' => 'RelatedObjectID3',
                                                                         'datatype' => 'integer',
                                                                         'default' => 0,
                                                                         'required' => true ),
                                         'status' => array( 'name' => 'Status',
                                                            'datatype' => 'integer',
                                                            'default' => 0,
                                                            'required' => true ) ),
                      "keys" => array( "id", 'status' ),
                      'increment_key' => 'id',
                      'function_attributes' => array( 'creator' => 'creator',
                                                      'subscription_count' => 'subscriptionCount',
                                                      'related_object_1' => 'relatedObject1',
                                                      'related_object_2' => 'relatedObject2',
                                                      'related_object_3' => 'relatedObject3',
                                                      'url_alias' => 'urlAlias' ),
                      "increment_key" => "id",
                      'sort' => array( 'id' => 'asc' ),
                      "class_name" => "eZSubscriptionList",
                      "name" => "ezsubscription_list" );
    }

    /*!
     \reimp
    */
    function &attribute( $attr )
    {
        $retVal = null;
        switch( $attr )
        {
            case 'related_object_1':
            case 'related_object_2':
            case 'related_object_3':
            {
                $retVal = eZContentObject::fetch( $this->attribute( 'related_object_id_' . substr( $attr, -1, 1 ) ) );
            } break;

            default:
            {
                $retVal =& eZPersistentObject::attribute( $attr );
            } break;
        }

        return $retVal;
    }

    /*!
     Get URL alias
    */
    function &urlAlias()
    {
        switch( $this->attribute( 'url_type' ) )
        {
            case eZSubscriptionList_URLTypeName:
            {
                return $this->attribute( 'url' );
            } break;

            default:
            case eZSubscriptionList_URLTypeID:
            {
                return $this->attribute( 'id' );
            } break;
        }
    }

    /*!
     Add regular subscription to subscription list

     \param name
     \param email
     \param password
    */
    function registerSubscription( $firstname, $name, $mobile, $email, $password = false )
    {
        if ( $this->emailSubscriptionExists( $email ) )
        {
            return false;
        }

        $subscription = eZSubscription::create( $this->attribute( 'id' ),
                                                $firstname,
                                                $name,
                                                $mobile,
                                                $email );

        $user = eZUser::instance();

        if ( $this->attribute( 'auto_confirm_registered' ) &&  $user->isLoggedIn( ) )
        {
            $subscription->setAttribute( 'status', eZSubscription_StatusConfirmed );

            if ( $this->attribute( 'auto_approve_registered' ) )
            {
                $subscription->setAttribute( 'status', eZSubscription_StatusApproved );
            }
        }

        if ( $password !== false )
        {
            $subscription->setAttribute( 'password', $password );
        }

        $subscription->publish();

        return $subscription;
    }

    /*!
     Add eZ user to subscription list

     \param user ID ( automaticly confirmed )
    */
    function registerUser( $userID )
    {
        if ( $this->userExists( $userID ) )
        {
            return false;
        }

        $subscription = eZSubscription::create( $this->attribute( 'id' ), '', '', '', '', $userID );

        $subscription->setAttribute( 'status', eZSubscription_StatusConfirmed );

        if ( $this->attribute( 'auto_approve_registered' ) )
        {
            $subscription->setAttribute( 'status', eZSubscription_StatusApproved );
        }

        $subscription->publish();

        return $subscription;
    }

    /*!
     Unsubscribe regular subscription to subscription list
    */
    function unsubscribeSubscription( $email, $password = false )
    {
        $subscription = eZSubscription::fetchByEmailSubscriptionListID( $email,
                                                                        $this->attribute( 'id' ) );
        if ( $subscription )
        {
            if ( $password != false ||
                 $this->attribute( 'require_password' ) )
            {
                if ( $subscription->attribute( 'password' ) != md5( $password ) )
                {
                    $subscription = false;
                }
            }
        }

        if ( $subscription )
        {
            $subscription->unsubscribe();
            return true;
        }

        return false;
    }

    /*!
     Fetch subscription list a user is subscribed to, base on email
    */
    function fetchSubscribeListByUserID( $userID )
    {
        $subscriptionListArray = array();
        foreach( eZSubscription::fetchListByUserID( $userID ) as $subscription )
        {
            $subscriptionListArray[] = $subscription->attribute( 'subscription_list' );
        }

        return $subscriptionListArray;
    }

    /*!
     Fetch subscription list a user is subscribed to, base on email
    */
    function fetchSubscribeListByEmail( $email )
    {
        $subscriptionListArray = array();
        foreach( eZSubscription::fetchListByEmail( $email ) as $subscription )
        {
            $subscriptionListArray[] = $subscription->attribute( 'subscription_list' );
        }

        return $subscriptionListArray;
    }

    /*!
     Unsubscribe eZ user to subscription list

     \param user ID ( automaticly confirmed )
    */
    function unsubscribeUser( $userID )
    {
        $subscription = eZSubscription::fetchByUserSubscriptionListID( $userID,
                                                                       $this->attribute( 'id' ) );
        if ( $subscription )
        {
            $subscription->unsubscribe();
            return true;
        }

        return false;
    }

    /*!
     Fetch subscription list a user is subscribed to, base on userId
    */
    function fetchSubscriptionByUserID( $userID )
    {
    $subscriptionListArray = array();
        foreach( eZSubscription::fetchListByUserID( $userID ) as $subscription )
        {
            $subscriptionListArray[] = $subscription;
        }
        return $subscriptionListArray;
    }

    /*!
     Fetch subscription list a user is subscribed to, base on email
    */
    function fetchSubscriptionByEmail( $email )
    {
        $subscriptionListArray = array();
        foreach( eZSubscription::fetchListByEmail( $email ) as $subscription )
        {
            $subscriptionListArray[] = $subscription;
        }
        return $subscriptionListArray;
    }

    /*!
     Get number of subscribers
    */
    function &subscriptionCount()
    {
        $count = eZSubscription::count( $this->attribute( 'id' ) );
        return $count;
    }

    /*!
     \static

     Fetch draft of the eZSubscriptionList. If none exist, create one base on the published object

     \param id
    */
    function fetchDraft( $id, $asObject = true )
    {
        $subscriptionList = eZSubscriptionList::fetch( $id, eZSubscriptionList_StatusDraft, $asObject );
        if ( !$subscriptionList )
        {
            $subscriptionList = eZSubscriptionList::fetch( $id, eZSubscriptionList_StatusPublished, $asObject );
            if ( $subscriptionList )
            {
                $subscriptionList->setAttribute( 'status', eZSubscriptionList_StatusDraft );
                $subscriptionList->store();
            }
        }

        if ( !$subscriptionList )
        {
            return false;
        }

        return $subscriptionList;
    }

    /*!
     \static

     Fetch eZSubscriptionList object

     \param id
     \param status
    */
    function fetch( $id, $status = eZSubscriptionList_StatusPublished, $asObject = true, $forceID = false )
    {
        $condArray = array( 'id' => $id,
                            'status' => $status );
        if ( !$forceID )
        {
            $condArray['url_type'] = eZSubscriptionList_URLTypeID;
        }

        $subscriptionList = eZPersistentObject::fetchObject( eZSubscriptionList::definition(),
                                                             null,
                                                             $condArray,
                                                             $asObject );
        if ( !$subscriptionList )
        {
            $subscriptionList = eZPersistentObject::fetchObject( eZSubscriptionList::definition(),
                                                                 null,
                                                                 array( 'url' => $id,
                                                                        'status' => $status,
                                                                        'url_type' => eZSubscriptionList_URLTypeName ),
                                                                 $asObject );
        }

        return $subscriptionList;
    }

    /*!
     Publish eZSubscriptionList.
     1. Sets status to publish
     2. Stores object
     3. Removes draft
    */
    function publish()
    {
        $this->setAttribute( 'status', eZSubscriptionList_StatusPublished );
        $this->store();

        $this->removeDraft();
    }

    /*!
     Remove draft of current object
    */
    function removeDraft()
    {
        $subscriptionListDraft = eZSubscriptionList::fetchDraft( $this->attribute( 'url_alias' ) );
        $subscriptionListDraft->remove();
    }

    /*!
     \static
     Remove all entries of specified ID.

     \param ID
    */
    function removeAll( $id )
    {
        eZPersistentObject::removeObject( eZSubscriptionList::definition(),
                                          array( 'id' => $id ) );
    }

    /*!
     Check if an email address is already registered in the subscription list

     \param email address
    */
    function emailSubscriptionExists( $email )
    {
        $subscription = eZSubscription::fetchByEmailSubscriptionListID( $email, $this->attribute( 'id' ) );
        if ( $subscription )
        {
            return true;
        }
        return false;
    }

    /*!
     Check if user exists in subscription list

     \param user id
    */
    function userExists( $userID )
    {
        $subscription = eZSubscription::fetchByUserSubscriptionListID( $userID, $this->attribute( 'id' ) );
        if ( $subscription )
        {
            return true;
        }
        return false;
    }

    /*!
     \static

     Create new eZSubscriptionList object
    */
    function create( $name = '', $userID = false )
    {
        if ( $userID === false )
        {
            $userID = eZUser::currentUserID();
        }

        $subscriptionList = new eZSubscriptionList( array( 'created' => mktime(),
                                                           'creator_id' => $userID,
                                                           'name' => $name,
                                                           'status' => eZSubscriptionList_StatusDraft ) );
        $subscriptionList->store();

        return $subscriptionList;
    }

    /*!
     Get Creator user object
    */
    function &creator()
    {
        include_once( 'kernel/classes/datatypes/ezuser/ezuser.php' );

        $user = eZUser::fetch( $this->attribute( 'creator_id' ) );
        return $user;
    }

    /*!
     \static

      Fetch list of subscriptions


     \param offset
     \param limit
     \param as object

     \return list of subscription list items
    */
    function fetchList( $offset = 0, $limit = 10, $asObject = true, $status = eZSubscriptionList_StatusPublished )
    {
        return eZPersistentObject::fetchObjectList( eZSubscriptionList::definition(),
                                                    null,
                                                    array( 'status' => $status ),
                                                    null,
                                                    array( 'limit' => $limit,
                                                           'offset' => $offset ),
                                                    $asObject );
    }

    /*!
     Fetch subscription list

     \param offset
     \param limit
     \param $asObject
     \param version status
     \param status
    */
    function fetchSubscriptionArray( $offset = 0,
                                     $limit = 100,
                                     $asObject = true,
                                     $versionStatus = eZSubscription_VersionStatusPublished,
                                     $status = eZSubscription_StatusApproved )
    {
        return eZPersistentObject::fetchObjectList( eZSubscription::definition(),
                                                    null,
                                                    array( 'version_status' => $versionStatus,
                                                           'status' => $status,
                                                           'subscriptionlist_id' => $this->attribute( 'id' ) ),
                                                    null,
                                                    array( 'limit' => $limit,
                                                           'offset' => $offset ),
                                                    $asObject );
    }

    /*!
     Fetch subscription list count

     \param version status
     \param status
    */
    function fetchSubscriptionArrayCount( $versionStatus = eZSubscription_VersionStatusPublished,
                                         $status = eZSubscription_StatusApproved )
    {
        $rows = eZPersistentObject::fetchObject( eZSubscription::definition(),
                                                 array(),
                                                 array( 'version_status' => $versionStatus,
                                                        'status' => $status,
                                                        'subscriptionlist_id' => $this->attribute( 'id' ) ),
                                                 false,
                                                 false,
                                                 array( array( 'operation' => 'count( id )',
                                                               'name' => 'count' ) ) );
        return $rows['count'];
    }

    /*!
     \static

     Get subscription list count

     \return eZSubscriptionList count
    */
    function count( $status = eZSubscriptionList_StatusPublished )
    {
        $rows = eZPersistentObject::fetchObject( eZSubscriptionList::definition(),
                                                 array(),
                                                 array( 'status' => $status ),
                                                 false,
                                                 false,
                                                 array( array( 'operation' => 'count( id )',
                                                               'name' => 'count' ) ) );
        return $rows['count'];
    }

    /*!
     \static
     Get login step name map
    */
    function loginStepsNameMap()
    {
        return array( eZSubscriptionList_LoginStepsOne => ezi18n( 'eznewsletter/login_steps', 'Confirm user' ),
                      eZSubscriptionList_LoginStepsTwo => ezi18n( 'eznewsletter/login_steps', 'Confirm and approve user' ) );
    }
}

?>
