<?php
//
// Created on: <18-Jan-2006 18:25:13 hovik>
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file subscription_import.php
*/

include_once( 'kernel/common/template.php' );
include_once( 'lib/ezutils/classes/ezmail.php' );
include_once( eZExtension::baseDirectory() . '/eznewsletter/classes/ezrobinsonlist.php' );

$Module =& $Params['Module'];

$http =& eZHTTPTool::instance();

$empty_input=true;
$done=false;
$warning="";

if ( $http->hasPostVariable( 'AddButton' ) || $http->hasPostVariable( 'RemoveButton' )  )
{
    if ( $http->hasPostVariable( 'RobinsonlistEntry_Email' ) )
    {
    if ( $http->postVariable( 'RobinsonlistEntry_Email' ) != "" )
    {    
        $empty_input=false;
        if ( eZMail::validate ( $http->postVariable( 'RobinsonlistEntry_Email' ) ) )
        {
        if ( $http->hasPostVariable( 'AddButton' ) )
        {
            if ( !eZRobinsonlistEntry::inList( $http->postVariable( 'RobinsonlistEntry_Email' ), eZRobinsonlistEntryType_EMAIL ) )
            {
            eZRobinsonlistEntry::create( $http->postVariable( 'RobinsonlistEntry_Email' ), eZRobinsonlistEntryType_EMAIL, eZRobinsonlistEntry_LOCAL );
            $done=true;
            }
            else
            {
            $warning = ezi18n( 'eznewsletter/robinson_user', 'Entered email address is already in the list.' );
            $done=true;
            }
            
        }
        else if ( $http->hasPostVariable( 'RemoveButton' ) )
        {
            if ( eZRobinsonlistEntry::inList( $http->postVariable( 'RobinsonlistEntry_Email' ), eZRobinsonlistEntryType_EMAIL, eZRobinsonlistEntry_LOCAL ) )
            {
            eZRobinsonlistEntry::removeByValue( $http->postVariable( 'RobinsonlistEntry_Email' ), eZRobinsonlistEntryType_EMAIL, eZRobinsonlistEntry_LOCAL );
            $done=true;
            }
            else
            {
            $warning = ezi18n( 'eznewsletter/robinson_user', 'Entered email address is not in the list.' );
            $done=true;
            }
        }
        }
        else
        {
        $warning = ezi18n( 'eznewsletter/robinson_user', 'Please enter a valid email.' );
        $done=true;
        }
    }
    }
    
    if ( $http->hasPostVariable( 'RobinsonlistEntry_Mobile' ) )
    {
    if ( $http->postVariable( 'RobinsonlistEntry_Mobile' ) != "" )
    {    
        $empty_input=false;
        if ( $http->hasPostVariable( 'AddButton' ) )
        {
            if ( !eZRobinsonlistEntry::inList( $http->postVariable( 'RobinsonlistEntry_Mobile' ), eZRobinsonlistEntryType_MOBILE ) )
            {
            eZRobinsonlistEntry::create( $http->postVariable( 'RobinsonlistEntry_Mobile' ), eZRobinsonlistEntryType_MOBILE, eZRobinsonlistEntry_LOCAL );
            $done=true;
            }
            else
            {
            $warning = ezi18n( 'eznewsletter/robinson_user', 'Entered mobile phone number is already in the list.' );
            $done=true;
            }
        }
        else if ( $http->hasPostVariable( 'RemoveButton' ) )
        {
            if ( eZRobinsonlistEntry::inList( $http->postVariable( 'RobinsonlistEntry_Mobile' ), eZRobinsonlistEntryType_MOBILE, eZRobinsonlistEntry_LOCAL ) )
            {
            eZRobinsonlistEntry::removeByValue( $http->postVariable( 'RobinsonlistEntry_Mobile' ), eZRobinsonlistEntryType_MOBILE, eZRobinsonlistEntry_LOCAL );
            $done=true;
            }
            else
            {
            $warning = ezi18n( 'eznewsletter/robinson_user', 'Entered mobile phone number is not in the list.' );
            $done=true;
            }
        }
    }
    }

    if ( ( !$done ) && ( $warning == "" ) )
    {
    $warning = ezi18n( 'eznewsletter/robinson_user', 'An error occured, no updates were made.' );
    }
    
    if ( ( $done ) && ( $warning == "" ) )
    {
    $warning = ezi18n( 'eznewsletter/robinson_user', 'Updates complete.' );
    }
    
    if ( ( $empty_input ) && ( $warning == ""  ) )
    {
    $warning = ezi18n( 'eznewsletter/robinson_user', 'You must fill in at least one field.' );
    }

}

$tpl =& templateInit();
if ( $warning != "" ) {
    $tpl->setVariable( 'warning', $warning );
}

$Result = array();
$Result['content'] =& $tpl->fetch( "design:eznewsletter/robinson_user.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'eznewsletter/robinson_user', 'Robinsonlist settings' ) ) );

?>
