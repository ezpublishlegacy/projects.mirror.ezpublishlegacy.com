<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/eznewsletter/autoloads/ezhelperoperators.php',
                                    'class' => 'eZHelperOperators',
                                    'operator_names' => array( 'eZDefaultHostname' ) );

$eZTemplateOperatorArray[] = array( 'script' => 'extension/eznewsletter/autoloads/eztopmenuoperator.php',
                                    'class' => 'eZTopMenuOperator',
                                    'operator_names' => array( 'topmenu' ) );
?>
