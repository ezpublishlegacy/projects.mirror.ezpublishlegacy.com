<?php /*

[ExtensionSettings]
DesignExtensions[]=eznewsletter

[StylesheetSettings]
CSSFileList[]=eznewsletter.css

*/ ?>
