<?php
//
// Definition of glossary class, based on the word to image operator by eZ systems 
//
// Created on: <2003-05-12>
// This operator is created in support of the Knowledge Management Portals
// project of the SCK-CEN. 
//
// Copyright (C) 2003 SCK-CEN, programming by Hans Melis.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the ez publish base distribution.
//

// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is also available at
// http://www.gnu.org/copyleft/gpl.html.
//
/*! \file ezglossaryoperator.php
*/

/*!
  \class eZglossaryoperator ezglossaryoperator.php
  \brief The class eZGlossaryoperator does

*/

include_once( "kernel/classes/ezcontentobject.php" );
include_once( "kernel/classes/ezcontentobjecttreenode.php" );


class eZGlossaryOperator
{
    /*!
      Initializes the object with the name $name, default is "glossary".
    */
    function eZGlossaryOperator( $name = "glossary" )
    {
	  $this->Operators = array( $name );
    }

    /*!
      Returns the template operators.
    */
    function &operatorList()
    {
	  return $this->Operators;
    }
	
	function namedParameterList()
	{
	  include_once( "lib/ezutils/classes/ezini.php" );
      $ini =& eZINI::instance("glossary.ini");
      $glossaryRoot = $ini->variable( 'GlossarySettings', 'DefaultGlossaryNodeID' );
	  
	  return array( "mark_once" => array( "type" => "string",
	                                     "required" => false,
	                                     "default" => "false" ),
					"glossary_root" => array( "type" => "numeric",
					                          "required" => false,
											  "default" => $glossaryRoot ),
					"return_method" => array( "type" => "string",
					                          "required" => false,
											  "default" => "replace" ) );
	}
	
	
	/*!
	  Retrieves info from the treenode members
	  Name, Class ID, Node ID of the object
	*/
	function getInfo($children)
	{
	  $i = 0;
	  $ret = array();
	  
	  foreach($children as $child)
	  {
	    // Get the object ID of the child and fetch it
		$objID = $child->attribute("contentobject_id");
		$obj = eZContentObject::fetch($objID);
	    
		// Load the object's datamap
		$obj->dataMap();
		$dataMap =& $obj->attribute( "data_map" );
		
		// Get the class id
		$clsID = $obj->attribute("contentclass_id");
				
		// Store the Name, ClassID and NodeID
		$ret[$i]["ClassID"] = $clsID;
		
		include_once( "lib/ezutils/classes/ezini.php" );
		$ini =& eZIni::instance( "glossary.ini" );
		$setting = $ini->variable( "GlossarySettings", "ClassSetting_" . $clsID );
				
		$ret[$i]["Name"] = $obj->attribute("name");
		$ret[$i]["NodeID"] = $child->attribute("node_id");
		
		if(isset($setting) && isset($dataMap[$setting["Short"]]))
		{
		  $ret[$i]["Desc"] = $dataMap[$setting["Short"]]->attribute("data_text");
		  $ret[$i]["Desc"] = strip_tags($ret[$i]["Desc"]);
		  
		  if(ord($ret[$i]["Desc"]) == 10)
		  {
		    $ret[$i]["Desc"] = substr($ret[$i]["Desc"],4);
			$ret[$i]["Desc"] = substr($ret[$i]["Desc"],0, strlen($ret[$i]["Desc"]) - 1);
		  }
		}
		
		// The class ID of Folders == 1
		// If the current child is a Folder, loop through its children
		// This makes this function recursive. It'll loop through _every_ child of the glossary root
		if($clsID == 1)
		{
		  $children2 =& $child->children();
		  $res = $this->getInfo($children2);
		  
		  $ret[$i]["Children"] = $res;
		}
		else
		{
		  $ret[$i]["Children"] = null;
		}
		
		$i++;
	  }
	  // Return the result
	  return $ret;
	}

	/*!
	  Makes the $search and $replace array ready for usage
	  Takes a tree of arrays as input and outputs 2 arrays
	*/
	function buildArrays( $glossaryTree )
	{
	  $search = array();
	  $replace = array();
	  	  
	  // Loop through each element
	  foreach($glossaryTree as $item)
	  {
	    if( $item["ClassID"] != 1 ) // Not a folder?
		{
		  $tmp = array();
		  // All varitions of the Name, NAME and name
		  $tmp[] = strtoupper($item["Name"]);
		  $tmp[] = strtolower($item["Name"]);
		  $tmp[] = ucfirst($item["Name"]);
		  
		  // Take each variation and make a $replace entry for it
		  // the $replace entry contains a link to the full object
		  foreach($tmp as $name)
		  {  
		    $search[] = $name;
		    $replace[] = "<a href=\"/index.php/demo/content/view/full/" . $item["NodeID"] . "\" title=\"" . strip_tags($item["Desc"]) . "\">" . $name . "</a>";
		  }
		}
		else // It's a folder
		{
		  // Recursive function again
		  // Do this function for every "child" array
		  $this->level++;
		  $res = $this->buildArrays($item["Children"]);
		  $this->level--;
		  // Merge the result of the children with the parent
		  $search = array_merge($search, $res[0]);
		  $replace = array_merge($replace, $res[1]);
		}
		
	  }
	  
	  for($j = 0; $j < count($search) && $this->level == 0; $j++)
	  {
	    $search[$j] = "/\b" . $search[$j] . "\b/";
	  }
	  
	  // Return both arrays
	  $ret[0] = $search;
	  $ret[1] = $replace;
	  
	  return $ret;
	}
	
	function flattenGlossaryArray( $glosArray )
	{
	  $ret = array();
	    
	  foreach( $glosArray as $glosItem )
	  {
	    if( $glosItem["ClassID"] != 1 ) // Not a folder?
		{
		  $ret[$this->teller]["Name"] = $glosItem["Name"];
		  $ret[$this->teller]["NodeID"] = $glosItem["NodeID"];
		  $ret[$this->teller]["Desc"] = $glosItem["Desc"];
		  $this->teller++;
		}
		else
		{
		  $res = $this->flattenGlossaryArray($glosItem["Children"]);
		  $ret = array_merge($ret, $res);
		}
	  }
	  
	  return $ret;
	}
	
	
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $markOnce = $namedParameters["mark_once"];
		$glossaryRoot = $namedParameters["glossary_root"];
		$returnMethod = $namedParameters["return_method"];
		
		
		// Fetch the tree node with the ID we found in the ini
		$node = eZContentObjectTreeNode::fetch($glossaryRoot);
		$node->dataMap();
		// Loop through all children of this node
		$children = $node->children();
		
		// Loop through all returned children and gather the info for the glossary
		$res = $this->getInfo($children);
		
		switch( $returnMethod )
		{
		  case "array":
		  {
		    $this->teller = 0;
			$res = $this->flattenGlossaryArray($res);
			$operatorValue = $res;
		  }
		  break;
		  
		  default: // "replace" method
		  {
			// Use the info to build the arrays so we can start replacing
			$res = $this->buildArrays($res);
			
			// $res[0] = what we need to find ; $res[1] = what we need to add
			$search = $res[0];
			$replace = $res[1];

			// Strip the "dangerous" tags from the $operatorValue.
			// This is to prevent false matches inside tag attributes
			$res = stripTags( $operatorValue, array( "link", "a", "object" ) );
			$operatorValue = $res[0];
			$orig_tags = $res[1];

			// Replace every match in $search with the corresponding value from $replace
			if( $markOnce != "false" )
			{
			  $operatorValue = preg_replace( $search, $replace, $operatorValue, 1 );
			}
			else
			{
			  $operatorValue = preg_replace( $search, $replace, $operatorValue );
			}

			// Now put the stripped tags back into the text
			$operatorValue = resetTags( $operatorValue, $orig_tags );
		  }
		}
    }
	
	
	
    var $Operators;
	var $teller;
	var $original_tags;
	var $level;
	var $settings;
}

	$original_tags = array();
	$teller = 0;
	
	/*!
	  Strips certain tags from the text
	*/
	function stripTags( $tekst, $tags )
	{
	  if( count($tags) > 0 )
	  {
	    foreach($tags as $tag)
		{
		  // Regular expressions ;)
		  // Use a callback to provide custmomised replacements
		  // This searches for <tag.....>.....</tag>
		  // If there's a match, it calls the function replaceLink
		  $tekst = preg_replace_callback( "/<$tag.*>.*<\/$tag>/i", 'replaceTags', $tekst );
		}
	  }
	  
	  global $original_tags;
	  
	  // Build an array so we can return multiple vars
	  $ret = array();
	  // The "stripped" text
	  $ret[0] = $tekst;
	  // The "stripped" tags
	  $ret[1] = $original_tags;
	  
	  return $ret;
	}
	
	/*!
	  Callback function for stripTags
	  Replaces a match in stripTags with <skip*> where * is an int >= 0
	*/
	function replaceTags( $match )
	{
	  global $original_tags;
	  global $teller;
	  
	  // Store the tag so it can be re-added later on
	  $original_tags[$teller] = $match[0];
	  $teller++;
	  
	  // Return what we want in place of the tag
	  return "<skip" . ($teller - 1) . ">";
	}
	
	
	/*!
	  Reverse function of stripTags
	  Add the tags in $original_tags back to the text
	*/
	function resetTags( $tekst, $tags )
	{
	  $j = 0;
	  
	  if( count($tags) > 0 )
	  {
	    foreach( $tags as $tag )
		{
		  // Replace the generic <skip*> tags with their respective tag in $original_tags
		  $tekst = str_replace( "<skip".$j.">", $tag, $tekst );
		  $j++;
		}
	  }
	  
	  // Return the result
	  return $tekst;
	}
?>
