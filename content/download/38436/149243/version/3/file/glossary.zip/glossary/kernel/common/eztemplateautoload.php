<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/glossary/kernel/common/ezglossaryoperator.php',
                                    'class' => 'eZGlossaryOperator',
                                    'operator_names' => array( 'glossary' ) );
?>