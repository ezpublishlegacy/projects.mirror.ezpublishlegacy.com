var dir_b79b4402c5a63f66facb61d37ae6dfdd =
[
    [ "muninplugin.php", "muninplugin_8php.html", "muninplugin_8php" ],
    [ "rotateperflogs.php", "bin_2php_2rotateperflogs_8php.html", "bin_2php_2rotateperflogs_8php" ],
    [ "updateperfstats.php", "bin_2php_2updateperfstats_8php.html", "bin_2php_2updateperfstats_8php" ]
];