var dir_971d3531c8489f009a3a58e6d4915cec =
[
    [ "removexhprofdata.php", "removexhprofdata_8php.html", null ],
    [ "rotateperflogs.php", "cronjobs_2rotateperflogs_8php.html", "cronjobs_2rotateperflogs_8php" ],
    [ "updateperfstats.php", "cronjobs_2updateperfstats_8php.html", "cronjobs_2updateperfstats_8php" ]
];