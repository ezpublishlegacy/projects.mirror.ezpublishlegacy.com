var display_8php =
[
    [ "$ini", "display_8php.html#a8f5f30fbe4092bf20ba2fcae8197ab09", null ],
    [ "$muninUrl", "display_8php.html#ad804d95c872283aa0a5ea595586ba1eb", null ],
    [ "$Result", "display_8php.html#a94a2cc5784adee982dec0235638f6251", null ],
    [ "$tpl", "display_8php.html#a04b1944cdb09f9a4e290cde7a12499e6", null ]
];