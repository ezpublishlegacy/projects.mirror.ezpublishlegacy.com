<?php /*

[Leftmenu_setup]
Links[xhprof]=xhprof/list
LinkNames[xhprof]=XHProf Profiling

[Leftmenu_setup]
Links[munin]=munin/display
LinkNames[munin]=Munin monitoring

*/ ?>
