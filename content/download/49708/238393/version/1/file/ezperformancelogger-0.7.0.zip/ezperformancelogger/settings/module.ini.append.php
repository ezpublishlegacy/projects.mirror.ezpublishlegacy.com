<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezperformancelogger

ModuleList[]=xhprof

*/ ?>
