var searchData=
[
  ['if',['if',['../xhprof_8php.html#a1c629f5ab50b18e83b859f79b55abe18',1,'xhprof.php']]],
  ['info',['info',['../classeZperformanceloggerInfo.html#a58a9b0ad80ed28ec99e6c910996fc6e7',1,'eZperformanceloggerInfo']]],
  ['init_5fmetrics',['init_metrics',['../xhprof_8php.html#ac0a56fe454d451714e26cacf7c6a007b',1,'xhprof.php']]],
  ['insertstats',['insertStats',['../classeZPerfLoggerCSVStorage.html#a3699f94fb5bacabd2756b921015250ca',1,'eZPerfLoggerCSVStorage\insertStats()'],['../classeZPerfLoggerMemStorage.html#aab82bd19054bc6baf3dc233f1fe1bdff',1,'eZPerfLoggerMemStorage\insertStats()'],['../interfaceeZPerfLoggerStorage.html#a247517717be6fd843fd6b385a255acc2',1,'eZPerfLoggerStorage\insertStats()']]],
  ['isenabled',['isEnabled',['../classeZPerfLogger.html#a4df6d5523d873d7520c87537bb3a7703',1,'eZPerfLogger']]],
  ['isrunning',['isRunning',['../classeZXHProfLogger.html#a80dbdea0e69c9f740ef13d86e8754207',1,'eZXHProfLogger']]],
  ['ixhprofruns',['iXHProfRuns',['../interfaceiXHProfRuns.html',1,'']]]
];
