var searchData=
[
  ['measure',['measure',['../classeZPerfLogger.html#a3952ebdfeda2fd81492a54bfbdea6bfc',1,'eZPerfLogger\measure()'],['../classeZMySQLiTracing46DB.html#a73ca4aadb284199ac32ac027bbf7680c',1,'eZMySQLiTracing46DB\measure()'],['../classeZDFSFileHandlerTracing46MySQLiBackend.html#a19fc876900b075259283bc1cbb424d51',1,'eZDFSFileHandlerTracing46MySQLiBackend\measure()'],['../interfaceeZPerfLoggerProvider.html#abf356d4c6d82eb55e228bc1d60e6ba74',1,'eZPerfLoggerProvider\measure()']]],
  ['modify',['modify',['../classeZPerformanceLoggerOperators.html#a7b930e75bdfb8b69e186cafef7a50a6b',1,'eZPerformanceLoggerOperators']]]
];
