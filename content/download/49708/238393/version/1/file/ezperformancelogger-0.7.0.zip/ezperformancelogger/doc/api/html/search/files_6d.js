var searchData=
[
  ['module_2ephp',['module.php',['../munin_2module_8php.html',1,'']]],
  ['module_2ephp',['module.php',['../xhprof_2module_8php.html',1,'']]],
  ['muninplugin_2ephp',['muninplugin.php',['../muninplugin_8php.html',1,'']]]
];
