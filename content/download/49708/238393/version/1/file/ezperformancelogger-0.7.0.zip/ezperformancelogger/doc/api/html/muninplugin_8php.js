var muninplugin_8php =
[
    [ "$cli", "muninplugin_8php.html#a1962cabd2d6087314ff8f618e5962cfd", null ],
    [ "$ini", "muninplugin_8php.html#a8f5f30fbe4092bf20ba2fcae8197ab09", null ],
    [ "$options", "muninplugin_8php.html#a011800c63ece4cbbfa77136a20607023", null ],
    [ "$range", "muninplugin_8php.html#ac2e4b5fa63099d7c943a803ae122dd2b", null ],
    [ "$script", "muninplugin_8php.html#af1de23de512bb5bf634c157dbb1b7758", null ],
    [ "$variable", "muninplugin_8php.html#a92967b17317b380ca6e34d6327dfa68a", null ]
];