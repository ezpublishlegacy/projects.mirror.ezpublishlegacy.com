<?php /*

[CronjobSettings]
Scripts[]=generate.php
ExtensionDirectories[]=ezgenerate

[CronjobPart-generate]
Scripts[]=generate.php

*/ ?>
