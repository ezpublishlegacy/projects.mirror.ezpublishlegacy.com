<?php

$localeZPath = "/ezp/path/";
$remoteeZPath = "/ezp/path/";
// If true then we are updateing slave against master,
// if false we are updateing master againt slave.
$remote = false;

$remoteHost = "REMOTEHOST";
$remoteUser = "USER";

$deleteArray = array();
$getFilesArray = array();

$localLogFile = "/ezp/path/fileops.log";
$remoteLogFileURL = "http://REMOTEHOST/fileops.log";
$remoteLogFile = "/ezp/path/fileops.log";

if ( $argv[1] == 'master' )
{
    $remote = false;
}
else
{
    $remote = true;
}

function rotate_log( $logFile )
{
    GLOBAL $remote;
    if ( $remote )
    {
        GLOBAL $remoteHost;
        GLOBAL $remoteUser;
        GLOBAL $remoteLogFile;
        
		system( "ssh $remoteUser@$remoteHost \" echo > $remoteLogFile \" " );
    }
    else
    {
        $fp = fopen( $logFile, 'w' );
        fwrite( $fp, "MARK\n" );
        fclose( $fp );
    }
}

function parse_log_file( $logFile )
{
    GLOBAL $deleteArray;
    GLOBAL $getFilesArray;

    $fileArray = file( $logFile );
    $fileArray = preg_replace( "/^.*var\/log\/.*$/", "", $fileArray );     // Remove var/log/ entries. Don't touch ezp log files.
    $fileArray = preg_replace( "/.+\.php\.\S+\n$/", "", $fileArray );      // Filter out temporary files
    $fileArray = array_unique( $fileArray );

    if ( !$fileArray )
    {
        die( "Unable to open file: $logFile\n" );
    }
    else
    {
        rotate_log( $logFile );
    }

    foreach ( $fileArray as $line )
    {
        list( $action, $filename, $extra ) = split( "\t", trim( $line ) );
        switch ( $action )
        {
            case "MUF": // Move Uploaded File
                $getFilesArray[] = $extra;
                break;
            case "R": // Rename
                 $getFilesArray[] = $extra;
                break;
            case "w": // Write
                $getFilesArray[] = $filename;
                break;
            case "a": // Append
                $getFilesArray[] = $filename;
                break;
            case "U": // Unlink (remove)
                $deleteArray[] = $filename;
                break;
            case "wb": // Write binary
                $getFilesArray[] = $filename;
                break;
            case "w+": // Write and append
                $getFilesArray[] = $filename;
                break;
        }
    }
}

function remove_local_files( $deleteArray, $localeZPath )
{
    $deleteArray = array_unique( $deleteArray );

    foreach( $deleteArray as $delFile )
    {
        $file = $localeZPath . $delFile;
        // If we hit a viewcache file, we need to delete every viewcache file for that node.
        // Because the other server might have viewcache files for a node that we don't. (One viewcache file per user per node).
        // Which is why we are grabbing the node id and removing all <node-id>-*.cache files
        if ( preg_match( "/(.+\/)(\d+)\-\w+\.cache$/", $file, $matches ) )
            $file = $matches[1] . $matches[2] . "-*.cache";

        system( "rm -f $file" );
    }
}

function remove_remote_files( $deleteArray, $remoteeZPath, $remoteUser, $remoteHost )
{
    $deleteArray = array_unique( $deleteArray );
    $deleteStringArray = array();

    $loopInc = 0;
    $fileArrayInc = 0;

    // The reason for the rather "complex" looping stuff here is we want to only pass 150
    // filenames as arguments at one time to scp. Because we don't want to flood the argument buffer.
    // If more than 150 files we simply slit it up and call scp as many times as needed.
    foreach( $deleteArray as $delFile )
    {
        $file = $remoteeZPath . $delFile;
        if ( !strstr( $delFile, '/var/log/' ) )
        {
            if ( $loopInc >= 150 )
            {
                ++$fileArrayInc;
                $loopInc = 0;
            }
            // If we hit a viewcache file, we need to delete every viewcache file for that node.
            // Because the other server might have viewcache files for a node that we don't. (One viewcache file per user per node).
            // Which is why we are grabbing the node id and removing all <node-id>-*.cache files
            if ( preg_match( "/(.+\/)(\d+)\-\w+\.cache$/", $file, $matches ) )
                $file = $matches[1] . $matches[2] . "-*.cache";

            $deleteStringArray[$fileArrayInc] .= " $file";
            ++$loopInc;
        }
    }
    foreach( $deleteStringArray as $deleteString )
    {
        system( "ssh $remoteUser@$remoteHost \"rm -f $deleteString\"\n" );
    }
}

function get_files( $getFilesArray, $localeZPath, $remoteeZPath, $remoteUser = '', $remoteHost = '')
{
    GLOBAL $remote;
    $getFilesArray = preg_replace( "/^var\/cache\/.+$/", "", $getFilesArray );     
    $getFilesArray = preg_replace( "/^var\/(.+\/|)cache\/.+\/.+$/", "", $getFilesArray );
    $getFilesArray = array_unique( $getFilesArray );

    $dirStringArray = array();
    $fileLoop = 0;

    // These loops are for the rsync import file. The file need to have structure like this:
    // var/
    // var/cache
    // var/cache/ini
    foreach( $getFilesArray as $file )
    {
        $dirLoop = 0;
        $dirArray = explode( "/", $file );
        foreach ( $dirArray as $dir )
        {
            if ( $dirLoop > 0 )
                 $dirStringArray[] = $dirStringArray[$fileLoop - 1] . "/" . $dir;
             else
                 $dirStringArray[] = "/" . $dir;
             ++$dirLoop;
            ++$fileLoop;
        }
    }

    $dirStringArray = array_unique( $dirStringArray );
    if ( count( $dirStringArray ) > 0 )
    {
        $outFile = tempnam( "/tmp/", "ezp-sync");
        $fp = fopen( $outFile, 'w+' );
        if ( !$fp )
        {
            trigger_error ( 'Can not write to temp file.', E_USER_ERROR );
            return;
        }
        fputs( $fp, implode( "\n", $dirStringArray ) );

        if ( $remote )
        {
            system( "rsync -pg -r --include-from=$outFile --exclude=\"*\" " . $remoteUser . '@' . $remoteHost . ":" . "$remoteeZPath $localeZPath" );
        }
        else
        {
            system( "rsync -pg -r --include-from=$outFile --exclude=\"*\" $localeZPath $remoteUser@$remoteHost:$remoteeZPath" );
        }

        fclose( $fp );
        unlink( $outFile );
    }
}

if ( $remote == true )
    $filename = $remoteLogFileURL;
else
    $filename = $localLogFile;

parse_log_file( $filename );

if ( $remote == true )
{
   get_files( $getFilesArray, $localeZPath, $remoteeZPath, $remoteUser, $remoteHost );
   remove_local_files( $deleteArray, $remoteeZPath, $remoteUser, $remoteHost );
}
else
{
   get_files( $getFilesArray, $remoteeZPath, $localeZPath, $remoteUser, $remoteHost );
   remove_remote_files( $deleteArray, $localeZPath, $remoteUser, $remoteHost );
}

?>