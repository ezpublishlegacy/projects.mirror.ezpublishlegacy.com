eZ publish and PHP patches
--------------------------

The three pathces available in this package can be
used to patch eZ publish and PHP in order to log every
file created, modified or removed.

Apply the following patches to eZ publish (3.5.x)
ezimagealiashandler.patch  
ezimagefile.patch

Apply the following patch to PHP 4.3.10
file-actions-log.patch

The default location of the log file is /tmp/fileops.log
and it can be altered with the PHP ini setting:
ile_action_log="/path/to/fileops.log"

The format of the log file is the following:
w+      var/cache/ini/f0b8476f1116201438d5110d1416160c.php
a       var/log/storage.log
r       var/ezno/cache/content/ezno/full/eng-GB/19-7c62aa.cache
rb      var/ezno/cache/override/override_1982253087.php
rb      var/ezno/cache/template/compiled/common.php

The file sync.php is a script which can be used to sync
files from one server to another. This script requires
that the REMOTEUSER has ssh keys in such a way that it 
can use ssh without passwords and that it needs to have
writeaccess to to var/ and fileops.log.

Usage:

$ php sync.php master # Syncs slave against master
$ php sync.php slave # Syncs the master against the slave
