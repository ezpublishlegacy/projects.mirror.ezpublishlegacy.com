<?php
class bcfetchxmlInfo
{
    function info()
    {
        return array(
            'Name' => "BC FetchXML",
            'Version' => "1.1.0",
            'Copyright' => "Copyright (C) 2008 - 2009 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Brookins Consulting",
            'License' => "GNU General Public License v2.0 (or later)"
        );
    }
}
?>