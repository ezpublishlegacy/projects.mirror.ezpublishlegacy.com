<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/bcfetchxml/autoloads/bcfetchxmloperator.php',
                                    'class' => 'BCFetchXmlOperator',
                                    'operator_names' => array( 'fetchxml' ) );
?>