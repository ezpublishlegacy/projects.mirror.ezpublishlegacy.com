<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=bcfetchxml

*/ ?>
