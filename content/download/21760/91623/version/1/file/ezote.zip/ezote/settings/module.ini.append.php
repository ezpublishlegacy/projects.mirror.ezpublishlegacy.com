<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezote
ModuleList[]=ezote
*/
?>