<?php

class eZOnlineTemplateEditorInfo {

    static function info(){

        return array( 	
            'Name'      => 'eZ Online Template Editor',
            'Version'   => '0.1-dev',
            'Author'    => '<a href="http://www.martin-damien.fr">MARTIN Damien</a>',
            'Copyright' => 'Copyright © MARTIN Damien',
            'License' 	=> 'GNU General Public License v2.0',
        );

    }

}

?>
