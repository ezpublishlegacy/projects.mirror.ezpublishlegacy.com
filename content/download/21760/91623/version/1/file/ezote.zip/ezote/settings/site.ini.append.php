<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezote

*/?>