<?php

    $Module = array('name' => 'ezote');

    $ViewList = array();

    $FunctionList = array();
    $FunctionList["all"] = array();

?>