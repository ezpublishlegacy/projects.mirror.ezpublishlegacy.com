<?php /* #?ini charset="utf-8"?

[templateedit]
Source=visual/templateedit.tpl
MatchFile=templateedit.tpl
Subdir=templates

*/ ?>