/*
* last update: 2009-11-28
* MARTIN Damien <le.pere.porcher@gmail.com>
*/

editAreaLoader.load_syntax["tpl"] = {
	'COMMENT_SINGLE' : {1 : '//'} // this one is for javascript because it could be usefull too
	,'COMMENT_MULTI' : {'{*' : '*}', '<!--' : '-->'}
	,'QUOTEMARKS' : {1: "'", 2: '"'}
	,'KEYWORD_CASE_SENSITIVE' : false
	,'KEYWORDS' : {
		'words': [
			'ezdesign', 'ezimage', 'ezurl', 'ezroot', 'ezini'
			, 'not', 'true', 'false', 'null'
			, 'fetch'
			, 'append', 'concat', 'array_sum', 'begins_with', 'compare', 'contains', 'ends_with', 'explode', 'extract', 'extract_left', 'extract_right', 'implode', 'insert', 'merge', 'prepend', 'remove', 'repeat', 'reverse', 'unique', 'currentdate', 'ezhttp', 'ezhttp_hasvariable', 'ezmodule', 'ezpreference', 'ezsys', 'module_params', 'datetime', 'si', 'image', 'imagefile', 'texttoimage'
			, 'and', 'choose', 'cond', 'first_set', 'or'
			, 'abs', 'ceil', 'dec', 'div', 'floor', 'inc', 'max', 'min', 'mod', 'mul', 'rand', 'round', 'sub', 'sum'		
			, 'action_icon', 'attribute', 'classgroup_icon', 'class_icon', 'content_structure_tree', 'ezpackage', 'flag_icon', 'gettime', 'icon_info', 'makedate', 'maketime', 'mimetype_icon', 'month_overview', 'pdf', 'roman', 'topmenu', 'treemenu'
			, 'autolink', 'break', 'chr', 'concat', 'count_chars', 'count_words', 'crc32', 'downcase', 'indent', 'md5', 'nl2br', 'ord', 'pad', 'rot13', 'shorten', 'simpletags', 'simplify', 'trim', 'upcase', 'upfirst', 'upword', 'wash', 'wordtoimage', 'wrap'
			, 'exturl', 'count', 'float', 'get_class', 'get_type', 'int', 'is_array', 'is_boolean', 'is_class', 'is_float', 'is_integer', 'is_null', 'is_numeric', 'is_object', 'is_set', 'is_string', 'is_unset'
			, 'i18n', 'i10n'
			, 'debug-accumulator', 'debug-timing-point', 'debug-trace'
			, 'cache-block', 'fetch_alias', 'include', 'ldelim', 'rdelim', 'run-once'
			, 'append-block', 'def', 'default', 'let', 'sequence', 'set-block', 'set', 'undef'
			, 'attribute_edit_gui', 'attribute_pdf_gui', 'attribute_result_gui', 'attribute_view_gui', 'class_attribute_edit_gui', 'class_attribute_view_gui', 'collaboration_icon', 'collaboration_participation_view', 'collaboration_simple_message_view', 'collaboration_view_gui', 'content_pdf_gui', 'content_version_view_gui', 'content_view_gui', 'event_edit_gui', 'node_view_gui', 'related_view_gui', 'shop_account_view_gui', 'tool_bar'
			,'literal', 'section-else', 'section' 
			,'hash', 'array'
			,'if', 'else', 'switch', 'case', 'do', 'for', 'foreach', 'while', 'section-exclude', 'section-include', 'section-else', 'section'
			,'eq', 'ne', 'ge', 'le', 'gt', 'lt', 'as'
			,'class', 'collaboration', 'content', 'layout', 'notification', 'package', 'search', 'section', 'shop', 'url', 'user'
			,'attribute_list', 'latest_list', 'list', 'override_template_list', 'group_tree', 'item_count', 'item_list', 'message_list', 'participant', 'participant_list', 'participant_map', 'tree_count'
			,'access', 'bookmarks', 'calendar', 'can_instanciate_classes', 'can_instanciate_class_list', 'class', 'class_attribute', 'class_attribute_list', 'collected_info_collection', 'collected_info_count', 'collected_info_count_list', 'content_object_attributes', 'country_list', 'draft_count', 'draft_version_list', 'keyword', 'keyword_count', 'list', 'list_count', 'locale', 'locale_list', 'navigation_parts', 'navigation_part', 'node', 'non_translation_list', 'object', 'object_by_attribute', 'object_count_by_user_id', 'pending_count', 'pending_list', 'recent', 'related_objects', 'related_objects_count', 'reverse_related_objects', 'reverse_related_objects_count', 'same_classattribute_node', 'search', 'section_list', 'tipafriend_top_list', 'translation_list', 'trash_count', 'trash_object_list', 'tree', 'tree_count', 'version', 'version_count', 'version_list', 'view_top_list'
			,'sitedesign_list'
			,'digest_handlers', 'digest_items', 'event_content', 'handler_list', 'subscribed_nodes', 'subscribed_nodes_count'
			,'can_create', 'can_edit', 'can_export', 'can_import', 'can_install', 'can_list', 'can_read', 'can_remove', 'dependent_list', 'item', 'list', 'maintainer_role_list', 'repository_list'
			,'list_count', 'object', 'object_list', 'object_list_count', 'roles', 'user_roles'
			,'basket', 'best_sell_list', 'currency', 'currency_list', 'preferred_currency_code', 'product_category', 'product_category_list', 'related_purchase', 'wish_list', 'wish_list_count'
			,'anonymous_count', 'current_user', 'has_access_to', 'is_logged_in', 'logged_in_count', 'logged_in_list', 'logged_in_users', 'member_of', 'user_role'
		]
	}
	,'OPERATORS' :[ '<', '>', '/>' ] // This is not a good use of the OPERATOR tag but it's the only way I found to highlight those characters
	,'DELIMITERS' :[
		'(', ')', '[', ']', '|'
	]
	,'REGEXPS' : {
		'variables' : {
			'search' : '()(\\$\\w+)()'
			,'class' : 'variables'
			,'modifiers' : 'g'
			,'execute' : 'after'
		}
		,'tags' : {
			'search' : '(<)(/?[a-z][^ \r\n\t>]*)([^>]*>)'
			,'class' : 'tags'
			,'modifiers' : 'gi'
			,'execute' : 'before' // before or after
		}
		,'attributes' : {
			'search' : '( |\n|\r|\t)([^ \r\n\t=]+)(=)'
			,'class' : 'attributes'
			,'modifiers' : 'g'
			,'execute' : 'before' // before or after
		}
	}
	,'STYLES' : {
		'COMMENTS': 'color: #ffb400;'
		,'QUOTESMARKS': 'color: #6381F8;'
		,'KEYWORDS' : {
			'words': 'color: #00aa00;'
		}
		,'OPERATORS' : 'color: #c68ac0;'
		,'DELIMITERS' : 'color: #000; font-weight:bold; '
		,'REGEXPS' : {
			'variables' : 'color: #6028a0; font-weight:bold'
			,'attributes': 'color: #eddbdb;'
			,'tags': 'color: #c68ac0;'
		}	
	}		
};
