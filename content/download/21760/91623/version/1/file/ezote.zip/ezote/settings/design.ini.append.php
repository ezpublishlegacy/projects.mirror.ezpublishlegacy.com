<?php /*

[ExtensionSettings]
DesignExtensions[]=ezote

*/ ?>