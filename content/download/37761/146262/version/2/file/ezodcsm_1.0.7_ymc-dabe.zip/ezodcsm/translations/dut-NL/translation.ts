<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezdcsm</name>
    <message>
        <source>Please wait...</source>
        <translation>Even wachten a.u.b...</translation>
    </message>
</context>
</TS>
