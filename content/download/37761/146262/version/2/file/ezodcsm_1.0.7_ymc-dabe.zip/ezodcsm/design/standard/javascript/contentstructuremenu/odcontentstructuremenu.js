//
// Created on: <20-Jul-2005 10:36:29 ymc-dabe>
//
// Copyright (C) 2005 Young Media Concepts GmbH. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// If you wish to use this extension under conditions others than the
// GPL you need to contact Young MediaConcepts firtst (licence@ymc.ch).
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ymc.ch if any conditions of this licencing isn't clear to
// you.
//



/*! \file odcontentstructuremenu.js
*/

/*!
    \brief
    This is a set of functions which helps the original content structure
    menu to get elements of its tree on demand.
*/

/*!
    Global variables needed by the on demand content structure menu
*/

var odcsm_standby_message = '<li class="lastli"><span class="openclose"></span><span class="node-name-normal">&nbsp;&nbsp;&nbsp<b>'+ODtextStrings["PleaseWait"]+'</b></span></li>';
var odcsm_expand_element;
var odcsm_expand_element_parent;
var odcsmRequest = false;


/*!
    Creates a new XML-http-request
*/
function newOdcsmRequest()
{
    var established = false;
    var temporary_counter=0;
    
    
    //First the right way...
    try
    {
        odcsmRequest = new XMLHttpRequest();
        established = true;
    }
    catch (e)
    {
        //...then the MS way
        if ( navigator.appName == "Microsoft Internet Explorer" )
        {
            var IE_XMLHTTP_VERSIONS = new Array( 'MSXML2.XMLHTTP',
                                                 'MSXML2.XMLHTTP.6.0',
                                                 'MSXML2.XMLHTTP.5.0',
                                                 'MSXML2.XMLHTTP.4.0',
                                                 'MSXML2.XMLHTTP.3.0',
                                                 'Microsoft.XMLHTTP');
            var success = false;
            
            while ( !established && temporary_counter < IE_XMLHTTP_VERSIONS.length )
            {
                try
                {
                    odcsmRequest = new ActiveXObject(IE_XMLHTTP_VERSIONS[temporary_counter]);
                    established = true;
                }
                catch (e)
                {
                    //just in case...
                    established = false;
                }
                temporary_counter++;
            }
        }
        else
        {
            //just in case...
            established = false;
        }
    }
    
    if ( !established )
    {
        //The XMLHTTP-request couldn't be initialised.
        odcsmRequest = false;
        return;
    }
}


/*!
    Check the state of the XML-http-request
*/
function checkOdcsmRequest(odcsmRequestCheck)
{
    if ( odcsmRequestCheck.readyState != 4 && odcsmRequestCheck.readyState != 0 )
        return true;
    else
        return false;
}


/*!
    Handles the response of the XML-http-request
*/
function handleOdcsmRequest()
{
    if ( odcsmRequest.readyState == 4 )
    {
        odcsm_expand_element.innerHTML=odcsmRequest.responseText;
        ezcst_foldUnfoldSubtree( odcsm_expand_element_parent, false, true, true, true, true );
    }
}


/*!
    Handles opening a node of the tree menu
*/
function ezodcst_onFoldClicked( node, url )
{
    var check_node_id = node.getAttribute( "id" );
    var check_node = document.getElementById(check_node_id);
    
    var foldUnfoldAllowed = true;
    
    for ( var i = 0; i < check_node.childNodes.length; ++i )
    {
        if (check_node.childNodes[i].nodeName == "UL" )
        {
            var check_child = check_node.childNodes[i];
            if (check_child.childNodes.length <= 1 )
            {
                if (!odcsmRequest)
                {
                    odcsm_expand_element = check_child;
                    odcsm_expand_element_parent = check_node;
                    
                    odcsm_expand_element.innerHTML = odcsm_standby_message;
                    ezcst_foldUnfoldSubtree( odcsm_expand_element_parent, false, true, false, false, true );
                    ezcst_foldUnfold( node, true, false, false, false );
                    
                    url = url.replace(/odcsm/, "content");
                    url = url.replace(/expand/, "view");
                    url = url.replace(/navigation/, "full");
                    window.location.href = url+'/'+check_node_id.replace(/n/, "");
                    return;
                }
                
                if ( !checkOdcsmRequest(odcsmRequest) )
                {
                    odcsm_expand_element = check_child;
                    odcsm_expand_element_parent = check_node;
                    
                    odcsm_expand_element.innerHTML = odcsm_standby_message;
                    ezcst_foldUnfoldSubtree( odcsm_expand_element_parent, false, true, false, false, true );
                    foldUnfoldAllowed=true;
                    
                    odcsmRequest.open("GET",url+'/'+check_node_id.replace(/n/, ""),true);
                    odcsmRequest.onreadystatechange = handleOdcsmRequest;
                    odcsmRequest.send(null);
                }
                else
                {
                    foldUnfoldAllowed=false;
                }
            }
        }
    }
    
    if ( foldUnfoldAllowed )
    {
        ezcst_foldUnfold( node, true, false, false, false );
    }
}


/*!
    Now initialise the XML-http-request object
*/
newOdcsmRequest();

