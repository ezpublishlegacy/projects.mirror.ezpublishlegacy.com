<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezdcsm</name>
    <message>
        <source>Please wait...</source>
        <translation>Merci de patienter...</translation>
    </message>
</context>
</TS>
