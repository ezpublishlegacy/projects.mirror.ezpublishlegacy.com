<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezdcsm</name>
    <message>
        <source>Please wait...</source>
        <translation>Vent venligst...</translation>
    </message>
</context>
</TS>
