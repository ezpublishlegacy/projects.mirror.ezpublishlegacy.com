<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezdcsm</name>
    <message>
        <source>Please wait...</source>
        <translation>Por favor espere un momento...</translation>
    </message>
</context>
</TS>
