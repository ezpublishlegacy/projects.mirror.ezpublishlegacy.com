<?php
//
// Created on: <20-Jul-2005 12:22:31 ymc-dabe>
//
// Copyright (C) 2005 Young Media Concepts GmbH. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// If you wish to use this extension under conditions others than the
// GPL you need to contact Young MediaConcepts firtst (licence@ymc.ch).
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ymc.ch if any conditions of this licencing isn't clear to
// you.
//


include_once( 'kernel/common/template.php' );

if ( isset( $Params['NodeID'] ) )
{
     $nodeID = $Params['NodeID'];
}
else
{
    echo "An error occured. Please reload this page!";
    eZExecution::cleanExit();
}

$tpl =& templateInit();

if ( isset( $Params['UIcontext'] ) )
{
     $UIcontext = $Params['UIcontext'];
     $tpl->setVariable( 'ui_context', $UIcontext );
     $Result['ui_context'] = $UIcontext;
     if ( $UIcontext == "browse" )
     {
         $tpl->setVariable( 'csm_menu_item_click_action', '/content/browse' );
     }
}

$tpl->setVariable( 'nodeID', $nodeID );

echo $tpl->fetch( 'design:contentstructuremenu/expand_dynamic_content_structure.tpl' );
eZExecution::cleanExit();

?>
