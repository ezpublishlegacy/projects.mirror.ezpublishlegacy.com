#!/bin/sh

liste=$(find ./ | grep \.svn)


for entfernen in $liste
do

	einfachername=$(basename $entfernen)
	
	if [ "$einfachername" = ".svn" ]; then
		rm -rf $entfernen
		echo "entfernt: $entfernen"
	fi
done


