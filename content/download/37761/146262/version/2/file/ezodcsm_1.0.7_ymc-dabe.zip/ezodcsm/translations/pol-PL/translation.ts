<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezdcsm</name>
    <message>
        <source>Please wait...</source>
        <translation>Proszę czekać...</translation>
    </message>
</context>
</TS>
