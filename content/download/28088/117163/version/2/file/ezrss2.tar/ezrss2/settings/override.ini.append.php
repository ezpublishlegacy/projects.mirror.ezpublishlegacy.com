<?php /* #?ini charset="utf-8"?

#[edit_export]
#Source=rss/edit_export.tpl
#MatchFile=rss/edit_export.tpl
#Subdir=templates

*/ ?>
