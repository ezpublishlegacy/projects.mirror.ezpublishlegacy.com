<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezsphinx

*/ ?>
