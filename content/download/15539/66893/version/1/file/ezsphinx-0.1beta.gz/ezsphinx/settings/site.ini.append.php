<?php /*

[SearchSettings]
# eZ Sphinx overload search settings.
ExtensionDirectories[]=ezsphinx
SearchEngine=ezsphinx
SearchViewHandling=template

# Empty search is allowed by default for eZ Sphinx, since it does not
# use extra resources compared to regular search.
AllowEmptySearch=enabled

*/ ?>
