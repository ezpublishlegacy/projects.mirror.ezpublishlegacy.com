<!DOCTYPE TS><TS>
<context>
    <name>extension/authorcontact</name>
    <message>
        <source>Missing or invalid input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author contact form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send a message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you. Your message was sent successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can use this form and contact article author. Ask a question, send your opinions, suggestions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make sure that all fileds marked as required are filled up.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid address syntax.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message was not sent.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
