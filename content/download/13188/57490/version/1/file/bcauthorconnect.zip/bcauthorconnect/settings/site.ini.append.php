<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=bcauthorconnect

[RoleSettings]
PolicyOmitList[]=authorconnect
# PolicyOmitList[]=authorcontact
# PolicyOmitList[]=ownercontact

# [TemplateSettings]
# ExtensionAutoloadPath[]=bceventfilter

*/ ?>