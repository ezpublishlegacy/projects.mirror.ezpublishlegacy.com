<?PHP 
 
//
// Definition of eZJupload write process class
//
// Created on: 2005-20-04 
//
// Version: 0.7
// Created by: Ralph Ekekihl, ralph@contactivity.com
// Contactivity bv, Leiden the Netherlands
// info@contactivity.com, http://www.contactivity.com
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//


/*! 
 \file write.php 
  The file write.php is called from the Java Applet to write the uploaded files 
  it create an empty object, that does not exists in the node tree, looks for ezbinaryattribute in it,
  writes ezbinaryfile to the object,
  creates a new object for every file, then uses ezjuploadtype (which is ezobjectrelationbrowse) to make a relation
  
*/

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( "lib/ezutils/classes/ezsys.php" );
include_once( 'lib/ezutils/classes/ezfunctionhandler.php' );
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );
include_once( "kernel/classes/datatypes/ezbinaryfile/ezbinaryfile.php" );
include_once( "kernel/common/template.php" );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );
include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentobjectattribute.php' );
include_once( "lib/ezutils/classes/ezhttpfile.php" );
include_once( 'lib/ezutils/classes/ezmimetype.php' );
include_once( 'lib/ezfile/classes/ezfile.php' );
include_once( 'lib/ezutils/classes/ezoperationhandler.php' );
include_once( 'kernel/classes/datatypes/ezobjectrelationlist/ezobjectrelationlisttype.php' );

                                                               
$attributeID =& $Params["attributeid"];
$attributeVersion =& $Params["version"];
$sectionID =& $Params["sectionid"]; //Get section ID from the contentobject and use it on the new objects

// Get the attribute from the object where ezjupload is
$mainAttribute =& eZContentObjectAttribute::fetch($attributeID, $attributeVersion, true);

$tpl =& templateInit();
$Module->setTitle( 'Upload Process' );


//  take uploaded files from the Java Applet in global $_FILES variable and put in fileArr array

$fileArr = array();
	     
	foreach($_FILES as $uf)
	{
		$file =& $GLOBALS["eZHTTPFile-$uf"];
		if ( get_class( $file ) != "ezhttpfile" )
		{
		    $file = null;
	
		    if ( isset( $uf ) and
			 $uf["name"] != "" )
		    {
		      
			$mimeType = eZMimeType::findByURL( $uf["name"] );
			$uf['type'] = $mimeType['name'];
			$fileArr[] = new eZHTTPFile( $uf['name'], $uf );
		    }
		    else{
			eZDebug::writeError( "Unknown file for post variable: $uf",
					     "eZHTTPFile" );
		        echo "Unknown file".$uf."\n";
		    }
		}
	}
	     
	
//  Main loop
	 foreach($fileArr as $http_array)
	
	 {   
		
		if ( get_class( $http_array ) == "ezhttpfile" )
		{
			//get class identifier from ini file, if not found, default to file
			$ini =& eZINI::instance("module.ini");
			$classIdentifier = $ini->variable( 'ClassSettings', 'ClassIdentifier' );
			if ($classIdentifier == null)
			$classIdentifier = 'file';
			
			//create a new class to store the content
			$class= eZContentClass::fetchByIdentifier($classIdentifier);
			unset( $contentObject );
			$userID = eZUser::currentUserID();
			$contentObject =& $class->instantiate( $userID, $sectionID);
			$contentObject->sync();
			
			// Commented out, dont create node, object should not be in the  content tree
			/*
			$nodeAssignment =& eZNodeAssignment::create( array( 'contentobject_id' => $contentObject->attribute( 'id' ),
										'contentobject_version' => $contentObject->attribute( 'current_version' ),
										'parent_node' => $contentObject->attribute( 'main_node_id' ),
										'sort_field' => 2,
										'sort_order' => 0,
										'is_main' => 1 ) );		
			 $nodeAssignment->store();
			 */
			 
			
	    
			$version =& $contentObject->version( 1 );
			$contentObjectAttributes =& $version->contentObjectAttributes();
			$contentObjectID =& $contentObject->attribute( 'id' );
			
			//check for ezbinaryfileattribute in object
						
			     foreach($contentObjectAttributes as $attribute)
			     {
			     if ( $attribute->attribute( 'data_type_string' ) == "ezbinaryfile" )
				      $contentObjectAttribute = $attribute;
			     }
			     if ( $contentObjectAttribute == null ){
				      
			       eZDebug::writeError( "Failed to find a ezbinaryfileattribute in the ".$classIdentifier." class, please add it");
			       echo "Failed to find a ezbinaryfileattribute in the ".$classIdentifier." class, please add it \n";
			       exit;
			     }
			
			    //set objectname to filename and store object 
			    
			$contentObject->setAttribute( 'name', basename($http_array->attribute( "original_filename" )) );
			$contentObject->store();
		
		       //get ezobjectrelationlist XML data  
		       $content = $mainAttribute->content();
			
		       //check relationlist
			$priority = 0;
			for ( $i = 0; $i < count( $content['relation_list'] ); ++$i )
			{
			    if ( $content['relation_list'][$i]['priority'] > $priority )
				$priority = $content['relation_list'][$i]['priority'];
			}
	
			//append new XML relation
			  $relationItem = eZObjectRelationListType::appendObject( $contentObjectID,
							  $priority + 1,
							  $contentObjectAttribute);
							  
						  
			$content['relation_list'][] = $relationItem;						  
				  
			$mainAttribute->setContent( $content );
	       
			$mainAttribute->store();
	
			$contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );
			
			$binaryFile = saveBinary($http_array, $contentObjectAttribute, $contentObjectAttributeID, 1);
			$contentObjectAttribute->store();
		 
			$binaryFile = null;
		}else{		
		eZDebug::writeError( $http_array." is not a eZHTTPFile" );
		}
	 }
	   
	 function saveBinary($http_array, $contentObjectAttribute, $contentObjectAttributeID, $version = 1) {
		 
	    $contentObjectAttribute->setContent( $http_array);
	    $mimeData =& eZMimeType::findByFileContents( $http_array->attribute( "original_filename" ) );
            $mime = $mimeData['name'];

            if ( $mime == '' )
            {
                $mime = $http_array->attribute( "mime_type" );
            }
            $extension = preg_replace('/.*\.(.+?)$/', '\\1', $http_array->attribute( "original_filename" ) );
            $http_array->setMimeType( $mime );
            if ( !$http_array->store( "original", $extension ) )
            {
                eZDebug::writeError( "Failed to store http-file: " . $http_array->attribute( "original_filename" ),
                                     "eZBinaryFileType" );
               echo "upload failed for".basename($http_array->attribute( "original_filename" )."\n");
            }

           $binary =& eZBinaryFile::fetch( $contentObjectAttributeID, $version );
           if ( $binary === null )
	    $binary =& eZBinaryFile::create( $contentObjectAttributeID, $version );
	    
            $orig_dir = $http_array->storageDir( "original" );

            $binary->setAttribute( "contentobject_attribute_id", $contentObjectAttributeID );
            $binary->setAttribute( "version", $version );
            $binary->setAttribute( "filename", basename( $http_array->attribute( "filename" ) ) );
            $binary->setAttribute( "original_filename", $http_array->attribute( "original_filename" ) );
            $binary->setAttribute( "mime_type", $mime );

            $binary->store();
	  
	    $contentObjectAttribute->setContent( $binary );
		// Dont publish, not in content tree
	     //$operationResult = eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $contentObjectID,
              //                                                                  'version' => 1 ) );
	  
	 
	    echo "successful upload for ".basename($http_array->attribute( "original_filename" )."\n");	
	//echo 'post_max_size = ' . ini_get('upload_max_filesize') . "\n";
	 
	 }	   
?>
