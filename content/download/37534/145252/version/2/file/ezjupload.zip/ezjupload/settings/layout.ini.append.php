[ezjupload]
PageLayout=upload_pagelayout.tpl
