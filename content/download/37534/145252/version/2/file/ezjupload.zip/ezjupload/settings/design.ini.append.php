[ExtensionSettings]
DesignExtensions[]=ezjupload