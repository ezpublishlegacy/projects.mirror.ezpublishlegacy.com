[DataTypeSettings]
ExtensionDirectories[]=ezjupload
AvailableDataTypes[]=ezjupload