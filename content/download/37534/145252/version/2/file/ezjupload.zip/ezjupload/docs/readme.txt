eZJupload Multiple Binaryfiles Datatype/Extension
-------------------------------

/*
    eZJupload  datatype/extension for eZ publish 3.4/3.5+
    Developed by Contactivity bv, Leiden the Netherlands
    http://www.contactivity.com, info@contactivity.com
    

    This file may be distributed and/or modified under the terms of the
    GNU General Public License" version 2 as published by the Free
    Software Foundation and appearing in the file LICENSE.GPL included in
    the packaging of this file.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    The "GNU General Public License" (GPL) is available at
    http://www.gnu.org/copyleft/gpl.html.
    
*/


1. Context
----------
The binaryfile datatype of eZ publish only allows the upload of a single file.

We needed a datatype that would allow the upload of multiple files in a single transaction.


2. Features
-----------
With the eZJupload datatype it is possible to upload multiple files in a single transaction, and to add the binary files as hidden objects with a relation the parent object.


3. Example of use
-----------------
The datatype can be used on sites where many files or directories containing files have to be published under a single object.


4. Known bugs, limitations, etc.
-----------------------------
The datatype has the following limitations:
- Datatype is dependent upon functions in the ezbinaryfile and objectrelationlist datatypes;
- After clicking the 'Upload' button in the applet you also have to click the "Send for publishing" button to make the files appear in a list.
- Priority sorting is not supported yet.
- There are no restrictions on the type of files, and the maximum number of files allowed.
- If debug output is turned on, it will display in the status window in the Java applet.

5. Requirements
------------------------------
- Javascript and Java 2 enabled browser (http://www.java.com/)
- A rewrite rule that allows access to /extension/ezjupload/design/applets/wjhk.jupload.jar
- A class in eZ publish that contains an ezbinaryfile attribute. The default class is set to 'file', but this may be changed in the module.ini.append.php file for eZJupload:
  [ClassSettings]
  ClassIdentifier=file


6. Usage
-----------
- Add the datatype 'multiple binary files' to the class in which you want to enable the upload of multiple files.
- After files have been uploaded, you have to click the 'Send for publishing' button to make the files appear in a list.
- To display the list of files in your template, use: {attribute_view_gui attribute=$node.object.data_map.(identifier)}


7. Jupload Java Applet
---------------------------------
To upload multiple files to the server, we used the Java applet Jupload, (http://jupload.sourceforge.net/).
- Jupload has been written by William JinHua Kwong and released under the GPL license.
- The Jupload applet has been modified for eZ publish, with added cookie support, etc. The full source code with comments has been included in the jar file for those curious. 

 How to sign the applet with your own certificate
 -----------------------------------------
 (require Java SDK installed)
 - Generate Private/Public key set.
 key tool -genkey -alias "jupload"
 - List key set.
 keytool -list
 - Sign the Applet with the private key.
 jarsigner wjhk.jupload.jar jupload
 - Verify the jar file have being sign properly.
 jarsigner -verify wjhk.jupload.jar


8. Feedback
--------------------------------
Please send all remarks, comments and suggestions for improvement to info@contactivity.com.


9. Disclaimer
-------------------------
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.


10. Acknowledgements
-------------------------
The development of this datatype was paid for by ARCADIS (http://www.arcadis.nl/).
Thanks to William JinHua Kwong, for his Jupload applet.
Thanks to Patrizio Bekerle, got some good ideas from his Multiple Upload extension.