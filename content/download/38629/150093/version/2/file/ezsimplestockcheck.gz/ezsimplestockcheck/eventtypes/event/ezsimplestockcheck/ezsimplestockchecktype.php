<?php
//
// Definition of ezsimplestockcheck class
//
// Created on: <6-12-2005 10:38:00 fats>
//
// Copyright (C) 2005 Grandmore. All rights reserved.
//
//	http://www.grandmore.com
//	http://www.grandmore.co.uk

/*! \file ezsimplestockchecktype.php
*/

/*!
  \class eZWrappingType ezwrappingtype.php
  \brief The class eZWrappingType does

*/
include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'kernel/classes/ezorderitem.php' );
include_once( "kernel/classes/ezorder.php" );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php" );

define( "EZ_WORKFLOW_TYPE_EZSIMPLESTOCKCHECK_ID", "ezsimplestockcheck" );

class eZSimpleStockCheckType extends eZWorkflowEventType
{
    /*!
     Constructor
    */
    function eZSimpleStockCheckType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_EZSIMPLESTOCKCHECK_ID, ezi18n( 'kernel/workflow/event', "SimpleStockCheck" ) );
    }
    function execute( &$process, &$event )
    {
        $parameters =& $process->attribute( 'parameter_list' );
        $http =& eZHTTPTool::instance();

        eZDebug::writeNotice( $parameters, "parameters" );
        $orderID = $parameters['order_id'];
        $order = eZOrder::fetch( $orderID );
        
        if (empty($orderID) || get_class( $order ) != 'ezorder')
        {
            eZDebug::writeWarning( "Can't proceed without a Order ID.", "SimpleStockCheck" );
            return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
        }

        // Decrement the quantitity field
		$order =& eZOrder::fetch( $orderID );
		$productCollection = $order->productCollection();
		$ordereditems = $productCollection->itemList();
		foreach ($ordereditems as $item)
		{
			$contentObject = $item->contentObject(); 
			$contentObjectVersion =& $contentObject->version($contentObject->attribute( 'current_version' ) );
			$contentObjectAttributes =& $contentObjectVersion->contentObjectAttributes();
			foreach (array_keys($contentObjectAttributes) as $key)
			{
				$contentObjectAttribute =& $contentObjectAttributes[$key];
				$contentClassAttribute =& $contentObjectAttribute->contentClassAttribute();

				// Each attribute has an attribute identifier called 'quantity' that identifies it.
				if ($contentClassAttribute->attribute("identifier") == "quantity")
				{ 
					$contentObjectAttribute->setAttribute("data_int", (($contentObjectAttribute->attribute("value")) - $item->ItemCount));
					$contentObjectAttribute->store();
				}
			}
		}

        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
        
    }
    
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_EZSIMPLESTOCKCHECK_ID, "ezsimplestockchecktype" );

?>
