<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsannotationnet

#[StylesheetSettings]
#BackendCSSFileList[]=gdannotationnet_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdannotationnet.js
*/ ?>