<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsannotationnet
ModuleList[]=groupdocsannotationnet
*/ ?>