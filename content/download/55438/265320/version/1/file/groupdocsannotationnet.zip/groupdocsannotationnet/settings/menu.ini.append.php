<?php /*
[NavigationPart]
Part[groupdocsannotationnetnavigationpart]=GD Annotation .NET
[TopAdminMenu]
Tabs[]=groupdocsannotationnet
[Topmenu_groupdocsannotationnet]
NavigationPartIdentifier=groupdocsannotationnetnavigationpart
Name=Groupdocs Annotation for .NET
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsannotationnet/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>