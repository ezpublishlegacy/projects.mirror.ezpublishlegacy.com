<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsassembly

#[StylesheetSettings]
#BackendCSSFileList[]=gdassembly_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdassembly.js
*/ ?>