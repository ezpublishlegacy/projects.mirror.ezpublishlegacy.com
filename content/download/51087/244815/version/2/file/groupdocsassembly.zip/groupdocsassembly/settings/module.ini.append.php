<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsassembly
ModuleList[]=groupdocsassembly
*/ ?>