<?php
class NivoSlider
{
    static function info()
    {
        return array(
'Name' => 'NivoSlider',
'Version' => '1.0',
'Copyright' => 'Copyright (C) 2009-'. date('Y') . ' Stefano Gattuso',
'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
