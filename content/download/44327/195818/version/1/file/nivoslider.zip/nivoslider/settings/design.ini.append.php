<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=nivoslider

[JavaScriptSettings]
FrontendJavaScriptList[]=jquery-1.6.4.min.js
FrontendJavaScriptList[]=jquery.nivo.slider.pack.js


[StylesheetSettings]
CSSFileList[]=nivo-slider.css
FrontendCSSFileList[]=nivo-slider.css
*/
?>
