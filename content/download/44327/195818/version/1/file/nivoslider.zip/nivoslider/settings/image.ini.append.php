<?php /* #?ini charset="utf8"?

[AliasSettings]
AliasList[]=nivoslider_embed
AliasList[]=nivoslider_full
AliasList[]=nivoslider_block_item

[nivoslider_embed]
Reference=
Filters[]
Filters[]=geometry/scaleexact=300;300

[nivoslider_full]
Reference=
Filters[]
Filters[]=geometry/scaleexact=448;448

[nivoslider_block_item]
Reference=
Filters[]
Filters[]=geometry/scaleexact=440;440
*/ ?>