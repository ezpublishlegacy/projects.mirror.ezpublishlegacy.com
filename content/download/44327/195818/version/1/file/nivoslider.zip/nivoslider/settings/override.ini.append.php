<?php /* #?ini charset="utf-8"?

[embed_nivoslider]
Source=content/view/embed.tpl
MatchFile=embed/nivoslider.tpl
Subdir=templates
Match[class_identifier]=nivoslider

[full_nivoslider]
Source=node/view/full.tpl
MatchFile=full/nivoslider.tpl
Subdir=templates
Match[class_identifier]=nivoslider

[block_item_nivoslider]
Source=node/view/block_item.tpl
MatchFile=block_item/nivoslider.tpl
Subdir=templates
Match[class_identifier]=nivoslider

*/ ?>