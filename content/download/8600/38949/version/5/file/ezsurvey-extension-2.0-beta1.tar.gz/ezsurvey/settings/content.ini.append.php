<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezsurvey

[CustomTagSettings]
AvailableCustomTags[]=survey

[DataTypeSettings]
AvailableDataTypes[]=ezsurvey

*/ ?>