<?php
#
# $Id: design.ini.append.php 2 2009-10-25 21:48:12Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.1/extension/autostatus/settings/design.ini.append.php $
#

[ExtensionSettings]
DesignExtensions[]=autostatus


?>
