<?php /*
#
# $Id: autostatus.ini.append.php 8 2009-10-27 19:24:15Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.1/extension/autostatus/settings/autostatus.ini.append.php $
#

[AutoStatusSettings]
# array of datatypes that can be used to store
# a status message
StatusDatatype[]
StatusDatatype[]=ezstring
StatusDatatype[]=eztext

# available social networks
SocialNetworks[]
SocialNetworks[]=twitter
SocialNetworks[]=identica

*/ ?>
