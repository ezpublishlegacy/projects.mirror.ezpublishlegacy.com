<?php /*
#
# $Id: module.ini.append.php 2 2009-10-25 21:48:12Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.1/extension/autostatus/settings/module.ini.append.php $
#

[ModuleSettings]
ExtensionRepositories[]=autostatus
ModuleList[]=autostatus

*/ ?>
