<?php
#
# $Id: site.ini.append.php 7 2009-10-26 22:29:11Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/tags/autostatus_0.1/extension/autostatus/settings/site.ini.append.php $
#

[RegionalSettings]
TranslationExtensions[]=autostatus

?>
