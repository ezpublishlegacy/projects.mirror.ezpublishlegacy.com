<?php

/**

    PDF catalogue extension for eZ Publish - Class abPDFCatalogue

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

class abPDFCatalogue
{

    const INTRODUCTION_FILE_ATTRIBUTE_NAME = 'introduction',
              APPENDIX_FILE_ATTRIBUTE_NAME = 'appendix',
           TARGET_FILE_NAME_ATTRIBUTE_NAME = 'targetfilename',
                 TOC_MARGINS_ATTRIBUE_NAME = 'toc_margins',
                  TOC_TITLE_ATTRIBUTE_NAME = 'toc_title',
             TOC_BACKGROUND_ATTRIBUTE_NAME = 'toc_background',
                PDF_SUBJECT_ATTRIBUTE_NAME = 'pdf_subject',
                  PDF_TITLE_ATTRIBUTE_NAME = 'pdf_title',
                 PDF_AUTHOR_ATTRIBUTE_NAME = 'pdf_author',
               PDF_KEYWORDS_ATTRIBUTE_NAME = 'pdf_keywords',
            PDF_COMPRESSION_ATTRIBUTE_NAME = 'pdf_compression',
                  DEFAULT_TARGET_FILE_NAME = 'catalogue.pdf',
          PDF_DOCUMENT_FILE_ATTRIBUTE_NAME = 'pdf',
            FILE_CLASS_FILE_ATTRIBUTE_NAME = 'file',
                         CACHE_SUBDIR_NAME = 'pdfcatalogue',
                      TOC_MARGIN_SEPARATOR = ';';

    private static $instance = null;

    private       $liveMode = false,
                      $mode = 'cache',
              $documentList = array(),
               $pdfMetaData = array(),
                       $pdf = null,
            $targetFileName = '',
                 $startTime = 0,
               $resultArray = array();

    public static function instance()
    {
        if ( self::$instance === null )
        {
            self::$instance = new abPDFCatalogue();
        }
        return self::$instance;
    }

    public static function getRelationTargetFromAttribute( $attributeObject, $classIdentifier,
                                                           $asObject = false, $asList = false
                                                         )
    {
        $result = false;
        if ( $asList )
        {
            $result = array();
        }
        if ( $attributeObject->hasContent() )
        {
            $attributeContent = $attributeObject->attribute( 'content' );
            if ( array_key_exists( 'relation_list', $attributeContent ) && is_array( $attributeContent['relation_list'] ) )
            {
                foreach ( $attributeContent['relation_list'] as $relatedObjectInformation )
                {
                    if ( array_key_exists( 'contentclass_identifier', $relatedObjectInformation ) &&
                         $relatedObjectInformation['contentclass_identifier'] == $classIdentifier
                       )
                    {
                        if ( array_key_exists( 'contentobject_id', $relatedObjectInformation ) )
                        {
                            if ( $asObject )
                            {
                                $targetObject = eZContentObject::fetch( $relatedObjectInformation['contentobject_id'] );
                                if ( is_object( $targetObject ) )
                                {
                                    if ( $asList )
                                    {
                                        $result[] = $targetObject;
                                    }
                                    else
                                    {
                                        $result = $targetObject;
                                    }
                                    break;
                                }
                                else
                                {
                                    eZDebug::writeWarning( 'Failed to fetch target object with ID ' . $relatedObjectInformation['contentobject_id'], __METHOD__ );
                                }
                            }
                            else
                            {
                                if ( $asList )
                                {
                                    $result[] = (int)$relatedObjectInformation['contentobject_id'];
                                }
                                else
                                {
                                    $result = (int)$relatedObjectInformation['contentobject_id'];
                                }
                                break;
                            }
                        }
                        else
                        {
                            eZDebug::writeWarning( 'The appendix attribute of the PDF Catalogue content object has no content object id in the relation list', __METHOD__ );
                        }
                    }
                    else
                    {
                        eZDebug::writeDebug( 'Skipping related object of class ' . $relatedObjectInformation['contentclass_identifier'], __METHOD__ );
                        continue;
                    }
                }
            }
            else
            {
                eZDebug::writeWarning( 'The appendix attribute of the PDF Catalogue content object has no relation list', __METHOD__ );
            }
        }
        return $result;
    }

    public function clearCache()
    {
        $cacheDirectory = $this->cacheDirectory();

        if ( $cacheDirectory !== false )
        {
            eZDebug::writeDebug( 'Clearing cache in ' . $cacheDirectory, __METHOD__ );
            eZDir::recursiveDelete( $cacheDirectory );
            return true;
        }
        else
        {
            eZDebug::writeWarning( 'Failed to remove cache directory.', __METHOD__ );
        }
        return false;
    }

    private function fetchObjectIDFromRelationAttribute( $attributeObject )
    {
        $pdfDocumentObject = abPDFCatalogue::getRelationTargetFromAttribute( $attributeObject, 'ab_pdf_catalogue_document', true );
        if ( is_object( $pdfDocumentObject ) )
        {
            $dataMap = $pdfDocumentObject->attribute( 'data_map' );
            if ( array_key_exists( 'pdf_file', $dataMap ) )
            {
                return abPDFCatalogue::getRelationTargetFromAttribute( $dataMap['pdf_file'], 'file' );
            }
        }
        return false;
    }

    private function checkCacheDir( $directoryName )
    {
        if ( !file_exists( $directoryName ) )
        {
            eZDebug::writeDebug( 'Creating cache directory for PDF catalogue files: ' . $directoryName, __METHOD__ );
            eZDir::mkdir( $directoryName, false, true );
        }
        if ( file_exists( $directoryName ) )
        {
            if ( is_dir( $directoryName ) )
            {
                if ( is_writable( $directoryName ) )
                {
                    return true;
                }
                else
                {
                    eZDebug::writeDebug( 'Directoy ' . $directoryName . ' is not writeable.', __METHOD__ );
                }
            }
            else
            {
                eZDebug::writeDebug( 'Directoy ' . $directoryName . ' is not a directory.', __METHOD__ );
            }
        }
        else
        {
            eZDebug::writeDebug( 'Directoy ' . $directoryName . ' does not exist.', __METHOD__ );
        }
        return false;
    }

    private function cacheDirectory()
    {
        $cacheDir           = false;
        $personalCatalogIni = eZINI::instance( 'personalcatalog.ini' );
        $separator          = eZDir::separator( eZDir::SEPARATOR_LOCAL );
        if ( $personalCatalogIni->hasVariable( 'CommonSettings', 'PDFCacheDirectory' ) )
        {
            $cacheDir = eZSys::cacheDirectory() . $separator . trim( $personalCatalogIni->variable( 'CommonSettings', 'PDFCacheDirectory' ) ) . $separator;
            eZDebug::writeDebug( 'Checking cache directory ' . $cacheDir, __METHOD__  );
            if ( !$this->checkCacheDir( $cacheDir ) )
            {
                $cacheDir = false;
            }
        }
        else
        {
            eZDebug::writeDebug( 'No custom cache directory configured. Using default.', __METHOD__  );
        }
        if ( $cacheDir === false )
        {
            $cacheDir = 'var' . $separator . 'cache' . $separator . abPDFCatalogue::CACHE_SUBDIR_NAME . $separator;
            eZDebug::writeDebug( 'Checking cache directory ' . $cacheDir, __METHOD__  );
            if ( !$this->checkCacheDir( $cacheDir ) )
            {
                $cacheDir = false;
            }
        }
        if ( $cacheDir === false )
        {
            eZDebug::writeWarning( 'Failed to create cache directory for PDF catalogue file.', __METHOD__  );
        }
        return $cacheDir;
    }

    private function cacheFilename( $hash )
    {
        $cacheDir = $this->cacheDirectory();
        if ( $cacheDir !== false )
        {
            return $cacheDir . $hash . ".pdf";
        }
        return false;
    }

    public function generatePDF( $jsonData, $mode, $filename )
    {
        $this->startTime   = microtime( true );
        $this->resultArray = array( 'success' => false );

        if ( $mode != 'cache' && $mode != 'live' )
        {
            $this->resultArray[ 'error' ] = 'Invalid mode: ' . $mode;
            return $this->exitJSON();
        }

        $this->mode     = $mode;
        $this->liveMode = ( strtolower( $mode ) == 'live' ) ? true : false;

        if ( $jsonData == '' )
        {
            $this->resultArray[ 'error' ] = 'No JSON input data';
            return $this->exitJSON();
        }

        $dataObject          = json_decode( $jsonData, true );
        $contentObjectIdList = array_key_exists( 'list',  $dataObject ) ? $dataObject[ 'list' ]  : array();
        $catalogueID         = array_key_exists( 'catid', $dataObject ) ? $dataObject[ 'catid' ] : false;

        if ( count( $contentObjectIdList ) == 0 )
        {
            $this->resultArray[ 'error' ] = 'No files selected';
            return $this->exitJSON();
        }

        if ( !$catalogueID )
        {
            $this->resultArray[ 'error' ] = 'No catalogue ID set';
            return $this->exitJSON();
        }

        $catalogueContentObject = eZContentObject::fetch( (int)$catalogueID );

        if ( !$catalogueContentObject instanceof eZContentObject )
        {
            $this->resultArray[ 'error' ] = 'Invalid Catalog ID: ' . $catalogueID;
            return $this->exitJSON();
        }

        $catalogueDataMap = $catalogueContentObject->dataMap();

        $this->targetFileName = abPDFCatalogue::DEFAULT_TARGET_FILE_NAME;

        $filename = trim( $filename );
        if ( $filename != '' )
        {
            $this->targetFileName = $filename;
        }

        $this->documentList = array();
        $this->pdfMetaData  = array();

        $tocMargins = array();
        if ( array_key_exists( self::TOC_MARGINS_ATTRIBUE_NAME, $catalogueDataMap ) &&
             is_object( $catalogueDataMap[self::TOC_MARGINS_ATTRIBUE_NAME] )
           )
        {
            $explodedString = explode( self::TOC_MARGIN_SEPARATOR,
                                       $catalogueDataMap[self::TOC_MARGINS_ATTRIBUE_NAME]->attribute( 'content' )
                                     );
            if ( count( $explodedString ) == 3 )
            {
                $tocMargins = $explodedString;
            }
        }

        $pdfCompression = false;
        if ( array_key_exists( self::PDF_COMPRESSION_ATTRIBUTE_NAME, $catalogueDataMap ) &&
             is_object( $catalogueDataMap[self::PDF_COMPRESSION_ATTRIBUTE_NAME] )
           )
        {
            if ( $catalogueDataMap[self::PDF_COMPRESSION_ATTRIBUTE_NAME]->attribute( 'content' ) == '1' )
            {
                $pdfCompression = true;
            }
        }

        $this->pdf = new abPDFCatalogueAssembler();

        $this->pdf->setTableOfContentsMargins( $tocMargins );
        $this->pdf->usePDFCompression( $pdfCompression );
        $this->preparePDFMetaData( $catalogueDataMap );
        $this->prepareDocumentList( $catalogueDataMap, $contentObjectIdList );
        $this->mergePDFFiles();
    }

    private function preparePDFMetaData( $dataMap )
    {
        $attributeNameList = array(    'toc_title' => abPDFCatalogue::TOC_TITLE_ATTRIBUTE_NAME,
                                     'pdf_subject' => abPDFCatalogue::PDF_SUBJECT_ATTRIBUTE_NAME,
                                       'pdf_title' => abPDFCatalogue::PDF_TITLE_ATTRIBUTE_NAME,
                                      'pdf_author' => abPDFCatalogue::PDF_AUTHOR_ATTRIBUTE_NAME,
                                    'pdf_keywords' => abPDFCatalogue::PDF_KEYWORDS_ATTRIBUTE_NAME
                                  );
        foreach ( $attributeNameList as $fieldName => $attributeName )
        {
            $this->pdfMetaData[$fieldName] = false;
            if ( array_key_exists( $attributeName, $dataMap ) && is_object( $dataMap[$attributeName] ) )
            {
                $attributeObject = $dataMap[$attributeName];
                if ( $attributeObject->hasContent() )
                {
                    $content = trim( $attributeObject->attribute( 'content' ) );
                    if ( $content != '' )
                    {
                        $this->pdfMetaData[$fieldName] = $content;
                    }
                    else
                    {
                        eZDebug::writeDebug( 'Empty attribute in PDF catalogue object: ' . $attributeName, __METHOD__ );
                    }
                }
                else
                {
                    eZDebug::writeDebug( 'No content in attribute of PDF catalogue object: ' . $attributeName, __METHOD__ );
                }
            }
            else
            {
                eZDebug::writeDebug( 'No such attribute in PDF catalogue object: ' . $attributeName, __METHOD__ );
            }
        }
        $this->pdf->setMetaData( $this->pdfMetaData );
    }

    private function prepareDocumentList( $dataMap, $contentObjectIdList )
    {
        $requiredAttributeNames = array( abPDFCatalogue::INTRODUCTION_FILE_ATTRIBUTE_NAME,
                                         abPDFCatalogue::APPENDIX_FILE_ATTRIBUTE_NAME,
                                         abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME
                                       );

        foreach ( $requiredAttributeNames as $requiredAttributeName )
        {
            if ( !array_key_exists( $requiredAttributeName, $dataMap ) ||
                 !is_object( $dataMap[$requiredAttributeName] )
               )
            {
                $this->resultArray[ 'error' ] = 'No such attribute in catalogue content object: ' . $requiredAttributeName;
                return $this->exitJSON();
            }
        }

        if ( $dataMap[abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME]->hasContent() )
        {
            $this->targetFileName = $dataMap[abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME]->attribute( 'content' );
        }

        $contentObjectId = $this->fetchObjectIDFromRelationAttribute( $dataMap[abPDFCatalogue::INTRODUCTION_FILE_ATTRIBUTE_NAME] );
        if ( is_int( $contentObjectId ) )
        {
            $this->documentList[] = array( 'type'  => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'id'    => $contentObjectId,
                                           'toc'   => false
                                         );
        }

        $tocBackgroundFile = false;
        if ( array_key_exists( self::TOC_BACKGROUND_ATTRIBUTE_NAME, $dataMap ) &&
             is_object( $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME] )
           )
        {
            if ( $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME]->hasContent() )
            {
                $fileObject        = $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME]->attribute( 'content' );
                $tocBackgroundFile = eZSys::siteDir() . $fileObject->filePath();
                if ( !is_readable( $tocBackgroundFile ) )
                {
                    $tocBackgroundFile = false;
                }
            }
        }

        $this->documentList[] = array( 'type'  => abPDFAssembler::DOCUMENT_TYPE_TOC ,
                                       'title' => false,
                                       'toc'   => false,
                                       'bg'    => $tocBackgroundFile
                                     );

        foreach ( $contentObjectIdList as $contentObjectId )
        {
            $this->documentList[] = array( 'type' => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'id'   => $contentObjectId,
                                           'toc'  => true
                                         );
        }

        $contentObjectId = $this->fetchObjectIDFromRelationAttribute( $dataMap[abPDFCatalogue::APPENDIX_FILE_ATTRIBUTE_NAME] );
        if ( is_int( $contentObjectId ) )
        {
            $this->documentList[] = array( 'type'  => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'id'    => $contentObjectId,
                                           'toc'   => false
                                         );
        }
    }

    private function mergePDFFiles()
    {
        $fileHash      = md5( serialize( $this->documentList ) );
        $cachefile     = $this->cacheFilename( $fileHash );
        $missingFiles  = array();
        $existingFiles = array();

        $this->resultArray[ 'hash' ]      = $fileHash;
        $this->resultArray[ 'cachefile' ] = $cachefile;
        $this->resultArray[ 'filename' ]  = $this->targetFileName;

        if ( $cachefile !== false && file_exists( $cachefile ) )
        {
            $this->resultArray[ 'cached' ]  = true;
            $this->resultArray[ 'success' ] = true;
        }
        else
        {
            foreach ( $this->documentList as $key => $doc )
            {
                if ( $doc['type'] != abPDFAssembler::DOCUMENT_TYPE_FILE )
                {
                    continue;
                }

                $objectID      = (int)$doc['id'];
                $contentObject = eZContentObject::fetch( $objectID );

                if ( is_object( $contentObject ) )
                {
                    $objectName = $contentObject->name();
                    $dataMap    = $contentObject->dataMap();

                    if ( array_key_exists( abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME, $dataMap ) &&
                         is_object( $dataMap[abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME] )
                       )
                    {
                        $attribute = $dataMap[abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME]->attribute( 'content' );
                        $filepath  = eZSys::siteDir() . $attribute->filePath();
                        if ( file_exists( $filepath ) )
                        {
                            $this->documentList[$key]['file']  = $filepath;
                            $this->documentList[$key]['title'] = $objectName;

                            $existingFiles[] = $objectID;
                        }
                        else
                        {
                            eZDebug::writeWarning( 'The file ' . $filepath . ' of content object ID ' . $objectID . ' and can not be merged into PDF catalogue.', __METHOD__ );
                            $missingFiles[] = $objectID;
                        }
                    }
                    else
                    {
                        eZDebug::writeWarning( 'Content object with ID ' . $objectID . ' does not seem to be a valid PDF Catalogue document.', __METHOD__ );
                        $missingFiles[] = $objectID;
                    }
                }
                else
                {
                    eZDebug::writeWarning( 'Document ID ' . $objectID . ' to merge into PDF catalogue is not a valid content object.', __METHOD__ );
                    $filepath = false;
                }

            }

            $this->pdf->setDocumentList( $this->documentList );
            $this->pdf->mergeDocuments();

            if  ( $cachefile !== false )
            {
                if ( !$this->pdf->Output( $cachefile, 'F' ) )
                {
                    $cachefile = false;
                }
            }

            $this->resultArray[ 'existingfiles' ] = $existingFiles;
            $this->resultArray[ 'missingfiles' ]  = $missingFiles;
        }

        switch( $this->mode )
        {
            case 'live':
            {
                if ( $cachefile !== false )
                {
                    $this->downloadPDF( $fileHash, $this->targetFileName, $cachefile );
                }
                else
                {
                    $this->pdf->Output( $this->targetFileName, 'I' );
                }

                $this->resultArray[ 'success' ] = false;
                $this->resultArray[ 'error' ]   = "PDF download failure";

                return $this->exitJSON();
            }
            break;

            case 'cache':
            default:
            {
                if  ( $cachefile !== false )
                {
                    $this->resultArray[ 'success' ] = true;
                    $this->resultArray[ 'time' ]    = microtime( true ) - $this->startTime;
                    return $this->exitJSON();
                }
                else
                {
                    $this->resultArray[ 'success' ] = false;
                    $this->resultArray[ 'error' ]   = 'File can not be stored in ' . $cachefile;
                    return $this->exitJSON();
                }
            }
        }
    }

    public function downloadPDF( $hash, $fileName, $cacheFilename = false )
    {
        $sourceFile = '';
        if ( $cacheFilename !== false )
        {
            $sourceFile = $cacheFilename;
        }
        else
        {
            $sourceFile = $this->cacheFilename( $hash );
        }

        if ( $target !== false && file_exists( $target ) )
        {
            ini_set('zlib.output_compression','0');
            header( 'Cache-Control: public' );
            header( 'Content-Description: File Transfer' );
            //header( 'Content-Disposition: inline; filename="' . $fileName . '' );
            header( 'Content-Disposition: attachment; filename="' . $fileName . '' );
            header( 'Content-type: application/pdf' );
            header( 'Content-Transfer-Encoding: binary');
            header( 'Content-Length: '. filesize( $sourceFile ) );
            readfile( $sourceFile );

            $this->eZPublishExit();
        }
    }

    public function exitJSON()
    {
        if ( $this->liveMode )
        {
            echo "<h1>Error</h1>";
            echo "<pre>", json_encode( $this->resultArray ), "</pre>";
        }
        else
        {
            header( 'Content-type: application/json' );
            header( 'Content-Disposition: attachment; filename=response.json' );
            echo json_encode( $this->resultArray );
        }

        $this->eZPublishExit();
    }

    private function eZPublishExit()
    {
        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
    }

}

?>