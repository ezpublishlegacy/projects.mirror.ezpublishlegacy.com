<!DOCTYPE TS><TS>
<context>
    <name>contentstructuremenu/show_content_structure</name>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>Възел ID: %node_id Видимост: %visibility</translation>
    </message>
</context>
<context>
    <name>design/admin/class/classlist</name>
    <message>
        <source>%group_name [Class group]</source>
        <translation>%group_name [Клас група]</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Classes inside &lt;%group_name&gt; [%class_count]</source>
        <translation>Класове в &lt;%group_name&gt; [%class_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Обекти</translation>
    </message>
    <message>
        <source>There are no classes in this group.</source>
        <translation>Няма класове в тази група.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Нов клас</translation>
    </message>
    <message>
        <source>Edit this class group.</source>
        <translation>Редактирай клас група.</translation>
    </message>
    <message>
        <source>Remove this class group.</source>
        <translation>Премахни клас група.</translation>
    </message>
    <message>
        <source>Back to class groups.</source>
        <translation>Назад към клас групи.</translation>
    </message>
    <message>
        <source>Select class for removal.</source>
        <translation>Избери клас за премахване.</translation>
    </message>
    <message>
        <source>Create a copy of the &lt;%class_name&gt; class.</source>
        <translation>Създай копие на &lt;%class_name&gt; клас.</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_name&gt; class.</source>
        <translation>Редактирай &lt;%class_name&gt; клас.</translation>
    </message>
    <message>
        <source>Remove selected classes from the &lt;%class_group_name&gt; class group.</source>
        <translation>Премахни избраните класове от &lt;%class_name&gt; групата класове.</translation>
    </message>
    <message>
        <source>Create a new class within the &lt;%class_group_name&gt; class group.</source>
        <translation>Създай нов клас вътре в &lt;%class_group_name&gt; групата класове.</translation>
    </message>
</context>
<context>
    <name>design/admin/class/datatype/browse_objectrelation_placement</name>
    <message>
        <source>Choose node for default selection</source>
        <translation>Определете възел за избор по подразбиране </translation>
    </message>
    <message>
        <source>Select the item that you want to be the default selection and click &quot;OK&quot;.</source>
        <translation>Прибавете нов атрибут на класа. Използвайте менюто отляво за избиране на съответния атрибут.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/class/datatype/browse_objectrelationlist_placement</name>
    <message>
        <source>Choose initial location</source>
        <translation>Определете начално място</translation>
    </message>
    <message>
        <source>Select the location that should be the default location and click &quot;OK&quot;.</source>
        <translation>Изберете мястото, което трябва да бъде по подразбиране и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/class/edit</name>
    <message>
        <source>The class definition could not be stored.</source>
        <translation>Дефиницията на класа не може да бъде съхранена.</translation>
    </message>
    <message>
        <source>The following information is either missing or invalid</source>
        <translation>Следната информация липсва или e невалидна</translation>
    </message>
    <message>
        <source>The class definition was successfully stored.</source>
        <translation>Дефиницията на класа беше успешно съхранена.</translation>
    </message>
    <message>
        <source>Edit &lt;%class_name&gt; [Class]</source>
        <translation>Редактирай &lt;%class_name&gt; [Клас]</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Схема на име на обекта</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Контейнер</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Надолу</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Нагоре</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Задължително</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Търсимо</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Събиране на информация</translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Забрани операцията</translation>
    </message>
    <message>
        <source>This class does not have any attributes.</source>
        <translation>Този клас няма никакви атрибути.</translation>
    </message>
    <message>
        <source>Remove selected attributes</source>
        <translation>Премахни избрани атрибути</translation>
    </message>
    <message>
        <source>Add attribute</source>
        <translation>Прибави атрибут</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Use this field to set the informal name of the class. The name field can contain whitespaces and special characters.</source>
        <translation>Използвайте това поле, за да дефинирате описателно име на класа. Името може да съдържа празни полета и специални символи.</translation>
    </message>
    <message>
        <source>Use this field to set the internal name of the class. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
        <translation>Използвайте това поле, за да дефинирате вътрешното име на класа. Идентификаторът ще бъде използван от шаблоните и в PHP кода. Разрешени символи: букви, числа и долна черта.</translation>
    </message>
    <message>
        <source>Use this field to configure how the name of the objects are generated (also applies to nice URLs). Type in the identifiers of the attributes that should be used. The identifiers must be enclosed in angle brackets. Text outside angle brackets will be included as is.</source>
        <translation>Използвайте това поле за  конфигурация на начина, по който се създават обектите (прилага се и за хубавите URL). Напишете идентификаторите на атрибутите, които ще се използват. Атрибутите трябва да са оградени в скоби-стрелки. Текстът извън скобите-стрелки ще бъде включен както е написан.</translation>
    </message>
    <message>
        <source>Use this checkbox to allow instances of the class to have sub items. If checked, it will be possible to create new sub-items. If not checked, the sub items will not be displayed.</source>
        <translation>Използвайте този чек-бокс, за да разрешите примери от класа да притежават подобекти. Ако е избран, е възможно да се създават нови подобекти. Ако не е избран, подобектите няма да се показват.</translation>
    </message>
    <message>
        <source>Select attribute for removal. Click the &quot;Remove selected attributes&quot; button to actually remove the selected attributes.</source>
        <translation>Изберете атрибут за премахване. Натиснете бутон &quot;Премахни избрани атрибути&quot; действително за премахване на избрани атрибути.</translation>
    </message>
    <message>
        <source>Use the order buttons to set the order of the class attributes. The up arrow moves the attribute one place up. The down arrow moves the attribute one place down.</source>
        <translation>Използвайте бутоните за подреждане, за да определите реда на клас атрибути. Стрелката нагоре премества атрибута едно място нагоре. Стрелката надолу премества атрибута едно място надолу.  </translation>
    </message>
    <message>
        <source>Use this field to set the informal name of the attribute. This field can contain whitespaces and special characters.</source>
        <translation>Използвайте това поле, за да дефинирате описателно име на атрибута. Името може да съдържа празни полета и специални символи.</translation>
    </message>
    <message>
        <source>Use this field to set the internal name of the attribute. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
        <translation>Използвайте това поле, за да дефинирате вътрешното име на атрибута. Идентификаторът ще бъде използван от шаблоните и в PHP кода. Разрешени символи: букви, числа и долна черта.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the user should be forced to enter information into the attribute.</source>
        <translation>Използвайте този чек-бокс, за да контролирате дали потребителят да бъде принуден да добави информация в атрибута.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the contents of the attribute should be indexed by the search engine.</source>
        <translation>Използвайте този чек-бокс, за да контролирате дали съдържанието на атрибута да се индексира от търсачката.</translation>
    </message>
    <message>
        <source>The &lt;%datatype_name&gt; datatype does not support search indexing.</source>
        <translation>Типът данни &lt;%datatype_name&gt; не поддържа търсене.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the attribute should collect input from users.</source>
        <translation>Използвайте този чек-бокс, за да контролирате дали атрибутът приема данни въведени от потребителите.</translation>
    </message>
    <message>
        <source>The &lt;%datatype_name&gt; datatype can not be used as an information collector.</source>
        <translation>Тип данни &lt;%datatype_name&gt; не може да бъде използван за събиране на информация.</translation>
    </message>
    <message>
        <source>Use this checkbox for attributes that contain non-translatable content.</source>
        <translation>Използвайте този чек-бокс за атрибутите със съдържание, което не се превежда.</translation>
    </message>
    <message>
        <source>Remove the selected attributes.</source>
        <translation>Премахни избраните атрибути.</translation>
    </message>
    <message>
        <source>Add a new attribute to the class. Use the menu on the left to select the attribute type.</source>
        <translation>Прибавете нов атрибут на класа. Използвайте менюто отляво за избиране на съответния атрибут.</translation>
    </message>
    <message>
        <source>Store changes and exit from edit mode.</source>
        <translation>Съхрани промените и излез от редакция.</translation>
    </message>
    <message>
        <source>Store changes and continue editing.</source>
        <translation>Съхрани промените и продължи редактирането.</translation>
    </message>
    <message>
        <source>Discard all changes and exit from edit mode.</source>
        <translation>Отмени промените и излез от режим редакция.</translation>
    </message>
    <message>
        <source>The class definition contains the following errors</source>
        <translation>Дефиницията на класа съдържа следните грешки</translation>
    </message>
</context>
<context>
    <name>design/admin/class/edit_denied</name>
    <message>
        <source>Class edit conflict</source>
        <translation>Клас редакция конфликт</translation>
    </message>
    <message>
        <source>This class is already being edited by someone else.</source>
        <translation>Класът се редактира от някой друг.</translation>
    </message>
    <message>
        <source>The class is temporarly locked and thus it can not be edited by you.</source>
        <translation>Класът е временно заключен и така не може да бъде редактиран от теб.</translation>
    </message>
    <message>
        <source>Possible actions</source>
        <translation>Възможни действия</translation>
    </message>
    <message>
        <source>Contact the person who is editing the class.</source>
        <translation>Контакт със субекта, който редактира класът.</translation>
    </message>
    <message>
        <source>Wait until the lock expires and try again.</source>
        <translation>Изчакай докато забраната изтече и опитай пак.</translation>
    </message>
    <message>
        <source>Edit &lt;%class_name&gt; [Class]</source>
        <translation>Редакция &lt;%class_name&gt; [Клас]</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Current modifier</source>
        <translation>Текущ модификатор</translation>
    </message>
    <message>
        <source>Unlock time</source>
        <translation>Време за отключване</translation>
    </message>
    <message>
        <source>The class will be available for editing once it has been stored by the current modifier or when it is unlocked by the system.</source>
        <translation>Класът ще бъде наличен за редакция след като е бил съхранен от текущия модификатор или когато е отключен от системата.</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Опитай отново</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/class/groupedit</name>
    <message>
        <source>Edit &lt;%group_name&gt; [Class group]</source>
        <translation>Редактирай &lt;%group_name&gt; [Клас група]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/class/grouplist</name>
    <message>
        <source>Class groups [%group_count]</source>
        <translation>Клас групи (%group_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Select class group for removal.</source>
        <translation>Избери клас група за премахване.
</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_group_name&gt; class group.</source>
        <translation>Редактирай &lt;%class_group_name&gt; клас група.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove the selected class groups. This will also remove all classes that only exist within the selected groups.</source>
        <translation>Премахни избраните групи класове. Така ще бъдат премахнати и всички класове, които съществуват единствено в избраните групи.</translation>
    </message>
    <message>
        <source>New class group</source>
        <translation>Нова група класове</translation>
    </message>
    <message>
        <source>Create a new class group.</source>
        <translation>Създай нова клас група.</translation>
    </message>
    <message>
        <source>Recently modified classes</source>
        <translation>Последно променяни класове</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_name&gt; class.</source>
        <translation>Редактирай &lt;%class_name&gt; клас.</translation>
    </message>
</context>
<context>
    <name>design/admin/class/removeclass</name>
    <message>
        <source>Are you sure you want to remove this class?</source>
        <translation>Сигурен ли си че искаш да премахнеш този клас?</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Confirm class removal</source>
        <translation>Потвърди премахването на класа</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the classes?</source>
        <translation>Сигурен ли си че искаш да премахнеш класовете?</translation>
    </message>
    <message>
        <source>You do not have permissions to remove classes.</source>
        <translation>Нямате право да премахнете този клас.</translation>
    </message>
    <message>
        <source>The %1 class was already removed from the group but still exists in other groups.</source>
        <translation>%1 класа вече е  премахнат от групата но още съществува в другите групи.</translation>
    </message>
    <message>
        <source>The %1 classes were already removed from the group but still exist in other groups.</source>
        <translation>%1 класовете вече са премахнати от групата, но още съществуват в другите групи.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 object.</source>
        <translation type="obsolete">Премахването на клас &lt;%1&gt; ще предизвика премахването на %2 обект.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 objects.</source>
        <translation type="obsolete">Премахването на клас &lt;%1&gt; ще предизвика премахването на %2 обекти.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 object and all it&apos;s sub-items.</source>
        <translation>Премахването на клас &lt;%1&gt; ще предизвика премахването на %2 обект и всички подобекти.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 objects and all their sub-items.</source>
        <translation>Премахването на клас &lt;%1&gt; ще предизвика премахването на %2 обекти и всички подобекти.</translation>
    </message>
</context>
<context>
    <name>design/admin/class/removegroup</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Confirm class group removal</source>
        <translation>Потвърдете премахването на клас групата</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the class group?</source>
        <translation>Сигурни ли сте, че искате да премахнете този клас група?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the class groups?</source>
        <translation>Сигурни ли сте, че искате да премахнете този клас групи?</translation>
    </message>
    <message>
        <source>The following classes will be removed from the &lt;%group_name&gt; class group</source>
        <translation>Следните класове ще бъдат премахнати от &lt;%group_name&gt; класа група</translation>
    </message>
    <message>
        <source>%objects objects will be removed</source>
        <translation>%objects обекти ще бъдат премахнати</translation>
    </message>
</context>
<context>
    <name>design/admin/class/view</name>
    <message>
        <source>Last modified: %time, %username</source>
        <translation>Последно променени: %username at %time</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Схема на име на обекта</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Контейнер</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Преброяване на обект</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибути</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Флагове</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Задължително е</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>Не е задължително</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Търсимо</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>Не е търсимо</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Събира информация</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>Не събира информация</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>Преводът деактивиран</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>Преводът е активиран</translation>
    </message>
    <message>
        <source>Override templates [%1]</source>
        <translation>Презапиши шаблоните [%1]</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Презапиши</translation>
    </message>
    <message>
        <source>Source template</source>
        <translation>Първоначален шаблон</translation>
    </message>
    <message>
        <source>Override template</source>
        <translation>Презапиши шаблона</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е потвърдена</translation>
    </message>
    <message>
        <source>%class_name [Class]</source>
        <translation>%class_name [Клас]</translation>
    </message>
    <message>
        <source>Edit this class.</source>
        <translation>Редактирай класа.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Member of class groups [%group_count]</source>
        <translation>Член на клас групи (%group_count]</translation>
    </message>
    <message>
        <source>Class group</source>
        <translation>Клас група</translation>
    </message>
    <message>
        <source>Select class group for removal.</source>
        <translation>Избери клас група за премахване.
</translation>
    </message>
    <message>
        <source>Remove from selected</source>
        <translation>Премахни от избраните</translation>
    </message>
    <message>
        <source>Remove the &lt;%class_name&gt; class from the selected class groups.</source>
        <translation>Премахни &lt;%class_name&gt; класа от избраните групи класове.</translation>
    </message>
    <message>
        <source>Select a group which the &lt;%class_name&gt; class should be added to.</source>
        <translation>Избери групата, към която &lt;%class_name&gt; класът да бъде добавен.</translation>
    </message>
    <message>
        <source>Add to class group</source>
        <translation>Добави към клас група</translation>
    </message>
    <message>
        <source>Add the &lt;%class_name&gt; class to the group specified in the menu on the left.</source>
        <translation>Добави &lt;%class_name&gt; класа към групата определена в менюто отляво.</translation>
    </message>
    <message>
        <source>The &lt;%class_name&gt; class already exists within all class groups.</source>
        <translation>&lt;%class_name&gt; класът вече съществува във всичките групи класове.</translation>
    </message>
    <message>
        <source>No group</source>
        <translation>Няма група</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>View template overrides for the &lt;%source_template_name&gt; template.</source>
        <translation>Виж пренаписаните шаблони за &lt;%source_template_name&gt; шаблона.</translation>
    </message>
    <message>
        <source>Edit the override template for the &lt;%override_name&gt; override.</source>
        <translation>Редактирай пренаписания шаблон за &lt;%override_name&gt; пренаписания шаблон. </translation>
    </message>
    <message>
        <source>This class does not have any class-level override templates.</source>
        <translation>Класът не притежава никакви пренаписани шаблони на ниво клас.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration</name>
    <message>
        <source>Approval</source>
        <translation>Одобрение</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/group/view/list</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Списък на групите за &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Няма обекти в групата.</translation>
    </message>
    <message>
        <source>Group tree for &apos;%1&apos;</source>
        <translation>Групово дърво за &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/group_tree</name>
    <message>
        <source>Groups</source>
        <translation>Групи</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/full/ezapprove</name>
    <message>
        <source>Approval</source>
        <translation>Одобрение</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Обектът %1 чака одобрение за публикация.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Ако желаете, можете да изпратите съобщение на човека, който го одобрява?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Обектът %1 чака вашето одобрение за публикация.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Одобрявате ли публикуването на този обект?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Обектът %1 е одобрен и ще бъде побликуван след като процесът на публикация продължи.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Обектът %1 не е приет, но е наличен като чернова.</translation>
    </message>
    <message>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>Можете да редактирате черновата и да я публикувате. В този случай отново се изисква одобрение.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Редактирай обекта</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Обектът %1 не е приет, но ще бъде наличен като чернова за автора.</translation>
    </message>
    <message>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>Авторът може да редактира черновата и да я публикува. В този случай се създава нов обект за одобрение.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Добави коментар</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Одобри</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Отказ</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Преглед</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Участници</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Съобщения</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was approved and will be published once the publishing workflow continues.</source>
        <translation>Обектът %1 [deleted] е одобрен и ще бъде побликуван след като процесът на публикация продължи.</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was not accepted but is available as a draft again.</source>
        <translation>Обектът %1 [deleted] не е приет, но е наличен като чернова.</translation>
    </message>
    <message>
        <source>The content object %1 [deleted] was not accepted but will be available as a draft for the author.</source>
        <translation>Обектът %1 не е приет, но ще бъде наличен като чернова за автора.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/line/ezapprove</name>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 очаква одобрение от редактора</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 е одобрен за публикуване</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 не е одобрен за публикуване</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 очаква вашето одобрение</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/item_list</name>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Прочетен</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочетен</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивен</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/view/element/ezapprove_comment</name>
    <message>
        <source>Posted: %1</source>
        <translation>Изпратен: %1</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/view/summary</name>
    <message>
        <source>Item list</source>
        <translation>Списък с обекти</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Няма нови обекти за обработка.</translation>
    </message>
    <message>
        <source>Group tree</source>
        <translation>Групово дърво</translation>
    </message>
</context>
<context>
    <name>design/admin/content/bookmark</name>
    <message>
        <source>My bookmarks [%bookmark_count]</source>
        <translation>Моите бележки (%bookmark_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>There are no bookmarks in the list.</source>
        <translation>Няма бележки в списъка.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select bookmark for removal.</source>
        <translation>Изберете бележка за премахване.</translation>
    </message>
    <message>
        <source>Edit &lt;%bookmark_name&gt;.</source>
        <translation>Редактирай &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit the contents of &lt;%bookmark_name&gt;.</source>
        <translation>Нямате права да редактираш съдържанието на &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected bookmarks.</source>
        <translation>Премахни избраните бележки.</translation>
    </message>
    <message>
        <source>Add items</source>
        <translation>Добави точки</translation>
    </message>
    <message>
        <source>Add items to your personal bookmark list.</source>
        <translation>Добавете точки в своя списък с бележки.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Най-горно ниво</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>За да определите обект, изберете подходящия радиобутон или чек-бокс (може и няколко) и натиснете бутона &quot;Избери&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>За да изберете обект, който е наследник на някой от показаните обекти, натиснете върху името на обекта и ще видите списък с наследниците на обекта.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Обратно</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation>Покажи под-точките като списък.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Списък</translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation>Иконка</translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation>Покажи под-точките като иконки.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_bookmark</name>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Изберете точки за отбелязване</translation>
    </message>
    <message>
        <source>Select the items that you want to bookmark using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Изберете точките, които искате  да отбележите чрез чек-боксовете и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_copy_node</name>
    <message>
        <source>Choose location for copy of &lt;%object_name&gt;</source>
        <translation>Изберете място за копиране на &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location the copy of &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Изберете ново място за копието на &lt;%object_name&gt; чрез радио бутоните и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
    <message>
        <source>Choose location for copy of subtree of node &lt;%node_name&gt;</source>
        <translation>Изберете място за копиране от под-дървото на възела &lt;%node_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location the copy subtree of node &lt;%node_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Изберете ново място за копиране от под-дървото на възела &lt;%node_name&gt; чрез радио бутоните и натиснете &quot;ОК&quot;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_export</name>
    <message>
        <source>Choose export node</source>
        <translation>Изберете възел за експорт</translation>
    </message>
    <message>
        <source>Select the item that you want to export using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Изберете обекта, който искате да експортирате чрез чек-боксовете и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_first_placement</name>
    <message>
        <source>Choose location for new &lt;%classname&gt;</source>
        <translation>Определете място за нов &lt;%classname&gt;</translation>
    </message>
    <message>
        <source>Choose a location for the new &lt;%classname&gt; using the radiobuttons and click &quot;OK&quot;.</source>
        <translation>Определете място за нов &lt;%classname&gt; чрез радиобутоните и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_move_node</name>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%object_name&gt;</source>
        <translation>Изберете ново място за &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Изберете ново място за &lt;%object_name&gt; чрез радиобутоните и натиснете &quot;ОК&quot;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_move_placement</name>
    <message>
        <source>Choose a new location for &lt;%version_name&gt;</source>
        <translation>Определете ново място за &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%version_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Определете ново място за &lt;%version_name&gt; чрез радиобутоните и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>The previous location was &lt;%previous_location&gt;.</source>
        <translation>Предишното място беше &lt;%previous_location&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_placement</name>
    <message>
        <source>Choose locations for &lt;%version_name&gt;</source>
        <translation>Определете място за &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Choose locations for &lt;%version_name&gt; using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Изберете място за &lt;%version_name&gt; чрез чек-боксовете и натиснете &quot;ОК&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_related</name>
    <message>
        <source>Choose objects that you wish to relate to &lt;%version_name&gt;</source>
        <translation>Определете обекти, които желаете да обедините към &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Use the checkboxes to choose the objects that you wish to relate to &lt;%version_name&gt;.</source>
        <translation>Чрез чекбоксовете изберете обектите, които желаете да обедините към &lt;%version_name&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_swap_node</name>
    <message>
        <source>Choose the exchanging node for &lt;%object_name&gt;</source>
        <translation>Изберете заменящия възел за &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the node with which you want to swap &lt;%object_name&gt;.</source>
        <translation>Чрез радиобутоните изберете връзка, която искате да замени &lt;%object_name&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони  (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/children_reverserelatedlist</name>
    <message>
        <source>Item</source>
        <translation>Елемент</translation>
    </message>
    <message>
        <source>Objects referring to this one</source>
        <translation>Обекти, отнасящи се до настоящия</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Отговор за %feedbackname</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Вече сте изпратили данни за този отговор. Предходно изпратените данни са както следва.</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Благодаря ви за обратната информация, следната информация беше събрана.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Обратно в сайта</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Форма %formname</translation>
    </message>
    <message>
        <source>Collected information</source>
        <translation>Събрана информация</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Вече сте изпратили данни за тази форма. Предходно изпратените данни са както следва.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Обратно</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Анкета %pollname</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Анонимни потребители не могат да гласуват в тази анкета, моле влезте.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Вие вече сте гласували в тази анкета.</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Резултати от анкетата</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count общи резултати</translation>
    </message>
</context>
<context>
    <name>design/admin/content/confirmtranslationremove</name>
    <message>
        <source>Confirm language removal</source>
        <translation>Потвърдете премахване на езика</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the language?</source>
        <translation>Сигурни ли сте, че искате да премахнете езика?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the languages?</source>
        <translation>Сигурни ли сте, че искате да премахнете езиците?</translation>
    </message>
    <message>
        <source>Removing &lt;%1&gt; will also result in the removal of %2 translated versions.</source>
        <translation>Премахването &lt;%1&gt; ще предизвика премахване на %2 преведени версии.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/content/datatype</name>
    <message>
        <source>No media file is available.</source>
        <translation>Няма валиден медия файл.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/datatype/ezuser</name>
    <message>
        <source>Account status</source>
        <translation>Статус на акаунта</translation>
    </message>
</context>
<context>
    <name>design/admin/content/draft</name>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove all</source>
        <translation>Премахни всички</translation>
    </message>
    <message>
        <source>My drafts [%draft_count]</source>
        <translation>Моите чернови [%draft_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Select draft for removal.</source>
        <translation>Изберете чернова за премахване.</translation>
    </message>
    <message>
        <source>Edit &lt;%draft_name&gt;.</source>
        <translation>Редактирай &lt;%draft_name&gt;.</translation>
    </message>
    <message>
        <source>There are no drafts that belong to you.</source>
        <translation>Няма ваши чернови.</translation>
    </message>
    <message>
        <source>Remove selected drafts.</source>
        <translation>Премахнете избраните проекти.</translation>
    </message>
    <message>
        <source>Remove all drafts that belong to you.</source>
        <translation>Премахнете всички ваши чернови.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Are you sure you want to remove all drafts?</source>
        <translation>Сигурни ли сте, че искате да премахнете всички чернови?</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Редактирай &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Превеждане на съдържание %from_lang към  %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Изпрати за публикация</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Публикуване на съдържанията на черновата, който беше редактиран. Проектът по този начин ще бъде публикуван във версията на обекта.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation> Съхрани чернова</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Съхранете съдържанията на черновата, който беше редактиран и продължете с промяната. Използвайте тези бутони периодично, за да запазвате работата по време на редакция.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Откажи чернова</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Дълбочина</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Идентификатор на класа</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Клас Име</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Locations [%locations]</source>
        <translation>Места [%locations]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Поделементи</translation>
    </message>
    <message>
        <source>Sorting of sub items</source>
        <translation>Сортиране на поделементи</translation>
    </message>
    <message>
        <source>Current visibility</source>
        <translation>Текущa видимост</translation>
    </message>
    <message>
        <source>Visibility after publishing</source>
        <translation>Видимост след публикуване</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Основен</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this location.</source>
        <translation>Нямате право да премахнете това място.</translation>
    </message>
    <message>
        <source>Select location for removal.</source>
        <translation>Изберете място за премахване.</translation>
    </message>
    <message>
        <source>Use this menu to set the sorting method for the sub items of the respective location.</source>
        <translation>Използвайте това меню за определяне на сортиращия метод за поделементите на съответното място.</translation>
    </message>
    <message>
        <source>Use this menu to set the sorting direction for the sub items of the respective location.</source>
        <translation>Използвайте това меню за определяне на сортиращaта посока за поделементите на съответното място.</translation>
    </message>
    <message>
        <source>Desc.</source>
        <translation>Низходящ.</translation>
    </message>
    <message>
        <source>Asc.</source>
        <translation>Възходящ.</translation>
    </message>
    <message>
        <source>Hidden by parent</source>
        <translation>Скрит от източник</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Видим</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Непроменен</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Скрит</translation>
    </message>
    <message>
        <source>Use these radio buttons to specify the main location (main node) for the object being edited.</source>
        <translation>Използвайте тези радиобутони за определяне на основното място (основната връзка) на редактираните обектите.</translation>
    </message>
    <message>
        <source>Move to another location.</source>
        <translation>Премести на друго място.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected locations.</source>
        <translation>Премахни избраните места.</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Добави места</translation>
    </message>
    <message>
        <source>Add one or more locations for the object being edited.</source>
        <translation>Добави едно или няколко места за редактирания обект.</translation>
    </message>
    <message>
        <source>You can not add or remove locations because the object being edited belongs to a top node.</source>
        <translation>Не можете да добавите или премахнете места, защото редактираният обект принадлежи на главен възел.</translation>
    </message>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>View and manage (copy, delete, etc.) the versions of this object.</source>
        <translation>Разглеждане и управление (копиране, изтриване, и т.н.) на версиите на този обект.</translation>
    </message>
    <message>
        <source>You can not manage the versions of this object because there is only one version available (the one that is being edited).</source>
        <translation>Не можете да управлявате версиите на този обект, защото съществува само една версия (тази, която се редактира в момента).</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Текуща чернова</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
    <message>
        <source>View the draft that is being edited.</source>
        <translation>Вижте черновата, която се редактира в момента.</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Запази и излез</translation>
    </message>
    <message>
        <source>Store the draft that is being edited and exit from edit mode.</source>
        <translation>Запази черновата, която се редактира в момента, и излез от режима за редакция.</translation>
    </message>
    <message>
        <source>Translations [%translation_count]</source>
        <translation>Преводи [%translation_count]</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Няма информация за мястото)</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the selected translation of the draft that is being edited.</source>
        <translation>Редактирайте избрания превод на черновата, която се редактира в момента.</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Преведи</translation>
    </message>
    <message>
        <source>Edit the selected translation of the draft using the content being edited as a reference.</source>
        <translation>Редактирайте избрания превод на черновата като използвате за еталон редактираното съдържание.</translation>
    </message>
    <message>
        <source>The draft that is being edited only exists in one language; thus this button is disabled.</source>
        <translation>Черновата, която се редакктира в момента, няма преводи; затова този бутон не е активен.</translation>
    </message>
    <message>
        <source>Manage translations</source>
        <translation>Управление на преводите</translation>
    </message>
    <message>
        <source>View and manage (add/remove) translations for the draft that is being edited.</source>
        <translation>Разглеждане и управление [добавяне/премахване] на преводи на черновата, която се редактира в момента.</translation>
    </message>
    <message>
        <source>Related objects [%related_objects]</source>
        <translation>Свързани обекти [%related_objects]</translation>
    </message>
    <message>
        <source>Related images [%related_images]</source>
        <translation>Свързани изображения [%related_images]</translation>
    </message>
    <message>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>Копийрате този код в XML полетo.</translation>
    </message>
    <message>
        <source>Related files [%related_files]</source>
        <translation>Свързани файлове [%related_files]</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Тип на файла</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Големина</translation>
    </message>
    <message>
        <source>XML code</source>
        <translation>XML код</translation>
    </message>
    <message>
        <source>Related content [%related_objects]</source>
        <translation>Свързано съдържание [%related_objects]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>Няма обекти свързани с редактирания в момента обект.</translation>
    </message>
    <message>
        <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
        <translation>Премахете избраните обекти от горния списък (списъци) . Само връзките ще бъдат премахнати. Обектите няма да бъдат изтрити.</translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Добави съществуващ</translation>
    </message>
    <message>
        <source>Add an existing item as a related object.</source>
        <translation>Добави съществуащ елемент като свързан обект.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Качи нов</translation>
    </message>
    <message>
        <source>Upload a file and add it as a related object.</source>
        <translation>Качи файл и добави като свързан обект.</translation>
    </message>
    <message>
        <source>The draft could not be stored.</source>
        <translation>Проектът не може да бъде съхранен.</translation>
    </message>
    <message>
        <source>Required data is either missing or is invalid</source>
        <translation>Задължителната дата липсва или е невалидна</translation>
    </message>
    <message>
        <source>The following locations are invalid</source>
        <translation>Следните места са невалидни</translation>
    </message>
    <message>
        <source>The draft was only partially stored.</source>
        <translation>Черновата беше частично съхранена.</translation>
    </message>
    <message>
        <source>The draft was successfully stored.</source>
        <translation>Черновата беше успешно съхранена.</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Сигурни ли сте, че искате да премахнете тази чернова?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Премахнете черновата, която се редактира в момента. Така ще бъдат премахнати и преводите на тази чернова (ако съществуват).</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>Нямате достатъчно права, за да разгледате този обект</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit_attribute</name>
    <message>
        <source>not translatable</source>
        <translation>Не се превежда</translation>
    </message>
    <message>
        <source>required</source>
        <translation>Задължително</translation>
    </message>
    <message>
        <source>information collector</source>
        <translation>колектор на информация</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit_draft</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Все още не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Possible edit conflict</source>
        <translation>Възможен е конфликт при редактирането</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else. In addition, it is already being edited by you.</source>
        <translation>Обектът вече е редактиран от някой друг. Допълнително е редактирана и от вас.</translation>
    </message>
    <message>
        <source>You should contact the other user(s) to make sure that you are not stepping on anyone&apos;s toes.</source>
        <translation>Трябва да се свържете с другите потребители, за да сте сигурни, че не се дублирате с някого.</translation>
    </message>
    <message>
        <source>The most recently modified draft is version #%version, created by %creator, last changed: %modified.</source>
        <translation>Последната модифицирана чернова е версия #%version, създадена от %creator, последно променена на: %modified.
</translation>
    </message>
    <message>
        <source>This object is already being edited by you.</source>
        <translation>Вече сте редактирали този обект.</translation>
    </message>
    <message>
        <source>Your most recently modified draft is version #%version, last changed: %modified.</source>
        <translation>Твоята последно модифицирана чернова е версия #%version, последно променена на: %modified.
</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.</source>
        <translation>Обектът вече е редактиран от някой друг.</translation>
    </message>
    <message>
        <source>Possible actions</source>
        <translation>Възможни действия</translation>
    </message>
    <message>
        <source>Continue editing one of your drafts.</source>
        <translation>Продължете да редактирате някоя от собствените си чернови.</translation>
    </message>
    <message>
        <source>Create a new draft and start editing it.</source>
        <translation>Създайте нов проект и го редактирайте.</translation>
    </message>
    <message>
        <source>Cancel the edit operation.</source>
        <translation>Отмени редактирането.</translation>
    </message>
    <message>
        <source>Current drafts [%draft_count]</source>
        <translation>Текущи чернови [%draft_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Select draft version #%version for editing.</source>
        <translation>Изберете версия на проекта #%version за редакция.</translation>
    </message>
    <message>
        <source>You can not select draft version #%version for editing because it belongs to another user. Please select a draft that belongs to you or create a new draft and then edit it.</source>
        <translation>Не можете да изберете версия на черновата #%version за редактиране, защото принадлежи на друг потребител. Моля, изберете чернова, която ви принадлежи или създайте нова чернова и тогава я редактирайте.</translation>
    </message>
    <message>
        <source>View the contents of version #%version. Default translation: %default_translation.</source>
        <translation>Разгледайте съдържанието на версия #%version. Превод по подразбиране: %default_translation.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Разгледайте съдържанието на версия #%version number. Превод: %translation.</translation>
    </message>
    <message>
        <source>Edit selected</source>
        <translation>Редактирай избрания</translation>
    </message>
    <message>
        <source>Edit the selected draft.</source>
        <translation>Редактирай избраната чернова.</translation>
    </message>
    <message>
        <source>You can not edit any of the drafts because none of them belong to you. Hint: Create a new draft, select it and edit it.</source>
        <translation>Не можете да редактирате нито една от черновите, защото не сте собственик. Предложение: Създайте нова чернова, изберете я и я редактирайте.</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Нова чернова</translation>
    </message>
    <message>
        <source>Create a new draft. The contents of the new draft will copied from the published version.</source>
        <translation>Създайте нова чернова. Съдържанието на новата чернова ще бъде копирано от публикуваната версия.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/content/pendinglist</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>The pending list is empty.</source>
        <translation>Списъкът с чакащи обекти е празен.</translation>
    </message>
    <message>
        <source>My pending items [%pending_count]</source>
        <translation>Моите чакащи обекти [%pending_count]</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeassignment</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Текуща чернова</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Confirm location removal</source>
        <translation>Потвърдете премахването на мястото</translation>
    </message>
    <message>
        <source>Insufficient permissions</source>
        <translation>Недостатъчни права</translation>
    </message>
    <message>
        <source>Some of the locations that are about to be removed contain sub items.</source>
        <translation>Някои от местата, които ще премахнете съдържат подобекти.</translation>
    </message>
    <message>
        <source>Removing the locations will also result in the removal of the sub items.</source>
        <translation>Премахването на местата ще доведе до премахването на подобектите.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the locations along with their contents?</source>
        <translation>Сигурни ли сте, че искате да премахнете местата заедно с тяхното съдържание?</translation>
    </message>
    <message>
        <source>The locations marked with red contain items that you do not have permissions to remove.</source>
        <translation>Местата отбелязани с червено съдържат обекти, които нямате право да премахвате.</translation>
    </message>
    <message>
        <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
        <translation>Натиснете бутона &quot;Отмени&quot; и опитайте да премахнете само местата, за които имате права.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Подобекти</translation>
    </message>
    <message>
        <source>%child_count item</source>
        <translation>%child_count обект</translation>
    </message>
    <message>
        <source>%child_count items</source>
        <translation>%child_count обекти</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Remove the locations along with all the sub items.</source>
        <translation>Премахни местата заедно с всички подобекти.</translation>
    </message>
    <message>
        <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
        <translation>Не можете да продължите, защото нямате права да премахвате някои от избраните места.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Cancel the removal of locations.</source>
        <translation>Отмени премахването на места.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeeditversion</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Confirm draft discard</source>
        <translation>Потвърди отмяната на черновата</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Сигурни ли сте, че искате да премахнете този проект?</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Текуща чернова</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeobject</name>
    <message>
        <source>%child_count item</source>
        <translation>%child_count обект</translation>
    </message>
    <message>
        <source>%child_count items</source>
        <translation>%child_count обекти</translation>
    </message>
</context>
<context>
    <name>design/admin/content/reverserelatedlist</name>
    <message>
        <source>&quot;%contentObjectName&quot; [%children_count]: Sub items that are used by other objects </source>
        <translation>&quot;%contentObjectName&quot; [%children_count]: Поделементи, които се използват от други обекти</translation>
    </message>
    <message>
        <source>This subtree/item has no external relations.</source>
        <translation>Това подменю / поделемент няма външни връзки.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/search</name>
    <message>
        <source>Update attributes</source>
        <translation>Обнови атрибутите</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Цялото съдържание</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>Същото място</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2.</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>За повече резултати опитай %1Advanced search%2.</translation>
    </message>
    <message>
        <source>No results were found while searching for &lt;%1&gt;</source>
        <translation>Не са намерени резултати за &lt;%1&gt;</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Техники за търсене</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Провери правописа на ключовите думи.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Опитайте с повече основни ключови думи.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>По-малкото ключови думи водят до повече резултати, опитайте да намалите ключовите думи, докато получите резултат.</translation>
    </message>
    <message>
        <source>Search for &lt;%1&gt; returned %2 matches</source>
        <translation>Търсенето ха &lt;%1&gt; върна %2 съвпадения</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Разширено търсене</translation>
    </message>
    <message>
        <source>Search for all of the following words</source>
        <translation>Търси всичките зададени думи</translation>
    </message>
    <message>
        <source>Search for an exact phrase</source>
        <translation>Търси точна фраза</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Всеки клас</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Атрибут на класа</translation>
    </message>
    <message>
        <source>Any attribute</source>
        <translation>Произволен атрибут</translation>
    </message>
    <message>
        <source>In</source>
        <translation>В</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Във всяка секция</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>По всяко време</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Последния ден</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Последната седмица</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Последния месец</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Последните три месеца</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Последната година</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation> Покажи на страница</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 обекта</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 обекта</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 обекта</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 обекта</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 обекта</translation>
    </message>
    <message>
        <source>No results were found when searching for &lt;%1&gt;</source>
        <translation>Не са намерени резултати от търсенето на &lt;%1&gt;</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Следните думи бяха изключени от търсенето</translation>
    </message>
    <message>
        <source>Try changing some keywords e.g. car instead of cars.</source>
        <translation>Опитайте да промените някои ключови думи, например кола вместо коли.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translate</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Текуща чернова</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Confirm translation removal</source>
        <translation>Потвърдете премахването на превода</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the translation?</source>
        <translation>Сигурни ли сте, че искате да премахнете този превод?</translation>
    </message>
    <message>
        <source>The following translation (along with translated content) will be removed from the draft</source>
        <translation>Следният превод (заедно с преведеното съдържание) ще бъде премахнат от черновата</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the translations?</source>
        <translation>Сигурни ли сте, че искате да премахнете тези преводи?</translation>
    </message>
    <message>
        <source>The following translations (along with translated content) will be removed from the draft</source>
        <translation>Следните преводи (заедно с преведеното съдържание) ще бъдат премахнати от черновата</translation>
    </message>
    <message>
        <source>(No locale information available.)</source>
        <translation>(Няма информация за мястото)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Translations for &lt;%object_name&gt; [%translation_count]</source>
        <translation>Преводи за &lt;%object_name&gt; [%translation_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Select translation for removal.</source>
        <translation>Изберете превод за премахване.</translation>
    </message>
    <message>
        <source>(Unable to display because of unknown locale!)</source>
        <translation>(Не може да бъде показан, поради неизвестно място!)</translation>
    </message>
    <message>
        <source>There are no translations available.</source>
        <translation> Няма налични преводи.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove the selected translations from the draft that is being edited.</source>
        <translation>Премахнете избраните преводи от черновата, която редактирате.</translation>
    </message>
    <message>
        <source>Select a translation you wish to add to the draft that is being edited.</source>
        <translation>Изберете превод, който искате да прибавите към редактираната чернова.</translation>
    </message>
    <message>
        <source>All available translations have been added to the draft that is being edited.</source>
        <translation>Всички налични преводи бяха добавени към редактираната чернова.</translation>
    </message>
    <message>
        <source>No languages</source>
        <translation>Няма езици</translation>
    </message>
    <message>
        <source>Add translation</source>
        <translation>Добави превод</translation>
    </message>
    <message>
        <source>Add the selected translation to the draft that is being edited.</source>
        <translation>Добави избрания превод към редактираната чернова.</translation>
    </message>
    <message>
        <source>Back to edit mode</source>
        <translation>Назад към режим за редакция</translation>
    </message>
    <message>
        <source>Go back to edit mode.</source>
        <translation>Обратно към режим за редакция.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translationnew</name>
    <message>
        <source>Translation</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Нов превод на съдържанието</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Направен</translation>
    </message>
    <message>
        <source>Name of custom translation</source>
        <translation>Име на направен превод</translation>
    </message>
    <message>
        <source>Locale for custom translation</source>
        <translation>Място за направен превод</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translations</name>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add language</source>
        <translation>Добави език</translation>
    </message>
    <message>
        <source>Available languages for translation of content [%translations_count]</source>
        <translation>Налични езици за превод на съдържание [%translations_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Select language for removal.</source>
        <translation>Изберете език за премахване.</translation>
    </message>
    <message>
        <source>The default language can not be removed.</source>
        <translation>Подразбиращият език не може да бъде премахнат.</translation>
    </message>
    <message>
        <source>Remove selected languages.</source>
        <translation>Премахни избраните езици.</translation>
    </message>
    <message>
        <source>Add a new language. The new language can then be used when translating content.</source>
        <translation>Добавете нов език. Новият език може да бъде използван за превод на съдържание.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translationview</name>
    <message>
        <source>%translation [Translation]</source>
        <translation>%translation (Превод)</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>%locale [Locale]</source>
        <translation>%locale (Локален)</translation>
    </message>
    <message>
        <source>Charset</source>
        <translation>Схема</translation>
    </message>
    <message>
        <source>Not set</source>
        <translation>Без настройка</translation>
    </message>
    <message>
        <source>Allowed charsets</source>
        <translation>Позволени схеми</translation>
    </message>
    <message>
        <source>Country name</source>
        <translation>Име на страна</translation>
    </message>
    <message>
        <source>Country comment</source>
        <translation>Коментар към страна</translation>
    </message>
    <message>
        <source>Country code</source>
        <translation>Код на страна</translation>
    </message>
    <message>
        <source>Country variation</source>
        <translation>Промяна на страна</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Име на език</translation>
    </message>
    <message>
        <source>International language name</source>
        <translation>Име на международен език</translation>
    </message>
    <message>
        <source>Language code</source>
        <translation>Код на език</translation>
    </message>
    <message>
        <source>Language comment</source>
        <translation>Коментар към език</translation>
    </message>
    <message>
        <source>Locale code</source>
        <translation>Код на място</translation>
    </message>
    <message>
        <source>Full locale code</source>
        <translation>Цял код на място</translation>
    </message>
    <message>
        <source>HTTP locale code</source>
        <translation>HTTP код на място</translation>
    </message>
    <message>
        <source>Decimal symbol</source>
        <translation>Десетичен символ</translation>
    </message>
    <message>
        <source>Thousands separator</source>
        <translation>Разделител за хиляди</translation>
    </message>
    <message>
        <source>Decimal count</source>
        <translation>Десетична запетая</translation>
    </message>
    <message>
        <source>Negative symbol</source>
        <translation>Минус</translation>
    </message>
    <message>
        <source>Positive symbol</source>
        <translation>Плюс</translation>
    </message>
    <message>
        <source>Currency decimal symbol</source>
        <translation>Валутен десетичен символ</translation>
    </message>
    <message>
        <source>Currency thousands separator</source>
        <translation>Валутен разделител за хиляди</translation>
    </message>
    <message>
        <source>Currency decimal count</source>
        <translation>Валутна десетична запетая</translation>
    </message>
    <message>
        <source>Currency negative symbol</source>
        <translation>Валутен знак плюс</translation>
    </message>
    <message>
        <source>Currency positive symbol</source>
        <translation>Валутен знак мунус</translation>
    </message>
    <message>
        <source>Currency symbol</source>
        <translation>Символ на валута</translation>
    </message>
    <message>
        <source>Currency name</source>
        <translation>Име на валута</translation>
    </message>
    <message>
        <source>Currency short name</source>
        <translation>Кратко име на валута</translation>
    </message>
    <message>
        <source>First day of week</source>
        <translation>Първи ден на седмица</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Понеделник</translation>
    </message>
    <message>
        <source>Weekday names</source>
        <translation>Имена на дните от седмицата</translation>
    </message>
    <message>
        <source>Month names</source>
        <translation>Имена на месеците</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Неделя</translation>
    </message>
</context>
<context>
    <name>design/admin/content/trash</name>
    <message>
        <source>Trash [%list_count]</source>
        <translation>Кошче [%list_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Use these checkboxes to mark items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
        <translation>Използвайте тези чек-боксове, за да маркирате атрибутите за премахване. Изберете бутон &quot;Премахни избраните&quot;, за да премахнете избраните атрибути.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Permanently remove the selected items.</source>
        <translation>Периодично премахвайте избраните атрибути.</translation>
    </message>
    <message>
        <source>Empty trash</source>
        <translation>Изпразни кошчето</translation>
    </message>
    <message>
        <source>Permanently remove all items from the trash.</source>
        <translation>Периодично премахвайте всички атрибути от кошчето.</translation>
    </message>
    <message>
        <source>There are no items in the trash</source>
        <translation>Няма атрибути в кошчето</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
</context>
<context>
    <name>design/admin/content/upload</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Текуща чернова</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>The file could not be uploaded</source>
        <translation>Файлът не може да бъде качен</translation>
    </message>
    <message>
        <source>The following errors occurred</source>
        <translation>Допуснати са следните грешки</translation>
    </message>
    <message>
        <source>File upload</source>
        <translation>Качване на файл</translation>
    </message>
    <message>
        <source>Choose a file from your local machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
        <translation>Изберете файл от своя компютър и натиснете бутон &quot;Качи&quot;. Обектът ще бъде създаден според типа на файл и местоположението мъ във вашия компютър.</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Качи файл</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>The location where the uploaded file should be placed.</source>
        <translation>Мястото, където е качен файла, трябва да бъде поставен.</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Автоматичен</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Select the file that you wish to upload.</source>
        <translation>Изберете файла, който искате да бъде качен.</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Качи</translation>
    </message>
    <message>
        <source>Proceed with uploading the selected file.</source>
        <translation>Продължете с качването на избрания файл.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Abort the upload operation and go back to where you came from.</source>
        <translation>Прекратете операцията с качването и се върнете, откъдето започнахте.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/upload_related</name>
    <message>
        <source>Upload a file and relate it to &lt;%version_name&gt;</source>
        <translation>Качи файл и го закачи към &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>This operation allows you to upload a file and add it as a related object.</source>
        <translation>Тази операция ви позволява да качите файл и да го добавите като свързан обект.</translation>
    </message>
    <message>
        <source>When the file is uploaded, an object will be created according to the type of the file.</source>
        <translation>Когато файлът е качен, обектът ще бъде създаден според типа на файл.</translation>
    </message>
    <message>
        <source>The newly created object will be placed within the chosen location.</source>
        <translation>Новият създаден обект ще бъде качен на избраното място.</translation>
    </message>
    <message>
        <source>The newly created object will be automatically related to the draft being edited (&lt;%version_name&gt;).</source>
        <translation>Новосъздаденият обект ще бъде автоматично свързан с черновата, която беше редактирана (&lt;%version_name&gt;).</translation>
    </message>
    <message>
        <source>Select the file you wish to upload and click the &quot;Upload&quot; button.</source>
        <translation>Изберете файл, който искаш да качите и изберете бутон &quot;Качи&quot;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/urltranslator</name>
    <message>
        <source>The destination URL &lt;%destination_url&gt; does not exist in the system.</source>
        <translation>Уеб адресът &lt;%destination_url&gt; не съществува в системата.</translation>
    </message>
    <message>
        <source>System URL</source>
        <translation>Системно URL</translation>
    </message>
    <message>
        <source>Example: /services</source>
        <translation>Пример: /services</translation>
    </message>
    <message>
        <source>Example: /content/view/full/42</source>
        <translation>Пример /content/view/full/42</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добави</translation>
    </message>
    <message>
        <source>Existing virtual URL</source>
        <translation>Съществуващо виртуално URL</translation>
    </message>
    <message>
        <source>Example: /about/service</source>
        <translation>Пример: /about/service</translation>
    </message>
    <message>
        <source>Example: /developer/*</source>
        <translation>Пример: /developer/*</translation>
    </message>
    <message>
        <source>Custom URL translations [%alias_count]</source>
        <translation>Потребителски преводи на URL [%alias_count]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Forwards to</source>
        <translation>Напред към</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърдете промените</translation>
    </message>
    <message>
        <source>New system URL forwarding</source>
        <translation>Пренасочване към ново системно URL</translation>
    </message>
    <message>
        <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system.</source>
        <translation>В това поле въведете адрес, свързан с root-a на системата, който трябва да бъде преведен в друго URL. Този адрес не трябва да съществува в настоящата система.</translation>
    </message>
    <message>
        <source>Use this field to enter a valid system URL. A system URL is easily recognized since it consists of several parts separated by a &quot;/&quot;.</source>
        <translation>В това поле въведете валиден системен URL. Системното URL се разпознава лесно, защото съдържа няколко елемента разделени чрез &quot;/&quot;.</translation>
    </message>
    <message>
        <source>Click this button to add a new system URL forwarding. System URL forwarding is used to forward any URL to a system URL in eZ publish.</source>
        <translation>Кликнете върху този бутон, за да добавите пренасочване към ново системно URL. Системното URL пренасочване се използва за пренасочване на произволно URL към системно URL в eZ.</translation>
    </message>
    <message>
        <source>New virtual URL forwarding</source>
        <translation>Ново виртуално URL пренасочване</translation>
    </message>
    <message>
        <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object.</source>
        <translation>В това поле въведете валидно виртуално URL, съществуващо в системата. Виртуално URL се генерира от системата и обикновено съдържа част от съдържанието на обекта.</translation>
    </message>
    <message>
        <source>Click this button to add a new virtual URL forwarding. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish.</source>
        <translation>Кликнете върху този бутон, за да добавите ново виртуално URL пренасочване. Виртуалното URL пренасочване се използва за пренасочване на произволно URL към съществуващо виртуално URL в eZ.</translation>
    </message>
    <message>
        <source>New virtual URL forwarding with wildcard</source>
        <translation>Ново виртуално URL пренасочване чрез wildcard</translation>
    </message>
    <message>
        <source>Redirecting URL</source>
        <translation>Пренасочване на URL</translation>
    </message>
    <message>
        <source>Example</source>
        <translation>Пример</translation>
    </message>
    <message>
        <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system. You can place a star anywhere in the URL which will match an arbitrary number of characters.</source>
        <translation>В това поле въведете свързан с основния адрес на системата адрес, който трябва да бъде преведен в друго URL. Този адрес не трябва да съществува в настоящата система. Можете да поставите звездичка на произволно място в  URL името. Това замества произволен брой символи.</translation>
    </message>
    <message>
        <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object. Any characters matched by a star in the source URL can be transfered to the destination URL by inserting {1\} where appropriate.</source>
        <translation>Използвайте това поле за въвеждане на валидно, съществуващо виртуално URL. Виртуално URL се създава от системата и обикновено съдържа част от съдържанието на обекта. Символи, заместени със звезда в source URL, могат да се въведат в destination URL чрез използването на {1\}.</translation>
    </message>
    <message>
        <source>Use this checkbox to select if eZ publish should perform an internal redirect or a browser redirect. An internal redirect simply redirects the old URL to the new one without notifying the browser. A browser redirect makes the browser abort the current request and reload with the new URL. A browser redirect can be useful if you want the browser URL field to be updated.</source>
        <translation>Използвайте този чек-бокс, за да определите дали еZ publish да изпълни вътрешно пренасочване или пренасочване чрез браузъра. Вътрешното пренасочване не предава на браузъра информация за новия URL. Пренасочването чрез браузъра го принуждава да прекъсне настоящата заявка и да зареди новото URL. Пренасочването чрез браузъра e полезно, ако искате полето за URL на браузъра да се обнови.</translation>
    </message>
    <message>
        <source>Click this button to add a new virtual URL forwarding with wildcard match. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish. The wildcard match is useful if you have moved a complete tree from one place to another.</source>
        <translation>Натиснете този бутон, за да добавите ново виртуално URL пренасочване чрез използването на wildcard. Виртуалното URL пренасочване се използва за пренасочване на произволно URL към съществуващо в Ez виртуално URL.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Source URL</source>
        <translation>Първоначално URL</translation>
    </message>
    <message>
        <source>Destination URL</source>
        <translation>Място на URL</translation>
    </message>
    <message>
        <source>Select URL translation for removal.</source>
        <translation>Изберете URL превод за премахване.</translation>
    </message>
    <message>
        <source>Wildcard forwarding</source>
        <translation>Wildcard пренасочване</translation>
    </message>
    <message>
        <source>System forwarding</source>
        <translation>Системно пренасочване</translation>
    </message>
    <message>
        <source>Virtual forwarding</source>
        <translation>Виртуално пренасочване</translation>
    </message>
    <message>
        <source>There are no custom URL translations.</source>
        <translation> Няма налични потребителски URL преводи.</translation>
    </message>
    <message>
        <source>Remove selected URL translations.</source>
        <translation>Премахни избраните URL преводи.</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields in the list above.</source>
        <translation>Кликнете върху този бутон, за да съхраните промените, ако сте променили което и да е от полетата по-горе.</translation>
    </message>
    <message>
        <source>New virtual URL</source>
        <translation>Ново виртуално URL</translation>
    </message>
    <message>
        <source>New virtual URL wildcard</source>
        <translation>Ново виртуално URL wildcard</translation>
    </message>
    <message>
        <source>The requested URL forwarding could not be created.</source>
        <translation>Желаният линк не може да бъде създаден.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/versions</name>
    <message>
        <source>Version not a draft</source>
        <translation>Версията не е чернова</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Версия %1 не е достъпна за редактиране, само чернови могат да се редактират.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>За да редактирате тази версия, създайте нейно копие.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Версията не е ваша</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Версия %1 не е създадена от вас, само вашите чернови могат да бъдат редактирани.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Не може да бъде създадена нова версия</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Историческият лимит на версията е надхвърлен и архивираните версии не могат да бъдат премахнати от системата.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Можете да променяте настройките на историята на версиите в content.ini,  да премахвате чернови или да редактирате съществуващи.</translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Версии за &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Създател</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Чернова</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Предстоящ</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Архивиран</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Отхвърлен</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Изберете версия #%version_number за премахване.</translation>
    </message>
    <message>
        <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
        <translation>Версия #%version_number не може да бъде премахната, защото или версията на обекта е публикувана или нямате разрешение да я премахнете. </translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
        <translation>Разгледайте съдържанието на версия #%version_number.Превод по подразбиране: %default_translation.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Разгледайте съдържанието на версия #%version_number. Превод: %translation.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копие</translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Създайте копие на версия #%version_number.</translation>
    </message>
    <message>
        <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
        <translation>Не можете да направите копия, защото нямате права да редактирате обекта.</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Редактиратей съдържанията на версия #%version_number.</translation>
    </message>
    <message>
        <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
        <translation>Не можете да редактирате съдържанието на версия #%version_number, защото не е чернова или защото нямате права, за да редактирате обекта.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Този обект няма версии.</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Премахни избраните версии от обекта.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove versions from this object.</source>
        <translation type="obsolete">Нямаш права да премахнеш версии от обектът.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/view/versionview</name>
    <message>
        <source>Object information</source>
        <translation>Информация за обекта</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Управление на версиите</translation>
    </message>
    <message>
        <source>View and manage (copy, delete, etc.) the versions of this object.</source>
        <translation>Разглеждане и управление (копиране, изтриване, и т.н.) на версиите на този обект.</translation>
    </message>
    <message>
        <source>You can not manage the versions of this object because there is only one version available (the one that is being displayed).</source>
        <translation>Не можете да управлявате версиите на този обект, защото съществува само една версия (тази която е показана в момента).</translation>
    </message>
    <message>
        <source>Version information</source>
        <translation>Информация за версията</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Чернова</translation>
    </message>
    <message>
        <source>Published / current</source>
        <translation>Публикуван / текущ</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Предстоящ</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Архивиран</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Отхвърлен</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>View control</source>
        <translation>Котрол на прегледа</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Няма информация за мястото)</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Update view</source>
        <translation>Предлед на последните данни</translation>
    </message>
    <message>
        <source>View the version that is currently being displayed using the selected language, location and design.</source>
        <translation>Разгледайте версията, която в момента е показана и използва избрания език, местоположение и дизайн.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the draft that is being displayed.</source>
        <translation>Редактирайте черновата, която е показана.</translation>
    </message>
    <message>
        <source>This version is not a draft and thus it can not be edited.</source>
        <translation>Тази версия не е чернова и по този начин не може да бъде редактирана.</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>You do not have permissions to manage the versions of this object.</source>
        <translation>Нямате достатъчно права, за да редактирате версията на този обект.</translation>
    </message>
</context>
<context>
    <name>design/admin/contentstructuremenu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Сгъни / Разгъни</translation>
    </message>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>[%classname] Кликнете върху иконата с контекстно меню.</translation>
    </message>
</context>
<context>
    <name>design/admin/error/kernel</name>
    <message>
        <source>The requested page could not be displayed. (1)</source>
        <translation>Избраната страница не може да бъде показана. (1)</translation>
    </message>
    <message>
        <source>The system is unable to display the requested page because of security issues.</source>
        <translation>Системата не може да покаже избраната страница поради съображения за сигурност. </translation>
    </message>
    <message>
        <source>Possible reasons</source>
        <translation>Възможни причини</translation>
    </message>
    <message>
        <source>Your account does not have the proper privileges to access the requested page.</source>
        <translation>Вашият акаунт не притежава нужните права за достъп до поисканата страница.</translation>
    </message>
    <message>
        <source>You are not logged into the system. Please log in.</source>
        <translation>Не сте влезли в системата. Моля, влезте. </translation>
    </message>
    <message>
        <source>The requested page does not exist. Try changing the URL.</source>
        <translation>Избраната страница не съществува. Опитайте да смените URL.</translation>
    </message>
    <message>
        <source>The following permission setting is required</source>
        <translation>Следните настройки на права са задължителни</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Click the &quot;Log in&quot; button in order to log in.</source>
        <translation>Натиснте бутона &quot;Вход&quot;, за да влезете.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Вход</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (2)</source>
        <translation>Избраната страница не може да бъде показана. (2)</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>Източникът не беше открит.</translation>
    </message>
    <message>
        <source>The ID number or the name of the resource was misspelled. Try changing the URL.</source>
        <translation>ID номерът на името на източникна е грешно написан. Опитайте да смените URL.</translation>
    </message>
    <message>
        <source>The resource is no longer available.</source>
        <translation>Източникът не е наличен.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (20)</source>
        <translation>Избраната страница не може да бъде показана. (20)</translation>
    </message>
    <message>
        <source>The requested address or module could not be found.</source>
        <translation>Избраният адрес или модул не може да бъде намерен.</translation>
    </message>
    <message>
        <source>The address was misspelled. Try changing the URL.</source>
        <translation>Адресът е грешно написан. Опитайте да смените URL.</translation>
    </message>
    <message>
        <source>The name of the module was misspelled. Try changing the URL.</source>
        <translation>Името на модула е грешно написано. Опитайте да смените URL.</translation>
    </message>
    <message>
        <source>There is no &lt;%module&gt; module available on this site.</source>
        <translation>Няма &lt;%module&gt; наличен модул на този сайт.</translation>
    </message>
    <message>
        <source>The site is using URL matching to determine which siteaccess to use, but the name of the siteaccess is missing from the URL. Try to add the name of the siteaccess, it should be specified before the name of the module.</source>
        <translation>Уеб-страницата използва URL съвпадение, за да определи кой siteaccess да използва, но името на този siteaccess не е посочено в URL. Опитайте да добавите името на търсения siteaccess. То трябва да се укаже преди името на модула.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (21)</source>
        <translation>Избраната страница не може да бъде показана. (21)</translation>
    </message>
    <message>
        <source>The requested view &lt;%view&gt; could not be found in the &lt;%module&gt; module.</source>
        <translation>Исканият изглед &lt;%view&gt; не може да бъде открит в модула &lt;%module&gt;.</translation>
    </message>
    <message>
        <source>The name of the view was misspelled. Try changing the URL.</source>
        <translation>Името на модула е грешно написано. Опитайте да смените URL.</translation>
    </message>
    <message>
        <source>The &lt;%module&gt; module does not have a &lt;%view&gt; view.</source>
        <translation>Модулът  &lt;%module&gt; не притежава изглед &lt;%view&gt;.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (22)</source>
        <translation>Избраната страница не може да бъде показана. (22)</translation>
    </message>
    <message>
        <source>The requested view can not be accessed.</source>
        <translation>Исканият изглед не е достъпен.</translation>
    </message>
    <message>
        <source>The &lt;%view&gt; within the &lt;%module&gt; is disabled and thus it can not be accessed.</source>
        <translation>&lt;%view&gt; в &lt;%module&gt; е забранен и не е достъпен.</translation>
    </message>
    <message>
        <source>The requested module can not be accessed.</source>
        <translation>Зададеният модул не е достъпен.</translation>
    </message>
    <message>
        <source>The &lt;%module&gt; module is disabled and thus it can not be accessed.</source>
        <translation>Модулът &lt;%module&gt; е забранен и не е достъпен.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (3)</source>
        <translation>Избраната страница не може да бъде показана. (3)</translation>
    </message>
    <message>
        <source>The requested object is not available.</source>
        <translation>Исканият обект не е наличен.</translation>
    </message>
    <message>
        <source>The ID number of the object is incorrect. Please check the URL for spelling mistakes.</source>
        <translation>ID номерът на обекта не е точен. Моля проверете URL за правописни грешки.</translation>
    </message>
    <message>
        <source>The object is no longer available.</source>
        <translation>Обектът не е наличен.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (4)</source>
        <translation>Избраната страница не може да бъде показана. (4)</translation>
    </message>
    <message>
        <source>The requested object has been moved and thus it is no longer available at the specified address.</source>
        <translation>Търсеният обект е преместен и не е достъпен на посочения адрес.</translation>
    </message>
    <message>
        <source>The system should automatically redirect you to the new location of the object.</source>
        <translation>Системата трябва автоматично да ви пренасочи към новото място на обекта.</translation>
    </message>
    <message>
        <source>If redirection fails, please click on the following address: %url.</source>
        <translation>Ако пренасочването не се осъществи, кликнете върху следния адрес: %url.</translation>
    </message>
</context>
<context>
    <name>design/admin/error/shop</name>
    <message>
        <source>Not a product. (1)</source>
        <translation>Не е продукт. (1)</translation>
    </message>
    <message>
        <source>The requested object is not a product and cannot be used by the shop module..</source>
        <translation>Исканият обект не е продукт и не може да бъде използван от магазинния модул..</translation>
    </message>
</context>
<context>
    <name>design/admin/infocollector/collectionlist</name>
    <message>
        <source>Information collected by &lt;%object_name&gt; [%collection_count]</source>
        <translation>Информацията е събрана от  &lt;%object_name&gt; [%collection_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Collection ID</source>
        <translation>Събирателно ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Select collected information for removal.</source>
        <translation>Изберете събраната информация за премахване.</translation>
    </message>
    <message>
        <source>No information has been collected by this object.</source>
        <translation>Информацията не е събрана от този обект. </translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected collection.</source>
        <translation>Премахни избраната колекция.</translation>
    </message>
</context>
<context>
    <name>design/admin/infocollector/confirmremoval</name>
    <message>
        <source>Confirm information collection removal</source>
        <translation>Потвърди информация за премахване</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the collected information?</source>
        <translation>Сигурни ли сте, че искате да премахнете събраната информация?</translation>
    </message>
    <message>
        <source>%collections collection will be removed.</source>
        <translation>%collections събраната информация ще бъде премахната.</translation>
    </message>
    <message>
        <source>%collections collections will be removed.</source>
        <translation>%collections събраните информации ще бъдат премахнати.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/infocollector/overview</name>
    <message>
        <source>Objects that have collected information [%object_count]</source>
        <translation>Обекти, които имат събрана информация (%object_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>First collection</source>
        <translation>Начална събрана информация</translation>
    </message>
    <message>
        <source>Last collection</source>
        <translation>Последна събрана информация</translation>
    </message>
    <message>
        <source>Collections</source>
        <translation>Събрани информации</translation>
    </message>
    <message>
        <source>Select collections for removal.</source>
        <translation>Избери събрана информация за премахване.</translation>
    </message>
    <message>
        <source>section</source>
        <translation>секция</translation>
    </message>
    <message>
        <source>There are no objects that have collected any information.</source>
        <translation>Няма обекти, в които е събрана информация.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove all information that was collected by the selected objects.</source>
        <translation>Премахни цялата информация, която беше събрана от избраните обекти.</translation>
    </message>
</context>
<context>
    <name>design/admin/infocollector/view</name>
    <message>
        <source>Collection #%collection_id for &lt;%object_name&gt;</source>
        <translation>Събрана информация  #%collection_id за &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Remove collection.</source>
        <translation>Премахни събраната информация.</translation>
    </message>
</context>
<context>
    <name>design/admin/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Предишен</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
</context>
<context>
    <name>design/admin/node/removenode</name>
    <message>
        <source>Remove node?</source>
        <translation>Премахване на връзка?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Сигурни ли сте, че искате да премахнете %1 от стойност %2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Премахването на присвоената стойност ще премахне и нейните %1 дъщерни.</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Премахнатите забележки могат да бъдат възстановени по-късно. Можете  да ги откриеш в кошчето.</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Премахване на присвоената стойност от %1</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Бележка</translation>
    </message>
</context>
<context>
    <name>design/admin/node/removeobject</name>
    <message>
        <source>Confirm location removal</source>
        <translation>Потвърдете премахването на мястото</translation>
    </message>
    <message>
        <source>Insufficient permissions</source>
        <translation>Недостатъчни права</translation>
    </message>
    <message>
        <source>Some of the items that are about to be removed contain sub items.</source>
        <translation>Някои от елементите, които ще бъдат премахнати, съдържат поделементи.</translation>
    </message>
    <message>
        <source>Removing the items will also result in the removal of their sub items.</source>
        <translation>Премахването на елементите ще доведе до премахването на техните поделементи.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the items along with their contents?</source>
        <translation>Сигурни ли сте, че искате да премахнете елементите заедно с тяхното съдържание?</translation>
    </message>
    <message>
        <source>The lines marked with red contain items that you do not have permissions to remove.</source>
        <translation>Редовете отбелязани с червено съдържат елементи, които нямате право да премахвате.</translation>
    </message>
    <message>
        <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
        <translation>Натиснете бутона &quot;Отмени&quot; и опитате да премахнете само местата, за които имате права.</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Елемент</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Поделементи</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Премести в кошчето</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
        <translation>Не можете да продължите, защото нямате права да премахвате някои от избраните места.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Cancel the removal of locations.</source>
        <translation>Отмени премахването на местата.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>If &quot;Move to trash&quot; is checked, the items will be moved to the trash instead of being permanently deleted.</source>
        <translation>Ако &quot;Премести в кошчето&quot; е избрано, елементите ще бъдат преместени в кошчето вместо да бъдат трайно изтрити.</translation>
    </message>
    <message>
        <source>Some of the subtrees or objects selected for removal are used by other objects. Select the menu from the content tree, and &lt;strong&gt;Advanced&lt;/strong&gt;-&amp;gt;&lt;strong&gt;Reverse related for subtree&lt;/strong&gt;.</source>
        <translation>Някои от избраните за изтриване подменюта или обекти се използват в момента. Изберете менюто от съдържанието и &lt;strong&gt;Бързо&lt;/strong&gt;-&amp;gt;&lt;strong&gt;превключване за подменюто&lt;/strong&gt;.</translation>
    </message>
    <message>
        <source>Some of the objects selected for removal are used by other objects. Select the menu from the content tree, and &lt;strong&gt;Advanced&lt;/strong&gt;-&amp;gt;&lt;strong&gt;Reverse related for subtree&lt;/strong&gt;.</source>
        <translation>Някои от избраните за изтриване обекти се използват в момента. Изберете менюто от съдържанието и  &lt;strong&gt;Бързо&lt;/strong&gt;-&amp;gt;&lt;strong&gt;превключване за подменюто&lt;/strong&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view</name>
    <message>
        <source>Two level index for &lt;%node_name&gt;</source>
        <translation>Двустепенен индекс за &lt;%node_name&gt;</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/embed</name>
    <message>
        <source> - You do not have sufficient permissions to view this object</source>
        <translation>- Нямате достатъчно права, за да разгледате този обект</translation>
    </message>
    <message>
        <source>You do not have sufficient permissions to view this object</source>
        <translation>Нямате достатъчно права, за да разгледате този обект</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Hide preview of content.</source>
        <translation>Скрий преглед на съдържание.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Преглед</translation>
    </message>
    <message>
        <source>Show preview of content.</source>
        <translation>Покажи преглед на съдържание.</translation>
    </message>
    <message>
        <source>Hide available translations.</source>
        <translation>Скрий наличните преводи.</translation>
    </message>
    <message>
        <source>Show available translations.</source>
        <translation>Покажи наличните преводи.</translation>
    </message>
    <message>
        <source>Hide location overview.</source>
        <translation>Скрий общ поглед на място.</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Места</translation>
    </message>
    <message>
        <source>Show location overview.</source>
        <translation>Покажи общ поглед на място.</translation>
    </message>
    <message>
        <source>Hide relation overview.</source>
        <translation>Скрий общ поглед на връзка.</translation>
    </message>
    <message>
        <source>Relations</source>
        <translation>Връзки</translation>
    </message>
    <message>
        <source>Show relation overview.</source>
        <translation>Покажи общ поглед на връзка.</translation>
    </message>
    <message>
        <source>Hide role overview.</source>
        <translation>Скриий общ поглед на роля.</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Роли</translation>
    </message>
    <message>
        <source>Show role overview.</source>
        <translation>Покажи общ поглед на роля.</translation>
    </message>
    <message>
        <source>Hide policy overview.</source>
        <translation>Скриий общ поглед на политика.</translation>
    </message>
    <message>
        <source>Policies</source>
        <translation>Политики</translation>
    </message>
    <message>
        <source>Show policy overview.</source>
        <translation>Покажи общ поглед на политика.</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Едно ниво нагоре</translation>
    </message>
    <message>
        <source>Sub items [%children_count]</source>
        <translation>Поделементи [%children_count]</translation>
    </message>
    <message>
        <source>The current item does not contain any sub items.</source>
        <translation>Текущият елемент не съдържа никакви поделементи.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation>Премахни избраните елементи от горния списък.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove any of the items from the list above.</source>
        <translation>Нямате права да премахвате елементи от горния списък. </translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритетите</translation>
    </message>
    <message>
        <source>Apply changes to the priorities of the items in the list above.</source>
        <translation>Приложи променте на приоритетите на елементите в по-горния списък.</translation>
    </message>
    <message>
        <source>You can not update the priorities because you do not have permissions to edit the current item or because a non-priority sorting method is used.</source>
        <translation>Не можете да обновите приоритетите, защото нямате права да редактирате текущия елемент или е използван не-приоритетен метод.</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Създай тук</translation>
    </message>
    <message>
        <source>Create a new item within the current location. Use the menu on the left to select the type of the item.</source>
        <translation>Създайте нов елемент в текущото място. Използвайте менюто отляво за избиране на тип на елемента.</translation>
    </message>
    <message>
        <source>You do not have permissions to create new items within the current location.</source>
        <translation>Нямате права да създавате нови елементи в текущото място. </translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Дълбочина</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>You can not set the sorting method for the current location because you do not have permissions to edit the current item.</source>
        <translation>Не можете да определяте сортиращ метод за текущото място, защото нямате права да редактирате текущия обект.</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Use the priority fields to control the order in which the items appear. Use positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
        <translation>Използвайте приоритетните полета, за да контролирате реда на показване на обектите. Използвайте положителни и отрицателни числа. Кликнте на бутона &quot;Обнови  приоритетите&quot;, за да въведете промените.</translation>
    </message>
    <message>
        <source>You are not allowed to update the priorities because you do not have permissions to edit &lt;%node_name&gt;.</source>
        <translation>Не ви е позволено да обновите приоритетите, защото нямате права да редактирате &lt;%node_name&gt;.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копиране</translation>
    </message>
    <message>
        <source>Create a copy of &lt;%child_name&gt;.</source>
        <translation>Създай копие на &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You can not make a copy of &lt;%child_name&gt; because you do not have create permissions for &lt;%node_name&gt;.</source>
        <translation>Не можете да направите копие на &lt;%child_name&gt;, защото нямат права за създаване на &lt;%node_name&gt;.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Редактирай &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>Нямате права да редактирате &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit %child_name.</source>
        <translation>Нямате права да редактирате %child_name.</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Възел ID</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>Oбект ID</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Sorting</source>
        <translation>Сортиране</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Основен</translation>
    </message>
    <message>
        <source>up</source>
        <translation>нагоре</translation>
    </message>
    <message>
        <source>down</source>
        <translation>надолу</translation>
    </message>
    <message>
        <source>Remove selected locations from the list above.</source>
        <translation>Премахни избраните места от горния списък.</translation>
    </message>
    <message>
        <source>You can not remove any locations because you do not have permissions to edit the current item.</source>
        <translation>Не можете да премахвате места, защото нямате права да редактирате текущия обект.</translation>
    </message>
    <message>
        <source>You can not add new locations because you do not have permissions to edit the current item.</source>
        <translation>Не можете да добавяте нови места, защото нямате права за редактиране на текущия елемент.</translation>
    </message>
    <message>
        <source>Set main</source>
        <translation>Основна настройка</translation>
    </message>
    <message>
        <source>You can not set the main location because you do not have permissions to edit the current item.</source>
        <translation>Не можете да определяте основното място, защото нямате права за редактиране на настоящия обект.</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation>Нямате права да редактирате този елемент.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Премести</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Премести този елемент на друго място.</translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation>Нямате права да преместите този елемент на друго място.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Премахни този елемент.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation>Нямате право да премахнете този елемент.</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Ограничение</translation>
    </message>
    <message>
        <source>all modules</source>
        <translation>всички модули</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>всички функции</translation>
    </message>
    <message>
        <source>There are no available policies.</source>
        <translation>Няма налични политики.</translation>
    </message>
    <message>
        <source>Related objects [%related_objects_count]</source>
        <translation>Свързани обекти [%related_objects_count]</translation>
    </message>
    <message>
        <source>The item being viewed does not make use of any other objects.</source>
        <translation>Елементът, който беше видян, не се използва от другите обекти.</translation>
    </message>
    <message>
        <source>Reverse related objects</source>
        <translation type="obsolete">Обърнати свързани обекти</translation>
    </message>
    <message>
        <source>The item being viewed is not in use by any other objects.</source>
        <translation>Елементът, който беше видян, не е използван от други обекти.</translation>
    </message>
    <message>
        <source>Assigned roles [%roles_count]</source>
        <translation>Определящи роли [%roles_count]</translation>
    </message>
    <message>
        <source>No limitation</source>
        <translation>Без ограничение</translation>
    </message>
    <message>
        <source>Edit role.</source>
        <translation>Редактирай роля.</translation>
    </message>
    <message>
        <source>There are no assigned roles.</source>
        <translation>Няма определящи роли.</translation>
    </message>
    <message>
        <source>Hide details.</source>
        <translation>Скрий детайли.</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Детайли</translation>
    </message>
    <message>
        <source>Show details.</source>
        <translation>Покажи детайли.</translation>
    </message>
    <message>
        <source>Up one level.</source>
        <translation>Едно ниво нагоре.</translation>
    </message>
    <message>
        <source>Show 10 items per page.</source>
        <translation>Покажи 10 елемента на страница.</translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation>Покажи 50 елемента на страница.</translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation>Покажи 25 елемента на страница.</translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation>Покажи поделементите като списък.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Списък</translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation>Иконка</translation>
    </message>
    <message>
        <source>Display sub items using a detailed list.</source>
        <translation>Покажи поделементите като подробен списък.</translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation>Подробен</translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation>Покажи подточките като иконки.</translation>
    </message>
    <message>
        <source>Use this menu to select the type of item you wish to create and click the &quot;Create here&quot; button. The item will be created within the current location.</source>
        <translation>Използвайте това меню, за да изберете типа на обекта, който искате да създадете и натиснете бутона &quot;Създай тук&quot;. Обектът ще бъде създаден на текущото място.</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Не е наличен</translation>
    </message>
    <message>
        <source>Class identifier</source>
        <translation>Идентификатор на класа</translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Клас име</translation>
    </message>
    <message>
        <source>Use these controls to set the sorting method for the sub items of the current location.</source>
        <translation>Използвайте тези опции за определяне на сортиращия метод за поделементите на текущото място.</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Низходящ</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Възходящ</translation>
    </message>
    <message>
        <source>Visibility</source>
        <translation>Видимост</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
        <translation>Използвайте тези чек-боксове, за да изберете елементи за премахване. Натиснете бутона &quot;Премахни избраните&quot;  за премахване на избраните елементи.</translation>
    </message>
    <message>
        <source>Move &lt;%child_name&gt; to another location.</source>
        <translation>Премести &lt;%child_name&gt; на друго място.</translation>
    </message>
    <message>
        <source>You do not have permissions remove this item.</source>
        <translation>Нямате право да премахнете този елемент.</translation>
    </message>
    <message>
        <source>Locations [%locations]</source>
        <translation>Места [%locations]</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Поделементи</translation>
    </message>
    <message>
        <source>This location can not be removed either because you do not have permissions to remove it or because it is currently being displayed.</source>
        <translation>Това място не може да бъде премахнато, защото нямате права да го премахнете или защото в момента се използва.</translation>
    </message>
    <message>
        <source>Select location for removal.</source>
        <translation>Избери място за премахване.</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Скрит</translation>
    </message>
    <message>
        <source>Make location and all sub items visible.</source>
        <translation>Направи мястото и всичките му поделементи видими.</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Покажи</translation>
    </message>
    <message>
        <source>Hidden by superior</source>
        <translation>Скрит от по-висш</translation>
    </message>
    <message>
        <source>Hide location and all sub items.</source>
        <translation>Скрий мястто и всичките му поделементи.</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Скрий</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Видим</translation>
    </message>
    <message>
        <source>Use these radio buttons to select the desired main location.</source>
        <translation>Използвайте тези радио-бутони, за да изберете желаното основно място.</translation>
    </message>
    <message>
        <source>The item being displayed has only one location and thus it does not make sense to set it.</source>
        <translation>Показаният обект притежава само едно място и следователно няма нужда то да бъде избирано.</translation>
    </message>
    <message>
        <source>You can not set the main location because you do not have permissions to edit the item being displayed.</source>
        <translation>Не можете да определяте основното място, защото нямате права за редактиране на показания обект.</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Добави места</translation>
    </message>
    <message>
        <source>Add one or more new locations.</source>
        <translation>Добави едно или повече места.</translation>
    </message>
    <message>
        <source>It is not possible to add locations to a top level node.</source>
        <translation>Не е възможно да се добявят места на възел от най-горното ниво.</translation>
    </message>
    <message>
        <source>Select the desired main location using the radio buttons above and click this button to store the setting.</source>
        <translation>Изберете желаното основно място чрез горните радио-бутони и натиснете този бутон, за да съхраните настройките.</translation>
    </message>
    <message>
        <source>You can not set the main location because there is only one location present.</source>
        <translation>Не можете да определяте основното място, защото има само едно възможно място.</translation>
    </message>
    <message>
        <source>The &lt;%class_name&gt; class is not configured to contain any sub items.</source>
        <translation>Класът &lt;%class_name&gt; не е конфигуриран да съдържа поделементи.</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Редактирай съдържанието на този обект.</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Без ограничения</translation>
    </message>
    <message>
        <source>Relations [%relation_count]</source>
        <translation>Връзки [%relation_count]</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Translations [%translations]</source>
        <translation>Преводи [%translations]</translation>
    </message>
    <message>
        <source>View translation.</source>
        <translation>Виж превода.</translation>
    </message>
    <message>
        <source>Hide object relation overview.</source>
        <translation>Скрий прегледа на връзката на обекта.</translation>
    </message>
    <message>
        <source>Show object relation overview.</source>
        <translation>Покажи прегледа на връзката на обекта.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>The information could not be collected.</source>
        <translation>Тази информация не може да бъде събрана.</translation>
    </message>
    <message>
        <source>Required data is either missing or is invalid</source>
        <translation>Поисканите данни липсват или са невалидни</translation>
    </message>
    <message>
        <source>There is no removable location.</source>
        <translation>Не съществува място, което да се премахне.</translation>
    </message>
    <message>
        <source>Available policies [%policy_count]</source>
        <translation>Възможни политики [%policy_count]</translation>
    </message>
    <message>
        <source>limited to %limitation_identifier %limitation_value</source>
        <translation>Ограничено до %limitation_identifier %limitation_value</translation>
    </message>
    <message>
        <source>(disabled)</source>
        <translation>(изключен)</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Reverse related objects [%related_objects_count]</source>
        <translation>Премахни свързаните обекти [%related_objects_count]</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/line</name>
    <message>
        <source>Click on the icon to get a context sensitive menu.</source>
        <translation>Кликнете върху иконата, за да видите подробното меню.</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %node_visibility</source>
        <translation>ID на възел: %node_id Visibility: %node_visibility</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/thumbnail</name>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>Кликнете върху иконата, за да видите подробното меню.</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/addingresult</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Add to my notifications</source>
        <translation>Добави към моите съобщения</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>Съобщение за възел &lt;%node_name&gt; вече съществува. </translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>Съобщение за възел &lt;%node_name&gt; беше добавено успешно. </translation>
    </message>
</context>
<context>
    <name>design/admin/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Съобщение за сътрудничество</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Изберете за кои елементи на сътрудничество искате да получавате съобщения.</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/handler/ezgeneraldigest/settings/edit</name>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Получаване на всички съобщения, комбинирани в едно</translation>
    </message>
    <message>
        <source>Daily, at</source>
        <translation>Всекидневно, на</translation>
    </message>
    <message>
        <source>Once per week, on </source>
        <translation>Един път на седмица, за</translation>
    </message>
    <message>
        <source>If day number is larger than the number of days within the current month, the last day of the current month will be used.</source>
        <translation>Ако числото на датата е по-голямо от броя на дните в рамките на текущият месец, миналият ден на текущия месец ще бъде използван.</translation>
    </message>
    <message>
        <source>Receive digests</source>
        <translation>Получаване на дайджести</translation>
    </message>
    <message>
        <source>Once per month, on day number</source>
        <translation>Веднъж на месец, на датата</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/handler/ezsubtree/settings/edit</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>My item notifications [%notification_count]</source>
        <translation>Мои съобщения за елемент [%notification_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Избери елемент за премахване.</translation>
    </message>
    <message>
        <source>You have not subscribed to receive notifications about any items.</source>
        <translation>Вие не сте абонирани да получавате съобщения относно каквито и да е елементи.</translation>
    </message>
    <message>
        <source>Remove selected items.</source>
        <translation>Премахни избраните елементи.</translation>
    </message>
    <message>
        <source>Add items</source>
        <translation>Добави елементи</translation>
    </message>
    <message>
        <source>Add items to your personal notification list.</source>
        <translation>Добави елементи в своя списък с бележки.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/runfilter</name>
    <message>
        <source>The notification time event was spawned.</source>
        <translation>Време е за съобщение за елемент. </translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Времево събитие</translation>
    </message>
    <message>
        <source>The notification filter processed all available notification events.</source>
        <translation>Филтърът за съобщения обработи всички събития.</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Старт на филтъра на съобщенията</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/settings</name>
    <message>
        <source>My notification settings</source>
        <translation>Настройки на съобщения</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
</context>
<context>
    <name>design/admin/package</name>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Моля осигурете информация за промените.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Промени</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) at the beginning of the line. The change will continue to the next change marker.</source>
        <translation>Започнете записа с маркера ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) в началото на реда. Промяната ще е валидна до следващия маркер за промяна.</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Моля дайте основна информация за вашия пакет.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Име на пакет</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Лиценз</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Хост на пакета</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Опаковащ</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Моля дайте информация за поддържащия пакета.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Създай пакет</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Налични помощници</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Моля изберете помощник за създаването на пакет</translation>
    </message>
    <message>
        <source>Specify export properties. The default settings will most likely be suitable for your needs.</source>
        <translation>Определете export properties. Настрйките, които са по подразбиране, сигурно са подходящи за твоите цели.</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Разни</translation>
    </message>
    <message>
        <source>Include class definitions.</source>
        <translation>Включване на клас дефиниции.</translation>
    </message>
    <message>
        <source>Include templates related exported objects.</source>
        <translation>Включи темплейтите свързани с експортираните обекти.</translation>
    </message>
    <message>
        <source>Select templates from the following siteaccesses</source>
        <translation>Изберете темплейти от съответния siteaccesses</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>All versions</source>
        <translation>Всички версии</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Езици</translation>
    </message>
    <message>
        <source>Select languages to export</source>
        <translation>Избери езици за експорт</translation>
    </message>
    <message>
        <source>Node assignments</source>
        <translation>Задаване на възел</translation>
    </message>
    <message>
        <source>Keep all in selected nodes</source>
        <translation>Запази във всички избрани възли</translation>
    </message>
    <message>
        <source>Main only</source>
        <translation>Основен само</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Свързани обекти</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Никой</translation>
    </message>
    <message>
        <source>Please choose objects you wish to include in the package.</source>
        <translation>Моля изберете обекти, които искате да влючите в пакета.</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Избрани възли</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Експорт на тип</translation>
    </message>
    <message>
        <source>There are currently no objects selected for exportation</source>
        <translation>В момента няма обекти избрани за експортиране</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add subtree</source>
        <translation>Добави поддърво</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Добави възел</translation>
    </message>
    <message>
        <source>Please select the site CSS file to be included in the package.</source>
        <translation>Моля изберете CSS сайт файл за включване в пакета.</translation>
    </message>
    <message>
        <source>Please select the classes CSS file to be included in the package.</source>
        <translation>Моля изберете CSS класове файл за включване в пакета.</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
Click &quot;Next&quot; without choosing an image to continue to the next step.</source>
        <translation>Изберете картина за включване в пакета и натиснете &quot;Следващ&quot;.
Натиснете &quot;Следващ&apos;, без да избирате картинка за продължаване към следващата стъпка.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Добавени файлове с картинки</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Помощник за пакет %wizardname</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Инсталирай пакет</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>Този пакет може да бъде изсталиран на вашата система, инсталирането ще копира файлове, ще създаде класове и т.н. в зависимост от пакета.
Ако не искате да изсталирате пакета сега, можете да го направиш по-късно и на страницата за разглеждане на пакета.</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Инсталирай елементи</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Пропусни инсталацията</translation>
    </message>
    <message>
        <source>Package install wizard: %wizardname</source>
        <translation>Помощник за инсталиране на пакет %wizardname</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Следващ %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Край</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Качване на пакет</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Изберете съдържанието на файл на пакет и натиснете бутона за качване</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Импортиране на пакет</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Инсталиран</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>Не е инсталиран</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Импортиран</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Файлове [%collectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Детайли</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталация</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Инсталация</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Експорт във файл</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Поддържащи</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>Относно  eZ publish пакет  &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send e-mail to the maintainer</source>
        <translation>Изпрати е-мейл на поддържащия</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Документи</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Лог с промени</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Списък с файлове</translation>
    </message>
    <message>
        <source>Uninstall package</source>
        <translation>Деинсталирай пакет</translation>
    </message>
    <message>
        <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
        <translation>Пакетът може да се деинсталира от системата. Деинсталирането на пакета ще премахне всички инсталирани файлове, класове обекти и т.н. свързани с пакета.(new line)
Ако не желаете да деинсталираш пакета сега, можете да го направите по-късно на страницата за разглеждане на пакета.(new line)
Можете да премахнеште пакета, без да го деинсталирате от списъка с пакети.</translation>
    </message>
    <message>
        <source>Uninstall items</source>
        <translation>Деинсталирай елементи</translation>
    </message>
    <message>
        <source>Skip uninstallation</source>
        <translation>Пропусни деинсталацията</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/package/list</name>
    <message>
        <source>Remove section?</source>
        <translation>Премахни секция?</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Премахване на пакети</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>Сигурни ли сте, че искате да премахнете следните пакети?
Тези пакети ще бъдат завинаги загубени.
Забележка: Пакетите няма да бъдат деинсталирани.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Package removal was canceled.</source>
        <translation>Премахването на пакет беше отменено.</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Пакети</translation>
    </message>
    <message>
        <source>Repository</source>
        <translation>Съхраняване на данни</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Change repository</source>
        <translation>Промени съхраняваните данни</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Инсталиран</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>Не е инсталиран</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Импортиран</translation>
    </message>
    <message>
        <source>There are no packages matching the selected repository.</source>
        <translation>Няма пакети, съвпадащи с избраните съхранени данни.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Import new package</source>
        <translation>Импортиране на нов пакет</translation>
    </message>
    <message>
        <source>Create new package</source>
        <translation>Създай нов пакет</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Цяло съдържание</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>Текущо място</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>Същото място</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Напреднал</translation>
    </message>
    <message>
        <source>Content structure</source>
        <translation>Съдържание на структура</translation>
    </message>
    <message>
        <source>Media library</source>
        <translation>Медийна библиотека</translation>
    </message>
    <message>
        <source>User accounts</source>
        <translation>Потребителски акаунти</translation>
    </message>
    <message>
        <source>Webshop</source>
        <translation>Web магазин</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Дизайн</translation>
    </message>
    <message>
        <source>My account</source>
        <translation>Мой акаунт</translation>
    </message>
    <message>
        <source>Current user</source>
        <translation>Текущ потребител</translation>
    </message>
    <message>
        <source>Change information</source>
        <translation>Промени информация</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Изход</translation>
    </message>
    <message>
        <source>Change user info</source>
        <translation>Промени информация за потребител</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Бележки</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Търси цялото съдържание.</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Търси само от текущото място.</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Разширено търсене.</translation>
    </message>
    <message>
        <source>Manage the main content structure of the site.</source>
        <translation>Управление на главното съдържание на структурата на сайта.</translation>
    </message>
    <message>
        <source>Manage images, files, documents, etc.</source>
        <translation>Управление на картинки, файлове, документи, пр.</translation>
    </message>
    <message>
        <source>Manage users, user groups and permission settings.</source>
        <translation>Управление на потребители, потребителски групи и настройки за правата.</translation>
    </message>
    <message>
        <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
        <translation>Управление на клиенти, поръчки. отстъпки и типове ДДС; виж статистики за продажби.</translation>
    </message>
    <message>
        <source>Manage templates, menus, toolbars and other things related to appearence.</source>
        <translation>Управление на шаблони, менюта, тулбарове и други неща свързани с изглед.</translation>
    </message>
    <message>
        <source>Configure settings and manage advanced functionality.</source>
        <translation>Оформяне настройките и специално управление на функционалността.</translation>
    </message>
    <message>
        <source>Manage items and settings that belong to your account.</source>
        <translation>Управление на елементи и настройки, които принадлежат на твоя акаунт.</translation>
    </message>
    <message>
        <source>Change name, e-mail, password, etc.</source>
        <translation>Промени име, е-мейл, парола, т.н.</translation>
    </message>
    <message>
        <source>Change password for &lt;%username&gt;.</source>
        <translation>Промени парола за &lt;%username&gt;.</translation>
    </message>
    <message>
        <source>There is %basket_count item in the shopping basket.</source>
        <translation>В количката има %basket_count елемент.</translation>
    </message>
    <message>
        <source>Shopping basket (%basket_count)</source>
        <translation>Кошница (%basket_count)</translation>
    </message>
    <message>
        <source>There are %basket_count items in the shopping basket.</source>
        <translation>В кошницата има %basket_count елементи.</translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation>Изход от системата.</translation>
    </message>
    <message>
        <source>Hide bookmarks.</source>
        <translation>Скрий бележки.</translation>
    </message>
    <message>
        <source>Manage your personal bookmarks.</source>
        <translation>Управление на вашите лични отметки.</translation>
    </message>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>[%classname] Кликнте върху иконата, за да видите подробно меню.</translation>
    </message>
    <message>
        <source>Show bookmarks.</source>
        <translation>Покажи бележки.</translation>
    </message>
    <message>
        <source>Add to bookmarks</source>
        <translation>Добави в бележки</translation>
    </message>
    <message>
        <source>Add the current item to your bookmarks.</source>
        <translation>Добавете текущия елемент във вашите бележки.</translation>
    </message>
    <message>
        <source>Hide clear cache menu.</source>
        <translation>Скрий изчистване на кеш меню.</translation>
    </message>
    <message>
        <source>Cache management page</source>
        <translation>Кеш управление на страница</translation>
    </message>
    <message>
        <source>Clear cache</source>
        <translation>Изчистване на кеш</translation>
    </message>
    <message>
        <source>Show clear cache menu.</source>
        <translation>Покажи кеш меню за изчистване.</translation>
    </message>
    <message>
        <source>Quick settings</source>
        <translation>Бързи настройки</translation>
    </message>
    <message>
        <source>Hide quick settings</source>
        <translation>Кошче</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/content/menu</name>
    <message>
        <source>Content structure</source>
        <translation>Съдържание на структура</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Малък</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Среден</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Голям</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Разглеждане и управление на съдържанията на кошчето.</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Промени ширината на лявото меню в малък формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Промени ширината на лявото меню в среден формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Промени ширината на лявото меню в голям формат.</translation>
    </message>
    <message>
        <source>Hide content structure.</source>
        <translation>Скрий съдържанието на структурата.</translation>
    </message>
    <message>
        <source>Show content structure.</source>
        <translation>Покажи съдържанието на структурата.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/media/menu</name>
    <message>
        <source>Media library</source>
        <translation>Медийна библиотека</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Малък</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Среден</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Голям</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Разглеждане и управление на съдържанията на кошчето.</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Промени ширината на лявото меню в малък формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Промени ширината на лявото меню в среден формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Промени ширината на лявото меню в голям формат.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/my/menu</name>
    <message>
        <source>My notification settings</source>
        <translation>Мои настройки на съобщения</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои бележки</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Съдействие</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>My account</source>
        <translation>Мой акаунт</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои чернови</translation>
    </message>
    <message>
        <source>My pending items</source>
        <translation>Моите чакащи елементи </translation>
    </message>
    <message>
        <source>My shopping basket</source>
        <translation>Моята кошница</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation> Моят списък с желания</translation>
    </message>
    <message>
        <source>Edit mode settings</source>
        <translation>Редактирай настройки на режим</translation>
    </message>
    <message>
        <source>on</source>
        <translation>включено</translation>
    </message>
    <message>
        <source>Disable location window when editing content.</source>
        <translation>Изключи прозорец по време на редактиране на съдържание.</translation>
    </message>
    <message>
        <source>off</source>
        <translation>изключено</translation>
    </message>
    <message>
        <source>Enable location window when editing content.</source>
        <translation>Включи прозорец по време на редактиране на съдържание.</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Места</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/setup/menu</name>
    <message>
        <source>Cache management</source>
        <translation>Кеш управление</translation>
    </message>
    <message>
        <source>Search statistics</source>
        <translation>Търси статистика</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Системна информация</translation>
    </message>
    <message>
        <source>URL management</source>
        <translation>URL управление</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL преводач</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Класове</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Разширения</translation>
    </message>
    <message>
        <source>Ini settings</source>
        <translation>Ini настройки</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>PDF export</source>
        <comment>PDF export</comment>
        <translation>Експорт в PDF </translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Пакети</translation>
    </message>
    <message>
        <source>RAD</source>
        <comment>Rapid Application Development</comment>
        <translation>Бърза разработка на приложения</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>Просто обединяване</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Сесии</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Тригери</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Работни потоци</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Roles and policies</source>
        <translation>Роли и политики</translation>
    </message>
    <message>
        <source>Upgrade check</source>
        <translation>Проверка на подобряване</translation>
    </message>
    <message>
        <source>Global settings</source>
        <translation>Глобални настройки</translation>
    </message>
    <message>
        <source>Collected information</source>
        <translation>Събрана информация</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/shop/menu</name>
    <message>
        <source>Customers</source>
        <translation>Клиенти</translation>
    </message>
    <message>
        <source>Discounts</source>
        <translation>Отстъпки</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>Поръчки</translation>
    </message>
    <message>
        <source>Product statistics</source>
        <translation>Статистики на продукти</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типове ДДС</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Магазин</translation>
    </message>
    <message>
        <source>Order status</source>
        <translation>Статус на поръчка</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/user/menu</name>
    <message>
        <source>User accounts</source>
        <translation>Потребителски акаунти</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Малък</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Среден</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Голям</translation>
    </message>
    <message>
        <source>Manage permission settings.</source>
        <translation>Управление на настройките на правата.</translation>
    </message>
    <message>
        <source>Roles and policies</source>
        <translation>Роли и политики</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Разглеждане и управление на съдържанията на кошчето.</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Промени ширината на лявото меню в малък формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Промени ширината на лявото меню в среден формат.</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Промени ширината на лявото меню в голям формат.</translation>
    </message>
    <message>
        <source>Role information</source>
        <translation>Информация за роля</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Access control</source>
        <translation>Контрол за достъп</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/visual/menu</name>
    <message>
        <source>Design</source>
        <translation>Дизайн</translation>
    </message>
    <message>
        <source>Menu management</source>
        <translation>Управление на меню</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на Меню инструменти</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Шаблони</translation>
    </message>
    <message>
        <source>Look and feel</source>
        <translation>Външен вид</translation>
    </message>
</context>
<context>
    <name>design/admin/pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>Експорт в PDF </translation>
    </message>
    <message>
        <source>%pdf_export_title [PDF export]</source>
        <translation>%pdf_export_title (експорт в PDF)</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заглавие</translation>
    </message>
    <message>
        <source>Display frontpage</source>
        <translation> Покажи начална страница</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Въвеждащ текст</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Подтекст</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Възел на източника</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Разгледай</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Експорт на структурата</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Дърво</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Начална страница</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>There is no source node.</source>
        <translation>Няма възел на източника.</translation>
    </message>
    <message>
        <source>Export classes (if exporting a tree)</source>
        <translation>Експорт на класове (ако експортирате дърво)</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Експорт на тип</translation>
    </message>
    <message>
        <source>Generate once</source>
        <translation>Генериран веднъж</translation>
    </message>
    <message>
        <source>Generate on the fly</source>
        <translation>Ако бъде генериран в движение</translation>
    </message>
    <message>
        <source>Filename (if generated on the fly)</source>
        <translation>Име на файл (ако бъде генериран в движение)</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
</context>
<context>
    <name>design/admin/pdf/list</name>
    <message>
        <source>PDF Exports [%export_count]</source>
        <translation>Експорт в PDF [%export_count]</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>Експорт в PDF </translation>
    </message>
    <message>
        <source>There are no PDF exports in the list.</source>
        <translation>Няма експорт в PDF от списъка.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Select PDF export for removal.</source>
        <translation>Избери експорт в PDF за премахване.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the &lt;%pdf_export_name&gt; PDF export.</source>
        <translation>Редактирай експорт в PDF &lt;%pdf_export_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected PDF exports.</source>
        <translation>Премахни избраните PDF.</translation>
    </message>
    <message>
        <source>New PDF export</source>
        <translation>Нов експорт в PDF</translation>
    </message>
    <message>
        <source>Create a new PDF export.</source>
        <translation>Създай нов експорт в PDF.</translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копиране</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Премести</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Напреднал</translation>
    </message>
    <message>
        <source>Expand</source>
        <translation>Разгъни</translation>
    </message>
    <message>
        <source>Collapse</source>
        <translation>Сгъни</translation>
    </message>
    <message>
        <source>Add to my bookmarks</source>
        <translation>Добави в бележки</translation>
    </message>
    <message>
        <source>Add to my notifications</source>
        <translation>Добави към мои съобщения</translation>
    </message>
    <message>
        <source>Swap with another node</source>
        <translation>Размени с друг възел 

</translation>
    </message>
    <message>
        <source>Hide / unhide</source>
        <translation>Скрий / Покажи</translation>
    </message>
    <message>
        <source>View index</source>
        <translation>Виж индекс</translation>
    </message>
    <message>
        <source>View class</source>
        <translation>Виж клас</translation>
    </message>
    <message>
        <source>Edit class</source>
        <translation>Редактирай клас</translation>
    </message>
    <message>
        <source>Delete view cache</source>
        <translation>Изтрий изглед на кеш</translation>
    </message>
    <message>
        <source>Delete template cache</source>
        <translation>Изтрий кеш на шаблона</translation>
    </message>
    <message>
        <source>Delete view cache from here</source>
        <translation>Изтрий изглед на кеш оттук 
</translation>
    </message>
    <message>
        <source>Template overrides</source>
        <translation>Препокриване на шаблони</translation>
    </message>
    <message>
        <source>New class override</source>
        <translation>препокриване на нов клас</translation>
    </message>
    <message>
        <source>New node override</source>
        <translation>Препокриване на нов възел</translation>
    </message>
    <message>
        <source>Copy Subtree</source>
        <translation>Копирай поддърво</translation>
    </message>
    <message>
        <source>Remove bookmark</source>
        <translation>Премахни бележки</translation>
    </message>
    <message>
        <source>Choose SiteAccess</source>
        <translation>Избери SiteAccess</translation>
    </message>
    <message>
        <source>Reverse related for subtree</source>
        <translation>Превключване за подменюто</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/article</name>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Comments allowed</source>
        <translation>Приети коментари</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/company</name>
    <message>
        <source>Contact information</source>
        <translation>Информация за контакт</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Допълнителна информация</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Контакти</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/feedbackform</name>
    <message>
        <source>Your E-mail address</source>
        <translation>Вашият e-mail адрес</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Recipient</source>
        <translation>Получател</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/folder</name>
    <message>
        <source>Show children</source>
        <translation>Покажи дъщерен</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/person</name>
    <message>
        <source>Contact information</source>
        <translation>Информация за контакт</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Коментари</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/poll</name>
    <message>
        <source>Result</source>
        <translation>Резултат</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/product</name>
    <message>
        <source>Download this product sheet as PDF</source>
        <translation>Свали брошурата за продукта като PDF</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Хората, които купиха този продукт, също купиха</translation>
    </message>
</context>
<context>
    <name>design/admin/role/assign_limited_section</name>
    <message>
        <source>Select section</source>
        <translation>Избери секция</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>There are no sections on the system.</source>
        <translation>Няма секции в системата.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep1</name>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Създай нова политика за ролята &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you create a new policy which will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Добре дошли в помощника за политики. Този помощник има три стъпки и ще ви помогне да създадете нова политика, която ще бъде добавена към редактираната роля. Помощникът може да бъде спрян чрез бутона &quot;Отмениl&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module</source>
        <translation>Първа стъпка: изберете модул</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Инструкции</translation>
    </message>
    <message>
        <source>Use the drop-down menu to select the module that you wish to grant access to.</source>
        <translation>Използвайте падащото меню за избиране на модул, за който искате разрешение за достъп.</translation>
    </message>
    <message>
        <source>Click one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
        <translation>Кликнете върху &quot;Разрешавам..&quot; бутоните (обяснени по-надолу) за отиване към следващата стъпка.</translation>
    </message>
    <message>
        <source>The &quot;Grant access to all functions&quot; button will create a policy that grants unlimited access to all functions of the selected module. If you wish to limit the access method to a specific function, use the &quot;Grant access to a function&quot; button. Please note that function limitation is only supported by some modules (the next step will reveal if it works or not).</source>
        <translation>Бутонът &quot;Разреши достъп до всички функции&quot; ще създаде политика, която дава неограничен достъп до всички функции на избрания модул. Ако искате да ограничите метода за достъп до специфична функция, използувайте бутона &quot;Разреши достъп до една функция&quot;. Моля, имайте предвид, че ограничението за функцията се поддържа само от няколко модула (следващата стъпка ще покаже, дали то работи или не). 
</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Всеки модул</translation>
    </message>
    <message>
        <source>Grant access to all functions</source>
        <translation>Разреши достъп до всички функции</translation>
    </message>
    <message>
        <source>Grant access to one function</source>
        <translation>Разреши достъп до една функция</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep2</name>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Добре дошли в помощника за политики. Този помощник има три стъпки и ще ви помогне да създадете нова политика, която ще бъде добавена към редактираната роля. Помощникът може да бъде спрян чрез бутона &quot;Отмениl&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module [completed]</source>
        <translation>Първа стъпка: изберете модул (завършено)</translation>
    </message>
    <message>
        <source>Selected module</source>
        <translation>Избран модул</translation>
    </message>
    <message>
        <source>All modules</source>
        <translation>Всички модули</translation>
    </message>
    <message>
        <source>Selected access method</source>
        <translation>Избери метод за достъп</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ограничен</translation>
    </message>
    <message>
        <source>Step two: select function</source>
        <translation>Втора стъпка: изберете функция</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Инструкции</translation>
    </message>
    <message>
        <source>Use the drop-down menu to select the function that you wish to grant access to.</source>
        <translation>Използвайте падащото меню за избиране на модул, за който искате разрешение за достъп.</translation>
    </message>
    <message>
        <source>The &quot;Grant full access&quot; button will create a policy that grants unlimited access to the selected function within the module that was specified in step one. If you wish to limit the access method in some way, click the &quot;Grant limited access&quot; button. Function limitation is only supported by some functions. If unsupported, eZ publish will simply set up a policy with unlimited access to the selected function.</source>
        <translation>Бутонът &quot;Разреши пълен достъп&quot; ще създаде политика, която дава неограничен достъп до избраната функция в модула избран в първата стъпка. Ако искате да ограничите метода за достъп по някакъв начин, използвайте бутона &quot;Разреши ограничен достъп&quot;. Ограничението на функциите се поддържа само за определени функции. Ако избраната функция не може да се ограничи, eZ ще настрои политика с неограничен достъп за избраната функция.</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Grant full access</source>
        <translation>Разреши пълен достъп</translation>
    </message>
    <message>
        <source>Grant limited access</source>
        <translation>Разреши ограничен достъп</translation>
    </message>
    <message>
        <source>It is unfortunately not possible to grant limited access to all modules at once. To grant unlimited access to all modules and their functions, go back to step one and select &quot;Grant access to all functions&quot;. In order to grant limited access to different functions within different modules, you need to set up a collection of policies.</source>
        <translation>Не е възможно наведнъж да бъде предоставен ограничен достъп до всички модули. За да осигурите неограничен достъп до всичките модули и техните функции, трябва да се върнете в стъпка първа и да изберете &quot;Позволи достъп до всички функции&quot;. За да предоставите ограничен достъп до различни функции в определени модули, е нужно да настроите списък от политики.</translation>
    </message>
    <message>
        <source>The selected module (%module_name) does not support limitations on the function level. Please go back to step one and use the &quot;Grant access to all functions&quot; option instead.</source>
        <translation>Избраният модул (%module_name) не поддържа ограничения на ниво функция. Моля, върнете се обратно една стъпка и използвайте опцията &quot;Позволи достъп до всички функции&quot;.</translation>
    </message>
    <message>
        <source>Go back to step one</source>
        <translation> Обратно към първа стъпка</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Създай нова политика за ролята &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Click on one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
        <translation>Кликнете върху &quot;Разрешавам..&quot; бутоните (обяснени по-надолу), за да отидете на следващата стъпка.</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep3</name>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Създай нова политика за ролята &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Добре дошли в помощника за политики. Този помощник има три стъпки и ще ви помогне да създадете нова политика, която ще бъде добавена към редактираната роля. Помощникът може да бъде спрян чрез бутона &quot;Отмениl&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module [completed]</source>
        <translation>Първа стъпка: изберете модул (завършено)</translation>
    </message>
    <message>
        <source>Selected module</source>
        <translation>Избран модул</translation>
    </message>
    <message>
        <source>All modules</source>
        <translation>Всички модули</translation>
    </message>
    <message>
        <source>Selected access method</source>
        <translation>Избери метод за достъп</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ограничен</translation>
    </message>
    <message>
        <source>Step two: select function [completed]</source>
        <translation>Втора стъпка: изберете функция (завършено)</translation>
    </message>
    <message>
        <source>Selected function</source>
        <translation>Избери функция</translation>
    </message>
    <message>
        <source>Step three: set function limitations</source>
        <translation>Трета стъпка: Поставете ограничения за функцията</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Инструкции</translation>
    </message>
    <message>
        <source>Set the desired function limitations using the controls below.</source>
        <translation>Поставете ограничения за желаната функция, използвайки контролите по-долу.
</translation>
    </message>
    <message>
        <source>Click the &quot;OK&quot; button to finish the wizard. The policy will be added to the role that is currently being edited.</source>
        <translation>Изберете бутон &quot;ОК&quot; за затваряне на помощника. Политиката ще бъде добавена към ролята, която беше редактирана.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Nodes [%node_count]</source>
        <translation>Възли [%node_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>The node list is empty.</source>
        <translation>Списъкът на възела е празен.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add nodes</source>
        <translation>Добави възли</translation>
    </message>
    <message>
        <source>Subtrees [%subtree_count]</source>
        <translation>Поддървета (%subtree_count]</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Поддърво</translation>
    </message>
    <message>
        <source>The subtree list is empty.</source>
        <translation>Списъкът на поддървото е празен.</translation>
    </message>
    <message>
        <source>Add subtrees</source>
        <translation>Добави поддървета</translation>
    </message>
    <message>
        <source>Go back to step one</source>
        <translation> Обратно към първа стъпка</translation>
    </message>
    <message>
        <source>Go back to step two</source>
        <translation> Обратно към втора стъпка</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/role/edit</name>
    <message>
        <source>Edit &lt;%role_name&gt; [Role]</source>
        <translation>Редактирай &lt;%role_name&gt; (Роля)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Policies</source>
        <translation>Политики</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Без ограничения</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Select policy for removal.</source>
        <translation>Избери политика за премахване.</translation>
    </message>
    <message>
        <source>all modules</source>
        <translation>всички модули</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>всички функции</translation>
    </message>
    <message>
        <source>Edit the policy&apos;s function limitations.</source>
        <translation>Редактирай ограниченията за функцията на политиката.</translation>
    </message>
    <message>
        <source>There are no policies set up for this role.</source>
        <translation>Няма политики, инсталирани за тази роля.</translation>
    </message>
    <message>
        <source>Remove selected policies.</source>
        <translation>Премахни избраните политики.</translation>
    </message>
    <message>
        <source>New policy</source>
        <translation>Нова политика</translation>
    </message>
    <message>
        <source>Create a new policy.</source>
        <translation>Създай нова политика.</translation>
    </message>
</context>
<context>
    <name>design/admin/role/list</name>
    <message>
        <source>Roles [%role_count]</source>
        <translation>Роли [%role_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected roles.</source>
        <translation>Премахни избраните роли.</translation>
    </message>
    <message>
        <source>New role</source>
        <translation>Нова роля</translation>
    </message>
    <message>
        <source>Create a new role.</source>
        <translation>Създай нова роля.</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Включи селекцията</translation>
    </message>
    <message>
        <source>Select role for removal.</source>
        <translation>Избери роля за премахване.</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Прехвърли</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
        <translation>Прехвърли ролята &lt;%role_name&gt; на потребител или група на потребител.</translation>
    </message>
    <message>
        <source>Edit the &lt;%role_name&gt; role.</source>
        <translation>Редактирай ролята &lt;%role_name&gt;.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копиране</translation>
    </message>
    <message>
        <source>Copy the &lt;%role_name&gt; role.</source>
        <translation>Копирай ролята &lt;%role_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/role/policyedit</name>
    <message>
        <source>Edit &lt;%policy_name&gt; policy for &lt;%role_name&gt; role</source>
        <translation>Редактирай политика &lt;%policy_name&gt; за роля &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Function limitations</source>
        <translation>Ограничения за функция</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Nodes [%node_count]</source>
        <translation>Възли [%node_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>The node list is empty.</source>
        <translation>Списъкът на възела е празен.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add nodes</source>
        <translation>Добави възли</translation>
    </message>
    <message>
        <source>Subtrees [%subtree_count]</source>
        <translation>Поддървета (%subtree_count]</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Поддърво</translation>
    </message>
    <message>
        <source>The subtree list is empty.</source>
        <translation>Списъкът на поддървото е празен.</translation>
    </message>
    <message>
        <source>Add subtrees</source>
        <translation>Добави поддървета</translation>
    </message>
    <message>
        <source>The function limitations of this policy can not be edited. This is either because the function simply does not support limitations or because the function was assigned without limitations when the policy was created.</source>
        <translation>Ограниченията на функцията на тази политика не могат да бъдат редактирани. Това се получава, защото функцията не поддържа ограничения или защото е била определена без ограничения, когато политиката е била създадена.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/role/view</name>
    <message>
        <source>all modules</source>
        <translation>всички модули</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>всички функции</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>%role_name [Role]</source>
        <translation>%role_name (Роля)</translation>
    </message>
    <message>
        <source>Policies [%policies_count]</source>
        <translation>Политики [%policy_count]</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Без ограничения</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit this role.</source>
        <translation>Редактирай тази роля.</translation>
    </message>
    <message>
        <source>Users and groups using the &lt;%role_name&gt; role [%users_count]</source>
        <translation>Потребители и групи ползващи ролята &lt;%role_name&gt; [%users_count]</translation>
    </message>
    <message>
        <source>User/group</source>
        <translation>Потребител/група</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Ограничение</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Прехвърли</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Поддърво</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>There are no policies set up for this role.</source>
        <translation>Няма политики, инсталирани за тази роля.</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Включи селекцията</translation>
    </message>
    <message>
        <source>Select user or user group for removal.</source>
        <translation>Избери потребител или група потребители за премахване.
</translation>
    </message>
    <message>
        <source>This role is not assigned to any users or user groups.</source>
        <translation>Тази роля не е прехвърлена на каквито и да е потребители или групи потребители.
 </translation>
    </message>
    <message>
        <source>Remove selected users and/or user groups.</source>
        <translation>Премахни избраните потребители и/или групи от потребители.</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
        <translation>Прехвърли ролята &lt;%role_name&gt; на потребител или група потребители.</translation>
    </message>
    <message>
        <source>Select limitation.</source>
        <translation>Избери ограничение.</translation>
    </message>
    <message>
        <source>Assign with limitation</source>
        <translation>Прехвърли с ограничение</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role with limitation (specified to the left) to a user or a user group.</source>
        <translation>Прехвърли ролята &lt;%role_name&gt; с ограничение (определено отляво) на потребител или група потребители.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_destination</name>
    <message>
        <source>Choose a destination for RSS import</source>
        <translation>Избери предназначение за импортиране на RSS</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a destination location for RSS import and click &quot;OK&quot;.</source>
        <translation>Използвайте бутоните, да изберете местоположение на предназначението за импортиране на RSS и натиснете &quot;OK&quot;.
</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_image</name>
    <message>
        <source>Choose image for RSS export</source>
        <translation>Избери изображение за RSS експорт</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose an image to use in the RSS export and click &quot;OK&quot;.</source>
        <translation>Използвайте бутоните, да изберете изображение за експорт на RSS и натиснете &quot;OK&quot;.
</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_source</name>
    <message>
        <source>Choose source for RSS export</source>
        <translation>Избери източник за RSS експорт</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the item that you wish to export using RSS and click &quot;OK&quot;.</source>
        <translation>Използвайте бутоните, да избере местоположение на елемента, който желаете да експортирате на RSS и натиснете &quot;OK&quot;.
</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_user</name>
    <message>
        <source>Choose owner for RSS imported objects</source>
        <translation>Избери собственик за RSS внесени обекти</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a user and click &quot;OK&quot;. The user will become the owner of the objects that were imported using RSS.</source>
        <translation>Използвайте бутоните за избиране на потребител и кликни &quot;OK&quot;. Потребителят ще стане собственик на обектите, които бяха внесени използувайки RSS.
</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Използвайте бутоните за избиране на потребител и натиснете &quot;OK&quot;. Потребителят ще стане собственик на обектите, които бяха внесени чрез RSS.
</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_export</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>Уеб адрес на сайта</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Разгледай</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>RSS версия</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>Уеб адрес за достъп</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Пътека на източник</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заглавие</translation>
    </message>
    <message>
        <source>Remove this source</source>
        <translation>Премахни този източник</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Edit &lt;%rss_export_name&gt; [RSS Export]</source>
        <translation>Редактирай &lt;%rss_export_name&gt; (RSS Експорт)</translation>
    </message>
    <message>
        <source>Name of the RSS export. This name is used in the administration interface only, to distinguish the different exports from each other.</source>
        <translation>Име на RSS експорта. Това име е използвано само в административния интерфейс за различаване на отделните експорти един от друг.
</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining what users can expect from the RSS export.</source>
        <translation>Използувайте полето за описание, за да напишете текст за обяснение на това, което потребителите могат да очакват от експорта на RSS.
</translation>
    </message>
    <message>
        <source>Click this button to select an image for the RSS export. Note that images only work with RSS version 2.0</source>
        <translation>Натиснете този бутон, за да изберете изображение за RSS експорта. Имайте предвид, че изображенията работят само с версия на RSS 2.0
</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the RSS version to use for the export. You must select RSS 2.0 in order to export the image selected above.</source>
        <translation>Използвайте това падащо меню, за да изберете RSS версията за експорт. Трябва да изберете RSS 2.0, за да експортирате изображението, което е избрано по-горе.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the RSS export is active or not. An inactive export will not be automatically updated.</source>
        <translation>Използвайте този чек-бокс за активиране или деактивиране на експорта на RSS. Неактивен експорт няма да бъде обновен автоматично.

</translation>
    </message>
    <message>
        <source>Use this field to set the URL where the RSS export should be available. Note that &quot;rss/feed/&quot; will be appended to the real URL. </source>
        <translation>Използвайте това поле, за да настроите уеб адреса, където експортът на RSS трябва да бъде наличен. Имайте предвид, че &quot;RSS/подхранващ/&quot; ще бъде добавен към реалния уеб адрес.</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Източник</translation>
    </message>
    <message>
        <source>Click this button to select the source node for RSS export source. Objects of the type selected in the drop down below published as sub-items of the selected node will be included in the RSS export.</source>
        <translation>Натиснете този бутон, за да изберете възела на източника за експорт на RSS. Обекти на вида, избрани по-долу, публикувани като поделементи на избрания възел, ще бъдат включени в експорта на RSS.
</translation>
    </message>
    <message>
        <source>Use this drop down to select the type of object that triggers the export. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
        <translation>Използвайте това падащо меню, за да изберете вида на обекта, който активира експорта. Натиснете бутона &quot; Настройка&quot;, за да заредите видовете на правилния атрибут за останалите полета.</translation>
    </message>
    <message>
        <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
        <translation>Натиснете този бутон, за да заредите правилните стойности в падащите менюта по-долу. Използвайте падащото меню вляво, за да изберете правилния вид на класа.</translation>
    </message>
    <message>
        <source>Use this drop-down to select which attribute that should be exported as the title of the RSS export entry.</source>
        <translation>Използвайте това падащо меню, за да изберете кой атрибут трябва да бъде експортиран като заглавие за експортиране на RSS.
</translation>
    </message>
    <message>
        <source>Use this drop-down to select which attribute that should be exported as the description of the RSS export entry.</source>
        <translation>Използвайте това падащо меню, за да изберете кой атрибут трябва да бъде експортиран като описание за експортиране на RSS.
</translation>
    </message>
    <message>
        <source>Click to remove this source from the RSS export.</source>
        <translation>Кликнете, за да премахнете този източник от експорта на RSS.</translation>
    </message>
    <message>
        <source>Add source</source>
        <translation>Добави източник</translation>
    </message>
    <message>
        <source>Click to add a new source to the RSS export.</source>
        <translation>Кликниете, за да прибавите нов източник към експорта на RSS.</translation>
    </message>
    <message>
        <source>Apply the changes and return to the RSS overview.</source>
        <translation>Приложи промените и се върни към прегледа на RSS.</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the RSS overview.</source>
        <translation>Отмени промените и се върни към прегледа на RSS.</translation>
    </message>
    <message>
        <source>Invalid Input</source>
        <translation>Невалидни входни данни</translation>
    </message>
    <message>
        <source>If RSS Export is Active then a valid Access URL is required.</source>
        <translation>Ако експортът на RSS е активен, тогава е необходим уеб адрес за валиден достъп.</translation>
    </message>
    <message>
        <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
        <translation>Използвайте това поле, за да въведете основния уеб адрес на вашия сайт. То се използва, за да произвежда уеб адресите в експорта, съставен до уеб адреса на сайта
 ( т.е.&quot; http://www.example.com/index.php&quot;) и пътя към обекта ( т.е.&quot; / артикули /моят артикул &quot;). Уеб адресът на сайта зависи от вашия Уебсървър и публината конфигурация на EZ.
</translation>
    </message>
    <message>
        <source>Number of objects</source>
        <translation>Брой обекти</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
        <translation>Използвайте падащото меню за избиране на максимален брой обекти включени в RSS източник.</translation>
    </message>
    <message>
        <source>Main node only</source>
        <translation>Основен възел</translation>
    </message>
    <message>
        <source>Check if you want to only feed the object from the main node.</source>
        <translation>Проверете, ако искате да само захраните обекта от главния възел.</translation>
    </message>
    <message>
        <source>Subnodes</source>
        <translation>Подвъзли</translation>
    </message>
    <message>
        <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
        <translation>Активирайте този чек-бокс, ако трябва да бъдат попълнени също обекти от подвъзлите на източника.
</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Премахни картинка</translation>
    </message>
    <message>
        <source>Click to remove image from RSS export.</source>
        <translation>Кликнете, за да премахнете тази картинка от експорта на RSS.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Source URL</source>
        <translation>Първоначално URL</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Пътека за предназначение</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Разгледай</translation>
    </message>
    <message>
        <source>Imported objects will be owned by</source>
        <translation>Импортнатите обекти ще бъдат притежавани от
</translation>
    </message>
    <message>
        <source>Change user</source>
        <translation>Смени потребител</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заглавие</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Игнорирай
</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Edit &lt;%rss_import_name&gt; [RSS Import]</source>
        <translation>Редактирай &lt;%rss_import_name&gt; (RSS Импорт)</translation>
    </message>
    <message>
        <source>Name of the RSS import. This name is used in the administration interface only, to distinguish the different imports from each other.</source>
        <translation>Име на RSS импорт. Това име е използвано в административния интерфейс само за различаване на отделните импорти един от друг.
</translation>
    </message>
    <message>
        <source>Use this field to enter the source URL of the RSS feed to import.</source>
        <translation>Използвайте това поле, за да въведете уеб адреса на RSS източник за импорт.</translation>
    </message>
    <message>
        <source>Click this button to select the destination node where objects created by the import are located.</source>
        <translation>Натиснете този бутон, за да изберете възел на предназначението, където са намерени обекти, създадени от импортването.</translation>
    </message>
    <message>
        <source>Click this button to select the user who should own the objects created by the import.</source>
        <translation>Натиснете този бутон за избиране на потребител, който притежава обектите, създадени от импорта.</translation>
    </message>
    <message>
        <source>Use this drop down to select the type of object the import should create. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
        <translation>Използвайте това падащо меню, за да изберете вида на обекта, който импортът трябва да създаде. Натиснете бутона &quot;Постави&quot;, за да заредите видовете на правилния атрибут за останалите полета.
</translation>
    </message>
    <message>
        <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
        <translation>Натиснете този бутон, за да заредите правилните стойности в падащите полета по-долу. Използувайте падащото меню вляво, за да изберете правилния вид на класа.</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should bet set to the title information from the RSS stream.</source>
        <translation>Използвайте това падащо меню, за да избeрете атрибута, който трябва да бъде до главната информация от потока на RSS.
</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should be set to the URL information from the RSS stream.</source>
        <translation>Използвайте това падащо меню, за да избeрете атрибута, който трябва да бъде поставен до информацията за уеб адрес от потока на RSS.
</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should be set to the description information from the RSS stream.</source>
        <translation>Използвайте това падащо меню, за да изберете атрибута, който трябва да бъде поставен в информацията за описание от потокът на RSS.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the RSS feed is active or not. An inactive feed will not be automatically updated.</source>
        <translation>Използвайте този чек-бокс за активиране или деактивиране на експорта на RSS. Неактивен експорт няма да бъде обновен автоматично.



</translation>
    </message>
    <message>
        <source>Apply the changes and return to the RSS overview.</source>
        <translation>Приложи промените и се върни към прегледът на RSS.</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the RSS overview.</source>
        <translation>Отмени промените и се върни към прегледа на RSS.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/list</name>
    <message>
        <source>RSS exports [%exports_count]</source>
        <translation>Експорти на RSS [%imports_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивен</translation>
    </message>
    <message>
        <source>The RSS export list is empty.</source>
        <translation>Списъкът на експорта на RSS е празен.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New export</source>
        <translation>Нов експорт</translation>
    </message>
    <message>
        <source>RSS imports [%imports_count]</source>
        <translation>Импорти на RSS [%imports_count]</translation>
    </message>
    <message>
        <source>The RSS import list is empty.</source>
        <translation>Списъкът на импорта на RSS е празен.

</translation>
    </message>
    <message>
        <source>New import</source>
        <translation>Нов импорт</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Обърни селекцията</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select RSS export for removal.</source>
        <translation>Избери RSS експорт за премахване.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the &lt;%name&gt; RSS export.</source>
        <translation>Редактирай &lt;%name&gt; RSS експорт.</translation>
    </message>
    <message>
        <source>Remove selected RSS exports.</source>
        <translation>Премахни избраните RSS експорти.</translation>
    </message>
    <message>
        <source>Create a new RSS export.</source>
        <translation>Създай нов RSS експорт.</translation>
    </message>
    <message>
        <source>Select RSS import for removal.</source>
        <translation>Избери RSS импорт за премахване.</translation>
    </message>
    <message>
        <source>Edit the &lt;%name&gt; RSS import.</source>
        <translation>Редактирай &lt;%name&gt; RSS импорт.</translation>
    </message>
    <message>
        <source>Remove selected RSS imports.</source>
        <translation>Премахни избраните RSS импорти.</translation>
    </message>
    <message>
        <source>Create a new RSS import.</source>
        <translation>Създай нов RSS импорт.</translation>
    </message>
</context>
<context>
    <name>design/admin/search/stats</name>
    <message>
        <source>Search statistics</source>
        <translation>Търси статистики</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Фраза</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Брой фрази</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Среден върнат резултат</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Изчистване на статистиката</translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation>Списъкът е празен.</translation>
    </message>
    <message>
        <source>Clear the search log.</source>
        <translation>Изчисти лог за търсене.</translation>
    </message>
</context>
<context>
    <name>design/admin/section/browse_assign</name>
    <message>
        <source>Choose start location for the &lt;%section_name&gt; section</source>
        <translation>Избери стартово местоположение за секцията &lt;%section_name&gt;</translation>
    </message>
    <message>
        <source>Use the radio buttons to select an item that should have the &lt;%section_name&gt; section assigned.</source>
        <translation>Използувайте бутоните, за да изберете елемент, ако има част &lt;%section_name&gt; на определяне.</translation>
    </message>
    <message>
        <source>Keep in mind that the section assignment of the sub items will also be changed.</source>
        <translation>Имайте предвид, че назначението на секцията на поделементите, също ще бъде променено.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/section/confirmremove</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Confirm section removal</source>
        <translation>Потвърди премахването на секцията</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the section?</source>
        <translation>Сигурни ли сте, че искате да премахнете секцията?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the sections?</source>
        <translation>Сигурни ли сте, че искате да премахнете секциите?</translation>
    </message>
    <message>
        <source>The following sections will be removed</source>
        <translation>Следните секции ще бъдат премахнати</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Removing a section may corrupt permission settings, template output and other things in the system.</source>
        <translation>Премахването на секция може да развали настройките на правата, изходните данни на шаблона и други неща в системата.</translation>
    </message>
    <message>
        <source>Proceed only if you know what you are doing.</source>
        <translation>Продължете само, ако знаете какво правите.</translation>
    </message>
</context>
<context>
    <name>design/admin/section/edit</name>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Edit &lt;%section_name&gt; [Section]</source>
        <translation>Редактирай (Секция) &lt;%section_name&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Навигационна пътека</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/section/list</name>
    <message>
        <source>Sections [%section_count]</source>
        <translation>Секции (%section_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>section</source>
        <translation>секция</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New section</source>
        <translation>Нова секция</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select section for removal.</source>
        <translation>Избери секция за премахване.</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Прехвърли</translation>
    </message>
    <message>
        <source>Assign the &lt;%section_name&gt; section to a subtree.</source>
        <translation>Прехвърли секцията &lt;%section_name&gt; към поддърво.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit the &lt;%section_name&gt; section.</source>
        <translation>Редактирай секция &lt;%section_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected sections.</source>
        <translation>Премахни избраните секции.</translation>
    </message>
    <message>
        <source>Create a new section.</source>
        <translation>Създай нова секция.</translation>
    </message>
</context>
<context>
    <name>design/admin/section/view</name>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>%section_name [Section]</source>
        <translation>%section_name (Секция)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit this section.</source>
        <translation>Редактирай тази секция.</translation>
    </message>
    <message>
        <source>Roles containing limitations associated with this section [%number_of_roles]</source>
        <translation>Роли, съдържащи ограничения, свързани с тази част [%number_of_roles]</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Limited policies</source>
        <translation>Ограничени политики</translation>
    </message>
    <message>
        <source>This section is not used to limit the policies of any role.</source>
        <translation>Тази секция не се използва за ограничение на политики от каквато и да е роля.</translation>
    </message>
    <message>
        <source>Users and user groups with role limitations associated with this section [%number_of_roles]</source>
        <translation>Потребители и потребителски групи с ограничения на роли свързани с тази секция [%number_of_roles]</translation>
    </message>
    <message>
        <source>User or user group</source>
        <translation>Потребител или потребителска група</translation>
    </message>
    <message>
        <source>This section is not used for limiting roles that are assigned to users or user groups. </source>
        <translation>Тази секция не е използвана, за да ограничава роли, които са прехвърлени на потребители или групи от потребители.</translation>
    </message>
    <message>
        <source>Objects within this section [%number_of_objects]</source>
        <translation>Обекти в тази секция [%number_of_objects]</translation>
    </message>
    <message>
        <source>This section is not assigned to any objects.</source>
        <translation>Тази секция не е прехвърлена на каквито и да е обекти.</translation>
    </message>
</context>
<context>
    <name>design/admin/settings</name>
    <message>
        <source>Edit setting %setting</source>
        <translation>Редактирай настройка %setting</translation>
    </message>
    <message>
        <source>New setting</source>
        <translation>Нова настройка</translation>
    </message>
    <message>
        <source>Block</source>
        <translation>Блок</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Setting: &lt;new setting&gt;</source>
        <translation>Настройка &lt;нова настройка&gt;</translation>
    </message>
    <message>
        <source>INI File</source>
        <translation>INI файл</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>SiteAccess</translation>
    </message>
    <message>
        <source>Change setting type</source>
        <translation>Промени вид на настройка</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Забележка</translation>
    </message>
    <message>
        <source>A global setting will override a siteaccess setting</source>
        <translation>Глобалната настройка ще отмени настройката на siteaccess</translation>
    </message>
    <message>
        <source>Tip</source>
        <translation>Полезен съвет</translation>
    </message>
    <message>
        <source>To create an empty array leave the first line empty</source>
        <translation>За да създадете празен масив, оставете първото поле празно</translation>
    </message>
    <message>
        <source>Siteaccess setting</source>
        <translation>Настройка на siteaccess</translation>
    </message>
    <message>
        <source>Override setting (global)</source>
        <translation>Отмени настройка (глобално)</translation>
    </message>
    <message>
        <source>Global setting</source>
        <translation>Глобална настройка</translation>
    </message>
    <message>
        <source>Setting Name</source>
        <translation>Настройка на Име</translation>
    </message>
    <message>
        <source>Setting value</source>
        <translation>Настройка на стойност</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Разрешен</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Забранен</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Запази</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входните данни не са валидни</translation>
    </message>
    <message>
        <source>%valfield is empty</source>
        <translation>%valfield е празен</translation>
    </message>
    <message>
        <source>Variable %valfield already exists in section %block</source>
        <translation>Променлива %valfield вече съществува в секция %block</translation>
    </message>
    <message>
        <source>Please choose another name that is not already taken</source>
        <translation>Моля, изберете друго име, което не е използвано</translation>
    </message>
    <message>
        <source>%valfield is not allowed to contain spaces</source>
        <translation>%valfield не може да съдържа интервали</translation>
    </message>
    <message>
        <source>Writing setting: %setting_name to file: %filename failed.</source>
        <translation>Записване на настройка към файл %setting_name, %filename се провали.</translation>
    </message>
    <message>
        <source>Make sure you have proper permissions to %path and try again.</source>
        <translation>Уверите се, че имате подходящите права към %path и опитайте пак.</translation>
    </message>
    <message>
        <source>Name contains illegal character(s).</source>
        <translation>Името съдържа грешни символ(и).</translation>
    </message>
    <message>
        <source>Name should only contain A-Z and 0-9.</source>
        <translation>Името може да съдържа само A-Z и 0-9.</translation>
    </message>
    <message>
        <source>%valfield does not contain a valid string.</source>
        <translation>$valfield не съдържа валиден стринг.</translation>
    </message>
    <message>
        <source>If the string is all numbers use the numeric type instead.</source>
        <translation>Ако стрингът използва само числа, използвайте числов вид вместо това.</translation>
    </message>
    <message>
        <source>%valfield does not contain a valid numeric</source>
        <translation>$valfield не съдържа валидна цифрова част</translation>
    </message>
    <message>
        <source>A valid numeric can only contain 0-9 and one . (dot). </source>
        <translation>Валидната цифрова част може да съдържа само 0 - 9 и една . (точка).</translation>
    </message>
    <message>
        <source>$valfield does not contain valid array.</source>
        <translation>$valfield не съдържа валиден масив.</translation>
    </message>
    <message>
        <source>View settings</source>
        <translation>Виж настройки</translation>
    </message>
    <message>
        <source>Using siteaccess</source>
        <translation>Използвай siteaccess</translation>
    </message>
    <message>
        <source>%ini_file consist of %blocks section(s) and %setting_count different setting(s)</source>
        <translation>%ini_file съставен от %blocks секции и %setting_count различни настройки</translation>
    </message>
    <message>
        <source>Please select an ini file from the dropdown below</source>
        <translation>Моля, избери файл INI от падащото меню по-долу</translation>
    </message>
    <message>
        <source>Select ini file to view</source>
        <translation>Избери ini файл за разглеждане</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Settings for %inifile in siteaccess %siteaccess</source>
        <translation>Настройки за %inifile в siteaccess %siteaccess</translation>
    </message>
    <message>
        <source>[add setting]</source>
        <translation>(добави настройки)</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Разположение</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Стойност</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
</context>
<context>
    <name>design/admin/setup</name>
    <message>
        <source>File consistency check OK.</source>
        <translation>Последователност на файл ОК.</translation>
    </message>
    <message>
        <source>Warning, it is not safe to upgrade without checking the modifications done to the following files</source>
        <translation>Внимание, не е безопасно за подобряване, без да проверитепромените, които са направени на следните файлове</translation>
    </message>
    <message>
        <source>Database check OK.</source>
        <translation>Проверка на база данни ОК.</translation>
    </message>
    <message>
        <source>The database is not consistent with the distribution database.</source>
        <translation>Базата данни не е съответстваща на базата данни за разпределение.
</translation>
    </message>
    <message>
        <source>To synchronize your database with the distribution setup, run the following SQL commands</source>
        <translation>За да синхронизирате базата данни с настройката на разпространение, пуснете следните SQL команди </translation>
    </message>
    <message>
        <source>System upgrade check</source>
        <translation>Проверка на системно обновяване</translation>
    </message>
    <message>
        <source>Before upgrading eZ publish to a newer version, it is important to check that the current installation is ready for upgrading.</source>
        <translation>Преди онбовяване на EZ към по-нова версия, важно е да проверите, че текущата инсталация е готова за обновяване.
</translation>
    </message>
    <message>
        <source>Remember to make a backup of the eZ publish directory and the database before you upgrade.</source>
        <translation>Помните, че трябва да направите заместник на публикуваната EZ директория и базата данни преди да обновявите.
</translation>
    </message>
    <message>
        <source>File consistency check</source>
        <translation>Проверка за консистентност на файл
</translation>
    </message>
    <message>
        <source>The file consistency tool checks if you have altered any of the files that came with the current installation. Altered files may be replaced by new versions which contain bugfixes, new features, etc. Make sure that you backup and then merge in your custom changes into the new versions of the files.</source>
        <translation>Инструментът за консистентност на файловете проверява, дали сте променили, който и да е от файловете заедно с текущата инсталация. Променените файлове могат да бъдат заменени от нови версии, които съдържат корекции на грешки, новите отличителни черти и т.н. Уверите се, че сте архивирали и след това обединете промените в новите версии на файловете.</translation>
    </message>
    <message>
        <source>Database consistency check</source>
        <translation>Проверка за консистентност на база данни </translation>
    </message>
    <message>
        <source>The database consistency tool checks if the current database is consistent with the database schema that came with the eZ publish distribution. If there are any inconsistencies, the tool will suggest the necessary SQL statements that should be ran in order to bring the database into a consistent state. Please run the suggested SQL statements before upgrading.</source>
        <translation>Инструментът за консистентност на базата данни проверява, дали текущата база данни е съответстваща на схемата на базата данни, която се налага с разпространението на EZ publish. Ако има каквито и да е несъвместимости, инструментът ще предложи необходимите команди на SQL, които трябва да бъдат задайствани, за да се приведе базата в консистентен вид. Моля, пуснете предложените команди на SQL преди да се обновяват.
</translation>
    </message>
    <message>
        <source>The upgrade checking tools require a lot of resources and it may take some time to run them.</source>
        <translation>Приложенията за обновяване изискват много ресурси и това може да отнеме известно време, за да бъдат задвижени.</translation>
    </message>
    <message>
        <source>Check file consistency</source>
        <translation>Провери консистентността на файла</translation>
    </message>
    <message>
        <source>Check database consistency</source>
        <translation>Провери консистентността на базата данни
</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/cache</name>
    <message>
        <source>Content view cache was cleared</source>
        <translation> Съдържанието на кеш беше изчистен</translation>
    </message>
    <message>
        <source>All caches were cleared</source>
        <translation>Всички кешове бяха изчистени</translation>
    </message>
    <message>
        <source>Ini file cache was cleared</source>
        <translation>Ini файл кеш беше изчистен</translation>
    </message>
    <message>
        <source>Template cache was cleared</source>
        <translation>Кеш на шаблон беше изчистен</translation>
    </message>
    <message>
        <source>%name was cleared</source>
        <translation>%name беше изчистен

</translation>
    </message>
    <message>
        <source>Template overrides and compiled templates</source>
        <translation>Презаписване на шаблони и подчинени шаблони</translation>
    </message>
    <message>
        <source>Clear template caches</source>
        <translation>Изчисти кеш на шаблони</translation>
    </message>
    <message>
        <source>Content views and template blocks</source>
        <translation>Изглед на съдържание и блокиране на шаблони</translation>
    </message>
    <message>
        <source>Clear content caches</source>
        <translation>Изчисти кеш на съдържание</translation>
    </message>
    <message>
        <source>Clear ini caches</source>
        <translation>Изчисти ini кешове</translation>
    </message>
    <message>
        <source>Clear all caches</source>
        <translation>Изчисти всички кешове</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Път</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Изчисти избраните</translation>
    </message>
    <message>
        <source>The following caches were cleared</source>
        <translation>Следните кешове бяха изчистени</translation>
    </message>
    <message>
        <source>Clear caches</source>
        <translation>Изчистване на кешове</translation>
    </message>
    <message>
        <source>This operation will clear all the template override caches and the compiled templates. It may lead to weaker performance until the caches are up and running again.</source>
        <translation>Тази операция ще изчисти изцяло кеш на шаблоните и подчинените шаблони. Това може да доведе до по-слабо действие, докато кешовете са в изправност отново.

</translation>
    </message>
    <message>
        <source>This operation will clear all caches that are related to either template views or cache blocks inside the pagelayout template. Use it if you have modified templates or if you have changed something inside a cache block.</source>
        <translation>Тази операция ще изчисти всички кешове, които са свързани с всички шаблони или ще блокира кеша в шаблона на pagelayout. Използвайте я, ако имате променени шаблони или ако сте променили нещо в блокирането на кеша.</translation>
    </message>
    <message>
        <source>Configuration (ini) caches</source>
        <translation>Конфигурация на (ini) кешове</translation>
    </message>
    <message>
        <source>This operation will clear all the configuration caches. Use it to force the system to re-read the configuration files if you have changed some settings.</source>
        <translation>Тази операция ще изчисти кешовете за цялата конфигурация. Използвайте я, за да принудите системата да прочете отново файловете за конфигурация, ако сте променяли някакви настройки.</translation>
    </message>
    <message>
        <source>Everything</source>
        <translation>Всичко</translation>
    </message>
    <message>
        <source>This operation will clear ALL the caches and may lead to long response times until the caches are up and running again.</source>
        <translation>Тази операция ще изчисти ВСИЧКИ кешове и може да доведе до дълго чакане, докато кешовете са в изправност отново.</translation>
    </message>
    <message>
        <source>Fine-grained cache control</source>
        <translation>Сложен кеш контрол</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select the &lt;%cache_name&gt; for clearing.</source>
        <translation>Избери за изчистване &lt;%cache_name&gt;.</translation>
    </message>
    <message>
        <source>The &lt;%cache_name&gt; is disabled and thus it can not be marked for clearing.</source>
        <translation>&lt;%cache_name&gt; е изключен и поради това не може да бъде маркиран за изчистване.</translation>
    </message>
    <message>
        <source>Clear the selected caches.</source>
        <translation>Изчисти избраните кешове. </translation>
    </message>
    <message>
        <source>Static content cache was regenerated</source>
        <translation>Статичното съдържание на кеша беше заредено отново</translation>
    </message>
    <message>
        <source>Static content cache</source>
        <translation>Статично съдържание на кеш</translation>
    </message>
    <message>
        <source>Regenerate static content cache</source>
        <translation>Зареждане отново на статично съдържание на кеш</translation>
    </message>
    <message>
        <source>This operation will regenerate all the static content caches that are configured. This action can take quite some time depending on the specifications of the server and the number of locations that are configured to be statically cached. If you encounter time-out problems, please use the &amp;quot;bin/php/makestaticcache.php&amp;quot; shell script.</source>
        <translation>Тази операция ще зареди отново всичките кешове за статично съдържание, които са конфигурирани. Това действие може да отнеме много време, зависещо от спецификациите на сървъра и броя на местата, които бяха конфигурирани за статично кеширане. Ако срещнете проблеми с времето, моля използвайте &amp;quot;bin/php/makestaticcache.php&amp;quot;скрипт за команден интерпретатор.</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Създай нов</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Конструктор</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/extensions</name>
    <message>
        <source>Available extensions [%extension_count]</source>
        <translation>Налични разширения [%extension_count]</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Приложи промените</translation>
    </message>
    <message>
        <source>Activate or deactivate extension. Use the &quot;Apply changes&quot; button to apply the changes.</source>
        <translation>Активирайте или деактивирайте разширението. Използвайте бутон &quot;Приложи промени&quot;, за да приложите промените.
</translation>
    </message>
    <message>
        <source>There are no available extensions.</source>
        <translation> Няма налични разширения.</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified the status of the checkboxes above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте промяли статуса на чек-боксовете по-горе.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/info</name>
    <message>
        <source>System information</source>
        <translation>Системна информация</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Сайт</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Версия

eZ publish версия</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>SVN ревизия

eZ publish версия</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Разширения

eZ publish разширения</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Версия

PHP версия</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Разширения

PHP разширения</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Разни</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>Режимът за сигурност е включен.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>Режимът за сигурност е изключен.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>Basedir ограничението е включено и е настроено на %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>Basedir ограничението е изключено.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>Регистрацията на глобалните променливи е включена.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>Регистрацията на глобалните променливи е изключена.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>Качването на файлове е включено.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>Качването на файлове е изключено.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>Максималният размер на данните (текс и файлове) е %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>Лимитът на паметта за скрипрове е %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>Максималното време за изпълнение е %1 секунди.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Webserver name</comment>
        <translation>Име

Webserver име</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>Webserver version</comment>
        <translation>Версия

Webserver версия</translation>
    </message>
    <message>
        <source>Modules</source>
        <comment>Webserver modules</comment>
        <translation>Модули

Уебсървър модули </translation>
    </message>
    <message>
        <source>eZ publish was unable to extract information from the webserver.</source>
        <translation>eZ publish не може да извади информация от уебсървъра.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Име

PHP Ускорител име</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Версия

PHP Ускорител версия</translation>
    </message>
    <message>
        <source>Version information could not be detected.</source>
        <translation>Информационната версия не може да бъде открита.</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>PHP Accelerator status</comment>
        <translation>Статус

PHP Ускорител статус</translation>
    </message>
    <message>
        <source>Enabled.</source>
        <translation>Включен.</translation>
    </message>
    <message>
        <source>Disabled.</source>
        <translation>Изключен.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>База данни</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Тип

База данни тип</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Сървър

База дани сървър</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Път на socket

База данни път на socket</translation>
    </message>
    <message>
        <source>Not in use.</source>
        <translation>Не е в употреба.</translation>
    </message>
    <message>
        <source>Database name</source>
        <comment>Database name</comment>
        <translation>Име на база данни</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Брояч на опитите за свързване</translation>
    </message>
    <message>
        <source>Character set</source>
        <comment>Database charset</comment>
        <translation>Настройка на символи</translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Вътрешен</translation>
    </message>
    <message>
        <source>Slave database (read only)</source>
        <translation>Подчинена база данни (само за четене)</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>База данни

Име на база данни</translation>
    </message>
    <message>
        <source>There is no slave database in use.</source>
        <translation>Няма никаква подчинена база данни в употреба.</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <translation>eZ publish</translation>
    </message>
    <message>
        <source>PHP</source>
        <translation>PHP</translation>
    </message>
    <message>
        <source>PHP Accelerator</source>
        <translation>PHP Ускорител</translation>
    </message>
    <message>
        <source>A known and active PHP accelerator could not be found.</source>
        <translation>Известен и активен ускорител на PHP не може да бъде намерен.</translation>
    </message>
    <message>
        <source>Webserver (software)</source>
        <comment>Webserver title</comment>
        <translation>Уебсървър (софтуер)</translation>
    </message>
    <message>
        <source>The modules of the webserver could not be detected.</source>
        <comment>Webserver modules</comment>
        <translation>Модулите на webserver не могат да бъдат намерени.</translation>
    </message>
    <message>
        <source>Webserver (hardware)</source>
        <translation>Уебсървър (хардуер)</translation>
    </message>
    <message>
        <source>CPU</source>
        <comment>CPU info</comment>
        <translation>Процесор</translation>
    </message>
    <message>
        <source>Memory</source>
        <comment>Memory info</comment>
        <translation>Памет</translation>
    </message>
    <message>
        <source>Script memory limit is Unlimited.</source>
        <translation>Лимитът на паметта за скриптове е Неограничен.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Пример</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Конструктор, не прави нищо по подразбиране.
 </translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>\return масив с името на оператора на шаблона.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Изпълнява PHP функция за почистване на оператора и променя \a$operatorValue.
</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Примерен код, този код трябва да бъде променен за да прави това, което операторът трябва да прави, в момента то само подрежда текст.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad</name>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Инструменти за бързо променяне на приложенията</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools make the creation of new/extended functionality for eZ publish easier. Currently there are two RAD tools available: the template operator wizard and the datatype wizard. The template operator wizard basically generates a valid framework (PHP code) for a new template operator. The datatype wizard generates a valid framework (PHP code) for a new datatype.</source>
        <translation>Инструментите за бързо променяне на приложенията (RAD) правят създаването на новата / разширена функционалност за EZ publish по-лесно. В момента два RAD инструмента са налични : помощникът на оператора на шаблона и помощникът за тип на данни. Помощникът на оператора на шаблона обикновено генерира валидна структура (код PHP) за нов оператор на шаблон. Помощникът за тип на данни генерира валидно скеле (код PHP) за нов тип на данни.</translation>
    </message>
    <message>
        <source>Available RAD tools</source>
        <translation>Налични RAD инструменти</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Помощник на оператор на шаблон</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Помощник за тип на данни</translation>
    </message>
    <message>
        <source>Template operator wizard (step 1 of 3)</source>
        <translation>Помощник за оператор на шаблон (стъпка от 1 до 3) </translation>
    </message>
    <message>
        <source>Welcome to the template operator wizard. Template operators are usually used for manipulating template variables. However, they can also be used to generate or fetch data. This wizard will take you through a couple of steps with some basic choices. When finished, eZ publish will generate a PHP framework for the a new operator (which will be available for download).</source>
        <translation>Добре дошли в помощника на оператора на шаблона. Операторите на шаблони обикновено се използват, за да манипулират променливи на шаблони. Освен това те също могат да бъдат използвани, за да генерират или връщат данни. Този помощник ще ви преведе през няколко стъпки с някои основни избори. Когато завърши, EZ publish генерира структурата на PHP за новия оператор (която ще бъде налична за сваляне).</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Рестарт</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad/datatype</name>
    <message>
        <source>Datatype wizard (step 1 of 3)</source>
        <translation>Помощник на тип на данни (стъпка от 1 до 3)</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Рестарт</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>Datatype wizard (step 2 of 3)</source>
        <translation>Помощник на тип на данни (стъпка от 2 до 3)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Descriptive name</source>
        <translation>Описателно име</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <translation>Управление на входните данни на ниво клас</translation>
    </message>
    <message>
        <source>Datatype wizard (step 3 of 3)</source>
        <translation>Помощник на тип на данни (стъпка от 3 до 3)</translation>
    </message>
    <message>
        <source>Name of class</source>
        <translation>Име на клас</translation>
    </message>
    <message>
        <source>Constant name</source>
        <translation>Име на константата</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <translation>Създател на тип на данните</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Handles the datatype %datatype_name. By using %datatype_name you can ...</source>
        <translation>Управлява тип на данни %datatype_name. Като използвате %datatype_name, можете ...</translation>
    </message>
    <message>
        <source>Hint: The first line will be used as the brief description. The rest will become operator documentation.</source>
        <translation>Кратък съвет: първата линия ще бъде използвана като кратко описание. Останалата част ще стане документация на оператора.</translation>
    </message>
    <message>
        <source>Finish and generate</source>
        <translation>Завърши и генерирай</translation>
    </message>
    <message>
        <source>Welcome to the wizard for creating a new datatypes. Everything you store in your content objects are called attributes. These attributes are defined as a data types. To be able to customize the storing and validation of these attributes, you can create your own data types.</source>
        <translation>Добре дошли в помощника за създаване на нов тип на данни. Всичко, което складирате в своите обекти със съдържание, са нареча атрибути. Тези атрибути са дефинирани като един от типовете на данни. За да промените складирането и валидирането на тези атрибути, можете да създадете свои собствени типове на данните.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad/templateoperator</name>
    <message>
        <source>Template operator wizard (step 2 of 3)</source>
        <translation>Помощник на оператор на шаблон (стъпка от 2 до 3) </translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Handles input</source>
        <translation>Управление на входяща информация</translation>
    </message>
    <message>
        <source>Generates output</source>
        <translation>Генерира резултат от изчисления
</translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation>Параметри</translation>
    </message>
    <message>
        <source>No parameters</source>
        <translation>Няма параметри</translation>
    </message>
    <message>
        <source>Named parameters</source>
        <translation>Наименувани параметри</translation>
    </message>
    <message>
        <source>Sequential parameters</source>
        <translation>Последователни параметри</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Потребителски</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Рестарт</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>Template operator wizard (step 3 of 3)</source>
        <translation>Помощник на оператор на шаблон (стъпка от 3 до 3) </translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Клас Име</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Handles template operator %operator_name. By using %operator_name you can...</source>
        <translation>Управлява оператор на шаблон %operator_namе. Като използвате %operator_name, можете...</translation>
    </message>
    <message>
        <source>Hint: The first line will be used for the brief description. The rest will become the documentation.</source>
        <translation>Кратък съвет: първата линия ще бъде използвана като кратко описание. Останалата част ще стане документация.</translation>
    </message>
    <message>
        <source>Example code</source>
        <translation>Примерен код</translation>
    </message>
    <message>
        <source>Hint: Feel free to add example code that demonstrates how the operator works.</source>
        <translation>Кратък съвет: Можете да прибавяте примерен код, който демонстрира начина, по който операторът работи.</translation>
    </message>
    <message>
        <source>Finish and generate</source>
        <translation>Завърши и генерирай</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/session</name>
    <message>
        <source>The sessions were successfully removed.</source>
        <translation>Сесиите бяха успешно премахнати.</translation>
    </message>
    <message>
        <source>Session administration</source>
        <translation>Администриране на сесия</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Сесии</translation>
    </message>
    <message>
        <source>Total number of sessions</source>
        <translation>Общ брой на сесиите</translation>
    </message>
    <message>
        <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
        <translation>Има регистрирани анонимни потребители онлайн %logged_in_count и %anonymous_count.</translation>
    </message>
    <message>
        <source>WARNING! When you remove sessions, users that are logged in will be logged out from the system.</source>
        <translation>Внимание! Когато премахвате сесии, потребителите, които са влезли, ще бъдат изхвърлени от системата.
</translation>
    </message>
    <message>
        <source>Remove all sessions</source>
        <translation>Премахни всички сесии</translation>
    </message>
    <message>
        <source>Remove timed out / old sessions</source>
        <translation>Премахни прекъснати / стари сесии</translation>
    </message>
    <message>
        <source>Filtered sessions</source>
        <translation>Филтрирани сесии</translation>
    </message>
    <message>
        <source>Displaying sessions for %username</source>
        <translation>Показващи се сесии за %username</translation>
    </message>
    <message>
        <source>Sessions for all users</source>
        <translation>Сесии за всички потребители</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Потребители</translation>
    </message>
    <message>
        <source>Everyone</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Registered users</source>
        <translation>Регистрирани потребители</translation>
    </message>
    <message>
        <source>Anonymous users</source>
        <translation>Анонимни потребители</translation>
    </message>
    <message>
        <source>Update list</source>
        <translation>Списък с последни данни</translation>
    </message>
    <message>
        <source>Include inactive users</source>
        <translation>Включване на неактивни потребители</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Обърни селекцията</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Брояч</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Full name</source>
        <translation>Пълно име</translation>
    </message>
    <message>
        <source>Idle time</source>
        <translation>Неизползвано време</translation>
    </message>
    <message>
        <source>Idle since</source>
        <translation>Неизползван от</translation>
    </message>
    <message>
        <source>Select session for removal.</source>
        <translation>Избери сесия за премахване.</translation>
    </message>
    <message>
        <source>Time skew detected</source>
        <translation>Изкривено намерено време</translation>
    </message>
    <message>
        <source>There are no sessions matching the selected options.</source>
        <translation>Няма сесии съвпадащи с избраните възможности.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected sessions.</source>
        <translation>Премахни избраните сесии.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/accounthandlers/html/ez</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Компания</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Улица</translation>
    </message>
    <message>
        <source>Zip code</source>
        <translation>Пощенски код</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/basket</name>
    <message>
        <source>Shopping basket</source>
        <translation>Кошница</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Цена (без ДДС)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Цена (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Сума (без ДДС)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избрани опции</translation>
    </message>
    <message>
        <source>Subtotal (ex. VAT)</source>
        <translation>Междинна сума (без ДДС)</translation>
    </message>
    <message>
        <source>Subtotal (inc. VAT)</source>
        <translation>Междинна сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Продължи пазаруването</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Проверка</translation>
    </message>
    <message>
        <source>Items removed</source>
        <translation>Елементи за премахване</translation>
    </message>
    <message>
        <source>The following items were removed from your basket because the products have changed</source>
        <translation>Следните елементи бяха премахнати от твоята кошница, защото продуктите бяха променени</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Избери елемент за премахване.</translation>
    </message>
    <message>
        <source>There are no items in your shopping basket.</source>
        <translation>Няма елементи в твоята кошница.</translation>
    </message>
    <message>
        <source>Remove selected items from the basket.</source>
        <translation>Премахни избраните елементи от кошницата.</translation>
    </message>
    <message>
        <source>Click this button to update the basket if you have modified any quantity and/or option fields.</source>
        <translation>Натиснете този бутон, за да обновите промените, ако сте променяли каквато и да е величина и/или алтернативни полета.

</translation>
    </message>
    <message>
        <source>Leave the basket and continue shopping.</source>
        <translation>Остави кошницата и продължи с пазаруването.</translation>
    </message>
    <message>
        <source>Proceed to checkout and purchase the items that are in the basket.</source>
        <translation>Продължи към проверка и купи елементите, които са в кошницата.</translation>
    </message>
    <message>
        <source>You can not remove any items because there are no items in the basket.</source>
        <translation>Не можете да премахвате който и да от елементите, защото няма елементи в кошницата.</translation>
    </message>
    <message>
        <source>You can not store any changes because the basket is empty.</source>
        <translation>Не можете да запазите, защото кошницата е празна.</translation>
    </message>
    <message>
        <source>You can not check out because the basket is empty.</source>
        <translation>Не можете да проверите, защото кошницата е празна.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/browse_discountcustomer</name>
    <message>
        <source>Choose customers for discount group</source>
        <translation>Избери потребители за групата за отстъпка</translation>
    </message>
    <message>
        <source>Use the checkboxes to select users and user groups (customers) that you wish to add to the discount group.</source>
        <translation>Използвайте чек-боксовете, за да изберете потребители и групи (клиенти), които искате да прибавите към групата за отстъпка.
</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържание (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/browse_discountgroup</name>
    <message>
        <source>Choose products for discount group</source>
        <translation>Избери продукти за групата за отстъпка</translation>
    </message>
    <message>
        <source>Use the checkboxes to select products to be included in the discount group.</source>
        <translation>Използувайте чек-боксовете, за да изберете продукти, които ще бъдат включени в групата за отстъпка.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>За навигация използвайте наличните бутони (отгоре), менюто (отляво) и списъка със съдържанието (по средата).</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/confirmorder</name>
    <message>
        <source>Order confirmation</source>
        <translation>Потвърждение на поръчката</translation>
    </message>
    <message>
        <source>Please confirm that the information below is correct. Click &quot;Confirm order&quot; to confirm the order.</source>
        <translation>Моля, потвърдете, че информацията по-долу е правилна. Натиснете &quot;потвърди нареждане&quot; за потвърждаване.</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Items to be purchased</source>
        <translation>Елементите бяха купени</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Цена (без ДДС)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Цена (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Total price (ex. VAT)</source>
        <translation>Пълна цена (без ДДС)</translation>
    </message>
    <message>
        <source>Total price (inc. VAT)</source>
        <translation>Пълна цена (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избрани опции</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Резюме на поръчката</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Междинна сума на елементите</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Общо сума на поръчката</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Потвърди поръчката</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerlist</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>Поръчки</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Сума (без ДДС)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>The customer list is empty.</source>
        <translation>Списъкът с клиента е празен.</translation>
    </message>
    <message>
        <source>Customers [%customers]</source>
        <translation>Клиенти [%customers]</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerorderview</name>
    <message>
        <source>Customer information</source>
        <translation>Информация за клиент</translation>
    </message>
    <message>
        <source>Orders [%order_count]</source>
        <translation>Поръчки [%order_count]</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Сума (без ДДС)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Време</translation>
    </message>
    <message>
        <source>Purchased products [%product_count]</source>
        <translation>Купени продукти [%product_count]</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroup</name>
    <message>
        <source>Discount groups [%discount_groups]</source>
        <translation>Групи с отстъпка [%discount_groups]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New discount group</source>
        <translation>Нова група с отсъпка</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select discount group for removal.</source>
        <translation>Избери група с отстъпка за премахване.</translation>
    </message>
    <message>
        <source>Edit the &lt;%discountgroup_name&gt; discount group.</source>
        <translation>Редактирай групата с отстъпка &lt;%discountgroup_name&gt;.</translation>
    </message>
    <message>
        <source>There are no discount groups.</source>
        <translation>Няма групи с отстъпка.</translation>
    </message>
    <message>
        <source>Remove selected discount groups.</source>
        <translation>Премахни избраните групи с отстъпка.</translation>
    </message>
    <message>
        <source>Create a new discount group.</source>
        <translation>Създай нова група с отстъпка.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupedit</name>
    <message>
        <source>Edit &lt;%discount_group&gt; [Discount group]</source>
        <translation>Редактирай &lt;%discount_group&gt; (Група с отстъпка)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupmembershipview</name>
    <message>
        <source>%discount_group [Discount group]</source>
        <translation>%discount_group (Група с отстъпка)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Discount rules [%rule_count]</source>
        <translation>Правила за отстъпка [%rule_count]</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Приложи за</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New discount rule</source>
        <translation>Нова правило за отсъпка</translation>
    </message>
    <message>
        <source>Edit this discount group.</source>
        <translation>Редактирай тази група с отстъпка. </translation>
    </message>
    <message>
        <source>Remove this discount group.</source>
        <translation>Премахни тази група с отстъпка.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select discount rule for removal.</source>
        <translation>Избери правило за отстъпка за премахване.</translation>
    </message>
    <message>
        <source>Edit the &lt;%discount_rule_name&gt; discount rule.</source>
        <translation>Редактирай правилото за отстъпка &lt;%discount_rule_name&gt;.</translation>
    </message>
    <message>
        <source>There are no discount rules in this group.</source>
        <translation>Няма правила за отстъпка за тази група.</translation>
    </message>
    <message>
        <source>Remove selected discount rules.</source>
        <translation>Премахни избраните правила за отстъпка.</translation>
    </message>
    <message>
        <source>Create a new discount rule and add it to the &lt;%discount_group_name&gt; discount group.</source>
        <translation>Създай ново правило за отстъпка и добави към групата с отстъпка &lt;%discount_group_name&gt;.</translation>
    </message>
    <message>
        <source>Customers (users and user groups) [%customer_count]</source>
        <translation>Клиенти (потребители и потребителски групи) [%customer_count]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Select user or user group for removal.</source>
        <translation>Избери потребител или група потребители за премахване.</translation>
    </message>
    <message>
        <source>There are no customers in this discount group.</source>
        <translation>Няма клиенти в тази група с отстъпка.</translation>
    </message>
    <message>
        <source>Remove selected users and/or user groups.</source>
        <translation>Премахни избраните потребители и/или групи от потребители.</translation>
    </message>
    <message>
        <source>Add customers</source>
        <translation>Прибави клиенти</translation>
    </message>
    <message>
        <source>Add users and/or user groups to the &lt;%discount_group_name&gt; discount group.</source>
        <translation>Прибави потребители и/или потребителски групи към групата с отстъпка &lt;%discount_group_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountruleedit</name>
    <message>
        <source>Edit &lt;%rule_name&gt; [Discount rule]</source>
        <translation>Редактирай (Правило за отстъпка) &lt;%rule_name&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Процент на отстъпка</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>New discount rule</source>
        <translation>Ново правило за отсъпка</translation>
    </message>
    <message>
        <source>Product types</source>
        <translation>Типове продукти</translation>
    </message>
    <message>
        <source>in sections</source>
        <translation>в секции</translation>
    </message>
    <message>
        <source>Individual products</source>
        <translation>Индивидуални продукти</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>The individual product list is empty.</source>
        <translation>Списъкът с индивидуални прокукти е празен.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add products</source>
        <translation>Добави продукти</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderlist</name>
    <message>
        <source>Orders [%count]</source>
        <translation>Поръчки [%order_count]</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Сума (без ДДС)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Време</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Възходящ</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Низходящ</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select order for removal.</source>
        <translation>Избери ред за премахване.</translation>
    </message>
    <message>
        <source>The order list is empty.</source>
        <translation>Списъкът на поръчките е празен.</translation>
    </message>
    <message>
        <source>Remove selected orders.</source>
        <translation>Премахни избраните степени.</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли, което и да е от полетата по-горе.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderstatistics</name>
    <message>
        <source>Product statistics [%count]</source>
        <translation>Статистики на продукти [%count]</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Сума (без ДДС)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>All years</source>
        <translation>Всички години</translation>
    </message>
    <message>
        <source>All months</source>
        <translation>Всички месеци</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Покажи</translation>
    </message>
    <message>
        <source>SUM</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation>Списъкът е празен.</translation>
    </message>
    <message>
        <source>Select the year for which you wish to view statistics.</source>
        <translation>Избери годината, за която искате да видите статистики.</translation>
    </message>
    <message>
        <source>Select the month for which you wish to view statistics.</source>
        <translation>Изберте месеца, за който искате да видите статистики.</translation>
    </message>
    <message>
        <source>Update the list using the values specified by the menus on the left.</source>
        <translation>Обнови списъка, използвайки стойностите, които са определени в менютата вляво.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderview</name>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Елементи на продукта</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Брояч</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без ДДС</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с ДДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Пълна цена без ДДС</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Пълна цена с ДДС</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Резюме поръчката</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Междинна сума на елементите</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Обща сума на поръчката</translation>
    </message>
    <message>
        <source>Remove this order.</source>
        <translation>Премахни тази поръчката.</translation>
    </message>
    <message>
        <source>Order #%order_id [%order_status]</source>
        <translation>Поръчка #%order_id [%order_status]</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Person</source>
        <translation>Човек</translation>
    </message>
    <message>
        <source>This is the person which modified the status of the order. Click to view the user information.</source>
        <translation>Това е човекът, който промени статуса на поръчката. Натиснете тук, за да разглеждате информацията за потребителя.</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избрани опции</translation>
    </message>
    <message>
        <source>Status history [%status_count]</source>
        <translation>История на статуса [%status_count]</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/removeorder</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Confirm order removal</source>
        <translation>Потвърди премахването на поръчката</translation>
    </message>
    <message>
        <source>Are you sure you want to remove order #%order_number?</source>
        <translation>Сигурни ли сте, че искате да премахнете поръчка #%order_number?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the following orders?</source>
        <translation>Сигурни ли сте, че искате да премахнете следните поръчки?</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/status</name>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Натиснете този бутон, за да съхранте промените, ако сте променяли което и да е от полетата по-горе.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Status ID</source>
        <translation>Статус ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Select order status for removal.</source>
        <translation>Избери статус на поръчка за премахване.</translation>
    </message>
    <message>
        <source>Check this if you want the status to be usable in the shopping system.</source>
        <translation>Проверите това, ако искате статусът да бъде използваем в системата за пазаруване.</translation>
    </message>
    <message>
        <source>There are no order statuses.</source>
        <translation>Няма статуси на поръчки.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected order statuses.</source>
        <translation>Премахни избраното статуси на поръчки.</translation>
    </message>
    <message>
        <source>New order status</source>
        <translation>Нов статус на поръчка</translation>
    </message>
    <message>
        <source>Create a new order status.</source>
        <translation>Създай нов статус на поръчка.</translation>
    </message>
    <message>
        <source>Order status [%order_status]</source>
        <translation>Статус на поръчка [%order_status]</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/userregister</name>
    <message>
        <source>Required information is missing...</source>
        <translation>Нужната информация липсва....</translation>
    </message>
    <message>
        <source>Please please fill in the fields that are marked with a star.</source>
        <translation>Моля, попълнете полето, което е маркирано със звезда.</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Информация за акаунта</translation>
    </message>
    <message>
        <source>Please fill in the necessary information. Required fields are marked with a star.</source>
        <translation>Моля, попълнете необходимата информация. Необходимите полета са маркирани със звезда.
</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Първо име</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Фамилия</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Компания</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Улица</translation>
    </message>
    <message>
        <source>ZIP code</source>
        <translation>Пощенски код</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Град</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Коментари</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/vattype</name>
    <message>
        <source>VAT types [%vat_types]</source>
        <translation>ДДС типове (%vat_types]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select VAT type for removal.</source>
        <translation>Избери ДДС тип за премахване.</translation>
    </message>
    <message>
        <source>There are no VAT types.</source>
        <translation>Няма ДДС типове.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected VAT types.</source>
        <translation>Премахни избраните ДДС типове.</translation>
    </message>
    <message>
        <source>New VAT type</source>
        <translation>Нов ДДС тип</translation>
    </message>
    <message>
        <source>Create a new VAT type.</source>
        <translation>Създай нов ДДС тип.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли което и да е от полетата по-горе.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/wishlist</name>
    <message>
        <source>My wish list [%item_count]</source>
        <translation>Моя списък с желания (%item_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Цена (без ДДС)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Цена (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Total price (ex. VAT)</source>
        <translation>Пълна цена (без ДДС)</translation>
    </message>
    <message>
        <source>Total price (inc. VAT)</source>
        <translation>Пълна цена (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Избери елемент за премахване.</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избери опции</translation>
    </message>
    <message>
        <source>The wish list is empty.</source>
        <translation>Списъкът с желания е празен.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected items.</source>
        <translation>Премахни избраните елементи.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified quantity and/or option values.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли количество и/или променливи.</translation>
    </message>
</context>
<context>
    <name>design/admin/trigger/list</name>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Connection type</source>
        <translation>Тип връзка</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Работен поток</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Няма работен поток</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Workflow triggers [%trigger_count]</source>
        <translation>Тригери от работен поток [%trigger_count]</translation>
    </message>
    <message>
        <source>Select the workflow that should be triggered %type the %function function is executed within the %module module.</source>
        <translation>Изберете работния поток, който трябваше да е активирал функция %type the %function приложена в модул %module.</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли което и да е от полетата по-горе.</translation>
    </message>
</context>
<context>
    <name>design/admin/url/edit</name>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Edit URL #%url_id</source>
        <translation>Редактирай уеб адрес #%url_id</translation>
    </message>
</context>
<context>
    <name>design/admin/url/list</name>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Valid URLs [%url_list_count]</source>
        <translation>Валидни уеб адреси [%url_list_count]</translation>
    </message>
    <message>
        <source>Invalid URLs [%url_list_count]</source>
        <translation>Невалидни уеб адреси [%url_list_count]</translation>
    </message>
    <message>
        <source>All URLs [%url_list_count]</source>
        <translation>Всички уеб адреси [%url_list_count]</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Валиден</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Невалиден</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Проверен</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>open</source>
        <translation>отворен</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никога</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>Show all URLs.</source>
        <translation>Покажи всички уеб адреси.</translation>
    </message>
    <message>
        <source>Show only invalid URLs.</source>
        <translation>Покажи само невалидните уеб адреси.</translation>
    </message>
    <message>
        <source>Show only valid URLs.</source>
        <translation>Покажи само валидните уеб адреси.</translation>
    </message>
    <message>
        <source>View information about URL.</source>
        <translation>Виж информацията за уеб адрес.</translation>
    </message>
    <message>
        <source>Open URL in new window.</source>
        <translation>Отвори уеб адрес в нов прозорец.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit URL.</source>
        <translation>Редактирай уеб адрес.</translation>
    </message>
    <message>
        <source>The requested list is empty.</source>
        <translation>Исканият списък е празен.</translation>
    </message>
</context>
<context>
    <name>design/admin/url/view</name>
    <message>
        <source>URL #%url_id</source>
        <translation>Уеб адрес #%url_id</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Валиден</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Невалиден</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Последно проверен</translation>
    </message>
    <message>
        <source>This URL has not been checked.</source>
        <translation>Този уеб адрес не е проверен.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Objects using URL #%url_id [%url_count]</source>
        <translation>Обекти използващи уеб адрес #%url_id [%url_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>URL #%url_id is not in use by any objects.</source>
        <translation>Уеб адресът не се използва от каквито и да е обекти #%url_id.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Edit this URL.</source>
        <translation>Редактирай този уеб адрес.</translation>
    </message>
    <message>
        <source>Edit &lt;%object_name&gt;.</source>
        <translation>Редактирай &lt;%object_name&gt;.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Чернова</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Предстоящ</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Архивиран</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Отхвърлен</translation>
    </message>
    <message>
        <source> (in trash)</source>
        <translation>(в кошчето)</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
        <translation>Разгледайте съдържанието на версия #%version_number. Превод по подразбиране: %default_translation.</translation>
    </message>
</context>
<context>
    <name>design/admin/user</name>
    <message>
        <source>Activate account</source>
        <translation>Активирай акаунт</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Регистриран потребител</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Вашият акаунт е активиран в момента.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Съжалявам, ключът, който е изпратен, не е беше валиден. Акаунтът не е активиран.</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Вашият акаунт беше успешно създаден. Е-мейл ще бъде изпратена към определения е-мейл адрес.
Трябва да следвате инструкциите в е-мейла, за да активирате ствоя акаунт.

</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Вашият акаунт беше успешно създаден.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/admin/user/login</name>
    <message>
        <source>The system could not log you in.</source>
        <translation>Не можете да влезете в системата.</translation>
    </message>
    <message>
        <source>Make sure that the username and password is correct.</source>
        <translation>Уверите се, че потребителското име и парола са правилни.</translation>
    </message>
    <message>
        <source>All letters must be typed in using the correct case.</source>
        <translation>Всички букви трябва да бъдат въведени, използвайки големите или малки букви, според начина, по който са били зададени.</translation>
    </message>
    <message>
        <source>Please try again or contact the site administrator.</source>
        <translation>Моля опитайте пак или се свържете с администратора на сайта.</translation>
    </message>
    <message>
        <source>Access denied!</source>
        <translation>Достъпът отказан!</translation>
    </message>
    <message>
        <source>You do not have permissions to access &lt;%siteaccess_name&gt;.</source>
        <translation>Нямате права за достъп &lt;%siteaccess_name&gt;.</translation>
    </message>
    <message>
        <source>Please contact the site administrator.</source>
        <translation>Моля, свържете се с администратора на страницата.</translation>
    </message>
    <message>
        <source>Log in to the administration interface of eZ publish</source>
        <translation>Влезте в администраторския интерфейс на eZ publish</translation>
    </message>
    <message>
        <source>Please enter a valid username/password combination and click &quot;Log in&quot;.</source>
        <translation>Моля, въведете правилно потребителското име и парола и натиснете &quot;Вход&quot;.</translation>
    </message>
    <message>
        <source>Use the &quot;Register&quot; button to create a new account.</source>
        <translation>Използвайте бутона &quot;Регистрация&quot; за създаване на нов акаунт.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Enter a valid username into this field.</source>
        <translation>Въведи валидно потребителско име в това поле.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Enter a valid password into this field.</source>
        <translation>Въведете валидна парола в това поле.</translation>
    </message>
    <message>
        <source>Log in</source>
        <comment>Login button</comment>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Click here to log in using the username/password combination entered in the fields above.</source>
        <translation>Натиснете тук за влизане, използвайки комбинацията потребителско име/парола, която е въведена в полетата по-горе.</translation>
    </message>
    <message>
        <source>Register</source>
        <comment>Register button</comment>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Click here to create a new account.</source>
        <translation>Натиснете тук за създаване на нов акаунт.</translation>
    </message>
</context>
<context>
    <name>design/admin/user/password</name>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Стара парола</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Нова парола</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>The password could not be changed.</source>
        <translation>Паролата не може да бъде променена.</translation>
    </message>
    <message>
        <source>The old password was either missing or incorrect.</source>
        <translation>Старата парола липсва или е непълна.</translation>
    </message>
    <message>
        <source>Please retype the old password and try again.</source>
        <translation>Моля, въведете отново старата парола и опитайте пак.</translation>
    </message>
    <message>
        <source>The new passwords did not match.</source>
        <translation>Новите пароли не съвпадат.</translation>
    </message>
    <message>
        <source>Please retype the new passwords and try again.</source>
        <translation>Моля, въведете отново новите пароли и опитайте пак.</translation>
    </message>
    <message>
        <source>The password was successfully changed.</source>
        <translation>Паролата беше успешно променена.</translation>
    </message>
    <message>
        <source>Change password for &lt;%username&gt;</source>
        <translation>Промени парола за &lt;%username&gt;</translation>
    </message>
    <message>
        <source>Confirm new password</source>
        <translation>Потвърди новата парола</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters long.</source>
        <translation>Паролата трябва да съдържа повече от 3 символа.</translation>
    </message>
</context>
<context>
    <name>design/admin/user/register</name>
    <message>
        <source>The information could not be stored...</source>
        <translation>Тази информация не може да бъде запазена...</translation>
    </message>
    <message>
        <source>The following information is either incorrect or missing</source>
        <translation>Следната информация е неправилна или липсва</translation>
    </message>
    <message>
        <source>Please correct the inputs (marked with red labels) and try again.</source>
        <translation>Моля, поправете входящата информация (маркирана в червено) и опитайте отново.</translation>
    </message>
    <message>
        <source>Register new user</source>
        <translation>Регистрирай нов потребител</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Не може да бъде регистриран нов потребител</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
<context>
    <name>design/admin/user/setting</name>
    <message>
        <source>Maximum concurrent logins</source>
        <translation>Максимум брой едновременни влизания</translation>
    </message>
    <message>
        <source>Enable user account</source>
        <translation>Активирай акаунта на потребителя</translation>
    </message>
    <message>
        <source>Use this checkbox to enable or disable the user account.</source>
        <translation>Чрез тези чекбоксове активирайте или деактивирайте акаунта на потребителя.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]</source>
        <translation>Тази функционалност в момента не е налична..(Използвайте това поле, за да определите максималния допустим брой на едновременни влизания.]</translation>
    </message>
    <message>
        <source>User settings for &lt;%user_name&gt;</source>
        <translation>Потребителски настройки за &lt;%user_name&gt;</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/menuconfig</name>
    <message>
        <source>Menu management</source>
        <translation>Управление на меню</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Menu positioning</source>
        <translation>Позициониране на меню</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click here to store the changes if you have modified the menu settings above.</source>
        <translation>Натиснете тук, за да съхраните промените, ако сте променяли настройките на менюто по-горе.</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templatecreate</name>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Не можете да създадете шаблон, разрешение отказано.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Грешно име. Можете  да използвате само буквите A - Z, числа и _.</translation>
    </message>
    <message>
        <source>Create new template override for &lt;%template_name&gt;</source>
        <translation>Създайте нов шаблон за &lt;%template_name&gt;</translation>
    </message>
    <message>
        <source>The newly created template file will be placed in</source>
        <translation>Току-що създаденият файл на шаблона ще бъде поставен в</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Име на файл</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Отмени ключове</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Всички класове</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Всички функции</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID на Възел</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Включен основен шаблон</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Празен файл</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Копие на стандартния шаблон</translation>
    </message>
    <message>
        <source>Container (with children)</source>
        <translation>Кутия (с дъщерни елементи)</translation>
    </message>
    <message>
        <source>View (without children)</source>
        <translation>Изглед (без дъщерни елементи)</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Обект</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templateedit</name>
    <message>
        <source>Edit template: &lt;%template&gt;</source>
        <translation>Редактирай шаблон: &lt;%template&gt;</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Приложи промените</translation>
    </message>
    <message>
        <source>Click this button to save the contents of the text field above to the template file.</source>
        <translation>Натиснете този бутон за запазване съдържанието на полето за текст по-горе към файла на шаблона.</translation>
    </message>
    <message>
        <source>Back to overrides</source>
        <translation>Обратно към пълномощни</translation>
    </message>
    <message>
        <source>Back to override overview.</source>
        <translation>Обратно към изглед на пълномощно.</translation>
    </message>
    <message>
        <source>You do not have permissions to save the contents of the text field above to the template file.</source>
        <translation>Нямате права за запазване на съдържанията на полето за текст върху файла на шаблона.</translation>
    </message>
    <message>
        <source>The template can not be edited.</source>
        <translation>Шаблонът може да бъде редактиран.</translation>
    </message>
    <message>
        <source>The web server does not have write access to the requested template.</source>
        <translation>Уеб сървърът няма достъп за писане до искания шаблон.</translation>
    </message>
    <message>
        <source>The web server does not have read access to the requested template.</source>
        <translation>Уеб сървърът няма достъп за четене до искания шаблон.</translation>
    </message>
    <message>
        <source>The requested template does not exist or is not being used as an override.</source>
        <translation>Исканият шаблон не съществува или не е използван като пълномощно.</translation>
    </message>
    <message>
        <source>Edit &lt;%template_name&gt; [Template]</source>
        <translation>Редактирай  &lt;%section_name&gt; (Шаблон)</translation>
    </message>
    <message>
        <source>Requested template</source>
        <translation>Зададен шаблон</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Overrides template</source>
        <translation>Пълномощни шаблони</translation>
    </message>
    <message>
        <source>Open as read only</source>
        <translation>Отвори само за четене</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templatelist</name>
    <message>
        <source>Complete template list</source>
        <translation>Завършен списък на шаблон</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Design resource</source>
        <translation>Дизайн ресурси</translation>
    </message>
    <message>
        <source>Manage overrides for template.</source>
        <translation>Управление на пълномощни за шаблон.</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Най-често използвани шаблони</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templateview</name>
    <message>
        <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
        <translation>Пълномощни за шаблон &lt;%template_name&gt; в &lt;%current_siteaccess&gt; достъп до сайт [%override_count]</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Стандартен ресурс на шаблон</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Съчетай условия</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Edit override template.</source>
        <translation>Редактирай пълномощен шаблон.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected template overrides.</source>
        <translation>Премахни избраните пълномощни шаблони.</translation>
    </message>
    <message>
        <source>New override</source>
        <translation>Ново пълномощно</translation>
    </message>
    <message>
        <source>Create a new template override.</source>
        <translation>Създай нов пълномощник на шаблон.</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритети</translation>
    </message>
    <message>
        <source>The overrides could not be removed.</source>
        <translation>Пълномощните не могат да бъдат премахнати.</translation>
    </message>
    <message>
        <source>The following files and override rules could not be removed because of insufficient file permissions</source>
        <translation>Следните файлове и пълномощни права не можег да бъдат премахнати заради недостатъчни права върху файла</translation>
    </message>
    <message>
        <source>The override.ini file could not be modified because of insufficient permissions.</source>
        <translation>Файлът на пълномощно ini не може да бъде променен заради недостатъчни права.</translation>
    </message>
    <message>
        <source>No file matched</source>
        <translation>Файлът не съвпада</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/toolbar</name>
    <message>
        <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
        <translation>Списък с инструменти за &lt;Toolbar_%toolbar_position&gt;</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>There are currently no tools in this toolbar</source>
        <translation>В момента няма инструменти в този тулбар</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритети</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Добави инструмент</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified the parameters above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли който и да е от параметрите по-горе.</translation>
    </message>
    <message>
        <source>Back to toolbars</source>
        <translation>Обратно към лента с инструменти</translation>
    </message>
    <message>
        <source>Go back to the toolbar list.</source>
        <translation>Върни се към списъка на лентата с инструменти.</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на лента с инструменти</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Текущ siteaccess</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
        <translation>Налични тулбарове за достъп до сайт &lt;%siteaccess&gt;</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/edit</name>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е потвърдена</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Информацията изисква поправка</translation>
    </message>
    <message>
        <source>Edit &lt;%workflow_name&gt; [Workflow]</source>
        <translation>Редактирай &lt;%workflow_name&gt; (Работен поток)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>Надолу</translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>Нагоре</translation>
    </message>
    <message>
        <source>Description / comments</source>
        <translation>Описание / коментари</translation>
    </message>
    <message>
        <source>There are no events within this workflow.</source>
        <translation>Няма събитие в работния поток.</translation>
    </message>
    <message>
        <source>Remove selected events</source>
        <translation>Премахни избраните елементи</translation>
    </message>
    <message>
        <source>Add event</source>
        <translation>Добави резултат</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
        <source>Affected sections</source>
        <translation>Засегнати секции</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Всички секции</translation>
    </message>
    <message>
        <source>User who approves content</source>
        <translation>Потребител, който одобрява съдържание</translation>
    </message>
    <message>
        <source>Excluded users and groups</source>
        <translation type="obsolete">Отхвурлени потребители и групи</translation>
    </message>
    <message>
        <source>All users and groups</source>
        <translation type="obsolete">Всички потребители и групи</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Класове за пускане на работен поток</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Всички класове</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Потребители без IDта за работни потоци </translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Работен поток за пускане</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Обнови атрибутите</translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation>Атрибут</translation>
    </message>
    <message>
        <source>Select attribute</source>
        <translation>Избери атрибут</translation>
    </message>
    <message>
        <source>Class/attribute combinations [%count]</source>
        <translation>Комбинации на класове/атрибути [%count]</translation>
    </message>
    <message>
        <source>There are no combinations</source>
        <translation>Няма комбинации</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Modify the objects&apos; publishing dates</source>
        <translation>Промени обектите, (публикуващи дати)</translation>
    </message>
    <message>
        <source>There are no payment Gateway extensions installed.</source>
        <translation>Няма инсталирани разширения на пътя за плащане.</translation>
    </message>
    <message>
        <source>Please install a payment extension first.</source>
        <translation>Моля, инсталирайте първо разширение за плащане.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Потребител</translation>
    </message>
    <message>
        <source>No user selected.</source>
        <translation>Няма избран потребител.</translation>
    </message>
    <message>
        <source>Add user</source>
        <translation>Добави потребител</translation>
    </message>
    <message>
        <source>Excluded user groups ( users in these groups do not need to have their content approved )</source>
        <translation>Изключени групи потребители (потребителите в тези групи не се нуждаят от одобрение на съдържанието им)</translation>
    </message>
    <message>
        <source>User and user groups</source>
        <translation>Потребител и потребителски групи</translation>
    </message>
    <message>
        <source>No groups selected.</source>
        <translation>Няма избрани групи.</translation>
    </message>
    <message>
        <source>Add groups</source>
        <translation>Добави групи</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/groupedit</name>
    <message>
        <source>Edit &lt;%group_name&gt; [Workflow group]</source>
        <translation>Редактирай &lt;%group_name&gt; (Работен поток)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/grouplist</name>
    <message>
        <source>Workflow groups [%groups_count]</source>
        <translation>Групи на работен поток [%groups_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>There are no workflow groups.</source>
        <translation>Няма групи на работен поток.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected workflow groups.</source>
        <translation>Премахни избраните групи на работен поток.</translation>
    </message>
    <message>
        <source>New workflow group</source>
        <translation>Нов работен поток на група</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select workflow group for removal.</source>
        <translation>Избери работен поток на група за пренахване.</translation>
    </message>
    <message>
        <source>Edit the &lt;%workflow_group_name&gt; workflow group.</source>
        <translation>Редактирай работен поток на група &lt;%workflow_group_name&gt;.</translation>
    </message>
    <message>
        <source>Create a new workflow group.</source>
        <translation>Създай нова група за работен поток.</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/view</name>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е потвърдена</translation>
    </message>
    <message>
        <source>%workflow_name [Workflow]</source>
        <translation>%workflow_name (Работен поток)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Member of groups [%group_count]</source>
        <translation>Член на групи (%group_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Група</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Добави към група</translation>
    </message>
    <message>
        <source>No group</source>
        <translation>Няма група</translation>
    </message>
    <message>
        <source>Events [%event_count]</source>
        <translation>Събития (%event_count]</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Допълнителна информация</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/workflowlist</name>
    <message>
        <source>%group_name [Workflow group]</source>
        <translation>%group_name (Работен поток)</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Workflows [%workflow_count]</source>
        <translation>Работни потоци [%workflow_count]</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>There are no workflows in this group.</source>
        <translation>Няма работни потоци в тази група.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Нов работен поток</translation>
    </message>
    <message>
        <source>Edit this workflow group.</source>
        <translation>Редактирай тази група на работен поток.</translation>
    </message>
    <message>
        <source>Remove this workflow group.</source>
        <translation>Премахни тези групи на работни потоци.</translation>
    </message>
    <message>
        <source>Back to workflow groups.</source>
        <translation>Обратно към групи на работни потоци.</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Select workflow for removal.</source>
        <translation>Избери работен поток за премахване.</translation>
    </message>
    <message>
        <source>Edit the &lt;%workflow_name&gt; workflow.</source>
        <translation>Редактирай работния поток &lt;%workflow_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected workflows.</source>
        <translation>Премахни избраните работни потоци.</translation>
    </message>
    <message>
        <source>Create a new workflow.</source>
        <translation>Създай нов работен поток.</translation>
    </message>
</context>
<context>
    <name>design/base</name>
    <message>
        <source>Back to poll</source>
        <translation>Обратно към анкета</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Съобщи ми при промяна</translation>
    </message>
    <message>
        <source>Sticky</source>
        <translation>Проблемен</translation>
    </message>
    <message>
        <source>Create new weblog</source>
        <translation>Създай нов уеблог</translation>
    </message>
    <message>
        <source>Read more...</source>
        <translation>Прочети повече...</translation>
    </message>
    <message>
        <source>Contact information</source>
        <translation>Информация за контакт</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Допълнителна информация</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Поздрави приятел</translation>
    </message>
    <message>
        <source>Download PDF</source>
        <translation>Свали PDF</translation>
    </message>
    <message>
        <source>Download PDF version of this page</source>
        <translation>Сваляне на PDF версия на страницата</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Коментари</translation>
    </message>
    <message>
        <source>New Comment</source>
        <translation>Нов Коментар</translation>
    </message>
    <message>
        <source>You are not allowed to create comments.</source>
        <translation>Нямате права за създаване на коментари.</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Контакти</translation>
    </message>
    <message>
        <source>Your E-mail address</source>
        <translation>Вашият e-mail адрес</translation>
    </message>
    <message>
        <source>Send form</source>
        <translation>Изпрати форма</translation>
    </message>
    <message>
        <source>New topic</source>
        <translation>Следваща тема</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Дръж ме в течение</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Трябва да сте влезли, за да получите дотъп до форумите. Можете да го направите така %login_link_start%here%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Отговори</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Последен отговор</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Страници</translation>
    </message>
    <message>
        <source>Message preview</source>
        <translation>Преглед на съобщение</translation>
    </message>
    <message>
        <source>Previous topic</source>
        <translation>Предишна тема</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Следваща тема</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Нов отговор</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so</source>
        <translation>Трябва да сте влезли, за да получите дотъп до форумите. Можете да го направите така</translation>
    </message>
    <message>
        <source>here</source>
        <translation>тук</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Ръководен от</translation>
    </message>
    <message>
        <source>View as slideshow</source>
        <translation>Виж като слайд-шоу</translation>
    </message>
    <message>
        <source>Previous image</source>
        <translation>Предишно изображение</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Следващо изображение</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Резултат</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Добави към кошница</translation>
    </message>
    <message>
        <source>Download this product sheet as PDF</source>
        <translation>Сваляне на тази брошура за продукта като PDF</translation>
    </message>
    <message>
        <source>Product reviews</source>
        <translation>Прегледи на продукт </translation>
    </message>
    <message>
        <source>New review</source>
        <translation>Нов преглед</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Хората, които купиха този продукт, купиха също</translation>
    </message>
    <message>
        <source>Previous entry</source>
        <translation>Предишно влизане</translation>
    </message>
    <message>
        <source>Next entry</source>
        <translation>Следващо влизане</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Нов коментар</translation>
    </message>
    <message>
        <source>More...</source>
        <translation>Повече...</translation>
    </message>
    <message>
        <source>View flash</source>
        <translation>Виж кратко съобщение</translation>
    </message>
    <message>
        <source>View list</source>
        <translation>Виж списък</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Влез във форум</translation>
    </message>
    <message>
        <source>Enter gallery</source>
        <translation>Влез в галерия</translation>
    </message>
    <message>
        <source>Vote</source>
        <translation>Гласувай</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Повече информация</translation>
    </message>
    <message>
        <source>View movie</source>
        <translation>Виж филм</translation>
    </message>
    <message>
        <source>in</source>
        <translation>в</translation>
    </message>
    <message>
        <source>View comments</source>
        <translation>Виж коментари</translation>
    </message>
    <message>
        <source>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</source>
        <translation>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</translation>
    </message>
    <message>
        <source>Top menu</source>
        <translation>Най-горно меню</translation>
    </message>
    <message>
        <source>Sub menu</source>
        <translation>Подменю</translation>
    </message>
    <message>
        <source>Left menu</source>
        <translation>Ляво меню</translation>
    </message>
    <message>
        <source>Left sub menu</source>
        <translation>Ляво подменю</translation>
    </message>
    <message>
        <source>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</source>
        <translation>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</translation>
    </message>
    <message>
        <source>Details...</source>
        <translation>Детайли...</translation>
    </message>
    <message>
        <source>Poll %pollname</source>
        <translation>Анкета %pollname</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Резултати</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Анонимни потребители не могат да гласуват в тази анкета, моля. влезте.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Вие вече сте гласували в тази анкета.</translation>
    </message>
    <message>
        <source>Votes</source>
        <translation>Гласове</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count общо гласове</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Събрана информация от %1</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>Следната информация беше събрана</translation>
    </message>
    <message>
        <source>The file could not be found.</source>
        <translation>Файлът не може да бъде намерен.</translation>
    </message>
    <message>
        <source>New row</source>
        <translation>Нова редица</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Стойност</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Ващата цена</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Спестявате</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Редактирай %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Изпрати за публикация</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Публикувай</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>Запис</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Преглед</translation>
    </message>
    <message>
        <source>Latest from</source>
        <translation>Най-нов</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Number of Topics</source>
        <translation>Брой теми</translation>
    </message>
    <message>
        <source>Number of Posts</source>
        <translation>Брой съобщения</translation>
    </message>
    <message>
        <source>%count votes</source>
        <translation>%count гласове</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Автор:</translation>
    </message>
    <message>
        <source>#page of #total</source>
        <translation>#page of #total</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>За повече възможности опитайте %1 Разширено търсене %2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Следните думи бяха изключени от търсенето</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Не са намерени резултати от търсенето на &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Техники на търсене</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Провери правописа на ключовите думи.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Опитайте да промените някои ключови думи, например кола вместо коли.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Опитайте с повече основни ключови думи.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>По-малко ключови думи водят до повече резултати, опитайте да намалите ключовите думи, докато получите резултат.</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Търсенето на &quot;%1&quot; върна %2 съвпадения</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>Предишен</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>Reply to:</source>
        <translation>Отговори на:</translation>
    </message>
</context>
<context>
    <name>design/base/shop</name>
    <message>
        <source>Quantity</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Цена</translation>
    </message>
    <message>
        <source>Total Price</source>
        <translation>Обща Цена</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Кошница</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Следните елементи бяха премахнати от вашата кошница, защото продуктите са били променени</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Опитвате се да прибавите обект без цена към кошницата.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Вашето плащане беше прекратено.</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избрани опции</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT</source>
        <translation>Междинна сума (вкл. ДДС)</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Проверка</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Продължи пазаруване</translation>
    </message>
    <message>
        <source>Store quantities</source>
        <translation>Съхрани количествата</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Нямате продукти в кошницата</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Потвърди поръчката</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Елементи на продукта</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Резюме на поръчката</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Междинна сума на елементите</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Общ сума на поръчката</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Поръчка %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>История на поръчката</translation>
    </message>
</context>
<context>
    <name>design/plain/layout</name>
    <message>
        <source>Advanced search</source>
        <translation type="obsolete">Разширено търсене</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Търсене</translation>
    </message>
</context>
<context>
    <name>design/standard/class</name>
    <message>
        <source>Class is locked</source>
        <translation>Класът е заключен</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Опитай отново</translation>
    </message>
</context>
<context>
    <name>design/standard/class/classlist</name>
    <message>
        <source>No classes in </source>
        <translation>Няма класове в</translation>
    </message>
    <message>
        <source>Click on the &apos;New&apos; button to create a class.</source>
        <translation>Натиснете бутона &apos;Нов&apos;, за да създадете клас.</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Класове в</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Брояч на обекти</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Нов клас</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Последно модифицирани класове</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size</source>
        <translation>Максимален размер на файл</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Стойност по подразбиране</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Празен</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Текуща дата</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Текуща дата и време</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Многостранен избор</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Кратко съобщение</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real Player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Уиндоус медия плеър</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с ДДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без ДДС</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Текущо време</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Минимално отклонение на стойност</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Максимално отклонение на стойност</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Миниимална стойност на цяло число</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Максимална стойност на цяло число</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Име по подразбиране</translation>
    </message>
    <message>
        <source>Default number of rows</source>
        <translation>Брой на редове по подразбиране</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Тип медия плейър</translation>
    </message>
    <message>
        <source>Allowed classes</source>
        <translation>Позволени класове</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>ДДС тип</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Максимална дължина на стринга</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Предпочитан брой редове</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Нова опция</translation>
    </message>
    <message>
        <source>Pretext</source>
        <translation>предварителен текст</translation>
    </message>
    <message>
        <source>Posttext</source>
        <translation>Последващ текст</translation>
    </message>
    <message>
        <source>Digits</source>
        <translation>Цифри</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Начална стойност</translation>
    </message>
    <message>
        <source>Ini file</source>
        <translation>Ini файл</translation>
    </message>
    <message>
        <source>Ini Section</source>
        <translation>Ini Секция</translation>
    </message>
    <message>
        <source>Ini Parameter</source>
        <translation>Ini Параметър</translation>
    </message>
    <message>
        <source>Ini file location</source>
        <translation>Ini файл на местоположение</translation>
    </message>
    <message>
        <source>Ini setting type</source>
        <translation>Ini тип на настройка</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <source>Enable/Disable</source>
        <translation>Включен/Изключен</translation>
    </message>
    <message>
        <source>True/False</source>
        <translation>Вярно/Грешно</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Цяло число</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Отклонение</translation>
    </message>
    <message>
        <source>Array</source>
        <translation>Масив</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>New and existing objects</source>
        <translation>Нови и съществуващи обекти</translation>
    </message>
    <message>
        <source>Only new objects</source>
        <translation>Само нови обекти</translation>
    </message>
    <message>
        <source>Only existing objects</source>
        <translation>Само съществуващи обекти</translation>
    </message>
    <message>
        <source>Select which classes user can create</source>
        <translation>Избери кои класове потребителят може да създаде</translation>
    </message>
    <message>
        <source>Package Type</source>
        <translation>Тип на пакета</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Проверен</translation>
    </message>
    <message>
        <source>Unchecked</source>
        <translation>Непроверен</translation>
    </message>
    <message>
        <source>Single choice</source>
        <translation>Единствен избор</translation>
    </message>
    <message>
        <source>Warning, the ini file settings value and object value does not match.</source>
        <translation>Внимание: стойността в началния файл и стойността на обекта не съвпадат.</translation>
    </message>
    <message>
        <source>The ini file has probably been modified manually since last time.</source>
        <translation>Началният файл вероятно е бил променен ръчно.</translation>
    </message>
    <message>
        <source>Ini File : </source>
        <translation>Ini Файл : </translation>
    </message>
    <message>
        <source>Ini Value: </source>
        <translation>Ini Стойност: </translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Разрешен</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Изключен</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Adjusted current datetime</source>
        <translation>Нагласено текущо време</translation>
    </message>
    <message>
        <source>Selection method</source>
        <translation>Метод на селекция</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Dropdown list</source>
        <translation>Падащ списък</translation>
    </message>
    <message>
        <source>Dropdown tree</source>
        <translation>Падащо дърво</translation>
    </message>
    <message>
        <source>Remove selection</source>
        <translation>Премахни селекцията</translation>
    </message>
    <message>
        <source>Allow fuzzy match</source>
        <translation>Позволи неясно съвпадение</translation>
    </message>
    <message>
        <source>Make empty array</source>
        <translation>Направи празен масив</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Година</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Месец</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Ден</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Час</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Минута</translation>
    </message>
    <message>
        <source>View Mode</source>
        <translation>Виж режима</translation>
    </message>
    <message>
        <source>Drop-down list</source>
        <translation>Падащ списък </translation>
    </message>
    <message>
        <source>Drop-down tree</source>
        <translation>Падащо дърво</translation>
    </message>
    <message>
        <source>There are no elements in the list.</source>
        <translation>Няма елементи в списъка.</translation>
    </message>
    <message>
        <source>New element</source>
        <translation>Нов елемент</translation>
    </message>
    <message>
        <source>Add a new enum element.</source>
        <translation>Добави нов изброяващ елемент.</translation>
    </message>
    <message>
        <source>Remove selected elements.</source>
        <translation>Премахни избраните елементи.</translation>
    </message>
    <message>
        <source>Current value</source>
        <translation>Текуща стойност</translation>
    </message>
    <message>
        <source>Columns</source>
        <translation>Колони</translation>
    </message>
    <message>
        <source>Matrix column</source>
        <translation>Колона на матрица</translation>
    </message>
    <message>
        <source>The matrix does not have any columns.</source>
        <translation>Матрицата не съдържа никакви колони.</translation>
    </message>
    <message>
        <source>New column</source>
        <translation>Нова колона</translation>
    </message>
    <message>
        <source>Add a new column.</source>
        <translation>Добави нова колона.</translation>
    </message>
    <message>
        <source>Remove selected columns.</source>
        <translation>Премахни избраните колони.</translation>
    </message>
    <message>
        <source>Default location for objects</source>
        <translation>Местоположение по подразбиране за обекти</translation>
    </message>
    <message>
        <source>New objects will not be placed in the content tree.</source>
        <translation>Новите обекти няма да бъдат поставени в дървото със съдържанието.</translation>
    </message>
    <message>
        <source>Select location</source>
        <translation>Избери местоположение</translation>
    </message>
    <message>
        <source>Remove location</source>
        <translation>Премахни местоположение</translation>
    </message>
    <message>
        <source>Select option for removal.</source>
        <translation>Избери опции за премахване.</translation>
    </message>
    <message>
        <source>There are no options.</source>
        <translation>Няма опции.</translation>
    </message>
    <message>
        <source>Add a new option.</source>
        <translation>Добави нова опция.</translation>
    </message>
    <message>
        <source>Remove selected options.</source>
        <translation>Премахни избраните опции.</translation>
    </message>
    <message>
        <source>Current date and time adjusted by</source>
        <translation>Текущата дата и време са нагласени от</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Стил</translation>
    </message>
    <message>
        <source>Checkboxes / radiobuttons</source>
        <translation>Чек-боксове / радиобутони</translation>
    </message>
    <message>
        <source>Dropdown menu / multi menu</source>
        <translation>Падащо меню / мулти меню</translation>
    </message>
    <message>
        <source>Elements</source>
        <translation>Елементи</translation>
    </message>
    <message>
        <source>Element</source>
        <translation>Елемент</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Стойност</translation>
    </message>
    <message>
        <source>Default selection item</source>
        <translation>Елемент за селекция по подразбиране</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Unknown section</source>
        <translation>Неизвестна част</translation>
    </message>
    <message>
        <source>No item has been selected.</source>
        <translation>Никакъв елемент не е избран.</translation>
    </message>
    <message>
        <source>Select item</source>
        <translation>Избери елемент</translation>
    </message>
    <message>
        <source>Package type</source>
        <translation>Тип на пакета</translation>
    </message>
    <message>
        <source>View mode</source>
        <translation>Виж режима</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Комбо кутия</translation>
    </message>
    <message>
        <source>Icon view</source>
        <translation>Изглед на икона </translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Опция</translation>
    </message>
    <message>
        <source>characters</source>
        <translation>символи</translation>
    </message>
    <message>
        <source>year(s)</source>
        <translation>година(и)</translation>
    </message>
    <message>
        <source>month(s)</source>
        <translation>месец(и)</translation>
    </message>
    <message>
        <source>day(s)</source>
        <translation>ден(дни)</translation>
    </message>
    <message>
        <source>hour(s)</source>
        <translation>час(ове)</translation>
    </message>
    <message>
        <source>minute(s)</source>
        <translation>минута(и)</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <source>Dropdown menu / multiselect</source>
        <translation>Падащо меню / мулти избор</translation>
    </message>
    <message>
        <source>Radiobuttons / checkboxes</source>
        <translation>Радиобутони / чекбоксове</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>combobox</source>
        <translation>комбо-кутия</translation>
    </message>
    <message>
        <source>icon view</source>
        <translation>изглед на икона </translation>
    </message>
    <message>
        <source>Default VAT</source>
        <translation>ДДС по подразбиране</translation>
    </message>
    <message>
        <source>Default VAT type</source>
        <translation>Тип ДДС по подразбиране</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Цена</translation>
    </message>
    <message>
        <source>For more options, set &quot;AdvancedObjectRelationList&quot; to &quot;enabled&quot; in a configuration override for &quot;site.ini&quot;.</source>
        <translation>За повече опции, настройте &quot;Списък за разширена връзка на обекта&quot; на &quot;задействан&quot; в конфигурация  за &quot;site.ini&quot;.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype </name>
    <message>
        <source>Max file size</source>
        <translation>Максимален размер на файла</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Добави към група</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Премахни от групите</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е потвърдена</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Входящата информация беше съхранена успешно</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибути</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Нужно</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Търсимо</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Събиране на информация</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Надолу</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Нагоре</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Отмени промените</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Сигурни ли сте, че искате да премахнете тези класове?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Премахване на клас %1 ще премахне и %2!</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Сигурни ли сте, че искате да премахнете този клас групи?</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Схема на име на обекта</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Член на групи</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Тип данни</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Премахването на клас група %1 ще премахне и класовете %2!</translation>
    </message>
    <message>
        <source>Editing class - %1</source>
        <translation>Редактиран клас - %1</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Редактиран клас група - %1</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Последно модифициран от %username в %time </translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Изключи превод</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Модифициран от %username в %time</translation>
    </message>
    <message>
        <source>Is Container Class</source>
        <translation>Е Контейнер на Клас</translation>
    </message>
    <message>
        <source>Use this menu to select the type of attribute you wish to create. Click the &quot;add attribute&quot; button. The attribute will be appended to the bottom of the list of attributes.</source>
        <translation>Използвайте това меню, за да изберете типа атрибут, който искате да създадете. Натиснете бутона &quot;добави атрибут&quot;. Атрибутът ще бъде добавен накрая на списъка от атрибути.</translation>
    </message>
    <message>
        <source>The class should have at least one attribute and nonempty &apos;Name&apos; attribute</source>
        <translation>Класът може да има повече от един атрибут и не празно &apos;Име&apos;</translation>
    </message>
    <message>
        <source>The class %1 was already removed from the group but still exists in others.</source>
        <translation>%1 класът вече е премахнат от групата, но още съществува в другите групи.</translation>
    </message>
    <message>
        <source>The classes %1 were already removed from the group but still exist in others.</source>
        <translation>%1 класовете вече са премахнати от групата, но още съществуват в другите групи.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Class groups</source>
        <translation>Клас групи</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Нова група</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Последно модифицирани класове</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Меню за настройки</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Нов клас</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Брояч на обекти</translation>
    </message>
    <message>
        <source>Class - %1</source>
        <translation>Клас - %1</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Последно модифициран от %username в %time </translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Схема на име на обекта</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Контейнер</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Член на групи</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибути</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Изисква се</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>Не се изисква</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Търсимо</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>Не е търсимо</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Събира информация</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>Не събира информация</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>Преводът не е активиран</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>Преводът е активиран</translation>
    </message>
    <message>
        <source>Override templates</source>
        <translation>Препокриване на шаблони</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Презапиши</translation>
    </message>
    <message>
        <source>Source template</source>
        <translation>Първоначален шаблон</translation>
    </message>
    <message>
        <source>Override template</source>
        <translation>Презапиши шаблона</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Списък на групи за &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Няма елементи в групата.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Групи</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 чака за разрешение от редактора</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 е одобрено за публикуване</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 не е одобрено за публикуване</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 чака за одобрение</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Прочетен</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочетен</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивен</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Изпратен: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Няма нови обекти за обработка.</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>[more]</source>
        <translation>[още]</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Одобрение</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Обектът %1 чака одобрение за публикация.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Ако желаете, можете да изпратите съобщение на човека, който го одобрява?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Обектът %1 чака вашето одобрение за публикация.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Одобрявате ли публикуването на този обект?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Обектът %1 е одобрен и ще бъде побликуван след като процесът на публикация продължи.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Добави коментар</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Одобри</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Отказ</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Участници</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Съобщения</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Редактирай обекта</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Обектът %1 не е приет, но е наличен като чернова.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Обектът %1 не е приет, но ще бъде наличен като чернова за автора.</translation>
    </message>
    <message>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] Одобрение за &quot;%objectname&quot; изчаква вашето внимание</translation>
    </message>
    <message>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot; чака одобрение</translation>
    </message>
    <message>
        <source>You may re-edit the draft and publish it, in which case an approval is required again.</source>
        <translation>Можете да редактирате черновата и да я публикувате. В този случай отново се изисква одобрение.</translation>
    </message>
    <message>
        <source>The author can re-edit the draft and publish it again, in which a new approval item is made.</source>
        <translation>Авторът може да редактира черновата и да я публикува. В този случай се създава нов обект за одобрение.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>Тази електронна поща трябва да информира, че &quot; %objectname&quot; чака вниманието ви от %sitename.
Процесът на публикуване беше спрян и зависи от теб да решиш, ако трябва да продължи или спре.
Oдобрението може да се види, използвайки уеб адреса по-долу.
</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>Тази електронна поща трябва да информира, че &quot; %objectname&quot; изчаква одобрение от %sitename преди да е публикуван.
Ако искате изпратете коментари към лицето, което одобрява или вижте статуса, използвайки уеб адреса по-долу.</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Сигурни ли сте, че искате да премахнете този превод?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Промени превода на съдържанието</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Изберете един от преводите от списъка за промяна или въведете нов в полето за въвеждане.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Нов превод на съдържанието</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Изберете един от преводите от списъка за промяна или въведете нов в полето за въвеждане.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Направен</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Име на превод</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Смени</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Създай</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Превод на съдържание</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>По-надолу можете да откриете списък с активните преводи, в които съдържанието на обектите може да бъде преведено.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL преводач</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добави</translation>
    </message>
    <message>
        <source>Removing &apos;%1&apos; will remove the translation itself and %2 translated versions!</source>
        <translation>Премахването на &quot;%1&quot; ще премахне превода и преведената версия на %2!</translation>
    </message>
</context>
<context>
    <name>design/standard/content/browse</name>
    <message>
        <source>Create new</source>
        <translation>Създай нов</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>За да определите обект, изберете подходящия радиобутон или чек-бокс (може и няколко) и натиснете бутона &quot;Избери&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>За да изберете обект, който е наследник на някой от показаните обекти, натиснете върху името на обекта и ще видтеш списък с наследниците на обекта.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Нагоре едно ниво</translation>
    </message>
    <message>
        <source>Top levels</source>
        <translation>Най-горно ниво</translation>
    </message>
    <message>
        <source>Switch top levels by clicking one of these items.</source>
        <translation>Промяна на най-високите нива чрез избор на един от тези елементи.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Бележки</translation>
    </message>
    <message>
        <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
        <translation>Отметките се управляват чрез %bookmarkname в частта %personalname.</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои бележки</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Личен</translation>
    </message>
    <message>
        <source>Recent items</source>
        <translation>Последни елементи</translation>
    </message>
    <message>
        <source>Recent items are added on publishing.</source>
        <translation>Последните елементи са добавени при публикуването.</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Копиране на %1</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Копирай всички версии</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Копирай текущата версия</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копие</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>Версията е %1, а текущата версия е %2.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy_subtree</name>
    <message>
        <source>Copying subtree from node %1</source>
        <translation>Копирайне поддърво от възел %1</translation>
    </message>
    <message>
        <source>Copy all versions.</source>
        <translation>Копирай всички версии.</translation>
    </message>
    <message>
        <source>Copy current version.</source>
        <translation>Копирай текущата версия.</translation>
    </message>
    <message>
        <source>Keep creators of contentobjects being copied unchaged.</source>
        <translation>Запазете създателите на обектите от съдържанието, които бяха копирани непроменени.</translation>
    </message>
    <message>
        <source>Set new creator for contentobjects being copied.</source>
        <translation>Настрой нов създател за обекти от съдържанието, които бяха копирани.</translation>
    </message>
    <message>
        <source>Keep time of creation and modification of contentobjects being copied unchanged.</source>
        <translation>Запазете времето на създаване и модифициране на съдържанието на обекти, които бяха копирани непроменени.</translation>
    </message>
    <message>
        <source>Copy and publish contentobjects at current time.</source>
        <translation>Копирай и публикувай съдържание на обекти през текущото време.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy_subtree_notification</name>
    <message>
        <source>Copy Subtree Notification</source>
        <translation>Копирай известие за поддърво</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Създай нов</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Име на файл</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Година</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Месец</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Ден</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Час</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Минута</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Алернативен текст на картинката</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Премахни картинка</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Височина</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Количество</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Висок</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Най-добър</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Нисък</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Автоматично висок</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Автоматично нисък</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Автоматично възпроизвеждане</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Цикъл</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Регулатор</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Контроли</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Прозорец на картинкaтa</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Контролен панел</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>Информационен панел за обема</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Информационен панел</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Без връзка</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Начална стойност</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Крайна стойност</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Стойност на стъпката</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>Потребителско ID</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Потвърди парола</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Стойност</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Информация за потребителска сметка</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Премахни обект</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>No media file is available.</source>
        <translation>Медия файлът е невалиден.</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>По подразбиране</translation>
    </message>
    <message>
        <source>Additional price</source>
        <translation>Допълнителна стойност</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Вашата цена</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Спестявате</translation>
    </message>
    <message>
        <source>Select author row for removal.</source>
        <translation>Избери редица на автор за премахване.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected rows from the author list.</source>
        <translation>Премахни избраните редици от авторския списък.</translation>
    </message>
    <message>
        <source>Add author</source>
        <translation>Добави автор</translation>
    </message>
    <message>
        <source>Add a new row to the author list.</source>
        <translation>Добави нова роля за авторския списък.</translation>
    </message>
    <message>
        <source>MIME type</source>
        <translation>MIME-тип</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Големина</translation>
    </message>
    <message>
        <source>Remove the file from this draft.</source>
        <translation>Премахни файла от този проект.</translation>
    </message>
    <message>
        <source>Remove selected rows from the matrix.</source>
        <translation>Премахни избраните редици от матрицата.</translation>
    </message>
    <message>
        <source>Number of rows to add.</source>
        <translation>Брой на редици за добавяне.</translation>
    </message>
    <message>
        <source>Add rows</source>
        <translation>Добави редици</translation>
    </message>
    <message>
        <source>Add new rows to the matrix.</source>
        <translation>Добави нови редици за матрицата.</translation>
    </message>
    <message>
        <source>Select multioption for removal.</source>
        <translation>Избери мулти-опции за премахване.</translation>
    </message>
    <message>
        <source>Use the radio buttons to set the default option.</source>
        <translation>Чрез радиобутоните настройте опция по подразбиране.</translation>
    </message>
    <message>
        <source>Add option</source>
        <translation>Добави опция</translation>
    </message>
    <message>
        <source>Add a new option.</source>
        <translation>Добави нова опция.</translation>
    </message>
    <message>
        <source>Remove selected options.</source>
        <translation>Премахни избраните опции.</translation>
    </message>
    <message>
        <source>Add multioption</source>
        <translation>Добави мулти-опция</translation>
    </message>
    <message>
        <source>Add a new multioption.</source>
        <translation>Добави нова мулти-опция.</translation>
    </message>
    <message>
        <source>Remove selected multioptions.</source>
        <translation>Премахни избраните мулти-опции.</translation>
    </message>
    <message>
        <source>Select option for removal.</source>
        <translation>Избери опция за премахване.</translation>
    </message>
    <message>
        <source>There are no options.</source>
        <translation>Няма опции.</translation>
    </message>
    <message>
        <source>Current file</source>
        <translation>Текущ файл</translation>
    </message>
    <message>
        <source>There is no file.</source>
        <translation>Няма файл.</translation>
    </message>
    <message>
        <source>New file for upload</source>
        <translation>Нов файл за качване</translation>
    </message>
    <message>
        <source>Current image</source>
        <translation>Текущо изображение</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Преглед</translation>
    </message>
    <message>
        <source>There is no image file.</source>
        <translation>Няма файл на изображение.</translation>
    </message>
    <message>
        <source>New image file for upload</source>
        <translation>Нов файл на изображение за качване</translation>
    </message>
    <message>
        <source>Select row for removal.</source>
        <translation>Избери редица за премахване.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Кратко съобщение</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real Player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows Media Player</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестен</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Опция</translation>
    </message>
    <message>
        <source>There are no multioptions.</source>
        <translation>Няма мулти-опции.</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>There are no related objects.</source>
        <translation>Няма свързани обекти.</translation>
    </message>
    <message>
        <source>Edit selected</source>
        <translation>Редактирай избрания</translation>
    </message>
    <message>
        <source>Create new object</source>
        <translation>Създай нов обект</translation>
    </message>
    <message>
        <source>There are no authors in the author list.</source>
        <translation>Няма автори в авторския списък.</translation>
    </message>
    <message>
        <source>There are no rows in the matrix.</source>
        <translation>Няма редици в матрицата.</translation>
    </message>
    <message>
        <source>Option set name</source>
        <translation>Опция за настройка на име</translation>
    </message>
    <message>
        <source>Configure user account settings</source>
        <translation>Конфигурирай настройки на акаунта на потребителя</translation>
    </message>
    <message>
        <source>Add object</source>
        <translation>Добави обект</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Edit &lt;%object_name&gt; [%object_class]</source>
        <translation>Редактирай &lt;%object_name&gt; [%object_class]</translation>
    </message>
    <message>
        <source>Add objects</source>
        <translation>Добави обекти</translation>
    </message>
    <message>
        <source>Current account status:</source>
        <translation>Статус на настоящия акаунт:</translation>
    </message>
    <message>
        <source>enabled</source>
        <translation>включен</translation>
    </message>
    <message>
        <source>disabled</source>
        <translation>изключен</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from %1</source>
        <translation>Събрана информация от %1</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Изпрати за публикация</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation> Съхрани проект</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Сортирай по</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Подредба</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Главен</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Премести</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Дълбочина</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Идентификатор на класа</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Клас Име</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Добави места</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Информация за обект</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Не е публикуван</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Текущ</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Управление</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Преглед</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Няма информация за мястото)</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Свързани обекти</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>Валидирането е неуспешно</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящите данни не са валидирани</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Местоположение не е валидирано</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Входящата информация беше съхранена успешно</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Редактирай %1 - %2</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Нова чернова</translation>
    </message>
    <message>
        <source>Feedback from %1</source>
        <translation>Отговор от %1</translation>
    </message>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>Текущата публикувана версия е %version и е публикувана в %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>Последната промяна беше готова при %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Обектът е с притежател %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Този обект се редактира от някой друг, включително и от вас.
Можете да продължите редакцията на някоя от черновите или можтеш да създадете нов проект.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Този обект вече е редактиран от вас.
Можете да продължите редакцията на някоя от вашите чернови или да създадете нова.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Този обект вече е редактиран от някой друг.
Можете да се свържете с него за черновата или да създадете нов за лична редакция.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Текущи чернови</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Собственик</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Input was partially stored</source>
        <translation>Въведената стойност е частично запазена</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft %versionname?</source>
        <translation>Сигурни ли сте, че искате да премахнете %versionname на черновата?</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>The following feedback was collected</source>
        <translation>Следната обратна информация беше събрана</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>Следната информация беше събрана</translation>
    </message>
</context>
<context>
    <name>design/standard/content/ezoption</name>
    <message>
        <source>No value chosen</source>
        <translation>Не е избрана стойност</translation>
    </message>
</context>
<context>
    <name>design/standard/content/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Отговор за %feedbackname</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Благодаря ви за обратната информация, следната информация беше събрана.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Обратно в сайта</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Вече сте изпратили данни за този отговор. Предходно изпратените данни са както следва.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Форма %formname</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Обратно в сайта</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Вече сте изпратили данни за тази форма. Предходно изпратените данни са както следва.</translation>
    </message>
    <message>
        <source>Collected information</source>
        <translation>Събрана информация</translation>
    </message>
</context>
<context>
    <name>design/standard/content/newcontent</name>
    <message>
        <source>New content since last visit</source>
        <translation>Ново съдържание от последното посещение</translation>
    </message>
    <message>
        <source>There are no new content since your last visit.</source>
        <translation type="obsolete">Няма ново съдържание от последното посещение.</translation>
    </message>
    <message>
        <source>Your last visit to this site was</source>
        <translation>Вашето последно посещение в сайта беше</translation>
    </message>
    <message>
        <source>There is no new content since your last visit.</source>
        <translation>Няма налично ново съдържание след последното ви влизане.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/pdf</name>
    <message>
        <source>eZ publish PDF export</source>
        <translation>eZ publish експорт в PDF</translation>
    </message>
    <message>
        <source>#page of #total</source>
        <translation>#page от #total</translation>
    </message>
    <message>
        <source>#level1 - #level2</source>
        <translation>#level1 - #level2</translation>
    </message>
    <message>
        <source>#levelIndex1:#levelIndex2</source>
        <translation>#levelIndex1:#levelIndex2</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Съдържание</translation>
    </message>
    <message>
        <source>Versionview not supported in PDF yet</source>
        <translation>Преглед на версията все още не се поддържа в PDF</translation>
    </message>
</context>
<context>
    <name>design/standard/content/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Анкета %pollname</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count общи резултати</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Резултати от анкетата</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Анонимни потребители не могат да гласуват в тази анкета, моле влезте.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Вие вече сте гласували в тази анкета.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Разширено търсене</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Търси всички думи</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Търси точната фраза</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Търси поне една от думите</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Всеки клас</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Атрибут на класа</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Обнови атрибутите</translation>
    </message>
    <message>
        <source>In</source>
        <translation>В</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Всяка секция</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Публикуван</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>По всяко време</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Последен ден</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Последната седмица</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Последния месец</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Последните три месеца</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Последната година</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Не са намерени резултати за търсенето на &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Търсенето на &quot;%1&quot; върна %2 съвпадения</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation> Покажи на страница</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 елемента</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 елемента</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 елемента</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 елемента</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 елемента</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Техники на търсене</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Провери правописа на ключовите думи.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Опитайте да промените някои ключови думи, например кола вместо коли.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Опитайте с повече основни ключови думи.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>По-малкото ключови думи водят до повече резултати, опитайте да намалите ключовите думи, докато получите резултат.</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>За повече възможности пробвайте %1 Разширено търсене %2</translation>
    </message>
    <message>
        <source>Any attribute</source>
        <translation>Произволен атрибут</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Следните думи бяха изключени от търсенето</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Поздрави приятел</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Съобщението беше изпратено.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Натиснете тук, за да се върнете на първоначалната страница.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Съобщението не беше изпратено.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Съобщението не беше изпратено поради неизвестна грешка. Моля, свържете се с администратора на сайта.</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Вашето име</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Вашият e-mail адрес</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Име на получателя</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>Е-мейл адрес на получателя</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Изпрати</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Това съобщение беше изпратено до вас поради &quot;%1 &lt;%2&gt;&quot;, тъй като може да се заинтересувате от страница &quot;%1 &lt;%2&gt;&quot;.</translation>
    </message>
    <message>
        <source>Please correct the following errors</source>
        <translation>Моля коригирайте следните грешки</translation>
    </message>
    <message>
        <source>This is the link to the page</source>
        <translation>Това е връзката към страница</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;</source>
        <translation>Коментар от &quot;%1 &lt;%2&gt;&quot; </translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 входяща информация беше съхранена успешно</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Няма информация за мястото)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Преведи в</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добави</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Преведи</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Превод на &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Премахни следния  превод от &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е потвърдена</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текуща версия</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Възстанови</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Кошчето е празно</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Маркирай всички</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Размаркирай всички</translation>
    </message>
    <message>
        <source>Empty Trash</source>
        <translation>Изпразни кошчето</translation>
    </message>
</context>
<context>
    <name>design/standard/content/upload</name>
    <message>
        <source>Upload file</source>
        <translation>Качи файл</translation>
    </message>
    <message>
        <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
        <translation>Изберете файл от своят компютър и натиснете бутон &quot;Качи&quot;. Обектът ще бъде създаден според типа на файл и местоположението във вашия компютър.</translation>
    </message>
    <message>
        <source>Some errors occurred</source>
        <translation>Допуснати са следните грешки</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Автоматичен</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Качи</translation>
    </message>
    <message>
        <source>Click here to upload a file. The file will be placed within the location that is specified using the dropdown menu on the top.</source>
        <translation>Натиснете тук, за да качите файл. Файлът ще бъде поставен в мястото, което е определено, използвайки падащото менюто в началото.
</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Version not a draft</source>
        <translation>Версията не е чернова</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>За да редактирате тази версия, създайте нейно копие.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Версията не е ваша</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Копирай и редактирай</translation>
    </message>
    <message>
        <source>Versions for: %1</source>
        <translation>Версии за: %1</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Версия %1 не е създадена от вас, само ваши чернови могат да бъдат редактирани.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Не може да бъде създадена нова версия</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Историческият лимит на версията е надхвърлен и неархивираните версии могат да бъдат премахнати от системата.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Можете да промените настройките на историята на версиите в content.ini, да премахнете чернови или да редактирате съществуващи.</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
        <translation>Версия %1 не е достъпна за редактиране, само чернови могат да бъдат редактирани.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Преводи</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои чернови</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Нямате чернови</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Текуща версия</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Свързани обекти</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Никой</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Дизайн на сайта</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Смени</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Публикувай</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои бележки</translation>
    </message>
    <message>
        <source>Add bookmarks</source>
        <translation>Добави бележки</translation>
    </message>
    <message>
        <source>You have no bookmarks</source>
        <translation>Нямате бележки</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Последна промяна</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Маркирай всички</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Размаркирай всички</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Изчисти Чернови</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Списък с чакащи</translation>
    </message>
    <message>
        <source>Your pending list is empty</source>
        <translation>Списъкът с чакащи е празен</translation>
    </message>
    <message>
        <source>Choose initial placement</source>
        <translation>Избор на първоначално място</translation>
    </message>
    <message>
        <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете къде да поставите новия %classname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото и  натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате  последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Избери елементи за отбелязване</translation>
    </message>
    <message>
        <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
        <translation>Моля изберете елементите, които да бъдат добавени в списъка с отметките(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете елементите и натиснете бутона %buttonname(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бърз избор е също възможно(new line)
(sp)(sp)(sp)(sp)Изберете името на елемента, за да промените списъка.
</translation>
    </message>
    <message>
        <source>Choose new placement</source>
        <translation>Избери ново място</translation>
    </message>
    <message>
        <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
        <translation>Моля изберете новото място за %name(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Предишното място беше в %placementname.(new line)
(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Изберете мястото и натиснете бутона %buttonname(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бърз избор е също възможно(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose placements</source>
        <translation>Избери места</translation>
    </message>
    <message>
        <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете място за %name(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бърз избор е също възможно.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose related objects</source>
        <translation>Избери свързани обекти</translation>
    </message>
    <message>
        <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Моля изберете обекти, които да свържете с %name(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото на обектите и натиснете бутона %buttonname(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бърз избор е също възможно(new line)
(sp)(sp)(sp)(sp)Изберете името на обекта, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose node for default selection</source>
        <translation>Определи възел за избор по подразбиране </translation>
    </message>
    <message>
        <source>Please choose where you want to the default selection of objectrelation to start from.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете от къде да стартира изборът на връзки между обектите.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете място и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бързо поставяне също е възможно.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на местата, за да промените списъка.</translation>
    </message>
    <message>
        <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
        <translation>Това са отметнатите от вас обекти. Изберете обект, за да го видите или, ако имате достатъчно права, можете да го редактирате.(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Ако искате да добавите нови обекти в списъка, натиснете бутона %emphasize_startAdd bookmarks%emphasize_stop.(new line)
(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Премахването на обекти само ще ги премахне от списъка.</translation>
    </message>
    <message>
        <source>Collected info</source>
        <translation>Събрана информация</translation>
    </message>
    <message>
        <source>Choose new location for %objectname</source>
        <translation>Избери ново място за %object_name</translation>
    </message>
    <message>
        <source>Please choose where you want to place %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете къде да поставите новото %objectname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото и  натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Качи файл</translation>
    </message>
    <message>
        <source>Choose the exchanging node for %objectname</source>
        <translation>Избери заменящия възел за &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Please choose which node you want to exchange %objectname with.

    Select the node and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля, изберете възелът с който искате да размените %objectname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете възела и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и запаметените елементи.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото за да промените списъкът.</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Това за последните обекти върху които сте работили. Вие сте собственик на черновите и само вие ги виждате.(new line)
(sp)(sp)(sp)(sp)(sp)(sp)Можете да ги редактирате или премахнете.</translation>
    </message>
    <message>
        <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.
</source>
        <translation>Изберете файл от вашия компютър и изберете бутон &quot;Качи&quot;. Обектът ще бъде създаден според типа на файл и местоположението му във вашия компютър.</translation>
    </message>
    <message>
        <source>Choose a new location the copy of %objectname</source>
        <translation>Изберете ново място за копиране на %object_name</translation>
    </message>
    <message>
        <source>Please choose where you want to copy %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете къде да копирате %objectname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото и  натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose new location for copy of subtree of node %node_name</source>
        <translation>Изберете място за копиране от поддървото на възела &lt;%node_name&gt;</translation>
    </message>
    <message>
        <source>Please choose where you want to copy subtree of node %node_name.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете къде да копирате поддървото на възела %node_name.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете мястото и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Изберете името на мястото, за да промените списъка.</translation>
    </message>
    <message>
        <source>Site Access</source>
        <translation>Достъп до сайта</translation>
    </message>
</context>
<context>
    <name>design/standard/contentstructuremenu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Сгъни / Разгъни</translation>
    </message>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>.[%classname] Кликнете върху иконата, за да видите подробното меню.</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Редактирай шаблон</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Запази</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templatecreate</name>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Не можете да създадете шаблон, разрешение отказано.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Грешно име. Можете  да използвате само буквите A - Z, числа и _.</translation>
    </message>
    <message>
        <source>Create new template override for &lt;%template_name&gt;</source>
        <translation>Създай нов шаблон за &lt;%template_name&gt;</translation>
    </message>
    <message>
        <source>The newly created template file will be placed in</source>
        <translation>Току-що създаденият файл на шаблона ще бъде поставен в</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Име на файл</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Ключове за пренаписване</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Всички класове</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Всички секции</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>Възел ID</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Включен основен шаблон</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Празен файл</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Копие на стандартния шаблон</translation>
    </message>
    <message>
        <source>Container (with children)</source>
        <translation>Кутия (с дъщерни)</translation>
    </message>
    <message>
        <source>View (without children)</source>
        <translation>Изглед (бездъщерни)</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Обект</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templatelist</name>
    <message>
        <source>Complete template list</source>
        <translation>Завършен списък на шаблон</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Design resource</source>
        <translation>Дизайн ресурс</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Най-често използвани шаблони</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templateview</name>
    <message>
        <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
        <translation>Пълномощни за шаблон &lt;%template_name&gt; в &lt;%current_siteaccess&gt; достъп до сайт [%override_count]</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Стандартен ресурс на шаблон</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Съчетай условия</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>New override</source>
        <translation>Ново пълномощно</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритети</translation>
    </message>
</context>
<context>
    <name>design/standard/design/toolbar</name>
    <message>
        <source>Tool List for Toolbar_%toolbar_position</source>
        <translation>Списък с инструменти за Toolbar_%toolbar_position</translation>
    </message>
    <message>
        <source>Tool</source>
        <translation>Инструменти</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Разположение</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Update Placement</source>
        <translation>Обнови разположението</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Добави инструмент</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на меню с инструменти</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Текущ siteaccess</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Available toolbars</source>
        <translation>Налични менюта с инструменти</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Достъпът забранен</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>Нямате права за достъп до тази област.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Натисните бутона Вход, за да влезете.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не е открит</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Модулът не е открит</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Изгледът не е открит</translation>
    </message>
    <message>
        <source>View is disabled</source>
        <translation>Изгледът е забранен</translation>
    </message>
    <message>
        <source>Module is disabled</source>
        <translation>Модулът е забранен</translation>
    </message>
    <message>
        <source>Your current user does not have the proper privileges to access this page.</source>
        <translation>Вашият текущ потребител няма подходящите привилегии за достъп до тази страница.</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>Източникът не беше открит.</translation>
    </message>
    <message>
        <source>The the id or name of the resource was misspelled, try changing it.</source>
        <translation>Името на ресурса е погрешно, пробвайте да го промените.</translation>
    </message>
    <message>
        <source>The resource no longer exists on the site.</source>
        <translation>Ресурсът вече не съществува на този сайт.</translation>
    </message>
    <message>
        <source>The requested module %module could not be found.</source>
        <translation>Исканият модул %module не може да бъде открит.</translation>
    </message>
    <message>
        <source>The module does not exist on this site.</source>
        <translation>Модулът не съществува на този сайт.</translation>
    </message>
    <message>
        <source>The requested view %view could not be found in module %module</source>
        <translation>Исканият изглед %view не може да бъде открит в модула %module</translation>
    </message>
    <message>
        <source>The view does not exist for the module %module.</source>
        <translation>Изгледът не съществува за модул %module.</translation>
    </message>
    <message>
        <source>The view %module/%view is disabled and cannot be accessed.</source>
        <translation>Изгледът %module/%view е забранен и няма достъп до него.</translation>
    </message>
    <message>
        <source>The module %module is disabled and cannot be accessed.</source>
        <translation>Модул %module е забранен и няма достъп до него.</translation>
    </message>
    <message>
        <source>Object is unavailable</source>
        <translation>Обектът не е наличен</translation>
    </message>
    <message>
        <source>The object you requested is not currently available.</source>
        <translation>Исканият обект не е наличен.</translation>
    </message>
    <message>
        <source>The id or name of the object was misspelled, try changing it.</source>
        <translation>Името на обекта е грешно, пробвайте да го промените.</translation>
    </message>
    <message>
        <source>The object is no longer available on the site.</source>
        <translation>Обектът вече не е наличен на сайта.</translation>
    </message>
    <message>
        <source>Object moved</source>
        <translation>Обектът е преместен</translation>
    </message>
    <message>
        <source>The object is no longer available at this URL.</source>
        <translation>Този обект вече не е наличен на това URL.</translation>
    </message>
    <message>
        <source>You should automatically be redirected to the new location. If not click %url.</source>
        <translation>Вие ще бъдете автоматично прехвърлени на новото място. Ако това не стане, натиснете %url.</translation>
    </message>
    <message>
        <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
        <translation>Вие не сте влезли в сайта, за да получите достъп, създайте нов потребител или влезте със съществуващ.</translation>
    </message>
    <message>
        <source>Permission required</source>
        <translation>Изисква се разрешение</translation>
    </message>
    <message>
        <source>Module : </source>
        <translation>Модул :</translation>
    </message>
    <message>
        <source>Function : </source>
        <translation>Функция :</translation>
    </message>
    <message>
        <source>You misspelled some parts of your URL, try changing it.</source>
        <translation>Погрешно сте написали някоя част на вашето URL, пробвайте да го промените.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Вход</translation>
    </message>
    <message>
        <source>The module name was misspelled, try changing the URL.</source>
        <translation>Името на модула е погрешно, пробвайте да промените URL..</translation>
    </message>
    <message>
        <source>This site uses siteaccess matching in the URL and you didn&apos;t supply one, try inserting a siteaccess name before the module in the URL .</source>
        <translation>Този сайт използва siteaccess matching в url, а вие не дадохте такъв. Вмъкнете име на siteaccess преди модула в url.</translation>
    </message>
    <message>
        <source>The view name was misspelled, try changing the URL.</source>
        <translation>Името на изгледа е погрешно, променете URL.</translation>
    </message>
    <message>
        <source>Possible reasons for this are</source>
        <translation>Възможните причини за това са</translation>
    </message>
</context>
<context>
    <name>design/standard/error/shop</name>
    <message>
        <source>Not a product</source>
        <translation>Не е продукт</translation>
    </message>
    <message>
        <source>The requested object is not a product and cannot be used by the shop module.</source>
        <translation>Исканият обект не е продукт и не може да бъде използван от магазинния модул..</translation>
    </message>
</context>
<context>
    <name>design/standard/form</name>
    <message>
        <source>Thank you for your feedback</source>
        <translation>Благодарим за  вашия отговор</translation>
    </message>
    <message>
        <source>Your information was successfully received.</source>
        <translation>Вашата информация беше успешно получена.</translation>
    </message>
</context>
<context>
    <name>design/standard/gui</name>
    <message>
        <source>Delete</source>
        <translation>Изтрий</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Добре дошли в администрацията на eZ publish</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>За вход въведете валидно име и парола.</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Изход</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Версия за печат</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Разширено търсене</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Начална страница</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Карта на сайта</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Лични</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Прехвърляне</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Грешка при зареждане на модула</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Недефиниран модул:</translation>
    </message>
    <message>
        <source>%sitetitle front page</source>
        <translation>%sitetitle начална страница</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Търси %sitetitle</translation>
    </message>
    <message>
        <source>eZ publish redirection - %url</source>
        <translation>eZ publish прехвъряне - %url</translation>
    </message>
    <message>
        <source>Redirecting to %url</source>
        <translation>Прехвърляне на %url</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
</context>
<context>
    <name>design/standard/location</name>
    <message>
        <source>Removal of locations</source>
        <translation>Премахване на места</translation>
    </message>
    <message>
        <source>Some of the locations you tried to remove has children, are you really sure you want to remove those locations?
If you do all the children will be removed as well.</source>
        <translation>Някои от местата, които вие опитахте да премахнете имат дъщерни такива, сигурни ли сте, че искате да премахнете тези места?(new line)
Ако го направите, всички дъщерни ще бъдат също премахнати.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Път</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Брояч</translation>
    </message>
    <message>
        <source>Remove locations</source>
        <translation>Премахни места</translation>
    </message>
    <message>
        <source>Cancel removal</source>
        <translation>Отмени премахване</translation>
    </message>
</context>
<context>
    <name>design/standard/menuconfig</name>
    <message>
        <source>Menu management</source>
        <translation>Управление на меню</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Текущ siteaccess</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Menu positioning</source>
        <translation>Позициониране на меню</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промени</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Предишен</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Сигурни ли сте, че искате да премахнете %1 от стойност %2?</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Бележка:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Премахнатите възли могат да бъдат възстановени по-късно. Можете  да ги откриете в кошчето.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Премахване на предназначението на възела от %1</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Премахването на това предназначение ще премахне и неговите %1 дъщерни.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Сигурни ли сте, че искате да премахнете тези елементи?</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename и неговия дъщерен %childcount. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Премести в кошчето</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Ако %trashname е проверен, вие ще намерите премахнатите елементи в кошчето.</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Бележка</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete">Приоритет</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Потребител</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Потребителска група</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Документ</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="obsolete">Актуализация</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation type="obsolete">Създай тук</translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="obsolete">Секция</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Карта на сайта</translation>
    </message>
    <message>
        <source>Add to Bookmarks</source>
        <translation type="obsolete">Добави в бележки</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation type="obsolete">Съобщи ми при промяна</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="obsolete">Преглед</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation type="obsolete">Избери всички</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Обратно избиране</translation>
    </message>
    <message>
        <source>Click to create a custom template</source>
        <translation type="obsolete">Натисни за създаване на потребителски шаблон</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation type="obsolete">Възел ID</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation type="obsolete">Oбект ID</translation>
    </message>
    <message>
        <source>Default object view.</source>
        <translation type="obsolete">Изглед на обекта по подразбиране.</translation>
    </message>
    <message>
        <source>Missing or invalid input</source>
        <translation>Липсваща или грешна входяща информация </translation>
    </message>
    <message>
        <source>Placed in</source>
        <translation>Поставен в</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Do you want to receive messages combined in digest</source>
        <translation>Искате ли да получавате съобщения, комбинирани в дайджест</translation>
    </message>
    <message>
        <source>Digest settings</source>
        <translation>Настройки на дайджест</translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Ако не искате да получавате тези съобщения,(new line)
променете настройките си в:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Получаване на всички съобщения, комбинирани в едно</translation>
    </message>
    <message>
        <source>Day of the week</source>
        <translation>Ден от седмицата</translation>
    </message>
    <message>
        <source>Notification admin</source>
        <translation>Админ за съобщение</translation>
    </message>
    <message>
        <source>Time event was spawned</source>
        <translation>Времевото събитие беше стартирано</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Старт на филтъра за съобщенията</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Стартиране</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Стартиране на времево събитие</translation>
    </message>
    <message>
        <source>Spawn</source>
        <translation>Стартиране</translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation>Настройки на съобщенията</translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation>Система за съобщения на %sitename </translation>
    </message>
    <message>
        <source>[%sitename] New collaboration item</source>
        <translation>[%sitename] Нов елемент за сътрудничество</translation>
    </message>
    <message>
        <source>[%sitename] Digest for %date</source>
        <translation>[%sitename] Дайджест за %date</translation>
    </message>
    <message>
        <source>&quot;%name&quot; was updated</source>
        <translation>&quot;%name&quot; беше обновено</translation>
    </message>
    <message>
        <source>The item can be viewed by using the URL below.</source>
        <translation>Елементът може да бъде разгледан, използвайки уеб адреса по-долу.
</translation>
    </message>
    <message>
        <source>&quot;%name&quot; was published</source>
        <translation>&quot;%name&quot; беше публикуван</translation>
    </message>
    <message>
        <source>Daily</source>
        <translation>Всекидневно</translation>
    </message>
    <message>
        <source>If the day of month number you have chosen is larger than the number of days in the current month, then the last day of the current month will be used instead.</source>
        <translation>Ако броят дни в даден месец, който вие сте посочили е по-голям от броя на дните през текущия месец, то тогава последният ден на текущия месец ще бъде използван.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
        <translation>Този е-мейл има за цел да ви информира, че нов елемент за сътрудничество очаква вашето внимание на %sitename.(new line)
Този елемент може да бъде видян чрез URL по-долу.</translation>
    </message>
    <message>
        <source>Time of day</source>
        <translation>Време на деня</translation>
    </message>
    <message>
        <source>Weekly, day of week</source>
        <translation>Седмично, ден от седмицата</translation>
    </message>
    <message>
        <source>Monthly, day of month</source>
        <translation>Месечно, ден от месеца</translation>
    </message>
    <message>
        <source>This digest e-mail is to inform you on new items at %sitename.</source>
        <translation>Този е-мейл с даждйест е, за да ви информира за нови елементи на %sitename.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you on news at %sitename.</source>
        <translation>Този е-мейл е, за да ви информира за новини на %sitename.</translation>
    </message>
    <message>
        <source>Node notification</source>
        <translation>Съобщение на възела</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that an updated item has been published at %sitename.</source>
        <translation>Тази електронна поща трябва да ви информира, че обновен елемент беше публикуван в %sitename.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that a new item has been published at %sitename.</source>
        <translation>Тази електронна поща трябва да ви информира, че нов елемент беше публикуван в %sitename.</translation>
    </message>
    <message>
        <source>Notification filter processed all available notification events</source>
        <translation>Филтърът за съобщения обработи всички събития</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/addingresult</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Add to my notifications</source>
        <translation>Добави към мои съобщения</translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; already exists.</source>
        <translation>Съобщение за възел &lt;%node_name&gt; вече съществува. </translation>
    </message>
    <message>
        <source>Notification for node &lt;%node_name&gt; was added successfully.</source>
        <translation>Съобщение за възел &lt;%node_name&gt; беше добавено успешно. </translation>
    </message>
</context>
<context>
    <name>design/standard/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Съобщение за сътрудничество</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Изберете за кои елементи на сътрудничество искате да получавате съобщения.</translation>
    </message>
</context>
<context>
    <name>design/standard/package</name>
    <message>
        <source>Packages</source>
        <translation>Пакети</translation>
    </message>
    <message>
        <source>The following packages are available on this system</source>
        <translation>Следните пакети са налични в системата</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Качване на пакет</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Изберете съдържанието на файл на пакет и натиснете бутона за качване</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Инсталирай пакет</translation>
    </message>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Моля осигурете информация за промените.</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Промени</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
        <translation>Стартирайте входяща стойност с маркер ( %emstart-%emend (dash) или %emstart*%emend (asterix) ) в началото на реда.
Промяната ще продължи до следващия маркер за промяна.</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Моля дайте основна информация за вашия пакет.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Име на пакет</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Лиценз</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Хост на пакета</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Опаковащ</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Моля дайте информация за поддържащия пакета.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
        <translation>Моля изберете намален файл за включване в пакета,(new line)
ако не искате да приложите такъв, натиснете &quot;Следващ&quot;.</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Създай пакет</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Налични помощници</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Моля изберете помощник за създаването на пакет</translation>
    </message>
    <message>
        <source>Please choose the content classes you wish to be included in the package.</source>
        <translation>Моля изберете класовете със съдържание за включване в пакета.</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Списък с класовете</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
        <translation>Изберете картинка за включване в пакета и натиснете &quot;Следващ&quot;.(new line)
Когато свършите добавянето на картинки, натиснете &quot;Следващ&apos;, без да избирате картинка.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Добавени файлове с картинки</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Помощник за пакет %wizardname</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>Този пакет може да бъде инсталиран във вашата система, инсталирането ще копира файлове, ще създаде класове и т.н. в зависимост от пакета.
Ако не искате да изсталирате пакета сега, можете да го направите по-късно и на страницата за разглеждане на пакета.</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Инсталирай елементи</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Пропусни инсталацията</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Премахване на пакети</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>Сигурни ли сте, че искате да премахнете следните пакети?(new line)
Тези пакети ще бъдат завинаги загубени.(new line)
Бележка: Пакетите няма да бъдат де-инсталирани.</translation>
    </message>
    <message>
        <source>Confirm removal</source>
        <translation>Потвърди премахването</translation>
    </message>
    <message>
        <source>Keep packages</source>
        <translation>Запази пакетите</translation>
    </message>
    <message>
        <source>Package removal was cancelled.</source>
        <translation>Премахването на пакет беше отменено.</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Избор</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Инсталиран</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>Не е инсталиран</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Импортиран</translation>
    </message>
    <message>
        <source>Remove package</source>
        <translation>Премахни пакет</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Импортиране на пакет</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Следващ %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Край</translation>
    </message>
    <message>
        <source>Uninstall package</source>
        <translation>Деинсталирай пакет</translation>
    </message>
    <message>
        <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
        <translation>Пакетът може да бъде де-инсталиран от системата, де-инсталирането премахва инсталирани файлове, класове със съдържание и т.н. в зависимост от пакета.(new line)
Ако не искате да де-инсталирате пакета сега, можете да направите това по-късно на страницата за преглед на пакета(new line)
Освен това, можете да премахнете пакета без де-инсталирането му от списъка с пакетите.</translation>
    </message>
    <message>
        <source>Uninstall items</source>
        <translation>Деинсталирай елементи</translation>
    </message>
    <message>
        <source>Skip uninstallation</source>
        <translation>Пропусни деинсталацията</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Файлове [%collectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Детайли</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталация</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Инсталация</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Експорт във файл</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Поддържащи</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>Относно  eZ publish пакет  &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send E-Mail to the maintainer</source>
        <translation>Изпрати е-мейл на поддържащия</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Документи</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Лог с промени</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Списък с файлове</translation>
    </message>
    <message>
        <source>Please choose objects you wish to include in the package.</source>
        <translation>Моля изберете обектите, които искате да влючите в пакета.</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Избрани възли</translation>
    </message>
    <message>
        <source>Please select the site CSS file to be included in the package.</source>
        <translation>Моля изберете CSS сайт файл за включване в пакета.</translation>
    </message>
    <message>
        <source>Please select the classes CSS file to be included in the package.</source>
        <translation>Моля изберете CSS класове файл за включване в пакета.</translation>
    </message>
    <message>
        <source>Package install wizard: %wizardname</source>
        <translation>Помощник за инсталиране на пакет %wizardname</translation>
    </message>
    <message>
        <source>You must now choose which siteaccess the package contents should be installed to.
The chosen siteaccess determines where design files and settings are written to.
If unsure choose the siteaccess which reflects the user part of your site, i.e. not admin.</source>
        <translation>Вие трябва да изберете в кой SITEACCESS трябва да бъде инсталирано съдържанието на пакета.
Избраният SITEACCESS определя къде са записани файловете за дизайна.
Ако не сте сигурни, изберете SITEACCESS, който отразява потребителската част на вашият сайт, т.е. не е админската.</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Please select where you want to place the imported items.</source>
        <translation>Моля изберете къде искате да сложите импортнатите елементи.</translation>
    </message>
    <message>
        <source>If you wish to change the placement click the browse button.</source>
        <translation>Ако искате да промените преместването, натиснете бутона&quot; Търси&quot;.</translation>
    </message>
    <message>
        <source>Place %object_name in node %node_placement</source>
        <translation>Място %object_name в  %node_placement</translation>
    </message>
    <message>
        <source>Choose placement for %object_name</source>
        <translation>Избери място за %object_name</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Change repository</source>
        <translation>Промени съхраняваните данни</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation> Тип на експорт</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Add subtree</source>
        <translation>Добави поддърво</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Добави възел</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Map %siteaccess_name to</source>
        <translation>Карта за %siteaccess_name</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Repositories</source>
        <translation>Съхраняване на данни</translation>
    </message>
    <message>
        <source>Send e-mail to the maintainer</source>
        <translation>Изпрати е-мейл на поддържащия</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/package/creators/ezcontentobject</name>
    <message>
        <source>Please choose the node(s) you wish to export.</source>
        <translation>Моля изберете възел(и), които искате да експортирате.</translation>
    </message>
    <message>
        <source>Please choose the subtree(s) you wish to export.</source>
        <translation>Моля изберете поддървото, което искате да експортирате.</translation>
    </message>
    <message>
        <source>Choose node for export</source>
        <translation>Избери възел за експорт</translation>
    </message>
    <message>
        <source>Choose subtree for export</source>
        <translation>Избери поддърво за експорт</translation>
    </message>
    <message>
        <source>Specify export properties. Default settings will most likely be suitable for your needs.</source>
        <translation>Определете свойствата на експорта. Стандартните настройки най-вероятно ще бъдат подходящи за вашите нужди.</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Разни</translation>
    </message>
    <message>
        <source>Include class definitions.</source>
        <translation>Включване на клас дефиниции.</translation>
    </message>
    <message>
        <source>Include templates related exported objects.</source>
        <translation>Включи свързаните с шаблоните експортнати обекти.</translation>
    </message>
    <message>
        <source>Select templates from the following siteaccesses</source>
        <translation>Избери шаблони от следващ siteaccesses</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Публикувана версия</translation>
    </message>
    <message>
        <source>All versions</source>
        <translation>Всички версии</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Езици</translation>
    </message>
    <message>
        <source>Select languages to export</source>
        <translation>Избери езици за експорт</translation>
    </message>
    <message>
        <source>Node assignments</source>
        <translation>Задаване на възел</translation>
    </message>
    <message>
        <source>Keep all in selected nodes</source>
        <translation>Запази във всички избрани възли</translation>
    </message>
    <message>
        <source>Main only</source>
        <translation>Основен само</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Свързани обекти</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Никой</translation>
    </message>
</context>
<context>
    <name>design/standard/package/installers/ezcontentobject</name>
    <message>
        <source>Choose parent node</source>
        <translation>Избери наследствен възел</translation>
    </message>
    <message>
        <source>Select parent node for new node.</source>
        <translation>Избери наследствен възел за нов възел.</translation>
    </message>
</context>
<context>
    <name>design/standard/pagelayout</name>
    <message>
        <source>All caches</source>
        <translation>Всички възли</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Съдържание</translation>
    </message>
    <message>
        <source>Content - node</source>
        <translation>Възел от съдържанието</translation>
    </message>
    <message>
        <source>Content - subtree</source>
        <translation>Поддърво от съдържанието</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Template &amp; content</source>
        <translation>Шаблон &amp; съдържание</translation>
    </message>
    <message>
        <source>Ini settings</source>
        <translation>Ini настройки</translation>
    </message>
    <message>
        <source>Static</source>
        <translation>Статичен</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Изчистване</translation>
    </message>
</context>
<context>
    <name>design/standard/pdf/list</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Създаден</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>PDF Exports</source>
        <translation>PDF Експорт </translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Нов експорт</translation>
    </message>
</context>
<context>
    <name>design/standard/reference/ez</name>
    <message>
        <source>No generated documentation found</source>
        <translation>Не е открита генерирана документация</translation>
    </message>
    <message>
        <source>To create the reference documentation you must do the following step</source>
        <translation>За да създадете документация, трабва да предприемете следната стъпка</translation>
    </message>
    <message>
        <source>Download and install doxygen</source>
        <translation>Свалете и инсталирайте doxygen</translation>
    </message>
    <message>
        <source>Generate the documentation by running the following command</source>
        <translation>Генерирайте документа чрез старт на следната команда</translation>
    </message>
    <message>
        <source>Download doxygen from %doxygenurl.</source>
        <translation>Сваляне на doxygen от %doxygenurl.</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Главен</translation>
    </message>
    <message>
        <source>Modules</source>
        <translation>Модули</translation>
    </message>
    <message>
        <source>Class hierarchy</source>
        <translation>Йерархия на класовете</translation>
    </message>
    <message>
        <source>Compound list</source>
        <translation>Списък на съставителите</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Списък с файлове</translation>
    </message>
    <message>
        <source>Compound members</source>
        <translation>Съставни членове</translation>
    </message>
    <message>
        <source>File members</source>
        <translation>Файлови членове</translation>
    </message>
    <message>
        <source>Related pages</source>
        <translation>Свързани страници</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Въведение</translation>
    </message>
    <message>
        <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
        <translation>Документацията за eZ publish се състои от много страници, които(new line)
имат различен изглед на документацията. Тази секция е достъпна от(new line)
менюто най-горе. </translation>
    </message>
    <message>
        <source>The documentation will give an overview of the API of eZ publish.</source>
        <translation>Тази документация дава общ поглед върху API на eZ publish.</translation>
    </message>
    <message>
        <source>All reference documentation has been made with %doxygenurl</source>
        <translation>Цялата документация е създадена с %doxygenurl</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Създай политика за </translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Стъпка 1</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Дайте достъп до модул</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Всеки модул</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Позволи всички</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Позволи ограничен брой</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Модул</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Достъп</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ограничен</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Обратно към стъпка 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Не успяхте да дадете достъп до ограничените функции на модула</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>защото списъкът с функции не е дефиниран.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Стъпка 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Определете функция в модул</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Обратно към стъпка 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Стъпка 3</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OК</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Текущи политики</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Ограничения</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Отмени промените</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Списък с ролите</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Прехвърли</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Изглед на ролите</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Политика на ролите</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Ограничение</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Потребители и групи към тази роля</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Потребител</translation>
    </message>
    <message>
        <source>Role edit %1</source>
        <translation>Редакция на роля %1</translation>
    </message>
    <message>
        <source>Edit policy</source>
        <translation>Редакция на политика</translation>
    </message>
    <message>
        <source>Policy</source>
        <translation>Политика</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Не е определен.</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Поддърво</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Актуализация</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Роля</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Remove selected policies</source>
        <translation>Премахни избраните политики</translation>
    </message>
    <message>
        <source>Edit role</source>
        <translation>Редакция на роля</translation>
    </message>
    <message>
        <source>Assign role to user or group</source>
        <translation>Превърли роля на потребител или група</translation>
    </message>
    <message>
        <source>Remove selected roles</source>
        <translation>Премахни избраните роли</translation>
    </message>
    <message>
        <source>Edit current role</source>
        <translation>Редакция на текущата роля</translation>
    </message>
    <message>
        <source>Remove selected assignments</source>
        <translation>Премахни избраните прехвърляния</translation>
    </message>
    <message>
        <source>Specify limitations for function %functionname in module %modulename. &apos;Any&apos; means no limitation by this parameter</source>
        <translation>Определете ограничения за функция %functionname в модула %modulename.&quot;Всеки&quot; означава липса на ограничение по този параметър</translation>
    </message>
    <message>
        <source>Assign role to user or group to subtree</source>
        <translation>Прехвърли роля на потребител или група от поддървото</translation>
    </message>
    <message>
        <source>Assign limited</source>
        <translation>Прехвърли с ограничения</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>Copy role</source>
        <translation>Копирай роля</translation>
    </message>
</context>
<context>
    <name>design/standard/rss</name>
    <message>
        <source>Choose export node</source>
        <translation>Избери възел за експорт</translation>
    </message>
    <message>
        <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Изберете откъде да се експортира.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете място и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бързо поставяне е също възможно.(new line)
(sp)(sp)(sp)(sp) Натиснете имената на местата, за да промените списъка.
</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Choose import destination</source>
        <translation>Избор на място за импортитане</translation>
    </message>
    <message>
        <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Изберете къде да се съхранят импортираните елементи(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете място и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бързо поставяне е също възможно(new line)
(sp)(sp)(sp)(sp)Натиснете имената на местата, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose RSS image</source>
        <translation>Избор на RSS картинка</translation>
    </message>
    <message>
        <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Изберете картинка, която да се използва в RSS експорта(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете място и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бързо поставяне е също възможно.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на местата, за да промените списъка.</translation>
    </message>
    <message>
        <source>Choose export source</source>
        <translation>Избери източник за експорт</translation>
    </message>
    <message>
        <source>Choose owner of imported objects</source>
        <translation>Изберете собственик на инпортираните обекти</translation>
    </message>
    <message>
        <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Изберете собственик на обектите за импортиране(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете потребителя и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отментатите бележки за бързо поставяне е също възможно.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на местата, за да промените списъка.</translation>
    </message>
    <message>
        <source>RSS export is locked</source>
        <translation>RSS експорт е заключен</translation>
    </message>
    <message>
        <source>The RSS export %name is currently locked by %user and was last modified on %datetime.</source>
        <translation>RSS експортът %name е заключен от %user и беше модифициран на %datetime.</translation>
    </message>
    <message>
        <source>The RSS export will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
        <translation>RSS експортът ше бъде наличен за редактиране след като бъде съхранен чрез модификатора или когато автоматично е отключен на %datetime.
</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Опитай отново</translation>
    </message>
    <message>
        <source>RSS import is locked</source>
        <translation>RSS импорт е заключен</translation>
    </message>
    <message>
        <source>The RSS import %name is currently locked by %user and was last modified on %datetime.</source>
        <translation>RSS импортът %name е заключен от %user и беше модифициран на %datetime.</translation>
    </message>
    <message>
        <source>The RSS import will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
        <translation>RSS импортът ше бъде наличен за редактиране, след като бъде съхранен чрез модификатора или когато автоматично е отключен на %datetime.
</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/edit</name>
    <message>
        <source>Display frontpage</source>
        <translation> Покажи началната страница</translation>
    </message>
    <message>
        <source>RSS Export</source>
        <translation>RSS Експорт</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заглавие</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>Уеб адрес на сайта</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Site Access</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>RSS версия</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>Уеб адрес за достъп</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Пътека на източник</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Актуализация</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Add Source</source>
        <translation>Добави източник</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>RSS Import</source>
        <translation>RSS Импорт</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Пътека за предназначение</translation>
    </message>
    <message>
        <source>Imported objects owner</source>
        <translation>Собственик на импортираните обекти</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Игнорирай</translation>
    </message>
    <message>
        <source>Remove Source</source>
        <translation>Премахни източник</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>PDF Експорт</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Въвеждащ текст</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Подтекст</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Възел на източника</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Експорт на структурата</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Дърво</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>Export classes</source>
        <translation>Експорт на класовете</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Export destination</source>
        <translation>Експорт на структурата</translation>
    </message>
    <message>
        <source>Export to URL</source>
        <translation>Експорт в уеб адрес</translation>
    </message>
    <message>
        <source>Export for direct download</source>
        <translation>Експорт за директно сваляне</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Експорт</translation>
    </message>
    <message>
        <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
        <translation>Използвайте това поле, за да въведете основния уеб адрес на вашия сайт. То е използвано, за да произвежда уеб адресите в експорта, съставен от уеб адреса на сайта
( т.е.&quot; http://www.example.com/index.php&quot;) и пътя към обекта ( т.е.&quot; / артикули /моят артикул &quot;). Уеб адресът на сайта зависи от вашия Уебсървър и EZ publish конфигурацията.</translation>
    </message>
    <message>
        <source>Number of objects</source>
        <translation>Брой обекти</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
        <translation>Използвайте падащо меню за избиране на максималния брой на обектите, включени в RSS източника.</translation>
    </message>
    <message>
        <source>Main node only</source>
        <translation>Основен възел</translation>
    </message>
    <message>
        <source>Check if you want to only feed the object from the main node.</source>
        <translation>Изберете, ако искате да съхраните само обект от главният възел.</translation>
    </message>
    <message>
        <source>Subnodes</source>
        <translation>Подвъзли</translation>
    </message>
    <message>
        <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
        <translation>Активирайте този чек-бокс, ако обекти от подвъзлите на източника трябва също да бъдат попълнени.</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/list</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>RSS Feeds</source>
        <translation>RSS източник</translation>
    </message>
    <message>
        <source>RSS Exports</source>
        <translation>RSS Експорти</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Нов експорт</translation>
    </message>
    <message>
        <source>RSS Imports</source>
        <translation>RSS Импорти</translation>
    </message>
    <message>
        <source>New Import</source>
        <translation>Нов импорт</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Търси статистики</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Най-често търсени фрази</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Фраза</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Брой фрази</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Среден върнат резултат</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Изистване на статистиката</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section to node</source>
        <translation>Прехвърли секция към възел</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Сигурни ли сте, че искате да премахнете тези секции?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Премахването на тези секции може да повреди правата, дизайна на сайта и други неща по системата. Не правете това, освен ако не знаете напълно какво правите.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Редакция на секция</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Част за навигация</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>За частите за навигиране</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>Администраторският интерфейс на eZ publish е разделен на навигационни части. Това е начин да се групират различни области от администрацията на сайта. Изберете навигационна част, която да е активна, когато се разглежда тази секция.</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Списък на секциите</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Прехвърли</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Assign section - %section</source>
        <translation>Прехвърли избор - %section</translation>
    </message>
    <message>
        <source>Remove selected sections</source>
        <translation>Премахни избраните секции</translation>
    </message>
    <message>
        <source>Choose section assignment</source>
        <translation>Избор на прехвърляне на секция</translation>
    </message>
    <message>
        <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Моля изберете къде да стартира прехвърлянето на секцията за секция %sectionname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете място и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)Използването на последните и отметнатите елементи за бързо поставяне също е възможно.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на местата, за да промените списъка.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Кеш админ</translation>
    </message>
    <message>
        <source>Content view cache was cleared.</source>
        <translation>Кешът на съдържанието е изчистен.</translation>
    </message>
    <message>
        <source>Ini file cache was cleared.</source>
        <translation>Ini файл кеш беше изчистен.</translation>
    </message>
    <message>
        <source>Template cache was cleared.</source>
        <translation>Кеш на шаблони беше изчистен.</translation>
    </message>
    <message>
        <source>View cache is enabled.</source>
        <translation>Разлеждането на кеша е разрешено.</translation>
    </message>
    <message>
        <source>View cache is disabled.</source>
        <translation>Разлеждането на кеша е забранено.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Изчистване</translation>
    </message>
    <message>
        <source>Ini cache</source>
        <translation>Ini кеш</translation>
    </message>
    <message>
        <source>Ini cache is always enabled.</source>
        <translation>Ini кешът е винаги разрешен.</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Кеш на шаблоните</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Системна информация</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>Режимът за сигурност е включен.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>Режимът за сигурност е изключен.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>Basedir ограничението е включено и е настроено на %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>Basedir ограничението е изключено.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>Регистрацията на глобалните променливи е включена.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>Регистрацията на глобалните променливи е изключена.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>Качването на файлове е включено.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>Качването на файлове е изключено.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>Максималният размер на данните (текст и файлове) е %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>Лимитът на паметта за скрипрове е %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>Максималното време за изпълнение е %1 секунди.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>База данни</translation>
    </message>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Инструменти за бързо развитие на приложението</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
        <translation> Инструментите за бързо развитие на приложението (RAD) ви позволяват лесно да започнете със създаването на нова функционалност за eZ publish.

</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Помощник за опериране с шаблони</translation>
    </message>
    <message>
        <source>Create new template override for</source>
        <translation>Създаване на нов шаблон за </translation>
    </message>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Не можеште да създадете шаблони, правата са отказани.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Грешно име. Можете  да използвате само буквите A - Z, числа и _.</translation>
    </message>
    <message>
        <source>Template will be placed in</source>
        <translation>Шаблонът ще бъде поставен в</translation>
    </message>
    <message>
        <source>Template name</source>
        <translation>Име на шаблона</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Презапиши ключовете</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Възел</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Включен основен шаблон</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Празен файл</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Копие на стандартния шаблон</translation>
    </message>
    <message>
        <source>Container ( with children )</source>
        <translation>Кутия ( с дъщерни )</translation>
    </message>
    <message>
        <source>View ( without children )</source>
        <translation>Изглед ( без дъщерни )</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Обект</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Списък с шаблони</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Повечето обикновени шаблони</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Design Resource</source>
        <translation>Дизайн ресурс</translation>
    </message>
    <message>
        <source>Complete template list</source>
        <translation>Завършен списък с шаблони</translation>
    </message>
    <message>
        <source>Basic information</source>
        <translation>Основна информация</translation>
    </message>
    <message>
        <source>Optional information</source>
        <translation>Незадължителна информация</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Изглед на шаблона</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Стандартен ресурс на шаблон</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Презапиши</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Съчетай условия</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Създай нов</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Помощник за тип на данни</translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Настройка на разширения</translation>
    </message>
    <message>
        <source>Available extensions</source>
        <translation>Налични разширения</translation>
    </message>
    <message>
        <source>There is no known PHP accelerator active.</source>
        <translation>Няма известен PHP ускорител.</translation>
    </message>
    <message>
        <source>&amp;percent% completed</source>
        <translation>&amp;percent завършено</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Datatype start</comment>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Name of datatype</source>
        <comment>Datatype</comment>
        <translation>Име на типа данни</translation>
    </message>
    <message>
        <source>Descriptive name of datatype</source>
        <comment>Datatype</comment>
        <translation>Описателно име на типа данни</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Datatype</comment>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <comment>Datatype</comment>
        <translation>Управление на входните данни на ниво клас</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Datatype next</comment>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Datatype restart</comment>
        <translation>Започни отново</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Datatype</comment>
        <translation>Име на клас</translation>
    </message>
    <message>
        <source>Constant name</source>
        <comment>Datatype</comment>
        <translation>Име на константата</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <comment>Datatype</comment>
        <translation>Създател на тип на данните</translation>
    </message>
    <message>
        <source>Description of your datatype</source>
        <comment>Datatype</comment>
        <translation>Описание на вашия тип данни</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Datatype</comment>
        <translation>Първият ред ще се използва за кратко описание, а останалото е документация на оператора.</translation>
    </message>
    <message>
        <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
        <comment>Datatype default description</comment>
        <translation>Управлява типа данни %datatypename.(new line)
Чрез изпозването на %datatypename можете...</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Datatype download</comment>
        <translation>Сваляне</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>SVN ревизия</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Разширения</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Разширения</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Charset</source>
        <comment>Database charset</comment>
        <translation>Символ</translation>
    </message>
    <message>
        <source>Tools</source>
        <comment>RAD Tools</comment>
        <translation>Инструменти</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Template operator start</comment>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <comment>Template operator</comment>
        <translation>Име на оператора</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Template operator</comment>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <comment>Template operator</comment>
        <translation>Един оператор в класа</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <comment>Template operator</comment>
        <translation>Управлява въведеното от оператора</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <comment>Template operator</comment>
        <translation>Генерира изходната информация от оператора</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <comment>Template operator</comment>
        <translation>Управление на параметри</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Template operator next</comment>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Template operator restart</comment>
        <translation>Започни отново</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Template operator</comment>
        <translation>Име на клас</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <comment>Template operator</comment>
        <translation>Създател на оператора</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <comment>Template operator</comment>
        <translation>Описание на вашия оператор</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Template operator</comment>
        <translation>Първия ред ще се използва за кратко описание, а останалото е документация на оператора.</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <comment>Template operator default description</comment>
        <translation>Управлява оператора на шаблони %operatorname
Чрез изпозването на %operatorname можете...</translation>
    </message>
    <message>
        <source>Example code</source>
        <comment>Template operator</comment>
        <translation>Примерен код</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <comment>Template operator</comment>
        <translation>Ако искате, можете  да добавите примерен код са обяснение, как вашия оператор трябва да работи.
Кодът по подразбиране е направен от основните параметри, които избирате.</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Template operator</comment>
        <translation>След натискане на бутона за сваляне, кодът ще бъде генериран и браузерът ще ви попита за запазване на генерирания файл.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Template operator download</comment>
        <translation>Сваляне</translation>
    </message>
    <message>
        <source>All caches were cleared.</source>
        <translation>Всички кешове бяха изчистени.</translation>
    </message>
    <message>
        <source>Cache collections</source>
        <translation>Кеш колекции</translation>
    </message>
    <message>
        <source>Click a button to clear a collection of caches.</source>
        <translation>Натиснете бутона, за да изчистите колекцията от кешове.</translation>
    </message>
    <message>
        <source>All caches.</source>
        <translation>Всички кешове.</translation>
    </message>
    <message>
        <source>All caches</source>
        <translation>Всички кешове</translation>
    </message>
    <message>
        <source>All caches are disabled</source>
        <translation>Всички кешове са забранени</translation>
    </message>
    <message>
        <source>Content views and template blocks.</source>
        <translation>Изглед на съдържание и блокиране на шаблон.</translation>
    </message>
    <message>
        <source>Content caches</source>
        <translation>Съдържание на кешове</translation>
    </message>
    <message>
        <source>Content caches is disabled</source>
        <translation>Съдържанието на кешове е забранено</translation>
    </message>
    <message>
        <source>Template overrides and template compiling.</source>
        <translation>Презаписване на шаблони и компилиране на шаблони.</translation>
    </message>
    <message>
        <source>Template caches</source>
        <translation>Кешове на шаблон</translation>
    </message>
    <message>
        <source>Template caches are disabled</source>
        <translation>Кеш на шаблон беше забранен</translation>
    </message>
    <message>
        <source>INI caches.</source>
        <translation>INI кешове.</translation>
    </message>
    <message>
        <source>INI caches</source>
        <translation>INI кешове</translation>
    </message>
    <message>
        <source>INI cache is disabled</source>
        <translation>INI кеш е забранен</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Път</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Избор</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Забранен</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Изчисти избраните</translation>
    </message>
    <message>
        <source>Content view cache</source>
        <translation>Кеш на съдържание</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Datatype</comment>
        <translation>След натискане на бутона за сваляне, кодът ще бъде генериран и браузерът ще ви попита за запазване на генерирания файл.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>Could not detect version</source>
        <translation>Не може да бъде открита версията</translation>
    </message>
    <message>
        <source>The PHP Accelerator is enabled.</source>
        <translation>PHP ускорителят е включен.</translation>
    </message>
    <message>
        <source>The PHP Accelerator is disabled.</source>
        <translation>PHP ускорителят е изключен.</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Сървър

База дани сървър</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Път на гнездо

База данни на път на гнездо</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>База данни</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Брояч на опитите за свързване</translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Вътрешен</translation>
    </message>
    <message>
        <source>Current read-only database (Slave)</source>
        <translation>Текуща база данни само за четене (Slave)</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>System upgrade</source>
        <translation>Системно обновяване</translation>
    </message>
    <message>
        <source>File consistency check OK</source>
        <translation>Консистентност на файл ОК</translation>
    </message>
    <message>
        <source>Click a button to check file consistency.</source>
        <translation>Натиснете бутона, за да проверите консистентността на файла.</translation>
    </message>
    <message>
        <source>Check files</source>
        <translation>Провери файлове</translation>
    </message>
    <message>
        <source>warning, this might take a while</source>
        <translation>внимание, това може да отнеме време</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Актуализация</translation>
    </message>
    <message>
        <source>%name was cleared.</source>
        <translation>%name беше изчистен.

</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Текущ siteaccess</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери siteaccess</translation>
    </message>
    <message>
        <source>Database check OK</source>
        <translation>Проверка на база данни ОК</translation>
    </message>
    <message>
        <source>Warning, your database is not consistent with the distribution database.</source>
        <translation>Внимание, вашата база данни не е съответстваща на базата данни за разпределение.</translation>
    </message>
    <message>
        <source>Click a button to check database consistency.</source>
        <translation>Натиснете бутона, за да проверите консистентността на базата данни.</translation>
    </message>
    <message>
        <source>Check database</source>
        <translation>Проверка на база данни</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Създай</translation>
    </message>
    <message>
        <source>Webserver</source>
        <comment>Webserver title</comment>
        <translation>Уебсървър

Име на уебсървъра</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Webserver name</comment>
        <translation>Име

Име на уебсървъра</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>Webserver version</comment>
        <translation>Версия

Версия на уебсървъра</translation>
    </message>
    <message>
        <source>Modules</source>
        <comment>Webserver modules</comment>
        <translation>Модули

Модули на уебсървъра</translation>
    </message>
    <message>
        <source>Webserver modules could not be detected</source>
        <comment>Webserver modules</comment>
        <translation>Модулите на уебсървър не могат да бъдат намерени

Модули на уебсървъра</translation>
    </message>
    <message>
        <source>No known information on the webserver</source>
        <translation>Никаква известна информация за уебсървър</translation>
    </message>
    <message>
        <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access specific extensions, modify these configuration files.</source>
        <translation>Тук можете да активирате/деактивирате вашите разширения. Само системни разширения могат да бъдат активирани, за специфични за сайта, модифицирайте конфигурационните файлове.</translation>
    </message>
    <message>
        <source>Operating System</source>
        <translation>Операционна система</translation>
    </message>
    <message>
        <source>CPU</source>
        <comment>Database type</comment>
        <translation>Процесор

Тип на базата данни</translation>
    </message>
    <message>
        <source>Memory</source>
        <comment>Database server</comment>
        <translation>Памет

Сървър с бази данни</translation>
    </message>
    <message>
        <source>No information on the operating system could be determined.</source>
        <translation>Никаква информация за операционната система не може да бъде определена.</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>Image system</source>
        <translation>Система за картинки</translation>
    </message>
    <message>
        <source>Mail</source>
        <translation>Поща</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Сайт</translation>
    </message>
    <message>
        <source>Warning, it is not safe to upgrade without checking the modifications done to the following files </source>
        <translation>Внимание, не е безопасно за подобряване, без да проверите промените, които са направени на следните файлове</translation>
    </message>
    <message>
        <source>To revert your database to distribution setup, run the following SQL queries</source>
        <translation>За да върнете вашата база данни до настройка на разпространение, извършете следните запитвания на SQL</translation>
    </message>
    <message>
        <source>Activate extensions</source>
        <translation>Активирай разширения</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Редакция на шаблон</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Запази</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на меню с инструменти </translation>
    </message>
    <message>
        <source>Available toolbars</source>
        <translation>Налични инструменти</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Конструктор</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Ако имате проблеми, свързвайки се с вашата база данни, трябва да я прегледате</translation>
    </message>
    <message>
        <source>at</source>
        <translation>местоположение в</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Въведение</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL е управление на система от бази данни, създадена от MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>В момента то е една от най-популярните бази данни в Open Source източник и повечето често са по подразбиране в PHP.</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL е базата данни на най-популярния в света Open Source, предназначен за скорост, сила и точност в полза на голямото натоварено използване.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Повече информация може да бъде намерена в</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Детайли</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation type="obsolete">MySQL е добър избор за боравене на повечето западни езици, както и да е той в момента не е най-добрият избор за Unicode или всички останали езици.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Инсталация</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>С използването на</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>Алтернатива за конфигурация, с която вие позволявате на PHP  да има достъп до бази данни на MySQL. Ако вие използвате тази алтернатива, без да определяте пътя към MySQL, PHP ще използва вградените клиентските библиотеки на MySQL.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Повече информация за MySQL разширението може да бъде открита в </translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL е система за ръководство на база данни, развита от университета на Калифорния от Berkeley Computer Science Department.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>То е много популярна база данни в общността на Open Source и предоставя висока функционалност на съвременната база данни.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL е усъвършенствана Object-Relational DBMS, поддържаща всички SQL концепции, включително subselects, транзакции, и дефинирани от потребителя типовете и функции. Освен това то е най-напредналата база данни с отворен код.
</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL е добър избор за управление на повечето езици, включително Unicode, но се изисква някаква конфигурация за получаване на  добра скорост.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>В последователност задействам PostgreSQL приложение,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>необходимо е когато съставяте PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Повече информация за PostgreSQL разширението може да бъде открита в</translation>
    </message>
    <message>
        <source>From their homepage</source>
        <translation>От тяхната главна страница</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, and as of version 4.1 it also supports Unicode.</source>
        <translation>MySQL е добър избор за поддържане на повечето западни езици, а от версия 4.1 той също така поддържа и Unicode.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>Install demo data?</source>
        <translation>Инсталирай демо данни?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>Не можете да инсталирате демо данни, разширението на zlib  липсва във вашата PHP инсталация.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>не поддържа демо данни за инсталиране в момента.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Провал на демо данни</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Не мога да разопаковам демо данните.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Трябва да опитате да инсталирате без демо данни.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Стартирането провалено</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>Базата данни не може да бъде правилно стартирана.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Вашата база данни вече съдържа данни.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>Настройката може да бъде стартирана, но може да повреди настоящите данни.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Какво искате настройката да прави?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Продължи, но остави данните както са си.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Позволете ми да избера нова база данни.</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Езикови опции</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Драйвър</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Unicode поддръжка</translation>
    </message>
    <message>
        <source>no</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Конфигурирай</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>бутон.</translation>
    </message>
    <message>
        <source>Servername</source>
        <translation>Име на сървъра</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>Добра настройка не е искана от вашата система, вие можете да продължите като натиснете </translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>Системата откри, че резултатите, могат да дават подобрена характеристика или повече отличителни черти. Моля, вижте резултатите по-долу за повече информация какво можете да направите. Всяка характеристика ще ви даде инструкции как да се направят по-добри настройки.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>След като оправите проблемите, натиснете</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Повтори проверка на системата</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>Бутон за повтаряне проверката на системата. Препоръчително е след системни промени да се проверява за критични провали. Вие също можете да натиснете</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Провери пак</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>бутон за повтаряне на проверките за по-добра настройка. Ако вие желаете, можете да отидете направо до следващата стъпка с натискане на </translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Характеристики</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Писането провалено </translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>Настройката не може да запише файла.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>Настройката не може да вземе достъп за</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>директория. Това е нужно за деактивиране на стартирането. Следвайте инструкциите намерени в</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>за да активирате достъп за писане, натиснете</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Опитай пак</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Променете втората линия от</translation>
    </message>
    <message>
        <source>to</source>
        <translation>към</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>Настройката в момента е деактивирана, натиснете</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>да се върнете към сайта.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Можете да изберете от</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>изпрати поща</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Поздравления,  eZ publish сега ще тръгне на вашата система. </translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>eZ publish уебсайт</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>eZ publish съобщения за технически дефект</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Направен</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>Време е да изберете езика, който този сайт трябва да поддържа.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Изберете вашия език и натиснете</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>бутон, или</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Детайли на език</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>бутон за избиране на езикови варианти.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>Време е да изберете езиците, които този сайт трябва да поддържа. Изберте вашия основен език и проверте всички допълнителни езици.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Когато сте готови, натиснете</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>Езиците, които избрахте ще ви помогнат да определите таблицата със символи на този сайт.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Име на език</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Селекция</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>Възможно е сега да се избере вариант за вашия език. Вариантите правят малки настройки на езика, като прибавяне поддръжка за Евро или промени на формат на дата. Вариантите за използване са незадължителни, така че вие можете безопасно да пропуснете тази стъпка. След като го направите. натиснете</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>Възможно е сега да се избере вариант за вашия език. Вариантите правят малки настройки на езика, като прибавяне поддръжка за Евро или промени на формат на дата. Вариантите за използване са незадължителни, така че вие можете безопасно да пропуснете тази стъпка. След като го направите. натиснете</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>По подразбиране</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Коментари</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Изпрати регистрация</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Пропусни регистрация</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>Какъв вид поддръжка за език трябва да има този сайт. Видът на поддръжката определя селекцията за езика и кодовата таблица.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Едноезичен (един език)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Многоезичен (много езици с една кодова таблица)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Многоезичен (Unicode, без лимит)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Регионални опции</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Тук ще видите резюме на основните настройки за вашия сайт. Ако сте доволни от настройките, можете да натиснете</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Настройка на База данни</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>Ако искате да промените вашите настройки, натиснете </translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Започнете отново</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation>бутон, който ще рестартира събирането на информация (Съществуващите настройки са запазени).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Настройки на база данни</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>База данни</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Настройки на език</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Вид език</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Едноезичен</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Многоезичен</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Езици</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>Няма проблеми във вашата система, можете да продължите като натиснете</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Система за добра настройка</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Моля, вижте резултатите по-долу за повече информация относно проблемите.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>Всеки проблем ще ви даде инструкции как да оправите проблема.</translation>
    </message>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>Базата данни е готова за стартиране, натиснете бутона %1, когато сте готови.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Продължи</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>Настройката няма да прави обновяване от по-стари eZ publish версии (като 2. 2. 7), ако вие оставите данните, така както са. Това е само за хората, които имат налични данни, които не искат да изгубят. Ако имате eZ publish 3.0 данни (като от RC release), вие трябва да пропуснете стартирането на базата данни, както и да направите ръчно обновяване.</translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Продължи, но първо премахни данните.</translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Запази данните и пропусни стартирането на базата данни.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>Стартирането на базата данни може да отнеме, така че моля, бъдете търпеливи и изчакайте, докато новата страница е готова.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Натиснете бутона %1, за да започнете конфигурацията на процеса.</translation>
    </message>
    <message>
        <source>which must be available on the server or</source>
        <translation>Което трябва да бъде налично на сървъра или</translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>Потребителското име по подразбиране за администратора е % 1 и паролата по подразбиране е % 2.</translation>
    </message>
    <message>
        <source>Database choice</source>
        <translation>Избор на база данни</translation>
    </message>
    <message>
        <source>The database would not accept the connection, please review your settings and try again.</source>
        <translation>Базата данни не прие връзката, моля, прегледайте вашите настройки и опитайте отново.</translation>
    </message>
    <message>
        <source>Password entries did not match.</source>
        <translation>Паролите не съвпадат.</translation>
    </message>
    <message>
        <source>The selected database was not empty, please choose from the alternatives below.</source>
        <translation>Избраната база данни не беше празна, моля, изберете от алтернативите по-долу.</translation>
    </message>
    <message>
        <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
        <translation>Избраният потребител няма достъп до каквито и да е бази данни. Променете потребителя или създайте база данни за потребителя.</translation>
    </message>
    <message>
        <source>Database initalization</source>
        <translation>Стартиране на база данни </translation>
    </message>
    <message>
        <source>Email settings</source>
        <translation>Настройки на е-мейл</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Завършен</translation>
    </message>
    <message>
        <source>Language options</source>
        <translation>Опции за език</translation>
    </message>
    <message>
        <source>Registration</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Securing site</source>
        <translation>Защитен сайт</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Site details</source>
        <translation>Детайли на сайта</translation>
    </message>
    <message>
        <source>No templates choosen.</source>
        <translation>Не са избрани шаблони.</translation>
    </message>
    <message>
        <source>Site template selection</source>
        <translation>Шаблон за селекция на сайта</translation>
    </message>
    <message>
        <source>System check</source>
        <translation>Проверка на системата</translation>
    </message>
    <message>
        <source>Welcome to eZ publish</source>
        <translation>Добре дошли в eZ publish</translation>
    </message>
    <message>
        <source>Choose database system</source>
        <translation>Изберете система за бази данни</translation>
    </message>
    <message>
        <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
        <translation>PostgreSQL или MySQL &gt;= 4.1 са нужни за unicode поддръжка в eZ publish.</translation>
    </message>
    <message>
        <source>More information about eZ publish and unicode support can be found %1.</source>
        <translation>Повече информация за eZ publish и unicode поддръжка може да бъде намерена %1.</translation>
    </message>
    <message>
        <source>Database initialization</source>
        <translation>Стартиране на база данни </translation>
    </message>
    <message>
        <source>Socket (optional)</source>
        <translation>Socket (по избор)</translation>
    </message>
    <message>
        <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
        <translation>Ако използвате MySQL и не знаеш какво да вкараш в полето socket, оставете го празно</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
        <translation>което смени е-мейлите. Ако не сте сигурни какво да използвате, попитайте вашия уебхост. Някои уебхостове не правят поддръжка</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Заглавие</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>User site</source>
        <translation>Сайт на потребител</translation>
    </message>
    <message>
        <source>Admin site</source>
        <translation>Сайт на администратор</translation>
    </message>
    <message>
        <source>Make sure to visit the %1 and the %2 web site.</source>
        <translation>Посетете %1 и уебсайт %2.</translation>
    </message>
    <message>
        <source>No Unicode support</source>
        <translation>Не съдържа Unicode </translation>
    </message>
    <message>
        <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
        <translation>Сървърът на базата данни, който вие свързахте не поддържа Unicode, което значи, че вие не можете да изберете всички езици.
За да оправите този проблем, трябва да направите някои от следните неща:</translation>
    </message>
    <message>
        <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won&apos;t work.</source>
        <translation>Изберете само езиците с подобни символи, например: Английски и Норвежки ще вървят заедно, докато Английски и Руски не.  </translation>
    </message>
    <message>
        <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
        <translation>Уверете се, че сървърът с базата данни е конфигуриран да използва Unicode или има най-новия софтуеър, който поддържа Unicode.</translation>
    </message>
    <message>
        <source>Primary/Additional</source>
        <translation>Първостепенен / допълнителен</translation>
    </message>
    <message>
        <source>eZ publish supports multiple languages.</source>
        <translation>eZ publish поддържа многобройни езици.</translation>
    </message>
    <message>
        <source>These and other additional languages can also be installed later.</source>
        <translation>Тези и други допълнителни езици също могат да бъдат инсталирани по-късно.</translation>
    </message>
    <message>
        <source>Site registration</source>
        <translation>Регистрация на сайт</translation>
    </message>
    <message>
        <source>By sending registration the following data will be sent to eZ systems</source>
        <translation>Чрез изпращане на регистрация следната информация ще бъде изпратена на eZ системите</translation>
    </message>
    <message>
        <source>Site access configuration</source>
        <translation>Конфигурация на достъп до сайта</translation>
    </message>
    <message>
        <source>URL (recommended)</source>
        <translation>Уеб адрес (препоръчително)</translation>
    </message>
    <message>
        <source>Port. Note: Requires web server configuration </source>
        <translation>Порт. Бележка: изисква конфигурация на уеб сървър</translation>
    </message>
    <message>
        <source>Hostname. Note: Requires DNS setup.</source>
        <translation>Име на хоста.Бележка: Изисква DNS настройка.</translation>
    </message>
    <message>
        <source>The path determines access.</source>
        <translation>Пътят определя достъп.</translation>
    </message>
    <message>
        <source>e.g. %adminsite and %usersite</source>
        <translation>%adminsite и %usersite</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <source>The port number determines access.*</source>
        <translation>Номерът на порта определя достъпа.*</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Име на хоста</translation>
    </message>
    <message>
        <source>The hostname determines access.*</source>
        <translation>Името на хоста определя достъпа.*</translation>
    </message>
    <message>
        <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
        <translation>Избрахте една и съща база данни за два или повече шаблона за сайтове.  Моля, променете местата, указани с *</translation>
    </message>
    <message>
        <source>Site url</source>
        <translation>Уеб адрес на сайт</translation>
    </message>
    <message>
        <source>Leave the data and add new</source>
        <translation>Оставете данните и прибавете ново</translation>
    </message>
    <message>
        <source>Remove existing data</source>
        <translation>Премахни съществуващите данни</translation>
    </message>
    <message>
        <source>Leave the data and do nothing</source>
        <translation>Оставете данните и не правете нищо</translation>
    </message>
    <message>
        <source>I&apos;ve chosen a new database</source>
        <translation>Избрах нова база данни</translation>
    </message>
    <message>
        <source>Select which sites you would like to install on your system.</source>
        <translation>Изберете кои сайтове бихте искали да инсталирате на вашата система.</translation>
    </message>
    <message>
        <source>The system check found some issues that need to be resolved before the setup can continue.</source>
        <translation>Системата намери някои проблеми, които трябва да бъдат решени преди настройката да продължи.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
        <translation>След като оправите проблемите, натиснете бутона 1&quot; %&quot;, за да пуснете отново системните проверки. Също можете да игнорирате специфичните тестове, кликвайки чек-боксовете.</translation>
    </message>
    <message>
        <source>Ignore this test</source>
        <translation>Отхвърли този тест</translation>
    </message>
    <message>
        <source>Welcome to eZ publish %1</source>
        <translation>Добре дошли в eZ publish %1</translation>
    </message>
    <message>
        <source>This section will contain information/help about each step in the setup wizard.</source>
        <translation>Тази част ще съдържа информация / помощ за всяка стъпка в помощника за настройка.</translation>
    </message>
    <message>
        <source>The summary section below will contain information about configured settings.</source>
        <translation>Частта за резюмето по-долу ще съдържа информация за конфигурираните настройки.</translation>
    </message>
    <message>
        <source>Information about how to set up eZ publish manually is available %1.</source>
        <translation>Информацията за ръчно настройване на eZ publish е налична % 1.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>link to unicode info</comment>
        <translation>тук

линк за информация за unicode</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <comment>eZ publish 3 link</comment>
        <translation>eZ publish

линк за eZ publish 3</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>Ако имате нужда помощ с eZ publish, можете да отидете на %ezlink и да получите помощ във форумите.(new line)
(sp)(sp)Ако намерите грешка, моля отидете на % buglink и докладвайте за нея.
(sp)(sp)С ваша помощ ние можем да оправим грешките, които eZ publish може да има, както и  имплементираме нови функци.</translation>
    </message>
    <message>
        <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
        <translation>Кликнете на уеб адреса за достъп до новия %ezlink или натиснете бутона %donebutton. Насладете се на една от най-успешните уеб системи за управление на съдържание!</translation>
    </message>
    <message>
        <source>Change the second line from %false to %true.</source>
        <translation>Промени втората линия от %false на %true.</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>language information link</comment>
        <translation>документация

линк за информация за езика</translation>
    </message>
    <message>
        <source>Back</source>
        <comment>back button in installation</comment>
        <translation>Назад

инсталиране на бутона за бръщане обратно</translation>
    </message>
    <message>
        <source>Refresh</source>
        <comment>Refresh button in installation</comment>
        <translation>Опресняване

инсталиране на бутона за опрезняване</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>next button in installation</comment>
        <translation>Следващ

инсталиране на бутона за преминаване на следваща стъпка</translation>
    </message>
    <message>
        <source>online documentation</source>
        <comment>site access documentation link</comment>
        <translation>онлайн документация

линк за документацията за достъп до сайта</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>site access documentation link</comment>
        <translation>документация

линк за документацията за достъп до сайта</translation>
    </message>
    <message>
        <source>here</source>
        <comment>manual installation link</comment>
        <translation>тук

линк за ръчно инсталиране</translation>
    </message>
    <message>
        <source>System finetuning</source>
        <translation>Система за добра настройка</translation>
    </message>
    <message>
        <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
        <translation>И двете MySQL и PostgreSQL поддръжки бяха открити на вашата система. Моля, изберете системата за бази данни, която бихте искали да използвате.</translation>
    </message>
    <message>
        <source>eZ publish supports both MySQL and PostgreSQL.</source>
        <translation>eZ publish поддържа MySQL и PostgreSQL.</translation>
    </message>
    <message>
        <source>Please input database access information in the form below.</source>
        <translation>Моля, въведете информация за достъп до бази данни във формата по-долу.</translation>
    </message>
    <message>
        <source>If you don&apos;t have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you&apos;re unsure about how to create a database.</source>
        <translation>Ако нямате достъп до база данни, трябва да придобиете достъп сега. eZ publish е способен да пусне многобройни сайтове, като всеки сайт има нужда от собствена база данни. Това значи, че вие трябва да създадете няколко бази данни, ако планирате да пуснете многобройни сайтове. Моля, погледнете ръководството за потребители на системата от бази данни, ако не сте несигурни как да създавате база данни.</translation>
    </message>
    <message>
        <source>Outgoing E-mail</source>
        <translation>Изходящ е-мейл</translation>
    </message>
    <message>
        <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
        <translation>Тази секция се използва за конфигуриране на начина, по който eZ publish да доставя изходящи е-мейли.</translation>
    </message>
    <message>
        <source>SMTP is recommended for MS Windows users.</source>
        <translation>SMTP е препоръчителен за MS Windows потребители.</translation>
    </message>
    <message>
        <source>E-mail delivery</source>
        <translation>E-мейл доставка</translation>
    </message>
    <message>
        <source>Server name: </source>
        <translation>Име на сървър:</translation>
    </message>
    <message>
        <source>Username (optional): </source>
        <translation>Потребителско име (по избор): </translation>
    </message>
    <message>
        <source>Password (optional): </source>
        <translation>Парола (по избор): </translation>
    </message>
    <message>
        <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
        <translation>eZ publish използва е-мейл за изпращане на важни съобщения като регистрация на потребител и одобрение на съдържанието. При Линукс / UNIX : опитайте да използвате sendmail. При Уиндоус : използвайте сървър на SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
        <translation>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt; Поща е получена през SMTP сървър. Като минимум трябва да бъде определено името на хоста на SMTP сървъра. Съвет: проверете настройките на SMTP във вашето приложение за електронна поща.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval.</source>
        <translation>E-мейл се използва за изпращане на важни известия като регистрация на потребител и одобрение на съдържание.</translation>
    </message>
    <message>
        <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
        <translation>Повечето Unix системи поддържат sendmail, докато потребителите на Уиндоус трябва да изберат SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP&lt;/b&gt;: If you&apos;re unsure what to enter, take a look at the settings in your e-mail application.</source>
        <translation>&lt;b&gt;SMTP&lt;/b&gt;: Ако вие не сте сигурни къде да влезете, погледнете настройките във вашето приложение за електронната поща.</translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following sites. You will find the username and password mentioned for each site.</source>
        <translation>eZ publish е инсталиран със следните сайтове. Вие ще намерите потребителското име и парола, опоменати за всеки сайт.</translation>
    </message>
    <message>
        <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
        <translation>Съвет: Запазете тази страница като файл на HTML с натискане на бутона Запиши, като във вашето меню на уеб браузера алтернативно можете да записвате уеб адресите за вашите сайтове.</translation>
    </message>
    <message>
        <source>forums</source>
        <comment>forum link</comment>
        <translation>форуми

линк към форума</translation>
    </message>
    <message>
        <source>Language support</source>
        <translation>Поддръжка за език</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the primary language, and the checkboxes to choose additional languages. You may choose more than one additional language.</source>
        <translation>Използвайте радио бутоните, за да изберете основния език, и чек-боксовете за избиране на допълнителни езици. Вие можете да избирате повече от един допълнителен език.</translation>
    </message>
    <message>
        <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
        <translation>Избраните езици са използвани за определяне на кодови таблици, формати за дата / брой и т.н..</translation>
    </message>
    <message>
        <source>For more information about language customization, please refer to the %1.</source>
        <translation>За повече информация за пригаждане на езика, моля, имайте предвид % 1.</translation>
    </message>
    <message>
        <source>Finetune</source>
        <comment>Finetune button in installation</comment>
        <translation>Добра настройка

инсталиране на бутон за добра настройка</translation>
    </message>
    <message>
        <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
        <translation>Ако желаете, можете също да прибавяте някои коментари, които ще бъдат включени в е-мейла за регистрация.</translation>
    </message>
    <message>
        <source>Send registration</source>
        <translation>Изпрати регистрация</translation>
    </message>
    <message>
        <source>System details (OS type, etc)</source>
        <translation>Детайли на системата (OS тип, т.н.)</translation>
    </message>
    <message>
        <source>The test results</source>
        <translation>Резултати от теста</translation>
    </message>
    <message>
        <source>The database type</source>
        <translation>Тип база данни</translation>
    </message>
    <message>
        <source>The site name</source>
        <translation>Името на сайта</translation>
    </message>
    <message>
        <source>The url of the site</source>
        <translation>Уеб адресът на сайта</translation>
    </message>
    <message>
        <source>Languages chosen</source>
        <translation>Избиране на езици</translation>
    </message>
    <message>
        <source>This data will help to improve future releases of eZ publish.</source>
        <translation>Тези данни ще ви помогнат да подобрите бъдещите публикувания за eZ publish.</translation>
    </message>
    <message>
        <source>Site security</source>
        <translation>Защита на сайта</translation>
    </message>
    <message>
        <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
        <translation>Вашият сайт не работи във виртуален режим на хоста, което е несигурно. Препоръчително е да пускате eZ publish във виртуален режим на хоста. Ако нямате възможността да използвате виртуален режим на хоста, трябва да следвате инструкциите по-долу за това как да се инсталира файл на .htaccess.  Файлът .htaccess казва на уеб сървера да ограничи достъпа до определени файлове.</translation>
    </message>
    <message>
        <source>If you have shell access, you can run the following commmands.</source>
        <translation>Ако имате достъп до конзолата, можете да пуснете следните команди.</translation>
    </message>
    <message>
        <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
        <translation>Ако нямате достъп до конзолата, ще трябва да копирате файла, използвайки FTP клиент или да помолите вашия хост-доставчик да направи това за вас.</translation>
    </message>
    <message>
        <source>This security tweak takes care of protecting configuration files and other important files.</source>
        <translation>Това прекъсване от съображения за сигурност се грижи за защитните файлове и други важни файлове.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
        <translation>Моля, изберете метода за достъп, който искате да използвате за вашия сайт. Методът за достъп определя как мястото ще бъде достигнато от съдържанието на уеб браузера. 
Ако не сте сигурни : изберете уеб адрес.</translation>
    </message>
    <message>
        <source>Port*</source>
        <translation>Порт*</translation>
    </message>
    <message>
        <source>* Requires web server setup.</source>
        <translation>* Изисква настройка на уеб сървъра.</translation>
    </message>
    <message>
        <source>Hostname*</source>
        <translation>Име на хост*</translation>
    </message>
    <message>
        <source>* Requires DNS setup.</source>
        <translation>* Изисква DNS настройка.</translation>
    </message>
    <message>
        <source>For more detailed information on site access, please refer to the %1</source>
        <translation>За повече детайлна информация на достъп до сайта, моля отидете на %1</translation>
    </message>
    <message>
        <source>Your passwords do not match.</source>
        <translation>Вашите пароли не съвпадат.</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Първо име</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Фамилия</translation>
    </message>
    <message>
        <source>User path</source>
        <translation>Потребителски път</translation>
    </message>
    <message>
        <source>User port</source>
        <translation>Потребителски порт</translation>
    </message>
    <message>
        <source>User hostname</source>
        <translation>Потребителско име на хоста</translation>
    </message>
    <message>
        <source>Admin path</source>
        <translation>Път на администратора</translation>
    </message>
    <message>
        <source>Admin port</source>
        <translation>Порт на администратора</translation>
    </message>
    <message>
        <source>Admin hostname</source>
        <translation>Хост име на администратора</translation>
    </message>
    <message>
        <source>You may modify the details for each site.</source>
        <translation>Можете да модифицирате детайлите за всеки сайт.</translation>
    </message>
    <message>
        <source>For more information about how to configure site access, please refer to the %1</source>
        <translation>За повече информация за това как да конфигурирате достъпа до сайта, моля, отидете на %1</translation>
    </message>
    <message>
        <source>Use the refresh button to update the database listing.</source>
        <translation>Използвайте бутона за опресняване на списъка с бази данни.</translation>
    </message>
    <message>
        <source>Site packages</source>
        <translation>Пакети за сайта</translation>
    </message>
    <message>
        <source>Each package will create a unique web site.</source>
        <translation>Всеки пакет ще създаде уникален уеб сайт.</translation>
    </message>
    <message>
        <source>Since each web site is unique, each package requires a unique database.</source>
        <translation>Тъй като всеки уеб сайт е уникален, всеки пакет изисква уникална база данни.</translation>
    </message>
    <message>
        <source>Next &amp;gt;</source>
        <translation>Следващ &amp;gt;</translation>
    </message>
    <message>
        <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Има някои важни проблеми, които бяха разрешени. Списък от въпроси / проблеми е представен по-долу. Всяка част съдържа описание и предложено / препоръчано решение.</translation>
    </message>
    <message>
        <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
        <translation>След като проблемите / въпроси са разрешени, можете да натиснете бутон &lt;i&gt; Следващ &lt; /i &gt;, за да продължите. Системната проверка ще бъде пусната отново. Ако всичко е добре, настройката ще отиде към следващия етап. Ако има проблеми, системната проверка на страницата ще се появи отново.</translation>
    </message>
    <message>
        <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
        <translation>Някои проблеми могат да бъдат игнорирани, маркирайки чек-боксовете &lt;i&gt;Игнорирай този тест&lt;/i &gt;; въпреки че това не е препоръчително.</translation>
    </message>
    <message>
        <source>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</source>
        <translation>Възможно е също да направите finetuning на вашата система, натиснете &lt;i&gt;Finetune&lt;/i&gt; вместо &lt;i&gt;Следващ&lt;/i&gt;, ако искате да виждате finetuning кратки съвети.</translation>
    </message>
    <message>
        <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
        <translation>Системната страница е показана. Това значи, че има някои проблеми в момента.</translation>
    </message>
    <message>
        <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
        <translation>Тези въпроси бяха решени, иначе eZ publish няма да функционира правилно.</translation>
    </message>
    <message>
        <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
        <translation>Проблемите обикновено са свързани със системни файлове и може лесно да бъдат оправен чрез команди за копиране и заместване, изпълнявани в системен интерпретатор.</translation>
    </message>
    <message>
        <source>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Има някои проблеми, които трябва да бъдат решени за получаване на максимално изпълнение и резултати. Списък с въпроси е представен по-долу. Всяка част съдържа описание и предложено / препоръчано решение.</translation>
    </message>
    <message>
        <source>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</source>
        <translation>След като проблемите са отстранени, можете да натиснете бутона &lt;i&gt;Finetune&lt;/i&gt;, за да продължите. Системната проверка ще бъде пусната отново. Ако всичко е добре, настройката ще отиде към следващия етап. Ако проблемите не са разрешени, системната страница на finetune ще се появи отново.</translation>
    </message>
    <message>
        <source>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</source>
        <translation>Ако не искате да оправите тези проблеми, натиснете &lt;i&gt;Следващ&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</source>
        <translation>Системната страница на finetune е показана. Това значи, че има някои проблеми, които трябва да се разрешат за подобряване изпълнението или резултатите.</translation>
    </message>
    <message>
        <source>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</source>
        <translation>Тези проблеми няма нужда да бъдат решени. eZ publish ще функционира правилно без тях.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</source>
        <translation>Добре дошли в eZ publish системата за управление на съдържанието и структурата. Този помощник ще ви помогне да настроите eZ publish. &lt;br&gt;Системата не е оптимална, ако искате,натиснете бутона &lt;i&gt;Finetune&lt;/i&gt;. Това ще ви даде съвети как да се разрешат тези проблеми.
&lt;br/&gt; Натиснете &lt;i&gt;Следващ&lt;/i&gt;, за да продължите без перфектна настройка.
</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
        <translation>Добре дошли в eZ publish системата за управление на съдържанието и структурата. Този помощник ще ви помогне да настроите eZ publish. &lt;br&gt;Натиснете &lt;i&gt;Следващ&lt;/i&gt;, за да продължите.</translation>
    </message>
    <message>
        <source>No data will be stored in the database until the final step of the setup.</source>
        <translation>Информацията не е съхранена в базата данни до финалната стъпка на настройката.</translation>
    </message>
    <message>
        <source>Site administrator</source>
        <translation>Сайт администратор</translation>
    </message>
    <message>
        <source>No packages choosen.</source>
        <translation>Не са избрани пакети.</translation>
    </message>
    <message>
        <source>Site functionality</source>
        <translation>Функционалност на сайта</translation>
    </message>
    <message>
        <source>No site choosen.</source>
        <translation>Не е избран сайт.</translation>
    </message>
    <message>
        <source>Site selection</source>
        <translation>Селекция на сайт</translation>
    </message>
    <message>
        <source>This page lets you modify the administrator for your site. This ensures that your site is secure and has proper name and E-mail set.</source>
        <translation>Тази страница ви позволява да променяте администратора на вашият сайт. Това гарантира, че вашият сайт е сигурен и има подходящо име и електронна поща.</translation>
    </message>
    <message>
        <source>You need to fill in the first name.</source>
        <translation>Вие трябва да попълните първото име.</translation>
    </message>
    <message>
        <source>You need to fill in the last name.</source>
        <translation>Вие трябва да попълните фамилното име.</translation>
    </message>
    <message>
        <source>You need to fill in an e-mail address.</source>
        <translation>Вие трябва да попълните е-мейл адрес.</translation>
    </message>
    <message>
        <source>You need to fill in a valid e-mail address.</source>
        <translation>Вие трябва да попълните валиден е-мейл адрес.</translation>
    </message>
    <message>
        <source>You need to fill in a password.</source>
        <translation>Вие трябва да попълните паролата.</translation>
    </message>
    <message>
        <source>Administrator settings</source>
        <translation>Настройки на администратор</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>E-mail address</source>
        <translation>Е-мейл адрес</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Потвърди парола</translation>
    </message>
    <message>
        <source>The login name is fixed and cannot be changed.
After the setup is done you can login with %admin_login and your password.</source>
        <translation>Името за вход е фиксирано и не може да бъде променено.(new line)
След като настройката е направена, вие можете да влизате с %admin_login и вашата парола.
</translation>
    </message>
    <message>
        <source>This page lets you modify information about the site you&apos;ve chosen to install. In addition, it also lets you choose a database for the site.</source>
        <translation>Тази страница ви позволява да променяте информация за сайта, който вие избрахте да инсталирате. В допълнение, то също ви позволява да избирате база данни за сайта.</translation>
    </message>
    <message>
        <source>Host names should not include underscores (&apos;_&apos;), as this violates the DNS RFC and will cause problems with Internet Explorer. They have been converted to dashes (&apos;-&apos;).</source>
        <translation>Хост имената не трябва да включва подчертавания (&apos;_&apos;), от това се нарушава DNS RFC и ще създаде проблеми с Интернет Експлоръра. Те трябва да бъдат преобразувани в тирета (&apos;-&apos;).</translation>
    </message>
    <message>
        <source>Your database already contain data.
The setup can continue with the initialization but may damage the present data.</source>
        <translation>Вашата база данни вече съдържа данни.(new line)
Настройката може да продължи със стартиране, но може да повреди настоящите данни.</translation>
    </message>
    <message>
        <source>Select what to do from the drop-down box.</source>
        <translation>Изберете това, което да искате да направите от падащото меню.</translation>
    </message>
    <message>
        <source>Action: </source>
        <translation>Действие:</translation>
    </message>
    <message>
        <source>Current site functionality</source>
        <translation>Текуща функционалност на сайта</translation>
    </message>
    <message>
        <source>Please select additional functionality</source>
        <translation>Моля, изберете допълнителна функционалност</translation>
    </message>
    <message>
        <source>Each site comes with a predefined set of functionality, however it is possible to add extra functionality.
This functionality is also available at a later time from the administration interface.</source>
        <translation>Всеки сайт върви с предефинирана функционалност, въпреки че е възможно да се прибавя допълнителна функционалност.(new line)
Тази функционалност е също достъпна и на по-късен етап в административния панел.</translation>
    </message>
    <message>
        <source>Site type</source>
        <translation>Тип сайт</translation>
    </message>
    <message>
        <source>The type of site will choose some basic settings for toolbars, menus, color and functionality.
It is possible to change these settings at a later time.</source>
        <translation>Типът на сайта ще избере някакви основни настройки за менюта с инструменти, менюта, цвят и функционалност.
Възможно е променяте тези настройки на по-късен етап.</translation>
    </message>
    <message>
        <source>The first time the user or admin site is accessed it will take some time (30 to 60 seconds). This is because eZ publish prepares the site for your machine.</source>
        <translation>Първият път, когато потребителят или администраторът на сайта отидат на сайта, това ще им отнеме малко време (30 до 60 секунди). Това е защото eZ publish приготвя сайта за вашата машина.</translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilities of eZ publish</source>
        <translation>Ако искате можете да позволите настройката да прибави някои демонстрационни данни към вашата база данни, тази демонстрационна информация ще даде добра демонстрация на способностите на eZ publish</translation>
    </message>
    <message>
        <source>First time users are advised to install the demo data.</source>
        <translation>Първият път е препоръчително потребителите да инсталират демо данните.
</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Бележка</translation>
    </message>
    <message>
        <source>The database was sucessfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>Базата данни беше успешно стартирана. Сега сте готови за преконфигурация на сайта.</translation>
    </message>
    <message>
        <source>PostgreSQL username and password is not tested until database names are selected.</source>
        <translation>PostgreSQL потребителското име и паролата не се тестват, докато имената на базите данни не са избрани.</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says</source>
        <translation>Можете да деактивирате това ръчно, редактирайте файл &lt;i&gt;settings/site.ini&lt;/i&gt; и потърсете реда, който показва</translation>
    </message>
    <message>
        <source>Sending e-mail failed</source>
        <translation>Провал на изпращането на е-мейла</translation>
    </message>
    <message>
        <source>Failed to send the registration email using</source>
        <translation>Провал на изпращането на е-мейл за регистрация</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file %filename and look for a line that says</source>
        <translation>Ако някога искате да рестартирате тази настройка, редактирайте файл %filename и потърсете реда, който показва</translation>
    </message>
    <message>
        <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited e-mails.</source>
        <translation>Ако желаете, можете да регистрирате тази инсталация чрез изпращане на определена информация към eZ системи. Никаква поверителна информация няма да бъде предадена и системите на EZ няма да използват вашите детайли за непоискани е-мейли.</translation>
    </message>
    <message>
        <source>The registration e-mail</source>
        <translation>Е-мейлът за регистрация</translation>
    </message>
    <message>
        <source>Sending out the e-mail and generating your site will take about 10 to 30 seconds depending on your machine. Please wait until the next page loads. Clicking the button again will only send out duplicate e-mails, and may corrupt the installation.</source>
        <translation>Изпращането на е-мейла и генерирането на вашия сайт ще продължи около 10 до 30 секунди според вашата машина. Моля, изчакайте докато следващата страница се зареди. Повторното натискане на бутона ще изпрати дупликат на е-мейлите и може да разваля инсталацията.</translation>
    </message>
    <message>
        <source>Creating sites</source>
        <translation>Създаване на сайтове</translation>
    </message>
    <message>
        <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the PHP documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that PostgreSQL 7.2 is not supported.</source>
        <translation>Моля, уверете се, че потребителското име и паролата са правилни. Потвърдете, че PostgreSQL база данни е конфигурирана правилно. Разгледайте документацията на PHP за повече информация. Запомнете да започнете постмастер с -i опцията. Имайте предвид, че PostgreSQL 7.2  не се поддържа.</translation>
    </message>
    <message>
        <source>The &apos;digest&apos; procedure is not available in your database, you cannot run eZ publish without this. Visit the FAQ for more information.</source>
        <translation>Процедурата &apos;digest&apos; не е налична в базата данни, не можете да пуснете eZ publish без това. Посетете Често задавани въпроси за повече информация.
</translation>
    </message>
    <message>
        <source>Your database version %version does not fit the minimum requirement which is %req_version.</source>
        <translation>Вашата версия на база данни %version не отговаря на минималното изискване, което е %req_version.</translation>
    </message>
    <message>
        <source>The setup wizard was not able to complete the creation of your selected sites.</source>
        <translation>Помощникът за настройка не е способен да завърши създаването на вашите избрани сайтове.</translation>
    </message>
    <message>
        <source>If you think you have fixed the errors you can try and click the &quot;Retry&quot; button.</source>
        <translation>Ако милите, че сте поправили грешките, можете да опитате с натискане на бутона &quot;Опитай пак&quot;.</translation>
    </message>
    <message>
        <source>The setup wizard failed to create the sites.</source>
        <translation>Помощникът за настройка се провали при създаване на сайтовете.</translation>
    </message>
    <message>
        <source>If possible try to fix these errors and click &quot;Retry&quot;.</source>
        <translation>Ако е възможно, опитайте да оправите тези грешки и натиснете &quot;Опитай отново&quot;.</translation>
    </message>
    <message>
        <source>Retry</source>
        <comment>Retry button in installation</comment>
        <translation>Опитай отново

Инсталиране на бутона Опитай отново</translation>
    </message>
    <message>
        <source>The database %database_name cannot be used, it uses the character set %charset which is different from the requested charset %req_charset.</source>
        <translation>Базата данни %database_name не може да бъде използвана. Тя използва символи %charset, които са различни от зададените %req_charset.</translation>
    </message>
    <message>
        <source>The following errors were detected</source>
        <translation>Следните грешки са окрити</translation>
    </message>
    <message>
        <source>There are two options:&lt;br&gt;- Direct delivery through transfer agent (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
        <translation>Има две опции: Директен получаване чрез агент за трансфер (трябва да бъде наличен на сървъра). Вторично използване на SMTP спомагателен сървър.</translation>
    </message>
    <message>
        <source>Sendmail/MTA</source>
        <translation>Sendmail/MTA</translation>
    </message>
    <message>
        <source>&lt;b&gt;Sendmail/MTA:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the mail transfer agent. The most common agent, sendmail, is usually available on most Linux/UNIX systems. If a mail transfer agent is not available then SMTP should be used.</source>
        <translation>Sendmail/MTA: Пощата е доставена директно, използвайки агентът за трансфер на поща. Най обикновеният агент, SendMail, обикновено е наличен на повечето операционни системи UNIX/Линукс. Ако агент за трансфер на поща не е наличен, тогава трябва да бъде използван SMTP.
</translation>
    </message>
    <message>
        <source>The access values must not be named &apos;admin&apos; or &apos;user&apos; and each value must be unique. Please change invalid values on site indicated by *</source>
        <translation type="obsolete">Стойностите за достъп не трябва да бъдат именувани &quot;администратор&quot; или &quot;потребител&quot; и всяка стойност трябва да бъде единствена. Моля, променете невалидните стойности на сайт, показани с *</translation>
    </message>
    <message>
        <source>&apos;User path&apos; and &apos;Admin path&apos; should only contain letters (&apos;a-zA-Z&apos;), digits (&apos;0-9&apos;) and underscores (&apos;_&apos;). These values must not be named &apos;admin&apos; or &apos;user&apos; and each value must be unique and non-empty. Please change invalid values for site indicated by *</source>
        <translation>&quot;Потребителската пътека&quot; и &quot;Администраторската пътека&quot; трябва да съдържат само букви (&apos;a-zA-Z&apos;), цифри (&apos;0-9&apos;) и долно тире (&apos;_&apos;). Тези променливи не трябва да се кръщават &apos;admin&apos; или &apos;user&apos; и всяка трябва да бъде уникална и не празна. Моля, променете невалидните променливи на сайта, отбелязани със *</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Пример</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Конструктор, не прави нищо по подразбиране.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>\return масив с името на оператора на шаблон.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Изпълнява PHP функция за почистване на оператора и променя \a$operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Примерен код, този код трябва да бъде променен, за да прави това, което операторът трябва да прави, в момента то само подрежда текст.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/session</name>
    <message>
        <source>Session admin</source>
        <translation>Администриране на сесии</translation>
    </message>
    <message>
        <source>The sessions were successfully removed.</source>
        <translation>Сесиите бяха успешно премахнати.</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Сесии</translation>
    </message>
    <message>
        <source>Use the buttons below to delete the session entries that are present in the database.</source>
        <translation>Използвайте бутоните по-долу за изтриване на командите, които са налични в базата данни.</translation>
    </message>
    <message>
        <source>WARNING! When removing sessions, users that are logged in will be thrown out from the system.</source>
        <translation>Внимание! Когато премахвате сесии, потребителите, които са влезли, ще бъдат изхвърлени от системата.</translation>
    </message>
    <message>
        <source>Remove all sessions</source>
        <translation>Премахни всички сесии</translation>
    </message>
    <message>
        <source>Remove timed out / old sessions</source>
        <translation>Премахни прекъснати / стари сесии</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Full name</source>
        <translation>Пълно име</translation>
    </message>
    <message>
        <source>Idle time</source>
        <translation>Неизползвано време</translation>
    </message>
    <message>
        <source>Idle since</source>
        <translation>Неизползван от</translation>
    </message>
    <message>
        <source>Time skew detected</source>
        <translation>Изкривено намерено време</translation>
    </message>
    <message>
        <source>Total number of sessions</source>
        <translation>Общ брой на сесиите</translation>
    </message>
    <message>
        <source>Displaying sessions for %username</source>
        <translation>Показване на сесии за %username</translation>
    </message>
    <message>
        <source>Show from all users</source>
        <translation>Покажи от всички потребители</translation>
    </message>
    <message>
        <source>Filter sessions</source>
        <translation>Филтрирани сесии</translation>
    </message>
    <message>
        <source>Everyone</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Registered users</source>
        <translation>Регистрирани потребители</translation>
    </message>
    <message>
        <source>Anonymous users</source>
        <translation>Анонимни потребители</translation>
    </message>
    <message>
        <source>Include inactive users</source>
        <translation>Включване на неактивни потребители</translation>
    </message>
    <message>
        <source>Update list</source>
        <translation>Подновяване на списък</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Брояч</translation>
    </message>
    <message>
        <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
        <translation>Има %logged_in_count регистрирани и %anonymous_count анонимни потребители онлайн.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Липсващи оператори на бази данни</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Вашето PHP няма подръжка за всички база данни, които eZ publish поддържа.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Също така някои бази данни имат по-нови функции от другите, като например кодова таблица.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>За да имате повече поддръжка на бази данни, трябва да прекомпилирате PHP, точното прекомпилиране на опциите е определно по-долу.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Липсваща оператор на бази данни</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>Никакви поддържащи оператори на бази данни не бяха намерени. eZ publish изисква база, данни за да складира данните, без такава системата ще се провали.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>За да придобиете поддръжка на бази данни, трябва да прекомпилирате PHP, точното прекомпилиране на опциите е определено по-долу.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Недостатъчни права върху директорията</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish не може да записва в никакви важни директории, без това настройката не може да завърши и някои от частите на eZ publish няма да функционират.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Препоръчително е да поправите това с текущите команди по-долу.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Shell команди</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Качването на файлове е забранено</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>Качването на файла не е допуснато, което значи, че е невъзможно, защото eZ publish управлява качването на файла. Всички други части на eZ publish все още работят добре, но е препоръчително да се позволят зарежданията на файловете.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Конфигурация</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Активирането на качването на файлове е готово чрез настройка на % 1 в php.ini. Погледнете ръководството на PHP за начина, по който да конфигурирате превключвателите
 </translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Повече информация за активирането на разширенията може да откриете като прочетете %1 и %2</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Липсваща поддръжка на превръщане на изображения</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>Способностите за превръщане на изображение не беше открита, това означава, че eZ publish не може да оразмерява всяка картинка или открива нейния тип. Това е съществена функционалност в eZ publish и трябва да бъде поддържана.</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>Операторът на шаблона не е наличен.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Бележка:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Бъдещите издания на eZ publish ще имат по-добре развита поддръжка на изображения, използвайки imagegd разширение.</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Липсваша ImageMagick програма</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>ImageMagick програма не е налична за eZ publish. Без нея eZ publish няма да е способен да прави превръщане на изображения, освен ако разширението на imagegd е налично.
</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Ако знаете къде е инсталирана програмата (Изпълнимият файл се казва</translation>
    </message>
    <message>
        <source>or</source>
        <translation>или</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>)влезте в директорията в полето на входящата информация по-долу и направете проверка (Разделете многото директории с </translation>
    </message>
    <message>
        <source>colon</source>
        <translation>двуеточие</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>точка и запетая</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Инсталация</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagick може да бъде свален от</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Липсващо MBString разширение</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>eZ publish съдържа добър списък от кодови таблици по подразбиране, въпреки че те могат да бъдат малко по-бавни тъй като са направени в чист PHP код. За щастие eZ publish поддържа разширението на mbstring за управляване на някои от кодовите таблици.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>Чрез задействане разширението на mbstring eZ publish ще има достъп до повече кодови таблици и ще бъде способен да преработва някои от тях по-бързо, като Unicode и ISO - 8859 - *. Това е препоръчително за многоезични сайтове и сайтове с по-екзотични кодови таблици.</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>Инсталацията на mbstring разширението е направена чрез компилиране на PHP с</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>опция.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Повече информация за задействане на разширението може да бъде открита в </translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>Не задействайте mbstring функцията, eZ publish ще използва разширенията само когато е нужно.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>PHP опция</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>е задействана</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish ще работи с тази опция, както и до него ще водят някои по-малки издания, докато всички входящи стойности ще бъдат върнати към </translation>
    </message>
    <message>
        <source>normal</source>
        <translation>нормален</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Недостатъчна PHP версия</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Твоята PHP версия, която е</translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>, не отговаря на минималните изисквания</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>По-нова версия на PHP може да се изтегли от</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Трябва да обновите в най-малко с версия</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish не може да запише в</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>директория, без нея настройката не може сама да се деактивира .
</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>Липсващо zlib разширение</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>Разширението zlib не е валидно за eZ publish. Без него eZ publish няма да бъде способна да инсталира демо данните, но ако не желаете демо данните, можете безопасно да ги игнорирате.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>За задействане на zlib трябва да прекомпилирате PHP със съдържанието му. Вие трябва да конфигурирате с PHP</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Повече информация по тази тема е налична в</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Повече информация по тази тема може да бъде намерена в %1.</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>PHP опция %1 is активирана</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish ще работи с тази опция, както и до него ще водят някои по-малки издания, докато всички входящи стойности ще бъдат направени цялостно във всяко изпълнение на скрипта.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>Препоръчително е опцията да е изключена. За да я изключите, редактирайте %1 конфигурация и настройка %2 в %3.</translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>PHP защитен режим е активиран</translation>
    </message>
    <message>
        <source>AcceptPathInfo disabled or running in CGI mode</source>
        <translation>AcceptPathInfo не е включен или върви в CGI режим</translation>
    </message>
    <message>
        <source>enter the following into your httpd.conf file.</source>
        <translation>Въведете следното във вашия httpd.conf файл.</translation>
    </message>
    <message>
        <source>Remember to restart your web server afterwards.</source>
        <translation>Не забравяйте след това да рестартирате вашия уеб сървър.</translation>
    </message>
    <message>
        <source>Insufficient execution time allowed to install eZ publish</source>
        <translation>Недостатъчното време за изпълнение позволи да се инсталира eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a execution time limit of %1.</source>
        <translation>eZ publish няма да работи правилно с ограничено време за изпълнение от %1.</translation>
    </message>
    <message>
        <source>It&apos;s highly recommended that you fix this.</source>
        <translation>Силно се препоръчва да поправите това.</translation>
    </message>
    <message>
        <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
        <translation>Намерете php.ini настройките за вашата PHP инсталация. На операционни системи UNIX, той обикновено се намира в /etc/php.ini, на Уиндоус системитe проверете пътя за инсталация на PHP.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
        <translation>Отворете php.ini файл и променете стойността max_execution_time на най-малко %1 и натиснете %2</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Следващ</translation>
    </message>
    <message>
        <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
        <translation>Ако пуснете eZ publish в хост обстановка, свържете се с вашият интернет доставчик, за да извърши промените</translation>
    </message>
    <message>
        <source>Missing imagegd2 extension</source>
        <translation>Липсващо imagegd2 разширение</translation>
    </message>
    <message>
        <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>Разширението imagegd2 не е ли налично в eZ publish. Без него eZ publish ще бъде неспособен да направи превръщане, използвайки ImageMagick</translation>
    </message>
    <message>
        <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>За да задействате imagegd2 трябва да прекомпилирате PHP с поддръжката за него, повече информация за което налична на</translation>
    </message>
    <message>
        <source>Insufficient memory allocated to install eZ publish</source>
        <translation>Недостатъчна памет, разпределена за инсталиране на eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a memory limit of %1.</source>
        <translation>eZ publish няма да работи правилно с ограничение на паметта от %1.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
        <translation>Отворете файла php.ini и превърнете стойността memory_limit в поне %1 и натиснете %2</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
        <translation>Препоръчително е опцията да е изключена. За спирането й редактирайте конфигурацията %phpini и настройте %magic_quotes_gpc и %magic_quotes_runtime в %offtext.</translation>
    </message>
    <message>
        <source>eZ publish will not work properly with this option on.</source>
        <translation>eZ publish няма да работи правилно с тази включена опция.</translation>
    </message>
    <message>
        <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
        <translation>За спирането й редактирайте конфигурацията %phpini и настройте %magic_quotes_gpc и %magic_quotes_runtime в %offtext.</translation>
    </message>
    <message>
        <source>Unstable PHP version</source>
        <translation>Неустойчива версия на PHP</translation>
    </message>
    <message>
        <source>, is known to be unstable</source>
        <translation>, е познат като неустойчив</translation>
    </message>
    <message>
        <source>Another version of PHP can be download at</source>
        <translation>Друга версия на PHP може да бъде свалена от</translation>
    </message>
    <message>
        <source>Missing text creation functions</source>
        <translation>Липсващ функции за създаване на текст</translation>
    </message>
    <message>
        <source>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</source>
        <translation>PHP функциите ImageTTFText и ImageTTFBBox липсват. Без тези функции не е възможно да се използва шаблонният оператор texttoimage.</translation>
    </message>
    <message>
        <source>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>За активиране на тези функции, имате нужда от прекомпилиране на PHP с поддръжка за него, повече информация за която е налична на</translation>
    </message>
    <message>
        <source>Missing Session Extension</source>
        <translation>Липсващо разширение на сесия</translation>
    </message>
    <message>
        <source>Your PHP module does not have session support, without this eZ publish will not work properly.</source>
        <translation>Вашият модул на PHP няма поддръжка на сесията, без това eZ publish няма да работи правилно.</translation>
    </message>
    <message>
        <source>To enable session support you will have recompile your PHP module without the %session_disable switch.</source>
        <translation>За активиране на сесията трябва да прекомпилирате PHP модула без превключвателя %session_disable.</translation>
    </message>
    <message>
        <source>If your site is on shared-hosting you must contact the system administrator of the hosting company.</source>
        <translation>Ако вашият сайт е на shared-hosting, трябва да се свържете със системния администратор на хостинг компанията.</translation>
    </message>
    <message>
        <source>, but the latest released PHP 4.3.x version is highly recommended.</source>
        <translation>, но най-новото издание на PHP 4.3.x версия е силно препоръчителна.</translation>
    </message>
    <message>
        <source>Although eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>Въпреки че eZ publish ще работи без него, вие може имате нужда от поддръжка за тази база данни.</translation>
    </message>
    <message>
        <source>The affected directories are: %dir_list</source>
        <translation>Повредените директории са: %dir_list</translation>
    </message>
    <message>
        <source>These shell commands will give proper permission to the webserver.</source>
        <translation>Тези shell команди ще ви дадат съответните права за уеб сървъра.</translation>
    </message>
    <message>
        <source>Alternative shell commands</source>
        <translation>Алтернативни shell команди</translation>
    </message>
    <message>
        <source>If you don&apos;t have permissions to change the ownership you can try these commands.</source>
        <translation>Нямате права да промените притежанието като използвате тези команди.</translation>
    </message>
    <message>
        <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the files to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
        <translation>eZ publish не може да намери тези потребители и групи на уеб сървъра.(new line)
Ако вие знаете потребителите и групите на уебсървъра, е препоръчително да се промени притежанието на файловете, за да се съчетаят този потребител и групата.(new line)
За да направите това, трябва да промените %chown commands под Алтернативни shell команди.
</translation>
    </message>
    <message>
        <source>These commands will setup the permission more correctly, but require knowledge about the running webserver.</source>
        <translation>Тези команди ще настроят разрешенията правилно, но изискват познания за работещия уеб сървър.</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Бележка</translation>
    </message>
    <message>
        <source>The %user_expr must be changed to your webserver username and groupname.</source>
        <translation>%user_expr трябва да промени вашето потребителско име и име на група на вашия уебсървър.</translation>
    </message>
    <message>
        <source>File uploading is not possible</source>
        <translation>Качването на файлове не е възможно</translation>
    </message>
    <message>
        <source>The PHP upload directory %upload_dir does not exists or is not accessible, without this you will not be able to upload files or images to eZ publish.</source>
        <translation>PHP директорията %upload_dir не съществува или не е достъпна, без това вие не може да качвате файлове или изображения в eZ publish.</translation>
    </message>
    <message>
        <source>Create the directory %upload_dir on your system. If you do not have the possibility to create this yourself ask the administrator to create it for you.</source>
        <translation>Създайте директорията %upload_dir във вашата система. Ако нямате възможността да създадете собствена, поискайте от администратора да направи това за вас.</translation>
    </message>
    <message>
        <source>The upload directory is currently placed in the directory of the root user.
This is a security problem and should be changed to another global temporary directory</source>
        <translation>Директорията за зареждане в момента е поставена в директорията на основния потребител.(new line)
Това е проблем на сигурността и тя трябва да бъде превърната в друга глобална временна директория
</translation>
    </message>
    <message>
        <source>This shell command will create the upload directory.</source>
        <translation>Тази shell команда ще създаде качената директория.</translation>
    </message>
    <message>
        <source>The PHP upload directory %upload_dir is not writeable. This means that it will be impossible to upload files or images to eZ publish.</source>
        <translation>PHP директорията %upload_dir не е записваща.Това означава, че не е възможно да качите файлове или изображения в eZ publish.</translation>
    </message>
    <message>
        <source>You must change the permission on the directory %upload_dir. If you do not have the possibility to create this yourself ask the administrator to do this for you.</source>
        <translation>Трябва да промените разрешенията в директорията %upload_dir. Ако нямате възможността да създадете това, поискайте от администратора да направи това вместо вас.
</translation>
    </message>
    <message>
        <source>These shell commands will give proper permission to the upload directory.</source>
        <translation>Тези shell команди ще ви дадат съответните права върху качената директория.</translation>
    </message>
    <message>
        <source>If you don&apos;t have permissions to change the ownership you can try this command.</source>
        <translation>Нямате права да промените притежанието като използвате тази команда.</translation>
    </message>
    <message>
        <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the upload directory to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
        <translation>eZ publish не може да намери този потребител и групи на уеб сървъра.(new line)
Ако вие знаете потребителите и групите на уебсървъра, е препоръчително да се промени притежанието на файловете, за да се съчетаят този потребител и групата.(new line)
За да направите това, трябва да промените %chown commands под Алтернативни shell команди.
</translation>
    </message>
    <message>
        <source>This shell command will give proper permission to the upload directory.</source>
        <translation>Тази shell команда ще ви даде съответните права върху качената директория.</translation>
    </message>
    <message>
        <source>If you know the user and group of the webserver you can try this command. Replace apache:apache with the user and group.</source>
        <translation>Ако знаете потребителя и групата на уеб сървъра, можете да пробвате тази команда. Заменете apache:apache с потребителя и групата.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are</source>
        <translation>Цялостният списък от кодови таблици е поддържан от mbstring</translation>
    </message>
    <message>
        <source>php.ini example</source>
        <translation>php.ini пример</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following</source>
        <translation>Примерно вие можете да създадете файл с име %1 във вашата eZ publish основна папка и да прибавите следната</translation>
    </message>
    <message>
        <source>.htaccess example</source>
        <translation>.htaccess пример</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are</source>
        <translation>eZ publish работи с включен защитен режим, въпреки че някои функции може да не бъдат налични. Някои от нещата може да се загубят</translation>
    </message>
    <message>
        <source>You need to enable AcceptPathInfo in your Apache config file, if you&apos;re using apache 2.x.</source>
        <translation>Вие трябва да включите AcceptPathInfo във вашия Apache config файл, ако използвате apache 2.x.</translation>
    </message>
    <message>
        <source>If you&apos;re running apache 1.3, eZ publish will not run in CGI mode.</source>
        <translation>Ако пуснете apache 1.3, eZ publish няма да тръгне в CGI режим.</translation>
    </message>
    <message>
        <source>allow_url_fopen ini setting is disabled</source>
        <translation>allow_url_fopen ini настройките са изключени</translation>
    </message>
    <message>
        <source>You need to alter your PHP settings, and enable the &apos;allow_url_fopen&apos; setting in your php.ini file.</source>
        <translation>Трябва да промените вашите PHP настройки и да включите &apos;allow_url_fopen&apos; настройките на вашия php.ini файл.</translation>
    </message>
    <message>
        <source>Note : Failure here will also cause failure to the accept_path_info test.</source>
        <translation>Бележка: Всяка грешка тук ще предизвика грешка в accept_path_info теста.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/toolbar</name>
    <message>
        <source>Tool</source>
        <translation>Инструмент</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Преместване</translation>
    </message>
    <message>
        <source>Update Placement</source>
        <translation>Обнови преместването</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Tool List for Toolbar_%toolbar_position</source>
        <translation>Списък с инструменти за Toolbar_%toolbar_position</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Добави инструмент</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Кошница</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Продукт</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Брояч</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>ДДС</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Цена без ДДС</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Цена с ДДС</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Отстъпка</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Пълна цена без ДДС</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Пълна цена с ДДС</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Продължи пазаруване</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Проверка</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Няма продукти в кошницата</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Потвърди поръчката</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Елементи на продукта</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потвърди</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Групи с отстъпка</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Редактирай тази група с отстъпка - %1</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Изглед на група</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Име на група</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Дефинирани правила</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Приложи за</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Добави правило</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Премахни правило</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Клиенти</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Прибави клиент</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Премахни клиент</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирай правило</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Процент на отстъпката</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Междинна сума на елементите</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Списък с поръчки</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Сума без ДДС</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Сума с ДДС</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Списъкът с поръчки е празен</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Ред</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Общ сбор на поръчки</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Регистрирай информация на акаунт</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Входящата информация не е валидна, попълнете всички полета</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Типове ДДС</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Процент</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Списък с желания</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Изпразни списък с желания</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Атрибути</translation>
    </message>
    <message>
        <source>Rule settings</source>
        <translation>Настройки на правила</translation>
    </message>
    <message>
        <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Изберете кои класове, секции или обекти (продукти) ще бъдат приложени към това под-правило. &apos;Всички&apos; означава, че правилото ще бъде приложено към всичките.</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Обект</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Не е определен.</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Първо име</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Фамилия</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
        <translation>Плащането беше отменено по неизвестна причина. Моля, опитайте да купите пак.</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Резюмена поръчки</translation>
    </message>
    <message>
        <source>Sort Result by</source>
        <translation>Сортирай резултатите по</translation>
    </message>
    <message>
        <source>Order Time</source>
        <translation>Време напоръчката</translation>
    </message>
    <message>
        <source>User Name</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>ID на поръчка</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Възходящ</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>Сортирай във възходящ ред</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Низходящ</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>Сортирай в низходящ ред</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Customer name</comment>
        <translation>Име

Име на клиента</translation>
    </message>
    <message>
        <source>Customer list</source>
        <translation>Списък с клиенти</translation>
    </message>
    <message>
        <source>Number of orders</source>
        <translation>Брой поръчки</translation>
    </message>
    <message>
        <source>The customer list is empty</source>
        <translation>Списъкът с клиенти е празен</translation>
    </message>
    <message>
        <source>Customer Information</source>
        <translation>Информация на клиент</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Списък с покупки</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>All Year</source>
        <translation type="obsolete">Цяла година</translation>
    </message>
    <message>
        <source>All Month</source>
        <translation type="obsolete">Цял месец</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
    <message>
        <source>Are you sure you want to remove order: </source>
        <translation>Сигурни ли сте, че искате да премахнете поръчка:</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Премахни елементи</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Избрани опции</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Статистики</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Информация за вашия акаунт</translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with * must be filled in</source>
        <translation>Входящата информация не е валидна, всички полета, маркирани с *,  трябва да бъдат попълнени</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Всички полета, маркирани с *,  трябва да бъдат попълнени.</translation>
    </message>
    <message>
        <source>Customer information</source>
        <translation>Информация на клиент</translation>
    </message>
    <message>
        <source>Shipping address</source>
        <translation>Адрес за доставка</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Компания</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Улица</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>Пощенски код</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Място</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Щат / Провинция</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Следните елементи бяха премахнати от вашата кошница, защото продуктите са били променени</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT</source>
        <translation>Междинна сума без ДДС</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT</source>
        <translation>Междинна сума с ДДС</translation>
    </message>
    <message>
        <source>SUM</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Продължи</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Опит се да прибави обект без цена към кошницата.</translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation>Вашето плащане беше прекратено.</translation>
    </message>
    <message>
        <source>Order %order_id [%order_status]</source>
        <translation>Поръчка %order_id [%order_status]</translation>
    </message>
    <message>
        <source>Order history</source>
        <translation>История на поръчката</translation>
    </message>
    <message>
        <source>We did not get a confirmation from the payment server.</source>
        <translation>Не получихме потвърждение от сървъра за плащането.</translation>
    </message>
    <message>
        <source>Waiting for a response from the payment server. This can take some time.</source>
        <translation>Очакване на отговор от сървъра за плащането. Това може да отнеме известно време.</translation>
    </message>
    <message>
        <source>Retrying to get a valid response.</source>
        <translation>Повторен опит за получаване на валиден отговор.</translation>
    </message>
    <message>
        <source>Retry </source>
        <translation>Опитай отново</translation>
    </message>
    <message>
        <source>out of </source>
        <translation>извън</translation>
    </message>
    <message>
        <source>If your page does not automatically refresh then press the refresh button manually.</source>
        <translation>Ако вашата страница не се зареди, опреснете автоматично и след това натиснете бутона за опресняване ръчно.</translation>
    </message>
    <message>
        <source>Order status</source>
        <translation>Статус на поръчка</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <source>Is active</source>
        <translation>Активен е</translation>
    </message>
    <message>
        <source>Is inactive</source>
        <translation>Не е активен</translation>
    </message>
    <message>
        <source>Please contact the owner of the webshop and provide your order ID</source>
        <translation>Моля, свържете се със собственика на уеб магазина и му дайте вашето ID</translation>
    </message>
    <message>
        <source>All Years</source>
        <translation>Всички години</translation>
    </message>
    <message>
        <source>All Months</source>
        <translation>Всички месеци</translation>
    </message>
</context>
<context>
    <name>design/standard/shop/view</name>
    <message>
        <source>Choose customers</source>
        <translation>Избери клиенти</translation>
    </message>
    <message>
        <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Моля, изберете потребителите, които искате да добавите към групата с отстъпка %groupname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете вашите потребители и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на обектите, за да промените списъка за търсене.</translation>
    </message>
    <message>
        <source>Choose product for discount</source>
        <translation>Изберете продукт за отстъпка</translation>
    </message>
    <message>
        <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
        <translation>Моля изберете продуктите, които искате да добавите към това правило %discountname в групата с отстъпка %groupname.(new line)
(new line)
(sp)(sp)(sp)(sp)Изберете вашите продукти и натиснете бутона %buttonname.(new line)
(sp)(sp)(sp)(sp)За бързо поставяне можете да използвате последните и отметнатите елементи.(new line)
(sp)(sp)(sp)(sp)Натиснете имената на продуктите, за да промените списъка за търсенез.
</translation>
    </message>
</context>
<context>
    <name>design/standard/simplified_treemenu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Сгъни / Разгъни</translation>
    </message>
</context>
<context>
    <name>design/standard/toolbar</name>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на менюта с инструменти</translation>
    </message>
    <message>
        <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
        <translation>Има %logged_in_count регистрирани и %anonymous_count анонимни потребители онлайн.</translation>
    </message>
    <message>
        <source>Shopping basket</source>
        <translation>Кошница за пазаруване</translation>
    </message>
    <message>
        <source>View all details</source>
        <translation>Виж всички детайли</translation>
    </message>
    <message>
        <source>Your basket is empty</source>
        <translation>Вашата кошница е празна</translation>
    </message>
    <message>
        <source>Best sellers</source>
        <translation>Най-добре продавани продукти</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Календар</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои чернови</translation>
    </message>
    <message>
        <source>Account</source>
        <translation>Акаунт</translation>
    </message>
    <message>
        <source>Not logged in</source>
        <translation>Не сте влезли</translation>
    </message>
    <message>
        <source>Logged in as: %username</source>
        <translation>Влез като: %username</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Редактирай акаунт</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Изход</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Not registered?</source>
        <translation>Не сте регистрирани?</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Забравили сте своята парола?</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation>Мои съобщения</translation>
    </message>
    <message>
        <source>User information</source>
        <translation>Информация на потребител</translation>
    </message>
    <message>
        <source>View basket</source>
        <translation>Виж кошница</translation>
    </message>
    <message>
        <source>Online: %logged_in_count:%anonymous_count</source>
        <comment>Short user information</comment>
        <translation>Онлайн: %logged_in_count:%anonymous_count

Кратка информация за потребител</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
</context>
<context>
    <name>design/standard/toolbar/search</name>
    <message>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Глобален</translation>
    </message>
    <message>
        <source>From here</source>
        <translation>От тук</translation>
    </message>
    <message>
        <source>Search: </source>
        <translation>Търси:</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Trigger list</source>
        <translation>Списък с тригери</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Работен поток</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Няма работен поток</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Module name</source>
        <translation>Име на модул</translation>
    </message>
    <message>
        <source>Function name</source>
        <translation>Име на функция</translation>
    </message>
    <message>
        <source>Connect type</source>
        <translation>Тип връзка</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Валиден</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Невалиден</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>Уеб адресът сочи към %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Последна промяна на %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>Уеб адресът няма дата на модификация</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Последно проверен на %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>Този уеб адрес не е проверен</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Филтър</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Последно проверен</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>Popup</source>
        <translation>Popup</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никога</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>All URLs</source>
        <translation>Всички уеб адреси</translation>
    </message>
    <message>
        <source>Invalid URLs</source>
        <translation>Невалидни уеб адреси</translation>
    </message>
    <message>
        <source>Valid URLs</source>
        <translation>Валидни уеб адреси</translation>
    </message>
    <message>
        <source>Information on URL</source>
        <translation>Информация за уеб адрес</translation>
    </message>
    <message>
        <source>Objects which use this link</source>
        <translation>Обекти, които използват този линк</translation>
    </message>
    <message>
        <source>No object available</source>
        <translation>Няма наличен обект</translation>
    </message>
    <message>
        <source>version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>The URL is not considered valid any more.</source>
        <translation>Уеб адресът вече не е валиден.</translation>
    </message>
    <message>
        <source>This means that the URL is no longer available or has been moved.</source>
        <translation>Това означава, че уеб адресът не е наличен или е бил преместен.</translation>
    </message>
</context>
<context>
    <name>design/standard/url/edit</name>
    <message>
        <source>Editing URL - %1</source>
        <translation>Редактиране на уеб адрес - %1</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Activate account</source>
        <translation>Активирай акаунт</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Не можете да влезете</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Валидно потребителско име и парола са нужни за влизане.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Достъпът не е позволен</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Нямате позволение за достъп до %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Промени парола на потребител</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Регистрирай потребител</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е валидна</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Входящата информация беше съхранена успешно</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Настройка на потребител</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Макскимум логин</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>е задействан</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обнови</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Регистриран потребител</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Вашият акаунт беше успешно създаден.</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Профил на потребител</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>Моля, въведете отново вашата стара парола.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>Паролата не съвпада, моля въведете вашата нова парола.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>Паролата беше успешно обновена.</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Редактирай профил</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>Change setting</source>
        <translation>Промени настройки</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Стара парола</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Нова парола</translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation>Въведете отново паролата</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Вашит акаунт беше успешно създаден. Е-мейл ще бъде изпратен на определения е-мейл адрес.(new line)
Трябва да следвате инструкциите във вашата поща, за да активирате(new line)
вашия акаунт.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Вход

Бутон</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>Вход

Бутон</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Забравили сте своята паролата?</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Вашият акаунт е активиран.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Съжалявам, ключът, който е изпратен, не е валиден. Акаунтът не е активиран.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation>Потребителско име

Потребителско име</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Не може да бъде регистриран нов потребител</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Обратно</translation>
    </message>
    <message>
        <source>The node (%1) specified in [UserSettings].DefaultUserPlacement setting in site.ini does not exist!</source>
        <translation>Възелът (%1), посочен в [UserSettings].DefaultUserPlacement настрйките в site.ini не съществува!</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Изпратено е писмо на този е-мейл адрес: %1. То съдържа линк, който трябва да кликнете за потвърждаване на това, че правилният потребител получава новата парола.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Няма регистрирани потребители с този е-мейл адрес.</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Забравили ли сте своята парола?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Ако сте забравиле паролата си, ние можем да генерираме нова за вас. Всичко, което трябва да направите, е да въведете вашия е-мейл адрес и ние ще създадем нова парола за вас.</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Генерирай нова парола</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Информация за вашия акаунт</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Паролата беше успешно генерирана и изпратена на: %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>Ключът за активация е невалиден или вече е използван.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>%siteurl new password</source>
        <translation>%siteurl нова парола</translation>
    </message>
    <message>
        <source>Click here to get new password</source>
        <translation>Натиснете тук, за да вземете новата парола</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Нова парола</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>%1 registration info</source>
        <translation>%1 Информация за регистрацията</translation>
    </message>
    <message>
        <source>Confirm user registration at %siteurl</source>
        <translation type="obsolete">Потвърди регистрацията на потребителя в %siteurl</translation>
    </message>
    <message>
        <source>Your user account at %siteurl has been created</source>
        <translation type="obsolete">Твоят потребителски акаунт %siteurl беше създаден</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation type="obsolete">Информация на акаунта</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Click the following URL to confirm your account</source>
        <translation>Кликнете следния уебадрес, за да потвърдите своя акаунт</translation>
    </message>
    <message>
        <source>New user registered at %siteurl</source>
        <translation>Нов потребител е регистриран в %siteurl</translation>
    </message>
    <message>
        <source>A new user has registered.</source>
        <translation>Нов потребител беше регистриран.</translation>
    </message>
    <message>
        <source>Account information.</source>
        <translation>Информация за акаунта.</translation>
    </message>
    <message>
        <source>Link to user information</source>
        <translation>Линк за потребителска информация</translation>
    </message>
    <message>
        <source>Thank you for registering at %siteurl.</source>
        <translation>Благодаря, че се регистрирахте в %siteurl.</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Информация за вашия акаунт</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>Login name</comment>
        <translation>Потребителско име

Потребителско име</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/menuconfig</name>
    <message>
        <source>Menu management</source>
        <translation>Управление на меню</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Menu positioning</source>
        <translation>Позициониране на меню</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click here to store the changes if you have modified the menu settings above.</source>
        <translation>Натиснете тук, за да съхраните промените, ако сте променяли настройките на менюто по-горе.</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/templatecreate</name>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Не можете да създадете шаблон, достъп забранен.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Грешно име. Можете да използвате само буквите A - Z, числа и _.</translation>
    </message>
    <message>
        <source>Create new template override for &lt;%template_name&gt;</source>
        <translation>Създай нов шаблон за &lt;%template_name&gt;</translation>
    </message>
    <message>
        <source>The newly created template file will be placed in</source>
        <translation>Току-що създаденият файл на шаблона ще бъде поставен в</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Име на файл</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Презапиши ключове</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Всички класове</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Секция</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Всички секции</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID на възел</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Включен основен шаблон</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Празен файл</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Копие на стандартния шаблон</translation>
    </message>
    <message>
        <source>Container (with children)</source>
        <translation>Кутия (с дъщерни)</translation>
    </message>
    <message>
        <source>View (without children)</source>
        <translation>Изглед (без дъщерни)</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Обект</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/templateedit</name>
    <message>
        <source>Edit template: &lt;%template&gt;</source>
        <translation>Редактирай шаблон: &lt;%template&gt;</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to save the contents of the text field above to the template file.</source>
        <translation>Натиснете този бутон за запазване съдържанието на полето за текст по-горе към файлът на шаблона.</translation>
    </message>
    <message>
        <source>You do not have permissions to save the contents of the text field above to the template file.</source>
        <translation>Нямате права за запазване на съдържанията на полето за текст върху файла на шаблона.</translation>
    </message>
    <message>
        <source>Back to overrides</source>
        <translation>Обратно към пълномощни</translation>
    </message>
    <message>
        <source>Back to override overview.</source>
        <translation>Обратно към изглед на пълномощно.</translation>
    </message>
    <message>
        <source>The template can not be edited.</source>
        <translation>Шаблонът не може да бъде редактиран.</translation>
    </message>
    <message>
        <source>The web server does not have write access to the requested template.</source>
        <translation>Уеб сървърът няма достъп за писане до искания шаблон.</translation>
    </message>
    <message>
        <source>The web server does not have read access to the requested template.</source>
        <translation>Уеб сървърът няма достъп за четене до зададения шаблон.</translation>
    </message>
    <message>
        <source>The requested template does not exist or is not being used as an override.</source>
        <translation>Зададеният шаблон не съществува или не е използван като пълномощно.</translation>
    </message>
    <message>
        <source>Edit &lt;%template_name&gt; [Template]</source>
        <translation>Редактирай  &lt;%section_name&gt; (Шаблон)</translation>
    </message>
    <message>
        <source>Requested template</source>
        <translation>Искан шаблон</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Overrides template</source>
        <translation>Пълномощни шаблони</translation>
    </message>
    <message>
        <source>Open as read only</source>
        <translation>Отвори само за четене</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/templatelist</name>
    <message>
        <source>Complete template list</source>
        <translation>Завършен списък с шаблони</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <source>Design resource</source>
        <translation>Дизайн ресурс</translation>
    </message>
    <message>
        <source>Manage overrides for template.</source>
        <translation>Управление на пълномощни за шаблон.</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Най-често срещани шаблони</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/templateview</name>
    <message>
        <source>The overrides could not be removed.</source>
        <translation>Пълномощните не могат да бъдат премахнати.</translation>
    </message>
    <message>
        <source>The following files and override rules could not be removed because of insufficient file permissions</source>
        <translation>Следните файлове и пълномощни правила не могат да бъдат премахнати заради недостатъчни права за файла</translation>
    </message>
    <message>
        <source>The override.ini file could not be modified because of insufficient permissions.</source>
        <translation>Файлът на override.ini не може да бъде променен поради недостатъчни права.</translation>
    </message>
    <message>
        <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
        <translation>Пълномощни за шаблон &lt;%template_name&gt; в &lt;%current_siteaccess&gt; достъп до сайта [%override_count]</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Стандартен ресурс на шаблон</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Обърни селекцията.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Съчетай условия</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>No file matched</source>
        <translation>Файлът не съвпада</translation>
    </message>
    <message>
        <source>Edit override template.</source>
        <translation>Редактирай пълномощен шаблон.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Remove selected template overrides.</source>
        <translation>Премахни избраните пълномощни шаблони.</translation>
    </message>
    <message>
        <source>New override</source>
        <translation>Ново пълномощно</translation>
    </message>
    <message>
        <source>Create a new template override.</source>
        <translation>Създай ново пълномощно на шаблон.</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритети</translation>
    </message>
</context>
<context>
    <name>design/standard/visual/toolbar</name>
    <message>
        <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
        <translation>Списък с инструменти за &lt;Toolbar_%toolbar_position&gt;</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Вярно</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Грешно</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>There are currently no tools in this toolbar</source>
        <translation>В момента няма инструменти в това меню с инструменти</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Обнови приоритети</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Добави инструмент</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Потвърди промените</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified the parameters above.</source>
        <translation>Натиснете този бутон, за да съхраните промените, ако сте променяли който и да е от параметрите по-горе.</translation>
    </message>
    <message>
        <source>Back to toolbars</source>
        <translation>Обратно към менюто с инструменти</translation>
    </message>
    <message>
        <source>Go back to the toolbar list.</source>
        <translation>Върни се към списъка от менюта с инструменти.</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Управление на меню с инструменти</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Достъп до сайта</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Текущ достъп до сайта</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Избери достъп до сайта</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
        <translation>Налични менюта с инструменти за достъп до сайта &lt;%siteaccess&gt;</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Remove</source>
        <translation>Премахни</translation>
    </message>
    <message>
        <source>Editing workflow</source>
        <translation>Редактиране на  работен поток</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Работен поток съхранен</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Информацията изисква поправка</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Модифициран от</translation>
    </message>
    <message>
        <source>on</source>
        <translation>включено</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Групи</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Събития</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Групи с работен поток</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Нова група</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>Процес на работния поток</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>Процесът на работния поток беше създаден в</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>и модифициран в</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Работен поток</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Използване на работен поток</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>в процес.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Потребител</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Този работен поток е пуснат от потребителя</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Обект със съдържание</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>Работният поток беше създаден за съдържанието</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>използвайки версия</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>в дъщерен</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Събитие от работния поток</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>Работният поток не е пуснат още, броят на главните събития в работния поток е</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>Позицията за текущото събитие е</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>Събитието, което ще бъде пуснато, е</translation>
    </message>
    <message>
        <source>event</source>
        <translation>събитие</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>Последното събитие върна статус</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Списък за събития за работния поток</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Рестартирай</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Следваща стъпка</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Лог за работен поток </translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Модификатор</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Модифициран</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Нов работен поток</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Добави група</translation>
    </message>
    <message>
        <source>Editing workflow group - %1</source>
        <translation>Редакция на група от работен поток - %1 </translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Модифициран от %username в %time</translation>
    </message>
    <message>
        <source>Edit workflow</source>
        <translation>Редактирай работен поток</translation>
    </message>
    <message>
        <source>Remove selected workflows</source>
        <translation>Премахни избраните работни потоци</translation>
    </message>
    <message>
        <source>Workflow process was created at %creation and modified at %modification.</source>
        <translation>Процесът на работния поток беше създаден от %creation и модифициран от %modification.</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <comment>%1 is workflow group</comment>
        <translation>Работни потоци в %1

%1 е група от работен поток</translation>
    </message>
    <message>
        <source>Select gateway</source>
        <translation>Избери вход</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмени</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Допълнителна информация</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Входящата информация не е валидна</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor</source>
        <translation type="obsolete">Редактор</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation type="obsolete">Потребители без одобрение</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Потребители без ID на работните потоци </translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Клас</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Класове за пускане на работен поток</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Работен поток за пускане</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Премахни избраните</translation>
    </message>
    <message>
        <source>Load attributes</source>
        <translation>Зареди атрибути</translation>
    </message>
    <message>
        <source>Modify publish date</source>
        <translation>Промени датата на публикуване</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Добави команда</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Class Attributes</source>
        <translation>Атрибути на класа</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
        <source>Editor</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Всеки</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Потребители без одобрение</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Класове за пускане на работен поток</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Потребители без ID на работните потоци </translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Работен поток за пускане</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Publish date will be modified.</source>
        <translation>Датата на публикуване ще бъде променена.</translation>
    </message>
    <message>
        <source>Publish date will not be modified.</source>
        <translation>Датата на публикуване няма да бъде променена.</translation>
    </message>
</context>
<context>
    <name>kernel/cache</name>
    <message>
        <source>Content view cache</source>
        <translation>Кеш на съдържание</translation>
    </message>
    <message>
        <source>Global INI cache</source>
        <translation>Глобален ini кеш</translation>
    </message>
    <message>
        <source>INI cache</source>
        <translation>Ini кеш</translation>
    </message>
    <message>
        <source>Codepage cache</source>
        <translation>Кеш на кодирана таблица</translation>
    </message>
    <message>
        <source>Expiry cache</source>
        <translation>Изтичане на кеш</translation>
    </message>
    <message>
        <source>Class identifier cache</source>
        <translation>Идентификатор на класа на кеш</translation>
    </message>
    <message>
        <source>Sort key cache</source>
        <translation>Сортиран ключов кеш</translation>
    </message>
    <message>
        <source>URL alias cache</source>
        <translation>Уеб адрес - кеш за псевдоним</translation>
    </message>
    <message>
        <source>Image alias</source>
        <translation>Псевдоним на изображение</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Кеш на шаблоните</translation>
    </message>
    <message>
        <source>Template block cache</source>
        <translation>Блокиране на кеш шаблон</translation>
    </message>
    <message>
        <source>Template override cache</source>
        <translation>Кеш на пълномощно на  шаблон</translation>
    </message>
    <message>
        <source>RSS cache</source>
        <translation>RSS кеш</translation>
    </message>
    <message>
        <source>Character transformation cache</source>
        <translation>Кеш за превръщане на символ</translation>
    </message>
    <message>
        <source>User info cache</source>
        <translation>Кеш на информация за потребител</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Списък на класове групи</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Списък на класове групи</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Премахни клас</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Редактирай клас</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Класове</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Списък с класовете</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(няма класове)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Премахни клас групи</translation>
    </message>
    <message>
        <source>You have to have at least one group that the class belongs to!</source>
        <translation>Вие трябва да имате поне една група, на която класът принадлежи!</translation>
    </message>
    <message>
        <source>Remove classes %class_id</source>
        <translation>Премахни класове %class_id</translation>
    </message>
    <message>
        <source>Copy of %class_name</source>
        <translation>Копие на %class_name</translation>
    </message>
    <message>
        <source>The class should have nonempty &apos;Name&apos; attribute.</source>
        <translation>Класът трябва да бъде с непразен атрибут &apos;Име&apos;.</translation>
    </message>
    <message>
        <source>The class should have at least one attribute.</source>
        <translation>Класът трябва да има поне един атрибут.</translation>
    </message>
    <message>
        <source>There is a class already having the same identifier.</source>
        <translation>Има друг клас, който вече притежава същия идентификатор.</translation>
    </message>
</context>
<context>
    <name>kernel/class/edit</name>
    <message>
        <source>New Class</source>
        <translation>Нов клас</translation>
    </message>
    <message>
        <source>new attribute</source>
        <translation>нов атрибут</translation>
    </message>
</context>
<context>
    <name>kernel/class/groupedit</name>
    <message>
        <source>New Group</source>
        <translation>Нова група</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezbinaryfile</name>
    <message>
        <source>Failed to store file %filename. Please contact the site administrator.</source>
        <translation>Файлът %filename не беше съхранен. Моля, свържете се с администратора.</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezimage</name>
    <message>
        <source>Failed to fetch Image Handler. Please contact the site administrator.</source>
        <translation>Image Handler не може да бъде изпълен. Моля, свържете се с администратора.</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezmedia</name>
    <message>
        <source>Failed to store media file %filename. Please contact the site administrator.</source>
        <translation>Медия файл %filename не може да бъде съхранен. Моля, свържете се с администратора.</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Одобрение</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Стандарт</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Наблюдател</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Собственик</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Лице, което одобрява</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Пощенска кутия</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Няма състояние до сега</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Пуснат работен поток</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Завършен работен поток</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Елемент от работният поток се провали</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Работният поток не съвпада с работата на cron</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>Работният поток беше оменен</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Работният поток беше възстановен за повторно използване</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Прието събитие</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Отхвърлено събитие</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Събитието не съвпада с работата на cron</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Събитието не съвпада с работата на cron, събитието ще бъде пуснато отново</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>Събитието пусна подсъбитие</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Целият работен поток е отменен</translation>
    </message>
    <message>
        <source>Workflow fetches template</source>
        <translation>Работният поток изкара шаблон</translation>
    </message>
    <message>
        <source>Workflow redirects user view</source>
        <translation>Работният поток препрати изглед на потребителя</translation>
    </message>
    <message>
        <source>New RSS Export</source>
        <translation>Нов RSS експорт</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Missing date input.</source>
        <translation>Няма въведена дата.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Няма въведени дата и време.</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <translation>Поне един автор е нужен.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <translation>Валиден файл е нужен.</translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>Datatype name</comment>
        <translation>Чек-бокс

Име на тип на данни</translation>
    </message>
    <message>
        <source>Enum</source>
        <comment>Datatype name</comment>
        <translation>Брояч

Име на тип на данни</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <translation>Поне едно поле трябва да се избере.</translation>
    </message>
    <message>
        <source>Float</source>
        <comment>Datatype name</comment>
        <translation>Пускам

Име на тип на данни</translation>
    </message>
    <message>
        <source>Image</source>
        <comment>Datatype name</comment>
        <translation>Изображение

Име на тип на данни</translation>
    </message>
    <message>
        <source>Integer</source>
        <comment>Datatype name</comment>
        <translation>Цяло число

Име на тип на данни</translation>
    </message>
    <message>
        <source>ISBN</source>
        <comment>Datatype name</comment>
        <translation>ISBN

Име на тип на данни</translation>
    </message>
    <message>
        <source>Matrix</source>
        <comment>Datatype name</comment>
        <translation>Матрица

Име на тип на данни</translation>
    </message>
    <message>
        <source>Media</source>
        <comment>Datatype name</comment>
        <translation>Медия

Име на тип на данни</translation>
    </message>
    <message>
        <source>Object relation</source>
        <comment>Datatype name</comment>
        <translation>Свързване на обекти

Име на тип на данни</translation>
    </message>
    <message>
        <source>Option</source>
        <comment>Datatype name</comment>
        <translation>Опция

Име на тип на данни</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <translation>Поне една опция е нужна.</translation>
    </message>
    <message>
        <source>Price</source>
        <comment>Datatype name</comment>
        <translation>Стойност

Име на тип на данни</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Добави към кошницата</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Добави към списък с желания</translation>
    </message>
    <message>
        <source>Range option</source>
        <comment>Datatype name</comment>
        <translation>Опция за подреждане

Име на тип на данни</translation>
    </message>
    <message>
        <source>Selection</source>
        <comment>Datatype name</comment>
        <translation>Избор

Име на тип на данни</translation>
    </message>
    <message>
        <source>Text line</source>
        <comment>Datatype name</comment>
        <translation>Текстов ред

Име на тип на данни</translation>
    </message>
    <message>
        <source>Subtree subscription</source>
        <comment>Datatype name</comment>
        <translation>Записване на поддърво

Име на тип на данни</translation>
    </message>
    <message>
        <source>URL</source>
        <comment>Datatype name</comment>
        <translation>Уеб адрес

Име на тип на данни</translation>
    </message>
    <message>
        <source>User account</source>
        <comment>Datatype name</comment>
        <translation>Потребителски акаунт

Име на тип на данни</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <translation>Потребител със същия е-мейл вече съществува.</translation>
    </message>
    <message>
        <source>Object %1 does not exist.</source>
        <translation>Обект %1 не същвствува.</translation>
    </message>
    <message>
        <source>Link %1 does not exist.</source>
        <translation>Линк %1 не съществува.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <comment>Datatype name</comment>
        <translation>Идентификатор

Име на тип на данни</translation>
    </message>
    <message>
        <source>image</source>
        <comment>Default image name</comment>
        <translation>картинка

Име на картинка по подразбиране</translation>
    </message>
    <message>
        <source>Ini Setting</source>
        <comment>Datatype name</comment>
        <translation>Ini настройка

Име на тип на данни</translation>
    </message>
    <message>
        <source>Package</source>
        <comment>Datatype name</comment>
        <translation>Пакет

Име на тип на данни</translation>
    </message>
    <message>
        <source>Send</source>
        <comment>Datatype information collector action</comment>
        <translation>Изпрати

Действие за събиране на информация за типа на данните</translation>
    </message>
    <message>
        <source>Missing objectrelation input.</source>
        <translation>Въведена е информация за липсващи свързани обекти.</translation>
    </message>
    <message>
        <source>Invalid time.</source>
        <translation>Невалидно време.</translation>
    </message>
    <message>
        <source>The author name must be provided.</source>
        <translation>Собственото име трябва да бъде предоставено.</translation>
    </message>
    <message>
        <source>The email address is not valid.</source>
        <translation>Е-мейл адресът не е валиден.</translation>
    </message>
    <message>
        <source>File uploading is not enabled. Please contact the site administrator to enable it.</source>
        <translation>Качването на файлове не е разрешено. Моля, свържете се с администратора за включване.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.</source>
        <translation>Размерът на качения файл превишава лимита в upload_max_filesize директива в php.ini.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the maximum upload size: %1 bytes.</source>
        <translation>Размерът на качения файл превишава максималния размер на качване: %1 байта.</translation>
    </message>
    <message>
        <source>The email address is empty.</source>
        <translation>Този е-мейл адрес е празен.</translation>
    </message>
    <message>
        <source>The given input is not a floating point number.</source>
        <translation>Дадената входяща информация не е вариращо число.</translation>
    </message>
    <message>
        <source>The input must be greater than %1</source>
        <translation>Входящата информация трябва да бъде повече от %1</translation>
    </message>
    <message>
        <source>The input must be less than %1</source>
        <translation>Входящата информация трябва да бъде по-малко от %1</translation>
    </message>
    <message>
        <source>The input is not in defined range %1 - %2</source>
        <translation>Входящата информация не е в дефинирания обхват %1 - %2</translation>
    </message>
    <message>
        <source>A valid image file is required.</source>
        <translation>Валиден файл на изображение е нужен.</translation>
    </message>
    <message>
        <source>The size of the uploaded image exceeds limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
        <translation>Размерът на качените картинки превишава лимита от upload_max_filesize директива в php.ini. Моля, свържете се с администратора.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
        <translation>Размерът на качения файл превишава лимита за този сайт: %1 байта.</translation>
    </message>
    <message>
        <source>Could not locate the ini file.</source>
        <translation>Не може да бъде открит ini файл.</translation>
    </message>
    <message>
        <source>The input is not a valid integer.</source>
        <translation>Входящата информация не е валидно цяло число.</translation>
    </message>
    <message>
        <source>The number must be greater than %1</source>
        <translation>Броят трябва да бъде повече от %1</translation>
    </message>
    <message>
        <source>The number must be less than %1</source>
        <translation>Броят трябва да бъде по-малко от %1</translation>
    </message>
    <message>
        <source>The number is not within the required range %1 - %2</source>
        <translation>Броят не е в желаната граница %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please check the input for mistakes.</source>
        <translation>ISBN брой не е верен. Моля, проверете входящата информация за грешки.</translation>
    </message>
    <message>
        <source>A valid media file is required.</source>
        <translation>Валиден медия файл е нужен.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
        <translation>Размерът на качения файл превишава лимита от upload_max_filesize директива в php.ini. Моля, свържете се с администратора.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds site maximum: %1 bytes.</source>
        <translation>Размерът на качения файл превишава максимума: %1 байта.</translation>
    </message>
    <message>
        <source>The option value must be provided.</source>
        <translation>Опция за стойността трябва да бъде предоставена.</translation>
    </message>
    <message>
        <source>The additional price for the multioption value is not valid.</source>
        <translation>Допълнителната сума за мултиопционална стойност не е валидна. </translation>
    </message>
    <message>
        <source>The Additional price value is not valid.</source>
        <translation>Допълнителната стойност на сумата не е валидна.</translation>
    </message>
    <message>
        <source>Input required.</source>
        <translation>Входяща информация е нужна.</translation>
    </message>
    <message>
        <source>The input text is too long. The maximum number of characters allowed is %1.</source>
        <translation>Входящият текст е твърде голям. Максималният брой позволени символи е %1.</translation>
    </message>
    <message>
        <source>Time input required.</source>
        <translation>Време за входяща информация е нужно.</translation>
    </message>
    <message>
        <source>The username must be specified.</source>
        <translation>Потребителското име трябва да бъде определено.</translation>
    </message>
    <message>
        <source>The username already exists, please choose another one.</source>
        <translation>Потребителското име вече съществува, моля изберете друго.</translation>
    </message>
    <message>
        <source>The passwords do not match.</source>
        <comment>eZUserType</comment>
        <translation>Паролите не съвпадат.
</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters long.</source>
        <translation>Паролата трябва да бъде наий-малко 3 символа.</translation>
    </message>
    <message>
        <source>Cannot remove the account:</source>
        <translation>Не може да премахне акаунта:</translation>
    </message>
    <message>
        <source>The account owner is currently logged in.</source>
        <translation>Собственикът на акаунта в момента е влязъл.</translation>
    </message>
    <message>
        <source>The account is currently used by the anonymous user.</source>
        <translation>Акаунтът в момента е използван от анонимен потребител.</translation>
    </message>
    <message>
        <source>The account is currenty used the administrator user.</source>
        <translation>Акаунтът в момента е използван от администратора.</translation>
    </message>
    <message>
        <source>You can not remove the last class holding user accounts.</source>
        <translation>Не можете да премахнете последния клас, прикрепен към акаунта на потребителите.</translation>
    </message>
    <message>
        <source>The link %1 does not exist.</source>
        <translation>Линк %1 не съществува.</translation>
    </message>
    <message>
        <source>Input required</source>
        <translation>Входяща информация е нужна</translation>
    </message>
    <message>
        <source>Multi-option</source>
        <comment>Datatype name</comment>
        <translation>Мулти-опция

Име на тип на данни</translation>
    </message>
    <message>
        <source>Authors</source>
        <comment>Datatype name</comment>
        <translation>Автори

Име на тип на данни</translation>
    </message>
    <message>
        <source>File</source>
        <comment>Datatype name</comment>
        <translation>Файл

Име на тип на данни</translation>
    </message>
    <message>
        <source>Date</source>
        <comment>Datatype name</comment>
        <translation>Дата

Име на тип на данни</translation>
    </message>
    <message>
        <source>Date and time</source>
        <comment>Datatype name</comment>
        <translation>дата и време

Име на тип на данни</translation>
    </message>
    <message>
        <source>E-mail</source>
        <comment>Datatype name</comment>
        <translation>Е-мейл

Име на тип на данни</translation>
    </message>
    <message>
        <source>Keywords</source>
        <comment>Datatype name</comment>
        <translation>Ключови думи

Име на тип на данни</translation>
    </message>
    <message>
        <source>Object relations</source>
        <comment>Datatype name</comment>
        <translation>Свързване на обекти

Име на тип на данни</translation>
    </message>
    <message>
        <source>Text block</source>
        <comment>Datatype name</comment>
        <translation>Блокиране на текст

Име на тип на данни</translation>
    </message>
    <message>
        <source>Time</source>
        <comment>Datatype name</comment>
        <translation>Време

Име на тип на данни</translation>
    </message>
    <message>
        <source>XML block</source>
        <comment>Datatype name</comment>
        <translation>Блокиране на XML

Име на тип на данни</translation>
    </message>
    <message>
        <source>Object %1 can not be embeded to itself.</source>
        <translation>Обект %1 не може да бъде прикрепен към себе си.</translation>
    </message>
    <message>
        <source>Node %1 does not exist.</source>
        <translation>Възел %1 не съществува.</translation>
    </message>
    <message>
        <source>Node &apos;%1&apos; does not exist.</source>
        <translation>Възел &apos;%1&apos; не съществува.</translation>
    </message>
    <message>
        <source>Invalid reference in &lt;embed&gt; tag. Note that &lt;embed&gt; tag supports only &apos;eznode&apos; and &apos;ezobject&apos; protocols.</source>
        <translation>Невалидна връзка в &lt;embed&gt; таг. Имайте предвид, че &lt;embed&gt; таг поддържа само &apos;eznode&apos;  и &apos;ezobject&apos; протоколи.</translation>
    </message>
    <message>
        <source>No &apos;href&apos; attribute in &apos;embed&apos; tag.</source>
        <translation>Няма &apos;href&apos; атрибут в &apos;embed&apos; таг.</translation>
    </message>
    <message>
        <source>Date is not valid.</source>
        <translation>Датата не е валидна.</translation>
    </message>
    <message>
        <source>Time is not valid.</source>
        <translation>Времето не е валидно.</translation>
    </message>
    <message>
        <source>The image file must have non-zero size.</source>
        <translation>Файлът с картинката трябва да има големина повече от нула.</translation>
    </message>
    <message>
        <source>Missing matrix input.</source>
        <translation>Въведена е липсваща матрица.</translation>
    </message>
    <message>
        <source>Missing objectrelation list input.</source>
        <translation>Въведен е списък с липсващи свързани обекти.</translation>
    </message>
    <message>
        <source>NAME is required.</source>
        <translation>ИМЕ е задължително поле.</translation>
    </message>
    <message>
        <source>Invalid price.</source>
        <translation>Невалидна цена.</translation>
    </message>
    <message>
        <source>The password mustn&apos;t be &quot;password&quot;.</source>
        <translation>Паролата не трябва да е &quot;password&quot;.</translation>
    </message>
    <message>
        <source>Attribute &apos;%attrName&apos; in tag %currentTag is not supported (removed)</source>
        <translation>Атрибутът &apos;%attrName&apos; в таг %currentTag не се поддържа (премахнат е)</translation>
    </message>
    <message>
        <source>Attribute &apos;%key&apos; in tag %currentTag not found (need fix)</source>
        <translation>Атрибутът &apos;%key&apos; в таг %currentTag не е открит (има нужда от фиксиране)</translation>
    </message>
    <message>
        <source>Attribute &apos;%key&apos; in tag %currentTag has invalid value ( choose &apos;%validValue&apos; )</source>
        <translation>Атрибутът  &apos;%key&apos; в таг %currentTag има невалидна променлива ( изберете &apos;%validValue&apos; )</translation>
    </message>
    <message>
        <source>Tag &apos;link&apos; must have attribute &apos;href&apos; or valid &apos;id&apos; (need fix)</source>
        <translation>Тагът &apos;link&apos; трябва да има атрибут &apos;href&apos; или валиден &apos;id&apos; (има нижда от фиксиране)</translation>
    </message>
    <message>
        <source>Attribute &apos;href&apos; in tag &apos;link&apos; cannot be empty</source>
        <translation>Атрибут &apos;href&apos; в таг &apos;link&apos; не може да е празен</translation>
    </message>
    <message>
        <source>Tag &apos;%currentTag&apos; is not allowed to be the child of &apos;%parentNodeTag&apos; (removed)</source>
        <translation>Таг &apos;%currentTag&apos; не може да бъде дъщерен на &apos;%parentNodeTag&apos; (премахнат е)</translation>
    </message>
    <message>
        <source>Unmatched tag %lastInsertedNodeTag</source>
        <translation>Неподходящ таг %lastInsertedNodeTag</translation>
    </message>
    <message>
        <source>Unsupported tag &apos;%justName&apos; (removed)</source>
        <translation>Не се поддържа таг &apos;%justName&apos; (премахнат е)</translation>
    </message>
    <message>
        <source>Attribute &apos;%attrName&apos; in tag %justName is not supported (removed)</source>
        <translation>Атрибутът &apos;%attrName&apos; в таг %justName не се поддържа (премахнат е)</translation>
    </message>
    <message>
        <source>Tag &apos;%justName&apos; is not allowed to be the child of &apos;%lastInsertedNodeTag&apos; (removed)</source>
        <translation>Таг &apos;%justName&apos; не може да бъде дъщерен на &apos;%lastInsertedNodeTag&apos; (премахнат е)</translation>
    </message>
    <message>
        <source>Custom tag &apos;%customTagName&apos; is not available, use one of the following: %availableTagList</source>
        <translation>Таг &apos;%customTagName&apos; не е наличен, използвайте някой от посочените: %availableTagList</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Действие за съдействие</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Съдействие</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Търси</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Напреднал</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Основен възел не е избран, моля изберете един.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Съдържание</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Мои чернови</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Премахни редактираната версия</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Премахни обект</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Съвет от %1:%2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Е-мейл адресът на подателя не е валиден</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Е-мейл адресът на получателя не е валиден</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Посъветвай приятел</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Преведи</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Преводи на съдържание</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Кошче</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Версии</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Мои бележки</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Списък с чакащи</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL преводач</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Ключови думи</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Медия</translation>
    </message>
    <message>
        <source>New content</source>
        <translation>Ново съдържание</translation>
    </message>
    <message>
        <source>Remove location</source>
        <translation>Премахни местоположение</translation>
    </message>
    <message>
        <source>You are not allowed to place this object under: %1</source>
        <translation>Нямате права да поставите този обект под: %1</translation>
    </message>
    <message>
        <source>Top Level Nodes</source>
        <translation>Най-горно ниво на възли</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Скрит</translation>
    </message>
    <message>
        <source>Hidden by superior</source>
        <translation>Скрит от по-висшестоящ</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Видим</translation>
    </message>
    <message>
        <source>Copy Subtree</source>
        <translation>Копирай поддърво</translation>
    </message>
    <message>
        <source>The receiver has already received the maximimum number of tipafriend mails the last hours</source>
        <translation>Получателят вече прие максималния брой tipafriend писма, през последните часове</translation>
    </message>
    <message>
        <source>A node in the node assignment list has been deleted.</source>
        <translation>Беше изтрит възел от списъка с възли.</translation>
    </message>
    <message>
        <source>&quot;$contentObjectName&quot;: Sub items that are used by other objects</source>
        <translation>&quot;$contentObjectName&quot;: Поделементи, които се използват от други обекти</translation>
    </message>
</context>
<context>
    <name>kernel/content/copysubtree</name>
    <message>
        <source>Object (ID = %1) was not copied: you don&apos;t have permissions to read object.</source>
        <translation>Обект (ID = %1) не е копиран: нямате права да прочетете обекта.</translation>
    </message>
    <message>
        <source>Node (ID = %1) was not copied: you don&apos;t have permissions to read object (ID = %2).</source>
        <translation>Възел (ID = %1) не е копиран: нямате права да прочетете обекта.</translation>
    </message>
    <message>
        <source>Node (ID = %1) wasn&apos;t copied: parent node (ID = %2) wasn&apos;t copied.</source>
        <translation>Възел (ID = %1) не беше копиран: възел на източник (ID = %2) не беше копиран.</translation>
    </message>
    <message>
        <source>Node (ID = %1) was not copied: you don&apos;t have permissions to create.</source>
        <translation>Възел (ID = %1) не е копиран: нямате права за създаване.</translation>
    </message>
    <message>
        <source>Object (ID = %1) was not copied: no one nodes of object wasn&apos;t copied.</source>
        <translation>Обект (ID = %1) не е копиран: нито един от възлите на обекта не беше копиран.</translation>
    </message>
    <message>
        <source>Cannot publish object (ID = %1).</source>
        <translation>Не може да се публикува обект (ID = %1).</translation>
    </message>
    <message>
        <source>Fatal error: cannot get subtree main node (ID = %1).</source>
        <translation>Фатална грешка: не може да намери главния възел на поддърво (ID = %1).</translation>
    </message>
    <message>
        <source>Fatal error: cannot get destination node (ID = %1).</source>
        <translation>Фатална грешка: не може да намери възел за предназначение (ID = %1).</translation>
    </message>
    <message>
        <source>Number of nodes of source subtree - %1</source>
        <translation>Брой на възлите на поддърво на източник - %1</translation>
    </message>
    <message>
        <source>Subtree was not copied.</source>
        <translation>Поддървото не беше копирано.</translation>
    </message>
    <message>
        <source>Number of copied nodes - %1</source>
        <translation>Брой на копираните възли - %1</translation>
    </message>
    <message>
        <source>Number of copied contentobjects - %1</source>
        <translation>Брой на копираните обектите на съдържанието - %1</translation>
    </message>
    <message>
        <source>Cannot create instance of eZDB to fix local links (related objects).</source>
        <translation>Не може да бъде създаден пример за eZ база данни за закрепване на локални линкове (свързани обекти).</translation>
    </message>
    <message>
        <source>Successfuly DONE.</source>
        <translation>Успешно е направено.</translation>
    </message>
    <message>
        <source>You are trying to copy a subtree that contains more than the maximum possible nodes for subtree copying. You can copy this subtree using Subtree Copy script.</source>
        <translation>Вие се опитвате да копирате поддърво, което съдържа максимума възможни възли за копиране на поддърво. Можете да копирате поддърво. използвайки Subtree Copy скрипт.</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>дъщерен

1 дъщерен</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>дъщерни

няколко дъщерни</translation>
    </message>
</context>
<context>
    <name>kernel/content/upload</name>
    <message>
        <source>The file %filename does not exist, cannot insert file.</source>
        <translation>Файлът %filename не съществува, не може да бъде въведен файл.</translation>
    </message>
    <message>
        <source>No matching class identifier found.</source>
        <translation>Няма намерен съответстващ идентификатор за клас.</translation>
    </message>
    <message>
        <source>The class %class_identifier does not exist.</source>
        <translation>Класът %class_identifier не съществува.</translation>
    </message>
    <message>
        <source>Was not able to figure out placement of object.</source>
        <translation>Невъзможно идентифициране на положение на обект.</translation>
    </message>
    <message>
        <source>No configuration group in upload.ini for class identifier %class_identifier.</source>
        <translation>Няма група за конфигурация в upload.ini за идентификатор на класа %class_identifier.</translation>
    </message>
    <message>
        <source>No matching file attribute found, cannot create content object without this.</source>
        <translation>Няма намерен подхождящ файлов атрибут, не може да бъде създаден обект за съдържание без това.</translation>
    </message>
    <message>
        <source>No matching name attribute found, cannot create content object without this.</source>
        <translation>Няма намерен подхождящ атрибут на име, не може да бъде създаден обект за съдържание без това.</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support regular file storage.</source>
        <translation>Атрибутът %class_identifier не поддържа правиилно съхранение на файл.</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support simple string storage.</source>
        <translation>Атрибутът %class_identifier не поддържа просто съхранение на стринг.</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support HTTP file storage.</source>
        <translation>Атрибутът %class_identifier не поддържа съхранение на HTTP файл.</translation>
    </message>
    <message>
        <source>Publishing of content object was halted.</source>
        <translation>Публикуването на свързани обекти беше прекъснато.</translation>
    </message>
    <message>
        <source>Publish process was cancelled.</source>
        <translation>Процесът на публикуване беше отменен.</translation>
    </message>
    <message>
        <source>A file is required for upload, no file were found.</source>
        <translation>Изисква се файл за зареждане, не беше намерен такъв.</translation>
    </message>
    <message>
        <source>Expected a eZHTTPFile object but got nothing.</source>
        <translation>Очакване на eZHTTPFile файл, но не е получено нищо.</translation>
    </message>
    <message>
        <source>No HTTP file found, cannot fetch uploaded file.</source>
        <translation>Никакъв HTTP файл не е намерен, не може да се стигне до качения файл.</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Разрешение отказано</translation>
    </message>
    <message>
        <source>There was an error trying to instantiate content upload handler.</source>
        <translation>Имаше грешка при моменталното зареждане на оператора. </translation>
    </message>
    <message>
        <source>Could not find content upload handler &apos;%handler_name&apos;</source>
        <translation>Не може да бъде намерен зареденият оператор &apos;%handler_name&apos;</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
        <translation>Размерът на качения файл превишава лимита за този сайт: %1 байта.</translation>
    </message>
</context>
<context>
    <name>kernel/contentclass</name>
    <message>
        <source>New %1</source>
        <translation>Нов %1</translation>
    </message>
    <message>
        <source>Cannot remove class &apos;%class_name&apos;:</source>
        <translation>Не може да бъде премахнат класът &apos;%class_name&apos;:</translation>
    </message>
    <message>
        <source>The class is used by a top-level node and cannot be removed.</source>
        <translation>Класът е използван от най-големия възел и не може да бъде премахнат.</translation>
    </message>
</context>
<context>
    <name>kernel/design</name>
    <message>
        <source>Template list</source>
        <translation>Списък с шаблони</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Изглед на шаблона</translation>
    </message>
    <message>
        <source>Create new template</source>
        <translation>Създай нов шаблон</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Редакция на шаблон</translation>
    </message>
    <message>
        <source>Toolbar list</source>
        <translation>Списък с менюта с инструменти</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>About</source>
        <translation>За</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Авторско право</translation>
    </message>
</context>
<context>
    <name>kernel/form</name>
    <message>
        <source>Form processing</source>
        <translation>Система в процес</translation>
    </message>
</context>
<context>
    <name>kernel/infocollector</name>
    <message>
        <source>Collected information</source>
        <translation>Събрана информация</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Content structure</source>
        <comment>Navigation part</comment>
        <translation>Съдържание на структура

Навигационна структура</translation>
    </message>
    <message>
        <source>Media library</source>
        <comment>Navigation part</comment>
        <translation>Медийна библиотека

Навигационна структура</translation>
    </message>
    <message>
        <source>User accounts</source>
        <comment>Navigation part</comment>
        <translation>Потребителски акаунти

Навигационна структура</translation>
    </message>
    <message>
        <source>Webshop</source>
        <comment>Navigation part</comment>
        <translation>Уеб магазин

Навигационна структура</translation>
    </message>
    <message>
        <source>Design</source>
        <comment>Navigation part</comment>
        <translation>Дизайн

Навигационна структура</translation>
    </message>
    <message>
        <source>Setup</source>
        <comment>Navigation part</comment>
        <translation>Настройка

Навигационна структура</translation>
    </message>
    <message>
        <source>My account</source>
        <comment>Navigation part</comment>
        <translation>Моят акаунт

Навигационна структура</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification settings</source>
        <translation>Настройки на съобщенията</translation>
    </message>
</context>
<context>
    <name>kernel/package</name>
    <message>
        <source>Packages</source>
        <translation>Пакети</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Качи</translation>
    </message>
    <message>
        <source>Package information</source>
        <translation>Информация за пакета</translation>
    </message>
    <message>
        <source>Package maintainer</source>
        <translation>Поддържащ пакета</translation>
    </message>
    <message>
        <source>Package changelog</source>
        <translation>Лог с промени на пакета</translation>
    </message>
    <message>
        <source>Package thumbnail</source>
        <translation>Умален файл на пакета</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Име на пакет</translation>
    </message>
    <message>
        <source>Package name is missing</source>
        <translation>Името на пакета липсва</translation>
    </message>
    <message>
        <source>A package named %packagename already exists, please give another name</source>
        <translation>Пакет, наречен %packagename вече съществува, моля, задайте ново име</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Резюме</translation>
    </message>
    <message>
        <source>Summary is missing</source>
        <translation>Резюмето липсва</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>You must enter a name for the changelog</source>
        <translation>Трябва да въведете име за лога с промените</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>Е-мейл</translation>
    </message>
    <message>
        <source>You must enter an e-mail for the changelog</source>
        <translation>Трябва да въведете е-майл за лога с промените</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Лог с промени</translation>
    </message>
    <message>
        <source>You must supply some text for the changelog entry</source>
        <translation>Трябва да включите някакъв текст във входните данни за лога с промените</translation>
    </message>
    <message>
        <source>You must enter a name of the maintainer</source>
        <translation>Трябва да въведете име на поддържащия</translation>
    </message>
    <message>
        <source>You must enter an e-mail address of the maintainer</source>
        <translation>Трябва да въведете е-майл на поддържащия</translation>
    </message>
    <message>
        <source>Content classes to include</source>
        <translation>Клас със съдържание за включване</translation>
    </message>
    <message>
        <source>Content class export</source>
        <translation>Експорт на клас със съдържание</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Списък с класовете</translation>
    </message>
    <message>
        <source>You must select at least one class for inclusion</source>
        <translation>Трябва да изберете поне един клас за включване</translation>
    </message>
    <message>
        <source>CSS file</source>
        <translation>CSS файл</translation>
    </message>
    <message>
        <source>Image files</source>
        <translation>Файлове с картинки</translation>
    </message>
    <message>
        <source>Site style</source>
        <translation>Стил на сайта</translation>
    </message>
    <message>
        <source>File did not have a .css suffix, this is most likely not a CSS file</source>
        <translation>Файлът няма .css разширение, най-вероятно това не е CSS файл</translation>
    </message>
    <message>
        <source>Content class %classname (%classidentifier)</source>
        <translation>Клас със съдържание %classname (%classidentifier)</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Създай пакет</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Инсталирай</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталирай</translation>
    </message>
    <message>
        <source>Package %packagename already exists, cannot import the package</source>
        <translation>Пакетът %packagename вече съществува, не може да се импортира пакета</translation>
    </message>
    <message>
        <source>Local</source>
        <translation>Локален</translation>
    </message>
    <message>
        <source>Styles</source>
        <translation>Стилове</translation>
    </message>
    <message>
        <source>Addons</source>
        <translation>Добавки</translation>
    </message>
    <message>
        <source>The version must only contain numbers (optionally followed by text) and must be delimited by dots (.), e.g. 1.0, 3.4.0beta1</source>
        <translation>Версията трябва да съдържа само числа (обикновено заедно с текст) и трябва да бъдат разделени с точки (.), например 1.0, 3.4.0beta1</translation>
    </message>
    <message>
        <source>Content objects to include</source>
        <translation>Включване на обекти със съдържание</translation>
    </message>
    <message>
        <source>Content object limits</source>
        <translation>Ограничение на обект със съдържание</translation>
    </message>
    <message>
        <source>Content object export</source>
        <translation>Експорт на обект със съдържание</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Избрани възли</translation>
    </message>
    <message>
        <source>You must select one or more node(s)/subtree(s) for export.</source>
        <translation>Трябва да изберете един или повече възли/поддървета за експорт.</translation>
    </message>
    <message>
        <source>You must choose one or more languages.</source>
        <translation>Трябва да изберете един или повече езици.</translation>
    </message>
    <message>
        <source>You must choose one or more site access.</source>
        <translation>Трябва да изберете един или повече сайтове за достъп.</translation>
    </message>
    <message>
        <source>CSS files</source>
        <translation>CSS файлове</translation>
    </message>
    <message>
        <source>You must upload both CSS files</source>
        <translation>Трябва да качите и двата CSS файла</translation>
    </message>
    <message>
        <source>Content object %objectname</source>
        <translation>Обект със съдържание %objectname</translation>
    </message>
    <message>
        <source>Site access mapping</source>
        <translation>Свързане на Site access</translation>
    </message>
    <message>
        <source>Top node placements</source>
        <translation>Място на главен възел</translation>
    </message>
    <message>
        <source>Content object import</source>
        <translation>Импорт на обект със съдържание</translation>
    </message>
    <message>
        <source>Select parent nodes</source>
        <translation>Избери дъщерни възли</translation>
    </message>
    <message>
        <source>You must assign all nodes to new parent nodes.</source>
        <translation>Вие трябва да прехвърлите всички възли на новите дъщерни възли.</translation>
    </message>
    <message>
        <source>Lead</source>
        <translation>Водещ</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Разработчик</translation>
    </message>
    <message>
        <source>Designer</source>
        <translation>Дизайнер</translation>
    </message>
    <message>
        <source>Contributor</source>
        <translation>Участник</translation>
    </message>
    <message>
        <source>Tester</source>
        <translation>Тестер</translation>
    </message>
    <message>
        <source>The package name %packagename is not valid, it can only contain characters in the range a-z, 0-9 and underscore.</source>
        <translation>Името на пакета %packagename не е валидно, то може да съдържа символите А-Я, цифри 0-9 и долна черта.</translation>
    </message>
</context>
<context>
    <name>kernel/pdf</name>
    <message>
        <source>PDF Export</source>
        <translation>Експорт в PDF </translation>
    </message>
</context>
<context>
    <name>kernel/pdfexport</name>
    <message>
        <source>New PDF Export</source>
        <translation>Нов експорт в PDF</translation>
    </message>
</context>
<context>
    <name>kernel/reference</name>
    <message>
        <source>Reference documentation</source>
        <translation>Препоръчителна документация</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Role list</source>
        <translation>Списък с ролите</translation>
    </message>
    <message>
        <source>Editing policy</source>
        <translation>Редактирана политика</translation>
    </message>
    <message>
        <source>Limit on section</source>
        <translation>Ограничение в секцията</translation>
    </message>
    <message>
        <source>Create new policy, step 2: select function</source>
        <translation>Създай нова политика, стъпка 2: избери функция</translation>
    </message>
    <message>
        <source>Create new policy, step three: set function limitations</source>
        <translation>Създай нова политика, трета стъпка: настрой ограничения на функцията</translation>
    </message>
    <message>
        <source>Create new policy, step two: select function</source>
        <translation>Създай нова политика, втора стъпка: избери функция</translation>
    </message>
    <message>
        <source>Create new policy, step one: select module</source>
        <translation>Създай нова политика, първа стъпка: избери модул</translation>
    </message>
</context>
<context>
    <name>kernel/role/edit</name>
    <message>
        <source>New role</source>
        <translation>Нова роля</translation>
    </message>
    <message>
        <source>Copy of %rolename</source>
        <translation>Копие на %rolename</translation>
    </message>
</context>
<context>
    <name>kernel/rss</name>
    <message>
        <source>Really Simple Syndication</source>
        <translation>Really Simple Syndication</translation>
    </message>
    <message>
        <source>New RSS Export</source>
        <translation>Нов RSS експорт</translation>
    </message>
    <message>
        <source>New RSS Import</source>
        <translation>Нов RSS импорт</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Резултати от търсене</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Редактирай секция</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Секции</translation>
    </message>
    <message>
        <source>View section</source>
        <translation>Виж секция</translation>
    </message>
    <message>
        <source>New section</source>
        <translation>Нова секция</translation>
    </message>
</context>
<context>
    <name>kernel/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Админ за кеш</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Системна информация</translation>
    </message>
    <message>
        <source>Rapid Application Development</source>
        <translation>Бързо развитие на приложение</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Помощник за оператор на шаблон</translation>
    </message>
    <message>
        <source>Extension configuration</source>
        <translation>Разширена конфигурация </translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Меню за настройки</translation>
    </message>
    <message>
        <source>System Upgrade</source>
        <translation>Системно обновяване</translation>
    </message>
    <message>
        <source>Session admin</source>
        <translation>Сесия на администратор</translation>
    </message>
    <message>
        <source>File %1 does not exist. You should copy it from the recent eZ Publish distribution.</source>
        <translation>Файл %1 не съществува. Трябва да го копирате от сегашното разпространение на eZ Publish.</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Помощник за тип данни</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Кошница</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Проверка</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Потвърди поръчка</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Група с отстъпка</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>Изглед на групата по правило за отстъпка</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Редактирано правило</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Списък с поръчки</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Въведи информация за акaунт</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Типове ДДС</translation>
    </message>
    <message>
        <source>Customer list</source>
        <translation>Списък с клиенти</translation>
    </message>
    <message>
        <source>Remove order</source>
        <translation>Премахни поръчка</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Статистики</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Тип ДДС</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Класове</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Всеки клас</translation>
    </message>
    <message>
        <source>in sections</source>
        <translation>в секции</translation>
    </message>
    <message>
        <source>in any section</source>
        <translation>Във всяка секция</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Продукти</translation>
    </message>
    <message>
        <source>Any product</source>
        <translation>Всеки продукт</translation>
    </message>
    <message>
        <source>Order status</source>
        <translation>Статус на поръчката</translation>
    </message>
    <message>
        <source>Undefined</source>
        <translation>Неопределен</translation>
    </message>
    <message>
        <source>The confirm order operation was canceled. Try to checkout again.</source>
        <translation>Потвърждението на поръчката беше отменено. Опитайте проверката отново.</translation>
    </message>
    <message>
        <source>Order #%order_id</source>
        <translation>Поръчка #%order_id</translation>
    </message>
    <message>
        <source>New order status was successfully added.</source>
        <translation>Новия статус на поръчката беше добавен успешно.</translation>
    </message>
    <message>
        <source>Changes to order status were successfully stored.</source>
        <translation>Промените в статус на поръчката бяха успешно съхранени.</translation>
    </message>
    <message>
        <source>Selected order statuses were successfully removed.</source>
        <translation>Избраните статуси на поръчката бяха успешно премахнати.</translation>
    </message>
    <message>
        <source>Internal orders cannot be removed.</source>
        <translation>Вътрешните поръчки не могат да бъдат премахнати.</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Customer order view</source>
        <translation>Изглед на клиентска поръчка</translation>
    </message>
</context>
<context>
    <name>kernel/shop/discountgroup</name>
    <message>
        <source>New discount group</source>
        <translation>Нова група с отстъпка</translation>
    </message>
    <message>
        <source>New Discount Rule</source>
        <translation>Нова правило за отстъпка</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Тригер</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Списък</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>Уеб адрес</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Списък</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
    <message>
        <source>URL edit</source>
        <translation>Редакция на уеб адрес</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Потребител</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Промени парола</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Забравена парола</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Профил на потребителя</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Информация за регистрацията</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Нов регистриран потребител</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Редактирай работен поток</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Работен поток</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Редактирай групата за работен поток</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Редактиране на група</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Списък на група с работен поток</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Списък на група</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Списък на работен поток</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Списък с работен поток на група</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Списък</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
    <message>
        <source>You have to have at least one group that the workflow belongs to!</source>
        <translation>Вие трябва да имате поне една група, на която работният поток принадлежи!</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/edit</name>
    <message>
        <source>New Workflow</source>
        <translation>Нов работен поток</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Event</source>
        <translation>Събитие</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Одобри</translation>
    </message>
    <message>
        <source>Multiplexer</source>
        <translation>Множител</translation>
    </message>
    <message>
        <source>Simple shipping</source>
        <translation>Лесно изпращане на стоки</translation>
    </message>
    <message>
        <source>Wait until date</source>
        <translation>Чакай до дата</translation>
    </message>
    <message>
        <source>Payment Gateway</source>
        <translation>Вход за плащане</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/group</name>
    <message>
        <source>Group</source>
        <translation>Група</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/groupedit</name>
    <message>
        <source>New WorkflowGroup</source>
        <translation>Нова група за работен поток</translation>
    </message>
</context>
<context>
    <name>lib/ezpdf/classes</name>
    <message>
        <source>Contents</source>
        <comment>Table of contents</comment>
        <translation>Съдържания

Таблица със съдържания</translation>
    </message>
    <message>
        <source>Index</source>
        <comment>Keyword index name</comment>
        <translation>Индекс

Име на индекс на ключова дума</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Възникнаха някои грешки в шаблона, разгледайте debug за повече информация.</translation>
    </message>
</context>
<context>
    <name>lib/template</name>
    <message>
        <source>The maximum nesting level of 40 has been reached. The execution is stopped to avoid infinite recursion.</source>
        <translation>Максималното ниво 40 беше достигнато. Извършването е спряно,за да се предоврати безкрайна рекурсия.
</translation>
    </message>
</context>
<context>
    <name>pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>Експорт в PDF</translation>
    </message>
</context>
<context>
    <name>settings/edit</name>
    <message>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
</context>
<context>
    <name>settings/view</name>
    <message>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Виж</translation>
    </message>
</context>
<context>
    <name>shop</name>
    <message>
        <source>Remove orders</source>
        <translation>Премахни поръчките</translation>
    </message>
</context>
<context>
    <name>simplified_treemenu/show_simplified_menu</name>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>Възел ID: %node_id Visibility: %visibility</translation>
    </message>
</context>
</TS>
