<?php /* #?ini charset="iso-8859-1"?

[CustomTagSettings]
AvailableCustomTags[]=googledoc
IsInline[googledoc]=true

[googledoc]
CustomAttributes[]=doc_url
CustomAttributes[]=demo_minimal_embebed
CustomAttributes[]=width
CustomAttributes[]=height
CustomAttributesDefaults[doc_url]= Ej:https://docs.google.com/spreadsheet/ccc?key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
CustomAttributesDefaults[width]=955
CustomAttributesDefaults[height]=700



*/ ?>
