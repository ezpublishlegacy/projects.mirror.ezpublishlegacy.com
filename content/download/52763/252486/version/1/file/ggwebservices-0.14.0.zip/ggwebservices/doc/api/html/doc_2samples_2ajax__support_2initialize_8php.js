var doc_2samples_2ajax__support_2initialize_8php =
[
    [ "notification_addtonotification", "doc_2samples_2ajax__support_2initialize_8php.html#a9d87040d57ab5861f4aecd3388594cc6", null ]
];