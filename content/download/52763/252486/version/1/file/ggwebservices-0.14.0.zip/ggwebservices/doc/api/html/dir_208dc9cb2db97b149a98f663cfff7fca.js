var dir_208dc9cb2db97b149a98f663cfff7fca =
[
    [ "wsproviders.ini.append.php", "template__client_2wsproviders_8ini_8append_8php.html", null ]
];