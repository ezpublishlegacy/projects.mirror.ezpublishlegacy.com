var dir_b02e4219757ae4e3a0f1714873865bbf =
[
    [ "ggezjscoreclient.php", "ggezjscoreclient_8php.html", [
      [ "ggeZJSCoreClient", "classggeZJSCoreClient.html", "classggeZJSCoreClient" ]
    ] ],
    [ "ggezjscorerequest.php", "ggezjscorerequest_8php.html", [
      [ "ggeZJSCoreRequest", "classggeZJSCoreRequest.html", "classggeZJSCoreRequest" ]
    ] ],
    [ "ggezjscoreresponse.php", "ggezjscoreresponse_8php.html", [
      [ "ggeZJSCoreResponse", "classggeZJSCoreResponse.html", "classggeZJSCoreResponse" ]
    ] ],
    [ "ggezwebservices.php", "ggezwebservices_8php.html", [
      [ "ggeZWebservices", "classggeZWebservices.html", "classggeZWebservices" ]
    ] ],
    [ "ggezwebservicesclient.php", "ggezwebservicesclient_8php.html", [
      [ "ggeZWebservicesClient", "classggeZWebservicesClient.html", "classggeZWebservicesClient" ]
    ] ],
    [ "ggezwebservicesresponse.php", "ggezwebservicesresponse_8php.html", [
      [ "ggeZWebservicesResponse", "classggeZWebservicesResponse.html", "classggeZWebservicesResponse" ]
    ] ],
    [ "gghttpclient.php", "gghttpclient_8php.html", [
      [ "ggHTTPClient", "classggHTTPClient.html", "classggHTTPClient" ]
    ] ],
    [ "gghttprequest.php", "gghttprequest_8php.html", [
      [ "ggHTTPRequest", "classggHTTPRequest.html", "classggHTTPRequest" ]
    ] ],
    [ "gghttpresponse.php", "gghttpresponse_8php.html", [
      [ "ggHTTPResponse", "classggHTTPResponse.html", "classggHTTPResponse" ]
    ] ],
    [ "ggjsonrpcclient.php", "ggjsonrpcclient_8php.html", [
      [ "ggJSONRPCClient", "classggJSONRPCClient.html", "classggJSONRPCClient" ]
    ] ],
    [ "ggjsonrpcrequest.php", "ggjsonrpcrequest_8php.html", [
      [ "ggJSONRPCRequest", "classggJSONRPCRequest.html", "classggJSONRPCRequest" ]
    ] ],
    [ "ggjsonrpcresponse.php", "ggjsonrpcresponse_8php.html", [
      [ "ggJSONRPCResponse", "classggJSONRPCResponse.html", "classggJSONRPCResponse" ]
    ] ],
    [ "ggjsonrpcserver.php", "ggjsonrpcserver_8php.html", [
      [ "ggJSONRPCServer", "classggJSONRPCServer.html", "classggJSONRPCServer" ]
    ] ],
    [ "ggphpsoapclient.php", "ggphpsoapclient_8php.html", [
      [ "ggPhpSOAPClient", "classggPhpSOAPClient.html", "classggPhpSOAPClient" ]
    ] ],
    [ "ggphpsoapclienttransport.php", "ggphpsoapclienttransport_8php.html", [
      [ "ggPhpSOAPClientTransport", "classggPhpSOAPClientTransport.html", "classggPhpSOAPClientTransport" ]
    ] ],
    [ "ggphpsoaprequest.php", "ggphpsoaprequest_8php.html", [
      [ "ggPhpSOAPRequest", "classggPhpSOAPRequest.html", "classggPhpSOAPRequest" ]
    ] ],
    [ "ggphpsoapresponse.php", "ggphpsoapresponse_8php.html", [
      [ "ggPhpSOAPResponse", "classggPhpSOAPResponse.html", "classggPhpSOAPResponse" ]
    ] ],
    [ "ggphpsoapserver.php", "ggphpsoapserver_8php.html", [
      [ "ggPhpSOAPServer", "classggPhpSOAPServer.html", "classggPhpSOAPServer" ]
    ] ],
    [ "ggrestclient.php", "ggrestclient_8php.html", [
      [ "ggRESTClient", "classggRESTClient.html", "classggRESTClient" ]
    ] ],
    [ "ggrestrequest.php", "ggrestrequest_8php.html", [
      [ "ggRESTRequest", "classggRESTRequest.html", "classggRESTRequest" ]
    ] ],
    [ "ggrestresponse.php", "ggrestresponse_8php.html", [
      [ "ggRESTResponse", "classggRESTResponse.html", "classggRESTResponse" ]
    ] ],
    [ "ggrestserver.php", "ggrestserver_8php.html", [
      [ "ggRESTServer", "classggRESTServer.html", "classggRESTServer" ]
    ] ],
    [ "ggsimpletemplatexml.php", "ggsimpletemplatexml_8php.html", [
      [ "ggSimpleTemplateXML", "classggSimpleTemplateXML.html", "classggSimpleTemplateXML" ]
    ] ],
    [ "ggsoapclient.php", "ggsoapclient_8php.html", [
      [ "ggSOAPClient", "classggSOAPClient.html", "classggSOAPClient" ]
    ] ],
    [ "ggsoaprequest.php", "ggsoaprequest_8php.html", [
      [ "ggSOAPRequest", "classggSOAPRequest.html", "classggSOAPRequest" ]
    ] ],
    [ "ggsoapresponse.php", "ggsoapresponse_8php.html", [
      [ "ggSOAPResponse", "classggSOAPResponse.html", "classggSOAPResponse" ]
    ] ],
    [ "ggwebservicesclient.php", "ggwebservicesclient_8php.html", [
      [ "ggWebservicesClient", "classggWebservicesClient.html", "classggWebservicesClient" ]
    ] ],
    [ "ggwebservicesfault.php", "ggwebservicesfault_8php.html", [
      [ "ggWebservicesFault", "classggWebservicesFault.html", "classggWebservicesFault" ]
    ] ],
    [ "ggwebservicesjscfunctions.php", "ggwebservicesjscfunctions_8php.html", [
      [ "ggwebservicesJSCFunctions", "classggwebservicesJSCFunctions.html", "classggwebservicesJSCFunctions" ]
    ] ],
    [ "ggwebservicesrequest.php", "ggwebservicesrequest_8php.html", [
      [ "ggWebservicesRequest", "classggWebservicesRequest.html", "classggWebservicesRequest" ]
    ] ],
    [ "ggwebservicesresponse.php", "ggwebservicesresponse_8php.html", [
      [ "ggWebservicesResponse", "classggWebservicesResponse.html", "classggWebservicesResponse" ]
    ] ],
    [ "ggwebservicesserver.php", "ggwebservicesserver_8php.html", [
      [ "ggWebservicesServer", "classggWebservicesServer.html", "classggWebservicesServer" ]
    ] ],
    [ "ggwsdlparser.php", "ggwsdlparser_8php.html", [
      [ "ggWSDLParser", "classggWSDLParser.html", "classggWSDLParser" ]
    ] ],
    [ "ggxmlrpcclient.php", "ggxmlrpcclient_8php.html", [
      [ "ggXMLRPCClient", "classggXMLRPCClient.html", "classggXMLRPCClient" ]
    ] ],
    [ "ggxmlrpcrequest.php", "ggxmlrpcrequest_8php.html", [
      [ "ggXMLRPCRequest", "classggXMLRPCRequest.html", "classggXMLRPCRequest" ]
    ] ],
    [ "ggxmlrpcresponse.php", "ggxmlrpcresponse_8php.html", [
      [ "ggXMLRPCResponse", "classggXMLRPCResponse.html", "classggXMLRPCResponse" ]
    ] ],
    [ "ggxmlrpcserver.php", "ggxmlrpcserver_8php.html", [
      [ "ggXMLRPCServer", "classggXMLRPCServer.html", "classggXMLRPCServer" ]
    ] ]
];