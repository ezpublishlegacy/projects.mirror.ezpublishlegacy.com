var classggHTTPResponse =
[
    [ "decodeStream", "classggHTTPResponse.html#a0061cda1c26bb49d30c8775f43a080f8", null ],
    [ "payload", "classggHTTPResponse.html#aeda1956f3e02646abd3b7a63dbaf970d", null ]
];