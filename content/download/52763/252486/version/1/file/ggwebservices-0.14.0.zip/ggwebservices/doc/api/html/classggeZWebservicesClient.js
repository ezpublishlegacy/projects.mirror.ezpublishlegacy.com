var classggeZWebservicesClient =
[
    [ "_call", "classggeZWebservicesClient.html#aa520897e7b8551259a75cf2e970d696d", null ],
    [ "call", "classggeZWebservicesClient.html#a3caea1c92158903b5fddb653511595eb", null ],
    [ "send", "classggeZWebservicesClient.html#a11e28c9945207209886a51bbc5210e45", null ]
];