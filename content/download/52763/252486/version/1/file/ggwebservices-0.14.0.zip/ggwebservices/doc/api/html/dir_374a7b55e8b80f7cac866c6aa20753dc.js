var dir_374a7b55e8b80f7cac866c6aa20753dc =
[
    [ "initialize.php", "doc_2samples_2ajax__support_2initialize_8php.html", "doc_2samples_2ajax__support_2initialize_8php" ]
];