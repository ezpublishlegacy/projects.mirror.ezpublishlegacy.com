var dir_59425e443f801f1f2fd8bbe4959a3ccf =
[
    [ "initialize_soapinterop.php", "initialize__soapinterop_8php.html", "initialize__soapinterop_8php" ],
    [ "suite.php", "suite_8php.html", [
      [ "ggwebservicesTestSuite", "classggwebservicesTestSuite.html", "classggwebservicesTestSuite" ]
    ] ]
];