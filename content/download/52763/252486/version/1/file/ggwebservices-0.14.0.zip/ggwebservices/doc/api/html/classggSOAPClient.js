var classggSOAPClient =
[
    [ "availableOptions", "classggSOAPClient.html#a4d53dd62b28dc851b4b11f98c68cb112", null ],
    [ "getOption", "classggSOAPClient.html#a63a52e50ee587daee9f13544deb52e12", null ],
    [ "send", "classggSOAPClient.html#a8c4b1eccd8a97b75d0ac5de84810c4b6", null ],
    [ "setOption", "classggSOAPClient.html#a9aea7c97a930f09c7cdd59026d14e731", null ],
    [ "setSoapVersion", "classggSOAPClient.html#ae43842635751d77cd8ee33b3ec2ddb90", null ],
    [ "$ResponseClass", "classggSOAPClient.html#aab808b94e15af660dd23865d31847e7e", null ],
    [ "$SoapVersion", "classggSOAPClient.html#a1cf5dfac8dd0d6f773b7c8f6a2c46aec", null ],
    [ "$UserAgent", "classggSOAPClient.html#a732d2d00a196bd1006ca59bf78835743", null ]
];