var classjsonrpcval =
[
    [ "serialize", "classjsonrpcval.html#aad2c715d20362d740133fc12d7bdd023", null ]
];