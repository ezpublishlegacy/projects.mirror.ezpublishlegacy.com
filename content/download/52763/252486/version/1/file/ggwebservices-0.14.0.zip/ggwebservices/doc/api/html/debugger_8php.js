var debugger_8php =
[
    [ "$patchtarget", "debugger_8php.html#aa3680c010422d93d56b2980fd5442f4f", null ],
    [ "$target", "debugger_8php.html#a97f00a3eb3f2c3198313323c8df7dcb2", null ],
    [ "if", "debugger_8php.html#a3373908e87acac6c2cef3dbda793ede1", null ]
];