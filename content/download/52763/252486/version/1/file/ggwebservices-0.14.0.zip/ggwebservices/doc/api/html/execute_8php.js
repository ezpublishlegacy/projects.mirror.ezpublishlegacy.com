var execute_8php =
[
    [ "$access", "execute_8php.html#ad7fd03ae69de40b00cc4758c23a4404e", null ],
    [ "$data", "execute_8php.html#a6efc15b5a2314dd4b5aaa556a375c6d6", null ],
    [ "$module", "execute_8php.html#ac531301c55a8d8b6c7613597218ff482", null ],
    [ "$namespaceURI", "execute_8php.html#a89994ba3ed9d40e2015b2264a7bb143c", null ],
    [ "$params", "execute_8php.html#afe68e6fbe7acfbffc0af0c84a1996466", null ],
    [ "$protocol", "execute_8php.html#ac01bf1cf041487498864d054b991f570", null ],
    [ "$request", "execute_8php.html#ad5bbfbc58529f6f538680855afbc438c", null ],
    [ "$server", "execute_8php.html#ad135cc8a47e55f0829949cf62214170f", null ],
    [ "$serverClass", "execute_8php.html#a6d8046a1467cd1dd3c9c18c8e1db26a2", null ],
    [ "$user", "execute_8php.html#a557c1cf098fe5b5c51772838f477931b", null ],
    [ "$wsclass", "execute_8php.html#a47590aba854d7817d72fcfea28b66474", null ],
    [ "$wsINI", "execute_8php.html#a2912be75e017af6e3a34d5a29df425a2", null ],
    [ "else", "execute_8php.html#a3bf3480c3b0fae9566f9458aaeb22286", null ]
];