var classggWebservicesRequest =
[
    [ "__construct", "classggWebservicesRequest.html#a8ee4d1bab9524b76945de32acd396492", null ],
    [ "addParameter", "classggWebservicesRequest.html#af931d084c7fab77b61fc765f3c86a691", null ],
    [ "addParameters", "classggWebservicesRequest.html#ab7e4c2fdd5a4d451b8710ed2392b2b67", null ],
    [ "contentType", "classggWebservicesRequest.html#aac2d6c4ee1cac83bccad4f21e875c296", null ],
    [ "decodeStream", "classggWebservicesRequest.html#aaab05f0bcbeda82dd155bd9156a969c6", null ],
    [ "method", "classggWebservicesRequest.html#aaf70ad48364fe2a61434ac349df41cfa", null ],
    [ "name", "classggWebservicesRequest.html#a9418893a04ef544cb6f294807d47cb3b", null ],
    [ "parameters", "classggWebservicesRequest.html#afe5183e062bfd5e646efafe38386e99b", null ],
    [ "payload", "classggWebservicesRequest.html#ad948d6987d9598468f53589847029831", null ],
    [ "requestHeaders", "classggWebservicesRequest.html#a618978f82c05e19ca6384b3d70b79023", null ],
    [ "requestURI", "classggWebservicesRequest.html#ad9b286d6e8d4bac972262fc17752f44b", null ],
    [ "$ContentType", "classggWebservicesRequest.html#a20dab1e9087e1febc1b32296ae6ae469", null ],
    [ "$Name", "classggWebservicesRequest.html#adb573d7715f27bbe28c80d9b9a7154f8", null ],
    [ "$Parameters", "classggWebservicesRequest.html#a5f7c94b9788405f569d40aa84badd084", null ],
    [ "$Verb", "classggWebservicesRequest.html#ae986541cdf0e90ef7ef61d62950bfd49", null ]
];