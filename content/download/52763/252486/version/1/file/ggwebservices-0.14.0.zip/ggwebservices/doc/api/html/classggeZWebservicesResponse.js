var classggeZWebservicesResponse =
[
    [ "__construct", "classggeZWebservicesResponse.html#a301a20885d473799d3ac2f0d742550b0", null ],
    [ "attribute", "classggeZWebservicesResponse.html#a638e74117686ff9dcf5fe843e4fe80a6", null ],
    [ "attributes", "classggeZWebservicesResponse.html#a9b5ea7a47dcd36615ae0b46d16377c23", null ],
    [ "hasattribute", "classggeZWebservicesResponse.html#ac170086d563237fecea242804088aa18", null ],
    [ "$attrs", "classggeZWebservicesResponse.html#a004e0e33e24650dabb04fa3ab38ddf5e", null ],
    [ "$resp", "classggeZWebservicesResponse.html#a051f72ef162a2d043cb28d4d565c41fc", null ]
];