<?php /*

[ExtensionSettings]
DesignExtensions[]=ezwebsitetoolbar

*/ ?>