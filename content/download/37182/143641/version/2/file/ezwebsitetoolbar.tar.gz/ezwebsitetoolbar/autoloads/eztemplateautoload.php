<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezwebsitetoolbar/autoloads/ezcreateclasslistgroups.php',
                                    'class' => 'eZCreateClassListGroups',
                                    'operator_names' => array( 'ezcreateclasslistgroups' ) );

?>