<?php

eZExecution::cleanExit();

?>