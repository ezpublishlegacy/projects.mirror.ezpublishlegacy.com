<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezwebsitetoolbar

*/ ?>