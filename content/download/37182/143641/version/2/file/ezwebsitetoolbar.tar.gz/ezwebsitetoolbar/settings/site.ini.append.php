<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezwebsitetoolbar

*/ ?>