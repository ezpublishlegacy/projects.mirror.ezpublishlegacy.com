var classggeZJSCoreResponse =
[
    [ "decodeStream", "classggeZJSCoreResponse.html#ad4eea49ee1c36577fc99858f7986d0d2", null ],
    [ "payload", "classggeZJSCoreResponse.html#a6b6e7999174aa06c05c55044afa25513", null ],
    [ "$ContentType", "classggeZJSCoreResponse.html#aff7ffb0e13320bcf6403a6186da9c335", null ]
];