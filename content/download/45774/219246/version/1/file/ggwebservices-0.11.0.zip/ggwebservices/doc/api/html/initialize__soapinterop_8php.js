var initialize__soapinterop_8php =
[
    [ "echoBase64", "initialize__soapinterop_8php.html#a514c7234b6d7754dc3e2278508e74ad0", null ],
    [ "echoDate", "initialize__soapinterop_8php.html#a86a87557a74c84da4c42d0a4b729b6ee", null ],
    [ "echoFloat", "initialize__soapinterop_8php.html#a1625343611582a08b55d2a97c15cb9fc", null ],
    [ "echoFloatArray", "initialize__soapinterop_8php.html#a7ad269b3cf50e171b9e4608b33a3b4ed", null ],
    [ "echoInteger", "initialize__soapinterop_8php.html#ace7ca7e9fa569e9b08833199ac1c039c", null ],
    [ "echoIntegerArray", "initialize__soapinterop_8php.html#ade172b1425705a1b438de6f27b54d9c9", null ],
    [ "echoString", "initialize__soapinterop_8php.html#a7c83d836f35fa8dc7fc99c731eccb980", null ],
    [ "echoStringArray", "initialize__soapinterop_8php.html#a39b999b3fcc049f9e31d93149da54c4e", null ],
    [ "echoStruct", "initialize__soapinterop_8php.html#a50cc3bbabcfd998008cf6af4b3b2dfd3", null ],
    [ "echoStructArray", "initialize__soapinterop_8php.html#a6ff16bef30ae8a9403aaf8696a37ed38", null ],
    [ "echoVoid", "initialize__soapinterop_8php.html#aba37953f17b00163077b04d502858381", null ]
];