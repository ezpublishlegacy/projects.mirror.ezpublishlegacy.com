<?php
/**
 * Class used to wrap soap responses. Modeled after the eZ Soap equivalent.
 *
 * @author G. Giunta
 * @version $Id: ggphpsoapresponse.php 419 2012-01-11 08:28:42Z gg $
 * @copyright (C) 2009-2012 G. Giunta
 */

class ggPhpSOAPResponse extends ggWebservicesResponse
{

    /// the use done of this function is a bit warped, ie. it does not conform
    /// to parent's class usage. @see ggPhpSOAPClient::_send()
    function payload( )
    {
        return $this->Value;
    }

    /// the use done of this function is a bit warped, ie. it does not conform
    /// to parent's class usage. @see ggPhpSOAPClient::_send()
    function decodeStream( $request, $stream, $headers=false, $cookies=array(), $statuscode="200" )
    {
        /// @todo verify if this makes sense
        $this->Cookies = $cookies;
        $this->StatusCode = $statuscode;

        $this->Value = $stream;
    }
}

?>