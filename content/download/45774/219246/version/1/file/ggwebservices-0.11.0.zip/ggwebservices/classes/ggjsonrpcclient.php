<?php
/**
 * Class used to communicate with jsonrpc servers
 * @deprecated use a plain ggWebservicesClient instead of this
 *
 * @author G. Giunta
 * @version $Id: ggjsonrpcclient.php 419 2012-01-11 08:28:42Z gg $
 * @copyright (C) 2009-2012 G. Giunta
 */

class ggJSONRPCClient extends ggWebservicesClient
{
    function __construct( $server, $path = '/', $port = 80, $protocol=null )
    {
        $this->ResponseClass = 'ggJSONRPCResponse';
        $this->UserAgent = 'gg eZ JSONRPC client';
        $this->ContentType = 'application/json';
        parent::__construct( $server, $path, $port, $protocol );
    }
}

?>