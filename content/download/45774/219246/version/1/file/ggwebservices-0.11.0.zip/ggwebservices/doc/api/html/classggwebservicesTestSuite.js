var classggwebservicesTestSuite =
[
    [ "__construct", "classggwebservicesTestSuite.html#ae1f01b5de98de19e83344790b0baec3e", null ],
    [ "suite", "classggwebservicesTestSuite.html#acf05147ad57c75e171f3987b6a4096bd", null ]
];