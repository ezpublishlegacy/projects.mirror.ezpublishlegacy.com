var rotatewslogs_8php =
[
    [ "$fileName", "rotatewslogs_8php.html#a68fbc5a9273a24181c50a057d11603fa", null ],
    [ "$ini", "rotatewslogs_8php.html#a8f5f30fbe4092bf20ba2fcae8197ab09", null ],
    [ "$logDir", "rotatewslogs_8php.html#a069da7851cabee054935efdfaca3926f", null ],
    [ "$logName", "rotatewslogs_8php.html#af612b26facb9f42bf4350dd9fdc9125e", null ],
    [ "$maxFileSize", "rotatewslogs_8php.html#a780508f3eed8cbf1268b3717f4581c1b", null ],
    [ "$varDir", "rotatewslogs_8php.html#a7f1184a0396fcf4d328597543bb267f9", null ]
];