var dir_def60a9abbdd46efd9b3bc5861151a16 =
[
    [ "flickr_client", "dir_582573f39336d348ad8a216c22f525ad.html", null ],
    [ "lastfm_client", "dir_14815dc3fa7380c32fe563e421747a7f.html", null ],
    [ "soap_server", "dir_fd6c18c8ed87061440b98c1de40d6e96.html", null ],
    [ "solr_client", "dir_b7542a5e392aa0f03595d7c06ff5194e.html", null ],
    [ "template_client", "dir_747768a72b2e2a8a2cf543457e567aaf.html", null ],
    [ "twitter_client", "dir_2d398fc79e662ffa175b6a19b387c9e7.html", null ],
    [ "yql_client", "dir_bc8a96071729b76135cbb9abadc33abf.html", null ]
];