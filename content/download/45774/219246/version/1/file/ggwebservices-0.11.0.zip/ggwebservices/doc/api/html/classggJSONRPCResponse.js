var classggJSONRPCResponse =
[
    [ "decodeStream", "classggJSONRPCResponse.html#a7adf1222164cb86b0ecbb980635e5567", null ],
    [ "payload", "classggJSONRPCResponse.html#a9051d1f4106ab87fc7e0f9a3ee862267", null ],
    [ "setId", "classggJSONRPCResponse.html#a5c516edaf7a59bbcced56305fa22cc4d", null ],
    [ "$ContentType", "classggJSONRPCResponse.html#a82b573a0fb0289039ca6df99dde778c0", null ],
    [ "$Id", "classggJSONRPCResponse.html#a414cfabf6ffc8c1cd3c12721c97a8c51", null ],
    [ "INVALIDIDERROR", "classggJSONRPCResponse.html#a933bd86409f6d1db67ffb4989bef6a0e", null ],
    [ "INVALIDIDSTRING", "classggJSONRPCResponse.html#a7043b1a0a095b0dd63f039de3c5dc97a", null ],
    [ "INVALIDRESPONSESTRING", "classggJSONRPCResponse.html#a12f5817154b0865f11b91ad42c233a81", null ]
];