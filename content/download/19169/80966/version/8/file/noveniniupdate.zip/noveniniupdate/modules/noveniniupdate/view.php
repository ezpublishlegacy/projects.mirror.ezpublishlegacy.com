<?php

//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: Noven INI Update
// SOFTWARE RELEASE: 2.0
// COPYRIGHT NOTICE: Copyright (C) 2009 - Jean-Luc Nguyen, Jerome Vieilledent - Noven.
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

include_once( "kernel/common/template.php" );

$Module = $Params["Module"];
$Result = array();
$tpl = templateInit();
$http = eZHTTPTool::instance();
$errors = array();

try
{
	$iniUpdater = new NovenINIUpdater();
	$clusterUpdater = new NovenClusterUpdater();
	$envs = $iniUpdater->getEnvs();

	$environments = array();
	foreach ( $envs as $env )
	{
		$environments[(string)$env['name']] = (string)$env['comment'];
	}
	$tpl->setVariable( 'envs', $environments );

	// Selected environment
	if ( $http->hasPostVariable( "selectedEnvironment" ) )
	{
		$selectedEnvironment = $http->postVariable( "selectedEnvironment" );
		$tpl->setVariable( 'selected_env', $selectedEnvironment );

		// Find variables by environment
		$tabs = $iniUpdater->getParamsByEnv($selectedEnvironment);
		$clusterParams = $clusterUpdater->getParamsByEnv($selectedEnvironment);
		$tpl->setVariable( 'tabs', $tabs );
		$tpl->setVariable( 'cluster_params', $clusterParams );
	}

	// Update current environment with XML content
	if ( $Module->isCurrentAction( 'UpdateEnvButton' ) )
	{
		if ( $http->hasPostVariable( "selectedEnvironment" ) )
		{
			$selectedEnvironment = $http->postVariable( "selectedEnvironment" );
			$iniUpdater->setEnv($selectedEnvironment);
			$clusterUpdater->setEnv($selectedEnvironment);
			$Module->redirectTo( '/noveniniupdate/view/(update)/1' );
		}
	}

	if ( isset( $Params['Update'] ) && $Params['Update'] == 1 )
	{
		$tpl->setVariable( 'confirm_label', ezi18n( 'extension/noveniniupdate/view', 'The INI parameter(s) have been updated for the selected environment' ) );
	}
	
}
catch(NovenConfigUpdaterException $e)
{
	$errMsg = (string)$e;
	eZLog::write($errMsg, 'noveniniupdate-error.log');
	eZDebug::writeError($errMsg, "NovenINIUpdate");
	$tpl->setVariable( 'error_message', $errMsg );
}

$Result['path'] = array(
	array(
		'url'		=> false,
		'text'		=> ezi18n( 'extension/noveniniupdate', 'Noven advanced INI parameters' )
	)
);
$Result['content'] = $tpl->fetch( "design:noveniniupdate/view.tpl" );

