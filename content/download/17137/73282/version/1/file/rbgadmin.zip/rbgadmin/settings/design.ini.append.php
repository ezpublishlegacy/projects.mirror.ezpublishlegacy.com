<?php /*
       
[ExtensionSettings]
DesignExtensions[]=rbgadmin

 
*/ ?>