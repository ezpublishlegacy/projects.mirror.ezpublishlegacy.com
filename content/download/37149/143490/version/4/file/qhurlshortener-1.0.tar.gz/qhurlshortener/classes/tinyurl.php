<?php

class tinyurl{

	private $results;

	public function tinyurl()
	{
	}
	
	public function getRawResults()
	{
		return $this->results;
	}

	public function shorten($url)
	{
		$ch = curl_init();
                $timeout = 5;
                curl_setopt($ch, CURLOPT_URL,'http://tinyurl.com/api-create.php?url='.urlencode($url));
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                $shortURL = curl_exec($ch);
                curl_close($ch);

		return $shortURL;
	}	

}
