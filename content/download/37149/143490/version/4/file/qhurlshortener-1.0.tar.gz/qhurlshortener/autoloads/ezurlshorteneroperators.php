<?php

class eZURLShortenerOperators {
   var $Operators;
   
   function __construct()
   {
       $this->Operators = array( 'bitlyed', 'tinyurled' );
   }

   function &operatorList()
   {
       return $this->Operators;
   }

   function namedParameterPerOperator()
   {
       return true;
   }

   function namedParameterList()
   {
       return array( 'bitlyed' => array( 'url' => array( 'type' => 'string',
    							 'require' => true,
							 'default' => false )
					),
    		     'tinyurled' => array ( 'url' => array ( 'type' => 'string',
		    					     'require' => true,
							     'default' => false )
					),
                    );
   }

   function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace,
                    &$currentNamespace, &$operatorValue, &$namedParameters )
   {
       $ini = eZINI::instance( "qhurlshortener.ini" );
       $authDetails = array ( 'bitly' => array(
    					    'user' => $ini->variable( "BitLy", "User" ),
					    'apiKey' => $ini->variable( "BitLy", "Key" )
					    ),
			    );
       switch ( $operatorName )
       {
           case 'bitlyed':
           {
		$bitly = new bitly( $authDetails['bitly']['user'], $authDetails['bitly']['apiKey'] );
		$operatorValue = $bitly->shorten( $namedParameters['url'] );
           } break;
	   
	   case 'tinyurled':
	   {
		$tinyurl = new tinyurl();
		$operatorValue = $tinyurl->shorten( $namedParameters['url'] );
	   } break;
       }
   }
}
?>
