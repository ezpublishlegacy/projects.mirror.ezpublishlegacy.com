<?php
 
$Module = array( 'name' => 'QH URL shortener' ); 
$ViewList = array();

$ViewList['test'] = array( 'script' => 'test.php',
                           'functions' => array( 'read' ),
                          );
 
$FunctionList = array(); 
$FunctionList['read'] = array(); 
 
?>
