<?php
include_once ('kernel/common/template.php');

$http = eZHTTPTool::instance();
$tpl = templateInit();

$Result = array();
$Result['pagelayout']=false;

$url = "http://www.google.com/";

$ini = eZINI::instance( "qhurlshortener.ini" );
$authDetails = array ( 'bitly' => array(
                                     'user' => $ini->variable( "BitLy", "User" ),
                                     'apiKey' => $ini->variable( "BitLy", "Key" )
                                     ),
                     );

$bitly = new bitly( $authDetails['bitly']['user'], $authDetails['bitly']['apiKey'] );
$tinyurl = new tinyurl();

// Shortening in PHP
$tpl->setVariable('phpbitly', $bitly->shorten($url) );
$tpl->setVariable('phptinyurl', $tinyurl->shorten($url) );

// Setting URL variable for shortening in TPL
$tpl->setVariable('url', $url );

$Result['content'] = $tpl->fetch( 'design:qhurlshortener/test.tpl' );

?>
