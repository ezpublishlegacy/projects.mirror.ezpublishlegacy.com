<?php
// Operator autoloading
 
$eZTemplateOperatorArray = array();
 
$eZTemplateOperatorArray[] = array( 'script' => 'extension/qhurlshortener/autoloads/ezurlshorteneroperators.php',
        'class' => 'eZURLShortenerOperators',
        'operator_names' => array( 'bitlyed', 'tinyurled') );
 
?>