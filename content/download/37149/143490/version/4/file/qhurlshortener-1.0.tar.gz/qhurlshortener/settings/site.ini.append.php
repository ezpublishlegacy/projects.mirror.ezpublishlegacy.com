<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=qhurlshortener

[RoleSettings]
PolicyOmitList[]=urlshortener/test

*/ ?>
