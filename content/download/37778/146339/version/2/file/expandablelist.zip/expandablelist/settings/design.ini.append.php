<?php /* #?ini charset="utf8"?

[StylesheetSettings]
CSSFileList[]=expandablelist.css

[JavaScriptSettings]
JavaScriptList[]=expandable.js

[ExtensionSettings]
DesignExtensions[]=expandablelist
*/ ?>