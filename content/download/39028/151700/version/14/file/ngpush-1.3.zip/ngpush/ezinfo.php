<?php

class ngpushInfo
{
    static function info()
    {
        $eZCopyrightString = 'Copyright (C) 2010-2013 Netgen d.o.o.';

        return array( 'Name'      => '<a href="http://projects.ez.no/ngpush">Netgen Push</a> extension',
                      'Version'   => '1.3',
                      'Copyright' => $eZCopyrightString,
                      'License'   => 'GNU General Public License v2.0'
                    );
    }
}

?>
