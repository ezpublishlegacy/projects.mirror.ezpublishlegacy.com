<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ngpush

[RoleSettings]
PolicyOmitList[]=push/save_access_token

[Cache]
CacheItems[]=ngpush

[Cache_ngpush]
name=Netgen Push authorization cache
id=ngpush
path=ngpush

[RegionalSettings]
TranslationExtensions[]=ngpush
*/ ?>
