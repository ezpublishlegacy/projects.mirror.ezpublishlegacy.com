<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=ngpushthumb

[ngpushthumb]
Reference=
Filters[]
Filters[]=geometry/scaledownonly=128;128
*/ ?>
