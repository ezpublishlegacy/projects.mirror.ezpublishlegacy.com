<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ngpush/classes/templatengpush_xml_cleanoperator.php',
																		'class' => 'TemplateNgpush_xml_cleanOperator',
																		'operator_names' => array( 'ngpush_xml_clean' ) );

