<?php /* #?ini charset="utf-8"?

[CustomTemplateSettings]
CustomTemplateList[]=ngpush
IncludeInView[ngpush]=full
*/ ?>