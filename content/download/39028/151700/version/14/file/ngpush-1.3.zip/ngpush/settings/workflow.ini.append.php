<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=ngpush
AvailableEventTypes[]=event_ngpushredirect
*/ ?>
