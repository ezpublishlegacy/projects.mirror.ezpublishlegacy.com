<?php /*

[ExtensionSettings]
DesignExtensions[]=ezinformation

*/ ?>