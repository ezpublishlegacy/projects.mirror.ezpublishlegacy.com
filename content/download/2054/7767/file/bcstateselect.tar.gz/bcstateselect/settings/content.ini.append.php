<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=bcstateselect
AvailableDataTypes[]=bcstateselect

*/ ?>