<?php /*

[DeleteSettings]
ConfirmJavascript=enabled
DefaultMoveToTrash=enabled

[ListSettings]
# DefaultSortMethod should be one of the following values : 
#  - depth
#  - modified
#  - name
#  - path
#  - path_string
#  - priority
#  - published
#  - section
DefaultSortMethod=modified

# ascending or descending
DefaultSortOrder=descending

IncludeClasses[]
# Fill this array with class identifier to have only
# those class listed in the left menu
#IncludeClasses[]=folder
#IncludeClasses[]=image



*/ ?>
