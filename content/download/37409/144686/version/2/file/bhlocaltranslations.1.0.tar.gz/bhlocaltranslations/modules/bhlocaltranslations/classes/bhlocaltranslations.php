<?php
error_reporting(E_ALL);

/*

    bhLocalTranslations - Local translation management extension for eZ publish 3.5
    
    Copyright (C) 2005 Bodoni Hus

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA	
    
	Jo Havik / jo.havik@bodonihus.no
	
*/

/*! \defgroup bhLocalTranslation 

*/

include_once('lib/ezfile/classes/ezfile.php');
include_once('lib/ezfile/classes/ezfilehandler.php');
include_once('lib/ezfile/classes/ezdir.php');
include_once('kernel/classes/ezcontenttranslation.php' );

/*! \class  bhLocalTranslations
    \brief  Handles interaction between GUI and XML translation files
    \todo   Lots of code duplication should be fixed
    
*/  
class bhLocalTranslations{

	var $translation_extension='';
	var $translation_filename='';
	var $dirSeparator='';
	var $baseDir='';
	var $tsInfo=array(); // info about the various translations, including cache

	/*!
      Constructor, reads content from translation files, and checks if file structure is OK
    */
	function bhLocalTranslations(){
		$this->translation_filename='translation.ts';
		$this->translation_extension='ts';
	    $this->dirSeparator=ezDir::separator(EZ_DIR_SEPARATOR_UNIX); // EZ_DIR_SEPARATOR_LOCAL returns \ under windows XP...
		$this->baseDir=eZExtension::baseDirectory().$this->dirSeparator.'bhlocaltranslations_share'.$this->dirSeparator.'translations';
		$this->initialize();
		$this->checkSiteLocales();
	}
	
	/*!
	 load info about all translations
	 \todo   Catch invalid directory permissions and directory structures
	*/
	function initialize(){
		// find all translation files
		$tsDirs=array();		
		$tsDirs=ezDir::recursiveFind($this->baseDir,$this->translation_extension);
		// find metadata for each translation file
		for ($teller=0;$teller<count($tsDirs);$teller++){
			
			$data=array();
			$parts=explode($this->dirSeparator,$tsDirs[$teller]);
			$data['locale_code']=$parts[count($parts)-2];
			$data['filepath']=$tsDirs[$teller];
			$translation_source=ezFile::getContents($data['filepath']); 
			
			// find number of elements. Do not create XML tree - use quick & dirty preg_match_all
			
			$data['total']=preg_match_all('/\<message/',$translation_source,$dummy_matches);

			if ($data['locale_code']=='untranslated'){
				$data['international_name']='Source text';
				$data['country_name']='';
				$data['language_name']='';
				// all original strings are counted as finished...
				$data['unfinished']=0; 
				$data['finished']=$data['total'];
				
			}else{ // get full name for actual translations
			    
				$localeobject =& eZLocale::instance( $data['locale_code'] );
				$data['international_name']=$localeobject->internationalLanguageName();
				$data['country_name']=$localeobject->countryName();
				$data['language_name']=$localeobject->languageName();
				// find number of unfinished and finished elements. Do not create XML tree - use quick & dirty preg_match_all
				$data['unfinished']=preg_match_all('/\<translation.*?type="unfinished".*?\>/',$translation_source,$dummy_matches);
				$data['finished']=($data['total']-$data['unfinished']);
			}
			$this->tsInfo[$data['locale_code']]=$data;
			$this->setTranslationContent($data['locale_code'],$translation_source); // cache for later use
		}
	}
	
	/*!
	   walk all current site locales, create translation directories as neccessary
	   Does not delete directories if a translation is removed from the site
	   \todo   Catch invalid directory permissions
	*/
	function checkSiteLocales(){
		$this->addDefaultLocale();
		$translationList=&eZContentTranslation::fetchLocaleList();
		for ($counter=0;$counter<count($translationList);$counter++){
			//en-GB is base language, and is never translated...
			if ($translationList[$counter]!='eng-GB'){
				$this->addLocale($translationList[$counter]);
			}
		}	
	}
	
	/*!
	   adds a default untranslated.ts file
	   \todo   Catch invalid directory permissions
	*/
	function addDefaultLocale(){
		if (!$this->getInfo('untranslated')){
			$target_dir=$this->baseDir.$this->dirSeparator.'untranslated';
			
			$content='<!DOCTYPE TS>
<TS>
  <context>
    <name>local/default</name>
  </context>
</TS>';
			ezFile::create($this->translation_filename,$target_dir,$content);
			$this->initialize();
		}
	}
	
	/*!
	   add a single new translation by copying every file from the untranslated directory
	   won't add an already existing locale
	   \todo   If we are adding a lot of locales, the call to initialize is not to bright...
	*/
	function addLocale($locale_code){
		$locale_code=$this->sanitizeLocaleCode($locale_code);		
		$untranslated_info=$this->getInfo('untranslated');
		if ( (!$this->getInfo($locale_code)) && $untranslated_info ){
			$target_dir=$this->baseDir.$this->dirSeparator.$locale_code;
			ezFile::create($this->translation_filename,$target_dir,$this->getTranslationContent('untranslated'));
			$this->initialize();
		}
		
	}
	
	/*!
	removes an existing translation by deleting this translations directory
	will not remove the untranslated directory
	*/
	function removeLocale($locale_name){
		$locale_code=$this->sanitizeLocaleCode($locale_code);
		if (($locale_code != 'untranslated') && $this->getInfo($locale_code)){
			ezDir::recursiveDelete(ezDir::dirPath($locale_info['filepath']));
			$this->initialize();
		}else{
			eZDebug::writeWarning("Cannot delete translation $locale_code",'bhLocalTranslations:removeLocale');
		}
	}
	
	/*!
	return a locale code that safely can be used as a file- or pathname
	*/
	function sanitizeLocaleCode($locale_code){
		return preg_replace('/[^a-z\-]/i','',$locale_code);
	}
	
	/*!
	 return actual existing translations
	*/
	function getAvailableTranslations(){
		return array_keys($this->tsInfo);
	}
	
	/*!
	returns info about a locale
	*/
	function getInfo($locale_code){
		if (array_key_exists($locale_code,$this->tsInfo)){
			return $this->tsInfo[$locale_code];
		}else{
			return false;
		}
	}
	
	/*!
	returns information about all available translations
	*/
	function getAllInfo(){
		return $this->tsInfo;
	}
	
	/*!
	 sets the XML source for a language
	 \todo: Validate XML
	*/
	function setTranslationContent($locale_code,$content){
		if ($this->getInfo($locale_code)){
			$content=str_replace('<?xml version="1.0" encoding="UTF-8"?>','',$content);
			if (strpos($content,'<!DOCTYPE TS>')===false){
				$content='<!DOCTYPE TS>'.$content;
			}
			$this->tsInfo[$locale_code]['file_content']=$content;
			$this->tsInfo[$locale_code]['content_dirty']=true;
		}else{
			eZDebug::writeWarning( "Translation $locale_code not found", 'bhLocalTranslations::setTranslationContent' );
			return false;
		}
	}
	
	/*!
	   writes XML to disk
	*/
	function storeContent($locale_code){
		if ($this->getInfo($locale_code) && isset($this->tsInfo[$locale_code]['file_content']) && $this->tsInfo[$locale_code]['content_dirty']){
			ezFile::create($this->translation_filename,ezDir::dirpath($this->tsInfo[$locale_code]['filepath']),$this->tsInfo[$locale_code]['file_content']);
		}
	}
	
	/*!
	   returns translation as text or array
	*/
	function getTranslationContent($locale_code,$asText=true){
		
		if (array_key_exists($locale_code,$this->tsInfo)){
			if (!isset($this->tsInfo[$locale_code]['file_content'])){
				$this->tsInfo[$locale_code]['file_content']=ezFile::getContents($this->tsInfo[$locale_code]['filepath']); 
				$this->tsInfo[$locale_code]['content_dirty']=false;
			}
			if ($asText){
				return $this->tsInfo[$locale_code]['file_content'];
			}else{
				$content=array();
				
				// go through XML file, return array
				include_once( "lib/ezxml/classes/ezxml.php" );
				$xml = new eZXML();
            	$tree =& $xml->domTree( $this->tsInfo[$locale_code]['file_content'] );
            	if ( !eZTSTranslator::validateDOMTree( $tree ) ){ // 3.5 always returns true
                	eZDebug::writeWarning( "XML text for file $path did not validate", 'bhLocalTranslation::getTranslationContent' );
            	}
            	$contexts=$tree->elementsByName('context');
            	foreach ($contexts as $context){
            		
            		$name=$context->elementTextContentByName('name');            		
            		$messages=$context->elementsByName('message');
            		$content[$name]=array(); // a context might be empty, so initialize
            		$messagecounter=0;
            		foreach ($messages as $message){
            			$source=$message->elementTextContentByName('source');
            			if (!$source){
            				$name='Warning: Empty source';
            				eZDebug::writeWarning( "Empty source string found in $path", 'bhLocalTranslation::getTranslationContent' );
            			}
            			
            			$translation=$message->elementByName('translation');
            			$finished=($translation->attributeValue('type')!=='unfinished');
            			
            			$content[$name][$messagecounter]['source']=$source;
            			$content[$name][$messagecounter]['finished']=$finished;
            			$content[$name][$messagecounter]['translation']=$translation->textContent();
            			$content[$name][$messagecounter]['comment']=$message->elementTextContentByName('comment');
            			$messagecounter++;
            		}
            	}            	
            	return $content;
            }
		}else{
			eZDebug::writeWarning( "Translation $locale_code not found", 'bhLocalTranslations::getTranslationContent' );
			return false;
		}
	}
	
	/*!
	returns a hash for the translation file for a language
	used to check for changes to existing files
	*/
	function getTranslationHash($locale_code){
		if (array_key_exists($locale_code,$this->tsInfo)){
			return md5_file($this->tsInfo[$locale_code]['filepath']);		
		}else{
			return false;
		}
	}
	
	/*!
	 removes a source string
	 */
	function deleteSource($set_language,$set_context,$set_source){
		$translation_source=$this->getTranslationContent($set_language);
		if ($translation_source !== false){
			include_once("lib/ezxml/classes/ezxml.php");
			$xml=new ezXML();
			$tree=& $xml->domTree($translation_source);
			$contexts=& $tree->elementsByName('context');
			for ($contextcounter=0;$contextcounter<count($contexts);$contextcounter++){
            	$context=& $contexts[$contextcounter];
            	if ($set_context == $context->elementTextContentByName('name')){
            		
            		// no easy way to remove a given node, it seems.
            		// remove all child nodes, and add all back except the one to remove...
            		
            		$name=$context->elementByName('name');
            		$existing_messages=$context->elementsByName('message');
            		$context->removeChildren();
            		$context->appendChild($name);
            		for ($teller=0;$teller<count($existing_messages);$teller++){
            			$child=&$existing_messages[$teller];
            			if ($set_source != $child->elementTextContentByName('source')){
            				$translation=&$child->elementByName('translation');
            				if ($translation->childrenCount()==0){
        						// add empty text child, to avoid self closing tag for translated
    							$translation->appendChild(eZDOMDocument::createTextNode(''));
        					}
            				$context->appendChild($child);
            			}
            		}
            	}
			}
			
			$this->setTranslationContent($set_language,$tree->toString());
		}
	}
	
	/*!
	removes a context
	*/
	function deleteContext($set_language,$set_context){
		$translation_source=$this->getTranslationContent($set_language);
		if ($translation_source !== false){
			include_once("lib/ezxml/classes/ezxml.php");
			$xml=new ezXML();
			$tree=& $xml->domTree($translation_source);
			
			// no easy way to remove a given node, it seems
       		// remove all contexts, and add all back except the one to remove...
			
			$root=&$tree->root();
			$contexts=$tree->elementsByName('context');
			$root->removeChildren();
			for ($contextcounter=0;$contextcounter<count($contexts);$contextcounter++){
				$context= &$contexts[$contextcounter];
				if ($set_context != $context->elementTextContentByName('name')){
					$root->appendChild($context);
				}
			}
			// add empty text child to ts if ts is empty, to avoid self closing tag for ts
			$ts=&$tree->root();
			if ($ts->childrenCount()==0){
			    $ts->appendChild(eZDOMDocument::createTextNode(''));
			}
			$this->setTranslationContent($set_language,$tree->toString());
		}
	}
	
	/*!
	 adds a new source string. 
	*/
	function setSource($set_language,$set_contextname,$set_source_edited,$set_comment_edited,$source_original=''){
		$translation_source=$this->getTranslationContent($set_language);

		if ($translation_source !== false){
			
			include_once( "lib/ezxml/classes/ezxml.php" );
			$xml=new ezXML();
			$tree=& $xml->domTree($translation_source);
			if ( !eZTSTranslator::validateDOMTree( $tree ) ){ // 3.5 always returns true
               	eZDebug::writeWarning( "XML text did not validate", 'bhLocalTranslation::setSource' );
            }
            $context_was_found=false;
            $contexts= & $tree->elementsByName('context');
            for ($contextcounter=0;$contextcounter<count($contexts);$contextcounter++){
            	$context=& $contexts[$contextcounter];
            	if ($set_contextname == $context->elementTextContentByName('name')){
            		$context_was_found=true;
            		$target_context=& $context; 
            		
            	}
            }
            if (!$context_was_found){
            	$root=& $tree->root();
            	$name=&eZDOMDocument::createElementNode('name');
            	$name->appendChild(eZDOMDocument::createTextNode($set_contextname));
            	$target_context=&eZDOMDocument::createElementNode('context');
            	$target_context->appendChild($name);
            	$root->appendChild($target_context);
            	
            }
    		if ($source_original == ''){ // store new source string
    			$message=&eZDOMDocument::createElementNode('message');
    			$source=&ezDOMDocument::createElementNode('source');
    			$source->appendChild(eZDOMDocument::createTextNode($set_source_edited));
    			$message->appendChild($source);
    			
    			$translation=&eZDOMDocument::createElementNode('translation',array('type' => 'unfinished'));
    			$translation->appendChild(eZDOMDocument::createTextNode(''));
    			$message->appendChild($translation);
    			if ($set_comment_edited!=''){
    				$comment=&eZDOMDocument::createElementNode('comment');
    				$comment->appendChild(eZDOMDocument::createTextNode($set_comment_edited));
    				$message->appendChild($comment);
    			}	
    			
    			$target_context->appendChild($message);
    			
    		}else{ // store changes to existing source string
        		$messages=& $target_context->elementsByName('message');
        		for ($messagecounter=0;$messagecounter<count($messages);$messagecounter++){ // ah. Sometimes we hate PHP - foreach ($messages as $message) screws up changes to $message, since messages is a pointer to an array of pointers..
        			$message=& $messages[$messagecounter];
        			if ($source_original==$message->elementTextContentByName('source')){
        				$source=&$message->elementByName('source');
        				$text=&$source->firstChild();
        				$text->setContent($set_source_edited);
        				$translation=&$message->elementByName('translation');
        				$translation->removeAttributes();
        				$translation->set_attribute('type','unfinished');
        				if ($translation->childrenCount()==0){
        					// add empty text child, to avoid self closing tag for translated
    						$translation->appendChild(eZDOMDocument::createTextNode(''));
        				}
        				if ($set_comment_edited!=''){
        					$comment=&$message->elementByName('comment');
        					if (is_null($comment) || ($comment===false) ){
								$comment= & eZDOMDocument::createElementNode('comment');
    							$comment->appendChild(eZDOMDocument::createTextNode($set_comment_edited));
    							$message->appendChild($comment);
        					}else{
        						$text=&$comment->firstChild();
        						if (is_null($text) || ($text===false)){
            						$comment->appendChild(eZDOMDocument::createTextNode($set_translation));
        						}else{
        							$text->setContent($set_comment_edited);
        						}
        					}
        				}
        			}
        		}
    		}
    		$this->setTranslationContent($set_language,$tree->toString());
		}
	}
	
	/*!
	 sets a translation for a source string
	 */
	function setTranslation($set_language,$set_context,$set_source,$set_translation,$set_finished){
		$translation_source=$this->getTranslationContent($set_language);
		if ($translation_source !== false){
			
			// go through XML file
			include_once( "lib/ezxml/classes/ezxml.php" );
			$xml = new eZXML();
            $tree =& $xml->domTree( $translation_source );
            if ( !eZTSTranslator::validateDOMTree( $tree ) ){ // 3.5 always returns true
               	eZDebug::writeWarning( "XML text did not validate", 'bhLocalTranslation::setTranslation' );
            }
            $contexts=&$tree->elementsByName('context');
            
            // go through all contexts until we find the correct one. Hm. Maybe we should look for xpath
            foreach ($contexts as $context){
            	if ($set_context == $context->elementTextContentByName('name')){
            		$messages=&$context->elementsByName('message');
					// iterate all messages until we find the right one
            		foreach ($messages as $message){
            			if ($set_source == $message->elementTextContentByName('source')){
							// set finished flag
            				$translation=&$message->elementByName('translation');
            				$translation->removeAttributes();
            				if (!$set_finished){
            					$translation->set_attribute('type','unfinished');
            				}
            				$text=&$translation->firstChild();
            				// if no current translation exists, we need to create a new text child
            				if (is_null($text) || !$text){
            					$text=&ezDOMDocument::createTextNode($set_translation);
            					$translation->appendChild($text);
            				}else{
            					// set new translation
            					$text->setContent($set_translation);
            				}
            			}
            		}
            	}
            }
            $this->setTranslationContent($set_language,$tree->toString());
		}else{
			eZDebug::writeWarning( "Translation for $locale_code not found, cannot set values", 'bhLocalTranslations::getTranslationContent' );
			return false;
		}
	}
	
	
};
?>