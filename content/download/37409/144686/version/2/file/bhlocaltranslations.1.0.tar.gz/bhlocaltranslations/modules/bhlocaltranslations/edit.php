<?php
/*

    bhLocalTranslations - Local translation management extension for eZ publish 3.5
    
    Copyright (C) 2005 Bodoni Hus

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA	
    
	Jo Havik / jo.havik@bodonihus.no
	
*/
include_once('kernel/common/template.php');
include_once('extension/bhlocaltranslations/modules/bhlocaltranslations/classes/bhlocaltranslations.php' );


$http =& eZHTTPTool::instance();
$Module =& $Params['Module'];



// get language parameter, set to untranslated if empty
$language=$Params['language'];

// sanitize value of language, this value is used to find a file on the local filesystem
$language=bhLocalTranslations::sanitizeLocaleCode($language);



if ($language=='untranslated'){
    $templatefile='edit_untranslated.tpl';
}else{
    $templatefile='edit_translated.tpl';
}



$translations = new bhLocalTranslations();
$translation_info=$translations->getInfo($language);
if (!$translation_info ){
    return $Module->handleError( EZ_ERROR_KERNEL_NOT_FOUND, 'kernel' );
}

$template = & templateInit();
$template->setVariable('translation_hash',$translations->getTranslationHash($language));
$template->setVariable('translation_info',$translation_info);
$template->setVariable('translation_content',$translations->getTranslationContent($language,false));

          
$Result=array();
$Result['content']=$template->fetch('design:bhlocaltranslations/'.$templatefile);
$Result['path']=array(array('url' => 'bhlocaltranslations/list', 'text' => 'Local translations'),array('url' => false, 'text' => 'Edit'),array('url' => false, 'text' => $translation_info['international_name']));




?>
