<!DOCTYPE TS>
<TS>
  <context>
    <name>bhsitetranslations</name>
    <message>
      <source>Warning: Clicking Remove, Store or Add will store the current values of the form</source>
      <translation>Advarsel: Alle verdier blir lagret når du klikker Fjern, Lagre eller Ny</translation>
    </message>
    <message>
      <source>Add</source>
      <translation>Ny</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Fjern</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Store</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Rediger</translation>
    </message>
    <message>
      <source>Context</source>
      <translation>Kontekst</translation>
    </message>
    <message>
      <source>Translations</source>
      <translation>Oversettelser</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Språk</translation>
    </message>
    <message>
      <source>Country</source>
      <translation>Land</translation>
    </message>
    <message>
      <source>Locale</source>
      <translation>Stedsinformasjon</translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Kilde</translation>
    </message>
    <message>
      <source>Translated</source>
      <translation>Oversatt</translation>
    </message>
    <message>
      <source>Finished</source>
      <translation>Ferdig</translation>
    </message>
    <message>
      <source>Translation</source>
      <translation>Oversettelse</translation>
    </message>
    <message>
      <source>Existing context</source>
      <translation>Eksisterende kontekst</translation>
    </message>
    <message>
      <source>New context</source>
      <translation>Ny kontekst</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Kommentar</translation>
    </message>
    <message>
      <source>Add string</source>
      <translation>Ny streng</translation>
    </message>
  </context>
</TS>