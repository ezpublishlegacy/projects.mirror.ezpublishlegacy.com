bhlocaltranslations Version 1.0  README
========================================

bhLocalTranslations is a simple extension to eZ Publish 3.5. The extension makes it easy for designers, day-to-day admins, etc. to make changes in a set of local translation files. It also saves the developer (you, that is :) from typing translations into an XML file (or using external tools) - minimizing errors, delay and boredom.

The main purpose is to be able to distribute a set of templates using custom translations, and use the admin interface to cater for translations for new site languages.

The translation files will (as an extension) survive upgrades of eZ Publish, which is a nice bonus.

Licence
=======
bhLocalTranslations is licensed under the Gnu GPL. Full license text is included in the file lisence

Installation
============
Please refer to the file install.txt


How does it work?
=================
The module is just a set of functions to read, change and write to local translation files, with a GUI on top.

You can access the module from "/bhlocaltranslations/list". 

Only admin has access to the module by default. If you want other users to be able to edit the translations, assign permission to access the module "bhlocaltranslations" to your users.

The extension will automatically create a second directory, called "bhlocaltranslations_share" in your extension directory. All local translation files are stored here. There are two reasons for this:

1. You can upgrade bhlocaltranslation without overwriting your current translations
2. eZ Publish can only manage a single translation repository per extension

The module assumes that you want to maintain translations for all languages defined in your site. It will automatically create the needed directory structure for your site. If you want to maintain translations for other languages, you must manually add a directory under "bhsitetranslations_share/translations". Make a copy of the directory "untranslated", and rename the copy to the locale code of the language you want to translate to.



Caveats
=======
Depending on your setup, you will have to clear your translation cache after editing local translations. In some cases, eZ Publish will do this automatically for each change to your translations. This will make the extension seem quite slow.

In 1.0 beta errorchecks, logs and documented code are close to nonexistent.

It is coded quite hastily. Some places brute force is used.

It is tested with eZ Publish 3.5 / firefox 1.0 / IE 6.0 only, and uses the design from 3.5 to keep our customers happy.

Your browser must support Javascript if you want to add multiple source lines in one go.





