<?php
/*

    bhLocalTranslations - Local translation management extension for eZ publish 3.5
    
    Copyright (C) 2005 Bodoni Hus

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA	
    
	Jo Havik / jo.havik@bodonihus.no
	
*/
$Module = array( 'name' => 'bhlocaltranslations' );

$ViewList = array();

// The "edit" view is handled by edit.php
// requires "translate" policy

$ViewList['list']=array(
    'script' => 'list.php',
    'functions' => array( 'administration' ),
    'default_navigation_part' => 'ezsetupnavigationpart'
);
$ViewList['edit']=array(
    'script' => 'edit.php',
    'ui_context' => 'edit',
    'params' => array('language'),
    'functions' => array('administration'),			      
    'default_navigation_part' => 'ezsetupnavigationpart'
);

$ViewList['store']=array(
    'script' => 'store.php',
    'params' => array('language'),
    'functions' => array('administration'),			      	
    'default_navigation_part' => 'ezsetupnavigationpart'
);

$ViewList['add']=array(
    'script' => 'add.php',
    'ui_context' => 'edit',
    'functions' => array('administration'),			      	
    'default_navigation_part' => 'ezsetupnavigationpart'
);

$FunctionList=array();
$FunctionList['administration'] = array();



?>
