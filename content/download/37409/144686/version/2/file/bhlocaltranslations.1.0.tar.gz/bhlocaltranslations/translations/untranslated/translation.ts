<!DOCTYPE TS>
<TS>
  <context>
    <name>bhsitetranslations</name>
    <message>
      <source>Warning: Clicking Remove, Store or Add will store the current values of the form</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Discard</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Store</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Edit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Context</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Translations</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Locale</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Source</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Translated</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Finished</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Translation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Existing context</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New context</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Comment</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add string</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
</TS>