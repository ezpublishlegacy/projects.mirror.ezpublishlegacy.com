<?php
/*

    bhLocalTranslations - Local translation management extension for eZ publish 3.5
    
    Copyright (C) 2005 Bodoni Hus

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA	
    
	Jo Havik / jo.havik@bodonihus.no
	
*/
include_once('kernel/common/template.php');
include_once('extension/bhlocaltranslations/modules/bhlocaltranslations/classes/bhlocaltranslations.php' );


$http =& eZHTTPTool::instance();
$Module =& $Params['Module'];

if ( $http->hasPostVariable( 'DiscardButton' ) )
{
    $Module->redirectTo( '/bhlocaltranslations/list' );
    return;
}

// get language parameter, set to untranslated if empty
$language=$Params['language'];
if ($language==''){
    $language='untranslated';
}

// sanitize value of language, this value is used to find a file on the local filesystem
$language=bhLocalTranslations::sanitizeLocaleCode($language);

$translations = new bhLocalTranslations();
$translation_info=$translations->getInfo($language);
if (!$translation_info){
    return $Module->handleError( EZ_ERROR_KERNEL_NOT_FOUND, 'kernel' );
}
if ($http->hasPostVariable('AddButton')){
    $Module->redirectTo('/bhlocaltranslations/add');
    return;
}

if ($http->hasPostVariable('AddDiscardButton')){
    $Module->redirectTo('/bhlocaltranslations/edit/untranslated');
    return;
}


// check if file has been altered by someone else
if ($http->postVariable( 'translation_hash' ) == $translations->getTranslationHash($language)){
	
    // we are going to remove source strings or contexts from all translations
    if ($http->hasPostVariable('RemoveButton') && $http->hasPostVariable('delete_src_array')){
    	$delete_src_array=$http->postVariable('delete_src_array');
    	foreach (array_values($delete_src_array) as $delete_key){
    		$parts =split('__BHSPLIT__',$delete_key);
    		$delete_context=urldecode($parts[0]);
    		$delete_src=urldecode($parts[1]);
    		$translated_languages=$translations->getAvailableTranslations();
    		foreach ($translated_languages as $trans){
    			if ($delete_src!=''){
    			    $translations->deleteSource($trans,$delete_context,$delete_src);
    			}else{
    			    $translations->deleteContext($trans,$delete_context);
    			}
    		}
    	}
    	foreach ($translated_languages as $trans){
           $translations->storeContent($trans);
    	}
    	$Module->redirectTo('/bhlocaltranslations/edit/untranslated');
    	return;
    }
	
	
    // TODO. When I find the time, rewrite this so that we avoid multiple calls to $translations->setTranslation
    
    // check if we should store new source strings
    if ($http->hasPostVariable('AddConfirmButton') && $http->hasPostVariable('stringcounter')){
    	$max=$http->postVariable('stringcounter');
    	$max=intval($max);
    	if ($http->postVariable('add_context_type')=='existing'){
    		$new_context=$http->postVariable('add_context_existing');
    	}else{
    		$new_context=$http->postVariable('add_context_new');
    	}
    	$new_context=urldecode($new_context);
    	$translated_languages=$translations->getAvailableTranslations();
    	for ($stringcounter=1;$stringcounter<=$max;$stringcounter++){
    		if ($http->hasPostVariable('add_source_'.$stringcounter) && $http->hasPostVariable('add_comment_'.$stringcounter)){
    			$new_source=$http->postVariable('add_source_'.$stringcounter);
    			$new_comment=$http->postVariable('add_comment_'.$stringcounter);
                if (($new_source != '') && ($new_context !='')){
    				foreach ($translated_languages as $trans){
		                  $translations->setSource($trans,$new_context,$new_source,$new_comment);
    				}
    			}
    		}
    	}
    	foreach ($translated_languages as $trans){
    		$translations->storeContent($trans);
    	}
    	
    	$Module->redirectTo( '/bhlocaltranslations/edit/untranslated' );
    	return;
    }

	// if we are storing changes to the source strings, changes should propagate through every laguage spesific file
	if ($language == 'untranslated'){
		$messages=$translations->getTranslationContent($language,false);
		$translated_languages=array();
		foreach (array_keys($messages) as $contextname){ // iterate contexts
		    for ($messagecounter=0;$messagecounter<count($messages[$contextname]);$messagecounter++){ // iterate messages in context
				$sourcePostName='context_'.urlencode($contextname).'_src_'.urlencode($messages[$contextname][$messagecounter]['source'].'_src'); // build form-name for each translation
				$commentPostName='context_'.urlencode($contextname).'_src_'.urlencode($messages[$contextname][$messagecounter]['source'].'_comment'); // build form-name for each translation
				if ($http->hasPostVariable($sourcePostName)){
					$source_original=$messages[$contextname][$messagecounter]['source'];
					$source_edited=$http->postVariable($sourcePostName);			
					$comment_original=$messages[$contextname][$messagecounter]['comment'];
					$comment_edited=$http->postVariable($commentPostName);
					if (($source_original != $source_edited) || ($comment_original != $comment_edited)){ // this source string has changed
						$translated_languages=$translations->getAvailableTranslations();
						foreach ($translated_languages as $trans){
							$translations->setSource($trans,$contextname,$source_edited,$comment_edited,$source_original);
						}
					}
				}
		    }
		}
		// changes has been made
		if (count($translated_languages)>0){
			foreach ($translated_languages as $trans){
				$translations->storeContent($trans);
			}
		}
		$Module->redirectTo( '/bhlocaltranslations/list' );
		return;
	}
	// iterate all messages, find edited translations
	if ($language != 'untranslated'){
		$messages=$translations->getTranslationContent($language,false);
		foreach (array_keys($messages) as $contextname){ // iterate contexts
			for ($messagecounter=0;$messagecounter<count($messages[$contextname]);$messagecounter++){ // iterate messages in context
	
				$translationPostName='context_'.urlencode($contextname).'_src_'.urlencode($messages[$contextname][$messagecounter]['source'].'_translation'); // build form-name for each translation
				$finishedPostName='context_'.urlencode($contextname).'_src_'.urlencode($messages[$contextname][$messagecounter]['source'].'_finished'); // build form-name for each finished checkbox
				
				// translation should be available for each message. Should always be true, unless post values are hand crafted
				if ($http->hasPostVariable($translationPostName)){
					
					
					$translation_original=$messages[$contextname][$messagecounter]['translation'];				
					$translation_edited=$http->postVariable($translationPostName);				
					
					$finished_original=&$messages[$contextname][$messagecounter]['finished'];
					$finished_edited=($http->hasPostVariable($finishedPostName) && ($http->hasPostVariable($finishedPostName) == 'on'));
					
					//check if message was altered
					if (($translation_original != $translation_edited) || ($finished_original != $finished_edited)) { 
						$translations->setTranslation($language,$contextname,$messages[$contextname][$messagecounter]['source'],$translation_edited,$finished_edited);
					}
				}
			}
		}
		$translations->storeContent($language);
		$Module->redirectTo( '/bhlocaltranslations/list' );
		return;
	}
}

$Module->redirectTo( '/bhlocaltranslations/list' );
return;	




?>
