<?php /*

[ExtensionSettings]
DesignExtensions[]=all2ejwplayer

[StylesheetSettings]
CSSFileList[]=JWPlayer.css

[JavaScriptSettings]
JavaScriptList[]=JWPlayer.js
JavaScriptList[]=swfobject.js

*/ ?>
