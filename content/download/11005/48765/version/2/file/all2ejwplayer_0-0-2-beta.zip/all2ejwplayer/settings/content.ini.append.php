<?php /* #?ini charset="utf-8"?

[CustomTagSettings]
AvailableCustomTags[]=jwplayer
IsInline[jwplayer]=true

[jwplayer]
CustomAttributes[]
#CustomAttributes[]=type, you can decide between 'lightbox' or 'inline'. if no type is given the player would be start as lightbox
# lightbox - only the link to the file is displayed, to play the video click on this link
# inline - the whole player would be loaded into your site and you can start em up by click on it
CustomAttributes[]=type

#CustomAttributes[]=playerclass, you can define several blocks(classes) in your all2ejwplayerclasses.ini. the name of this block
# should be placed here. by default, or without an entry the player use 'Standard' for the type-lightbox and 'Inline' for type-inline
CustomAttributes[]=playerclass

*/ ?>
