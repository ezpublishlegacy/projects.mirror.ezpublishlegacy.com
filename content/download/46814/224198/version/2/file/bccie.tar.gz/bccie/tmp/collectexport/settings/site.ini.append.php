<?php /*

[RegionalSettings]
TranslationExtensions[]=collectexport

*/ ?>

