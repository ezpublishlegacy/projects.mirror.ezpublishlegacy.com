<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fre-FR">
<context>
    <name>design/collectexport/overview</name>
    <message>
        <source>Collected informations</source>
        <translation>Informations collectées</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BC CIE Export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/bccie/menu</name>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extension project</source>
        <translation type="unfinished"></translation>
    </message>
</context>

<context>
    <name>extension/collectexport</name>
    <message>
        <source>Collected information export</source>
        <translation>Export des informations collectées</translation>
    </message>
</context>
<context>
    <name>design/collectexport/export</name>
    <message>
        <source>Field #%counter</source>
        <translation>Champ N°%counter</translation>
    </message>
    <message>
        <source>Content object id</source>
        <translation>Identifiant de l'objet</translation>
    </message>
    <message>
        <source>Leave empty (note: field still gets created)</source>
        <translation>Laisser vide (le champs sera créé)</translation>
    </message>
    <message>
        <source>Ignore (note: field doesn't get created at all)</source>
        <translation>Ignorer (le champs ne sera pas créé)</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Type d'export</translation>
    </message>
    <message>
        <source>Separation char for CSV export</source>
        <translation>Séparateur pour l'export CSV</translation>
    </message>
    <message>
        <source>Do export</source>
        <translation>Exporter</translation>
    </message>    
</context>
</TS>
