<!DOCTYPE TS><TS>
<context>
    <name>design/collectexport/overview</name>
    <message>
        <source>Collected informations</source>
        <translation>Gesammelte Informationen</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
</context>

<context>
    <name>extension/collectexport</name>
    <message>
        <source>Collected information export</source>
        <translation>Export gesammelter Informationen</translation>
    </message>
</context>
<context>
    <name>design/collectexport/export</name>
    <message>
        <source>Field #%counter</source>
        <translation>Feld Nr. %counter</translation>
    </message>
    <message>
        <source>Content object id</source>
        <translation>Objekt ID</translation>
    </message>
    <message>
        <source>Leave empty (note: field still gets created)</source>
        <translation>Übergehen (Hinweis: Feld wird leer erstellt)</translation>
    </message>
    <message>
        <source>Ignore (note: field doesn't get created at all)</source>
        <translation>Ignorieren (Hinweis: Feld wird nicht erstellt)</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Exporttyp</translation>
    </message>
    <message>
        <source>Separation char for CSV export</source>
        <translation>Trennzeichen für CSV-Export</translation>
    </message>
    <message>
        <source>Do export</source>
        <translation>Exportieren</translation>
    </message>    
</context>
</TS>
