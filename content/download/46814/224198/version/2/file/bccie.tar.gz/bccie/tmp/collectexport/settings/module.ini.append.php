<?php /*

[ModuleSettings]
ExtensionRepositories[]=collectexport

*/ ?>