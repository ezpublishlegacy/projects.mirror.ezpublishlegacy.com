<?php /*

[ExtensionSettings]
DesignExtensions[]=collectexport

*/ ?>