<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezrss/kernel/common/ezrssoperator.php',
                                    'class' => 'eZRSSOperator',
                                    'operator_names' => array( 'ezrss' ) );
