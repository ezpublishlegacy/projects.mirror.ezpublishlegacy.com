<?php
//
// Definition of eZRSSOperator class
//
// Created on: <27-Mar-2003 13:43:10 oh>
//
// Copyright (C) 1999-2003 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid "eZ publish professional licences" may use this
// file in accordance with the "eZ publish professional licence" Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "eZ publish professional licence" is available at
// http://ez.no/home/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

/*! \file eZRSSOperator.php
*/

/*!
  \class eZRSSOperator eZRSSoperator.php
  \brief The class eZRSSOperator does

*/
class eZRSSOperator
{
    /*!
     Initializes the object with the name $name, default is "ezrss".
    */
    function eZRSSOperator( $name = "ezrss" )
    {
	$this->Operators = array( $name );
    }

    /*!
Returns the template operators.
    */
    function &operatorList()
    {
        return $this->Operators;
    }

    function namedParameterList()
    {
        return array( 'rss_site' => array( 'type' => 'string',
                                           'required' => true,
                                           'default' => false ));
    }

    function getNodes( $dom, $node, $limit = 'disabled', $uniqeNode = 0 )
    {
        $elements =& $dom->elementsByName( $node );
        $i=0;

        foreach( $elements as $element )
        {
            // Is the limit disabled or is it reached?
            if ( $limit != 'disabled' and $limit <= $i )
                break;

            // Loop through every child and grab the content
            foreach ( $element->children() as $childNode )
            {
                if ( $uniqeNode == 0 ) {
                    $elementArray[$i][$childNode->name()]['content'] = $childNode->textContent();
                }
                else {
                    $elementArray[$childNode->name()]['content'] = $childNode->textContent();
                }
            }
            $i++;
        }
        return( $elementArray );
    }

    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        include_once( "lib/ezutils/classes/ezini.php" );
        include_once( "lib/ezxml/classes/ezxml.php" );

        $ini =& eZINI::instance("ezrss.ini");

        // Get the site passed to us as a argument
        $rssSite = $namedParameters['rss_site'];
        $rssSettings = $ini->variable( 'eZRSSSettings', $rssSite );

        // Open file
        $fp = fopen( $rssSettings['url'], "r" );
        if ( !$fp )
        {
            return false;
        }

        // Get the content of the file
        while( !feof( $fp ) )
        {
            $rssFileContent .= fread( $fp, 1024 );
        }
        fclose( $fp );

        // New xml parser.
        $xml = new eZXML();
        $dom =& $xml->domTree( $rssFileContent );
        if ( !$dom )
        {
            return false;
        }

        // Get <channel> information
        if ( $rssSettings['ChannelData'] == 'enabled' )
            $rssData['channel'] = $this->getNodes( $dom, 'channel', 'disabled', 1 );

        // Get <image> information
        if ( $rssSettings['ImageData'] == 'enabled' )
            $rssData['image'] = $this->getNodes( $dom, 'image', 'disabled', 1 );

        // Get every <item>
        $rssData['items'] = $this->getNodes( $dom, 'item', $rssSettings['items'], 0 );

        // Return data
        $operatorValue = $rssData;
    }
    var $Operators;
}
?>
