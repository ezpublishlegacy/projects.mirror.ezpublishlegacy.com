Installation
------------
See the installation.txt file


Configuration
-------------
The ezrss operator is configurable through it's own .ini file located in extension/ezrss/settings/ezrss.ini

Configuration example:
# Path to the RSS file. This can either be a URL or a file path. Note: for better speed make
# a cronjob which download the RSS file to disk, and set the url to the local file.
freshmeat[url]=http://freshmeat.net/backend/fm.rdf
# How many items (news) should we show? If set to disabled all items in the rss file
# will be shown.
freshmeat[items]=4
# Enable parsing of channel data. Channel data contains basic information about
# the site, like url, title, description and so on. 
# This data might not be available on all sites.
freshmeat[ChannelData]=disabled
# Enable parsing of image data. Image data contains among other thing a link to
# the site logo. This data might not be available on all sites.
freshmeat[ImageData]=enabled

Here we are reading the rss file for freshmeat.net and only displaying the first 4 items.
eZRSS will not parse any channel data but will parse and return image data.


Usage
-----
eZRSS takes one argument, the site to parse information from.
If you call eZRSS like this:
  ezrss("examplesite")
eZRSS will look in its ezrss.ini after examplesite[url] and try to parse the specified file/url.
Likewise, if you call eZRSS with "mynewssite" like this:
  ezrss("mynewssite")
ezrss will look after a url/file path specified in mynewssite[url].


A complete example (this example requires the site "freshmeat" to be configured):
{cache-block keys=$#module_result.node_id expiry=3600}
{let freshmeat_data=ezrss("freshmeat")}
<h1>Freshmeat</h1>
{* View the site logo *}
<a href="{$freshmeat_data.image.link.content}"><img src="{$freshmeat_data.image.url.content}" /></a>
<ul>
	{section name=rss loop=$freshmeat_data.items)}
	<li><a href="{$rss:item.link.content}">{$rss:item.title.content}</a></li>
	{/section}
</ul>		
{/let}
{/cache-block}

Here we call ezrss with "freshmeat" as a argument. ezrss will look in the
ezrss.ini after the content of freshmeat[url]. It will then open the url, parse it and return
the data.

Making sure the ezrss is inside a {cache-block} is a very good idea, _especially_ if you do not read the RSS data
from local disk. It's recommended to download the RSS data to disk when you are testing as some sites may ban for a period of time if
you request the data to often.

If you want to see the data eZRSS returns put the following in a template:
{let freshmeat_data=ezrss("freshmeat")}
     {$freshmeat_data|attribute(show)}
{/let}

