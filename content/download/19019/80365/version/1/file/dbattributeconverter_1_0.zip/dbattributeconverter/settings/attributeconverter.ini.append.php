<?php /* #?ini charset="utf8"?

[ConverterHandlers]
Handler[]=ezstring2ezinteger
Handler[]=ezinteger2ezstring
Handler[]=ezstring2eztext
Handler[]=eztext2ezstring
Handler[]=ezinteger2ezfloat
Handler[]=ezfloat2ezinteger
Handler[]=ezselection2ezstring
Handler[]=ezxmltext2eztext
Handler[]=eztext2ezxmltext
Handler[]=ezdate2ezdatetime
Handler[]=ezdatetime2ezdate
Handler[]=ezobjectrelation2ezobjectrelationlist
Handler[]=ezobjectrelationlist2ezobjectrelation

*/?>
