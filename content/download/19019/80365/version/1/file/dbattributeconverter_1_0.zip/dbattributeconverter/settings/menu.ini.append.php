<?php /*

[NavigationPart]
Part[dbattributeconverter]=DB Attribute Converter

[TopAdminMenu]
Tabs[]=dbattributeconverter

[Topmenu_dbattributeconverter]
NavigationPartIdentifier=dbattributeconverter
Name=DB Attribute Converter
Tooltip=Convert content attribute from one datatype to another.
URL[]
URL[default]=attributeconverter/wizard
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>