Explanation
-------------------------------
This extension will create automatically (using the 'content,after,publish' trigger) a audio sample from object related mp3 audio files.
With this workflow event it's possible to setup the playtime, the cutstart and the fadein-/fadeouttime in seconds to get a automatically created audio sample.
For optimal use the server needs ffmpeg and sox installed, but also worked without it too (simple mp3 cutting in php without fading).

If u need info you are welcome in IRC #ezpublish on freenode server or you can write to audiosample@vigilax.net,
I would be happy too, if you write me where you're using vxaudiosample.


Recommended Requirements
-------------------------------
FFmpeg, Lame, Mad and Sox + Codecs and Libs

It's possible to install this in a Userspace too, more info follows 2012 =)


Installation
-------------------------------

1) Put this extension's folder in the "extension" directory under the root of
   the ez Publish site.

2) Open the appropriate site.ini and add ActiveExtensions[]=vxaudiosample (in the
   case of the override site.ini) or ActiveAccessExtension[]=vxaudiosample to the
   [ExtensionSettings] block.

3) Add/edit the path from LD_LIBRARY_PATH and bin_path in vxaudiosample.ini if needed.

4) Add/install a emusic container class with a object relation attribute named 'download'.
   You find the emusic_demo class example in the packages folder.

5) Install the audio_sample class package.

6) Add a Workflow with the Audio Sample event and choose this at the content publish after trigger.

7) Don't forget to refresh the autoload and clear the cache and have fun =)


Version history:
-------------------------------
* Release 0.8: initial release


To do:
-------------------------------
- code revision
- commands in code
- automatic recognition of existing samples
- multiple sample creation (objectrelation list)


Credits:
-------------------------------
James Heinrich  => getID3() Lib
mfboy           => mp3 Class
Daniel Kinzler  => cmd Class


Disclaimer & Copyright:
-------------------------------
/*
    vxaudiosample extension for eZ publish 4.x
    Copyright (C) 2011-2012 vigilax.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
