<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
	array( 'script' => 'extension/vxaudiosample/autoloads/getid3operator.php',
                            'class' => 'getID3Operator',
                            'operator_names' => array( 'getid3' ) );
?>
