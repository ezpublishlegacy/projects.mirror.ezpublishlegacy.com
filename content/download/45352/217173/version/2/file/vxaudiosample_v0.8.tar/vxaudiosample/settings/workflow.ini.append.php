<?php /*

[EventSettings]
ExtensionDirectories[]=vxaudiosample
AvailableEventTypes[]=event_createaudiosample

*/ ?>