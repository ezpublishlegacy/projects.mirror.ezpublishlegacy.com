<?php

class getID3Operator
{
    /*!
     Initializes the object with the name $name, default is "getid3".
    */
    function getID3Operator( $name = "getid3" )
    {
        $this->AttributeName = $name;
        $this->Operators = array( $name );
    }

    /*!
     Returns the template operators.
    */
    function operatorList()
    {
        return array( 'getid3' );
    }

    function operatorTemplateHints()
    {
        return array( $this->AttributeName => array( 'input' => true,
                                                     'output' => true,
                                                     'parameters' => 2 ) );
    }

    /*!
     See eZTemplateOperator::namedParameterList()
    */

    function namedParameterList()
    {
        return array( "limit" =>	array( "type" => "string",
                                           "required" => false,
                                           "default" => "" )
					 );
    }

    /*!
     Display the variable.
    */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
    {
        $limit  = $namedParameters['limit'];

		require_once('extension/vxaudiosample/lib/getid3.php');
		$getID3 = new getID3;

		$ThisFileInfo = $getID3->analyze($operatorValue);

		if($limit){
			$output = $ThisFileInfo[$limit];
		} else {
			$output = $ThisFileInfo;
		}

	$operatorValue=$output;
	return;
    }

    /// The array of operators, used for registering operators
    public $Operators;
}

?>