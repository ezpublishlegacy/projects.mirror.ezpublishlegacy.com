<?php
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: vxaudiosample
// SOFTWARE RELEASE: 0.8
// COPYRIGHT NOTICE: Copyright (c) 2011-2012 vigilax.net
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >

//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

/*! \file ezinfo.php


  \class vxaudiosample ezinfo.php
  \brief
*/

class vxaudiosampleInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/vxaudiosample" title="vxAudioSample by vigilax.net on projects.ez.no">vxAudioSample</a>',
            'Version' => '0.8',
            'Description' => 'This extension create automatically a audio sample from object related mp3 audio files.',
            'Copyright' => 'Copyright &copy; 2011-'.date('Y').' <a href="http://vigilax.net" title="vigilax.net">vigilax.net</a>',
            'License' => "GNU General Public License v2.0",
              'Includes the following library'              => array( 'Name' => 'getID3()',
                                                                      'Version' => '1.9.1',
                                                                      'Author' => '<a href="http://www.getid3.org" title="James Heinrich">James Heinrich</a>',
                                                                      'License' => 'GNU General Public License v2.0')
	);
    }
}

?>
