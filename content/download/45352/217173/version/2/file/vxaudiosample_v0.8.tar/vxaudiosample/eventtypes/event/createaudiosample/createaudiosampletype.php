<?php
//
// ## BEGIN COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
// SOFTWARE NAME: vxaudiosample
// SOFTWARE RELEASE: 0.8
// COPYRIGHT NOTICE: Copyright (c) 2011-2012 vigilax.net
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >

//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//
// ## END COPYRIGHT, LICENSE AND WARRANTY NOTICE ##
//

class createAudioSampleType extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_STRING = "createaudiosample";
    public function __construct()
    {
        parent::__construct( createAudioSampleType::WORKFLOW_TYPE_STRING, 'Audio Sample' );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array ( 'after' ) ) ) );
    }
 
    public function execute( $process, $event )
    {
        $parameters = $process->attribute( 'parameter_list' );

       $ini = eZINI::instance();
       $vxAudioSampleINI = eZINI::instance( 'vxaudiosample.ini' );
       $vxAudioSampleDebugOutput = $vxAudioSampleINI->variable( 'AudioSampleSettings', 'DebugOutput' );
 
       eZLog::write( "Entering createAudioSample workflow" );
       
       if( $vxAudioSampleDebugOutput == 'enabled' )
             eZLog::write( "Credentials found in vxaudiosample.ini" );

       
       // Translation
       // ezpI18n::tr( $context, $source, $comment = null, $arguments = null )


		$objectID = $parameters['object_id'];
		$userID = $parameters['user_id'];
                
                //$node = eZContentObjectTreeNode::fetchByContentObjectID( $objectID, false );
                //$nodeID = $node[0]['node_id'];
                
                $node = eZContentObjectTreeNode::findMainNode( $objectID, true );
                $dataMap = $node->dataMap();

                $parentClassIdentifier_INI = $vxAudioSampleINI->variable( 'AudioSampleSettings', 'parentClassIdentifier' );
                if($parentClassIdentifier_INI){
                    $parentClassIdentifier = $parentClassIdentifier_INI;
                } else {
                    $parentClassIdentifier = 'emusic_single';
                }
                
                if ($node->ClassIdentifier == $parentClassIdentifier && array_key_exists('download', $dataMap)) {
                    
                    $getID3 = new getID3;

                    $dataMap_playtime_seconds = $dataMap['playtime_seconds']->content();
                    $dataMap_cut_start = $dataMap['cut_start']->content();
                    $dataMap_fadein_time = $dataMap['fadein_time']->content();
                    $dataMap_fadeout_time = $dataMap['fadeout_time']->content();
                    
                    // compare timestrings and names to update audio sample or not
                    // compare 3 times, +1 sec and -1 sec ...
                    $rounded_playtime = date( "H:i:s", round($dataMap_playtime_seconds) );
                    
                    // create audio sample if it don't exist or it's another one
                    $user_childrens = eZContentObjectTreeNode::subTreeByNodeID( false, $node->NodeID );
                    $user_children_list = array();
                    foreach($user_childrens as $user_children){
                        if($user_children->ClassIdentifier == 'audio_sample' ){
                            $user_children_dataMap = $user_children->dataMap();
                            $children_file = $user_children_dataMap['file']->content();
                            $children_original_name = $user_children_dataMap['original_name']->content();
                            
                            $children_file_path = $children_file->filePath();
                            $children_FileInfo = $getID3->analyze($children_file_path);

                            
                            // wenn schon ein audio_sample vorhanden ist abbrechen
                            // ToDo: erkennen ob die quell audio objectrelation eine andere ist und dann ggf. updaten
                            return false;
                        }
                        $user_children_list[$user_children->MainNodeID]['Name'] = $user_children->Name;
                        $user_children_list[$user_children->MainNodeID]['ContentObjectID'] = $user_children->ContentObjectID;
                        // file info checken und mit ner eigenen id oder name + spiellänge vergleichen, 
                        // nur wenn keine datei vorhanden ist oder die neue anders ist den ganzen kram durchrattern...
                        $rounded_children_playtime = date( "H:i:s", round($children_FileInfo['playtime_seconds']) );
                    }

                  
                    $download = $dataMap['download']->content();
                    $download_dataMap = $download->dataMap();
                    $download_file_content = $download_dataMap['file']->content();
                    $download_file_path = $download_file_content->filePath();
                    
                    $OriginalFilename = $download_file_content->OriginalFilename;
                    $Original_name = substr($OriginalFilename, 0, (strlen ($OriginalFilename)) - (strlen (strrchr($OriginalFilename,'.'))));
                    $Sample_name = substr($OriginalFilename, 0, (strlen ($OriginalFilename)) - (strlen (strrchr($OriginalFilename,'.')))) . ' Sample';

                    /*
                    print_r($Original_name); 
                    print('<br />'); 
                    print_r($children_original_name);     
                    die();
                    */
                    
                    // create a tmp folder
                    $VarDir = $ini->variable( 'FileSettings', 'VarDir' );
                    $directory = $VarDir . '/vxtmp/';
                    if ( !file_exists( $directory ) )
                    {
                        if ( !eZDir::mkdir( $directory, 0775, true ) )
                        {
                            return false;
                        }
                    }
                    $download_file_path_info = pathinfo($download_file_path);
                    $file_sample_tmp_name = md5($download_file_path_info['filename']) . '_tmp.' . $download_file_path_info['extension'];
                    $file_sample_name = md5($download_file_path_info['filename']) . '.' . $download_file_path_info['extension'];

                    
                    // lib path from ini
                    $LD_LIBRARY_PATH_INI = $vxAudioSampleINI->variable( 'AudioSampleSettings', 'LD_LIBRARY_PATH' );
                    if($LD_LIBRARY_PATH_INI){
                        $LD_LIBRARY_PATH = $LD_LIBRARY_PATH_INI;
                    } else {
                        $LD_LIBRARY_PATH = '/usr/local/lib/';
                    }
                    $LD_LIBRARY_PATH_cmd = 'export LD_LIBRARY_PATH=' . $LD_LIBRARY_PATH . ';';

                    // bin path from ini
                    $bin_path_INI = $vxAudioSampleINI->variable( 'AudioSampleSettings', 'bin_path' );
                    if($bin_path_INI){
                        $bin_path = $bin_path_INI;
                    } else {
                        $bin_path = '';
                    }
                    $absolute_path = $_SERVER['DOCUMENT_ROOT'] . '/';

                    $file_fullpath = $absolute_path . $download_file_path;
                    $tmpfile_fullpath = $absolute_path . $directory . $file_sample_tmp_name;
                    $samplefile_fullpath = $absolute_path . $directory . $file_sample_name;

                    $FileInfo = $getID3->analyze($file_fullpath);
                    $playtime_seconds = $FileInfo['playtime_seconds'];
                    $playtime_string = $FileInfo['playtime_string'];

                    $cmd = new cmd();
                
                    // standard format: 00:00:00.00
                    // 00:00:59.5885416667 possible
                    // seconds only also possible

                    // ffmpeg copy & cut command (advantage: starttime)
                    //$cut_start = '00:00:00.00';
                    $cut_start = (float) $dataMap_cut_start; // daten im audioschnittprogramm vergleichen...
                    $cut_end = (float) $dataMap_playtime_seconds + 1; // + 1 because a sox lenght warning after fading without it
                    $ffmpeg_cut = $bin_path . 'ffmpeg -ss ' . $cut_start . ' -t ' . $cut_end . ' -i ' . $file_fullpath . ' -acodec copy ' . $tmpfile_fullpath . ';';
                    $ffmpeg_cmd = $LD_LIBRARY_PATH_cmd . $ffmpeg_cut;
                    $ffmpeg_output = $cmd->runExternal( $ffmpeg_cmd, $ffmpeg_code );

                    if ($ffmpeg_code == 127) {
                        // debug log schreiben... ffmpeg läuft nicht, php class zum schneiden verwenden
                        // kann probleme in sox verursachen
                        $mp3 = new mp3();
                        $file_input = $file_fullpath;
                        $file_output = $tmpfile_fullpath;
                        $startindex = 0;
                        $endindex = (float) $dataMap_playtime_seconds + 1; // + 1 because a sox lenght warning after fading without it
                        $indextype = 'second';
                        $cleantags = false;
                        $mp3->cut_mp3($file_input, $file_output, $startindex, $endindex, $indextype, $cleantags);
                    }

                    // sox fade command
                    $fadein_time = (float) $dataMap_fadein_time;
                    $fadeout_time = (float) $dataMap_fadeout_time;
                    $sample_length = (float) $dataMap_playtime_seconds;
                    $sox_fade = $bin_path . 'sox ' . $tmpfile_fullpath . ' ' . $samplefile_fullpath . ' fade ' . $fadein_time . ' ' . $sample_length . ' ' . $fadeout_time;
                    $sox_cmd = $LD_LIBRARY_PATH_cmd . $sox_fade;
                    $sox_output = $cmd->runExternal( $sox_cmd, $sox_code );

                    if ($sox_code == 127) {
                        // debug log schreiben... sox läuft nicht
                        rename($tmpfile_fullpath, $samplefile_fullpath);
                    }


                    $sample_file_path_info = pathinfo($samplefile_fullpath);

                    //setting general node details
                    $params = array();
                    $params['class_identifier'] = 'audio_sample';
                    $params['creator_id'] = $userID; 
                    $params['parent_node_id'] = $node->NodeID;
                    $params['storage_dir' ] = $sample_file_path_info['dirname'] . '/';

                    $attributesData = array();
                    $attributesData['name'] = $Sample_name;
                    $attributesData['original_name'] = $Original_name;
                    $attributesData ['file'] = $sample_file_path_info['basename'];;
                    $attributesData ['playtime_seconds'] = $playtime_seconds;
                    $attributesData ['playtime_string'] = $playtime_string;
                    $params['attributes'] = $attributesData;

                    $mp3Object = eZContentFunctions::createAndPublishObject( $params );      
                    unlink( $tmpfile_fullpath );
                    unlink( $samplefile_fullpath );


                }
                
                // objectrelation list
                if (array_key_exists('download_list', $dataMap)) {
                    // create audio sample still for simple objectrelation only
                }
                


        return eZWorkflowType::STATUS_ACCEPTED;
    }

    
}
eZWorkflowEventType::registerEventType( createAudioSampleType::WORKFLOW_TYPE_STRING, 'createaudiosampletype' );

?>