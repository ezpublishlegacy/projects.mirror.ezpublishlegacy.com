[ExtensionSettings]
DesignExtensions[]=locationfinder
