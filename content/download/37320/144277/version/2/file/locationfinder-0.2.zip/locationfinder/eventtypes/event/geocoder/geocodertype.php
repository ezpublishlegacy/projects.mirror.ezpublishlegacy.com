<?php
//
// Definition of GeocoderType class
//
// Created on: <11-22-2006>
//
// COPYRIGHT NOTICE: Copyright (C) 2006 Blend Interactive
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file geocodertype.php
*/

/*!
  \class GeocoderType geocodertype.php
  \brief The GeocoderType class provides a workflow event to add a geocode index to an object.

*/
include_once( 'kernel/classes/ezorder.php' );
include_once( 'lib/ezutils/classes/ezhttptool.php' );

include_once( 'extension/locationfinder/classes/geocoderitem.php');
include_once( 'extension/locationfinder/classes/geocoder.php');

define( 'EZ_WORKFLOW_TYPE_GEOCODER_ID', 'geocoder' );

class GeocoderType extends eZWorkflowEventType
{
    /*!
     Constructor
    */
    function GeocoderType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_GEOCODER_ID, 'Geocoder' );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array ( 'after' ) ) ) );
    }

    function execute( &$process, &$event )
    {
        $ini =& eZINI::instance( 'workflow.ini' );
        
        $classes = $ini->variable( "GeocoderWorkflow", "GeocodeClasses");

        $parameters = $process->attribute( 'parameter_list' );
        $objectId = $parameters['object_id'];
        $object =& eZContentObject::fetch( $objectId );
		 
        $classIdentifier = $object->attribute('class_identifier');
        //If this isn't one of the classes we're looking for, skip it.
        if(!in_array($classIdentifier,$classes))
        {
            return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;		  	
        }        
        
        $locationFieldId = $ini->variable( "Geocode_" . $classIdentifier, "LocationField");
        $addressFieldIdsDirty = $ini->variable( "Geocode_" . $classIdentifier, "AddressFields");
        $addressFieldIds = array();
        foreach ( $addressFieldIdsDirty as $field ) 
        {
            $addressFieldIds[]=trim($field);
        }
        
        $version =& $object->version( $parameters['version'] );
        $objectAttributes = $version->attribute( 'contentobject_attributes' );
        
        $locationAttribute = null;
        $addressValues = array();
        $addressValue = null;
        $addressAttributes = array();
        $latitude = $longitude = null;
        
        foreach ( array_keys( $objectAttributes ) as $key )
        {
            $objectAttribute =& $objectAttributes[$key];
            $attribIdentifier = $objectAttribute->attribute('contentclass_attribute_identifier');

            if(in_array($attribIdentifier, $addressFieldIds))
            {
                $addressAttributes[$attribIdentifier]=$objectAttribute;
            }
            
            if($locationFieldId == $attribIdentifier && $objectAttribute->attribute('data_type_string') == 'ezgmaplocation')
            {
                $locationAttribute = $objectAttribute;
            }
            

        }
        

        //Use the location
        if ( $locationAttribute && $locationAttribute->attribute('has_content') )
        {
            $content = $locationAttribute->attribute('content');
  		    $latitude = $content->Latitude;
		    $longitude = $content->Longitude;
        }
        else
        {
            foreach ($addressFieldIds as $addressFieldId)
            {            
                $attrib = $addressAttributes[trim($addressFieldId)];

                if (is_object($attrib) && $attrib->attribute('has_content'))
                {
                    $addressValues[]=$attrib->attribute('content');
                }
            }
            $addressValue = implode(', ', $addressValues);

            $geocodeResult = GeoCoder::geocodeAddress($addressValue);

            $latitude = $geocodeResult['Latitude'];
            $longitude = $geocodeResult['Longitude'];
        }
        
        $geoItem = GeocoderItem::fetch( $objectId );

        if(is_object($geoItem))
        {
            $geoItem->setAttribute('latitude',$latitude);
            $geoItem->setAttribute('longitude',$longitude);
            
        }
        else
        {
            $geoItem =GeocoderItem::create($objectId, $latitude, $longitude);
        }
        $geoItem->store();

        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;		  	

        
    }
    
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_GEOCODER_ID, "geocodertype" );

?>
