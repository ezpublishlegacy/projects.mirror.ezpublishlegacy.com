[EventSettings]
ExtensionDirectories[]=locationfinder
AvailableEventTypes[]=event_geocoder

[GeocoderWorkflow]

# List the class identifiers for the classes that 
# you wish to have geocoded below.
# The geocoder will only run for the listed classes.
# Example: 
# GeocodeClasses[]
# GeocodeClasses[]=office
GeocodeClasses[]
GeocodeClasses[]=image

# For each geocoded class, you need to create a 
# Geocode_class section. This section defines
# what fields will be used to geocode the class

# For each class, there are two possible ways to 
# retrieve the lat/lon data. 
# You can set the LocationField object to an 
# attribute using the GMaps Location 
# datatype (the Gmaps Location Datatype is available
# here: http://ez.no/community/contribs/datatypes/google_maps_location_datatype )
# If LocationField or the attribute that it points to is null, 
# Then the system concatenates the data in the fields listed in 
# AddressFields array together and submits the results to the 
# Google Geocoder.
# Example:
# [Geocode_office]
# LocationField=location
# AddressFields[]
# AddressFields[]=address_1 
# AddressFields[]=city
# AddressFields[]=state
# AddressFields[]=zip

[Geocode_image]
LocationField=location
AddressFields[]
