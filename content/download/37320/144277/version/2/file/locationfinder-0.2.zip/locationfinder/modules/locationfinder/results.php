<?php
	 
include_once( 'kernel/common/template.php' );
include_once( 'extension/locationfinder/classes/geocoderitem.php');
include_once( 'extension/locationfinder/classes/geocoder.php');
	 
$http =& eZHTTPTool::instance();
$query=$Params['query'];
$tpl =& templateInit();

$coords = Geocoder::geocodeAddress($query);

$locations = GeocoderItem::fetchClosest($coords['Latitude'], $coords['Longitude'], array('ClassFilterType'=>'include','ClassFilterArray'=>array('image')));

// Module return value,
// normally fetched from template
$tpl->setVariable( 'locations', $locations );
$tpl->setVariable( 'search_point',$coords );
$tpl->setVariable( 'query', $query);
$text =& $tpl->fetch( 'design:locationfinder/results.tpl' );

// Build module result array
$Result = array();
$Result['content'] = $text;
$Result['path'] = array( array( 'url' =>  '/','text' => "Home"),
array( 'url' => false, 'text' => "Locator"));



?> 