Location Finder Extension
Version 0.2
Developed by Blend Interactive
http://blendinteractive.com
----------------------
The locationfinder extension allows you to easily create 'find the nearest X' 
applications using eZ Publish (e.g. Find the nearest store location.)

It does this by assigning location data (latitude and longitude) to eZ publish
objects using a workflow event. A module is then provided that will query this
location data and return a list of the closest objects, as well as their 
distance.

Location data is assigned in one of two ways: 
 -- If you have Blend's Gmaps Location Datatype on your object, the workflow 
    event will read the lat/lon data directly from that attribute. You can get
    Blend's Gmaps datatype here: 
    http://ez.no/community/contribs/datatypes/google_maps_location_datatype
    
 -- If you don't have the Gmaps datatype, the workflow event can ask Google 
    to geocode your object by concatenating a number of attributes together.
    For instance, if your object has attributes called 'address_1', 'city', 
    'state', and 'zip', and they're set to '123 Test St', 'Sioux Falls', 
    'SD',' and '57104' respectively, you can configure the workflow event to 
    ask Google's API to geocode '123 Test St, Sioux Falls, SD, 57104'.       

Installation
---------------

1.) Obtain a Google Maps Key for all domains you'll be using by registering 
your domains with Google at http://www.google.com/apis/maps/

2.) Upload the locationfinder folder to the extensions folder in your 
eZ Publish installation.

3.) Execute the included sql/locationfinder.sql file in your eZ Publish 
database. This creates a table called 'geocoder_item'.  

4.) Activate the extension from the 'Extensions' portion of the 
'Setup' tab in the eZ publish admin interface.

5.) Add your GmapsKey to the site.ini under [SiteSettings] like so: 
GMapsKey=<Long string of characters from Google>

6.) Read the configuration notes below and configure the workflow event 
using settings/workflow.ini or the appropriate override.

7.) Create a new workflow from the eZ Publish admin's Setup tab and add  
the 'Event/Geocoder' item to the workflow.

8.) Set the content/publish/after workflow trigger to point to your new workflow.

9.) Grant permissions to the anonymous role for the locationfinder (assuming you 
want anonymous users to use it). 

Configuration
---------------

The first step is determining what objects you would like to use for geocoding.
In a business scenario, the most likely candidates will be stores or business
locations, so let's assume that you want to find the nearest stores. 

First, you'd create a class called 'Store' like this: 

Store (identifier: store)
Name       Identifier         Type
-------------------------------------------------
Name       name               [string]
Address 1  address_1          [string]
Address 2  address_2          [string]
City       city               [string]
State      state              [string]
Zip Code   zip                [string]
Location   location           [Gmaps Location]
Phone      phone              [string]
Fax        fax                [string]
Hours      hours              [text]

Note that the 'location' attribute is a Gmaps Location attribute provided 
by the Gmaps Location Datatype extension, and is optional (but cool).

To configure this item in the geocoder, we'll edit 
settings/override/workflow.ini.append.php, and add the following: 
----------------------------------------------------
[GeocoderWorkflow]
GeocodeClasses[]
GeocodeClasses[]=store 

[Geocode_store]
LocationField=location
AddressFields[]
AddressFields[]=address_1
AddressFields[]=city
AddressFields[]=state
AddressFields[]=zip
------------------------------------------------------
(documentation for the ini syntax is in this extension's workflow.ini file)

In this configuration, the extension will use the 'location' attribute to 
retrieve the latitude and longitude whenever possible. Failing that, it will
assemble the contents of the address_1, city, state, and zip datatypes 
together into a comma-delimited string and send it to Google's API to try and 
get a latitude/longitude value. 

Use
---------------
Visitors can query the 'find nearest' data by going to '/locationfinder/search'
in your eZ site. From there they can enter anything Google will turn into a 
latitude and longitude (zip codes work well), and get the closest items in your
database to the point that they searched for.

Template authors can also use a couple of fetch functions to utilize location
data in their templates.

{fetch ('locationfinder','closest_to_point', hash(
latitude, <latitude of the search point>,
longitude, <longitude of the search point>,
offset, <offset>,
limit, <limit>,
class_filter_type, <include or exclude>,
class_filter_array, <filter array>
))}

{fetch ('locationfinder','closest_to_object', hash(
object_id, <id of a geolocated object>,
offset, <offset>,
limit, <limit>,
class_filter_type, <include or exclude>,
class_filter_array, <filter array>
))}

(The object passed in must be one that's been geolocated for closest_to_object to work.)

Notes
---------------
A couple of points: 

-- This extension is still a bit experimental and is of alpha quality. I don't 
   think it will start anything on fire, but, you know...
   
-- In the interests of speed, the algorithm used to select the closest point
   is pretty simplistic. Certain situations may arise in which it doesn't
   strictly return the closest point, but these errors would only occur over 
   very large distances (like across the pacific).
   
   