<?php
//
// Definition of GeocoderItem class
//
// Created on: <11-22-2006>
//
// COPYRIGHT NOTICE: Copyright (C) 2006 Blend Interactive
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file geocoderitem.php
*/

/*!
  \class GeocoderItem geocoderitem.php
  \brief The GeocoderItem class is a persistent object used to store the
  geolocation of eZ Publish content objects. It is typically maintained 
  by the Geocoder Workflow Event.

*/

include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'extension/locationfinder/classes/geocoder.php');
class GeocoderItem extends eZPersistentObject
{

    var $_searchDist;
    function GeocoderItem($row)
    {
        $this->eZPersistentObject( $row );
        $this->_searchDist = -1;
    }
    
    function definition()
    {
        return array( 'fields' => array( 'contentobject_id' => array( 'name' => 'ContentObjectID',
                                                                      'datatype' => 'integer',
                                                                      'default' => 0,
                                                                      'required' => true ),
                                         'latitude' => array( 'name' => 'Latitude',
                                                           'datatype' => 'float',
                                                           'default' => 0.0,
                                                           'required' => true ),
                                         'longitude' => array( 'name' => 'Longitude',
                                                           'datatype' => 'float',
                                                           'default' => 0.0,
                                                           'required' => true ) ),
                      'keys' => array( 'contentobject_id' ),
                      'function_attributes' => array( 'contentobject' => 'contentObject',
                                                      'object' => 'contentObject',
                                                      'miles_from_search' => 'milesFromSearch'),
                      'relations' => array( 'contentobject_id' => array( 'class' => 'ezcontentobject',
                                                                         'field' => 'id' ) ),
                      'class_name' => 'GeocoderItem',
                      'name' => 'geocoder_item' );
    } 


    function create( $contentObjectID, $latitude, $longitude )
    {
        $row = array(
            'contentobject_id' => $contentObjectID,
            'latitude' => $latitude,
            'longitude' => $longitude
            );
        return new GeocoderItem( $row );
    }    

    function fetch( $id, $asObject = true )
    {
        return eZPersistentObject::fetchObject( GeocoderItem::definition(),
                                                null,
                                                array( 'contentobject_id' => $id ),
                                                $asObject );
    }

    function &contentObject()
    {
        if ( isset( $this->ContentObjectID ) and $this->ContentObjectID )
        {
            include_once( 'kernel/classes/ezcontentobject.php' );
            $object =& eZContentObject::fetch( $this->ContentObjectID );
        }
        else
            $object = null;
        return $object;
    } 
    
    /* function milesFromSearch 
     * If the GeocoderItem was returned as part of an array by the fetchClosest 
     * function, then the milesFromSearch function will return the distance in 
     * miles from the point provided in the search to this object. 
     * If fetchClosest was not used, milesFromSearch will return false.
     */    
    function milesFromSearch()
    {
        if ($this->_searchDist > 0)
        {        
            return $this->_searchDist * 69.09;
        }
        else
        {
            return false;
        }
    }
    
    /* function fetchClosest
     * fetchClosest returns an array of GeocoderItem objects in order of 
     * increasing distance from the point provided in the $latitude and 
     * $longitude parameters. 
     */
    function &fetchClosest($latitude, $longitude, $params)
    {
    
        $db =& eZDB::instance();
        
        $offset           = ( isset( $params['Offset'] ) && is_numeric( $params['Offset'] ) ) ? $params['Offset'] + 1             : 1;
        $limit            = ( isset( $params['Limit']  ) && is_numeric( $params['Limit']  ) ) ? $params['Limit']              : false;

        $classCondition          = eZContentObjectTreeNode::createClassFilteringSQLString( $params['ClassFilterType'], $params['ClassFilterArray'] );
        if ( $classCondition === false )
        {
            eZDebug::writeNotice( "Class filter returned false" );
            $retValue = null;
            return $retValue;
        }
        
        $sql = "SELECT 
                    geocoder_item.*
                FROM 
                    geocoder_item,
                    ezcontentobject,
                    ezcontentclass
                    $attributeFilter[from]                    
                WHERE
                    geocoder_item.contentobject_id = ezcontentobject.id AND
                    ezcontentclass.id = ezcontentobject.contentclass_id AND
                    $attributeFilter[where]
                    $classCondition  
                    1=1                       
                ORDER BY SQRT(POW(latitude - $latitude, 2) + POW(longitude - $longitude,2))";    

        $rows = null;                    
        if ( !$offset && !$limit )
        {
            $rows = $db->arrayQuery( $sql );
        }
        else
        {
            $rows = $db->arrayQuery( $sql, array( 'offset' => $offset,
                                                              'limit'  => $limit ) );
        }

        $list = array();
        foreach ( $rows as $row )
        {
            $item = new GeocoderItem( $row );
            $item->_searchDist = $item->DistanceFrom($latitude, $longitude);
            $list[] = $item;         
        }
        return $list;        
    }
    
    function DistanceFrom($latitude, $longitude)
    {
        $lat_A = $latitude;
        $long_A = $longitude;
        $lat_B = $this->attribute('latitude');
        $long_B = $this->attribute('longitude');
        
        $distance = sin(deg2rad($lat_A))
                * sin(deg2rad($lat_B))
                + cos(deg2rad($lat_A))
                * cos(deg2rad($lat_B))
                * cos(deg2rad($long_A - $long_B));
        
        $distance = (rad2deg(acos($distance)));
        
        return $distance;        
    }              

}

?>