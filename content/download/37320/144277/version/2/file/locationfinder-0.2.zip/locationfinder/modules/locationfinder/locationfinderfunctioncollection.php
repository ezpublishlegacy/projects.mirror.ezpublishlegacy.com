<?php

class LocationFinderFunctionCollection
{
    function LocationFinderFunctionCollection()
    {
    }
    
    function closestToPoint ( $latitude, $longitude, $offset, $limit, $class_filter_type, $class_filter_array)
    {
        include_once( 'extension/locationfinder/classes/geocoderitem.php' );
        $parameters = array( 'Offset' => $offset,
                             'Limit' => $limit,
                             'ClassFilterType' => $class_filter_type,
                             'ClassFilterArray' => $class_filter_array );
        
        $items = GeocoderItem::fetchClosest($latitude, $longitude, $parameters);
        
        return array('result'=>$items);            
        
    }
    
    function closestToObject ( $object_id, $offset, $limit, $class_filter_type, $class_filter_array)
    {

        include_once( 'extension/locationfinder/classes/geocoderitem.php' );
        $object = GeocoderItem::fetch($object_id);
        
        if ($object === null)
        {
            $result = array( 'error' => array( 'error_type' => 'kernel',
                                               'error_code' => EZ_ERROR_KERNEL_NOT_FOUND ) );
            return $result;
        }
        
        $latitude = $object->attribute('latitude');
        $longitude = $object->attribute('longitude');
        
        $result= LocationFinderFunctionCollection::closestToPoint ( $latitude, $longitude, $offset, $limit, $class_filter_type, $class_filter_array);
        
        return $result;
        
    }
}
?>