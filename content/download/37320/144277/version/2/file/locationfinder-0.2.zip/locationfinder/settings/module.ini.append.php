[ModuleSettings]
ExtensionRepositories[]=locationfinder