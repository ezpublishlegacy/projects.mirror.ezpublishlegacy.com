<?php
	 
include_once( 'kernel/common/template.php' );
include_once( 'extension/ezsurvey/modules/survey/classes/ezsurvey.php' );
include_once( 'kernel/classes/ezcontentobject.php' );

$Module =& $Params['Module'];

$error=false;

if ($_POST['query'])
{
	$query = trim($_POST['query']);
	//Validate query
	if ($query != '')
	{
		$Module->redirectTo( '/locationfinder/results/' . $query );
		return;
	}
	else
	{
		$error = "Please enter a postal code, address, or place.";
	}
}
// Module return value,
// normally fetched from template
$tpl =& templateInit();
$tpl->setVariable( 'error', $error );
$tpl->setVariable( 'query', $query );

$text =& $tpl->fetch( 'design:locationfinder/search.tpl' );

// Build module result array
$Result = array();
$Result['content'] = $text;
$Result['path'] = array( array( 'url' =>  '/','text' => "Home"),
						array( 'url' => false, 'text' => "Locator"));
?> 