CREATE TABLE `geocoder_item` (
`contentobject_id` INT NOT NULL ,
`latitude` DOUBLE NOT NULL ,
`longitude` DOUBLE NOT NULL ,
PRIMARY KEY ( `contentobject_id` ) ,
INDEX ( `latitude` , `longitude` )
);
