<?php
$Module = array( "name" => "locationfinder" );

$ViewList = array();

$ViewList["search"] = array(
'functions'=>array('use'),
"script" => "search.php" );

$ViewList["results"] = array(
'functions'=>array('use'),
"script" => "results.php",
'params' => array('query'));

$FunctionList['use'] = array( );

?>
