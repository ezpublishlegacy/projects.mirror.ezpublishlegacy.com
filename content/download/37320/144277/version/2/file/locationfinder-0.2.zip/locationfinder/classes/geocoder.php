<?php
//
// Definition of Geocoder class
//
// Created on: <11-22-2006>
//
// COPYRIGHT NOTICE: Copyright (C) 2006 Blend Interactive
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file geocoder.php
*/

/*!
  \class Geocoder geocoder.php
  \brief The Geocoder class is a utility singleton for deriving 
   latitude/longitude data from an input query using Google Maps.

*/
include_once( 'lib/ezxml/classes/ezxml.php' );
class Geocoder
{
    function Geocoder()
    {
    }
    
    /* 
     * function geocodeAddress
     * geocodeAddress() handles the query of Google Maps for address data.
     * input parameters: $address - a string query to google Maps
     * returns: a 3-element hash containing: 
     *           * Latitude - returned latitude
     *           * Longitude - returned longitude
     *           * status - the status code returned by Google
     */
    function geocodeAddress($address)
    {
        $http = eZHTTPTool::instance();
        $ini =& eZINI::instance( 'site.ini' );
        $apiKey = $ini->variable( "SiteSettings", "GMapsKey");
        $uri = 'http://maps.google.com/maps/geo?q=' . urlencode($address) . '&key=' . $apiKey . '&output=xml';
        $response = $http->sendHTTPRequest($uri, 80, false, 'eZ publish', false);
        $header = $body = null;
        $http->parseHTTPResponse( $response, $header, $body );
        $xml = new eZXML();
        $xmlString = $body;

        $dom =& $xml->domTree( $xmlString );
        if ( $xmlString != "" )
        {
            $rootElement =& $dom->root( );
            $response = $rootElement->elementByName('Response');
            $status = $response->elementByName('Status');
            $statusCode=$status->elementTextContentByName('code');
            $coords = null;
            if($statusCode == '200')
            {
                $placeMark = $response->elementByName('Placemark');
                $point = $placeMark->elementByName('Point');
                $coords = $point->elementTextContentByName('coordinates');
                $coordArray=explode(',',$coords);                
                return array('Latitude'=>$coordArray[1], 'Longitude'=>$coordArray[0], 'status'=>$statusCode);                
            }
            return array('Latitude'=>0.0,'Longitude'=>0.0, 'status'=>$statusCode);
        }
        else
        {
            return array('Latitude'=>0.0,'Longitude'=>0.0, 'status'=>$statusCode);
        }        

    }    
}
?>