<?php
/**
 *
 * @version $Id: mib.php 79 2010-01-17 10:39:48Z gg $
 * @author Gaetano Giunta
 * @copyright (c) 2009 G. Giunta
 * @license code licensed under the GPL License: see README
 */

header( 'Content-Type: text/plain' );

$server = new eZSNMPd();
echo $server->getFullMIB();

eZExecution::cleanExit();

?>