var classeZPerfLoggerMonologLogger =
[
    [ "doLog", "classeZPerfLoggerMonologLogger.html#a6e6f1e87cc1841f7fe39f8cb1e5d70f1", null ],
    [ "supportedLogMethods", "classeZPerfLoggerMonologLogger.html#a83e09162f10a7debf289058958b1e4e4", null ]
];