var classeZImageTracing47ShellFactory =
[
    [ "eZImageTracing47ShellFactory", "classeZImageTracing47ShellFactory.html#a2a05e9f3601cd77f0e5ce5579554bdbd", null ],
    [ "produceFromINI", "classeZImageTracing47ShellFactory.html#a320dc30dc13dcd16a73c547361c6b48b", null ]
];