var classeZMySQLiTracing45DB =
[
    [ "arrayQuery", "classeZMySQLiTracing45DB.html#ac3713c3352efd2498c777eb273a04f64", null ],
    [ "connect", "classeZMySQLiTracing45DB.html#a0b1503e22af7d5032670f51530dcc465", null ],
    [ "measure", "classeZMySQLiTracing45DB.html#a0e864a86637b426e7eedec6d8e520fff", null ],
    [ "query", "classeZMySQLiTracing45DB.html#af0402a81dddd48daa91e509a944f8667", null ]
];