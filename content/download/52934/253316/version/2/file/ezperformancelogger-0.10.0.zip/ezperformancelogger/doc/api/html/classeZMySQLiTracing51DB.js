var classeZMySQLiTracing51DB =
[
    [ "arrayQuery", "classeZMySQLiTracing51DB.html#aca762e721b44c2f32336be3cae2af36d", null ],
    [ "connect", "classeZMySQLiTracing51DB.html#af02d8fb591653ad89de23d05b164d202", null ],
    [ "measure", "classeZMySQLiTracing51DB.html#a7d98da521ea03dce3c822c1dd4f4ec43", null ],
    [ "query", "classeZMySQLiTracing51DB.html#a689aec44ef4f6485e72ea3342f72a6e6", null ]
];