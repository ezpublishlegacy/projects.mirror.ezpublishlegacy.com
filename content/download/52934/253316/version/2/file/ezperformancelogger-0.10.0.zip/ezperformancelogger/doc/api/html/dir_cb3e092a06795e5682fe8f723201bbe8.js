var dir_cb3e092a06795e5682fe8f723201bbe8 =
[
    [ "display.php", "munin_2display_8php.html", "munin_2display_8php" ],
    [ "module.php", "munin_2module_8php.html", "munin_2module_8php" ]
];