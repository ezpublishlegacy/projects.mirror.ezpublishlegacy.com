<?php /*
 
[TemplateSettings]
ExtensionAutoloadPath[]=ezsh

*/ ?>