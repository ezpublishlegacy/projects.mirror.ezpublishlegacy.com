<?php /* 

[ExtensionSettings]
DesignExtensions[]=ezsh

*/ ?>
