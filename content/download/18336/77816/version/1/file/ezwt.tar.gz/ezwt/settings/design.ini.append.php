<?php /*

[ExtensionSettings]
DesignExtensions[]=ezwt

*/ ?>
