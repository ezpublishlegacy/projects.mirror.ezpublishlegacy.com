<?php

class myPurchasesOperator
{
    var $Operators;

    function myPurchasesOperator()
    {
	$this->Operators = array( "my_purchases" );
    }


    function operatorList()
    {
	return $this->Operators;
    }


    function namedParameterPerOperator()
    {
        return true;
    }   

    function namedParameterList()
    {
        return array( 'my_purchases' => array() );
    }


    function modify( $tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        if (get_class($operatorValue) == 'eZUser') {
            $output = array();
            foreach (eZOrder::activeByUserID( $operatorValue->id() ) as $this_order) {
                foreach ($this_order->productItems() as $this_product) {
		      $output[$this_product["item_object"]->attribute('contentobject_id')] = $this_order->statusName();
                }
            }
            $operatorValue = $output;
            return true;
        } else {
            $operatorValue = '';
            eZDebug::writeDebug("Variable passed to $operatorName is not an eZUser object");
            return false;
        }
    }
}

?>
