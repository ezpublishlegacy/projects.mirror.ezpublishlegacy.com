<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/tc_mypurchases/my_purchasesoperator.php',
                                    'class' => 'myPurchasesOperator',
                                    'operator_names' => array( 'my_purchases' ) );

?>