<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsannotation
ModuleList[]=groupdocsannotation
*/ ?>