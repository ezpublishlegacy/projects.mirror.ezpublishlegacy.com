<?php
 
// Which operators will load automatically? 
$eZTemplateOperatorArray = array();
 
// Operator: gaddata 
$eZTemplateOperatorArray[] = array( 'class' => 'GADOperator',
                                    'operator_names' => array( 'gad' ) ); 
?>