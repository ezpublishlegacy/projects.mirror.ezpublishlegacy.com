<?php /*

[RepositorySettings]
# Keys of repositories
RepositoryList[]
RepositoryList[default]=ROOT
RepositoryList[]=MEDIA

[ROOT]
Name=Main repository
Description=
RootNode=2
SpecificInformation=
# A string that MAY describe how this repository relates to other repositories.
# Perhaps there should be sibling
Relationship=self

[MEDIA]
Name=Media repository
Description=
RootNode=43
SpecificInformation=
Relationship=self


*/ ?>