<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=pageflip

[pageflip]
Reference=original


*/ ?>
