<?php /* #?ini charset="utf-8"?

[cjw_contexthelp_class_datatype_edit_ez_class_identifer]
Source=content/datatype/edit/ezstring.tpl
MatchFile=datatype/edit/cjw_contexthelp_class_ez_class_identifier.tpl
Subdir=templates
Match[class_identifier]=cjw_contexthelp_class
Match[attribute_identifier]=ez_class_identifier

[cjw_contexthelp_class_attribute_datatype_edit_ez_class_attribute_identifer]
Source=content/datatype/edit/ezstring.tpl
MatchFile=datatype/edit/cjw_contexthelp_class_attribute_ez_class_attribute_identifier.tpl
Subdir=templates
Match[class_identifier]=cjw_contexthelp_class_attribute
Match[attribute_identifier]=ez_class_attribute_identifier

*/ ?>