<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=cjw_contexthelp
AvailableDataTypes[]=cjwfieldset

*/ ?>