<?php

class CjwFieldsetType extends eZDataType
{
    const DATA_TYPE_STRING = 'cjwfieldset';

    // 0 - standard, 1 - fieldset without label, 2 - fieldset end
    const CLASS_MODE_DB_FIELD = 'data_int1';
    const CLASS_MODE_VARIABLE = '_cjwfieldset_mode_';
    const CLASS_LEGEND_DB_FIELD = 'data_int2';
    const CLASS_LEGEND_VARIABLE = '_cjwfieldset_legend_';
    const CLASS_CLOSE_DB_FIELD = 'data_int3';
    const CLASS_CLOSE_VARIABLE = '_cjwfieldset_close_';


    function __construct()
    {
        $this->eZDataType( self::DATA_TYPE_STRING, ezi18n( 'extension/cjw_contexthelp/datatypes', 'CJW Fieldset' , 'Datatype name' ),
                           array( 'serialize_supported' => true, 'translation_allowed' => true ) );
    }


    function initializeObjectAttribute( $contentObjectAttribute, $currentVersion, $originalContentObjectAttribute )
    {
    }


    function validateObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        return eZInputValidator::STATE_ACCEPTED;
    }


    function fetchObjectAttributeHTTPInput( $http, $base, $contentObjectAttribute )
    {
        return false;
    }


    function storeObjectAttribute( $attribute )
    {
    }


    function storeDefinedClassAttribute( $attribute )
    {
    }


    function initializeClassAttribute( $classAttribute )
    {
    }


    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        return eZInputValidator::STATE_ACCEPTED;
    }

    function fixupClassAttributeHTTPInput( $http, $base, $classAttribute )
    {

    }


    function storeClassAttribute( $attribute, $version )
    {

    }


    /*
        fetch $_POST vars and set
    */
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        $postModeName = $base . self::CLASS_MODE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $postModeName ) )
        {
            $modeValue = (int) $http->postVariable( $postModeName );
            $classAttribute->setAttribute( self::CLASS_MODE_DB_FIELD , $modeValue );

        }
        $postLegendName = $base . self::CLASS_LEGEND_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $postLegendName ) )
        {
            $legendValue = (int) $http->postVariable( $postLegendName );
            $classAttribute->setAttribute( self::CLASS_LEGEND_DB_FIELD , $legendValue );

        }
        $postCloseName = $base . self::CLASS_CLOSE_VARIABLE . $classAttribute->attribute( 'id' );
        if ( $http->hasPostVariable( $postCloseName ) )
        {
            $closeValue = (int) $http->postVariable( $postCloseName );
            $classAttribute->setAttribute( self::CLASS_CLOSE_DB_FIELD , $closeValue );
        }

        return true;
    }

    /*!
     Returns the content data for the given content class attribute.
    */
    function classAttributeContent( $classAttribute )
    {
        $mode_id = (int) $classAttribute->attribute( self::CLASS_MODE_DB_FIELD );
        $legend_id = (int) $classAttribute->attribute( self::CLASS_LEGEND_DB_FIELD );
        $close_id = (int) $classAttribute->attribute( self::CLASS_CLOSE_DB_FIELD );

        return array( 'current_mode_id' => $mode_id,
                      'available_mode_ids' => array(    1 => '1 standard - START',
                                                        0 => '0 STOP'),
                      'current_legend_id' => $legend_id,
                      'available_legend_ids' => array(  1 => '1 standard - show legend',
                                                        0 => '0 disable legend' ),
                      'current_close_id' => $close_id,
                      'available_close_ids' => array(   1 => '1 standard - only close previous fieldset',
                                                        2 => '2 all - all open fieldsets',
                                                        0 => '0 none - none to open a sub-fieldset' ),

                      );
    }


    function isIndexable()
    {
        return false;
    }


    function isInformationCollector()
    {
        return false;
    }



        /*!
     \reimp
    */
    function serializeContentClassAttribute( $classAttribute, $attributeNode, $attributeParametersNode )
    {

        $mode_id = (int) $classAttribute->attribute( self::CLASS_MODE_DB_FIELD );
        $legend_id = (int) $classAttribute->attribute( self::CLASS_LEGEND_DB_FIELD );
        $close_id = (int) $classAttribute->attribute( self::CLASS_CLOSE_DB_FIELD );

        $dom = $attributeParametersNode->ownerDocument;
        $modeIdElement = $dom->createElement( 'mode_id', $mode_id );
        $legendIdElement = $dom->createElement( 'legend_id', $legend_id );
        $closeIdElement = $dom->createElement( 'close_id', $close_id );

        $attributeParametersNode->appendChild( $modeIdElement );
        $attributeParametersNode->appendChild( $legendIdElement );
        $attributeParametersNode->appendChild( $closeIdElement );

    }

    /*!
     \reimp
    */
    function unserializeContentClassAttribute( $classAttribute, $attributeNode, $attributeParametersNode )
    {
        //$mode_id = (int) $classAttribute->attribute( self::CLASS_MODE_DB_FIELD );
        //$legend_id = (int) $classAttribute->attribute( self::CLASS_LEGEND_DB_FIELD );
        //$close_id = (int) $classAttribute->attribute( self::CLASS_CLOSE_DB_FIELD );

        $mode_id = (int) $attributeParametersNode->getElementsByTagName( 'mode_id' )->item( 0 )->textContent;
        $legend_id = (int) $attributeParametersNode->getElementsByTagName( 'legend_id' )->item( 0 )->textContent;
        $close_id = (int) $attributeParametersNode->getElementsByTagName( 'close_id' )->item( 0 )->textContent;


        $classAttribute->setAttribute( self::CLASS_MODE_DB_FIELD, $mode_id );
        $classAttribute->setAttribute( self::CLASS_LEGEND_DB_FIELD, $legend_id );
        $classAttribute->setAttribute( self::CLASS_CLOSE_DB_FIELD, $close_id );
    }

}

eZDataType::register( CjwFieldsetType::DATA_TYPE_STRING, 'CjwFieldsetType' );

?>