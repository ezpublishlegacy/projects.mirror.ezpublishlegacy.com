var files =
[
    [ "ezinfo.php", "ezinfo_8php.html", null ],
    [ "bin/php/updateperfstats.php", "bin_2php_2updateperfstats_8php.html", "bin_2php_2updateperfstats_8php" ],
    [ "classes/ezperflogger.php", "ezperflogger_8php.html", null ],
    [ "classes/ezperfloggercsvstorage.php", "ezperfloggercsvstorage_8php.html", null ],
    [ "cronjobs/updateperfstats.php", "cronjobs_2updateperfstats_8php.html", "cronjobs_2updateperfstats_8php" ],
    [ "interfaces/ezperfloggerprovider.php", "ezperfloggerprovider_8php.html", null ],
    [ "interfaces/ezperfloggerstorage.php", "ezperfloggerstorage_8php.html", null ]
];