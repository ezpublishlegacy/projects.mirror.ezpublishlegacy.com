var classeZPerfLogger =
[
    [ "filter", "classeZPerfLogger.html#ac1709f4338f17af91eaf86b6dc021c5d", null ],
    [ "measure", "classeZPerfLogger.html#a9edd95d7316916a12f074e43faf102d8", null ],
    [ "parseLog", "classeZPerfLogger.html#af8890aea173779b43b46d4306b9fe8f5", null ],
    [ "recordValue", "classeZPerfLogger.html#a26375ce3a77d6cbdafb106c351aa6961", null ],
    [ "$custom_variables", "classeZPerfLogger.html#a0c79904ce0043c976652c698f0e635df", null ]
];