var hierarchy =
[
    [ "eZPerfLogger", "classeZPerfLogger.html", null ],
    [ "eZPerfLoggerProvider", "interfaceeZPerfLoggerProvider.html", null ],
    [ "eZPerfLoggerStorage", "interfaceeZPerfLoggerStorage.html", [
      [ "eZPerfLoggerCSVStorage", "classeZPerfLoggerCSVStorage.html", null ]
    ] ],
    [ "eZperformanceloggerInfo", "classeZperformanceloggerInfo.html", null ]
];