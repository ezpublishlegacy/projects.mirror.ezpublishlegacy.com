var searchData=
[
  ['info',['info',['../classeZperformanceloggerInfo.html#a58a9b0ad80ed28ec99e6c910996fc6e7',1,'eZperformanceloggerInfo']]],
  ['insertstats',['insertStats',['../classeZPerfLoggerCSVStorage.html#a224bc5b9b7e4e68efd1b97ad28ac87ed',1,'eZPerfLoggerCSVStorage\insertStats()'],['../interfaceeZPerfLoggerStorage.html#ae9d081fbe8ea531a67c713ae23bef307',1,'eZPerfLoggerStorage\insertStats()']]]
];
