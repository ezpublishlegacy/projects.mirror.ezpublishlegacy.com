<?php /*

[OutputSettings]
OutputFilterName=eZPerfLogger

*/ ?>