<?php

$FunctionList = array();

$FunctionList['object_count_date'] = array(
								'name' => 'object_count_date',
								'operation_types' => array( 'read' ),
								'call_method' => array(
														'include_file' => 'extension/objectcountdate/classes/ObjectCountDate.php',
														'class' => 'ObjectCountDate',
														'method' => 'fetchObjectCountDate'
													),
								'parameter_type' => 'standard',
								'parameters' => array( array( 'name' => 'class_id',
                                                                        'type' => 'integer',
                                                                        'required' => true,
                                                                        'default' => 0 ),
                                                       array( 'name' => 'date_from',
                                                                        'type' => 'integer',
                                                                        'required' => false,
                                                                        'default' => 0 ),
                                                       array( 'name' => 'date_to',
                                                                        'type' => 'integer',
                                                                        'required' => false,
                                                                        'default' => 0 ) )
							);

?>