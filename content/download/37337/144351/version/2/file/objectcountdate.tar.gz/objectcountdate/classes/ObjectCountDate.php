<?php

class ObjectCountDate
{
	function fetchObjectCountDate( $classID, $dateFrom, $dateTo )
	{

	$objectCount = 0;

        if ( is_numeric( $classID ) and is_numeric( $dateFrom ) and is_numeric( $dateTo ) )
        {
            $db =& eZDB::instance();

            $where =(int) $classID;
            $dateFrom =(int) $dateFrom;
            $dateTo =(int) $dateTo;

            $where_time = '';
            if ($dateFrom != 0)
            {
            	$where_time .= " AND published > '$dateFrom'";
            }
            if ($dateTo != 0)
            {
            	$where_time .= " AND published < '$dateTo'";
            }
            
            $countArray = $db->arrayQuery( "SELECT count(*) AS count 
            					FROM ezcontentobject 
            					WHERE contentclass_id = $where  
            					$where_time" 
            				 );
            
            $objectCount = $countArray[0]['count'];
        }
        
        return $objectCount;
	}
}

?>