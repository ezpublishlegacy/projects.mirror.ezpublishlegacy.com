<?php /*

[ModuleSettings]
ExtensionRepositories[]=objectcountdate

*/ ?>