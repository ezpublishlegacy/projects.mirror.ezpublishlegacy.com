----------------------------------------------------------------
                       Webdav locks support
----------------------------------------------------------------

What is it?
-----------
This extension provides a lock support for ezWebdav (the webdav server embedded in ezPublish).
It will allow users to place locks on resources, preventing conflicts between users editing contents.
On a technical point, the PEAR Webdav Server classes (version 1.0rc2) were used to implement it. This was mainly testes with cadaver (http://www.webdav.org/cadaver) to ensure about webdav standards.

Installation
------------
* Create the table 'ezwebdav_locks' using the sql file given in the archive. This will be used to store locks tokens.
* Patch the ezWebdav server: 
   - With patch file:
      Copy the file 'webdav_locks.patch' in your ezpublish directory
      Get a console, go in your ezpublish folder and type
        bash#  patch -p0 < webdavLocks.patch
   - With source files:
      Overwrite the source files given in the archive (folders 'lib' and 'kernel').

Notes
-----
The files are based on ezpublish version 3.6.5, but I don't think there are changes made in webdav related files on 3.6.x and 3.7.x series.
This hack is distributed under the terms of the GNU/GPL License. Feel free to use and improve it!

Author
------
Alexandre Nion ( alexandre.nion@linagora.com )
The extension is based on the shoulders of PEAR Webdav Server classes ( http://pear.php.net/package/HTTP_WebDAV_Server ), maintained by Hartmut Holzgraefe and Christian Stocker
