<?/*

[users_class_group_override]
Source=node/view/full.tpl
MatchFile=node/view/full_caching_disabled.tpl
Subdir=templates
Match[class_group]=2

*/ ?>
