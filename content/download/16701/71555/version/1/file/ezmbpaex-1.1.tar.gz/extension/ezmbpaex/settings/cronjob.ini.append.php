<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezmbpaex

[CronjobPart-send_expiry_notifications]
Scripts[]
Scripts[]=sendexpirynotifications.php

[CronjobPart-updatechildren]
Scripts[]
Scripts[]=updatechildren.php

*/ ?>
