<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=ezmbpaex

*/ ?>
