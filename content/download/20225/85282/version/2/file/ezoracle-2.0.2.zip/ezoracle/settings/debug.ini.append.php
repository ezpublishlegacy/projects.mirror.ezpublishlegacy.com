<?php /*
[GeneralCondition]
kernel-db-oracle=disabled
*/ ?>