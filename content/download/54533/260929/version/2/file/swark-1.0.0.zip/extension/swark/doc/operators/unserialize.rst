unserialize
-----------

Summary
~~~~~~~
Returns the value previously stored by the serialize operator.

Usage
~~~~~
::

    input|unserialize

Parameters
~~~~~~~~~~
None.

Examples
~~~~~~~~
See examples of the serialize operator.
