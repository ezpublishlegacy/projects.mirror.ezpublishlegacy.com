<?php /* #?ini charset="iso-8859-1"?

[EventSettings]
ExtensionDirectories[]=swark
AvailableEventTypes[]=event_autopriority
AvailableEventTypes[]=event_defertocron

*/ ?>
