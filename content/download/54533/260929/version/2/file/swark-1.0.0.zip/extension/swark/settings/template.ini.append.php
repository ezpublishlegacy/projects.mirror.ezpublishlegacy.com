<?php /* #?ini charset="iso-8859-1"?

[PHP]
PHPOperatorList[serialize]=serialize
PHPOperatorList[unserialize]=unserialize

*/ ?>
