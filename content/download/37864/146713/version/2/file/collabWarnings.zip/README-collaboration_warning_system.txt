Collaboration Warning System
----------------------------

*********
* Intro *
*********

Instead of having to remember to check the collaboration system for new messages, use this modification
to be reminded of new messages. It'll display a red box wherever you are in the admin interface as soon
as you have received a new message.

This is possible thanks to a few simple template modifications, no PHP programming required.

Translation of the messages is possible. This modification will add 6 strings to the translation file for
the design/standard/collaboration part.


*****************************
* Installation Instructions *
*****************************

1) Open the file "design/<admin design>/templates/pagelayout.tpl"

2) Search for "{* Main area START *}"

3) Between that line and "{include uri='design:page_mainarea.tpl}" add this:

  {let unread_count=count(fetch("collaboration","item_list",hash("is_read",false())))}
     
  {section show=$unread_count}
    {include uri="design:collaboration/warning.tpl" item_count=$unread_count}
  {/section}

  
  ---- END OF COPY/PASTE ----
  
  The {let ...} fetches a list of all collaboration items that have not been read yet.
  The {section..} makes sure that we only include the warning message when the number of
  unread items is >0.


4) Now browse to the directory "design/standard/templates/collaboration/"

5) Add a new textfile in that directory and name it "warning.tpl"

6) Put the following code in the file:

  <div style="border: 3px solid #ff0000">
    <b>
      You have {$item_count} new collaboration {cond($item_count|gt(1),"items", "item")} waiting.
      <a href={"/collaboration/view/summary/"|ezurl}>Click here to see {cond($item_count|gt(1),"them", "it")}</a>.
    </b>
  </div>

  ---- END OF COPY/PASTE ----

  This displays an area surrounded by a red border. The warning message is inside the
  box and checks for multiple messages before being displayed.


7) Open a browser, log into the admin area and test it. Everything should work ;-)




****************************
* Alternative Installation *
****************************

If you haven't changed the pagelayout.tpl in design/admin/templates yet, you can use the files
in this archive to set up the warning system.

1) Extract pagelayout.tpl to "design/admin/templates"

2) Extract warning.tpl to "design/standard/templates/collaboration"

3) That's it.