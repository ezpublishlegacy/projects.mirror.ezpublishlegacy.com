<?php
//
// Created on: <30-Oct-2005 11:11:11 dis>
//
// Copyright (C) 1999-2005 eZ systems as. All rights reserved.
//
// This source file is part of the eZ publish (tm) Open Source Content
// Management System.
//
// This file may be distributed and/or modified under the terms of the
// 'GNU General Public License' version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE.GPL included in
// the packaging of this file.
//
// Licencees holding valid 'eZ publish professional licences' may use this
// file in accordance with the 'eZ publish professional licence' Agreement
// provided with the Software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The 'eZ publish professional licence' is available at
// http://ez.no/products/licences/professional/. For pricing of this licence
// please contact us via e-mail to licence@ez.no. Further contact
// information is available at http://ez.no/home/contact/.
//
// The 'GNU General Public License' (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ez.no if any conditions of this licencing isn't clear to
// you.
//

include_once( 'kernel/classes/ezpersistentobject.php' );
include_once( 'lib/ezutils/classes/ezdebug.php' );

class eZLabel extends eZPersistentObject {
    function eZLabel( $row ) {
        $this->eZPersistentObject( $row );
    }

    function definition() {
        return array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                        'datatype' => 'integer',
                                                        'default' => 0,
                                                        'required' => true ),
                                         'owner_id' => array( 'name' => 'Owner',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         'creator_id' => array( 'name' => 'Creator',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         'created' => array( 'name' => 'Created',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                         'name' => array( 'name' => 'Name',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ) ),
                      'function_attributes' => array( 'is_private' => 'isPrivate',
                                                      'is_creator' => 'isCreator',
                                                      'can_edit' => 'canEdit',
                                                      'can_view' => 'canView',
                                                      'scope' => 'scope',
                                                      'can_remove' => 'canRemove',
                                                      'is_global' => 'isGlobal' ),
                      'keys' => array( 'id' ),
                      'increment_key' => 'id',
                      'sort' => array ( 'name' => 'desc' ),
                      'class_name' => 'eZLabel',
                      'name' => 'ezlabel' );
    }

    function &fetch( $id, $asObject = true ) {
        $user =& eZUser::currentUser();
        $user_id = $user->attribute( 'contentobject_id' );
        $conds['id'] = array( '=', $id  );

        $persObject =  eZPersistentObject::fetchObject( eZLabel::definition(),
                                                null,
                                                $conds,
                                                $asObject );
        if( !$persObject )
            return -1;
        if( $persObject->attribute('owner_id') == 0 || $persObject->attribute('owner_id') == $user_id  )
            return $persObject;
        else
            return -2;
    }

    function fetchList( $scope = false, $offset = false, $limit = false ) {
        if( $scope == 'global' ) {
            $conds['owner_id'] = array( '=', 0  );
        }
        elseif( $scope == 'private' ) {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds['owner_id'] = array( '=', $user_id  );
        }
        elseif( $scope == 'all' ) {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds['owner_id'] = array( array( 0, $user_id ) );
        }
        else {
            return false;
        }
        return eZPersistentObject::fetchObjectList( eZLabel::definition(),
                                                    null, // field filters
                                                    $conds, // conds
                                                    array('name' => 'asc'),
                                                    ( $limit )? array( 'offset' => $offset, 'length' => $limit ): null );

    }

    function &fetchObjectList( $object, $scope, $offset = false, $limit = false ) {
        $accessResult = eZLabel::checkAccess( 'view' );
        $accessWord = $accessResult['accessWord'];
        if( $accessWord == 'limited' ) {
            foreach($accessResult['policies'] as $key => $value ) {
                foreach($value as $key => $val ) {
                if( $key == 'Scope')
                    if( count($val) == 1 ) {
                        if( $scope == 'all' ) $scope = $val[0];
                        if( $val[0] != $scope) echo "ERROR";
                    }
                }
            }
        }
        $cond = '';
        if( $scope == 'global' ) {
            $conds[] = 0;
        }
        elseif( $scope == 'private' ) {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds[] = $user_id;
        }
        else {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds[] = $user_id;
            $conds[] = 0;
        }
        $cond = ' WHERE ezlabel.owner_id IN ( ' . implode(', ',$conds ). ' ) ';

        $user =& eZUser::currentUser();
        $user_id = $user->attribute( 'contentobject_id' );
        if( $object ) {
             $cond .= 'AND ezlabel_object.contentobject_id = ' . $object . ' ';
        }
        $sql = 'SELECT ezlabel_object.contentobject_id, ezlabel.id,ezlabel.name
                  FROM ezlabel JOIN ezlabel_object ON ( ezlabel.id=ezlabel_object.label_id ) ' . $cond . '';

        $db = &ezDB::instance();
        $result = $db->arrayQuery( $sql );

        $objectList =& eZPersistentObject::handleRows( $result, 'ezlabel', true );
        return $objectList;
    }

    function &fetchListCount( $scope = false, $offset = false, $limit = false ) {
        $db =& eZDB::instance();
        $conds = array();
        if( $scope == 'global' ) {
            $conds[] = 0;
        }
        elseif( $scope == 'private' ) {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds[] = $user_id;
        }
        elseif( $scope == 'all' ) {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds[] = $user_id;
            $conds[] = 0;
        }
        else {
            return false;
        }
        $where = 'WHERE owner_id in ( '.implode( ', ', $conds ).' ) ';

        $resultArray =& $db->arrayQuery( 'SELECT count(*) AS count FROM ezlabel ' . $where );
        return $resultArray[0]['count'];
    }


    function &createNew( $user_id, $name, $private = true, $object_id = false ) {
        $db =& eZDB::instance();
        $db->begin();
        $label =& new eZLabel( array( 'name' => $name,
                                      'owner_id' => 0,
                                      'creator_id' => $user_id,
                                      'created' => time() ) );
        $label->store();
        $db->commit();

        if( $object_id ) {
            eZLabel::createRelation( $label->ID, $object_id );
        }
        return $label;
    }

    function &createRelation( $label_id, $object_id ) {
        $db =& eZDB::instance();
        $db->begin();
        $db->arrayQuery( 'INSERT INTO ezlabel_object(label_id, contentobject_id) values('.$label_id.', '.$object_id.')' );
        $db->commit();
        return true;
    }

    function &removeRelation( $label_id, $object_id ) {
        $db =& eZDB::instance();
        $db->begin();
        $db->arrayQuery( 'DELETE FROM ezlabel_object WHERE label_id='.$label_id.' AND contentobject_id='.$object_id );
        $db->commit();
        return true;
    }

    function &removeLabel( $label_id ) {
        $db =& eZDB::instance();
        $db->begin();
        $db->arrayQuery( 'DELETE FROM ezlabel WHERE id='.$label_id );
        $db->commit();

        $db->begin();
        $db->arrayQuery( 'DELETE FROM ezlabel_object WHERE label_id='.$label_id );
        $db->commit();
        return $label;
    }

    function createSqlParts( $params ) {
        $user =& eZUser::currentUser();
        $user_id = $user->attribute( 'contentobject_id' );

        $sqlTables= ', ezlabel_object, ezlabel ';

        $sqlJoins = ' ezlabel.id = ezlabel_object.label_id AND ezcontentobject.id = ezlabel_object.contentobject_id AND ';

        if ( isset( $params['label'] ) ) {
             $label = $params['label'];
        }
        else {
             return false;
        }
        $conds = array();
        if ( isset( $params['scope'] ) ) {
            $scope = $params['scope'];
            if( $scope == 'global' ) {
                $conds[] = 0;
            }
            elseif( $scope == 'private' ) {
                $user =& eZUser::currentUser();
                $user_id = $user->attribute( 'contentobject_id' );
                $conds[] = $user_id;
            }
            elseif( $scope == 'all' ) {
                $user =& eZUser::currentUser();
                $user_id = $user->attribute( 'contentobject_id' );
                $conds[] = $user_id;
                $conds[] = 0;
            }
            else {
                return false;
            }
        }
        else {
            $user =& eZUser::currentUser();
            $user_id = $user->attribute( 'contentobject_id' );
            $conds[] = $user_id;
            $conds[] = 0;
        }
        $sqlJoins = $sqlJoins.' ezlabel.owner_id IN (' . implode(', ',$conds).') AND ';

        $sqlCond = 'ezlabel_object.label_id = ' . $label . ' AND ' . $sqlJoins;;

        return array( 'tables' => $sqlTables, 'joins'  => $sqlCond );
    }

    function isGlobal() {
        if( $this->attribute( 'owner_id' ) == 0 )
            return true;
        else
            return false;
    }

    function isPrivate() {
        if( $this->attribute( 'owner_id' ) != 0 )
            return true;
        else
            return false;
    }
    function scope() {
        $label = eZLabel::fetch( $this->attribute( 'id' ) ); 
        if( $label->attribute( 'owner_id' ) == 0 )
            return 'global';
        else
            return 'private';
    }

    function isCreator() {
        $user =& eZUser::currentUser();
        $user_id = $user->attribute( 'contentobject_id' );
        if( $this->attribute( 'creator_id' ) == $user_id )
            return true;
        else
            return false;
    }
    function canEdit( )
    {
        if ( !isset( $this->Permissions["can_edit"] ) )
        {
            $accessResult = $this->checkAccess( 'edit' );
            $accessWord = $accessResult['accessWord'];
            if( $accessWord == 'yes' )
                $this->Permissions["can_edit"] = 1;
        }
        $p = ( $this->Permissions["can_edit"] == 1 );
        return $p;
    }
    function canView( )
    {
        if ( !isset( $this->Permissions["can_view"] ) )
        {
            $accessResult = $this->checkAccess( 'edit' );
            $accessWord = $accessResult['accessWord'];
            if( $accessWord == 'yes' )
                $this->Permissions["can_view"] = 1;
        }
        $p = ( $this->Permissions["can_view"] == 1 );
        return $p;
    }
    function canRemove( )
    {
        if ( !isset( $this->Permissions["can_remove"] ) )
        {
            $accessResult = $this->checkAccess( 'edit' );
            $accessWord = $accessResult['accessWord'];
           if( $accessWord == 'yes' )
                $this->Permissions["can_remove"] = 1;
        }
        $p = ( $this->Permissions["can_remove"] == 1 );
        return $p;
    }

    function checkAccess( $functionName )
    {
        $user =& eZUser::currentUser();
        $userID = $user->attribute( 'contentobject_id' );
        $accessResult = $user->hasAccessTo( 'label' , $functionName );
        return $accessResult;
    }

    function setPermissions( $permissionArray )
    {
        $this->Permissions =& $permissionArray;
    }

    function permissions( )
    {
        return $this->Permissions;
    }
    var $Permissions = array();
}

?>
