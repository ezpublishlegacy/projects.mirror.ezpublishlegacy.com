<?php /* #?ini charset="iso-8859-1"?

[eZLabelFilter]
ExtensionName=ezlabel
ClassName=eZLabel
MethodName=createSqlParts
FileName=classes/ezlabel.php

*/ ?> 
