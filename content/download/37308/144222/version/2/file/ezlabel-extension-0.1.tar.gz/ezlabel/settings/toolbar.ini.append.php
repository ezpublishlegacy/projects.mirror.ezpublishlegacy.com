<?php /*

[Tool]
AvailableToolArray[]=label

[Tool_label]

*/ ?>