Created by Lukasz Klejnberg 2010.02.09

Tested on eZ Publish 4.2 Website Interface.

With the help of ezmp3player you can very easily add to your website the possibility to play sound
stored in mp3 format from the online editor using custom tag.

Quick Install:
1. Copy extension
2. Activate
3. Clear cache

To add an MP3 file of mp3player to the website must complete three steps:
1. Add custom tag mp3player: write the original file name with .mp3 in original_filename field.
2. Add mp3 file (insert object from online editor).
3. Publish.

The default settings:
CustomAttributesDefaults[original_filename]=write original file name with .mp3
CustomAttributesDefaults[width]=200
CustomAttributesDefaults[height]=20
CustomAttributesDefaults[bgcolor]=ffffff
CustomAttributesDefaults[showstop]=1
CustomAttributesDefaults[showvolume]=1
CustomAttributesDefaults[loadingcolor]=D91717
CustomAttributesDefaults[bgcolor1]=efefef
CustomAttributesDefaults[bgcolor2]=b1b1b1
CustomAttributesDefaults[slidercolor1]=000000
CustomAttributesDefaults[slidercolor2]=000000
CustomAttributesDefaults[sliderovercolor]=BB1010
CustomAttributesDefaults[buttoncolor]=000000
CustomAttributesDefaults[buttonovercolor]=BB1010

If you have any questions, ideas or suggestions, please write.