<?php /* #?ini charset="utf-8" ?

[CustomTagSettings]
AvailableCustomTags[]=mp3player
IsInline[tabs_main_article]=false

[mp3player]
CustomAttributes[]=original_filename
CustomAttributes[]=width
CustomAttributes[]=height
CustomAttributes[]=bgcolor
CustomAttributes[]=showstop
CustomAttributes[]=showvolume
CustomAttributes[]=loadingcolor
CustomAttributes[]=bgcolor1
CustomAttributes[]=bgcolor2
CustomAttributes[]=slidercolor1
CustomAttributes[]=slidercolor2
CustomAttributes[]=sliderovercolor
CustomAttributes[]=buttoncolor
CustomAttributes[]=buttonovercolor

CustomAttributesDefaults[original_filename]=write original file name with .mp3
CustomAttributesDefaults[width]=200
CustomAttributesDefaults[height]=20
CustomAttributesDefaults[bgcolor]=ffffff
CustomAttributesDefaults[showstop]=1
CustomAttributesDefaults[showvolume]=1
CustomAttributesDefaults[loadingcolor]=D91717
CustomAttributesDefaults[bgcolor1]=efefef
CustomAttributesDefaults[bgcolor2]=b1b1b1
CustomAttributesDefaults[slidercolor1]=000000
CustomAttributesDefaults[slidercolor2]=000000
CustomAttributesDefaults[sliderovercolor]=BB1010
CustomAttributesDefaults[buttoncolor]=000000
CustomAttributesDefaults[buttonovercolor]=BB1010

*/
?>