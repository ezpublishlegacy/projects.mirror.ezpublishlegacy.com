<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name>design/base</name>
    <message>
        <location filename="" line="296"/>
        <source>The following words were excluded from the search</source>
        <translation>以下关键字不会被搜索</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>如果需要更多选项，请尝试%1高级搜索%2</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>&quot;%1&quot;的搜索没有结果</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search tips</source>
        <translation>搜索提示</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Check spelling of keywords.</source>
        <translation>关键字拼写检查。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>尝试修改一些关键字，比如: 用car代替cars。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Try more general keywords.</source>
        <translation>尝试更一般的关键字。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>关键字越少，结果越多，尝试减少关键字知道您得到结果。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>&quot;%1&quot;的搜索返回%2条记录</translation>
    </message>
</context>
<context>
    <name>design/ezwebin/content/search</name>
    <message>
        <location filename="" line="296"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>如果需要更多选项，请尝试%1高级搜索%2</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>No results were found when searching for &quot;%1&quot;.</source>
        <translation>&quot;%1&quot;的搜索没有结果。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search tips</source>
        <translation>搜索提示</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Check spelling of keywords.</source>
        <translation>关键字拼写检查。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Try changing some keywords (eg, &quot;car&quot; instead of &quot;cars&quot;).</source>
        <translation>尝试修改一些关键字(比如,用&quot;car&quot;代替&quot;cars&quot;)。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Try searching with less specific keywords.</source>
        <translation>尝试使用更一般的关键字。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Reduce number of keywords to get more results.</source>
        <translation>减少关键字的数量来获得更多的结果。</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>&quot;%1&quot;的搜索返回%2条记录</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <location filename="" line="296"/>
        <source>Advanced search</source>
        <translation>高级搜索</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search all the words</source>
        <translation>搜索所有的关键字</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search the exact phrase</source>
        <translation>精确匹配短语</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search with at least one of the words</source>
        <translation>搜索所有关键字中的至少一个关键字</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Class</source>
        <translation>类</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Any class</source>
        <translation>所有类</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Class attribute</source>
        <translation>类属性</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Any attribute</source>
        <translation>所有属性</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Update attributes</source>
        <translation>更新属性</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>In</source>
        <translation>存在于</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Any section</source>
        <translation>所有分区</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Published</source>
        <translation>发布</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Any time</source>
        <translation>所有时间</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Last day</source>
        <translation>过去一天</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Last week</source>
        <translation>过去一周</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Last month</source>
        <translation>过于一个月</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Last three months</source>
        <translation>过去三个月</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Last year</source>
        <translation>过去一年</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Display per page</source>
        <translation>每页显示</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>5 items</source>
        <translation>5项</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>10 items</source>
        <translation>10项</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>20 items</source>
        <translation>20项</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>30 items</source>
        <translation>30项</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>50 items</source>
        <translation>50项</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>&quot;%1&quot;的搜索没有结果</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>&quot;%1&quot;的搜索返回%2条记录</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Score</source>
        <translation>分数</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
</context>
<context>
    <name>ezfind</name>
    <message>
        <location filename="" line="296"/>
        <source>Search time: %1 msecs</source>
        <translation>搜索时间: %1 毫秒</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Core search time: %1 msecs</source>
        <translation>核心搜索时间: %1 毫秒</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>Server not running</source>
        <translation>服务器未启动</translation>
    </message>
    <message>
        <location filename="" line="296"/>
        <source>eZ Find search plugin &amp;copy; 2007 eZ Systems AS, eZ Labs</source>
        <translation>eZ Find search plugin &amp;copy; 2007 eZ Systems AS, eZ Labs</translation>
    </message>
</context>
</TS>
