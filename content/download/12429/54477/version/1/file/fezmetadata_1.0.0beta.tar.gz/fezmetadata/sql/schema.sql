CREATE TABLE fezmeta_data (
id INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
contentobject_id INT( 11 ) NOT NULL ,
meta_name VARCHAR( 255 ) NOT NULL ,
meta_value VARCHAR( 255 ) NOT NULL
)
