<?php /* #?ini charset="utf-8"?

[MetaData]
AvailablesMetaData[]
AvailablesMetaData[]=description
AvailablesMetaData[]=keywords

[MetaData_description]
Name=Description
Operator=ezmetadata_description

[MetaData_keywords]
Name=Keywords
Operator=ezmetadata_keywords

*/ ?>
