<!DOCTYPE TS><TS>
<context>
	<name>design/admin/node/view/full</name>
	<message>
		<source>Meta Data</source>
		<translation></translation>
	</message>
	<message>
		<source>Meta Data [%meta_data]</source>
		<translation>translation>
	</message>
	<message>
		<source>Select meta data for removal.</source>
		<translation></translation>
	</message>
	<message>
		<source>Add meta data</source>
		<translation></translation>
	</message>
	</context>
<context>
	<name>fezmetadata</name>
	<message>
		<source>No Meta Data stored for this object</source>
		<translation></translation>
	</message>
	<message>
		<source>Add one new meta data</source>
		<translation></translation>
	</message>
	<message>
		<source>Add meta data</source>
		<translation></translation>
	</message>
	<message>
		<source>Update this Meta Data</source>
		<translation></translation>
	</message>
	<message>
		<source>Metadata name</source>
		<translation></translation>
	</message>
	<message>
		<source>Metadata value</source>
		<translation></translation>
	</message>

	<message>
		<source>Keywords</source>
		<translation></translation>
	</message>
</context></TS>
