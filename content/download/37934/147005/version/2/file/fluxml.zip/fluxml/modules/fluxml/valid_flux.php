<?php
include_once( 'extension/fluxml/modules/fluxml/classes/classe_fluxml.php' );
		$row['flux_identifiant']=$_POST['flux_url'];
		$row['flux_name']=$_POST['flux_name'];
		$row['flux_description']=$_POST['flux_description'];
		$row['flux_url_site']=$_POST['flux_url_site'];
		$row['flux_arbo_fille']=($_POST['flux_arbo']=="on")?1:0;
		$row['flux_is_actif']=($_POST['flux_actif']=="on")?1:0;
		$row['flux_for_arbo']=($_POST['flux_for_arbo']=="on")?1:0;
		$row['flux_source_node']=$_POST['flux_source_node'];
		$row['flux_class_identifier']=$_POST['flux_class'];
		if ($_FILES['image_flux']['tmp_name']!="")
		{
			$row['flux_image']="/extension/fluxml/design/standard/images/fluximg/".$_POST['flux_url'];
			move_uploaded_file($_FILES['image_flux']['tmp_name'],$_SERVER['DOCUMENT_ROOT'].$row['flux_image']);
		}
		$champs=Array();
		foreach ($_POST['attr_want'] as $inputchoisi)
			$champs[$inputchoisi]=$_POST[$inputchoisi];
		$row['flux_champs']=$champs;
		$flux=new fluxml();
		$flux->fill($row);
		$flux->store();
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$Result = array();
$Result['content'] =& $tpl->fetch( 'design:fluxml/syndicateadmin.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Export XML > Liste des syndications'
                                )
                        );		
?>