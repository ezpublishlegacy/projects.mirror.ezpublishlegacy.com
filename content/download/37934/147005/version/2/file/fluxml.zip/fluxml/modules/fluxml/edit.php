<?php
include_once( 'kernel/common/template.php' );
include_once( 'extension/fluxml/modules/fluxml/classes/classe_fluxml.php' );
$tpl =& templateInit();
if ($_GET['identifiant'])
{
	$flux=new fluxml($_GET['identifiant']);
	$tpl->setVariable( 'flux', $flux->getTabAttributes() );
	$titre="Edition";
}else 
{
	$tpl->setVariable( 'flux',array() );
	$titre="Création";
}
$Result = array();
$Result['content'] =& $tpl->fetch( 'design:fluxml/edit.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Export XML > '.$titre
                                )
                        );
?>