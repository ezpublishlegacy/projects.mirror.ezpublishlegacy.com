<?
include_once( 'extension/fluxml/modules/fluxml/classes/classe_fluxml.php' );

if (sizeof($_POST['CheckIDArray'])>0)
{
	foreach ($_POST['CheckIDArray'] as $identiflux)
	{
		$flux=new fluxml($identiflux);
		$flux->delete();
	}
}
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();
$Result = array();
$Result['content'] =& $tpl->fetch( 'design:fluxml/syndicateadmin.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Export XML > Liste des syndications'
                                )
                        );	
?>