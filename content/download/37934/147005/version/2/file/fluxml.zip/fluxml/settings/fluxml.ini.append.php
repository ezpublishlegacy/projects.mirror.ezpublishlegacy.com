<?php
/*
[ClassesExportables]
identifier[]=article
identifier[]=folder
*/
?>