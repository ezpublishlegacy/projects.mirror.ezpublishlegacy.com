<?php
/*
[ModuleSettings]
ExtensionRepositories[]=fluxml


[ModuleOverrides]
NavigationPart[fluxml/syndicateadmin]=ezfluxmlnavigationpart
NavigationPart[fluxml/syndicate]=ezfluxmlnavigationpart
NavigationPart[fluxml/supsyndic]=ezfluxmlnavigationpart
NavigationPart[fluxml/edit]=ezfluxmlnavigationpart
NavigationPart[fluxml/valid_flux]=ezfluxmlnavigationpart


*/
?>