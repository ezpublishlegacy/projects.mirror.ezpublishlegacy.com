<?php
include_once( "lib/ezutils/classes/ezextension.php" );
include_once( "lib/ezutils/classes/ezmodule.php" );
include_once( 'lib/ezutils/classes/ezcli.php' );
include_once( 'kernel/classes/ezcontentclass.php' );
include_once( "kernel/classes/datatypes/ezuser/ezuser.php");
include_once( "kernel/classes/datatypes/ezuser/ezuseraccountkey.php" );
include_once ('lib/ezutils/classes/ezoperationhandler.php');
include_once ('lib/phpxpath/XPath.class.php');
include_once ('kernel/classes/datatypes/ezenum/ezenumvalue.php');
include_once ('kernel/classes/datatypes/ezenum/ezenumobjectvalue.php');

class fluxml
{
	/* Attributes */
	var $identifiant;
	var $name;
	var $description;
	var $url_site;
	var $is_actif;
	var $for_arbo;
	var $source_node;
	var $arbo_fille;
	var $class_identifier;
	var $champs;
	var $image;
	
	
	function fluxml($id)
	{
		if ($id)
		{
			$this->identifiant=$id;
			$result=mysql_query("select * from FLUX_xml where flux_identifiant='".$this->identifiant."'")or die("Erreur de slection constructeur : ".mysql_error());
			if (mysql_num_rows($result))
			{
				$row=mysql_fetch_assoc($result);
				$this->name=$row['flux_name'];
				$this->description=$row['flux_description'];
				$this->url_site=$row['flux_url_site'];
				$this->is_actif=$row['flux_is_actif'];
				$this->for_arbo=$row['flux_for_arbo'];
				$this->source_node=$row['flux_source_node'];
				$this->arbo_fille=$row['flux_arbo_fille'];
				$this->class_identifier=$row['flux_class_identifier'];
				$this->champs=unserialize($row['flux_champs']);
				$this->image=$row['flux_image'];
			}
		}
	}
	
	function fill($row)
	{
		$this->identifiant=$row['flux_identifiant'];
		$this->name=$row['flux_name'];
		$this->description=$row['flux_description'];
		$this->url_site=$row['flux_url_site'];
		$this->is_actif=$row['flux_is_actif'];
		$this->for_arbo=$row['flux_for_arbo'];
		$this->source_node=$row['flux_source_node'];
		$this->arbo_fille=$row['flux_arbo_fille'];
		$this->class_identifier=$row['flux_class_identifier'];
		$this->champs=$row['flux_champs'];
		$this->image=$row['flux_image'];
	}
	
	
	function store()
	{
		/* On vérifie l'existance du identifiant*/
			$queriverif="select flux_name from FLUX_xml where flux_identifiant='".$this->identifiant."'";
			$resultverif = mysql_query($queriverif)or die("Erreur de vérification : ".mysql_error());
			if (mysql_num_rows($resultverif)) $action="update";
			else $action="insert";
			$query = $action." FLUX_xml SET 
			
						flux_identifiant='".addslashes($this->identifiant)."', 
						flux_name='".addslashes($this->name)."', 
						flux_description='".addslashes($this->description)."', 
						flux_url_site='".$this->url_site."', 
						flux_is_actif='".$this->is_actif."', 
						flux_for_arbo='".$this->for_arbo."', 
						flux_source_node='".$this->source_node."', 
						flux_arbo_fille='".$this->arbo_fille."', 
						flux_class_identifier='".$this->class_identifier."', 
						flux_champs='".serialize($this->champs)."', ";
				if ($this->image!="")
				 $query.=" flux_image='".$this->image."', ";
				 
				$query.=" flux_date_lastmodif=NOW()";
						
			if ($action == "update")
				$query.= " WHERE flux_identifiant='".$this->identifiant."'";
			$result = mysql_query($query)or die("Erreur d'enregistrement : ".mysql_error()."<br />".$query);
	}
	
	function delete()
	{
		$query="delete from FLUX_xml where flux_identifiant='".$this->identifiant."'";
		$result = mysql_query($query)or die("Erreur de suppression : ".mysql_error());
	}
	
	function is_visible() { return ($this->is_actif==1)?true:false;}
	function node_parent() { return ($this->for_arbo==1)?true:false;}
	function getName() {return $this->name; }
	function getDescription() {return $this->description; }
	function getUrlSite() {return $this->url_site; }
	function getIdSourceNode() { return $this->source_node; }
	function getClassIdentifier() { return $this->class_identifier; }
	function getChamps() { return $this->champs;}
	function getImage() { return $this->image; }
	function getIsForArboFille()  {return ($this->arbo_fille==1)?true:false;}
	
	function getTagForIdentifier($identifier)
	{
		if (array_key_exists($identifier,$this->champs))
			return $this->champs[$identifier];
		else 
			return false;
	}
	
	
	function getClassName()
	{
		$class =& eZContentClass::fetchByIdentifier( $this->class_identifier );
		return $class->attribute("name");
	}
	function getTabAttributes()
	{
		return Array(
				"identifiant"=>$this->identifiant,
				"name"=>$this->getName(),
				"description"=>$this->getDescription(),
				"url_site"=>$this->getUrlSite(),
				"is_actif"=>$this->is_visible(),
				"for_arbo"=>$this->node_parent(),
				"source_node"=>$this->getIdSourceNode(),
				"arbo_fille"=>$this->getIsForArboFille(),
				"class_identifier"=>$this->getClassIdentifier(),
				"class_name"=>$this->getClassName(),
				"champs"=>$this->getChamps(),
				"image"=>$this->getImage(),
				"url"=>"/fluxml/syndicate~".$this->identifiant
				);
	}

	function exportXML()
	{
		header("Content-Type: text/xml");
		print "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
		print "<root>";
		print "<name><![CDATA[".$this->getName()."]]></name>";	
		print "<description><![CDATA[".$this->getDescription()."]]></description>";	
		print "<site><![CDATA[".$this->getUrlSite()."]]></site>";	
		if ($this->getImage()!="")
			print "<image><![CDATA[http://".$_SERVER['HTTP_HOST'].$this->getImage()."]]></image>";	
		else 
			print "<image/>";	
		$pere =& eZContentObjectTreeNode::fetch($this->getIdSourceNode());
		$this->exportNodeXML($pere);
		print "</root>";
	}
	
	
	function exportNodeXML($pere)
	{
		if (is_object($pere))
		{
			$children=$pere->children();
			if (sizeof($children)>0)
			{
				$objectPere=$pere->attribute('object');
				print "<object id='".$objectPere->attribute('id')."' node_id='".$pere->attribute( 'node_id' )."' ";
				if ($this->node_parent()) print " node_id_parent='".$pere->attribute( 'parent_node_id' )."' ";
				print "class='".$pere->attribute('class_identifier')."'>";
				print "<name><![CDATA[".$pere->attribute( 'name' )."]]></name>";
				print "</object>";
				foreach ($children as $node)
				{
					if ($this->getIsForArboFille())	$this->exportNodeXML($node);
					
					if (($node->attribute('class_identifier')==$this->getClassIdentifier()))
					{
						$object=$node->attribute('object');
						print "<object id='".$object->attribute('id')."' node_id='".$node->attribute( 'node_id' )."' ";
						if ($this->node_parent()) print " node_id_parent='".$pere->attribute( 'node_id' )."' ";
						print "class='".$node->attribute('class_identifier')."'>";
						$objectVersion=$object->version($object->attribute( 'current_version' ) );
				        $data_map=$objectVersion->dataMap();
						foreach ($data_map as $identifer=>$attribute)
						{
							if ($tag=$this->getTagForIdentifier($identifer))
							{
								$buffer=$content=$contentTab=$bufferTab="";
								
								switch($attribute->attribute("data_type_string"))
								{
									case "ezstring":
										if (trim($attribute->content())!="")
											$buffer="<![CDATA[".$attribute->content()."]]>";
									break;
									case "ezinteger":
										$buffer=$attribute->content();
									break;
									case "eztext":
										if (trim($attribute->content())!="")
											$buffer="<![CDATA[".$attribute->content()."]]>";
									break;
									case "ezxmltext":
										 include_once( "kernel/classes/datatypes/ezxmltext/handlers/output/ezxhtmlxmloutput.php" );
										$buffer="<![CDATA[";
										$content=$attribute->content(); // $content->XMLData
										$out=new eZXHTMLXMLOutput($content->XMLData,null,$attribute);
										$buffer.=$out->outputText();
			   							$buffer.="]]>";
			
									break;
									case "ezselection":
										if (trim($attribute->title())!="")
											$buffer.="<![CDATA[".$attribute->title()."]]>";
									break;
									case "ezenum":
										if (trim($attribute->title())!="")
											$buffer.="<![CDATA[".$attribute->title()."]]>";
									break;
									case "ezdate":
										if (trim($attribute->attribute("data_int"))!="")
											$buffer.=date("d/m/Y H:i:s",$attribute->attribute("data_int"));
									break;
									case "ezboolean":
										$attribute->attribute("data_int");
										$buffer=($attribute->attribute("data_int")==1)?"true":"false";
									break;
									case "ezimage":
										include_once( "kernel/classes/datatypes/ezimage/ezimagefile.php" );
											$id_attr=$attribute->attribute("id");
											$imgTab=eZImageFile::fetchForContentObjectAttribute($id_attr,true);
											if (sizeof($imgTab)>0)
												$buffer.="<![CDATA[http://".str_replace("admin","",$_SERVER['HTTP_HOST'])."/".$imgTab[sizeof($imgTab)-1]->attribute('filepath')."]]>";
											unset($id_attr);
											unset($imgTab);
									break;
									default:
										$buffer="Type de données inconnue.";
									break;		
								}
								print "<$tag>$buffer</$tag>";
							}
						}
						print "</object>";
					}
				}
			}
		}
	}
	
	
	function getAllFlux()
	{
		$tab=array();
		$query="select flux_identifiant from FLUX_xml";
		$result=mysql_query($query)or die("Erreur de selection : ".mysql_error()."<br />".$query);
		while($row=mysql_fetch_assoc($result)) 
		{
			$flux=new fluxml($row['flux_identifiant']);
			$tab[]=$flux->getTabAttributes();
		}
		$result=Array(
						"result"=>$tab
					);
		return $result;
	}
}
?>