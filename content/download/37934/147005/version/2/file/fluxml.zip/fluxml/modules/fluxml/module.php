<?php

$Module = array( 'name' => 'Flux XML' );

$ViewList = array();
$ViewList['syndicateadmin'] = array(
    'script' => 'syndicateadmin.php',
    'functions' => array( 'private' ),
    'params' => array ( ) );

$ViewList['edit'] = array(
    'script' => 'edit.php',
     "functions" => array( 'private' ),
    'params' => array ( ) );

   
$ViewList['valid_flux'] = array(
    'script' => 'valid_flux.php',
     "functions" => array( 'private' ),
    'params' => array ( ) );    

$ViewList['syndicate'] = array(
    'script' => 'syndicate.php',
    'functions' => array( 'public' ),
    'params' => array ( ) );  

    $ViewList['supsyndic'] = array(
    'script' => 'supsyndic.php',
    'functions' => array( 'private' ),
    'params' => array ( ) );    
    
$FunctionList['private'] = array( );
$FunctionList['public'] = array( );   
    
?>