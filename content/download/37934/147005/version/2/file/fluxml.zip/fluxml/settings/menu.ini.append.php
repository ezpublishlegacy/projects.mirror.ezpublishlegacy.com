<?php /* #?ini charset="iso-8859-1"?

[NavigationPart]
Part[ezfluxmlnavigationpart]=Export XML


[TopAdminMenu]
Tabs[]=fluxml

[Topmenu_fluxml]
NavigationPartIdentifier=ezfluxmlnavigationpart
Name=Export XML
Tooltip=Gestion des syndication XML
URL[]
URL[default]=fluxml/syndicateadmin
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true