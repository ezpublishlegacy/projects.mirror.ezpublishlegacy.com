<?php

$FunctionList = array();

$FunctionList['getAllFlux'] = array(
	'name' => 'getAllFlux',
	'call_method' => array(
		'include_file' => 'extension/fluxml/modules/fluxml/classes/classe_fluxml.php',
		'class' => 'fluxml',
		'method' => 'getAllFlux')
);

?>