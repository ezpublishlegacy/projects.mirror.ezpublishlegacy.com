<?php
include_once( 'kernel/common/template.php' );
$tpl =& templateInit();

$tpl->setVariable( 'identiflux', $_POST );

$Result = array();
$Result['content'] =& $tpl->fetch( 'design:fluxml/syndicateadmin.tpl' );
$Result['path'] = array( array( 'url' => false,
                                'text' => 'Export XML > Liste des syndications'
                                )
                        );
?>