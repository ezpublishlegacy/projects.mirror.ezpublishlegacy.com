<?php
/*
[ExtensionSettings]
DesignExtensions[]=fluxml

[JavaScriptSettings]
JavaScriptList[]=fluxml.js
*/
?>