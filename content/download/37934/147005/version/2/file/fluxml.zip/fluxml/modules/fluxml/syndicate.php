<?php
include_once( 'extension/fluxml/modules/fluxml/classes/classe_fluxml.php' );
if ($_GET['id']) $flux=new fluxml($_GET['id']);
if ($flux->is_visible()) 
{
	$flux->exportXML();
	eZExecution::cleanExit();
}
else 
{
	include_once( 'kernel/common/template.php' );
	$tpl =& templateInit();
	$Result = array();
	$Result['content'] =& $tpl->fetch( 'design:fluxml/syndicate.tpl' );
	$Result['path'] = array( array( 'url' => false,
	                                'text' => 'Export XML > Syndication'
	                                )
	                        );
}
?>