<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/latex/autoloads/templatelatexoperators.php',
                                    'class' => 'TemplateLatexOperators',
                                    'operator_names' => array( 'latexrender' ) );

?>
