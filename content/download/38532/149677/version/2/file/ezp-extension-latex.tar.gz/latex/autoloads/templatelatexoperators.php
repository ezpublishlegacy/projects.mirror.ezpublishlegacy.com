<?php
/*!
\class   TemplateLatexOperator templatesckganttchartoperator.php
\ingroup eZTemplateOperators
\brief   Handles template operators for latex manipulation
\version 0.1
\date    2005-08-08
\authors  Paul Borgermans

Docs .... (I'm lazy|too busy|think it is not necessary|....)

*/


class TemplateLatexOperators
{
    /*!
    Constructor, does nothing by default.
    */
    function TemplateLatexOperators()
    {
    }

    /*!
    \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'latexrender' );
    }

    /*!
    \return true to tell the template engine that the parameter list exists per operator type,
            this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }

    /*!
    See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'latexrender' => array( 'format' => array( 'type' => 'string',
                                                                 'required' => false,
                                                                  'default' => 'png' ),
                                              'fontsize' => array( 'type' => 'int',
                                                                 'required' => false,
                                                                  'default' => 10 ),
                                              'formuladensity' => array( 'type' => 'int',
                                                                 'required' => false,
                                                                  'default' => 120 ) ) );
    }


    /*!
    Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {


        switch ( $operatorName )
        {
            case 'latexrender':
            {
                    //echo "<pre>Using LatexRender</pre>";
                    include_once('lib/ezutils/classes/ezsys.php');
                    include_once('extension/latex/lib/class.latexrender.php');

                    //Initialise caches and prepare to call the latex render class
                    $picture_dir = realpath(eZSys::cacheDirectory()).eZSys::fileSeparator().'latex';
                    //echo "Picture dir:";
                    //echo $picture_dir;
                    $apache_dir = eZSys::fileSeparator().eZSys::cacheDirectory().eZSys::fileSeparator().'latex';
                    $picture_tmp_dir = realpath(eZSys::cacheDirectory()).eZSys::fileSeparator().'latex_tmp';
                    foreach (array($picture_dir,$picture_tmp_dir) as $cachedir)
                    {
                    //echo $cachedir;
                        if ( !file_exists( $cachedir ))
                        {
                            eZDir::mkdir($cachedir);
                        }
                    }

                    //make a new LatexRender object whoch wil do the actual work
                    $latex = new LatexRender($picture_dir,$apache_dir,$picture_tmp_dir);
                    $latex->_image_format = $namedParameters['format'];
                    $latex->_font_size = $namedParameters['fontsize'];
                    $latex->_formula_density = $namedParameters['formuladensity'];
                    $latex->_extraname=md5(serialize($namedParameters));
                    //Should do some more cleanup actually, but here we go
                    $url = $latex->getFormulaURL($operatorValue);
                    //echo $url;
                    //returns the URL to the png image
                    $operatorValue = $url;
            }
            break;
        }

    }


}

?>
