<?php /* #?ini charset="utf-8"?

[google]
PageLayout=googlesitemap_pagelayout.tpl

*/ ?>