<?php /* #?ini charset="utf-8"?

[ContentSettings]
CachedViewModes=full;sitemap;pdf;googlesitemap
ComplexDisplayViewModes=sitemap;googlesitemap

*/ ?>