<?php
//
// Created on: <22-Feb-2008 16:30:00 hmarx>
//
// SOFTWARE NAME: googlesitemapgenerator
// SOFTWARE RELEASE: 3.0.0
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (C) 2008 MEDIATA Communications GmbH
// SOFTWARE LICENSE: GNU General Public License v2.0
//
// CMS NAME: eZ Publish
// CMS RELEASE: 4.0.2
// CVS: $Id: ezinfo.php 13 2009-02-13 15:12:12Z  $
//

class googlesitemapgeneratorInfo
{
    static function info()
    {
        return array( 'name' => "Google Sitemap Extension",
                      'version' => "3.0.0",
                      'copyright' => "Copyright (C) 2008 MEDIATA Communications GmbH",
                      'license' => "GNU General Public License v2.0"
                     );
    }
}
?>
