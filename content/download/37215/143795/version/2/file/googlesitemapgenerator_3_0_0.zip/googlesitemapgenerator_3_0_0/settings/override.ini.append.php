<?php /* #?ini charset="iso-8859-1"?

[googlesitemap_view]
Source=googlesitemap/generate.tpl
MatchFile=googlesitemap/generate.tpl
Subdir=templates

[googlesitemap_node_view]
Source=node/view/googlesitemap.tpl
MatchFile=googlesitemap/generate.tpl
Subdir=templates

*/
?>