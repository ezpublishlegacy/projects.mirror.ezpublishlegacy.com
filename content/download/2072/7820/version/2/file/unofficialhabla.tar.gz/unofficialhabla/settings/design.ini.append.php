<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=unofficialhabla

[JavaScriptSettings]
JavaScriptList[]=wc.js
JavaScriptList[]=unofficialhabla.js

*/ ?>