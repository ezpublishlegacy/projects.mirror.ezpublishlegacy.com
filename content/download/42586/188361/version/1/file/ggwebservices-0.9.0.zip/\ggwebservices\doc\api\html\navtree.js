var NAVTREE =
[
  [ "ggwebservices", "index.html", [
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ],
      [ "Deprecated List", "deprecated.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "ezjscore_client", "classezjscore__client.html", null ],
      [ "ezjscoremsg", "classezjscoremsg.html", null ],
      [ "ezjscoreresp", "classezjscoreresp.html", null ],
      [ "ezjscoreval", "classezjscoreval.html", null ],
      [ "ggeZJSCoreClient", "classggeZJSCoreClient.html", null ],
      [ "ggeZJSCoreRequest", "classggeZJSCoreRequest.html", null ],
      [ "ggeZJSCoreResponse", "classggeZJSCoreResponse.html", null ],
      [ "ggeZWebservices", "classggeZWebservices.html", null ],
      [ "ggeZWebservicesClient", "classggeZWebservicesClient.html", null ],
      [ "ggHTTPClient", "classggHTTPClient.html", null ],
      [ "ggHTTPRequest", "classggHTTPRequest.html", null ],
      [ "ggHTTPResponse", "classggHTTPResponse.html", null ],
      [ "ggJSONRPCClient", "classggJSONRPCClient.html", null ],
      [ "ggJSONRPCRequest", "classggJSONRPCRequest.html", null ],
      [ "ggJSONRPCResponse", "classggJSONRPCResponse.html", null ],
      [ "ggJSONRPCServer", "classggJSONRPCServer.html", null ],
      [ "ggPhpSOAPClient", "classggPhpSOAPClient.html", null ],
      [ "ggPhpSOAPClientTransport", "classggPhpSOAPClientTransport.html", null ],
      [ "ggPhpSOAPRequest", "classggPhpSOAPRequest.html", null ],
      [ "ggPhpSOAPResponse", "classggPhpSOAPResponse.html", null ],
      [ "ggPhpSOAPServer", "classggPhpSOAPServer.html", null ],
      [ "ggRESTClient", "classggRESTClient.html", null ],
      [ "ggRESTRequest", "classggRESTRequest.html", null ],
      [ "ggRESTResponse", "classggRESTResponse.html", null ],
      [ "ggRESTServer", "classggRESTServer.html", null ],
      [ "ggSOAPClient", "classggSOAPClient.html", null ],
      [ "ggSOAPRequest", "classggSOAPRequest.html", null ],
      [ "ggSOAPResponse", "classggSOAPResponse.html", null ],
      [ "ggWebservicesClient", "classggWebservicesClient.html", null ],
      [ "ggWebservicesFault", "classggWebservicesFault.html", null ],
      [ "ggwebservicesInfo", "classggwebservicesInfo.html", null ],
      [ "ggwebservicesJSCFunctions", "classggwebservicesJSCFunctions.html", null ],
      [ "ggWebservicesOperators", "classggWebservicesOperators.html", null ],
      [ "ggWebservicesRequest", "classggWebservicesRequest.html", null ],
      [ "ggWebservicesResponse", "classggWebservicesResponse.html", null ],
      [ "ggWebservicesServer", "classggWebservicesServer.html", null ],
      [ "ggwebservicesTestSuite", "classggwebservicesTestSuite.html", null ],
      [ "ggWSDLParser", "classggWSDLParser.html", null ],
      [ "ggXMLRPCClient", "classggXMLRPCClient.html", null ],
      [ "ggXMLRPCRequest", "classggXMLRPCRequest.html", null ],
      [ "ggXMLRPCResponse", "classggXMLRPCResponse.html", null ],
      [ "ggXMLRPCServer", "classggXMLRPCServer.html", null ],
      [ "jsonrpc_client", "classjsonrpc__client.html", null ],
      [ "jsonrpc_server", "classjsonrpc__server.html", null ],
      [ "jsonrpcmsg", "classjsonrpcmsg.html", null ],
      [ "jsonrpcresp", "classjsonrpcresp.html", null ],
      [ "jsonrpcval", "classjsonrpcval.html", null ],
      [ "xmlrpc_client", "classxmlrpc__client.html", null ],
      [ "xmlrpc_server", "classxmlrpc__server.html", null ],
      [ "xmlrpcmsg", "classxmlrpcmsg.html", null ],
      [ "xmlrpcresp", "classxmlrpcresp.html", null ],
      [ "xmlrpcval", "classxmlrpcval.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "ggeZWebservices", "classggeZWebservices.html", null ],
      [ "ggeZWebservicesClient", "classggeZWebservicesClient.html", null ],
      [ "ggPhpSOAPClientTransport", "classggPhpSOAPClientTransport.html", null ],
      [ "ggWebservicesClient", "classggWebservicesClient.html", [
        [ "ggeZJSCoreClient", "classggeZJSCoreClient.html", null ],
        [ "ggHTTPClient", "classggHTTPClient.html", null ],
        [ "ggJSONRPCClient", "classggJSONRPCClient.html", null ],
        [ "ggPhpSOAPClient", "classggPhpSOAPClient.html", null ],
        [ "ggRESTClient", "classggRESTClient.html", null ],
        [ "ggSOAPClient", "classggSOAPClient.html", null ],
        [ "ggXMLRPCClient", "classggXMLRPCClient.html", null ]
      ] ],
      [ "ggWebservicesFault", "classggWebservicesFault.html", null ],
      [ "ggwebservicesInfo", "classggwebservicesInfo.html", null ],
      [ "ggwebservicesJSCFunctions", "classggwebservicesJSCFunctions.html", null ],
      [ "ggWebservicesOperators", "classggWebservicesOperators.html", null ],
      [ "ggWebservicesRequest", "classggWebservicesRequest.html", [
        [ "ggeZJSCoreRequest", "classggeZJSCoreRequest.html", null ],
        [ "ggHTTPRequest", "classggHTTPRequest.html", null ],
        [ "ggJSONRPCRequest", "classggJSONRPCRequest.html", null ],
        [ "ggRESTRequest", "classggRESTRequest.html", null ],
        [ "ggSOAPRequest", "classggSOAPRequest.html", [
          [ "ggPhpSOAPRequest", "classggPhpSOAPRequest.html", null ]
        ] ],
        [ "ggXMLRPCRequest", "classggXMLRPCRequest.html", null ]
      ] ],
      [ "ggWebservicesResponse", "classggWebservicesResponse.html", [
        [ "ggeZJSCoreResponse", "classggeZJSCoreResponse.html", null ],
        [ "ggHTTPResponse", "classggHTTPResponse.html", null ],
        [ "ggJSONRPCResponse", "classggJSONRPCResponse.html", null ],
        [ "ggPhpSOAPResponse", "classggPhpSOAPResponse.html", null ],
        [ "ggRESTResponse", "classggRESTResponse.html", null ],
        [ "ggSOAPResponse", "classggSOAPResponse.html", null ],
        [ "ggXMLRPCResponse", "classggXMLRPCResponse.html", null ]
      ] ],
      [ "ggWebservicesServer", "classggWebservicesServer.html", [
        [ "ggPhpSOAPServer", "classggPhpSOAPServer.html", null ],
        [ "ggRESTServer", "classggRESTServer.html", null ],
        [ "ggXMLRPCServer", "classggXMLRPCServer.html", [
          [ "ggJSONRPCServer", "classggJSONRPCServer.html", null ]
        ] ]
      ] ],
      [ "ggwebservicesTestSuite", "classggwebservicesTestSuite.html", null ],
      [ "ggWSDLParser", "classggWSDLParser.html", null ],
      [ "xmlrpc_client", "classxmlrpc__client.html", [
        [ "ezjscore_client", "classezjscore__client.html", null ],
        [ "jsonrpc_client", "classjsonrpc__client.html", null ]
      ] ],
      [ "xmlrpc_server", "classxmlrpc__server.html", [
        [ "jsonrpc_server", "classjsonrpc__server.html", null ]
      ] ],
      [ "xmlrpcmsg", "classxmlrpcmsg.html", [
        [ "ezjscoremsg", "classezjscoremsg.html", null ],
        [ "jsonrpcmsg", "classjsonrpcmsg.html", null ]
      ] ],
      [ "xmlrpcresp", "classxmlrpcresp.html", [
        [ "ezjscoreresp", "classezjscoreresp.html", null ],
        [ "jsonrpcresp", "classjsonrpcresp.html", null ]
      ] ],
      [ "xmlrpcval", "classxmlrpcval.html", [
        [ "ezjscoreval", "classezjscoreval.html", null ],
        [ "jsonrpcval", "classjsonrpcval.html", null ]
      ] ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "ezinfo.php", "ezinfo_8php.html", null ],
      [ "jsonrpc.php", "jsonrpc_8php.html", null ],
      [ "webservicescontroller.php", "webservicescontroller_8php.html", null ],
      [ "xmlrpc.php", "xmlrpc_8php.html", null ],
      [ "autoloads/eztemplateautoload.php", "eztemplateautoload_8php.html", null ],
      [ "autoloads/ggwebservicesoperators.php", "ggwebservicesoperators_8php.html", null ],
      [ "classes/ggezjscoreclient.php", "ggezjscoreclient_8php.html", null ],
      [ "classes/ggezjscorerequest.php", "ggezjscorerequest_8php.html", null ],
      [ "classes/ggezjscoreresponse.php", "ggezjscoreresponse_8php.html", null ],
      [ "classes/ggezwebservices.php", "ggezwebservices_8php.html", null ],
      [ "classes/ggezwebservicesclient.php", "ggezwebservicesclient_8php.html", null ],
      [ "classes/gghttpclient.php", "gghttpclient_8php.html", null ],
      [ "classes/gghttprequest.php", "gghttprequest_8php.html", null ],
      [ "classes/gghttpresponse.php", "gghttpresponse_8php.html", null ],
      [ "classes/ggjsonrpcclient.php", "ggjsonrpcclient_8php.html", null ],
      [ "classes/ggjsonrpcrequest.php", "ggjsonrpcrequest_8php.html", null ],
      [ "classes/ggjsonrpcresponse.php", "ggjsonrpcresponse_8php.html", null ],
      [ "classes/ggjsonrpcserver.php", "ggjsonrpcserver_8php.html", null ],
      [ "classes/ggphpsoapclient.php", "ggphpsoapclient_8php.html", null ],
      [ "classes/ggphpsoapclienttransport.php", "ggphpsoapclienttransport_8php.html", null ],
      [ "classes/ggphpsoaprequest.php", "ggphpsoaprequest_8php.html", null ],
      [ "classes/ggphpsoapresponse.php", "ggphpsoapresponse_8php.html", null ],
      [ "classes/ggphpsoapserver.php", "ggphpsoapserver_8php.html", null ],
      [ "classes/ggrestclient.php", "ggrestclient_8php.html", null ],
      [ "classes/ggrestrequest.php", "ggrestrequest_8php.html", null ],
      [ "classes/ggrestresponse.php", "ggrestresponse_8php.html", null ],
      [ "classes/ggrestserver.php", "ggrestserver_8php.html", null ],
      [ "classes/ggsoapclient.php", "ggsoapclient_8php.html", null ],
      [ "classes/ggsoaprequest.php", "ggsoaprequest_8php.html", null ],
      [ "classes/ggsoapresponse.php", "ggsoapresponse_8php.html", null ],
      [ "classes/ggwebservicesclient.php", "ggwebservicesclient_8php.html", null ],
      [ "classes/ggwebservicesfault.php", "ggwebservicesfault_8php.html", null ],
      [ "classes/ggwebservicesjscfunctions.php", "ggwebservicesjscfunctions_8php.html", null ],
      [ "classes/ggwebservicesrequest.php", "ggwebservicesrequest_8php.html", null ],
      [ "classes/ggwebservicesresponse.php", "ggwebservicesresponse_8php.html", null ],
      [ "classes/ggwebservicesserver.php", "ggwebservicesserver_8php.html", null ],
      [ "classes/ggwsdlparser.php", "ggwsdlparser_8php.html", null ],
      [ "classes/ggxmlrpcclient.php", "ggxmlrpcclient_8php.html", null ],
      [ "classes/ggxmlrpcrequest.php", "ggxmlrpcrequest_8php.html", null ],
      [ "classes/ggxmlrpcresponse.php", "ggxmlrpcresponse_8php.html", null ],
      [ "classes/ggxmlrpcserver.php", "ggxmlrpcserver_8php.html", null ],
      [ "cronjobs/rotatewslogs.php", "rotatewslogs_8php.html", null ],
      [ "doc/samples/initialize_example.php", "initialize__example_8php.html", null ],
      [ "doc/samples/soap_client_outside_ezp.php", "soap__client__outside__ezp_8php.html", null ],
      [ "doc/samples/xmlrpc_client_outside_ezp.php", "xmlrpc__client__outside__ezp_8php.html", null ],
      [ "doc/samples/xmlrpc_server_outside_ezp.php", "xmlrpc__server__outside__ezp_8php.html", null ],
      [ "doc/samples/flickr_client/wsproviders.ini.append.php", "flickr__client_2wsproviders_8ini_8append_8php.html", null ],
      [ "doc/samples/lastfm_client/wsproviders.ini.append.php", "lastfm__client_2wsproviders_8ini_8append_8php.html", null ],
      [ "doc/samples/soap_server/initialize.php", "doc_2samples_2soap__server_2initialize_8php.html", null ],
      [ "doc/samples/soap_server/soap.ini.append.php", "soap_8ini_8append_8php.html", null ],
      [ "doc/samples/template_client/wsproviders.ini.append.php", "template__client_2wsproviders_8ini_8append_8php.html", null ],
      [ "jsonrpc/initialize.php", "jsonrpc_2initialize_8php.html", null ],
      [ "lib/ezjscore/ezjscore.inc.php", "ezjscore_8inc_8php.html", null ],
      [ "lib/json/jsonrpc.inc.php", "jsonrpc_8inc_8php.html", null ],
      [ "lib/json/jsonrpcs.inc.php", "jsonrpcs_8inc_8php.html", null ],
      [ "lib/xmlrpc/xmlrpc.inc.php", "xmlrpc_8inc_8php.html", null ],
      [ "lib/xmlrpc/xmlrpcs.inc.php", "xmlrpcs_8inc_8php.html", null ],
      [ "modules/webservices/debugger.php", "debugger_8php.html", null ],
      [ "modules/webservices/execute.php", "execute_8php.html", null ],
      [ "modules/webservices/function_definition.php", "function__definition_8php.html", null ],
      [ "modules/webservices/module.php", "module_8php.html", null ],
      [ "modules/webservices/proxy.php", "proxy_8php.html", null ],
      [ "modules/webservices/wsdl.php", "wsdl_8php.html", null ],
      [ "modules/webservices/xsd.php", "xsd_8php.html", null ],
      [ "modules/webservices/debugger/action.php", "action_8php.html", null ],
      [ "modules/webservices/debugger/common.php", "modules_2webservices_2debugger_2common_8php.html", null ],
      [ "modules/webservices/debugger/controller.php", "controller_8php.html", null ],
      [ "modules/webservices/debugger/frame.php", "frame_8php.html", null ],
      [ "modules/webservices/debugger/visualeditor.php", "visualeditor_8php.html", null ],
      [ "rest/initialize.php", "rest_2initialize_8php.html", null ],
      [ "tests/initialize_soapinterop.php", "initialize__soapinterop_8php.html", null ],
      [ "tests/suite.php", "suite_8php.html", null ],
      [ "xmlrpc/common.php", "xmlrpc_2common_8php.html", null ],
      [ "xmlrpc/initialize.php", "xmlrpc_2initialize_8php.html", null ]
    ] ],
    [ "Directories", "dirs.html", [
      [ "autoloads", "dir_93296b41b9945379efe332df2a20eedc.html", null ],
      [ "classes", "dir_444ae754327ddc3215c2e3e86c3cc1d1.html", null ],
      [ "cronjobs", "dir_2a55923535403aabc5e7396e3336e6bf.html", null ],
      [ "doc", "dir_0f0178060b506254b8141592cc99a0dd.html", [
        [ "samples", "dir_def60a9abbdd46efd9b3bc5861151a16.html", [
          [ "flickr_client", "dir_582573f39336d348ad8a216c22f525ad.html", null ],
          [ "lastfm_client", "dir_14815dc3fa7380c32fe563e421747a7f.html", null ],
          [ "soap_server", "dir_fd6c18c8ed87061440b98c1de40d6e96.html", null ],
          [ "template_client", "dir_747768a72b2e2a8a2cf543457e567aaf.html", null ]
        ] ]
      ] ],
      [ "jsonrpc", "dir_2dad4fde66cccb6054650e964e7d8a14.html", null ],
      [ "lib", "dir_6bd66afc8ea4785181cef3c61698edd1.html", [
        [ "ezjscore", "dir_d50c4acaf0b71590a57cac40c771882f.html", null ],
        [ "json", "dir_64b955945291029ec7b7dddc96a4cddb.html", null ],
        [ "xmlrpc", "dir_c3ac37129c8a6395a7e8ed718bad2bbf.html", null ]
      ] ],
      [ "modules", "dir_0b5bad077453aee88266a3edaa584cd5.html", [
        [ "webservices", "dir_f0804e23227f551c5f12a196ab2fca86.html", [
          [ "debugger", "dir_7f51f9780471727c330e2ff928d07de3.html", null ]
        ] ]
      ] ],
      [ "rest", "dir_721f4c70916fa266a2334eeb8637baf3.html", null ],
      [ "tests", "dir_6a382a65d70cae8528b6e929d9000c3a.html", null ],
      [ "xmlrpc", "dir_05472eac427ba0741d891b63071002c4.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

