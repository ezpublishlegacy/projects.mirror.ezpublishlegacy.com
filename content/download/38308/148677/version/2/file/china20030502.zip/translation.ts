<!DOCTYPE TS><TS>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>商店</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>个人</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>首页</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>站点地图</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>垃圾箱</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>个人草稿</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>修改口令</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>类别</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>段落</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>工作流</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>触发器</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>翻译</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>搜索状态</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>订单</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>折扣</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Name</translation>
    </message>
</context>
<context>
    <name>design/shop</name>
    <message>
        <source>Payment was canceled. Try to buy again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Real player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created by</source>
        <translation>建立者</translation>
    </message>
    <message>
        <source>on</source>
        <translation>on</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation>最后修改者</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>标示</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>组成员</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>添加到组</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>从组中删除</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>输入信息无效</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>输入已经被保存</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>属性</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>必填项目</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>检索选择</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>信息收集器</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>下</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>上</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>数据类型</translation>
    </message>
    <message>
        <source>New</source>
        <translation>新</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>放弃改变</translation>
    </message>
    <message>
        <source>Editing class group</source>
        <translation>编辑类别组</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>修改者</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>放弃</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>是否确认删除这些类别?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>删除类别%1将同时删除%2!</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>是否确认删除这些类别组?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>删除类别组%1将同时删除类别组%2!</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Class groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes in </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New class</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was deferred and is available as a draft.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The content object %1 was deferred and will be available as a draft.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deny</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>是否确认要删除这个翻译?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>修改翻译的内容</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>新建</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIME Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Best</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Existing orignal filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No relation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You save:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the following translations from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is not available for editing anymore, only drafts can be edited.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>was not created by you, only your own drafts can be edited.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Placement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redirecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2! %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site map</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Every module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify limitations in function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;Any&apos; means no limitation by this parameter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>搜索统计</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>最常用的搜索词汇</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>词汇</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>词汇数量</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>平均返回结果</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>site registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>setup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By using the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button when ready.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to loose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue and remove the data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue and skip database initialization.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It can take some time creating the database so please be patient and wait until the new page is finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to start the configuration process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servername</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Socket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Databasename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>which must available on the server or</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you find a bug (error), please go to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and look for a line that says:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the URL to access your new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button. Enjoy one of the most successful web content management systems!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title of your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL to your site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>button to re-run the system checking.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Check</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>colon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>configuration and set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on the subject can be found at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration example:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose which classes or sections applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>没有订单</translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Trigger list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Login</source>
        <translation>登录</translation>
    </message>
    <message>
        <source>Activate account</source>
        <translation>激活账户</translation>
    </message>
    <message>
        <source>Registed user profile</source>
        <translation>注册用户资料</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Update Profile</source>
        <translation>更新资料</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>修改口令</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation>修改设置</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>产生</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>放弃</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>不能登录</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>需要用一个有效的用户和口令登录.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>没有存取的权限</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>你没有权限存取%1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>口令</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation>注册</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>修改用户口令</translation>
    </message>
    <message>
        <source>Old Password</source>
        <translation>旧口令</translation>
    </message>
    <message>
        <source>New Password</source>
        <translation>新口令</translation>
    </message>
    <message>
        <source>Retype Password</source>
        <translation>重复口令</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>注册用户</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>输入无效</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>输入信息已保存</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>注册</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>用户设置</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>最大登录数</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>允许</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>用户已经注册</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>你的账户已经被成功建立.</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>Confirm user registration at %1</source>
        <translation>确认用户注册在%1</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation>%1新口令</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation>点击这里得到新口令:</translation>
    </message>
    <message>
        <source>New user registered at %1</source>
        <translation>新用户注册于%1</translation>
    </message>
    <message>
        <source>%1 registration info</source>
        <translation>%1注册信息</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Editing workflow</source>
        <translation>编辑工作流</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>工作流已保存</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>数据需要修整</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>修改者是</translation>
    </message>
    <message>
        <source>on</source>
        <translation>on</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>组</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>New</source>
        <translation>新</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>放弃</translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation>编辑工作流组</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>工作流</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>新组</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>工作流处理</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>工作流处理已经建立于</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>同时修改于</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>工作流</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>使用工作流</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>正在处理.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>本工作流正在运行</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>内容目标</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>工作流已经为内容建立</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>使用版本</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>在父版本</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>工作流事件</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>工作流还没有保存,主工作流的号码是</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>当前事件位置是</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>要运行的事件是</translation>
    </message>
    <message>
        <source>event</source>
        <translation>事件</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>事件最后返回的状态</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>工作流事件清单</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>复位</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>下一步</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>工作流事件日志</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <translation>工作流在%1</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>修改者</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>已修改</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>新工作流</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor</source>
        <translation>编辑者</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>段落
</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>任何</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>用户没有授权</translation>
    </message>
    <message>
        <source>Checkout text</source>
        <translation>查询文本</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>消息</translation>
    </message>
    <message>
        <source>Section IDs</source>
        <translation>段落ID</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>用户没有工作流ID</translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation>没有发布的目标</translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation>发布目标</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>天</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>小时</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>分钟</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>新入口</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>删除选择</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation>调入属性</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>类别</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>类别属性:</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/result</name>
    <message>
        <source>Checkout</source>
        <translation>检查</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>下一个</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation>回卷</translation>
    </message>
    <message>
        <source>Hello</source>
        <translation>你好</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>组类别列表</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>类别组列表</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>删除类别</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>类别编辑</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>多个类别</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>类别清单</translation>
    </message>
    <message>
        <source> object</source>
        <translation>目标</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>目标</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>删除多个类别</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(没有类别)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>删除类别组</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Observer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatype/ezbinaryfiletype</name>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is required.</source>
        <comment>eZAuthorType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <comment>eZOptionType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>高级</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>没有主选择节点，请选择一个.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>个人草稿</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>删除编辑版本</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>删除目标</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>来自%1的技巧：%2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>发信人的邮件地址无效</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>收件人的邮件地址无效</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>内容翻译</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>垃圾箱</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>版本</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Role list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>搜索状态</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
