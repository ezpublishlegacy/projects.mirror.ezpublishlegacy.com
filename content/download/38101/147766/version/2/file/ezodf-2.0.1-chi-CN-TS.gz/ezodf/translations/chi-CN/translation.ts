<!DOCTYPE TS><TS>
<context>
    <name>extension/ezodf</name>
    <message>
        <source>Import</source>
<translation type="obsolete">导入</translation>
    </message>
    <message>
        <source>Export</source>
<translation type="obsolete">导出</translation>
    </message>
    <message>
        <source>Replace</source>
<translation type="obsolete">替换</translation>
    </message>
    <message>
        <source>Choose document placement</source>
<translation type="obsolete">选择文档的位置</translation>
    </message>
    <message>
        <source>Upload file</source>
<translation>上传文件</translation>
    </message>
    <message>
        <source>Error</source>
<translation>错误</translation>
    </message>
    <message>
        <source>Export Object</source>
<translation>导出对象</translation>
    </message>
    <message>
        <source>OpenOffice.org import</source>
<translation>OpenOffice.org导入</translation>
    </message>
    <message>
        <source>OpenOffice.org export</source>
<translation>OpenOffice.org导出</translation>
    </message>
    <message>
        <source>Export eZ publish content to OpenOffice.org</source>
<translation>将eZ Publish的内容导出到OpenOffice.org</translation>
    </message>
    <message>
        <source>Here you can export any eZ publish content object to an OpenOffice.org Writer document format.</source>
<translation>在此您可以将eZ Publish的任何内容对象导出为OpenOffice.orgWriter的文档格式。</translation>
    </message>
    <message>
        <source>Document is now imported</source>
<translation>文档已经被导入</translation>
    </message>
    <message>
        <source>The object was imported as: %class_name</source>
<translation>对象被导入为：%class_name</translation>
    </message>
    <message>
        <source>Document imported as</source>
<translation>文档被导入为</translation>
    </message>
    <message>
        <source>The images are placed in the media and can be re-used.</source>
<translation>图片将被放置到媒体中并可以重用。</translation>
    </message>
    <message>
        <source>Import another document</source>
<translation>导入其他的文档</translation>
    </message>
    <message>
        <source>Import OpenOffice.org document</source>
<translation>导入OpenOffice.org文档</translation>
    </message>
    <message>
        <source>Replace document</source>
<translation>替换文档</translation>
    </message>
    <message>
        <source>Import to</source>
<translation>导入到</translation>
    </message>
    <message>
        <source>You can import OpenOffice.org Writer documents directly into eZ publish from this page. You are
asked where to place the document and eZ publish does the rest. The document is converted into
the appropriate class during the import, you get a notice about this after the import is done.
Images are placed in the media library so you can re-use them in other articles.</source>
<translation>在这个页面中，您可以直接将OpenOffice.orgWriter的文档导入到eZ Publish。eZ Publish只会询问您文档将放置的位置，然后eZ Publish完成会完成剩下的步骤。在导入过程中，该文档将会被转换成适当的类，在导入结束后您将会获得一个提示。图片将会被放置到媒体库，因此您可以在其他的文章中重用它们。</translation>
    </message>
</context>
<context>
    <name>extension/ezodf/browse</name>
    <message>
        <source>Choose document placement</source>
<translation>选择文档的位置</translation>
    </message>
    <message>
        <source>Please choose the placement for the OpenOffice.org object.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
<translation>请为OpenOffice.org对象选择放置的位置。
<byte value="x9"/><byte value="x9"/>选择位置并点击%buttonname按钮。
<byte value="x9"/><byte value="x9"/>也可以使用最近访问和书签来快速定位。
<byte value="x9"/><byte value="x9"/>要更改浏览列表点击位置的名称。
<byte value="x9"/></translation>
    </message>
    <message>
        <source>Select</source>
<translation>选择</translation>
    </message>
</context>
<context>
    <name>extension/ezodf/export/error</name>
    <message>
        <source>Destination file format not supported</source>
<translation>不支持目标文件的格式</translation>
    </message>
    <message>
        <source>PDF conversion failed</source>
<translation>转换到PDF失败</translation>
    </message>
    <message>
        <source>Word conversion failed</source>
<translation>转换到Word失败</translation>
    </message>
    <message>
        <source>Unable to fetch node, or no read access</source>
<translation>不能获取节点，或没有权限读取</translation>
    </message>
    <message>
        <source>Unable to open file %1 on server side</source>
<translation>在服务器端不能打开文件%1</translation>
    </message>
</context>
<context>
    <name>extension/ezodf/import/error</name>
    <message>
        <source>File extension or type is not allowed.</source>
<translation>不允许该文件扩展或类型</translation>
    </message>
    <message>
        <source>Could not parse XML.</source>
<translation>不能解析XML</translation>
    </message>
    <message>
        <source>Can not open socket. Please check if extension/ezodf/deamon.php is running.</source>
<translation>不能打开socket。请检查extension/ezodf/deamon.php是否在运行。</translation>
    </message>
    <message>
        <source>Can not convert the given document.</source>
<translation>不能转换指定的文档。</translation>
    </message>
    <message>
        <source>Unable to call deamon. Fork can not create child process.</source>
<translation>不能调用deamon。Fork不能创建子进程。</translation>
    </message>
    <message>
        <source>Deamon reported error.</source>
<translation>Deamon报告错误。</translation>
    </message>
    <message>
        <source>Unknown node.</source>
<translation>未知节点。</translation>
    </message>
    <message>
        <source>Access denied.</source>
<translation>拒绝访问。</translation>
    </message>
    <message>
        <source>Error during import.</source>
<translation>导入过程出错。</translation>
    </message>
    <message>
        <source>Unknown content class specified in odf.ini:</source>
<translation>在odf.ini中指定的未知内容类：</translation>
    </message>
    <message>
        <source>Unknown error.</source>
<translation>未知错误。</translation>
    </message>
    <message>
        <source>Filetype: </source>
<translation>文件类型：</translation>
    </message>
    <message>
        <source>Unable to fetch node with id  </source>
<translation>不能用id获取节点</translation>
    </message>
    <message>
        <source>Folder for images could not be created, access denied.</source>
<translation>不能创建图片文件夹，拒绝访问。</translation>
    </message>
    <message>
        <source>Document is not suported.</source>
<translation>不支持该文档。</translation>
    </message>
    <message>
        <source>Cannot import. File not found. Already imported?</source>
<translation>不能导入。找不到文件。已经导入的？</translation>
    </message>
    <message>
        <source>Cannot import document, supplied placement nodeID is not valid.</source>
<translation>不能导入文档，提供的位置的nodeID不可用。</translation>
    </message>
    <message>
        <source>Cannot store uploaded file, cannot import.</source>
<translation>不能保存上传的文件，不能导入。</translation>
    </message>
</context>
<context>
    <name>extension/ezodf/popupmenu</name>
    <message>
        <source>Export OpenOffice.org</source>
<translation type="obsolete">导出OpenOffice.org</translation>
    </message>
    <message>
        <source>Export PDF</source>
<translation>导出PDF</translation>
    </message>
    <message>
        <source>Export Word</source>
<translation>导出Word</translation>
    </message>
    <message>
        <source>Import OpenOffice.org</source>
<translation type="obsolete">导入OpenOffice.org</translation>
    </message>
    <message>
        <source>Replace OpenOffice.org</source>
<translation type="obsolete">替换OpenOffice.org</translation>
    </message>
    <message>
        <source>OpenOffice.org</source>
<translation>OpenOffice.org</translation>
    </message>
    <message>
        <source>Export OpenOffice</source>
<translation>导出OpenOffice</translation>
    </message>
    <message>
        <source>Import OpenOffice</source>
<translation>导入OpenOffice</translation>
    </message>
    <message>
        <source>Replace OpenOffice</source>
<translation>替换OpenOffice</translation>
    </message>
</context>
</TS>
