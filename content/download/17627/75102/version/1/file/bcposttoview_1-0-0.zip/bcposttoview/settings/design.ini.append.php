<?php /*

[ExtensionSettings]
DesignExtensions[]=stdl

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
# JavaScriptList[]=example/lib.js

*/ ?>
