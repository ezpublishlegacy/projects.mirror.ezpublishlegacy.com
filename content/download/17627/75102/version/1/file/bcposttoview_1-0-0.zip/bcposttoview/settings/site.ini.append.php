<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=posttoview
PolicyOmitList[]=defaultfilter
PolicyOmitList[]=customfilter01
PolicyOmitList[]=customfilter02

*/ ?>