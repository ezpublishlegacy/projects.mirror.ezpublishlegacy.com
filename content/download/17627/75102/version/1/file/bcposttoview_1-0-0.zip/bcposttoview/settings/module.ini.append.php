<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=bcposttoview
# Provided Modules
ModuleList[]=posttoview
ModuleList[]=defaultfilter
ModuleList[]=customfilter01
ModuleList[]=customfilter02
# ModuleList[]=customfilter03
# ModuleList[]=customfilter04

*/ ?>
