﻿FCKLang.eZPublishLinkBtn			= 'Insert/Edit eZPublish link' ;
FCKLang.eZPublishLinkDlgTitle		= 'ezPublish link Properties' ;
FCKLang.eZPublishLinkDlgName		= 'Placeholder Name' ;
FCKLang.eZPublishLinkErrNoName	= 'Please type the placeholder name' ;
FCKLang.eZPublishLinkErrNameInUse	= 'The specified name is already in use' ;