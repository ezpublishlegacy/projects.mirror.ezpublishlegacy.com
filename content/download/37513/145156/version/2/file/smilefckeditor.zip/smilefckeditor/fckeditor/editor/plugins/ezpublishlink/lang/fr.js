﻿FCKLang.eZPublishLinkBtn			= 'Insérer un lien eZPublish' ;
FCKLang.eZPublishLinkDlgTitle		= 'Propriétés lien eZPublish' ;
FCKLang.eZPublishLinkDlgName		= 'Insérer un lien eZPublish' ;