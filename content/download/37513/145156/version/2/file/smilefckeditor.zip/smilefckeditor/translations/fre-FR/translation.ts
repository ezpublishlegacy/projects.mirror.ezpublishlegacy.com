<!DOCTYPE TS><TS>
<context>
  <name>content</name>
  <message>
    <source>HTML fields</source>
    <translation>Champs HTML</translation>
  </message>
</context>
</TS>
