<?php
//
// Created on: <19-Apr-2007 10:30:00 bkoester>
//
// SOFTWARE NAME: zendplatform
// SOFTWARE RELEASE: 1.0.0
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 2007 MEDIATA Communications GmbH
// SOFTWARE LICENSE: GNU General Public License v2.0
//
// CMS NAME: eZ Publish
// CMS RELEASE: 3.8.7 / 3.9.1 / 3.9.2 / 3.9.3
// CVS: $Id: ezinfo.php,v 1.1 2007-08-27 08:44:32 bkoester Exp $
//

class ezdhtmlInfo
{
    function info()
    {
        return array( 'name' => "Zend Platform Extension",
                      'version' => "1.0.0",
                      'copyright' => "Copyright (C) 2007 MEDIATA Communications GmbH",
                      'license' => "GNU General Public License v2.0"
                    );
    }
}
?>
