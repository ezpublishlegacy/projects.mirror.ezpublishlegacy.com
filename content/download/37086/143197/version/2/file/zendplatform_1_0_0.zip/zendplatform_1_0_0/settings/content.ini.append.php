<?php /*

[EditSettings]
#ExtensionDirectories[]=zendplatform
*/ ?>
