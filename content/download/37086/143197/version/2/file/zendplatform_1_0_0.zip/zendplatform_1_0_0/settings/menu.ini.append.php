<?php /*

[NavigationPart]
Part[zendplatform]=Zend Platform

[TopAdminMenu]
Tabs[]=zendplatform

[Topmenu_zendplatform]
NavigationPartIdentifier=zendplatform
Name=Zend Platform
Tooltip=Zend Platform menu
URL[]
URL[default]=zendplatform/list_type
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true



*/ ?>
