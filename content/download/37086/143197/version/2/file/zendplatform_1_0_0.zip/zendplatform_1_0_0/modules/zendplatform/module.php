<?php
// Created on: <19-Apr-2007 10:30:00 bkoester>
//
// SOFTWARE NAME: zendplatform
// SOFTWARE RELEASE: 1.0.0
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 2007 MEDIATA Communications GmbH
// SOFTWARE LICENSE: GNU General Public License v2.0
//
// CMS NAME: eZ Publish
// CMS RELEASE: 3.8.7 / 3.9.1 / 3.9.2 / 3.9.3
// CVS: $Id: module.php,v 1.3 2007-08-27 08:36:15 bkoester Exp $
//
// Definition of Module class
//

$Module = array( 'name' => 'ZendCache' );

$ViewList = array();
$ViewList['list_type'] = array(
    'script' => 'list_cache.php',
    'default_navigation_part' => 'zendplatform',
    'functions' => array( 'view_admin' ),
    'unordered_params' => array( "offset" => "Offset",
                                 "offset2" => "Offset2",
                                 "limit" => "Limit",
                                 "limit2" => "Limit2" ),
    'params' => array( 'ZendCacheID' ) );

$ViewList['clean_type'] = array(
    'script' => 'clean_cache.php',
    'functions' => array( 'view_admin' ),
    'default_navigation_part' => 'zendplatform',
    'params' => array( 'ZendCacheID' ) );

$ViewList['view_type'] = array(
    'script' => 'view_cache.php',
    'functions' => array( 'view_admin' ),
    'default_navigation_part' => 'zendplatform',
    'params' => array( 'ZendCacheID' ) );    
    
$FunctionList['view_admin'] = array( ); 
?>