<? /*

[ModuleSettings]
ExtensionRepositories[]=zendplatform

*/ ?>
