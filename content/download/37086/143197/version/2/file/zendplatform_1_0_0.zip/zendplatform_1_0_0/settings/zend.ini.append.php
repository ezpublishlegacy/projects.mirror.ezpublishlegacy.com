<?PHP
/*

[ZendCacheSettings]
ZendCache=enabled
ZendCacheDir=/tmp/zend_cache
ZendCacheHostDir=/var/www/bjoern.intranet.mediata.com/htdocs

ZendCacheFileName[]
ZendCacheFileName[]=/test/index.php
ZendCacheFileName[]=/ezpublish/index.php
ZendCacheFileName[]=/cms/index.php

[ZDSSettings]
ZDS=disabled

*/
?>