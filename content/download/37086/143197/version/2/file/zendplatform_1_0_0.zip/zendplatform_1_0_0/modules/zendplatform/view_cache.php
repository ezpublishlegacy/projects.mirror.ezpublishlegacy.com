<?php
// Created on: <19-Apr-2007 10:30:00 bkoester>
//
// SOFTWARE NAME: zendplatform
// SOFTWARE RELEASE: 1.0.0
// BUILD VERSION: 
// COPYRIGHT NOTICE: Copyright (C) 2007 MEDIATA Communications GmbH
// SOFTWARE LICENSE: GNU General Public License v2.0
//
// CMS NAME: eZ Publish
// CMS RELEASE: 3.8.7 / 3.9.1 / 3.9.2 / 3.9.3
// CVS: $Id: view_cache.php,v 1.2 2007-08-27 08:36:15 bkoester Exp $

include_once( "lib/ezutils/classes/ezhttptool.php" );
include_once( 'kernel/common/template.php' );

#include_once( "classes/ezinifile.php" );
$ini = eZINI::instance( "zend.ini" );
// get a variable from the file.
$iniVar_ZendCache = $ini->variable( "ZendCacheSettings", "ZendCache" );
$iniVar_ZendCacheDir = $ini->variable( "ZendCacheSettings", "ZendCacheDir" );
$iniVar_ZendCacheHostDir = $ini->variable( "ZendCacheSettings", "ZendCacheHostDir" );
$iniVar_ZendCacheFileName_array = $ini->variable( "ZendCacheSettings", "ZendCacheFileName" );



$http =& eZHTTPTool::instance();

$cacheTypeID = $Params['ZendCacheID'];


$Module =& $Params['Module'];

$userParameters = $Params['UserParameters'];
$offset = isset( $userParameters['offset'] ) ? $userParameters['offset'] : 0;
$limitKey = isset( $userParameters['limit'] ) ? $userParameters['limit'] : '1';
$limitList = array ( '1' => 10,
                     '2' => 25,
                     '3' => 50 );

$limit = $limitList[(string)$limitKey];

$viewParameters = array( 'offset' => $offset,
                         'limitkey' => $limitKey );






$tpl =& templateInit();
$tpl->setVariable( 'module', $Module );

$cacheListArray = array();
/*
foreach( $iniVar_ZendCacheFileName_array as $key => $value )
    {
        
    	if (is_dir($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$key])) {
			$cache_fileowner = posix_getpwuid(fileowner($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$key]));
			$cache_filetime = filemtime($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$key]);
		}else{
			$cache_fileowner = '';
			$cache_filetime = '';
		}
        $cacheListArray[] = array('filename'	=> $iniVar_ZendCacheFileName_array[$key],
								'id'			=> $key,
								'creator'		=> $cache_fileowner['name'],
								'created'		=> $cache_filetime
						);
		
    }
*/
if (is_dir($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$cacheTypeID])) {
	$cache_fileowner = posix_getpwuid(fileowner($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$cacheTypeID]));
	$cache_fileowner = $cache_fileowner['name'];
	$cache_filetime = filemtime($iniVar_ZendCacheDir.$iniVar_ZendCacheHostDir.$iniVar_ZendCacheFileName_array[$cacheTypeID]);
}else{
	$cache_fileowner = '';
	$cache_filetime = '';
}
$cacheListArray = array('filename'	=> $iniVar_ZendCacheFileName_array[$cacheTypeID],
								'id'			=> $cacheTypeID,
								'creator'		=> $cache_fileowner,
								'created'		=> $cache_filetime
						);

$tpl->setVariable( 'view_parameters', $viewParameters );
$tpl->setVariable( 'limit', $limit );
$tpl->setVariable( 'cacheTypeID', $cacheTypeID );
$tpl->setVariable( 'cachelist_array', $cacheListArray );

$Result = array();
$Result['left_menu'] = 'design:parts/content/zendplatform_menu.tpl';
$Result['content'] =& $tpl->fetch( "design:zendplatform/view_cache.tpl" );
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'zendplatform', 'Zend Platform' ) ) );

?>