<?php /*

[ExtensionSettings]
DesignExtensions[]=zendplatform

[StylesheetSettings]

*/ ?>
