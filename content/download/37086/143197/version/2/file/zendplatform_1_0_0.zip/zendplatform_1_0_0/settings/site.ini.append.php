<?PHP
/*
[RegionalSettings]
TranslationExtensions[]=zendplatform

*/
?>