<?PHP
/*
[PHP]
# A list with php functions and their equivelant template operator names
# Giving the operators a different name from the PHP functions
# are recommended, that way you ensure that all operators follow
# the same naming guidelines. It also means that you can change the
# php function later on without doing template changes.
PHPOperatorList[]
#
#
# Zend Platform APIs
#
# Accelerator Functions
#
PHPOperatorList[accelerator_set_status]=accelerator_set_status
# void accelerator_set_status(bool status)
# Description: Disable/enable the Code Acceleration functionality at run time.
# Return Values: none
# Parameters: status - if false, Acceleration is disabled, if true - enabled accelerator_reset
PHPOperatorList[accelerator_reset]=accelerator_reset
# Description: resets the contents of the Accelerator cache. This is not an
# immediate action, the cache is actually reset on the first request once there are
# no scripts running that are using the cache.
#
#
# Output Cache Functions
#
PHPOperatorList[output_cache_disable]=output_cache_disable
#Description: Disables output caching for currently running scripts.
# Return Values: none
# Parameters: none
PHPOperatorList[output_cache_disable_compression]=output_cache_disable_compression
# Description: Does not allow the cache to perform compression on the output
# of the current page. This output will not be compressed, even if the global
# settings would normally allow compression on files of this type.
# Return Values: none
# Parameters: none
PHPOperatorList[output_cache_fetch]=output_cache_fetch
# string output_cache_fetch(string key, string function, int lifetime)
# Description: Gets the code?s return value from the cache if it is there, if not -
# run function and cache the value.
# Return Values: function's return
# Parameters: key - cache key, function - PHP expression, lifetime - data lifetime in cache (seconds)
PHPOperatorList[output_cache_output]=output_cache_output
# string output_cache_output(string key, string function, int lifetime)
# Description: If they cache for the key exists, output it, otherwise capture 
# expression output, cache and pass it out.
# Return Values: expression output
# Parameters: key - cache key, function - PHP expression, lifetime - data lifetime in cache (seconds)
PHPOperatorList[output_cache_remove]=output_cache_remove
# bool output_cache_remove(string filename)
# Description: Removes all the cache data for the given filename.
# Return Values: true if OK, false if something went wrong
# Parameters: filename - full script path on local file system
PHPOperatorList[output_cache_remove_url]=output_cache_remove_url
# bool output_cache_remove_url(string url)
# Description: Remove cache data for the script with given URL (all dependent data is removed)
# Return Values: true if OK
# Parameters: url - the local url for the script
PHPOperatorList[output_cache_remove_key]=output_cache_remove_key
# bool output_cache_remove_key(string key)
# Description: Remove item from PHP API cache by key
# Return Values: true if OK
# Parameters: key - cache key as given to output_cache_get/output_cache_put
PHPOperatorList[output_cache_put]=output_cache_put
# bool output_cache_put(string key, mixed data)
# Description: Puts data in cache according to the assigned key.
# Return Values: true if OK
# Parameters: key - cache key, data - cached data (must not contain objects or resources)
#
#
# Monitor Functions
#
PHPOperatorList[output_cache_get]=output_cache_get
# mixed output_cache_get(string key, int lifetime)
# Description: Gets cached data according to the assigned key.
# Return Values: cached data if cache exists, false otherwise
# Parameters: key - cache key, lifetime - cache validity time (seconds)
PHPOperatorList[output_cache_exists]=output_cache_exists
# bool output_cache_exists(string key, int lifetime)
# Description: If data for assigned key exists, this function outputs it and
# returns a value of true. If not, it starts capturing the output. To be used in pair
# with output_cache_stop.
# Return Values: true if cached data exists
# Parameters: key - cache key, lifetime - cache data validity time (seconds)
PHPOperatorList[output_cache_get]=output_cache_stop
# Description: If output was captured by output_cache_exists, this function
# stops the output capture and stores the data under the key that was given to output_cache_exists()
# Return Values: none
# Parameters: none
#
#
# ZDS (Zend Download Server)
#
PHPOperatorList[zend_send_file]=zend_send_file
# bool zend_send_file(string filename[, string mime_type])
# Description: Send a file using ZDS
# Return Value: FALSE if sending file failed, does not return otherwise
# Parameters: filename - path to the file, mime_type - MIME type of the file, if 
# omitted, taken from configured MIME types file



*/
?>