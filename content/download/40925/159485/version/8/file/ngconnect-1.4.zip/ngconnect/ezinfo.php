<?php

class ngconnectInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/ngconnect">Netgen Connect</a> extension',
            'Version' => '1.4',
            'Copyright' => 'Copyright (C) 2011-2013 Netgen d.o.o.',
            'License' => 'GNU General Public License v2.0'
        );
    }
}
