<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>extension/ngconnect/ngconnect/profile</name>
    <message>
        <source>Profile setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One more step is needed to activate your account and to be able to sign in using regular username and password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you already have a regular account, input your details under "Login to existing account" section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you do not have a regular account, enter your desired username and password under "Create new account" section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you do not wish to create a regular account, simply click the "Skip" button below, and we won't bother you with this again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account with the email address from your social network (%1) already exists. Please enter your login details below to connect to that account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you forgot your password, request a new one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This account already has a connection to selected social network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not allowed to access the site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeat password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login to existing account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create new account</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ngconnect/ngconnect/success</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ngconnect/ngconnect/connections</name>
    <message>
        <source>Your account is currently linked to the following social networks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Social network name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your account currently has no active social network connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional social network connections are available</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
