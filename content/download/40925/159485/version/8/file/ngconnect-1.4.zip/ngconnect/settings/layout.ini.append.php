<?php /* #?ini charset="utf-8"?

[ngconnect]
PageLayout=ngconnect_pagelayout.tpl
UseAccessPass=false
*/ ?>
