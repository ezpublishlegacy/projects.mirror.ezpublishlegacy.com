<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array(
    'script' => 'extension/ngconnect/autoloads/ngconnecttemplatefunctions.php',
    'class' => 'ngConnectTemplateFunctions',
    'operator_names' => array( 'user_exists' )
);
