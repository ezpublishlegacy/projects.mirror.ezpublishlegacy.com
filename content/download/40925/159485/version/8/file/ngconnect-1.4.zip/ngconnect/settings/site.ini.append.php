<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ngconnect

[RegionalSettings]
TranslationExtensions[]=ngconnect

[RoleSettings]
PolicyOmitList[]=ngconnect/login
PolicyOmitList[]=ngconnect/callback
PolicyOmitList[]=ngconnect/profile
PolicyOmitList[]=ngconnect/success
*/ ?>
