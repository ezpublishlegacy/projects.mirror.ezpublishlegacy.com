<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=nivoslider

[ExtensionSettings]
ActiveExtensions[]=nivoslider

[RegionalSettings]
TranslationExtensions[]=nivoslider

*/?>