<?php /* #?ini charset="utf-8"?

[embed_ivoslider]
Source=content/view/embed.tpl
MatchFile=embed/nivoslider.tpl
Subdir=templates
Match[class_identifier]=nivoslider

*/ ?>